

# Generated at 2022-06-25 13:55:20.460669
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Setup
    expected_result = SemanticVersion('1.0.0')
    test_loose_version = LooseVersion('1.0.0')

    # Test
    result = SemanticVersion.from_loose_version(test_loose_version)

    # outputs
    assert result == expected_result


# Generated at 2022-06-25 13:55:29.455506
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    try:
        semantic_version_0.parse('0')
    except ValueError:
        pass
    else:
        raise AssertionError

    semantic_version_0 = SemanticVersion()
    try:
        semantic_version_0.parse('')
    except ValueError:
        pass
    else:
        raise AssertionError

    semantic_version_0 = SemanticVersion()
    try:
        semantic_version_0.parse('0.x')
    except ValueError:
        pass
    else:
        raise AssertionError

    semantic_version_0 = SemanticVersion()
    try:
        semantic_version_0.parse('0.1.x')
    except ValueError:
        pass
    else:
        raise AssertionError

   

# Generated at 2022-06-25 13:55:39.641343
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:55:45.305734
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion()
    # The call SemanticVersion.parse(vstring)
    # does not raise any exception
    try:
        semantic_version_0.parse('1.2.3')
    except Exception:
        pass
    # The call SemanticVersion.parse(vstring)
    # does not raise any exception
    try:
        semantic_version_1.parse('1.2.3')
    except Exception:
        pass


# Generated at 2022-06-25 13:55:53.574154
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.2a1'))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 2
    assert v.prerelease == ('a', 1)
    assert not v.buildmetadata

    v = SemanticVersion.from_loose_version(LooseVersion('1.2.2a1.post1'))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 2
    assert v.prerelease == ('a', 1, 'post', 1)
    assert not v.buildmetadata

    v = SemanticVersion.from_loose_version(LooseVersion('1.2.2a1.post1+g4070fb3'))

# Generated at 2022-06-25 13:56:02.277007
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    from distutils.version import StrictVersion
    from ansible.module_utils.compat.version import LooseVersion


# Generated at 2022-06-25 13:56:06.538842
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    N1 = _Numeric("15")
    assert N1.__lt__("10") == False
    assert N1.__lt__("20") == True
    N2 = _Numeric("15")
    assert N1.__lt__(N2) == False
    assert N1.__lt__(_Numeric("20")) == True
    N3 = _Numeric("15")
    assert N3.__lt__(N2) == False
    assert N3.__lt__(_Numeric("20")) == True


# Generated at 2022-06-25 13:56:13.275267
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    for vstring in (
        '1.4.4',
        '1.4.4-alpha',
        '1.4.4-alpha.1',
        '1.4.4-1.2.3',
        '1.4.4-1.2.3+build.1',
        '1.4.4-1.2.3+build.alpha.1',
        '1.4.4-1.2.3+1.2.3.4',
    ):
        loose_version = LooseVersion(vstring)
        sversion = SemanticVersion.from_loose_version(loose_version)
        assert type(sversion) == SemanticVersion
        assert sversion.vstring == vstring



# Generated at 2022-06-25 13:56:20.411443
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:56:25.894999
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    # Setup
    numeric_object_0 = _Numeric('0')
    numeric_object_1 = _Numeric('1')
    numeric_object_2 = _Numeric('1')

    # Actual
    actual_0 = numeric_object_0.__eq__(numeric_object_1)
    actual_1 = numeric_object_0.__eq__(text_type('0'))
    actual_2 = numeric_object_0.__eq__(int(0))
    actual_3 = numeric_object_1.__eq__(numeric_object_2)

    # Verify
    assert actual_0 is False
    assert actual_1 is True
    assert actual_2 is True
    assert actual_3 is True



# Generated at 2022-06-25 13:56:40.456656
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('1.2.3').parse('1.2.3') is None
    assert SemanticVersion('1.2.3').parse('4.5.6') is None


# Generated at 2022-06-25 13:56:48.207483
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests where input is not a LooseVersion
    try:
        SemanticVersion.from_loose_version(1)
    except ValueError:
        # This test was supposed to fail this way
        pass
    else:
        assert False

    # Tests where input has non integer values
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.0a0'))
    except ValueError:
        # This test was supposed to fail this way
        pass
    else:
        assert False

    # Tests where input is a LooseVersion without extra
    test_loose_version = LooseVersion('1.2.3')
    test_semantic_version = SemanticVersion.from_loose_version(test_loose_version)

# Generated at 2022-06-25 13:56:53.243955
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Unit test for method __lt__ of class _Alpha
    def test__Alpha___lt__():
        x = _Alpha('1')
        y = _Alpha('2')
        assert x < y

    # Unit test for method __eq__ of class _Alpha
    def test__Alpha___eq__():
        x = _Alpha('1')
        y = _Alpha('1')
        assert x == y

    return test__Alpha___lt__(), test__Alpha___eq__()


# Generated at 2022-06-25 13:57:00.843581
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.10.0')) == SemanticVersion('1.10.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.10.10')) == SemanticVersion('1.10.10')
    assert SemanticVersion.from_loose_version(LooseVersion('1.10.10-alpha')) == SemanticVersion('1.10.10-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.10.10-alpha.1')) == SemanticVersion('1.10.10-alpha.1')

# Generated at 2022-06-25 13:57:09.730435
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    instance = SemanticVersion.from_loose_version(loose_version)
    assert instance.vstring == '1.2.3'
    assert instance.major == 1
    assert instance.minor == 2
    assert instance.patch == 3

    loose_version = LooseVersion('1.2.3.4')
    instance = SemanticVersion.from_loose_version(loose_version)
    assert instance.vstring == '1.2.3'
    assert instance.major == 1
    assert instance.minor == 2
    assert instance.patch == 3

    loose_version = LooseVersion('1.2')
    instance = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-25 13:57:11.466661
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('c')
    assert not _Alpha('c') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('a')


# Generated at 2022-06-25 13:57:21.049165
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Assert that passing something other than a LooseVersion
    # to from_loose_version raises a ValueError
    try:
        SemanticVersion.from_loose_version('')
        raise AssertionError('from_loose_version should have failed')
    except ValueError:
        pass
    try:
        SemanticVersion.from_loose_version(None)
        raise AssertionError('from_loose_version should have failed')
    except ValueError:
        pass
    try:
        SemanticVersion.from_loose_version({'a': None})
        raise AssertionError('from_loose_version should have failed')
    except ValueError:
        pass

# Generated at 2022-06-25 13:57:30.098819
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    v = SemanticVersion.from_loose_version(
        LooseVersion("2.2.0")
    )
    assert v.major == 2
    assert v.minor == 2
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()
    assert not v.is_prerelease
    assert v.is_stable

    v = SemanticVersion.from_loose_version(
        LooseVersion("2.2.0-alpha.1")
    )
    assert v.major == 2
    assert v.minor == 2
    assert v.patch == 0
    assert v.prerelease == ('alpha', '1')
    assert v.buildmetadata == ()
    assert v.is_prerelease
    assert not v.is_stable


# Generated at 2022-06-25 13:57:32.226391
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.0.4')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    return semantic_version



# Generated at 2022-06-25 13:57:41.172358
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion, LooseVersion

    loose_version_0 = LooseVersion('1.2.3')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    loose_version_1 = LooseVersion('1.2.3-b1')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)

    loose_version_2 = LooseVersion('1.2.3+b1')
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version_2)

    loose_version_3 = LooseVersion('1.2.3.4.5')

# Generated at 2022-06-25 13:57:50.959182
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test _Alpha less than
    assert _Alpha('alpha') <= _Alpha('beta')
    assert _Alpha('alpha') <= _Alpha('alpha')
    assert not _Alpha('beta') <= _Alpha('alpha')


# Generated at 2022-06-25 13:57:58.637121
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test cases
    # Inputs
    #     arg1 - LooseVersion object, arg2 - Expected output
    test_cases = [
        (LooseVersion('1.0.0'), SemanticVersion('1.0.0')),
        (LooseVersion('1.0.0-0.3.7'), SemanticVersion('1.0.0-0.3.7')),
        (LooseVersion('1.0.0-0.3.7.patch'), SemanticVersion('1.0.0-0.3.7.patch')),
        (LooseVersion('1.0.0+build.1.e0f985a'), SemanticVersion('1.0.0+build.1.e0f985a')),
    ]

    for test_case in test_cases:
        loose_version_obj

# Generated at 2022-06-25 13:58:01.149391
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.1.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '2.1.1'


# Generated at 2022-06-25 13:58:04.590686
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a LooseVersion with a valid semantic version
    loose_version_0 = LooseVersion('1.0.0')

    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    assert semantic_version_0 == '1.0.0'


# Generated at 2022-06-25 13:58:10.487165
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion("0.0.0-rc.1")
    semantic_version_2 = SemanticVersion("0.0.0-rc.1")
    semantic_version_3 = SemanticVersion("0.0.0")
    semantic_version_4 = SemanticVersion("0.1.0-rc.1")
    semantic_version_5 = SemanticVersion("0.0.0-rc.2")
    semantic_version_6 = SemanticVersion("0.0.0-a.0")
    semantic_version_7 = SemanticVersion("0.0.0-a.1")
    semantic_version_8 = SemanticVersion("0.0.0-rc.a")

# Generated at 2022-06-25 13:58:18.463163
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class DummyLooseVersion:
        def __init__(self, vstring):
            self.vstring = vstring

        def set_version(self, version):
            self.version = version

    # Prepare request inputs
    vstring1 = b'1.2.3+abc'
    vstring2 = b'0.9.9'
    vstring3 = b'0.9rc1'

    # Execute the API call through the SDK function
    loose_version1 = DummyLooseVersion(vstring1)
    loose_version2 = DummyLooseVersion(vstring2)
    loose_version3 = DummyLooseVersion(vstring3)
    loose_version1.set_version([1, 2, 3, 'abc'])
    loose_version2.set_version([0, 9, 9])


# Generated at 2022-06-25 13:58:20.344753
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # There is no way to actually test parse, since
    # it needs to raise ValueError when it finds an invalid version
    # and assertRaises does not work because it is a property that
    # only gets created on init
    pass

# Generated at 2022-06-25 13:58:23.449868
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    with raises(ValueError):
        semantic_version_0.parse('1.0.0')
    assert semantic_version_0.major == None
    assert semantic_version_0.minor == None
    assert semantic_version_0.patch == None
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()


# Generated at 2022-06-25 13:58:28.762009
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    # Test with a valid semantic version
    loose_version = LooseVersion('1.2.3')

    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert len(semantic_version.prerelease) == 0
    assert len(semantic_version.buildmetadata) == 0
    assert semantic_version.vstring == '1.2.3'

    # Test with a loose version with prerelease
    loose_version = LooseVersion('1.2.3-alpha.1')

    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1


# Generated at 2022-06-25 13:58:31.586351
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    instance = _Alpha('foo')
    other = 'foo'

    assert instance <= other

    instance = _Alpha('foo')
    other = 'bar'

    assert not instance <= other


# Generated at 2022-06-25 13:58:41.520851
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Check that two identical _Alpha objects are equal using __le__
    a = _Alpha('a')
    b = _Alpha('a')
    assert a <= b == True


# Generated at 2022-06-25 13:58:43.368279
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    semantic_version_0 = SemanticVersion()
    _Alpha_object_0 = _Alpha(semantic_version_0)


# Generated at 2022-06-25 13:58:46.990564
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('1.1.1')
    b = _Alpha('1.1.2')
    c = _Alpha('1.1.1')
    assert (a <= b) is False
    assert (b <= a) is True
    assert (a <= c) is True
    assert (b <= c) is False
    assert (c <= c) is True


# Generated at 2022-06-25 13:58:53.178402
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion("1")
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0 == "1.0.0"

    loose_version_0 = LooseVersion("1.2")
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0 == "1.2.0"

    loose_version_0 = LooseVersion("1.2.3")
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0 == "1.2.3"

    loose_version_0 = LooseVersion("1.2.3.4")
    semantic_version_

# Generated at 2022-06-25 13:59:00.165793
# Unit test for method __le__ of class _Alpha

# Generated at 2022-06-25 13:59:03.088844
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.9.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)



# Generated at 2022-06-25 13:59:09.110599
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    for ver_string in ('1.0.0', '1.0.0-alpha1', '1.0.2-alpha.1.2', '1.0.2+meta.data'):
        loose_version = LooseVersion(ver_string)
        semver = SemanticVersion.from_loose_version(loose_version)
        assert semver == ver_string, '%r -> %r' % (ver_string, semver)


# Generated at 2022-06-25 13:59:15.548217
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test isinstance on success
    loose_version = LooseVersion('1.2')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semantic_version, SemanticVersion)

    # Test ValueError on failure
    loose_version_string = '1-1'
    loose_version_object = LooseVersion(loose_version_string)
    try:
        semantic_version = SemanticVersion.from_loose_version(loose_version_object)
    except ValueError:
        pass
    else:
        raise AssertionError("SemanticVersion failed to raise ValueError on invalid instance")

    # Test ValueError on failure
    loose_version_string = '1'
    loose_version_object = LooseVersion(loose_version_string)
   

# Generated at 2022-06-25 13:59:23.662981
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test simple positive case

    result = _Alpha('alpha').__le__('beta')
    assert result is True, "_Alpha('alpha').__le__('beta') returned %r instead of True" % (result, )

    # Test simple negative case

    result = _Alpha('gamma').__le__('beta')
    assert result is False, "_Alpha('gamma').__le__('beta') returned %r instead of False" % (result, )

    # Test same string

    result = _Alpha('beta').__le__('beta')
    assert result is True, "_Alpha('beta').__le__('beta') returned %r instead of True" % (result, )

    # Test _Numeric

    result = _Alpha('alpha').__le__(_Numeric(2))

# Generated at 2022-06-25 13:59:28.368035
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():

    test_list = [
        'a'
    ]

    for test in test_list:
        assert {
            'a' <= 'a',
            'a' <= 'b',
            'a' <= 'c',
            'a' <= 'd',
            'a' <= 'y',
            'a' <= 'z'
        }


# Generated at 2022-06-25 13:59:39.777910
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    loose_version_0 = LooseVersion()
    semantic_version_1 = SemanticVersion()
    int_0 = semantic_version_1.from_loose_version(loose_version_0)
    assert type(semantic_version_1) == type(semantic_version_0)
    assert type(loose_version_0) == type(int_0)

# Function version_compare

# Generated at 2022-06-25 13:59:48.674438
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # pass
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert semantic_version == '1.2.3'

    # should raise
    with raises(ValueError):
        SemanticVersion.from_loose_version(object())

    # should raise
    with raises(ValueError):
        SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))

    # should raise
    with raises(ValueError):
        SemanticVersion.from_loose_version(LooseVersion('1.2'))

    # should raise
    with raises(ValueError):
        SemanticVersion.from_loose_version(LooseVersion('1.2b.3'))

    # should raise

# Generated at 2022-06-25 13:59:56.103820
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.17.0a1')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.17.0-a1'
    loose_version = LooseVersion('2.0.0b1')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '2.0.0-b1'
    loose_version = LooseVersion('3.1.0rc1')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '3.1.0-rc1'
    loose_version = LooseVersion('4.5.5')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '4.5.5'
    loose_version

# Generated at 2022-06-25 14:00:04.329034
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check if from_loose_version successfully creates an object of class SemanticVersion when given a string
    assert isinstance(SemanticVersion.from_loose_version('0.1.0'), SemanticVersion)

    # Check if from_loose_version successfully creates an object of class SemanticVersion when given a LooseVersion
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('0.1.0')), SemanticVersion)

    # Check if from_loose_version successfully initializes the major version of the SemanticVersion object
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.0')).major == 0

    # Check if from_loose_version successfully initializes the minor version of the SemanticVersion object

# Generated at 2022-06-25 14:00:07.768584
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases = [
        ('1.2', SemanticVersion('1.2.0')),
    ]
    for input, output in test_cases:
        assert SemanticVersion.from_loose_version(LooseVersion(input)) == output


# Generated at 2022-06-25 14:00:14.996072
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:00:19.107934
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v_string = "0.0.1"
    loose_version = LooseVersion(v_string)
    semver = SemanticVersion.from_loose_version(loose_version)
    if not isinstance(semver, SemanticVersion):
        raise AssertionError()
    if v_string != semver.vstring:
        raise AssertionError()


# Generated at 2022-06-25 14:00:22.071482
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    expected = SemanticVersion('1.0.0')
    actual = SemanticVersion.from_loose_version(loose_version)
    assert actual == expected


# Generated at 2022-06-25 14:00:30.035204
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases = (
        '0.1.2',
        '0.1.2-alpha',
        '0.1.2-alpha.beta',
        '0.1.2+build.1',
        '1.2-alpha.3+build.4.beta',
    )
    for test_case in test_cases:
        loose_version = LooseVersion(test_case)
        instance = SemanticVersion.from_loose_version(loose_version)
        assert isinstance(instance, SemanticVersion), '%s should be SemanticVersion' % instance



# Generated at 2022-06-25 14:00:33.530138
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for proper behavior of method from_loose_version
    # of class SemanticVersion when passed a LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3a')) == SemanticVersion('1.2.3-a')


# Generated at 2022-06-25 14:00:56.359860
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    valid_result = isinstance(semantic_version, text_type)
    assert valid_result is True


# Generated at 2022-06-25 14:01:04.293155
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # simple test
    semantic_version = SemanticVersion.from_loose_version('1.2.3-4.5.6.7')
    assert semantic_version._cmp('1.2.3') == 0

    # pre-release
    semantic_version = SemanticVersion.from_loose_version('1.2.3-alpha.1')
    assert semantic_version._cmp('1.2.3') == -1
    assert semantic_version._cmp('1.2.3-alpha.5') == -1
    assert semantic_version._cmp('1.2.3-beta.1') == -1

    # build metadata
    semantic_version = SemanticVersion.from_loose_version('1.2.3+build.1')
    assert semantic_version._cmp('1.2.3') == 0

#

# Generated at 2022-06-25 14:01:07.727232
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.8.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    # Should be equal to the text_type representation
    assert semantic_version == text_type(loose_version)



# Generated at 2022-06-25 14:01:12.928933
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).vstring == '1.0.0'


# Generated at 2022-06-25 14:01:19.928270
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version_0 = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version_0) == SemanticVersion('1.2.3')

    # Test with a string
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')

    # Test with an instance of SemanticVersion
    semantic_version_0 = SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(semantic_version_0) == SemanticVersion('1.2.3')


# Generated at 2022-06-25 14:01:28.307636
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import collections
    import os
    import sys

    LooseVersion = collections.namedtuple('LooseVersion', ('vstring', 'version'))


# Generated at 2022-06-25 14:01:31.955377
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion("1.0.0"))
    semantic_version_2 = SemanticVersion.from_loose_version("1.0.0")

    assert(semantic_version_1 == semantic_version_2)


# Generated at 2022-06-25 14:01:34.207819
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    expected = SemanticVersion('1.8.0')
    loose = LooseVersion('1.8c1')
    semantic = SemanticVersion.from_loose_version(loose)
    assert semantic == expected


# Generated at 2022-06-25 14:01:40.303203
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test SemanticVersion.from_loose_version"""

# Generated at 2022-06-25 14:01:46.648765
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion()
    semantic_version_2 = SemanticVersion()
    semantic_version_3 = SemanticVersion()
    semantic_version_4 = SemanticVersion()
    semantic_version_5 = SemanticVersion()
    semantic_version_6 = SemanticVersion()

    # simple conversion
    loose_version = LooseVersion("1.0")
    assert(semantic_version_0.from_loose_version(loose_version) == loose_version)

    # prerelease and buildmetadata
    loose_version = LooseVersion("1.0rc2+foo.bar")
    assert(semantic_version_1.from_loose_version(loose_version) == loose_version)

    # prerelease and buildmetadata without rc
    loose

# Generated at 2022-06-25 14:02:10.023214
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.version import LooseVersion
    from ansible.module_utils.six import u

    assert SemanticVersion.from_loose_version('10.99.99') == SemanticVersion('10.99.99')
    assert SemanticVersion.from_loose_version('10.99.99.99') == SemanticVersion('10.99.99.99')

    v = SemanticVersion.from_loose_version(LooseVersion('10.99.99.99'))
    assert v == SemanticVersion('10.99.99.99')

    assert SemanticVersion.from_loose_version('10.99.99.99-rc1') == SemanticVersion('10.99.99.99-rc1')

# Generated at 2022-06-25 14:02:17.945761
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v0 = str(123) # Could be any string that does not match the
                  # semantic versioning spec
    v1 = "0.11.4"
    v2 = "1.2.3-4.5"
    v3 = "1.2.3-alpha.5+blah"
    v4 = "1.2.3-4.5.6/blah/blah"
    v5 = "1.2.3-4.5.6/blah/blah+b"
    v6 = "1.2.3-4.5.6/blah/blah-b"
    v7 = "1.2.3-4.5.6/blah/blah+b-c"

# Generated at 2022-06-25 14:02:23.153063
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test if input is not of type LooseVersion
    try:
        SemanticVersion.from_loose_version(0)
    except ValueError:
        pass
    else:
        assert False, "Input is not of type LooseVersion, but no ValueError was raised"

    # Test if input is of type LooseVersion
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.2.3.4-alpha.4'))
    except ValueError:
        assert False, "Input is of type LooseVersion, but ValueError was raised"

# Generated at 2022-06-25 14:02:32.549818
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # The following test cases are based off of
    # Semantic Versioning 2.0.0
    # https://semver.org/#is-there-a-suggested-regular-expression-regex-to-check-a-semver-string

    # 1.2.3-alpha
    loose_version = LooseVersion('1.2.3-alpha')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.3-alpha'

    # 1.2.3-alpha+n.sha.5114f85
    loose_version = LooseVersion('1.2.3-alpha+n.sha.5114f85')
    semantic_version = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-25 14:02:35.475315
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = LooseVersion("1.1.1a")
    semver = SemanticVersion.from_loose_version(version)
    assert semver.vstring == "1.1.1-0.a"


# Generated at 2022-06-25 14:02:43.158329
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Arrange
    # This is a non-compliant LooseVersion
    Loose_Version = LooseVersion('1.0-alpha.3+build.id')

    # Act
    result = SemanticVersion.from_loose_version(Loose_Version)

    # Assert
    assert isinstance(result, SemanticVersion)
    assert result.major == 1
    assert result.minor == 0
    assert result.patch == 0
    assert result.prerelease == ('alpha', '3')
    assert result.buildmetadata == ('build', 'id')
    assert str(result) == '1.0.0-alpha.3+build.id'


# Generated at 2022-06-25 14:02:51.766996
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test SemanticVersion.from_loose_version
    """

    loose_version = LooseVersion('2.3.4')
    result = SemanticVersion.from_loose_version(loose_version)
    assert result.major == 2
    assert result.minor == 3
    assert result.patch == 4
    assert result.prerelease is None
    assert result.buildmetadata is None

    loose_version = LooseVersion('2.3.4-beta.1')
    result = SemanticVersion.from_loose_version(loose_version)
    assert result.major == 2
    assert result.minor == 3
    assert result.patch == 4
    assert result.prerelease == ('beta', '1')
    assert result.buildmetadata is None


# Generated at 2022-06-25 14:02:59.005772
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:03:00.384997
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('1.1.1'))


# Generated at 2022-06-25 14:03:02.562596
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.2.4')
    semantic_version = SemanticVersion.from_loose_version(
        loose_version
    )
    assert semantic_version.vstring == '2.2.4'



# Generated at 2022-06-25 14:04:08.307664
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with exception
    try:
        SemanticVersion.from_loose_version(1)
    except ValueError as e:
        assert e.args[0] == '1 is not a LooseVersion'
        assert str(e) == '1 is not a LooseVersion'
    else:
        assert False

    # Test with exception
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.0a1'))
    except ValueError as e:
        assert e.args[0] == 'Non integer values in LooseVersion ("1.0a1")'
        assert str(e) == 'Non integer values in LooseVersion ("1.0a1")'
    else:
        assert False

    # Test without exception

# Generated at 2022-06-25 14:04:13.119336
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # This should work just fine
    assert not SemanticVersion.from_loose_version('2018.5.0')
    # This should work just fine
    assert not SemanticVersion.from_loose_version('2018.5.0-beta.1')
    # This should work just fine
    assert not SemanticVersion.from_loose_version('2018.5.0-rc.1')
    # This should work just fine
    assert not SemanticVersion.from_loose_version('2018.5.0+1')



# Generated at 2022-06-25 14:04:15.249310
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.1.3')
    SemanticVersion.from_loose_version(loose_version)

test_case_0()
test_SemanticVersion_from_loose_version()

# Generated at 2022-06-25 14:04:20.182163
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test = LooseVersion('0.11.3+86f0eab97')
    test1 = SemanticVersion.from_loose_version(test)
    assert str(test1) == "0.11.3+86f0eab97"


# Generated at 2022-06-25 14:04:22.855269
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # When
    version = SemanticVersion.from_loose_version(LooseVersion('0.1.1'))
    # Then
    assert version == '0.1.1'



# Generated at 2022-06-25 14:04:26.819904
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible.module_utils.semver
    try:
        version = ansible.module_utils.semver.SemanticVersion.from_loose_version('1.9.3')
        assert version == SemanticVersion('1.9.3')
    except:
        raise AssertionError('Unable to convert LooseVersion to SemanticVersion')



# Generated at 2022-06-25 14:04:32.543683
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    s = '1.2.3+4.5.6'
    loose_version_0 = LooseVersion(s)
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_0)
    s = '1.2.3-5.6.7'
    loose_version_1 = LooseVersion(s)
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version_1)
    s = '1.2.3-5.6.7+8'
    loose_version_2 = LooseVersion(s)
    semantic_version_3 = SemanticVersion.from_loose_version(loose_version_2)
    pass


# Generated at 2022-06-25 14:04:38.978829
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    # Test with LooseVersion(2.2.2)
    assert SemanticVersion.from_loose_version(LooseVersion('2.2.2')) == SemanticVersion('2.2.2')

    # Test with LooseVersion(2.2.2.2)
    assert SemanticVersion.from_loose_version(LooseVersion('2.2.2.2')) == SemanticVersion('2.2.2')

    # Test with LooseVersion(2.2.2.2.2)
    assert SemanticVersion.from_loose_version(LooseVersion('2.2.2.2.2')) == SemanticVersion('2.2.2')

    # Test with LooseVersion(2.2.2-2.

# Generated at 2022-06-25 14:04:46.709615
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')).vstring == '1.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2-alpha.1')).vstring == '1.2.0-alpha.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')).vstring == '1.2.3-alpha.1'

# Generated at 2022-06-25 14:04:52.805947
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check that the function raises ValueError when appropriate
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(None)
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('1.2.3')
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))

    # Test the function with various inputs
    loose_version_0 = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version_0) == SemanticVersion('1.2.3')

    loose_version_1 = LooseVersion('1.2.3.4')