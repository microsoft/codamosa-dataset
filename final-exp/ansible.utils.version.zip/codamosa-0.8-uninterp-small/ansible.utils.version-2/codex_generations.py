

# Generated at 2022-06-25 13:55:22.775226
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class TestLooseVersion(LooseVersion):
        version = [1, 2, 3]

    assert SemanticVersion.from_loose_version(TestLooseVersion()) == SemanticVersion('1.2.3')

    with pytest.raises(ValueError):
        class TestLooseVersion2(LooseVersion):
            version = [1, 2, 3, 'a']
        SemanticVersion.from_loose_version(TestLooseVersion2())

    class TestLooseVersion3(LooseVersion):
        version = [1, 2, 3, '-a']
        vstring = '1.2.3-a'
    assert SemanticVersion.from_loose_version(TestLooseVersion3()) == SemanticVersion(TestLooseVersion3().vstring)


# Generated at 2022-06-25 13:55:27.748269
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()
    semantic_version.parse('1.2.3-alpha.4.5+foo.bar')
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert semantic_version.prerelease == ('alpha', 4, 5)
    assert semantic_version.buildmetadata == ('foo', 'bar')



# Generated at 2022-06-25 13:55:37.839304
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion('1.0.0')

    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert not v.prerelease
    assert not v.buildmetadata

    v = SemanticVersion('1.0.0-rc1')

    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Numeric('rc1'),)
    assert not v.buildmetadata

    v = SemanticVersion('1.0.0-rc1+20130313144700')

    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Numeric('rc1'),)

# Generated at 2022-06-25 13:55:41.665408
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    vstring = text_type(semantic_version_0)
    try:
        semantic_version_0.parse(vstring)
    except ValueError as e:
        raise AssertionError(e)
    else:
        pass


# Generated at 2022-06-25 13:55:48.524614
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    test_cases = (
        ('0.1.1', (0, 1, 1)),
        ('1.2.3', (1, 2, 3)),
        ('1.1.1.1', ValueError),
        ('1.a.1', ValueError),
        ('a.1.1', ValueError),
        ('1.1.b', ValueError),
    )
    for vstring, expected in test_cases:
        try:
            semantic_version = SemanticVersion(vstring)
            assert semantic_version.major == expected[0]
            assert semantic_version.minor == expected[1]
            assert semantic_version.patch == expected[2]
        except ValueError:
            assert isinstance(expected, type) and issubclass(expected, ValueError)

# Generated at 2022-06-25 13:55:57.833596
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:56:03.419872
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a valid `LooseVersion`
    v = LooseVersion('2.0.0b1')
    result = SemanticVersion.from_loose_version(v)
    assert result.major == 2
    assert result.minor == 0
    assert result.patch == 0
    assert result.prerelease == (_Numeric(0),)
    assert result.buildmetadata == ()

    # Test with a `LooseVersion` that contains a single number
    # Should be set as the patch version
    v = LooseVersion('2')
    result = SemanticVersion.from_loose_version(v)
    assert result.major == 0
    assert result.minor == 0
    assert result.patch == 2
    assert result.prerelease == ()
    assert result.buildmetadata == ()

    # Test with a `LooseVersion

# Generated at 2022-06-25 13:56:04.508425
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))


# Generated at 2022-06-25 13:56:07.656783
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion().parse('1.2.3') == (1, 2, 3)
    assert SemanticVersion().parse('1.2.3-beta') == (1, 2, 3, 'beta')
    assert SemanticVersion().parse('1.2.3+build') == (1, 2, 3, None, 'build')


# Generated at 2022-06-25 13:56:15.077614
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test passing in a valid semantic version
    semantic_version_0 = SemanticVersion()
    # vstring of semantic_version_0 has default value None
    assert semantic_version_0.vstring is None
    # major of semantic_version_0 has default value None
    assert semantic_version_0.major is None
    # minor of semantic_version_0 has default value None
    assert semantic_version_0.minor is None
    # patch of semantic_version_0 has default value None
    assert semantic_version_0.patch is None
    # prerelease of semantic_version_0 has default value ()
    assert semantic_version_0.prerelease == ()
    # buildmetadata of semantic_version_0 has default value ()
    assert semantic_version_0.buildmetadata == ()


# Generated at 2022-06-25 13:56:30.949488
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible.module_utils.basic


# Generated at 2022-06-25 13:56:39.322359
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Unit test for method from_loose_version of class SemanticVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).core == (1, 2, 3)
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).prerelease == ()
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).buildmetadata == ()
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3c')).core == (1, 2, 3)

# Generated at 2022-06-25 13:56:47.319064
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test basic usage
    loose_version = LooseVersion('1.0.0')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.0.0'
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    # Test with pre-release and build metadata
    loose_version = LooseVersion('1.0.0-rc-1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.0.0-rc-1'
    assert semver.prerelease == ('rc', '1')
    assert semver.buildmetadata == ()

    loose_version = LooseVersion('1.0.0+20181012155953')
    semver = Semantic

# Generated at 2022-06-25 13:56:51.855442
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # From a LooseVersion
    lv1 = LooseVersion('2.3.5')
    assert isinstance(SemanticVersion.from_loose_version(lv1), SemanticVersion)
    lv2 = LooseVersion('5.5.0')
    assert isinstance(SemanticVersion.from_loose_version(lv2), SemanticVersion)


# Generated at 2022-06-25 13:56:58.736007
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_input_1 = LooseVersion('1.0')
    expected_output_1 = SemanticVersion('1.0.0')
    actual_output_1 = SemanticVersion.from_loose_version(test_input_1)
    assert actual_output_1 == expected_output_1

    test_input_2 = LooseVersion('1.0.1')
    expected_output_2 = SemanticVersion('1.0.1')
    actual_output_2 = SemanticVersion.from_loose_version(test_input_2)
    assert actual_output_2 == expected_output_2

    test_input_3 = LooseVersion('1.0.1a1')
    expected_output_3 = SemanticVersion('1.0.1-a1')
    actual_output_3 = SemanticVersion

# Generated at 2022-06-25 13:57:01.954132
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert isinstance(version, SemanticVersion)
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3



# Generated at 2022-06-25 13:57:10.490942
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')).vstring == '1.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-dev')).vstring == '1.2.3-dev'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-dev-1')).vstring == '1.2.3-dev-1'

# Generated at 2022-06-25 13:57:19.517845
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '2.1.1'
    loose_version = LooseVersion(vstring)
    assert loose_version.vstring == vstring
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert semantic_version.major == 2
    assert semantic_version.minor == 1
    assert semantic_version.patch == 1
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()

    vstring = '4.4.0-alpha.1'
    loose_version = LooseVersion(vstring)
    assert loose_version.vstring == vstring
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert semantic_version.major == 4
    assert semantic_version.minor == 4
    assert semantic

# Generated at 2022-06-25 13:57:28.633406
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a string without build metadata or pre-release data
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion('2.0.0'))
    assert semantic_version_1.major == 2
    assert semantic_version_1.minor == 0
    assert semantic_version_1.patch == 0
    assert semantic_version_1.prerelease == ()
    assert semantic_version_1.buildmetadata == ()

    # Test a string with pre-release data but no build metadata
    semantic_version_0 = SemanticVersion()
    semantic_version_2 = SemanticVersion.from_loose_version(LooseVersion('2.0.0-1.alpha'))
    assert semantic_version_2.major == 2
    assert semantic_version_2

# Generated at 2022-06-25 13:57:37.106098
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4-final+rc.1.full')) == SemanticVersion('1.2.3-4.final')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.final-rc.1.full')) == SemanticVersion('1.2.3-4.final')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4.final')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')

# Generated at 2022-06-25 13:57:51.661402
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('0.0.0') == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version('0.0.1') == SemanticVersion('0.0.1')
    assert SemanticVersion.from_loose_version('1.1.1') == SemanticVersion('1.1.1')

    assert SemanticVersion.from_loose_version('0.0.0a') == SemanticVersion('0.0.0-a')
    assert SemanticVersion.from_loose_version('0.0.0a.0') == SemanticVersion('0.0.0-a.0')

# Generated at 2022-06-25 13:57:54.673348
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()

    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion("2.1.1"))
    assert semantic_version_0.__eq__(semantic_version_1) is False


# Generated at 2022-06-25 13:58:02.138900
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Instantiating the class
    import ast
    import sys
    from ansible.module_utils.six import string_types
    from ansible.module_utils.basic import AnsibleModule

    def main():
        # argv[0] is the filename
        argv = sys.argv[1:]
        # convert to integer if not string

# Generated at 2022-06-25 13:58:09.092021
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version_0 = SemanticVersion.from_loose_version(LooseVersion('1.1.1'))
    assert text_type(version_0) == '1.1.1'
    version_1 = SemanticVersion.from_loose_version(LooseVersion('1.1.1+foo.bar'))
    assert text_type(version_1) == '1.1.1+foo.bar'
    version_2 = SemanticVersion.from_loose_version(LooseVersion('1.1.1-1.1'))
    assert text_type(version_2) == '1.1.1-1.1'
    version_3 = SemanticVersion.from_loose_version(LooseVersion('1.1.1-1.1+foo.bar'))

# Generated at 2022-06-25 13:58:14.176336
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.1.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 0
    assert semantic_version.minor == 1
    assert semantic_version.patch == 3
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()
    assert semantic_version.vstring == '0.1.3'


# Generated at 2022-06-25 13:58:21.089706
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_loose_version = LooseVersion("3.3.3")
    semantic_version = SemanticVersion.from_loose_version(test_loose_version)
    assert(isinstance(semantic_version, SemanticVersion))
    assert(isinstance(semantic_version.buildmetadata, tuple))
    assert(len(semantic_version.buildmetadata) == 0)
    assert(semantic_version.core == (3, 3, 3))
    assert(semantic_version.is_stable)
    assert(not semantic_version.is_prerelease)
    assert(isinstance(semantic_version.major, int))
    assert(isinstance(semantic_version.minor, int))
    assert(isinstance(semantic_version.patch, int))

# Generated at 2022-06-25 13:58:25.137529
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # arrange
    loose_version = LooseVersion('2.2.0')
    sut = SemanticVersion()

    # act
    actual = sut.from_loose_version(loose_version)

    # assert
    assert actual.major == loose_version.version[0]
    assert actual.minor == loose_version.version[1]
    assert actual.patch == loose_version.version[2]
    assert not actual.is_prerelease


# Generated at 2022-06-25 13:58:34.105851
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    Just put in a whole mess of test cases, with expected results
    '''
    # We want to test with some empty scenarios so we need to
    # start with a good LooseVersion

# Generated at 2022-06-25 13:58:38.134539
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3.4")).vstring == "1.2.3"
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-4")).vstring == "1.2.3-4"


# Generated at 2022-06-25 13:58:46.497912
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion with a version number
    assert(SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3'))
    # LooseVersion with a version number and build metadata
    assert(SemanticVersion.from_loose_version(LooseVersion('1.2.3+4.5.6')) == SemanticVersion('1.2.3+4.5.6'))
    # LooseVersion with a version number and prerelease
    assert(SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5.6')) == SemanticVersion('1.2.3-4.5.6'))
    # LooseVersion with a version number and build metadata and prerelease

# Generated at 2022-06-25 13:58:59.216760
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Empty LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion()) == SemanticVersion('0.0.0')

    # Simple version string that is already semver
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    # Simple version string with extra . in it
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')

    # Simple version string with extra . in it and an alpha release
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4-alpha')) == SemanticVersion('1.2.3-alpha')

    # Simple version string with extra . in it

# Generated at 2022-06-25 13:59:09.152786
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with py2
    try:
        import ansible.module_utils.six.moves.builtins as builtins
    except ImportError:
        import __builtin__ as builtins
    builtins.str = builtins.unicode
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('1.2.3')), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('1.2.3')), Version)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('1.2.3-beta')), SemanticVersion)

# Generated at 2022-06-25 13:59:15.889777
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2
    loose_version = LooseVersion('0.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 0
    assert semantic_version.minor == 1
    assert semantic_version.patch == 0
    assert not semantic_version.prerelease
    assert not semantic_version.buildmetadata
    assert not semantic_version.is_prerelease
    assert semantic_version.is_stable

    loose_version = LooseVersion('1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert not semantic_version.prerelease


# Generated at 2022-06-25 13:59:23.998573
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert semantic_version.vstring == '1.2.3'

    # Test where version includes a prerelease
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre'))
    assert semantic_version.vstring == '1.2.3-pre'

    # Test where version includes build metadata
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.2.3+build'))
    assert semantic_version.vstring == '1.2.3+build'

    # Test invalid versions

# Generated at 2022-06-25 13:59:32.879882
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:59:34.874002
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4+abc')) == SemanticVersion('1.2.3-4+abc')



# Generated at 2022-06-25 13:59:43.312944
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test: Using a text of 3.10.12-80.0.0.0+ansible
    test_case_true_0 = SemanticVersion.from_loose_version(LooseVersion('3.10.12-80.0.0.0+ansible'))

    assert True == (test_case_true_0.major == 3)
    assert True == (test_case_true_0.minor == 10)
    assert True == (test_case_true_0.patch == 12)
    assert True == (test_case_true_0.prerelease == (_Numeric('80'), _Numeric('0'), _Numeric('0'), _Numeric('0')))
    assert True == (test_case_true_0.buildmetadata == (_Alpha('ansible'),))
    # Test: Using a text of 3.

# Generated at 2022-06-25 13:59:52.011128
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Normal use case
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+build')) == SemanticVersion('1.0.0+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha+build')) == SemanticVersion('1.0.0-alpha+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')

# Generated at 2022-06-25 13:59:59.397053
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for the SemanticVersion class
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')).vstring == '0.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('0.0')).vstring == '0.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('0')).vstring == '0.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('0-parrot-1')).vstring == '0.0.0-parrot-1'
    assert SemanticVersion.from_loose_version(LooseVersion('0.0-parrot-1')).vstring == '0.0.0-parrot-1'

# Generated at 2022-06-25 14:00:08.118845
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Setup
    vstring_0 = '1.2.3'
    loose_version_0 = LooseVersion(vstring_0)

    # Procedure
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    # Assertion
    assert(semantic_version_0.core == (1, 2, 3))
    assert(semantic_version_0.is_prerelease is False)
    assert(semantic_version_0.prerelease == ())

    # Setup
    vstring_1 = '1.2.3-alpha'
    loose_version_1 = LooseVersion(vstring_1)

    # Procedure
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)

    # Assertion

# Generated at 2022-06-25 14:00:28.071874
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion()
    loose_version_0.parse('0.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.major == 0
    assert semantic_version_0.minor == 0
    assert semantic_version_0.patch == 0
    assert not semantic_version_0.prerelease
    assert not semantic_version_0.buildmetadata

    loose_version_1 = LooseVersion()
    loose_version_1.parse('0.0.0-alpha')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert semantic_version_1.major == 0
    assert semantic_version_1.minor == 0
    assert semantic_version

# Generated at 2022-06-25 14:00:32.839594
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    script_module_utils_version = LooseVersion("0.2.0")
    semantic_version = SemanticVersion.from_loose_version(script_module_utils_version)
    assert semantic_version.vstring == "0.2.0"
    assert semantic_version.major == 0
    assert semantic_version.minor == 2
    assert semantic_version.patch == 0


# Generated at 2022-06-25 14:00:40.475428
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion()
    with pytest.raises(ValueError) as exc:
        SemanticVersion.from_loose_version(loose_version)
    assert exc.value.args[0] == "%r is not a LooseVersion" % loose_version

    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert(semantic_version == '1.2.3')

    loose_version = LooseVersion('1.2.3a1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert(semantic_version == '1.2.3a1')

    loose_version = LooseVersion('1.2.3-alpha.0')

# Generated at 2022-06-25 14:00:46.154010
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Unit test for method from_loose_version of class SemanticVersion
    from distutils.version import LooseVersion

    v = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.2.3')

    v = LooseVersion('1.2.3.4')
    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.2.3')

    v = LooseVersion('1.2.3a4')
    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.2.3a4')

    v = LooseVersion('0.0.0')
    assert SemanticVersion.from_loose_version(v) == SemanticVersion('0.0.0')



# Generated at 2022-06-25 14:00:53.336138
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion()
    try:
        SemanticVersion.from_loose_version(loose_version_0)
    except ValueError:
        pass
    else:
        print("Error at \'except\'")
    try:
        SemanticVersion.from_loose_version(None)
    except ValueError:
        pass
    else:
        print("Error at \'except\'")
    try:
        SemanticVersion.from_loose_version("")
    except ValueError:
        pass
    else:
        print("Error at \'except\'")
    try:
        SemanticVersion.from_loose_version("")
    except ValueError:
        pass
    else:
        print("Error at \'except\'")
    loose_version_1 = LooseVersion("1.alpha")


# Generated at 2022-06-25 14:01:01.012965
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:05.549786
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion, LooseVersion
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('0.3.2'))
    assert semantic_version.major == 0
    assert semantic_version.minor == 3
    assert semantic_version.patch == 2
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()



# Generated at 2022-06-25 14:01:10.109205
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
  version = '1.2.3'
  loose_version = LooseVersion(version)
  semantic_version = SemanticVersion.from_loose_version(loose_version)
  assert semantic_version.major == 1
  assert semantic_version.minor == 2
  assert semantic_version.patch == 3


# Generated at 2022-06-25 14:01:18.470311
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:22.776221
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '2.2.0_20150220'
    loose_version = LooseVersion(vstring)

    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert semantic_version.is_stable

    assert semantic_version == '2.2.0'


# Generated at 2022-06-25 14:01:50.241445
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        v = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
        assert v.major == 1
        assert v.minor == 2
        assert v.patch == 3
    except ValueError:
        raise
    try:
        v = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
        assert v.major == 1
        assert v.minor == 2
        assert v.patch == 3
    except ValueError:
        raise
    except AssertionError:
        raise

# Generated at 2022-06-25 14:01:57.051938
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    loose_version0 = LooseVersion('1.1.0')
    loose_version1 = LooseVersion('1.1.0-dev.1')
    loose_version2 = LooseVersion('1.1.1-dev.1')
    loose_version3 = LooseVersion('1.1.1')
    loose_version4 = LooseVersion('1.1.1+build-1')

    # Try to construct a SemanticVersion from loose_version0 and
    # check that it matches 1.1.0
    semantic_version0 = SemanticVersion.from_loose_version(loose_version0)
    assert semantic_version0 != loose_version1
    assert semantic_version0 != loose_version2
    assert semantic_version0 != loose

# Generated at 2022-06-25 14:02:04.213350
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # invalid vstring
    with pytest.raises(ValueError) as e:
        SemanticVersion.from_loose_version(LooseVersion('2.3.1.2'))
    assert 'invalid semantic version' in str(e)

    # non integer values
    with pytest.raises(ValueError) as e:
        SemanticVersion.from_loose_version(LooseVersion('2.2.2a'))
    assert 'Non integer values' in str(e)

    # missing version
    with pytest.raises(ValueError) as e:
        SemanticVersion.from_loose_version(LooseVersion(''))
    assert 'is not a LooseVersion' in str(e)
    with pytest.raises(ValueError) as e:
        SemanticVersion.from_loose

# Generated at 2022-06-25 14:02:12.071703
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Verify that SemanticVersion.from_loose_version() works as expected"""
    # Test that an exception is raised when passed a non-LooseVersion object
    try:
        SemanticVersion.from_loose_version(12345)
    except ValueError:
        pass
    else:
        raise AssertionError()


    # Test that a ValueError is raised if the LooseVersion does not include
    # an identifiable version (i.e. no version component)
    try:
        SemanticVersion.from_loose_version(LooseVersion('FOO'))
    except ValueError:
        pass
    else:
        raise AssertionError()

    # Test that a ValueError is raised if the LooseVersion contains non-
    # integers in the version component

# Generated at 2022-06-25 14:02:15.504795
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(
        loose_version='0.3.0.0.post1'
    )

    semantic_version_1 = SemanticVersion.from_loose_version(
        loose_version=None
    )



# Generated at 2022-06-25 14:02:16.122411
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_case_0()

# Generated at 2022-06-25 14:02:19.671865
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    # Call method from_loose_version of class SemanticVersion
    try:
        semantic_version_0.from_loose_version(10)
    except ValueError:
        pass
    else:
        assert False, "Failure with the call of method from_loose_version of class SemanticVersion"


# Generated at 2022-06-25 14:02:26.262223
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Validate ``SemanticVersion.from_loose_version`` method"""
    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1')).vstring == '1.1.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')).vstring == '1.1.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1-alpha')).vstring == '1.0.0-alpha'
    assert SemanticVersion.from_loose_version(LooseVersion('1-alpha.alpha')).vstring == '1.0.0-alpha.alpha'

# Generated at 2022-06-25 14:02:31.060686
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.1~alpha.1.2')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.is_stable is False
    assert semantic_version.is_prerelease is True
    assert semantic_version == loose_version


# Generated at 2022-06-25 14:02:39.808543
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        # This is a valid SemanticVersion but an invalid LooseVersion
        semantic_version_0 = SemanticVersion('1.0.0-alpha.1+build.1')
    except ValueError:
        assert False, "Unable to instantiate SemanticVersion with vstring set to '1.0.0-alpha.1+build.1'"
    try:
        # This is a valid LooseVersion but an invalid SemanticVersion
        loose_version_0 = LooseVersion('1.0.0-alpha.1+build.1')
    except ValueError:
        assert False, "Unable to instantiate LooseVersion with vstring set to '1.0.0-alpha.1+build.1'"
    # The value of attribute vstring of semantic_version_0 before the call to
    # method from_loose_

# Generated at 2022-06-25 14:03:22.364735
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.7.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)


# Generated at 2022-06-25 14:03:27.475458
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('0.1.2')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.__eq__('0.1.2')

    loose_version_1 = LooseVersion('1.1.0-alpha+build01')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert semantic_version_1.__eq__('1.1.0-alpha+build01')


# Generated at 2022-06-25 14:03:35.199425
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for "from_loose_version" method of class "SemanticVersion"."""

    # Unit test for invalid parameters type
    try:
        SemanticVersion.from_loose_version('0')
    except ValueError:
        build_semantic_version_from_loose_version_expected_exception_raised = True
    else:
        build_semantic_version_from_loose_version_expected_exception_raised = False
    assert build_semantic_version_from_loose_version_expected_exception_raised

    # Unit test for invalid version string format
    try:
        SemanticVersion.from_loose_version(LooseVersion('0.1.2.3.4'))
    except ValueError:
        build_semantic_version_from_loose_version_expected_ex

# Generated at 2022-06-25 14:03:37.686077
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    expected = SemanticVersion('1.2.3')
    test_input = LooseVersion('1.2.3')
    result = SemanticVersion.from_loose_version(test_input)
    assert result == expected


# Generated at 2022-06-25 14:03:41.148761
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.1.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version_0 == '2.1.1'

# Generated at 2022-06-25 14:03:41.671225
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    pass

# Generated at 2022-06-25 14:03:47.099176
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose = LooseVersion('1.2.4')

    # SemanticVersion object should be created for LooseVersion object
    try:
        semantic_version_0 = SemanticVersion.from_loose_version(loose)
    except ValueError:
        assert False

    # ValueError should be raised when input is not a LooseVersion object
    with pytest.raises(ValueError):
        semantic_version_1 = SemanticVersion.from_loose_version('1.2.4')


# Generated at 2022-06-25 14:03:48.720392
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = SemanticVersion.from_loose_version(LooseVersion('x.x.x'))


# Generated at 2022-06-25 14:03:56.109482
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '1.0.0'
    loose_version = LooseVersion(vstring)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == vstring
    assert semantic_version.is_stable
    assert not semantic_version.is_prerelease
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()

    vstring = '1.0.0-alpha.1'
    loose_version = LooseVersion(vstring)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == vstring

# Generated at 2022-06-25 14:04:02.476072
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('1.0'))
    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 0
    assert semantic_version_0.patch == 0
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()
    assert isinstance(semantic_version_0, SemanticVersion)
    assert repr(semantic_version_0) == "SemanticVersion('1.0.0')"
    # Test against a LooseVersion with a prerelease
    semantic_version_2 = SemanticVersion.from_loose_version(LooseVersion('1.0-beta.1'))
    assert semantic_version_2.major == 1
    assert semantic_version_2.min