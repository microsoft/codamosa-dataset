

# Generated at 2022-06-25 13:55:08.407974
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    if _Numeric(1) < _Numeric(2):
        assert True
    else:
        assert False


# Generated at 2022-06-25 13:55:13.868373
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import builtins

    # Ambiguous test case if we are on Windows and the user's python is not a
    # 64 bit build, the most obvious fix would be to use
    # compat.is_windows() for this test case, however that is not available
    # in ansible-test.
    # We also want to exclude py2, as the py2 implementation of
    # from_loose_version already tests for these cases

# Generated at 2022-06-25 13:55:20.294041
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    n0 = _Numeric('1')
    n1 = _Numeric('2')
    n2 = _Numeric('0')
    a0 = _Alpha('0')
    a1 = _Alpha('2')

    assert n0 < n1
    assert not n1 < n0
    assert not n0 < n0
    assert n2 < n0
    assert not n0 < n2
    assert not n0 < a0
    assert not a0 < n0
    assert not n1 < a1
    with raises(ValueError):
        n0 < 'foo'


# Generated at 2022-06-25 13:55:29.139827
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:55:34.059151
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    test_case = (_Numeric('1'), _Numeric('0'), _Numeric('2'))
    assert test_case[0].__le__(test_case[0]) == True
    assert test_case[0].__le__(test_case[1]) == False
    assert test_case[0].__le__(test_case[2]) == True


# Generated at 2022-06-25 13:55:35.567509
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    if not (True):
        raise AssertionError



# Generated at 2022-06-25 13:55:37.351736
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert(SemanticVersion().parse('1.0.0') == None)


# Generated at 2022-06-25 13:55:43.111551
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    test_cases = [
        (_Numeric(1), 0),
        (_Numeric(1), 1),
        (_Numeric(1), 2),
        (_Numeric(5), 1),
        (_Numeric(5), 5),
        (_Numeric(5), 6),
        (_Numeric(9), 1),
        (_Numeric(9), 9),
        (_Numeric(9), 10),
    ]

    for c1, c2 in test_cases:
        assert(c1 < c2)



# Generated at 2022-06-25 13:55:45.537802
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    specifier = 'a'
    object = _Alpha(specifier)
    other = 'b'
    result = object.__lt__(other)
    assert result == True


# Generated at 2022-06-25 13:55:47.683773
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0')
    result = SemanticVersion.from_loose_version(loose_version)
    assert result == "1.0.0"



# Generated at 2022-06-25 13:56:11.861070
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    ver = SemanticVersion()
    ver.parse("1.0.0")
    assert ver.major == 1
    assert ver.minor == 0
    assert ver.patch == 0
    assert ver.prerelease == ()
    assert ver.buildmetadata == ()


# Generated at 2022-06-25 13:56:18.992303
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = LooseVersion('1.0.0')
    sv = SemanticVersion.from_loose_version(v)
    assert sv.major == v.version[0]
    assert sv.minor == v.version[1]
    assert sv.patch == v.version[2]
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()
    assert sv.is_stable

    v = LooseVersion('1.0.0-alpha')
    sv = SemanticVersion.from_loose_version(v)
    assert sv.major == v.version[0]
    assert sv.minor == v.version[1]
    assert sv.patch == v.version[2]
    assert sv.prerelease == ('alpha',)
    assert sv.buildmetadata == ()
    assert not sv.is_stable

# Generated at 2022-06-25 13:56:25.184585
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that from_loose_version() from a version that contains
    # invalid characters, raises a ValueError
    #
    # Input:
    #    LooseVersion("1.0.0a")
    #
    # Expected:
    #    ValueError("1.0.0a contains invalid characters and is not a valid SemanticVersion.")
    #
    # Actual:
    #    ValueError("1.0.0a contains invalid characters and is not a valid SemanticVersion.")
    #
    loose_version_0 = LooseVersion("1.0.0a")
    try:
        SemanticVersion.from_loose_version(loose_version_0)
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-25 13:56:28.888417
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """ Test method parse of class SemanticVersion """
    version = "1.2.3-alpha.10+build.11"
    semantic_version = SemanticVersion()
    semantic_version.parse(version)


# Generated at 2022-06-25 13:56:37.289880
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests for type LooseVersion
    assert SemanticVersion.from_loose_version('1.2.2') == \
        SemanticVersion('1.2.2')
    assert SemanticVersion.from_loose_version('1.2.0') == \
        SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version('1.2.0.dev1') == \
        SemanticVersion('1.2.0-dev1')
    assert SemanticVersion.from_loose_version('1.2.0.dev1+abc') == \
        SemanticVersion('1.2.0-dev1+abc')

    # Tests for type tuple of int

# Generated at 2022-06-25 13:56:40.965518
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    semantic_version_0.parse(vstring='1.0.0')
    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 0
    assert semantic_version_0.patch == 0


# Generated at 2022-06-25 13:56:48.932876
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-25 13:56:50.964610
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("0")
    actual = SemanticVersion.from_loose_version(loose_version)
    expected = "0.0.0"
    assert actual.vstring == expected



# Generated at 2022-06-25 13:56:54.771345
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Using the following semver...
    #   1.2.3-alpha+002
    semantic_version_0 = SemanticVersion()
    semantic_version_0.parse('1.2.3-alpha+002')
    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 2
    assert semantic_version_0.patch == 3
    assert semantic_version_0.prerelease == (_Alpha('alpha'),)
    assert semantic_version_0.buildmetadata == (_Numeric('002'),)



# Generated at 2022-06-25 13:57:02.686188
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # example from the distutils source code
    loose_version = LooseVersion("1.2.0a1")
    s = SemanticVersion.from_loose_version(loose_version)
    assert s.core == (1, 2, 0)
    assert s.prerelease == ('alpha', 1)
    assert s.is_prerelease
    assert not s.is_stable

    # example with a numeric prerelease
    loose_version = LooseVersion("1.2.0beta2")
    s = SemanticVersion.from_loose_version(loose_version)
    assert s.core == (1, 2, 0)
    assert s.prerelease == ('beta', 2)
    assert s.is_prerelease
    assert not s.is_stable

    # example with no prerelease
    loose_version = Lo

# Generated at 2022-06-25 13:57:11.362401
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '1.2.3'
    loose_version = LooseVersion(vstring)
    assert isinstance(loose_version, LooseVersion)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semantic_version, SemanticVersion)
    assert(semantic_version.vstring == vstring)


# Generated at 2022-06-25 13:57:14.862682
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion

    loose_version = LooseVersion('1.9.0b2')

    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert semantic_version == '1.9.0-b2'



# Generated at 2022-06-25 13:57:24.673680
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.0')
    loose_version_1 = LooseVersion('1.0.1')
    loose_version_2 = LooseVersion('1.0.1-prerelease')
    loose_version_3 = LooseVersion('1.0.1-1')
    loose_version_4 = LooseVersion('1.0.1-1+buildmetadata')
    loose_version_5 = LooseVersion('1.0.1-prerelease+buildmetadata')
    loose_version_6 = LooseVersion('1.0.1+buildmetadata')
    loose_version_7 = LooseVersion('1.0.1-prerelease-prerelease')
    loose_version_8 = LooseVersion('1.1.0')

# Generated at 2022-06-25 13:57:33.300104
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases = (
        (LooseVersion('1.2.3'), SemanticVersion('1.2.3')),
        (LooseVersion('1.2.3-alpha'), SemanticVersion('1.2.3-alpha')),
        (LooseVersion('1.2.3-alpha.4'), SemanticVersion('1.2.3-alpha.4')),
        (LooseVersion('1.2.3-alpha.4+build.5'), SemanticVersion('1.2.3-alpha.4+build.5')),
    )
    for loose_version, expected in test_cases:
        actual = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-25 13:57:35.402989
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert (SemanticVersion.from_loose_version(LooseVersion('1.2.3')) ==
            SemanticVersion('1.2.3'))


# Generated at 2022-06-25 13:57:44.165865
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test the from_loose_version method
    """


# Generated at 2022-06-25 13:57:51.523254
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:57:59.172469
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion()

    # Call method from_loose_version of class SemanticVersion
    assert isinstance(
        SemanticVersion.from_loose_version(semantic_version_1),
        SemanticVersion
    )
    # Call method from_loose_version of class SemanticVersion with args
    # vstring = ''
    try:
        assert isinstance(
            SemanticVersion.from_loose_version(''),
            SemanticVersion
        )
    except ValueError as e:
        pass
    # Call method from_loose_version of class SemanticVersion with args
    # vstring = '2.7.13'
    assert isinstance(
        SemanticVersion.from_loose_version('2.7.13'),
        SemanticVersion
    )
    # Call method

# Generated at 2022-06-25 13:58:06.909113
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # This test ensures that SemanticVersion.from_loose_version
    # properly takes a LooseVersion and creates a SemanticVersion
    # from it

    from ansible.module_utils.common.version import LooseVersion

    # Test with a LooseVersion with prerelease and buildmetadata
    test_version = LooseVersion('1.3.0-alpha.1+build.48')
    result = SemanticVersion.from_loose_version(test_version)

    # Ensure that the result is a SemanticVersion
    assert isinstance(result, SemanticVersion)

    # Ensure that we get the expected result
    assert result == '1.3.0-alpha.1+build.48'

    # Test with a LooseVersion with prerelease and no buildmetadata

# Generated at 2022-06-25 13:58:08.659699
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.0.0')
    result = SemanticVersion.from_loose_version(loose_version)


# Generated at 2022-06-25 13:58:25.557470
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases = [
        ('1.2.3', '1.2.3+4g.5'),
        ('0.8.2a0', '0.8.2a0'),
        ('0.2.3-alpha', '0.2.3-alpha'),
        ('1.1.0', '1.1.0+RC1')
    ]

    for loose_version, vstring in test_cases:
        assert SemanticVersion.from_loose_version(LooseVersion(loose_version)).__repr__() == "SemanticVersion('%s')" % vstring


# Generated at 2022-06-25 13:58:33.190725
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.1.1b1')
    assert SemanticVersion.from_loose_version(loose_version_0) == SemanticVersion('1.1.1-b1')
    loose_version_1 = LooseVersion('1.1.1.dev0')
    assert SemanticVersion.from_loose_version(loose_version_1) == SemanticVersion('1.1.1')
    loose_version_2 = LooseVersion('1.1.1')
    assert SemanticVersion.from_loose_version(loose_version_2) == SemanticVersion('1.1.1')



# Generated at 2022-06-25 13:58:36.131152
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        assert SemanticVersion.from_loose_version(None) == 'None'
    except AssertionError:
        print ('test_SemanticVersion_from_loose_version() failed')


# Generated at 2022-06-25 13:58:44.966690
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    loose_version_0 = LooseVersion('1.16.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.vstring == '1.16.1'
    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 16
    assert semantic_version_0.patch == 1
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()
    assert semantic_version_0.is_stable
    assert not semantic_version_0.is_prerelease
    assert semantic_version_0.core == (1, 16, 1)

    loose_version_1 = LooseVersion('1.16.1rc2')
    semantic_version_1 = Semantic

# Generated at 2022-06-25 13:58:46.680854
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("3.3.0")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == "3.3.0"


# Generated at 2022-06-25 13:58:53.388234
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with an integer
    try:
        SemanticVersion.from_loose_version(1)
        return False
    except ValueError:
        pass

    # Test with a string
    try:
        SemanticVersion.from_loose_version('foo')
        return False
    except ValueError:
        pass

    # Test with a LooseVersion
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    except ValueError:
        return False

    # Test with a LooseVersion with a prerelease
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.2.3-prerelease'))
    except ValueError:
        return False

    # Test with a LooseVersion with build metadata

# Generated at 2022-06-25 13:59:00.341258
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test to make sure that if we call from_loose_version on a Non LooseVersion it throws an exception
    raised_exception = False
    try:
        SemanticVersion.from_loose_version(object())
    except ValueError:
        raised_exception = True
    assert raised_exception
    # Test that an empty string gets a default value
    assert SemanticVersion.from_loose_version(LooseVersion("")).vstring == "0.0.0"
    # Test that a single number is converted to a valid semantic version
    assert SemanticVersion.from_loose_version(LooseVersion("1")).vstring == "1"
    assert SemanticVersion.from_loose_version(LooseVersion("1.1")).vstring == "1.1"
    assert SemanticVersion.from_lo

# Generated at 2022-06-25 13:59:10.030186
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import StringIO
    from ansible.module_utils.six import print_

    # Beginning of test case from_loose_version
    print_('>>> s = SemanticVersion.from_loose_version(LooseVersion("1.2.4+abc.def"))')
    s = SemanticVersion.from_loose_version(LooseVersion("1.2.4+abc.def"))

    print_('>>> s')
    print_('SemanticVersion(%r)' % s.vstring)

    print_('>>> s.vstring')
    print_(s.vstring)

    print_('>>> type(s.vstring)')
    print_(type(s.vstring))

    print_('>>> s.major')
    print_(s.major)

    print_

# Generated at 2022-06-25 13:59:17.323070
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Assert the type of the output of SemanticVersion.from_loose_version() is SemanticVersion
    version_0_input = LooseVersion('2.2.1')
    version_0_expected_type = SemanticVersion
    assert isinstance(SemanticVersion.from_loose_version(version_0_input), version_0_expected_type)

    # Assert that if a LooseVersion object is passed to SemanticVersion.from_loose_version,
    # then the version that is returned is the version of the LooseVersion object passed
    version_1_input = LooseVersion('2.2.1')
    version_1_expected = '2.2.1'
    assert str(SemanticVersion.from_loose_version(version_1_input)) == version_1_expected

    # Assert that

# Generated at 2022-06-25 13:59:21.786730
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test 'from_loose_version' method of class SemanticVersion"""

    # Expected result
    expected_result = SemanticVersion(vstring='10.0.0')

    # Actual result
    loose_version = LooseVersion('10.0')
    actual_result = SemanticVersion.from_loose_version(loose_version)

    assert actual_result == expected_result



# Generated at 2022-06-25 13:59:44.797503
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1')).vstring == '0.0.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.0')).vstring == '2.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.1')).vstring == '2.0.1'
    assert SemanticVersion.from_loose_version(LooseVersion('2.1.0')).vstring == '2.1.0'

# Generated at 2022-06-25 13:59:53.246615
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_0_input = LooseVersion('1.2.3')
    test_0_expected = SemanticVersion('1.2.3')
    test_0_actual = SemanticVersion.from_loose_version(test_0_input)
    assert test_0_actual == test_0_expected
    assert test_0_actual.major == 1
    assert test_0_actual.minor == 2
    assert test_0_actual.patch == 3
    assert not test_0_actual.prerelease
    assert not test_0_actual.buildmetadata
    assert test_0_actual.vstring == '1.2.3'
    assert test_0_actual.core == (1, 2, 3)
    assert test_0_actual.is_stable


# Generated at 2022-06-25 14:00:00.364086
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test the valid case
    # Case 1:
    test_case_1 = SemanticVersion.from_loose_version(LooseVersion('0.1.0'))
    assert test_case_1.vstring == '0.1.0'
    assert test_case_1.major == 0
    assert test_case_1.minor == 1
    assert test_case_1.patch == 0
    assert test_case_1.prerelease == ()
    assert test_case_1.buildmetadata == ()
    assert test_case_1.core == (0, 1, 0)
    assert test_case_1.is_prerelease is False
    assert test_case_1.is_stable is False


# Generated at 2022-06-25 14:00:06.334400
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion("0.2.0"))
    assert semantic_version_1.vstring == '0.2.0'
    assert semantic_version_1.major == 0
    assert semantic_version_1.minor == 2
    assert semantic_version_1.patch == 0
    assert semantic_version_1.prerelease == ()
    assert semantic_version_1.buildmetadata == ()



# Generated at 2022-06-25 14:00:13.829708
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2-3.4+5.6')) == SemanticVersion('0.1.2-3.4+5.6')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2-3.4')) == SemanticVersion('0.1.2-3.4')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2')) == SemanticVersion('0.1.2')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2-alpha')) == SemanticVersion('0.1.2-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2-alpha1'))

# Generated at 2022-06-25 14:00:21.175533
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.vstring == '1.0.0'
    assert semantic_version_0.core == (1, 0, 0)
    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 0
    assert semantic_version_0.patch == 0
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()
    assert semantic_version_0.is_prerelease == False
    assert semantic_version_0.is_stable == True


# Generated at 2022-06-25 14:00:24.216962
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    expected = SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(loose_version) == expected


# Generated at 2022-06-25 14:00:26.786594
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion()
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version)


# Generated at 2022-06-25 14:00:30.773615
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test method from_loose_version of class SemanticVersion
    """
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Test case for argument value None

# Generated at 2022-06-25 14:00:38.793573
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:36.031598
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2')) == SemanticVersion('0.1.2')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')) == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('12.345.678')) == SemanticVersion('12.345.678')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2-3')) == SemanticVersion('0.1.2-3')

# Generated at 2022-06-25 14:01:39.556009
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    loose_version_1 = LooseVersion('2.0')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_1)

    assert semantic_version_0 < semantic_version_1



# Generated at 2022-06-25 14:01:45.760368
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        loose_version = LooseVersion('')
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to raise ValueError when passed ''")

    try:
        loose_version = LooseVersion('1 2 3')
    except ValueError:
        pass
    else:
        raise AssertionError("Failed to raise ValueError when passed '1 2 3'")

    loose_version = LooseVersion('1.2.3')
    assert(SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3'))

    loose_version = LooseVersion('1.2.3.0.0.0.0.0.0.0')

# Generated at 2022-06-25 14:01:52.683734
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert v.vstring == '1.0.0'
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert not v.is_prerelease
    assert v.is_stable

    v = SemanticVersion.from_loose_version(LooseVersion('1.0.0.0'))
    assert v.vstring == '1.0.0'
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert not v.is_prerelease
    assert v.is_stable

    v = SemanticVersion.from_loose_version(LooseVersion('1.0'))
    assert v.v

# Generated at 2022-06-25 14:01:56.747628
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_object = LooseVersion('1.0.0')
    semantic_version_object = SemanticVersion.from_loose_version(loose_version_object)
    assert semantic_version_object.major == 1
    assert semantic_version_object.minor == 0
    assert semantic_version_object.patch == 0
    assert semantic_version_object.buildmetadata == ()
    assert semantic_version_object.prerelease == ()


# Generated at 2022-06-25 14:02:03.943574
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test calling with multiple values
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.0a0')) == SemanticVersion('0.1.0-0a0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1b1')) == SemanticVersion('0.0.1-0b1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0rc1')) == SemanticVersion('1.0.0-0rc1')
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.0-rc2.141+abc')) == SemanticVersion('2.0.0-0rc2.141+abc')

# Generated at 2022-06-25 14:02:11.717782
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    sver = SemanticVersion.from_loose_version(LooseVersion('2.4.1'))
    assert sver == '2.4.1'

    sver = SemanticVersion.from_loose_version(LooseVersion('0.3'))
    assert sver == '0.3.0'

    sver = SemanticVersion.from_loose_version(LooseVersion('0.2'))
    assert sver == '0.2.0'

    sver = SemanticVersion.from_loose_version(LooseVersion('1.23.1.dev1'))
    assert sver == '1.23.1-dev1'

    sver = SemanticVersion.from_loose_version(LooseVersion('10.0.0'))

# Generated at 2022-06-25 14:02:13.983999
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version_0 = LooseVersion('1.2.3')
    version_1 = SemanticVersion.from_loose_version(version_0)


# Generated at 2022-06-25 14:02:21.156750
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common._collections_compat import OrderedDict

    if not isinstance({}, OrderedDict):
        # The LooseVersion class does a sort on the version tuple
        # This is only important if we are on python 2.6/2.7
        # and we are not using the OrderedDict backport
        # or if we are using the dict backport
        # or if we are using a python 3 version < 3.7
        import sys

        if sys.version_info[0] == 2:
            if sys.version_info[1] < 7:
                # Python <= 2.6
                loose_version = LooseVersion('4.9.9.9.9-1.2.3')
                assert SemanticVersion.from_loose_version(loose_version) == Semantic

# Generated at 2022-06-25 14:02:23.292452
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion("0.1.1"))

    assert semantic_version_0.vstring == "0.1.1"


# Generated at 2022-06-25 14:03:21.509542
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.0.0alpha')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)


# Generated at 2022-06-25 14:03:28.749943
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    print('Test SemanticVersion.from_loose_version')

# Generated at 2022-06-25 14:03:36.431741
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    expected_value_0 = semver( '1.2.3' )
    actual_value_0 = SemanticVersion.from_loose_version( LooseVersion( '1.2.3' ) )
    assert actual_value_0 == expected_value_0

    semantic_version_1 = SemanticVersion()
    expected_value_1 = semver( '1.2.3' )
    actual_value_1 = SemanticVersion.from_loose_version( LooseVersion( '1.2.3.4' ) )
    assert actual_value_1 == expected_value_1

    semantic_version_2 = SemanticVersion()
    expected_value_2 = semver( '1.2.3-rc.1' )
    actual_value_2 = Sem

# Generated at 2022-06-25 14:03:40.391411
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_str = '12.34'
    expected = '12.34.0'

    loose_version = LooseVersion(loose_version_str)
    actual = str(SemanticVersion.from_loose_version(loose_version))

    assert expected == actual

# Generated at 2022-06-25 14:03:43.311073
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    result = SemanticVersion.from_loose_version(LooseVersion("0.0.1-alpha1+20130313144700"))
    assert result == "0.0.1-alpha1+20130313144700"

# Generated at 2022-06-25 14:03:51.085458
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.0.0'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.0'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha'))) == '1.2.3-alpha'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3+build'))) == '1.2.3+build'

# Generated at 2022-06-25 14:03:58.157328
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Test the method without any parameters
    try:
        SemanticVersion.from_loose_version()
    except (TypeError, AttributeError):
        pass

    # Test the method with a non-LooseVersion as the single parameter
    try:
        SemanticVersion.from_loose_version("")
    except ValueError:
        pass

    # Test the method with a LooseVersion that has a pre-release version
    # that contains non-numeric values
    test_loose_version = LooseVersion("1.2.3-pre.rc.4")
    try:
        SemanticVersion.from_loose_version(test_loose_version)
    except ValueError:
        pass

    # Test the method with a LooseVersion that has a pre-release version
    # that contains a numeric value
    test_

# Generated at 2022-06-25 14:04:04.228956
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Invalid LooseVersion
    assert SemanticVersion.from_loose_version('ansible') is None
    # Valid LooseVersion with no extra
    assert SemanticVersion.from_loose_version('2.10.0') == SemanticVersion('2.10.0')
    # Valid LooseVersion with extra
    assert SemanticVersion.from_loose_version('2.10.0.alpha.1') == SemanticVersion('2.10.0-alpha.1')

    # We need to override from_loose_version in python2 because it
    # doesn't return a SemanticVersion, it returns a version.StrictVersion
    if SemanticVersion.from_loose_version == Version.from_loose_version:
        return

    # Valid LooseVersion with no extra
    assert SemanticVersion.from_loose_

# Generated at 2022-06-25 14:04:10.677239
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create instance of class LooseVersion
    loose_version = LooseVersion('8.7.6')

    # Store return value of method from_loose_version of class SemanticVersion
    SemanticVersion_from_loose_version_return = SemanticVersion.from_loose_version(loose_version)

    # Test contents of SemanticVersion_from_loose_version_return
    assert isinstance(SemanticVersion_from_loose_version_return, SemanticVersion), \
        "A valid SemanticVersion object should be returned from from_loose_version"
    assert SemanticVersion_from_loose_version_return == SemanticVersion('8.7.6')


# Generated at 2022-06-25 14:04:16.598837
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import datetime
    # test that an error is raised when something other than a LooseVersion
    # is passed to the class
    error = None
    try:
        SemanticVersion.from_loose_version("1.0.1")
    except Exception as e:
        error = e
    assert type(error) == ValueError
    assert str(error) == "'1.0.1' is not a LooseVersion"

    # test that an error is raised if a LooseVersion with more than 3 segments
    # is passed
    error = None
    try:
        SemanticVersion.from_loose_version(LooseVersion("1.0.1.1"))
    except Exception as e:
        error = e
    assert type(error) == ValueError