

# Generated at 2022-06-25 13:55:29.309705
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    vstring = '0.0.0'
    semantic_version_0 = SemanticVersion()
    semantic_version_0.parse(vstring)
    assert (semantic_version_0.major == 0)
    assert (semantic_version_0.minor == 0)
    assert (semantic_version_0.patch == 0)
    assert (semantic_version_0.core == (0, 0, 0))
    assert (not semantic_version_0.prerelease)
    assert (not semantic_version_0.buildmetadata)
    assert (semantic_version_0.vstring == vstring)


# Generated at 2022-06-25 13:55:39.454073
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Vars
    semantic_version_0 = None
    loose_version_0 = None
    str_0 = None
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    str_9 = None
    str_10 = None
    str_11 = None
    str_12 = None
    str_13 = None
    str_14 = None
    str_15 = None
    str_16 = None

    # ##
    # Test when '1.2.3' is passed in
    # ##
    str_0 = '1.2.3'
    # The following line is needed for downstream tests that depend on
    # this method
    loose

# Generated at 2022-06-25 13:55:47.272669
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test passing non-LooseVersion argument
    try:
        SemanticVersion.from_loose_version('1.2.3')
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError when passing string")

    # Test passing LooseVersion with non integer components
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.2.3a4'))
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError when passing LooseVersion with non integer components")

    # Test basic version parsing
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert str(version) == '1.2.3'

    # Test with prerelease
    version = Sem

# Generated at 2022-06-25 13:55:56.489918
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import random
    from ansible.module_utils.date_info import LooseVersion
    from ansible.module_utils.six import string_types

    for _ in range(random.randint(10, 100)):
        version_numbers = list()
        for _ in range(random.randint(0, 3)):
            version_numbers.append(random.randint(0, 1000))
        version_numbers = tuple(version_numbers)
        pre_release = ''.join(random.sample(string_types, random.randint(0, 10)))
        build_metadata = ''.join(random.sample(string_types, random.randint(0, 10)))

# Generated at 2022-06-25 13:56:04.240048
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert semantic_version.vstring == '1.0.0'
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()
    assert semantic_version.is_stable

    semantic_version = SemanticVersion.from_loose_version(LooseVersion('1.0.0-test'))
    assert semantic_version.vstring == '1.0.0-test'
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0

# Generated at 2022-06-25 13:56:11.360135
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        assert SemanticVersion.from_loose_version('0.0.0') == SemanticVersion('0.0.0')
    except AssertionError:
        return False

    try:
        assert SemanticVersion.from_loose_version('0.0.0.0') == SemanticVersion('0.0.0.0')
    except AssertionError:
        return False

    try:
        assert SemanticVersion.from_loose_version('0.0.1') == SemanticVersion('0.0.1')
    except AssertionError:
        return False

    try:
        assert SemanticVersion.from_loose_version('0.1.0') == SemanticVersion('0.1.0')
    except AssertionError:
        return False


# Generated at 2022-06-25 13:56:13.005073
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    semantic_version_0.parse('0.0.0-0.0.0')



# Generated at 2022-06-25 13:56:16.802935
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_1 = SemanticVersion()
    vstring = '0.0.0'
    match_1 = re.match(r'^\d[\d\.]*', vstring)
    version_1 = match_1.group(0)
    semantic_version_1.parse(version_1)
    assert semantic_version_1.vstring == vstring



# Generated at 2022-06-25 13:56:22.376122
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()

    # Test basic string
    semantic_version.parse('1.0.0')
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert not semantic_version.prerelease
    assert not semantic_version.buildmetadata

    semantic_version.parse('1.0.0-alpha')
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == (_Alpha('alpha'),)
    assert not se

# Generated at 2022-06-25 13:56:31.321909
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a LooseVersion instance with a float in the version.
    # Semantic versions cannot contain floats.
    # Therefore, this should raise a ValueError
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(LooseVersion('1.0.0b1.dev-something'))
    # Test a LooseVersion instance with a non integer value in the version.
    # Semantic versions cannot contain non integer values.
    # Therefore, this should raise a ValueError
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(LooseVersion('1.0.0b1.dev-something-m0'))
    # Test a LooseVersion instance without anything special.
    # This should return a valid SemanticVersion

# Generated at 2022-06-25 13:56:41.511404
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    vstring = text_type()
    semantic_version_0.parse(vstring)


# Generated at 2022-06-25 13:56:46.523928
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # the following test does not test the whole method
    # but only the point where this dynamic call is done
    # in order to add the "test_" prefix to the method name
    # and not create a real method
    # (see https://github.com/ansible/ansibullbot/issues/1907)
    loose_version = LooseVersion('1.5.5.5')
    assert str(SemanticVersion.from_loose_version(loose_version)) == '1.5.5'



# Generated at 2022-06-25 13:56:54.958337
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    # Test with a loose_version with some extras
    loose_version_0 = LooseVersion('1.2.3-alpha')
    # Test with a loose_version without some extras
    loose_version_1 = LooseVersion('1.2.3')
    try:
        # Test with a non-LooseVersion
        semantic_version = SemanticVersion.from_loose_version(SemanticVersion())
    except ValueError as err:
        print(repr(err))
    except Exception as err:
        print(repr(err))
    # Test with an empty LooseVersion
    try:
        semantic_version = SemanticVersion.from_loose_version(LooseVersion())
    except ValueError as err:
        print(repr(err))


# Generated at 2022-06-25 13:57:02.957863
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv1 = LooseVersion("0.0.1")
    lv2 = LooseVersion("0.0.1.dev1")
    lv3 = LooseVersion("1.2.1")
    lv4 = LooseVersion("1.2.1.dev1")
    lv5 = LooseVersion("1.2.1.dev1+sha")
    lv6 = LooseVersion("1.2.1+sha")

    sv1 = SemanticVersion.from_loose_version(lv1)
    sv2 = SemanticVersion.from_loose_version(lv2)
    sv3 = SemanticVersion.from_loose_version(lv3)
    sv4 = SemanticVersion.from_loose_version(lv4)
    sv5 = SemanticVersion.from_loose_version

# Generated at 2022-06-25 13:57:11.239390
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import builtins
    if hasattr(builtins, '_get_builtin'):
        builtins._get_builtin = lambda name: None  # @UndefinedVariable
    else:
        builtins.__dict__['_get_builtin'] = lambda name: None  # @UndefinedVariable

# Generated at 2022-06-25 13:57:20.718207
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Basic usage
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    # in case of a LooseVersion instance where the version string is not a
    # compliant semver string
    # e.g. '1.2.3.dev', '1.2.3.post'
    # We expect the extra information to be stripped
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.post')) == SemanticVersion('1.2.3')

    # in case of a LooseVersion instance where the version string has a
    # prerelease

# Generated at 2022-06-25 13:57:29.776663
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Test SemanticVersion.from_loose_version method with LooseVersion
    # as input
    loose_version = LooseVersion(
        '1.2.0-alpha.1+00001.a.b')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.0-alpha.1+00001.a.b'

    # Test SemanticVersion.from_loose_version method with tuple
    # as input
    loose_version = LooseVersion((1, 2, 0))
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.0'

    # Test SemanticVersion.from_loose_version method with version string
    # as input
   

# Generated at 2022-06-25 13:57:31.587797
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    semantic_version_0.parse('0.1.2-3.4')


# Generated at 2022-06-25 13:57:34.970147
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Testing for proper handling of non-LooseVersion input
    try:
        SemanticVersion.from_loose_version('1.2.3')
    except ValueError:
        pass
    else:
        assert False, "Non LooseVersion input should have raised ValueError"



# Generated at 2022-06-25 13:57:43.734463
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # make sure the example version from semver.org works
    vstring = '1.0.0-alpha+001'
    semantic_version = SemanticVersion(vstring)
    assert semantic_version.vstring == vstring
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == (_Alpha('alpha'),)
    assert semantic_version.buildmetadata == (_Numeric('001'),)

    # make sure that it fails when it should
    try:
        semantic_version = SemanticVersion('not a valid version')
    except ValueError:
        pass
    else:
        assert False

    # make sure that version with a prerelease and no buildmetadata work
    vstring = '1.0.0-alpha'
    semantic_

# Generated at 2022-06-25 13:57:58.719701
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0_0 = SemanticVersion('3.12.1')
    assert isinstance(semantic_version_0_0, SemanticVersion)

    assert semantic_version_0_0.vstring == '3.12.1'
    assert semantic_version_0_0.major == 3
    assert semantic_version_0_0.minor == 12
    assert semantic_version_0_0.patch == 1
    assert semantic_version_0_0.prerelease == ()
    assert semantic_version_0_0.buildmetadata == ()
    assert semantic_version_0_0.core == (3, 12, 1)
    assert semantic_version_0_0.is_prerelease is False
    assert semantic_version_0_0.is_stable is True


# Generated at 2022-06-25 13:58:06.498618
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Argument must be a LooseVersion object
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion(""))
    assert(isinstance(semantic_version_1, SemanticVersion))

    # Case where vstring can be parsed
    semantic_version_2 = SemanticVersion.from_loose_version(LooseVersion("1.2.3"))
    assert(semantic_version_2.major == 1)
    assert(semantic_version_2.minor == 2)
    assert(semantic_version_2.patch == 3)

    # Case where vstring has a prerelease
    semantic_version_3 = SemanticVersion.from_loose_version(LooseVersion("1.2.3-beta.1"))

# Generated at 2022-06-25 13:58:14.284136
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # In this test case we are testing that the method from_loose_version
    # correctly parses out the version from the LooseVersion string
    # and constructs a SemanticVersion with the correct vstring
    # LooseVersion: 1.2.3-r3-alpha5+debian-5-5+build.5
    # SemanticVersion: 1.2.3-r3-alpha5+debian-5-5
    loose_version = LooseVersion('1.2.3-r3-alpha5+debian-5-5+build.5')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    vstring = semantic_version.vstring
    assert vstring == '1.2.3-r3-alpha5+debian-5-5'


# Generated at 2022-06-25 13:58:21.177069
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Major version zero (0.y.z) is for initial development. Anything MAY change at any time.
    # The public API SHOULD NOT be considered stable.
    # https://semver.org/#spec-item-4
    assert SemanticVersion.from_loose_version(LooseVersion('0')).vstring == '0.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('0.1')).vstring == '0.1.0'
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2')).vstring == '0.1.2'
    assert SemanticVersion.from_loose_version(
        LooseVersion('0.1.2.post3.dev5')).vstring == '0.1.2-3.dev5'


# Generated at 2022-06-25 13:58:27.289344
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check semantic version from LooseVersion without marker
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert (str(sv) == '1.2.3')
    # Check semantic version from LooseVersion with pre-release marker and pre-release version
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3-rc.1'))
    assert (str(sv) == '1.2.3-rc.1')
    # Check semantic version from LooseVersion with build-metadata marker and build-metadata version
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3+rc.1'))
    assert (str(sv) == '1.2.3+rc.1')
    # Check semantic version

# Generated at 2022-06-25 13:58:36.328303
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = '2.7.13'
    loose_version_obj = LooseVersion(loose_version)
    semantic_version_obj = SemanticVersion.from_loose_version(loose_version_obj)
    if not isinstance(semantic_version_obj, SemanticVersion):
        raise AssertionError("The returned object should be an instance of SemanticVersion")

    loose_version = '2.7.13-dev0'
    loose_version_obj = LooseVersion(loose_version)
    semantic_version_obj = SemanticVersion.from_loose_version(loose_version_obj)
    if not isinstance(semantic_version_obj, SemanticVersion):
        raise AssertionError("The returned object should be an instance of SemanticVersion")


# Generated at 2022-06-25 13:58:45.150189
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    import ansible.module_utils.six as six
    import ansible.module_utils.distro as distro

    # Create an instance of a class LooseVersion
    loose_version = distro.LooseVersion('1.28.0')

    # Call method from_loose_version of class SemanticVersion
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # Verify the type of the object returned is SemanticVersion
    assert isinstance(semantic_version, SemanticVersion), 'Expected type of object returned to be SemanticVersion'

    # Verify the value of the object returned is of type string
    assert isinstance(semantic_version, six.string_types), 'Expected value of object returned to be of type string'

    # Verify the string returned has the same value as the original
    #

# Generated at 2022-06-25 13:58:47.547000
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create an example LooseVersion
    loose_version = LooseVersion('1.2.3-rc1')
    # Create an example SemanticVersion
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    # Check that it succeeded
    assert len(semantic_version.prerelease) == 1


# Generated at 2022-06-25 13:58:54.743340
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion('0.1.2')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 0
    assert sv.minor == 1
    assert sv.patch == 2
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()

    lv = LooseVersion('0.1.2alpha1')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 0
    assert sv.minor == 1
    assert sv.patch == 2
    assert sv.prerelease == ('alpha', '1')
    assert sv.buildmetadata == ()

    lv = LooseVersion('0.1.2alpha1.1')
    sv = SemanticVersion.from_loose_version(lv)

# Generated at 2022-06-25 13:59:01.074296
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    from ansible.module_utils.six import string_types


# Generated at 2022-06-25 13:59:21.529043
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion
    assert SemanticVersion.from_loose_version('0.5.5').vstring == '0.5.5'


# Generated at 2022-06-25 13:59:25.709760
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3a'))
    assert version.vstring == '1.2.3-a'
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()


# Generated at 2022-06-25 13:59:34.171075
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')) == SemanticVersion()
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1')) == SemanticVersion('0.0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.0')) == SemanticVersion('0.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0')) == SemanticVersion()
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
   

# Generated at 2022-06-25 13:59:42.487315
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Instantiate mock object of class LooseVersion
    loose_version_mock = mock.Mock(spec=LooseVersion)
    # Instantiate mock object of class SemanticVersion
    version_mock = mock.Mock(spec=SemanticVersion)

    # Set mock attributes and return values
    type(loose_version_mock).vstring = '0.0.0'
    loose_version_mock.version.__getitem__.return_value = type(version_mock)('0.0.0')
    type(loose_version_mock).version = ['0', '0', '0']

    # Test execution
    # AssertionError raised

    # Test execution
    # AssertionError raised

    # Test execution

# Generated at 2022-06-25 13:59:45.048669
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.1.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)



# Generated at 2022-06-25 13:59:48.719695
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion"""
    try:
        SemanticVersion.from_loose_version(LooseVersion('3.3.3'))
    except ValueError:
        assert False
    except Exception:
        assert True
    else:
        assert True


# Generated at 2022-06-25 13:59:56.131484
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('0')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_0)
    setattr(semantic_version_1, 'vstring', '0.0.0')
    loose_version_1 = LooseVersion('1.2.3.4')
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version_1)
    setattr(semantic_version_2, 'vstring', '1.2.3')
    loose_version_2 = LooseVersion('1.2.3.4-alpha')
    semantic_version_3 = SemanticVersion.from_loose_version(loose_version_2)

# Generated at 2022-06-25 14:00:04.328890
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version=LooseVersion('1'))
    assert semantic_version_0.core == (1, 0, 0)
    assert semantic_version_0.prerelease == ()

    semantic_version_1 = SemanticVersion.from_loose_version(loose_version=LooseVersion('1.2.3'))
    assert semantic_version_1.core == (1, 2, 3)
    assert semantic_version_1.prerelease == ()

    semantic_version_2 = SemanticVersion.from_loose_version(loose_version=LooseVersion('1.2.3.4'))
    assert semantic_version_2.core == (1, 2, 3)

# Generated at 2022-06-25 14:00:12.618728
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    LooseVersion.version_re = re.compile(
        r'''
        ^
        (\d+)         # major
        \.
        (\d+)         # minor
        (?:\.
            (\d+)     # patch
            (?:\.
                (.*)  # prerelease
            )?
        )?
        $
        ''',
        flags=re.X
    )
    loose_versions = [
        '6.8.6',
        '6.8.6.1',
        '6.8.6.pl1',
        '6.8.6.a1',
        '6.8.6.b2',
    ]

# Generated at 2022-06-25 14:00:16.357494
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Pass a loose version object
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')

    # Pass a string
    assert SemanticVersion.from_loose_version('1') == SemanticVersion('1.0.0')

    # Verify a string with a prerelease
    assert SemanticVersion.from_loose_version('1.0.0b4') == SemanticVersion('1.0.0-b4')


# Generated at 2022-06-25 14:00:33.080247
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    #  Taken from https://semver.org/#spec-item-9
    # 1.0.0-alpha < 1.0.0-alpha.1 < 1.0.0-alpha.beta < 1.0.0-beta < 1.0.0-beta.2 < 1.0.0-beta.11 < 1.0.0-rc.1 < 1.0.0

    vlist = [
        '1.0.0-alpha', '1.0.0-alpha.1', '1.0.0-alpha.beta', '1.0.0-beta', '1.0.0-beta.2',
        '1.0.0-beta.11', '1.0.0-rc.1', '1.0.0'
    ]


# Generated at 2022-06-25 14:00:36.185223
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.8.1-1')
    v = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(v, SemanticVersion)
    assert v == '1.8.1-1'



# Generated at 2022-06-25 14:00:39.776771
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1+build.1'))) == '1.0.0-alpha.1+build.1'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta.2+build.3'))) == '1.0.0-beta.2+build.3'



# Generated at 2022-06-25 14:00:44.842373
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # An example of a LooseVersion that can be converted to a SemanticVersion
    loose_version_0 = LooseVersion('123')

    # An example of a LooseVersion that cannot be converted to a SemanticVersion
    loose_version_1 = LooseVersion('v123')

    # An example of a LooseVersion that can be converted to a SemanticVersion
    loose_version_2 = LooseVersion('v.0.0.1')

    # Create a SemanticVersion from a LooseVersion
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    # Create a SemanticVersion from a LooseVersion
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(loose_version_1)

    # Create a SemanticVersion from a

# Generated at 2022-06-25 14:00:52.166166
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()
    assert semantic_version.is_stable
    assert not semantic_version.is_prerelease

    loose_version = LooseVersion("1.2")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()
   

# Generated at 2022-06-25 14:00:53.677247
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')

# Generated at 2022-06-25 14:00:56.566108
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('0.1.2')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    assert '0.1.2' == semantic_version_0.vstring


# Generated at 2022-06-25 14:01:04.494584
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
  # Test from_loose_version with args
  # Execute from_loose_version with args
  # Assert from_loose_version(loose_version) == SemanticVersion
  assert True

  # Test from_loose_version with args
  # Execute from_loose_version with args
  # Assert from_loose_version(loose_version) == SemanticVersion
  assert True

  # Test from_loose_version with args
  # Execute from_loose_version with args
  # Assert from_loose_version(loose_version) == SemanticVersion
  assert True

  # Test from_loose_version with args
  # Execute from_loose_version with args
  # Assert from_loose_version(loose_version) == SemanticVersion
  assert True

# Generated at 2022-06-25 14:01:10.309870
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("20.4.4")) == SemanticVersion("20.4.4")
    assert SemanticVersion.from_loose_version(LooseVersion("20.4.4-1")) == SemanticVersion("20.4.4-1")
    assert SemanticVersion.from_loose_version(LooseVersion("20.4.4+1")) == SemanticVersion("20.4.4+1")


# Generated at 2022-06-25 14:01:17.990968
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    for loose_version_str in [
        '1.4.0',
        '1.4.2',
        '10.4.0',
        '1.4.0-alpha',
        '1.4.0-alpha.2',
        '1.4.0-alpha.beta',
        '1.4.0-beta+exp.sha.5114f85',
    ]:
        loose_version = LooseVersion(loose_version_str)
        semantic_version = SemanticVersion.from_loose_version(loose_version)
        assert_equal(repr(semantic_version), repr(loose_version_str))
        assert_true(semantic_version.is_stable)


# Generated at 2022-06-25 14:01:36.289528
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test case 0
    assert_equal(SemanticVersion.from_loose_version(LooseVersion('1.1.1')).major, 1)
    assert_equal(SemanticVersion.from_loose_version(LooseVersion('1.1.1')).minor, 1)
    assert_equal(SemanticVersion.from_loose_version(LooseVersion('1.1.1')).patch, 1)
    assert_equal(SemanticVersion.from_loose_version(LooseVersion('1.1.1')).prerelease, ())
    assert_equal(SemanticVersion.from_loose_version(LooseVersion('1.1.1')).buildmetadata, ())
    # Test case 1

# Generated at 2022-06-25 14:01:41.887345
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Assert that the LooseVersion is converted to a SemanticVersion
    assert SemanticVersion.from_loose_version(
        LooseVersion("1.2.3")
    ) == SemanticVersion("1.2.3")

    # Assert that the LooseVersion is converted to a SemanticVersion,
    # and that the string values are cast as integers
    assert SemanticVersion.from_loose_version(
        LooseVersion("1.2.3-a")
    ) == SemanticVersion("1.2.3-0")

    # Assert that the LooseVersion is converted to a SemanticVersion,
    # and that the string values are cast as integers

# Generated at 2022-06-25 14:01:48.656311
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    SemanticVersion.from_loose_version(LooseVersion('1.0.0-1'))
    SemanticVersion.from_loose_version(LooseVersion('1.0.0+2'))
    SemanticVersion.from_loose_version(LooseVersion('1.0.0-1+2'))
    SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta'))
    SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta.3'))
    SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta.3+2'))
    SemanticVersion.from_loose_version

# Generated at 2022-06-25 14:01:50.780682
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert(semver.vstring == '1.2.3')



# Generated at 2022-06-25 14:01:55.164664
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Creating a LooseVersion with a semantic version
    loose_version_0 = LooseVersion('0.3.0')
    # Getting a SemanticVersion from the LooseVersion
    result = SemanticVersion.from_loose_version(loose_version_0)
    # Creating a SemanticVersion with a semantic version
    semantic_version_0 = SemanticVersion('0.3.0')
    assert semantic_version_0.__eq__(result)


# Generated at 2022-06-25 14:01:58.005099
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3-alpha.1+build.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.2.3-alpha.1+build.1'


# Generated at 2022-06-25 14:02:05.354619
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.11.0-alpha.1')
    result = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(result, SemanticVersion)

    loose_version = LooseVersion('0.11.0-alpha.1+abcdef')
    result = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(result, SemanticVersion)

    loose_version = LooseVersion('1.0.0')
    result = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(result, SemanticVersion)

    loose_version = LooseVersion('1.0.0+xyz')
    result = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-25 14:02:12.784796
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible_collections.github.dcos_ansible.plugins.module_utils.semantic_version
    import ansible_collections.github.dcos_ansible.plugins.module_utils.version
    loose_version = ansible_collections.github.dcos_ansible.plugins.module_utils.version.LooseVersion('1.0.0-alpha+20180322224933')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == (_Alpha('alpha'),)
    assert semantic_version.buildmetadata == (_Numeric('20180322224933'),)

# Generated at 2022-06-25 14:02:19.733310
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    string = "5.5.5"
    loose_version = LooseVersion(string)
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert(semantic_version.vstring == string)
    assert(semantic_version.major == 5)
    assert(semantic_version.minor == 5)
    assert(semantic_version.patch == 5)
    assert(semantic_version.prerelease == ())
    assert(semantic_version.buildmetadata == ())
    assert(semantic_version.core == (5, 5, 5))
    assert(semantic_version.is_prerelease is False)
    assert(semantic_version.is_stable is True)


# Generated at 2022-06-25 14:02:25.702049
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Construct a LooseVersion for v0.5.5
    with open('tests/output/loose_version_1.txt', 'r') as file:
        loose_version_0 = file.read()

    # Construct a SemanticVersion from the LooseVersion
    semantic_version_0 = SemanticVersion.from_loose_version(
        loose_version_0
    )

    # Verify that the constructed SemanticVersion is correct
    assert semantic_version_0.major == 0
    assert semantic_version_0.minor == 5
    assert semantic_version_0.patch == 5
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()



# Generated at 2022-06-25 14:03:11.971966
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # For test_case 1, 2 and 3 check that we get the correct exceptions
    # with an object that is not a LooseVersion
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version({})

    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(())

    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('')

    # For test_case 4, 5 and 6 check that we get the correct
    # semantic version from a valid loose version
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')


# Generated at 2022-06-25 14:03:15.812947
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.2')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == loose_version.version[0]
    assert semantic_version.minor == loose_version.version[1]
    assert semantic_version.patch == loose_version.version[2]



# Generated at 2022-06-25 14:03:23.285833
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:03:30.596847
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.0')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == Semantic

# Generated at 2022-06-25 14:03:38.423057
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Pass
    test_0 = LooseVersion('1.2.3')
    test_1 = SemanticVersion.from_loose_version(test_0)

    # Fail
    test_2 = None
    with should_raise(ValueError) as ex:
        test_3 = SemanticVersion.from_loose_version(test_2)
    ex.exception.args[0].should.equal.__("None is not a LooseVersion")

    # Fail
    test_4 = '1.2.3'
    with should_raise(ValueError) as ex:
        test_5 = SemanticVersion.from_loose_version(test_4)
    ex.exception.args[0].should.equal.__("'1.2.3' is not a LooseVersion")


# Generated at 2022-06-25 14:03:47.137399
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.a')) == SemanticVersion('1.0.0-a')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.a.0')) == SemanticVersion('1.0.0-a.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.a-1')) == SemanticVersion('1.0.0-a-1')

# Generated at 2022-06-25 14:03:54.656323
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:03:56.416499
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_str = '0.0.0'
    semantic_version_0 = SemanticVersion.from_loose_version(test_str)
    assert semantic_version_0.vstring == test_str



# Generated at 2022-06-25 14:04:02.759144
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '1.4.4'
    loose_version = loose_version_from_string(vstring)
    assert SemanticVersion.from_loose_version(loose_version).vstring == vstring

    vstring = '1'
    loose_version = loose_version_from_string(vstring)
    assert SemanticVersion.from_loose_version(loose_version).vstring == vstring

    vstring = '1.4'
    loose_version = loose_version_from_string(vstring)
    assert SemanticVersion.from_loose_version(loose_version).vstring == vstring

    vstring = '1.4.4a'
    loose_version = loose_version_from_string(vstring)

# Generated at 2022-06-25 14:04:04.350132
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_from_loose_version_0 = SemanticVersion.from_loose_version(0)


# Generated at 2022-06-25 14:04:48.944750
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible.module_utils.compat.version
    loose_version_0 = ansible.module_utils.compat.version.LooseVersion("1.0")
    try:
        SemanticVersion.from_loose_version(loose_version_0)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected a ValueError")



# Generated at 2022-06-25 14:04:54.642153
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    v = SemanticVersion.from_loose_version(loose_version)
    assert v.vstring == '1.0.0'
    # Test with extra data in the LooseVersion
    loose_version = LooseVersion('1.0.0-alpha.1+20130313144700')
    v = SemanticVersion.from_loose_version(loose_version)
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ('alpha', '1')
    assert v.buildmetadata == tuple()
    # Test with a LooseVersion that contains non integer values
    loose_version = LooseVersion('2.0.1b')

# Generated at 2022-06-25 14:05:01.926448
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    case_0_loose_version = LooseVersion('1')
    case_0_expected = SemanticVersion('1.0.0')
    case_0_actual = SemanticVersion.from_loose_version(case_0_loose_version)
    assert case_0_expected == case_0_actual
    case_1_loose_version = LooseVersion('1.2')
    case_1_expected = SemanticVersion('1.2.0')
    case_1_actual = SemanticVersion.from_loose_version(case_1_loose_version)
    assert case_1_expected == case_1_actual
    case_2_loose_version = LooseVersion('1.2.3')
    case_2_expected = SemanticVersion('1.2.3')
    case_2