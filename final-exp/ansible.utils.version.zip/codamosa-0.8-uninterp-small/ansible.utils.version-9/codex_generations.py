

# Generated at 2022-06-25 13:55:37.708310
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    def test_case_0():
        semantic_version = SemanticVersion()
        semantic_version.parse('0.0.0')

    def test_case_1():
        semantic_version = SemanticVersion()
        semantic_version.parse('0.0.1')

    def test_case_2():
        semantic_version = SemanticVersion()
        semantic_version.parse('0.0.2')

    def test_case_3():
        semantic_version = SemanticVersion()
        semantic_version.parse('1.0.0')

    def test_case_4():
        semantic_version = SemanticVersion()
        semantic_version.parse('1.0.1')

    def test_case_5():
        semantic_version = SemanticVersion()
        semantic_version.parse('1.0.2')

   

# Generated at 2022-06-25 13:55:41.173647
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0


# Generated at 2022-06-25 13:55:42.709777
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version()



# Generated at 2022-06-25 13:55:49.301935
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check that a LooseVersion can successfully be converted to a SemanticVersion
    loose_version_0 = LooseVersion('1.0.0')
    SemanticVersion.from_loose_version(loose_version_0)

    # Check that the arguments to the method must be a LooseVersion
    with raises(ValueError):
        SemanticVersion.from_loose_version(SemanticVersion('1.0.0'))

    # Check that the arguments to the method must be a LooseVersion with only integers
    loose_version_0 = LooseVersion('1.0')
    with raises(ValueError):
        SemanticVersion.from_loose_version(loose_version_0)

    # Check that the arguments to the method must be a LooseVersion with only integers

# Generated at 2022-06-25 13:55:51.125610
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0+abc')
    SemanticVersion.from_loose_version(loose_version)


# Generated at 2022-06-25 13:56:00.415414
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # For this test we will always construct a valid SemanticVersion
    # it is up to other tests to test the various build options

    # Test a simple version with no extra info
    assert SemanticVersion.from_loose_version(LooseVersion('14.10.0')).vstring == '14.10.0'

    # Test a version with prerelease info
    assert SemanticVersion.from_loose_version(LooseVersion('14.10.0-beta1')).vstring == '14.10.0-beta1'

    # Test a version with build metadata
    assert SemanticVersion.from_loose_version(LooseVersion('14.10.0+20130313144700')).vstring == '14.10.0+20130313144700'

    # Test a version with mixed prerelease and build metadata
   

# Generated at 2022-06-25 13:56:01.257882
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(None) == None


# Generated at 2022-06-25 13:56:04.591437
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    Version.__init__ = None
    SemanticVersion.__init__ = None
    semantic_version_0 = SemanticVersion()
    semantic_version_0.major = 0
    semantic_version_0.minor = 1
    semantic_version_0.patch = 0
    semantic_version_0.parse('0.1.0')
    assert semantic_version_0.core == (0,1,0)



# Generated at 2022-06-25 13:56:05.402535
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert False # TODO: implement your test here


# Generated at 2022-06-25 13:56:12.780639
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0')) == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    # Prereleases
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')

# Generated at 2022-06-25 13:56:25.815976
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Uncomment to get verbose information
    # import logging
    # logging.basicConfig(level=logging.DEBUG)

    # Create a loose_version from a string
    try:
        loose_version = LooseVersion('1.2.3')
    except ValueError as e:
        logger.error('Exception raised: {}'.format(e))

    # Create a SemanticVersion from a LooseVersion
    try:
        semantic_version = SemanticVersion.from_loose_version(loose_version)
    except ValueError as e:
        logger.error('Exception raised: {}'.format(e))
    assert semantic_version == SemanticVersion('1.2.3')

    # Create a LooseVersion from a string with a prerelease

# Generated at 2022-06-25 13:56:34.986678
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_in_ = '1.2.3.dev1'
    expected_ = '1.2.3-dev1'
    semantic_version = SemanticVersion.from_loose_version(loose_version_in_)
    assert expected_ == semantic_version.vstring

    loose_version_in_ = '1.2.3'
    expected_ = '1.2.3'
    semantic_version = SemanticVersion.from_loose_version(loose_version_in_)
    assert expected_ == semantic_version.vstring

    loose_version_in_ = '1.2.3.post1'
    expected_ = '1.2.3+post1'
    semantic_version = SemanticVersion.from_loose_version(loose_version_in_)
    assert expected_

# Generated at 2022-06-25 13:56:43.535811
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()
    try:
        semantic_version.parse('1.2.3')
    except ValueError:
        assert False
    try:
        semantic_version.parse('1.2.3-alpha')
    except ValueError:
        assert False
    try:
        semantic_version.parse('1.2.3+build')
    except ValueError:
        assert False
    try:
        semantic_version.parse('1.2.3-alpha+build')
    except ValueError:
        assert False
    try:
        semantic_version.parse('1.2.3-1.alpha')
    except ValueError:
        assert False
    try:
        semantic_version.parse('1.2.3-alpha.1')
    except ValueError:
        assert False

# Generated at 2022-06-25 13:56:52.258880
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion"""

# Generated at 2022-06-25 13:56:58.294941
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()
    assert semantic_version.parse("1.1.1") == None
    assert semantic_version.parse("1.1.1-rc.1+metadata") == None
    assert semantic_version.parse("1.1.1+metadata") == None
    assert semantic_version.parse("1.1.1-rc.1") == None
    assert semantic_version.parse("1.1.1-rc.1-metadata1.metadata2") == None
    assert semantic_version.parse("1.1.1-rc.1.2") == None
    assert semantic_version.parse("0.1.1-rc.1") == None


# Generated at 2022-06-25 13:57:06.615062
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('2.0.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.major == 2
    assert semantic_version_0.minor == 0
    assert semantic_version_0.patch == 1
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()
    with raises(ValueError):
        SemanticVersion.from_loose_version('2.0.1')
    struct_time_0 = time.gmtime()
    loose_version_1 = LooseVersion('2.0.1', struct_time_0)
    with raises(ValueError):
        SemanticVersion.from_loose_version(loose_version_1)


# Generated at 2022-06-25 13:57:13.588268
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Invalid tests
    invalid_tests = (
        'a.b.c',
        '1.2.3test',
    )
    for vstring in invalid_tests:
        try:
            SemanticVersion.from_loose_version(LooseVersion(vstring))
            assert False
        except ValueError:
            pass

    # Version tests

# Generated at 2022-06-25 13:57:16.616820
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_1 = LooseVersion(text_type('1.0.0'))
    semantic_version_2 = SemanticVersion.from_loose_version(loose_version=loose_version_1)


# Generated at 2022-06-25 13:57:26.524854
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys

    # Create a loose version
    loose_version = LooseVersion('0.10.12.alpha1-2')

    # Create an instance of SemanticVersion class and pass the
    # previously created loose version to it
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # If a string is passed to the method
    # ValueError is raised
    if sys.version_info[0] < 3:
        with pytest.raises(ValueError) as excinfo:
            semantic_version = SemanticVersion.from_loose_version('0.10.12.alpha1-2')

# Generated at 2022-06-25 13:57:31.072228
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # arrange
    semantic_version_obj = SemanticVersion()
    string_version = "1.2.3"

    # act
    semantic_version_obj.parse(string_version)

    # assert
    assert semantic_version_obj.core == (1, 2, 3)
    assert semantic_version_obj.prerelease == ()
    assert semantic_version_obj.buildmetadata == ()


# Generated at 2022-06-25 13:57:45.210194
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('1.1.1'))

    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 1
    assert semantic_version_0.patch == 1
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()


# Generated at 2022-06-25 13:57:48.207279
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0_expected = SemanticVersion(vstring='1.3.3.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version=LooseVersion(vstring='1.3.3.0'))
    assert semantic_version_0 == semantic_version_0_expected



# Generated at 2022-06-25 13:57:52.629512
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    semantic_version_0.parse('1.0.0-rc.1')

    loose_version_0 = LooseVersion('1.0.0-rc.1')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_0)

    assert semantic_version_1 == semantic_version_0


# Generated at 2022-06-25 13:58:00.239455
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion('')
    loose_version_0 = LooseVersion()
    try:
        SemanticVersion.from_loose_version(loose_version_0)
    except ValueError:
        pass
    else:
        assert False

    loose_version_0 = LooseVersion('')
    try:
        SemanticVersion.from_loose_version(loose_version_0)
    except ValueError:
        pass
    else:
        assert False

    semantic_version_0 = SemanticVersion('')
    loose_version_0 = LooseVersion('')
    try:
        SemanticVersion.from_loose_version(loose_version_0)
    except ValueError:
        pass
    else:
        assert False

    semantic_version_0 = Sem

# Generated at 2022-06-25 13:58:07.773406
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_1 = SemanticVersion.from_loose_version(
        LooseVersion(
            '0.1.2'
        )
    )

    semantic_version_2 = SemanticVersion.from_loose_version(
        LooseVersion(
            '0.1.2.3'
        )
    )

    semantic_version_3 = SemanticVersion.from_loose_version(
        LooseVersion(
            '22.2.2.2'
        )
    )

    semantic_version_4 = SemanticVersion.from_loose_version(
        LooseVersion(
            '0.1.2+build.2'
        )
    )


# Generated at 2022-06-25 13:58:16.070491
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:58:22.389939
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.2.0-alpha.10')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == "2.2.0-alpha.10"

    loose_version = LooseVersion('2.2.0-10.alpha')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == "2.2.0-10.alpha"

    loose_version = LooseVersion('2.2.0.alpha')
    try:
        semantic_version = SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        # ValueError is expected for this case
        pass
    else:
        raise AssertionError

# Generated at 2022-06-25 13:58:26.032198
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('0.3.5')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_0)
    str_0 = str(semantic_version_1)
    assert(str_0 == '0.3.5')


# Generated at 2022-06-25 13:58:35.023834
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test pythons 2 and 3
    for version in ('0.9', '1.0.0', '1.1.1', '1.2.3a4.post5'):
        v = LooseVersion(version)
        sv = SemanticVersion.from_loose_version(v)
        assert sv.major == v.version[0]
        assert sv.minor == v.version[1]
        assert sv.patch == v.version[2]
    # test with prerelease
    version = '1.0.0-alpha.1+build.100'
    v = LooseVersion(version)
    sv = SemanticVersion.from_loose_version(v)
    assert sv.major == v.version[0]
    assert sv.minor == v.version[1]
    assert sv.patch

# Generated at 2022-06-25 13:58:43.940139
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = LooseVersion('1.0.0')
    v2 = SemanticVersion.from_loose_version(v1)
    assert SemanticVersion(v2) == SemanticVersion('1.0.0')

    v1 = LooseVersion('1.0.0-x')
    v2 = SemanticVersion.from_loose_version(v1)
    assert SemanticVersion(v2) == SemanticVersion('1.0.0-x')

    v1 = LooseVersion('1.0.0-x.1')
    v2 = SemanticVersion.from_loose_version(v1)
    assert SemanticVersion(v2) == SemanticVersion('1.0.0-x.1')

    v1 = LooseVersion('1.0.0-x.1.a')
   

# Generated at 2022-06-25 13:58:57.056202
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = LooseVersion("0.0.0")

    # Test string type
    actual = SemanticVersion.from_loose_version(vstring)
    expected = SemanticVersion("0.0.0")
    assert actual == expected



# Generated at 2022-06-25 13:59:01.683474
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Initialize a LooseVersion instance
    loose_version = LooseVersion('1.2.3')
    # Initialize a SemanticVersion instance with the given LooseVersion object
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    # Verify that the constructed version string is valid
    assert semantic_version.version_re.match(semantic_version.vstring) is not None


# Generated at 2022-06-25 13:59:09.987383
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test passing a LooseVersion
    loose = LooseVersion('1.0alpha1')
    assert SemanticVersion.from_loose_version(loose).vstring == '1.0.0-alpha.1'

    # Test passing a string
    loose = '1.0alpha1'
    assert SemanticVersion.from_loose_version(loose).vstring == '1.0.0-alpha.1'

    # Test failing on non-LooseVersion
    loose = '1.0alpha1'
    assert not SemanticVersion.from_loose_version(loose).vstring == '1.0.0-alpha.1'



# Generated at 2022-06-25 13:59:11.804775
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')


# Generated at 2022-06-25 13:59:20.117710
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.version import SemanticVersion, LooseVersion

    mod = AnsibleModule(argument_spec={
        'old_version': {'type': 'str', 'required': True},
        'new_version': {'type': 'str', 'required': True},
    })

    old_version = mod.params['old_version']
    new_version = mod.params['new_version']

    loose_old_version = LooseVersion(old_version)
    loose_new_version = LooseVersion(new_version)
    semver_old_version = SemanticVersion.from_loose_version(loose_old_version)

# Generated at 2022-06-25 13:59:28.805381
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test describing how to test ``SemanticVersion.from_loose_version``"""
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')).vstring == '0.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0-rc0')).vstring == '0.0.0-rc0'
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0-rc0-dev')).vstring == '0.0.0-rc0-dev'
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0-rc0+dev')).vstring == '0.0.0-rc0+dev'
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-25 13:59:36.147599
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        SemanticVersion.from_loose_version(
            "0.0.2-dev"
        )
    except:
        assert False
    try:
        SemanticVersion.from_loose_version(
            "0.0.2+0.g0e814b1"
        )
    except:
        assert False
    try:
        SemanticVersion.from_loose_version(
            "0.0.2+0.g0e814b1.dirty"
        )
    except:
        assert False
    try:
        SemanticVersion.from_loose_version(
            "1.5.5+0.g0e814b1.dirty"
        )
    except:
        assert False

# Generated at 2022-06-25 13:59:44.966229
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.0+a.b.c')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.2.0+a.b.c'

    loose_version = LooseVersion('1.2.0+a-1.b-2')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.2.0+a-1.b-2'

    loose_version = LooseVersion('1.2.3+a-1.b-2')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.2.3+a-1.b-2'

    # Test that something that is not a LooseVersion fails

# Generated at 2022-06-25 13:59:53.417384
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:59:55.745909
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_string = '1.2.3'
    loose_version = LooseVersion(test_string)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == test_string


# Generated at 2022-06-25 14:00:38.691202
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that SemanticVersion.from_loose_version does not accept non-LooseVersion param
    try:
        SemanticVersion.from_loose_version('1.0.0')
    except ValueError as excinfo:
        if not isinstance(excinfo, ValueError):
            raise
        assert str(excinfo) == "'1.0.0' is not a LooseVersion"
    else:
        assert False, "ValueError not raised"
    assert True


# Generated at 2022-06-25 14:00:44.777452
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion()
    loose_version_1 = LooseVersion()
    loose_version_2 = LooseVersion()
    loose_version_3 = LooseVersion()
    loose_version_4 = LooseVersion()
    loose_version_5 = LooseVersion()
    loose_version_6 = LooseVersion()
    loose_version_7 = LooseVersion()
    loose_version_8 = LooseVersion()
    loose_version_9 = LooseVersion()
    loose_version_10 = LooseVersion()
    loose_version_11 = LooseVersion()
    loose_version_12 = LooseVersion()
    loose_version_13 = LooseVersion()
    loose_version_14 = LooseVersion()
    loose_version_15 = LooseVersion()

# Generated at 2022-06-25 14:00:49.034231
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.2.3-a.b.c.d+z")
    version = SemanticVersion.from_loose_version(loose_version)
    assert version.vstring == "1.2.3-a.b.c.d+z"
    assert version.prerelease == (_Numeric("a"), _Alpha("b"), _Numeric("c"), _Alpha("d"))
    assert version.buildmetadata == (_Alpha("z"), )

# Generated at 2022-06-25 14:00:55.556492
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = LooseVersion('1.2.3')
    v = SemanticVersion.from_loose_version(version)
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()
    assert v.vstring == '1.2.3'

    version = LooseVersion('1.2.3-rc1')
    v = SemanticVersion.from_loose_version(version)
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == (_Numeric('rc1'),)
    assert v.buildmetadata == ()
    assert v.vstring == '1.2.3-rc1'


# Generated at 2022-06-25 14:01:03.850046
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:09.235984
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert(semantic_version.major == 1)
    assert(semantic_version.minor == 0)
    assert(semantic_version.patch == 0)
    assert(semantic_version.prerelease == ())
    assert(semantic_version.buildmetadata == ())


# Generated at 2022-06-25 14:01:17.597496
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2

    # Test with a string in the same format as a LooseVersion
    my_version = '1.9.9+version'
    my_loose_version = SemanticVersion.from_loose_version(my_version)

    assert SemanticVersion.version_re.match(my_version)
    assert my_loose_version.major == 1
    assert my_loose_version.minor == 9
    assert my_loose_version.patch == 9

    # Test with a string in the same format as a LooseVersion with no
    # build metadata
    my_version = '1.9.9'
    my_loose_version = SemanticVersion.from_loose_version(my_version)

    assert my_loose_version.major == 1

# Generated at 2022-06-25 14:01:26.178839
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Assert that invalid inputs are rejected
    try:
        SemanticVersion.from_loose_version(1)
    except ValueError:
        pass
    else:
        assert False
    try:
        SemanticVersion.from_loose_version('')
    except ValueError:
        pass
    else:
        assert False

    # Assert that a non-LooseVersion is rejected
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.0.0'))
    except ValueError:
        pass
    else:
        assert False

    # Assert that a version without major versions
    # has been set to 0
    v = SemanticVersion.from_loose_version(LooseVersion('1'))
    assert v.major == 0
    assert v.minor == 0


# Generated at 2022-06-25 14:01:34.052168
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion with only version
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')) == SemanticVersion('0.0.0')
    # Test with a LooseVersion with prerelease
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0-alpha.0')) == SemanticVersion('0.0.0-alpha.0')
    # Test with a LooseVersion with metadata
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0+0.0.0')) == SemanticVersion('0.0.0+0.0.0')
    # Test with a LooseVersion with multidigit parts

# Generated at 2022-06-25 14:01:40.160618
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # LooseVersion with no prerelease/build metadata
    loose_version = LooseVersion('1.0.0')
    assert SemanticVersion.from_loose_version(loose_version) == '1.0.0'

    # LooseVersion with prerelease/build metadata
    loose_version = LooseVersion('1.0.0-rc4+build10')
    assert SemanticVersion.from_loose_version(loose_version) == '1.0.0-rc4+build10'

    # LooseVersion with extra parts
    loose_version = LooseVersion('0.10.2b2-py2.7')
    assert SemanticVersion.from_loose_version(loose_version) == '0.10.2'

    # LooseVersion with non-integer parts
    loose_version = Lo

# Generated at 2022-06-25 14:02:02.059005
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion("0.13.38")
    x = SemanticVersion.from_loose_version(loose_version_0)
    assert x == "0.13.38"


# Generated at 2022-06-25 14:02:04.314141
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version == '1.0.0'


# Generated at 2022-06-25 14:02:10.124642
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion.from_loose_version(LooseVersion("1.2.3"))
    assert v1.vstring == "1.2.3"
    v2 = SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha.2"))
    assert v2.vstring == "1.2.3-alpha.2"
    v3 = SemanticVersion.from_loose_version(LooseVersion("1.2.3+FOO"))
    assert v3.vstring == "1.2.3+FOO"


# Generated at 2022-06-25 14:02:18.013393
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test trying to construct a semantic version from a non-loose version
    # Raises ValueError
    try:
        SemanticVersion.from_loose_version('1.2')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    # Test specifying a loose version
    loose_version = LooseVersion('1.2')

    version = SemanticVersion.from_loose_version(loose_version)
    assert version == '1.2.0', "Expected semantic version 1.2.0"

    # Test specifying a loose version with prerelease and build metadata
    loose_version = LooseVersion('1.2-alpha+build.1')

    version = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-25 14:02:24.971990
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    from_loose_version = SemanticVersion.from_loose_version(loose_version)
    assert from_loose_version.major == 1
    assert from_loose_version.minor == 2
    assert from_loose_version.patch == 3
    assert from_loose_version.prerelease == ()
    assert from_loose_version.buildmetadata == ()
    assert from_loose_version.is_prerelease == False
    assert from_loose_version.is_stable == True
    assert from_loose_version.core == (1, 2, 3)

    loose_version = LooseVersion('1.2.3-alpha')

# Generated at 2022-06-25 14:02:34.666820
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Testing case when loose_version is not type of LooseVersion
    loose_version = None
    try:
        SemanticVersion.from_loose_version(loose_version)
        raise AssertionError()
    except ValueError:
        # If exception is not AssertionError, then test is passed
        pass
    
    # Testing case when there is marker in the version
    loose_version = LooseVersion("2.4.0a0.dev0+b31f1d4")
    wanted_result = SemanticVersion("2.4.0a0.dev0+b31f1d4")
    assert SemanticVersion.from_loose_version(loose_version) == wanted_result

    # Testing case when there is no marker in the version
    loose_version = LooseVersion("2.4.0")

# Generated at 2022-06-25 14:02:43.620962
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create a LooseVersion
    loose_version_0 = LooseVersion('2.02')

    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0 == '2.2.0'

    semantic_version_1 = SemanticVersion.from_loose_version(SemanticVersion())
    assert semantic_version_1 == '0.0.0'

    semantic_version_2 = SemanticVersion.from_loose_version(SemanticVersion('0.0.0'))
    assert semantic_version_2 == '0.0.0'

    # Make sure we can handle pre-release versions
    # There is no way to create a pre-release version with a
    # LooseVersion, but string works fine
    loose_version_1 = Loose

# Generated at 2022-06-25 14:02:49.657616
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Given version string
    version_string = '1.0.0'
    # Given LooseVersion
    loose_version = LooseVersion(version_string)

    # When LooseVersion is passed to SemanticVersion.from_loose_version
    semver = SemanticVersion.from_loose_version(loose_version)

    # Then it should be equivalent to SemanticVersion(version_string)
    assert isinstance(semver, SemanticVersion) and (semver.vstring == version_string)



# Generated at 2022-06-25 14:02:55.416372
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2
    loose_version_0 = LooseVersion('1.0.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    if PY2:
        assert_false(hasattr(semantic_version_0, '__class__'))
    else:
        assert_equal(type(semantic_version_0), SemanticVersion)
    assert_equal(semantic_version_0.vstring, '1.0.0')


# Generated at 2022-06-25 14:03:01.963918
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:03:47.876874
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    assert SemanticVersion.from_loose_version(LooseVersion('1-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')


# Generated at 2022-06-25 14:03:51.969759
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    ret = SemanticVersion.from_loose_version(
        LooseVersion('1.2.3')
    )
    assert ret == SemanticVersion('1.2.3')

    ret = SemanticVersion.from_loose_version(
        LooseVersion('1.2.3-alpha.1')
    )
    assert ret == SemanticVersion('1.2.3-alpha.1')

    ret = SemanticVersion.from_loose_version(
        LooseVersion('1.2.3-alpha.1+build.1')
    )
    assert ret == SemanticVersion('1.2.3-alpha.1+build.1')

    ret = SemanticVersion.from_loose_version(
        LooseVersion('1.2.3-alpha+build.1')
    )

# Generated at 2022-06-25 14:03:58.930122
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    string_0 = SemanticVersion(vstring='1.0.0')
    assert isinstance(string_0, SemanticVersion)
    assert string_0.core == (1, 0, 0)

    loose_version = LooseVersion('1.0.0')
    version = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(version, SemanticVersion)
    assert version.core == (1, 0, 0)

    loose_version = LooseVersion('1.0.0.0.0')
    version = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(version, SemanticVersion)
    assert version.core == (1, 0, 0)

    loose_version = LooseVersion('1.0.0-1')
    version = Sem

# Generated at 2022-06-25 14:04:06.070063
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3rc1')) == SemanticVersion('1.2.3-rc1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-rc1')) == SemanticVersion('1.2.3-rc1')

# Generated at 2022-06-25 14:04:08.474035
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    d = LooseVersion('1.1a2')
    s = SemanticVersion.from_loose_version(d)
    assert s == '1.1.0'



# Generated at 2022-06-25 14:04:15.207958
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:04:25.592979
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1')
    sv = SemanticVersion.from_loose_version(loose_version)
    assert sv == '1.0.0'

    loose_version = LooseVersion('1.1')
    sv = SemanticVersion.from_loose_version(loose_version)
    assert sv == '1.1.0'

    loose_version = LooseVersion('1.1.1')
    sv = SemanticVersion.from_loose_version(loose_version)
    assert sv == '1.1.1'

    loose_version = LooseVersion('1.1.1-alpha')
    sv = SemanticVersion.from_loose_version(loose_version)
    assert sv == '1.1.1-alpha'


# Generated at 2022-06-25 14:04:28.165952
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test SemanticVersion.from_loose_version"""
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('0.0.10a')
    assert SemanticVersion.from_loose_version('0.0.10a') == SemanticVersion('0.0.10')

# Generated at 2022-06-25 14:04:31.448799
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    loose_version_0 = LooseVersion()
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version_0)
    try:
        semantic_version_1 = SemanticVersion.from_loose_version(semantic_version_0)
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-25 14:04:34.519386
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.5.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert semantic_version.__class__ == SemanticVersion
    assert semantic_version.major == 1
    assert semantic_version.minor == 5
    assert semantic_version.patch == 1
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()

