

# Generated at 2022-06-25 13:55:18.348162
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    _alpha_0 = _Alpha('1.0.0-alpha')
    _alpha_1 = _Alpha('1.0.0-alpha.1')
    assert _alpha_0 <= _alpha_1


# Generated at 2022-06-25 13:55:21.049249
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.11.1')
    SemanticVersion_from_loose_version_0 = SemanticVersion.from_loose_version(loose_version_0)


# Generated at 2022-06-25 13:55:23.130376
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    try:
        test_case_0()
    except ValueError as expected_exception:
        assert str(expected_exception) == "invalid semantic version ''"


# Generated at 2022-06-25 13:55:32.748704
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('0.0.0').major == 0
    assert SemanticVersion('0.0.0').minor == 0
    assert SemanticVersion('0.0.0').patch == 0
    assert SemanticVersion('0.0.0').core == (0, 0, 0)
    assert SemanticVersion('0.0.0').prerelease == ()
    assert SemanticVersion('0.0.0').buildmetadata == ()

    assert SemanticVersion('1.2.3').major == 1
    assert SemanticVersion('1.2.3').minor == 2
    assert SemanticVersion('1.2.3').patch == 3
    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    assert SemanticVersion('1.2.3').prerelease == ()

# Generated at 2022-06-25 13:55:39.792428
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()
    test_case_10()
    test_case_11()
    test_case_12()
    test_case_13()
    test_case_14()
    test_case_15()
    test_case_16()


# Generated at 2022-06-25 13:55:47.494369
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_1 = LooseVersion('1')
    semantic_version_3 = SemanticVersion.from_loose_version(loose_version_1)
    assert semantic_version_3.vstring == '1.0.0'
    loose_version_2 = LooseVersion('1.2')
    semantic_version_4 = SemanticVersion.from_loose_version(loose_version_2)
    assert semantic_version_4.vstring == '1.2.0'
    loose_version_3 = LooseVersion('1.2.3')
    semantic_version_5 = SemanticVersion.from_loose_version(loose_version_3)
    assert semantic_version_5.vstring == '1.2.3'

# Generated at 2022-06-25 13:55:49.966080
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.3.0')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)


# Generated at 2022-06-25 13:55:55.950555
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    vstring = u'0.0.0'
    semantic_version_0.parse(vstring)
    complex_semantic_version_0 = u'0.0.1-a.b+c.d'
    semantic_version_0.parse(complex_semantic_version_0)
    version_0 = u'0'
    semantic_version_0.parse(version_0)


# Generated at 2022-06-25 13:56:03.827952
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    import os
    import json
    import pytest
    from ansible.galaxy.api.semver import SemanticVersion

    test_data = json.load(open(os.path.join(os.path.dirname(__file__), 'data/semver.json')))

    invalid = test_data['invalid']
    valid = test_data['valid']

    # Invalid
    for case in invalid:
        assert pytest.raises(ValueError, SemanticVersion, case)

    # Valid
    for case in valid:
        version = SemanticVersion(case)
        assert isinstance(version, SemanticVersion)
        assert version.major == valid[case]['major']
        assert version.minor == valid[case]['minor']
        assert version.patch == valid[case]['patch']

# Generated at 2022-06-25 13:56:04.777089
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion().parse('1.2.3') == (1, 2, 3)


# Generated at 2022-06-25 13:56:18.402179
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha_1 = _Alpha('alpha')
    alpha_2 = _Alpha('alpha')
    alpha_3 = _Alpha('numeric')

    assert(alpha_1 <= alpha_2)
    assert(alpha_1 <= text_type('alpha'))
    assert(alpha_2 <= text_type('alpha'))
    assert(alpha_1 <= text_type('numeric'))
    assert(alpha_2 <= text_type('numeric'))
    assert(not alpha_3 <= text_type('alpha'))
    assert(not alpha_3 <= text_type('numeric'))


# Generated at 2022-06-25 13:56:22.341770
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():

    # Set up method data
    a_str = 'a'
    b_str = 'b'

    # Invoke method
    alpha_a = _Alpha(a_str)
    alpha_b = _Alpha(b_str)
    actual_result = alpha_a.__le__(alpha_b)
    assert alpha_a <= alpha_b
    assert not alpha_a > alpha_b


# Generated at 2022-06-25 13:56:31.316781
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    semantic_version_0 = SemanticVersion()
    _alpha_1 = _Alpha("0")
    _alpha_2 = _Alpha("0")
    _alpha___le___call_result_0 = _alpha_1.__le__(_alpha_2)
    _alpha___le___call_result_1 = _alpha_1.__le__("0")
    _alpha___le___call_result_2 = _alpha_1.__le__(_alpha_1)
    _alpha_3 = _Alpha("1")
    _alpha___le___call_result_3 = _alpha_1.__le__(_alpha_3)
    _alpha___le___call_result_4 = _alpha_1.__le__("1")
    _alpha_4 = _Alpha("0")
    _alpha_5 = _Alpha("1")
   

# Generated at 2022-06-25 13:56:32.158476
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    pass


# Generated at 2022-06-25 13:56:40.622891
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-25 13:56:48.164442
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = SemanticVersion.from_loose_version('1.3.3rc1')
    assert v.is_prerelease
    assert v.prerelease == ('rc', 1)
    assert v.core == (1, 3, 3)

    v = SemanticVersion.from_loose_version('1.3.3')
    assert not v.is_prerelease
    assert v.core == (1, 3, 3)

    v = SemanticVersion.from_loose_version('1.3.3-rc1.3.3')
    assert v.is_prerelease
    assert v.prerelease == ('rc', 1, 3, 3)
    assert v.core == (1, 3, 3)

    v = SemanticVersion.from_loose_version('1.3.3-rc1')
    assert v

# Generated at 2022-06-25 13:56:55.736588
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test where none of the version components contain any characters
    # that would need to be filtered from the version
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    # Test where the version contains a prerelease component
    loose_version = LooseVersion('1.2.3b4-alpha.1')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3-b4.alpha.1')

    # Test where the version contains a build metadata component
    loose_version = LooseVersion('1.2.3-b4.alpha.1-1+20200101.20200102')
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-25 13:56:58.589737
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    input_args = '2.8.15+'
    expected_result = '2.8.15+'

    result = SemanticVersion.from_loose_version(
        LooseVersion(input_args)
    ).vstring

    assert result == expected_result


# Generated at 2022-06-25 13:57:07.031263
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible.module_utils.distro_spec.distro_spec
    from ansible.module_utils.distro_spec.distro_spec import VersionRange

    version_string = '3.3.3-beta1.1.1'
    loose_version = LooseVersion(version_string)

    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == version_string

    # test with non LooseVersion
    try:
        SemanticVersion.from_loose_version(ansible.module_utils.distro_spec.distro_spec.DistroSpec)
        assert False
    except ValueError:
        assert True

    # test with LooseVersion with non int values

# Generated at 2022-06-25 13:57:08.505245
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha_0 = _Alpha('1')
    _Numeric('1') <= alpha_0


# Generated at 2022-06-25 13:57:24.280933
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:57:28.752546
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = '1.2.3.dev123'
    expected_version = '1.2.3'
    expected_version_type = str
    v = SemanticVersion.from_loose_version(loose_version)
    assert v.vstring == expected_version
    assert type(v.vstring) == expected_version_type


# Generated at 2022-06-25 13:57:37.220627
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0')) == SemanticVersion('1.0.0')

# Generated at 2022-06-25 13:57:39.724950
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_from_loose_version_0 = SemanticVersion.from_loose_version(
        LooseVersion('1.9.0')
    )



# Generated at 2022-06-25 13:57:42.539404
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1-beta.1')).vstring == '0.1-beta.1'

test_case_0()
test_SemanticVersion_from_loose_version()

# Generated at 2022-06-25 13:57:49.135934
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    # Test basic numeric version
    v=SemanticVersion( '1.2.3' )
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert len(v.prerelease) == 0
    assert len(v.buildmetadata) == 0
    assert v.is_stable

    # Test with prerelease
    v=SemanticVersion( '1.2.3-alpha1' )
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert len(v.prerelease) == 1
    assert v.prerelease[0] == 'alpha1'
    assert len(v.buildmetadata) == 0
    assert not v.is_stable

    v=SemanticVersion( '1.2.3-alpha.1' )


# Generated at 2022-06-25 13:57:57.322916
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("3.2.1.2")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 3
    assert semantic_version.minor == 2
    assert semantic_version.patch == 1
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()

    loose_version = LooseVersion("3.2.1.2+b2")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 3
    assert semantic_version.minor == 2
    assert semantic_version.patch == 1
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == (u'b', u'2')

    loose

# Generated at 2022-06-25 13:57:57.828659
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    pass


# Generated at 2022-06-25 13:58:05.583060
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    SemanticVersion_0 = SemanticVersion.from_loose_version(LooseVersion('0.0'))
    SemanticVersion_1 = SemanticVersion.from_loose_version(LooseVersion('0.0.1'))
    SemanticVersion_2 = SemanticVersion.from_loose_version(LooseVersion('0.1'))
    SemanticVersion_3 = SemanticVersion.from_loose_version(LooseVersion('0.0-0'))
    SemanticVersion_4 = SemanticVersion.from_loose_version(LooseVersion('0.0.1-0'))
    SemanticVersion_5 = SemanticVersion.from_loose_version(LooseVersion('0.1-0'))

# Generated at 2022-06-25 13:58:10.563398
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Init
    loose_version = LooseVersion('0.1.1-rc.0')

    # Run
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # Assert
    assert semantic_version.major == 0
    assert semantic_version.minor == 1
    assert semantic_version.patch == 1
    assert semantic_version.prerelease == (_Numeric(0),)
    assert isinstance(semantic_version.prerelease[0], _Numeric)
    assert semantic_version.vstring == '0.1.1-rc.0'



# Generated at 2022-06-25 13:58:22.037899
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:58:27.919390
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Testing the case where the 'version' attribute is not a list
    case_1 = LooseVersion('1')
    case_1.version = 1
    try:
        SemanticVersion.from_loose_version(case_1)
    except ValueError:
        assert True
    else:
        assert False

    # Testing the case where the 'version' attribute contains non integer values
    case_2 = LooseVersion('test')
    case_2.version = ['test']
    try:
        SemanticVersion.from_loose_version(case_2)
    except ValueError:
        assert True
    else:
        assert False

    # Testing the case where a LooseVersion is used
    case_3 = LooseVersion('1.2.3-rc.4')
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-25 13:58:35.572230
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()
    assert not hasattr(semantic_version, 'major')
    assert not hasattr(semantic_version, 'minor')
    assert not hasattr(semantic_version, 'patch')
    assert not hasattr(semantic_version, 'prerelease')
    assert not hasattr(semantic_version, 'buildmetadata')

    semantic_version.parse('1.2.3')

    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert not semantic_version.prerelease
    assert not semantic_version.buildmetadata

# Tests for the prerelease and buildmetadata handling

# Generated at 2022-06-25 13:58:44.453173
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0a1')).vstring == '1.0.0-a1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0a1')).vstring == '1.0.0-a1'

# Generated at 2022-06-25 13:58:49.171297
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Creating instance of class SemanticVersion
    semantic_version = SemanticVersion()

    # Creating instance of class LooseVersion
    loose_version = LooseVersion('13.0.0')

    # Calling method from_loose_version of class SemanticVersion
    result = SemanticVersion.from_loose_version(loose_version)

    # Testing result of method from_loose_version
    # note that we don't test the exact value of result, as it depends on the
    # value of the field 'build_stage' of class SemanticVersion, which is
    # not accessible outside the class. We only test that result is an
    # instance of class SemanticVersion
    assert isinstance(result, SemanticVersion)

# Generated at 2022-06-25 13:58:56.875144
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 13:59:05.925424
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion(text_type('1.2.3'))
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert not semantic_version.prerelease
    assert not semantic_version.buildmetadata
    assert semantic_version.is_stable
    assert not semantic_version.is_prerelease
    assert semantic_version == '1.2.3'

    loose_version = LooseVersion(text_type('0.1.2'))
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 0
    assert semantic_version.minor == 1
    assert semantic_version

# Generated at 2022-06-25 13:59:13.354465
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('2.4.3.4')

    # Call method from_loose_version of class SemanticVersion with argument loose_version_0
    # It raises ValueError if the version component is not an
    # integer.

    try:
        SemanticVersion.from_loose_version(loose_version_0)
    except ValueError as err:
        print(err)

    loose_version_1 = LooseVersion('2.4.3.4')

    # Construct a SemanticVersion coerced from a LooseVersion
    # and test that the constructed version is equivalent to
    # the coerced version

    assert SemanticVersion.from_loose_version(loose_version_1) == SemanticVersion('2.4.3.4')


# Generated at 2022-06-25 13:59:21.422180
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.compat.version import LooseVersion

    vstring = '1.2.3'

    loose_version = LooseVersion(vstring)
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # Ensure the provided string is not a semver
    if PY3:
        assert not isinstance(semantic_version.vstring, bytes)
    assert not isinstance(semantic_version.vstring, text_type)

    # Ensure the provided string is not a loose version
    assert not isinstance(
        loose_version, LooseVersion
    )

    # Ensure the from_loose_version method actually worked
    assert isinstance(semantic_version, SemanticVersion)

    # Ensure that

# Generated at 2022-06-25 13:59:28.922474
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '2.0'
    expect_major = 2
    expect_minor = 0
    expect_patch = 0
    expect_prerelease = ()
    expect_buildmetadata = ()

    loose_version = LooseVersion(vstring)
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert semantic_version.vstring == vstring
    assert semantic_version.major == expect_major
    assert semantic_version.minor == expect_minor
    assert semantic_version.patch == expect_patch
    assert semantic_version.prerelease == expect_prerelease
    assert semantic_version.buildmetadata == expect_buildmetadata


# Generated at 2022-06-25 13:59:51.707226
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test basic parse
    for vstring in (
        '1.2.3',
        '1.2.3-rc.1',
        '1.2.3+build.42',
        '1.2.3-rc.1+build.42',
    ):
        semantic_version = SemanticVersion(vstring)
        assert vstring == semantic_version.vstring, 'failed to parse %r' % vstring
        assert semantic_version.major == 1, 'failed to parse %r major' % vstring
        assert semantic_version.minor == 2, 'failed to parse %r minor' % vstring
        assert semantic_version.patch == 3, 'failed to parse %r patch' % vstring

    # Test equality
    vstring = '1.2.3'

# Generated at 2022-06-25 13:59:58.784010
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # NOTE: LooseVersion is used as it is the parent class of StrictVersion
    # which is not present in python2
    loose_version = LooseVersion('2.5.1')
    result = SemanticVersion.from_loose_version(loose_version)
    assert result == SemanticVersion('2.5.1')
    assert result.major == 2
    assert result.minor == 5
    assert result.patch == 1
    assert result.prerelease == ()
    assert result.buildmetadata == ()

    loose_version = LooseVersion('2.5.1a1')
    result = SemanticVersion.from_loose_version(loose_version)
    assert result == SemanticVersion('2.5.1-a1')
    assert result.major == 2
    assert result.minor == 5

# Generated at 2022-06-25 14:00:07.600499
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.version import SemanticVersion, LooseVersion

    assert SemanticVersion('1') == SemanticVersion.from_loose_version(LooseVersion('1'))
    assert SemanticVersion('1.0') == SemanticVersion.from_loose_version(LooseVersion('1.0'))
    assert SemanticVersion('1.0.0') == SemanticVersion.from_loose_version(LooseVersion('1.0.0'))

    assert SemanticVersion('1-alpha') == SemanticVersion.from_loose_version(LooseVersion('1pre-alpha'))
    assert SemanticVersion('1-alpha.1') == SemanticVersion.from_loose_version(LooseVersion('1pre-alpha.1'))
    assert SemanticVersion('1.0-alpha') == Sem

# Generated at 2022-06-25 14:00:13.675775
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0-1')
    semantic_version = '1.0.0-1'
    expected = semantic_version

    actual = SemanticVersion.from_loose_version(loose_version).vstring

    print('Asserting that SemanticVersion.from_loose_version(%s) is %s' % (repr(loose_version), repr(expected)))
    assert expected == actual, '%s != %s' % (expected, actual)

if __name__ == '__main__':
    test_case_0()
    test_SemanticVersion_from_loose_version()

# Generated at 2022-06-25 14:00:21.953004
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    v.parse("1.2.3")
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()
    assert str(v) == "1.2.3"

    v.parse("1.2.3-alpha")
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ('alpha',)
    assert v.buildmetadata == ()
    assert str(v) == "1.2.3-alpha"

    v.parse("1.2.3-alpha.1")
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v

# Generated at 2022-06-25 14:00:25.805563
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = LooseVersion('1.0')
    assert isinstance(SemanticVersion.from_loose_version(v), SemanticVersion)
    assert SemanticVersion.from_loose_version(v).vstring == '1.0.0'


# Generated at 2022-06-25 14:00:35.073978
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    print('Test parse')

    test_cases = (
        '1.0.0',
        '1.0.1',
        '2.2.4',
        '2.2.4+build.1',
        '1.0.0-alpha',
        '1.0.0-alpha.1',
        '1.0.0-0.3.7',
        '1.0.0-x.7.z.92',
        '1.0.0-alpha+001',
        '1.0.0+20130313144700',
        '1.0.0-beta+exp.sha.5114f85',
    )

# Generated at 2022-06-25 14:00:41.246530
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Simple test
    version = SemanticVersion('1.0.0')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # Prerelease test
    version = SemanticVersion('1.0.0-alpha')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == (_Alpha('alpha'),)
    assert version.buildmetadata == ()

    # Build metadata test
    version = SemanticVersion('1.0.0+foo')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()

# Generated at 2022-06-25 14:00:42.910458
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion()
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)


# Generated at 2022-06-25 14:00:49.418077
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()

    semantic_version.parse("1.0.0")

    assert semantic_version.vstring == "1.0.0"
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()
    assert semantic_version.core == (1, 0, 0)
    assert semantic_version.is_prerelease == False
    assert semantic_version.is_stable == True

    semantic_version.parse("1.0.0-alpha.1")

    assert semantic_version.vstring == "1.0.0-alpha.1"
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_

# Generated at 2022-06-25 14:01:11.808275
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Missing argument
    try:
        ansible_module_utils.compat.version_utils.SemanticVersion.from_loose_version()
    except Exception as e:
        assert str(e) == "from_loose_version() missing 1 required positional argument: 'loose_version'"

    # Non 'LooseVersion' type argument
    try:
        ansible_module_utils.compat.version_utils.SemanticVersion.from_loose_version(1)
    except Exception as e:
        assert str(e) == "1 is not a LooseVersion"

    # 'LooseVersion' with non-integer values
    try:
        ansible_module_utils.compat.version_utils.SemanticVersion.from_loose_version('1.5a1')
    except Exception as e:
        assert str

# Generated at 2022-06-25 14:01:20.084920
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    semantic_version_1 = SemanticVersion()
    semantic_version_2 = SemanticVersion()
    semantic_version_3 = SemanticVersion()
    semantic_version_4 = SemanticVersion()
    semantic_version_5 = SemanticVersion()
    semantic_version_6 = SemanticVersion()
    semantic_version_7 = SemanticVersion()
    semantic_version_8 = SemanticVersion()
    semantic_version_9 = SemanticVersion()
    semantic_version_10 = SemanticVersion()
    semantic_version_11 = SemanticVersion()
    semantic_version_12 = SemanticVersion()
    semantic_version_13 = SemanticVersion()
    semantic_version_14 = SemanticVersion()
    semantic_version_15 = SemanticVersion()

# Generated at 2022-06-25 14:01:28.482081
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.10.1+dev1')

    version = SemanticVersion.from_loose_version(loose_version)
    assert version.major == 2
    assert version.minor == 10
    assert version.patch == 1
    assert version.prerelease == ()
    assert version.buildmetadata == (text_type('dev1'),)

    try:
        SemanticVersion.from_loose_version('2.0')
    except ValueError as e:
        assert e.args[0] == "'2.0' is not a LooseVersion"
    else:
        assert False, "No ValueError exception thrown" # pragma: no cover


# Generated at 2022-06-25 14:01:30.294606
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version = SemanticVersion()
    semantic_version.parse("1.2.3")


# Generated at 2022-06-25 14:01:31.227919
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert not getattr(SemanticVersion, 'parse')


# Generated at 2022-06-25 14:01:37.923899
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    semantic_version_0 = SemanticVersion()
    semantic_version_0.parse('0.0.0')
    assert semantic_version_0.major == 0
    assert semantic_version_0.minor == 0
    assert semantic_version_0.patch == 0
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()
    semantic_version_0.parse('0.0.0-alpha+alpha')
    assert semantic_version_0.major == 0
    assert semantic_version_0.minor == 0
    assert semantic_version_0.patch == 0
    assert semantic_version_0.prerelease == ('alpha',)
    assert semantic_version_0.buildmetadata == ('alpha',)

# Generated at 2022-06-25 14:01:43.686957
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version1 = SemanticVersion.from_loose_version(LooseVersion('1.0.0-rc.1'))
    assert version1 == SemanticVersion('1.0.0-rc.1')

    version2 = SemanticVersion.from_loose_version(LooseVersion('1.0.1-alpha'))
    assert version2 == SemanticVersion('1.0.1-alpha')

    version3 = SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.12'))
    assert version3 == SemanticVersion('1.2.3+build.12')

    version4 = SemanticVersion.from_loose_version(LooseVersion('2.2.2.0'))
    assert version4 == SemanticVersion('2.2.2')

    version5 = Sem

# Generated at 2022-06-25 14:01:45.728033
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion("0.0.0")
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)



# Generated at 2022-06-25 14:01:49.468447
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test case 1
    semantic_version_1 = SemanticVersion()
    try:
        semantic_version_1.parse('1.0.0')
    except ValueError:
        assert True
    else:
        assert False
    assert semantic_version_1.major == 1
    assert semantic_version_1.minor == 0
    assert semantic_version_1.patch == 0


# Generated at 2022-06-25 14:01:56.266639
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0'

    loose_version = LooseVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0-alpha'

    loose_version = LooseVersion('1.0.0-beta')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0-beta'

    loose_version = LooseVersion('1.0.0-rc')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0-rc'

    loose_version = Loose

# Generated at 2022-06-25 14:02:26.690011
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with good values
    loose_version = LooseVersion('0.12.4-final')
    assert_equals(SemanticVersion.from_loose_version(loose_version), SemanticVersion('0.12.4'))

    loose_version = LooseVersion('0.12.4.final')
    assert_equals(SemanticVersion.from_loose_version(loose_version), SemanticVersion('0.12.4'))

    loose_version = LooseVersion('0.12.4-final-abc')
    assert_equals(SemanticVersion.from_loose_version(loose_version), SemanticVersion('0.12.4-final-abc'))

    loose_version = LooseVersion('0.12.4+abc')

# Generated at 2022-06-25 14:02:30.479083
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0b1')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0-0b1'


# Generated at 2022-06-25 14:02:39.282945
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:02:48.682888
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    class LooseVersionwithExtra(LooseVersion):
        def __init__(self, vstring):
            super(LooseVersionwithExtra, self).__init__(vstring)
            self.vstring = vstring

    class LooseVersionwithNone(LooseVersion):
        def __init__(self, vstring):
            super(LooseVersionwithNone, self).__init__(vstring)

    assert SemanticVersion.from_loose_version(LooseVersionwithExtra('1.2.3')) == SemanticVersion('1.2.3')

    assert SemanticVersion.from_loose_version(LooseVersionwithNone('1.2.3')) == Sem

# Generated at 2022-06-25 14:02:51.697621
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('0.1.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semantic_version_0.vstring == '0.1.1'


# Generated at 2022-06-25 14:02:54.630904
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vstring = '1.2.3-1.2.3'
    loose_version = LooseVersion(vstring)
    result = SemanticVersion.from_loose_version(loose_version)
    assert result.vstring == vstring


# Generated at 2022-06-25 14:03:01.326064
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).major == 1
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).minor == 0
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).patch == 0
    #
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0')).major == 1
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0')).minor == 0
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0')).patch == 0

# Generated at 2022-06-25 14:03:07.909251
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.5.1")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert type(semantic_version) == SemanticVersion
    assert semantic_version.major == 1
    assert semantic_version.minor == 5
    assert semantic_version.patch == 1

    # empty string
    loose_version = LooseVersion("1")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert type(semantic_version) == SemanticVersion
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0

    # prerelease
    loose_version = LooseVersion("1.5.1-beta.2")
    semantic_version = Semantic

# Generated at 2022-06-25 14:03:14.686534
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test passing a non-LooseVersion
    try:
        SemanticVersion.from_loose_version(None)
    except ValueError:
        pass
    else:
        assert False, "Failed to raise ValueError on SemanticVersion.from_loose_version(None)"

    # Test passing a LooseVersion with a marker but without a build metadata
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.0.0-0'))
    except ValueError:
        pass
    else:
        assert False, "Failed to raise ValueError on SemanticVersion.from_loose_version(LooseVersion('1.0.0-0'))"

    # Test passing a LooseVersion with a marker and build metadata

# Generated at 2022-06-25 14:03:21.963304
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_0 = LooseVersion('1.2.3')
    if isinstance(loose_0, LooseVersion):
        semantic_0 = SemanticVersion.from_loose_version(loose_0)
        assert semantic_0.major == 1
        assert semantic_0.minor == 2
        assert semantic_0.patch == 3
        assert semantic_0.prerelease == ()
        assert semantic_0.buildmetadata == ()
    loose_1 = LooseVersion('1.2.3.4')
    if isinstance(loose_1, LooseVersion):
        semantic_1 = SemanticVersion.from_loose_version(loose_1)
        assert semantic_1.major == 1
        assert semantic_1.minor == 2
        assert semantic_1.patch == 3
        assert semantic_1.pre

# Generated at 2022-06-25 14:03:59.376908
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class LooseVersion:
        def __init__(self, vstring):
            self.vstring = vstring
            self.version = None

        def __repr__(self):
            return 'LooseVersion(%r)' % self.vstring

    ret = SemanticVersion.from_loose_version(LooseVersion('1'))
    assert ret.vstring == '1.0.0'

    ret = SemanticVersion.from_loose_version(LooseVersion('1.2'))
    assert ret.vstring == '1.2.0'

    ret = SemanticVersion.from_loose_version(LooseVersion('1.2.5'))
    assert ret.vstring == '1.2.5'


# Generated at 2022-06-25 14:04:06.895234
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert semantic_version_0.major == 1
    assert type(semantic_version_0.major) is int
    assert semantic_version_0.minor == 0
    assert type(semantic_version_0.minor) is int
    assert semantic_version_0.patch == 0
    assert type(semantic_version_0.patch) is int
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion('1.0'))
    assert semantic_version_1.major == 1
    semantic_version_2 = SemanticVersion.from_loose_version(LooseVersion('1'))
    assert semantic_version_2.major == 1
    semantic_version_

# Generated at 2022-06-25 14:04:13.878022
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:04:24.074764
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    if not isinstance(loose_version, LooseVersion):
        raise ValueError("%r is not a LooseVersion" % loose_version)

    try:
        version = loose_version.version[:]
    except AttributeError:
        raise ValueError("%r is not a LooseVersion" % loose_version)

    extra_idx = 3
    for marker in ('-', '+'):
        try:
            idx = version.index(marker)
        except ValueError:
            continue
        else:
            if idx < extra_idx:
                extra_idx = idx
    version = version[:extra_idx]

    if version and set(type(v) for v in version) != set((int,)):
        raise ValueError("Non integer values in %r" % loose_version)



# Generated at 2022-06-25 14:04:30.704765
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Validate SemanticVersion.from_loose_version
    # Given vstring is not a LooseVersion
    try:
        SemanticVersion.from_loose_version('0.0.0')
    except ValueError:
        pass
    else:
        raise AssertionError()

    # Given vstring has non integer values
    try:
        SemanticVersion.from_loose_version(LooseVersion('0.0.0-dev'))
    except ValueError:
        pass
    else:
        raise AssertionError()

    # Given vstring has no prerelease or build metadata
    version = SemanticVersion.from_loose_version(LooseVersion('0.0.0'))

    assert isinstance(version, SemanticVersion)

    # Given vstring has prerelease

# Generated at 2022-06-25 14:04:37.147093
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:04:42.864673
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    Test for method from_loose_version of class SemanticVersion
    '''
    # Set up local variables
    current = '2.2.0.0'
    latest = '2.2.0.0'
    latest_semantic = SemanticVersion.from_loose_version(LooseVersion(latest))
    current_semantic = SemanticVersion.from_loose_version(LooseVersion(current))
    assert latest_semantic == current_semantic
# end of test_SemanticVersion_from_loose_version


# Generated at 2022-06-25 14:04:49.673576
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.1')) == '1.0.1'
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.0')) == '2.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('2.1.0')) == '2.1.0'
    assert SemanticVersion.from_loose_version(LooseVersion('2.1.1')) == '2.1.1'
    assert SemanticVersion.from_loose_version(LooseVersion('2.1.2')) == '2.1.2'
   

# Generated at 2022-06-25 14:04:55.671030
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    ss = SemanticVersion.from_loose_version(LooseVersion("1"))
    assert isinstance(ss, SemanticVersion)
    assert ss == "1.0.0"

    ss = SemanticVersion.from_loose_version(LooseVersion("1.1"))
    assert isinstance(ss, SemanticVersion)
    assert ss == "1.1.0"

    ss = SemanticVersion.from_loose_version(LooseVersion("1.1.1"))
    assert isinstance(ss, SemanticVersion)
    assert ss == "1.1.1"

    ss = SemanticVersion.from_loose_version(LooseVersion("1-acme"))
    assert isinstance(ss, SemanticVersion)
    assert ss == "1.0.0-acme"


# Generated at 2022-06-25 14:05:00.185035
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.0.0-rc.1')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)
    # Check the value of attribute major of type int
    assert semantic_version_0.major == 1
    # Check the value of attribute minor of type int
    assert semantic_version_0.minor == 0
    # Check the value of attribute patch of type int
    assert semantic_version_0.patch == 0
    # Check the value of attribute prerelease of type int
    assert semantic_version_0.prerelease == ('rc.', 1)
    # Check the value of attribute buildmetadata of type int
    assert semantic_version_0.buildmetadata == ()
