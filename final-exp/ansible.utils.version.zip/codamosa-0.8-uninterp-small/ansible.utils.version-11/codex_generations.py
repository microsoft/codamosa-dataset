

# Generated at 2022-06-25 13:55:14.259712
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    numeric_0 = 1
    numeric_1 = _Numeric(numeric_0)
    numeric_2 = numeric_1
    numeric_3 = _Numeric(numeric_1)
    str_0 = 'z'
    str_1 = _Alpha(str_0)
    str_2 = str_1
    str_3 = _Alpha(str_1)
    var_0 = str_1
    var_1 = str_3
    assert (var_0 <= var_1)
    var_0 = str_2
    var_1 = str_2
    assert (var_0 <= var_1)
    var_0 = str_1
    var_1 = str_2
    assert (var_0 <= var_1)
    var_0 = str_1
    var_1 = numeric_0
   

# Generated at 2022-06-25 13:55:18.994347
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    """
    Test the _Alpha class __le__ method
    """
    for semantic_version_0 in range(10):
        for semantic_version_1 in range(10):
            assert(_Alpha(semantic_version_0) <= _Alpha(semantic_version_1))
            assert not(_Alpha(semantic_version_1) <= _Alpha(semantic_version_0))


# Generated at 2022-06-25 13:55:21.099104
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        raise AssertionError('load_module_source failed')

# Generated at 2022-06-25 13:55:28.259333
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha_1 = _Alpha('alpha')
    alpha_2 = _Alpha('alpha')
    alpha_3 = _Alpha('beta')
    alpha_4 = _Alpha('gamma')

    assert alpha_1 <= alpha_2
    assert alpha_1 <= alpha_3
    assert alpha_1 <= alpha_4
    assert alpha_1 <= 'alpha'
    assert alpha_1 <= 'beta'

    assert not alpha_3 <= alpha_1
    assert not alpha_3 <= 'alpha'
    assert alpha_3 <= alpha_3
    assert alpha_3 <= alpha_4
    assert alpha_3 <= 'gamma'



# Generated at 2022-06-25 13:55:38.605330
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = LooseVersion('0.12.3+abc')
    sv = SemanticVersion.from_loose_version(version)

    assert sv.major == 0
    assert sv.minor == 12
    assert sv.patch == 3

    assert sv.is_stable

    version = LooseVersion('1.12.3+abc')
    sv = SemanticVersion.from_loose_version(version)

    assert sv.major == 1
    assert sv.minor == 12
    assert sv.patch == 3

    assert sv.is_stable

    version = LooseVersion('1.12.3-rc1')
    sv = SemanticVersion.from_loose_version(version)

    assert sv.major == 1
    assert sv.minor == 12
    assert sv.patch == 3

    assert sv.is_prerelease

# Generated at 2022-06-25 13:55:40.490646
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha_0 = _Alpha(_Alpha(None))
    alpha_1 = _Alpha(None)
    assert alpha_0 <= alpha_1


# Generated at 2022-06-25 13:55:43.273934
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    numeric_0 = None
    _alpha_0 = _Alpha(numeric_0)
    numeric_1 = None
    _alpha_1 = _Alpha(numeric_1)
    assert not (_alpha_0 <= _alpha_1)


# Generated at 2022-06-25 13:55:51.847085
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    numeric_0 = None
    numeric_1 = 0
    numeric_2 = 0
    numeric_3 = 0
    numeric_4 = 0
    numeric_5 = 0
    numeric_6 = 0
    numeric_7 = 0
    numeric_8 = 0
    numeric_9 = 0
    semantic_version_0 = SemanticVersion(numeric_0)
    semantic_version_1 = SemanticVersion(numeric_0)
    semantic_version_2 = SemanticVersion(numeric_0)
    semantic_version_3 = SemanticVersion(numeric_0)
    semantic_version_4 = SemanticVersion(numeric_0)
    semantic_version_5 = SemanticVersion(numeric_0)
    semantic_version_6 = SemanticVersion(numeric_0)
    semantic_version_7 = SemanticVersion

# Generated at 2022-06-25 13:56:01.170801
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create some test objects
    numeric_0 = SemanticVersion.from_loose_version(
        LooseVersion('20200304')
    )

    # Call the method
    try:
        # Call the method
        SemanticVersion.from_loose_version('20200304')
    except ValueError:
        assert True
    else:
        assert False, "Failed to raise a ValueError"

    numeric_1 = SemanticVersion.from_loose_version('20200304')

    numeric_2 = SemanticVersion.from_loose_version(
        LooseVersion('20200304.0')
    )

    numeric_3 = SemanticVersion.from_loose_version('20200304.0')


# Generated at 2022-06-25 13:56:06.848596
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    numeric_0 = None
    semantic_version_0 = SemanticVersion(numeric_0)

    try:
        semantic_version_0.parse('1.2.3')
    except ValueError:
        raise AssertionError("Invocation of method parse failed. Exception ValueError not raised")

    try:
        semantic_version_0.parse('1.2.3-alpha.beta')
    except ValueError:
        raise AssertionError("Invocation of method parse failed. Exception ValueError not raised")

    try:
        semantic_version_0.parse('1.2.3+build.metadata')
    except ValueError:
        raise AssertionError("Invocation of method parse failed. Exception ValueError not raised")


# Generated at 2022-06-25 13:56:19.773616
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test the _Alpha class __le__ method
    x = 'foo'
    expected_result = True
    y = 'foo'
    a = _Alpha(x)
    b = _Alpha(y)
    result = a.__le__(b)
    assert type(result) is bool
    assert result == expected_result
    x = 'foo'
    expected_result = True
    y = 'foo'
    a = _Alpha(x)
    b = _Alpha(y)
    result = b.__le__(a)
    assert type(result) is bool
    assert result == expected_result
    x = 'bar'
    expected_result = True
    y = 'foo'
    a = _Alpha(x)
    b = _Alpha(y)
    result = a.__le__(b)


# Generated at 2022-06-25 13:56:25.857862
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    print("Test Start test__Alpha___le__")
    str_0 = '\n    Test the _Alpha class __le__ method\n    '
    str_1 = '\n    Test the _Alpha class __le__ method\n    '
    str_2 = '\n    Test the _Alpha class __le__ method\n    '
    str_3 = '\n    Test the _Alpha class __le__ method\n    '
    str_4 = '\n    Test the _Alpha class __le__ method\n    '
    str_5 = '\n    Test the _Alpha class __le__ method\n    '
    str_6 = '\n    Test the _Alpha class __le__ method\n    '
    str_7 = '\n    Test the _Alpha class __le__ method\n    '
    str

# Generated at 2022-06-25 13:56:27.898992
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    str_0 = '\n    Test the _Alpha class __le__ method\n    '


# Generated at 2022-06-25 13:56:36.498719
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    str_0 = '\n    Test the SemanticVersion parse method\n    '
    # Test the SemanticVersion parse method
    str_1 = '0.0.0'
    obj_0 = '0.0.0'
    obj_1 = SemanticVersion(obj_0)
    obj_2 = obj_1
    obj_3 = SemanticVersion(obj_2)
    obj_4 = obj_3
    obj_5 = obj_4
    obj_6 = obj_5
    obj_7 = obj_6
    obj_8 = obj_7
    obj_9 = obj_8
    obj_10 = obj_9
    obj_11 = obj_10
    obj_12 = obj_11
    obj_13 = obj_12
    obj_14 = obj_13
    obj_15 = obj

# Generated at 2022-06-25 13:56:44.940838
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    case_0 = LooseVersion('1.10.3')
    case_0_vstring = '1.10.3'
    expected_result_0 = SemanticVersion(case_0_vstring)
    actual_result_0 = SemanticVersion.from_loose_version(case_0)
    assert actual_result_0 == expected_result_0, (fake_todo_msg(actual_result_0, expected_result_0))

    case_1 = LooseVersion('1.10.3-alpha')
    case_1_vstring = '1.10.3-alpha'
    expected_result_1 = SemanticVersion(case_1_vstring)

# Generated at 2022-06-25 13:56:49.764851
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    str_1 = '1'
    str_2 = '2'
    str_3 = '3'
    obj_4 = LooseVersion(str_3)
    obj_5 = SemanticVersion.from_loose_version(obj_4)
    obj_6 = SemanticVersion('3')
    assert (obj_5 == obj_6)


# Generated at 2022-06-25 13:56:53.347481
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    str_0 = '\n    Test the _Alpha class __le__ method\n    '
    str_1 = '12345'
    str_2 = '12345'
    str_3 = '1234'
    str_4 = '12345'
    str_5 = '123456'
    str_6 = '12345'
    str_7 = '12346'
    str_8 = '12345'
    str_9 = '12346'
    str_10 = '12345'
    str_11 = '12346'
    assert _Alpha(str_1).__le__(_Alpha(str_2)) == True


# Generated at 2022-06-25 13:57:00.989442
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    from distutils.version import StrictVersion
    from ansible.module_utils.six import u
    from ansible.module_utils.distribution.version import SemanticVersion

    assert str(SemanticVersion.from_loose_version(LooseVersion('1.0.0'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.0'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.0b1'))) == '1.0.0-b1'

# Generated at 2022-06-25 13:57:02.568700
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    str_0 = '\n    Test that a LooseVersion cannot be used.\n    '


# Generated at 2022-06-25 13:57:10.944436
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    #  The from_loose_version method is designed to take a LooseVersion
    # and attempt to construct a SemanticVersion from it. The
    # calculation isn't perfect, but it allows for simple version
    # comparisions without requiring users to supply a strict semver
    # string.
    #  This test is designed to ensure that from_loose_version can
    # convert all of the various format options that LooseVersion
    # supports, but it is not exhaustive.
    str_0 = '\n    Test the from_loose_version class method of the SemanticVersion class\n    '
    str_1 = 'a'
    str_2 = 'b'
    str_3 = 'c'
    str_4 = 'a.b'
    str_5 = '1'
    str_6 = '2'
    str

# Generated at 2022-06-25 13:57:19.076566
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # output = SemanticVersion.from_loose_version(input)
    assert False # TODO: implement your test here


# Generated at 2022-06-25 13:57:23.666995
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests that a LooseVersion with a base version and no metadata creates
    # a SemanticVersion with the same base version and no metadata

    version = '1.2.3'
    loose = LooseVersion(version)
    res = SemanticVersion.from_loose_version(loose)
    assert res.buildmetadata == ()
    assert res.prerelease == ()


# Generated at 2022-06-25 13:57:28.514949
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create an instance of a class
    obj = SemanticVersion()
    # Assert that an error is raised for the following call
    # SemanticVersion.from_loose_version(LooseVersion('1,2,3'))
    #
    # Call the method
    # SemanticVersion.from_loose_version(loose_version)
    #
    # Verify the results


# Generated at 2022-06-25 13:57:36.987891
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Invalid type
    # Try to pass a string, should raise a value error
    try:
        instance_0 = SemanticVersion.from_loose_version('0.0.0')
        assert False
    except ((AssertionError, Exception)):
        pass
    else:
        assert False
    # Pass a non loose version, should raise a value error
    try:
        instance_0 = SemanticVersion.from_loose_version('0.0.0')
        assert False
    except ((AssertionError, Exception)):
        pass
    else:
        assert False
    # Negative test
    try:
        instance_0 = SemanticVersion.from_loose_version(0.0)
        assert False
    except ((AssertionError, Exception)):
        pass
    else:
        assert False
   

# Generated at 2022-06-25 13:57:45.244709
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    from ansible.module_utils.six.moves.urllib.parse \
        import \
            urlparse

    p = urlparse('http://github.com/ansible/ansible')
    lv = LooseVersion(p.path.lstrip('/'))

    print("Testing method from_loose_version of class SemanticVersion")

    sv = SemanticVersion.from_loose_version(lv)

    print("inspection: %r" % sv)
    assert sv.core == (2, 9, 12)
    assert sv.is_prerelease is False
    assert sv.is_stable is False

    # Expected failure
    print("Raising expected failure due to input argument of wrong type")
    # Failure: Exception: ValueError("invalid semantic version '2.9'") raised
    sv = SemanticVersion

# Generated at 2022-06-25 13:57:47.358635
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Test Case: 0
    #
    # Passed in: '\n    Test the _Alpha class __le__ method\n    '
    #
    # Returned: None
    #
    # Returned: None

    pass



# Generated at 2022-06-25 13:57:55.448002
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils.six import PY2
    from ansible.module_utils.six.moves.builtins import str
    str_0 = '\n    Test the _Alpha class __le__ method\n    '
    class_0 = SemanticVersion
    str_1 = '0.0.0'
    var_0 = LooseVersion(str_1)
    var_1 = class_0.from_loose_version(var_0)
    str_2 = '0.0.1-alpha.1'
    var_2 = LooseVersion(str_2)
    var_3 = class_0.from_loose_version(var_2)

# Generated at 2022-06-25 13:58:03.156939
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    loose_version = LooseVersion('0.0.1-b1')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version == '0.0.1-b1'
    loose_version = LooseVersion('0.0.1')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version == '0.0.1'
    loose_version = LooseVersion('0.0.1+b1')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version == '0.0.1+b1'
    loose_version = LooseVersion('0.0.1-b1.b2')
    version = SemanticVersion.from_lo

# Generated at 2022-06-25 13:58:09.620467
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # It should raise an exception if the provided arg is not a LooseVersion
    v = '1.2.3'
    try:
        s = SemanticVersion.from_loose_version(v)
        raise Exception('You should see this because of an error')
    except ValueError:
        pass  # expected
    except Exception as e:
        raise Exception('You should not see this because we are expecting a ValueError')

    # It should raise an exception if the LooseVersion has non integer values
    v = LooseVersion('1.2.3.hello')
    try:
        s = SemanticVersion.from_loose_version(v)
        raise Exception('You should see this because of an error')
    except ValueError:
        pass  # expected

# Generated at 2022-06-25 13:58:12.631178
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    expected = SemanticVersion('1.0.4-rc1+25')
    actual = SemanticVersion.from_loose_version(LooseVersion('1.0.4-rc1+25'))
    assert actual == expected


# Generated at 2022-06-25 13:58:24.903820
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.2a')
    semantic_version_0 = SemanticVersion.from_loose_version(loose_version_0)

    assert semantic_version_0.major == 1
    assert semantic_version_0.minor == 2
    assert semantic_version_0.patch == 0
    assert semantic_version_0.core == (1, 2, 0)
    assert semantic_version_0.prerelease == ('a',)
    assert semantic_version_0.buildmetadata == ()
    assert isinstance(semantic_version_0.prerelease[0], _Alpha)
    assert not semantic_version_0.is_prerelease
    assert semantic_version_0.is_stable

    loose_version_1 = LooseVersion('1.2-alpha')

# Generated at 2022-06-25 13:58:33.978149
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-1.alpha')) == SemanticVersion('1.2.3-1.alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.metadata')) == SemanticVersion('1.2.3+build.metadata')

# Generated at 2022-06-25 13:58:42.918816
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion
    from ansible.module_utils.compat.version import LooseVersion

# Generated at 2022-06-25 13:58:46.136048
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.0.1')
    semantic_version = semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '0.0.1', 'Failed to create SemanticVersion from LooseVersion'



# Generated at 2022-06-25 13:58:49.005667
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('0.3'))
    assert semantic_version_0.major == 0
    assert semantic_version_0.minor == 3
    assert semantic_version_0.patch == 0
    assert semantic_version_0.prerelease == ()
    assert semantic_version_0.buildmetadata == ()


# Generated at 2022-06-25 13:58:53.808354
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    with pytest.raises(ValueError):
        version = SemanticVersion.from_loose_version('0.1.1')
    assert version.major == 0
    assert version.minor == 1
    assert version.patch == 1

    with pytest.raises(ValueError):
        version = SemanticVersion.from_loose_version('1.0.1a1')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 1


# Generated at 2022-06-25 13:59:00.564075
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Testing case 1 of method "from_loose_version"
    loose_version = LooseVersion("2.0.0")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    if semantic_version is None:
        raise AssertionError("expected semantic_version to be not None")
    if semantic_version.vstring != "2.0.0":
        raise AssertionError("expected semantic_version.vstring to be '2.0.0', got '%s'" % semantic_version.vstring)
    if semantic_version.major != 2:
        raise AssertionError("expected semantic_version.major to be 2, got '%s'" % semantic_version.major)

# Generated at 2022-06-25 13:59:10.225153
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test valid semver strings
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build')) == SemanticVersion('1.2.3-alpha.1+build')

# Generated at 2022-06-25 13:59:17.644002
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    loose_version_0 = LooseVersion("0.0.0")
    assert SemanticVersion.from_loose_version(loose_version_0) == semantic_version_0
    string_0 = "0.0.0"
    assert SemanticVersion.from_loose_version(string_0) == semantic_version_0
    string_0 = "1.2.3"
    assert SemanticVersion.from_loose_version(string_0) == loose_version_0
    list_0 = []
    assert SemanticVersion.from_loose_version(list_0) == semantic_version_0
    list_0 = [0, 1, 2, 3]
    assert SemanticVersion.from_loose_version(list_0) == loose_version_

# Generated at 2022-06-25 13:59:26.199114
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    semantic_version_1 = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version_1.major == 1
    assert semantic_version_1.minor == 2
    assert semantic_version_1.patch == 3
    assert semantic_version_1.prerelease == ()
    assert semantic_version_1.buildmetadata == ()
    assert semantic_version_1 == semantic_version_1
    assert semantic_version_1 != '1.2.3'
    assert semantic_version_1 != '1.2'
    assert semantic_version_1 != 1.2
    assert semantic_version_1 == SemanticVersion('1.2.3')
    assert semantic_version_1 != SemanticVersion('1.2')
    assert semantic_

# Generated at 2022-06-25 13:59:38.049528
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Assert that the following version is parsed as expected

    loose_version = LooseVersion("1.2.3")
    expected_semantic_version = "1.2.3"
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert text_type(semantic_version) == expected_semantic_version

    loose_version = LooseVersion("1.2")
    expected_semantic_version = "1.2.0"
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert text_type(semantic_version) == expected_semantic_version

    loose_version = LooseVersion("1")
    expected_semantic_version = "1.0.0"
    semantic_version = SemanticVersion.from_loose_

# Generated at 2022-06-25 13:59:40.677638
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version(LooseVersion('2.2.0'))

    assert_semantic_version(version, 2, 2, 0)


# Generated at 2022-06-25 13:59:49.728685
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # python_version_tuple = sys.version_info[:2]

    # if python_version_tuple[0] == 3 and python_version_tuple[1] < 7:
    #     pytest.xfail('Version 1.0.0 not available on python < 3.7')

    version_0 = LooseVersion('1.0.0')
    result = SemanticVersion.from_loose_version(version_0)
    assert result == SemanticVersion('1.0.0')

    version_1 = LooseVersion('1.0.0')
    result = SemanticVersion.from_loose_version(version_1)
    assert result == SemanticVersion('1.0.0')

    version_2 = LooseVersion('1.0.0')
    result = SemanticVersion.from_loose

# Generated at 2022-06-25 13:59:55.900228
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a valid LooseVersion object
    expected_version = SemanticVersion('1.2.3')
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert v == expected_version

    # Test with a valid LooseVersion object with pre-release information
    expected_version = SemanticVersion('1.2.3-rc.4')
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3rc4'))
    assert v == expected_version

    # Test with a valid LooseVersion object with build-metadata information
    expected_version = SemanticVersion('1.2.3+build.4')
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3b4'))

# Generated at 2022-06-25 14:00:00.375967
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with both str and unicode
    for txt in [
        '1.2.3-4-alpha+build.metadata.0',
        u'1.2.3-4-alpha+build.metadata.0',
    ]:
        loose_version = LooseVersion(txt)
        expected = SemanticVersion(txt)
        assert SemanticVersion.from_loose_version(loose_version) == expected


# Generated at 2022-06-25 14:00:03.752219
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.3+3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == SemanticVersion('1.3.0+3')


# Generated at 2022-06-25 14:00:12.025549
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(
        LooseVersion('2')
    ) == SemanticVersion('2.0.0')

    assert SemanticVersion.from_loose_version(
        LooseVersion('1.2')
    ) == SemanticVersion('1.2.0')

    assert SemanticVersion.from_loose_version(
        LooseVersion('1.2.3')
    ) == SemanticVersion('1.2.3')

    assert SemanticVersion.from_loose_version(
        LooseVersion('1.2.3.4')
    ) == SemanticVersion('1.2.3')

    assert SemanticVersion.from_loose_version(
        LooseVersion('1.2.3-alpha')
    ) == SemanticVersion('1.2.3-alpha')

# Generated at 2022-06-25 14:00:17.700398
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    #
    # Casting a LooseVersion to a SemanticVersion
    #

    # stable version
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')

    # non-stable version
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    # non-stable version
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha1')) == SemanticVersion('1.0.0-alpha1')

    # pre-release version

# Generated at 2022-06-25 14:00:27.304606
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Testing for inputs of type ``LooseVersion``
    for test_input in ((LooseVersion('0.1.1', '')), (LooseVersion('1.2.3', '')), (LooseVersion('0.2.3', '')), (LooseVersion('0.1.4', '')), (LooseVersion('0.1.3', '')), (LooseVersion('1.0.0-4', '')), (LooseVersion('1.0.0-4-foo', '')), (LooseVersion('1.0.0', ''))):
        try:
            SemanticVersion.from_loose_version(test_input)
        except ValueError:
            raise AssertionError('\n\nExpected: No exception is thrown\nActual: exception is thrown')
        else:
            pass

    # Testing for inputs of

# Generated at 2022-06-25 14:00:35.993244
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test casting a loose version to a semantic version

    This test case may be removed if/when backwards compatibility can be broken.
    """
    assert SemanticVersion.from_loose_version(LooseVersion('0.1')) == SemanticVersion('0.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2')) == SemanticVersion('0.1.2')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2.3')) == SemanticVersion('0.1.2')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2.3.4')) == SemanticVersion('0.1.2')

# Generated at 2022-06-25 14:00:48.235370
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('10.0')
    assert (SemanticVersion.from_loose_version(loose_version) == SemanticVersion('10.0.0'))



# Generated at 2022-06-25 14:00:54.296601
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('  1.2.3 ')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.2+dev')) == SemanticVersion('1.2.2+dev')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')


# Generated at 2022-06-25 14:01:02.411204
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test bad input
    try:
        test = SemanticVersion.from_loose_version(1)
        assert False
    except ValueError:
        pass

    # Test good input
    test = SemanticVersion.from_loose_version(LooseVersion('2.1.8'))
    assert test.major == 2
    assert test.minor == 1
    assert test.patch == 8
    assert not test.prerelease
    assert not test.buildmetadata

    test = SemanticVersion.from_loose_version(LooseVersion('2.1.8-1-2-3'))
    assert test.major == 2
    assert test.minor == 1
    assert test.patch == 8
    assert test.prerelease == (1, 2, 3,)
    assert not test.buildmetadata

    test = SemanticVersion

# Generated at 2022-06-25 14:01:11.276318
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.2.3")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == "1.2.3", \
        "version is %s, expected %s" % (semantic_version, "1.2.3")
    assert semantic_version.major == 1, \
        "major is %s, expected %s" % (semantic_version.major, 1)
    assert semantic_version.minor == 2, \
        "minor is %s, expected %s" % (semantic_version.minor, 2)
    assert semantic_version.patch == 3, \
        "patch is %s, expected %s" % (semantic_version.patch, 3)

# Generated at 2022-06-25 14:01:13.470315
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.0")).vstring == "1.2.0"


# Generated at 2022-06-25 14:01:22.223817
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:01:30.335199
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        SemanticVersion.from_loose_version(1)
        assert False, "ValueError expected"
    except ValueError:
        pass
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert semantic_version_1.__dict__ == {'major': 1, 'minor': 2, 'patch': 3, 'prerelease': (), 'buildmetadata': (), 'vstring': '1.2.3'}
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha1'))

# Generated at 2022-06-25 14:01:34.545540
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = SemanticVersion.from_loose_version(LooseVersion('0.1.2'))
    assert loose_version_0.major == 0
    assert loose_version_0.minor == 1
    assert loose_version_0.patch == 2
    assert loose_version_0.prerelease == ()
    assert loose_version_0.buildmetadata == ()

    loose_version_1 = SemanticVersion.from_loose_version(LooseVersion('0.1.2.3'))
    assert loose_version_1.major == 0
    assert loose_version_1.minor == 1
    assert loose_version_1.patch == 2
    assert loose_version_1.prerelease == ()
    assert loose_version_1.buildmetadata == ()


# Generated at 2022-06-25 14:01:40.626027
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('4.2.1')) == SemanticVersion('4.2.1')
    assert SemanticVersion.from_loose_version(LooseVersion('4.2.1.1')) == SemanticVersion('4.2.1')
    assert SemanticVersion.from_loose_version(LooseVersion('4.2.1.1.1')) == SemanticVersion('4.2.1')
    assert SemanticVersion.from_loose_version(LooseVersion('4.2.1.1.1.1')) == SemanticVersion('4.2.1')

# Generated at 2022-06-25 14:01:47.021207
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test SemanticVersion.from_loose_version"""

    loose_version = LooseVersion('1.2.3')
    result = SemanticVersion.from_loose_version(loose_version)
    assert result.core == (1, 2, 3)
    assert not any((result.prerelease, result.buildmetadata))

    loose_version = LooseVersion('1.2.3-alfa.5.beta-1')
    result = SemanticVersion.from_loose_version(loose_version)
    assert result.core == (1, 2, 3)
    assert result.prerelease == (_Alpha('alfa'), _Numeric(5), _Alpha('beta'), _Numeric(1))
    assert not result.buildmetadata


# Generated at 2022-06-25 14:02:09.747048
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version = SemanticVersion()
    loose_version = LooseVersion('1.2.3')
    assert semantic_version.from_loose_version(loose_version) == SemanticVersion('1.2.3')



# Generated at 2022-06-25 14:02:14.306371
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Input parameters
    loose_version = LooseVersion('1.0.0')

    # Call to tested method
    result = SemanticVersion.from_loose_version(loose_version)

    # Optional attributes for method
    assert result.major == 1
    assert result.minor == 0
    assert result.patch == 0
    assert result.prerelease == ()
    assert result.buildmetadata == ()


# Generated at 2022-06-25 14:02:17.451428
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible_collections.sivel.version

    expected_result = SemanticVersion('1.2.5+foobar')

    loose_version = text_type(ansible_collections.sivel.version.__version__)
    assert SemanticVersion.from_loose_version(LooseVersion(loose_version)) == expected_result


# Generated at 2022-06-25 14:02:21.088551
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    # Create input parameters for function
    loose_version = LooseVersion('1.0.0')

    # Call method directly
    instance = SemanticVersion.from_loose_version(loose_version)

    # Check returned data
    assert instance.vstring == '1.0.0'



# Generated at 2022-06-25 14:02:22.665597
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))


# Generated at 2022-06-25 14:02:28.388023
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Construct a version from a LooseVersion
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert isinstance(version, SemanticVersion)

    # Test that they compare the same
    assert version == LooseVersion('1.2.3')

    # Test that non LooseVersion can't be converted
    try:
        SemanticVersion.from_loose_version('1.2.3')

        raise AssertionError("Non LooseVersion passed in")
    except ValueError:
        pass

    # Test that a non vstring LooseVersion can't be converted
    try:
        SemanticVersion.from_loose_version(LooseVersion())

        raise AssertionError("Non LooseVersion passed in")
    except ValueError:
        pass

    # Test that extra

# Generated at 2022-06-25 14:02:37.653215
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.3.0')
    sver = SemanticVersion.from_loose_version(loose_version)
    assert sver.vstring == '0.3.0'

    loose_version = LooseVersion('0.3.0+dev.1')
    sver = SemanticVersion.from_loose_version(loose_version)
    assert sver.vstring == '0.3.0+dev.1'

    loose_version = LooseVersion('0.3.0-dev.1')
    sver = SemanticVersion.from_loose_version(loose_version)
    assert sver.vstring == '0.3.0-dev.1'

    loose_version = LooseVersion('0.3.0-1.dev1')
    sver

# Generated at 2022-06-25 14:02:40.328178
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
  # From test_utils.py
  assert SemanticVersion.from_loose_version(LooseVersion("3.3.0")) == SemanticVersion("3.3.0")


# Generated at 2022-06-25 14:02:42.977795
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2')
    assert SemanticVersion.from_loose_version(loose_version) == '1.2.0'

# Generated at 2022-06-25 14:02:51.627702
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test behavior where LooseVersion is a bad type
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(1)

    # Test behavior where LooseVersion raises AttributeError
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(object())

    # Test behavior where LooseVersion contains non integer values
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(LooseVersion('1.2.3.abc'))

    # Test behavior where LooseVersion contains non integer values
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(LooseVersion('1.2.3-abc'))

    # Test behavior where LooseVersion contains non integer values

# Generated at 2022-06-25 14:03:42.175066
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-25 14:03:50.036857
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    semantic_version_0 = LooseVersion("1.4.6.4")

    semantic_version_1 = SemanticVersion.from_loose_version(semantic_version_0)
    assert semantic_version_1.__class__.__name__ == 'SemanticVersion'
    assert semantic_version_1.major == 1
    assert semantic_version_1.minor == 4
    assert semantic_version_1.patch == 6
    assert semantic_version_1.prerelease == ()
    assert semantic_version_1.buildmetadata == ()

    semantic_version_2 = LooseVersion("1.4.6.4.5")

    semantic_version_3 = SemanticVersion.from_loose_version(semantic_version_2)

# Generated at 2022-06-25 14:03:55.551400
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils.six.moves import urllib
    url = urlparse('http://example.com/v2.2.3/foo.bar')
    version = urllib.request.urlopen(url).getheader('X-Version')
    semantic_version = SemanticVersion.from_loose_version(LooseVersion(version))
    assert semantic_version._cmp('2.2.3') == 0
# End test


# Generated at 2022-06-25 14:03:59.864934
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test case 0
    # Expected result: SemanticVersion('1.2.3')
    test_case_0_loose_version = LooseVersion('1.2.3')
    test_case_0_expected = SemanticVersion('1.2.3')
    test_case_0_actual = SemanticVersion.from_loose_version(test_case_0_loose_version)
    assert test_case_0_actual == test_case_0_expected


# Generated at 2022-06-25 14:04:07.153729
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for LooseVersion
    loose_version = LooseVersion('2')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '2.0.0'

    # Test for LooseVersion with float
    loose_version = LooseVersion('2.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '2.0.0'

    # Test for LooseVersion with string
    loose_version = LooseVersion('2.0.0-alpha.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '2.0.0-alpha.1'

    # Test for

# Generated at 2022-06-25 14:04:14.221069
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that an error is raised when the passed in object is not
    # a LooseVersion object
    with raises(ValueError):
        SemanticVersion.from_loose_version(None)
    # Test that an error is raised when the passed in object is not
    # a LooseVersion object
    with raises(ValueError):
        SemanticVersion.from_loose_version(SemanticVersion())
    # Test that an error is not raised when the passed in object is
    # a LooseVersion object
    try:
        SemanticVersion.from_loose_version(LooseVersion())
    except ValueError:
        assert False, "SemanticVersion.from_loose_version should not raise ValueError when passed in LooseVersion()"
    # Test that an error is raised when the passed in object is not
    # a LooseVersion object

# Generated at 2022-06-25 14:04:20.328743
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that from_loose_version returns SemanticVersion object
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('1.2')), SemanticVersion)

    # Test that raise ValueError if arg is not a LooseVersion
    exc_raised = False
    try:
        SemanticVersion.from_loose_version(None)
    except ValueError:
        exc_raised = True
    assert exc_raised

# Generated at 2022-06-25 14:04:28.337523
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    class FakeLooseVersion(object):
        def __init__(self, version, vstring):
            self.version = version
            self.vstring = vstring

    sv = SemanticVersion.from_loose_version(FakeLooseVersion([1, 2], '1.2'))
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 0

    sv = SemanticVersion.from_loose_version(FakeLooseVersion([1, 2, 3], '1.2.3'))
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3

    sv = SemanticVersion.from_loose_version(FakeLooseVersion([1, 2, 3], '1.2.3-1'))
    assert sv.major == 1
   

# Generated at 2022-06-25 14:04:34.234451
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semantic_version_0 = SemanticVersion()
    loose_version_1 = LooseVersion('1.2.3')
    SemanticVersion.from_loose_version(loose_version_1)
    loose_version_2 = LooseVersion('1.2.3-4')
    SemanticVersion.from_loose_version(loose_version_2)
    loose_version_3 = LooseVersion('1.2.3-4.5.6')
    SemanticVersion.from_loose_version(loose_version_3)
    loose_version_4 = LooseVersion('1.2.3-4.5.6-7')
    SemanticVersion.from_loose_version(loose_version_4)

# Generated at 2022-06-25 14:04:39.551017
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    result = SemanticVersion.from_loose_version(LooseVersion('1.5.3'))
    assert result == SemanticVersion('1.5.3')
    result = SemanticVersion.from_loose_version(LooseVersion('1.5.3.dev1'))
    assert result == SemanticVersion('1.5.3-dev1')
    result = SemanticVersion.from_loose_version(LooseVersion('1.5.3.0'))
    assert result == SemanticVersion('1.5.3-0')
    result = SemanticVersion.from_loose_version(LooseVersion('1.5.3-dev4'))
    assert result == SemanticVersion('1.5.3-dev4')