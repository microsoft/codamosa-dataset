

# Generated at 2022-06-23 14:48:35.419710
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    s = SemanticVersion('1.0.0')
    assert repr(s) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-23 14:48:46.584292
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    a = SemanticVersion('1.0.0-alpha')
    b = SemanticVersion('1.0.0')
    assert a != b

    a = SemanticVersion('1.0.0-alpha')
    b = SemanticVersion('1.0.0-alpha')
    assert a == b

    a = SemanticVersion('1.0.0')
    b = SemanticVersion('1.0.0')
    assert a == b

    a = SemanticVersion('1.0.0-alpha')
    b = SemanticVersion('1.0.0-beta')
    assert a != b

    a = SemanticVersion('1.0.0-alpha.1')
    b = SemanticVersion('1.0.0-alpha.1')
    assert a == b


# Generated at 2022-06-23 14:48:49.013821
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n1 = _Numeric(0)
    assert n1 == 0
    n2 = _Numeric(1)
    assert n2 == 1


# Generated at 2022-06-23 14:48:54.221751
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.1")
    assert(v1.__ne__(v2) == True)
    assert(v1.__ne__("1.0.1") == True)
    assert(v1.__ne__("1.0.0") == False)


# Generated at 2022-06-23 14:48:56.144608
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.1')) == "SemanticVersion('0.0.1')"


# Generated at 2022-06-23 14:48:59.076804
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    n = _Numeric('3')
    assert(repr(n) == repr(3))
    n = _Numeric(None)
    assert(repr(n) == repr(0))


# Generated at 2022-06-23 14:49:08.138967
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Create the list of test case
    test_cases = []

    # Test case where a < b
    a = _Alpha("a")
    b = _Alpha("b")
    test_cases.append({"method": "__lt__", "a": a, "b": b, "result": True})

    # Test case where a > b
    a = _Alpha("b")
    b = _Alpha("a")
    test_cases.append({"method": "__lt__", "a": a, "b": b, "result": False})

    # Test case where a == b
    a = _Alpha("a")
    b = _Alpha("a")
    test_cases.append({"method": "__lt__", "a": a, "b": b, "result": False})

    # Test case where a and b are

# Generated at 2022-06-23 14:49:09.988248
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('alpha') >= 'alpha'
    assert _Alpha('alpha') >= _Alpha('alpha')


# Generated at 2022-06-23 14:49:13.395270
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(0) == 0
    assert not _Numeric(0) == 1
    assert not _Numeric(1) == 0
    assert _Numeric(1) == 1


# Generated at 2022-06-23 14:49:16.026443
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    vstring = '1.2.3-alpha.2+build1'
    assert SemanticVersion(vstring).__repr__() == 'SemanticVersion(\'1.2.3-alpha.2+build1\')'



# Generated at 2022-06-23 14:49:23.975330
# Unit test for constructor of class _Numeric
def test__Numeric():
    import sys
    if sys.version_info[0] < 3:
        # The py26 and py27 versions of unittest do not support py35+ features
        raise ImportError("Only supported on python 3")

    try:
        from unittest import mock
    except ImportError:
        import mock

    # This type of testing is a bit odd but it allows us to test
    # the class _Numeric without actually using the SemanticVersion
    # class

    # Test to make sure that the class _Numeric can properly be initialized
    # with int and str and properly compare
    with mock.patch.object(_Numeric, '__init__', return_value=None) as mock_init:
        for value in (0, 1, 2, '0', '1', '2'):
            _Numeric(value)

# Generated at 2022-06-23 14:49:26.279615
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('2.1.1')) == "SemanticVersion('2.1.1')"


# Generated at 2022-06-23 14:49:34.545623
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < '1.0.1'
    assert SemanticVersion('1.0.0') < '1.1.0'
    assert SemanticVersion('1.0.0') < '2.0.0'
    assert SemanticVersion('1.0.0') < '1.0.0-1'
    assert not (SemanticVersion('1.0.0') < '1.0.0')
    assert not (SemanticVersion('1.0.0') < '0.9.9')
    assert not (SemanticVersion('1.0.0') < '1.0.0-0')


# Generated at 2022-06-23 14:49:38.041628
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') != _Numeric('2')
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') <= _Numeric('2')
    assert _Numeric('1') <= _Numeric('1')


# Generated at 2022-06-23 14:49:44.152298
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('15') <= _Alpha('15')
    assert _Alpha('15') <= '15'
    assert _Alpha('15') <= _Numeric('15')
    assert _Alpha('15') < '16'
    assert _Alpha('15') < _Numeric('16')
    assert _Alpha('15') < _Alpha('16')

    with raises(ValueError):
        _Alpha('16') < '15'
    with raises(ValueError):
        _Alpha('16') < _Numeric('15')


# Generated at 2022-06-23 14:49:45.505951
# Unit test for constructor of class _Numeric
def test__Numeric():
    _Numeric(3)


# Generated at 2022-06-23 14:49:53.667555
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    """
    This method tests for method __lt__ of class SemanticVersion
    """
    # To test __lt__() of class _Numeric we will create two objects of class _Numeric
    # one object will have value "5"
    # another object will have value "6"
    # We will check if first object is less than second object
    # Which should be true
    # Then we will check if first object is less than or equal to second object
    # Which should be true
    # Then we will check if first object is greater than second object
    # Which should be false
    # Then we will check if first object is greater than or equal to second object
    # Which should be false

    numeric_object_1 = _Numeric("5")
    numeric_object_2 = _Numeric("6")

    assert numeric_object_1 < numeric_object

# Generated at 2022-06-23 14:50:00.774899
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert( _Numeric('1') < _Numeric('2') )
    assert( _Numeric('2') > _Numeric('1') )
    assert( _Numeric('1') < _Alpha('2') )
    assert( _Numeric('2') > _Alpha('1') )
    try:
        assert( _Numeric('1') < _Alpha('b') )
    except ValueError:
        pass
    try:
        assert( _Numeric('b') > _Alpha('1') )
    except ValueError:
        pass


# Generated at 2022-06-23 14:50:05.224344
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'a'
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != 1
    assert not (_Alpha('a') != 'a')
    assert not (_Numeric(1) != 1)



# Generated at 2022-06-23 14:50:13.577494
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    test_data = {
        '10': 10,
        '10.0': 10,
        '10.06': 10,
        '11': 11,
        '11.0': 11,
        '11.06': 11,
        'a': 'a',
        'alpha': 'alpha',
        'beta': 'beta',
        'gamma': 'gamma',
        'z1': 'z1',
        'z2': 'z2',
        'z3': 'z3',
        'zeta': 'zeta',
    }

# Generated at 2022-06-23 14:50:16.148356
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.0-alpha")

    assert v1 >= v2
    assert not (v2 >= v1)



# Generated at 2022-06-23 14:50:19.916777
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    _1 = _Numeric(1)
    _10 = _Numeric(10)
    _11 = _Numeric(11)
    _A = _Alpha('a')

    assert _1 < _11
    assert not _11 < _1
    assert _1 < _A
    assert not _A < _1



# Generated at 2022-06-23 14:50:29.652904
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha(1) <= _Alpha(2)
    assert _Alpha(1) <= '2'
    assert not _Alpha(2) <= _Alpha(1)
    assert not _Alpha(2) <= '1'
    assert _Alpha('1') <= _Alpha('2')
    assert _Alpha('1') <= '2'
    assert not _Alpha('2') <= _Alpha('1')
    assert not _Alpha('2') <= '1'
    assert _Alpha('1') <= _Alpha('1')
    assert _Alpha('1') <= '1'
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'b'

# Generated at 2022-06-23 14:50:35.382500
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1) 
    assert _Numeric(2) >= _Numeric(1) 
    assert _Numeric(1) >= _Numeric(2) is False
    assert _Numeric(1) >= _Alpha('a') 
    assert _Numeric(1) >= _Alpha('1') 
    assert _Numeric(1) >= _Alpha('2') is False
    assert _Numeric(1) >= 1 
    assert _Numeric(2) >= 1 
    assert _Numeric(1) >= 2 is False


# Generated at 2022-06-23 14:50:38.418886
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    assert a.specifier == 'a'
    assert text_type(a) == 'a'
    assert repr(a) == "'a'"



# Generated at 2022-06-23 14:50:47.114379
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha1 = _Alpha('alpha1')
    alpha2 = _Alpha('alpha2')
    numeric1 = _Numeric(1)

    assert alpha1 < alpha2
    assert not (alpha1 < numeric1)
    assert alpha2 > numeric1

    assert alpha1 <= alpha2
    assert not (alpha1 <= numeric1)
    assert alpha2 >= numeric1

    assert not (alpha1 == alpha2)
    assert alpha1 != alpha2
    assert not (alpha1 == numeric1)
    assert alpha1 != numeric1
    assert not (alpha2 == numeric1)
    assert alpha2 != numeric1



# Generated at 2022-06-23 14:50:50.692068
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1.0.0') >= _Alpha('1.0.0')
    assert _Alpha('1.0.0') >= _Numeric('1.0.0')
    assert not _Alpha('1.0.0') >= _Alpha('2.0.0')


# Generated at 2022-06-23 14:50:54.274292
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= _Numeric('a')

    assert not _Alpha('a') >= 'b'
    assert not _Alpha('a') >= _Alpha('b')
    assert not _Alpha('a') >= _Numeric('b')

    assert not _Alpha('b') >= 'a'
    assert not _Alpha('b') >= _Alpha('a')
    assert not _Alpha('b') >= _Numeric('a')



# Generated at 2022-06-23 14:50:56.236591
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('1') != '1.0'


# Generated at 2022-06-23 14:51:04.783202
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # equal
    assert not _Numeric(1) < _Numeric(1)
    # greater
    assert not _Numeric(1) < _Numeric(0)
    # lesser
    assert _Numeric(0) < _Numeric(1)
    # equal
    assert not _Numeric(1) < 1
    # greater
    assert not _Numeric(1) < 0
    # lesser
    assert _Numeric(0) < 1
    # wrong type
    try:
        _Numeric(0) < {}
        assert False
    except ValueError:
        pass



# Generated at 2022-06-23 14:51:08.275913
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(1) >= _Numeric(1)


# Generated at 2022-06-23 14:51:12.631395
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    # Test 1
    test_obj = _Numeric(5)
    assert test_obj == _Numeric(5)

    # Test 2
    assert test_obj != _Numeric(6)

    # Test 3
    assert test_obj != _Alpha('5')

    # Test 4
    assert test_obj != 5



# Generated at 2022-06-23 14:51:14.660958
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    s = SemanticVersion('1.0.0')
    assert s != '1.0.0'



# Generated at 2022-06-23 14:51:18.627381
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') == 1
    assert _Numeric('1') == '1'
    assert _Numeric('1') != _Numeric('2')
    assert _Numeric('1') != 2
    assert _Numeric('1') != '2'


# Generated at 2022-06-23 14:51:22.743759
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    ver = SemanticVersion('1.2.3')
    assert ver >= '1.2.3'
    assert not ver >= '1.2.4'


# Generated at 2022-06-23 14:51:32.455461
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    s = SemanticVersion("1.0.0")
    assert s.core == (1, 0, 0)
    assert s.major == 1
    assert s.minor == 0
    assert s.patch == 0
    assert s.prerelease == ()

    s = SemanticVersion("1.0.0-beta.1")
    assert s.core == (1, 0, 0)
    assert s.major == 1
    assert s.minor == 0
    assert s.patch == 0
    assert s.prerelease == (_Numeric('beta'), _Numeric('1'))

    s = SemanticVersion("1.0.0-alpha.beta.1")
    assert s.core == (1, 0, 0)
    assert s.major == 1
    assert s.minor == 0
    assert s.patch == 0


# Generated at 2022-06-23 14:51:39.858631
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('alpha').specifier == 'alpha'
    assert _Alpha('1').specifier == '1'

    assert _Alpha('alpha') == _Alpha('alpha')
    assert _Alpha('1') == _Alpha('1')
    assert _Alpha('alpha') != _Alpha('1')
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('1') == '1'
    assert _Alpha('alpha') != '1'

    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') < 'beta'
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('2') > _Alpha('1')
    assert _Alpha('1') < 2
    assert _Alpha('2') > 1
    assert _Alpha('2') > _Numeric('1')


# Generated at 2022-06-23 14:51:44.043364
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Alpha("1")
    assert(a == 1)
    assert(a == _Numeric(1))
    assert(a != 1.0)
    assert(a != 2)
    assert(a != b)
    assert(a != c)


# Generated at 2022-06-23 14:51:54.928147
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    sv = SemanticVersion("1.0.0")
    assert sv >= "0.0.1"
    assert sv >= "0.0.0"
    assert sv >= sv
    assert not sv >= "1.0.1"
    assert not sv >= "1.1.0"
    assert not sv >= "2.0.0"

    sv = SemanticVersion("1.1.1")
    assert sv >= "0.0.1"
    assert sv >= "0.1.1"
    assert sv >= "1.1.1"
    assert sv >= "0.0.0"
    assert not sv >= "1.1.2"
    assert not sv >= "1.2.1"
    assert not sv >= "2.0.0"


# Generated at 2022-06-23 14:51:58.715133
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') <= _Numeric('2')
    assert not (_Numeric('1') > _Numeric('2'))
    assert not (_Numeric('1') >= _Numeric('2'))



# Generated at 2022-06-23 14:52:03.331014
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    alpha1 = _Alpha("alpha")
    alpha2 = _Alpha("beta")
    alpha3 = _Alpha("gamma")

    assert alpha2 >= alpha1
    assert alpha1 < alpha3
    assert alpha3 >= alpha3
    assert alpha3 > alpha2
    assert alpha2 > alpha1
    assert alpha1 <= alpha1
    assert alpha1 <= alpha2
    assert alpha2 <= alpha3


# Generated at 2022-06-23 14:52:06.829424
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    obj = _Numeric(5)
    obj2 = _Numeric(6)
    assert obj.__gt__(obj2) is False
    assert obj2.__gt__(obj) is True


# Generated at 2022-06-23 14:52:08.477572
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha('test') == _Alpha('test')


# Generated at 2022-06-23 14:52:20.197979
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert (_Numeric(1).__gt__(_Numeric(1))) == False
    assert (_Numeric(1).__gt__(_Numeric(2))) == False
    assert (_Numeric(2).__gt__(_Numeric(1))) == True
    assert (_Numeric(1).__gt__(_Numeric('1'))) == False
    assert (_Numeric(1).__gt__(_Numeric('2'))) == False
    assert (_Numeric(2).__gt__(_Numeric('1'))) == True
    assert (_Numeric(1).__gt__(_Alpha('1'))) == True
    assert (_Numeric(1).__gt__(_Alpha('2'))) == False
    assert (_Numeric(2).__gt__(_Alpha('1'))) == True

# Generated at 2022-06-23 14:52:24.135636
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('1') > _Alpha('0')
    assert _Alpha('-') > _Alpha('.')
    assert _Alpha('1') > _Alpha('-')
    assert _Alpha('1') > _Alpha('a')
    assert _Alpha('a') < _Alpha('1')


# Generated at 2022-06-23 14:52:32.632762
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion()

    version.parse('1.2.3')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version.parse('1.2.3-alpha')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Alpha('alpha'),)
    assert version.buildmetadata == ()

    version.parse('1.2.3-alpha.1')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert version.buildmetadata == ()

    version.parse

# Generated at 2022-06-23 14:52:34.146953
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a = _Alpha('foo')
    b = _Alpha('foo')
    assert a == b
    assert b == a


# Generated at 2022-06-23 14:52:40.838578
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert eval("_Numeric('1') == _Numeric('1')") is True
    assert eval("_Numeric('1') == _Numeric('2')") is False
    assert eval("_Numeric('1') == 1") is True
    assert eval("_Numeric('1') == 2") is False
    assert eval("_Numeric('1') == _Alpha('1')") is False
    assert eval("_Numeric('1') == '1'") is False


# Generated at 2022-06-23 14:52:50.354578
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > 'b'
    assert _Alpha('b') <= 'b'
    assert _Alpha('b') < 'c'

    assert _Alpha('0') > '1'
    assert _Alpha('0') < '9'

    assert _Alpha('a1') < 'a2'
    assert _Alpha('a1') < 'a10'
    assert _Alpha('a1') < 'b1'
    assert _Alpha('a1') < 'b2'
    assert _Alpha('a1') < 'b10'
    assert _Alpha('b1') > 'a1'
    assert _Alpha('b1') > 'a2'
    assert _Alpha('b1') > 'a10'

    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('b') <= _Alpha('b')

# Generated at 2022-06-23 14:52:58.339224
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    version1 = SemanticVersion('1.2.3')
    version2 = SemanticVersion('1.2.3')
    version3 = SemanticVersion('1.2.3-beta')
    version4 = SemanticVersion('1.2.3+build')
    version5 = SemanticVersion('1.2.3-beta+build')
    version6 = SemanticVersion('1.2.4')
    version7 = SemanticVersion('2.0.0')
    version8 = SemanticVersion('1.3.3')
    version9 = SemanticVersion('0.2.3')

    assert (version1 >= version2)
    assert (version1 >= version3)
    assert (version1 >= version4)
    assert (version1 >= version5)
    assert (not version1 >= version6)

# Generated at 2022-06-23 14:53:07.909490
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    v2 = SemanticVersion.from_loose_version(LooseVersion('1.0.0-2.3.4.5-6'))
    v3 = SemanticVersion.from_loose_version(LooseVersion('1.0.0-2.3.4.5-alpha'))
    v4 = SemanticVersion.from_loose_version(LooseVersion('1.0.0-2.3.4.5-alpha+blah'))
    v5 = SemanticVersion.from_loose_version(LooseVersion('1.0.0-2.3.4.5-beta.1'))
   

# Generated at 2022-06-23 14:53:09.716751
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('2') >= _Numeric('2')
    assert not _Numeric('1') >= _Numeric('2')
    assert not _Numeric('1') >= _Numeric('a')


# Generated at 2022-06-23 14:53:16.258093
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion("0.0.0-alpha") < SemanticVersion("0.0.0-alpha.1")
    assert SemanticVersion("0.0.0-alpha.1") < SemanticVersion("0.0.0-alpha.beta")
    assert SemanticVersion("0.0.0-alpha.beta") < SemanticVersion("0.0.0-beta")
    assert SemanticVersion("0.0.0-beta") < SemanticVersion("0.0.0-beta.2")
    assert SemanticVersion("0.0.0-beta.2") < SemanticVersion("0.0.0-beta.11")
    assert SemanticVersion("0.0.0-beta.11") < SemanticVersion("0.0.0-rc.1")

# Generated at 2022-06-23 14:53:20.394048
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric("0") >= _Numeric("0")
    assert _Numeric("0") >= _Numeric("-1")
    assert _Numeric("0") >= _Numeric("1")
    assert _Numeric("0") >= 0
    assert _Numeric("0") >= -1
    assert _Numeric("0") >= 1



# Generated at 2022-06-23 14:53:31.880499
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    s = SemanticVersion('1.2.3-alpha.1+build.1')
    assert s.major == 1
    assert s.minor == 2
    assert s.patch == 3
    assert s.prerelease == (_Numeric('alpha'), _Numeric('1'))
    assert s.buildmetadata == (_Numeric('build'), _Numeric('1'))

    s = SemanticVersion('1.17.0')
    assert s.major == 1
    assert s.minor == 17
    assert s.patch == 0
    assert s.prerelease == ()
    assert s.buildmetadata == ()

    s = SemanticVersion('1.2.3-4.5.0-alpha.1+build.1')
    assert s.major == 1
    assert s.minor == 2
    assert s.patch == 3


# Generated at 2022-06-23 14:53:36.304079
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    _le = SemanticVersion('3.0.2').__le__
    assert _le(SemanticVersion('3.0.2'))
    assert _le(SemanticVersion('3.0.3'))
    assert not _le(SemanticVersion('3.0.1'))


# Generated at 2022-06-23 14:53:37.654790
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric("1") != "1"



# Generated at 2022-06-23 14:53:45.727091
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    version = LooseVersion('2.3.4')
    semver = SemanticVersion.from_loose_version(version)
    assert isinstance(semver, SemanticVersion)
    assert semver == version

    version = LooseVersion('2.3.4-9.8')
    semver = SemanticVersion.from_loose_version(version)
    assert isinstance(semver, SemanticVersion)
    assert semver == version

    version = LooseVersion('2.3.4-9.8.7')
    semver = SemanticVersion.from_loose_version(version)
    assert isinstance(semver, SemanticVersion)
    assert semver == version

    version = LooseVersion('2.3.4-x')


# Generated at 2022-06-23 14:53:50.300123
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    ver = SemanticVersion('1.0.0')
    ver2 = SemanticVersion('1.0.0-alpha')
    assert 0 == ver.__eq__(ver2)


# Generated at 2022-06-23 14:54:00.312828
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    alpharegex = re.compile(r'[A-z]+')
    for letter in 'abcdefghijklmnopqrstuvwxyz':
        l = _Alpha(letter)
        assert l.__eq__(letter) is True
        assert l.__eq__(letter.upper()) is True
        assert l.__eq__(_Alpha(letter)) is True
        assert l.__eq__(_Alpha(letter.upper())) is True
        for otherletter in 'abcdefghijklmnopqrstuvwxyz':
            if letter == otherletter:
                continue
            assert l.__eq__(otherletter) is False
            assert l.__eq__(otherletter.upper()) is False
            assert l.__eq__(_Alpha(otherletter)) is False

# Generated at 2022-06-23 14:54:01.508568
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'


# Generated at 2022-06-23 14:54:02.959037
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert not SemanticVersion("1.2.3") != '1.2.3'


# Generated at 2022-06-23 14:54:04.312789
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == '1'



# Generated at 2022-06-23 14:54:05.926107
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(123)) == "123"


# Generated at 2022-06-23 14:54:11.115531
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha('a')
    b = _Alpha('b')
    zero = _Alpha('0')
    one = _Alpha('1')
    n = _Numeric(1)
    assert a < b
    assert zero < one
    assert not a < zero
    assert not a < n


# Generated at 2022-06-23 14:54:20.069381
# Unit test for method __le__ of class _Alpha

# Generated at 2022-06-23 14:54:22.887962
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("a") >= _Alpha("a")
    assert _Alpha("b") >= _Alpha("a")
    assert not _Alpha("a") >= _Alpha("b")



# Generated at 2022-06-23 14:54:26.616240
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    """Test for method `__eq__` of class `SemanticVersion` """
    assert SemanticVersion("1.1.1") == "1.1.1"
    assert not SemanticVersion("1.1.1") == "1.1.2"
    assert not SemanticVersion("1.1.2") == "1.1.1"


# Generated at 2022-06-23 14:54:38.535696
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= 'a'
    assert not _Alpha('a') <= 'A'
    assert not _Alpha('a') <= _Alpha('A')
    assert not _Alpha('A') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('A') == _Alpha('A')
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == 'A'
    assert _Alpha('a') < 'b'
    assert not _Alpha('b') < 'a'
    assert _Alpha('a') < 'A'
    assert _Alpha('b') > 'a'
    assert _Alpha('A') < 'a'
    assert not _Alpha('a') > 'A'

# Generated at 2022-06-23 14:54:41.333875
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(2) <= _Numeric(3)
    assert _Numeric(3) <= _Numeric(3)
    assert not _Numeric(3) <= _Numeric(2)


# Generated at 2022-06-23 14:54:44.049373
# Unit test for constructor of class _Alpha
def test__Alpha():

    a = _Alpha("foo")
    assert a.specifier == "foo"
    assert type(a.specifier) == text_type  # noqa



# Generated at 2022-06-23 14:54:53.004565
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion() == SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') == SemanticVersion('0.0.0')
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0-alpha') == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha+build.metadata') == SemanticVersion('1.0.0-alpha+build.metadata')
    assert SemanticVersion('1.0.0+build.metadata') == SemanticVersion('1.0.0+build.metadata')
    assert SemanticVersion('1.0.0-alpha.beta') == SemanticVersion('1.0.0-alpha.beta')
    assert SemanticVersion

# Generated at 2022-06-23 14:54:59.755565
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    # Two _Numeric instances with same specifier
    r = _Numeric(1) == _Numeric(1)
    assert r is True

    # Two _Numeric instances with different specifier
    r = _Numeric(1) == _Numeric(2)
    assert r is False

    # _Numeric instance and integer
    r = _Numeric(1) == 1
    assert r is True

    # _Numeric instance and string
    r = _Numeric(1) == '1'
    assert r is False


# Generated at 2022-06-23 14:55:02.797985
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a = _Alpha('foo')
    assert a == 'foo'
    assert a != 'foo2'
    assert a != 1

# Generated at 2022-06-23 14:55:07.575330
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    obj = _Numeric(0)
    assert obj.__ne__(obj) == False
    assert obj.__ne__(1) == True
    assert obj.__ne__(True) == True
    assert obj.__ne__(None) == True
    assert obj.__ne__("") == True
    assert obj.__ne__("1") == True
    assert obj.__ne__(_Numeric(1)) == True



# Generated at 2022-06-23 14:55:12.595227
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    alpha = _Alpha('abc')
    assert alpha.__ne__(1234) == True
    assert alpha.__ne__('abc') == False
    assert alpha.__ne__('def') == True
    assert alpha.__ne__(None) == True



# Generated at 2022-06-23 14:55:21.344505
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    sem_vers = SemanticVersion('5.5.5')
    assert(sem_vers.__ge__('1.0.0'))
    assert(sem_vers.__ge__('5.0.0'))
    assert(sem_vers.__ge__('5.5.4'))
    assert(sem_vers.__ge__('5.5.5-beta'))
    assert(sem_vers.__ge__('5.5.5-beta.0'))
    assert(sem_vers.__ge__('5.5.5-0'))
    assert(sem_vers.__ge__('5.5.5-1'))
    assert(sem_vers.__ge__('5.5.5-0.beta'))

# Generated at 2022-06-23 14:55:26.528683
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert text_type('a') < _Alpha('b')
    assert not _Alpha('b') < _Alpha('a')
    assert not _Alpha('b') < 'a'
    assert not text_type('b') < _Alpha('a')

# Generated at 2022-06-23 14:55:29.463184
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    version_example_1 = SemanticVersion('1.0.0')
    version_example_2 = SemanticVersion('1.0.0')
    assert (version_example_1 == version_example_2)


# Generated at 2022-06-23 14:55:35.074110
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    v1 = _Numeric(1)
    v2 = _Numeric(2)
    v3 = _Numeric(3)
    assert (v1 == v1) == True
    assert (v1 == v2) == False
    assert (v2 == v1) == False
    assert (v2 == v2) == True
    assert (v2 == v3) == False
    assert (v3 == v2) == False
    assert (v3 == v3) == True


# Generated at 2022-06-23 14:55:37.363778
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    test = _Alpha("rc.1")
    assert test >= "beta.1", "test__Alpha___gt__: test failed"
    assert test > "beta.1", "test__Alpha___gt__: test failed"


# Generated at 2022-06-23 14:55:44.214897
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.0-1')
    assert SemanticVersion('1.0.0-1') < SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0-1') < SemanticVersion('1.0.0-2')
    assert SemanticVersion('1.0.0-z.1') < SemanticVersion('1.0.0-z.2')

    assert not SemanticVersion('1.0.0') < Sem

# Generated at 2022-06-23 14:55:53.743478
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > _Numeric(1)
    assert _Alpha('a.1') < _Numeric(1)
    assert _Alpha('a.1') > _Numeric(0)
    assert _Alpha('a.01') > _Numeric(1)
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a.b') > _Alpha('a.a')
    assert _Alpha('a.a') < _Alpha('a.b')
    assert _Alpha('a.0') > _Alpha('a')
    assert _Alpha('a') < _Alpha('a.0')


# Generated at 2022-06-23 14:56:03.325802
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0b') == SemanticVersion('1.0.0b')
    assert SemanticVersion('1.0.0-rc2') == SemanticVersion('1.0.0-rc2')
    assert SemanticVersion('1.0.0a') == SemanticVersion('1.0.0a')
    assert SemanticVersion('1.0.0a-rc2') == SemanticVersion('1.0.0a-rc2')

    assert not SemanticVersion('1.0.0') == SemanticVersion('1.0.1')
    assert not SemanticVersion('1.0.0') == SemanticVersion('1.1.0')

# Generated at 2022-06-23 14:56:11.285407
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < _Numeric(1.1)
    assert _Numeric(1) < _Alpha('2')
    assert _Numeric(1) < _Alpha('1.1')
    assert _Numeric(1) < 2
    assert _Numeric(1) < 1.1
    assert _Numeric(1) < '2'
    assert _Numeric(1) < '1.1'


# Generated at 2022-06-23 14:56:12.209113
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert _Numeric(1).__repr__() == '1'


# Generated at 2022-06-23 14:56:20.006861
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:56:31.470685
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
  version1 = SemanticVersion('1.0.0-alpha+001')
  version2 = SemanticVersion('1.0.0-alpha+002')
  version3 = SemanticVersion('1.0.0-beta+001')
  version4 = SemanticVersion('1.0.0-beta+002')
  assert (version1 == '1.0.0-alpha+001')
  assert (version1 == version1)
  assert (version1 != '1.0.0-alpha+002')
  assert (version1 != '1.0.0-beta+001')
  assert (version1 != '1.0.0-beta+002')
  assert (version1 != version2)
  assert (version1 != version3)
  assert (version1 != version4)


# Generated at 2022-06-23 14:56:36.863563
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    # Test 1
    n1 = _Numeric(2)
    n2 = _Numeric(2)
    actual = n1.__ne__(n2)
    expected = False
    assert actual == expected
    # Test 2
    n1 = _Numeric(2)
    n2 = _Numeric(5)
    actual = n1.__ne__(n2)
    expected = True
    assert actual == expected


# Generated at 2022-06-23 14:56:48.322861
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    if SemanticVersion('1.0.0') > SemanticVersion('1.0.0'):
        assert False, 'failed: 1.0.0 > 1.0.0'
    if SemanticVersion('1.0.1') > SemanticVersion('1.0.0'):
        pass
    else:
        assert False, 'failed: 1.0.1 > 1.0.0'
    if SemanticVersion('1.1.0') > SemanticVersion('1.0.0'):
        pass
    else:
        assert False, 'failed: 1.1.0 > 1.0.0'
    if SemanticVersion('2.0.0') > SemanticVersion('1.0.0'):
        pass

# Generated at 2022-06-23 14:56:50.836598
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('1') == _Alpha('1')
    assert _Alpha('1') == '1'
    assert _Alpha('1') != _Alpha('2')
    assert _Alpha('1') != '2'


# Generated at 2022-06-23 14:56:57.905141
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert not _Numeric(1) < _Numeric(1)
    assert _Numeric(1) < _Numeric(2)
    assert not _Numeric(2) < _Numeric(1)
    assert not _Numeric(1) < 1
    assert _Numeric(1) < 2
    assert not _Numeric(2) < 1


# Generated at 2022-06-23 14:56:59.884305
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    ver_a = SemanticVersion('0.0.1')
    ver_b = SemanticVersion('0.0.1-1')
    assert ver_a >= ver_b
    ver_a = SemanticVersion('0.0.1+2')
    ver_b = SemanticVersion('0.0.1-1')
    assert ver_a >= ver_b

# Generated at 2022-06-23 14:57:02.601602
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion("1.2.3-alpha.1+build.2")
    assert v.__repr__() == "SemanticVersion('1.2.3-alpha.1+build.2')"


# Generated at 2022-06-23 14:57:04.168120
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(2) > _Numeric(1)
    assert not (_Numeric(1) > _Numeric(2))



# Generated at 2022-06-23 14:57:06.153302
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion('0.0.1')
    v2 = SemanticVersion('0.0.1')
    assert v1.__ne__(v2) == False


# Generated at 2022-06-23 14:57:16.888697
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    import unittest
    class test(unittest.TestCase):
        def test_1(self):
            self.assertTrue(_Numeric(2)>_Numeric(1))
            self.assertTrue(_Numeric(2)>1)
            self.assertFalse(_Numeric(1)>_Numeric(2))
            self.assertFalse(_Numeric(1)>2)
            self.assertFalse(_Numeric(2)>_Alpha('a'))
        def test_2(self):
            self.assertTrue(_Numeric(2)>=_Numeric(1))
            self.assertTrue(_Numeric(2)>=1)
            self.assertFalse(_Numeric(1)>=_Numeric(2))
            self.assertFalse(_Numeric(1)>=2)

# Generated at 2022-06-23 14:57:25.713437
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert not _Alpha('alpha') >= _Alpha('alpha')
    assert _Alpha('alpha') >= _Alpha('a')
    assert not _Alpha('a') >= _Alpha('alpha')

    assert not _Alpha('alpha') >= _Numeric(0)
    assert not _Alpha('alpha') >= _Numeric(1)

    assert _Alpha('alpha') >= 'a'
    assert not _Alpha('a') >= 'alpha'
    assert not _Alpha('alpha') >= 'alpha'

    assert _Alpha('alpha') >= 0
    assert _Alpha('alpha') >= 1
    assert not _Alpha('alpha') >= 'alpha'



# Generated at 2022-06-23 14:57:27.027879
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('0') == _Numeric('0')


# Generated at 2022-06-23 14:57:29.081198
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') >= _Numeric(1)
    assert not _Alpha('a') >= 1


# Generated at 2022-06-23 14:57:38.728841
# Unit test for constructor of class _Alpha
def test__Alpha():
    v = _Alpha('abc')
    assert v.specifier == 'abc'
    assert repr(v) == repr('abc')
    assert v == _Alpha('abc')
    assert v == 'abc'
    assert v != _Alpha('abcd')
    assert not v != 'abc'
    assert v > _Alpha('abb')
    assert v > 'abb'
    assert v > _Alpha('abbc')
    assert v > 'abbc'
    assert v < _Alpha('abcd')
    assert v < 'abcd'
    assert v <= _Alpha('abc')
    assert v <= 'abc'
    assert v >= _Alpha('abc')
    assert v >= 'abc'


# Generated at 2022-06-23 14:57:47.362285
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    version1 = SemanticVersion("1.2.3")
    version2 = SemanticVersion("1.2.4")
    version3 = SemanticVersion("1.2.3")
    
    assert version1 > version2
    assert version1 >= version2
    assert version2 >= version1
    assert version1 <= version2
    assert version2 <= version1
    assert version1 < version2
    assert version1 != version2

    assert version1 == version3
    assert version1 <= version3
    assert version1 >= version3
    assert version3 <= version1
    assert version3 >= version1
    assert version1 != version2



# Generated at 2022-06-23 14:57:51.835444
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Positive test cases (examples) with list of integers
    assert _Numeric(2) < _Numeric(3)
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(1) < _Numeric(1)

    # Negative test cases (counterexamples)
    assert not (_Numeric(1) < _Numeric(0))
    assert not (_Numeric(3) < _Numeric(2))


# Generated at 2022-06-23 14:57:59.160798
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.1')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.1.1')
    assert SemanticVersion('1.1.1') > SemanticVersion('1.0.0')
    assert SemanticVersion('1.1.0') >= SemanticVersion('1.0.0')

# Generated at 2022-06-23 14:58:00.695261
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
	vstring = "1.2.3-alpha1"
	assert str(SemanticVersion(vstring)) == "SemanticVersion('" + vstring + "')"


# Generated at 2022-06-23 14:58:03.216448
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < 2
    assert not _Numeric(2) < 2
    assert not _Numeric(3) < 2


# Generated at 2022-06-23 14:58:13.253309
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion("1.2.3")
    v2 = SemanticVersion("1.2.3")
    assert v1 <= v2

    v1 = SemanticVersion("1.2.3")
    v2 = SemanticVersion("1.2.4")
    assert v1 <= v2

    v1 = SemanticVersion("1.2.3")
    v2 = SemanticVersion("1.3.3")
    assert v1 <= v2

    v1 = SemanticVersion("1.2.3")
    v2 = SemanticVersion("2.2.3")
    assert v1 <= v2

    # Less than, prerelease first
    # foo < foo.1
    v1 = SemanticVersion("1.2.3")

# Generated at 2022-06-23 14:58:19.247959
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('a')
    assert a.__ge__(text_type('a'))
    assert a.__ge__(_Alpha('a'))
    assert a.__ge__(_Alpha('b')) is False
    assert a.__ge__(0)
    assert a.__ge__(_Numeric('a')) is False



# Generated at 2022-06-23 14:58:28.533449
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # v1 > v2 if major(v1) > major(v2)
    v1 = SemanticVersion("2.25.1")
    v2 = SemanticVersion("1.25.1")
    assert v1 > v2

    # v1 > v2 if major(v1) == major(v2) and minor(v1) > minor(v2)
    v1 = SemanticVersion("1.26.1")
    v2 = SemanticVersion("1.25.1")
    assert v1 > v2

    # v1 > v2 if major(v1) == major(v2) and minor(v1) == minor(v2) and patch(v1) > patch(v2)
    v1 = SemanticVersion("1.25.2")

# Generated at 2022-06-23 14:58:36.819527
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-0alpha.1')) == SemanticVersion('1.2.3-0alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.0')) == SemanticVersion('1.2.3+build.0')