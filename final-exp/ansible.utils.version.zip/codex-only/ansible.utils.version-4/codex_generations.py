

# Generated at 2022-06-23 14:48:33.327022
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    version = SemanticVersion('1.2.3')
    assert version >= '1.2.3'
    assert version >= '1.2.2'
    assert version < '1.2.3-rc1'
    assert version < '1.2.3+build'
    assert version <= '1.2.3+build'
    assert version >= '1.2.3+build'
    assert version < '1.2.4'
    assert version < '2.0.0'


# Generated at 2022-06-23 14:48:40.299633
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(2) <= _Numeric(1)

    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 2
    assert _Numeric(2) <= 1

    assert 1 <= _Numeric(1)
    assert 2 <= _Numeric(1)
    assert 1 <= _Numeric(2)

    # unit test for method __gt__ of class _Numeric

# Generated at 2022-06-23 14:48:50.255500
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('test') == 'test'
    assert _Alpha('test') == _Alpha('test')
    assert _Alpha('test') != 'test2'
    # Python 2
    if hasattr(text_type, '__cmp__'):
        assert _Alpha('test') < 'test2'
        assert _Alpha('test') <= 'test2'
        assert _Alpha('test') <= 'test'
        assert _Alpha('test') == 'test'
        assert _Alpha('test') != 'test2'
        assert 'test' != _Alpha('test')
        assert _Alpha('test') > 'test1'
        assert _Alpha('test') >= 'test'
        assert _Alpha('test') >= 'test0'
    # Python 3
    else:
        assert _Alpha('test') < 'test2'
        assert _Alpha

# Generated at 2022-06-23 14:48:56.040428
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    test_string = '1.2.3-alpha.1.2+build.11.e0f985a'
    sv = SemanticVersion()
    sv.parse(test_string)
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == (_Numeric('alpha'), _Numeric('1'), _Numeric('2'))
    assert sv.buildmetadata == (_Numeric('build'), _Numeric('11'), _Alpha('e0f985a'))



# Generated at 2022-06-23 14:49:05.088166
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    tests = [
        ('1.2.3', ('1', '2', '3', (), ())),
        ('1.2.3-rc1', ('1', '2', '3', ('rc', '1'), ())),
        ('1.2.3-rc.1', ('1', '2', '3', ('rc', '1'), ())),
        ('1.2.3-rc.1.2.3+build.1', ('1', '2', '3', ('rc', '1', '2', '3'), ('build', '1'))),
        ('1.2.3+build.1', ('1', '2', '3', (), ('build', '1'))),
    ]

    for test in tests:
        version = SemanticVersion()
        version.parse(test[0])
        assert version.v

# Generated at 2022-06-23 14:49:12.395200
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # True
    for v in [
        SemanticVersion("0.0.0"),
        SemanticVersion("1.0.0"),
        SemanticVersion("1.0.0"),
        SemanticVersion("1.0.0"),
        SemanticVersion("1.0.0"),
        SemanticVersion("1.0.0"),
        SemanticVersion("1.1.1"),
        SemanticVersion("2.0.0"),
        SemanticVersion("2.0.0"),
        SemanticVersion("3.0.0")
    ]:
        assert v <= SemanticVersion("3.0.0")

    # False

# Generated at 2022-06-23 14:49:21.178328
# Unit test for method __ge__ of class SemanticVersion

# Generated at 2022-06-23 14:49:31.679347
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    from ansible.module_utils.compat.version import LooseVersion
    for vstring in ('0.8.6', '1.4.1', '1.2.8', '2.0.0-beta.11'):
        version = SemanticVersion(vstring)
        vstring2 = str(version)
        if version != vstring2:
            raise AssertionError("Versions differ: from '{0}' to '{1}'".format(vstring, vstring2))

    for vstring in ('0.10.5', '1.10.7', '1.2.12', '2.0.2-beta.11', '2.0.0-beta.9'):
        version = SemanticVersion(vstring)
        loose_version = LooseVersion(version)

# Generated at 2022-06-23 14:49:35.483713
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert ('a' == _Alpha('a'))
    assert _Alpha('b') != _Alpha('a')
    assert _Alpha('b') != 'a'
    assert ('a' != _Alpha('b'))


# Generated at 2022-06-23 14:49:38.052539
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    """test__Alpha___ge__
    """
    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') >= 'b'
    assert not _Alpha('a') >= 'A'


# Generated at 2022-06-23 14:49:39.252149
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('2') < _Numeric('10')


# Generated at 2022-06-23 14:49:41.955843
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # __lt__ return True when first argument is less than second argument
    a1 = _Alpha('a')
    a2 = _Alpha('b')
    assert a1 < a2


# Generated at 2022-06-23 14:49:43.226955
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(0) != _Numeric(1)


# Generated at 2022-06-23 14:49:52.451563
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    from ansible.module_utils._text import to_native
    from ansible.module_utils.common.version import SemanticVersion


# Generated at 2022-06-23 14:50:03.029610
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    test_string = "1.2.3"
    semver = SemanticVersion(test_string)
    assert(semver.major == 1)
    assert(semver.minor == 2)
    assert(semver.patch == 3)

    test_string = "1.2.3-alpha.1"
    semver = SemanticVersion(test_string)
    assert(semver.major == 1)
    assert(semver.minor == 2)
    assert(semver.patch == 3)
    assert(semver.prerelease == (_Numeric('alpha'), _Numeric('1')))

    test_string = "1.2.3+build.1"
    semver = SemanticVersion(test_string)
    assert(semver.major == 1)
    assert(semver.minor == 2)

# Generated at 2022-06-23 14:50:12.525908
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    passed = []
    failed = []
    with open("SemanticVersion___ge___unit_test.txt", encoding="utf-8") as file:
        while True:
            line = file.readline()
            # Check if we are at the end of the file
            if not line:
                break
            v1 = line.split()[0]
            v2 = line.split()[1]
            expected = line.split()[2]
            expected = True if expected == "True" else False
            passed_ = True if ((SemanticVersion(v1) >= SemanticVersion(v2)) == expected) else False
            if(passed_):
                passed.append(v1 + " " + v2 + " " + str(expected))

# Generated at 2022-06-23 14:50:19.579890
# Unit test for constructor of class _Numeric
def test__Numeric():
  assert type(_Numeric(1)) == type(1)
  assert _Numeric(1) == 1
  assert _Numeric(3) > 2
  assert _Numeric(3) < 4
  assert _Numeric(1) >= _Numeric(1)
  assert _Numeric(5) >= _Numeric(2)
  assert _Numeric(5) <= _Numeric(6)
  assert _Numeric(5) >= _Numeric(5)
  assert _Numeric(6) > _Numeric(5)
  assert _Numeric(6) >= _Numeric(5)
  assert _Numeric(6) == 6
  assert _Numeric(5) != 6
  assert not _Numeric(5) < 5
  assert not _Numeric(5) == 'string'

# Generated at 2022-06-23 14:50:27.594951
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # A simple unit test for method __lt__ of class SemanticVersion
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.1'), 'SemanticVersion("1.0.0") < SemanticVersion("1.0.1")'
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0-beta'), 'SemanticVersion("1.0.0-alpha") < SemanticVersion("1.0.0-beta")'
    assert SemanticVersion('1.0.0-alpha.beta') < SemanticVersion('1.0.0-beta.rc'), 'SemanticVersion("1.0.0-alpha.beta") < SemanticVersion("1.0.0-beta.rc")'
    assert SemanticVersion('1.0.0-alpha') < Semantic

# Generated at 2022-06-23 14:50:30.216951
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion('1.2.3-alpha.1')
    v2 = SemanticVersion('1.2.3')
    assert v1 != v2


# Generated at 2022-06-23 14:50:31.976801
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'


# Generated at 2022-06-23 14:50:36.495541
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('3').__eq__('3') == True
    assert _Numeric('3').__eq__(3) == True
    assert _Numeric('3').__eq__(_Alpha('3')) == False
    assert _Numeric('3').__eq__(_Numeric('3')) == True


# Generated at 2022-06-23 14:50:44.484861
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.0.0') >= '1.0.0'
    assert SemanticVersion('1.0.0') >= '0.2.3'
    assert SemanticVersion('0.2.3') >= '0.2.3'

    assert SemanticVersion('1.0.0-alpha.1') >= '1.0.0-alpha.1'
    assert SemanticVersion('1.0.0-alpha.1') >= '1.0.0'
    assert SemanticVersion('1.0.0') >= '1.0.0-alpha.1'
    assert SemanticVersion('1.0.0-alpha.1') >= '1.0.0-alpha.beta'
    assert SemanticVersion('1.0.0-alpha.beta') >= '1.0.0-alpha.1'

# Generated at 2022-06-23 14:50:52.720299
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    version = SemanticVersion()
    assert version.major is None
    assert version.minor is None
    assert version.patch is None
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # Invalid semver
    try:
        SemanticVersion('1.1.1-1+meta.data')
    except ValueError:
        pass
    else:
        raise AssertionError('Invalid semver should raise ValueError')

    # Major
    version = SemanticVersion('1')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # Major.minor
    version = SemanticVersion('1.1')
    assert version.major == 1

# Generated at 2022-06-23 14:50:56.520805
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric("1") > "2"
    assert _Numeric("1") > _Alpha("2")
    assert _Numeric("1") >= _Alpha("1")
    assert _Numeric("1") > 1
    assert _Numeric("1") == 1
    assert _Numeric("1") >= 1
    assert _Numeric("1") <= 1


# Generated at 2022-06-23 14:50:58.310019
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < 'b'



# Generated at 2022-06-23 14:51:03.818053
# Unit test for constructor of class _Numeric
def test__Numeric():
    # Constructor should accept integer
    _Numeric(1)

    # Constructor should convert string to integer
    _Numeric('1')

    # Constructor should fail if not passed a int or str
    try:
        _Numeric(None)
    except TypeError:
        pass
    else:
        assert False, 'TypeError not raised'


# Generated at 2022-06-23 14:51:07.492727
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha("alpha") == _Alpha("alpha")
    assert _Alpha("alpha") != _Alpha("Beta")
    assert _Alpha("alpha").specifier == "alpha"
    assert _Alpha("alpha") == "alpha"
    assert _Alpha("alpha") != "Beta"


# Generated at 2022-06-23 14:51:16.227990
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('0.0.0')
    assert SemanticVersion('0.0')
    assert SemanticVersion('0')
    assert SemanticVersion('0.1.1')
    assert SemanticVersion('0.1')
    assert SemanticVersion('1.0.0')
    assert SemanticVersion('1.0')
    assert SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-0.3.7')
    assert SemanticVersion('1.0.0-x.7.z.92')
    assert SemanticVersion('1.0.0-alpha+001')
    assert SemanticVersion('1.0.0+20130313144700')

# Generated at 2022-06-23 14:51:20.108452
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Alpha('2')
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < 2
    assert not _Numeric(1) < _Alpha('0')
    assert not _Numeric(1) < _Numeric(1)
    assert not _Numeric(1) < 1


# Generated at 2022-06-23 14:51:31.167457
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    x = _Alpha("1.2")
    y = _Alpha("1.2")
    assert not x < y
    y = _Alpha("1.3")
    assert x < y
    y = _Alpha("2.0")
    assert x < y
    y = _Alpha("1.2.0")
    assert x < y
    y = _Alpha("1.2.0.0")
    assert x < y
    y = _Alpha("1.2dev")
    assert not x < y
    y = _Alpha("1.2.dev")
    assert not x < y
    y = _Alpha("1.2.dev0")
    assert not x < y
    y = _Alpha("1.2.dev000")
    assert not x < y
    y = _Alpha("1.2.dev0.0")

# Generated at 2022-06-23 14:51:32.370067
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v = SemanticVersion('1.2.3')
    assert v < '1.2.4'


# Generated at 2022-06-23 14:51:35.242077
# Unit test for constructor of class _Numeric
def test__Numeric():
    numeric_specifier = _Numeric(42) # pass a numeric
    assert numeric_specifier.specifier == 42

    numeric_specifier = _Numeric('42') # pass a string
    assert numeric_specifier.specifier == 42



# Generated at 2022-06-23 14:51:36.322160
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    _Numeric(1) == _Numeric(1)


# Generated at 2022-06-23 14:51:39.806068
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion(vstring='1.2.3-4.5+6.7.8')
    assert repr(v) == 'SemanticVersion(\'1.2.3-4.5+6.7.8\')'


# Generated at 2022-06-23 14:51:40.595336
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
  pass

# Generated at 2022-06-23 14:51:46.742554
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    gt = [ 'alpha', 'beta', 'gamma', 'delta', 'epsilon', 'zeta', 'eta', 'theta', 'iota', 'kappa', 'lambda', 'mu', 'nu', 'xi', 'omicron', 'pi', 'rho', 'sigma', 'tau', 'upsilon', 'phi', 'chi', 'psi', 'omega' ]

    for lhs in gt:
        alpha = _Alpha(lhs)
        for rhs in gt:
            if lhs == rhs:
                assert alpha <= _Alpha(rhs), "%r <= %r" % (lhs, rhs)
            else:
                assert alpha <= _Alpha(rhs), "%r <= %r" % (lhs, rhs)



# Generated at 2022-06-23 14:51:49.402855
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'b'


# Generated at 2022-06-23 14:51:52.713027
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'b'
    assert 'a' != _Alpha('b')



# Generated at 2022-06-23 14:52:02.864169
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # Test for: SemanticVersion("1.0.0").__repr__()
    expected_repr = "SemanticVersion('1.0.0')"
    assert SemanticVersion("1.0.0").__repr__() == expected_repr
    # Test for: SemanticVersion("1.2.3").__repr__()
    expected_repr = "SemanticVersion('1.2.3')"
    assert SemanticVersion("1.2.3").__repr__() == expected_repr
    # Test for: SemanticVersion("1.2.3-rc.1").__repr__()
    expected_repr = "SemanticVersion('1.2.3-rc.1')"
    assert SemanticVersion("1.2.3-rc.1").__repr__() == expected_re

# Generated at 2022-06-23 14:52:13.163540
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(3) >= _Numeric(3)
    assert _Numeric(3) >= _Numeric(2)
    assert not _Numeric(2) >= _Numeric(3)
    assert not _Numeric(2) >= _Numeric(2)
    assert not _Numeric(3) >= _Numeric('3')
    assert not _Numeric(3) >= _Alpha('3')
    assert not _Numeric(3) >= 3
    assert _Numeric(3) >= 2
    assert not _Numeric(2) >= 3
    assert _Numeric(2) >= 1
    assert not _Numeric(1) >= 2


# Generated at 2022-06-23 14:52:23.455718
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('2')
    assert a.specifier == '2'

    # Test comparisons with _Numeric
    b = _Numeric('2')
    assert a == b
    assert not a != b
    assert not a < b
    assert a <= b
    assert not a > b
    assert a >= b


    # Test comparisons with str
    c = '2'
    assert a == c
    assert not a != c
    assert not a < c
    assert a <= c
    assert not a > c
    assert a >= c

    # Test comparisons with _Alpha
    d = _Alpha('1')
    assert not a == d
    assert a != d
    assert not a < d
    assert not a <= d
    assert a > d
    assert a >= d



# Generated at 2022-06-23 14:52:26.963164
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0-alpha')
    assert v1 <= v2
    v2 = SemanticVersion('1.0.0')
    assert v1 <= v2



# Generated at 2022-06-23 14:52:34.562611
# Unit test for method __ge__ of class _Alpha

# Generated at 2022-06-23 14:52:42.793478
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('test__Alpha___ge__') >= _Alpha('test__Alpha___ge__')
    assert _Alpha('test__Alpha___ge__') >= 'test__Alpha___ge__'
    assert _Alpha('test__Alpha___ge__') >= _Numeric('0')
    assert _Alpha('test__Alpha___ge__') >= '0'
    assert not _Alpha('test__Alpha___ge__') >= _Alpha('0')
    assert not _Alpha('test__Alpha___ge__') >= '0'


# Generated at 2022-06-23 14:52:52.739961
# Unit test for method __gt__ of class SemanticVersion

# Generated at 2022-06-23 14:52:56.184939
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Assert that SemanticVersion('1.2.3-alpha.1+build.1234') <= SemanticVersion('1.2.3') is True
    assert SemanticVersion('1.2.3-alpha.1+build.1234') <= SemanticVersion('1.2.3')



# Generated at 2022-06-23 14:53:00.545596
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    alpha = _Alpha("test")
    assert alpha == "test", "Fail: test__Alpha___eq__ expected True got False"
    assert alpha != 10, "Fail: test__Alpha___eq__ expected True got False"


# Generated at 2022-06-23 14:53:06.861582
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(10) <= _Numeric(11)
    assert _Numeric(10) <= _Numeric(10)
    assert not _Numeric(10) <= _Numeric(9)

    assert _Numeric(10) <= 11
    assert _Numeric(10) <= 10
    assert not _Numeric(10) <= 9

    assert not _Numeric(10) <= _Alpha('10')
    assert not _Numeric(10) <= _Alpha('9')



# Generated at 2022-06-23 14:53:08.009195
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')


# Generated at 2022-06-23 14:53:12.442403
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    obj = SemanticVersion('1.2.3')
    other = '1.2.3'
    expected = False
    result = obj.__ne__(other)
    assert result == expected



# Generated at 2022-06-23 14:53:18.292689
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == 1
    assert _Numeric(1) != 2
    assert _Numeric(1) < 2
    assert _Numeric(1) <= 2
    assert _Numeric(1) <= 1
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= 0
    assert _Numeric(1) > 0
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == _Numeric(2)


# Generated at 2022-06-23 14:53:20.598083
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('b') > _Alpha('a')
    assert not _Alpha('a') < _Alpha('a')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Numeric('1')


# Generated at 2022-06-23 14:53:32.113350
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert not SemanticVersion('1.2.3').__ne__('1.2.3')
    assert SemanticVersion('1.2.3').__ne__('1.2.4')
    assert SemanticVersion('1.2.3').__ne__(SemanticVersion('1.2.4'))
    assert not SemanticVersion('1.2.3-alpha.1').__ne__('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3-alpha.1').__ne__('1.2.3-alpha.2')
    assert SemanticVersion('1.2.3-alpha.1').__ne__(SemanticVersion('1.2.3-alpha.2'))
    assert not SemanticVersion('1.2.3-alpha.1+build.123.4567').__

# Generated at 2022-06-23 14:53:34.126133
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3+4') == SemanticVersion('1.2.3+4')


# Generated at 2022-06-23 14:53:43.581115
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    class _Alpha_lt_t(object):
        def __init__(self, value):
            self.value = value

        def __lt__(self, other):
            return self.value < other

    # both are _Alpha
    a = _Alpha('1')
    b = _Alpha('2')
    assert (a < b)
    assert not (b < a)
    assert not (a < a)
    a = _Alpha('a')
    b = _Alpha('b')
    assert (a < b)
    assert not (b < a)
    assert not (a < a)
    a = _Alpha('2')
    b = _Alpha('a')
    assert (a < b)
    assert not (b < a)
    assert not (a < a)

    # _Alpha and string
    a = _

# Generated at 2022-06-23 14:53:55.146598
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    _Numeric_1 = _Numeric(1)
    _Numeric_2 = _Numeric(2)

    assert (_Numeric_1 == _Numeric_1)
    assert not (_Numeric_1 == _Numeric_2)

    assert (_Numeric_1 == 1)
    assert not (_Numeric_1 == 2)

    assert not (_Numeric_1 == None)
    assert not (_Numeric_1 == 'hello')
    assert not (_Numeric_1 == '1')
    assert not (_Numeric_1 == '1.5')
    assert not (_Numeric_1 == '1.5.2')
    assert not (_Numeric_1 == '1.5.2.4')


# Generated at 2022-06-23 14:53:58.316586
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    int1 = _Numeric(5)
    int2 = 5

    assert int1 != int2


# Generated at 2022-06-23 14:53:59.678710
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(0) != _Numeric(1)


# Generated at 2022-06-23 14:54:01.187752
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    n = _Numeric('1')
    assert repr(n) == repr(n.specifier)



# Generated at 2022-06-23 14:54:06.348922
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    b = _Numeric('15')
    a = _Numeric('14')
    assert not a < a
    assert a < b
    assert not b < a
    assert not a < '14'
    assert not '14' < a
    assert a < '15'
    assert not '15' < a
    assert not a < 14
    assert not 14 < a
    assert a < 15
    assert not 15 < a
    try:
        assert a < b
    except Exception:
        pass
    except AssertionError:
        return True
    return False


# Generated at 2022-06-23 14:54:11.896295
# Unit test for constructor of class _Alpha
def test__Alpha():
    if _Alpha('a') == 'a':
        print('unit test for constructor of class _Alpha : \
                failed because _Alpha(\'a\') == \'a\' is True')
    else:
        print('unit test for constructor of class _Alpha : \
                passed because _Alpha(\'a\') == \'a\' is False')


# Generated at 2022-06-23 14:54:15.355908
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    # Test for method __repr__(self) of class _Numeric
    assert repr(_Numeric(1)) == '1'
    # Test for method __repr__(self) of class _Numeric
    assert repr(_Numeric('2')) == '2'


# Generated at 2022-06-23 14:54:22.774514
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('3') > _Alpha('2')
    assert _Alpha('alpha') > _Alpha('2')
    assert _Alpha('alpha') > _Alpha('beta')
    assert _Alpha('beta') > _Alpha('alpha')
    assert _Alpha('alpha') > '2'
    assert _Alpha('2') < 'alpha'
    assert _Alpha('alpha') < 'beta'
    assert _Alpha('beta') > 'alpha'


# Generated at 2022-06-23 14:54:26.957467
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Numeric(2) < _Alpha('b')
    assert not _Numeric(2) > _Alpha('b')
    assert _Alpha('b') > _Numeric(2)
    assert _Alpha('beta2') > _Alpha('beta')
    assert not _Alpha('beta') > _Alpha('beta')
    assert not _Alpha('beta') > _Alpha('Beta')
    assert _Alpha('beta') > _Alpha('alpha')


# Generated at 2022-06-23 14:54:38.711587
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(0) == 0
    assert _Numeric(0) <= 0
    assert _Numeric(0) >= 0
    assert _Numeric(0) >= 1
    assert _Numeric(0) < 1
    assert _Numeric(0) <= 1
    assert _Numeric(0) > -1
    assert _Numeric(0) >= -1
    assert _Numeric(0) <= -1
    assert _Numeric(1) > 0
    assert _Numeric(1) >= 0
    assert _Numeric(1) < 2
    assert _Numeric(1) > -1
    assert _Numeric(1) >= -1
    assert _Numeric(1) <= -1
    assert _Numeric(1) < 'a'
    assert _Numeric(1) > -1
    assert _

# Generated at 2022-06-23 14:54:42.190213
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) != 0
    assert _Numeric(1) != _Numeric(0)
    assert _Numeric(1) != _Alpha('1')


# Generated at 2022-06-23 14:54:48.447443
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != 1
    assert not _Numeric(1) != _Numeric(1)
    assert not _Numeric(1) != _Numeric('1')
    assert _Numeric('1') != 1
    assert _Numeric('1') != '1'
    assert not _Numeric('1') != _Numeric(1)
    assert not _Numeric('1') != _Numeric('1')


# Generated at 2022-06-23 14:54:51.950559
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric("123") != 123
    assert _Numeric("123") != "123"
    assert 123 != _Numeric("123")
    assert _Numeric("123") != _Numeric("123")
    assert _Numeric("123") != _Numeric("456")
    assert _Numeric("123") != _Alpha("123")


# Generated at 2022-06-23 14:54:57.268979
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) > _Alpha('0')
    assert not _Numeric(1) > _Numeric(1)
    assert not _Numeric(1) > _Alpha('1')
    assert not _Numeric(1) > _Numeric(2)
    assert not _Numeric(1) > _Alpha('2')

# Generated at 2022-06-23 14:54:59.227839
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    object1 = _Alpha("10")
    object2 = _Alpha("10")
    assert object1 == object2, "Test failed!"


# Generated at 2022-06-23 14:55:03.397042
# Unit test for constructor of class _Numeric
def test__Numeric():
    _Numeric(1)
    _Numeric('1')
    _Numeric('0')
    _Numeric(0)
    _Numeric('a')
    _Numeric('')


# Generated at 2022-06-23 14:55:08.854112
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.2.3') < SemanticVersion('2.3.4')
    assert SemanticVersion('1.2.3') < '2.3.4'
    assert not SemanticVersion('1.2.3') < SemanticVersion('1.2.3')
    assert not SemanticVersion('1.2.3') < '1.2.3'
    assert not SemanticVersion('2.3.4') < SemanticVersion('1.2.3')
    assert not SemanticVersion('2.3.4') < '1.2.3'


# Generated at 2022-06-23 14:55:11.502243
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha("1") == "1"
    assert isinstance(_Alpha("1"), _Alpha)


# Generated at 2022-06-23 14:55:14.648216
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    # Equal
    assert v1 >= v2
    assert v2 >= v1


# Generated at 2022-06-23 14:55:17.508200
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("1.2") <= "1.3"
    assert _Alpha("1.2") <= 1
    assert _Alpha("1.2") <= _Alpha("1.3")


# Generated at 2022-06-23 14:55:21.907348
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    return (
        _Numeric(0) > _Numeric(0)
    ) == False and (
        _Numeric(0) > _Numeric(1)
    ) == True and (
        _Numeric(0) > _Numeric(-1)
    ) == False and (
        _Numeric(0) > _Alpha('0')
    ) == False and (
        _Numeric(0) > _Alpha('a')
    ) == True


# Generated at 2022-06-23 14:55:31.234048
# Unit test for constructor of class _Numeric
def test__Numeric():
    n = _Numeric(1)
    n1 = _Numeric(1)
    n2 = _Numeric(3)
    n3 = _Numeric(1.5)
    n4 = _Numeric(1.4)
    n5 = _Numeric(1.5)
    assert n == n1
    assert n != n2
    assert n1 != n2
    assert str(n) == "1"
    assert str(n3) == "1"
    assert n < n2
    assert n2 > n
    assert n2 > n3
    assert n3 < n2
    assert n <= n1
    assert n >= n1
    assert n3 < n5
    assert n3 >= n4
    assert n3 <= n5
    assert n3 <= n4
    assert n3 == n5

# Generated at 2022-06-23 14:55:39.481405
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(2) <= _Numeric(3)

    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 2
    assert _Numeric(1) <= 2
    assert _Numeric(2) <= 3

    assert _Numeric(1) <= "1"
    assert _Numeric(1) <= "2"
    assert _Numeric(1) <= "2"
    assert _Numeric(2) <= "3"

    assert 1 <= _Numeric(1)
    assert 1 <= _Numeric(2)
    assert 1 <= _Numeric(2)
    assert 2 <= _N

# Generated at 2022-06-23 14:55:40.574067
# Unit test for constructor of class _Numeric
def test__Numeric():
    n = _Numeric("123")
    assert n.specifier == 123


# Generated at 2022-06-23 14:55:45.355258
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1, 'Should return True if compared to an int'
    assert _Numeric(1) == _Numeric(1), 'Should return True if compared to another instance of _Numeric'
    assert _Numeric(1) != _Numeric(2), 'Should return False if compared to another instance of _Numeric'



# Generated at 2022-06-23 14:55:53.032988
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("a") >= _Alpha("a")
    assert _Alpha("a") >= _Alpha("b") is False
    assert _Alpha("b") >= _Alpha("a")
    assert _Alpha("b") >= "a"
    assert "a" <= _Alpha("b")
    assert _Alpha("b") <= "b"
    assert "b" <= _Alpha("b")
    with pytest.raises(ValueError):
        _Alpha("a") >= _Numeric("2")


# Generated at 2022-06-23 14:55:55.467588
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == '1'
    assert repr(_Numeric('1.1')) == '1'
    assert repr(_Numeric('a')) == '0'


# Generated at 2022-06-23 14:55:59.193394
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    try:
        a = _Alpha('1')
        b = _Alpha('2')
        if a >= b:
            raise ValueError
        else:
            print("SUCCESS")
    except ValueError:
        print("FAILURE")


# Generated at 2022-06-23 14:56:07.043409
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    test_instances = [
        ('1.0.0', text_type('1.0.0')),
        ('1.0.0+build.metadata', text_type('1.0.0')),
        ('1.0.0-alpha', text_type('1.0.0')),
        ('1.0.0-alpha+build.metadata', text_type('1.0.0-alpha')),
    ]

    result = []
    for test_pair in test_instances:
        instance = SemanticVersion(test_pair[0])
        result.append((instance, test_pair[1], instance != test_pair[1]))


# Generated at 2022-06-23 14:56:16.496451
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    class Test:
        def __init__(self, value):
            self.value = value

        def __eq__(self, other):
            if self.value == other.value:
                return True
            else:
                return False

        def __ne__(self, other):
            if self.value != other.value:
                return True
            else:
                return False

        def __lt__(self, other):
            if self.value < other.value:
                return True
            else:
                return False

        def __le__(self, other):
            if self.value <= other.value:
                return True
            else:
                return False

        def __gt__(self, other):
            if self.value > other.value:
                return True
            else:
                return False


# Generated at 2022-06-23 14:56:27.842867
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    import itertools
    import unittest
    from collections import namedtuple

    TestCase = namedtuple('TestCase', ('a', 'b', 'expected'))
    test_cases = (
        # a          b         expected
        TestCase(_Alpha('alpha'), _Alpha('alpha'), True),
        TestCase(_Alpha('alpha'), _Alpha('beta'), True),
        TestCase(_Alpha('beta'), _Alpha('alpha'), False),
        TestCase(_Alpha('alpha'), _Alpha('1'), False),
        TestCase(_Alpha('alpha'), _Numeric('1'), False),
        TestCase(_Alpha('alpha'), _Alpha('1.0'), False),
        TestCase(_Alpha('alpha'), _Numeric('1.0'), False),
    )
    for test_case in test_cases:
        a = test_case.a
       

# Generated at 2022-06-23 14:56:37.894711
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # New
    assert SemanticVersion('0.0.0') == '0.0.0'
    # New
    assert SemanticVersion('0.0.0') == SemanticVersion('0.0.0')
    # New
    assert SemanticVersion('0.0.0') != '0.0.1'
    # New
    assert SemanticVersion('0.0.0') != SemanticVersion('0.0.1')
    # New
    assert SemanticVersion('1.0.0') == '1.0.0'
    # New
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    # New
    assert SemanticVersion('1.0.0') != '0.0.0'
    # New

# Generated at 2022-06-23 14:56:48.898682
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > 0
    assert _Numeric(1) < 2

    assert not _Numeric(1) > 1
    assert not _Numeric(1) < 1

    assert not _Numeric(1) > 2
    assert not _Numeric(1) < 0

    try:
        _Numeric(1) > _Alpha('1')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    try:
        _Numeric(1) < _Alpha('1')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    assert not _Numeric(1) >= 0
    assert not _Numeric(1) <= 0

    assert _Numeric(1) >= 1
    assert _Numeric(1) <= 1

# Generated at 2022-06-23 14:56:55.215584
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    assert SemanticVersion('1.2.3-alpha').core == (1, 2, 3)
    assert SemanticVersion('1.2.3+build123').core == (1, 2, 3)
    assert SemanticVersion('1.2.3-alpha+build123.1').core == (1, 2, 3)



# Generated at 2022-06-23 14:57:03.995121
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # Test 1: Provide a valid version in the form of a string
    version = SemanticVersion("1.1.1")
    assert version >= "1.1.1"
    assert version >= "1.1.2"
    assert not version >= "1.2.1"
    assert not version >= "2.1.1"
    # Test 2: Provide a valid version in the form of a SemanticVersion object
    version = SemanticVersion("1.1.1")
    assert version >= SemanticVersion("1.1.1")
    assert version >= SemanticVersion("1.1.2")
    assert not version >= SemanticVersion("1.2.1")
    assert not version >= SemanticVersion("2.1.1")
    # Test 3: Provide an invalid version in the form of a string

# Generated at 2022-06-23 14:57:05.773384
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('test') <= _Alpha('test')
    assert _Alpha('test') <= 'test'
    assert _Alpha('test') <= _Alpha('TEST')


# Generated at 2022-06-23 14:57:16.448709
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
  sv = SemanticVersion('2.0.0')
  assert sv == '2.0.0'
  assert sv == SemanticVersion('2.0.0')
  assert sv == SemanticVersion.from_loose_version(LooseVersion('2.0'))
  assert sv == LooseVersion('2.0')
  assert sv == (2, 0, 0)
  assert sv == [2, 0, 0]
  assert not sv == '2.0'
  assert not sv == SemanticVersion('2.0')
  assert not sv == LooseVersion('2')
  assert not sv == '2.0.0-rc.1'
  assert not sv == '2.0.0+metadata'
  assert not sv == '2.0.0+metadata.2'

# Generated at 2022-06-23 14:57:19.931608
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(2) < _Numeric(3)


# Generated at 2022-06-23 14:57:28.635005
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
   print("Unit test for method __ge__ of class SemanticVersion")
   sv = SemanticVersion("1.1.1")
   assert sv >= SemanticVersion("1.1.1")
   assert sv >= "1.1.1"
   assert not sv >= "1.1.2"
   assert not sv >= SemanticVersion("1.1.2")
   sv2 = SemanticVersion("1.1.1-1")
   assert sv2 >= SemanticVersion("1.1.1-1")
   assert sv2 >= "1.1.1-1"
   assert not sv2 >= "1.1.1-2"
   assert sv2 >= SemanticVersion("1.1.0")
   assert sv >= SemanticVersion("0.0.0")

# Generated at 2022-06-23 14:57:33.194767
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a1 = _Numeric(1)
    a2 = _Numeric(2)

    assert a1 <= a2
    assert not a2 <= a1

    assert not a1 <= 0
    assert a2 <= 2

    assert not a1 <= ""
    assert not a2 <= "2"

    assert not a1 <= _Numeric(None)
    assert not a2 <= _Numeric(None)



# Generated at 2022-06-23 14:57:36.656184
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    a = _Numeric(5)
    b = _Numeric(5)
    c = _Numeric('5')
    d = _Numeric(4)
    e = _Alpha(5)

    assert a.__eq__(a) is True
    assert a.__eq__(b) is True
    assert a.__eq__(c) is True
    assert a.__eq__(d) is False
    assert a.__eq__(e) is False


# Generated at 2022-06-23 14:57:40.710756
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert not _Numeric(1).__eq__(1)
    assert _Numeric(1).__eq__(_Numeric(1))
    assert not _Numeric(1).__eq__(_Numeric(2))
    assert _Numeric(1).__eq__(1)
    assert not _Numeric(1).__eq__(2)


# Generated at 2022-06-23 14:57:43.457250
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    """
    Tests the __ne__ method of the SemanticVersion class
    """
    SemanticVersion.__ne__(SemanticVersion("1.0.0"), "1.0.0")



# Generated at 2022-06-23 14:57:50.929917
# Unit test for constructor of class _Alpha
def test__Alpha():
    obj = _Alpha('alpha')
    assert repr(obj) == "'alpha'"
    assert obj == 'alpha'
    assert obj != 'beta'
    assert obj < 'beta'
    assert obj <= 'beta'
    assert not obj > 'beta'
    assert not obj >= 'beta'
    assert obj == _Alpha('alpha')
    assert obj != _Alpha('beta')
    assert obj < _Alpha('beta')
    assert obj <= _Alpha('beta')
    assert not obj > _Alpha('beta')
    assert not obj >= _Alpha('beta')
    assert not obj == 5
    assert obj != 5
    assert obj < 5
    assert obj <= 5
    assert not obj > 5
    assert not obj >= 5
    with pytest.raises(ValueError):
        assert obj < 'beta'
        # :off
        # Wrong

# Generated at 2022-06-23 14:57:58.579568
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    from ansible_collections.sensu.sensu_go.plugins.module_utils.sensu_common import SemanticVersion

    assert SemanticVersion("1.2.3-4").major == 1
    assert SemanticVersion("1.2.3-4").minor == 2
    assert SemanticVersion("1.2.3-4").patch == 3
    assert SemanticVersion("1.2.3-4").prerelease == (4,)
    assert SemanticVersion("1.2.3-4").buildmetadata == ()

    assert SemanticVersion("1.2.3-prerelease-4").major == 1
    assert SemanticVersion("1.2.3-prerelease-4").minor == 2
    assert SemanticVersion("1.2.3-prerelease-4").patch == 3

# Generated at 2022-06-23 14:58:03.461878
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    assert a.specifier == 'a'
    assert not a < 'a'
    assert not a <= 'b'
    assert not a > 'a'
    assert a <= 'b'
    assert a > 'A'
    assert not a < 'A'
    assert a >= 'a'



# Generated at 2022-06-23 14:58:13.158600
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(2) < _Numeric(3)
    assert _Numeric(3) < _Numeric(4)

    assert _Numeric(2) < 3
    assert _Numeric(3) < 4
    assert _Numeric(3) < _Alpha('3')

    try:
        _Numeric(1) < 0
        raise AssertionError('Should have raised')
    except ValueError:
        pass

    try:
        _Numeric(0) < _Alpha('0')
        raise AssertionError('Should have raised')
    except ValueError:
        pass

    try:
        _Numeric(0) < '0'
        raise AssertionError('Should have raised')
    except ValueError:
        pass


# Generated at 2022-06-23 14:58:22.737161
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    for i in range(10):
        for j in range(10):
            if i < j:
                assert _Alpha(i) < _Alpha(j)
            else:
                assert not _Alpha(i) < _Alpha(j)

    for i in range(10):
        for j in range(10):
            if i == j:
                assert not _Alpha(i) < j
            else:
                assert _Alpha(i) < j

    for i in range(10):
        for j in range(10):
            if i == j:
                assert not i < _Alpha(j)
            else:
                assert i < _Alpha(j)


# Generated at 2022-06-23 14:58:30.353276
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    version = SemanticVersion('1.2.3')
    assert version._SemanticVersion__major == 1
    assert version._SemanticVersion__minor == 2
    assert version._SemanticVersion__patch == 3
    assert version._SemanticVersion__prerelease == ()
    assert version._SemanticVersion__buildmetadata == ()
    version = SemanticVersion('1.2.3-alpha.1+build.1')
    assert version._SemanticVersion__major == 1
    assert version._SemanticVersion__minor == 2
    assert version._SemanticVersion__patch == 3
    assert version._SemanticVersion__prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert version._SemanticVersion__buildmetadata == (_Alpha('build'), _Numeric('1'))
    version = SemanticVersion('1.2.3-alpha')