

# Generated at 2022-06-23 14:48:35.080134
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    objs = [_Alpha('alpha'), _Alpha('ALPHA'), _Alpha('b')]
    expect = ['b', 'ALPHA', 'alpha']
    obs = sorted(objs)
    assert obs == expect, "Failed sorting _Alphas"



# Generated at 2022-06-23 14:48:36.286508
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(123) == repr(_Numeric(123))


# Generated at 2022-06-23 14:48:47.689950
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    import sys

    # test for equality
    assert _Numeric(5) >= 5
    assert _Numeric(5) >= _Numeric(5)

    # test for greater than
    assert _Numeric(5) >= 3
    assert _Numeric(5) >= _Numeric(3)

    # test for less than
    assert _Numeric(3) >= 5 is False
    assert _Numeric(3) >= _Numeric(5) is False

    # test for type errors
    if sys.version_info < (3, 0):
        assert _Numeric(5) >= '5' is False
        assert _Numeric(5) >= _Alpha('5') is False

        assert _Numeric(5) >= _Alpha('3') is False
        assert _Alpha('5') >= _Numeric(3) is True

# Generated at 2022-06-23 14:48:57.034949
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('0.9.9')
    assert SemanticVersion('1.0.1') > SemanticVersion('1.0.0')
    assert SemanticVersion('1.1.1') > SemanticVersion('1.1.0')
    assert SemanticVersion('2.0.0') > SemanticVersion('1.9.9')
    # Prereleases
    assert SemanticVersion('1.0.0') > SemanticVersion('0.9.9-alpha')
    assert SemanticVersion('0.0.1') > SemanticVersion('0.0.1-alpha')
    assert SemanticVersion('0.0.1') > SemanticVersion('0.0.1-alpha.1')

# Generated at 2022-06-23 14:48:59.567506
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('foo').__ne__('foo') == False
    assert _Alpha('foo').__ne__(_Alpha('foo')) == False


# Generated at 2022-06-23 14:49:05.831286
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert str(SemanticVersion('1.2.3-alpha')) == '1.2.3-alpha'
    assert str(SemanticVersion('1.2.3-alpha1.beta2')) == '1.2.3-alpha1.beta2'
    assert str(SemanticVersion('1.2.3')) == '1.2.3'
    assert str(SemanticVersion('1.2.3-alpha1.1')) == '1.2.3-alpha1.1'


# Generated at 2022-06-23 14:49:09.369546
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3-alpha.1+build.1')


# Generated at 2022-06-23 14:49:16.479146
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert (_Alpha('1') != 1) == False
    assert (_Alpha('1') != _Alpha('1')) == False
    assert (_Alpha('1') != _Alpha('2')) == True
    assert (_Alpha('1') != _Numeric('1')) == False
    assert (_Alpha('1') != _Numeric('2')) == True

    # _Alpha(1) != '1' # Can't compare '_Alpha' instance with str instance
    # _Alpha(1) != None # Can't compare '_Alpha' instance with NoneType instance
    # _Alpha(1) != [] # Can't compare '_Alpha' instance with list instance
    # _Alpha(1) != () # Can't compare '_Alpha' instance with tuple instance
    # _Alpha(1) != {} # Can't compare '_Alpha' instance with dict instance

# Unit

# Generated at 2022-06-23 14:49:26.082571
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Verify '1.0.0' > '1.0.0-alpha.1'
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha.1')
    # Verify '1.0.0-alpha.2' > '1.0.0-alpha.1'
    assert SemanticVersion('1.0.0-alpha.2') > SemanticVersion('1.0.0-alpha.1')
    # Verify '1.0.0-alpha.1' > '1.0.0-alpha'
    assert SemanticVersion('1.0.0-alpha.1') > SemanticVersion('1.0.0-alpha')
    # Verify '1.0.0-alpha.2' > '1.0.0-alpha'

# Generated at 2022-06-23 14:49:30.680407
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha("1.2.0") != "1.2.0"
    assert _Alpha("1.2.0") != "1.2.0"
    assert not (_Alpha("1.3.0") != "1.3.0")

# Unit tests for method __eq__ of class _Alpha

# Generated at 2022-06-23 14:49:31.926934
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('alpha')) == "'alpha'"


# Generated at 2022-06-23 14:49:33.135430
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('-alpha')) == "'-alpha'"



# Generated at 2022-06-23 14:49:36.343681
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    specifier = _Alpha("a")
    other = _Alpha("b")
    assert specifier.__le__(other) == True
    assert specifier.__le__("b") == True
    assert specifier.__le__(_Numeric("1")) == False


# Generated at 2022-06-23 14:49:45.716649
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # init empty vars to be used in unit tests
    # test_value_type should be a list of strings
    test_value_type = []
    # test_value_type_error should be a list of strings
    test_value_type_errors = []
    # test_value_loose_version should be a list of strings
    test_value_loose_version = []
    # test_value_loose_version_error should be a list of strings
    test_value_loose_version_errors = []
    # test_value_non_integer should be a list of strings
    test_value_non_integer = []
    # test_value_non_integer_errors should be a list of strings
    test_value_non_integer_errors = []
    # test_value_conversion should be a list of tuples


# Generated at 2022-06-23 14:49:53.858157
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.3.3')
    assert SemanticVersion('1.2.3') < SemanticVersion('2.2.3')
    assert SemanticVersion('1.2.3-alpha') < SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3-alpha') < SemanticVersion('1.2.3-beta')
    assert SemanticVersion('1.2.3-beta') < SemanticVersion('1.2.3-rc')

# Generated at 2022-06-23 14:50:04.271249
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion('1.2.3-alpha.0.0.0')

    assert v.vstring == '1.2.3-alpha.0.0.0'
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == (_Numeric('0'), _Alpha('alpha'), _Numeric('0'), _Numeric('0'))
    assert v.buildmetadata == ()

    v = SemanticVersion('1.2.3-alpha.10')

    assert v.vstring == '1.2.3-alpha.10'
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == (_Numeric('10'), _Alpha('alpha'))
    assert v.buildmetadata

# Generated at 2022-06-23 14:50:12.820429
# Unit test for method __le__ of class SemanticVersion

# Generated at 2022-06-23 14:50:14.040773
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(5)) == "5"


# Generated at 2022-06-23 14:50:18.126755
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3.4")) == SemanticVersion("1.2.3")


# Generated at 2022-06-23 14:50:24.255661
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    '''
    Case 1: if input is int
    '''
    x = _Numeric(1)
    y = 2
    assert x.__gt__(y) == True, "Test failed"
    '''
    Case 2: if input is _Numeric
    '''
    x = _Numeric(2)
    y = _Numeric(1)
    assert x.__gt__(y) == True, "Test failed"
    '''
    Case 3: if x is equal to y
    '''
    x = _Numeric(1)
    y = _Numeric(1)
    assert x.__gt__(y) == False, "Test failed"


# Generated at 2022-06-23 14:50:25.531063
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('test')) == repr('test')


# Generated at 2022-06-23 14:50:28.787397
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1').specifier == 1
    assert _Numeric('2').specifier == 2


# Generated at 2022-06-23 14:50:32.656496
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alphas = (
        ('a', 'b'),
        ('a', 'a2'),
        ('a2', 'a3'),
        ('a', 'aa'),
    )
    for lhs, rhs in alphas:
        assert _Alpha(lhs) < _Alpha(rhs)


# Generated at 2022-06-23 14:50:35.912101
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion("2.0.0")
    v2 = SemanticVersion("1.0.0")
    v3 = SemanticVersion("1.0.0")
    assert v1 >= v2 and v2 >= v3

# Generated at 2022-06-23 14:50:43.173842
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == '1'
    assert repr(_Numeric(1.1)) == '1'
    assert repr(_Numeric('1')) == '1'
    assert repr(_Numeric('1.1')) == '1'
    with pytest.raises(TypeError):
        _Numeric(None)
    with pytest.raises(TypeError):
        _Numeric('foo')


# Generated at 2022-06-23 14:50:46.424282
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    version = _Numeric(2)

    assert version == 2
    assert version == _Numeric(2)
    assert version != 1
    assert version != _Numeric(1)
    assert not version == 1

    assert not version == '2'
    assert not version == _Alpha('2')



# Generated at 2022-06-23 14:50:51.629544
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    """Unit test for method __ne__ of class SemanticVersion"""
    version = SemanticVersion('1.2.3')
    assert version != '1.2.4'
    assert version != '1.2.3'
    assert version != '1.2.3.4'
    assert version != '1.2.3.4.5'
    assert version != '1.2.3-5'
    assert version != '1.2.3-5.6'


# Generated at 2022-06-23 14:50:52.448793
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    return None


# Generated at 2022-06-23 14:50:54.967096
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    ver1 = SemanticVersion('1.2.2')
    ver2 = SemanticVersion('1.2.3')

    assert ver1.__ge__(ver2) == False
    assert ver2.__ge__(ver1) == True


# Generated at 2022-06-23 14:51:06.040656
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= '1.0.0'
    assert SemanticVersion('1.0.1') <= '1.0.1'
    assert SemanticVersion('2.0.0') <= '2.0.0'
    assert SemanticVersion('2.0.0') <= '2.1.0'
    assert SemanticVersion('2.0.0') <= '2.1.1'
    assert SemanticVersion('2.0.1') <= '2.1.0'
    assert SemanticVersion('2.0.1') <= '2.1.1'
    assert SemanticVersion('2.1.0') <= '2.1.0'
    assert SemanticVersion('2.1.0') <= '2.2.0'

# Generated at 2022-06-23 14:51:08.117923
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion("1.1.1")
    assert repr(v) == 'SemanticVersion("1.1.1")'


# Generated at 2022-06-23 14:51:12.800768
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    s=_Numeric(5.5)
    z=_Numeric(5)
    st2=_Numeric(5.5)
    assert s.__ne__(z) == True, 'Equal number considered as not equal number'
    assert s.__ne__(st2) == False, 'Not equal number considered as equal number'


# Generated at 2022-06-23 14:51:17.075972
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    test_cases = [
        ('a', "_Alpha('a')"),
        ('1abc', "_Alpha('1abc')"),
        ('abc-1', "_Alpha('abc-1')")
    ]

    for (specifier, expected) in test_cases:
        obj = _Alpha(specifier)
        actual = obj.__repr__()
        assert actual == expected, "'%s' != '%s'" % (actual, expected)


# Generated at 2022-06-23 14:51:28.815035
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion, LooseVersion
    try:
        SemanticVersion.from_loose_version('1.2.3')
    except ValueError:
        pass
    else:
        raise RuntimeError('test should have failed.')

    # Loose version with non integer values
    lv = LooseVersion('1.2.3-alpha')
    try:
        SemanticVersion.from_loose_version(lv)
    except ValueError:
        pass
    else:
        raise RuntimeError('test should have failed.')

    lv = LooseVersion('1.2.3')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == '1.2.3', sv.vstring


# Generated at 2022-06-23 14:51:37.287458
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():

    # Test string comparison
    assert _Alpha('a') < _Alpha('z'), 'String comparison failed'
    assert _Alpha('a') < _Alpha('z1'), 'String comparison failed'
    assert _Alpha('a') > _Alpha('0'), 'String comparison failed'

    # Test integer comparison
    assert _Alpha('1') < _Alpha('2'), 'Integer comparison failed'
    assert _Alpha('1.2') < _Alpha('2.2'), 'Integer comparison failed'
    assert not _Alpha('1') < _Alpha('0'), 'Integer comparison failed'

    # Test mixed number/string comparison
    assert _Alpha('1') < _Alpha('a'), 'Mixed number/string comparison failed'
    assert _Alpha('1') < _Alpha('2a'), 'Mixed number/string comparison failed'

# Generated at 2022-06-23 14:51:44.444453
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a1').__lt__('a1') is False
    assert _Alpha('a1').__lt__('a2') is True
    assert _Alpha('a2').__lt__('a1') is False
    assert _Alpha('a1').__lt__(1) is True
    assert _Alpha('a1').__lt__(_Alpha('a1')) is False
    assert _Alpha('a1').__lt__(_Alpha('a2')) is True
    assert _Alpha('a1').__lt__(_Alpha('b1')) is True
    assert _Alpha('a2').__lt__(_Alpha('a1')) is False



# Generated at 2022-06-23 14:51:49.712336
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version_str = '2.1.0+abc'
    loose_version = LooseVersion(version_str)
    semver_version = SemanticVersion.from_loose_version(loose_version)
    assert text_type(semver_version) == version_str


# Generated at 2022-06-23 14:51:59.376652
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('1.0.0-alpha').parse('1.0.0-alpha') == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha.1').parse('1.0.0-alpha.1') == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-0.3.7').parse('1.0.0-0.3.7') == SemanticVersion('1.0.0-0.3.7')
    assert SemanticVersion('1.0.0-x.7.z.92').parse('1.0.0-x.7.z.92') == SemanticVersion('1.0.0-x.7.z.92')

# Generated at 2022-06-23 14:52:00.858635
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion("0.9.0") < SemanticVersion("1.0.0")


# Generated at 2022-06-23 14:52:05.885614
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert 'a' >= _Alpha('a')
    assert _Alpha('a') <= 'a'
    assert 'a' <= _Alpha('a')
    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')
    assert _Alpha('a') > 'A'
    assert 'A' < _Alpha('a')
    assert _Alpha('a') == 'A'
    assert 'A' == _Alpha('a')
    assert _Alpha('a') != 'b'
    assert 'b' != _Alpha('a')


# Generated at 2022-06-23 14:52:12.270490
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # Given a string
    vstring = "1.2.3"

    # When I create a SemanticVersion
    v = SemanticVersion(vstring)

    # Then I expect the string representation to be:
    # "'<vstring>'"
    expected = "'{}'".format(vstring)
    assert repr(v) == expected



# Generated at 2022-06-23 14:52:15.923330
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('A') == 'A'
    assert _Alpha('A') != 'B'
    assert _Alpha('A') == _Alpha('A')
    assert _Alpha('A') != _Alpha('B')


# Generated at 2022-06-23 14:52:25.080981
# Unit test for constructor of class _Alpha
def test__Alpha():
    # Test for for different inputs
    assert not _Alpha("1.1") == "1.2"
    assert _Alpha("1.1") == "1.1"
    assert not _Alpha("1.1") == "1"
    assert not _Alpha("1.1") == 1
    assert not _Alpha("1.1") == text_type("1.2")
    assert _Alpha("1.1") == text_type("1.1")
    assert not _Alpha("1.1") == text_type("1")
    assert not _Alpha("1.2") == 1
    assert _Alpha("1.1") == _Alpha("1.1")
    assert not _Alpha("1.1") == _Alpha("1")
    assert not _Alpha("1.1") == _Alpha("1.2")


# Generated at 2022-06-23 14:52:31.060504
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    n1 = _Numeric('1')
    n2 = _Numeric('2')
    n3 = _Numeric('3')
    na = _Numeric('a')
    assert n1 < n2
    assert n1 < n3
    assert n2 < n3
    assert n1 < na
    assert na < n2
    assert not (n2 < n1)
    assert not (n3 < n1)
    assert not (n3 < n2)
    assert not (n1 < n1)
    assert not (n2 < n2)
    assert not (n3 < n3)
    assert not (na < na)
    assert not (n1 < 1)
    assert not (1 < n1)
    assert n1 < 2
    assert not (n1 < 'b')

# Generated at 2022-06-23 14:52:37.509774
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    assert a.specifier == 'a'
    b = _Alpha('b')
    assert b.specifier == 'b'
    assert a < b
    assert a <= b
    assert not a == b
    assert not a >= b
    assert not a > b
    assert a != b
    c = _Alpha('a')
    assert a == c
    assert c == a
    assert a == 'a'
    assert a != 1
    assert 1 != a
    assert not a == 1
    assert not 1 == a
    assert a < 1
    assert 1 > a
    assert a <= 1
    assert 1 >= a
    try:
        a > 1
    except ValueError:
        pass

# Generated at 2022-06-23 14:52:41.742519
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('1') >= _Alpha('0')
    assert _Alpha('1') >= '1'
    assert _Alpha('1') >= '0'
    assert _Alpha('1') < '2'
    assert _Alpha('1') <= '2'


# Generated at 2022-06-23 14:52:45.958740
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) == _Numeric(1)
    assert 1 == _Numeric(1)
    assert _Numeric(1) != 2
    assert _Numeric(1) != _Numeric(2)
    assert 1 != _Numeric(2)


# Generated at 2022-06-23 14:52:55.291944
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.2.3') >= '1.2.3'
    assert SemanticVersion('1.2.3') >= '1.2.2'
    assert SemanticVersion('1.2.3') >= '1.1.3'
    assert SemanticVersion('1.2.3') >= '0.2.3'
    assert SemanticVersion('1.2.3') >= '1.2.3-alpha'
    assert SemanticVersion('1.2.3') >= '1.2.2-alpha'
    assert SemanticVersion('1.2.3') >= '1.1.3-alpha'
    assert SemanticVersion('1.2.3') >= '0.2.3-alpha'

# Generated at 2022-06-23 14:53:06.379503
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    from ansible.module_utils.semver import SemanticVersion
    assert(SemanticVersion('1.1.1') <= SemanticVersion('2.2.2'))
    assert(SemanticVersion('1.1.1') <= SemanticVersion('1.1.1'))
    assert(SemanticVersion('0.2.2') <= SemanticVersion('0.3.3alpha1'))
    assert(SemanticVersion('0.2.2') <= SemanticVersion('0.3.3alpha1'))
    assert(SemanticVersion('0.2.2beta1') <= SemanticVersion('0.2.2beta2'))
    assert(SemanticVersion('0.2.2beta1') <= SemanticVersion('0.2.2alpha'))

# Generated at 2022-06-23 14:53:08.368283
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    alpha = _Alpha("test")
    assert alpha == "test"
    assert alpha == _Alpha("test")


# Generated at 2022-06-23 14:53:17.136950
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('1') <= _Alpha('1')
    assert not _Alpha('1') <= _Alpha('0')
    assert _Alpha('1') <= _Alpha('2')
    assert not _Alpha('2') <= _Alpha('1')
    assert _Alpha('a') <= _Alpha('a')
    assert not _Alpha('a') <= _Alpha('0')
    assert _Alpha('a') <= _Alpha('b')
    assert not _Alpha('b') <= _Alpha('a')
    assert not _Alpha('a') <= _Numeric(1)
    assert _Alpha('a') <= _Numeric(2)
    assert not _Alpha('a') <= _Numeric(0)
    assert not _Alpha('b') <= _Numeric(1)
    assert _Alpha('b') <= _Numeric(2)
    assert not _Alpha

# Generated at 2022-06-23 14:53:20.331783
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    """Unit test for method __repr__ of class _Numeric"""
    assert repr(_Numeric('1')) == '1'
    assert repr(_Numeric('0')) == '0'
    assert repr(_Numeric('0.0.0')) == '0'


# Generated at 2022-06-23 14:53:26.947112
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Tests for method parse of class SemanticVersion
    #
    # A test case for the parser.

    # This tests that a valid version string is parsed
    # correctly into its parts.
    version = SemanticVersion('1.5.0alpha1-r3')
    assert version.major == 1
    assert version.minor == 5
    assert version.patch == 0
    assert version.prerelease == ('alpha', 1)
    assert version.is_prerelease
    assert not version.is_stable

    # This tests that an invalid version string raises an
    # exception.
    try:
        SemanticVersion('1.5-alpha1-r3')
    except ValueError:
        pass
    else:
        assert 0, 'expected ValueError'

# Generated at 2022-06-23 14:53:35.498195
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # invalid version
    invalid_version = ['-1.0.1', '0..1', '1.0.', 'a.b.c', '1.A.1']
    for version in invalid_version:
        try:
            SemanticVersion(version)
        except ValueError:
            pass
        else:
            raise ValueError(
                "Failed to raise ValueError for invalid version {0}".format(version)
            )

    # valid version

# Generated at 2022-06-23 14:53:43.665867
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < SemanticVersion('2.0.0')
    assert SemanticVersion('2.0.0') < SemanticVersion('2.1.0')
    assert SemanticVersion('2.1.0') <= SemanticVersion('2.1.0')
    assert SemanticVersion('2.1.0') >= SemanticVersion('2.1.0')
    assert SemanticVersion('2.1.0') > SemanticVersion('2.0.0')
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0')
    assert SemanticVersion('1.1.0') < SemanticVersion('1.2.0')
    assert SemanticVersion('1.2.0') > SemanticVersion('1.1.0')

# Generated at 2022-06-23 14:53:53.101136
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert not (_Alpha('b') <= _Alpha('a'))
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert not (_Alpha('b') <= 'a')
    assert not (_Alpha('b') <= 1)
    try:
        _Alpha('b') <= 1
    except ValueError:
        pass
    else:
        raise Exception('Failed to raise ValueError when comparing str and int')


# Generated at 2022-06-23 14:54:01.906041
# Unit test for method __ge__ of class SemanticVersion

# Generated at 2022-06-23 14:54:03.285145
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < 2



# Generated at 2022-06-23 14:54:06.125317
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    """Method __eq__ does not compare object if object of other class is passed """
    x = _Numeric(1)
    y = _Alpha(1)
    assert (x == y) == False


# Generated at 2022-06-23 14:54:08.831862
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Alpha('1')


# Generated at 2022-06-23 14:54:11.610255
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('1') <= _Numeric('2')
    assert _Numeric('1') <= _Numeric('1')
    assert not _Numeric('1') <= _Numeric('0')


# Generated at 2022-06-23 14:54:14.745631
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha(3)
    assert a == 3
    assert 3 == a
    assert a != 4
    assert 4 != a
    assert a < 4
    assert a <= 4
    assert 4 > a
    assert 4 >= a


# Generated at 2022-06-23 14:54:18.877913
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n = _Numeric(0)
    assert n == _Numeric(0)
    assert n == 0


# Generated at 2022-06-23 14:54:21.516767
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    obj = _Numeric(123)
    otherObject = _Numeric(456)
    value = otherObject

    result = obj.__ne__(value)

    assert result == True


# Generated at 2022-06-23 14:54:27.587826
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a = _Numeric(0)
    b = _Numeric(0)

    assert a <= b

    a = _Numeric(0)
    b = _Numeric(1)

    assert a <= b

    a = _Numeric(1)
    b = _Numeric(0)

    assert not a <= b

    a = _Numeric(1)
    b = _Numeric(1)

    assert a <= b

    a = _Numeric(1.1)
    b = _Numeric(1)

    assert not a <= b

    print('test__Numeric___le__ passed')


# Generated at 2022-06-23 14:54:39.162765
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('a')
    alpha = _Alpha('alpha')
    a2 = _Alpha('a2')
    a20 = _Alpha('a20')
    b = _Alpha('b')
    z = _Alpha('z')
    n1 = _Numeric(1)
    n10 = _Numeric(10)
    n2 = _Numeric(2)

    assert not a > a
    assert not a > 'a'
    assert a < 'b'

    assert not alpha > alpha
    assert not alpha > 'alpha'
    assert alpha < 'b'

    assert not a2 > a2
    assert not a2 > 'a2'
    assert a2 < 'b'

    assert not a20 > a20
    assert not a20 > 'a20'
    assert a20 < 'b'


# Generated at 2022-06-23 14:54:49.606662
# Unit test for constructor of class SemanticVersion

# Generated at 2022-06-23 14:54:56.625401
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert (_Numeric('0') != '0') == False
    assert (_Numeric('1') != '1') == False
    assert (_Numeric('123') != '123') == False
    assert (_Numeric('0') != 0) == False
    assert (_Numeric('1') != 1) == False
    assert (_Numeric('123') != 123) == False
    assert (_Numeric('0') != _Numeric('0')) == False
    assert (_Numeric('1') != _Numeric('1')) == False
    assert (_Numeric('123') != _Numeric('123')) == False
    assert (_Numeric('0') != '1') == True
    assert (_Numeric('1') != '2') == True
    assert (_Numeric('123') != '1234') == True

# Generated at 2022-06-23 14:54:57.827893
# Unit test for constructor of class _Numeric
def test__Numeric():
    if _Numeric('4') != 4:
        raise AssertionError("_Numeric('4') != 4")



# Generated at 2022-06-23 14:55:02.066062
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    for v1, v2 in [('', 'a'), ('a', ''), ('a', 'b'), ('b', 'a')]:
        if _Alpha(v1) != _Alpha(v2):
            pass



# Generated at 2022-06-23 14:55:04.291026
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > 'b'
    assert _Alpha('a') < 'b'
    assert _Alpha('a') > 1


# Generated at 2022-06-23 14:55:11.653867
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion("1.0.0")
    assert v1.__ne__("1.0.0") == False  # Expected {'vstring': '1.0.0', 'major': 1, 'minor': 0, 'patch': 0, 'prerelease': (), 'buildmetadata': ()} != {'vstring': '1.0.0', 'major': 1, 'minor': 0, 'patch': 0, 'prerelease': (), 'buildmetadata': ()}
    assert v1.__ne__("2.0.0") == True  # Expected {'vstring': '1.0.0', 'major': 1, 'minor': 0, 'patch': 0, 'prerelease': (), 'buildmetadata': ()} != {'vstring': '2.0.0', 'major': 2, 'minor': 0

# Generated at 2022-06-23 14:55:14.439703
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():

    assert _Numeric(1) != 2
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != _Alpha('2')



# Generated at 2022-06-23 14:55:22.145168
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    i = _Numeric(10)
    j = _Numeric(10)
    assert i == j
    assert not i != j
    assert not i < j
    assert i <= j
    assert not i > j
    assert i >= j
    j = _Numeric(1000)
    assert not i == j
    assert i != j
    assert not i > j
    assert not i >= j
    assert i < j
    assert i <= j
    j = _Numeric(1)
    assert not i == j
    assert i != j
    assert i > j
    assert i >= j
    assert not i < j
    assert not i <= j


# Generated at 2022-06-23 14:55:25.650350
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    """
    _Numeric.__eq__(self,other):

    This method returns true if two _Numeric instances are equal, else false
    """
    obj = _Numeric(2)
    assert obj == 2


# Generated at 2022-06-23 14:55:34.503953
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a1 = _Alpha('a')
    a2 = _Alpha('b')
    a3 = _Alpha('a')
    assert a1 <= a1
    assert a1 <= a2
    assert a1 <= a3
    assert a1 <= 'a'
    assert a1 <= 'b'
    assert a1 <= 'A'
    assert a1 <= 'B'

    a1 = _Alpha('A')
    a2 = _Alpha('B')
    a3 = _Alpha('1')
    a4 = _Alpha('a')
    a5 = _Alpha('1')
    a6 = _Alpha('b')
    a7 = _Alpha('B')
    assert a4 <= a4
    assert a4 <= a3
    assert a4 <= a2
    assert a4 <= a1

# Generated at 2022-06-23 14:55:38.986251
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    e1 = _Alpha("a")
    e2 = _Alpha("a")
    e3 = _Alpha("b")
    e4 = "a"

    # Same instance
    assert e1 == e1

    # Same value
    assert e1 == e2

    # Different value
    assert e1 != e3

    # String
    assert e1 == e4

    # Same value - Different type
    assert e1 != 1


# Generated at 2022-06-23 14:55:40.504566
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > '0.9.9'


# Generated at 2022-06-23 14:55:46.526549
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    class Test_Numeric_gt:
        def test_numeric_gt_simple(self):
            num = _Numeric('2')
            assert num > '1'

        def test_numeric_gt_equal(self):
            num = _Numeric('2')
            assert not num > '2'

        def test_numeric_gt_not(self):
            num = _Numeric('2')
            assert not num > '3'

    Test_Numeric_gt().test_numeric_gt_simple()
    Test_Numeric_gt().test_numeric_gt_equal()
    Test_Numeric_gt().test_numeric_gt_not()


# Generated at 2022-06-23 14:55:57.612220
# Unit test for constructor of class _Numeric
def test__Numeric():
    # i = _Numeric(10)
    s = _Numeric('10')
    assert s.specifier == 10
    assert repr(s) == '10'
    assert s == 10
    assert not s == '10'
    assert not s == 11
    assert s != '11'
    assert not s != 10
    assert s < 111
    assert s < 12
    assert not s < '11'
    assert not s < 10
    assert s <= 111
    assert s <= 12
    assert s <= 10
    assert not s <= '11'
    assert not s <= 9
    assert not s > 111
    assert not s > 12
    assert s > 9
    assert s > '9'
    assert not s > 10
    assert not s >= 111
    assert not s >= 12
    assert s >= 10

# Generated at 2022-06-23 14:55:59.369412
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha('alpha')
    assert repr(alpha) == "'alpha'"


# Generated at 2022-06-23 14:56:00.634044
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == "1"


# Generated at 2022-06-23 14:56:04.033467
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(0) > _Alpha('0')
    assert _Numeric(0) > 0
    assert not _Numeric(0) > 1

#Unit test for method __gt__ of class _Alpha

# Generated at 2022-06-23 14:56:14.892394
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-23 14:56:17.210776
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    x = SemanticVersion("0.2.10")
    y = "0.2.10"
    assert x == y



# Generated at 2022-06-23 14:56:28.602431
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    result1 = _Numeric(1) == _Numeric(2)
    result2 = _Numeric(2) == _Numeric(2)
    result3 = _Numeric(3) == _Numeric(2)
    result4 = _Numeric(3) == 3
    result5 = 3 == _Numeric(3)
    result6 = _Numeric(3) == '3'
    assert not result1, "result1 should be False, is %s" % result1
    assert result2, "result2 should be True, is %s" % result2
    assert not result3, "result3 should be False, is %s" % result3
    assert result4, "result4 should be True, is %s" % result4
    assert result5, "result5 should be True, is %s" % result5

# Generated at 2022-06-23 14:56:38.444503
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # test the examples from https://semver.org/#is-there-a-suggested-regular-expression-regex-to-check-a-semver-string

    assert SemanticVersion("1.2.3-alpha")
    assert SemanticVersion("1.2.3-alpha.3")
    assert SemanticVersion("1.2.3-beta.2")
    assert SemanticVersion("1.2.3-rc.4")
    assert SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3-5")
    assert SemanticVersion("1.2.3+build.234")
    assert SemanticVersion("1.2.3+build.234")
    assert SemanticVersion("1.2.3+build.metadata.234234234234")

# Generated at 2022-06-23 14:56:46.739513
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Test comparison of numeric and numeric
    numeric_1 = _Numeric(5)
    numeric_2 = _Numeric(5)
    numeric_3 = _Numeric(10)
    assert numeric_1 < numeric_3
    assert not (numeric_1 < numeric_2)
    assert not (numeric_3 < numeric_2)
    # Test comparison of numeric and alpha
    alpha_1 = _Alpha('a')
    alpha_2 = _Alpha('b')
    assert numeric_1 < alpha_1
    assert not (numeric_3 < alpha_2)


# Generated at 2022-06-23 14:56:50.899762
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():

    version1 = SemanticVersion('1.0.0')
    version2 = SemanticVersion('1.0.0')
    version3 = SemanticVersion('1.0.1')
    version4 = SemanticVersion('2.0.0')

    assert version1 == version2
    assert not version1 == version3
    assert not version1 == version4



# Generated at 2022-06-23 14:57:00.301415
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    result_semver_vstring_empty = SemanticVersion()
    result_semver_vstring_given = SemanticVersion('1.0')
    
    expected_result_semver_vstring_empty = 'SemanticVersion(None)'
    expected_result_semver_vstring_given = 'SemanticVersion(\'1.0\')'

    assert result_semver_vstring_empty.__repr__() == expected_result_semver_vstring_empty
    assert result_semver_vstring_given.__repr__() == expected_result_semver_vstring_given


# Generated at 2022-06-23 14:57:06.481752
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.4')
    v3 = SemanticVersion('1.3.3')
    v4 = SemanticVersion('2.2.3')
    assert v2.__gt__(v1)
    assert not v1.__gt__(v2)
    assert v3.__gt__(v1)
    assert v4.__gt__(v1)
    assert v4.__gt__(v2)
    assert v4.__gt__(v3)
    assert not v1.__gt__(v1)
    assert not v2.__gt__(v2)
    assert not v3.__gt__(v3)
    assert not v4.__gt__(v4)


# Unit test

# Generated at 2022-06-23 14:57:09.713242
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    src = '0.7.3b3'
    dst = '0.7.3b4'
    assert SemanticVersion(src) < SemanticVersion(dst), "%s > %s is false" % (src, dst)


# Generated at 2022-06-23 14:57:17.597087
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    tests = [
        # Value to test, Other value, Expected result
        (2, 3, False),
        (3, 2, False),
        (3, 3, True),
        (1, 1.0, True),
        ('1', 1, True),
        ('1', '1', True),
        ('1', '2', False),
        ('2', '1', False),
    ]
    for test in tests:
        assert _Numeric(test[0]).__eq__(test[1]) == test[2]


# Generated at 2022-06-23 14:57:20.033368
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert (_Alpha('a') > _Alpha('b')) \
           == False


# Generated at 2022-06-23 14:57:23.725995
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    arg = SemanticVersion("1.12.0")
    arg2 = "1.12.0"
    expected = False
    actual = arg.__ne__(arg2)
    assert expected == actual


# Generated at 2022-06-23 14:57:27.718804
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('abc') != _Alpha('abc')
    assert _Alpha('abc') != _Alpha('def')
    assert _Alpha('abc') != 'abc'
    assert _Alpha('abc') != 'def'
    assert _Alpha('abc') != 1
    assert _Alpha('abc') != 2
    return True


# Generated at 2022-06-23 14:57:32.434187
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= _Alpha('a')
    assert not _Alpha('a') >= 'b'
    assert not _Alpha('a') >= _Alpha('b')
    assert not _Alpha('b') >= 'a'
    assert not _Alpha('b') >= _Alpha('a')


# Generated at 2022-06-23 14:57:41.976834
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert(_Alpha('a') == 'a')
    assert(_Alpha('a') != 'b')
    assert(_Alpha('b') > _Alpha('a'))
    assert(_Alpha('a') < _Alpha('b'))
    assert(_Alpha('a') <= _Alpha('b'))
    assert(_Alpha('b') >= _Alpha('a'))
    assert(_Alpha('a') != 1)
    assert(not _Alpha('a') == 1)
    with pytest.raises(ValueError):
        assert(_Alpha('a') > 1)
    with pytest.raises(ValueError):
        assert(_Alpha('a') < 1)
    with pytest.raises(ValueError):
        assert(_Alpha('a') <= 1)
    with pytest.raises(ValueError):
        assert(_Alpha('a') >= 1)

# Generated at 2022-06-23 14:57:45.797154
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    a = _Numeric("1")
    b = _Numeric("2")
    assert a.__ge__(b), "1 >= 2 failed"
    assert b.__ge__(a), "2 >= 1 failed"
    assert a.__ge__(a), "1 >= 1 failed"


# Generated at 2022-06-23 14:57:48.559144
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    # true if v1 is less than or equal to v2
    assert v1 <= v2


# Generated at 2022-06-23 14:57:49.702352
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric("2")) == "2"


# Generated at 2022-06-23 14:57:51.909510
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    semver_obj = SemanticVersion('1.2.3')
    assert semver_obj.__repr__() == 'SemanticVersion(\'1.2.3\')'

# Generated at 2022-06-23 14:57:56.860614
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a = _Numeric('1')
    b = _Numeric('2')
    c = _Numeric('3')
    d = _Numeric('1')

    # _Numeric < _Numeric
    assert a < b
    assert a < c
    assert b < c

    # _Numeric <= _Numeric
    assert a <= d
    assert a <= b
    assert a <= c
    assert b <= c
    assert b <= c

    # _Numeric > _Numeric
    assert b > a
    assert c > a
    assert c > b

    # _Numeric >= _Numeric
    assert d >= a
    assert b >= a
    assert c >= a
    assert c >= b
    assert c >= b

    assert not a == b     # Test __eq__
    assert a != b         # Test __ne

# Generated at 2022-06-23 14:58:03.861718
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    print('unit test start: test_SemanticVersion___lt__')
    sver = SemanticVersion('1.2.3')
    assert sver.__lt__('2'), 'test_SemanticVersion___lt__ failed'
    assert not sver.__lt__('1.2.3'), 'test_SemanticVersion___lt__ failed'
    assert not sver.__lt__('1.2.3-rc'), 'test_SemanticVersion___lt__ failed'
    print('unit test passed: test_SemanticVersion___lt__')


# Generated at 2022-06-23 14:58:08.026087
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha('beta')
    b = _Alpha('alpha')
    c = _Alpha('beta')
    d = _Alpha('gamma')

    assert not a < b
    assert not a < c
    assert a < d


# Generated at 2022-06-23 14:58:12.569596
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    semver = SemanticVersion('1.2.5-alpha.1+1.a.2')
    assert semver.major == semver.minor == semver.patch == 1
    assert semver.prerelease == ('alpha', _Numeric('1'))
    assert semver.buildmetadata == (_Numeric('1'), 'a', _Numeric('2'))


# Generated at 2022-06-23 14:58:18.068879
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('b') >= _Alpha('a')
    assert not _Alpha('a') >= _Alpha('b')
    assert not _Alpha('a') >= 'b'
    assert _Alpha('b') >= 'a'


# Generated at 2022-06-23 14:58:20.514290
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    f = _Alpha("4")
    s = _Alpha("4")
    assert(f == s)
    assert(not f != s)


# Generated at 2022-06-23 14:58:29.231912
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    # Test valid versions

# Generated at 2022-06-23 14:58:33.305675
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
  assert _Numeric(0) == 0
  assert _Numeric('0') == 0
  assert not _Numeric(0) == 1
  assert not _Numeric('0') == '1'
  assert _Numeric(0) == _Numeric(0)
  assert not _Numeric(0) == _Numeric(1)
