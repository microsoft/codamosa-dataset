

# Generated at 2022-06-23 14:48:36.713924
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('0.0.1').core == (0, 0, 1)
    assert SemanticVersion('0.0.1').buildmetadata == ()
    assert SemanticVersion('0.0.1').prerelease == ()
    assert SemanticVersion('0.0.1').major == 0
    assert SemanticVersion('0.0.1').minor == 0
    assert SemanticVersion('0.0.1').patch == 1

    assert SemanticVersion('0.0.1-pre.1').core == (0, 0, 1)
    assert SemanticVersion('0.0.1-pre.1').buildmetadata == ()
    assert SemanticVersion('0.0.1-pre.1').prerelease == ('pre', '1')
    assert SemanticVersion('0.0.1-pre.1').major == 0
   

# Generated at 2022-06-23 14:48:48.132242
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Provided by LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.1')).vstring == '1.0.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.0')).vstring == '1.1.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')).vstring == '1.1.1'

    # Provided by SemanticVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-23 14:48:49.301760
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('A')) == repr(str('A'))



# Generated at 2022-06-23 14:48:55.430413
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')



# Generated at 2022-06-23 14:49:04.616337
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion("1.0") >= text_type("1.0")
    assert SemanticVersion("1.0.0") >= text_type("1.0")
    assert SemanticVersion("1.0.0") >= text_type("1.0.0")
    assert SemanticVersion("1.0.1") >= text_type("1.0")
    assert SemanticVersion("1.0.1") >= text_type("1.0.0")
    assert SemanticVersion("1.0") >= SemanticVersion("1.0")
    assert SemanticVersion("1.0.0") >= SemanticVersion("1.0")
    assert SemanticVersion("1.0.0") >= SemanticVersion("1.0.0")
    assert SemanticVersion("1.0.1") >= SemanticVersion("1.0")

# Generated at 2022-06-23 14:49:15.142596
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import pytest
    from ansible.module_utils.six.moves.urllib.parse import urlparse


# Generated at 2022-06-23 14:49:16.568372
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('beta') < _Alpha('gamma')
    assert not _Alpha('gamma') < _Alpha('alpha')


# Generated at 2022-06-23 14:49:20.430761
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a = SemanticVersion('1.2.3-beta.1+build.1')
    b = SemanticVersion('1.2.3-beta.1+build.2')
    assert not a <= b


if __name__ == '__main__':
    test_SemanticVersion___le__()

# Generated at 2022-06-23 14:49:21.842329
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    specifier = _Numeric(1)
    assert not specifier.__ne__(1)


# Generated at 2022-06-23 14:49:24.246563
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    semver = SemanticVersion('1.2.3')
    assert semver != '1.2.4'


# Generated at 2022-06-23 14:49:26.120730
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    obj = _Numeric(0)
    assert (obj.__repr__() == '0')


# Generated at 2022-06-23 14:49:35.811971
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('2.0.0') != SemanticVersion('1.0.0')

    # 1.0.0
    assert SemanticVersion('1.0.0') == (1, 0, 0)
    assert SemanticVersion('1.0.0') > (0, 0, 0)
    assert SemanticVersion('1.0.0') > (0, 1, 0)
    assert SemanticVersion('1.0.0') > (1, 0, 0)
    assert SemanticVersion('1.0.0') > (1, 0, 1)
    assert SemanticVersion('1.0.0') < (1, 1, 0)

# Generated at 2022-06-23 14:49:41.688869
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    case_1 = _Numeric('1') <= _Numeric('2')
    case_2 = _Numeric('1') <= 1
    case_3 = _Numeric('1') <= 2
    case_4 = _Numeric('1') <= _Alpha('1')
    case_5 = _Numeric(1) <= _Alpha('2')
    case_6 = _Numeric(1) <= _Alpha('1')

    assert(case_1 and case_2 and case_3 and case_4 and case_5 and case_6)


# Generated at 2022-06-23 14:49:43.946721
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == '1'
    assert repr(_Numeric('1.1')) == '1'


# Generated at 2022-06-23 14:49:49.905324
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    n1_again = _Numeric(1)
    a1 = _Alpha('1')
    n2_again = _Numeric(2)
    assert n1 <= n2
    assert n1 <= a1
    assert n1 <= n1_again
    assert n2 <= n2_again
    assert not n2 <= n1
    assert not n2 <= a1


# Generated at 2022-06-23 14:50:00.269409
# Unit test for method __lt__ of class _Alpha

# Generated at 2022-06-23 14:50:01.671904
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)


# Generated at 2022-06-23 14:50:09.466180
# Unit test for method __ge__ of class _Numeric

# Generated at 2022-06-23 14:50:17.907130
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a1 = SemanticVersion("0.0.1")
    a2 = SemanticVersion("0.0.2")
    b1 = SemanticVersion("1.0.0")
    b2 = SemanticVersion("2.0.0")
    c1 = SemanticVersion("1.0.0-dev")
    c2 = SemanticVersion("1.0.3-dev")
    c3 = SemanticVersion("1.0.3")
    c4 = SemanticVersion("1.0.3-alpha")
    d1 = SemanticVersion("1.0.0+foo")
    d2 = SemanticVersion("1.0.0+bar")
    e1 = SemanticVersion("0.0.1-alpha")
    e2 = SemanticVersion("1.0.1-alpha")
    e3 = Sem

# Generated at 2022-06-23 14:50:26.239719
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    import unittest
    class TestSemanticVersionParse(unittest.TestCase):

        def test_parse_0(self):
            # semver: 0.0.0
            v = SemanticVersion('0.0.0')
            self.assertEqual(v.major, 0)
            self.assertEqual(v.minor, 0)
            self.assertEqual(v.patch, 0)
            self.assertEqual(v.prerelease, ())
            self.assertEqual(v.buildmetadata, ())

        def test_parse_1(self):
            # semver: 1.0.0
            v = SemanticVersion('1.0.0')
            self.assertEqual(v.major, 1)
            self.assertEqual(v.minor, 0)

# Generated at 2022-06-23 14:50:30.174270
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    cmp = SemanticVersion("1.0.0-alpha-1")
    assert cmp.__repr__() == repr("1.0.0-alpha-1")


# Generated at 2022-06-23 14:50:33.883695
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) != 1
    assert _Numeric(1) == 1
    assert 1 != _Numeric(1)
    assert 1 == _Numeric(1)


# Generated at 2022-06-23 14:50:42.133495
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import cStringIO
    import sys

    # redirecting stdout to cStringIO buffer
    stdout_old = sys.stdout
    sys.stdout = cStringIO()


# Generated at 2022-06-23 14:50:50.336912
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test defaults
    version = SemanticVersion()
    assert version.vstring is None
    assert version.major is None
    assert version.minor is None
    assert version.patch is None
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # Test invalid versions
    for vstring in ('',):
        try:
            version = SemanticVersion(vstring)
        except ValueError:
            assert True
        else:
            assert False

    # Test valid versions

# Generated at 2022-06-23 14:50:56.862752
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    try:
        SemanticVersion('v1.2.3')
    except ValueError as e:
        assert str(e) == 'invalid semantic version \'v1.2.3\''
    else:
        assert False

    v = SemanticVersion('1.2.3')
    assert v.vstring == '1.2.3'
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion('1.2.3-alpha.7')
    assert v.vstring == '1.2.3-alpha.7'
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3

# Generated at 2022-06-23 14:50:59.456289
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    s = SemanticVersion(vstring='1.0.0')
    assert not (s != '1.0.0')


# Generated at 2022-06-23 14:51:03.616416
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion()
    assert "SemanticVersion(None)" == v.__repr__()
    v = SemanticVersion('2.0.0')
    assert "SemanticVersion('2.0.0')" == v.__repr__()


# Generated at 2022-06-23 14:51:05.536071
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha(specifier='specifier')) == 'specifier'


# Generated at 2022-06-23 14:51:08.881163
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    """
    Method __gt__ of class _Alpha should return True for comparison between two
    members of class _Alpha should return True
    """
    aa = _Alpha('a')
    ab = _Alpha('b')

    assert aa < ab



# Generated at 2022-06-23 14:51:12.168688
# Unit test for constructor of class _Alpha
def test__Alpha():
    try:
        alpha = _Alpha('1.2')
    except:
        assert(False)
    else:
        assert(isinstance(alpha, _Alpha))
        assert(alpha.specifier == '1.2')


# Generated at 2022-06-23 14:51:13.711886
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('first') == _Alpha('first')
    assert _Alpha('first') == 'first'



# Generated at 2022-06-23 14:51:16.458410
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # Arrange
    v = _Alpha('alpha0')
    w = _Alpha('alpha')

    # Act
    result = v > w

    # Assert
    assert result is True


# Generated at 2022-06-23 14:51:23.086176
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import collections
    import unittest
    class TestCase(unittest.TestCase):
        class MyLooseVersion(LooseVersion):
            "LooseVersion but with no normalization."

            def __init__(self, version):
                self.parse(version)

            def parse(self, version):
                self.version = tuple([int(x) for x in version.split('.')])

        def test_from_loose_version_with_LooseVersion(self):
            self.assertEqual(
                SemanticVersion.from_loose_version(LooseVersion('1.0.0')),
                SemanticVersion('1.0.0')
            )


# Generated at 2022-06-23 14:51:26.041103
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('foo') != _Alpha('foo')
    assert _Alpha('foo') != 'foo'
    assert _Alpha('foo') != _Numeric('foo')


# Generated at 2022-06-23 14:51:32.092326
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    semver = SemanticVersion('1.0.0')
    loose = LooseVersion('1.0.0')
    assert semver <= '1.0.0'
    assert semver <= loose
    assert semver <= '1.0'
    assert semver <= '1'

    semver = SemanticVersion('1.0.0')
    loose = LooseVersion('1.0.0')
    assert semver >= '1.0.0'
    assert semver >= loose
    assert semver >= '1.0'
    assert semver >= '1'

# Generated at 2022-06-23 14:51:38.328136
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    sv1 = SemanticVersion('0.0.1')
    sv2 = SemanticVersion('0.1.0')
    sv3 = SemanticVersion('1.0.0')
    # This test is not working with Python < 3.5.0
    # Py2.7 has a different cmp() function than py3.x
    # This is implemented in 4.0.0
    # https://docs.python.org/3/whatsnew/3.0.html#ordering-comparisons
    if not ((sv1 < sv2) and (sv2 < sv3)):
        raise AssertionError("SemanticVersion not ordering as expected")


# Generated at 2022-06-23 14:51:41.339796
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert not _Numeric(2) <= _Numeric(1)


# Generated at 2022-06-23 14:51:47.623428
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')) == SemanticVersion('1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1.dev0')) == SemanticVersion('1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1.0')) == SemanticVersion('1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1.1')) == SemanticVersion('1.1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1.rc.2')) == SemanticVersion('1.1.1-rc.2')

# Generated at 2022-06-23 14:51:51.588837
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha("test")
    if not repr(alpha) == repr("test"):
        print("Bad result in method __repr__ of class _Alpha")
        print("Expected:", repr("test"))
        print("Received:", repr(alpha))



# Generated at 2022-06-23 14:52:02.123123
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils._text import to_text

    # Test with invalid semantic version
    for version in (1, True, None):
        exception = None
        try:
            SemanticVersion.from_loose_version(version)
        except ValueError as e:
            exception = e
        assert exception is not None, 'version = %r' % version

    # Test a variety of known LooseVersions to make sure they convert as expected
    class LooseVersion_Test(LooseVersion):
        """Test class used to override LooseVersion to simplify unit test
        """
        def __init__(self, vstring):
            self.vstring = vstring
            self.version = list(map(text_type, vstring.split('.')))


# Generated at 2022-06-23 14:52:13.741014
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('2.0.0') >= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0')
    assert SemanticVersion('2.0.0') >= SemanticVersion('1.99.0')
    assert SemanticVersion('1.99.0') >= SemanticVersion('1.99.0')
    assert SemanticVersion('1.0.0') >= SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') >= SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') >= SemanticVersion('0.0.0-beta')
    assert SemanticVersion('0.0.0-beta') >= SemanticVersion('0.0.0-beta')
   

# Generated at 2022-06-23 14:52:23.937468
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():

    def _cmp(left, right):
        return left.__le__(right)

    def _test(left, right, expected):
        name = '%s <= %s' % (left, right)
        result = _cmp(left, right)
        if result != expected:
            print('FAIL: %s' % name)
            print('Expected: %s' % expected)
            print('Received: %s' % result)

    _Numeric = SemanticVersion._Numeric

    int_1 = _Numeric(1)
    int_2 = _Numeric(2)

    # Comparisons of _Numeric to _Numeric
    _test(int_1, int_1, True)
    _test(int_1, int_2, True)

# Generated at 2022-06-23 14:52:32.532573
# Unit test for constructor of class _Numeric
def test__Numeric():

    # test basic comparison
    # 1 < 2
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1).specifier < 2

    # 2 > 1
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(2).specifier > 1

    # 1 == 1
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1).specifier == 1

    # 1 <= 1
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1).specifier <= 1

    # 1 <= 2
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1).specifier <= 2

    # 1 >= 1
    assert _Numeric(1) >= _Numeric

# Generated at 2022-06-23 14:52:34.533234
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(1)
    assert a.__ne__(2)
    assert not a.__ne__(1)
    assert a.__ne__('1')


# Generated at 2022-06-23 14:52:40.521575
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion('1.2.3')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version = SemanticVersion('1.2.3-4.5.6')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Numeric('4'), _Numeric('5'), _Numeric('6'))
    assert version.buildmetadata == ()

    version = SemanticVersion('1.2.3-alpha.1.2+build.1.2')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3

# Generated at 2022-06-23 14:52:43.695961
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert version.vstring == '1.2.3'

# Generated at 2022-06-23 14:52:47.766963
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    num_obj = _Numeric(1)
    num_obj2 = _Numeric(2)
    num_obj_string = _Numeric("2")
    str_obj = _Alpha("1")
    assert num_obj < num_obj2
    assert num_obj < num_obj_string
    assert num_obj < str_obj


# Generated at 2022-06-23 14:52:51.129296
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    # Create an instance of _Alpha with specifier '_Alpha'
    test_obj = _Alpha('_Alpha')
    # Verify that __repr__ is what we expect
    assert test_obj.__repr__() == '_Alpha'


# Generated at 2022-06-23 14:52:55.013700
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # setup
    _SV = SemanticVersion(vstring=None)
    _SV.vstring = '0.0.1'

    # exercise
    actual = _SV.__repr__()

    # verify
    expected = "SemanticVersion('0.0.1')"
    assert actual == expected



# Generated at 2022-06-23 14:52:59.556411
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a = _Numeric(7)
    b = _Numeric(7)
    assert a.__le__(b)
    b = _Numeric(3)
    assert not a.__le__(b)


# Generated at 2022-06-23 14:53:04.418100
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion('1.0.0-rc.2+build.345').__repr__() == 'SemanticVersion(\'1.0.0-rc.2+build.345\')'
    assert SemanticVersion('1.5.23').__repr__() == 'SemanticVersion(\'1.5.23\')'


# Generated at 2022-06-23 14:53:11.583742
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # From https://semver.org/#spec-item-11

    assert SemanticVersion('1.0.0-alpha') == SemanticVersion('1.0.0-alpha')
    assert not SemanticVersion('1.0.0-alpha') == SemanticVersion('1.0.0-alpha.1')

    assert not SemanticVersion('1.0.0-alpha') == SemanticVersion('1.0.0-alpha.1')
    assert not SemanticVersion('1.0.0-alpha.1') == SemanticVersion('1.0.0-alpha.beta')
    assert not SemanticVersion('1.0.0-alpha.1') == SemanticVersion('1.0.0-beta')

# Generated at 2022-06-23 14:53:13.172711
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    a = _Alpha('test')
    assert repr(a) == "'test'"


# Generated at 2022-06-23 14:53:19.930527
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    assert SemanticVersion('1.2.3.4.5').core == (1, 2, 3)
    assert SemanticVersion('1.2.3-4.5').prerelease == (4, 5)
    assert SemanticVersion('1.2.3+4.5').buildmetadata == (4, 5)
    assert SemanticVersion('1.2.3-alpha').prerelease == ('alpha',)
    assert SemanticVersion('1.2.3-alpha.beta').prerelease == ('alpha', 'beta')


# Generated at 2022-06-23 14:53:21.027537
# Unit test for constructor of class _Alpha
def test__Alpha():
    obj = _Alpha("0")
    return True


# Generated at 2022-06-23 14:53:31.997027
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a1 = _Alpha("a")
    a2 = _Alpha("a")
    b = _Alpha("b")
    na1 = _Alpha("hello")
    na2 = _Alpha("hello")
    nb = _Alpha("world")

    assert a1 < b
    assert a1 <= b
    assert a1 <= a1
    assert a1 <= a2
    assert a2 <= a2
    assert a1 <= na1
    assert na1 <= na2

    assert na1 > nb
    assert na1 >= nb
    assert na1 >= na1
    assert na1 >= na2
    assert na2 >= na2
    assert na1 >= b
    assert nb >= b
    assert na1 >= a1
    assert nb >= a1


# Generated at 2022-06-23 14:53:33.311133
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha(1) != _Alpha(2)

# Generated at 2022-06-23 14:53:35.405057
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1').specifier == 1
    assert _Numeric(1).specifier == 1


# Generated at 2022-06-23 14:53:44.234977
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    x = SemanticVersion(vstring='1.2.3')
    assert x.__le__(x)
    assert x.__le__(SemanticVersion(vstring='1.2.3'))
    assert x.__le__(SemanticVersion(vstring='1.2'))
    assert x.__le__(SemanticVersion(vstring='1'))
    assert x.__le__(SemanticVersion(vstring='1.2.4'))
    assert x.__le__(SemanticVersion(vstring='1.3.3'))
    assert x.__le__(SemanticVersion(vstring='2.2.3'))

    assert x.__le__('1.2.3')
    assert x.__le__('1.2')
    assert x.__le__('1')


# Generated at 2022-06-23 14:53:48.736149
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    arg1 = SemanticVersion("1.0.0-alpha")
    arg2 = "1.0.0-beta"
    assert arg1.__ne__(arg2)


# Generated at 2022-06-23 14:53:55.516226
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('b').__ge__('a')
    assert not _Alpha('b').__ge__('c')
    assert _Alpha('b').__ge__(_Alpha('a'))
    assert not _Alpha('b').__ge__(_Alpha('c'))
    try:
        _Alpha('b').__ge__(3)
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')


# Generated at 2022-06-23 14:54:00.696319
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'

# Generated at 2022-06-23 14:54:07.547216
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    v3 = SemanticVersion('1.2.3-alpha')
    v4 = SemanticVersion('1.2.3-alpha.1')
    v5 = SemanticVersion('1.2.3-beta')
    v6 = SemanticVersion('1.2.3-beta.1')
    v7 = SemanticVersion('1.2.3-beta.2')
    v8 = SemanticVersion('1.2.3-rc')
    v9 = SemanticVersion('1.2.3-rc.1')
    v10 = SemanticVersion('1.2.3+build')
    v11 = SemanticVersion('1.2.3+build.1')
    v12 = Semantic

# Generated at 2022-06-23 14:54:16.785097
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    """
    Test the method _Numeric.__gt__

    """
    assert _Numeric(3).__gt__(_Numeric(4))
    assert _Numeric(3).__gt__(4)
    assert _Numeric(3).__gt__(_Alpha('4'))
    assert _Numeric('3').__gt__(_Alpha('4'))
    assert not _Numeric(4).__gt__(_Numeric(4))
    assert not _Numeric(4).__gt__(4)

    try:
        _Numeric(3).__gt__(None)
        assert False
    except:
        assert True

    try:
        _Numeric(3).__gt__(3.3)
        assert False
    except:
        assert True



# Generated at 2022-06-23 14:54:19.950735
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric("1") != "1"
    assert not _Numeric("1") == "1"


# Generated at 2022-06-23 14:54:20.788129
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    return True
    assert True is True


# Generated at 2022-06-23 14:54:21.963397
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha('test').__repr__() == repr('test')


# Generated at 2022-06-23 14:54:23.705666
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha("abc")
    b = _Alpha("xyz")
    assert a < b


# Generated at 2022-06-23 14:54:26.931841
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert not _Alpha('a') >= _Alpha('b')
    assert _Alpha('b') >= _Alpha('a')

    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') >= 'b'
    assert _Alpha('b') >= 'a'


# Generated at 2022-06-23 14:54:30.284911
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < _Alpha('2')
    assert _Numeric('1') < 2


# Generated at 2022-06-23 14:54:37.914058
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    # instance created
    a = _Alpha('a')
    # instance created
    b = _Alpha('a')
    try:
        # equal instances comparison
        eq_(a.__ne__(b), False)

    except AssertionError as e:
        # exception handler
        raise AssertionError(e)
    except Exception as e:
        # exception handler
        print('Warning, unexpected exception')
        raise
    else:
        pass
    finally:
        pass



# Generated at 2022-06-23 14:54:48.406815
# Unit test for constructor of class _Alpha
def test__Alpha():
    # Slicing should strip out the 'v'
    a1 = _Alpha('v1.2.3')
    assert(a1.specifier == '1.2.3')

    a2 = _Alpha('1.2.3')
    assert(a2.specifier == '1.2.3')

    # Should be able to compare one _Alpha to another
    assert(a1 == a2)

    # Should be able to compare one _Alpha to a string
    assert(a1 == '1.2.3')
    assert(a2 == '1.2.3')

    # Should be able to compare one _Alpha to a strint (u'1.2.3')
    assert(a1 == u'1.2.3')
    assert(a2 == u'1.2.3')

    # Should not

# Generated at 2022-06-23 14:54:49.531928
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(3) != "3"


# Generated at 2022-06-23 14:54:51.237616
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha("1.0.0")
    assert repr(alpha) == "1.0.0"


# Generated at 2022-06-23 14:54:52.982373
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1') == 1
    assert _Numeric('1') != '1'


# Generated at 2022-06-23 14:55:02.508914
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    from nose.tools import assert_equal, assert_not_equal
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.0")
    assert_equal(v1, v2)
    v2 = SemanticVersion("1.0.0-alpha+build.metadata")
    assert_equal(v1, v2)
    v2 = SemanticVersion("1.0.0-alpha.1+build.metadata")
    assert_equal(v1, v2)
    v2 = SemanticVersion("1.0.0-0.3.7+build.metadata")
    assert_equal(v1, v2)
    v2 = SemanticVersion("1.0.0-alpha.alpha+build.metadata")
    assert_equal(v1, v2)



# Generated at 2022-06-23 14:55:04.965281
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.2.3') <= SemanticVersion('2.3.4')

test_SemanticVersion___le__()



# Generated at 2022-06-23 14:55:06.108324
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion()) == 'SemanticVersion(None)'


# Generated at 2022-06-23 14:55:14.998777
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    val1 = _Numeric(3)
    val2 = _Numeric(3)
    val3 = _Numeric(2)
    val4 = _Alpha(1)
    val5 = _Alpha(3)
    val6 = _Alpha('3')

    assert val1.__ne__(val2) == False
    assert val1.__ne__(val3) == True
    assert val1.__ne__(val4) == False
    assert val1.__ne__(val5) == True
    assert val1.__ne__(val6) == True

# Generated at 2022-06-23 14:55:22.406009
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    v = SemanticVersion('0.0.0-1.0')
    assert v.major == 0
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Numeric('1'), _Numeric('0'))
    assert v.buildmetadata == ()
    assert v._cmp(v) == 0
    assert v.__eq__(v) is True
    assert v.__ne__(v) is False
    assert v.__lt__(v) is False
    assert v.__le__(v) is True
    assert v.__gt__(v) is False
    assert v.__ge__(v) is True
    assert v.is_prerelease is True
    assert v.is_stable is False



# Generated at 2022-06-23 14:55:26.913014
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) >= _Numeric(1)


# Generated at 2022-06-23 14:55:29.505786
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('1') >= _Numeric('1')
    assert _Numeric('1') >= _Numeric('0')
    assert not _Numeric('0') >= _Numeric('1')


# Generated at 2022-06-23 14:55:37.636248
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # Test valid version strings
    test_str = ['1.0', '1.2.3', '1.2.3-alpha', '1.2.3-alpha.1', '1.2.3-0.3.7', '1.2.3-x.7.z.92', '1.2.3+build', '1.2.3+build.2.b8f12d7', '1.2.3-beta+build.11.e0f985a']
    for i in test_str:
        SemanticVersion(i)

    # Test invalid version strings

# Generated at 2022-06-23 14:55:45.424898
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion with extra text
    loose_version = LooseVersion('1.0.0.b1')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0-b1'

    # LooseVersion without extra text
    loose_version = LooseVersion('1.0.0')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0'

    # Invalid loose version
    loose_version = LooseVersion('1.0.0.b1+')
    try:
        SemanticVersion.from_loose_version(loose_version).vstring
    except ValueError:
        pass
    else:
        raise AssertionError('LooseVersion with extra text did not raise ValueError')

#

# Generated at 2022-06-23 14:55:49.691279
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alpha1 = _Alpha("alpha")
    alpha2 = _Alpha("beta")
    assert alpha1 < alpha2
    assert not alpha1 > alpha2
    assert not alpha1 == alpha2
    assert alpha1 != alpha2


# Generated at 2022-06-23 14:55:59.797550
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= '1.0.0'
    assert not SemanticVersion('1.0.0') <= '0.0.1'
    assert not SemanticVersion('1.0.0') <= '1.0.0-beta+build.1'
    assert SemanticVersion('1.0.0-beta+build.1') <= '1.0.0-beta+build.1'
    assert not SemanticVersion('1.0.0-beta+build.1') <= '1.0.0-beta'
    assert SemanticVersion('1.0.0-beta') <= '1.0.0-beta'
    assert SemanticVersion('1.0.0-beta') <= '1.0.0-beta.2'

# Generated at 2022-06-23 14:56:11.331549
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    loose_version = LooseVersion('1.4.0')

    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.4.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.4.0.0.0')) == SemanticVersion('1.4.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.4.0-alpha.5')) == SemanticVersion('1.4.0-alpha.5')
    assert SemanticVersion.from_loose_version(LooseVersion('1.4.0+abc')) == SemanticVersion('1.4.0+abc')
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-23 14:56:13.043567
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    vstring = '1.0.0'
    semver = SemanticVersion(vstring)
    result = semver.__ge__(vstring)
    assert result == True


# Generated at 2022-06-23 14:56:13.933218
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('alpha')) == repr('alpha')


# Generated at 2022-06-23 14:56:15.452412
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
  assert SemanticVersion('1.2.3').__ge__('1.2.2') == True


# Generated at 2022-06-23 14:56:18.011318
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric("4")
    assert a > 3, "should return true"
    assert not a > "4", "should return false"


# Generated at 2022-06-23 14:56:29.734817
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
	with pytest.raises(TypeError):
		assert _Alpha('1') == 1
		assert _Alpha('1') == '1'
		assert _Alpha('1') != _Numeric('1')
		assert _Alpha('1') != _Alpha('1')
		assert _Alpha('1') == '1'
		assert _Alpha('1') != '1.1'
		assert _Alpha('1') != '2'
		assert _Alpha('a') != _Alpha('b')
		assert _Alpha('a') == 'a'
		assert _Alpha('a') != 'b'
		assert _Alpha('a.1') != 'a.1'
		assert _Alpha('a.1') != 'b.1'
		assert _Alpha('a.1') != 'a.2'

# Generated at 2022-06-23 14:56:39.158356
# Unit test for method __le__ of class SemanticVersion

# Generated at 2022-06-23 14:56:43.819258
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha("1.2.3") == _Alpha("1.2.3")
    assert not _Alpha("a") == _Alpha("a")
    assert not _Alpha("a") == "a"
    assert _Alpha("a") != _Alpha("b")
    assert _Alpha("a") != "b"


# Generated at 2022-06-23 14:56:52.492068
# Unit test for constructor of class _Alpha
def test__Alpha():
    # Test constructors 
    assert _Alpha('47') == '47'
    assert _Alpha('47') != 47
    # Test repr 
    assert repr(_Alpha('47')) == repr('47')
    # Test comparison operators 
    assert _Alpha('47') == _Alpha('47')
    assert _Alpha('47') == '47'
    assert _Alpha('47') != 47
    assert _Alpha('47') != _Alpha('48')
    assert _Alpha('47') != '48'
    assert _Alpha('47') < '48'
    assert _Alpha('47') < _Alpha('48')
    assert _Alpha('47') <= _Alpha('47')
    assert _Alpha('47') <= '47'
    assert not _Alpha('47') > '48'
    assert not _Alpha('47') > _Alpha('48')


# Generated at 2022-06-23 14:56:55.294827
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    semanticversion = SemanticVersion('1.0.0')
    assert repr(semanticversion) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-23 14:57:00.056942
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    """
    Ensure we can compare strings
    """
    alpha_a = _Alpha('a')
    alpha_b = _Alpha('b')
    assert alpha_a < alpha_b
    assert alpha_b > alpha_a
    assert alpha_a <= alpha_b
    assert alpha_b >= alpha_a



# Generated at 2022-06-23 14:57:03.937505
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) >= _Numeric(1)


# Generated at 2022-06-23 14:57:06.283599
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert not _Numeric(0) == None
    assert not _Numeric(0) == 0.0
    assert not _Numeric(0) == _Numeric(0.0)

    assert _Numeric(0) == _Numeric(0)
    assert _Numeric(0) == 0


# Generated at 2022-06-23 14:57:08.189451
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    if not _Numeric(42) != _Numeric(42):
        raise Exception('Unit test for method __ne__ of class _Numeric failed!')


# Generated at 2022-06-23 14:57:11.266735
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    numeric = _Numeric('1')
    assert _Numeric('1') != numeric


# Generated at 2022-06-23 14:57:17.502132
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric("1") <= _Numeric("1")
    assert _Numeric("1") <= _Numeric("2")

    assert _Numeric("1") <= _Alpha("2")
    assert _Numeric("1") <= _Alpha("1")
    assert _Numeric("1") <= _Alpha("a")
    assert _Numeric("1") <= _Alpha("1a")
    assert _Numeric("1") <= _Alpha("a1")


# Generated at 2022-06-23 14:57:23.009139
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')
    assert _Alpha('a') != 'b'
    assert 'b' != _Alpha('a')
    assert _Alpha(1) != 1
    assert _Alpha(1) != _Alpha(1)



# Generated at 2022-06-23 14:57:24.266101
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') >= '1.0.0'


# Generated at 2022-06-23 14:57:33.036647
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    import json
    import sys

    sys.stderr.write(json.dumps({
        "DEBUG": False,
        "changed": False,
        "msg": "The module has been received and is being processed",
    }, indent=4))

    success = True

    # The data to be used in the test

# Generated at 2022-06-23 14:57:37.650826
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    
    # Successful conversion.
    s = SemanticVersion.from_loose_version(LooseVersion("0.12.0+dev.20180601"))
    assert(s.vstring == "0.12.0")

    # Unsuccessful conversion
    s = None
    try:
        s = SemanticVersion.from_loose_version("0.12.0")
    except ValueError:
        pass
    assert(s is None)

    s = None
    try:
        s = SemanticVersion.from_loose_version("0.12.0+a.b.c")
    except ValueError:
        pass
    assert(s is None)

# Generated at 2022-06-23 14:57:47.362000
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion, StrictVersion

# Generated at 2022-06-23 14:57:48.792715
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(text_type(1)) == "1"


# Generated at 2022-06-23 14:57:54.594091
# Unit test for constructor of class _Alpha

# Generated at 2022-06-23 14:58:04.109928
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert SemanticVersion._Numeric(1) == SemanticVersion._Numeric('1')
    assert SemanticVersion._Numeric(1) != SemanticVersion._Numeric('2')
    assert SemanticVersion._Numeric('1') < SemanticVersion._Numeric('2')
    assert SemanticVersion._Numeric('1') <= SemanticVersion._Numeric('2')
    assert SemanticVersion._Numeric('1') <= SemanticVersion._Numeric('1')
    assert SemanticVersion._Numeric('1') > SemanticVersion._Numeric('0')
    assert SemanticVersion._Numeric('1') >= SemanticVersion._Numeric('1')
    assert SemanticVersion._Numeric('2') >= SemanticVersion._Numeric('1')


# Generated at 2022-06-23 14:58:09.253459
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion()) == 'SemanticVersion(None)'
    assert repr(SemanticVersion('1.0.0')) == "SemanticVersion('1.0.0')"
    assert repr(SemanticVersion(u'1.0.0')) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-23 14:58:17.763716
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    '''
    Should return True if the specifier is not equal to the other specifier.
    '''
    # should return false if other is an _Alpha
    assert _Alpha('1.0.0').__ne__(_Alpha('1.0.0')) == False
    # should return false if other is a string
    assert _Alpha('1.0.0').__ne__('1.0.0') == False
    # should return true if other isn't an _Alpha or string
    assert _Alpha('1.0.0').__ne__(1.0) == True


# Generated at 2022-06-23 14:58:20.262372
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    numeric = _Numeric(123)
    assert numeric.__repr__() == '(123,)', '_Numeric.__repr__()'


# Generated at 2022-06-23 14:58:24.161905
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert not _Alpha('1') == 1
    assert _Alpha('1') == '1'
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == _Alpha('a')
    assert not _Alpha('a') == _Alpha('b')


# Generated at 2022-06-23 14:58:33.517159
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    """Unit test for method __le__ of class _Alpha"""
    # equality against string
    _Alpha('a') <= 'a'

    # less than against string
    _Alpha('a') <= 'b'

    # less than against numeric
    _Alpha('a') <= _Numeric('0')

    try:
        _Alpha('a') <= _Numeric('a')
    except ValueError:
        pass
    else:
        assert False, "ValueError should be raised"

    # equality against _Alpha
    _Alpha('a') <= _Alpha('a')

    # less than against _Alpha
    _Alpha('a') <= _Alpha('b')
