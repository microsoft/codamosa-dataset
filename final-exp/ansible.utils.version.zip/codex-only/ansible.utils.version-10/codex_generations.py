

# Generated at 2022-06-23 14:48:39.765748
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.0.0').vstring == '1.0.0'
    try:
        SemanticVersion('gibberish')
    except ValueError as e:
        assert e.args[0] == "invalid semantic version 'gibberish'"
    try:
        SemanticVersion('1.04.0-rc.1')
    except ValueError as e:
        assert e.args[0] == "invalid semantic version '1.04.0-rc.1'"
    try:
        SemanticVersion('1.0.0-%')
    except ValueError as e:
        assert e.args[0] == "invalid semantic version '1.0.0-%'"

# Generated at 2022-06-23 14:48:46.234564
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    # If a < b and a != b, then a <= b is true.
    assert _Numeric(1) <= _Numeric(2)

    # If a < b but a == b, then a <= b is true.
    assert _Numeric(1) <= _Numeric(1)

    # If a > b, then a <= b is false.
    assert not _Numeric(2) <= _Numeric(1)


# Generated at 2022-06-23 14:48:48.731921
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    ver = SemanticVersion('1.24.39')
    assert repr(ver) == 'SemanticVersion(\'1.24.39\')'


# Generated at 2022-06-23 14:48:53.288837
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    obj_a = _Alpha("foo")
    obj_b = _Alpha("foo")
    assert obj_a == obj_b
    assert obj_a.specifier == obj_b.specifier
    assert not (obj_a != obj_b)


# Generated at 2022-06-23 14:48:55.710576
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    version1 = SemanticVersion('0.0.1')
    version2 = SemanticVersion('0.0.1')
    assert version1 == version2


# Generated at 2022-06-23 14:48:59.390284
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert not _Numeric("1") > _Numeric("1")
    assert not _Numeric("1") > _Numeric("2")
    assert _Numeric("2") > _Numeric("1")
    assert _Numeric("2") > _Alpha("1")


# Generated at 2022-06-23 14:49:08.416893
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('0') < _Numeric('1')
    assert _Numeric('1') < _Numeric('2')

    assert _Numeric('0') < _Alpha('1')
    assert _Numeric('1') < _Alpha('2')
    assert _Numeric('0') < _Alpha('0a')
    assert _Numeric('1') < _Alpha('1a')

    assert _Numeric('1') < _Alpha('1b')
    assert _Numeric('1') < _Alpha('11')

    assert _Numeric('0') < '1'
    assert _Numeric('1') < '2'

    assert _Numeric('0') < 1
    assert _Numeric('1') < 2

    try:
        assert _Numeric('1') < 'a'
    except ValueError:
        pass


# Generated at 2022-06-23 14:49:11.341724
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion('2.2.0')
    v2 = SemanticVersion('2.2.1')
    assert v1 <= v2



# Generated at 2022-06-23 14:49:14.427305
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Verify that two instances of SemanticVersion with the same data
    # are equal
    v1 = SemanticVersion('1.2.3-alpha.0')
    v2 = SemanticVersion('1.2.3-alpha.0')

    assert v1.__eq__(v2)



# Generated at 2022-06-23 14:49:15.742203
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha('1').__eq__('1')


# Generated at 2022-06-23 14:49:23.697595
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Test of comparison with strings
    assert SemanticVersion('1.0.0') < '1.1.0'
    assert SemanticVersion('1.1.0') < '2.0.0'
    assert SemanticVersion('1.0.0') < '2.0.0'
    assert not SemanticVersion('1.0.0') < '0.0.0'
    assert not SemanticVersion('1.0.0') < '1.0.0'
    assert not SemanticVersion('1.0.1') < '1.0.0'

    # Test of comparison with a loose version
    assert SemanticVersion('1.0.0') < LooseVersion('1.1.0')
    assert SemanticVersion('1.1.0') < LooseVersion('2.0.0')
    assert Semantic

# Generated at 2022-06-23 14:49:25.395114
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != _Alpha('z')


# Generated at 2022-06-23 14:49:28.672034
# Unit test for constructor of class _Numeric
def test__Numeric():
    # Test creation of numeric from numeric
    numeric = _Numeric(1)
    assert numeric == 1

    # Test creation of numeric from string
    numeric = _Numeric('1')
    assert numeric == 1



# Generated at 2022-06-23 14:49:31.883713
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert 'a' > 'b'
    assert not _Alpha('a') > 'b'
    assert _Alpha('a') > _Alpha('b')
    assert not _Alpha('a') > _Alpha('a')


# Generated at 2022-06-23 14:49:36.928169
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') >= _Alpha('a')

    assert not _Alpha('b') < _Alpha('a')
    assert not _Alpha('b') < 'a'
    assert not _Alpha('b') <= _Alpha('a')
    assert not _Alpha('b') >= _Alpha('a')


# Generated at 2022-06-23 14:49:38.917032
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion('4.3.2')
    v2 = SemanticVersion('4.3.2')

    assert v1 >= v2
    assert v2 >= v1


# Generated at 2022-06-23 14:49:41.688640
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    sv = SemanticVersion()
    sv.parse('1.2.3')

    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3


# Generated at 2022-06-23 14:49:47.205638
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == 1
    assert not _Numeric(1) == _Numeric(2)
    assert not _Numeric(1) == 2
    assert not _Numeric(1) == _Alpha('1')
    assert not _Numeric(1) == '1'


# Generated at 2022-06-23 14:49:50.493927
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha('abc').__repr__() == repr('abc')
    assert _Alpha('123').__repr__() == repr('123')


# Generated at 2022-06-23 14:50:00.946068
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0')
    assert SemanticVersion('0.0.1') > SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0-rc') > SemanticVersion('0.0.0-alpha')
    assert SemanticVersion('0.0.0-alpha') > SemanticVersion('0.0.0-beta')
    assert SemanticVersion('0.0.0-alpha.1') > SemanticVersion('0.0.0-alpha')
    assert SemanticVersion('0.0.0+1') > SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-1')

# Generated at 2022-06-23 14:50:09.083196
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    import sys
    if sys.version_info[0] < 3:
        SemanticVersion('')
        SemanticVersion('1')
        SemanticVersion('1.1')
        SemanticVersion('1.1.1')
        SemanticVersion('1.1.1-prerelease')
        SemanticVersion('1.1.1-prerelease.alpha')
        SemanticVersion('1.1.1-prerelease.alpha.1')
        SemanticVersion('1.1.1-prerelease.alpha.1.beta.2')
        SemanticVersion('1.1.1-prerelease.alpha.1.beta.2+build.meta')
        SemanticVersion('1.1.1-prerelease.alpha.1.beta.2+build.meta.data')


# Generated at 2022-06-23 14:50:17.727228
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('3.3.0') <= '3.3.0'
    assert _Alpha('3.3.0') <= _Alpha('3.3.0')
    assert _Alpha('3.3.0') <= _Alpha('3.3.0.0')
    assert _Alpha('3.3.0.0') <= _Alpha('3.3.0')
    assert _Alpha('3.3.0') <= '3.3'
    assert _Alpha('3.3') <= '3.3.0'
    assert _Alpha('3.3.0') <= _Numeric('3.3')
    assert _Alpha('3.3') <= _Numeric('3.3.0')
    assert _Alpha('3.3') <= _Numeric('3.3')

# Generated at 2022-06-23 14:50:26.105284
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('1') <= '1'
    assert _Alpha('a') <= 'a'
    assert _Alpha('0') <= '1'
    assert _Alpha('a') <= '1'
    assert _Alpha('a') <= 'b'
    assert _Alpha('1') <= _Alpha('1')
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('0') <= _Alpha('1')
    assert _Alpha('a') <= _Alpha('1')
    assert _Alpha('a') <= _Alpha('b')
    assert not _Alpha('2') <= '1'
    assert not _Alpha('b') <= '1'
    assert not _Alpha('a') <= '0'
    assert not _Alpha('b') <= 'a'
    assert not _Alpha('2') <= _Alpha('1')

# Generated at 2022-06-23 14:50:35.593486
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    #
    # Test the function from_loose_version of class SemanticVersion
    #
    #

    # Apply the function from_loose_version for version 0
    version_string_0 = '0'
    semantic_version_0 = SemanticVersion.from_loose_version(LooseVersion(version_string_0))
    expected_0 = SemanticVersion('0.0.0')
    assert semantic_version_0 == expected_0

    # Apply the function from_loose_version for version 1
    version_string_1 = '1'
    semantic_version_1 = SemanticVersion.from_loose_version(LooseVersion(version_string_1))
    expected_1 = SemanticVersion('1.0.0')
    assert semantic_version_1 == expected_1

    # Apply the function from_

# Generated at 2022-06-23 14:50:39.376558
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') >= 'b'
    assert not _Alpha('b') >= 'a'
    assert _Alpha('b') >= _Alpha('b')
    assert not _Alpha('b') >= _Alpha('a')


# Generated at 2022-06-23 14:50:49.742320
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # version without prerelease
    version = SemanticVersion('1.2.3')
    if version.major!=1:
        raise AssertionError('TEST FAILED: version.major!=1')
    if version.minor!=2:
        raise AssertionError('TEST FAILED: version.minor!=2')
    if version.patch!=3:
        raise AssertionError('TEST FAILED: version.patch!=3')
    if version.prerelease!=():
        raise AssertionError('TEST FAILED: version.prerelease!=()')
    if version.buildmetadata!=():
        raise AssertionError('TEST FAILED: version.buildmetadata!=()')

    # version with prerelease

# Generated at 2022-06-23 14:50:53.446665
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('alpha') == _Alpha('alpha')
    assert _Alpha('alpha') == 'alpha'
    assert 'alpha' == _Alpha('alpha')

    assert not _Alpha('alpha') == _Alpha('beta')
    assert not _Alpha('alpha') == _Numeric('1')



# Generated at 2022-06-23 14:50:55.765094
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    x = _Alpha("x")
    y = _Alpha("y")
    assert (x == y) == False
    assert (x == "x") == True
    assert (x == 3) == False


# Generated at 2022-06-23 14:51:06.533441
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('a')
    a_eq = _Alpha('a')
    a_gt = _Alpha('b')
    a_lt = _Alpha('A')
    i = _Numeric('1')

    assert a == a_eq
    assert a != a_gt
    assert a != a_lt
    assert a != i
    assert a <= a_eq
    assert a <= a_gt
    assert a < a_gt
    assert a < i
    assert a < a_lt
    assert a <= a_lt
    assert not (a > a_eq)
    assert not (a > a_gt)
    assert not (a > a_lt)
    assert not (a > i)
    assert not (a > i)
    assert not (a >= a_eq)

# Generated at 2022-06-23 14:51:07.893782
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(0) != 0


# Generated at 2022-06-23 14:51:16.287882
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= '1.0.0'
    assert not SemanticVersion('1.0.0') <= '0.9.9'
    assert not SemanticVersion('1.0.0') <= '0.0.0'
    assert SemanticVersion('0.0.0') <= '1.0.0'

    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    assert not SemanticVersion('1.0.0') <= SemanticVersion('0.9.9')
    assert not SemanticVersion('1.0.0') <= SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') <= SemanticVersion('1.0.0')


# Generated at 2022-06-23 14:51:22.985948
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    Tests
    '''
    from distutils.version import LooseVersion as lv
    assert SemanticVersion.from_loose_version(lv('0.1.2+3')).format() == '0.1.2+3'
    assert SemanticVersion.from_loose_version(lv('0.1.2-3')).format() == '0.1.2-3'
    assert SemanticVersion.from_loose_version(lv('0.1.2')).format() == '0.1.2+0'
    assert SemanticVersion.from_loose_version(lv('0.1')).format() == '0.1.0+0'
    assert SemanticVersion.from_loose_version(lv('0')).format() == '0.0.0+0'
   

# Generated at 2022-06-23 14:51:25.051716
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a1 = _Alpha('a')
    a2 = _Alpha('b')
    assert a1 < a2



# Generated at 2022-06-23 14:51:28.924476
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    """
    Test that the ``__repr__`` method of the ``SemanticVersion`` class
    returns a string containing a valid Python expression that could be
    used to recreate an object with the same value.
    """
    for vstring in ('1.2.3', '1.2.3-alpha5'):
        v = SemanticVersion(vstring)
        assert eval(repr(v)) == v


# Generated at 2022-06-23 14:51:31.377670
# Unit test for constructor of class _Alpha
def test__Alpha():
    # string
    assert _Alpha('1').specifier == '1'
    # int
    assert _Alpha(1).specifier == 1



# Generated at 2022-06-23 14:51:32.449905
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(2) != 3


# Generated at 2022-06-23 14:51:34.692271
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha('a') != _Alpha('a')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'a'


# Generated at 2022-06-23 14:51:38.285502
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
     g1=_Numeric(1)
     g2=_Numeric(2)
     g3=_Numeric(3)
     assert g1 <= g1
     assert g1 <= g2
     assert g1 <= g3


# Generated at 2022-06-23 14:51:41.984343
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    '''
    Test _Alpha.__lt__
    '''
    assert not _Alpha('a') < _Alpha('a')
    assert _Alpha('a') < _Alpha('b')
    assert not _Alpha('b') < _Alpha('a')


# Generated at 2022-06-23 14:51:50.795173
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    """
    We need __lt__ to return True when comparing an integer and a
    string.
    """
    assert _Numeric('3') < '3.10'
    assert _Numeric('3') < '3.10-10'
    assert _Numeric('3') < '3.10+10'
    assert _Numeric('3') < '3.10-10+10'
    assert _Numeric('3') < 3.9
    assert _Numeric('3') < 3.10
    assert _Numeric('3') < 3.10-0.1
    assert _Numeric('3') < 3.10+0.1



# Generated at 2022-06-23 14:52:00.972014
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test when other is a _Alpha object
    try:
        _Alpha('a') <= _Alpha('b')
    except Exception as e:
        if str(e) != "ValueError()":
            raise Exception("Unexpected exception thrown")

    if not (_Alpha('a') <= _Alpha('a')):
        raise Exception("Values are equal and less than or equal is True")

    if (_Alpha('b') <= _Alpha('a')):
        raise Exception("LHS is greater than RHS and less than or equal is True")

    # Test when other is a str
    try:
        _Alpha('a') <= 'b'
    except Exception as e:
        if str(e) != "ValueError()":
            raise Exception("Unexpected exception thrown")


# Generated at 2022-06-23 14:52:03.418524
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(2) == False
    assert _Numeric(1) >= _Numeric(1) == True
    assert _Numeric(4) >= _Numeric(3) == True


# Generated at 2022-06-23 14:52:04.759107
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    version1 = SemanticVersion()


# Generated at 2022-06-23 14:52:16.398361
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    abc = _Alpha('abc')
    cba = _Alpha('cba')
    one = _Alpha('1')
    two = _Alpha('2')
    three = _Alpha('3')
    twelve = _Alpha('12')

    #test __lt__
    assert a < b
    assert a < c
    assert a < abc
    assert a < cba
    assert a < one
    assert a < two
    assert a < three
    assert a < twelve

    assert b < c
    assert b < abc
    assert b < cba
    assert b < one
    assert b < two
    assert b < three
    assert b < twelve

    assert c < abc
    assert c < cba


# Generated at 2022-06-23 14:52:25.373983
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    a='v0.0.0'
    b='v1.1.0'
    c='v1.1.1'
    print('a=%s b=%s c=%s' % (a,b,c))
    # __eq__ with string
    print('a==a Result: {}'.format(SemanticVersion(a)==a))
    print('a==b Result: {}'.format(SemanticVersion(a)==b))
    print('a==c Result: {}'.format(SemanticVersion(a)==c))
    print('b==c Result: {}'.format(SemanticVersion(b)==c))
    # __eq__ without string
    print('a==SemanticVersion(a) Result: {}'.format(SemanticVersion(a)==SemanticVersion(a)))

# Generated at 2022-06-23 14:52:29.350277
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == 1
    assert 1 == _Numeric(1)
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != 2
    assert 1 != _Numeric(2)



# Generated at 2022-06-23 14:52:34.533037
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    """Test __gt__ function"""

    # TODO: Figure out how to use a py2/py3 compatible way to do this,
    # the below does not work on py2
    # version1 = SemanticVersion('1.0.0-alpha')
    # version2 = SemanticVersion('1.0.0-beta')
    version1 = SemanticVersion('1.0.0-alpha')
    version2 = SemanticVersion('1.0.0-beta')
    assert version1 < version2


# Generated at 2022-06-23 14:52:40.549155
# Unit test for method __le__ of class SemanticVersion

# Generated at 2022-06-23 14:52:45.661106
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Test case of when current is less than other
    # When major, minor and patch are the same 0 < 9
    # and is_prerelease is the same False < True
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0-0.3.7')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0-x.7.z.92')
    # When minor and patch are the same 0 < 9
    # and is_prerelease is the same False < True

# Generated at 2022-06-23 14:52:55.178775
# Unit test for method __ge__ of class _Alpha

# Generated at 2022-06-23 14:53:03.596798
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    for g in globals().values():
        if isinstance(g, type) and issubclass(g, _Numeric):
            for i in range(5):
                for j in range(5):
                    if i <= j:
                        assert g(i) <= g(j)
                    else:
                        assert g(i) > g(j)
                    assert g(i) <= g(i)
                    if i < j:
                        assert g(i) < g(j)
                    else:
                        assert not g(i) < g(j)



# Generated at 2022-06-23 14:53:10.351067
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    for vstring in ['0.1.2', '1.2.3', '0.0.0', '10.20.30']:
        version = SemanticVersion(vstring)
        assert version.major == vstring.split('.', 1)[0], 'major error'
        assert version.minor == vstring.split('.', 2)[1], 'minor error'
        assert version.patch == vstring.rsplit('.', 1)[1], 'patch error'
    for vstring in ['1', '1.2', '1.2.3.4']:
        try:
            SemanticVersion(vstring)
            assert False, 'must raise ValueError exception'
        except ValueError:
            pass



# Generated at 2022-06-23 14:53:14.878146
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(3)
    d = _Numeric(100)
    e = _Alpha(1)
    f = _Alpha(2)
    g = _Alpha(3)
    assert a < b
    assert a < c
    assert a < d
    assert b < d
    assert c < d
    assert a < e
    assert a < f
    assert a < g
    assert b < g
    return True


# Generated at 2022-06-23 14:53:22.950794
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= _Alpha('1')
    assert 1 <= _Numeric(1)
    assert _Alpha('1') <= _Numeric(1)
    assert _Numeric(1) >= _Numeric(0)
    assert _Numeric(1) >= 0
    assert _Numeric(1) >= _Alpha('0')
    assert _Numeric(0) <= _Numeric(1)
    assert _Alpha('0') <= _Numeric(1)
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(2) >= 1
    assert _Numeric(2) >= _Alpha('1')
    assert 2 <= _Numeric(2)

# Generated at 2022-06-23 14:53:33.037105
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha('a')
    b = _Alpha('b')
    assert (a < b)
    assert (a <= b)
    assert not (a == b)
    assert (a != b)
    assert not (a > b)
    assert not (a >= b)

    a = _Alpha('z')
    b = _Alpha('a')
    assert not (a < b)
    assert not (a <= b)
    assert not (a == b)
    assert (a != b)
    assert (a > b)
    assert (a >= b)

    a = _Alpha('a')
    b = _Alpha('a')
    assert not (a < b)
    assert (a <= b)
    assert (a == b)
    assert not (a != b)
    assert not (a > b)


# Generated at 2022-06-23 14:53:36.026345
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a = _Alpha('a')
    assert a == 'a'

    b = _Alpha('b')
    assert a != b
    assert a != 'b'


# Generated at 2022-06-23 14:53:41.527039
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric('0') < _Numeric('1')
    assert _Numeric('1.0') > _Numeric('0.1')
    assert _Numeric('0.1') < _Numeric('1.0')
    assert _Numeric('1.0') > _Numeric('0.0.1')
    assert _Numeric('0.0.1') < _Numeric('1.0')



# Generated at 2022-06-23 14:53:43.977578
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    s = SemanticVersion('1.2.3-alpha.1.2+build.11.e0f985a')
    assert s >= '1.2.3-alpha.1.2+build.11.e0f985a'



# Generated at 2022-06-23 14:53:56.204837
# Unit test for method __ge__ of class SemanticVersion

# Generated at 2022-06-23 14:54:04.166289
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion("1.0.0") != "1.0.0"
    assert SemanticVersion("1.2.0") != "1.0.0"
    assert SemanticVersion("1.0.0-alpha") != "1.0.0"
    assert SemanticVersion("1.0.0-alpha.1") != "1.0.0-alpha"
    assert SemanticVersion("1.0.0-alpha.1") != "1.0.0-alpha.beta"
    assert SemanticVersion("1.0.0+build.1") != "1.0.0-alpha"



# Generated at 2022-06-23 14:54:10.746728
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    _Alpha_ = _Alpha('1.0.0-alpha')

    # Test that true is returned when _Alpha_ specifier is equal to _Alpha_.specifier
    assert _Alpha_ == '1.0.0-alpha'

    # Test that false is returned when _Alpha_.specifier is not equal to _Alpha_.specifier
    assert not _Alpha_ == '2.0.0-alpha'



# Generated at 2022-06-23 14:54:17.285333
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a='_Numeric:3'
    b=3
    c=_Numeric(3)
    d=_Numeric(4)
    
    assert(c.__ne__(a)) == True, 'Unit test fail'
    assert(c.__ne__(b)) == False, 'Unit test fail'
    assert(c.__ne__(c)) == False, 'Unit test fail'
    assert(c.__ne__(d)) == True, 'Unit test fail'
    assert(c.__ne__(None)) == True, 'Unit test fail'

    

# Generated at 2022-06-23 14:54:20.389225
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == _Numeric('1')


# Generated at 2022-06-23 14:54:24.337903
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    with raises(ValueError):
        _Numeric(1) > _Alpha('0')
    assert _Numeric(1) > 0
    with raises(ValueError):
        _Numeric(1) > '0'


# Generated at 2022-06-23 14:54:27.964578
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    result = SemanticVersion.__repr__(LooseVersion('2.1.1'))
    assert result == 'SemanticVersion(\'2.1.1\')'


# Generated at 2022-06-23 14:54:39.360550
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('alpha') <= _Alpha('alpha')
    assert _Alpha('alpha') <= _Alpha('beta')
    assert _Alpha('alpha') <= _Alpha('gamma')
    assert _Alpha('alpha') <= _Alpha('omega')

    # this is where things get a bit weird
    assert _Alpha('alpha') <= 'beta'
    assert _Alpha('alpha') <= 'beta'
    assert _Alpha('alpha') <= 'gamma'
    assert _Alpha('alpha') <= 'omega'

    assert _Alpha('alpha') <= 'alpha'
    assert _Alpha('alpha') <= 'beta'
    assert _Alpha('alpha') <= 'gamma'
    assert _Alpha('alpha') <= 'omega'

    assert not _Alpha('alpha') <= _Numeric(1)
    with pytest.raises(ValueError):
        _

# Generated at 2022-06-23 14:54:49.788697
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion("0.0.0") == SemanticVersion("0.0.0")
    assert SemanticVersion("0.0.0") == "0.0.0"
    assert "0.0.0" == SemanticVersion("0.0.0")
    assert SemanticVersion("1.2.3") == SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3") == "1.2.3"
    assert "1.2.3" == SemanticVersion("1.2.3")
    assert SemanticVersion("0.0.1") == "0.0.1"
    assert "0.0.1" == SemanticVersion("0.0.1")
    assert SemanticVersion("0.1.1") == "0.1.1"

# Generated at 2022-06-23 14:54:52.363296
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('1.0.0')
    c = SemanticVersion('2.0.0')
    assert a == b
    assert a != c


# Generated at 2022-06-23 14:54:54.069770
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    a = '2.0.0'
    b = '0.1.0'
    assert SemanticVersion(a) > SemanticVersion(b)



# Generated at 2022-06-23 14:55:03.320617
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v = SemanticVersion()

    assert not v.__le__('')
    assert not v.__le__('0')
    assert not v.__le__('0.1')
    assert not v.__le__('0.1.0')
    assert not v.__le__('1')
    assert not v.__le__('1.0')
    assert not v.__le__('1.0.0')
    assert not v.__le__('1.0.1')
    assert not v.__le__('0.0.0-a')
    assert not v.__le__('0.0.0-a.1')

    v = SemanticVersion('0.0.0')

    assert v.__le__('0.0.0')


# Generated at 2022-06-23 14:55:11.063886
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.4.4').core == (1, 4, 4)
    assert SemanticVersion('1.4.4').prerelease == ()
    assert SemanticVersion('1.4.4').buildmetadata == ()
    assert SemanticVersion('1.4.4-beta').core == (1, 4, 4)
    assert SemanticVersion('1.4.4-beta').prerelease == (_Alpha('beta'),)
    assert SemanticVersion('1.4.4-beta').buildmetadata == ()
    assert SemanticVersion('1.4.4-beta').is_prerelease is True
    assert SemanticVersion('1.4.4-beta').is_stable is False
    assert SemanticVersion('1.4.4-beta').vstring == '1.4.4-beta'

# Generated at 2022-06-23 14:55:12.503161
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)


# Generated at 2022-06-23 14:55:17.830683
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0')
    assert v1 == v2
    assert v1.__eq__(v2) == True

    v2 = SemanticVersion('1.0.1')
    assert v1 == v2 == False
    assert v1.__eq__(v2) == False


# Generated at 2022-06-23 14:55:24.084558
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    result = SemanticVersion.from_loose_version(LooseVersion('0.0.1'))
    result2 = SemanticVersion.from_loose_version(LooseVersion('0.0.1-rc.1'))
    result3 = SemanticVersion.from_loose_version(LooseVersion('0.0.1+build.1'))
    result4 = SemanticVersion.from_loose_version(LooseVersion('0.0.1-rc.1+build.1'))
    assert result.vstring == '0.0.1' and result2.vstring == '0.0.1-rc.1' and result3.vstring == '0.0.1+build.1' and \
        result4.vstring == '0.0.1-rc.1+build.1'

# Generated at 2022-06-23 14:55:33.495859
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    a = SemanticVersion('2.3.1')
    assert a.vstring == '2.3.1'
    assert a.prerelease == ()
    assert a.buildmetadata == ()
    assert a.major == 2
    assert a.minor == 3
    assert a.patch == 1
    assert a.is_prerelease == False
    assert a.is_stable

    a = SemanticVersion('2.3.1-alpha')
    assert a.vstring == '2.3.1-alpha'
    assert a.prerelease == (_Alpha('alpha'),)
    assert a.buildmetadata == ()
    assert a.major == 2
    assert a.minor == 3
    assert a.patch == 1
    assert a.is_prerelease == True
    assert not a.is_stable


# Generated at 2022-06-23 14:55:35.662238
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'


# Generated at 2022-06-23 14:55:37.029278
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    alpha = _Alpha('y')
    assert alpha.__ne__(1) == True


# Generated at 2022-06-23 14:55:38.772746
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(0xF) == _Numeric(15)
    assert _Numeric(1) != _Numeric(15)


# Generated at 2022-06-23 14:55:40.972576
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert 'a' >= _Alpha('a')


# Generated at 2022-06-23 14:55:47.760060
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-beta')
    assert SemanticVersion('1.0.0-rc')
    assert SemanticVersion('1.0.0-rc.1.2')
    assert SemanticVersion('1.0.0-rc.1.alpha')
    assert SemanticVersion('1.0.0-alpha.1.2')
    assert SemanticVersion('1.0.0-alpha.1.rc')
    assert SemanticVersion('1.0.0-alpha.1.beta')
    assert SemanticVersion('1.0.0-alpha+001')
    assert SemanticVersion('1.0.0-alpha.1+001')

# Generated at 2022-06-23 14:55:49.852101
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    obj = _Alpha('a')
    assert repr(obj) == repr(obj.specifier)


# Generated at 2022-06-23 14:55:53.833311
# Unit test for constructor of class _Alpha
def test__Alpha():
    s = _Alpha('alpha')
    i = _Alpha(0)
    assert s.specifier == 'alpha'
    assert str(s) == "alpha"
    assert i.specifier == '0'
    assert str(i) == "0"


# Generated at 2022-06-23 14:55:56.398132
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("2.0.0")
    assert v1 != v2



# Generated at 2022-06-23 14:56:00.619722
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Tests numeric vs numeric sorting
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('2') > _Numeric('1')

    # Tests numeric vs string sorting
    assert _Numeric('1') < _Alpha('2')
    assert _Numeric('1') < _Alpha('1.1')



# Generated at 2022-06-23 14:56:06.019346
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    num=_Numeric('5')
    assert num > 3
    assert num > 4
    assert not num > 5
    assert not num > 6
    assert not num > '6'
    assert not num > _Alpha('6')
    try:
        num > 'a'
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-23 14:56:09.252734
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'abc'
    assert _Alpha('a') != 'a'


# Generated at 2022-06-23 14:56:13.936546
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha("b") > _Alpha("a")
    assert _Alpha("0") > _Alpha("alpha")
    assert _Alpha("0") < _Alpha("42")
    assert _Alpha("0") < _Alpha("b")
    assert _Alpha("alpha") < _Alpha("42")
    assert _Alpha("alpha") < _Alpha("b")


# Generated at 2022-06-23 14:56:16.773812
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('b') < _Alpha('c') is True
    assert _Alpha('b') < _Alpha('b') is False
    assert _Alpha('b') < _Alpha('a') is False

    assert _Alpha('b') < 'c' is True
    assert _Alpha('b') < 'b' is False
    assert _Alpha('b') < 'a' is False


# Generated at 2022-06-23 14:56:28.288909
# Unit test for method __gt__ of class _Numeric

# Generated at 2022-06-23 14:56:37.810273
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha("1").specifier == "1"
    assert not (_Alpha("1") > _Alpha("2"))
    assert _Alpha("2") > _Alpha("1")
    assert _Alpha("21") > _Alpha("2")
    assert not (_Alpha("21") < _Alpha("2"))
    assert not (_Alpha("21") == _Alpha("2"))
    assert not (_Alpha("21") == _Alpha("22"))
    assert _Alpha("2b") < _Alpha("21")
    assert _Alpha("2a") < _Alpha("2b")
    assert _Alpha("2b") > _Alpha("2a")
    assert _Alpha("2b1") > _Alpha("2a")
    assert _Alpha("2.b") < _Alpha("2b")


# Generated at 2022-06-23 14:56:42.685468
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    for string in ("1.4.4", "1.4.4+build_ident", "1.4.4-alpha.4", "1.4.4-alpha.4+build_ident"):
        assert(str(SemanticVersion(string)) == string)

# Unit tests for SemanticVersion.from_loose_version

# Generated at 2022-06-23 14:56:46.405392
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == repr(1)
    assert repr(_Numeric('1')) == repr(1)
    assert repr(_Numeric(_Numeric(1))) == repr(1)


# Generated at 2022-06-23 14:56:51.137897
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    """Testing method __le__ of class SemanticVersion"""
    # Arrange
    sv1 = SemanticVersion('1.4.3')
    sv2 = SemanticVersion('1.4.6-beta1')
    # Act
    result = sv1.__le__(sv2)
    # Assert
    assert result, '1.4.3 should be less then or equal to 1.4.6-beta1'


# Generated at 2022-06-23 14:57:00.140865
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha(1) < _Alpha(2)

    # This is intentionally not a tuple so the 0 is not a
    # string literal but an integer
    assert _Alpha(0) < _Alpha(1)
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha(1)
    assert not _Alpha('1') < _Alpha('0')
    assert not _Alpha(1) < _Alpha('0')

    with pytest.raises(ValueError):
        _Alpha(1) < _Alpha('a')


# Generated at 2022-06-23 14:57:05.750903
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion("1.2.3-alpha.1")
    assert v1 == "1.2.3-alpha.1"
    v2 = SemanticVersion("1.2.3-alpha.2")
    assert v1 != v2
    v3 = SemanticVersion("1.2.3")
    assert v1 != v3
    v4 = SemanticVersion("1.2.4-alpha.1")
    assert v1 != v4
    v5 = SemanticVersion("2.2.3-alpha.1")
    assert v1 != v5
    assert v1 != "1.2.3-beta.1"



# Generated at 2022-06-23 14:57:07.629068
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('1.0.0')
    assert v.__repr__() == "SemanticVersion('1.0.0')"



# Generated at 2022-06-23 14:57:14.118976
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('A') < _Alpha('b')
    assert _Alpha('a') < _Alpha('B')
    assert _Alpha('a') == 'a'
    assert _Alpha('a') < 'b'
    assert _Alpha('a') < 'B'
    assert _Alpha('a') < '0'


# Generated at 2022-06-23 14:57:15.413017
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha(1) != _Alpha(1)


# Generated at 2022-06-23 14:57:26.010883
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    from ansible.module_utils import semver
    from distutils.version import LooseVersion

    lv1 = LooseVersion('1.0.0')
    lv2 = LooseVersion('1.0.0-alpha.1.2')
    lv3 = LooseVersion('1.0.0-alpha.1+build.metadata')
    lv4 = LooseVersion('1.0.0+build.metadata')
    lv5 = LooseVersion('1.0.0-alpha.1+build.metadata')
    lv6 = LooseVersion('1.0.0-alpha+build.metadata')

# Generated at 2022-06-23 14:57:30.813641
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(2) < _Numeric('3')
    assert _Numeric('1') < _Numeric(2)
    assert _Numeric('2') < _Numeric('3')
    assert _Numeric(1) < 2
    assert _Numeric(2) < 3
    assert _Numeric('1') < 2
    assert _Numeric('2') < 3
    assert _Numeric(1) != 2
    assert _Numeric(2) != 3
    assert _Numeric('1') != 2
    assert _Numeric('2') != 3



# Generated at 2022-06-23 14:57:41.143508
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Test the case, version1 <= version1
    version1 = "1.2.3"
    version2 = "1.2.3"
    v1 = SemanticVersion(version1)
    v2 = SemanticVersion(version2)
    assert v1 <= v2

    # Test the case, version2 <= version1
    version1 = "1.2.3"
    version2 = "1.2.4"
    v1 = SemanticVersion(version1)
    v2 = SemanticVersion(version2)
    assert v2 <= v1

    # Test the case, version1 <= version2
    version1 = "1.2.3"
    version2 = "2.2.3"
    v1 = SemanticVersion(version1)
    v2 = SemanticVersion(version2)
    assert v

# Generated at 2022-06-23 14:57:44.940949
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('b') >= 'a'
    assert not _Alpha('a') >= 'b'
    assert not _Alpha('a') >= _Numeric(1)


# Generated at 2022-06-23 14:57:48.063616
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    num = _Numeric('1')
    assert (num == num) == True
    assert (num == 1) == True
    assert (num == 2) == False
    assert (num == '1') == False
    assert (num == 'two') == False


# Generated at 2022-06-23 14:57:52.733643
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert not (_Numeric(1) < _Numeric(1))
    assert not (_Numeric(2) < _Numeric(1))
    assert not (_Numeric(1) < _Numeric('1'))
    assert not (_Numeric(1) < _Alpha('1'))
    assert _Numeric(1) < _Alpha('2')


# Generated at 2022-06-23 14:57:56.282474
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')
    assert _Alpha('b') != _Alpha('a')
    assert _Alpha('b') != 'a'
    assert 'b' != _Alpha('a')


# Generated at 2022-06-23 14:57:58.098577
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    a = _Alpha('test')
    assert repr(a) == 'test'



# Generated at 2022-06-23 14:58:06.580658
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # it should return True when the given version is equal or greater
    # than the current version
    assert SemanticVersion('2.2.0') >= '2.2.0'
    assert SemanticVersion('2.3.0') >= '2.2.0'
    assert SemanticVersion('3.0.0') >= '2.2.0'
    # it should return True with a prerelease of the current version
    assert SemanticVersion('2.2.0') >= '2.2.0-a'
    assert SemanticVersion('2.2.0') >= '2.2.0-b'
    assert SemanticVersion('2.2.0') >= '2.2.0-a.1'
    assert SemanticVersion('2.2.0') >= '2.2.0-b.1'
    # it

# Generated at 2022-06-23 14:58:13.254022
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # The method is correct on py3
    version = SemanticVersion('0.0.0-alpha.1.beta.1+build.1')
    assert version <= '0.0.0-alpha.1.beta.2+build.1'

    # The method is NOT correct on py2
    version = SemanticVersion('0.0.0-alpha.1.beta.1+build.1')
    assert not version.__le__('0.0.0-alpha.1.beta.2+build.1')


# Generated at 2022-06-23 14:58:16.440448
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != 1
    assert not _Numeric(1).__ne__(1)



# Generated at 2022-06-23 14:58:19.400271
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    c = _Alpha('a')
    assert c > None
    assert c > 0
    assert c > False
    assert c > 'a'
    assert c < 'b'


# Generated at 2022-06-23 14:58:28.619616
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    method from_loose_version of class SemanticVersion
    """
    from ansible.module_utils.six.moves.urllib.parse import quote_plus
    from ansible.module_utils.compat.version import LooseVersion

    def hyperlink_version(version):
        return '<a href="https://semver.org/#is-there-a-suggested-regular-expression-regex-to-check-a-semver-string">%s</a>' % version

    def semantic_version(version):
        return '<a href="https://semver.org/">Semantic version</a>: %s' % version


# Generated at 2022-06-23 14:58:30.055268
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    try:
        assert _Numeric(1) <= _Numeric(2)
        print('pass')
    except:
        print('error')


# Generated at 2022-06-23 14:58:37.742371
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('2.0.0') >= '1.9.9'
    assert SemanticVersion('1.9.9') >= '1.9.9'
    assert not SemanticVersion('1.9.9') >= '1.10.0'
    assert SemanticVersion('1.9.9') >= '1.9.9-alpha0'
    assert SemanticVersion('1.9.9') >= '1.9.9-alpha'
    assert not SemanticVersion('1.9.9') >= '1.9.9-beta'
    assert SemanticVersion('1.9.9') >= '1.9.9-beta2'
    assert SemanticVersion('1.9.9') >= '1.9.9-beta.2'