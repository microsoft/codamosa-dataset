

# Generated at 2022-06-23 14:48:32.031670
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('0.0.1')



# Generated at 2022-06-23 14:48:41.836926
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    sv1 = SemanticVersion('1.2.3')
    sv2 = SemanticVersion('1.2.4')
    assert sv2 > sv1
    sv3 = SemanticVersion('1.3.3')
    assert sv3 > sv1 and sv3 > sv2
    sv4 = SemanticVersion('2.2.3')
    assert sv4 > sv1 and sv4 > sv2 and sv4 > sv3
    sv5 = SemanticVersion('1.2.3+tag')
    assert sv5 > sv1 and sv3 > sv5
    sv6 = SemanticVersion('2.0.0-beta+tag')
    assert sv6 > sv5 and sv3 > sv6

if __name__ == '__main__':
    test_SemanticVersion___gt__()
    print('PASS')

__all__

# Generated at 2022-06-23 14:48:51.097248
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    obj1 = _Numeric("")
    obj2 = _Numeric("")

    obj3 = _Numeric("")
    obj3.specifier = 1

    obj4 = _Numeric("")
    obj4.specifier = ""

    obj5 = _Numeric("")
    obj5.specifier = 1

    obj6 = _Numeric("")
    obj6.specifier = 2

    obj7 = None

    assert obj1.__ne__(obj2) == False
    assert obj1.__ne__(obj3) == True
    assert obj1.__ne__(obj4) == True
    assert obj1.__ne__(obj5) == True
    assert obj1.__ne__(obj6) == True
    assert obj1.__ne__(obj7) == True


# Generated at 2022-06-23 14:48:58.317376
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Test comparison with version in version format
    assert (SemanticVersion('2.0.0') > '1.0.0')
    assert not (SemanticVersion('1.0.0') > '2.0.0')
    assert (SemanticVersion('1.0.0') > '0.0.0')
    assert not (SemanticVersion('1.0.0') > '1.0.1')
    assert not (SemanticVersion('1.0.0') > '1.1.0')
    assert not (SemanticVersion('1.0.0') > '2.0.0')
    assert not (SemanticVersion('1.0.1') > '1.0.0')
    assert not (SemanticVersion('1.1.0') > '1.0.0')

# Generated at 2022-06-23 14:49:02.212777
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    num = _Numeric(1)
    assert num <= 1
    assert num <= _Numeric(1)
    assert num <= _Alpha("1")
    assert not num <= 2
    assert not num <= _Numeric(2)
    assert not num <= _Alpha("2")


# Generated at 2022-06-23 14:49:10.649549
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Any LooseVersion can be cast to a SemanticVersion
    lv = LooseVersion('1.2.3a4')
    assert SemanticVersion.from_loose_version(lv).vstring == '1.2.3-a4'
    # LooseVersion with a build metadata string is correctly cast to
    # a SemanticVersion
    lv = LooseVersion('1.2.3b4+build1')
    assert SemanticVersion.from_loose_version(lv).vstring == '1.2.3-b4+build1'
    # LooseVersion with a prerelease string is correctly cast to
    # a SemanticVersion
    lv = LooseVersion('1.2.3a4')

# Generated at 2022-06-23 14:49:13.369282
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') != 'b'
    assert _Alpha('b') == 'b'
    assert _Alpha('b') != 'c'
    assert _Alpha('c') == 'c'
    assert _Alpha('c') != 'd'


# Generated at 2022-06-23 14:49:16.090545
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('foo') >= 'foo'
    assert _Alpha('foo') >= 'bar'
    assert not _Alpha('foo') >= 'baz'


# Generated at 2022-06-23 14:49:20.738845
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    example_cases = [
        (_Numeric(1), _Numeric(1), True),
        (_Numeric(1), _Numeric(2), False),
        (_Numeric(1), 1, True),
        (_Numeric(1), 2, False)
    ]
    for (value1, value2, expected_output) in example_cases:
        actual_output = value1 == value2
        assert actual_output == expected_output


# Generated at 2022-06-23 14:49:22.504279
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    s = SemanticVersion('1.0.0')
    assert s >= '1.0.0'
    return s



# Generated at 2022-06-23 14:49:29.053914
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('2.0.0') <= '2.0.0'
    assert SemanticVersion('1.0.10') <= '2.0.0'
    assert SemanticVersion('1.0.0') <= '2.0.0'
    assert SemanticVersion('1.1.0') <= '2.0.0'
    assert SemanticVersion('1.0.0') <= '1.0.1'


# Generated at 2022-06-23 14:49:37.068235
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') <= _Alpha('b')

    assert not _Alpha('a') < _Alpha('a')
    assert _Alpha('a') <= _Alpha('a')

    assert not _Alpha('a') < _Alpha('A')
    assert not _Alpha('a') <= _Alpha('A')

    assert not _Alpha('b') < _Alpha('a')
    assert not _Alpha('b') <= _Alpha('a')

    assert _Alpha('a') < _Numeric(1)
    assert _Alpha('a') < _Numeric(100)

    assert not _Alpha('a') < _Alpha('1')
    assert not _Alpha('a') < _Alpha('100')


# Generated at 2022-06-23 14:49:42.460838
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("0.6.0") == SemanticVersion("0.6")
    assert SemanticVersion("1.2.3-alpha-1") < SemanticVersion("1.2.3-alpha.2")
    assert SemanticVersion("1.2.3-alpha.2") < SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3-alpha-1") < SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3-alpha.2-1000") < SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3+0") == SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3-0") == SemanticVersion("1.2.3")

# Generated at 2022-06-23 14:49:47.296369
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    instance = SemanticVersion('0.0.0')

    class Stub:
        pass

    stub = Stub()
    stub.core = (0, 0, 0)
    stub.prerelease = ()
    stub.buildmetadata = ()

    assert instance == stub

    assert not instance != stub


# Generated at 2022-06-23 14:49:56.566549
# Unit test for constructor of class _Numeric
def test__Numeric():
    from nose2.tools import params
    from nose2.tools.such import AssertThat, Is
    import nose2
    @params(
        (1, 1),
        ('1', 1),
        ('11', 11)
    )
    def test_int(specifier, expected):
        with AssertThat(specifier):
            assert_that(_Numeric(specifier).specifier, Is(expected))
    nose2.main(argv=['-v', '--with-coverage', '--coverage-report=term-missing', '--coverage=ansible.module_utils.semver'])


# Generated at 2022-06-23 14:49:58.581621
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha("test").specifier == "test"
    assert _Alpha("test").specifier != "test2"


# Generated at 2022-06-23 14:50:07.563076
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:50:16.167291
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    vstring = '1.2.3-alpha.4'
    version = SemanticVersion(vstring)
    assert version.vstring == vstring
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Alpha('alpha'), _Numeric('4'))
    assert version.buildmetadata == ()
    assert version.core == (1, 2, 3)
    assert version.is_prerelease
    assert not version.is_stable
    assert str(version) == str(SemanticVersion('1.2.3-alpha.4'))

    vstring = '1.2.3+build.4.5'
    version = SemanticVersion(vstring)
    assert version.vstring == vstring
    assert version.major == 1

# Generated at 2022-06-23 14:50:23.063626
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1') < SemanticVersion('2')
    # The major version is the number before the first dot.
    assert SemanticVersion('1.0') < SemanticVersion('2.0')
    assert SemanticVersion('1.0') < SemanticVersion('1.1')
    assert SemanticVersion('1.0') < SemanticVersion('2.1')
    assert SemanticVersion('1.0') < SemanticVersion('1.1.0')

    # A normal version number MUST take the form X.Y.Z where X, Y, and Z are non-negative integers
    # https://semver.org/#spec-item-2
    # The following should raise ValueError:
    # assert SemanticVersion('1.0.1.2') < SemanticVersion('1.0.1.3')
    # assert Semantic

# Generated at 2022-06-23 14:50:25.554261
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a1 = _Alpha('a')
    a2 = _Alpha('a')

    assert a1 == 'a'
    assert a2 == 'a'
    assert a1 == a2


# Generated at 2022-06-23 14:50:30.334782
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric("1") != _Numeric("2")
    assert _Numeric("1") != 1
    assert not _Numeric("1") != _Numeric("1")
    assert not _Numeric("1") != 1


# Generated at 2022-06-23 14:50:33.453369
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    alpha1 = _Alpha('alpha')
    alpha2 = _Alpha('beta')
    assert(alpha1 < alpha2)
    assert(not (alpha1 < alpha1))
    assert(not (alpha2 < alpha1))


# Generated at 2022-06-23 14:50:36.237437
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    # Arrange
    specifier = '123'

    # Act
    numeric = _Numeric(specifier)

    # Assert
    assert numeric.__repr__() == '123'


# Generated at 2022-06-23 14:50:38.306138
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion("1.11.8-pre")
    v2 = SemanticVersion("1.11.8")
    assert (v1 != v2)


# Generated at 2022-06-23 14:50:39.695365
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0')


# Generated at 2022-06-23 14:50:43.961503
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    number_1 = _Numeric(1)
    number_1_bis = _Numeric(1)
    number_2 = _Numeric(2)
    string_1 = _Alpha('1')

    assert number_1 != number_2
    assert number_1 != string_1
    assert number_1 == number_1
    assert number_1 == number_1_bis


# Generated at 2022-06-23 14:50:47.634132
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n = _Numeric(1)
    assert n == 1
    assert 1 == n

    assert not n == 2
    assert 2 != n

    m = _Numeric(1)
    assert n == m

    a = _Alpha('a')
    assert not n == a


# Generated at 2022-06-23 14:50:55.160179
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    sv1 = SemanticVersion('1.2.9')
    sv1_1 = SemanticVersion('1.2.9')
    sv2 = SemanticVersion('1.2.9')
    sv3 = SemanticVersion('1.2.10')
    sv4 = SemanticVersion('1.3.9')
    sv5 = SemanticVersion('2.2.9')
    sv6 = SemanticVersion('2.2.9+1.1')
    sv7 = SemanticVersion('2.2.9+2.1')

    assert(sv1 != sv1_1)
    assert(sv1 == sv2)
    assert(sv1 < sv3)
    assert(sv1 <= sv3)
    assert(sv1 < sv4)
    assert(sv1 <= sv4)

# Generated at 2022-06-23 14:51:00.141508
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= 'A'

    assert not _Alpha('a') >= 'b'
    assert not _Alpha('a') >= 'B'

    assert _Alpha('a') >= _Alpha('A')
    assert not _Alpha('a') >= _Alpha('b')


# Generated at 2022-06-23 14:51:03.556675
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha("alpha") == _Alpha("alpha")
    assert _Alpha("alpha") in ("alpha", _Alpha("alpha"))
    assert text_type(_Alpha("alpha")) == "alpha"


# Generated at 2022-06-23 14:51:13.094826
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alpha = _Alpha('alpha')
    alpha1 = _Alpha('alpha')
    numeric = _Numeric('1')
    numeric1 = _Numeric('1')
    a = _Alpha('a')

    assert(alpha1 == alpha)
    assert(not alpha1 != alpha)

    assert(not alpha1 < alpha)
    assert(alpha1 <= alpha)

    assert(not alpha1 > alpha)
    assert(alpha1 >= alpha)

    assert(alpha1 < numeric)
    assert(alpha1 <= numeric)

    assert(not alpha1 > numeric)
    assert(not alpha1 >= numeric)

    assert(alpha1 > a)
    assert(alpha1 >= a)

    assert(not alpha1 < a)
    assert(not alpha1 <= a)

    assert(not numeric1 == numeric)

# Generated at 2022-06-23 14:51:15.164950
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion("1.2.2")
    assert repr(v) == "SemanticVersion('1.2.2')"


# Generated at 2022-06-23 14:51:21.453960
# Unit test for constructor of class _Alpha
def test__Alpha():
    class obj:
        # Unit test for constructor of class _Alpha
        def test__Alpha_(self):
            try:
                a = _Alpha(5)
            except:
                r = False
            else:
                r = (a.specifier == 5)
            return r

        def test__Alpha__2(self):
            try:
                a = _Alpha('a')
            except:
                r = False
            else:
                r = (a.specifier == 'a')
            return r

    o = obj()
    r = o.test__Alpha_()
    if r:
        r = o.test__Alpha__2()
    return r


# Generated at 2022-06-23 14:51:30.611328
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    versions = [
        '1.2.3',
        '0.2.3',
        '0.2.4',
        '0.11.4',
        '1.11.4',
        '1.11.4-0.3.7',
        '1.11.4-0.3.7+build5',
        '1.11.4-0.3.7+build5.foo',
    ]

    for left in range(len(versions)):
        for right in range(left):
            assert SemanticVersion(versions[left]) > SemanticVersion(versions[right])
            assert SemanticVersion(versions[right]) < SemanticVersion(versions[left])


# Generated at 2022-06-23 14:51:32.791736
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    ver1 = SemanticVersion(vstring='1.0.0')
    ver2 = SemanticVersion(vstring='1.0.0')

    assert(ver1.__eq__(ver2))


# Generated at 2022-06-23 14:51:40.061731
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    '''
    Input of parse():
    - vstring: string

    Test:
    - Class SemanticVersion
    - Method parse() of class SemanticVersion
    - Input: sample string
    - Expected: parse vstring and set value for attribute of class
    '''

# Generated at 2022-06-23 14:51:41.900499
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('alpha')
    assert a.specifier == 'alpha'


# Generated at 2022-06-23 14:51:52.706044
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('0.0.0') < SemanticVersion('0.0.1')
    assert SemanticVersion('0.0.1') < SemanticVersion('0.1.0')
    assert SemanticVersion('0.1.0') < SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-1') < SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0-alpha.1')

# Generated at 2022-06-23 14:52:02.864701
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha('a')
    b = _Alpha('b')
    a1 = _Alpha('a')
    n = _Numeric('1')
    n1 = _Numeric('1')
    s = '3'
    i = 4

    assert (a < b)
    assert (a < n)
    assert (a < s)
    assert (a < i)
    assert (not a < a)
    assert (not a < a1)

    assert (b > a)
    assert (b > n)
    assert (b > s)
    assert (b > i)
    assert (not b < a)
    assert (not b < a1)

    assert (not a <= a)
    assert (a <= a1)
    assert (a <= b)
    assert (a <= n)

# Generated at 2022-06-23 14:52:14.553908
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha("a")
    b = _Alpha("b")
    aa = _Alpha("aa")
    a1 = _Alpha("a1")
    a12 = _Alpha("a12")

    assert a < b
    assert a < aa
    assert a < a1
    assert a < "a"
    assert a < 1

    assert b > a
    assert b > aa
    assert b > a1
    assert b > "a"
    assert b > 1

    assert aa > a
    assert aa > b
    assert aa > a1
    assert aa > "a"
    assert aa > 1

    assert a1 > a
    assert a1 > b
    assert a1 > aa
    assert a1 > "a"
    assert a1 > 1


# Generated at 2022-06-23 14:52:18.519309
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    obj1 = _Numeric('1')
    assert obj1 >= 1
    assert obj1 >= obj1
    obj2 = _Numeric('2')
    assert obj1 < obj2
    assert obj1 < 2


# Generated at 2022-06-23 14:52:28.206039
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == 1
    assert not _Numeric(1) == 2
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == _Numeric(2)
    assert _Numeric(1) < _Numeric(2)
    assert not _Numeric(2) < _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert not _Numeric(2) <= _Numeric(1)
    assert _Numeric(2) > _Numeric(1)
    assert not _Numeric(1) > _Numeric(2)
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(1) >= _Numeric

# Generated at 2022-06-23 14:52:29.294303
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion("2.8.4") != "2.8.4"


# Generated at 2022-06-23 14:52:31.817091
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    specifier = "1"
    expected = "'1'"
    # Run the actual test:
    actual = repr(_Alpha(specifier))
    assert actual == expected, "%s != %s" % (actual, expected)


# Generated at 2022-06-23 14:52:38.165358
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Test version < version
    assert SemanticVersion('2.0.0') < SemanticVersion('2.1.0')
    assert SemanticVersion('2.0.0') < SemanticVersion('3.1.0')
    assert SemanticVersion('2.0.0') < SemanticVersion('2.1.1')

    # Test version < string
    assert SemanticVersion('2.0.0') < '2.1.0'
    assert SemanticVersion('2.0.0') < '3.1.0'
    assert SemanticVersion('2.0.0') < '2.1.1'
    assert SemanticVersion('2.0.0') < '3.0.0'

    assert not SemanticVersion('2.1.1') < '2.1.1'

# Generated at 2022-06-23 14:52:42.944509
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("A") <= _Alpha("A")
    assert _Alpha("A") <= _Alpha("B")
    assert _Alpha("A") <= "A"
    assert _Alpha("A") <= "B"
    assert not _Alpha("B") <= _Alpha("A")
    assert not _Alpha("B") <= "A"


# Generated at 2022-06-23 14:52:43.877271
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric("1") == "1"


# Generated at 2022-06-23 14:52:45.745838
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.0')) == "SemanticVersion('0.0.0')"



# Generated at 2022-06-23 14:52:53.211636
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('alpha').__lt__(_Alpha('beta')) is True
    assert _Alpha('alpha').__lt__('beta') is True

    assert _Alpha('alpha').__lt__(_Alpha('alpha')) is False
    assert _Alpha('alpha').__lt__('alpha') is False
    assert _Alpha('alpha').__lt__(_Numeric('alpha')) is False

    # This should raise ValueError
    # assert _Alpha('alpha').__lt__(_Numeric('10')) is False

    assert _Alpha('alpha').__lt__(_Numeric('10')) is False


# Generated at 2022-06-23 14:53:00.180687
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('z') < 'z'
    assert _Alpha('z') < _Alpha('Z')
    assert _Alpha('Z') < 'Z'
    assert _Alpha('Z') < _Alpha('z')

    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('2') > _Alpha('1')
    assert _Alpha('1') > '1'

    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('a') > 'a'

    assert _Alpha('A') < _Alpha('b')
    assert _Alpha('B') > _Alpha('a')

    assert _Alpha('A') < 'a'
    assert _Alpha('B') > 'a'

    assert _Alpha('a') > '0'
    assert _

# Generated at 2022-06-23 14:53:08.211377
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    """test_SemanticVersion___ge__
    This unittest tests method __ge__ of class SemanticVersion"""
    # Create two SemanticVersion v1 and v2
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("2.0.0")
    # v1 >= v2 should be False
    assert v1 >= v2 == False, "v1 >= v2 should be False"
    # v2 >= v1 should be True
    assert v2 >= v1 == True, "v2 >= v1 should be True"
    # v1 >= v1 should be True
    assert v1 >= v1 == True, "v1 >= v1 should be True"


# Generated at 2022-06-23 14:53:17.086594
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('0.0.0')
    assert v1 == '0.0.0', "{!r} == '0.0.0' failed".format(v1)
    v2 = SemanticVersion('1.2.3')
    assert v2 == '1.2.3', "{!r} == '1.2.3' failed".format(v2)
    assert v1 != v2, "{!r} != {!r} failed".format(v1, v2)
    v3 = SemanticVersion('1.2.3-beta')
    assert v3 == '1.2.3-beta', "{!r} == '1.2.3-beta' failed".format(v3)

# Generated at 2022-06-23 14:53:21.357092
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    expected_results = [
        (1, 2, True),
        (2, 1, False),
        ('1', '2', True),
        ('2', '1', False),
    ]
    for test_case in expected_results:
        if _Numeric(test_case[0]).__lt__(_Numeric(test_case[1])) != test_case[2]:
            return False

    return True



# Generated at 2022-06-23 14:53:24.109782
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('name') < 'version'
    assert _Alpha('version') < _Numeric(1)


# Generated at 2022-06-23 14:53:33.698361
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """Unit test for method parse of class SemanticVersion"""
    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    assert SemanticVersion('1.2.3').prerelease == ()
    assert SemanticVersion('1.2.3').buildmetadata == ()
    assert SemanticVersion('1.2.3-alpha').core == (1, 2, 3)
    assert SemanticVersion('1.2.3-alpha').prerelease == tuple(_Alpha(a) for a in ['alpha'])
    assert SemanticVersion('1.2.3-alpha').buildmetadata == ()
    assert SemanticVersion('1.2.3-alpha.1').core == (1, 2, 3)

# Generated at 2022-06-23 14:53:35.986132
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    instance = _Alpha('alpha')
    other = _Alpha('beta')
    assert instance < other



# Generated at 2022-06-23 14:53:37.290519
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    _Numeric(1).__repr__() == "1"


# Generated at 2022-06-23 14:53:45.493272
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("1.3.8") <= _Alpha("1.3.8")
    assert _Alpha("1.3.8") <= _Alpha("1.3.8-alpha")
    assert _Alpha("1.3.8") <= _Alpha("1.3.8-alpha.1")
    assert _Alpha("1.3.8") <= _Alpha("1.3.8-alpha.beta")
    assert _Alpha("1.3.8") <= _Alpha("1.3.8-beta")
    assert _Alpha("1.3.8") <= _Alpha("1.3.8-beta.2")
    assert _Alpha("1.3.8") <= _Alpha("1.3.8-beta.11")
    assert _Alpha("1.3.8") <= _Alpha("1.3.8-rc.1")

# Generated at 2022-06-23 14:53:57.204742
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    try:
        from unittest import mock
    except ImportError:
        from mock import mock

    def mock_match(vstring):
        return mock.Mock(
            group=mock.Mock(
                return_value=(
                    '123',
                    '456',
                    '789',
                    'asdf',
                    'qwer',
                )
            )
        )

    with mock.patch('ansible.module_utils.semver.SemanticVersion.version_re', SEMVER_RE):
        with mock.patch('ansible.module_utils.semver.SEMVER_RE.match', mock_match):
            sv = SemanticVersion()
            sv.parse('123.456.789-asdf+qwer')

            assert sv.major == 123
            assert sv.minor == 456

# Generated at 2022-06-23 14:53:59.720087
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha(100) > _Alpha('100')
    assert _Alpha('b') > _Alpha(2)


# Generated at 2022-06-23 14:54:01.587578
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion('2.1.3').__repr__() == 'SemanticVersion(\'2.1.3\')'


# Generated at 2022-06-23 14:54:08.056305
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
	assert SemanticVersion().__repr__() == 'SemanticVersion(None)'
	assert SemanticVersion('1.2.3').__repr__() == 'SemanticVersion(\'1.2.3\')'
	assert SemanticVersion('v1.2.3').__repr__() == 'SemanticVersion(\'v1.2.3\')'
	assert SemanticVersion('1.2.3-alpha.1').__repr__() == 'SemanticVersion(\'1.2.3-alpha.1\')'
	assert SemanticVersion('1.2.3-alpha.1+git+hash').__repr__() == 'SemanticVersion(\'1.2.3-alpha.1+git+hash\')'
	assert SemanticVersion('1.2.3-alpha.1+git+hash').__

# Generated at 2022-06-23 14:54:17.360046
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("a") <= _Alpha("a")
    assert _Alpha("a") <= _Alpha("b")
    assert _Alpha("a") <= _Alpha("A")
    assert _Alpha("a") <= _Alpha("A")
    assert _Alpha("a") <= _Alpha("z")
    assert _Alpha("a") <= _Alpha("Z")
    assert _Alpha("a") <= _Alpha("aa")
    assert _Alpha("a") <= _Alpha("ab")
    assert _Alpha("a") <= _Alpha("ba")
    assert _Alpha("a") <= _Alpha("ba")
    assert _Alpha("a") <= _Alpha("zz")
    assert _Alpha("a") <= _Alpha("zz")
    assert _Alpha("a") <= _Alpha("Aa")
    assert _Alpha("a") <= _Alpha("Aa")
   

# Generated at 2022-06-23 14:54:20.001352
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():

    assert  _Numeric(1) != _Numeric(2)
    assert  _Numeric(1) != 1
    assert  _Numeric(1) != _Numeric(_Alpha('1'))


# Generated at 2022-06-23 14:54:21.171689
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert _Numeric(1) == _Numeric(1)


# Generated at 2022-06-23 14:54:28.417085
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Test to ensure that __le__ returns the correct boolean value
    # based on the definition of semantic versioning
    # https://semver.org/#spec-item-11
    # Create 3 lists of 2 elements with the 1st list in order and the
    # other two not in order. Use these lists to create a SemanticVersion
    # object and compare using __le__ (Less than equal to)

    # Create a list of 3 tuples with 2 elements each to compare
    l1 = [('1.0.0', '2.0.0'), ('1.0.0', '1.1.0'), ('1.0.0', '1.0.1')]
    # Create a list of 3 tuples with 2 elements each to compare

# Generated at 2022-06-23 14:54:39.489097
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    equal = _Numeric(1) == _Numeric(1)
    assert equal == True

    not_equal = _Numeric(1) == _Numeric(2)
    assert not_equal == False

    equal_alt_1 = _Numeric(1) == 1
    assert equal_alt_1 == True

    equal_alt_2 = _Numeric(1) == 1.0
    assert equal_alt_2 == True

    not_equal_alt_1 = _Numeric(1) == "1"
    assert not_equal_alt_1 == False

    not_equal_alt_2 = _Numeric(1) == 0
    assert not_equal_alt_2 == False

    not_equal_alt_3 = _Numeric(1) == 2
    assert not_equal_alt_3 == False

# Unit

# Generated at 2022-06-23 14:54:43.295419
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') == '1.2.3'
    assert SemanticVersion('1.2.3') != '1.2.4'



# Generated at 2022-06-23 14:54:51.558040
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    version = SemanticVersion('0.0.1')
    version = SemanticVersion('1.1.1-alpha')
    version = SemanticVersion('1.1.1-1.0.0.0+build')
    version = SemanticVersion('1.1.1+build')
    version = SemanticVersion('1.1.1-1.0.0.0+build')
    try:
        version = SemanticVersion('1.1.1-1.0.0.0-build')
        assert False, 'expected ValueError for SemanticVersion(1.1.1-1.0.0.0-build)'
    except ValueError:
        pass

# Generated at 2022-06-23 14:55:01.121008
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    from distutils.version import LooseVersion, StrictVersion
    import operator


# Generated at 2022-06-23 14:55:03.752215
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    test_str = 'test_str'
    result = repr(test_str)

    assert result == repr(_Alpha(test_str))


# Generated at 2022-06-23 14:55:06.486371
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    d = _Alpha('d')
    assert a < b
    assert b < c
    assert c < d


# Generated at 2022-06-23 14:55:08.034765
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == repr(1)


# Generated at 2022-06-23 14:55:12.685580
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    alpha = _Alpha('b')
    assert alpha.__ge__('a')
    assert alpha.__ge__(_Alpha('b'))
    assert alpha.__ge__('c') is False
    assert alpha.__ge__('b.a')


# Generated at 2022-06-23 14:55:14.345998
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(42) == 42


# Unit tests for class _Numeric

# Generated at 2022-06-23 14:55:21.311614
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    obj = SemanticVersion("0.0.0")
    obj.major = 0
    obj.minor = 0
    obj.patch = 0
    assert obj.__eq__("0.0.0"), "Test 1 Failed"
    assert obj.__eq__("0.0.1"), "Test 2 Failed"
    assert obj.__eq__("0.1.0"), "Test 3 Failed"
    assert obj.__eq__("1.0.0"), "Test 4 Failed"
    assert obj.__eq__("1.1.1"), "Test 5 Failed"
    assert obj.__eq__(SemanticVersion("0.0.1")), "Test 6 Failed"


# Generated at 2022-06-23 14:55:30.979621
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # strictly equal
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')

    # strictly less
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0') <= SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.1')

    # pre-release
    assert SemanticVersion('1.0.0-alpha') <= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0-alpha') <= SemanticVersion('1.0.1-alpha')

# Generated at 2022-06-23 14:55:32.245653
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('01')) == repr('01')



# Generated at 2022-06-23 14:55:33.639248
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    num = _Numeric("1")
    assert num != 1


# Generated at 2022-06-23 14:55:36.908684
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    return_value = not _Alpha('a') >= _Alpha('b')
    if return_value == False:
        raise AssertionError("Return error")
    elif return_value == True:
        return 0
    else:
        return 1


# Generated at 2022-06-23 14:55:38.373872
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    first = _Numeric('1')
    second = _Numeric('2')
    assert first < second


# Generated at 2022-06-23 14:55:45.930929
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    svr = SemanticVersion('1.0.0-alpha.1+build.1')
    assert (svr.major, svr.minor, svr.patch, svr.prerelease, svr.buildmetadata) == (1, 0, 0, ('alpha', _Alpha('1')), ('build', _Numeric('1')))
    svr = SemanticVersion('1.0.0-alpha+build.1')
    assert (svr.major, svr.minor, svr.patch, svr.prerelease, svr.buildmetadata) == (1, 0, 0, ('alpha',), ('build', _Numeric('1')))
    svr = SemanticVersion('1.0.0-0.3.7')

# Generated at 2022-06-23 14:55:49.590199
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion("1.0.0") == "1.0.0"
    assert SemanticVersion("1.0.0") != "1.0.1"


# Generated at 2022-06-23 14:55:59.713492
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    from textwrap import dedent
    from . import _Numeric

    tests = dedent('''\
    0  > 100
    100 > 0
    0   > 100.0
    100 > 0.0
    0.0 > 100
    100 > 0.0
    100 == 100
    100.0 == 100
    100 == 100.0
    100.0 == 100
    100.0 == 100.0
    ''').splitlines()

    def _parse_tests(tests):
        for test in tests:
            lhs, rhs = test.strip().split()
            yield lhs, rhs, {}

    for lhs, rhs, kwargs in _parse_tests(tests):
        lhs = _Numeric(lhs)
        rhs = _Numeric(rhs)

# Generated at 2022-06-23 14:56:07.484451
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    """Unit test for method __lt__ of class _Alpha"""
    a = _Alpha("a")
    b = _Alpha("b")

    assert not a == "a"
    assert a == _Alpha("a")
    assert not a != _Alpha("a")
    assert a != "b"

    assert a < "b"
    assert a <= "b"
    assert a <= "a"

    assert b > "a"
    assert b >= "a"
    assert b >= "b"


# Generated at 2022-06-23 14:56:16.864773
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric("1").__ne__("1") == False
    assert _Numeric("1").__ne__("2") == True
    assert _Numeric("1").__ne__("3") == True
    assert _Numeric("1").__ne__("4") == True
    assert _Numeric("1").__ne__("5") == True
    assert _Numeric("1").__ne__("6") == True
    assert _Numeric("1").__ne__("7") == True
    assert _Numeric("1").__ne__("8") == True
    assert _Numeric("1").__ne__("9") == True
    assert _Numeric("1").__ne__("10") == True
    assert _Numeric("1").__ne__("11") == True

# Generated at 2022-06-23 14:56:18.372201
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == repr(1)



# Generated at 2022-06-23 14:56:20.926923
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(int(2)) == '2'
    assert repr(_Numeric(2)) == '2'


# Generated at 2022-06-23 14:56:24.893227
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)

    assert _Numeric(1) < 2

    with pytest.raises(ValueError):
        _Numeric(1) < _Alpha('a')


# Generated at 2022-06-23 14:56:33.341107
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    occurrences = [
        [_Alpha('a'), _Alpha('a'), True],
        [_Alpha('b'), _Alpha('a'), False],
        [_Alpha('a'), 'a', True],
        [_Alpha('b'), 'a', False],
        [_Alpha('a'), _Numeric('1'), False],
        [_Alpha('a'), 1, False]
    ]

    for case in occurrences:
        assert case[0].__eq__(case[1]) == case[2], 'occurence %s should be %s' % (case[:2], case[2])


# Generated at 2022-06-23 14:56:41.793927
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0-beta') <= SemanticVersion('1.0.0-beta')
    assert SemanticVersion('1.0.0-beta') < SemanticVersion('1.0.0-beta.2')
    assert SemanticVersion('1.0.0-beta.2') < SemanticVersion('1.0.0-beta.11')
    assert SemanticVersion('1.0.0-beta.11') < SemanticVersion('1.0.0-rc.1')
    assert SemanticVersion('1.0.0-rc.1') < SemanticVersion('1.0.0-rc.1+build.1')

# Generated at 2022-06-23 14:56:46.100739
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    alpha = _Numeric(1)
    assert not alpha.__ne__(alpha)

    assert alpha.__ne__(_Numeric(2))

    assert alpha.__ne__(1)

    assert alpha.__ne__(True)



# Generated at 2022-06-23 14:56:49.299353
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    """Test method SemanticVersion.__eq__"""
    v = SemanticVersion('1.2.3')
    assert not v == '1.2.4'
    assert v == '1.2.3'


# Generated at 2022-06-23 14:57:00.301460
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Test comparing two SemanticVersions
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('2.3.4')
    assert v1 <= v2

    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    assert not v1 <= v2

    # Test comparing one SemanticVersion and one LooseVersion
    v1 = SemanticVersion('1.2.3')
    v2 = LooseVersion('2.3.4')
    assert v1 <= v2

    v1 = SemanticVersion('1.2.3')
    v2 = LooseVersion('1.2.3')
    assert not v1 <= v2

    v1 = SemanticVersion('1.2.3')
    v2 = LooseVersion

# Generated at 2022-06-23 14:57:03.877751
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('a1')
    assert _Alpha('a') < _Alpha('aa')
    assert _Alpha('a1') < _Alpha('a11')
    assert _Alpha('a1') < _Alpha('a2')
    assert _Alpha('a1') < _Alpha('b')


# Generated at 2022-06-23 14:57:09.038017
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(SemanticVersion('123')) == "SemanticVersion('123')"
    assert repr(SemanticVersion('123.456.789-alpha.1.2')) == "SemanticVersion('123.456.789-alpha.1.2')"
    assert repr(SemanticVersion('123.456.789-alpha+1.2')) == "SemanticVersion('123.456.789-alpha+1.2')"
    assert repr(SemanticVersion('123.456.789-alpha.1+1.2')) == "SemanticVersion('123.456.789-alpha.1+1.2')"
    assert repr(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"

# Generated at 2022-06-23 14:57:11.897993
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    value = "1"
    assert _Numeric(value).__repr__() == value


# Generated at 2022-06-23 14:57:15.961961
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('a')
    b1 = _Alpha('b')
    b2 = _Alpha('b')
    c = 'c'
    assert (a != b1)
    assert (a != b2)
    assert (a != c)


# Generated at 2022-06-23 14:57:20.557456
# Unit test for constructor of class _Numeric
def test__Numeric():
    numeric = _Numeric(4)
    assert numeric.specifier == 4
    numeric = _Numeric("4")
    assert numeric.specifier == 4
    try:
        numeric = _Numeric("hi")
    except ValueError:
        pass
    else:
        raise ValueError


# Generated at 2022-06-23 14:57:23.100556
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('abc') <= 'abc'
    assert _Alpha('abc') <= _Alpha('def')



# Generated at 2022-06-23 14:57:29.996038
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion()
    assert version.parse("1.2.3") == None
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()
    assert version.parse("0.0.0") == None
    assert version.major == 0
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()
    assert version.parse("1.0.0-alpha") == None
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease[0] == "alpha"
    assert version.parse("1.0.0-alpha.1") == None


# Generated at 2022-06-23 14:57:34.848920
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # Arrange
    expected = 'SemanticVersion(\'SemanticVersion(0.0.0)\')'
    x = SemanticVersion(0)

    # Act
    result = repr(x)

    # Assert
    assert result == expected


# Generated at 2022-06-23 14:57:40.784317
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert (_Numeric(1) <= _Numeric(1)) is True
    assert (_Numeric(1) <= _Numeric(2)) is True
    assert (_Numeric(1) <= _Numeric(0)) is False
    assert (_Numeric(1) <= 1) is True
    assert (_Numeric(1) <= 0) is False
    assert (_Numeric(1) <= _Alpha('1')) is False
    assert (_Numeric(1) <= _Alpha('0')) is False


# Generated at 2022-06-23 14:57:45.227701
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(1)
    b = _Numeric(1)
    assert a == b
    assert not a != b
    b = _Numeric(2)
    assert not a == b
    assert a != b
    assert a != '1'
    assert '1' != a
    assert not a != '1'
    assert not '1' != a


# Generated at 2022-06-23 14:57:49.565067
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(2) == False
    assert _Numeric(1) >= _Numeric(1) == True
    assert _Numeric(1) >= _Numeric(0) == True
    assert _Numeric(1) >= 1 == True
    assert _Numeric(1) >= 0 == True
    assert _Numeric(1) >= _Alpha('0') == False



# Generated at 2022-06-23 14:57:54.603312
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # _Alpha == _Alpha
    assert _Alpha('a') >= _Alpha('a')
    # _Alpha == str
    assert _Alpha('a') >= 'a'
    # _Alpha != _Alpha
    assert _Alpha('a') >= _Alpha('b')
    # _Alpha != str
    assert _Alpha('a') >= 'b'
    # _Alpha != _Numeric
    assert not _Alpha('a') >= _Numeric(1)



# Generated at 2022-06-23 14:57:55.718337
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'


# Generated at 2022-06-23 14:58:05.150045
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    def test(vstring):
        return SemanticVersion(vstring)

    assert test("1.2.3")
    assert test("1.2")
    assert test("1")
    assert test("1.2.3-alpha.1")
    assert test("1.2.3+x.7.z.92")
    assert test("1.2.3-alpha1+x1.7.z2.92")
    assert test("1.0")
    assert test("1.0")
    assert test("1.0.1")
    assert test("1.0.1+x.7.z.92")
    assert test("1.0.1-alpha.1")
    assert test("1.0.1-alpha.1+x.7.z.92")

# Generated at 2022-06-23 14:58:11.646219
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    a_ = _Alpha('a')

    assert a < b
    assert a <= b
    assert a != b
    assert a <= a_
    assert a >= a_
    assert not a > b
    assert not b < a
    assert not a > a_
    assert not a_ < a



# Generated at 2022-06-23 14:58:23.692425
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion("3.2.6")
    print("(3.2.6) is NOT equal to (3.2.6)", v1 != "3.2.6")
    v2 = SemanticVersion("3.2.6-1")
    print("(3.2.6-1) is NOT equal to (3.2.6)", v2 != "3.2.6")
    v3 = SemanticVersion("3.2.6-1+build")
    print("(3.2.6-1+build) is NOT equal to (3.2.6)", v3 != "3.2.6")
    v4 = SemanticVersion("4.2.6")
    print("(4.2.6) is NOT equal to (3.2.6)", v4 != "3.2.6")

# Generated at 2022-06-23 14:58:29.778567
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert not _Numeric('0') > _Numeric('1')
    assert not _Numeric('1') > _Numeric('1')

    assert _Numeric('1') > 0
    assert not _Numeric('0') > 1
    assert not _Numeric('1') > 1


# Generated at 2022-06-23 14:58:33.825007
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    v3 = SemanticVersion('1.2.3+metadata1')

    assert v1 == v2
    assert not v1 != v2
    assert v1 != v3
    assert not v1 == v3
