

# Generated at 2022-06-23 14:48:44.544545
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    # Version 1.0.0 and Version 1.0.0 are equal.
    assert (SemanticVersion('1.0.0') != SemanticVersion('1.0.0')) is False

    # Version 1.0.0 and Version 2.0.0 are not equal.
    assert (SemanticVersion('1.0.0') != SemanticVersion('2.0.0')) is True

    # Version 1.0.0 and Version 1.0.0-beta are not equal.
    assert (SemanticVersion('1.0.0') != SemanticVersion('1.0.0-beta')) is True

    # Version 1.0.0-beta and Version 1.0.0 are not equal.
    assert (SemanticVersion('1.0.0-beta') != SemanticVersion('1.0.0')) is True



# Generated at 2022-06-23 14:48:50.504526
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert (_Alpha('a') < _Alpha('b'))
    assert (_Alpha('a') < _Alpha('a1'))
    assert (_Alpha('a') < _Alpha('1'))
    assert (_Alpha('a') < _Alpha('1a'))
    assert (not (_Alpha('a1') < _Alpha('a')))
    assert (not (_Alpha('1a') < _Alpha('a')))
    assert (not (_Alpha('a') < _Alpha('a')))

# Unit tests for method __lt__ of class _Numeric

# Generated at 2022-06-23 14:48:52.545939
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    w = _Alpha('w')
    assert w >= 'w'


# Generated at 2022-06-23 14:49:01.298385
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    t = _Numeric('1')
    failed_cases = []
    cases = [
        (1, True),
        ('2', False),
    ]
    for c in cases:
        expected, actual = c
        try:
            assert expected == (t.__gt__(c))
        except AssertionError:
            failed_cases.append((expected, actual))
    if failed_cases:
        for expected, actual in failed_cases:
            print('test__Numeric___gt__: FAIL\nExpected: {expected}\nActual: {actual}'.format(expected=expected, actual=actual))
        raise AssertionError
    else:
        print('test__Numeric___gt__: PASS')


# Generated at 2022-06-23 14:49:09.339890
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')).vstring == '1.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')).vstring == '1.2.3-alpha'

# Generated at 2022-06-23 14:49:19.372146
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion(vstring='1.2.3') <= SemanticVersion(vstring='1.2.3')
    assert SemanticVersion(vstring='1.2.3.4') <= SemanticVersion(vstring='1.2.3.4')
    assert SemanticVersion(vstring='1.2.3-alpha') <= SemanticVersion(vstring='1.2.3-alpha')
    assert SemanticVersion(vstring='1.2.3-alpha.1.2') <= SemanticVersion(vstring='1.2.3-alpha.1.2')
    assert SemanticVersion(vstring='1.2.3+build.5.6') <= SemanticVersion(vstring='1.2.3+build.5.6')

    assert SemanticVersion(vstring='1.2.3') <= Sem

# Generated at 2022-06-23 14:49:29.859982
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('0.0.1') < SemanticVersion('0.0.2')
    assert SemanticVersion('0.0.1') < SemanticVersion('0.0.2-alpha.1')
    assert SemanticVersion('0.0.1-alpha') < SemanticVersion('0.0.2')
    assert SemanticVersion('0.0.1-alpha.1') < SemanticVersion('0.0.1-alpha.2')
    assert SemanticVersion('0.0.1-alpha.1') < SemanticVersion('0.0.1-beta.1')
    assert SemanticVersion('0.0.1-alpha.1') < SemanticVersion('0.0.1-0.3.7')

# Generated at 2022-06-23 14:49:37.297562
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric('1') > 0
    assert _Numeric(1) > '0'
    assert not _Numeric(1) > 1
    assert not _Numeric(1) > _Numeric(1)
    assert not _Numeric(1) > '1'
    assert _Numeric(1) > _Alpha('0')
    assert not _Numeric(1) > _Alpha('2')
    assert not _Numeric('a') > 0
    assert not _Alpha('a') > 0
    assert not _Alpha('a') > _Alpha('0')


# Generated at 2022-06-23 14:49:42.587955
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    result = SemanticVersion('1.5.1') < '1.5.1'
    assert result == False
    result = SemanticVersion('1.5.1') < '1.5.1+build1'
    assert result == False
    result = SemanticVersion('1.5.1') < '1.5.1-beta1'
    assert result == False
    result = SemanticVersion('1.5.1') < '1.5.1-beta1+build2'
    assert result == False
    result = SemanticVersion('1.5.1') < '1.5.0'
    assert result == False
    result = SemanticVersion('1.5.1') < '1.4.2'
    assert result == False

# Generated at 2022-06-23 14:49:51.893909
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    def check(v1, v2, expected):
        sv1 = SemanticVersion(v1)
        sv2 = SemanticVersion(v2)
        if sv1 > sv2 != expected:
            raise AssertionError("{0} {1} {2}".format(v1, ">" if expected else "!>", v2))
        if sv2 < sv1 != expected:
            raise AssertionError("{0} {1} {2}".format(v2, "<" if expected else "!<", v1))

    # Test equal versions
    check("1.0.0", "1.0.0", False)
    check("2.0.0", "2.0.0", False)
    check("1.1.0", "1.1.0", False)

# Generated at 2022-06-23 14:50:01.036826
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    o_t = _Alpha('test')
    o_s = _Alpha('test')

    assert o_t == o_s
    assert o_s == o_t

    o_t2 = _Alpha('test2')

    assert o_t != o_t2
    assert o_t2 != o_t

    assert o_t == 'test'
    assert 'test' == o_t
    assert o_t2 == 'test2'
    assert 'test2' == o_t2
    assert o_t != 'test2'
    assert 'test2' != o_t
    assert o_t2 != 'test'
    assert 'test' != o_t2


# Generated at 2022-06-23 14:50:03.088571
# Unit test for constructor of class _Numeric
def test__Numeric():
    if _Numeric('1') == '1':
        return True
    return False


# Generated at 2022-06-23 14:50:06.396855
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    a = SemanticVersion("1.2.3")
    b = "1.2.3"
    assert a != b


# Generated at 2022-06-23 14:50:09.828859
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha('a') > 'a'
    assert not _Alpha('a') > 'b'
    assert _Alpha('b') > 'a'
    assert not _Alpha('a') > 1
    assert _Alpha('a') > 0
    assert _Alpha('b') > 1


# Generated at 2022-06-23 14:50:18.146004
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # Regression test for init being declared as a function instead
    # of a method
    assert SemanticVersion().major is None


# Generated at 2022-06-23 14:50:19.319523
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha("alpha").__repr__() == "'alpha'"


# Generated at 2022-06-23 14:50:23.223140
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    # Equals to itself
    assert _Alpha('1') == _Alpha('1')
    # Equals to same
    assert _Alpha('1') == '1'
    # Does not equal to different
    assert not _Alpha('1') == '2'
    # Does not equal to nothing
    assert not _Alpha('1') == None


# Generated at 2022-06-23 14:50:23.804483
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    pass

# Generated at 2022-06-23 14:50:30.486255
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    import pytest
    assert _Alpha("foo") > _Alpha("bar")
    assert _Alpha("foo0") > _Alpha("foo")
    assert _Alpha("foo") == _Alpha("foo")
    assert _Alpha("foo") > "bar"
    with pytest.raises(ValueError):
        assert _Alpha("foo") < 10
    assert _Alpha("foo") < "foo0"

    # Unit test for method __lt__ of class _Alpha
    import pytest
    assert _Alpha("bar") < _Alpha("foo")
    assert _Alpha("foo") < _Alpha("foo0")
    assert _Alpha("foo") == _Alpha("foo")
    assert _Alpha("bar") < "foo"
    with pytest.raises(ValueError):
        assert _Alpha("foo") > 10

# Generated at 2022-06-23 14:50:38.809653
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('0') <= _Numeric('0')
    assert _Numeric('0') <= _Numeric('1')
    assert not _Numeric('1') <= _Numeric('0')

    # Unit tests for method __lt__ of class _Numeric
    def test__Numeric___lt__():
        assert _Numeric('0') < _Numeric('1')
        assert not _Numeric('1') < _Numeric('0')

    # Unit tests for method __ge__ of class _Numeric
    def test__Numeric___ge__():
        assert _Numeric('1') >= _Numeric('0')
        assert _Numeric('0') >= _Numeric('0')
        assert not _Numeric('0') >= _Numeric('1')

    # Unit tests for method __eq__ of class _Numeric
   

# Generated at 2022-06-23 14:50:49.102250
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') >= _Alpha('2')
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('1') >= _Alpha('0')
    assert _Alpha('1.0') >= _Alpha('1')
    assert _Alpha('1') >= _Alpha('1.0')
    assert _Alpha('1.0') >= _Alpha('1.0')
    assert _Alpha('1.0.0') >= _Alpha('1.0')
    assert _Alpha('1.0') >= _Alpha('1.0.0')
    assert _Alpha('1.0.0') >= _Alpha('1.0.0')
    assert _Alpha('1.0.0') >= _Alpha('1.0.0-beta')

# Generated at 2022-06-23 14:50:57.114933
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
  # Test case 0
  try:
    Test = _Alpha("Test")
    other = _Alpha("Test")
    expected = True
    actual = Test.__eq__(other)
    assert actual == expected
  except AssertionError as e:
    raise AssertionError("Test case 0: " + str(e))
  # Test case 1
  try:
    Test = _Alpha("Test")
    other = "Test"
    expected = True
    actual = Test.__eq__(other)
    assert actual == expected
  except AssertionError as e:
    raise AssertionError("Test case 1: " + str(e))
  # Test case 2

# Generated at 2022-06-23 14:50:59.274290
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    a = _Alpha('a')
    assert a.__repr__() == "'a'"


# Generated at 2022-06-23 14:51:09.405908
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-23 14:51:15.218319
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') < 'beta'
    assert not _Alpha('alpha') < 'alpha'
    assert not _Alpha('beta') < _Alpha('alpha')
    try:
        _Alpha('a') < 1
        raise AssertionError
    except ValueError:
        pass
    try:
        _Alpha('a') < _Numeric('1')
        raise AssertionError
    except ValueError:
        pass


# Generated at 2022-06-23 14:51:22.352764
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    x, y = SemanticVersion('1.2.3'), SemanticVersion('1.2.3')
    assert not x > y and not x > '1.2.3'
    x, y = SemanticVersion('1.2.4'), SemanticVersion('1.2.3')
    assert x > y and x > '1.2.3'
    x, y = SemanticVersion('1.3.3'), SemanticVersion('1.2.3')
    assert x > y and x > '1.2.3'
    x, y = SemanticVersion('2.2.3'), SemanticVersion('1.2.3')
    assert x > y and x > '1.2.3'
    x, y = SemanticVersion('1.2.3-beta.1'), SemanticVersion('1.2.3')

# Generated at 2022-06-23 14:51:32.202958
# Unit test for method __le__ of class SemanticVersion

# Generated at 2022-06-23 14:51:33.452239
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('15')) == repr(15)



# Generated at 2022-06-23 14:51:38.072400
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('alpha') < 'alpha'
    assert not _Alpha('alpha') < 'Alpha'
    assert not _Alpha('alpha') < 'beta'
    assert _Alpha('alpha') < _Alpha('beta')
    assert not _Alpha('alpha') < _Alpha('Alpha')
    assert not _Alpha('alpha') < _Numeric('0')
    assert not _Alpha('alpha') < _Numeric('1')
    assert _Alpha('alpha') < _Numeric('2')


# Generated at 2022-06-23 14:51:43.822222
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # import pdb; pdb.set_trace()
    sv = SemanticVersion("0.0.1")
    assert sv.major == 0
    assert sv.minor == 0
    assert sv.patch == 1
    assert sv.prerelease == tuple()
    assert sv.buildmetadata == tuple()

    sv = SemanticVersion("1.2.3")
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == tuple()
    assert sv.buildmetadata == tuple()

    sv = SemanticVersion("1.2.3-rc1")
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == (_Alpha("rc"), _Numeric("1"))
    assert sv.buildmetadata

# Generated at 2022-06-23 14:51:50.399401
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    """
    Verify correct behavior of _Alpha.__ge__() with three versions of
    python before fixing this issue
    """
    # 2.7
    assert _Alpha('7').__ge__(u'7') is True
    # 3.5
    assert _Alpha('7').__ge__(u'7') is True
    # 3.6
    assert _Alpha('7').__ge__(u'7') is True



# Generated at 2022-06-23 14:52:00.654712
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # test: without a vstring
    assert SemanticVersion() is not None

    # test: empty vstring
    assert SemanticVersion('') is not None

    # test: production version
    v = SemanticVersion('1.0.0')
    assert v is not None
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    # test: prerelease version
    v = SemanticVersion('1.0.0-alpha.1')
    assert v is not None
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Alpha('alpha'), _Numeric(1))
    assert v.buildmetadata == ()

    # test

# Generated at 2022-06-23 14:52:04.199594
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("1") <= "1"
    assert _Alpha("1") <= _Alpha("1")
    assert _Alpha("1") <= _Alpha("2")
    assert _Alpha("1") < _Alpha("2")
    assert not _Alpha("1") >= _Alpha("2")
    assert not _Alpha("1") > _Alpha("2")


# Generated at 2022-06-23 14:52:05.349240
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    pass



# Generated at 2022-06-23 14:52:17.088900
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Compare two semantic versions
    assert SemanticVersion("1.2.3") == SemanticVersion("1.2.3")
    assert not SemanticVersion("1.2.3") != SemanticVersion("1.2.3")

    # Compare two semantic versions with prerelease
    assert SemanticVersion("1.2.3-alpha.1") == SemanticVersion("1.2.3-alpha.1")
    assert not SemanticVersion("1.2.3-alpha.1") != SemanticVersion("1.2.3-alpha.1")

    # Compare two semantic versions with prerelease and build metadata
    assert SemanticVersion("1.2.3-alpha.1+build") == SemanticVersion("1.2.3-alpha.1+build")
    assert not SemanticVersion("1.2.3-alpha.1+build")

# Generated at 2022-06-23 14:52:25.773651
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('bc')
    assert _Alpha('bc') < _Alpha('bc1')
    assert _Alpha('abc') < _Alpha('bcd')
    assert _Alpha('ab1') < _Alpha('ab10')
    assert _Alpha('a') < _Alpha('aa')
    assert _Alpha('1a') < _Alpha('2a')
    assert _Alpha('1b') < _Alpha('2a')
    assert _Alpha('a') < 'b'
    assert _Alpha('1a').specifier < '1b'
    assert _Alpha('a').specifier < 'b'
    assert _Alpha('1a') < '1b'
    assert _Alpha('a') < b'b'
    assert _Alpha('a') < text_

# Generated at 2022-06-23 14:52:33.708433
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Numeric('3') > _Alpha('3')
    assert _Numeric('3') >= _Alpha('3')
    assert _Alpha('3') < _Numeric('3')
    assert _Alpha('3') <= _Numeric('3')
    assert _Alpha('3') <= _Alpha('3')
    assert _Alpha('3') >= _Alpha('3')
    assert _Alpha('4') > _Alpha('3')
    assert _Alpha('4') >= _Alpha('3')
    assert _Alpha('3') < _Alpha('4')
    assert _Alpha('3') <= _Alpha('4')
    assert _Alpha('3') != _Alpha('4')
    assert _Alpha('4') != _Alpha('3')
    assert _Alpha('4') == _Alpha('4')
    assert _Alpha('4') <= _Alpha('4')

# Generated at 2022-06-23 14:52:42.599703
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert( _Numeric('0') < _Numeric('1') )
    assert( _Numeric('0') < _Numeric('9') )
    assert( not (_Numeric('1') < _Numeric('0')) )
    assert( _Numeric('9') < _Numeric('10') )
    assert( not (_Numeric('10') < _Numeric('9')) )
    assert( not (_Numeric('9') < _Numeric('9')) )
    assert( not (_Numeric('10') < _Numeric('10')) )



# Generated at 2022-06-23 14:52:48.119374
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    # Test with _Alpha objects
    assert _Alpha('1.2.3') == _Alpha('1.2.3')
    assert not _Alpha('1.2.3') == _Alpha('1.2.3.4')

    # Test with strings
    assert _Alpha('1.2.3') == '1.2.3'
    assert not _Alpha('1.2.3') == '1.2.3.4'


# Generated at 2022-06-23 14:52:51.263316
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(3) < _Numeric(5)
    assert _Numeric(3) < _Numeric('5')
    assert _Numeric('3') < _Numeric(5)
    assert _Numeric('3') < _Numeric('5')


# Generated at 2022-06-23 14:52:58.896136
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    from ansible.module_utils.basic import AnsibleModule
    # Capture the module arguments so that we can re-use this test function
    # for other test functions
    (failed,
     changed,
     msg,
     v1,
     v2) = AnsibleModule(argument_spec={'v1': {'required': True},
                                        'v2': {'required': True}}).run_command('./test_SemanticVersion___gt__.py v1=%s v2=%s' %(v1,v2))

    # Unit test code
    # Create instances of SemanticVersion and compare
    v1 = SemanticVersion(v1)
    v2 = SemanticVersion(v2)
    assert v1 > v2
    return (failed, changed, msg)



# Generated at 2022-06-23 14:53:07.963921
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    # Check that when two versions are not equal, __ne__ returns True
    assert SemanticVersion('1.0.0') != SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') != SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') != SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0') != SemanticVersion('1.0.0-beta')

    # Check that when two versions are equal, __ne__ returns False
    assert not SemanticVersion('1.0.0') != SemanticVersion('1.0.0')
    assert not SemanticVersion('1.0.0-beta') != SemanticVersion('1.0.0-beta')



# Generated at 2022-06-23 14:53:09.339054
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < _Alpha('2')


# Generated at 2022-06-23 14:53:13.401558
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('1') >= _Numeric('2') == False
    assert _Numeric('2') >= _Numeric('2') == True
    assert _Numeric('3') >= _Numeric('2') == True



# Generated at 2022-06-23 14:53:17.756216
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('a')
    b = _Alpha('b')

    assert (a > b) is False
    assert (a > 'b') is False
    assert (a > _Numeric('a')) is False

    assert (b > a) is True
    assert (b > 'a') is True
    assert (b > _Numeric('a')) is True


# Generated at 2022-06-23 14:53:19.891704
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    obj = _Alpha(specifier='5')
    other = _Alpha(specifier='5')
    res = (obj != other)
    assert not res


# Generated at 2022-06-23 14:53:25.241250
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(b'1') <= b'1'
    assert _Numeric('1') <= '1'
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Alpha('1')

    assert not _Numeric(2) <= b'1'
    assert not _Numeric(2) <= '1'
    assert not _Numeric(2) <= 1
    assert not _Numeric(2) <= _Numeric(1)
    assert not _Numeric(2) <= _Alpha('1')


# Generated at 2022-06-23 14:53:28.307465
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    v1 = _Numeric(1)
    v2 = _Numeric(2)

    assert v1 < v2
    assert not v1 > v2


# Generated at 2022-06-23 14:53:37.748457
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:53:39.728615
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    instance = _Numeric(1)
    expected = repr(1)
    actual = repr(instance)

    assert actual == expected


# Generated at 2022-06-23 14:53:41.654708
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    """Test that units of measure are comparable using =="""
    x = _Numeric(10)
    assert x == 10



# Generated at 2022-06-23 14:53:43.799049
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n_obj = _Numeric(1)
    
    assert n_obj.__eq__(1)
    assert n_obj.__eq__(_Numeric(1))
    
    

# Generated at 2022-06-23 14:53:56.048251
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-1.4.4.4')) == SemanticVersion('1.0.0-1.4.4.4')

# Generated at 2022-06-23 14:54:03.260944
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(0) == _Numeric(0)
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(0) == _Numeric(1)
    assert not _Numeric(1) == _Numeric(0)
    assert not _Numeric(0) == text_type('1')
    assert not _Numeric(1) == text_type('0')
    assert not _Numeric(1) == 0
    assert not _Numeric(0) == 1


# Generated at 2022-06-23 14:54:06.641601
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('1')
    b = _Alpha('2')
    assert (a < b)
    assert not (a > b)
    assert (a <= b)
    assert not (a >= b)


# Generated at 2022-06-23 14:54:16.944473
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test any SemanticVersion
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.1")) == SemanticVersion("0.0.1")
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.1-1-2-3")) == SemanticVersion("0.0.1-1-2-3")
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.1-alpha")) == SemanticVersion("0.0.1-alpha")
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.1-1.2.3.a.b.c")) == SemanticVersion("0.0.1-1.2.3.a.b.c")
    assert SemanticVersion.from_loose_

# Generated at 2022-06-23 14:54:25.715752
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('0.9.9')
    assert not (SemanticVersion('1.0.0') > SemanticVersion('1.0.0'))
    assert not (SemanticVersion('1.0.0') > SemanticVersion('1.0.1'))
    assert not (SemanticVersion('1.0.0') > SemanticVersion('1.0.0-beta'))
    assert not (SemanticVersion('1.0.0') > SemanticVersion('1.0.0+build'))
    assert not (SemanticVersion('1.0.0') > SemanticVersion('1.0.0-beta+build'))


# Generated at 2022-06-23 14:54:29.677198
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('something') != _Alpha('Something')
    assert _Alpha('a') == _Alpha('a')
    # Unit test for method __lt__ of class _Alpha

# Generated at 2022-06-23 14:54:33.195495
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    Numeric_test = _Numeric("3")
    n = 9
    result = True
    if Numeric_test >= n:
        result = True
    else:
        result = False
    assert result


# Generated at 2022-06-23 14:54:38.887212
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    v1 = SemanticVersion('1.3.2')
    v2 = SemanticVersion('2.2.2')
    v3 = SemanticVersion('1.3.2')

    assert v1 == v3
    assert v1 < v2
    assert v1 <= v3
    assert v1 != v2
    assert v2 >= v3



# Generated at 2022-06-23 14:54:47.745579
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') < 'a'
    assert not _Alpha('a') > 'a'

    assert _Alpha('a') <= 'b'
    assert not _Alpha('a') >= 'b'
    assert _Alpha('a') < 'b'
    assert not _Alpha('a') > 'b'

    assert not _Alpha('b') <= 'a'
    assert _Alpha('b') >= 'a'
    assert not _Alpha('b') < 'a'
    assert _Alpha('b') > 'a'


# Generated at 2022-06-23 14:54:54.898770
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # Test comparisons of strings
    assert _Alpha('1') <= _Alpha('1')
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('2') > _Alpha('1')

    # Test comparisons of strings and integers
    assert _Alpha('1') <= _Alpha(1)
    assert _Alpha('1') < _Alpha(2)
    assert _Alpha('1') >= _Alpha(1)
    assert _Alpha('2') > _Alpha(1)

    # Test comparisons of strings and strings
    assert _Alpha('foo') <= 'foo'
    assert _Alpha('foo') < 'bar'
    assert _Alpha('bar') >= 'bar'
    assert _Alpha('foo') > 'bar'

    # Test comparisons of strings, integers and strings
    assert _

# Generated at 2022-06-23 14:55:01.346362
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Test that __lt__ works correctly
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert not(_Alpha('a') < _Alpha('a'))
    assert not(_Alpha('a') < 'a')
    assert not(_Alpha('b') < _Alpha('a'))
    assert not(_Alpha('b') < 'a')
    # Test for ValueError
    try:
        _Alpha('a') < 1
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-23 14:55:03.041066
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < 2


# Generated at 2022-06-23 14:55:10.823566
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == 1
    assert _Numeric(1) != '1'
    assert _Numeric('1') == 1
    assert _Numeric('1') != '1'

    assert _Numeric(1) < 2
    assert _Numeric(2) > 1
    assert _Numeric(1) <= 2
    assert _Numeric(1) <= 1
    assert _Numeric(1) >= 1
    assert _Numeric(2) >= 1

    assert _Numeric(2) < 3.0
    assert _Numeric(3.0) > 2
    assert _Numeric(2) <= 3.0
    assert _Numeric(2) <= 2
    assert _Numeric(2) >= 2
    assert _Numeric(3.0) >= 2

    assert _Numeric(2) < 3.

# Generated at 2022-06-23 14:55:16.126640
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion("1.0.1") >= SemanticVersion("1.0.0")
    assert SemanticVersion("1.0.1") >= SemanticVersion("1.0.1")
    assert SemanticVersion("1.0.0-alpha.1") >= SemanticVersion("1.0.0-alpha")
    assert SemanticVersion("1.0.0-alpha.1") >= SemanticVersion("1.0.0-alpha.beta")
    assert SemanticVersion("1.0.0-alpha.1") >= SemanticVersion("1.0.0-alpha.1")
    assert SemanticVersion("1.0.0-alpha.1") >= SemanticVersion("1.0.0-alpha.1+build.1")



# Generated at 2022-06-23 14:55:21.732867
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert(_Alpha('alpha') > 'alpha') == False
    assert(_Alpha('alpha') > 'beta') == True
    assert(_Alpha('alpha') > 'omega') == True
    assert(_Alpha('beta') > 'alpha') == False
    assert(_Alpha('beta') > 'beta') == False
    assert(_Alpha('beta') > 'omega') == True
    assert(_Alpha('omega') > 'alpha') == False
    assert(_Alpha('omega') > 'beta') == False
    assert(_Alpha('omega') > 'omega') == False


# Generated at 2022-06-23 14:55:24.268825
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    if SemanticVersion('2.0.1') >= '1.0.0':
        print('Passed')
    else:
        print('Failed')

# Generated at 2022-06-23 14:55:33.520540
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('1') == _Alpha('1')
    assert _Alpha('1') != _Alpha('2')
    assert not _Alpha('1') > _Alpha('1')
    assert not _Alpha('1') < _Alpha('1')
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('1') <= _Alpha('1')
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('2') > _Alpha('1')
    assert _Alpha('1') <= _Alpha('2')
    assert _Alpha('2') >= _Alpha('1')
    assert _Alpha('a') > _Alpha('1')
    assert _Alpha('1') < _Alpha('a')
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') >= _Alpha('a')
   

# Generated at 2022-06-23 14:55:42.020102
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert ( isinstance(SemanticVersion("1.2.3").__eq__("1.2.3-alpha.1+build.1"), bool) )
    assert ( SemanticVersion("1.2.3").__eq__("1.2.3-alpha.1+build.1") == True )
    assert ( SemanticVersion("1.2.3").__eq__("1.2.3-alpha.1+build.1") == True )
    assert ( SemanticVersion("1.2.3").__eq__("1.2.3-alpha.1+build.1") == True )
    assert ( SemanticVersion("1.2.3").__eq__("1.2.3-alpha.1+build.1") == True )

# Generated at 2022-06-23 14:55:45.909838
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    _alpha_one = _Alpha('alpha')
    _alpha_two = _Alpha('beta')
    _alpha_three = _Alpha('alpha')
    assert _alpha_one != _alpha_two
    assert _alpha_one != _alpha_three



# Generated at 2022-06-23 14:55:57.182395
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    sv = SemanticVersion()
    assert sv.parse('0.0.0') == None
    assert sv.major == 0
    assert sv.minor == 0
    assert sv.patch == 0

    assert sv.parse('3.0.0') == None
    assert sv.major == 3
    assert sv.minor == 0
    assert sv.patch == 0

    assert sv.parse('3.2.1') == None
    assert sv.major == 3
    assert sv.minor == 2
    assert sv.patch == 1

    assert sv.parse('3.2.1-alpha.1') == None
    assert sv.major == 3
    assert sv.minor == 2
    assert sv.patch == 1
    assert sv.prerelease == tuple([_Numeric('alpha'), _Numeric('1')])


# Generated at 2022-06-23 14:56:00.619317
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alpha1 = _Alpha('beta')
    alpha2 = _Alpha('dev')
    alpha3 = _Alpha('beta')
    numeric1 = _Numeric(10)

    assert alpha1 > alpha2
    assert alpha2 > numeric1
    assert not alpha1 > alpha3


# Generated at 2022-06-23 14:56:12.226756
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # Test non _Alpha instance
    foo = _Alpha('foo')
    assert foo > 'foo'
    assert foo > 'fo'
    assert not foo > 'foot'

    assert foo >= 'foo'
    assert foo >= 'fo'
    assert not foo >= 'foot'

    # Test with different _Alpha instance
    bar = _Alpha('bar')
    assert foo > bar
    assert not foo > foo

    assert foo >= bar
    assert foo >= foo

    # Test different type
    assert not bar > 1
    assert not bar >= 1
    assert bar < 1
    assert bar <= 1

    # Test equality
    assert not foo < 'foo'
    assert foo <= 'foo'

    assert not foo < foo
    assert foo <= foo

    assert not bar < bar
    assert bar <= bar

    assert not bar < 'bar'


# Generated at 2022-06-23 14:56:17.693227
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Integer
    value = _Numeric(1)
    assert value < 2
    assert value < _Numeric(2)
    assert value < _Alpha('2')
    assert not value < _Alpha('1')

    # String
    value = _Alpha('a')
    assert value < 'b'
    assert value < _Alpha('b')
    assert value < _Numeric(1)

    # ValueError
    value = _Numeric(1)
    try:
        value < 'a'
        assert False
    except ValueError:
        assert True



# Generated at 2022-06-23 14:56:20.197551
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Arrange
    A = _Alpha('a')
    B = _Alpha('b')

    # Check
    assert A < B



# Generated at 2022-06-23 14:56:24.263600
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('b') > _Alpha('a')
    assert not _Alpha('a') < _Alpha('a')
    assert not _Alpha('a') < 'a'


# Generated at 2022-06-23 14:56:34.943016
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('1.2.3').parse('1.2.3') == (1, 2, 3)
    assert SemanticVersion('1.2.3-alpha').parse('1.2.3-alpha') == (1, 2, 3, 'alpha')
    assert SemanticVersion('1.2.3+build').parse('1.2.3+build') == (1, 2, 3, '', 'build')
    assert SemanticVersion('1.2.3-alpha+build').parse('1.2.3-alpha+build') == (1, 2, 3, 'alpha', 'build')
    assert SemanticVersion('1.2.3.4-alpha.5').parse('1.2.3.4-alpha.5') == (1, 2, 3, 'alpha.5')

# Generated at 2022-06-23 14:56:42.740732
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    from distutils.version import LooseVersion
    # Test numeric versions
    assert SemanticVersion('1.2.3') >= LooseVersion('1.2.3')
    assert SemanticVersion('1.2.3') >= LooseVersion('1.2.2')
    assert SemanticVersion('1.2.3') >= LooseVersion('1.1.3')
    assert SemanticVersion('1.2.3') >= LooseVersion('0.2.3')
    assert SemanticVersion('1.2.3') >= LooseVersion('0.2.2')
    assert SemanticVersion('1.2.3') >= LooseVersion('0.1.3')
    assert SemanticVersion('0.2.3') >= LooseVersion('0.2.2')
    assert SemanticVersion('0.2.3') >= Lo

# Generated at 2022-06-23 14:56:51.968535
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion

    This is not part of the unit tests in the module,
    but run manually to ensure that it works as expected.
    """

    def test_case(loose_version_string, expected_semver_string):
        """Test case method

        This takes a ``LooseVersion`` string, constructs a ``SemanticVersion``
        from it and compares it against the ``expected_semver_string``.
        """
        tv = SemanticVersion.from_loose_version(LooseVersion(loose_version_string))
        assert str(tv) == expected_semver_string, \
            ('%s -> %s != %s' % (loose_version_string, tv.vstring, expected_semver_string))

    # This includes all possible test cases with

# Generated at 2022-06-23 14:56:59.541144
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    v.parse("1.2.3-alpha.10.beta.0+build.unicorn.rainbow")
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == (_Numeric("alpha"), _Numeric("10"), _Alpha("beta"), _Numeric("0"))
    assert v.buildmetadata == (_Alpha("build"), _Alpha("unicorn"), _Alpha("rainbow"))



# Generated at 2022-06-23 14:57:04.050112
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Define two object of type _Numeric
    a = _Numeric("1")
    b = _Numeric("2")

    if not (a < b):
        raise AssertionError()
    if a > b:
        raise AssertionError()
    if a >= b:
        raise AssertionError()
    if not (b > a):
        raise AssertionError()
    if not (b >= a):
        raise AssertionError()


# Generated at 2022-06-23 14:57:06.067202
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == '1'
    assert repr(_Numeric('12')) == '12'
    assert repr(_Numeric('123')) == '123'


# Generated at 2022-06-23 14:57:10.626508
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # equal
    assert SemanticVersion("1.0.0") == SemanticVersion("1.0.0")
    assert SemanticVersion("1.0.0+foo") == SemanticVersion("1.0.0+foo")
    assert SemanticVersion("1.0.0-bar") == SemanticVersion("1.0.0-bar")
    assert SemanticVersion("1.0.0-bar+foo") == SemanticVersion("1.0.0-bar+foo")

    # not equal
    assert SemanticVersion("1.0.0") != SemanticVersion("1.2.0")
    assert SemanticVersion("1.0.0") != SemanticVersion("2.0.0")
    assert SemanticVersion("1.0.0") != SemanticVersion("0.0.1")

# Generated at 2022-06-23 14:57:14.211224
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1) == _Numeric(1)
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != _Alpha("1")



# Generated at 2022-06-23 14:57:16.298925
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == 'SemanticVersion(\'1.2.3\')'


# Generated at 2022-06-23 14:57:18.854992
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    specifier = 'alpha'
    alpha = _Alpha(specifier)
    expected = repr(specifier)
    assert alpha.__repr__() == expected


# Generated at 2022-06-23 14:57:26.550549
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert not (_Numeric(1) < _Numeric(1))
    assert not (_Numeric(1) < _Numeric(0))
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(0)
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) >= _Numeric(0)
    assert _Numeric(1) >= _Numeric(1)
    assert not (_Numeric(1) > _Numeric(1))


# Generated at 2022-06-23 14:57:30.021607
# Unit test for constructor of class _Numeric
def test__Numeric():
    n = _Numeric(2)

    assert n.specifier == 2
    assert repr(n) == repr(2)

    assert n == 2
    assert n != 1

    assert n < 3
    assert n <= 3
    assert n <= 2
    assert not n < 2
    assert not n <= 1

    assert n > 1
    assert n >= 1
    assert n >= 2
    assert not n > 2
    assert not n >= 3

# Generated at 2022-06-23 14:57:40.640194
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('0.9.0').parse('0.9.0').vstring == '0.9.0'
    assert SemanticVersion('0.9.0').parse('0.9.0').major == 0
    assert SemanticVersion('0.9.0').parse('0.9.0').minor == 9
    assert SemanticVersion('0.9.0').parse('0.9.0').patch == 0
    assert SemanticVersion('0.9.0').parse('0.9.0').prerelease == ()
    assert SemanticVersion('0.9.0').parse('0.9.0').buildmetadata == ()

    assert SemanticVersion('0.9.0-alpha1').parse('0.9.0-alpha1').vstring == '0.9.0-alpha1'
    assert SemanticVersion

# Generated at 2022-06-23 14:57:49.199316
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests for valid inputs
    assert SemanticVersion.from_loose_version('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1.0.0-foo') == SemanticVersion('1.0.0-foo')
    assert (
        SemanticVersion.from_loose_version(
            '1.0.0+metadata-moremetadata-and-even-more-metadata'
        ) ==
        SemanticVersion('1.0.0+metadata-moremetadata-and-even-more-metadata')
    )
    assert SemanticVersion.from_loose_version('1.0.0-prerelease+metadata') == SemanticVersion('1.0.0-prerelease+metadata')

# Generated at 2022-06-23 14:57:51.759495
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    alpha_lower = _Alpha('a')
    alpha_higher = _Alpha('z')

    assert(alpha_lower < alpha_higher)
    assert(alpha_higher > alpha_lower)
    assert(alpha_lower == _Alpha('a'))
    assert(alpha_higher == _Alpha('z'))



# Generated at 2022-06-23 14:57:56.759593
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion("1.2.3") == SemanticVersion("1.2.3")
    assert not (SemanticVersion("1.2.3") != SemanticVersion("1.2.3"))

    assert SemanticVersion("1.2.3") == "1.2.3"
    assert not (SemanticVersion("1.2.3") != "1.2.3")

    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3")
    assert not (SemanticVersion.from_loose_version(LooseVersion("1.2.3")) != SemanticVersion("1.2.3"))

    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == "1.2.3"
   

# Generated at 2022-06-23 14:58:00.824529
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.1')) == repr(SemanticVersion('0.0.1'))
    assert repr(SemanticVersion('0.0.1')) != repr(SemanticVersion('0.0.2'))


# Generated at 2022-06-23 14:58:03.664163
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha("text")) == repr("text")
    assert repr(_Alpha("text too")) == repr("text too")
    assert repr(_Alpha("text too long")) == repr("text too long")


# Generated at 2022-06-23 14:58:13.405807
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') < 'b'
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('b') > 'a'
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('b') >= 'a'
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('b') >= 'b'
    assert _Alpha('b') >= _Alpha('b')
    

# Generated at 2022-06-23 14:58:17.506052
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('a')
    assert not _Alpha('b') <= _Alpha('a')


# Generated at 2022-06-23 14:58:24.412452
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert not _Alpha('a') < _Alpha('a')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('a1')
    assert _Alpha('a') < _Alpha('a1b')
    assert _Alpha('a1') < _Alpha('a1b')
    assert _Alpha('a1') < _Alpha('a2')
    assert _Alpha('a1') < _Alpha('b')
    assert _Alpha('a1') < _Alpha('b1')


# Generated at 2022-06-23 14:58:27.448227
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    """
    Test method ``_Alpha.__ne__()``
    """

    assert _Alpha('2') != '2'



# Generated at 2022-06-23 14:58:27.998243
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    pass

# Generated at 2022-06-23 14:58:31.908735
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('123') == _Numeric('123')
    assert not (_Numeric('123') == _Numeric('321'))
    assert not (_Numeric('123') == 123)
    assert _Numeric('123') == 123


# Generated at 2022-06-23 14:58:39.455140
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.1')

    assert SemanticVersion('1.0.0-rc1') <= SemanticVersion('1.0.0-rc2')
    assert SemanticVersion('1.0.0-rc1') <= SemanticVersion('1.0.0')

    assert SemanticVersion('1.0.0-rc1+foo') <= SemanticVersion('1.0.0-rc1+foo')
    assert SemanticVersion('1.0.0-rc1+foo') <= SemanticVersion('1.0.0-rc1+bar')
