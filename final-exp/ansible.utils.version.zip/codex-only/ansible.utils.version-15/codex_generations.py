

# Generated at 2022-06-23 14:48:29.601840
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('test') > 'test'
    assert not _Alpha('test') > 'testing'


# Generated at 2022-06-23 14:48:32.218135
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < _Alpha('2')
    assert _Numeric('1') < '2'



# Generated at 2022-06-23 14:48:36.286242
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('3') > _Alpha('a')
    assert _Alpha('3') > 'a'
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('b') > 'a'
    #assert _Alpha('a') < 3


# Generated at 2022-06-23 14:48:47.694958
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # Tests for constructor with valid strings
    assert isinstance(SemanticVersion('1.0.0'), SemanticVersion)
    assert isinstance(SemanticVersion('0.2.4'), SemanticVersion)
    assert isinstance(SemanticVersion('1.2.3-alpha.10.beta.0+build.unicorn.rainbow'), SemanticVersion)
    assert isinstance(SemanticVersion('0.2.4-alpha'), SemanticVersion)

    # Tests for constructor with invalid strings
    try:
        SemanticVersion('1.0')
        assert False
    except ValueError:
        pass
    try:
        SemanticVersion('2.0.1.1')
        assert False
    except ValueError:
        pass

# Generated at 2022-06-23 14:48:55.224662
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    """
    Ensure the '>=' comparison for the _Alpha() class works as expected.
    """
    assert _Alpha("1") >= "1"
    assert _Alpha("1") >= _Alpha("1")
    assert _Alpha("1") >= _Numeric("0")
    assert _Alpha("0") >= _Numeric("0")
    assert _Alpha("1") >= _Numeric("1")
    assert _Alpha("beta") >= _Numeric("0")
    assert _Alpha("beta") >= _Numeric("1")



# Generated at 2022-06-23 14:49:02.796435
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    from nose.tools import assert_equal, assert_true, assert_false

    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0')

    assert_true(v1 <= v2)
    assert_false(v1 < v2)

    v3 = SemanticVersion('1.0.0-beta.2')
    assert_true(v1 > v3)
    assert_false(v1 >= v3)

    v4 = SemanticVersion('1.0.0-beta.1')
    assert_true(v3 > v4)
    assert_false(v3 >= v4)

# Generated at 2022-06-23 14:49:10.788077
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    numeric = _Numeric("1")
    alpha = _Alpha("2")

    assert numeric < alpha
    assert alpha > numeric
    assert numeric <= alpha
    assert alpha >= numeric
    assert numeric != alpha

    assert not numeric == alpha
    assert not alpha == numeric
    assert not numeric > alpha
    assert not alpha < numeric
    assert not numeric >= alpha
    assert not alpha <= numeric

    numeric = _Numeric("2")
    alpha = _Alpha("2")
    numeric2 = _Numeric("2")

    assert numeric2 == alpha
    assert alpha == numeric2

    assert numeric2 <= alpha
    assert alpha <= numeric2
    assert numeric2 >= alpha
    assert alpha >= numeric2

    assert not numeric2 < alpha
    assert not alpha < numeric2
    assert not numeric2 > alpha
    assert not alpha > numeric2

    assert not numeric

# Generated at 2022-06-23 14:49:13.071054
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('rc1')
    assert a.__ne__(None)
    assert a.__ne__('')
    assert a.__ne__('rc1')
    assert not a.__ne__('rc1')


# Generated at 2022-06-23 14:49:21.672462
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert not _Alpha('1') < _Alpha('1')
    assert _Alpha('alpha') < _Alpha('beta')
    assert not _Alpha('beta') < _Alpha('alpha')
    assert _Alpha('1') < _Alpha('alpha')
    assert not _Alpha('alpha') < _Alpha('1')
    assert not _Alpha('1.0') < _Alpha('1')
    assert not _Alpha('1') < _Alpha('1.0')
    assert _Alpha('1.0.0') < _Alpha('1')
    assert not _Alpha('1') < _Alpha('1.0.0')
    assert _Alpha('1.0.1') < _Alpha('1.0.0')
    assert not _Alpha('1.0.0') < _Alpha('1.0.1')


# Generated at 2022-06-23 14:49:25.514258
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    alpha_equal = _Alpha('1') == _Alpha('1')
    alpha_not_equal = _Alpha('2') != _Alpha('2')
    assert alpha_equal is True
    assert alpha_not_equal is False


# Generated at 2022-06-23 14:49:35.094592
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    val = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert val == '1.0.0'

    val = SemanticVersion.from_loose_version(LooseVersion('1.0.0a'))
    assert val == '1.0.0-a'

    val = SemanticVersion.from_loose_version(LooseVersion('1.0.0a0'))
    assert val == '1.0.0-a0'

    val = SemanticVersion.from_loose_version(LooseVersion('1.0.0a0b'))
    assert val == '1.0.0-a0b'

    val = SemanticVersion.from_loose_version(LooseVersion('1.0.0abc'))

# Generated at 2022-06-23 14:49:44.943814
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # Instantiating a SemanticVersion with a valid semantic version should work.
    assert SemanticVersion("0.0.1").vstring == "0.0.1"
    assert SemanticVersion("1.0.0").vstring == "1.0.0"
    assert SemanticVersion("1.2.3").vstring == "1.2.3"
    assert SemanticVersion("1.2.3-alpha").vstring == "1.2.3-alpha"
    assert SemanticVersion("1.2.3-alpha.5").vstring == "1.2.3-alpha.5"
    assert SemanticVersion("1.2.3+1234").vstring == "1.2.3+1234"

    # Missing parts of the string should raise a ValueError

# Generated at 2022-06-23 14:49:53.255580
# Unit test for method __ne__ of class _Numeric

# Generated at 2022-06-23 14:49:57.071797
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('alpha')
    b = _Alpha('beta')
    c = 'beta'
    assert not a.__ge__(b) # False
    assert a.__ge__(c) # True


# Generated at 2022-06-23 14:49:58.713312
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion("123.456.789") >= SemanticVersion("123.456.789")



# Generated at 2022-06-23 14:50:00.521572
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha("specifier")
    assert repr(alpha) == "'specifier'"



# Generated at 2022-06-23 14:50:02.315544
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    v = _Numeric('1')
    assert repr(v) == '1'


# Generated at 2022-06-23 14:50:11.889929
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():

    # Test SemanticVersion.__repr__
    semver = SemanticVersion('1.1.1')
    assert semver.__repr__() == 'SemanticVersion(\'1.1.1\')'

    # Test SemanticVersion.__repr__
    semver = SemanticVersion('1.1.1-alpha')
    assert semver.__repr__() == 'SemanticVersion(\'1.1.1-alpha\')'

    # Test SemanticVersion.__repr__
    semver = SemanticVersion('1.1.1+alpha')
    assert semver.__repr__() == 'SemanticVersion(\'1.1.1+alpha\')'

    # Test SemanticVersion.__repr__
    semver = SemanticVersion('1.1.1-alpha+alpha')
   

# Generated at 2022-06-23 14:50:17.315419
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('hello').specifier == 'hello'
    assert repr(_Alpha('hello')) == "'hello'"
    assert _Alpha('hello') == 'hello'
    assert _Alpha('hello') != 'world'
    assert _Alpha('hello') < 'world'
    assert _Alpha('hello') <= 'world'
    assert _Alpha('hello') < 'hello '  # space matters
    assert _Alpha('hello') <= 'hello'
    assert not _Alpha('hello') > 'hello'
    assert not _Alpha('hello') >= 'hello'


# Generated at 2022-06-23 14:50:25.749206
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("1.2.3+alpha1") == SemanticVersion("1.2.3+alpha1")
    assert SemanticVersion("1.2.3+alpha1") != SemanticVersion("1.2.3+alpha2")
    assert SemanticVersion("1.2.3+alpha1") != SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3+alpha1") < SemanticVersion("1.2.3+alpha2")
    assert SemanticVersion("1.2.3+alpha1") < SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3+alpha1") <= SemanticVersion("1.2.3+alpha1")

# Generated at 2022-06-23 14:50:33.926977
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('x') == 'x'
    assert _Alpha('x') != 1
    assert _Alpha('x').specifier == 'x'

    assert _Alpha('x') < 'y'
    assert _Alpha('x') < 1
    assert _Alpha('x') <= 'y'
    assert _Alpha('x') <= 1
    assert _Alpha('z') > 'y'
    assert _Alpha('z') >= 'y'

    try:
        _Alpha('z') > 1
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError when comparing with a numeric'



# Generated at 2022-06-23 14:50:42.213397
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Testing Version compare
    ver1 = SemanticVersion('1.0.0')
    ver2 = SemanticVersion('1.1.0')
    assert ver1 < ver2
    assert ver2 > ver1
    assert ver1 <= ver2
    assert ver2 >= ver1
    assert ver1 != ver2
    
    ver3 = SemanticVersion('1.1.0')
    ver4 = SemanticVersion('2.0.0')
    assert ver3 < ver4
    assert ver4 > ver3
    assert ver3 <= ver4
    assert ver4 >= ver3
    assert ver3 != ver4
    
    ver5 = SemanticVersion('2.0.0')
    ver6 = SemanticVersion('2.0.1')
    assert ver5 < ver6
    assert ver6 > ver5
    assert ver

# Generated at 2022-06-23 14:50:51.658557
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("1.0.0").major == 1
    assert SemanticVersion("1.0.0-pre").major == 1
    assert SemanticVersion("1.0.0-pre.0").major == 1
    assert SemanticVersion("1.0.0+pre").major == 1
    assert SemanticVersion("1.0.0+pre.0").major == 1
    assert SemanticVersion("1.0.0-pre.0+pre.0").major == 1
    assert SemanticVersion("1.0.0-pre0+pre0").major == 1
    assert SemanticVersion("1.0.0-pre0.0+pre0.0").major == 1
    assert SemanticVersion("1.0.0-pre0.0pre0.0").major == 1


# Generated at 2022-06-23 14:50:54.116757
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not (_Numeric(1) != _Numeric(1))
    assert not (_Numeric(1) != 1)
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != 2


# Generated at 2022-06-23 14:51:00.509268
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1').specifier == 1
    assert _Numeric('2').specifier == 2
    assert _Numeric('100').specifier == 100
    assert _Numeric('1').specifier != 2
    assert _Numeric('99').specifier < 100
    assert _Numeric('100').specifier <= 100
    assert _Numeric('100').specifier >= 100
    assert _Numeric('1').specifier > 0


# Generated at 2022-06-23 14:51:05.993939
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    """Unit test for method __ne__ of class _Alpha

    :return:
    """
    a = _Alpha('1')
    b = _Alpha('1')
    c = _Alpha('2')
    d = '1'
    e = '2'

    assert a != b
    assert a != c
    assert a != d
    assert a != e



# Generated at 2022-06-23 14:51:11.433989
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha1 = _Alpha('something')
    alpha2 = _Alpha('some')
    assert alpha1.__le__(alpha1) is True
    assert alpha1.__le__('something') is True
    assert alpha2.__le__(alpha1) is True
    assert alpha2.__le__('something') is True
    assert alpha2.__le__(alpha2) is True
    assert alpha2.__le__('some') is True
    assert alpha1.__le__(alpha2) is False
    assert alpha1.__le__('some') is False


# Generated at 2022-06-23 14:51:16.322810
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(2) != 3
    assert _Numeric(2) != _Numeric(3)
    assert _Numeric(3) != 2
    assert _Numeric(3) != _Numeric(2)
    assert _Numeric(2) != _Alpha('2')
    assert _Numeric(2) != _Alpha('3')
    assert _Numeric(3) != _Alpha('2')
    assert _Numeric(3) != _Alpha('3')


# Generated at 2022-06-23 14:51:17.630842
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)


# Generated at 2022-06-23 14:51:22.414149
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('test') >= _Alpha('test')
    assert _Alpha('test') >= 'test'
    assert not _Alpha('test') >= _Alpha('TEST')
    assert not _Alpha('test') >= 'TEST'


# Generated at 2022-06-23 14:51:24.468570
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('1.2.3')
    assert repr(v) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-23 14:51:33.597356
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('0') < SemanticVersion('1')
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.0-beta')
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha.1') < SemanticVersion('1.0.0-alpha.beta')
    assert SemanticVersion('1.0.0-alpha.beta') < SemanticVersion('1.0.0-beta')
    assert SemanticVersion('1.0.0-beta') < SemanticVersion('1.0.0-beta.2')

# Generated at 2022-06-23 14:51:34.145692
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    pass



# Generated at 2022-06-23 14:51:43.750198
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():

    x = _Numeric('54')
    y = _Numeric('56')
    assert not x.__gt__(y)
    assert x.__lt__(y)

    x = _Numeric('54')
    y = _Numeric('43')
    assert x.__gt__(y)
    assert not x.__lt__(y)

    x = _Numeric('54')
    y = _Numeric('54')
    assert not x.__gt__(y)
    assert not x.__lt__(y)

    x = _Numeric('54')
    y = _Alpha('5.5.5')
    assert x.__gt__(y)
    assert not x.__lt__(y)


# Generated at 2022-06-23 14:51:49.545722
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(2) <= _Numeric(2)
    assert _Numeric(1) <= _Alpha('1')
    assert _Numeric(1) <= 1
    assert not _Numeric(2) <= _Alpha('1')
    assert not _Numeric(2) <= 1


# Generated at 2022-06-23 14:51:51.605350
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    testcase = _Alpha('testcase')
    assert repr(testcase) == "'testcase'"



# Generated at 2022-06-23 14:51:53.281488
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(2).__gt__(_Numeric(1)) == True


# Generated at 2022-06-23 14:52:03.069041
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3-pre+meta') == SemanticVersion('1.2.3-pre+meta')
    assert SemanticVersion('1.2.3-pre') == SemanticVersion('1.2.3-pre')
    assert SemanticVersion('1.2.3+build') == SemanticVersion('1.2.3+build')
    assert SemanticVersion('1.2.3-pre+meta') == SemanticVersion('1.2.3-pre+meta')
    assert SemanticVersion('1.2.3-pre1+meta') == SemanticVersion('1.2.3-pre1+meta')
    assert SemanticVersion('1.2.3-pre1+meta1') == Semantic

# Generated at 2022-06-23 14:52:14.635274
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:52:24.597699
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    """Unit test for method `__ge__' of class `_Numeric'"""
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) >= _Numeric(0)
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(0) <= _Numeric(1)
    assert _Numeric(1) != _Numeric(0)
    assert _Numeric(1) not in (_Numeric(0), _Numeric('0'))
    assert _Numeric(1) not in (_Numeric(0), _Alpha('0'))

# Generated at 2022-06-23 14:52:29.150126
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1') == 1
    assert _Numeric('1') < 2
    assert _Numeric('1') <= 1
    assert _Numeric('1') <= 2
    assert _Numeric('1') > 0
    assert _Numeric('1') >= 0
    assert _Numeric('1') >= 1
    assert _Numeric('1') != 2


# Generated at 2022-06-23 14:52:36.045644
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:52:42.282659
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert 1 <= _Numeric(1)
    assert _Numeric(1) <= 1

    assert 1 <= _Numeric(2)
    assert _Numeric(1) <= 2

    assert _Numeric(2) <= 1
    assert 2 <= _Numeric(1)

    assert _Numeric('1') <= _Numeric('1')
    assert _Numeric('1') <= '1'
    assert '1' <= _Numeric('1')

    assert _Numeric('1') <= _Numeric('2')
    assert _Numeric('1') <= '2'
    assert '1' <= _Numeric('2')

    assert _Numeric('2') <= _Numeric('1')
    assert _Numeric('2') <= '1'

# Generated at 2022-06-23 14:52:49.153761
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    # Initialize the class instance x
    x = _Alpha("1.0.0-alpha")

    # Test 1: is x equal to the same class instance?
    assert x == x

    # Test 2: is x equal to a string?
    assert x == "1.0.0-alpha"

    # Test 3: is x equal to an integer?
    assert x != 1

    # Test 4: is x equal to a class instance of _Numeric?
    assert x != _Numeric("1.0.0-alpha")


# Generated at 2022-06-23 14:52:57.390002
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible.module_utils.distro

# Generated at 2022-06-23 14:53:07.223002
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a valid version of a LooseVersion object
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2')) == SemanticVersion('0.1.2')
    # Test an invalid version of a LooseVersion object
    try:
        SemanticVersion.from_loose_version(LooseVersion('0.1.2.3.4'))
    except ValueError:
        pass
    # Test a type error
    try:
        SemanticVersion.from_loose_version('0.1.2')
    except ValueError:
        pass
    # Test a LooseVersion object with prerelease and buildmetadata
    # Build metadata MUST be ignored when determining version precedence
    # https://semver.org/#spec-item-10

# Generated at 2022-06-23 14:53:14.153944
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(0) <= _Numeric(0)
    assert _Numeric(0) <= _Numeric(1)
    assert _Numeric(0) <= _Numeric(100)
    assert _Numeric(10) <= _Numeric(100)
    assert not _Numeric(100) <= _Numeric(10)
    assert not _Numeric(1) <= _Numeric(0)
    assert not _Numeric(0) <= _Numeric(-1)
    assert not _Numeric(-1) <= _Numeric(0)
    assert not _Numeric(-10) <= _Numeric(-1)
    assert not _Numeric(-1) <= _Numeric(-10)
    assert _Numeric(-1) <= _Numeric(-1)

    assert _Numeric(0) <= 0

# Generated at 2022-06-23 14:53:17.001253
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # test_SemanticVersion___lt__ is a function
    #   vstring = 'a'
    #   out = SemanticVersion(vstring) < 'a'
    #   assert out == False
    #   return out
    pass


# Generated at 2022-06-23 14:53:23.479228
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # comparing a semantic version to a loose version
    assert(SemanticVersion('0.0.1-beta') > LooseVersion('0.0.1-alpha.1'))

    # comparing two semantic versions
    assert(SemanticVersion('0.0.1-alpha') > SemanticVersion('0.0.1-alpha.1'))
    assert(SemanticVersion('0.0.1-alpha') > SemanticVersion('0.0.2-alpha'))
    assert(SemanticVersion('0.1.1-alpha') > SemanticVersion('0.2.1-alpha'))
    assert(SemanticVersion('1.1.1-alpha') > SemanticVersion('2.1.1-alpha'))

    # comparing two loose versions

# Generated at 2022-06-23 14:53:33.367272
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    """
    Test for method __ge__ of class SemanticVersion
    """
    version = SemanticVersion('1.0.0-alpha.1')

    assert version.__ge__('1.0.0-alpha.1')
    assert version.__ge__('1.0.0-alpha')
    assert not version.__ge__('1.0.0-0')
    assert not version.__ge__('1.0.0-beta')
    assert not version.__ge__('1.0.0-beta.2')
    assert not version.__ge__('1.0.0-beta.11')
    assert not version.__ge__('1.0.0-rc.1')
    assert not version.__ge__('1.0.0')

# Generated at 2022-06-23 14:53:42.910540
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert (_Numeric('1') > _Numeric('2')) == False
    assert (_Numeric('1') > _Numeric('1')) == False
    assert (_Numeric('1') > _Numeric('0')) == True
    assert (_Numeric('1') > _Alpha('1')) == True
    assert (_Numeric('1') > _Alpha('0')) == True
    assert (_Numeric('1') > int(1)) == False
    assert (_Numeric('1') > int(2)) == False
    assert (_Numeric('1') > int(0)) == True
    assert (_Numeric('1') > str(1)) == False
    assert (_Numeric('1') > str(2)) == False
    assert (_Numeric('1') > str(0)) == True


# Generated at 2022-06-23 14:53:55.294207
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Testing function SemanticVersion.from_loose_version of class SemanticVersion
    """
    import distutils.version as dv
    lv = dv.LooseVersion(str(text_type(SemanticVersion('1.2.3'))))
    sv = SemanticVersion.from_loose_version(lv)
    assert(sv.vstring == '1.2.3')

    lv = dv.LooseVersion('1.2.3.4')
    sv = SemanticVersion.from_loose_version(lv)
    assert(sv.vstring == '1.2.3')

    lv = dv.LooseVersion('1.2.3pre1')
    sv = SemanticVersion.from_loose_version(lv)

# Generated at 2022-06-23 14:53:58.395508
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') != 1


# Generated at 2022-06-23 14:54:06.118516
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.2.3') >= '1.2.3'
    assert SemanticVersion('1.2.4') >= '1.2.3'
    assert SemanticVersion('2.0.0') >= '1.2.3'
    assert SemanticVersion('1.3.3') >= '1.2.3'

    assert SemanticVersion('1.2.3-alpha') >= '1.2.3-alpha'
    assert SemanticVersion('1.2.3-beta') >= '1.2.3-alpha'
    assert SemanticVersion('1.2.3+abc') >= '1.2.3-beta'

    assert not SemanticVersion('1.2.3') >= '1.2.4'

# Generated at 2022-06-23 14:54:16.664765
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('10') < _Alpha('20')
    assert _Alpha('10') < _Alpha('11')
    assert _Alpha('2.0') < _Alpha('3.0')
    assert _Alpha('2.0.3') < _Alpha('3.0.3')
    assert _Alpha('10.1') < _Alpha('10.1a')
    assert _Alpha('10.1') < _Alpha('10.1alpha')
    assert _Alpha('10.1a') < _Alpha('10.1b')
    assert _Alpha('10.1a') < _Alpha('10.1alpha')
    assert _Alpha('10.1a') < _Alpha('10.1alpha.1')
    assert _Alpha('10.1alpha') < _Alpha('10.1b')

# Generated at 2022-06-23 14:54:26.421298
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # If the left operand has a higher major version number the result is True
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0')
    # If the left operand has a higher minor version number the result is True
    assert SemanticVersion('1.2.0') > SemanticVersion('1.1.0')
    # If the left operand has a higher patch version number the result is True
    assert SemanticVersion('1.1.2') > SemanticVersion('1.1.1')
    # If the major, minor and patch version number are equal and the left operand has a larger number of prerelease fields than the result is False
    assert SemanticVersion('1.1.1-a.b') < SemanticVersion('1.1.1-a.b.c')

# Generated at 2022-06-23 14:54:29.126913
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    import pytest
    assert SemanticVersion("1.2.3") != SemanticVersion("1.3.2")


# Generated at 2022-06-23 14:54:39.834678
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('0') < _Numeric('1')
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('2') < _Numeric('3')
    assert _Numeric('3') < _Numeric('4')
    assert _Numeric('4') < _Numeric('5')
    assert _Numeric('5') < _Numeric('6')
    assert _Numeric('6') < _Numeric('7')
    assert _Numeric('7') < _Numeric('8')
    assert _Numeric('8') < _Numeric('9')
    assert _Numeric('9') < _Numeric('10')
    assert _Numeric('9') < _Numeric('11')
    assert _Numeric('9') < _Numeric('12')

# Generated at 2022-06-23 14:54:42.384070
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('a')
    b = _Alpha('b')
    assert a < b
    assert b > a


# Generated at 2022-06-23 14:54:44.817622
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    r = SemanticVersion("1.2.3a")
    assert not r.__ne__("1.2.3a")



# Generated at 2022-06-23 14:54:53.359008
# Unit test for constructor of class _Alpha
def test__Alpha():
    # __init__
    assert _Alpha(1).specifier == 1
    assert _Alpha('1').specifier == '1'
    # __repr__
    assert repr(_Alpha(1)) == "1"
    assert repr(_Alpha('1')) == "'1'"
    # __eq__
    assert _Alpha(1) == 1
    assert _Alpha(1) == _Alpha(1)
    assert _Alpha(1) == '1'
    assert _Alpha('1') == _Numeric(1)
    assert not _Alpha(1) == _Numeric(2)
    # __ne__
    assert not _Alpha(1) != 1
    assert not _Alpha(1) != _Alpha(1)
    assert not _Alpha(1) != '1'
    assert _Alpha('1') != _Numeric(2)


# Generated at 2022-06-23 14:55:02.814782
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Check that equality is not always true
    from random import randint
    from test.support import import_module
    random = import_module('random')
    for i in xrange(0, 100):
        k = randint(0, 100)
        assert not SemanticVersion('').__eq__(k)
        assert not SemanticVersion('{}'.format(k)).__eq__(k+1)
        assert not SemanticVersion('{}.{}'.format(k, k)).__eq__(k+1)
        assert not SemanticVersion('{}.{}.{}'.format(k, k, k)).__eq__(k+1)
        assert not SemanticVersion('{}.{}.{}-alpha'.format(k, k, k)).__eq__(k+1)

# Generated at 2022-06-23 14:55:09.762349
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('0.0.1') > SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-alpha.1')
    assert SemanticVersion('0.0.0-alpha.2') > SemanticVersion('0.0.0-alpha.1')
    assert SemanticVersion('0.0.0-alpha.1') > SemanticVersion('0.0.0-alpha')
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0')
    assert SemanticVersion('1.1.0') > SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.1') > SemanticVersion('1.0.0')

# Generated at 2022-06-23 14:55:19.800852
# Unit test for method __eq__ of class SemanticVersion

# Generated at 2022-06-23 14:55:25.085751
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = '1.2.3'

    sv1 = SemanticVersion()
    sv2 = SemanticVersion(v)

    assert repr(sv1) == "SemanticVersion(None)"
    assert repr(sv2) == "SemanticVersion('%s')" % v


# Generated at 2022-06-23 14:55:33.988360
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    def test_case(left, right):
        assert (SemanticVersion(left) <= SemanticVersion(right)) == (left <= right)

    test_case('1.0.0', '1.0.0') 
    test_case('1.0.0', '2.0.0') 
    test_case('1.0.0', '2.0.0-alpha') 
    test_case('1.0.0', '2.0.0-alpha.1') 
    test_case('1.0.0', '2.0.0-0.3.7') 
    test_case('1.0.0', '1.1.0') 
    test_case('1.0.0', '1.2.0') 

# Generated at 2022-06-23 14:55:35.305646
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    # check outpu
    assert repr(_Alpha('specifier')) == repr('specifier')


# Generated at 2022-06-23 14:55:36.584822
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert text_type(repr(_Numeric('1'))) == text_type("'1'")



# Generated at 2022-06-23 14:55:39.769096
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha1 = _Alpha("a0")
    alpha2 = _Alpha("a1")
    assert alpha1 <= alpha2 is True
    assert alpha2 <= alpha1 is False
    alpha2 = _Alpha("a0")
    assert alpha1 <= alpha2 is True
    assert alpha2 <= alpha1 is True


# Generated at 2022-06-23 14:55:40.768622
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(7)) == repr(7)


# Generated at 2022-06-23 14:55:46.563703
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v0 = SemanticVersion('0.0.0')
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('10.20.30')
    v3 = SemanticVersion('1.2.3-4.5.6')
    v4 = SemanticVersion('1.2.3-4.5.6-7.8.9')
    v5 = SemanticVersion('1.2.3+4.5.6')
    v6 = SemanticVersion('1.2.3+4.5.6-7.8.9')
    v7 = SemanticVersion('1.2.3-4.5.6+7.8.9')

# Generated at 2022-06-23 14:55:51.928819
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    # Test if int and _Numeric can be compared.
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == _Numeric(2)
    assert not _Numeric(1) == None

    assert _Numeric(1) == 1
    assert not _Numeric(1) == 2


# Generated at 2022-06-23 14:56:01.984456
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():

    # creation of a SemanticVersion object from a string
    v_string_3 = '1.2.3'
    v_string_3_buildmetadata = '1.2.3+build.1'
    v_string_3_prerelease = '1.2.3-rc.1.2'
    v_string_3_prerelease_buildmetadata = '1.2.3-rc.1.2+build.1'
    v_string_4 = '2.0.0-alpha.1'
    v_string_4_buildmetadata = '2.0.0-alpha.1+build.1'
    v_string = '3.0.0'

    # This SemanticVersion object is used for the unit test
    v_3 = SemanticVersion(v_string_3)
    v_3_build

# Generated at 2022-06-23 14:56:04.988040
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('2.1.3')
    assert repr(v) == "SemanticVersion('2.1.3')"


# Generated at 2022-06-23 14:56:10.050429
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha(1) < _Alpha(2)
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('b') < _Alpha('c')
    assert _Alpha(1) < _Alpha('2')
    assert _Alpha(1) < '2'


# Generated at 2022-06-23 14:56:17.700042
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    sv1 = SemanticVersion('1.2.3')
    sv2 = SemanticVersion('1.2.3-alpha')
    sv3 = SemanticVersion('1.2.3-beta')
    sv4 = SemanticVersion('1.2.3-rc')
    sv5 = SemanticVersion('1.2.3')

    assert sv1.__lt__(sv2)
    assert sv2.__lt__(sv3)
    assert sv3.__lt__(sv4)
    assert not sv4.__lt__(sv5)
    assert not sv5.__lt__(sv1)

if __name__ == '__main__':
    test_SemanticVersion___lt__()

# Generated at 2022-06-23 14:56:29.140839
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    import unittest

    class TestSemanticVersion___gt__(unittest.TestCase):
        def test_SemanticVersion___gt__(self):
            self.assertEqual(SemanticVersion('1.2.3-alpha') > SemanticVersion('1.2.3-alpha.1'), False)
            self.assertEqual(SemanticVersion('1.2.3-alpha.1') > SemanticVersion('1.2.3-alpha'), True)
            self.assertEqual(SemanticVersion('1.2.3-alpha') > SemanticVersion('1.2.3-alpha.beta'), False)
            self.assertEqual(SemanticVersion('1.2.3-alpha.beta') > SemanticVersion('1.2.3-alpha'), True)

# Generated at 2022-06-23 14:56:32.809096
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'a'
    assert not _Alpha('a') != 'a'
    return True



# Generated at 2022-06-23 14:56:35.299343
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v1 = SemanticVersion('0.9.9')
    assert repr(v1) == "SemanticVersion('0.9.9')"



# Generated at 2022-06-23 14:56:40.758865
# Unit test for constructor of class _Numeric
def test__Numeric():
    try:
        _Numeric([])
        raise AssertionError
    except ValueError:
        pass

    assert _Numeric(None) == 0
    assert _Numeric(False) == 0
    assert _Numeric(True) == 1
    assert _Numeric('') == 0
    assert _Numeric('0') == 0
    assert _Numeric(0) == 0
    assert _Numeric('1') == 1
    assert _Numeric(1) == 1



# Generated at 2022-06-23 14:56:44.123548
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
  """Unit test for method __lt__ of class _Numeric"""
  a = _Numeric('1')
  b = _Numeric('2')
  assert a < b
  print('Success')


# Generated at 2022-06-23 14:56:52.594740
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-23 14:57:02.441378
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    #  Check if method __lt__ of class _Numeric works correctly.

    # Create an instance of class _Numeric
    numeric = _Numeric(5)

    # Check if numeric is correctly compared with 5 to be equal with numeric
    assert numeric.__eq__(5) is True

    # Check if numeric is correctly compared with 5 to be not equal with numeric
    assert numeric.__ne__(5) is False

    # Check if numeric is correctly compared with 4 to be less than numeric
    assert numeric.__lt__(4) is False

    # Check if numeric is correctly compared with 5 to be less than numeric
    assert numeric.__lt__(5) is False

    # Check if numeric is correctly compared with 6 to be less than numeric
    assert numeric.__lt__(6) is True

    # Check if numeric is correctly compared with 4 to be less than

# Generated at 2022-06-23 14:57:06.929560
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    semver = SemanticVersion('1.7.1')
    assert semver.__ne__('1.7.2') is True
    assert semver.__ne__(SemanticVersion('1.7.2')) is True
    assert semver.__ne__('1.7.1') is False
    assert semver.__ne__(SemanticVersion('1.7.1')) is False


# Generated at 2022-06-23 14:57:17.972309
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('0.9.9')
    assert SemanticVersion('0.8.1') > SemanticVersion('0.8.0')
    assert SemanticVersion('5.0.0') > SemanticVersion('4.12.1')
    assert SemanticVersion('1.3.0') > SemanticVersion('1.2.7')
    assert SemanticVersion('0.1.1') > SemanticVersion('0.1.0')
    assert SemanticVersion('2.5.5') > SemanticVersion('2.5.4')
    assert SemanticVersion('2.5.5') > SemanticVersion('2.5.3')
    assert SemanticVersion('2.5.5') > SemanticVersion('2.4.4')

# Generated at 2022-06-23 14:57:20.085200
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1) != 1


# Generated at 2022-06-23 14:57:28.717084
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    def test(expected, *args):
        result = args[0].__lt__(args[1])
        if not result == expected:
            raise AssertionError((
                "expected {0!r}.__lt__({1!r}) to return {2!r} but "
                "it returned {3!r}").format(args[0], args[1], expected, result))

    # regular versions
    test(False, SemanticVersion('2.0.0'), SemanticVersion('2.0.0'))
    test(False, SemanticVersion('2.0.0'), SemanticVersion('2.0.1'))
    test(False, SemanticVersion('2.0.0'), SemanticVersion('2.1.0'))

# Generated at 2022-06-23 14:57:30.789030
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():

    # test _Numeric with str specifier
    assert repr(_Numeric("10")) == "10"

    # test _Numeric with invalid specifier
    try:
        _Numeric("test")
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 14:57:32.333117
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)



# Generated at 2022-06-23 14:57:37.992350
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'b'
    assert 'b' != _Alpha('a')


# Generated at 2022-06-23 14:57:41.717770
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    n1=_Numeric(1)
    n2=_Numeric(2)
    n3=_Numeric(3)

    assert n2 > n1
    assert n3 > n2


# Generated at 2022-06-23 14:57:50.192978
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0-alpha') == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha.1') == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-0.3.7') == SemanticVersion('1.0.0-0.3.7')
    assert SemanticVersion('1.0.0-x.7.z.92') == SemanticVersion('1.0.0-x.7.z.92')
    assert SemanticVersion('1.0.0-alpha+001') == SemanticVersion('1.0.0-alpha+001')

# Generated at 2022-06-23 14:57:52.773498
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('1')) == "'1'"
    assert repr(_Alpha(1)) == "'1'"
    assert repr(_Alpha('1.2.3')) == "'1.2.3'"


# Generated at 2022-06-23 14:57:56.039702
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    s = SemanticVersion("1.2.3-alpha.1")
    if s == "1.2.3-alpha.1":
        assert True
    else:
        assert False

# Generated at 2022-06-23 14:58:01.617468
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert not _Numeric(5) > _Numeric(5)
    assert _Numeric(5) > _Numeric(4)
    assert not _Numeric(5) > _Numeric(6)
    assert not _Numeric(5) > '5'
    assert _Numeric(5) > '4'
    assert not _Numeric(5) > '6'


# Generated at 2022-06-23 14:58:07.995231
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # x <= y
    # x < y or x == y
    # x <= w and w < y
    # x <= w and w < y or x <= w and w == y
    # x <= w <= y
    # x <= w <= y or x < w <= y and w == x
    
    # x: a.b.c
    # y: p.q.r
    # w: u.v.w
    
    # major ==
    # major <
    # major >
    # major !=
    
    # minor ==
    # minor <
    # minor >
    # minor !=
    
    # patch ==
    # patch <
    # patch >
    # patch !=
    
    from itertools import product
    

# Generated at 2022-06-23 14:58:12.291919
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric('1') > _Alpha('0')
    assert not _Numeric('1') > _Numeric('1')
    assert not _Numeric('1') > _Alpha('1')
    assert not _Numeric('1') > _Alpha('2')


# Generated at 2022-06-23 14:58:23.819828
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= _Alpha('1')
    assert _Numeric(1) >= _Alpha('1.1')
    assert _Numeric(1) >= 0
    assert _Numeric(1) >= _Numeric(0)
    assert _Numeric(1) >= _Alpha('0')
    assert not _Numeric(1) >= 1.1
    assert not _Numeric(1) >= _Alpha('1.1')
    assert not _Numeric(1) >= 2
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= _Alpha('2')
    assert not _Numeric(1) >= _Alpha('a')
    assert not _N

# Generated at 2022-06-23 14:58:27.449641
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert(_Numeric(1) != 2)
    assert(_Numeric(2) != 1)
    assert(_Numeric(1) != '1')
    assert(_Numeric('1') != 1)


# Generated at 2022-06-23 14:58:32.714088
# Unit test for constructor of class _Numeric
def test__Numeric():
    # Test constructor of _Numeric
    assert _Numeric(1) == _Numeric("1")
    assert _Numeric(1) != _Numeric("2")
    assert _Numeric("1") == _Numeric(1)
    assert _Numeric("1") != _Numeric(2)
    assert _Numeric("1") != _Numeric("2")
