

# Generated at 2022-06-23 14:48:36.030576
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    a = _Numeric(1)
    b = _Numeric(2)
    assert a < b, 'a={} should be less than b={}'.format(a, b)


# Generated at 2022-06-23 14:48:37.513970
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric("1") == _Numeric("1")


# Generated at 2022-06-23 14:48:40.468567
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    obj = _Alpha('a')
    assert obj == 'a'
    assert obj > 1
    assert obj > '1'
    assert obj > _Numeric('1')


# Generated at 2022-06-23 14:48:42.085084
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('foo')) == "'foo'"


# Generated at 2022-06-23 14:48:51.280101
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    """
    Unittest for method SemanticVersion.__lt__
    """

    # Less than
    assert SemanticVersion('1.2.2') < SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.3.3')
    assert SemanticVersion('1.3.3') < SemanticVersion('2.3.3')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3-alpha') < SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3-alpha.1') < SemanticVersion('1.2.3-alpha.beta')

# Generated at 2022-06-23 14:48:52.913893
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    f = SemanticVersion("1.2.3")
    t = SemanticVersion("1.2.3")
    assert f == t


# Generated at 2022-06-23 14:48:55.002015
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    x = _Numeric(1)
    assert x >= 1
    assert x >= 0
    assert not x >= 2


# Generated at 2022-06-23 14:48:56.685876
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    result = _Numeric(1).__repr__()
    assert result == '1'


# Generated at 2022-06-23 14:48:59.567515
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('3') != _Numeric('1')
    assert _Numeric('3') != _Numeric('3')
    assert _Numeric('3') != _Numeric('2')


# Generated at 2022-06-23 14:49:06.376415
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    # should compare two _Alpha instances
    a1 = _Alpha('abc')
    a2 = _Alpha('abc')
    assert(a1 == a2)
    a1 = _Alpha('abc')
    a2 = _Alpha('xyz')
    assert(a1 != a2)
    a1 = _Alpha('abc')
    assert(a1 == 'abc')
    a1 = _Alpha('abc')
    assert(a1 != 'xyz')
    a1 = _Alpha('abc')
    assert(not a1 == 123)
    a1 = _Alpha('abc')
    assert(not a1 != 123)


# Generated at 2022-06-23 14:49:13.300620
# Unit test for constructor of class _Numeric
def test__Numeric():
    _Numeric('1')
    _Numeric('-1')
    _Numeric('+1')

    try:
        _Numeric('a')
    except ValueError:
        pass
    else:
        assert False, "_Numeric('a') should have raised an exception"

    try:
        _Numeric('1a')
    except ValueError:
        pass
    else:
        assert False, "_Numeric('1a') should have raised an exception"



# Generated at 2022-06-23 14:49:15.317040
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion("1.2.0").__ne__("1.2.1")



# Generated at 2022-06-23 14:49:19.516002
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('1.3.3') == _Alpha('1.3.3')
    assert _Alpha('1.3.3') == '1.3.3'
    assert not (_Alpha('1.3.3') == _Alpha('1.3.4'))
    assert not (_Alpha('1.3.3') == '1.3.4')


# Generated at 2022-06-23 14:49:24.993445
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') >= SemanticVersion('0.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('2.0.0')


# Generated at 2022-06-23 14:49:34.581548
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert not _Numeric('1') > _Numeric('1')
    assert not _Numeric('1') > _Numeric('2')
    assert not _Numeric('0') > _Numeric('2')

    # Numbers should always be greater than strings
    assert _Numeric('1') > _Alpha('0')
    assert _Numeric('1') > _Alpha('foo')
    assert _Numeric('2') > _Alpha('foo')

    # These should not be equal
    assert not _Numeric('0') == _Alpha('0')
    assert not _Numeric('1') == _Alpha('1')
    assert not _Numeric('2') == _Alpha('2')

    # Now, we should get an error

# Generated at 2022-06-23 14:49:39.633747
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    a = 1
    na = _Numeric(a)
    b = '4'
    nb = _Numeric(b)
    c = 'alpha'
    nc = _Alpha(c)
    assert na >= a
    assert not nb >= a
    assert na >= b
    assert nb >= b
    assert c >= na
    assert not c >= nb
    assert not c >= nc

# Generated at 2022-06-23 14:49:41.870902
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    sv1 = SemanticVersion('0.2.0')
    sv2 = SemanticVersion('0.2.0')
    assert sv1 == sv2


# Generated at 2022-06-23 14:49:51.241459
# Unit test for constructor of class _Alpha
def test__Alpha():
    a1 = _Alpha("")
    assert a1.specifier == ""
    assert a1.specifier == u""
    assert not (a1.specifier == 1)
    assert a1.specifier != 1
    assert not (a1.specifier != "")

    a2 = _Alpha("")
    assert a2.specifier == ""
    assert a1 == a2
    assert not (a1 != a2)

    a1 = _Alpha("a")
    assert a1.specifier == "a"
    assert not (a1.specifier == b"a")
    assert a1.specifier != b"a"
    assert not (a1.specifier != "a")

    a2 = _Alpha("a")
    assert a2.specifier == "a"
    assert a1 == a2
   

# Generated at 2022-06-23 14:50:01.775171
# Unit test for method __le__ of class _Alpha

# Generated at 2022-06-23 14:50:07.823579
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('foo') < _Alpha('foofoo')
    assert _Alpha('foo') < _Alpha('foo1')
    assert _Alpha('foo') < _Alpha('foo.1')
    assert _Alpha('foo') < _Alpha('foo+1')

    assert not _Alpha('foo') < _Alpha('foo')
    assert not _Alpha('foo+1') < _Alpha('foo')
    assert not _Alpha('foo+1') < _Alpha('foo.1')
    assert not _Alpha('foo+1') < _Alpha('foofoo')



# Generated at 2022-06-23 14:50:15.493464
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Case 1:
    # semantic version 1.0.0 is lower than or equal to semantic version 2.0.0
    result = SemanticVersion('1.0.0') <= SemanticVersion('2.0.0')
    assert result

    # Case 2:
    # semantic version 1.0.0 is lower than or equal to semantic version 1.0.0
    result = SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    assert result

    # Case 3:
    # semantic version 2.0.0 is not lower than or equal to semantic version 1.0.0
    result = SemanticVersion('2.0.0') <= SemanticVersion('1.0.0')
    assert not result


# Generated at 2022-06-23 14:50:19.792453
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) != 2
    assert _Numeric(1) != _Alpha('1')
    assert _Numeric(1) != _Alpha('2')
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) != _Numeric(2)


# Generated at 2022-06-23 14:50:21.852037
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('2')
    b = _Alpha('foo')
    c = _Alpha('2')

    assert a != b
    assert a != c



# Generated at 2022-06-23 14:50:24.209993
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    obj = _Numeric(specifier=0)
    obj2 = _Numeric(specifier=0)
    assert not obj.__ne__(obj2)


# Generated at 2022-06-23 14:50:30.741169
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') >= '1.0.0'
    assert not SemanticVersion('0.0.0') >= SemanticVersion('1.0.0')
    assert not SemanticVersion('0.0.0') >= '1.0.0'
    assert not SemanticVersion('1.0.0-alpha') >= SemanticVersion('1.0.0')
    assert not SemanticVersion('1.0.0-alpha') >= '1.0.0'
    assert SemanticVersion('1.0.0-alpha.3') >= SemanticVersion('1.0.0-alpha.3')

# Generated at 2022-06-23 14:50:35.821210
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('x') == 'x'
    assert _Alpha('x') == _Alpha('x')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('a') >= _Alpha('a')


# Generated at 2022-06-23 14:50:40.157869
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != None
    assert _Numeric(1) != 1
    assert _Numeric(1) != '1'
    assert _Numeric(1) != _Numeric(2)
    assert not _Numeric(1) != _Numeric(1)
    assert not _Numeric(1) != 1
    assert not _Numeric(1) != '1'


# Generated at 2022-06-23 14:50:48.178276
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # < on 2 numbers
    # < on number and string
    # < on number and Unicode string
    # < on number and numeric string
    # < on number and non-numeric string
    num = _Numeric(1)
    assert num < 2
    assert num < '2'
    assert num < text_type('2')
    assert num < '2a'
    assert num < 'a2'
    assert num < _Alpha('a')

    # > on 2 numbers
    # > on number and string
    # > on number and Unicode string
    # > on number and numeric string
    # > on number and non-numeric string
    num = _Numeric(2)
    assert num > 1
    assert num > '1'
    assert num > text_type('1')
    assert num > '1a'

# Generated at 2022-06-23 14:50:53.126913
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # given
    vstring = "1.2.3-alpha.1+build.2"
    # when
    result = SemanticVersion(vstring)
    # then
    assert result.major == 1
    assert result.minor == 2
    assert result.patch == 3
    assert result.prerelease == (_Numeric('alpha'), _Numeric('1'))
    assert result.buildmetadata == (_Alpha('build'), _Numeric('2'))



# Generated at 2022-06-23 14:50:59.585227
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('foo') < _Alpha('foo1')
    assert _Alpha('foo1') < _Alpha('foo2')
    assert _Alpha('foo') < _Alpha('foo01')
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('2') < _Alpha('foo')
    assert _Alpha('2') < _Alpha('foo1')
    assert _Alpha('2') < _Alpha('foo01')
    assert _Alpha('2') < _Alpha('alpha')

    assert not _Alpha('foo') < _Alpha('foo')
    assert not _Alpha('foo1') < _Alpha('foo1')
    assert not _Alpha('foo01') < _Alpha('foo01')
    assert not _Alpha('alpha') < _Alpha('alpha')

# Generated at 2022-06-23 14:51:03.173989
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == 1
    assert _Numeric('42') == 42
    try:
        _Numeric('foo')
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-23 14:51:11.235936
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    """Unit test for method __ne__ of class _Numeric."""
    test__list = (
        (1, True),
        ('0', True),
        ('1.0', True),
        ('1', False),
    )

    for (specifier, result) in test__list:
        test__obj = _Numeric(specifier)
        test__result = test__obj.__ne__(1)
        if test__result != result:
            raise Exception('TEST FAILED: _Numeric.__ne__(%r) returned %r, expected %r' % (specifier, test__result, result))


# Generated at 2022-06-23 14:51:13.767331
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1).__ne__(1)


# Generated at 2022-06-23 14:51:17.062791
# Unit test for constructor of class _Numeric
def test__Numeric():
    try:
        v = _Numeric(5)
    except ValueError:
        raise AssertionError("_Numeric object construction with valid value failed")
    if v.specifier != 5:
        raise AssertionError("_Numeric object construction with valid value returned wrong value")

    try:
        _Numeric('test')
    except ValueError:
        pass
    else:
        raise AssertionError("_Numeric object construction with invalid value failed to raise ValueError")


# Generated at 2022-06-23 14:51:18.552517
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.1.1') != '1.1.2'


# Generated at 2022-06-23 14:51:24.112876
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    v1 = _Numeric(1)
    v2 = _Numeric(2)

    assert v1 == v2 is False
    assert v1 == 1
    assert v1 == _Numeric(1)
    assert v1 == 1.0 is False
    assert v1 == '1' is False


# Generated at 2022-06-23 14:51:31.199686
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = '0.0.1-alpha.1+dev.4.5'
    version_object = SemanticVersion(version)
    version_object.parse(version)

    assert version_object.major == 0
    assert version_object.minor == 0
    assert version_object.patch == 1
    assert version_object.prerelease == (_Numeric('alpha'), _Numeric('1'))
    assert version_object.buildmetadata == (_Numeric('dev'), _Numeric('4'), _Numeric('5'))



# Generated at 2022-06-23 14:51:32.370576
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    numeric = _Numeric('1')
    assert numeric.__repr__() == '1'


# Generated at 2022-06-23 14:51:35.792228
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    """Unit test for method __repr__ of class _Alpha"""
    assert repr(_Alpha('a')) == text_type("'a'")
    assert repr(_Alpha('9')) == text_type("'9'")
    assert repr(_Alpha('.')) == text_type("'.'")


# Generated at 2022-06-23 14:51:44.525873
# Unit test for method __eq__ of class SemanticVersion

# Generated at 2022-06-23 14:51:50.178036
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    # No error should occur when x and y are equal
    # No error should occur when x and y are not equal
    x = _Alpha('5')
    assert x.__ne__('a5') == True
    assert x.__ne__('5') == False
    assert x.__ne__('6') == True



# Generated at 2022-06-23 14:51:56.407578
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert (_Numeric(0) > _Numeric(1)) == False
    assert (_Numeric(1) > _Numeric(0)) == True
    assert (_Numeric(1) > _Numeric(1)) == False
    assert (_Numeric(1) > _Numeric(2)) == False
    assert (_Numeric(2) > _Numeric(1)) == True


# Generated at 2022-06-23 14:52:02.834750
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("alpha") >= "alpha"
    assert _Alpha("alpha") >= _Alpha("alpha")
    assert not _Alpha("alpha") >= "AlPha"
    assert not _Alpha("alpha") >= _Alpha("AlPha")
    assert not _Alpha("alpha") >= 1
    assert not _Alpha("alpha") >= _Numeric("1")
    assert _Alpha("alpha") >= "al"
    assert _Alpha("alpha") >= _Alpha("al")
    assert not _Alpha("alpha") >= "beta"
    assert not _Alpha("alpha") >= _Alpha("beta")



# Generated at 2022-06-23 14:52:05.801479
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    v = _Numeric('1')
    assert repr(v) == "1"

    v = _Numeric(1)
    assert repr(v) == "1"



# Generated at 2022-06-23 14:52:17.603028
# Unit test for constructor of class SemanticVersion

# Generated at 2022-06-23 14:52:21.334929
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') == 1
    assert _Numeric('1') < 2
    assert _Numeric('1') > 0
    assert _Numeric('1') >= 1
    assert _Numeric('1') <= 1


# Generated at 2022-06-23 14:52:23.996211
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('1') <= _Alpha('2')
    assert _Alpha('2') <= _Alpha('2')
    assert _Alpha('2') >= _Alpha('1')
    assert _Alpha('2') >= _Alpha('2')


# Generated at 2022-06-23 14:52:29.348021
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    i1 = _Numeric(1)
    i2 = _Numeric(2)
    s1 = _Alpha('1')
    s2 = _Alpha('2')

    assert i1 < i2
    assert i1 < s2
    assert i1 <= i2
    assert i1 <= s2

    assert i2 > i1
    assert i2 > s1
    assert i2 >= i1
    assert i2 >= s1



# Generated at 2022-06-23 14:52:34.779130
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # test with valid version
    v = SemanticVersion.from_loose_version(LooseVersion('2.10.9'))
    assert v.major == 2
    assert v.minor == 10
    assert v.patch == 9
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    # test with invalid version
    try:
        SemanticVersion.from_loose_version(LooseVersion('_2.10.9'))
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-23 14:52:38.425433
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < 10
    assert not _Numeric(1) < 1
    assert _Numeric(2) > 1


# Generated at 2022-06-23 14:52:47.608755
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    """_Alpha.__eq__() Test method"""

    # Test with _Alpha and _Alpha
    a = _Alpha("abc")
    b = _Alpha("abc")
    result = a.__eq__(b)
    assert result is True, "Result is not True with _Alpha and _Alpha"

    # Test with _Alpha and unicode
    a = _Alpha(u"abc")
    b = u"abc"
    result = a.__eq__(b)
    assert result is True, "Result is not True with _Alpha and unicode"

    # Test with _Alpha and str
    a = _Alpha("abc")
    b = "abc"
    result = a.__eq__(b)
    assert result is True, "Result is not True with _Alpha and str"

    # Test with _Alpha and not equal
    a

# Generated at 2022-06-23 14:52:52.670657
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('x') < 'x'
    assert _Alpha('x') < 'y'
    assert _Alpha('x') < '1'
    assert _Alpha('x') < _Alpha('y')
    assert _Alpha('x') < _Alpha('1')
    assert _Alpha('x') < _Numeric('1')
    assert _Alpha('x') < _Numeric('0')


# Generated at 2022-06-23 14:52:56.953518
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha(3)) == "3"
    assert repr(_Alpha("3")) == "'3'"
    assert repr(_Alpha(b"3")) == "'3'"
    assert repr(_Alpha("alpha")) == "'alpha'"
    assert repr(_Alpha("beta")) == "'beta'"
    assert repr(_Alpha("rc5")) == "'rc5'"
    assert repr(_Alpha("a")) == "'a'"


# Generated at 2022-06-23 14:53:02.413430
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') != '1.2.3'
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.3') != '1.2.4'


# Generated at 2022-06-23 14:53:05.429736
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    semantic_version_1 = SemanticVersion("1.0.0")
    semantic_version_2 = SemanticVersion("2.0.0")
    assert semantic_version_1 <= semantic_version_2


# Generated at 2022-06-23 14:53:10.794929
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():

    text1 = 'foo'
    text2 = 'bar'
    alpha1 = _Alpha(text1)
    alpha2 = _Alpha(text2)

    assert (alpha1 < text1) is False
    assert (alpha1 < text2) is False
    assert (alpha1 < alpha1) is False
    assert (alpha1 < alpha2) is False

    assert (alpha2 < text2) is False
    assert (alpha2 < text1) is True
    assert (alpha2 < alpha1) is True
    assert (alpha2 < alpha2) is False


# Generated at 2022-06-23 14:53:12.367980
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    number = _Numeric(100)
    string = _Alpha('100')

    assert number == string
    assert string == number



# Generated at 2022-06-23 14:53:20.991594
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Method from_loose_version of class SemanticVersion converts a LooseVersion to SemanticVersion

    Also tests that input is a LooseVersion
    """
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+build.1')) == SemanticVersion('1.0.0+build.1')

# Generated at 2022-06-23 14:53:32.298911
# Unit test for method __le__ of class SemanticVersion

# Generated at 2022-06-23 14:53:33.998621
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion("1.2.3-beta") == "1.2.3-beta"


# Generated at 2022-06-23 14:53:37.020948
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion(vstring='1.4.5')
    assert version.__repr__() == 'SemanticVersion(\'1.4.5\')'


# Generated at 2022-06-23 14:53:38.327088
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('201').__ne__('2')



# Generated at 2022-06-23 14:53:39.601351
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('spec')) == "'spec'"


# Generated at 2022-06-23 14:53:46.962862
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('0').specifier == 0
    assert _Numeric('1').specifier == 1
    assert _Numeric('2').specifier == 2
    assert _Numeric('3').specifier == 3
    assert _Numeric('4').specifier == 4
    assert _Numeric('5').specifier == 5
    assert _Numeric('6').specifier == 6
    assert _Numeric('7').specifier == 7
    assert _Numeric('8').specifier == 8
    assert _Numeric('9').specifier == 9
    assert _Numeric('10').specifier == 10
    assert _Numeric('11').specifier == 11
    assert _Numeric('12').specifier == 12
    assert _Numeric('13').specifier == 13
    assert _Numeric('14').specifier == 14
    assert _N

# Generated at 2022-06-23 14:53:52.584850
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('b')
    assert _Alpha('b') >= _Alpha('b')
    assert _Alpha('c') >= _Alpha('b')
    assert _Alpha('a') >= 'b'
    assert _Alpha('b') >= 'b'
    assert _Alpha('c') >= 'b'



# Generated at 2022-06-23 14:54:01.619329
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    ver1 = SemanticVersion('4.4.7-alpha.1+build.12.e0f985a-1')
    ver2 = SemanticVersion('4.4.7-alpha.1+build.12.e0f985a-1')
    assert ver1.__le__(ver2) == True
    ver1 = SemanticVersion('4.4.7-alpha.1+build.12.e0f985a-1')
    ver2 = SemanticVersion('4.4.7-alpha.1+build.12.e0f985a-2')
    assert ver1.__le__(ver2) == True
    ver1 = SemanticVersion('4.4.7-alpha.1+build.12.e0f985a-1')

# Generated at 2022-06-23 14:54:05.155847
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(2) >= 1
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= 2
    assert not _Numeric(1) >= _Alpha('a')
    assert _Numeric(1) >= _Alpha('0')


# Generated at 2022-06-23 14:54:06.804748
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('1')) == repr('1')


# Generated at 2022-06-23 14:54:16.981850
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    """
    Test method __gt__ of class _Alpha
    """
    assert _Alpha('1.1a') > _Alpha('1.1')
    assert _Alpha('1.2') > _Alpha('1.1a')
    assert _Alpha('1.1rc3') > _Alpha('1.1rc2')
    assert _Alpha('1.1b') > _Alpha('1.1a')
    assert _Alpha('1.1b1') > _Alpha('1.1b')
    assert not _Alpha('1.1b1') > _Alpha('1.1b1')
    assert not _Alpha('1.1b') > _Alpha('1.1b1')
    assert not _Alpha('1.1b') > _Alpha('1.1b2')
    assert not _Alpha('1.1b') > _Alpha

# Generated at 2022-06-23 14:54:25.770826
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():

    # Comparison of SemanticVersion with SemanticVersion
    assert SemanticVersion('0.0.0') <= SemanticVersion('0.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    assert SemanticVersion('1.1.1') <= SemanticVersion('1.1.1')
    assert SemanticVersion('0.0.0-alpha') <= SemanticVersion('0.0.0-alpha')
    assert SemanticVersion('1.0.0-beta') <= SemanticVersion('1.0.0-beta')
    assert SemanticVersion('1.1.1-rc') <= SemanticVersion('1.1.1-rc')
    assert SemanticVersion('0.0.0-alpha+1') <= SemanticVersion('0.0.0-alpha+1')

# Generated at 2022-06-23 14:54:38.273915
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    import random
    import string

    assert _Numeric('0') == _Numeric('0')
    assert _Numeric('0') <= _Numeric('0')

    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') <= _Numeric('1')

    for i in range(0, 10):
        assert _Numeric('1') > _Numeric('0')
        assert _Numeric('0') < _Numeric('1')

        assert _Numeric('1') >= _Numeric('0')
        assert _Numeric('0') <= _Numeric('1')

        assert _Numeric('1') >= _Numeric('1')
        assert _Numeric('1') <= _Numeric('1')

        assert _Numeric('2') > _Numeric('1')
        assert _N

# Generated at 2022-06-23 14:54:48.689800
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v1 = SemanticVersion('1.1.1')
    v2 = SemanticVersion('2.0.0')
    v3 = SemanticVersion('1.1.1-pre.1')
    v4 = SemanticVersion('1.2.0-pre.1')
    v5 = SemanticVersion('1.1.1-pre.2')
    v6 = SemanticVersion('1.1.1-pre.1+build.1')
    v7 = SemanticVersion('1.1.1-pre.1+build.2')
    v8 = SemanticVersion('1.1.1+build.1')
    v9 = SemanticVersion('1.1.1+build.2')

    assert v1 < v2
    assert v3 < v1
    assert v4 < v1
    assert v5

# Generated at 2022-06-23 14:54:49.972304
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('1') == '1'
    assert _Alpha('1') == _Alpha('1')


# Generated at 2022-06-23 14:54:51.096189
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != 1


# Generated at 2022-06-23 14:54:56.812478
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert _Numeric('1') >= _Numeric(1)
    assert _Numeric('1') >= 1
    assert 1 >= _Numeric(1)
    assert 1 >= _Numeric('1')
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= 2
    assert not _Numeric('1') >= _Numeric(2)
    assert not _Numeric('1') >= 2
    assert not 1 >= _Numeric(2)
    assert not 1 >= _Numeric('2')



# Generated at 2022-06-23 14:55:04.888811
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert not _Numeric(1) > _Numeric(1)
    assert _Numeric(1) > _Alpha('0')
    assert _Numeric(1) > _Alpha('1')
    assert _Numeric(1) > 0
    assert _Numeric(1) > 1
    try:
        _Numeric(1) > '0'
        assert False, "ValueError not raised"
    except ValueError:
        pass


# Generated at 2022-06-23 14:55:06.674518
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
  v1 = SemanticVersion('4.4.4')
  v2 = SemanticVersion('4.4.4')
  return v1 >= v2


# Generated at 2022-06-23 14:55:16.002059
# Unit test for constructor of class _Numeric
def test__Numeric():
    n = _Numeric(3)
    n2 = _Numeric(3)
    assert n == n2
    assert n == 3
    assert n != '3'
    assert _Numeric(4) > _Numeric(3)
    assert _Numeric(4) > 3
    assert _Numeric(4) >= _Numeric(4)
    assert _Numeric(4) >= 4
    assert _Numeric(4) < _Numeric(5)
    assert _Numeric(4) < 5
    assert _Numeric(4) <= _Numeric(4)
    assert _Numeric(4) <= 4


# Generated at 2022-06-23 14:55:23.091365
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Test that compares a _Numeric with an _Alpha
    # This is where the complex logic lies
    #
    # _Alpha objects are used in the prerelease portion of a semantic version
    # _Numeric objects are used in the buildmetadata portion of a semantic version
    #
    # If a prerelease has an _Alpha object, the _Numeric object should compare as
    # greater than the _Alpha object
    #
    # If a prerelease has an _Alpha object, and a buildmetadata has a _Numeric object,
    # the _Numeric object should compare as greater than the _Alpha object

    prefix = _Numeric(1)
    first = _Alpha('alpha')
    second = _Alpha('beta')

    # Test when both parts of the semantic version have _Alpha objects
    assert prefix < first
    assert first < second

    # Test when pre

# Generated at 2022-06-23 14:55:26.829943
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # GIVEN
    v1 = SemanticVersion('1.2.3-alpha.1')
    v2 = SemanticVersion('1.2.3-alpha.1')

    # WHEN
    result = v1 >= v2

    # THEN
    assert result == True


# Generated at 2022-06-23 14:55:35.401983
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    # If a<b and a!=b, then a<b
    for a in range(0,10):
        for b in range(0,10):
            if(a<b):
                assert(_Numeric(a)<_Numeric(b))

    # If a<=b and b<=a, then a=b
    for a in range(0,10):
        for b in range(0,10):
            if(a<=b or b<=a):
                assert(_Numeric(a)<=_Numeric(b))
                if(a!=b):
                    assert(_Numeric(a)<_Numeric(b))

    # If a<=b and b<=c, then a<=c

# Generated at 2022-06-23 14:55:42.590108
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.2.0')) == SemanticVersion('0.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.2')) == SemanticVersion('0.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

# Generated at 2022-06-23 14:55:53.613128
# Unit test for method __gt__ of class _Numeric

# Generated at 2022-06-23 14:55:55.745146
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    result = SemanticVersion('1.2.3') > SemanticVersion('1.2.4')
    assert result == False


# Generated at 2022-06-23 14:55:59.108516
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    """
    Test method __gt__ of class _Numeric
    """
    v = _Numeric(10)
    assert v > 9
    assert not (v > 10)
    assert not (v > 11)


# Generated at 2022-06-23 14:56:06.981759
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion(vstring="1.0.0")
    v2 = "1.0.0"
    v3 = SemanticVersion(vstring="0.0.1+abc")
    v4 = "0.0.1"
    v5 = SemanticVersion(vstring="0.0.1-1")
    v6 = "0.0.1-1"
    v7 = SemanticVersion(vstring="0.0.1-1.1")
    v8 = "0.0.1-1.1"
    v9 = SemanticVersion(vstring="0.0.1-1.1.1")
    v10 = "0.0.1-1.1.1"

# Generated at 2022-06-23 14:56:12.828943
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    a = _Numeric('2')
    b = _Numeric('1')
    c = _Numeric('2')
    d = _Numeric('3')
    e = _Alpha('1')

    x = a < b
    assert x == False
    x = a < c
    assert x == False
    x = a < d
    assert x == True
    x = a < e
    assert x == False



# Generated at 2022-06-23 14:56:15.713835
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Numeric('1')
    assert _Alpha('a') <= 'b'


# Generated at 2022-06-23 14:56:17.737218
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == 2


# Generated at 2022-06-23 14:56:26.730784
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('1') >= _Numeric('1')
    assert not _Numeric('1') >= _Numeric('2')
    assert _Numeric('2') >= _Numeric('1')
    assert _Numeric('1') >= '1'
    assert not _Numeric('2') >= '1'
    assert _Numeric('1') >= '1'
    assert _Numeric('2') >= '1'
    try:
        _Numeric('1') >= _Alpha('1')
        assert False, 'Expected ValueError'
    except ValueError:
        pass


# Generated at 2022-06-23 14:56:27.917538
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    t1 = _Alpha(1)
    assert t1.__ne__(2)


# Generated at 2022-06-23 14:56:36.517170
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    """Unit test for method __ge__ of class _Alpha"""
    assert not _Alpha('0') > '0'
    assert not _Alpha('0') > _Alpha('0')
    assert _Alpha('0') > _Numeric(0)
    assert not _Alpha('0') < _Alpha('0')
    assert _Alpha('0') < _Alpha('1')
    assert not _Alpha('0') > _Alpha('1')
    assert not _Alpha('0') < _Alpha('a')
    assert not _Alpha('a') < _Alpha('1')
    assert _Alpha('a') < _Alpha('b')
    assert not _Alpha('b') < _Alpha('a')


# Generated at 2022-06-23 14:56:41.613626
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') < _Alpha('a')
    assert not _Alpha('alpha') < _Alpha('alpha')
    assert not _Alpha('alpha') < _Alpha('ALPHA')
    assert _Alpha('alpha') < _Numeric(1)


# Generated at 2022-06-23 14:56:44.207058
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a = SemanticVersion('1.2.3')
    b = SemanticVersion('1.2.3')
    assert a <= b


# Generated at 2022-06-23 14:56:49.139106
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= _Numeric(0)
    assert _Numeric(1) >= 1
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= _Alpha('2')


# Generated at 2022-06-23 14:56:53.460822
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) > 0
    assert not _Numeric(0) > _Numeric(1)
    assert not _Numeric(0) > 1



# Generated at 2022-06-23 14:56:57.905805
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('1') == 1
    assert _Numeric('1') <= 1
    assert _Numeric('1') <= 2
    assert _Numeric('2') <= 3
    assert _Numeric('2') <= 2
    assert not _Numeric('2') <= 1


# Generated at 2022-06-23 14:57:00.843141
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    """
    This function tests the method __lt__ of class SemanticVersion in module ansible_collections.notmintest.not_a_real_collection.plugins.modules.package_manager_utils.
    """
    raise NotImplementedError()


# Generated at 2022-06-23 14:57:02.873418
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion("1.0.0") <= SemanticVersion("1.0.0") # assert True

test_SemanticVersion___le__()


# Generated at 2022-06-23 14:57:08.297542
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
  version1 = "1.0.0"
  version2 = "1.0.0"
  semver1 = SemanticVersion(version1)
  semver2 = SemanticVersion(version2)
  if semver1 == semver2 and not semver1 != semver2:
    print("Test 1 passed")
  else:
    print("Test 1 failed")
  semver1 = SemanticVersion("1.0.0-alpha.1")
  semver2 = SemanticVersion("1.0.0")
  if semver1 != semver2 and not semver1 == semver2:
    print("Test 2 passed")
  else:
    print("Test 2 failed")
  semver1 = SemanticVersion("1.0.0-alpha.1")

# Generated at 2022-06-23 14:57:10.300540
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')


# Generated at 2022-06-23 14:57:21.520620
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.2.3') != '1.2.3'
    assert SemanticVersion('1.2.3') != '1.2.4'
    assert SemanticVersion('1.2.3') != '1.3.3'
    assert SemanticVersion('1.2.3') != '2.2.3'
    assert SemanticVersion('1.2.3') != '1.2.3-beta'
    assert SemanticVersion('1.2.3') != '1.2.3-beta.1'
    assert SemanticVersion('1.2.3') != '1.2.3-beta.2'
    assert SemanticVersion('1.2.3') != '1.2.3-beta.11'

# Generated at 2022-06-23 14:57:24.019796
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():

    assert SemanticVersion('1.0.0') != '2.0.0'


# Generated at 2022-06-23 14:57:33.000013
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Test empty
    alpha_1 = _Alpha('')
    alpha_2 = _Alpha('')
    assert alpha_1.__lt__(alpha_2) == False

    # Test both letters
    alpha_1 = _Alpha('a')
    alpha_2 = _Alpha('b')
    assert alpha_1.__lt__(alpha_2) == True

    # Test other letters
    alpha_1 = _Alpha('b')
    alpha_2 = _Alpha('a')
    assert alpha_1.__lt__(alpha_2) == False

    # Test same letter
    alpha_1 = _Alpha('a')
    alpha_2 = _Alpha('a')
    assert alpha_1.__lt__(alpha_2) == False

    # Test one letter and different
    alpha_1 = _Alpha('a')
   

# Generated at 2022-06-23 14:57:37.569932
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    ge = _Numeric(1).__ge__
    bind = lambda other: ge(other)
    assert bind(0) is False
    assert bind(1) is True
    assert bind(2) is True


# Generated at 2022-06-23 14:57:47.240340
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.1")
    assert (v1 <= v2) is True

    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.1.0")
    assert (v1 <= v2) is True

    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("2.0.0")
    assert (v1 <= v2) is True

    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.0")
    assert (v1 <= v2) is True

    v1 = SemanticVersion("1.1.0")
    v2 = SemanticVersion("1.0.0")
   

# Generated at 2022-06-23 14:57:49.886384
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
  version_a = SemanticVersion('1.2.3')
  version_b = SemanticVersion('1.2.3')
  assert (version_a >= version_b)


# Generated at 2022-06-23 14:57:52.078461
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    value1 = _Numeric(1)
    value2 = _Numeric(2)
    assert value1.__gt__(value2) == False


# Generated at 2022-06-23 14:57:59.316975
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == '1.2.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2'))) == '1.2.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1'))) == '1.0.0'

    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha-1'))) == '1.2.3-alpha-1'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2-alpha-1'))) == '1.2.0-alpha-1'

# Generated at 2022-06-23 14:58:06.966830
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # [_Alpha(a) <= _Alpha(b)] should be [a <= b]
    assert _Alpha('a') <= _Alpha('b')
    assert not _Alpha('b') <= _Alpha('a')
    # [_Alpha(a) <= b] should be [a <= b]
    assert _Alpha('a') <= 'b'
    assert not _Alpha('b') <= 'a'
    # [_Alpha(a) <= _Numeric(b)] should be [False]
    assert not _Alpha('a') <= _Numeric('b')
    # [_Alpha(a) <= b] should be [True] for [b == 0]
    assert _Alpha('a') <= '0'
    # [_Alpha(a) <= b] should be [False] for [a == b]

# Generated at 2022-06-23 14:58:12.964410
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # This is a simple unit test for the method
    # __lt__ of class _Numeric.
    #
    # It will be used to check that the method
    # is doing the correct thing.
    assert (_Numeric("2") < _Numeric("1"))
    assert (_Numeric("1") < _Numeric("2"))
    assert (_Numeric("2") < _Numeric("3"))
    assert (_Numeric("3") < _Numeric("4"))



# Generated at 2022-06-23 14:58:24.162016
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    #
    # Check if the comparison works as expected when a _Numeric is compared with an _Alpha.
    #
    a = _Numeric(1)
    b = _Alpha('a')
    assert a > b
    assert a >= b
    assert not a < b
    assert not a <= b
    assert a != b
    assert not a == b

    b = _Alpha('0')
    assert a > b
    assert a >= b
    assert not a < b
    assert not a <= b
    assert a != b
    assert not a == b

    #
    # Check if the comparison works as expected when a _Numeric is compared with a _Numeric.
    #
    a = _Numeric(1)
    b = _Numeric(2)
    assert a < b
    assert a <= b
    assert not a

# Generated at 2022-06-23 14:58:28.796688
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') == 1

    assert _Numeric('1') != _Numeric('2')
    assert _Numeric('1') != 2


# Generated at 2022-06-23 14:58:36.984709
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    number1 = _Numeric(1)
    number2 = _Numeric(2)
    number3 = _Numeric(3)
    string1 = _Alpha('1')
    string2 = _Alpha('2')
    string3 = _Alpha('3')

    assert(number1 >= number1)
    assert(not number1 >= number2)
    assert(not number1 >= number3)
    assert(not number1 >= string1)
    assert(not number1 >= string2)
    assert(not number1 >= string3)
    assert(not string1 >= number1)
    assert(not string1 >= number2)
    assert(not string1 >= number3)
    assert(string1 >= string1)
    assert(not string1 >= string2)
    assert(not string1 >= string3)