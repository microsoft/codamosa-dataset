

# Generated at 2022-06-23 14:48:31.514060
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric('1')
    b = _Numeric('2')
    c = _Numeric('2')

    assert a < b
    assert a < c
    assert not b < a
    assert not c < a


# Generated at 2022-06-23 14:48:34.382332
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.2.3') != 'a.b.c'
    assert SemanticVersion('a.b.c') != '1.2.3'
    assert not SemanticVersion('a.b.c') != 'a.b.c'


# Generated at 2022-06-23 14:48:41.998471
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha(1) != 1
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != _Alpha(1)
    assert _Alpha('a') < _Alpha(1)
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') >= _Alpha('a')
    assert not _Alpha('a') > _Alpha(1)
    assert not _Alpha('a') >= _Alpha(1)
    assert _Alpha('a') > _Alpha('b')


# Generated at 2022-06-23 14:48:47.191733
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < 'a'
    assert _Alpha('a') < 'b'
    assert _Alpha('a') < 'A'
    assert _Alpha('a') < _Alpha('a')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('A')


# Generated at 2022-06-23 14:48:49.928939
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('1') > _Alpha('2')
    assert _Alpha('a') > _Alpha('b')
    assert _Alpha('a') > _Alpha('1')
    assert not _Alpha('1') > _Alpha('1')


# Generated at 2022-06-23 14:48:56.306035
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert not SemanticVersion("1.2.3") == "1.2.3"
    assert not SemanticVersion("1.2.3") == SemanticVersion("1.2.3")
    assert not SemanticVersion("1.2.3") == LooseVersion("1.2.3")
    assert SemanticVersion("1.2.3") != "1.2.4"
    assert SemanticVersion("1.2.3") != SemanticVersion("1.2.4")
    assert SemanticVersion("1.2.3") != LooseVersion("1.2.4")


# Generated at 2022-06-23 14:49:05.583222
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    """Test that SemanticVersion behaves like LooseVersion"""

# Generated at 2022-06-23 14:49:16.415314
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    """
    Check the logic for the __le__ method of the SemanticVersion class
    """
    from SemanticVersion import SemanticVersion

    assert SemanticVersion('1.0.0') <= '1.0.0'
    assert SemanticVersion('1.0.0') <= '2.0.0'
    assert SemanticVersion('1.0.0') <= '1.1.0'
    assert SemanticVersion('1.0.0') <= '1.0.1'
    assert SemanticVersion('1.0.0-rc.1') <= '1.0.0'
    assert SemanticVersion('1.0.0') <= '1.0.0-rc.1'
    assert SemanticVersion('1.0.0-rc.2') <= '1.0.0-rc.1'
    assert Sem

# Generated at 2022-06-23 14:49:19.998216
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    v1 = _Numeric(1)
    v2 = _Numeric(2)
    assert v1 <= v2
    v2 = _Numeric(1)
    assert v1 <= v2
    assert v1 <= 1
    assert v1 <= _Alpha('1')


# Generated at 2022-06-23 14:49:22.720882
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.0.0') != 'NOT_VERSION'
    assert SemanticVersion('1.0.0') != SemanticVersion('1.0.0')



# Generated at 2022-06-23 14:49:25.999337
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    numeric = _Numeric(2)

    assert numeric <= 2
    assert numeric <= _Numeric(2)
    assert not numeric <= 1
    assert not numeric <= _Numeric(1)


# Generated at 2022-06-23 14:49:35.608861
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n1 = _Numeric("1")
    n2 = _Numeric("2")
    n1_1 = _Numeric("1")
    n1_str = _Numeric("1")
    n2_str = _Numeric("2")
    n1_str_str = "1"
    n2_str_str = "2"
    n1_int = 1
    n2_int = 2

    assert n1 == n1_1
    assert not n1 == n2
    assert n1 == n1_str
    assert not n1 == n1_int
    assert not n1 == n1_str_str
    assert not n2 == n2_str
    assert not n2 == n2_int
    assert not n2 == n2_str_str


# Generated at 2022-06-23 14:49:42.227521
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert 3 == _Numeric(3) == _Numeric(text_type(3))
    assert 3 < _Numeric('3.0') < _Alpha('3.0')
    assert _Numeric('3.0') > _Alpha('3.0')
    assert 3 > _Alpha('3') > _Numeric('3')
    assert _Alpha('3') < _Numeric('3')
    assert _Alpha('3.0') < _Numeric('3.0')
    assert 3 == _Numeric(3)
    assert 3.0 == _Numeric('3.0')


# Generated at 2022-06-23 14:49:48.127599
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    a1 = _Alpha('a1')
    a2 = _Alpha('a2')
    try:
        a1.__repr__() == '_Alpha(a1)'
        a2.__repr__() == '_Alpha(a2)'
    except Exception as e:
        print ("test__Alpha___repr__ failed: " + str(e))
        return False

    return True


# Generated at 2022-06-23 14:49:53.527331
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    # The method returns False when the compared versions are equal
    assert not _Numeric(0) > _Numeric(0)
    assert not _Numeric(1) > _Numeric(1)

    # The method returns True when the compared versions differ
    assert _Numeric(0) > _Numeric(1)
    assert _Numeric(1) > _Numeric(0)

# Generated at 2022-06-23 14:50:01.351329
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # test__Numeric___lt__()
    assert _Numeric(1).__lt__(_Numeric(2))
    assert not _Numeric(2).__lt__(_Numeric(2))

    assert _Numeric(1).__lt__(_Alpha(1))

    assert _Numeric(1).__lt__(1)
    assert _Numeric(1).__lt__('1')
    assert not _Numeric('1').__lt__(1)
    assert not _Numeric(1).__lt__('2')
    assert not _Numeric(2).__lt__('2')


# Generated at 2022-06-23 14:50:09.309288
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a = SemanticVersion('0.0.1')
    b = SemanticVersion('0.0.2')
    c = SemanticVersion('0.1.1')
    d = SemanticVersion('0.0.1')
    print(a < b)
    print(a <= b)
    print(a <= c)
    print(a <= d)
    a = SemanticVersion('1.0.1')
    b = SemanticVersion('0.0.2')
    c = SemanticVersion('1.1.1')
    d = SemanticVersion('1.0.1')
    print(a < b)
    print(a <= b)
    print(a <= c)
    print(a <= d)

# test_SemanticVersion___le__()


# Generated at 2022-06-23 14:50:14.454787
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(0) < _Numeric(0.0)
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < _Numeric(1.0)
    assert _Numeric(0) < _Numeric(1)


# Generated at 2022-06-23 14:50:23.475277
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert not _Numeric('1') > _Numeric('1')
    assert not _Numeric('0') > _Numeric('1')

    assert _Numeric('2') > _Numeric('1')
    assert _Numeric('2') > _Numeric('1')
    assert _Numeric('2') > _Numeric('0')
    assert _Numeric('1') > _Numeric('0')

    assert _Numeric('1') > _Alpha('1')
    assert _Numeric('2') > _Alpha('1')
    assert not _Numeric('1') > _Alpha('2')
    assert not _Numeric('0') > _Alpha('1')

    assert _Numeric('1') > 0
    assert _Numeric('2') > 1
   

# Generated at 2022-06-23 14:50:26.238502
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(1.1)
    assert _Numeric(0.9) < _Numeric(1)
    assert _Numeric(1) < _Numeric(2)


# Generated at 2022-06-23 14:50:35.594088
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert all(type(_Numeric(n)) is int for n in ('0', 0, '1', 1))
    # add tuples
    assert all(type(n) is int for n in _Numeric('0') + _Numeric('1'))
    assert all(type(n) is int for n in _Numeric('0') + 1)
    assert all(type(n) is int for n in 0        + _Numeric('1'))
    # multiply tuples
    assert all(type(n) is int for n in _Numeric('0') * _Numeric('1'))
    assert all(type(n) is int for n in _Numeric('0') * 1)
    assert all(type(n) is int for n in 0        * _Numeric('1'))


# Generated at 2022-06-23 14:50:39.485860
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    from ansible.module_utils.six import PY3
    if PY3:
        import unittest

        class Test__Numeric___ge__(unittest.TestCase):
            def test_greater_than(self):
                self.assertTrue(_Numeric(1) >= _Numeric(1))
                self.assertTrue(_Numeric(2) >= _Numeric(1))
                self.assertFalse(_Numeric(1) >= _Numeric(2))

            def test_greater_than_int(self):
                self.assertTrue(_Numeric(1) >= 1)
                self.assertTrue(_Numeric(2) >= 1)
                self.assertFalse(_Numeric(1) >= 2)


# Generated at 2022-06-23 14:50:48.857919
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion("0.0.0")) == "SemanticVersion('0.0.0')"
    assert repr(SemanticVersion("1.0.0")) == "SemanticVersion('1.0.0')"
    assert repr(SemanticVersion("1.2.3")) == "SemanticVersion('1.2.3')"
    assert repr(SemanticVersion("1.2.3-alpha.1")) == "SemanticVersion('1.2.3-alpha.1')"
    assert repr(SemanticVersion("1.2.3-alpha.1+build.2")) == "SemanticVersion('1.2.3-alpha.1+build.2')"


# Generated at 2022-06-23 14:50:56.940827
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    from ansible.module_utils._text import to_native

    # Ensure SemanticVersion is a subclass of Version
    assert issubclass(SemanticVersion, Version)

    # Ensure error handling for invalid input

# Generated at 2022-06-23 14:50:58.405005
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n = _Numeric(1)
    assert n == 1
    assert not n == "1"
    assert n != "1"
    assert not n != 1


# Generated at 2022-06-23 14:51:08.805666
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    ver = SemanticVersion(0.1)
    assert ver.major == 0, "Major version should be 0, was %r" % ver.major
    assert ver.minor == 1, "Minor version should be 1, was %r" % ver.minor

    ver = SemanticVersion(0.9)
    assert ver.major == 0, "Major version should be 0, was %r" % ver.major
    assert ver.minor == 9, "Minor version should be 9, was %r" % ver.minor

    ver = SemanticVersion(10.9)
    assert ver.major == 10, "Major version should be 10, was %r" % ver.major
    assert ver.minor == 9, "Minor version should be 9, was %r" % ver.minor


# Generated at 2022-06-23 14:51:17.139510
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    v.parse('1.2.3')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v.parse('1.2.3-alpha.beta+build.0')
    assert v.prerelease == (_Alpha('alpha'), _Alpha('beta'))
    assert v.buildmetadata == (_Numeric('build'), _Numeric('0'))

    v.parse('1.2.3-alpha.2.beta.2+build.1.2')
    assert v.prerelease == (_Alpha('alpha'), _Numeric('2'), _Alpha('beta'), _Numeric('2'))

# Generated at 2022-06-23 14:51:24.382255
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    n3 = _Numeric(3)
    assert n1 != n2
    assert n1 != n3
    assert n2 != n3
    assert n2 != 1
    assert n2 != 3
    assert n3 != 1
    assert n3 != 2
    assert n3 != 'somestring'
    assert n3 != object()
    assert n3 != object


# Generated at 2022-06-23 14:51:33.539902
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0+a')
    assert SemanticVersion('1.0.0-alpha') == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha') == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha.1') == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha.beta') == SemanticVersion('1.0.0-alpha.beta')

# Generated at 2022-06-23 14:51:40.552111
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    import unittest
    """ Class to test __repr__ method of _Numeric class """
    class __Numeric___repr__(unittest.TestCase):
        
        # Testing a normal case
        def test_normal(self):
            sut = _Numeric(1)
            self.assertEqual(repr(sut), '1')
        
        # Testing a zero case
        def test_zero(self):
            sut = _Numeric(0)
            self.assertEqual(repr(sut), '0')
        
        # Testing a negative case
        def test_negative(self):
            sut = _Numeric(-1)
            self.assertEqual(repr(sut), '-1')
        
        # Testing an over nine case

# Generated at 2022-06-23 14:51:42.776913
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert(_Numeric('123').specifier == int('123'))
    assert(_Numeric('1a').specifier == int('1'))


# Generated at 2022-06-23 14:51:54.048364
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(2) == 2
    assert _Numeric(3) == 3
    assert _Numeric(4) == 4
    assert _Numeric(5) == 5
    assert _Numeric(6) == 6
    assert _Numeric(7) == 7
    assert _Numeric(8) == 8
    assert _Numeric(9) == 9
    assert _Numeric(10) == 10
    assert _Numeric(11) == 11
    assert _Numeric(12) == 12
    assert _Numeric(13) == 13
    assert _Numeric(14) == 14
    assert _Numeric(15) == 15
    assert _Numeric(16) == 16
    assert _Numeric(17) == 17
    assert _Numeric(18) == 18
   

# Generated at 2022-06-23 14:51:56.644706
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert not SemanticVersion('3.1.1') == SemanticVersion('3.1.1')


# Generated at 2022-06-23 14:52:04.529183
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('abc') == _Numeric('abc')
    assert _Numeric('abc') != _Numeric('abcd')
    assert _Numeric('101') > _Numeric('100')
    assert _Numeric('100') == _Numeric('100')
    assert _Numeric('101') >= _Numeric('100')
    assert _Numeric('100') <= _Numeric('100')
    try:
        assert _Numeric('100') < '100'
        assert False, "Expected ValueError"
    except ValueError:
        pass
    try:
        assert _Numeric('100') <= '100'
        assert False, "Expected ValueError"
    except ValueError:
        pass

# Generated at 2022-06-23 14:52:07.460641
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    vstring = '1.2.3'
    assert(repr(SemanticVersion(vstring)) == "SemanticVersion('1.2.3')")



# Generated at 2022-06-23 14:52:11.140297
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    # Initialize a numeric object
    numeric = _Numeric(123)

    # Assert the repr of numeric object is "123"
    assert (repr(numeric) == "123")


# Generated at 2022-06-23 14:52:22.054065
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    alpha1 = _Alpha('alpha1')
    alpha2 = _Alpha('alpha2')
    alpha3 = _Alpha('alpha3')
    num1 = _Numeric('1')
    num2 = _Numeric('2')
    num3 = _Numeric('3')

    assert num1 <= alpha1
    assert num1 <= alpha2
    assert num1 <= alpha3

    assert num2 <= alpha1
    assert num2 <= alpha2
    assert num2 <= alpha3

    assert num3 <= alpha1
    assert num3 <= alpha2
    assert num3 <= alpha3

    assert alpha1 <= num1
    assert alpha1 <= num2
    assert alpha1 <= num3

    assert alpha2 <= num1
    assert alpha2 <= num2
    assert alpha2 <= num3

    assert alpha3 <= num1

# Generated at 2022-06-23 14:52:27.813367
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('2') < '3'
    assert _Numeric('2') < _Numeric('3')
    assert _Numeric('2') < _Alpha('3')
    assert _Numeric('2') < 3

    assert not _Numeric('4') < '3'
    assert not _Numeric('4') < _Numeric('3')
    assert not _Numeric('4') < _Alpha('3')
    assert not _Numeric('4') < 3

    assert not _Numeric('4') < '4'
    assert not _Numeric('4') < _Numeric('4')
    assert not _Numeric('4') < _Alpha('4')
    assert not _Numeric('4') < 4


# Generated at 2022-06-23 14:52:32.757564
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert not _Numeric(1) < _Numeric(2), '1 is not less than 2'
    assert _Numeric(1) < _Numeric(3), '1 is less than 3'
    assert not _Numeric(1) < _Numeric('1'), '1 is not less than "1"'
    assert _Numeric(1) < _Numeric('2'), '1 is less than "2"'
    assert _Numeric(1) < _Alpha('a'), '1 is less than a'
    assert not _Numeric(1) < _Alpha('1'), '1 is not less than "1"'
    assert _Numeric(1) < _Alpha('b'), '1 is less than b'


# Generated at 2022-06-23 14:52:38.550108
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Define an instance of class SemanticVersion
    semantic_version = SemanticVersion(vstring='1.0.0-alpha.1',)
    # Define a version to compare with
    version = '2.0.0'

    # Test if semantic_version < version
    assert (semantic_version < version) == True


# Generated at 2022-06-23 14:52:40.565567
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(1)

    assert a < b
    assert a == c


# Generated at 2022-06-23 14:52:44.475457
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    '''
    Tests that the _Alpha class's __lt__ method is working
    '''
    alpha1 = _Alpha("2")
    alpha2 = _Alpha("4")
    assert alpha1 < alpha2



# Generated at 2022-06-23 14:52:53.859538
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('2') < _Alpha('9')
    assert _Alpha('2') < _Alpha('b')
    assert _Alpha('2') < _Alpha('z')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('A') < _Alpha('b')
    assert _Alpha('A') < _Alpha('B')

    assert not _Alpha('a') < _Alpha('a')
    assert not _Alpha('z') < _Alpha('a')
    assert not _Alpha('b') < _Alpha('A')
    assert not _Alpha('A') < _Alpha('A')
    assert not _Alpha('a') < _Alpha('A')
    assert not _Alpha('b') < _Alpha('2')


# Generated at 2022-06-23 14:52:54.624794
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) <= _Numeric(2)


# Generated at 2022-06-23 14:53:06.213075
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    s = SemanticVersion("1.0.1-alpha.3+build.20170101235959")
    assert s == "1.0.1-alpha.3+build.20170101235959"
    assert s != "1.0.1-alpha.3+build.20170101235959_2"
    s2 = SemanticVersion("1.0.1-alpha.3+build.20170101235959")
    assert s == s2
    assert s != "1.0.1-aLpha.3+build.20170101235959"
    assert s != "1.0.1-alpha.4+build.20170101235959"
    assert s != "1.0.1-alpha.3"

# Generated at 2022-06-23 14:53:13.470789
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('0.0.0') < SemanticVersion('0.0.1')
    assert SemanticVersion('0.0.0') < SemanticVersion('0.1.0')
    assert SemanticVersion('0.0.0') < SemanticVersion('1.0.0')
    assert SemanticVersion('0.0.1') < SemanticVersion('0.0.2')
    assert SemanticVersion('0.0.1') < SemanticVersion('0.1.0')
    assert SemanticVersion('0.0.1') < SemanticVersion('1.0.0')
    assert SemanticVersion('0.0.1') < SemanticVersion('0.1.0')
    assert SemanticVersion('0.1.1') < SemanticVersion('1.1.1')

# Generated at 2022-06-23 14:53:14.650811
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= '0'


# Generated at 2022-06-23 14:53:16.532429
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    x = SemanticVersion('1')
    y = '2'
    assert not x.__le__(y)


# Generated at 2022-06-23 14:53:21.209058
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('1') <= '1'
    assert _Alpha('1') <= _Numeric('1')
    assert not _Alpha('2') <= _Numeric('1')
    assert not _Alpha('1') <= _Numeric('2')
    assert _Alpha('1') <= _Alpha('1')
    assert not _Alpha('2') <= _Alpha('1')
    assert not _Alpha('1') <= _Alpha('2')


# Generated at 2022-06-23 14:53:24.894299
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    if not(_Alpha('a') != 'a'):
        raise AssertionError()
    if not(_Alpha('a') != _Alpha('a')):
        raise AssertionError()
    if _Alpha('a') != _Alpha('b'):
        raise AssertionError()
    if _Alpha('a') != _Alpha('A'):
        raise AssertionError()


# Generated at 2022-06-23 14:53:34.190545
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose = LooseVersion('0.0.1')
    sv = SemanticVersion.from_loose_version(loose)
    assert sv.vstring == '0.0.1'

    loose = LooseVersion('0.0.1-rc1')
    sv = SemanticVersion.from_loose_version(loose)
    assert sv.vstring == '0.0.1-rc1'

    loose = LooseVersion('0.0.1+1.0')
    sv = SemanticVersion.from_loose_version(loose)
    assert sv.vstring == '0.0.1+1.0'


if __name__ == '__main__':
    import doctest
    doctest.testmod()
    test_SemanticVersion_from_loose_version()

# Generated at 2022-06-23 14:53:38.327149
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert(_Numeric(1) == _Numeric(1))
    assert(_Numeric(1) == 1)
    assert(not _Numeric(1) == _Numeric(2))
    assert(not _Numeric(1) == 2)


# Generated at 2022-06-23 14:53:45.647170
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion('1.2.3-alpha.3+build.2.b8f12d7')
    v2 = SemanticVersion('1.2.3-alpha.3+build.2.b8f12d7')
    v3 = SemanticVersion('1.2.3-alpha.3+build.2.b8f12d7')
    assert v1 == v2
    assert v2 == v3
    assert v3 == v1
    assert v1 >= v2
    assert v2 >= v3
    assert v3 >= v1
    assert v1 <= v2
    assert v2 <= v3
    assert v3 <= v1

    v1 = SemanticVersion('1.2.3-alpha.3')

# Generated at 2022-06-23 14:53:51.657694
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(3).specifier == 3
    assert _Numeric("3").specifier == 3
    try:
        _Numeric("a")
    except ValueError:
        pass
    else:
        raise AssertionError("_Numeric() didn't raise a ValueError")



# Generated at 2022-06-23 14:53:56.876392
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import doctest

    suite = unittest.TestSuite((
        unittest.makeSuite(SemanticVersionTestCase),
        doctest.DocTestSuite(SemanticVersion),
    ))
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-23 14:54:05.491664
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    '''
    Test method __eq__
    '''
    assert SemanticVersion('1.2.3') == '1.2.3'
    assert SemanticVersion('1.2.3') == '1.2.3-alpha.1'
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3-alpha.1') == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3') != '4.5.6'
    assert SemanticVersion('1.2.3') != '1.2.3-beta.1'
    assert SemanticVersion('1.2.3') != '1.2.3-alpha.1'

# Generated at 2022-06-23 14:54:16.041862
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('0.0.0') == SemanticVersion('0.0.0')
    assert SemanticVersion('2.0.0') == SemanticVersion('2.0.0')
    assert SemanticVersion('1.1.1') == SemanticVersion('1.1.1')
    assert SemanticVersion('1.1.1') != SemanticVersion('1.1.2')
    assert SemanticVersion('0.0.0-0') == SemanticVersion('0.0.0-0')
    assert SemanticVersion('0.0.0-alpha') == SemanticVersion('0.0.0-alpha')
    assert SemanticVersion('0.0.0-0') != SemanticVersion('0.0.0-alpha')
    assert SemanticVersion('1.1.1+build00001') == Semantic

# Generated at 2022-06-23 14:54:22.501065
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v = SemanticVersion('1.0.0')
    assert v >= '1.0.0'
    assert v >= '1.0.0-alpha'

    v = SemanticVersion('1.0.0-alpha')
    assert not v >= '1.0.0'
    assert v >= '1.0.0-alpha'


# Generated at 2022-06-23 14:54:24.004397
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("a") >= _Alpha("a")
    assert _Alpha("a") >= "a"


# Generated at 2022-06-23 14:54:25.967120
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():

    for specifier in ('a', 'b', 'c'):
        assert _Alpha(specifier) < 'd'
        assert _Alpha(specifier) < _Alpha('d')
        assert not _Alpha(specifier) < _Numeric('0')


# Generated at 2022-06-23 14:54:30.610464
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert not _Alpha('a') == _Alpha('b')
    assert not _Alpha('a') == 'b'


# Generated at 2022-06-23 14:54:32.480126
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != 'b'
    assert not _Alpha('a') != 'a'


# Generated at 2022-06-23 14:54:40.927405
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    print("trying non-numeric")
    try:
        _Numeric(1) == "2"
        raise AssertionError
    except ValueError:
        pass
    try:
        _Numeric(1) == 2.0
        raise AssertionError
    except ValueError:
        pass
    try:
        _Numeric(1) == (1,)
        raise AssertionError
    except ValueError:
        pass

    print("trying numeric")
    assert _Numeric(1) == 1
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) != 2
    assert _Numeric(1) != _Numeric(2)



# Generated at 2022-06-23 14:54:51.022506
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.4') > SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.4') < SemanticVersion('1.2.4-alpha.1')
    assert SemanticVersion('1.2.4-alpha.1') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.4-alpha.1') < SemanticVersion('1.2.4-beta.2')
    assert SemanticVersion('1.2.4-beta.2') < SemanticVersion('1.2.4-beta.11')
    assert SemanticVersion('1.2.4-beta.11') < SemanticVersion('1.2.4-rc.1')

# Generated at 2022-06-23 14:54:52.937472
# Unit test for constructor of class _Alpha
def test__Alpha():
    an_alpha = _Alpha('alpha')
    assert an_alpha.specifier == 'alpha'
    assert repr(an_alpha) == "'alpha'"



# Generated at 2022-06-23 14:54:55.325606
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    a = _Numeric(2)
    b = _Numeric(2)
    assert a >= b
    assert b >= a


# Generated at 2022-06-23 14:55:01.387269
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():

    assert _Alpha(1) != 1
    assert _Alpha('a') != 'a'
    assert _Alpha('b') != _Alpha('a')
    assert _Alpha('a') != _Alpha(1)

    assert not _Alpha(1) != _Alpha(1)
    assert not _Alpha('a') != _Alpha('a')

    assert 1 != _Alpha(1)
    assert 'a' != _Alpha('a')
    assert _Alpha('b') != _Alpha('a')
    assert _Alpha('a') != _Alpha(1)



# Generated at 2022-06-23 14:55:05.302868
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    for i in range(1,10):
        for j in range(1,10):
            assert (_Numeric(i) >= _Numeric(j)) == (i >= j)
            if i >= j:
                assert _Numeric(i) >= j
            else:
                assert not _Numeric(i) >= j


# Generated at 2022-06-23 14:55:12.380237
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < 2
    assert not _Numeric(1) < _Numeric(1)
    assert not _Numeric(2) < _Numeric(1)
    assert not _Numeric(1) < _Alpha('1-BETA')
    assert not _Numeric(1) < _Alpha('1-BETA')
    assert _Numeric(2) < _Alpha('1-BETA')
    assert not _Numeric(2) < _Alpha('2-BETA')
    assert not _Numeric(1) < _Alpha('1.alpha')
    assert _Numeric(2) < _Alpha('1.alpha')
    assert _Numeric(1) < _Alpha('1.BETA')

# Generated at 2022-06-23 14:55:14.436200
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('alpha')
    assert a.specifier == 'alpha'


# Generated at 2022-06-23 14:55:22.280216
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= _Numeric('1')
    assert _Numeric('1') >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert 1 >= _Numeric(1)

    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= _Numeric('2')
    assert not _Numeric('1') >= _Numeric(2)
    assert not _Numeric(1) >= 2
    assert not 1 >= _Numeric(2)

    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(2) >= _Numeric('1')
    assert _Numeric('2') >= _Numeric(1)

# Generated at 2022-06-23 14:55:29.169139
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    a = _Numeric("1")
    b = _Numeric("2")

    assert( a < b )
    assert( a <= b )
    assert( a != b )
    assert( a <= a )
    assert( a >= a )
    assert( a == a )
    assert( a >= a )

    assert( b > a )
    assert( b >= a )
    assert( b != a )
    assert( b >= b )
    assert( b <= b )
    assert( b == b )
    assert( b <= b )


# Generated at 2022-06-23 14:55:32.118304
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') >= 'b'
    assert not _Alpha('a') >= _Numeric(1)


# Generated at 2022-06-23 14:55:34.601982
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.1')) == "SemanticVersion('0.0.1')"


# Generated at 2022-06-23 14:55:42.452167
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v1 = SemanticVersion("1.2.3")
    v2 = SemanticVersion("1.2.3-beta")
    v3 = SemanticVersion("1.2.3-beta.1")
    v4 = SemanticVersion("1.2.3-beta.2")
    v5 = SemanticVersion("1.2.3-beta.11")
    v6 = SemanticVersion("1.2.3-rc.1")
    v7 = SemanticVersion("1.2.3")
    assert v1 < v2
    assert v1 < v3
    assert v1 < v4
    assert v1 < v5
    assert v1 < v6
    assert v1 == v7

    v1 = SemanticVersion("1.2.3-beta")

# Generated at 2022-06-23 14:55:52.016475
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    # Test with a 0
    x1 = _Numeric(0)
    y1 = _Numeric(0)
    assert (x1 == y1)
    assert (0 == y1)
    assert (x1 == 0)
    assert (not(x1 == 1))
    assert (not(0 == 1))
    assert (not(0 == _Alpha(0)))

    # Test with a 42
    x2 = _Numeric(42)
    y2 = 42
    assert (x2 == y2)
    assert (x2 == _Numeric(42))
    assert (not(x2 == 1))
    assert (not(x2 == _Alpha(42)))


# Generated at 2022-06-23 14:56:02.021703
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Test SemanticVersion.__le__ when the major version is unequal.
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('2.0.0')
    assert v1 <= v2

    # Test SemanticVersion.__le__ when the major version is equal and
    # the minor version is unequal.
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.1.0')
    assert v1 <= v2

    # Test SemanticVersion.__le__ when the major and minor versions are
    # equal and the patch version is unequal.
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.1')
    assert v1 <= v2

    # Test SemanticVersion.__le__ when

# Generated at 2022-06-23 14:56:05.038962
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == 'SemanticVersion(\'1.2.3\')'



# Generated at 2022-06-23 14:56:10.546680
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    def test(a, b, expected):
        assert (_Alpha(a) <= _Alpha(b)) == expected, (a, b, expected)

    test('a', 'b', True)
    test('1', '2', True)
    test('3', '3', True)
    test('3', '2', False)
    test('3', 'A', True)
    test('A', 'a', True)
    test('A', 'Z', True)
    test('Z', 'z', True)
    test('z', 'a', False)
    test('1', 'A', False)
    test('z', '1', False)


# Generated at 2022-06-23 14:56:17.194637
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(11) <= _Numeric(11)
    assert _Numeric(11) <= _Numeric(11.0)
    assert _Numeric(11) <= 11
    assert _Numeric(11) <= 11.0
    assert not _Numeric(11) <= 10
    assert not _Numeric(11) <= 9.9
    assert not _Numeric(11) <= '10'
    assert not _Numeric(11) <= '10.0'
    assert not _Numeric(11) <= '11-1'
    assert not _Numeric(11) <= '11.0'


# Generated at 2022-06-23 14:56:20.093676
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    x = _Alpha('1')
    y = _Alpha('2')
    z = _Alpha('2')
    assert x < y
    assert not x < z


# Generated at 2022-06-23 14:56:24.841868
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('a') >= _Alpha('a')
    assert not (_Alpha('a') >= _Alpha('b'))
    assert _Alpha('a') >= 'a'
    assert not (_Alpha('a') >= 'b')



# Generated at 2022-06-23 14:56:30.844893
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():

    ##
    ## _Alpha specified comparison
    ##

    # equal
    assert not _Alpha('1') != '1'
    # different
    assert _Alpha('1') != '2'

    ##
    ## _Alpha un-specified comparison
    ##

    # equal
    assert not _Alpha('1') != '1'
    # different
    assert _Alpha('1') != '2'


# Generated at 2022-06-23 14:56:40.071190
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    versions = (
        '1.0.0-alpha.1',
        '1.0.0-alpha.beta',
        '1.0.0-beta.2',
        '1.0.0-beta.11',
        '1.0.0-rc.1',
        '1.0.0-rc.1+build.1',
        '1.0.0',
        '1.0.0+0.3.7',
        '1.3.7+build',
        '1.3.7+build.2.b8f12d7',
        '1.3.7+build.11.e0f985a',
    )

    for idx, version in enumerate(versions):
        for compare in versions[:idx]:
            assert SemanticVersion(version) > Semantic

# Generated at 2022-06-23 14:56:42.583339
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    x = SemanticVersion('2.0.0')
    y = None

    assert x.__ne__(y) == True


# Generated at 2022-06-23 14:56:45.732831
# Unit test for constructor of class _Numeric
def test__Numeric():
    """Testing __init__ in _Numeric class."""
    _Numeric(3)
    _Numeric('3')
    _Numeric('3.5')


# Generated at 2022-06-23 14:56:53.251378
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Test for simple values
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.4') < SemanticVersion('1.3.3')
    assert SemanticVersion('1.3.3') < SemanticVersion('2.2.3')
    assert not (SemanticVersion('1.2.3') < SemanticVersion('1.2.3'))
    assert not (SemanticVersion('1.2.3') < SemanticVersion('1.2.3-1'))
    assert not (SemanticVersion('1.2.3') < SemanticVersion('1.2.3+1'))
    # Test for edge values
    assert not (SemanticVersion('9.9.9') < SemanticVersion('10.0.0'))
   

# Generated at 2022-06-23 14:56:55.818107
# Unit test for constructor of class _Numeric
def test__Numeric():
    """Tests for class _Numeric"""
    assert _Numeric(1).specifier == 1
    assert _Numeric('1').specifier == 1


# Generated at 2022-06-23 14:56:57.613519
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)


# Generated at 2022-06-23 14:56:59.262959
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    ver = SemanticVersion("3.7.3")
    assert ver != "3.7.3"


# Generated at 2022-06-23 14:57:00.100112
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    pass


# Generated at 2022-06-23 14:57:03.966686
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    sut = SemanticVersion('1.0.0')

    assert sut == '1.0.0'
    assert sut == SemanticVersion('1.0.0')

    assert sut != '1.0.1'
    assert sut != SemanticVersion('1.0.1')

    assert sut != '1.0'
    assert sut != SemanticVersion('1.0')



# Generated at 2022-06-23 14:57:09.656676
# Unit test for method __ge__ of class _Alpha

# Generated at 2022-06-23 14:57:15.024551
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    alpha1 = _Alpha('test')
    alpha2 = _Alpha('test')
    alpha3 = _Alpha('test_%+')
    assert alpha1 == alpha2
    assert alpha1 != alpha3
    assert alpha1 != 'test'
    assert 'test' != alpha1


# Generated at 2022-06-23 14:57:23.768960
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    a = SemanticVersion('1.2.3-a.b.c.d')
    b = SemanticVersion('1.2.3-a.b.c.d')
    assert a == b

    a = SemanticVersion('1.2.3-a.b.c.d')
    b = SemanticVersion('1.2.3-a.b.c')
    assert a != b

    a = SemanticVersion('1.2.3-a.b.c.d')
    b = SemanticVersion('1.2.3-a.b.d')
    assert a != b


# Generated at 2022-06-23 14:57:32.999781
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test that _Alpha.__le__ works correctly when the versions are different
    a = _Alpha('a')
    b = _Alpha('b')
    assert a.__le__(b)
    assert a <= b
    assert b.__ge__(a)
    assert b >= a

    # Test that _Alpha.__le__ works correctly when the versions are equal
    a = _Alpha('a')
    assert a.__le__(a)
    assert a <= a
    assert a.__ge__(a)
    assert a >= a

    # Test that that _Alpha.__le__ raises ValueError on incorrect input
    a = _Alpha('a')
    c = 'a'
    assert c.__eq__(a)
    assert c == a

# Generated at 2022-06-23 14:57:38.238662
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    test_values = [
        ('1.2.3-alpha.1', 'SemanticVersion(\'1.2.3-alpha.1\')'),
    ]
    for item in test_values:
        assert repr(SemanticVersion(item[0])) == item[1]


# Generated at 2022-06-23 14:57:41.756982
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert not _Numeric(1) == 2
    assert not _Numeric(1) == _Alpha(1)


# Generated at 2022-06-23 14:57:43.543520
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    o = _Alpha('specifier')
    assert o.__repr__() == "'specifier'"


# Generated at 2022-06-23 14:57:51.741207
# Unit test for method __ge__ of class SemanticVersion

# Generated at 2022-06-23 14:57:52.804629
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion().__repr__() == 'SemanticVersion(None)'


# Generated at 2022-06-23 14:57:57.680629
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < 2
    assert _Numeric(1) < _Alpha('2')


# Generated at 2022-06-23 14:57:59.467902
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert False, "TODO: Write test"


# Generated at 2022-06-23 14:58:07.033608
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion


# Generated at 2022-06-23 14:58:10.138076
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.4').__lt__(SemanticVersion('1.0.5'))


# Generated at 2022-06-23 14:58:21.801624
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    # Check inequality with two _Numeric
    data = (
        (1, 1, True),
        (1, 2, True),
        (2, 2, True),
        (2, 1, False),
    )

    for pyvalue in [0, 1]:
        for x, y, expected in data:
            assert (_Numeric(x)).__le__(_Numeric(y)) == expected

    # Check inequality with an integer
    data = (
        (1, 1, True),
        (1, 2, True),
        (2, 2, True),
        (2, 1, False),
    )

    for pyvalue in [0, 1]:
        for x, y, expected in data:
            assert (_Numeric(x)).__le__(y) == expected

    # Check inequality with an _Alpha class
    data

# Generated at 2022-06-23 14:58:25.300393
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric('0') < _Numeric('1')
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') != _Numeric('0')


# Generated at 2022-06-23 14:58:28.849446
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('1')
    b = _Alpha('2')
    assert a < b
    assert not a >= b
