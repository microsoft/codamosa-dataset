

# Generated at 2022-06-23 14:48:29.848353
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v = SemanticVersion(vstring='0.1.2')
    assert v == '0.1.2'


# Generated at 2022-06-23 14:48:39.362189
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    cmp = SemanticVersion
    assert cmp('1.0.0') <= cmp('1.0.0')
    assert cmp('1.0.0') <= cmp('1.1.0')
    assert cmp('1.0.0') <= cmp('1.1.1')
    assert cmp('1.0.0') <= cmp('2.1.1')
    assert cmp('1.1.1') <= cmp('2.0.0')
    assert cmp('1.1.1') <= cmp('2.1.1')
    assert cmp('2.1.1') <= cmp('2.1.1')

    assert cmp('1.0.0-alpha') <= cmp('1.0.0-alpha')

# Generated at 2022-06-23 14:48:40.299855
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    pass



# Generated at 2022-06-23 14:48:44.747159
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    num_1 = _Numeric('1')
    assert num_1.specifier == 1
    num_2 = _Numeric('2')
    assert num_2.specifier == 2

    assert num_1 != num_2
    assert num_2 != num_1



# Generated at 2022-06-23 14:48:48.527462
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert _Numeric(2) >= _Numeric(1)
    assert not _Numeric(1) >= _Numeric(2)


# Generated at 2022-06-23 14:48:52.022328
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.5.3')) == "SemanticVersion('1.5.3')"


# Generated at 2022-06-23 14:48:55.152195
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    """Test __ne__ of class SemanticVersion"""
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('1.0.0')
    assert a == b
    assert not (a != b)


# Generated at 2022-06-23 14:48:59.524889
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(2) != 2
    assert 2 != _Numeric(2)
    assert _Numeric(2) != _Numeric(2)
    assert 2 != _Numeric(4)
    assert _Numeric(2) != _Numeric(4)
    assert _Numeric(4) != _Numeric(2)


# Generated at 2022-06-23 14:49:08.567370
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    """Unit test for method __eq__ of class _Numeric"""
    # Test equality of an _Numeric with an _Numeric of the same value
    a = _Numeric('12')
    b = _Numeric('12')
    assert a == b
    assert b == a

    # Test equality of an _Numeric with an int of the same value
    a = _Numeric('12')
    b = 12
    assert a == b
    assert b == a

    # Test inequality of an _Numeric with an _Numeric of a different value
    a = _Numeric('12')
    b = _Numeric('13')
    assert a != b
    assert b != a

    # Test inequality of an _Numeric with an int of a different value
    a = _Numeric('12')
    b = 13
    assert a != b

# Generated at 2022-06-23 14:49:18.849428
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    result = SemanticVersion.from_loose_version(LooseVersion('1.1.1'))
    assert isinstance(result, SemanticVersion)
    assert result == '1.1.1'

    result = SemanticVersion.from_loose_version(LooseVersion('1.1.1-alpha.1'))
    assert isinstance(result, SemanticVersion)
    assert result == '1.1.1-alpha.1'

    result = SemanticVersion.from_loose_version(LooseVersion('1.1.1-1.1'))
    assert isinstance(result, SemanticVersion)
    assert result == '1.1.1-1.1'

    result = SemanticVersion.from_loose_version(LooseVersion('1.1.1-1-alpha.1'))
   

# Generated at 2022-06-23 14:49:23.305081
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Compare two _Numeric objects
    assert (_Numeric(1) < _Numeric(2))
    # Compare a _Numeric object to an integer
    assert (_Numeric(1) < 2)
    # Compare an integer to a _Numeric object
    assert (1 < _Numeric(2))
    try:
        _Numeric(1) < '2'
        return False
    except ValueError:
        # Expected exception
        return True


# Generated at 2022-06-23 14:49:25.319392
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    actual = repr(_Numeric(42))
    assert actual == '42'


# Generated at 2022-06-23 14:49:34.859150
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    """Unit tests for __gt__ of class SemanticVersion.

    The __gt__ method of class SemanticVersion defines the comparison
    of Semantic Versions greater than.

    If a version is a prerelease - it is lower than all non-prerelease
    versions.

    There are two exceptions
    - the empty string is less than any version
    - the string '0' (the string not the integer) is less than any version.

    """

    #
    # First test that invalid versions raise an error
    #
    try:
        sv = SemanticVersion('1.0.x')
        raise AssertionError('SemanticVersion.__gt__ should raise an error when version is invalid')
    except ValueError:
        pass


# Generated at 2022-06-23 14:49:44.943363
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse(): # Name should start with "test_"
    # Test regular case
    v1 = SemanticVersion('1.0.0')
    assert v1.major == 1
    assert v1.minor == 0
    assert v1.patch == 0
    assert v1.prerelease == ()
    assert v1.buildmetadata == ()

    # Test irregular major
    v2 = SemanticVersion('1x.0.0')
    assert v2.major == 1
    assert v2.minor == 0
    assert v2.patch == 0
    assert v2.prerelease == ()
    assert v2.buildmetadata == ()

    # Test irregular minor
    v3 = SemanticVersion('1.0x.0')
    assert v3.major == 1
    assert v3.minor == 0
    assert v3.patch == 0
   

# Generated at 2022-06-23 14:49:51.400670
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    alpha = _Alpha('z')
    assert alpha >= 'z'
    assert alpha >= 'y'
    assert not alpha >= 'a'
    assert not alpha >= 1
    assert not alpha >= 1.0
    assert not alpha >= _Alpha('a')

    alpha = _Alpha('1')
    assert alpha >= '1'
    assert alpha >= '0'
    assert not alpha >= '9'
    assert not alpha >= 'a'

    try:
        alpha > _Numeric(1)
    except ValueError:
        pass
    else:
        assert False, 'Should have raised ValueError'


# Generated at 2022-06-23 14:49:53.938788
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) != 2
    assert _Numeric(1) != _Numeric(2)


# Generated at 2022-06-23 14:49:56.564937
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('2.0.0')) == "SemanticVersion('2.0.0')"


# Generated at 2022-06-23 14:49:58.216520
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    repr = _Alpha('a').__repr__()
    assert repr == "'a'"


# Generated at 2022-06-23 14:50:01.127397
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a1 = _Alpha('alpha')
    a2 = _Alpha('alpha')
    a3 = _Alpha('beta')
    assert a1 <= a2
    assert not a1 <= a3



# Generated at 2022-06-23 14:50:09.197418
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+23')) == SemanticVersion('1.2.3-alpha.1+23')
    assert SemanticVersion.from_loose_version(LooseVersion('1.20000.3')) == SemanticVersion('1.20000.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')

# Generated at 2022-06-23 14:50:17.753129
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') <= _Numeric('1')
    assert _Numeric('1') >= _Numeric('1')
    assert _Numeric('1') >= _Numeric('0')
    assert _Numeric('1') <= _Numeric('2')
    assert _Numeric('2') > _Numeric('1')
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric('1') != _Numeric('0')
    assert _Numeric('1') != _Numeric('2')

    try:
        _Numeric('1') == '1'  # noqa: F821
    except ValueError:
        pass
    else:
        raise

# Generated at 2022-06-23 14:50:21.173924
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert not _Numeric(1) < _Numeric(0)
    assert _Numeric(1) < _Alpha('2')
    assert _Numeric(2) > _Alpha('2')
    assert not _Numeric(1) < _Numeric(1)


# Generated at 2022-06-23 14:50:23.205117
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    from ansible.module_utils.compat.semver import _Alpha
    assert(_Alpha('1') < _Alpha('2'))
    assert(_Alpha('a') < _Alpha('b'))


# Generated at 2022-06-23 14:50:30.111669
# Unit test for constructor of class _Numeric
def test__Numeric():
    def test_number_eq(number):
        return number == _Numeric(number)

    def test_number_lt(number):
        return number < _Numeric(number)

    def test_number_gt(number):
        return number > _Numeric(number)

    def test_number_ge(number):
        return number >= _Numeric(number)

    def test_number_ne(number):
        return number != _Numeric(number)

    def test_number_le(number):
        return number <= _Numeric(number)

    def test_str_eq(number):
        return str(number) == _Numeric(number)

    def test_str_lt(number):
        return str(number) < _Numeric(number)

    def test_str_gt(number):
        return str(number)

# Generated at 2022-06-23 14:50:32.809885
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion()) == "SemanticVersion(None)"
    assert repr(SemanticVersion("1.0.0")) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-23 14:50:41.523229
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    def method(sf, sv):
        sf, sv = SemanticVersion(sf), SemanticVersion(sv)
        return (sf < sv) == (sf.vstring < sv.vstring)

    assert not method('1.0.0', '1.0.0')  # Equal
    assert method('2.0.0', '1.0.0')  # Major
    assert method('1.1.0', '1.0.0')  # Minor
    assert method('1.0.1', '1.0.0')  # Patch

    # Pre-releases
    assert not method('1.0.0', '1.0.0-alpha.1')  # Stable vs pre-release
    assert method('1.0.0-alpha', '1.0.0-alpha.1')  # Pre-release

# Generated at 2022-06-23 14:50:42.954584
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('test')
    assert a.specifier == 'test'



# Generated at 2022-06-23 14:50:44.032650
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('x') != 'x'


# Generated at 2022-06-23 14:50:46.097537
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('1.2.5+build42')
    assert repr(v) == "SemanticVersion('1.2.5+build42')"


# Generated at 2022-06-23 14:50:48.025906
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    value = 4
    obj = _Numeric(value)
    assert repr(obj) == repr(value)


# Generated at 2022-06-23 14:50:51.810013
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(4) != 0
    assert _Numeric(4) != _Numeric(0)
    assert _Numeric(4) != _Alpha("4")
    assert _Numeric(4) != '4'
    with pytest.raises(ValueError):
        _Numeric(4) != _Numeric("4")



# Generated at 2022-06-23 14:50:58.407391
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    # Test whether the __le__ method of class _Numeric returns the
    # correct values.
    # Parameters:
    #   a: comparison value of type _Numeric
    #   b: comparison value of type _Numeric
    #   control: reference value for comparison of a and b
    # Return value:
    #   result: boolean result of the comparison a <= b

    a = _Numeric('1')
    b = _Numeric('2')
    control = False
    result = a.__le__(b)
    assert result == control, ("_Numeric.__le__() - Result of less than comparison "
                               "between a and b is incorrect.")

    a = _Numeric('2')
    b = _Numeric('2')
    control = True
    result = a.__le__(b)
    assert result

# Generated at 2022-06-23 14:51:07.714567
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1, "__eq__ failed for 1 == 1"
    assert _Numeric(1) == _Numeric(1), "__eq__ failed for Numeric(1) == Numeric(1)"
    assert not _Numeric(1) == '1', "__eq__ failed for 1 == '1'"
    assert not _Numeric(1) == _Alpha('1'), "__eq__ failed for 1 == Alpha('1')"
    assert not 1 == _Numeric(1), "__eq__ failed for 1 == Numeric(1)"
    assert not _Alpha('1') == _Numeric(1), "__eq__ failed for Alpha('1') == Numeric(1)"


# Generated at 2022-06-23 14:51:16.395145
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    sample_arg_list = [
        ('A', True),
        ('a', True),
        ('.', True),
        ('', False),
        ('0', False),
        ('aA', False),
        ('10', False),
        (1, True),
        (10, True),
        (0, True),
    ]
    for arg_pair in sample_arg_list:
        arg_a = arg_pair[0]
        arg_b = arg_pair[1]
        obj_a = _Numeric(arg_a)
        obj_b = _Alpha(arg_a)
        obj_c = _Numeric(arg_a)

# Generated at 2022-06-23 14:51:17.672781
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)


# Generated at 2022-06-23 14:51:18.491228
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    _ = SemanticVersion



# Generated at 2022-06-23 14:51:28.253025
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(1)
    d = _Alpha('a')
    try:
        a < d
        raise Exception("Expected exception to raise when comparing <_Numeric> instance with <_Alpha> instance, but didn't")
    except ValueError:
        pass
    assert a < b
    assert a <= b
    assert b > a
    assert b >= a
    assert a <= c
    assert a >= c
    assert a == c
    assert a != b
    assert a != d


# Generated at 2022-06-23 14:51:36.777418
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    '''
    Ensures that the method of SemanticVersion class that is being tested returns the expected result
    '''
    # Input Parameters
    input_parameters = [
        {'self': SemanticVersion('1.0.0'), 'other': SemanticVersion('0.9.9')},
        {'self': SemanticVersion('1.1.0'), 'other': SemanticVersion('1.9.9')},
        {'self': SemanticVersion('2.1.0'), 'other': SemanticVersion('1.9.9')}
    ]

    # Expected Output
    expected_output = True


# Generated at 2022-06-23 14:51:38.240067
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion("1.2.3") < SemanticVersion("1.2.4")


# Generated at 2022-06-23 14:51:43.914773
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:51:48.323041
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a') == _Alpha('a')
    assert _Alpha('a') >= 'a' == 'a'
    assert _Alpha('a') >= 'b' != 'a'
    assert _Alpha('b') >= 'c'


# Generated at 2022-06-23 14:51:54.052503
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n0 = _Numeric(0)
    n1 = _Numeric(1)

    assert n0 == 0
    assert n1 == 1

    assert not n0 == 1
    assert not n1 == 0

    assert not n0 == '0'
    assert not n1 == '1'

    assert not n0 == _Numeric('0')
    assert not n1 == _Numeric('1')



# Generated at 2022-06-23 14:52:00.515712
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('1') != _Numeric('2')
    assert _Numeric('2') != _Numeric('1')
    assert not (_Numeric('1') != _Numeric('1'))
    assert not (_Numeric('2') != _Numeric('2'))
    assert _Numeric('1') != 1
    assert 1 != _Numeric('1')
    assert not (_Numeric('1') != 1)
    assert not (1 != _Numeric('1'))


# Generated at 2022-06-23 14:52:06.462146
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) >= _Numeric(0)
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(2) >= _Numeric(2)
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) > _Numeric(1)
    assert not _Numeric(0) >= _Numeric(1)
    assert not _Numeric(0) > _Numeric(1)

test__Numeric___ge__()


# Generated at 2022-06-23 14:52:18.309267
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    # Create an instance of a class
    x = SemanticVersion('1.5.5')
    # Compare the class to a string
    assert x.__ne__('1.5.5')
    assert not x.__ne__('1.5.5')
    # Compare the class to its self
    assert not x.__ne__(x)
    assert x.__ne__(SemanticVersion('1.5.6'))
    assert not x.__ne__(SemanticVersion('1.5.5'))
    # Create an instance of a SemanticVersion class
    y = SemanticVersion('1.5.5')
    assert not x.__ne__(y)
    # Compare the class to an instance of a different class
    assert x.__ne__(object())
    # Compare the class to an instance of a different class

# Generated at 2022-06-23 14:52:20.906979
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("4.4.4")
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion("4.4.4")

# Generated at 2022-06-23 14:52:22.038944
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert str(_Numeric(1)) == '1'


# Generated at 2022-06-23 14:52:23.716976
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert repr(_Alpha('alpha')) == repr('alpha')
    assert repr(_Alpha('beta')) == repr('beta')
    return


# Generated at 2022-06-23 14:52:25.268647
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('prerelease')) == repr('prerelease')


# Generated at 2022-06-23 14:52:28.205734
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    x = _Alpha('a')
    y = _Alpha('b')
    assert(x < y)
    assert(x <= y)
    assert(not y < x)
    assert(not y <= x)


# Generated at 2022-06-23 14:52:32.093072
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v = SemanticVersion('1.0.0')
    assert v == v
    assert v == '1.0.0'
    assert v != '0.0.1'
    assert v != '1.0.0-rc'
    assert v == '1.0.0+build1'
    assert v != '1.0.0-rc+build1'


# Generated at 2022-06-23 14:52:34.386911
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # test when both operands are strings
    assert _Alpha('a') >= _Alpha('b')

    # test when first operand is a string and second is an object of type _Alpha
    assert _Alpha('a') >= _Alpha('b')


# Generated at 2022-06-23 14:52:36.016589
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    try:
        v = SemanticVersion()
    except TypeError:
        return
    assert False, 'SemanticVersion should raise TypeError'


# Generated at 2022-06-23 14:52:40.345245
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(3) == _Numeric(3)
    assert _Numeric(3) == 3
    assert _Numeric(3) != _Numeric('3')
    assert _Numeric(3) != '3'
    assert _Numeric(3) != _Alpha(3)
    assert _Numeric(3) != _Alpha('3')
    assert _Numeric(3) != _Numeric(4)
    assert _Numeric(3) != 4
    assert _Numeric(3) != _Alpha(4)


# Generated at 2022-06-23 14:52:49.975595
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('0.0.0-alpha') < SemanticVersion('0.0.0-beta')
    assert SemanticVersion('0.0.0-alpha') < SemanticVersion('0.0.0-alpha.1')
    assert SemanticVersion('0.0.0-alpha') < SemanticVersion('0.0.0-alpha.beta')
    assert SemanticVersion('0.0.0-alpha.1') < SemanticVersion('0.0.0-alpha.beta')
    assert SemanticVersion('0.0.0-alpha.beta') < SemanticVersion('0.0.0-beta')
    assert SemanticVersion('0.0.0-alpha.beta') < SemanticVersion('0.0.0-beta.2')

# Generated at 2022-06-23 14:52:53.294774
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    """Test comparison of numeric and alpha specifiers
    """
    assert _Numeric(2) < _Alpha('beta')
    assert not _Numeric(2) < _Numeric(2)
    assert _Numeric(2) < _Numeric(3)


# Generated at 2022-06-23 14:52:54.556847
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion("1.0.0") == SemanticVersion("1.0.0")


# Generated at 2022-06-23 14:53:03.468252
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('b') is False
    assert _Alpha('b') >= _Alpha('a') is True
    assert _Alpha('b') >= _Alpha('c') is False
    assert _Alpha('c') >= _Alpha('b') is True
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('2') <= _Alpha('2')
    assert _Alpha('1') <= _Alpha('2')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('1') <= _Alpha('a')


# Generated at 2022-06-23 14:53:06.049404
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha(1) == 1
    assert _Alpha(1) == _Alpha(1)
    assert not _Alpha(1) == _Alpha(2)


# Generated at 2022-06-23 14:53:07.461570
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    _numeric = _Numeric(1)
    assert(repr(_numeric) == '1')


# Generated at 2022-06-23 14:53:09.680042
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('1')) == "'1'"
    assert repr(_Alpha('foo')) == "'foo'"
    assert repr(_Alpha('foo.baz')) == "'foo.baz'"


# Generated at 2022-06-23 14:53:11.003700
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    a = _Alpha("alpha")
    assert repr(a) == "\"alpha\""


# Generated at 2022-06-23 14:53:18.538807
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    import unittest

    from ansible.module_utils.six import PY2, PY3

    class TestSemanticVersion___le__(unittest.TestCase):
        def test_simple(self):
            for version in (
                    "1.2.3",
                    "0.4.4-beta",
                    "1.2.3+build",
                    "1.2.3-alpha.10+build.unicorn.rainbow",
            ):
                self.assertTrue(SemanticVersion(version) <= version)

        def test_mixed_string_number(self):
            # Make sure that a string and a number sort in the proper order
            # This will fail if the _Alpha in SemanticVersion is not used
            # properly
            self.assertTrue("alpha" <= "10")

# Generated at 2022-06-23 14:53:22.336400
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < 2

    assert not _Numeric(1) < 1

    assert not _Numeric(2) < 1

    assert _Numeric(1) < _Numeric(2)

    assert not _Numeric(1) < _Numeric(1)

    assert not _Numeric(2) < _Numeric(1)


# Generated at 2022-06-23 14:53:23.609395
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.0.0') != '0.0.0'



# Generated at 2022-06-23 14:53:26.541484
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha = _Alpha("a")
    assert alpha <= _Alpha("a")
    assert alpha <= "a"
    assert not (alpha <= "b")
    assert not (alpha <= _Numeric("1"))



# Generated at 2022-06-23 14:53:30.674209
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('b') == _Alpha('b')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('b') != _Alpha('a')


# Generated at 2022-06-23 14:53:40.716381
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # assert first <= second
    assert SemanticVersion("1.0.0") <= SemanticVersion("1.1.0")
    assert SemanticVersion("1.1.0") <= SemanticVersion("2.0.0")
    assert SemanticVersion("2.0.0") <= SemanticVersion("2.1.0")
    assert SemanticVersion("2.1.0") <= SemanticVersion("2.1.1")
    assert SemanticVersion("2.1.1") <= SemanticVersion("3.0.0")
    assert SemanticVersion("3.0.0") <= SemanticVersion("3.0.1")
    assert SemanticVersion("3.0.1") <= SemanticVersion("3.1.0")
    assert SemanticVersion("3.1.0") <= SemanticVersion("3.2.0")


# Generated at 2022-06-23 14:53:47.160967
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    # For valid inputs, it must return True
    x = _Alpha('a')
    y = _Alpha('a')
    assert (x.__eq__(y) == True)
    x = _Alpha('a')
    y = 'a'
    assert (x.__eq__(y) == True)
    # For invalid inputs, it must return False
    x = _Alpha('a')
    y = _Alpha('b')
    assert (x.__eq__(y) == False)
    x = _Alpha('a')
    y = 'b'
    assert (x.__eq__(y) == False)
    x = _Alpha('a')
    y = _Numeric(1)
    assert (x.__eq__(y) == False)


# Generated at 2022-06-23 14:53:57.661405
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    sv = SemanticVersion()
    vstring = '2.2.2'
    sv.parse(vstring)
    assert sv.major == 2
    assert sv.minor == 2
    assert sv.patch == 2
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()

    vstring = '2.2.2-alpha.2'
    sv.parse(vstring)
    assert sv.major == 2
    assert sv.minor == 2
    assert sv.patch == 2
    assert sv.prerelease == (_Alpha(u'alpha'), _Numeric(u'2'))
    assert sv.buildmetadata == ()

    vstring = '2.2.2+build.2'
    sv.parse(vstring)
    assert sv.major == 2
    assert sv.minor == 2

# Generated at 2022-06-23 14:54:05.706846
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    _Numeric(2) < _Numeric(5)
    _Numeric(5) < _Numeric(10)
    _Numeric(10) < _Numeric(20)
    _Numeric(20) < _Numeric(50)
    _Numeric(50) < _Numeric(100)
    _Numeric(100) < _Numeric(200)
    _Numeric(200) < _Numeric(500)
    _Numeric(500) < _Numeric(1000)
    _Numeric(1000) < _Numeric(2000)
    _Numeric(2000) < _Numeric(5000)
    _Numeric(5000) < _Numeric(10000)
    _Numeric(10000) < _Numeric(20000)
    _Numeric(20000) < _Numeric(50000)
   

# Generated at 2022-06-23 14:54:10.160051
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v = SemanticVersion()
    assert v is not None
    # Place holder for unit test of method __ge__ of class SemanticVersion
    assert False, 'No unit test written for method __ge__ of class SemanticVersion'


# Generated at 2022-06-23 14:54:13.283903
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion().__repr__() == 'SemanticVersion(None)'
    assert SemanticVersion('2.0.0').__repr__() == 'SemanticVersion(\'2.0.0\')'


# Generated at 2022-06-23 14:54:19.194540
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha("a")
    b = _Alpha("b")

    assert (a >= b) == False
    assert (a >= "b") == False
    assert (a >= _Alpha("b")) == False

    assert (a >= a) == True
    assert (a >= "a") == True
    assert (a >= _Alpha("a")) == True

    assert (b >= a) == True
    assert (b >= "a") == True
    assert (b >= _Alpha("a")) == True


# Generated at 2022-06-23 14:54:24.707060
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') >= _Alpha('0')
    assert _Alpha('1') >= _Alpha('1')
    assert not _Alpha('1') >= _Alpha('2')
    assert _Alpha('1') >= '0'
    assert _Alpha('1') >= '1'
    assert not _Alpha('1') >= '2'
    assert not _Alpha('1') >= 2
    assert _Alpha('1') >= _Numeric('1')


# Generated at 2022-06-23 14:54:30.017885
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    test_semver = SemanticVersion()
    test_semver.parse('1.0.0')
    assert test_semver >= SemanticVersion('1.0.0')
    assert test_semver >= SemanticVersion('1.0.1')
    assert test_semver >= SemanticVersion('2.0.0')
    assert test_semver >= SemanticVersion('1.0.0-rc1')
    assert test_semver >= SemanticVersion('1.0.0-beta.2')
    assert test_semver >= SemanticVersion('1.0.1-rc1')
    assert test_semver >= SemanticVersion('1.0.0-rc1+build.1')
    assert test_semver >= '1.0.0'
    assert test_semver >= '1.0.1'


# Generated at 2022-06-23 14:54:40.245120
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('2.0.0a1') == SemanticVersion('2.0.0a1')
    assert SemanticVersion('2.0.0.a1') == SemanticVersion('2.0.0.a1')
    assert SemanticVersion('2.0.0-a1') == SemanticVersion('2.0.0-a1')
    assert SemanticVersion('2.0.0+a1') == SemanticVersion('2.0.0+a1')
    assert SemanticVersion('2.0.0.a1+a1') == SemanticVersion('2.0.0.a1+a1')
    assert SemanticVersion('2.0.0-a1.a2+a1') == SemanticVersion('2.0.0-a1.a2+a1')
    assert Sem

# Generated at 2022-06-23 14:54:42.863060
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    result = _Numeric(1) != _Numeric(1)
    assert result is False
    assert result == False


# Generated at 2022-06-23 14:54:47.786605
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1

    assert _Numeric(1) != _Alpha('1')
    assert _Numeric(1) != _Alpha('2')
    assert _Numeric(1) != '1'
    assert _Numeric(1) != '2'



# Generated at 2022-06-23 14:54:51.059978
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion(vstring='2.1.1').__repr__() == "SemanticVersion('2.1.1')"
    assert SemanticVersion(vstring='0.0.1').__repr__() == "SemanticVersion('0.0.1')"



# Generated at 2022-06-23 14:54:53.231825
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Given
    s = SemanticVersion("1.2.3")

    # When
    r = s.__eq__("1.2.3+abc")

    # Then
    assert r == True


# Generated at 2022-06-23 14:54:57.223870
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('a')
    a_ = _Alpha('a')
    b = _Alpha('b')

    assert a <= b
    assert a <= a_
    assert b <= b
    assert a_ <= a
    assert a_ <= b



# Generated at 2022-06-23 14:54:59.185303
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') != 'b'
    assert _Alpha('a') != 1


# Generated at 2022-06-23 14:55:04.531427
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    a = _Numeric(2)
    b = _Numeric(2)
    c = _Numeric(3)
    d = 2
    assert a == b
    assert a == d
    assert b == d
    assert not(a == c)
    assert not(b == c)


# Generated at 2022-06-23 14:55:11.821455
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Testing this Python 2/3 compatible class is non-trivial. We need
    # an environment where we can test both 2 and 3.
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') < 'b'
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert 'a' < _Alpha('b')
    assert 'a' <= _Alpha('a')
    assert 'a' <= _Alpha('b')
    # This fails in Python 3.0 - 3.4, but works in all versions of 2
    # assert _Alpha('b') > 'a'
    assert _Alpha('a') != _Alpha('b')

# Generated at 2022-06-23 14:55:15.516920
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('1.2.3-alpha.1')
    v2 = SemanticVersion(v1)
    assert v1.__eq__(v1)
    assert v1.__eq__(v2)


# Generated at 2022-06-23 14:55:18.452533
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha("A") == "A"
    assert not (_Alpha("A") == "B")
    assert _Alpha("A") == _Alpha("A")
    assert not (_Alpha("A") == _Alpha("B"))


# Generated at 2022-06-23 14:55:20.680644
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == '1'


# Generated at 2022-06-23 14:55:23.534597
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    repralpha = _Alpha("alpha").__repr__()
    if repralpha != "'alpha'":
        raise AssertionError


# Generated at 2022-06-23 14:55:32.711316
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests with "normal" LooseVersions
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4.5.6')) == SemanticVersion('1.2.3+4.5.6')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5.6')) == SemanticVersion('1.2.3-4.5.6')
    # Test without prerelease or build metadata
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-23 14:55:41.459983
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != 'b'
    assert 'a' != _Alpha('b')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') < 'b'
    assert 'a' < _Alpha('b')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') <= 'b'
    assert 'a' <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'a'
    assert 'a' <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('a')

# Generated at 2022-06-23 14:55:52.723002
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    invalid_type_func_fixtures = [
        (_Numeric(2), _Numeric(3)),
        (1, _Numeric(3)),
        (_Numeric(1), 2),
        ("1", _Numeric(3)),
        (_Numeric(3), "1"),
    ]

    for args in invalid_type_func_fixtures:
        try:
            _Alpha.__ge__(*args)
            raise AssertionError("test__Alpha___ge__() failed with args %s" % args)
        except ValueError:
            pass

    success_func_fixtures = [
        ("a", "a", True),
        ("a", "b", True),
        ("b", "a", False),
    ]

    for args, expected in success_func_fixtures:
        arg1, arg2, exp

# Generated at 2022-06-23 14:56:02.314057
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:56:13.769659
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert not _Alpha('1') < _Alpha('1')
    assert _Alpha('1') < _Alpha('2')
    assert not _Alpha('2') < _Alpha('1')
    assert _Alpha('abc') < _Alpha('abcd')
    assert not _Alpha('abcd') < _Alpha('abc')
    assert _Alpha('1.2.3') < _Alpha('1.2.4')
    assert not _Alpha('1.2.4') < _Alpha('1.2.3')
    assert _Alpha('1.2.3') < _Alpha('1.2.4.1')
    assert not _Alpha('1.2.4.1') < _Alpha('1.2.3')
    assert _Alpha('abc.1') < _Alpha('abc.2')
    assert not _Alpha('abc.2') < _

# Generated at 2022-06-23 14:56:18.223058
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0') < SemanticVersion('2.0')
    assert SemanticVersion('2.0') > SemanticVersion('1.0')
    assert SemanticVersion('2.0') > SemanticVersion('0.20')
    assert SemanticVersion('0.30') < SemanticVersion('0.9')


# Generated at 2022-06-23 14:56:29.916409
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v1 = SemanticVersion('0.0.1')
    v2 = SemanticVersion('0.1.1')
    assert v1 < v2
    v1 = SemanticVersion('0.0.1')
    v2 = SemanticVersion('1.0.1')
    assert v1 < v2
    v1 = SemanticVersion('0.0.1')
    v2 = SemanticVersion('0.0.2')
    assert v1 < v2
    v1 = SemanticVersion('0.0.1-alpha')
    v2 = SemanticVersion('0.0.1')
    assert v1 < v2
    v1 = SemanticVersion('0.0.1')
    v2 = SemanticVersion('0.0.1-alpha')
    assert not v1 < v2

# Generated at 2022-06-23 14:56:39.340316
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():

    # initialize variables
    ansible_module = exit_json = None
    ansible_module = AnsibleModule(argument_spec=dict(
        string_one=dict(type='str', default='v2.3.3'),
        string_two=dict(type='str', default='1.2.3'),
        string_three=dict(type='str', default='2.3.3'),
    ),
                                  supports_check_mode=True)
    string_one = ansible_module.params['string_one']
    string_two = ansible_module.params['string_two']
    string_three = ansible_module.params['string_three']

# Generated at 2022-06-23 14:56:41.510287
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('9.9.9')
    assert repr(v) == "SemanticVersion('9.9.9')"


# Generated at 2022-06-23 14:56:51.077515
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    s = SemanticVersion('1.3.3')
    assert s <= '1.3.3'
    assert s <= '1.3.4'
    assert s <= '1.4.3'
    assert s <= '2.3.3'
    assert s <= '1.3.3-beta'
    assert s <= '1.3.4-alpha.1'
    assert s <= '1.4.3-beta'
    assert s <= '2.3.3-alpha'
    assert s <= '1.3.3-alpha'
    assert s <= '1.3.3-alpha+gdp'
    assert s <= '1.3.3-alpha+old'
    assert s <= '1.3.3-alpha+gdc'


# Generated at 2022-06-23 14:56:54.602413
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('1') != '1'
    assert _Alpha('1') != '2'


# Generated at 2022-06-23 14:57:03.560260
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    SV = SemanticVersion
    # https://semver.org/#spec-item-11
    assert SV('1.0.0-alpha') <= SV('1.0.0-alpha.1')
    assert SV('1.0.0-alpha.1') <= SV('1.0.0-alpha.beta')
    assert SV('1.0.0-alpha.beta') <= SV('1.0.0-beta')
    assert SV('1.0.0-beta') <= SV('1.0.0-beta.2')
    assert SV('1.0.0-beta.2') <= SV('1.0.0-beta.11')
    assert SV('1.0.0-beta.11') <= SV('1.0.0-rc.1')

# Generated at 2022-06-23 14:57:04.651076
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    w = _Numeric(1)
    assert w != 'a' 
    

# Generated at 2022-06-23 14:57:16.003110
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.2.3') >= SemanticVersion('1.2.3')
    assert not SemanticVersion('1.2.3') >= SemanticVersion('1.2.4')
    assert not SemanticVersion('1.2.3') >= SemanticVersion('1.3.0')
    assert not SemanticVersion('1.2.3') >= SemanticVersion('2.0.0')

    assert SemanticVersion('1.2.3') >= SemanticVersion('1.2.3-rc.1')
    assert not SemanticVersion('1.2.3') >= SemanticVersion('1.2.3-rc.2')

    assert SemanticVersion('1.2.3-rc.1') >= SemanticVersion('1.2.3-rc.1')

# Generated at 2022-06-23 14:57:17.279152
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric("10") > _Numeric("9")


# Generated at 2022-06-23 14:57:27.427222
# Unit test for method __le__ of class SemanticVersion

# Generated at 2022-06-23 14:57:31.915258
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    """Test"""
    if (_Numeric(3) >= _Numeric(2)):
        pass
    else:
        assert False, "Expected False"
    if (_Numeric(1) >= _Numeric(1)):
        pass
    else:
        assert False, "Expected False"



# Generated at 2022-06-23 14:57:41.716200
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    
    # Try 1
    obj1 = _Alpha(specifier = '1')
    obj2 = _Alpha(specifier = '2')
    try:
        assert obj1.__ge__(obj2)
    except:
        print('Fail: 1: _Alpha(specifier = "1").__ge__(_Alpha(specifier = "2")')
    
    # Try 2
    obj1 = _Alpha(specifier = '3')
    obj2 = _Alpha(specifier = '3')
    try:
        assert obj1.__ge__(obj2)
    except:
        print('Fail: 2: _Alpha(specifier = "3").__ge__(_Alpha(specifier = "3")')
    
    # Try 3
    obj1 = _Alpha(specifier = '4')
    obj2 = _Alpha

# Generated at 2022-06-23 14:57:46.260162
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Compare two SemanticVersions
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('1.0.0')
    assert (a == b)

    # Compare a SemanticVersion to a string
    a = SemanticVersion('1.0.0')
    b = '1.0.0'
    assert (a == b)

    # Compare a string to a SemanticVersion
    a = '1.0.0'
    b = SemanticVersion('1.0.0')
    assert (a == b)


# Generated at 2022-06-23 14:57:47.439361
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('0') > _Alpha('-')


# Generated at 2022-06-23 14:57:50.517076
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("a") <= _Alpha("a")
    assert _Alpha("a") <= _Alpha("b")
    assert _Alpha("a") <= "b"
    assert "a" <= _Alpha("b")
    assert _Alpha("a") <= 0


# Generated at 2022-06-23 14:57:56.112359
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('20') > '20'
    assert _Numeric('20') > _Alpha('20')
    assert not _Numeric('20') > _Numeric('20')

    assert _Numeric('20') > _Numeric('10')
    assert not _Numeric('20') > _Numeric('30')

    with pytest.raises(ValueError):
        _Numeric('20') > _Alpha('10')
    with pytest.raises(ValueError):
        _Numeric('20') > '10'


# Generated at 2022-06-23 14:58:05.483314
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= 2
    assert _Numeric(1) >= _Numeric(2)

    assert _Numeric(2) >= 1
    assert _Numeric(2) >= 2
    assert _Numeric(2) >= _Numeric(1)

    assert _Numeric(1) >= _Alpha('1')
    assert _Numeric(1) >= _Alpha('2')

    assert _Numeric(2) >= _Alpha('1')
    assert _Numeric(2) >= _Alpha('2')

    assert not (_Numeric(1) >= _Alpha('a'))
    assert not (_Numeric(2) >= _Alpha('a'))

    # Fails because _Numeric and _Alpha are of different types
    # assert _Numeric(1) >= _Alpha('

# Generated at 2022-06-23 14:58:14.616655
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    test_version = SemanticVersion('1.0.0')
    # This assert checks initialization
    assert test_version.major == 1
    assert test_version.minor == 0
    assert test_version.patch == 0
    assert test_version.prerelease == ()
    assert test_version.buildmetadata == ()

    test_version = SemanticVersion('1.0.0-alpha.1+junk')
    # This assert checks initialization
    assert test_version.major == 1
    assert test_version.minor == 0
    assert test_version.patch == 0
    assert test_version.prerelease == ('alpha', '1')
    assert test_version.buildmetadata == ('junk',)

    # This assert checks initialization
    test_version = SemanticVersion('1.0.0-alpha')

# Generated at 2022-06-23 14:58:19.482190
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    d = _Alpha('d')

    assert a > b
    assert a > c
    assert b > c
    assert a > d
    assert b > d
    assert c > d


# Generated at 2022-06-23 14:58:24.162011
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('0.0.0')
    b = _Alpha('0.1.0')
    c = _Alpha('0.0.0')
    assert a.__ne__(b)
    assert not a.__ne__(c)
    return "test__Alpha___ne__(): OK"


# Generated at 2022-06-23 14:58:34.670490
# Unit test for method parse of class SemanticVersion