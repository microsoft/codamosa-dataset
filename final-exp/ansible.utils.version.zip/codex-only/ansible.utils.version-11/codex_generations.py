

# Generated at 2022-06-23 14:48:36.151040
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    v3 = SemanticVersion('1.2.4')

    # Test for expected success
    assert (v1 == v2) is True
    assert (v1 == v3) is False

    # Test for expected failure
    try:
        v1 == '1.2.3'
    except ValueError:
        pass
    else:
        raise AssertionError("Parsing succeeded when it should have failed")


# Generated at 2022-06-23 14:48:47.497683
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+ansible')) == SemanticVersion('1.2.3+ansible')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+ansible')) == SemanticVersion('1.2.3-alpha.1+ansible')

# Generated at 2022-06-23 14:48:51.967079
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    if not isinstance(SemanticVersion('1.0.0') >= '1.0.0', bool):
        return False
    if not isinstance(SemanticVersion('1.0.0') >= SemanticVersion('1.0.0'), bool):
        return False
    if not SemanticVersion('1.0.0') >= '1.0.0':
        return False
    if not SemanticVersion('1.0.0') >= SemanticVersion('1.0.0'):
        return False
    return True

# Generated at 2022-06-23 14:48:53.234824
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a = _Alpha('alpha')
    assert a == 'alpha'


# Generated at 2022-06-23 14:48:57.998286
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("a") >= "a"
    assert not _Alpha("a") >= "b"
    assert _Alpha("1") >= _Alpha("1")
    assert not _Alpha("1") >= _Alpha("2")
    assert not _Alpha("a") >= _Alpha("1")
    assert not _Alpha("1") >= _Alpha("a")


# Generated at 2022-06-23 14:49:04.799586
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    num = _Numeric(0)
    num2 = _Numeric(0)
    num3 = _Numeric(1)
    num4 = _Numeric('0')
    assert not num.__ne__(num2)
    assert num.__ne__(num3)
    assert num.__ne__(num4)
    assert not num.__ne__(0)
    assert not num.__ne__('0')
    assert num.__ne__('1')
    assert num.__ne__(1)
    assert num.__ne__([])
    assert num.__ne__({})


# Generated at 2022-06-23 14:49:05.965071
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    pass



# Generated at 2022-06-23 14:49:07.699014
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('5')) == '5'


# Generated at 2022-06-23 14:49:09.032847
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != 'a'



# Generated at 2022-06-23 14:49:13.300316
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('').specifier == ''
    assert _Alpha('a').specifier == 'a'
    assert _Alpha(1).specifier == 1
    assert _Alpha(object()).specifier == object()
    assert _Alpha(None).specifier is None


# Generated at 2022-06-23 14:49:15.609356
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = '1.2.3-beta.1'
    expected = 'SemanticVersion(%r)' % version
    obj = SemanticVersion(version)
    actual = obj.__repr__()
    assert actual == expected



# Generated at 2022-06-23 14:49:16.980953
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(2)



# Generated at 2022-06-23 14:49:26.280452
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == _Numeric('1')

    assert _Numeric('1') != _Numeric('2')
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != _Numeric('2')

    assert _Numeric('1') != 1
    assert _Numeric(1) != '1'

    assert _Numeric('1') <= _Numeric('2')
    assert _Numeric('1') <= _Numeric(2)
    assert _Numeric('2') >= _Numeric('1')
    assert _Numeric(2) >= _Numeric('1')

    assert _Numeric('1') < _Numeric('2')

# Generated at 2022-06-23 14:49:29.222939
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    sv = SemanticVersion(vstring='0.1.0')
    assert sv.__repr__() == 'SemanticVersion(\'0.1.0\')'


# Generated at 2022-06-23 14:49:35.796910
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.10.24') == SemanticVersion('1.10.24')
    assert SemanticVersion('1.10.24') == '1.10.24'
    assert '1.10.24' == SemanticVersion('1.10.24')
    assert SemanticVersion('1.10.24') != SemanticVersion('1.10.23')
    assert SemanticVersion('1.10.24') != '1.10.23'
    assert '1.10.24' != SemanticVersion('1.10.23')


# Generated at 2022-06-23 14:49:40.043159
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.2.3') >= '1.2.3'
    assert SemanticVersion('1.2.3') >= '1.2.3-alpha'
    assert SemanticVersion('1.2.3-alpha') >= '1.2.3'
    assert SemanticVersion('1.2.3-alpha') >= '1.2.3-alpha'



# Generated at 2022-06-23 14:49:40.950602
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('x') == 'x'

# Generated at 2022-06-23 14:49:50.463263
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Ensure that a LooseVersion with an integer major version is successfully
    # converted to a SemanticVersion as long as the rest of the LooseVersion
    # is numeric (or does not have extraneous characters).
    loose_version = LooseVersion('10.2.3')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version == SemanticVersion('10.2.3')

    # Ensure that a LooseVersion with an integer major version is not
    # converted to a SemanticVersion if the LooseVersion has extraneous
    # characters.
    loose_version = LooseVersion('10a.2.3')
    try:
        SemanticVersion.from_loose_version(loose_version)
        assert False
    except ValueError:
        pass

    # Ensure that a LooseVersion with

# Generated at 2022-06-23 14:49:53.052478
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(1)
    assert a.specifier == 1
    assert a != 5
    assert a != _Numeric(5)



# Generated at 2022-06-23 14:49:56.327274
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha("a")
    b = _Alpha("b")

    assert (a != b) == True
    assert (a == b) == False


# Generated at 2022-06-23 14:49:57.645143
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha(1) == _Alpha(1)



# Generated at 2022-06-23 14:50:03.919880
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    test_cases = [
        {
            'in': None,
            'out': 'SemanticVersion(None)',
        },
        {
            'in': '5.5.5',
            'out': 'SemanticVersion(\'5.5.5\')',
        }
    ]
    for test_case in test_cases:
        assert text_type(SemanticVersion(test_case['in'])) == test_case['out']


# Generated at 2022-06-23 14:50:06.585564
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.0.1')) == "SemanticVersion('1.0.1')"


# Generated at 2022-06-23 14:50:16.417568
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test not match
    try:
        SemanticVersion().parse('abcdef')
    except ValueError:
        pass
    else:
        raise AssertionError()

    # Test match
    version = SemanticVersion()
    version.parse('0.0.0')
    assert version.major == 0
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # Test match
    version = SemanticVersion()
    version.parse('1.2.3')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # Test match
    version = SemanticVersion()

# Generated at 2022-06-23 14:50:24.866456
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()

    # valid
    v.parse('0.0.0')
    assert (v.major == 0)
    assert (v.minor == 0)
    assert (v.patch == 0)
    assert (v.prerelease == ())
    assert (v.buildmetadata == ())

    v.parse('0.0.0-alpha')
    assert (v.major == 0)
    assert (v.minor == 0)
    assert (v.patch == 0)
    assert (v.prerelease == ('alpha',))
    assert (v.buildmetadata == ())

    v.parse('0.0.0-alpha.1.2')
    assert (v.major == 0)
    assert (v.minor == 0)
    assert (v.patch == 0)

# Generated at 2022-06-23 14:50:29.566364
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    x = _Numeric(1)
    assert x >= 1
    assert x >= _Numeric(1)
    assert not x >= 2
    assert not x >= _Numeric(2)


# Generated at 2022-06-23 14:50:35.044914
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.2') == SemanticVersion('1.2.0')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3-rc.1') == SemanticVersion('1.2.3-rc.1')
    assert SemanticVersion('1.2.3+build.1') == SemanticVersion('1.2.3+build.1')


# Generated at 2022-06-23 14:50:37.617227
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    # Initialization of tests
    n = _Numeric(1)
    # Tests
    if not n.__repr__() == '1':
        raise AssertionError()
    # Destroy tests


# Generated at 2022-06-23 14:50:38.767722
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != 'a'



# Generated at 2022-06-23 14:50:42.211565
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    n1 = _Numeric('1')
    assert n1.__gt__(0)
    assert n1.__gt__('0')
    assert n1.__gt__('a') is None
    assert n1.__gt__(_Numeric('1')) is None


# Generated at 2022-06-23 14:50:50.424545
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('A') != 'a'
    assert _Alpha('a') != '0'
    assert _Alpha('a') != 0
    assert not _Alpha('a') == 0
    assert not _Alpha('a') < 0
    assert not _Alpha('a') > 0
    assert _Alpha('a') <= 0
    assert _Alpha('a') >= 0
    assert _Alpha('a') < '0'
    assert _Alpha('a') <= '0'
    assert not _Alpha('a') > '0'
    assert not _Alpha('a') >= '0'
    assert not _Alpha('a') == '0'
    assert not _Alpha('a') != '0'
    assert _Alpha('a') == 'a'


# Generated at 2022-06-23 14:50:56.917051
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test valid parsing
    v = SemanticVersion('1.2.3')
    assert(v.core == (1, 2, 3))
    assert(v.prerelease == ())
    assert(v.buildmetadata == ())
    assert(v.is_prerelease == False)
    assert(v.is_stable == True)

    v = SemanticVersion('1.2.3-alpha')
    assert(v.core == (1, 2, 3))
    assert(v.prerelease == (_Alpha('alpha'),))
    assert(v.buildmetadata == ())
    assert(v.is_prerelease == True)
    assert(v.is_stable == False)

    v = SemanticVersion('1.2.3-alpha.1.beta')
    assert(v.core == (1, 2, 3))

# Generated at 2022-06-23 14:51:01.292842
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion("2.11.0") > SemanticVersion("2.10.0")
    assert SemanticVersion("2.11.0") > SemanticVersion("2.10.0")
    assert SemanticVersion("2.11.0") > SemanticVersion("2.11.0-alpha")


# Generated at 2022-06-23 14:51:04.425886
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('1') == _Alpha('1')
    assert _Alpha('1') == '1'
    assert _Alpha('1') != _Alpha('2')


# Generated at 2022-06-23 14:51:13.793628
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class TestCase:
        pass


# Generated at 2022-06-23 14:51:22.090904
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('B') == 'B'
    assert _Alpha('B') == _Alpha('B')
    assert _Alpha('B') != 'b'
    assert _Alpha('B') != _Alpha('b')
    assert _Alpha('B') < 'b'
    assert _Alpha('B') < _Alpha('b')
    assert 'B' < _Alpha('b')
    assert _Alpha('B') <= 'B'
    assert _Alpha('B') <= _Alpha('B')
    assert _Alpha('B') <= 'b'
    assert _Alpha('B') <= _Alpha('b')
    assert 'B' <= _Alpha('B')
    assert _Alpha('B') >= 'B'
    assert _Alpha('B') >= _Alpha('B')
    assert _Alpha('B') >= 'b'
    assert _Alpha('B')

# Generated at 2022-06-23 14:51:23.807740
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha("test")
    assert repr(alpha) == "'test'"


# Generated at 2022-06-23 14:51:30.688117
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert not _Numeric(4) < 4
    assert not 4 < _Numeric(4)
    assert _Numeric(4) < 5
    assert not 5 < _Numeric(4)
    assert _Numeric(5) == 5
    assert _Numeric(5) < _Alpha('abc')
    assert not _Numeric(5) < _Numeric(5)
    assert _Numeric(5) < _Numeric(6)
    assert _Numeric(6) > _Numeric(5)


# Generated at 2022-06-23 14:51:33.677253
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == _Numeric(2)
    assert _Numeric(1) == 1
    assert not _Numeric(2) == 1


# Generated at 2022-06-23 14:51:35.164208
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('10.2.2') != '10.2.2'


# Generated at 2022-06-23 14:51:44.303952
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    class _Alpha(object):
        def __init__(self, specifier):
            self.specifier = specifier

        def __le__(self, other):
            if isinstance(other, _Alpha):
                return self.specifier <= other.specifier
            elif isinstance(other, str):
                return self.specifier <= other

            raise ValueError

    assert _Alpha('alpha').__le__('alpha')
    assert _Alpha('alpha').__le__(_Alpha('alpha'))
    assert not _Alpha('alpha').__le__('beta')
    assert not _Alpha('alpha').__le__(_Alpha('beta'))
    assert _Alpha('beta').__le__('beta')
    assert _Alpha('beta').__le__(_Alpha('beta'))
    assert not _Alpha('beta').__le__('alpha')
   

# Generated at 2022-06-23 14:51:55.181397
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha(1) <= _Alpha(2)
    assert _Alpha('beta') <= _Alpha('alpha')
    assert not (_Alpha(1) <= 'beta')
    assert not ('alpha' <= _Alpha(2))
# Define test cases for method __ge__ of class _Alpha
test__Alpha___ge___list = [
    _Alpha(1),
    _Alpha('beta')
]
# Define test cases for method __lt__ of class _Alpha
test__Alpha___lt___list = [
    _Alpha(2),
    _Alpha('alpha')
]
# Define test cases for method __ne__ of class _Alpha
test__Alpha___ne___list = [
    _Alpha(2),
    _Alpha('alpha')
]
# Define test cases for method __eq__ of class _Alpha
test__Alpha___

# Generated at 2022-06-23 14:52:03.550673
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # This is the set of (input, expected) pairs that we will use in testing the method
    pairs_to_test = [
        ((_Alpha('a'), _Alpha('b')), True),
        ((_Alpha('a'), _Alpha('a')), False),
        ((_Alpha('b'), _Alpha('a')), False),
    ]
    for ((alphas, expected), value) in zip(pairs_to_test, [
        _Alpha(alphas[0]).__lt__(_Alpha(alphas[1])),
        _Alpha(alphas[0]).__lt__(_Alpha(alphas[0])),
        _Alpha(alphas[0]).__lt__(_Alpha(alphas[1])),
    ]):
        # Check that the result of calling the function is correct
        assert(value == expected)

# Unit test

# Generated at 2022-06-23 14:52:10.604064
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric('1') > _Numeric('0.5')
    assert _Numeric('1') > _Numeric('1')
    assert not _Numeric('1') > _Numeric('2')
    assert not _Numeric('1') > _Numeric('1.5')
    assert not _Numeric('1') > _Numeric('1.0')


# Generated at 2022-06-23 14:52:21.522745
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('1') >= '1'
    assert '1' >= _Alpha('1')
    assert _Alpha('1') >= 1
    assert 1 >= _Alpha('1')
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert 'a' >= _Alpha('a')
    assert _Alpha('1') >= _Alpha('a')
    assert _Alpha('1') >= 'a'
    assert '1' >= _Alpha('a')
    assert _Alpha('a') >= _Alpha('1')
    assert _Alpha('a') >= '1'
    assert 'a' >= _Alpha('1')
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('b') >= 'a'
   

# Generated at 2022-06-23 14:52:25.088157
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('alpha') > _Numeric('1')
    assert _Alpha('alpha') > _Numeric('2')
    assert _Alpha('alpha') > _Alpha('beta')
    assert _Alpha('alpha') > _Alpha('gamma')
    assert _Alpha('alpha') > _Alpha('0')

# Generated at 2022-06-23 14:52:28.046195
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('1')) == "'1'"
    assert repr(_Alpha('a')) == "'a'"
    assert repr(_Alpha('A')) == "'A'"
    assert repr(_Alpha('abc123')) == "'abc123'"


# Generated at 2022-06-23 14:52:29.901499
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    alpha = _Numeric(1)
    assert alpha != 2
    assert alpha != _Numeric(2)


# Generated at 2022-06-23 14:52:37.119675
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('1.2.3') == '1.2.3'
    assert _Alpha('1.2.3') < '1.2.3-rc01'
    assert _Alpha('1.2.3-rc01') < '1.2.3'
    assert _Alpha('1.2.3-rc01') > '1.2.3-rc'
    assert _Alpha('rc') < 'rc01'
    assert _Alpha('rc') < '1.2.3'
    assert _Alpha('rc01') < '1.2.3'
    assert _Alpha('1.2.3-rc') < '1.2.3-rc01'
    assert _Alpha('1.2.3-rc') < '1.2.3'

# Generated at 2022-06-23 14:52:40.565536
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v = SemanticVersion('1.0.0')
    assert v >= '1.0.0'   # assert a == b
    assert v >= '1.0.1'   # assert a < b
    assert not v >= '99.99.99'   # assert !(a > b)


# Generated at 2022-06-23 14:52:43.140696
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion("1.0.0") > SemanticVersion("0.9.9")
    assert not SemanticVersion("0.9.9") > SemanticVersion("0.9.9")
    assert not SemanticVersion("0.9.9") > SemanticVersion("1.0.0")


# Generated at 2022-06-23 14:52:50.009862
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    method = _Numeric.__ne__
    assert method(None, _Numeric(1)) is False, "Return value should be False"
    assert method(_Numeric(1), _Numeric('1')) is False, "Return value should be False"
    assert method(_Numeric(1), _Numeric(2)) is True, "Return value should be True"
    assert method(_Numeric(1), _Alpha('1')) is True, "Return value should be True"
    try:
        method(_Numeric(1), 1)
        raise AssertionError("Expected an exception to be raised")
    except ValueError:
        pass


# Generated at 2022-06-23 14:52:51.488517
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion("1.2.3")) == 'SemanticVersion(\'1.2.3\')'



# Generated at 2022-06-23 14:52:54.726162
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    v1 = _Numeric(1)
    v2 = _Numeric(2)
    v3 = _Numeric(3)
    assert v1 < v2
    assert v2 < v3
    assert v1 <= v2
    assert not v3 <= v2


# Generated at 2022-06-23 14:52:57.840410
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    assert isinstance(a, _Alpha)


# Generated at 2022-06-23 14:53:07.565088
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.2.3') != '1.2.3'
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3-dev') != '1.2.3-dev'
    assert SemanticVersion('1.2.3-dev') != SemanticVersion('1.2.3-dev')
    assert SemanticVersion('1.2.3+dev') != '1.2.3+dev'
    assert SemanticVersion('1.2.3+dev') != SemanticVersion('1.2.3+dev')
    assert SemanticVersion('1.2.3-dev+dev') != '1.2.3-dev+dev'
    assert SemanticVersion('1.2.3-dev+dev') != Semantic

# Generated at 2022-06-23 14:53:11.144667
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('3') <= _Numeric('3')
    assert _Numeric('3') <= _Numeric('4')
    assert _Numeric('3') <= 3
    assert not _Numeric('3') <= '3'
    assert not _Numeric('3') <= _Numeric('2')
    assert not _Numeric('3') <= 2


# Generated at 2022-06-23 14:53:15.062455
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= '1'
    assert _Numeric(1) <= _Numeric(1)
    assert not _Numeric(2) <= 1
    assert not _Numeric(2) <= '1'
    assert not _Numeric(2) <= _Numeric(1)


# Generated at 2022-06-23 14:53:17.335960
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1) == 5
    assert _Numeric(1) != 5
    assert _Numeric(1) != _Numeric(5)


# Generated at 2022-06-23 14:53:24.801932
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion("1.2.3") > SemanticVersion("1.2.2")
    assert SemanticVersion("1.2.3") > SemanticVersion("1.2")
    assert SemanticVersion("1.2.3") > SemanticVersion("1")
    assert SemanticVersion("1.2") > SemanticVersion("1")
    assert SemanticVersion("1") > SemanticVersion("0")
    assert SemanticVersion("0.0.1") > SemanticVersion("0.0.0")
    assert SemanticVersion("0.0.1") > SemanticVersion("0.0")
    assert SemanticVersion("1.2.3-alpha.0") > SemanticVersion("1.2.3-alpha")

# Generated at 2022-06-23 14:53:28.223906
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    one = _Numeric(1)
    one_again = _Numeric(1)

    assert(one == one_again)
    assert(one == 1)
    assert(1 == one)



# Generated at 2022-06-23 14:53:33.352827
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha("1") == "1"
    assert _Alpha("1") == _Alpha("1")
    assert _Alpha("1") != 1
    assert _Alpha("1") < "2"
    assert _Alpha("1") <= "2"
    assert _Alpha("1") <= "1"
    assert _Alpha("1") > "0"
    assert _Alpha("1") >= "0"
    assert _Alpha("1") >= "1"


# Generated at 2022-06-23 14:53:37.827193
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == 1
    assert _Numeric(1) != '1'
    assert _Numeric(1) < 2
    assert _Numeric(1) <= 2
    assert _Numeric(2) > 1
    assert _Numeric(2) >= 1


# Generated at 2022-06-23 14:53:42.788340
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(5) > _Numeric(4)
    assert _Numeric(5) > 4
    assert _Numeric(5) > _Alpha('4')
    assert not _Numeric(5) > _Numeric(5)
    assert not _Numeric(5) > 5
    assert not _Numeric(5) > _Alpha('5')
    assert not _Numeric(5) > _Alpha('6')


# Generated at 2022-06-23 14:53:43.397564
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    pass

# Generated at 2022-06-23 14:53:52.708678
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test against same type
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('b') <= _Alpha('b')
    assert _Alpha('c') <= _Alpha('b')
    # Test against string type
    assert _Alpha('a') <= 'b'
    assert _Alpha('b') <= 'b'
    assert _Alpha('c') <= 'b'
    # Test against int type
    assert _Alpha('a') <= 3
    assert _Alpha('b') <= 1
    assert _Alpha('b') <= '3'


# Generated at 2022-06-23 14:54:03.763890
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            a = _Numeric(1)
            b = _Numeric(2)
            self.assertTrue(a < b)
            self.assertTrue(a <= b)

            a = _Numeric(2)
            b = _Numeric(1)
            self.assertTrue(a > b)
            self.assertTrue(a >= b)

            a = _Numeric(1)
            b = _Numeric(1)
            self.assertTrue(a == b)
            self.assertTrue(a >= b)
            self.assertTrue(b <= a)

            a = _Numeric(1)
            b = _Alpha('foo')
            self.assertFalse(a == b)

# Generated at 2022-06-23 14:54:14.529929
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    print(0)

    assert _Alpha('alpha') <= _Alpha('alpha'), '_Alpha(\'alpha\') <= _Alpha(\'alpha\') failed'
    assert _Alpha('alpha') <= _Alpha('beta'), '_Alpha(\'alpha\') <= _Alpha(\'beta\') failed'
    assert _Alpha('alpha') <= _Alpha('gamma'), '_Alpha(\'alpha\') <= _Alpha(\'gamma\') failed'
    assert not _Alpha('beta') <= _Alpha('alpha'), '_Alpha(\'beta\') <= _Alpha(\'alpha\') failed'
    assert _Alpha('beta') <= _Alpha('beta'), '_Alpha(\'beta\') <= _Alpha(\'beta\') failed'

# Generated at 2022-06-23 14:54:16.964424
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(2)



# Generated at 2022-06-23 14:54:25.748763
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    my_numeric = _Numeric(1)
    smaller = _Numeric(0)
    larger = _Numeric(2)
    similar = _Numeric(1)

    # Check: my_numeric is the same as similar
    assert my_numeric == similar

    # Check: smaller < my_numeric
    assert smaller < my_numeric

    # Check: my_numeric < larger
    assert my_numeric < larger

    # Check: my_numeric >= similar
    assert my_numeric >= similar

    # Check: my_numeric >= smaller
    assert my_numeric >= smaller

    # Check: smaller <= my_numeric
    assert smaller <= my_numeric

    # Check: larger <= my_numeric
    assert not larger <= my_numeric


# Generated at 2022-06-23 14:54:38.285567
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-23 14:54:48.689348
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test simple version
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert v1 == SemanticVersion('1.2.3')

    # Test version with prerelease and buildmetadata
    v2 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre.0+foo.bar'))
    assert v2 == SemanticVersion('1.2.3-pre.0+foo.bar')

    # Test non-integer loose versions
    try:
        v3 = SemanticVersion.from_loose_version(LooseVersion('1.2a.3.0'))
        assert False, "should have raised a ValueError"
    except ValueError:
        pass

    # Test with a non-LooseVersion input

# Generated at 2022-06-23 14:54:55.477358
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('alpha') == _Alpha('alpha')
    assert 'alpha' == _Alpha('alpha')
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('alpha') != _Alpha('beta')
    assert _Alpha('alpha') != _Numeric('alpha')
    assert _Alpha('alpha') == _Numeric(1)
    # Test __lt__
    assert _Alpha('alpha') < 'beta'
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') < _Numeric(1)
    assert _Alpha('alpha') <= _Alpha('alpha')
    assert _Alpha('alpha') <= 'beta'
    # Test __gt__
    assert _Alpha('alpha') > _Alpha('beta')
    assert _Alpha('alpha') > _N

# Generated at 2022-06-23 14:54:57.268630
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    t = _Alpha("test")
    assert t.__repr__() == "'test'"


# Generated at 2022-06-23 14:54:59.172095
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.1.0') == '1.1.0'


# Generated at 2022-06-23 14:55:08.907159
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.distro import RedHatDistro
    from ansible.module_utils.six import unichr as _unichr
    from ansible.module_utils.six import binary_type, text_type


# Generated at 2022-06-23 14:55:13.528255
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('1.0.1')
    c = SemanticVersion('1.0.0_pre')
    assert a != b
    assert b != c
    assert a != c


# Generated at 2022-06-23 14:55:21.879555
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha("alpha")
    b = _Alpha("beta")
    c = _Alpha("gamma")
    d = _Alpha("delta")
    e = _Alpha("delta")
    f = _Alpha("gamma")
    g = _Alpha("beta")
    h = _Alpha("alpha")

    assert a < b
    assert a < c
    assert a < d
    assert a < e
    assert a < f
    assert a < g
    assert a < h
    assert b < c
    assert b < d
    assert b < e
    assert b < f
    assert b < g
    assert b < h
    assert c < d
    assert c < e
    assert c < f
    assert c < g
    assert c < h
    assert d < e
    assert d < f
    assert d

# Generated at 2022-06-23 14:55:26.736851
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(0) > _Numeric(-1)
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(0) > _Alpha('-1')
    assert _Numeric(1) > _Alpha('0')
    assert not _Numeric(0) > _Numeric(0)
    assert not _Numeric(1) > _Numeric(1)
    assert not _Numeric(0) > _Numeric(1)
    assert not _Numeric(1) > _Numeric(2)
    assert not _Numeric(0) > _Alpha('0')
    assert not _Numeric(1) > _Alpha('1')
    assert not _Numeric(0) > _Alpha('1')
    assert not _Numeric(1) > _Alpha('2')


# Unit test

# Generated at 2022-06-23 14:55:32.077908
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    semver1 = SemanticVersion('1.0.0')
    semver2 = SemanticVersion('1.0.0')
    semver3 = SemanticVersion('1.0.0-foo')
    semver4 = SemanticVersion('1.0.0-foo')
    assert semver1 == semver2
    assert semver3 == semver4
    assert not semver1 == semver3
    assert not semver1 == 1


# Generated at 2022-06-23 14:55:38.412977
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    from nose.tools import assert_equal, assert_true, assert_false

    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0+foo')
    v3 = SemanticVersion('1.0.0-foo')
    v4 = SemanticVersion('2.0.0')

    assert_true(v1 != v2)
    assert_true(v1 != v3)
    assert_true(v1 != v4)
    assert_true(v2 != v3)
    assert_true(v2 != v4)
    assert_true(v3 != v4)


# Generated at 2022-06-23 14:55:45.962478
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('0') <= _Numeric('0')
    assert _Numeric('0') <= _Numeric('1')
    assert _Numeric('0') <= _Numeric('01')
    assert _Numeric('1') <= _Numeric('1')
    assert _Numeric('1') <= _Numeric('2')
    assert _Numeric('1') <= _Numeric('02')
    #
    assert _Numeric('0') <= _Alpha('0')
    assert _Numeric('0') <= _Alpha('1')
    assert _Numeric('0') <= _Alpha('01')
    assert _Numeric('1') <= _Alpha('1')
    assert _Numeric('1') <= _Alpha('2')
    assert _Numeric('1') <= _Alpha('02')
    #

# Generated at 2022-06-23 14:55:49.999293
# Unit test for constructor of class _Alpha
def test__Alpha():
    alpha = _Alpha('alpha')
    assert hasattr(alpha, "specifier")
    assert alpha.specifier == 'alpha'
    assert isinstance(alpha, _Alpha)


# Generated at 2022-06-23 14:55:52.104011
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.1')) == "SemanticVersion('0.0.1')"


# Generated at 2022-06-23 14:55:58.608890
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    a = _Numeric('3')
    b = _Numeric('3')
    c = _Numeric('4')

    assert a == a
    assert a == '3'
    assert '3' == a
    assert a == 3
    assert 3 == a
    assert b == a
    assert not (a == c)
    assert not (a == 'ab')
    assert not ('ab' == a)


# Generated at 2022-06-23 14:56:02.094134
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    val1 = _Numeric(1)
    val2 = _Numeric(2)
    val3 = _Numeric(1)
    assert val1.__ne__(val2) is True
    assert val1.__ne__(val3) is False


# Generated at 2022-06-23 14:56:13.636968
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    b = _Alpha('b')

    assert _Alpha('1') < _Alpha('a')
    assert 1 < _Alpha('a')
    assert _Alpha('1') < 'a'
    assert 1 < 'a'

    assert a < b
    assert a < 'b'
    assert a < _Alpha('b')
    assert 'a' < _Alpha('b')
    assert 'a' < b

    assert a <= b
    assert a <= 'b'
    assert a <= _Alpha('b')
    assert 'a' <= _Alpha('b')
    assert 'a' <= b

    assert 'a' > _Alpha('1')
    assert b > _Alpha('1')
    assert b > 1

    assert 'a' >= _Alpha('1')
    assert b >= _Alpha('1')

# Generated at 2022-06-23 14:56:18.300637
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a1') == 'a1'
    assert _Alpha('a1') == _Alpha('a1')
    assert not _Alpha('a1') == 'b1'
    assert not _Alpha('a1') == _Alpha('b1')
    assert not _Alpha('a1') == 'b1'
    assert not _Alpha('a1') == '1b'
    assert not _Alpha('a1') == '1'
    assert not _Alpha('1') == _Alpha('a1')
    assert not _Alpha('a1') == 1
    assert not _Alpha('a1') == 1.1
    assert not _Alpha('a1') == True


# Generated at 2022-06-23 14:56:29.959938
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion("1.8.0") > SemanticVersion("1.7.9")
    assert SemanticVersion("1.8.0") < SemanticVersion("1.10.0")
    assert SemanticVersion("1.8.0") < SemanticVersion("1.8.0-beta.0")
    assert SemanticVersion("1.8.0") < SemanticVersion("1.8.0-beta.1")
    assert SemanticVersion("1.8.0") < SemanticVersion("1.8.0-beta.1+build.1")
    assert SemanticVersion("1.8.0-beta.1") > SemanticVersion("1.8.0-alpha.1")
    assert SemanticVersion("1.8.0-beta.1") < SemanticVersion("1.8.0-beta.2")

# Generated at 2022-06-23 14:56:39.357536
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    '''
    Test class constructor
    '''
    assert SemanticVersion('1.2.3')
    assert SemanticVersion('0.2.3')
    assert SemanticVersion('1.0.3')
    assert SemanticVersion('1.2.0')
    assert SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3-alpha.beta')
    assert SemanticVersion('1.2.3-1.2.3')
    assert SemanticVersion('1.2.3-1.2.3-alpha.beta')
    assert SemanticVersion('1.2.3-1.2.3+20130313144700')
    assert SemanticVersion('1.2.3+20130313144700')

# Generated at 2022-06-23 14:56:49.922634
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    global _Alpha
    assert _Alpha('1').__le__(1)
    assert _Alpha('2').__le__('2')
    assert _Alpha('1').__le__(_Alpha('1'))
    assert _Alpha('1').__le__(0)
    assert _Alpha('0').__le__(0)
    assert _Alpha('1').__le__('0')
    assert not _Alpha('1').__le__('2')
    assert not _Alpha('2').__le__('1')
    assert not _Alpha('2').__le__('2x')
    # Unit test for method __ge__ of class _Alpha
    def test__Alpha___ge__():
        global _Alpha
        assert _Alpha('1').__ge__(1)
        assert _Alpha('2').__ge__('2')
        assert _Alpha

# Generated at 2022-06-23 14:57:01.148611
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.0')) == SemanticVersion('0.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1')) == SemanticVersion('0.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')

    assert SemanticVersion.from_loose_version(LooseVersion('0.1.0-alpha')) == SemanticVersion('0.1.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1-alpha')) == SemanticVersion('0.1.0-alpha')

# Generated at 2022-06-23 14:57:07.197979
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # test true cases
    assert SemanticVersion('0.0.0') == '0.0.0'
    assert SemanticVersion('0.0.1') == '0.0.1'
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert SemanticVersion('1.2.0') == '1.2.0'
    assert SemanticVersion('1.2.3') == '1.2.3'
    assert SemanticVersion('1.2.3.4') == '1.2.3.4'
    assert SemanticVersion('1.2.3-1') == '1.2.3-1'
    assert SemanticVersion('1.2.3-1+1') == '1.2.3-1+1'

# Generated at 2022-06-23 14:57:18.306100
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert (_Alpha('a') >= _Alpha('a'))
    assert (_Alpha('b') >= _Alpha('a'))
    assert (_Alpha('1') >= _Alpha('a'))
    assert (_Alpha('b') >= _Alpha('1')), 'b is not greater than or equal to 1'
    assert not (_Alpha('a') >= _Alpha('b')), 'a is not less than or equal to b'
    assert not (_Alpha('a') >= 'b'), 'a is not less than or equal to b'
    assert (_Alpha('a') >= 'a')
    assert (_Alpha('b') >= 'a')
    assert (_Alpha('1') >= 'a')
    assert not ('b' >= _Alpha('1')), 'b is not greater than or equal to 1'
    assert ('b' >= _Alpha('b'))

# Generated at 2022-06-23 14:57:27.889510
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('1') > _Alpha('0') and _Alpha('1') > _Numeric('0') and \
        _Alpha('1') > '0' and _Alpha('a') > 'A' and _Alpha('A') > _Numeric('0')
    assert not _Alpha('0') > _Alpha('1') and not _Alpha('0') > _Numeric('1') and \
        not _Alpha('0') > '1' and not _Alpha('A') > 'a' and not _Alpha('a') > 'A' and \
        not _Alpha('0') > _Numeric('1')
    assert _Alpha('0') == _Alpha('0') and _Alpha('0') == _Numeric('0') and \
        _Alpha('0') == '0'


# Generated at 2022-06-23 14:57:35.006203
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-23 14:57:41.612368
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('foo') <= _Alpha('foo')
    assert _Alpha('foo') <= _Alpha('foobar')
    assert _Alpha('foo') <= 'foo'
    assert not _Alpha('foobar') <= _Alpha('foo')
    assert _Alpha('') <= _Alpha('')
    assert _Alpha('') <= 'foo'
    assert not _Alpha('foo') <= 'bar'
    assert _Alpha('foo') <= _Numeric(1)
    assert not _Alpha('foo') <= _Numeric(0)
    assert not _Numeric(1) <= _Alpha('foo')


# Generated at 2022-06-23 14:57:50.116609
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:57:56.039699
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha("a") < _Alpha("z")
    assert _Alpha("z") < _Alpha("aa")
    assert _Alpha("A") < _Alpha("Z")
    assert _Alpha("Z") < _Alpha("AA")
    assert _Alpha("a") < _Alpha("AA")
    assert _Alpha("A") < _Alpha("AA")
    assert not _Alpha("a") < _Alpha("a")
    assert not _Alpha("Z") < _Alpha("Z")
    assert _Alpha("a") < "b"
    assert _Alpha("a") < 1


# Generated at 2022-06-23 14:57:57.067807
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    _Numeric(1).__ne__(2)

# Generated at 2022-06-23 14:57:59.641943
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(2) != _Numeric(1)


# Generated at 2022-06-23 14:58:01.698205
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.1')) == "SemanticVersion('0.0.1')"



# Generated at 2022-06-23 14:58:05.630751
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha('1') > _Alpha('1')
    assert not _Alpha('1') > _Alpha('2')
    assert _Alpha('1') > _Alpha('0')
    assert not _Alpha('1') > _Alpha('a')
    assert not _Alpha('a') > _Alpha('1')
    assert _Alpha('a') > _Alpha('0')



# Generated at 2022-06-23 14:58:09.253624
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    result = None

# Generated at 2022-06-23 14:58:19.152479
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    # _Numeric(3) > _Numeric(2)
    assert _Numeric(3) > _Numeric(2) == True
    # _Numeric(2) > _Numeric(3)
    assert _Numeric(2) > _Numeric(3) == False
    # _Numeric(2) >= _Numeric(3)
    assert _Numeric(2) >= _Numeric(3) == False
    # _Numeric(3) >= _Numeric(2)
    assert _Numeric(3) >= _Numeric(2) == True
    # _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= _Numeric(1) == True


# Generated at 2022-06-23 14:58:28.443911
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-23 14:58:34.183468
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= 'A'
    assert _Alpha('aB') >= 'a'
    assert not (_Alpha('a') >= _Alpha('b'))
    assert not (_Alpha('a') >= _Alpha('aB'))
    assert not (_Alpha('a') >= 'b')
    assert not (_Alpha('a') >= 'bC')

