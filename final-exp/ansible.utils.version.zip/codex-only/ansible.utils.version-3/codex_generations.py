

# Generated at 2022-06-23 14:48:38.177622
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('0.1.1') > SemanticVersion('0.1.0')
    assert SemanticVersion('1.1.0') > SemanticVersion('1.0.9')
    assert SemanticVersion('1.1.1') > SemanticVersion('1.1.0')
    assert SemanticVersion('1.10.1') > SemanticVersion('1.2.0')
    assert SemanticVersion('1.10.1') > SemanticVersion('1.9.1')
    assert SemanticVersion('1.1.1') > SemanticVersion('1.1.0')
    # Test that pre-releases are less than their associated release
    # https://semver.org/#spec-item-9
    assert SemanticVersion('1.0.0-beta') < SemanticVersion('1.0.0')

# Generated at 2022-06-23 14:48:47.141199
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha_a = _Alpha('a')
    alpha_b = _Alpha('b')
    alpha_c = _Alpha('c')
    numeric_4 = _Numeric('4')
    numeric_5 = _Numeric('5')
    numeric_6 = _Numeric('6')

    assert not (alpha_a <= alpha_c)
    assert alpha_a <= alpha_b
    assert alpha_a <= alpha_a

    assert not (numeric_4 <= alpha_a)
    assert not (numeric_5 <= alpha_a)
    assert not (numeric_6 <= alpha_a)


# Generated at 2022-06-23 14:48:54.925195
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > '0.0.0'
    assert SemanticVersion('1.0.1') > '1.0.0'
    assert not SemanticVersion('1.0.1') > '1.0.1'
    assert not SemanticVersion('1.0.0') > '1.0.1'
    assert not SemanticVersion('1.1.0') > '1.0.1'
    assert SemanticVersion('1.0.0-alpha') > '1.0.0'
    assert not SemanticVersion('1.0.0-alpha') > '1.0.0-alpha'
    assert not SemanticVersion('1.0.0-alpha') > '1.0.0-beta'
    assert SemanticVersion('1.0.0-alpha.1')

# Generated at 2022-06-23 14:48:59.655307
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    expected = {
        'vstring': '1.0.0',
        'major': 1,
        'minor': 0,
        'patch': 0,
        'prerelease': tuple(),
        'buildmetadata': tuple()
    }

    v = SemanticVersion('1.0.0')
    assert v.__dict__ == expected



# Generated at 2022-06-23 14:49:08.642756
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    alphanum1 = _Alpha('alpha')
    alphanum2 = _Alpha('alpha')

    # Test successful equality
    assert alphanum1 == alphanum2

    # Test failed equality
    assert not (alphanum1 == 'alpha')
    assert not (alphanum1 == _Alpha('beta'))
    assert not (alphanum1 == _Numeric('alpha'))
    assert not (alphanum1 == _Numeric('beta'))

    # Test equality with other types
    assert not (alphanum1 == None)
    assert not (alphanum1 == 1)
    assert not (alphanum1 == 1.0)
    assert not (alphanum1 == 1+1j)
    assert not (alphanum1 == [1, 2, 3])



# Generated at 2022-06-23 14:49:18.885809
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    """Unit test for method __eq__ of class SemanticVersion"""
    # Test for different major
    assert SemanticVersion('1.2.3') != SemanticVersion('2.2.3')

    # Test for different minor
    assert SemanticVersion('1.2.3') != SemanticVersion('1.3.3')

    # Test for different patch
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.4')

    # Test for prerelease and build metadata
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.3+build.1')

# Generated at 2022-06-23 14:49:25.018498
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # test string comparison
    a = _Alpha('b')
    b = _Alpha('a')
    assert a > b

    # test string comparison is not case sensitive
    a = _Alpha('A')
    b = _Alpha('a')
    assert a == b

    # test integer comparison
    a = _Alpha(100)
    b = _Alpha(10)
    assert a > b

    # test integer comparison with string
    a = _Alpha(100)
    b = _Alpha('a')
    assert a > b

    # test string comparison with integer
    a = _Alpha('a')
    b = _Alpha(10)
    assert a > b


# Generated at 2022-06-23 14:49:34.580550
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1').specifier == 1
    assert _Numeric(1).specifier == 1
    assert _Numeric('001').specifier == 1
    assert _Numeric('0001').specifier == 1

    assert _Numeric('2') > _Numeric('1')
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(2) > _Numeric('1')
    assert _Numeric('2') > _Numeric(1)

    assert _Numeric('2') >= _Numeric('1')
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(2) >= _Numeric('1')
    assert _Numeric('2') >= _Numeric(1)

    assert _Numeric('1') < _Numeric('2')
    assert _

# Generated at 2022-06-23 14:49:36.719831
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha('foo').__repr__() == "'foo'"
    assert _Alpha('foo.bar').__repr__() == "'foo.bar'"


# Generated at 2022-06-23 14:49:38.972996
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('a')
    d = 'a'

    assert a == c
    assert b == 'b'
    assert a == d



# Generated at 2022-06-23 14:49:48.942219
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    SemanticVersion('1.0.0')
    SemanticVersion('0.0.4')
    SemanticVersion('4.11.6')
    SemanticVersion('21.1.0')
    SemanticVersion('1.0.0-alpha')
    SemanticVersion('1.0.0-alpha.1')
    SemanticVersion('1.0.0-0.3.7')
    SemanticVersion('1.0.0-x.7.z.92')
    SemanticVersion('1.0.0-alpha+001')
    SemanticVersion('1.0.0+20130313144700')
    SemanticVersion('1.0.0-beta+exp.sha.5114f85')
    SemanticVersion('1.0.0-alpha.beta')

# Generated at 2022-06-23 14:49:50.493821
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert _Numeric(7).__repr__() == "7"


# Generated at 2022-06-23 14:49:56.417690
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    pass
    # assert _Numeric("0.9").__gt__(_Numeric("0.11")) == False
    # assert _Numeric("0.9").__gt__(_Numeric("0.11")) == False
    # assert _Numeric("0.9").__gt__("0.11") == False
    # assert _Numeric("0.9").__gt__("0.11") == False


# Generated at 2022-06-23 14:50:05.918696
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    fake_semver = tuple(
        '0.1.%s-alpha' % i for i in range(
            1,
            3
        )
    )

    # The default < operator separates number vs strings
    # such that:
    #   '1.0.0-foo' > '1.0.0-123'
    # This causes a problem for SemanticVersion because
    # the order should be reversed.
    # By defining our own _Alpha and _Numeric classes we can
    # force the desired outcome in python.

    # For reference, in Python 3.3, using the default operator works
    # as expected

    # These are more like unit tests, but this is the easiest place to
    # put them

    assert _Alpha('a.a') <= _Alpha('b.b')
    assert _Alpha('a.a')

# Generated at 2022-06-23 14:50:14.057402
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    simple_str_ver = "1.2.3"
    ver = SemanticVersion(simple_str_ver)
    assert ver.vstring == simple_str_ver
    assert ver.major == 1
    assert ver.minor == 2
    assert ver.patch == 3
    assert ver.prerelease == ()
    assert ver.buildmetadata == ()

    simple_str_ver_no_metadata = "1.2.3"
    ver = SemanticVersion(simple_str_ver_no_metadata)
    assert ver.vstring == simple_str_ver_no_metadata
    assert ver.major == 1
    assert ver.minor == 2
    assert ver.patch == 3
    assert ver.prerelease == ()
    assert ver.buildmetadata == ()


# Generated at 2022-06-23 14:50:18.487365
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    assert not n1.__eq__(n2)
    assert not n1.__eq__(2)
    assert n1.__eq__(1)
    assert n1.__eq__(_Numeric(1))


# Generated at 2022-06-23 14:50:24.339296
# Unit test for constructor of class _Alpha
def test__Alpha():
    num = 0
    numStr = '0'
    assert(_Alpha(num) == _Alpha(numStr))
    assert(_Alpha(numStr) == _Alpha(num))

    num = 1
    numStr = '1'
    assert(_Alpha(num) == _Alpha(numStr))
    assert(_Alpha(numStr) == _Alpha(num))

    num = 10
    numStr = '10'
    assert(_Alpha(num) == _Alpha(numStr))
    assert(_Alpha(numStr) == _Alpha(num))


# Generated at 2022-06-23 14:50:34.417261
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion().__repr__() == 'SemanticVersion(None)'
    assert SemanticVersion('1.2.3').__repr__() == 'SemanticVersion(\'1.2.3\')'
    assert SemanticVersion('1.2.3-rc.1').__repr__() == 'SemanticVersion(\'1.2.3-rc.1\')'
    assert SemanticVersion('1.2.3+build.1').__repr__() == 'SemanticVersion(\'1.2.3+build.1\')'
    assert SemanticVersion('1.2.3-rc.1+build.1').__repr__() == 'SemanticVersion(\'1.2.3-rc.1+build.1\')'


# Generated at 2022-06-23 14:50:42.701366
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    def test_init(version):
        assert isinstance(version, SemanticVersion)
        assert isinstance(version.vstring, text_type)
        assert isinstance(version.major, int)
        assert isinstance(version.minor, int)
        assert isinstance(version.patch, int)
        assert isinstance(version.prerelease, tuple)
        assert isinstance(version.buildmetadata, tuple)

    # Test that a string can be passed in to the constructor
    test_init(SemanticVersion('1.2.3'))

    # Test that a LooseVersion can be passed in to the constructor
    test_init(SemanticVersion.from_loose_version(LooseVersion('1.2.3')))

    # Test that the constructor parses the version properly

# Generated at 2022-06-23 14:50:50.936359
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    assert a.specifier == 'a'
    assert 0 < a

    b = _Alpha('b')
    assert a < b
    assert a <= b
    assert b > a
    assert b >= a

    c = _Alpha('c')
    assert b < c
    assert b <= c
    assert c > b
    assert c >= b

    d = _Alpha('b')
    assert b == d
    assert b <= d
    assert b >= d
    assert d == b
    assert d <= b
    assert d >= b

    e = _Alpha('0')
    assert e > a
    assert e > b
    assert e > c
    assert a < e
    assert b < e
    assert c < e

    assert a <= e
    assert a < e

    assert b <= e

# Generated at 2022-06-23 14:50:57.267950
# Unit test for method __ge__ of class _Alpha

# Generated at 2022-06-23 14:51:01.246524
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    vstring = "1.0.0"
    version = SemanticVersion(vstring)
    returned_value = version.__ne__("2.0.0")
    assert returned_value
    assert type(returned_value) == bool



# Generated at 2022-06-23 14:51:11.234485
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a = _Alpha(0)
    b = _Alpha(0)
    c = _Alpha('1')
    d = _Alpha('1')
    e = _Alpha('2')
    f = _Alpha('2')
    g = _Alpha('a')
    h = _Alpha('a')
    i = _Alpha('b')
    j = _Alpha('b')
    k = _Alpha(1)
    assert a < c
    assert c < g
    assert g < k
    assert a < g
    assert a < k
    assert c < k
    assert not a < b
    assert not c < d
    assert not g < h
    assert not a < a
    assert not c < c
    assert not g < g
    assert not k < k


# Generated at 2022-06-23 14:51:18.447219
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    s = SemanticVersion.from_loose_version(LooseVersion('0.2.2'))
    assert s.core == (0, 2, 2)
    assert s.prerelease == ()
    assert s.buildmetadata == ()

    s = SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5'))
    assert s.core == (1, 2, 3)
    assert s.prerelease == (4, 5)
    assert s.buildmetadata == ()

    s = SemanticVersion.from_loose_version(LooseVersion('1.2.3+1.2.3'))
    assert s.core == (1, 2, 3)
    assert s.prerelease == ()
    assert s.buildmetadata == (1, 2, 3)

    s = Semantic

# Generated at 2022-06-23 14:51:27.312933
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    number1 = _Numeric(10)
    number2 = _Numeric(10)
    number3 = _Numeric(0)
    number4 = _Numeric(1)
    assert number1 == number2, "Should return True"
    assert number1 == 10, "Should return True"
    assert number1 != number3, "Should return True"
    assert number1 != number4, "Should return True"
    assert number1 != 2, "Should return True"
    assert number1 != "10", "Should return True"


# Generated at 2022-06-23 14:51:33.717700
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('A') == 'A'
    assert _Alpha('A').specifier == 'A'
    with_digit = _Alpha('A1')
    assert with_digit == 'A1'
    assert with_digit.specifier == 'A1'
    assert with_digit != 'A'

    assert repr(_Alpha('a')) == repr('a')
    assert repr(_Alpha('A')) == repr('A')
    assert repr(_Alpha('A1')) == repr('A1')


# Generated at 2022-06-23 14:51:37.124779
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    semver_1 = SemanticVersion("3.3.3")
    semver_2 = SemanticVersion("3.3.3")
    semver_3 = SemanticVersion("3.3.4")

    assert semver_1 == semver_2
    assert not semver_1 == semver_3


# Generated at 2022-06-23 14:51:38.522700
# Unit test for constructor of class _Alpha
def test__Alpha():
    import pytest
    a = _Alpha('a')
    assert a.specifier == 'a'


# Generated at 2022-06-23 14:51:39.429760
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    pass


# Generated at 2022-06-23 14:51:42.348045
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('alpha') == _Alpha('alpha')
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('alpha') != _Alpha('beta')
    assert 'alpha' > 'beta'



# Generated at 2022-06-23 14:51:53.202885
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion("1.0.0") <= SemanticVersion("1.0.0")
    # first digit major
    assert SemanticVersion("0.0.7") <= SemanticVersion("1.0.1")
    assert SemanticVersion("0.0.7") <= SemanticVersion("0.0.8")
    assert SemanticVersion("0.0.7") <= SemanticVersion("0.1.5")
    assert SemanticVersion("1.0.7") <= SemanticVersion("1.0.8")
    assert SemanticVersion("1.0.7") <= SemanticVersion("1.0.8-alpha")
    assert SemanticVersion("1.0.7") <= SemanticVersion("1.0.8+debian")

# Generated at 2022-06-23 14:52:03.040444
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    n3 = _Numeric(3)
    n1_1 = _Numeric(1)
    n2_2 = _Numeric(2)
    n3_3 = _Numeric(3)

    # check 2 > 1
    assert n2 > n1
    # check 1 < 2
    assert n1 < n2
    # check 3 > 2
    assert n3 > n2
    # check 3 > 1
    assert n3 > n1
    # check 1 < 3
    assert n1 < n3
    # check 1 <= 2
    assert n1 <= n2
    # check 2 <= 3
    assert n2 <= n3
    # check 1 <= 3
    assert n1 <= n3
    # check 1 <= 1


# Generated at 2022-06-23 14:52:11.090237
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert not _Numeric('0') > _Numeric('1')

    assert not _Numeric('1') > _Alpha('0')
    assert not _Numeric('1') > _Alpha('1')
    assert not _Numeric('1') > _Alpha('2')

    assert _Numeric('1') > 0
    assert not _Numeric('0') > 0
    assert not _Numeric('0') > 1



# Generated at 2022-06-23 14:52:22.018123
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # first test
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('2.0.0')
    assert a < b

    # second test
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('1.1.0')
    assert a < b

    # third test
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('1.0.1')
    assert a < b

    # fourth test
    # comparing release with prerelease
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('1.0.1-alpha')
    assert a < b

    # fifth test
    # comparing prerelease with prerelease
    # where prerelease is not equal

# Generated at 2022-06-23 14:52:25.944786
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(0) == _Numeric(0)
    assert _Numeric(0) == 0
    assert _Numeric(1) != _Numeric(0)
    assert _Numeric(0) != _Numeric(1)
    assert _Numeric(0) != 1
    assert _Numeric(1) != 0


# Generated at 2022-06-23 14:52:33.837152
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # test assert for equal objects
    assert _Alpha("4") >= _Alpha("4")

    # test assert for equal objects
    assert _Alpha("4") >= "4"

    # test assert for equal objects
    assert "4" <= _Alpha("4")

    # test assert for greater objects
    assert _Alpha("5") >= _Alpha("4")

    # test assert for greater objects
    assert _Alpha("5") >= "4"

    # test assert for greater object
    assert _Alpha("5") >= _Alpha("5a")

    # test assert for lower objects
    assert _Alpha("4") <= _Alpha("5")

    # test assert for lower objects
    assert _Alpha("4") <= "5"

    # test assert for lower object
    assert _Alpha("5a") <= _Alpha("5")

    # test assert for different types

# Generated at 2022-06-23 14:52:42.601348
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion("1.0.0") > SemanticVersion("0.0.9")
    assert SemanticVersion("1.0.0") > SemanticVersion("1.0.0")
    assert SemanticVersion("1.0.0") > SemanticVersion("1.0.0-rc1")
    assert SemanticVersion("1.0.0-rc1") > SemanticVersion("1.0.0-alpha.1")
    assert SemanticVersion("1.0.0-alpha.1") > SemanticVersion("1.0.0-alpha")


# Generated at 2022-06-23 14:52:46.458652
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    numeric_1 = _Numeric(1)

    numeric_2 = _Numeric(2)
    numeric_3 = _Numeric(1)

    assert numeric_1 == numeric_3
    assert numeric_1 != numeric_2
    assert numeric_1 != 1
    assert numeric_1 != '1'


# Generated at 2022-06-23 14:52:49.668640
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert not _Numeric(2) < _Numeric(2)
    assert not _Numeric(2) < _Numeric(1)


# Generated at 2022-06-23 14:52:57.779106
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(0) < _Numeric(1), '0 is less than 1'
    assert _Numeric(1) < _Numeric(2), '1 is less than 2'
    assert _Numeric(2) < _Numeric(3), '2 is less than 3'
    assert not _Numeric(0) < _Numeric(0), '0 is not less than 0'
    assert not _Numeric(1) < _Numeric(1), '1 is not less than 1'
    assert not _Numeric(2) < _Numeric(2), '2 is not less than 2'
    assert not _Numeric(0) < _Numeric(2), '0 is not less than 2'
    assert not _Numeric(2) < _Numeric(0), '2 is not less than 0'
    assert _Numeric

# Generated at 2022-06-23 14:53:07.532158
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Version 1.0.0
    v1_str = '1.0.0'
    v1 = SemanticVersion(v1_str)
    # Version 1.0.1
    v2_str = '1.0.1'
    v2 = SemanticVersion(v2_str)
    assert v1 < v2
    assert v2 > v1
    # Version 1.1.0
    v3_str = '1.1.0'
    v3 = SemanticVersion(v3_str)
    assert v1 < v3
    assert v3 > v1
    assert v2 < v3
    assert v3 > v2
    # Version 2.0.0
    v4_str = '2.0.0'
    v4 = SemanticVersion(v4_str)
    assert v

# Generated at 2022-06-23 14:53:11.378953
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha('a') > _Alpha('a'), "__gt__ for _Alpha('a') and _Alpha('a') failed"
    assert _Alpha('b') > _Alpha('a'), "__gt__ for _Alpha('b') and _Alpha('a') failed"
    assert not _Alpha('a') > _Alpha('b'), "__gt__ for _Alpha('a') and _Alpha('b') failed"


# Generated at 2022-06-23 14:53:14.378689
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(10)) == '10'
    assert repr(_Numeric(12.0)) == '12'
    assert repr(_Numeric('20')) == '20'
    assert repr(_Numeric('20.0')) == '20'


# Generated at 2022-06-23 14:53:18.253612
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    c = SemanticVersion('1.0.0')

    obj = c == '1.0.0'
    assert isinstance(obj, bool)
    assert obj

    obj = c == SemanticVersion('1.0.0')
    assert obj

    obj = c == SemanticVersion('1.0.1')
    assert not obj



# Generated at 2022-06-23 14:53:25.013369
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('5') == 5
    assert not _Numeric('5') == 6
    assert _Numeric('5') < 6
    assert _Numeric('5') <= 6
    assert _Numeric('5') < 7
    assert _Numeric('5') <= 7
    assert _Numeric('5') < 'alpha'
    assert _Numeric('5') <= 'alpha'
    assert _Numeric('5') < '6'
    assert _Numeric('5') <= '6'
    assert _Numeric('5') >= 5
    assert _Numeric('5') > 4
    assert _Numeric('5') >= 4
    assert _Numeric('5') > 3
    assert _Numeric('5') >= 3


# Generated at 2022-06-23 14:53:34.528443
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    test_cases = [
        {
            "input": "10",
            "expected_result": repr("10")
        },
        {
            "input": "abc",
            "expected_result": repr("abc")
        },
        {
            "input": "abc10",
            "expected_result": repr("abc10")
        },
        {
            "input": "10abc",
            "expected_result": repr("10abc")
        }
    ]
    for test_case in test_cases:
        result = _Alpha(test_case["input"]).__repr__()
        assert result == test_case["expected_result"], \
            "Expected test_case['expected_result']=`%s`, but got result=`%s`" % (test_case["expected_result"], result)

#

# Generated at 2022-06-23 14:53:39.989477
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # Test where arg is equal to self
    alpha = _Alpha('a')
    assert alpha.__ge__(alpha)

    # Test where arg is greater than self
    arg = _Alpha('b')
    assert not alpha.__ge__(arg)

    # Test where arg is less than self
    arg = _Alpha('a')
    assert alpha.__ge__(arg)


# Generated at 2022-06-23 14:53:42.170083
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion('v1.2.4+xyz')
    assert repr(version) == "SemanticVersion('v1.2.4+xyz')"


# Generated at 2022-06-23 14:53:47.725426
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(5) <= _Numeric(5)
    assert _Numeric(5) <= _Numeric(6)
    assert _Numeric(5) <= _Numeric(0)

    assert _Numeric(5) <= _Alpha('5')
    assert _Numeric(5) <= _Alpha('6')
    assert _Numeric(5) <= _Alpha('0')

    assert _Numeric(5) <= '5'
    assert _Numeric(5) <= '6'
    assert _Numeric(5) <= '0'

    assert _Numeric(5) <= 5
    assert _Numeric(5) <= 6
    assert _Numeric(5) <= 0


# Generated at 2022-06-23 14:53:48.787553
# Unit test for constructor of class _Alpha
def test__Alpha():
    _Alpha('a')


# Generated at 2022-06-23 14:53:50.700997
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    return _Numeric(1) != _Numeric(2) and _Numeric(1) != 2


# Generated at 2022-06-23 14:53:54.092598
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert not _Numeric(2) <= _Numeric(1)



# Generated at 2022-06-23 14:54:02.474475
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    from hypothesis import given
    from hypothesis import strategies as st
    import operator
    from ansible.module_utils.basic import AnsibleModule

    @given(st.integers(), st.integers())
    def _Numeric_object___ne___strategy(num1, num2):
        num1_obj = _Numeric(num1)
        num2_obj = _Numeric(num2)
        num1_ne_num2 = operator.ne(num1_obj, num2_obj)
        num1_ne_num2_str = operator.ne(num1_obj, num2_str)

# Generated at 2022-06-23 14:54:04.728770
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(0)) == '0'
    assert repr(_Numeric('0')) == '0'

# Generated at 2022-06-23 14:54:06.242841
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    foo = _Alpha('0')
    assert foo >= '0'


# Generated at 2022-06-23 14:54:10.026302
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1).__ne__(_Numeric(1)) == False
    assert _Numeric(1).__ne__(_Numeric(2)) == True


# Generated at 2022-06-23 14:54:11.327735
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == '1'


# Generated at 2022-06-23 14:54:20.595205
# Unit test for constructor of class _Alpha
def test__Alpha():
    # equal
    assert (_Alpha('alpha') == _Alpha('alpha'))
    assert (_Alpha('alpha') == 'alpha')
    assert ('alpha' == _Alpha('alpha'))

    # not equal
    assert (_Alpha('alpha') != _Alpha('beta'))
    assert (_Alpha('alpha') != 'beta')
    assert ('alpha' != _Alpha('beta'))

    # less than
    assert (_Alpha('alpha') < _Alpha('beta'))
    assert (_Alpha('alpha') < 'beta')
    assert ('alpha' < _Alpha('beta'))

    # less than or equal
    assert (_Alpha('alpha') <= _Alpha('beta'))
    assert (_Alpha('alpha') <= 'beta')
    assert (_Alpha('alpha') <= _Alpha('alpha'))
    assert (_Alpha('alpha') <= 'alpha')

# Generated at 2022-06-23 14:54:23.091213
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    x = _Numeric("0")
    assert x == "0"
    assert x == 0
    assert x != "1"
    assert x != 1


# Generated at 2022-06-23 14:54:26.560047
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') == 1
    assert 1 == _Numeric('1')
    assert not _Numeric('1') != 1
    assert not _Numeric('1') != _Numeric('1')
    assert not 1 != _Numeric('1')



# Generated at 2022-06-23 14:54:31.325717
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    global _Alpha
    assert _Alpha('1') > _Alpha('0')
    assert _Alpha('a') > _Alpha('1')
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('b') > _Alpha('A')



# Generated at 2022-06-23 14:54:35.077266
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha('pre')
    expected = repr(alpha.specifier)
    actual = repr(alpha)
    assert expected == actual, "test__Alpha__repr__(): Expected %r, got %r" % (expected, actual)


# Generated at 2022-06-23 14:54:38.273715
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    s = 'test'
    p = _Alpha(s)
    assert p.specifier == s
    assert repr(p) == repr(s)


# Generated at 2022-06-23 14:54:48.689536
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v = SemanticVersion("0.0.0")
    # v <= '0.0.0'
    assert v.__le__("0.0.0")

    # v <= '9.9.9'
    assert v.__le__("9.9.9")

    v = SemanticVersion("9.9.9")
    # v <= '9.9.9'
    assert v.__le__("9.9.9")

    # v <= '10.0.0'
    assert v.__le__("10.0.0")

    # v <= '10.0.0-alpha'
    assert v.__le__("10.0.0-alpha")

    # v <= '10.0.0-alpha+build'

# Generated at 2022-06-23 14:54:57.809828
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    s1 = SemanticVersion("1.3.3")
    s2 = SemanticVersion("1.3.3")
    assert not s1 < s2
    assert not s2 < s1
    assert s1 == s2

    s2 = SemanticVersion("1.4.0")
    assert s1 < s2
    assert not s1 == s2
    assert s2 > s1

    s2 = SemanticVersion("2.0.0")
    assert s1 < s2
    assert not s1 == s2
    assert s2 > s1

    s2 = SemanticVersion("0.0.0")
    assert not s1 < s2
    assert not s1 == s2
    assert s1 > s2

    s1 = SemanticVersion("1.3.0")
    s2 = SemanticVersion

# Generated at 2022-06-23 14:55:00.031755
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    sv1 = SemanticVersion("1.0.0")
    sv2 = SemanticVersion("1.0.0")
    assert (sv1 == sv2)


# Generated at 2022-06-23 14:55:02.016274
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha("a")) == repr("a")


# Generated at 2022-06-23 14:55:04.889749
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    SemanticVersion('0.1.2-3.4.5')
    SemanticVersion('0.1.2-3.4.5+6.7.8')
    SemanticVersion()


# Generated at 2022-06-23 14:55:12.088899
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.0.1-alpha.3+23.2') == SemanticVersion('1.0.1-alpha.3+23.2')
    assert SemanticVersion('1.0.1-alpha.3+23.2') != SemanticVersion('1.0.1-alpha.3+23.3')
    assert SemanticVersion('0.0.1-alpha.1+23.2') != SemanticVersion('1.0.1-alpha.3+23.3')
    assert SemanticVersion('1.0.1') > SemanticVersion('0.0.1-alpha.1+23.2')
    assert SemanticVersion('1.0.1-alpha.3+23.2') > SemanticVersion('0.0.1-alpha.1+23.2')


# Generated at 2022-06-23 14:55:14.478523
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    if SemanticVersion("1.0.0") >= SemanticVersion("1.0.0"):
        return True
    return False


# Generated at 2022-06-23 14:55:17.985873
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Alpha('1')
    d = _Alpha('2')
    assert not a > b
    assert b > c
    assert c > a
    assert d > c



# Generated at 2022-06-23 14:55:19.409502
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.0.0') != '1.0.0'


# Generated at 2022-06-23 14:55:25.734552
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    try:
        assert _Alpha("a") >= _Alpha("a")
        assert _Alpha("a") >= "a"
        assert "a" >= _Alpha("a")
        assert _Alpha("b") >= _Alpha("a")
        assert _Alpha("a") >= _Alpha("b") == False
    except:
        return False
    else:
        return True


# Generated at 2022-06-23 14:55:27.639728
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    result = SemanticVersion('1.2.3') == SemanticVersion('1.2.3')

    assert(result is True)


# Generated at 2022-06-23 14:55:35.239566
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1.4') > _Alpha('1.4')
    assert _Alpha('1.4') >= _Alpha('1.4')
    assert _Alpha('1.4') >= _Alpha('1.3')
    assert _Alpha('1.4') > _Alpha('1.3')
    assert _Alpha('1.4') >= _Numeric('1.4')
    assert _Alpha('1.4') > _Numeric('1.3')
    assert _Alpha('1.4') == '1.4'
    assert _Alpha('1.4') != '1.3'
    assert _Alpha('1.4') == 1.4
    assert _Alpha('1.4') != 1.3


# Generated at 2022-06-23 14:55:36.285459
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():

    assert _Alpha('ABC').__ne__('ABC') == False


# Generated at 2022-06-23 14:55:43.398589
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-23 14:55:54.331027
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.20.1')) == SemanticVersion('1.20.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.20.1')) == SemanticVersion('1.20.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.20.1.dev1')) == SemanticVersion('1.20.1-dev1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.20.1.dev1')) == SemanticVersion('1.20.1-dev1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.20.1.dev.1')) == SemanticVersion('1.20.1-dev.1')

# Generated at 2022-06-23 14:56:03.124577
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha(0) == _Alpha(0)
    assert _Alpha(0) == 0
    assert _Alpha('0') == _Alpha(0)
    assert _Alpha('0') == '0'
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha(1) != _Alpha(1.0)
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert _Alpha(1) > _Alpha('a')


# Generated at 2022-06-23 14:56:10.337367
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
  assert _Numeric(1) <= _Numeric(2)
  assert not _Numeric(2) <= _Numeric(1)
  assert _Numeric(1) <= _Numeric(1)
  assert _Numeric(1) <= 1
  assert not _Numeric(2) <= 1
  assert 1 <= _Numeric(2)
  assert not 1 <= _Numeric(1)
  assert 1 <= _Numeric(1)


# Generated at 2022-06-23 14:56:18.740596
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert SemanticVersion('1.0.0') != '1.0.1'
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') != SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0-prerelease.1') == '1.0.0-prerelease.1'
    assert SemanticVersion('1.0.0-prerelease.1') != '1.0.0'
    assert SemanticVersion('1.0.0-prerelease.1') == SemanticVersion('1.0.0-prerelease.1')

# Generated at 2022-06-23 14:56:20.251394
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('0') <= _Alpha('a')

# Generated at 2022-06-23 14:56:24.622699
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    x = _Alpha(specifier='a')
    y = _Alpha(specifier='a')
    z = _Alpha(specifier='b')
    assert x.__ne__(y) == False
    assert x.__ne__(z) == True


# Generated at 2022-06-23 14:56:31.523959
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > _Alpha('b')
    assert _Alpha('a') >= _Alpha('b')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') != _Alpha('b')


# Generated at 2022-06-23 14:56:40.476509
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.1')
    assert v1 <= v2
    v3 = SemanticVersion('1.0.0-alpha')
    assert v3 <= v1
    v4 = SemanticVersion('1.0.0-alpha.1')
    assert v4 <= v3
    v5 = SemanticVersion('1.0.0-alpha.beta')
    assert v5 <= v4
    v6 = SemanticVersion('1.0.0-beta')
    assert v6 <= v5
    v7 = SemanticVersion('1.0.0-beta.2')
    assert v7 <= v6
    v8 = SemanticVersion('1.0.0-beta.11')
    assert v8 <= v7
    v9

# Generated at 2022-06-23 14:56:44.957585
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    specifier = "1"
    # Verifying the maximum value of number
    # assertion is True because returning True
    assert (_Numeric(specifier).__ne__(2))
    # assertion is False because returning False
    assert not (_Numeric(specifier).__ne__(1))



# Generated at 2022-06-23 14:56:53.019049
# Unit test for method __gt__ of class SemanticVersion

# Generated at 2022-06-23 14:57:02.460701
# Unit test for constructor of class SemanticVersion

# Generated at 2022-06-23 14:57:08.115812
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # Unit test for method __ge__
    # of class _Alpha
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') >= _Alpha('b')
    assert not _Alpha('a') >= 'b'
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('b') >= 'a'
    assert not _Alpha('a') >= _Alpha('1')
    assert _Alpha('1') >= _Alpha('a')



# Generated at 2022-06-23 14:57:11.222979
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
  assert SemanticVersion('1.0.0') != '2.0.0'


# Generated at 2022-06-23 14:57:17.841078
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric("2") >= _Numeric("1")
    assert _Numeric("1") >= _Numeric("1")
    assert not _Numeric("1") >= _Numeric("2")
    assert _Numeric("1") >= "1"
    assert not _Numeric("1") >= "2"
    assert _Numeric("2") >= "1"
    assert _Numeric("1") >= "1"
    assert not _Numeric("1") >= "2"


# Generated at 2022-06-23 14:57:18.938321
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    pass


# Generated at 2022-06-23 14:57:25.972532
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    env = {}
    env['ansible_facts'] = {
        'distribution': 'debian',
        'distribution_version': '10',
    }
    tester = SemanticVersion('10')
    assert tester.__lt__('10.0.0') is True
    assert tester.__lt__('10.0.0') is True
    assert tester.__lt__('10') is True
    assert tester.__lt__('9.9.9') is False



# Generated at 2022-06-23 14:57:36.593021
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
	assert SemanticVersion('1.2.3-alpha') <= '1.2.3-alpha'
	assert SemanticVersion('1.2.3') <= '1.2.3'
	assert SemanticVersion('1.2.3+beta') <= '1.2.3'
	assert SemanticVersion('1.2.3') <= '1.2.3+beta'
	assert SemanticVersion('1.2.3') <= '1.2.3-alpha'
	assert not SemanticVersion('1.2.3-alpha') <= '1.2.3'
	assert SemanticVersion('1.2.3-beta') <= '1.2.3-alpha'
	assert not SemanticVersion('1.2.3-alpha') <= '1.2.3-beta'

# Generated at 2022-06-23 14:57:41.437270
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Numeric('a')
    assert not _Alpha('a') <= _Alpha('A')
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= _Numeric('1')
    assert not _Alpha('a') <= _Alpha('A')


# Generated at 2022-06-23 14:57:49.931592
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) == '1.2.3-4'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-beta4')) == '1.2.3-beta4'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4'))

# Generated at 2022-06-23 14:57:52.812977
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    try:
        assert SemanticVersion('1.0.0') > '0.0.0'
    except AssertionError as e:
        print('AssertionError: ' + str(e))
    

# Generated at 2022-06-23 14:58:00.292959
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('0') <= _Alpha('1')
    assert _Alpha('0') <= _Alpha('0')
    assert _Alpha('0') <= '1'
    assert _Alpha('0') <= '0'
    assert not _Alpha('1') <= _Alpha('0')
    assert not _Alpha('1') <= '0'
    assert not _Alpha('0') <= _Numeric(1)


# Generated at 2022-06-23 14:58:07.448757
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
  from ansible.module_utils.common.collections import ImmutableDict
  from ansible.module_utils.six import PY2

  assert SemanticVersion.from_loose_version(LooseVersion('1.10.0')) == SemanticVersion('1.10.0')

  if not PY2:
    assert SemanticVersion.from_loose_version(LooseVersion('1.10.0-alpha')) == SemanticVersion('1.10.0-alpha')

  assert SemanticVersion.from_loose_version(LooseVersion('1.10.1')) > SemanticVersion('1.10.0')

  if not PY2:
    assert SemanticVersion.from_loose_version(LooseVersion('1.10.0-alpha')) < SemanticVersion('1.10.0')

# Generated at 2022-06-23 14:58:13.563313
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    alphav = _Alpha('v')
    num1 = _Numeric('1')
    num2 = _Numeric('2')
    alphav.__ge__(num1)
    assert alphav.__ge__(num1) == False
    assert alphav.__ge__(num2) == False
    assert alphav.__ge__('v') == True
    assert alphav.__ge__('a') == True
    assert alphav.__ge__('z') == False

# Generated at 2022-06-23 14:58:23.469943
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > '0.9.0'
    assert not (SemanticVersion('1.0.0') > '1.0.0')
    assert not (SemanticVersion('1.0.0') > '1.0.1')
    assert SemanticVersion('1.0.0') > SemanticVersion('0.9.0')
    assert not (SemanticVersion('1.0.0') > SemanticVersion('1.0.0'))
    assert not (SemanticVersion('1.0.0') > SemanticVersion('1.0.1'))
    assert not (SemanticVersion('1.0.0') > LooseVersion('1.0.0'))

# Generated at 2022-06-23 14:58:28.809554
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric('1') > _Alpha('0')
    assert _Numeric('0') < _Numeric('1')
    assert _Numeric('0') < _Alpha('1')
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') == 1
    assert _Numeric('1') != _Numeric('2')
    assert _Numeric('1') != 2


# Generated at 2022-06-23 14:58:37.016046
# Unit test for constructor of class _Alpha
def test__Alpha():
    r = _Alpha('b')
    assert(r.specifier == 'b')
    assert(r == 'b')
    assert(r != 'a')
    assert(r < 'c')
    assert(r <= 'c')
    assert(r <= 'b')
    assert(r > 'a')
    assert(r >= 'a')
    assert(r >= 'b')
    assert(r == _Alpha('b'))
    assert(r != _Alpha('a'))
    assert(r < _Alpha('c'))
    assert(r <= _Alpha('c'))
    assert(r <= _Alpha('b'))
    assert(r > _Alpha('a'))
    assert(r >= _Alpha('a'))
    assert(r >= _Alpha('b'))
