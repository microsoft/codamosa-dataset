

# Generated at 2022-06-23 14:48:30.087414
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    assert v1 <= v2


# Generated at 2022-06-23 14:48:33.360542
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    pv = SemanticVersion('1.2.3')
    nv = SemanticVersion('2.0.0')
    assert pv < nv
    assert pv <= nv
    assert nv > pv
    assert nv >= pv


# Generated at 2022-06-23 14:48:43.540018
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.compat.version import LooseVersion

    loose_version_string = "1.0.0"
    loose_version_obj = LooseVersion(loose_version_string)
    semver_obj = SemanticVersion(loose_version_string)

    # test: compare method SemanticVersion.from_loose_version() against LooseVersion instance
    assert semver_obj == SemanticVersion.from_loose_version(loose_version_obj)

    # test: compare method SemanticVersion.from_loose_version() against string
    assert semver_obj == SemanticVersion.from_loose_version(loose_version_string)

    # test: test the method with a loose_version which has extra chars

# Generated at 2022-06-23 14:48:47.688803
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('foo') >= _Alpha('foo')
    assert _Alpha('foo') >= _Alpha('bar')
    assert _Alpha('foo') >= 'foo'
    assert not _Alpha('foo') >= 'bar'


# Generated at 2022-06-23 14:48:55.354983
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Alpha('1')
    assert _Numeric(1) < _Alpha('1')
    assert _Numeric('1') < _Alpha(1)
    assert _Numeric('1') < _Numeric(2)
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < _Numeric('10')

    try:
        _Numeric('1') < '1'
        assert False
    except ValueError:
        pass

    assert not _Numeric('1') < _Alpha('0')
    assert not _Numeric(1) < _Alpha('0')
    assert not _Numeric('1') < _Alpha(0)
    assert not _Numeric('1') < _Numeric(0)
    assert not _Numeric('1') < _N

# Generated at 2022-06-23 14:49:04.574952
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # valid inputs
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == \
           SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == \
           SemanticVersion('1.2.3')

    # valid inputs with metadata
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+metadata')) == \
           SemanticVersion('1.2.3+metadata')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-pr.1+metadata')) == \
           SemanticVersion('1.2.3-pr.1+metadata')

# Generated at 2022-06-23 14:49:09.550977
# Unit test for constructor of class _Numeric
def test__Numeric():
    num = _Numeric(1)
    assert isinstance(num, _Numeric)
    assert repr(num) == repr(1)
    assert num == 1
    assert not num == 2
    assert num != 2
    assert not num != 1
    assert num < 2
    assert num <= 2
    assert num <= 1
    assert not num < 1
    assert not num <= 0
    assert num > 0
    assert num >= 0
    assert num >= 1
    assert not num > 1
    assert not num >= 2


# Generated at 2022-06-23 14:49:11.332343
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion("1.0.0")) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-23 14:49:13.300727
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == '1.0.0'


# Generated at 2022-06-23 14:49:19.335383
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
  assert (_Alpha('foo') >= 'foo')
  assert _Alpha('foo' >= 'foo')
  assert (_Alpha('foo') >= _Alpha('foo'))
  assert (_Alpha('foo') >= _Numeric('1'))
  assert (_Alpha('foo') >= _Numeric(1))
  assert not (_Alpha('foo') >= _Alpha('bar'))
  assert not (_Alpha('foo') >= _Numeric('0'))
  assert not (_Alpha('foo') >= _Numeric(0))


# Generated at 2022-06-23 14:49:20.703845
# Unit test for constructor of class _Alpha
def test__Alpha():
    if _Alpha('alpha').specifier != 'alpha':
        raise AssertionError


# Generated at 2022-06-23 14:49:25.800808
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    vstring = '1.8.0-rc1+build.1848'
    semver = SemanticVersion(vstring)
    assert semver.major == 1
    assert semver.minor == 8
    assert semver.patch == 0
    assert semver.prerelease == ('rc', 1)
    assert semver.buildmetadata == ('build', 1848)



# Generated at 2022-06-23 14:49:32.720490
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    # init with string
    obj1 = _Alpha("test")
    obj2 = _Alpha("test")
    obj3 = _Alpha("test2")

    # compare to string
    assert not obj1.__ne__("test")
    assert obj1.__ne__("test2")

    # compare to self
    assert not obj1.__ne__(obj1)

    # compare to other obj
    assert not obj1.__ne__(obj2)
    assert obj1.__ne__(obj3)


# Generated at 2022-06-23 14:49:37.877603
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= _Alpha('b') == False
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= 'b' == False
    assert _Alpha('b') >= 'a'
    assert _Alpha('b') >= 0 == False
    assert _Alpha('b') >= 1 == False
    assert _Alpha('b') >= -1


# Generated at 2022-06-23 14:49:40.330173
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha('alpha')
    if repr(alpha) != "'alpha'":
        raise AssertionError('_Alpha.__repr__() failed')


# Generated at 2022-06-23 14:49:42.851909
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    new_obj = _Alpha(None)
    arg = None
    expected = NotImplemented
    actual = new_obj.__ne__(arg)
    assert expected == actual



# Generated at 2022-06-23 14:49:45.927022
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    for i in range(5):
        for j in range(5):
            assert _Numeric(i) >= _Numeric(j) == (i >= j)


# Generated at 2022-06-23 14:49:47.161903
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    pass



# Generated at 2022-06-23 14:49:50.737135
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > _Alpha('b')
    assert _Alpha('c') > _Alpha('b')
    assert _Alpha('a') >= _Alpha('a')


# Generated at 2022-06-23 14:49:53.563517
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.1')

    assert v1 < v2


# Generated at 2022-06-23 14:50:04.041776
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # Case 1
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    assert v1 >= v2
    # Case 2
    v1 = SemanticVersion('1.2.4')
    v2 = SemanticVersion('1.2.3')
    assert v1 >= v2
    # Case 3
    v1 = SemanticVersion('1.3.3')
    v2 = SemanticVersion('1.2.3')
    assert v1 >= v2
    # Case 4
    v1 = SemanticVersion('2.2.3')
    v2 = SemanticVersion('1.2.3')
    assert v1 >= v2
    # Case 5
    v1 = SemanticVersion('1.2.3-beta')
    v2 = Sem

# Generated at 2022-06-23 14:50:06.347705
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('a')
    assert not _Alpha('b') <= _Alpha('a')


# Generated at 2022-06-23 14:50:13.089498
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > 0
    assert _Numeric('1') > _Numeric('0')
    assert not _Numeric('0') > _Numeric('0')
    assert not _Numeric('0') > 0
    assert not _Numeric('0') > _Alpha('0')
    assert not _Numeric('0') > _Alpha('1')
    assert _Numeric('0') > '0'


# Generated at 2022-06-23 14:50:15.170396
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    expected_value = "'Hello'"
    actual_value = repr( _Alpha(specifier='Hello') )
    assert expected_value == actual_value


# Generated at 2022-06-23 14:50:23.144735
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != _Alpha('a')
    assert _Alpha('a') != 'a'
    assert _Alpha('a') != _Numeric('a')
    assert _Alpha('a') != _Numeric(10)
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'b'
    assert not (_Alpha('a') != _Alpha('a'))
    assert not (_Alpha('a') != 'a')
    assert not (_Alpha('a') != _Numeric('a'))
    assert not (_Alpha('a') != _Numeric(10))
    assert not (_Alpha('a') != _Alpha('b'))
    assert not (_Alpha('a') != 'b')

# Generated at 2022-06-23 14:50:30.085727
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert SemanticVersion('1.0.0') >= '1.0.0'
    assert SemanticVersion('1.1.0') >= '1.0.0'
    assert SemanticVersion('2.0.0') >= '1.0.0'
    assert SemanticVersion('1.0.0') >= '1.0.0-beta'
    assert SemanticVersion('1.0.0') < '1.0.0-beta.2'
    assert SemanticVersion('1.0.0-beta.2') < '1.0.0-beta.10'
    assert SemanticVersion('1.0.0-beta.11') > '1.0.0-beta.2'
    assert SemanticVersion('1.0.0-r1') > '1.0.0-beta.10'

# Generated at 2022-06-23 14:50:33.453112
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == _Numeric(2)
    assert _Numeric(1) == 1
    assert not _Numeric(1) == 2


# Generated at 2022-06-23 14:50:36.879995
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(1)

    assert a.__ne__(b)
    assert a.__ne__(1)
    assert not a.__ne__(c)


# Generated at 2022-06-23 14:50:44.827438
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    alphalist = [
        _Alpha('alpha'),
        _Alpha(u'alpha'),
        _Alpha('alphA'),
        _Alpha(u'alphA'),
        _Alpha('alpHA'),
        _Alpha(u'alpHA'),
        _Alpha('Alpha'),
        _Alpha(u'Alpha'),
        _Alpha('ALPHA'),
        _Alpha(u'ALPHA'),
        _Alpha('beta'),
        _Alpha(u'beta'),
        _Alpha('betA'),
        _Alpha(u'betA'),
        _Alpha('beTA'),
        _Alpha(u'beTA'),
        _Alpha('Beta'),
        _Alpha(u'Beta'),
        _Alpha('BETA'),
        _Alpha(u'BETA'),
    ]

# Generated at 2022-06-23 14:50:46.279850
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    obj = _Numeric('5')
    assert repr(obj) == "'5'"



# Generated at 2022-06-23 14:50:54.304766
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    """test__eq__ of class SemanticVersion"""
    # Testing equal major versions
    semver1 = SemanticVersion('1.0.0')
    semver2 = SemanticVersion('1.0.0')
    semver3 = SemanticVersion('1.0.0-alpha')
    semver4 = SemanticVersion('1.0.0-beta')
    semver5 = SemanticVersion('1.0.0-rc.1')

    assert semver1 == semver2
    assert semver1 == '1.0.0'
    assert '1.0.0' == semver1
    assert semver1 == semver3
    assert semver1 == semver4
    assert semver1 == semver5
    assert semver2 == semver3
    assert semver2 == semver4
    assert sem

# Generated at 2022-06-23 14:51:05.303778
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    semantic_version = SemanticVersion("2.0.0")
    assert semantic_version.__gt__("0.1.1") == True
    assert semantic_version.__gt__("1.0.0") == True
    assert semantic_version.__gt__("2.0.1") == False
    assert semantic_version.__gt__("2.0.0") == False
    assert semantic_version.__gt__("2.0.0-dev") == False
    assert semantic_version.__gt__("2.0.0-dev.1") == False
    assert semantic_version.__gt__("2.0.0-alpha") == False
    assert semantic_version.__gt__("2.0.0-alpha.1") == False


# Generated at 2022-06-23 14:51:14.446775
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    # Test: compare an int with a num
    e = _Numeric(3)
    c = e.__gt__(2)
    assert c is True

    # Test: compare a num with an int
    e = _Numeric(2)
    c = e.__gt__(3)
    assert c is False

    # Test: compare two nums
    e = _Numeric(2)
    c = e.__gt__(_Numeric(3))
    assert c is False

    # Test: compare a num with a char
    e = _Numeric(3)
    c = e.__gt__(_Alpha("beta"))
    assert c is False

    # Test: compare a num with an int
    e = _Numeric(3)
    c = e.__gt__(_Alpha("alpha"))
    assert c is True

# Generated at 2022-06-23 14:51:21.260197
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric("1") < _Numeric("2")
    assert not _Numeric("1") < _Numeric("1")
    assert not _Numeric("2") < _Numeric("1")

    assert _Numeric("1") < _Alpha("2")
    assert _Numeric("1") < _Alpha("10")
    assert not _Numeric("1") < _Alpha("1")
    assert not _Numeric("2") < _Alpha("1")
    assert not _Numeric("10") < _Alpha("1")

    try:
        _Numeric("1") < _Numeric("a")
        assert False, "expected ValueError"
    except ValueError:
        pass



# Generated at 2022-06-23 14:51:28.577260
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    for integer in range(0, 10):
        for alpha in range(0, 26):
            assert _Alpha(integer) <= _Alpha(integer)
            assert _Alpha(integer) <= _Alpha(alpha)
            assert _Alpha(integer) != _Alpha(alpha)
            assert _Alpha(integer) < _Alpha(alpha)
            assert _Alpha(alpha) != _Alpha(integer)
            assert _Alpha(alpha) > _Alpha(integer)
            assert _Alpha(alpha) >= _Alpha(integer)
    return True


# Generated at 2022-06-23 14:51:31.061205
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion('3.6.0')
    assert repr(version) == 'SemanticVersion(\'3.6.0\')'


# Generated at 2022-06-23 14:51:35.844555
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha("a") > _Alpha("b")
    assert _Alpha("a") > _Alpha("0")
    assert _Alpha("a") < _Alpha("0")
    assert _Alpha("a") == _Alpha("a")
    assert _Alpha("a1") > _Alpha("a")
    assert _Alpha("a") < _Alpha("a1")
    assert _Alpha("a1") == _Alpha("a1")
    return True


# Generated at 2022-06-23 14:51:44.582013
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    sv1 = SemanticVersion('1.0.0')
    sv2 = SemanticVersion('2.0.0')
    sv3 = SemanticVersion('2.0.0-alpha')
    sv4 = SemanticVersion('2.0.0-beta')
    sv5 = SemanticVersion('2.0.0-alpha.1')
    sv6 = SemanticVersion('2.0.0-alpha.2')
    sv7 = SemanticVersion('2.0.0-beta.1')
    sv8 = SemanticVersion('2.0.0-beta.2')
    sv9 = SemanticVersion('2.0.0-beta.11')
    sv10 = SemanticVersion('2.0.0-rc.1')
    sv11 = SemanticVersion('2.0.0')


# Generated at 2022-06-23 14:51:46.041841
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == _Numeric('1')



# Generated at 2022-06-23 14:51:56.846750
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Test with major, minor and patch semver
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0')

    assert (v1 == v2), 'Failed to match semvers for exact match'

    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('2.0.0')

    assert not (v1 == v2), 'Failed to distinguish semvers with different major version'

    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.1.0')

    assert not (v1 == v2), 'Failed to distinguish semvers with different minor version'

    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.1')



# Generated at 2022-06-23 14:52:00.347690
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert not _Numeric(2) <= _Numeric(1)
    assert _Alpha('a') >= _Numeric(1)


# Generated at 2022-06-23 14:52:03.384638
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.2') == SemanticVersion('1.2.2')
    assert SemanticVersion('1.2.2') == '1.2.2'
    assert SemanticVersion('1.2.2') == LooseVersion('1.2.2')


# Generated at 2022-06-23 14:52:07.408231
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("1.2.3")
    assert SemanticVersion("0.0.0")
    assert SemanticVersion("1.2.3-alpha.10.beta.0+build.unicorn.rainbow")


# Generated at 2022-06-23 14:52:19.347766
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3
    version = '7.3.1'
    loose_version = LooseVersion(version)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    if PY3 and isinstance(semantic_version, str):
        semantic_version = SemanticVersion(semantic_version)
    assert semantic_version == SemanticVersion(version)
    version = '7.3.1-0.2.alpha'
    loose_version = LooseVersion(version)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    if PY3 and isinstance(semantic_version, str):
        semantic_version = SemanticVersion(semantic_version)

# Generated at 2022-06-23 14:52:24.339261
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == _Alpha('a') == _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')
    assert _Alpha('a') < 'b'
    assert _Alpha('b') > 'a'
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert _Alpha('b') >= 'a'
    assert _Alpha('b') >= 'b'



# Generated at 2022-06-23 14:52:32.797100
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    a = SemanticVersion('1')
    b = SemanticVersion('2')
    c = SemanticVersion('1.0.0')
    d = SemanticVersion('1.0.1')
    e = SemanticVersion('1.1.0')
    f = SemanticVersion('1.0.0-alpha')
    g = SemanticVersion('1.0.0-alpha.1')
    h = SemanticVersion('1.0.0-alpha.beta')
    i = SemanticVersion('1.0.0-beta')
    j = SemanticVersion('1.0.0-beta.2')
    k = SemanticVersion('1.0.0-beta.11')
    l = SemanticVersion('1.0.0-rc.1')
    m = SemanticVersion('1.0.0')
   

# Generated at 2022-06-23 14:52:34.810913
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('x').specifier == 'x'
    assert _Alpha('1').specifier == '1'


# Generated at 2022-06-23 14:52:38.726113
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('1.0.0')
    assert v.__repr__() == "SemanticVersion('1.0.0')"


# Generated at 2022-06-23 14:52:43.486806
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('1') <= _Numeric('2')
    assert _Numeric('1') <= _Numeric('1')
    assert not _Numeric('1') <= _Numeric('0')
    assert _Numeric('1') <= _Alpha('1')
    assert not _Numeric('1') <= _Alpha('0')



# Generated at 2022-06-23 14:52:51.600359
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion("0.1.1") >= SemanticVersion("0.1.0")
    assert SemanticVersion("1.1.0") >= SemanticVersion("0.1.0")
    assert SemanticVersion("1.1.1") >= SemanticVersion("0.1.0")
    assert not SemanticVersion("0.1.1") >= SemanticVersion("0.2.0")
    assert not SemanticVersion("1.1.0") >= SemanticVersion("2.1.0")
    assert not SemanticVersion("0.9.9") >= SemanticVersion("1.1.0")
    assert SemanticVersion("0.1.1") >= SemanticVersion("0.1.1")
    assert SemanticVersion("1.1.0") >= SemanticVersion("1.1.0")
    assert Semantic

# Generated at 2022-06-23 14:52:54.190638
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n1 = _Numeric("1")
    n2 = _Numeric("1")
    n3 = _Numeric("2")
    assert n1 == n2
    assert n1 != n3


# Generated at 2022-06-23 14:53:06.129850
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('1') >= _Alpha('1.0')
    assert _Alpha('1') >= _Alpha('1.0.1')
    assert _Alpha('1') >= _Alpha('a')
    assert _Alpha('1') >= _Alpha('a.b')
    assert _Alpha('1') >= _Alpha('a.b.c')
    assert _Alpha('1') >= '1'
    assert _Alpha('1') >= '1.0'
    assert _Alpha('1') >= '1.0.1'
    assert _Alpha('1') >= 'a'
    assert _Alpha('1') >= 'a.b'
    assert _Alpha('1') >= 'a.b.c'
    assert _Alpha('1.0') >= _Alpha('1')
    assert _

# Generated at 2022-06-23 14:53:11.881013
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    _numeric_a = _Numeric(1)
    _numeric_b = _Numeric(2)
    _numeric_A = _Numeric(1.0)
    _numeric_B = _Numeric(1.1)
    _numeric_c = _Numeric('2')
    _numeric_C = _Numeric('1.1')
    _numeric_D = _Numeric('1.0')
    _numeric_e = _Numeric(int('1'))
    _numeric_f = _Numeric(int('2'))

    assert(_numeric_A <= _numeric_A)
    assert(_numeric_A <= _numeric_B)
    assert(_numeric_A <= _numeric_C)
    assert(_numeric_A <= _numeric_D)

# Generated at 2022-06-23 14:53:14.092280
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a1 = _Alpha('a')
    a2 = _Alpha('b')
    a3 = _Alpha('b')
    assert a1 < a2
    assert not a1 > a2
    assert a2 == a3


# Generated at 2022-06-23 14:53:22.201549
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') <= _Alpha('beta')
    assert _Alpha('alpha') < _Alpha('Beta')
    assert _Alpha('alpha') <= _Alpha('Beta')
    assert _Alpha('alpha') < _Alpha('ALPHA')
    assert _Alpha('alpha') <= _Alpha('ALPHA')
    assert _Alpha('alpha') < _Alpha('a')
    assert _Alpha('alpha') <= _Alpha('a')
    assert _Alpha('alpha') < _Alpha('b')
    assert _Alpha('alpha') <= _Alpha('b')
    assert _Alpha('alpha') < _Alpha('A')
    assert _Alpha('alpha') <= _Alpha('A')
    assert _Alpha('alpha') < _Alpha('B')
    assert _Alpha('alpha') <= _Alpha('B')

# Generated at 2022-06-23 14:53:27.501896
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < _Numeric('01')
    assert not _Numeric('2') < _Numeric('1')
    assert not _Numeric('1') < _Numeric('1')
    assert _Numeric('1') < _Alpha('01')
    assert _Numeric('1') < _Alpha('2')
    assert _Numeric('1') < _Alpha('2alpha')
    assert not _Numeric('2') < _Alpha('1')
    assert not _Numeric('1') < _Alpha('1')
    assert _Numeric('1') < _Alpha('1alpha')



# Generated at 2022-06-23 14:53:29.122848
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha('ansible')
    assert repr(alpha) == repr('ansible')


# Generated at 2022-06-23 14:53:31.516615
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    _Numeric(1).__ne__(1)
    _Numeric(1).__ne__(2)

# Generated at 2022-06-23 14:53:38.009317
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    try:
        SemanticVersion('0.1.1')
        SemanticVersion('0.1.2')
        SemanticVersion('0.2.1')
        SemanticVersion('0.2.2')
        SemanticVersion('1.1.1')
        SemanticVersion('1.1.2')
        SemanticVersion('1.2.1')
        SemanticVersion('1.2.2')
    except ValueError:
        assert False, 'Invalid semver string'


# Generated at 2022-06-23 14:53:45.386419
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("a") < _Alpha("b")
    assert _Alpha("a") <= _Alpha("a")
    assert _Alpha("a") <= _Alpha("b")
    assert _Alpha("b") > _Alpha("a")
    assert _Alpha("b") >= _Alpha("a")
    assert _Alpha("b") >= _Alpha("b")
    assert _Alpha("b") == _Alpha("b")
    assert _Alpha("b") != _Alpha("a")
    assert "a" < _Alpha("b")
    assert "a" <= _Alpha("a")
    assert "a" <= _Alpha("b")
    assert "b" > _Alpha("a")
    assert "b" >= _Alpha("a")
    assert "b" >= _Alpha("b")
    assert "b" == _Alpha("b")

# Generated at 2022-06-23 14:53:52.708703
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= 2

    try:
        _Numeric(1) >= _Alpha('1')
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-23 14:53:59.246952
# Unit test for constructor of class _Numeric
def test__Numeric():
    obj1 = _Numeric("123")
    obj2 = _Numeric("123")
    obj3 = _Numeric("456")
    assert (obj1 == obj2)
    assert (obj1 != obj3)
    assert (obj3 != "456")
    assert (obj1 < obj3)
    assert (obj1 <= obj3)
    assert (obj1 <= obj2)
    assert (obj3 > obj1)
    assert (obj3 >= obj1)
    assert (obj1 >= obj2)


# Generated at 2022-06-23 14:54:05.427492
# Unit test for constructor of class _Numeric
def test__Numeric():
    _numeric = _Numeric('1')
    assert(_numeric.specifier == 1)
    _numeric = _Numeric('2')
    assert(_numeric.specifier == 2)
    _numeric = _Numeric('3')
    assert(_numeric.specifier == 3)
    _numeric = _Numeric(1)
    assert(_numeric.specifier == 1)
    _numeric = _Numeric(2)
    assert(_numeric.specifier == 2)
    _numeric = _Numeric(3)
    assert(_numeric.specifier == 3)
# test_numeric


# Generated at 2022-06-23 14:54:11.347924
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    v1 = _Numeric(1)
    v2 = _Numeric(2)

    assert v1 <= v2

    v1 = _Numeric(1)
    v2 = _Numeric(1)

    assert v1 <= v2

    v2 = _Numeric(1)
    v1 = _Numeric(2)

    assert v1 != v2


# Generated at 2022-06-23 14:54:16.068106
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    """Unit test for method __le__ of class _Alpha"""

    # Test that __le__ returns True when it's the same
    assert _Alpha('abc') <= _Alpha('abc')
    assert _Alpha('abc') <= 'abc'
    assert 'abc' <= _Alpha('abc')

    # Test that __le__ returns True when it's less than
    assert _Alpha('abc') <= _Alpha('abcd')
    assert _Alpha('abc') <= 'abcd'
    assert 'abc' <= _Alpha('abcd')

    # Test that __le__ returns True when it's greater than, because the
    # integers get converted to _Numeric before comparison
    assert _Alpha('abc') <= _Alpha('123')

    # Test that __le__ return False when it's greater than
    assert not _Alpha('abcd') <= _Alpha('abc')


# Generated at 2022-06-23 14:54:26.392255
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test that SemanticVersion.from_loose_version correctly converts
        LooseVersion instances to SemanticVersion instances
    """
    # This test is a unit test for a method of SemanticVersion.
    # pylint: disable=no-self-use
    # Check that the method works when given a valid LooseVersion instance
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    # Check that the method works when given an instance with a pre-release
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.0')) == SemanticVersion('1.2.3-alpha.0')
    # Check that the method works when given an instance with a build metadata
    assert SemanticVersion.from_

# Generated at 2022-06-23 14:54:38.390049
# Unit test for method __eq__ of class SemanticVersion

# Generated at 2022-06-23 14:54:39.520249
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'


# Generated at 2022-06-23 14:54:42.705441
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(2) >= _Numeric(1)
    assert not _Numeric(1) >= _Numeric(2)


# Generated at 2022-06-23 14:54:45.639129
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')


# Generated at 2022-06-23 14:54:53.926859
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # With empty argument
    try:
        SemanticVersion()
    except ValueError as e:
        assert 'invalid semantic version' in text_type(e)
    else:
        raise AssertionError

    # With invalid semantic version string
    try:
        SemanticVersion('a.b.c')
    except ValueError as e:
        assert 'invalid semantic version' in text_type(e)
    else:
        raise AssertionError

    # With string of valid semantic version
    s = SemanticVersion('2.0.0')
    assert s.major == 2
    assert s.minor == 0
    assert s.patch == 0
    assert len(s.prerelease) == 0
    assert len(s.buildmetadata) == 0

    # With LooseVersion
    s = SemanticVersion.from_lo

# Generated at 2022-06-23 14:54:56.057799
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')


# Generated at 2022-06-23 14:54:57.489527
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1.1') >= _Alpha('1.1')



# Generated at 2022-06-23 14:54:58.413172
# Unit test for constructor of class _Numeric
def test__Numeric():
    _Numeric('1')


# Generated at 2022-06-23 14:55:00.564812
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('2')) == '2'
    assert repr(_Numeric(1)) == '1'


# Unit tests for method __eq__ of class _Numeric

# Generated at 2022-06-23 14:55:02.896640
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1.12') < _Numeric('1.13'), "Test Failed"


# Generated at 2022-06-23 14:55:04.331824
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('1') != _Numeric('1')


# Generated at 2022-06-23 14:55:10.998815
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("1.0.0+foo.1") == "1.0.0+foo.1"
    assert SemanticVersion("1.0.0-dev") == "1.0.0-dev"
    assert SemanticVersion("1.0.0") == "1.0.0"
    assert SemanticVersion("1.0.1") > "1.0.0"
    assert SemanticVersion("1.0.1") >= "1.0.0"
    assert SemanticVersion("1.0.1") == "1.0.1"
    assert SemanticVersion("1.0.1") >= "1.0.1"
    assert SemanticVersion("1.0.1") <= "1.0.1"

# Generated at 2022-06-23 14:55:12.081022
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)


# Generated at 2022-06-23 14:55:14.477998
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion("0.0.1").__repr__() == "SemanticVersion(u'0.0.1')"


# Generated at 2022-06-23 14:55:16.320756
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    version1 = SemanticVersion('5.5.5+build')
    version2 = SemanticVersion('5.5.6+build')
    assert version1 < version2


# Generated at 2022-06-23 14:55:21.150679
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    a = SemanticVersion('3.0.0')
    assert(a == '3.0.0')
    assert(a == SemanticVersion('3.0.0'))
    assert(a == LooseVersion('3.0.0'))

    assert(a != '2.9.9')
    assert(a != SemanticVersion('2.9.9'))
    assert(a != LooseVersion('2.9.9'))


# Generated at 2022-06-23 14:55:30.895770
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    try:
        assert _Numeric(2) <= 2
    except AssertionError as e:
        print('AssertionError was raised => %s' % e.message)
    else:
        print('OK')

    try:
        assert _Numeric(3) <= 2
    except AssertionError as e:
        print('AssertionError was raised => %s' % e.message)
    else:
        print('OK')

    try:
        assert not _Numeric(2) <= 1
    except AssertionError as e:
        print('AssertionError was raised => %s' % e.message)
    else:
        print('OK')


# Generated at 2022-06-23 14:55:32.459209
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    a = _Numeric(1)
    assert repr(a) == '1'



# Generated at 2022-06-23 14:55:34.453530
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < 2


# Generated at 2022-06-23 14:55:36.032800
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    _alpha = _Alpha('1')
    assert _alpha >= '1'


# Generated at 2022-06-23 14:55:43.189295
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    class TestClass:
        def __init__(self):
            pass

        def _cmp(self, actual, expected):
            try:
                actual = SemanticVersion(actual)
                expected = SemanticVersion(expected)
            except ValueError:
                pass

            self.assertEqual(actual, expected)
            self.assertEqual(actual <= expected, True)

    TestClass.run = run_test
    TestClass()._cmp('0.0.1', '0.0.0')
    TestClass()._cmp('0.1.1', '0.0.1')
    TestClass()._cmp('1.1.1', '0.1.1')
    TestClass()._cmp('1.1.1', '1.1.1')

# Generated at 2022-06-23 14:55:53.388895
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('1').__ge__(_Numeric('1')) == True
    assert _Numeric('1').__ge__(_Numeric('2')) == False
    assert _Numeric('2').__ge__(_Numeric('1')) == True

    assert _Numeric('1').__ge__('1') == True
    assert _Numeric('1').__ge__('2') == False
    assert _Numeric('2').__ge__('1') == True

    assert _Numeric('1').__ge__(_Alpha('1')) == False
    assert _Numeric('1').__ge__(_Alpha('2')) == False
    assert _Numeric('2').__ge__(_Alpha('1')) == True


# Generated at 2022-06-23 14:55:57.089661
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # Test if __repr__ is defined
    instance = SemanticVersion()
    assert hasattr(instance, '__repr__')
    # Test if __repr__ return type is str
    assert isinstance(instance.__repr__(), str)



# Generated at 2022-06-23 14:56:05.636116
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():

    def lt(v1, v2, v3):
        sv1 = SemanticVersion(v1)
        sv2 = SemanticVersion(v2)

        assert sv1 < sv2, 'Expected {0} < {1}'.format(sv1 < sv2)
        assert not (sv1 > sv2), 'Expected {0} > {1}'.format(sv1 > sv2)

        if v3 is not None:
            sv3 = SemanticVersion(v3)
            assert sv1 < sv3, 'Expected {0} < {1}'.format(sv1 < sv3)
            assert not (sv1 > sv3), 'Expected {0} > {1}'.format(sv1 > sv3)

    # Test semver.org Example 1

# Generated at 2022-06-23 14:56:09.868475
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion("1.2.3")
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()


# Generated at 2022-06-23 14:56:11.238420
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric('1') == 1



# Generated at 2022-06-23 14:56:19.346704
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert (SemanticVersion('0.0.0') > SemanticVersion('0.0.0-0'))
    assert (SemanticVersion('0.0.0') > SemanticVersion('0.0.0-alpha'))
    assert (SemanticVersion('0.0.0-alpha') > SemanticVersion('0.0.0-0'))
    assert (SemanticVersion('0.0.0-alpha') > SemanticVersion('0.0.0-alpha'))
    assert (SemanticVersion('0.0.0-alpha.1') > SemanticVersion('0.0.0-alpha'))
    assert (SemanticVersion('0.0.0-alpha.alpha') > SemanticVersion('0.0.0-alpha.beta'))

# Generated at 2022-06-23 14:56:23.215609
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert not _Alpha('foo') == _Alpha('bar')
    assert _Alpha('foo') == _Alpha('foo')
    assert _Alpha('bar') == _Alpha('bar')
    assert not _Alpha('bar') == _Alpha('foo')


# Generated at 2022-06-23 14:56:34.239625
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    # Test with object of the same class
    o1 = _Numeric(1)
    o2 = _Numeric(1)
    assert o1.__gt__(o2) == False

    o1 = _Numeric(1)
    o2 = _Numeric(2)
    assert o1.__gt__(o2) == True
    assert o2.__gt__(o1) == False

    # Test with string
    o1 = _Numeric(1)
    o2 = "1"
    assert o1.__gt__(o2) == False
    assert o2.__gt__(o1) == False

    o1 = _Numeric(1)
    o2 = 2
    assert o1.__gt__(o2) == True

# Generated at 2022-06-23 14:56:39.279082
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('10') < _Numeric('11')
    assert _Numeric('2') < _Numeric('21')
    assert _Numeric('21') > _Numeric('2')
    assert _Numeric('2') < _Numeric('10')
    assert _Numeric('3.10') > _Numeric('3.9')
    assert _Numeric('3.10') == _Numeric('3.10')


# Generated at 2022-06-23 14:56:46.616145
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    v3 = SemanticVersion('1.2.4-alpha')
    v4 = SemanticVersion('1.2.4+build')
    v5 = SemanticVersion('2.0.0-alpha.3+build.1')
    assert v1 == v2
    assert not v1 == v3
    assert not v1 == v4
    assert not v1 == v5


# Generated at 2022-06-23 14:56:50.329346
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('v1.2.3')
    b = 'v1'
    c = _Alpha('v1')
    d = 1

    assert a.__ne__(b)
    assert a.__ne__(c)
    assert a.__ne__(d)


# Generated at 2022-06-23 14:57:01.672384
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') < _Alpha('alpha2')
    assert _Alpha('alpha01') < _Alpha('alpha02')
    assert _Alpha('alpha01') < _Alpha('alpha10')
    assert _Alpha('alpha01') < _Alpha('alpha2')
    assert _Alpha('alpha1') < _Alpha('alpha02')
    assert _Alpha('alpha1') < _Alpha('alpha10')
    assert _Alpha('alpha1') < _Alpha('alpha2')
    assert _Alpha('beta') < _Alpha('gamma')
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') < _Alpha('gamma')
    assert _Alpha('alpha') < _Alpha('alpha2')



# Generated at 2022-06-23 14:57:07.514240
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    t = SemanticVersion
    assert not t('1.0.0') != t('1.0.0')
    assert t('0.0.1') != t('1.0.0')
    assert t('0.0.1') != t('0.1.0')
    assert t('0.0.1') != t('0.0.2')
    assert t('1.0.0') != t('2.0.0')

    assert t('1.0.0') != t('1.0.0-alpha')
    assert t('1.0.0') != t('1.0.0-alpha.1')
    assert t('1.0.0-alpha') != t('1.0.0-alpha.3')

# Generated at 2022-06-23 14:57:18.855412
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    
    if SemanticVersion("1.2.3") == "1.2.3":
        print("1.2.3")
    else:
        print("not 1.2.3")

    if SemanticVersion("1.2.3-test") == "1.2.3-test":
        print("1.2.3-test")
    else:
        print("not 1.2.3-test")

    if SemanticVersion("1.2.3-test") == SemanticVersion("1.2.3-test"):
        print("1.2.3-test == 1.2.3-test")
    else:
        print("1.2.3-test != 1.2.3-test")


# Generated at 2022-06-23 14:57:23.423008
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('alpha')
    b = _Alpha('beta')
    assert not a.__gt__(b)
    assert a.__gt__(a)
    assert b.__gt__(a)



# Generated at 2022-06-23 14:57:30.174586
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion("1.2.3") >= "1.2.3"
    assert not SemanticVersion("1.2.3") >= "1.2.3-beta.3"
    assert SemanticVersion("1.2.3") >= "1.2.3-beta.2"
    assert not SemanticVersion("1.2.3-beta.1") >= "1.2.3-beta.2"
    assert not SemanticVersion("1.2.3-beta.2") >= "1.2.3-beta.2.1"
    assert not SemanticVersion("1.2.3-beta.11") >= "1.2.3-beta.2"
    assert SemanticVersion("1.2.3-beta.2") >= "1.2.3-beta.2"


# Generated at 2022-06-23 14:57:31.548705
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= 1


# Generated at 2022-06-23 14:57:41.639037
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v = SemanticVersion('1.0.0-rc1')
    assert not v <= '2.0.0'
    assert not v <= '1.1.0'
    assert not v <= '1.0.1'
    assert v <= '1.0.0'
    assert v <= '1.0.0-rc1'
    assert v <= '1.0.0-rc2'
    assert v <= '1.0.0-rc.1'

    v = SemanticVersion('1.0.0')
    assert not v <= '2.0.0'
    assert not v <= '1.1.0'
    assert not v <= '1.0.1'
    assert v <= '1.0.0'
    assert v <= '1.0.0-rc1'

# Generated at 2022-06-23 14:57:43.798648
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != _Alpha('b')


# Generated at 2022-06-23 14:57:46.954757
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Test with int
    value_1 = 1
    value_2 = 2
    numeric_1 = _Numeric(value_1)
    numeric_2 = _Numeric(value_2)
    assert numeric_1 < numeric_2 == value_1 < value_2



# Generated at 2022-06-23 14:57:48.444582
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha("1alpha").__repr__() == "'1alpha'"


# Generated at 2022-06-23 14:57:56.415453
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha(0) == 0
    assert _Alpha(0) == '0'
    assert _Alpha('1') == 1
    assert _Alpha('1') == '1'
    assert _Alpha(2) == '2'
    assert _Alpha(3) == 3
    assert _Alpha(3) == '3'
    assert _Alpha('3') == 3

    assert '0' == _Alpha(0)
    assert 0 == _Alpha('0')
    assert 1 == _Alpha('1')
    assert '1' == _Alpha(1)
    assert '2' == _Alpha(2)
    assert 3 == _Alpha(3)
    assert '3' == _Alpha(3)
    assert 3 == _Alpha('3')

    assert _Alpha(0) != '1'
    assert _Alpha(0) != 1
   

# Generated at 2022-06-23 14:57:59.857349
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(0) < _Numeric('1')
    assert not _Numeric(0) < _Numeric(0)


# Generated at 2022-06-23 14:58:07.228893
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys

    if sys.version_info < (3, 5):
        from distutils.version import LooseVersion
    else:
        from packaging.version import Version as LooseVersion
    obj = SemanticVersion.from_loose_version(LooseVersion('0.0.0-alpha+deadbeef.1.2.3.4'))
    assert isinstance(obj, SemanticVersion)
    assert obj == SemanticVersion('0.0.0-alpha+deadbeef.1.2.3.4')
    assert obj.is_prerelease
    assert not obj.is_stable
    assert obj.core == (0, 0, 0)
    assert obj.major == 0
    assert obj.minor == 0
    assert obj.patch == 0
    assert obj.prerelease == (_Alpha('alpha'),)

# Generated at 2022-06-23 14:58:14.490685
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(0) == _Numeric(0)
    assert _Numeric(0) == 0
    assert 0 == _Numeric(0)

    assert not _Numeric(0) == _Numeric(1)
    assert not _Numeric(0) == 1
    assert not 0 == _Numeric(1)

    assert _Numeric(0) != _Numeric(1)
    assert _Numeric(0) != 1
    assert 0 != _Numeric(1)

    assert not _Numeric(0) != _Numeric(0)
    assert not _Numeric(0) != 0
    assert not 0 != _Numeric(0)



# Generated at 2022-06-23 14:58:21.122845
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('foo') >= _Alpha('foo')
    assert not _Alpha('bar') >= _Alpha('foo')
    assert not 'bar' >= _Alpha('foo')
    assert _Alpha('foo') >= 'foo'
    # Try to order an int and a string, should raise ValueError
    try:
        _Alpha('foo') >= 10
    except ValueError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-23 14:58:26.387545
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    """
    _Alpha.__ne__(other)

    Test __ne__ method on _Alpha class.
    Returns True if the two instances are not equal, otherwise False.
    """

    # Arrange
    sut = _Alpha("one")
    other = _Alpha("one")

    # Act
    result = sut.__ne__(other)

    # Assert
    assert result != True


# Generated at 2022-06-23 14:58:31.661773
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    class FakeNumeric:
        def __lt__(self, other):
            pass
        def __eq__(self, other):
            pass

    PyTest.raises(ValueError, _Numeric(1).__le__, None)
    assert _Numeric(1).__le__(FakeNumeric()) == NotImplemented
