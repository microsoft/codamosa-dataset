

# Generated at 2022-06-23 14:48:35.661443
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.1')) == 'SemanticVersion(\'0.0.1\')'



# Generated at 2022-06-23 14:48:38.770563
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    # test method __repr__() of class _Numeric
    numeric_val = _Numeric(specifier=7)
    assert numeric_val.__repr__() == '7'


# Generated at 2022-06-23 14:48:49.430594
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a = SemanticVersion("1.0.0-alpha.1+build")
    b = SemanticVersion("1.0.0-beta.1+build")
    assert (a < b) == True
    assert (a <= b) == True
    assert (b > a) == True
    assert (b >= a) == True
    assert (a > b) == False
    assert (a >= b) == False
    assert (b < a) == False
    assert (b <= a) == False

    a = SemanticVersion("1.0.0-alpha.1+build")
    b = SemanticVersion("1.0.0-beta.2+build")
    assert (a < b) == True
    assert (a <= b) == True
    assert (b > a) == True
    assert (b >= a) == True

# Generated at 2022-06-23 14:48:57.505900
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    sv = SemanticVersion('1.2.3')
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()

    sv = SemanticVersion('1.2.3-rc1.2.3-beta1.2.3-alpha')
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == ('rc1', '2', '3', 'beta1', '2', '3', 'alpha')
    assert sv.buildmetadata == ()

    sv = SemanticVersion('1.2.3-rc1.2.3-beta1.2.3-alpha+exp.sha.5114f85')
    assert sv.major == 1


# Generated at 2022-06-23 14:49:06.187325
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    a = SemanticVersion('2.0.0')
    b = SemanticVersion('1.0.0')
    assert a > b
    b = SemanticVersion('1.0.1')
    assert a > b
    b = SemanticVersion('1.1.0')
    assert a > b
    b = SemanticVersion('1.1.1')
    assert a > b
    b = SemanticVersion('2.0.0')
    assert not a > b
    b = SemanticVersion('2.0.1')
    assert not a > b
    b = SemanticVersion('2.1.0')
    assert not a > b
    b = SemanticVersion('3.0.0')
    assert not a > b

    a = SemanticVersion('2.0.0-alpha')
    b = Semantic

# Generated at 2022-06-23 14:49:17.123464
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    print("test_SemanticVersion")
    # Semantic version format
    version = '1.0.1-beta.1+exp.sha.5114f85'
    semantic_version = SemanticVersion(version)

    # Test for major version
    if semantic_version.major == 1:
        print("major_version.. ok")
    else:
        print("major_version.. failed")
        return

    # Test for minor version
    if semantic_version.minor == 0:
        print("minor_version.. ok")
    else:
        print("minor_version.. failed")
        return

    # Test for patch number
    if semantic_version.patch == 1:
        print("patch_version.. ok")
    else:
        print("patch_version.. failed")
        return

    # Test for pre release
   

# Generated at 2022-06-23 14:49:26.795911
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    sw = SemanticVersion()
    sw.parse('1.0.0')
    assert sw.major == 1
    assert sw.minor == 0
    assert sw.patch == 0
    assert sw.prerelease == ()
    assert sw.buildmetadata == ()
    assert sw.is_stable
    assert not sw.is_prerelease

    sw = SemanticVersion()
    sw.parse('1.0.0-alpha')
    assert sw.major == 1
    assert sw.minor == 0
    assert sw.patch == 0
    assert sw.prerelease == (_Alpha('alpha'),)
    assert sw.buildmetadata == ()
    assert not sw.is_stable
    assert sw.is_prerelease

    sw = SemanticVersion()
    sw.parse('1.0.0-alpha.1')

# Generated at 2022-06-23 14:49:34.501040
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    """Test the method of class _Alpha which allows comparing strings"""

    test_string_1 = "test"
    test_string_2 = "test1"
    test_string_3 = "test-1"

    assert _Alpha(test_string_2).__gt__(_Alpha(test_string_1))

    assert not _Alpha(test_string_1).__gt__(_Alpha(test_string_2))

    assert not _Alpha(test_string_3).__gt__(_Alpha(test_string_2))

    assert not _Alpha(test_string_2).__gt__(_Alpha(test_string_3))



# Generated at 2022-06-23 14:49:38.941266
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    class A(_Numeric):
        pass
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= 1
    assert not (_Numeric(1) <= None)

    assert _Numeric(1) <= A(1)
    assert _Numeric(1) <= A('1')
    assert not (_Numeric(1) <= A(2))


# Generated at 2022-06-23 14:49:47.963633
# Unit test for constructor of class _Numeric
def test__Numeric():
    # TODO add unit tests
    import pytest
    with pytest.raises(ValueError):
        _Numeric('a')
    with pytest.raises(ValueError):
        _Numeric(1) > _Numeric('b')
    with pytest.raises(ValueError):
        _Numeric(1) < _Numeric('b')
    with pytest.raises(ValueError):
        _Numeric(1) == _Numeric('b')
    with pytest.raises(ValueError):
        _Numeric(1) <= _Numeric('b')
    with pytest.raises(ValueError):
        _Numeric(1) >= _Numeric('b')

# Generated at 2022-06-23 14:49:50.458515
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric(1)
    b = _Numeric(2)
    assert(a < b)



# Generated at 2022-06-23 14:49:54.013526
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('hello') == 'hello'
    assert _Alpha('hello') == _Alpha('hello')
    assert not _Alpha('hello') == 'world'
    assert not _Alpha('hello') == _Alpha('world')


# Generated at 2022-06-23 14:50:00.398625
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha('rc') > 'rc'
    assert _Alpha('rc') > 'beta'
    assert _Alpha('rc') > 'alpha'
    assert not _Alpha('alpha') > 'alpha'
    assert _Alpha('beta') > 'alpha'
    assert not _Alpha('1.0') > '1.0'
    assert not _Alpha('2.0') > '1.0'
    assert not _Alpha('1') > '1'


# Generated at 2022-06-23 14:50:07.982018
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    # Test same instance
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric(1) == _Numeric(1)

    # Test identical values
    assert _Numeric('1') == _Numeric(1)
    assert _Numeric(1) == _Numeric('1')

    # Test different values
    assert not _Numeric('1') == _Numeric('2')
    assert not _Numeric('1') == _Numeric(2)
    assert not _Numeric(1) == _Numeric(2)

    # Test 2 different types
    assert not _Numeric('1') == 1
    assert not _Numeric(1) == '1'


# Generated at 2022-06-23 14:50:16.526978
# Unit test for method __eq__ of class SemanticVersion

# Generated at 2022-06-23 14:50:19.319443
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.2.3') > '1.2.2'
    assert SemanticVersion('1.2.3') > '1.2'
    assert SemanticVersion('1.2.3') > '1'


# Generated at 2022-06-23 14:50:24.210520
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('1') < _Alpha('11')
    assert _Alpha('1') < _Alpha('10')
    # assert _Alpha('1') < _Alpha('a')
    assert _Alpha('1') < _Alpha('a1')
    assert _Alpha('1') < _Alpha('a11')
    assert _Alpha('1') < _Alpha('a10')


# Generated at 2022-06-23 14:50:27.348501
# Unit test for method __eq__ of class SemanticVersion

# Generated at 2022-06-23 14:50:31.612182
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    test_cases = (
        ((1, 2), False),
        ((2, 1), True),
        ((1, 1), False),
    )

    for values, result in test_cases:
        assert (_Numeric(values[0]) < _Numeric(values[1])) is result


# Generated at 2022-06-23 14:50:33.482005
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('alpha') > 'alpha'


# Generated at 2022-06-23 14:50:41.940938
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion is converted to SemanticVersion correctly.
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) \
        == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) \
        == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) \
        == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4')) \
        == SemanticVersion('1.2.3+4')

# Generated at 2022-06-23 14:50:43.926419
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('1') <= _Alpha('2')
    assert _Alpha('1') <= _Alpha('1')
    assert not _Alpha('1') <= _Alpha('0')

# Generated at 2022-06-23 14:50:50.711598
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('0.0.0') == '0.0.0'
    assert SemanticVersion('0.0.0') != '0.0.1'
    assert SemanticVersion('0.0.0') != '0.1.0'
    assert SemanticVersion('0.0.0') != '1.0.0'
    assert SemanticVersion('0.1.0') == '0.1.0'
    assert SemanticVersion('0.1.0') != '0.0.1'
    assert SemanticVersion('0.1.0') != '0.1.1'



# Generated at 2022-06-23 14:50:57.113371
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('alpha') != 1
    assert _Alpha('alpha') < 1
    assert _Alpha('alpha') < 2
    assert _Alpha('alpha') < 'alpha'
    assert _Alpha('alpha') < 'beta'
    assert _Alpha('alpha') < 'Alpha'
    assert _Alpha('alpha') <= 'alpha'
    assert _Alpha('alpha') <= 'beta'
    assert _Alpha('alpha') <= 'Alpha'
    assert _Alpha('alpha') > 1
    assert _Alpha('alpha') > 2
    assert _Alpha('alpha') > 'Alpha'
    assert _Alpha('alpha') >= 'Alpha'
    try:
        assert _Alpha('alpha') < '1'
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-23 14:51:06.711080
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    v.parse('1.0.0-rc1-beta')
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Numeric('rc'), _Numeric('1'), _Alpha('beta'))
    assert not v.buildmetadata

    v.parse('1.0.0+1234')
    assert v.buildmetadata == (_Numeric('1234'),)

    v.parse('0.0.0')
    assert v.major == 0
    assert v.minor == 0
    assert v.patch == 0
    assert not v.prerelease
    assert not v.buildmetadata



# Generated at 2022-06-23 14:51:10.091695
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
  assert not _Alpha("foo") < _Alpha("bar")
  assert _Alpha("foo") < _Alpha("foo ")
  assert _Alpha("foo") < _Alpha("foo0")
  assert _Alpha("foo") < _Alpha("foo0 ")
  assert not _Alpha("foo") < _Alpha("foo")


# Generated at 2022-06-23 14:51:12.672855
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    class_ = _Alpha("class")
    assert class_ != "class"
    assert class_ != _Alpha("Class")
    assert class_ != _Alpha("Test")


# Generated at 2022-06-23 14:51:19.824171
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.1.1') > '1.1.0'
    assert SemanticVersion('1.2.0') > '1.1.1'
    assert SemanticVersion('2.0.1') > '1.2.9'
    assert SemanticVersion('0.0.2') > '0.0.1'
    assert SemanticVersion('0.1.0') > '0.0.2'
    assert SemanticVersion('1.0.0') > '0.1.9'
    assert SemanticVersion('1.0.0') > '0.0.0'


# Generated at 2022-06-23 14:51:23.539822
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha("a")
    b = _Alpha("b")
    assert a <= b
    assert a <= "b"
    assert not a <= "a"


# Generated at 2022-06-23 14:51:27.683283
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(0) > _Numeric(-1)
    assert not _Numeric(-1) > _Numeric(0)
    assert not _Numeric(0) > _Numeric(1)



# Generated at 2022-06-23 14:51:33.089662
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    v = SemanticVersion("1.2.3")
    assert v.major == 1, "Unexpected major version"
    assert v.minor == 2, "Unexpected minor version"
    assert v.patch == 3, "Unexpected patch version"
    assert v.prerelease == (), "Unexpected prerelease version"
    assert v.buildmetadata == (), "Unexpected build metadata"
    assert v.is_stable, "Expected version to be stable"


# Generated at 2022-06-23 14:51:34.931571
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    assert (v1 >= v2) is True



# Generated at 2022-06-23 14:51:37.932914
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    semantic_version = SemanticVersion('1.2.3')
    assert repr(semantic_version) == 'SemanticVersion(\'1.2.3\')'
    

# Generated at 2022-06-23 14:51:38.901478
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(2).__ne__(2)

# Generated at 2022-06-23 14:51:40.301443
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("foo") >=  _Alpha("foo")
    

# Generated at 2022-06-23 14:51:42.968039
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    my_version = SemanticVersion('2.1.1')
    my_version2 = SemanticVersion('2.1.1')
    assert False == (my_version2 > my_version)


# Generated at 2022-06-23 14:51:49.403240
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a = _Numeric("1")
    b = _Numeric("2")
    c = _Alpha("1")

    assert a <= b
    assert a <= c
    assert a <= "1"
    assert a <= 1
    assert a <= 1.0
    assert a != "2"
    assert a != 2
    assert a != 2.0
    assert a != b


# Generated at 2022-06-23 14:51:59.143572
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    one = _Alpha('1')
    one1 = _Alpha('1')
    one_one = _Alpha('1.1')
    one_one1 = _Alpha('1.1')
    one_one_dev = _Alpha('1.1.dev')
    one_one_dev1 = _Alpha('1.1.dev')
    one_one_dev_one = _Alpha('1.1.dev.1')
    one_one_dev_one1 = _Alpha('1.1.dev.1')
    one_one_dev_one_alpha = _Alpha('1.1.dev.1.alpha')
    one_one_dev_one_alpha1 = _Alpha('1.1.dev.1.alpha')

    # Trivial cases
    assert one == one
    assert one == one1

# Generated at 2022-06-23 14:52:04.165337
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('1') > '0'
    assert _Alpha('1') >= '0'
    assert _Alpha('1') > 0
    assert _Alpha('1') >= 0
    assert _Alpha('a') > '1'
    assert _Alpha('a') >= '1'
    assert _Alpha('b') > 'a'
    assert _Alpha('b') >= 'a'
    assert _Alpha('b') > 'A'
    assert _Alpha('b') >= 'A'



# Generated at 2022-06-23 14:52:16.049137
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Test code
    test_code_1 = """
v1 = SemanticVersion('1.0.0')
assert v1 < '2.0.0'
"""
    test_code_2 = """
v1 = SemanticVersion('1.0.0')
assert v1 < '1.1.0'
"""
    test_code_3 = """
v1 = SemanticVersion('1.0.0')
assert v1 < '1.0.1'
"""
    test_code_4 = """
v1 = SemanticVersion('1.0.0-alpha')
assert v1 < '1.0.0-beta'
"""

# Generated at 2022-06-23 14:52:21.425042
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    numeric = _Numeric(1)
    numeric2 = _Numeric(1)
    numeric3 = _Numeric(2)
    alpha = _Alpha('1')
    alpha2 = _Alpha('2')
    assert numeric >= numeric2
    assert numeric >= numeric
    assert numeric >= alpha
    assert numeric >= alpha2
    assert numeric >= numeric3


# Generated at 2022-06-23 14:52:26.045175
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == _Alpha('1')

    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != _Alpha('2')

    assert not (_Numeric(1) == '')
    assert not (_Numeric(1) == None)

    assert _Numeric(1) != ''
    assert _Numeric(1) != None


# Generated at 2022-06-23 14:52:30.277087
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert SemanticVersion('1.0.0') != '1.0.1'
    assert SemanticVersion('1.0.0') != '2.0.0'
    assert SemanticVersion('1.0.0') != '0.1.0'


# Generated at 2022-06-23 14:52:32.877830
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(1)
    assert a == c
    assert a <= b
    assert a <= c


# Generated at 2022-06-23 14:52:37.223112
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(0) == 0
    assert _Numeric(1) == 1
    assert not _Numeric(0) == 1
    assert not _Numeric(1) == 0


# Generated at 2022-06-23 14:52:39.064443
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    """
    test version__Numeric___ne__:
    """
    obj = _Numeric(1)
    other = _Numeric(1)
    assert obj != other


# Generated at 2022-06-23 14:52:40.874961
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-23 14:52:50.386148
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('1').specifier == '1'
    assert _Alpha('a').specifier == 'a'

    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'a'
    assert _Alpha('a') == 'a'
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= 'a'
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('b') > 'a'
    assert _Alpha('b') >= _Alpha('a')
   

# Generated at 2022-06-23 14:52:55.367090
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    assert a < b
    assert a <= b
    assert a < c
    assert a <= c
    assert b > a
    assert b >= a
    assert b < c
    assert b <= c
    assert c > a
    assert c >= a
    assert c > b
    assert c >= b


# Generated at 2022-06-23 14:52:58.757753
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('2.0.0')
    assert repr(v) == 'SemanticVersion(\'2.0.0\')'



# Generated at 2022-06-23 14:52:59.811112
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    _Alpha("3")



# Generated at 2022-06-23 14:53:08.712735
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    num1 = _Numeric('2')
    num2 = _Numeric('2')
    num3 = _Numeric('3')
    num4 = _Numeric('1')
    test_cases = [
        {'num1': num1, 'num2': num2, 'result': False},
        {'num1': num1, 'num2': num3, 'result': False},
        {'num1': num1, 'num2': num4, 'result': True},
        {'num1': num3, 'num2': num4, 'result': True},
    ]

# Generated at 2022-06-23 14:53:12.728434
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert not SemanticVersion('1.2.3') == SemanticVersion('1.2.4')


# Generated at 2022-06-23 14:53:21.317924
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    success = True
    _Alpha = SemanticVersion._Alpha

    # No error should be raised!
    try:
        _Alpha('a').__gt__('a')
    except:
        success = False
    if success:
        print(
            'test_Alpha __gt__: The comparison between two _Alpha objects '
            'with the same value did not raise a ValueError'
        )

    # No error should be raised!
    try:
        _Alpha('a').__gt__('b')
    except:
        success = False
    if success:
        print(
            'test_Alpha __gt__: The comparison between two _Alpha objects '
            'where the first is lexicographically less than the second '
            'did not raise a ValueError'
        )

    # No error should be raised!

# Generated at 2022-06-23 14:53:24.106099
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.1.0')) == 'SemanticVersion(\'0.1.0\')'


# Generated at 2022-06-23 14:53:32.674755
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():

    try:
        assert not _Alpha('1') > '2'
    except:
        return False

    try:
        assert _Alpha('1') > '0'
    except:
        return False

    try:
        assert not _Alpha('1') > '1'
    except:
        return False

    try:
        assert not _Alpha('1') > _Alpha('2')
    except:
        return False

    try:
        assert _Alpha('1') > _Alpha('0')
    except:
        return False

    try:
        assert not _Alpha('1') > _Alpha('1')
    except:
        return False

    return True


# Generated at 2022-06-23 14:53:42.207364
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # string, major, minor, patch, prerelease, buildmetadata
    assert SemanticVersion('1.0.0').core == (1, 0, 0)
    # Prerelease, ignore build metadata
    assert SemanticVersion('1.0.0-rc.1').core == (1, 0, 0)
    assert SemanticVersion('1.0.0-rc.1').prerelease == _Numeric('rc.1')
    # Minor and patch versions MUST be treated as zero when major version is zero
    assert SemanticVersion('0.1.5').core == (0, 1, 5)
    assert SemanticVersion('1.0.0-rc.1').buildmetadata == ()
    assert SemanticVersion('1.0.0+meta').buildmetadata == _Numeric('meta')

# Generated at 2022-06-23 14:53:45.083229
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    string_a = _Alpha('a')
    assert string_a == 'a'
    assert 'a' == string_a
    assert string_a == _Alpha('a')
    assert string_a == _Numeric('a')
    assert string_a == 999
    assert 999 == string_a


# Generated at 2022-06-23 14:53:49.952596
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('2.0.0') > SemanticVersion('1.9.9')
    assert not (SemanticVersion('1.0.0') > SemanticVersion('1.9.9'))


# Generated at 2022-06-23 14:53:51.658573
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('beta')) == repr('beta')


# Generated at 2022-06-23 14:54:01.007195
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('0') == '0'
    assert _Alpha('1') == '1'
    assert _Alpha('a') == 'a'
    assert _Alpha('alpha') == 'alpha'

    assert _Alpha('A') == 'A'
    assert _Alpha('Alpha') == 'Alpha'

    assert _Alpha('1') != '1a'

    assert _Alpha('a') < 'b'
    assert _Alpha('b') > 'a'

    assert _Alpha('a') < '1'
    assert _Alpha('b') > '1'

    assert _Alpha('0') < '1'
    assert _Alpha('0') < '1a'

    assert _Alpha('1a') > '1'

    try:
        _Alpha('a') < 1
        assert False
    except ValueError:
        pass


# Generated at 2022-06-23 14:54:06.523910
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < SemanticVersion('2.0.0')
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0')
    assert (SemanticVersion('1.0.0') < SemanticVersion('2.0.0') and
            SemanticVersion('2.0.0') > SemanticVersion('1.0.0'))

    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0')

# Generated at 2022-06-23 14:54:13.059592
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Method's docstring to be tested
    """
    Method __lt__ of class _Alpha.
    """

    # Code to be tested
    if isinstance(other, _Alpha):
        return self.specifier < other.specifier
    elif isinstance(other, str):
        return self.specifier < other
    elif isinstance(other, _Numeric):
        return False
    raise ValueError


# Generated at 2022-06-23 14:54:19.620699
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a = SemanticVersion("1.2.3")
    b = SemanticVersion("2.2.2")
    c = SemanticVersion("1.3.3")
    d = SemanticVersion("1.2.4")
    assert a <= b == True
    assert a <= c == True
    assert a <= d == True
    assert b <= a == False
    assert c <= a == False
    assert d <= a == False
    assert a <= a == True
    assert b <= b == True
    assert c <= c == True
    assert d <= d == True


# Generated at 2022-06-23 14:54:25.995738
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
     a = _Alpha('a')
     b = _Alpha('b')
     c = _Alpha('1')
     
     result = a < c
     assert True == result, "_Alpha('a') is less than _Alpha('1'), but result was %r" % result

     result = c < b
     assert True == result, "_Alpha('1') is less than _Alpha('b'), but result was %r" % result

     result = a > b
     assert False == result, "_Alpha('a') is not greater than _Alpha('b'), but result was %r" % result




# Generated at 2022-06-23 14:54:31.899097
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a = _Numeric(3)
    b = _Numeric(5)
    c = _Numeric(3)
    d = _Alpha('a')
    try:
        if not (a <= b and a <= c and a <= d):
            return False
    except ValueError:
        return False
    return True


# Generated at 2022-06-23 14:54:35.670482
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('alpha') == _Alpha('alpha')
    assert _Alpha('alpha') == text_type('alpha')
    assert _Alpha('alpha') != _Alpha('beta')
    assert _Alpha('alpha') != text_type('beta')



# Generated at 2022-06-23 14:54:43.109666
# Unit test for constructor of class _Numeric
def test__Numeric():
    num1 = _Numeric(1)
    num2 = _Numeric(3)
    num3 = _Numeric('3')
    num4 = _Numeric(4)
    num5 = _Numeric(4)

    assert num1.specifier == 1
    assert num2.specifier == 3
    assert num3.specifier == 3
    assert num4.specifier == 4
    assert num5.specifier == 4

    assert num1 < num2
    assert num3 == num2
    assert num4 > num2
    assert num5 == num4

    try:
        num1 == num2
    except ValueError:
        pass
    else:
        assert False

    try:
        num1 < num3
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-23 14:54:49.347496
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    # Test if a _Numeric is less than or equal to int
    lower_numeric = _Numeric('1')
    lower_numeric_equal_int = _Numeric('2')
    higher_numeric_int = '3'

    assert lower_numeric <= lower_numeric_equal_int
    assert lower_numeric <= lower_numeric
    assert lower_numeric < higher_numeric_int


# Generated at 2022-06-23 14:54:53.539774
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    n3 = _Numeric(1)
    eq_test1 = n1 == n2
    eq_test2 = n1 == n3
    assert eq_test1 == False, "failed test__Numeric___eq__"
    assert eq_test2 == True, "failed test__Numeric___eq__"
    return True


# Generated at 2022-06-23 14:55:01.460249
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    """
    unit test for method __le__ of class SemanticVersion
    """
    a = SemanticVersion("0.0.0")
    b = SemanticVersion("0.0.0")
    assert a.__le__(b)
    b = SemanticVersion("0.0.0-dev")
    assert a.__le__(b)
    b = SemanticVersion("0.0.1")
    assert a.__le__(b)
    b = SemanticVersion("0.1.0")
    assert a.__le__(b)
    b = SemanticVersion("1.0.0")
    assert a.__le__(b)


# Generated at 2022-06-23 14:55:03.458262
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():

    n = '2'
    a = _Alpha('1')
    assert a >= n == True


# Generated at 2022-06-23 14:55:10.488857
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion("1.0.0") < SemanticVersion("2.0.0")
    assert not SemanticVersion("1.0.0") < SemanticVersion("1.0.0")
    assert not SemanticVersion("2.0.0") < SemanticVersion("1.0.0")
    assert SemanticVersion("1.0.0") < SemanticVersion("1.1.0")
    assert not SemanticVersion("1.1.0") < SemanticVersion("1.0.0")
    assert SemanticVersion("1.1.0") < SemanticVersion("1.2.0")
    assert not SemanticVersion("1.2.0") < SemanticVersion("1.1.0")
    assert SemanticVersion("1.0.0") < SemanticVersion("1.0.1")

# Generated at 2022-06-23 14:55:13.926651
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test empty
    data = []

    for test in data:
        kwargs = test["input"]

        a = _Alpha(**kwargs)
        assert a <= test["expected_output"]


# Generated at 2022-06-23 14:55:22.040356
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Test equal
    assert SemanticVersion('1.2.3') == '1.2.3'
    assert '1.2.3' == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3+metadata')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3-alpha.1+metadata')
    assert SemanticVersion('1.2.3-alpha.1') == SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-23 14:55:25.893442
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    answ = SemanticVersion('1.0.0')
    answ.parse('1.0.0')
    answ.major == 1
    answ.minor == 0
    answ.patch == 0
    answ.prerelease == ()
    answ.buildmetadata == ()


# Generated at 2022-06-23 14:55:34.668227
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.2.3') < SemanticVersion('2.2.3') == True
    assert SemanticVersion('1.2.3') < SemanticVersion('2.2.3') == True
    assert SemanticVersion('1.2.3') < SemanticVersion('1.3.3') == True
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4') == True
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3.0') == True
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3.0.0') == True
    assert SemanticVersion('1.2.3.3') < SemanticVersion('1.2.3.3.3') == True
    assert SemanticVersion

# Generated at 2022-06-23 14:55:39.441727
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert not _Numeric(2) <= _Numeric(1)
    assert not _Numeric(2) <= _Numeric(2)
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 2
    assert not _Numeric(2) <= 1
    assert not _Numeric(2) <= 2


# Generated at 2022-06-23 14:55:41.540889
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') == '1.2.3'


# Generated at 2022-06-23 14:55:52.810141
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric("1") <= _Numeric("1")
    assert _Numeric("1") <= _Numeric("2")
    assert not (_Numeric("2") <= _Numeric("1"))
    assert _Numeric("1") <= "1"
    assert _Numeric("1") <= "2"
    assert not ("2" <= _Numeric("1"))
    assert 1 <= _Numeric("1")
    assert 1 <= _Numeric("2")
    assert not (2 <= _Numeric("1"))
    # unit test for method __le__ of class _Numeric
    def test__Alpha___le__():
        assert _Alpha("a") <= _Alpha("a")
        assert _Alpha("a") <= _Alpha("b")
        assert not (_Alpha("b") <= _Alpha("a"))
        assert _Alpha("a")

# Generated at 2022-06-23 14:56:02.382776
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils._text import to_bytes

    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.1')

    # Test that SemanticVersion is not a subclass of Version
    assert not isinstance(v1, Version)

    # Test that SemanticVersion is a subclass of LooseVersion
    assert isinstance(v1, LooseVersion)

    assert v1 == '1.0.0'
    assert v2 != '1.0.0'

    assert v1 < '1.0.1'
    assert v1 <= '1.0.1'

    assert v2 >= '1.0.0'
    assert v2 > '1.0.0'

   

# Generated at 2022-06-23 14:56:05.468824
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # false positives
    assert not (_Alpha('alpha') > _Alpha('beta'))
    assert not (_Alpha('') > _Alpha('a'))

    # true positives
    assert (_Alpha('beta') > _Alpha('alpha'))
    assert (_Alpha('a') > _Alpha(''))


# Generated at 2022-06-23 14:56:09.324820
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion()
    version.parse('1.2.3')
    assert repr(version) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-23 14:56:14.643448
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    vstring = '1.0.0'
    v = SemanticVersion(vstring)
    assert v.__eq__(vstring) == True
    assert v.__eq__(v) == True
    assert v.__eq__('1.0.1') == False
    assert v.__eq__('1.1.0') == False
    assert v.__eq__('2.0.0') == False


# Generated at 2022-06-23 14:56:25.598398
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():

    # Equality test for str
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert SemanticVersion('2.0.0') != '2.0.1'

    # Equality test for core versions
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('2.0.0') != SemanticVersion('2.0.1')

    # Equality tests for prerelease/buildmetadata
    assert SemanticVersion('1.0.0-rc1') == SemanticVersion('1.0.0-rc1')
    assert SemanticVersion('1.0.0-rc1') == SemanticVersion('1.0.0-alpha')

# Generated at 2022-06-23 14:56:28.646673
# Unit test for constructor of class _Numeric
def test__Numeric():
    try:
        _Numeric('05')
    except ValueError:
        pass
    else:
        raise AssertionError('Expected ValueError')


# Generated at 2022-06-23 14:56:31.624932
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
	assert _Alpha('0') >= _Alpha('0')
	assert _Alpha('0') >= '0'
	assert not _Alpha('1') >= '0'


# Generated at 2022-06-23 14:56:40.558375
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    from nose.tools import assert_equal
    from nose.tools import assert_false
    from nose.tools import assert_true

    # ARRANGE #
    alpha_one = _Alpha('1')
    alpha_one_value_check = '1'
    alpha_one_repr_check = '\'1\''
    alpha_one_eq_check = '1'
    alpha_two = _Alpha('2')
    alpha_two_value_check = '2'
    alpha_two_repr_check = '\'2\''
    alpha_two_eq_check = '2'
    alpha_one_two = _Alpha('1.2')
    alpha_one_two_value_check = '1.2'
    alpha_one_two_repr_check = '\'1.2\''
    alpha_one

# Generated at 2022-06-23 14:56:47.631416
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < 'b'
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('a')
    assert not _Alpha('b') < _Alpha('a')
    assert not _Alpha('b') <= _Alpha('a')


# Generated at 2022-06-23 14:56:49.814054
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('1.0.0')
    assert repr(v) == 'SemanticVersion(\'1.0.0\')'


# Generated at 2022-06-23 14:56:53.749500
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert _Alpha('a') < _Numeric(1)


# Generated at 2022-06-23 14:56:57.820425
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert not _Numeric('2') < _Numeric('1')
    assert _Numeric('1') < _Alpha('2')
    assert not _Alpha('2') < _Numeric('1')



# Generated at 2022-06-23 14:57:01.712419
# Unit test for constructor of class _Numeric
def test__Numeric():
    class_Numeric = _Numeric(123)
    assert class_Numeric.specifier == 123
    # The assertion below will pass under Python 2, but fail under Python 3
    assert isinstance(class_Numeric.specifier, int)
    assert isinstance(class_Numeric.specifier, text_type) == False


# Generated at 2022-06-23 14:57:07.564044
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')

    # Prereleases have lower precedence than the associated normal version
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0-rc.1')
    assert not SemanticVersion('1.0.0-beta.1') <= SemanticVersion('1.0.0')

    # Prereleases with the same version MUST be ordered by their identifier
    # https://semver.org/#spec-item-9
    # Identifiers MUST comprise only ASCII alphanumerics and hyphen [0-9A-Za-z-].
    # Identifiers MUST NOT be empty.
    # Numeric identifiers MUST NOT include leading zeroes.
    # Numeric identifiers MUST precede non-numeric identifiers

# Generated at 2022-06-23 14:57:18.897279
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    assert v1 != v2
    assert v1.__gt__(v2) == False
    assert v1.__ge__(v2) == False
    assert v2.__gt__(v1) == False
    assert v2.__ge__(v1) == False

    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.4')
    assert v1 != v2
    assert v1.__gt__(v2) == False
    assert v1.__ge__(v2) == False
    assert v2.__gt__(v1) == True
    assert v2.__ge__(v1) == True

    v1

# Generated at 2022-06-23 14:57:25.376881
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('1') < _Alpha('3')
    assert _Alpha('3') > _Alpha('1')
    assert _Alpha('v1') > _Alpha('1')
    assert _Alpha('v1') == _Alpha('v1')
    assert not _Alpha('v1') < _Alpha('v1')
    assert not _Alpha('1') > _Alpha('1')
    assert _Alpha('1') != _Alpha('v1')


# Generated at 2022-06-23 14:57:27.022511
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(2)
    b = _Numeric(2)
    assert not a.__ne__(b)


# Generated at 2022-06-23 14:57:37.613367
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():

    # Case 1: the other is not _Numeric and is not int
    other = "string"
    expected = False
    actual = (_Numeric("123")).__eq__(other)
    assert expected == actual

    # Case 2: the other is not _Numeric and is an int
    other = 123
    expected = False
    actual = (_Numeric("123")).__eq__(other)
    assert expected == actual

    # Case 3: the other is _Numeric and it is greater
    other = _Numeric("1234")
    expected = False
    actual = (_Numeric("123")).__eq__(other)
    assert expected == actual

    # Case 4: the other is _Numeric and it is lesser
    other = _Numeric("122")
    expected = False
    actual = (_Numeric("123")).__

# Generated at 2022-06-23 14:57:47.321701
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    from ansible.module_utils.six import PY2
    if PY2:
        n1 = _Numeric(1)
        assert n1.__ne__('') is False
        assert n1.__ne__('2') is True
        assert n1.__ne__(3) is True
        assert n1.__ne__(_Numeric(4)) is True
        assert n1.__ne__(_Numeric(1)) is False
    else:
        n1 = _Numeric(1)
        assert n1.__ne__('') is True
        assert n1.__ne__('2') is True
        assert n1.__ne__(3) is True
        assert n1.__ne__(_Numeric(4)) is True
        assert n1.__ne__(_Numeric(1)) is False

# Generated at 2022-06-23 14:57:52.611702
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    """Unit test for method __gt__ of class _Alpha"""
    # positive tests
    assert _Alpha('1') > _Alpha('0')
    assert _Alpha('a') > _Alpha('A')
    assert _Alpha('1') > _Alpha('0.1')

    # negative tests
    assert not (_Alpha('0') > _Alpha('1'))
    assert not (_Alpha('A') > _Alpha('a'))
    assert not (_Alpha('0.1') > _Alpha('1'))



# Generated at 2022-06-23 14:57:57.341934
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-23 14:58:06.127449
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
        version_a = SemanticVersion('1.0.0')
        version_b = SemanticVersion('1.0.0')

        assert(version_a == version_b)

        version_b = SemanticVersion('1.0.1')

        assert(version_a < version_b)

        version_b = SemanticVersion('2.0.0')

        assert(version_a < version_b)

        version_b = SemanticVersion('0.9.0')

        assert(version_a > version_b)

        version_b = SemanticVersion('1.1.0')

        assert(version_a < version_b)

        version_b = SemanticVersion('0.9.9')

        assert(version_a > version_b)

        # When major, minor, and patch are equal, a pre-

# Generated at 2022-06-23 14:58:14.686560
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3-0.1.2'))
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (0, _Alpha('1'), 2)
    assert version.buildmetadata == ()

    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3+0.1.2'))
    assert version.major == 1
    assert version.minor

# Generated at 2022-06-23 14:58:17.672608
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.1')) == 'SemanticVersion(\'0.0.1\')'


# Generated at 2022-06-23 14:58:20.177605
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    a = _Alpha('foo')
    b = _Alpha(1)
    assert repr(a) == "'foo'"
    assert repr(b) == '1'


# Generated at 2022-06-23 14:58:21.713828
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha("a")) == repr("a")


# Generated at 2022-06-23 14:58:28.273725
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Both Alpha
    assert _Alpha("b") <= _Alpha("b")
    assert _Alpha("b") <= _Alpha("c")
    assert _Alpha("c") <= _Alpha("b") is False
    # Both string
    assert _Alpha("b") <= "b"
    assert _Alpha("b") <= "c"
    assert _Alpha("c") <= "b" is False
    # Alpha vs string
    assert _Alpha("b") <= _Alpha("b")
    assert _Alpha("b") <= "c"
    assert _Alpha("c") <= "b" is False


# Generated at 2022-06-23 14:58:33.722945
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') > _Alpha('0')
    assert _Alpha('1') >= _Alpha('0')
    assert _Alpha('1') >= _Alpha('1')
    assert not _Alpha('0') > _Alpha('1')
    assert not _Alpha('0') >= _Alpha('1')
    assert not _Alpha('0') > _Alpha('0')
    assert _Alpha('0') >= _Alpha('0')


# Generated at 2022-06-23 14:58:37.919031
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('1') == '1'
    assert _Alpha('a') == 'a'
    assert _Alpha('1') == _Alpha('1')
    assert _Alpha('a') == _Alpha('a')
    assert not _Alpha('1') == 'a'
    assert not _Alpha('a') == '1'
    assert not _Alpha('1') == _Alpha('a')
    assert not _Alpha('a') == _Alpha('1')
