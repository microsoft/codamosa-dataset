

# Generated at 2022-06-23 14:48:32.032721
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('foo') <= _Alpha('foo')
    assert not _Alpha('foo') <= _Alpha('bar')
    assert _Alpha('bar') <= _Alpha('foo')


# Generated at 2022-06-23 14:48:35.080111
# Unit test for constructor of class _Alpha
def test__Alpha():
    obj = _Alpha('test')
    assert obj.specifier == 'test'
    obj = _Alpha('')
    assert obj.specifier == ''
    obj = _Alpha('test' * 100)
    assert obj.specifier == 'test' * 100


# Generated at 2022-06-23 14:48:46.187613
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('0.9.4')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha') > SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha') > SemanticVersion('1.0.0-alpha.beta')
    assert SemanticVersion('1.0.0-alpha.beta') > SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha.1') > SemanticVersion('1.0.0-alpha.beta')

# Generated at 2022-06-23 14:48:51.001169
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.0.0').is_stable is True
    assert SemanticVersion('0.2.4').is_stable is False
    assert SemanticVersion('1.2.3-4.5.6').is_stable is False
    assert SemanticVersion('1.2.3-4.5.6+build.metadata').is_stable is False
    assert SemanticVersion('1.2.3-1.5.6').is_stable is False


# Generated at 2022-06-23 14:48:58.291080
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    test_cases = (
        (0, 1, True),
        (1, 0, False),
        (1, 1, True),
        (1, '1', True),
        ('1', 1, True),
        ('1', '1', True),
        ('0', '1', True),
        ('1', '0', False),
    )
    for specifier1, specifier2, expected_result in test_cases:
        numeric1 = _Numeric(specifier1)
        numeric2 = _Numeric(specifier2)
        result = numeric1.__le__(numeric2)
        assert result == expected_result, "Specifier1 {0} <= Specifier2 {1} should be {2} but is {3}".format(specifier1, specifier2, expected_result, result)

# Unit

# Generated at 2022-06-23 14:48:59.971824
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('1') != 1
    assert 1 != _Numeric('1')


# Generated at 2022-06-23 14:49:03.981442
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    """
    Comparing two versions

    Version `1.0.0-alpha.1` is less than `1.0.0-beta.1`
    """


# Generated at 2022-06-23 14:49:05.670375
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.0.0')) == 'SemanticVersion(\'1.0.0\')'


# Generated at 2022-06-23 14:49:07.510475
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Numeric(1)


# Generated at 2022-06-23 14:49:17.893895
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < _Numeric(2.0)
    assert _Numeric(1) < _Numeric('2.0')
    assert _Numeric(1) < _Numeric('2')
    assert _Numeric(1) < _Alpha('2')

    assert not _Numeric(2) < _Numeric(1)
    assert not _Numeric(2) < _Numeric(1.0)
    assert not _Numeric(2) < _Numeric('1.0')
    assert not _Numeric(2) < _Numeric('1')
    assert not _Numeric(2) < _Alpha('1')

    assert not _Numeric(1) < _Numeric(1)
    assert not _Numeric(1) < _

# Generated at 2022-06-23 14:49:28.038720
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('1.2.3') <= _Alpha('1.2.3')
    assert not _Alpha('1.2.3') <= _Alpha('1.2.4')
    assert not _Alpha('1.2.4') <= _Alpha('1.2.3')
    assert _Alpha('1.2.3') <= _Alpha('1.2.3-1')
    assert not _Alpha('1.2.3') <= _Alpha('1.2.3-2')
    assert not _Alpha('1.2.3-2') <= _Alpha('1.2.3')
    assert not _Alpha('1.2.3-beta') <= _Alpha('1.2.3-alpha')
    assert _Alpha('1.2.3-alpha') <= _Alpha('1.2.3-alpha')
    assert _Alpha

# Generated at 2022-06-23 14:49:33.543431
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('aa') < _Alpha('ab')
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('ab') > _Alpha('aa')

    assert _Alpha('a') > _Numeric(1)
    assert _Alpha('1') > _Numeric(1)
    assert _Alpha('1') < _Numeric(2)


# Generated at 2022-06-23 14:49:38.014258
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric('1')
    b = _Numeric('1')

    assert (a >= b) is True
    assert (a <= b) is True
    assert (a == b) is True

    b = _Numeric('2')

    assert (a <= b) is True
    assert (a < b) is True
    assert (a == b) is False
# End of unit test for method __gt__ of class _Numeric



# Generated at 2022-06-23 14:49:40.085196
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('a')
    a_le_a = a <= a
    assert (a_le_a == True)


# Generated at 2022-06-23 14:49:41.966454
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    semver = SemanticVersion('1.0.0')
    assert semver < '1.1.0'


# Generated at 2022-06-23 14:49:51.340159
# Unit test for method __le__ of class SemanticVersion

# Generated at 2022-06-23 14:49:58.974043
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('13') == 13
    assert _Numeric('13') != 12
    assert _Numeric('13') != '13'
    assert _Numeric('12') < '13'
    assert _Numeric('12') < 13
    assert _Numeric('13') <= '13'
    assert _Numeric('13') <= 13
    assert _Numeric('13') > '12'
    assert _Numeric('13') > 12
    assert _Numeric('13') >= '13'
    assert _Numeric('13') >= 13


# Generated at 2022-06-23 14:50:02.959626
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    expected = True

    sv1 = SemanticVersion("10.0.0")
    sv2 = SemanticVersion("9.0.0")
    actual = sv1 >= sv2

    assert actual == expected, "%s != %s" % (actual, expected)



# Generated at 2022-06-23 14:50:09.906297
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Test versions are greater than or equal to
    test_versions = [
        '0.1.1',
        '0.3.1',
        '0.3.3',
        '0.3.7',
        '1.0.0',
        '1.2.0',
        '1.2.11',
        '1.2.12',
    ]

    for test in test_versions:
        assert SemanticVersion(test) > '0.0.0'



# Generated at 2022-06-23 14:50:16.635319
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    versions = [
        (_Numeric(0), _Numeric(0), 0),
        (_Numeric(1), _Numeric(1), 0),
        (_Numeric(0), _Numeric(1), 1),
        (_Numeric(1), _Numeric(0), -1),
    ]

    for (a, b, expected_cmp) in versions:
        if expected_cmp == 0:
            assert a >= b
        if expected_cmp < 0:
            assert a < b
        elif expected_cmp > 0:
            assert a > b


# Generated at 2022-06-23 14:50:21.310008
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha(1) > _Alpha(1)
    assert not _Alpha(1) > _Alpha(2)
    assert _Alpha(2) > _Alpha(1)
    assert _Alpha('1') > _Alpha(1)
    assert _Alpha(1) > _Alpha(0)

    # Should raise ValueError
    try:
        assert _Alpha('a') > 0
    except ValueError:
        pass



# Generated at 2022-06-23 14:50:23.918790
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('alpha') > 'alpha'
    assert _Alpha('alpha') > '1'
    assert _Alpha('alpha') > 1
    assert not (_Alpha('alpha') > 'beta')
    assert not (_Alpha('alpha') > '2')
    assert not (_Alpha('alpha') > 2)


# Generated at 2022-06-23 14:50:27.094787
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(3)
    d = _Numeric(3)
    e = _Numeric(4)
    assert a < b
    assert b < c
    assert c == d
    assert e > c


# Generated at 2022-06-23 14:50:30.375069
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) != _Numeric(2)


# Generated at 2022-06-23 14:50:32.731347
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(0) > _Numeric(1)
    assert _Numeric(0) > 1
    assert _Numeric(0) > _Alpha(1)


# Generated at 2022-06-23 14:50:38.843711
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= 1
    assert not _Numeric(1) >= 2
    assert _Numeric(1) >= _Numeric(1)
    assert not _Numeric(1) >= _Numeric(2)
    # Need to compare against a string to make sure strings work
    assert not _Numeric(1) >= '2'
    # Assertions on raised exceptions
    try:
        _Numeric(1) >= 'a'
        assert False, 'error not raised'
    except ValueError:
        pass



# Generated at 2022-06-23 14:50:46.473626
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('1') <= _Numeric('2')
    assert _Numeric('1') <= _Numeric('1')
    assert _Numeric('1') <= _Alpha('2')
    assert _Numeric('1') <= 1
    assert not _Numeric('1') <= _Alpha('1')
    assert not _Numeric('1') <= 0
    try:
        _Numeric('1') <= None
        assert False
    except:
        pass


# Generated at 2022-06-23 14:50:48.103360
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > 0
    assert _Numeric(1) > _Alpha('0')


# Generated at 2022-06-23 14:50:49.731020
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha('A')
    assert repr(alpha) == "'A'"



# Generated at 2022-06-23 14:50:50.931788
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('a')) == "'a'"



# Generated at 2022-06-23 14:50:57.301544
# Unit test for method __gt__ of class SemanticVersion

# Generated at 2022-06-23 14:51:07.976562
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    # Test for valid version string
    v.parse('1.2.3')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    # Test for version with prerelease
    v.parse('1.2.3-alpha.1')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == (_Alpha('alpha'), _Numeric('1'))
    # Test for version with build metadata
    v.parse('1.2.3+20190101')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.buildmetadata == (_Numeric('20190101'), )
    # Test for version with prerelease and

# Generated at 2022-06-23 14:51:16.581596
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    semver = SemanticVersion()

    # Major Version

    # Major version two (2.y.z). This is a stable version.
    semver.parse('2.1.2')
    assert semver.major == 2

    # Major version one (1.y.z). This is a stable version.
    semver.parse('1.0.0')
    assert semver.major == 1

    # Major version zero (0.y.z) is for initial development. Anything MAY change at any time.
    # The public API SHOULD NOT be considered stable.
    semver.parse('0.1.2')
    assert semver.major == 0

    # Minor Version

    # The minor version Y (x.Y.z | x > 0) MUST be incremented if new, backwards
    # compatible functionality is introduced to the public API.
   

# Generated at 2022-06-23 14:51:19.028672
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("2.0.0")

    assert v2 > v1
    assert v1 < v2


# Generated at 2022-06-23 14:51:21.945660
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    global pkg_version
    pkg_version = SemanticVersion(__version__)

# Generated at 2022-06-23 14:51:31.919212
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # test that it returns True if self is greater or equal to other
    assert SemanticVersion("2.2.2") >= SemanticVersion("2.2.2-1")
    # test that it returns False if self is less than other
    assert not SemanticVersion("2.2.2") >= SemanticVersion("2.2.2-1.0.1")
    # test that it returns True if self is equal to other
    assert SemanticVersion("2.2.2") >= SemanticVersion("2.2.2")
    # Test that it works with build metadata
    assert SemanticVersion("2.2.2+build") >= SemanticVersion("2.2.2")
    # Test that build metadata is ignored when comparing

# Generated at 2022-06-23 14:51:33.083677
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)


# Generated at 2022-06-23 14:51:38.837611
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    ver1 = SemanticVersion("2.0.0-alpha")
    ver2 = SemanticVersion("2.0.0-beta")
    assert ver1.__ne__(ver2)

    ver1 = SemanticVersion("2.0.0")
    ver2 = SemanticVersion("2.0.0-beta")
    assert ver1.__ne__(ver2)

    ver1 = SemanticVersion("2.0.0-beta")
    ver2 = SemanticVersion("2.0.0-beta")
    assert not ver1.__ne__(ver2)


# Generated at 2022-06-23 14:51:46.168243
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # equal
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.0') == False

    # numeric
    assert SemanticVersion('0.0.1') < SemanticVersion('1.0.0') == True

    # numeric
    assert SemanticVersion('0.0.0') < SemanticVersion('1.0.0') == True

    # numeric
    assert SemanticVersion('0.0.0') < SemanticVersion('0.0.1') == True

    # alphanumeric
    assert SemanticVersion('1.0.0-alpha1') < SemanticVersion('1.0.0-rc1') == True
    assert SemanticVersion('1.0.0-alpha1') < SemanticVersion('1.0.0-rc2') == True

    # alphanumeric
    assert Sem

# Generated at 2022-06-23 14:51:56.967847
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Py2
    assert _Alpha('a1') < _Alpha('a2')
    assert _Alpha('a1') < _Alpha('b1')
    assert _Alpha('a1') < _Alpha('a10')
    assert _Alpha('a1') < _Alpha('a1-1')
    assert _Alpha('a1-1') < _Alpha('a1-2')
    assert _Alpha('a1-1') < _Alpha('a2-1')
    assert _Alpha('a1-1') < _Alpha('a1-1-1')

    # Py3
    assert _Alpha('a1') < 'a2'
    assert _Alpha('a1') < 'b1'
    assert _Alpha('a1') < 'a10'
    assert _Alpha('a1') < 'a1-1'
    assert _

# Generated at 2022-06-23 14:51:58.874259
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha("hello-world")
    assert repr(alpha) == "'hello-world'"


# Generated at 2022-06-23 14:52:03.181312
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == 2
    assert not _Numeric(1) == _Numeric(2)
    assert not _Numeric(1) == _Alpha('1')
    assert not _Numeric(1) == _Alpha('2')


# Generated at 2022-06-23 14:52:14.677369
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert (_Numeric('1') < _Numeric('2'))
    assert (_Numeric('1') < _Numeric('10'))
    assert (_Numeric('10') < _Numeric('2'))
    assert (_Numeric('2') < _Numeric('10'))
    assert not (_Numeric('1') < _Numeric('1'))
    assert not (_Numeric('2') < _Numeric('1'))
    assert not (_Numeric('10') < _Numeric('1'))
    assert not (_Numeric('1') < _Alpha('2'))
    assert (_Numeric('1') < _Alpha('20'))
    assert not (_Numeric('10') < _Alpha('2'))
    assert (_Numeric('2') < _Alpha('a'))

# Generated at 2022-06-23 14:52:24.627976
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('beta') > 'alpha'
    assert _Alpha('beta') > 'Beta'
    assert _Alpha('beta') > 'Alpha'
    assert _Alpha('beta') > 'alpha-1'
    assert _Alpha('beta') > 'beta-1'
    assert not _Alpha('beta') > 'beta'
    assert not _Alpha('beta') > 'beta-0'
    assert not _Alpha('beta') > 'beta-1'
    assert not _Alpha('beta') > 'beta2'
    assert not _Alpha('beta') > 'beta2-2'
    assert not _Alpha('beta') > 'rc.1'
    assert not _Alpha('beta') > 'rc.2'
    assert not _Alpha('beta') > None
    assert not _Alpha('beta') > 12345

# Generated at 2022-06-23 14:52:27.085089
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    s = SemanticVersion(vstring="1.0.0")
    assert repr(s) == "SemanticVersion('1.0.0')"



# Generated at 2022-06-23 14:52:31.440705
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    _Alpha.__le__(_Alpha('a'), 'a')
    _Alpha.__le__(_Alpha('a'), 'b')
    _Alpha.__le__(_Alpha('a'), '0')
    _Alpha.__le__(_Alpha(''), '0')
    _Alpha.__le__(_Alpha('a'), 'a')
    _Alpha.__le__(_Alpha('a'), 'a')


# Generated at 2022-06-23 14:52:38.065414
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)

    # Should return True when comparing the same numeric value
    assert n1 == n1
    assert n2 == n2

    # Should return False when comparing different numeric values
    assert n1 != n2

    # Should return True when comparing the same numeric value
    assert n1 == 1
    assert n2 == 2

    # Should return False when comparing different numeric values
    assert n1 != 2
    assert n2 != 1

    # Should return False when comparing a numeric and non-numeric
    # value
    assert n1 != "1"
    assert n2 != "2"

    # Should return False when comparing a numeric to a list
    assert n1 != [1]
    assert n2 != [2]



# Generated at 2022-06-23 14:52:43.165813
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    class_variable_Alpha = _Alpha('1.2.3-a.b+c.d')
    assert class_variable_Alpha < '1.2.3-a.b+c.d'

# Generated at 2022-06-23 14:52:50.044379
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1') == 1
    assert _Numeric('1') != 2
    assert _Numeric('1') != '1'
    assert _Numeric('1') < 2
    assert _Numeric('1') <= 2
    assert _Numeric('1') <= 1
    assert not (_Numeric('1') > 1)
    assert not (_Numeric('1') >= 1)
    assert _Numeric('1') <= '2'
    assert _Numeric('1') <= '1'
    assert not (_Numeric('1') > '1')
    assert not (_Numeric('1') >= '1')


# Generated at 2022-06-23 14:52:58.093231
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == 1
    assert _Numeric('1') == 1
    assert _Numeric(1) == _Numeric('1')
    assert _Numeric(1) < 2
    assert _Numeric(1) < _Numeric('2')
    assert _Numeric(2) > _Numeric('1')
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= _Numeric('1')
    assert _Numeric(1) <= 2
    assert _Numeric(1) <= _Numeric('2')
    assert _Numeric(2) >= _Numeric('1')
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= _Numeric('1')
    assert _Numeric(2) >= _Numeric('1')

# Generated at 2022-06-23 14:53:07.751957
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    def SemanticVersion___eq__(expected_result, version, version2):
        '''
        Method to unit test method __eq__ of class SemanticVersion
        '''
        actual_result = version == version2
        if expected_result != actual_result:
            raise AssertionError(
                "Expected is %s but actual is %s"
                % (expected_result, actual_result)
            )
    # Test case 1
    SemanticVersion___eq__(True,
        SemanticVersion('1.0.0'), '1.0.0'
    )
    # Test case 2
    SemanticVersion___eq__(False,
        SemanticVersion('1.0.0'), '1.0.1'
    )
    # Test case 3

# Generated at 2022-06-23 14:53:14.564866
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Test for issue #55804
    # https://github.com/ansible/ansible/issues/55804
    assert SemanticVersion('2.0.0') < SemanticVersion('2.0.1')
    assert SemanticVersion('2.0.0') < SemanticVersion('2.1.0')
    assert SemanticVersion('2.0.0') < SemanticVersion('3.0.0')
    assert not SemanticVersion('2.0.1') < SemanticVersion('2.0.0')
    assert not SemanticVersion('2.1.0') < SemanticVersion('2.0.0')
    assert not SemanticVersion('3.0.0') < SemanticVersion('2.0.0')

# Generated at 2022-06-23 14:53:18.777700
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == 1
    assert not _Numeric(1) == _Numeric(2)
    assert not _Numeric(1) == 2
    assert not _Numeric(1) == _Alpha(1)
    assert not _Numeric(1) == '1'


# Generated at 2022-06-23 14:53:20.703160
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.2.3")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == "1.2.3"

# Generated at 2022-06-23 14:53:32.238923
# Unit test for method __gt__ of class SemanticVersion

# Generated at 2022-06-23 14:53:34.253434
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert (
        SemanticVersion("1.0.0") ==
        SemanticVersion("1.0.0")
    )


# Generated at 2022-06-23 14:53:42.380849
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != 'a'
    assert _Alpha('a') != _Alpha('a')
    assert _Alpha('a') != _Numeric('a')
    assert _Alpha('a') != _Numeric('1')
    assert not (_Alpha('a') == 'a')
    assert not (_Alpha('a') == _Alpha('a'))
    assert not (_Alpha('a') == _Numeric('a'))
    assert not (_Alpha('a') == _Numeric('1'))
    assert 'a' != _Alpha('a')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'b'


# Generated at 2022-06-23 14:53:47.237298
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.0.0')) == "SemanticVersion('1.0.0')"
    assert repr(SemanticVersion('1.0.0-alpha')) == "SemanticVersion('1.0.0-alpha')"
    assert repr(SemanticVersion('1.0.0+abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc')) == "SemanticVersion('1.0.0+abcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabcabc')"


# Generated at 2022-06-23 14:53:57.692925
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Python 2.7 and 3.5 versions of SemanticVersion.__le__ should
    # return the same results
    from ansible.module_utils.compat.version import LooseVersion

# Generated at 2022-06-23 14:54:00.539396
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) < _Numeric(2)
    assert not (_Numeric(1) > _Numeric(2))
    assert not (_Numeric(1) == _Numeric(2))


# Generated at 2022-06-23 14:54:07.458672
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    s = SemanticVersion(vstring='1.2.3')
    assert s.__ne__(None) == True
    assert s.__ne__('') == True
    assert s.__ne__('1.2.3') == False
    assert s.__ne__('1.2.4') == True
    assert s.__ne__('1.3.3') == True
    assert s.__ne__('2.2.3') == True
    assert s.__ne__('1.2.3-alpha') == True
    assert s.__ne__('1.2.3-alpha.1') == True
    assert s.__ne__('1.2.3+buildmetadata') == True
    assert s.__ne__('1.2.3+buildmetadata.1') == True
    assert s.__ne

# Generated at 2022-06-23 14:54:17.055770
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    s = text_type(type(u'str')())
    v = SemanticVersion(s)
    assert v.vstring is None

    s = text_type(type(u'str')())
    v = SemanticVersion()
    assert v.vstring is None

    s = text_type(type(u'str')())
    v = SemanticVersion(s)
    assert v.vstring is None

    s = text_type(type(u'str')())
    v = SemanticVersion("1.0.0")
    assert v.vstring == "1.0.0"
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()


# Generated at 2022-06-23 14:54:25.854503
# Unit test for constructor of class _Alpha
def test__Alpha():
    class X:
        pass

    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    x = X()
    y = X()

    assert a == 'a'
    assert a != 'b'
    assert a != x
    assert a != y
    assert a < 'b'
    assert a < 'c'
    assert a <= 'b'
    assert a <= 'a'
    assert a > 'a'
    assert a > '0'
    assert a >= 'a'
    assert a >= 'b'

    assert c > 'b'
    assert c >= 'b'
    assert c > 'a'
    assert c >= 'a'
    assert c >= 'c'
    assert c > '0'

    assert '0' < a

# Generated at 2022-06-23 14:54:28.548518
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.15.5') <= '1.15.5'


# Generated at 2022-06-23 14:54:33.238606
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > _Alpha('b')
    assert not (_Alpha('a') > _Alpha('a'))
    assert not (_Alpha('b') > _Alpha('a'))
    assert not (_Alpha('a') > 'a')
    assert not ('a' > _Alpha('a'))


# Generated at 2022-06-23 14:54:37.384951
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # import from current directory
    from ansible.module_utils.semver import SemanticVersion
    version = SemanticVersion('1.0.0')
    assert version >= '1.0.0'



# Generated at 2022-06-23 14:54:47.872609
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Arrange
    # Act
    # Assert
    assert _Alpha('1.1') <= _Alpha('1.1')
    assert _Alpha('1.1') <= _Alpha('1.2')
    assert _Alpha('1.1') <= _Alpha('2')
    assert _Alpha('1.1') <= '1.1'
    assert _Alpha('1.1') <= '1.2'
    assert _Alpha('1.1') <= '2'
    assert _Alpha('1.1') <= 2
    assert _Alpha('1.1') <= 2
    assert not _Alpha('1.1') <= 1
    assert not _Alpha('1.1') <= _Numeric('1')
    assert _Alpha('1.1') <= _Alpha('1.1')

# Generated at 2022-06-23 14:54:54.953358
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion("1.0.0").__ge__("1.0.0") == True
    assert SemanticVersion("1.0.0").__ge__("1.0.0-beta") == True
    assert SemanticVersion("1.0.0-beta").__ge__("1.0.0") == False
    assert SemanticVersion("1.0.1").__ge__("1.0.0") == True
    assert SemanticVersion("1.0.0").__ge__("1.0.1") == False
    assert SemanticVersion("1.1.0").__ge__("1.0.0") == True
    assert SemanticVersion("1.0.0").__ge__("1.1.0") == False

# Generated at 2022-06-23 14:55:02.364618
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('a0')
    assert _Alpha('a') < _Alpha('a9')
    assert _Alpha('a') < _Alpha('a0')
    assert _Alpha('a') < _Alpha('a9')
    assert not _Alpha('a') < _Alpha('a')
    assert not _Alpha('a0') < _Alpha('a')
    assert not _Alpha('a9') < _Alpha('a')
    assert not _Alpha('a0') < _Alpha('a')
    assert not _Alpha('a9') < _Alpha('a')


# Generated at 2022-06-23 14:55:10.341936
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    # Valid semver
    v1 = SemanticVersion('1.0.0')
    assert v1.major == 1
    assert v1.minor == 0
    assert v1.patch == 0
    assert v1.prerelease == ()
    assert v1.buildmetadata == ()
    
    v2 = SemanticVersion('1.2.3')
    assert v2.major == 1
    assert v2.minor == 2
    assert v2.patch == 3
    assert v2.prerelease == ()
    assert v2.buildmetadata == ()

    v3 = SemanticVersion('0.0.0-1.2.3')
    assert v3.major == 0
    assert v3.minor == 0
    assert v3.patch == 0

# Generated at 2022-06-23 14:55:20.084041
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.2.3') >= '1.2.3'
    assert not SemanticVersion('1.2.3-4') >= '1.2.3'
    assert not SemanticVersion('1.2.3-4') >= '1.2.3+build'
    assert SemanticVersion('1.2.3-beta') >= '1.2.3-alpha'
    assert SemanticVersion('1.2.3-beta') >= SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3-beta') >= '1.2.3-1'
    assert SemanticVersion('1.2.3-beta') >= '1.2.3-a'
    assert SemanticVersion('1.2.3-beta') >= '1.2.3-9'


# Generated at 2022-06-23 14:55:23.000018
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('b')
    assert _Alpha('a') >= _Alpha('a')


# Generated at 2022-06-23 14:55:24.268171
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert (_Alpha('preview') != 'preview') is False


# Generated at 2022-06-23 14:55:26.341705
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('a')
    b = _Alpha('b')
    assert (a < b) is True
    assert (a == b) is False
    assert (a > b) is False
    assert (a <= b) is True
    assert (a >= b) is False


# Generated at 2022-06-23 14:55:35.041355
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():

    # lhs is class instance
    obj = _Alpha('test')
    lhs = obj
    # rhs is class instance
    obj = _Alpha('test')
    rhs = obj

    assert(lhs == rhs)
    if lhs != rhs:
        raise AssertionError('%r != %r' % (lhs, rhs))
    assert(not bool(lhs != rhs))

    # lhs is class instance
    obj = _Alpha('test')
    lhs = obj
    # rhs is class instance
    obj = _Alpha('test1')
    rhs = obj

    assert(lhs != rhs)
    if lhs == rhs:
        raise AssertionError('%r == %r' % (lhs, rhs))
    assert(bool(lhs != rhs))

# Generated at 2022-06-23 14:55:37.333807
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('1.0') == _Alpha('1.0')
    assert _Alpha('1.0') != _Alpha('2.0')
    assert _Alpha('1.0') != '2.0'


# Generated at 2022-06-23 14:55:43.513956
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('a') > _Numeric(1)
    assert _Alpha('b') > 'a'
    assert _Alpha('a') > 1
    assert not _Alpha('b') < _Alpha('a')
    assert not _Alpha('a') < _Numeric(1)
    assert not _Alpha('b') < 'a'
    assert not _Alpha('a') < 1

    try:
        _Alpha('b') > 'bb'
    except ValueError:
        pass
    else:
        assert False

    try:
        _Alpha('a') > 'b'
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-23 14:55:46.152036
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alphaA = _Alpha('a')
    alphaB = _Alpha('b')
    assert alphaA.__gt__(alphaB)
    assert alphaA.__gt__('b')


# Generated at 2022-06-23 14:55:55.697054
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('0') < _Numeric('1') is True
    assert _Numeric('1') < _Numeric('1') is False
    assert _Numeric('2') < _Numeric('1') is False
    # And now the same with strings
    assert _Numeric('0') < '1' is True
    assert _Numeric('1') < '1' is False
    assert _Numeric('2') < '1' is False
    # And now with ints
    assert _Numeric('0') < 1 is True
    assert _Numeric('1') < 1 is False
    assert _Numeric('2') < 1 is False


# Generated at 2022-06-23 14:55:58.227584
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    instance = SemanticVersion('0.0.0')
    expected = 'SemanticVersion(\'0.0.0\')'
    assert repr(instance) == expected



# Generated at 2022-06-23 14:56:06.380549
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(1)
    d = _Alpha(1)
    if not (a < b):
        raise AssertionError
    if not (a <= b):
        raise AssertionError
    if not (b > a):
        raise AssertionError
    if not (b >= a):
        raise AssertionError
    if not (a == c):
        raise AssertionError
    if not (a <= c):
        raise AssertionError
    if not (a >= c):
        raise AssertionError
    if a != c:
        raise AssertionError
    if a < d:
        raise AssertionError
    if not (a <= d):
        raise AssertionError

# Generated at 2022-06-23 14:56:08.508036
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    n = _Numeric(10)
    assert repr(n) == '10'


# Generated at 2022-06-23 14:56:13.725558
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Check a < b
    a = _Alpha('a')
    b = _Alpha('b')
    assert a < b

    # Check a < a
    a = _Alpha('a')
    assert not (a < a)

    # Check a < 1
    a = _Alpha('a')
    b = _Numeric('1')
    assert not (a < b)



# Generated at 2022-06-23 14:56:24.624746
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion('0.1.0')
    v2 = SemanticVersion('0.1.1')
    v3 = SemanticVersion('0.1.1-beta')
    v4 = SemanticVersion('0.1.1-beta+a.b.c.d')
    v5 = SemanticVersion('0.1.1+a.b.c.d')
    v6 = SemanticVersion('0.2.0')
    v7 = SemanticVersion('1.0.0')
    v8 = SemanticVersion('1.0.0-beta.1')
    v9 = SemanticVersion('1.0.0-beta.2')
    v10 = SemanticVersion('1.0.0-beta.11')

# Generated at 2022-06-23 14:56:35.298750
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0')
    assert SemanticVersion('1.1.0') < SemanticVersion('1.1.1')
    assert SemanticVersion('1.1.1') < SemanticVersion('2.0.0')
    assert SemanticVersion('2.0.0') < SemanticVersion('2.1.0')
    assert SemanticVersion('2.1.0') < SemanticVersion('2.1.1')
    assert SemanticVersion('2.1.1') < SemanticVersion('3.0.0')

    assert SemanticVersion('1.0.0') < SemanticVersion('2.0.0')  # short circuit
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0')  # short circuit

# Generated at 2022-06-23 14:56:36.223017
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('2') > _Numeric('1')


# Generated at 2022-06-23 14:56:39.157857
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('2.0.0')
    assert v2 > v1
    assert not v1 > v2
    assert not v1 > v1


# Generated at 2022-06-23 14:56:49.708654
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha.1') > SemanticVersion('1.0.0-alpha.beta')
    assert SemanticVersion('1.0.0-alpha.1') > SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha.1') > SemanticVersion('1.0.0-alpha.0')
    assert SemanticVersion('1.0.0-alpha.1') > SemanticVersion('1.0.0-0.3.7')

# Generated at 2022-06-23 14:56:53.607213
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0-rc.2')
    assert v1 >= v2



# Generated at 2022-06-23 14:56:54.888605
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('5')) == repr(5)


# Generated at 2022-06-23 14:56:59.659404
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')

    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'b'
    assert 'a' != _Alpha('b')



# Generated at 2022-06-23 14:57:06.257764
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Tests the SemanticVersion class, with a call to method __lt__

    # version1 must be < version2
    # version1, version2: SemanticVersion
    # <return_value>: bool

    # test 1
    version1 = SemanticVersion("3.2.1-alpha.2+meta")
    version2 = SemanticVersion("3.2.1")
    return_value = version1 < version2
    print("return_value: %s" % return_value)

    # test 2
    version1 = SemanticVersion("3.2.1-alpha.2")
    version2 = SemanticVersion("3.2.1-alpha.7")
    return_value = version1 < version2
    print("return_value: %s" % return_value)

    # test 3
    version1 = SemanticVersion

# Generated at 2022-06-23 14:57:17.061845
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # Tests for spec 4.1
    # N.B. This should fail because the version is not compliant with spec
    # 4.1.1 and 4.1.2
    # TODO: This should really raise an exception!
    assert SemanticVersion("1.1.1") == SemanticVersion("1.1.1")

    # Test for spec 4.2.3
    assert SemanticVersion("1.1.1") == SemanticVersion("1.1.1+build.1")

    # Test for spec 4.3.1
    assert SemanticVersion("1.1.1") != SemanticVersion("1.1.1-alpha.1")
    assert SemanticVersion("1.1.1") > SemanticVersion("1.1.1-alpha.1")

# Generated at 2022-06-23 14:57:27.270121
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    from . import module_utils_common

    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.2')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.3-0.3.7')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.3-beta.11')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.3-beta.1')

# Generated at 2022-06-23 14:57:33.767619
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    SemanticVersion("2.0.0") >= SemanticVersion("2.0.0")
    SemanticVersion("2.0.0") >= SemanticVersion("1.0.0")
    SemanticVersion("2.0.0") >= SemanticVersion("2.0.0-rc.1")
    SemanticVersion("2.0.0") >= SemanticVersion("2.0.0+build.1")
    SemanticVersion("2.0.0") >= SemanticVersion("2.0.0-rc.1+build.1")


# unit test for method __gt__ of class SemanticVersion

# Generated at 2022-06-23 14:57:41.553759
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.0.0')
    assert SemanticVersion('0.2.4')
    assert SemanticVersion('1.2.3-prerelease+buildmetadata')
    assert SemanticVersion('1.2.3-prerelease+buildmetadata.1.2.3')
    assert SemanticVersion('1.2.3-prerelease+buildmetadata.1.2.3-prerelease+b.1-prerelease.2+build')
    assert SemanticVersion('1.2.3-prerelease+buildmetadata-prerelease.1.2.3-prerelease+b.1-prerelease.2+build')


# Generated at 2022-06-23 14:57:50.083071
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('a') >= _Alpha('1')
    assert _Alpha('1') >= '1'
    assert _Alpha('a') >= '1'
    assert _Alpha('a') >= '1'
    assert not _Alpha('a') >= 'b'
    assert not _Alpha('1') >= _Alpha('a')
    assert not _Alpha('1') >= _Alpha('b')
    assert _Alpha('abc') >= _Alpha('abc')
    assert _Alpha('abc') >= _Alpha('ab')
    assert _Alpha('abcd') >= _Alpha('abc')
    assert _Alpha('abcd') >= _Alpha('abb')
    assert not _Alpha('abcd') >= _Alpha('abce')
    assert not _Alpha('abcd') >= _Alpha('bcde')


# Generated at 2022-06-23 14:57:53.914955
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("alpha") >= "alpha"
    assert _Alpha("alpha") >= _Alpha("alpha")
    assert not _Alpha("alpha") >= "beta"
    assert not _Alpha("alpha") >= _Alpha("beta")
    assert not _Alpha("alpha") >= 1
    assert not _Alpha("alpha") >= _Numeric(1)


# Generated at 2022-06-23 14:57:58.428459
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    number = _Numeric(4)
    assert number.__ne__(5)
    assert not number.__ne__(4)
    assert number.__ne__('a')
    assert not number.__ne__(text_type(4))


# Generated at 2022-06-23 14:58:02.070005
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1='2.0.5'
    v2='2.0.5'
    assert SemanticVersion(v1) >= SemanticVersion(v2)
    assert SemanticVersion(v1) >= v2


# Generated at 2022-06-23 14:58:05.658734
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    values = [("0.0.0", "0.0.0"),
              (b"0.0.0", "0.0.0"),
              (u"0.0.0", "0.0.0")]
    for inp, expected in values:
        assert SemanticVersion(inp).vstring == expected


# Generated at 2022-06-23 14:58:14.616823
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.2') == SemanticVersion('1.2.0')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3-alpha.1') == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3-alpha.1').prerelease == ('alpha', '1')

# Generated at 2022-06-23 14:58:25.263345
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0')
    v3 = SemanticVersion('1.0.0-alpha.1')
    v4 = SemanticVersion('1.0.0-alpha.2')
    v5 = SemanticVersion('1.0.0+build01')
    v6 = SemanticVersion('1.0.0+build02')

    # Test equality of core versions
    assert v1 == v2
    assert v1 == '1.0.0'
    assert '1.0.0' == v1

    assert v1 != v3
    assert v3 != v1
    assert v1 != '1.0.0-alpha.1'
    assert '1.0.0-alpha.1' != v1

    assert v

# Generated at 2022-06-23 14:58:35.520178
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(0) <= _Numeric(0)
    assert _Numeric(0) <= _Numeric(1)
    assert _Numeric(0) <= _Numeric("0")
    assert _Numeric(0) <= _Numeric("1")
    assert _Numeric(0) <= 0
    assert _Numeric(0) <= 1
    assert not _Numeric(1) <= _Numeric(0)
    assert not _Numeric(1) <= _Numeric("0")
    assert not _Numeric("1") <= _Numeric(0)
    assert not _Numeric("1") <= _Numeric("0")
    assert not _Numeric(1) <= 0
    assert not _Numeric(1) <= 1
    assert _Numeric("a0") <= _Numeric("a0")