

# Generated at 2022-06-21 09:17:05.842941
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == _Alpha('a')
    assert not _Alpha('a') == _Alpha('b')
    assert not _Alpha('a') == _Numeric('a')
    assert not _Alpha('a') == 1
    assert not _Alpha('a') == '1'
    assert not _Alpha('a') == _Numeric(1)


# Generated at 2022-06-21 09:17:08.931494
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('0') >= _Numeric('0')
    assert _Numeric('0') >= _Alpha('0')
    assert _Numeric('1') >= _Alpha('0')

    with pytest.raises(ValueError):
        _Numeric('0') >= _Alpha('1')



# Generated at 2022-06-21 09:17:19.842962
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('0.0.1') <= SemanticVersion('0.0.2') is True
    assert SemanticVersion('0.0.1') <= SemanticVersion('0.0.1') is True
    assert SemanticVersion('0.0.2') <= SemanticVersion('0.0.1') is False
    assert SemanticVersion('0.0.1') <= SemanticVersion('0.1.0') is True
    assert SemanticVersion('0.1.2') <= SemanticVersion('0.1.2') is True
    assert SemanticVersion('0.1.2') <= SemanticVersion('0.1.10') is True
    assert SemanticVersion('1.1.2') <= SemanticVersion('1.1.2') is True

# Generated at 2022-06-21 09:17:23.912136
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) > 1
    assert not _Numeric(1) > _Numeric(1)
    assert not _Numeric(1) > 2


# Generated at 2022-06-21 09:17:30.279885
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-21 09:17:40.470937
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('1.2.3-alpha.1+123')
    v2 = '1.2.3-alpha.1'
    v3 = '1.2.3'
    v4 = '1.2.4'
    v5 = SemanticVersion('1.2.4-alpha.1')
    v6 = SemanticVersion('1.2.3-alpha.1')
    v7 = SemanticVersion('1.2.3')
    v8 = SemanticVersion('2.2.3')
    v9 = SemanticVersion('1.3.3')
    v10 = SemanticVersion('1.2.4-alpha.2')
    v11 = SemanticVersion('1.2.4-alpha.2+123')

# Generated at 2022-06-21 09:17:43.502394
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # Create an instance of class SemanticVersion
    sv = SemanticVersion('1.2.3')
    assert repr(sv) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-21 09:17:49.109330
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2) is True
    assert _Numeric(1) < _Numeric(1) is False
    assert _Numeric(2) < _Numeric(1) is False
    assert _Numeric(1) < 2 is True
    assert _Numeric(1) < 1 is False
    assert _Numeric(2) < 1 is False


# Generated at 2022-06-21 09:17:50.603333
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    x = _Alpha(specifier="1")
    assert repr(x) == "'1'"



# Generated at 2022-06-21 09:17:52.224056
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.2.3') != '1.2.3'
test_SemanticVersion___ne__()



# Generated at 2022-06-21 09:18:07.415596
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    """
    @Assert: Less than (numeric) is implemented
    @Status: Manual
    """
    num1 = _Numeric(1)
    num2 = _Numeric(2)
    assert num2 < 3, "Numeric with value 2 is not less than 3"
    assert num1 < 2, "Numeric with value 1 is not less than 2"
    assert not num1 < 1, "Numeric with value 1 is less than 1"
    assert num1 < 2, "Numeric with value 1 is not less than 2"
    assert num2 < num1, "Numeric with value 2 is not less than numeric with value 1"
    assert num1 < num2, "Numeric with value 1 is not less than numeric with value 2"


# Generated at 2022-06-21 09:18:15.768792
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # Unit test for method __ge__ of class SemanticVersion
    v1 = SemanticVersion('1.0.0')
    assert v1 >= Version('1.0.0')
    assert v1 >= '1.0.0'
    assert v1 >= (1, 0, 0)
    assert v1 >= '1.0.0'
    assert v1 >= SemanticVersion('1.0.0')
    assert not v1 >= '2.0.0'
    assert not v1 >= (2, 0, 0)
    assert not v1 >= SemanticVersion('2.0.0')
    assert not v1 >= '2'
    assert not v1 >= 2
    assert not v1 >= SemanticVersion(2)
    assert not v1 >= (1, 0, 1)

# Generated at 2022-06-21 09:18:21.856297
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    print("Testing method __eq__ of class _Numeric")

    a = _Numeric(1)
    # Compare integer to numeric
    assert a == 1

    b = _Numeric(1)
    # Compare numeric to numeric
    assert a == b

    c = _Alpha('1')
    # Compare numeric to alpha
    assert not a == c


# Generated at 2022-06-21 09:18:25.817683
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    x = _Alpha('foo')
    y = _Alpha(123)

    assert isinstance(x.__repr__(), str)
    assert x.__repr__() == "'foo'"
    assert isinstance(y.__repr__(), str)
    assert y.__repr__() == "123"



# Generated at 2022-06-21 09:18:31.141485
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    test_object = _Alpha('test string')

    # Test that not equal
    assert test_object.__ge__('different string') == False, \
        'Test __ge__ method of class _Alpha - not equal case'

    # Test that equal
    assert test_object.__ge__('test string') == True, \
        'Test __ge__ method of class _Alpha - equal case'


# Generated at 2022-06-21 09:18:34.181287
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion("1.2.3-pre.1+meta")
    assert v1 >= "1.2.3-pre.1+meta" is True


# Generated at 2022-06-21 09:18:41.041860
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    test_cases = [
        ({'name': '1.1', 'result': False}, {'name': 'a.a'}),
        ({'name': '1.1', 'result': True}, {'name': '2'}),
        ({'name': 'a.a', 'result': True}, {'name': '2'}),
        ({'name': '1.1', 'result': True}, {'name': '2.2'}),
        ({'name': '1.1', 'result': False}, {'name': '1.0'}),
    ]

    for test in test_cases:
        a = _Numeric(test[0]['name'])
        b = _Numeric(test[1]['name'])
        # print(test[0]['name'], ">=", test

# Generated at 2022-06-21 09:18:52.415931
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test passing proper types
    SemanticVersion.from_loose_version(LooseVersion('1.0'))
    SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    SemanticVersion.from_loose_version(LooseVersion('1.1.1'))

    # Test where the core version is not an integer
    def test_invalid_loose_version():
        SemanticVersion.from_loose_version(LooseVersion('1.0.0.bad'))
    assert test_invalid_loose_version()

    # Test with prerelease
    SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha1'))

# Generated at 2022-06-21 09:18:55.626700
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.0.1') >= '1.0.0'
    assert not SemanticVersion('1.0.0') >= '1.0.1'


# Generated at 2022-06-21 09:19:01.908541
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert(SemanticVersion('1.2.4').major == 1)
    assert(SemanticVersion('1.2.4').minor == 2)
    assert(SemanticVersion('1.2.4').patch == 4)
    assert(SemanticVersion('1.2.4').prerelease == ())
    assert(SemanticVersion('1.2.4').buildmetadata == ())

    assert(SemanticVersion('1.2.4-alpha').prerelease == (_Alpha('alpha'),))
    assert(SemanticVersion('1.2.4+build.3').buildmetadata == (_Numeric('3'),))

    assert(SemanticVersion('1.2.4-alpha.1').prerelease == (_Alpha('alpha'), _Numeric('1')))

# Generated at 2022-06-21 09:19:18.586170
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') >= 'b'
    assert _Alpha('a') >= _Alpha('a')
    assert not _Alpha('a') >= _Alpha('b')
    assert not _Alpha('a') > 'a'
    assert _Alpha('a') > 'b'
    assert not _Alpha('a') > _Alpha('a')
    assert _Alpha('a') > _Alpha('b')



# Generated at 2022-06-21 09:19:20.987065
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"



# Generated at 2022-06-21 09:19:32.218031
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    print("Test __le__")
    v1 = SemanticVersion("1.2.3")
    v2 = SemanticVersion("1.2.3")
    assert v1 <= v2
    v1 = SemanticVersion("1.2.3-1")
    v2 = SemanticVersion("1.2.3-1")
    assert v1 <= v2
    v1 = SemanticVersion("1.2.3-1")
    v2 = SemanticVersion("1.2.3-2")
    assert v1 <= v2
    v1 = SemanticVersion("1.2.3-a.b")
    v2 = SemanticVersion("1.2.3-c.d")
    assert v1 <= v2
    print("Done")


# Generated at 2022-06-21 09:19:33.806696
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('10000.0.19') > SemanticVersion('1.0.19')


# Generated at 2022-06-21 09:19:40.642418
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # All equal
    assert SemanticVersion("1.2.3") <= SemanticVersion("1.2.3")
    # Compare alphanumeric prereleases
    assert SemanticVersion("1.0.0-alpha.1") <= SemanticVersion("1.0.0-alpha.x")
    assert SemanticVersion("1.0.0-alpha.x") <= SemanticVersion("1.0.0-alpha.1x")
    assert SemanticVersion("1.0.0-alpha.1") <= SemanticVersion("1.0.0-alpha.1")
    assert SemanticVersion("1.0.0-alpha.1") <= SemanticVersion("1.0.0-alpha.x")

# Generated at 2022-06-21 09:19:50.006929
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    # Test for int
    assert _Numeric(9999) >= 1, "Test _Numeric operator >= int : failed"
    assert _Numeric(1) >= 1, "Test _Numeric operator >= int : failed"
    assert not _Numeric(0) >= 1, "Test _Numeric operator >= int : failed"

    # Test for _Alpha
    assert not _Numeric('0') >= _Alpha('1'), "Test _Numeric operator >= _Alpha : failed"
    assert not _Numeric('1') >= _Alpha('1'), "Test _Numeric operator >= _Alpha : failed"
    assert not _Numeric('1') >= _Alpha('a'), "Test _Numeric operator >= _Alpha : failed"


# Generated at 2022-06-21 09:19:52.742036
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    a = SemanticVersion('1.2.3')
    expected = "SemanticVersion('1.2.3')"
    assert a.__repr__() == expected


# Generated at 2022-06-21 09:19:54.934296
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(3) >= _Numeric(3)


# Generated at 2022-06-21 09:19:59.922115
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    class A:
        def __init__(self, v):
            self.a = v

    class B:
        def __init__(self, v):
            self.a = v

    assert _Numeric('0') == 0
    assert _Numeric('1') != '0'
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('0') != A(0)
    assert _Numeric('0') != B(0)



# Generated at 2022-06-21 09:20:01.621081
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    v1 = _Numeric('1')
    v2 = _Numeric('2')
    assert v1 >= v2 is False


# Generated at 2022-06-21 09:20:09.167304
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr( _Alpha('1.0.1') ) == repr('1.0.1')
    assert repr( _Alpha('alpha') ) == repr('alpha')
    assert repr( _Alpha('') ) == repr('')
    assert repr( _Alpha(None) ) == repr(None)


# Generated at 2022-06-21 09:20:10.173611
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == '1'


# Generated at 2022-06-21 09:20:14.505729
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    # Try not to be too odd
    assert SemanticVersion('0.0.0') != '0'
    assert SemanticVersion('1.0.0') != '0.0.0'
    assert SemanticVersion('0.0.0+test') != SemanticVersion('0.0.0+test')
    assert SemanticVersion('1.0.0') != SemanticVersion('0.0.0')
    assert SemanticVersion('1.0.0') != SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha') != SemanticVersion('1.0.0')


# Generated at 2022-06-21 09:20:20.134853
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= 2
    assert not _Numeric(1) >= _Alpha('a')
    assert not _Numeric(1) >= 'a'


# Generated at 2022-06-21 09:20:21.934923
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2') == True


# Generated at 2022-06-21 09:20:32.388791
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(9) < _Numeric(10)

    assert _Numeric(0) < _Alpha('a')
    assert _Numeric(1) < _Alpha('b')
    assert _Numeric(9) < _Alpha('a')

    assert not _Numeric(0) < _Numeric(0)
    assert not _Numeric(1) < _Numeric(1)
    assert not _Numeric(9) < _Numeric(9)

    assert _Numeric(0) < 0
    assert _Numeric(1) < 1
    assert _Numeric(9) < 9


# Generated at 2022-06-21 09:20:35.291398
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('1') != 1
    assert 1 != _Numeric('1')
    assert _Numeric('1') != _Alpha('1')
    assert _Alpha('1') != _Numeric('1')


# Generated at 2022-06-21 09:20:41.563690
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('abc') < _Alpha('bcd')
    assert _Alpha('bcd') > _Alpha('abc')
    assert _Alpha('bcd') > _Alpha('18f')
    assert _Alpha('bcd') == _Alpha('bcd')
    assert _Alpha('bcd') != _Alpha('ABC')
    assert _Alpha('bcd') != 'bcd'
    assert _Alpha('bcd') > 'abc'
    assert _Alpha('bcd') > '18f'


# Generated at 2022-06-21 09:20:45.988634
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    item = _Alpha('1')
    assert item >= _Alpha(1)
    assert item >= '1'
    assert item <= _Alpha(1)
    assert item <= '1'
    assert item == _Alpha(1)
    assert item == '1'


# Generated at 2022-06-21 09:20:52.527454
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    vstring = '2.1.1'
    v = SemanticVersion()
    v.parse(vstring)
    assert v.major == 2
    assert v.minor == 1
    assert v.patch == 1
    assert v.prerelease == ()
    assert v.buildmetadata == ()
    assert v.vstring == vstring

    vstring = '2.1.1-alpha+3f3f3f3f'
    v = SemanticVersion()
    v.parse(vstring)
    assert v.major == 2
    assert v.minor == 1
    assert v.patch == 1
    assert v.prerelease == ('alpha',)
    assert v.buildmetadata == ('3f3f3f3f',)
    assert v.vstring == vstring


# Generated at 2022-06-21 09:21:08.961658
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion("1.3.3") != "2.3.3"
    assert SemanticVersion("1.3.3") != SemanticVersion("2.3.3")
    assert not (SemanticVersion("1.3.3") != SemanticVersion("1.3.3"))


# Generated at 2022-06-21 09:21:13.257804
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == 1
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') != _Alpha('1')
    assert _Numeric('1') != '1.0'


# Generated at 2022-06-21 09:21:15.795613
# Unit test for constructor of class _Alpha
def test__Alpha():
    # Test with int
    result = _Alpha(1)
    assert result.specifier == 1
    # Test with string
    result = _Alpha('A')
    assert result.specifier == 'A'
    #Test with float
    result = _Alpha(1.0)
    assert result.specifier == 1.0

# Generated at 2022-06-21 09:21:25.095240
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.11.0')) == SemanticVersion('1.11.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.11.0+abcdefg')) == SemanticVersion('1.11.0+abcdefg')
    assert SemanticVersion.from_loose_version(LooseVersion('1.11.0-1.0')) == SemanticVersion('1.11.0-1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.11.0-1.0.dev')) == SemanticVersion('1.11.0-1.0.dev')

# Generated at 2022-06-21 09:21:27.669845
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion('1.2.3').__repr__() == "SemanticVersion('1.2.3')"



# Generated at 2022-06-21 09:21:30.112481
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-21 09:21:36.632944
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    v = _Numeric(1)
    assert v.__eq__(1) is True, '_Numeric(1).__eq__(1) should return True but it returned {}'.format(v.__eq__(1))
    assert v.__eq__(_Numeric(1)) is True, '_Numeric(1).__eq__(_Numeric(1)) should return True but it returned {}'.format(v.__eq__(_Numeric(1)))
    assert v.__eq__(_Numeric(2)) is False, '_Numeric(1).__eq__(_Numeric(2)) should return False but it returned {}'.format(v.__eq__(_Numeric(2)))



# Generated at 2022-06-21 09:21:41.704349
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > 0
    assert _Numeric(1) > _Alpha('0')
    assert not _Numeric(1) > 1
    assert not _Numeric(1) > _Alpha('1')
    assert not _Numeric(1) > _Numeric(2)


# Generated at 2022-06-21 09:21:44.500294
# Unit test for constructor of class _Numeric
def test__Numeric():
    i1 = _Numeric(42)
    i2 = _Numeric('42')
    i3 = _Numeric(43)
    assert i1 == i2
    assert i1 < i3


# Generated at 2022-06-21 09:21:55.434199
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # test Version
    v = SemanticVersion('1.0.0')
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()
    assert str(v) == '1.0.0'

    # test Version
    v = SemanticVersion('1.0.0+ssss')
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ('ssss',)
    assert str(v) == '1.0.0+ssss'

    # test Version
    v = SemanticVersion('1.0.0-prerelease')
    assert v.major == 1
    assert v.min

# Generated at 2022-06-21 09:22:30.965972
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(0) > _Numeric(0)
    assert _Numeric(0) > _Numeric(-1)
    assert _Numeric(0) > _Numeric(-10)
    assert _Numeric(0) > _Numeric(-100)

    assert _Numeric(-1) > _Numeric(-1)
    assert _Numeric(-1) > _Numeric(-10)
    assert _Numeric(-1) > _Numeric(-100)

    assert _Numeric(-10) > _Numeric(-10)
    assert _Numeric(-10) > _Numeric(-100)

    assert _Numeric(-100) > _Numeric(-100)


# Generated at 2022-06-21 09:22:42.849409
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-21 09:22:45.627192
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('a')
    assert not _Alpha('a') <= _Alpha('A')


# Generated at 2022-06-21 09:22:52.215259
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion("2.2.2") > SemanticVersion("2.2.1")
    assert SemanticVersion("2.2.1") < SemanticVersion("2.2.2")
    assert SemanticVersion("2.2.2") > SemanticVersion("2.2.1")
    assert SemanticVersion("1.2.3a") < SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3") > SemanticVersion("1.2.3a")
    assert SemanticVersion("1.2.3a") < SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3") > SemanticVersion("1.2.3a")
    assert SemanticVersion("2.2.2") > SemanticVersion("2.2.1")
    assert Sem

# Generated at 2022-06-21 09:22:55.867591
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    method = _Alpha('foo').__repr__
    assert method() == "'foo'"
    assert method() == repr(_Alpha('foo'))
