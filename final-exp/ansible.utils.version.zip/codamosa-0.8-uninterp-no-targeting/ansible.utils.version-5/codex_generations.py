

# Generated at 2022-06-21 09:17:07.336433
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('abc') < _Alpha('xyz')
    assert _Alpha('abc') < 'xyz'
    assert not _Alpha('xyz') < 'abc'
    assert _Alpha('abc') < _Numeric('123')
    assert not _Alpha('abc') < _Numeric('456')
    try:
        _Alpha('abc') < _Alpha('123')
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-21 09:17:09.257787
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('1') != _Numeric('2')
    assert _Numeric('1') != 2


# Generated at 2022-06-21 09:17:20.643288
# Unit test for method __gt__ of class _Numeric

# Generated at 2022-06-21 09:17:25.182973
# Unit test for constructor of class _Numeric
def test__Numeric():
    num_obj_1 = _Numeric('1')
    assert num_obj_1.specifier == 1

    num_obj_1a = _Numeric(1)
    assert num_obj_1a.specifier == 1

    # Test inequality
    assert num_obj_1 != '1'



# Generated at 2022-06-21 09:17:26.874723
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    alpha1 = _Alpha("abc")
    alpha2 = _Alpha("abc")
    assert alpha1 != alpha2


# Generated at 2022-06-21 09:17:32.270135
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # Test the case where the two values are equal
    x = _Alpha('foo')
    y = _Alpha('foo')
    assert not x > y

    # Test the case where x > y
    x = _Alpha('foo')
    y = _Alpha('bar')
    assert x > y

    # Test the case where x < y
    x = _Alpha('bar')
    y = _Alpha('foo')
    assert not x > y



# Generated at 2022-06-21 09:17:41.708010
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a1 = _Alpha(specifier='test')
    a2 = _Alpha(specifier='test')
    a3 = _Alpha(specifier='test2')
    a4 = _Alpha(specifier='test1')
    assert a1 >= a2 and a2 >= a1 and a2 >= a2
    assert a1 >= 'test' and 'test' >= a1
    assert a1 >= a4 and a4 <= a1
    assert a4 <= 'test1' and 'test1' >= a4
    assert a1 <= a3 and a3 >= a1
    assert a1 >= 'test2' and 'test' <= a3
    assert a3 >= 'test' and a3 >= 'test1'
    assert a3 >= 0 and a3 >= 1


# Generated at 2022-06-21 09:17:51.383905
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.semver import SemanticVersion, SemanticVersionMatcher

    module = AnsibleModule(argument_spec=dict(
        _raw_params=dict(required=False, type='list'),
        version=dict(required=True, type='str'),
        state=dict(required=False, type='str', default='present', choices=['absent', 'present']),
    ))

    matcher = SemanticVersionMatcher(module,
                                     _raw_params=module.params['_raw_params'],
                                     state=module.params['state'],
                                     )
    SemanticVersion.__eq__(matcher, module.params['version'])
    assert True


# Generated at 2022-06-21 09:18:00.480558
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    ret = SemanticVersion("1.2.3") <= "1.2.3"
    assert ret is True


# Generated at 2022-06-21 09:18:11.074957
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion("1.2.3") == SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3") is not None
    assert SemanticVersion("1.2.3") != "1.2.3"
    assert SemanticVersion("1.2.3-alpha") == SemanticVersion("1.2.3-alpha")
    assert SemanticVersion("1.2.3-alpha") != SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3+build") == SemanticVersion("1.2.3+build")
    assert SemanticVersion("1.2.3+build") == SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3+build") != SemanticVersion("1.2.3+build+metadata")


# Generated at 2022-06-21 09:18:22.393697
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    mycase = (
        # vstring, __ne__
        ('1.2.3', False),
        ('1.2.3-alpha.1', True),
    )

    for vstring, result in mycase:
        assert SemanticVersion(vstring) != '1.2.3' == result


# Generated at 2022-06-21 09:18:32.335611
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    num1 = _Numeric(1)
    num2 = _Numeric(2)
    num3 = _Numeric('15')
    assert(num1 < num2)
    assert(num3 > num1)
    assert(num3 == 15)
    assert(num3 >= 15)
    assert(num3 >= 15.3)
    assert(num3 < '16')
    assert(num3 < 17)
    assert(num3 <= 15)
    assert(num3 >= 15)
    assert(num3 != 16)
    assert(num3 != '15')
    try:
        num4 = _Numeric('a')
    except ValueError as e:
        print('passing a string that does not contain an integer to _Numeric() is not allowed [%s]' % e)
    else:
        assert(False)

# Generated at 2022-06-21 09:18:38.949326
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('test')
    b = _Alpha('test')
    c = _Alpha('test2')

    assert a != b, "'%s' != '%s'" % (a, b)
    assert a != c, "'%s' != '%s'" % (a, c)
    assert a != 'test', "'%s' != '%s'" % (a, 'test')
    assert a != 'test2', "'%s' != '%s'" % (a, 'test2')
    assert a != ''
    assert 0 != a
    assert '' != a


# Generated at 2022-06-21 09:18:50.304037
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('b') <= _Alpha('b')
    assert _Alpha('b') <= _Alpha('c')
    assert not (_Alpha('c') <= _Alpha('b'))
    assert not (_Alpha('b') <= 'b')
    assert _Alpha('b') >= _Alpha('b')
    assert _Alpha('b') >= 'b'
    assert not (_Alpha('b') >= 'c')
    assert not (_Alpha('c') >= _Alpha('b'))
    assert _Alpha('b') < _Alpha('c')
    assert _Alpha('b') < 'c'
    assert not (_Alpha('c') < _Alpha('b'))
    assert not (_Alpha('c') < 'b')
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('b') > 'a'

# Generated at 2022-06-21 09:18:58.481139
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert(SemanticVersion('1.0.0').__gt__('1.1.0') == False)
    assert(SemanticVersion('1.0.0').__gt__('0.1.0') == True)
    assert(SemanticVersion('1.0.0').__gt__('1.0.1') == False)
    assert(SemanticVersion('1.0.0').__gt__('v1.0.0') == True)
    assert(SemanticVersion('1.0.0').__gt__('1.0.0') == False)
    assert(SemanticVersion('1.0.0').__gt__('0.0.1') == True)



# Generated at 2022-06-21 09:19:08.767369
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    class TestVersion(object):
        def __init__(self, version_string, major, minor, patch, prerelease, buildmetadata):
            self.version_string = version_string
            self.major = major
            self.minor = minor
            self.patch = patch
            self.prerelease = prerelease
            self.buildmetadata = buildmetadata


# Generated at 2022-06-21 09:19:14.132783
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'b'
    assert _Alpha('a') != 1
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'b'
    assert not _Alpha('a') < _Alpha('a')
    assert not _Alpha('a') < 'a'
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert not _Alpha

# Generated at 2022-06-21 09:19:25.917795
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    with open('tests/fixtures/semver.json') as f:
        semver_fixtures = json.load(f)
        for semver in semver_fixtures:
            if semver['input'][0]:
                v = SemanticVersion(semver['input'][0])
                assert isinstance(v, SemanticVersion)
                assert v.major==semver['expected']['major']
                assert v.minor==semver['expected']['minor']
                assert v.patch==semver['expected']['patch']
                assert v.prerelease==semver['expected']['prerelease']
                assert v.buildmetadata==semver['expected']['buildmetadata']
                assert v.is_stable==semver['expected']['is_stable']
                assert v.is_prerelease==sem

# Generated at 2022-06-21 09:19:31.010181
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("beta") >= _Alpha("alpha")
    assert _Alpha("beta") >= "alpha"
    assert _Alpha("beta") >= _Alpha("beta")
    assert _Alpha("beta") >= "beta"
    assert not (_Alpha("beta") >= _Alpha("gamma"))
    assert not (_Alpha("beta") >= "gamma")


# Generated at 2022-06-21 09:19:39.394525
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("1.2.3+foo.bar") == SemanticVersion("1.2.3+foo.bar")
    assert SemanticVersion("1.2.3+foo.bar") > SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3+foo.bar") == SemanticVersion("1.2.3-alpha") # build metadata doesn't matter
    assert SemanticVersion("1.2.3+foo.bar") == SemanticVersion("1.2.3+foo")
    assert SemanticVersion("1.2.3+foo") == SemanticVersion("1.2.3+foo.0")
    assert SemanticVersion("1.2.3+foo.0") == SemanticVersion("1.2.3+foo.0.0")

# Generated at 2022-06-21 09:19:50.160937
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # Given
    version_a = "0.0.1"
    version_a_object = SemanticVersion(version_a)
    version_b = "0.0.2"
    version_b_object = SemanticVersion(version_b)

    # When
    comparison = version_b_object.__ge__(version_a)

    # Then
    assert comparison == True


# Generated at 2022-06-21 09:19:52.262746
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('0.9.9')


# Generated at 2022-06-21 09:20:01.008898
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Test for basic version comparison
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.2')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.4')

    # Test for prereleases
    assert SemanticVersion('1.2.3-alpha') < SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3-alpha') < SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion

# Generated at 2022-06-21 09:20:03.887461
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # todo: move this to a normal unit test
    # Create an object of class SemanticVersion
    semver = SemanticVersion()

    # Create string
    vstring = '0.1.1'

    # Call method __gt__ of class SemanticVersion
    res = semver.__gt__(vstring)

    # Check the result
    assert False


# Generated at 2022-06-21 09:20:07.922096
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.2.3') < '1.2.4'
    assert SemanticVersion('1.2.3') < '1.3.0'
    assert SemanticVersion('1.2.3') < '2.0.0'
    assert not (SemanticVersion('1.2.3') < '1.2.3')
    assert not (SemanticVersion('1.2.2') < '1.2.3')

# Generated at 2022-06-21 09:20:13.617030
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("0.0.1") == "0.0.1"
    assert SemanticVersion("0.0.1-alpha") == "0.0.1-alpha"
    assert SemanticVersion("0.0.1-alpha.1") == "0.0.1-alpha.1"
    assert SemanticVersion("0.0.1+buildmetadata") == "0.0.1+buildmetadata"
    assert SemanticVersion("0.0.1-alpha.1+buildmetadata") == "0.0.1-alpha.1+buildmetadata"
    assert SemanticVersion("0.0.1.1") == "0.0.1.1"

# Generated at 2022-06-21 09:20:24.566837
# Unit test for method __ge__ of class _Alpha

# Generated at 2022-06-21 09:20:26.295064
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(1) == '1'


# Generated at 2022-06-21 09:20:27.480423
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('2')


# Generated at 2022-06-21 09:20:34.809388
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(0) <= _Numeric(1)
    assert _Numeric(0) <= _Numeric(0)
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric('1')
    assert _Numeric(1) <= _Numeric(0)
    assert _Numeric('1') <= _Numeric(0)
    assert _Numeric(1) <= _Numeric('0')
    assert _Numeric(0) <= _Numeric('1')



# Generated at 2022-06-21 09:20:45.688765
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():

    x = _Numeric('1')
    y = _Numeric('1')
    z = _Numeric('2')
    assert x <= y
    assert not x <= z
    assert x <= x
    assert not x <= _Alpha('1')
    assert not x <= _Alpha('2')
    assert x <= _Alpha('3')


# Generated at 2022-06-21 09:20:47.692644
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.0.0') != '1.0.1'


# Generated at 2022-06-21 09:20:56.975403
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('0') >= _Alpha('0')
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('0') >= '0'
    assert _Alpha('1') >= '1'
    assert _Alpha('0') >= '0'
    assert _Alpha('1') >= '1'
    assert _Alpha('z') >= 'z'
    assert _Alpha('-') >= '-'

    assert not _Alpha('0') >= '1'
    assert not _Alpha('5') >= '6'

    assert _Alpha('0') >= _Numeric('0')
    assert _Alpha('0') >= _Numeric('1')
    assert not _Alpha('1') >= _Numeric('0')


# Generated at 2022-06-21 09:20:59.347509
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"



# Generated at 2022-06-21 09:21:01.892109
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.2.3') <= '1.2.3'
    assert SemanticVersion('1.2.3') <= SemanticVersion('1.2.3')


# Generated at 2022-06-21 09:21:05.044274
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('10') > _Numeric('9')
    assert _Numeric('10') >= _Numeric('10')
    assert _Numeric('9') < _Numeric('10')
    assert _Numeric('10') <= _Numeric('10')
    assert _Numeric('9') <= _Numeric('10')


# Generated at 2022-06-21 09:21:15.031208
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    version = SemanticVersion('1.2.3')

    assert version >= version
    assert version >= '1.2.3'
    assert version >= SemanticVersion('0.9.9')
    assert version >= '0.9.9'
    assert version >= SemanticVersion('0.9.9-alpha')
    assert version >= '0.9.9-alpha'
    assert version >= SemanticVersion('0.9.9-alpha.1')
    assert version >= '0.9.9-alpha.1'
    assert version >= SemanticVersion('1.1.0')
    assert version >= '1.1.0'
    assert version >= SemanticVersion('1.1.0-alpha')
    assert version >= '1.1.0-alpha'

# Generated at 2022-06-21 09:21:17.397173
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    n1 = _Numeric(100)
    assert n1 != '100'
    n2 = _Numeric(100)
    assert n1 != n2
    assert n1 != 101


# Generated at 2022-06-21 09:21:27.523399
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # Test the case where self.specifier is a string and other is a string
    # Input:
    #   - 'a'
    #   - 'b'
    # Expected output:
    #   - True
    alpha1 = _Alpha('a')
    alpha2 = _Alpha('b')

    assert alpha1.__gt__(alpha2)

    # Test the case where self.specifier is a string and other is a string
    # Input:
    #   - 'b'
    #   - 'a'
    # Expected output:
    #   - False
    alpha1 = _Alpha('b')
    alpha2 = _Alpha('a')

    assert not alpha1.__gt__(alpha2)

    # Test the case where self.specifier is a string and other is a string
    # Input:
    #

# Generated at 2022-06-21 09:21:30.469809
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('1') < _Alpha('a')
    assert _Alpha('1') < 'a'


# Generated at 2022-06-21 09:21:48.671132
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert(SemanticVersion('1.0.0') != '1.0.0')
    assert(SemanticVersion('1.0.0') != SemanticVersion('1.0.0'))
    assert(SemanticVersion('1.0.1') != '1.0.0')
    assert(SemanticVersion('1.0.1') != SemanticVersion('1.0.0'))
    assert(SemanticVersion('1.0.0') != '1.0.1')
    assert(SemanticVersion('1.0.0') != SemanticVersion('1.0.1'))
    assert(SemanticVersion('1.1.0') != '1.0.0')
    assert(SemanticVersion('1.1.0') != SemanticVersion('1.0.0'))

# Generated at 2022-06-21 09:21:50.767368
# Unit test for constructor of class _Alpha
def test__Alpha():
    '''Test instantiation of helper class _Alpha'''
    ret = _Alpha('a')
    assert isinstance(ret, _Alpha)


# Generated at 2022-06-21 09:21:57.230310
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('1-alpha') == '1-alpha'
    assert _Alpha('1-alpha') == _Alpha('1-alpha')
    assert _Alpha('1-alpha') != '1-beta'
    assert _Alpha('1-alpha') != _Alpha('1-beta')
    assert _Alpha('1-alpha') < _Alpha('1-beta')
    assert _Alpha('1-alpha') < '1-beta'
    assert _Alpha('1-alpha') > '1-RC'
    assert _Alpha('1-alpha') <= '1-alpha'
    assert _Alpha('1-alpha') >= '1-alpha'


# Generated at 2022-06-21 09:22:00.677509
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():

    if SemanticVersion('1.0.0') != SemanticVersion('1.0.0'):
        raise AssertionError("Must return False when tested versions are equal")

    return True


# Generated at 2022-06-21 09:22:11.935021
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion('1.0.0-alpha')
    v2 = SemanticVersion('2.0.0')
    v3 = SemanticVersion('1.0.0-beta')
    v4 = SemanticVersion('1.0.0')
    v5 = SemanticVersion('1.0.0+build')
    assert not v1 >= v2
    assert not v1 >= v3
    assert not v1 >= v4
    assert not v1 >= v5
    assert not v2 >= v1
    assert not v2 >= v3
    assert not v2 >= v4
    assert not v2 >= v5
    assert v3 >= v1
    assert not v3 >= v2
    assert not v3 >= v4
    assert not v3 >= v5
    assert v4 >= v1

# Generated at 2022-06-21 09:22:23.087565
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0-beta.3') > SemanticVersion('1.0.0-beta.2')
    assert SemanticVersion('1.0.0-beta.2+build.123') > SemanticVersion('1.0.0-beta.2')
    assert SemanticVersion('1.0.0-beta.2') > SemanticVersion('1.0.0-beta.2+build.123')
    assert SemanticVersion('1.0.0-beta.3') > '1.0.0-beta.2'
    assert SemanticVersion('1.0.0-beta.2') > '1.0.0-beta.2+build.123'
    assert SemanticVersion('1.0.0-beta.3') > '1.0.0-beta.3+build.123'


# Generated at 2022-06-21 09:22:30.867199
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') != 'b'
    assert _Alpha('b') != 'a'
    assert _Alpha('b') != 1
    assert _Alpha('a') < 1
    assert not _Alpha('a') > 1
    assert _Alpha('a') < 'b'
    assert not _Alpha('a') > 'b'
    assert _Alpha('b') == _Alpha('b')
    assert _Alpha('b') != _Alpha('a')
    assert _Alpha('b') != _Numeric(1)
    assert _Alpha('a') < _Numeric(1)
    assert not _Alpha('a') > _Numeric(1)
    assert _Alpha('a') < _Alpha('b')
    assert not _Alpha('a') > _Alpha('b')
    assert _Alpha

# Generated at 2022-06-21 09:22:32.537711
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    if _Alpha('test') != _Alpha('test'):
        raise AssertionError



# Generated at 2022-06-21 09:22:35.973080
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') != 'b'
    assert _Alpha('a') != 1


# Generated at 2022-06-21 09:22:46.403775
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    alpha1 = _Alpha('alpha')
    alpha2 = _Alpha('Alpha')
    alpha3 = _Alpha('beta')
    alpha4 = _Alpha('0010')
    assert alpha1.__eq__(alpha2) == True
    assert alpha2.__eq__(alpha1) == True
    assert alpha1.__eq__(alpha3) == False
    assert alpha3.__eq__(alpha1) == False
    assert alpha1.__eq__(alpha4) == False
    assert alpha4.__eq__(alpha1) == False
    assert alpha2.__eq__(alpha3) == False
    assert alpha3.__eq__(alpha2) == False
    assert alpha2.__eq__(alpha4) == False
    assert alpha4.__eq__(alpha2) == False

# Generated at 2022-06-21 09:23:09.929856
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    expected = "SemanticVersion('1.2.3')"
    assert repr(SemanticVersion('1.2.3')) == expected


# Generated at 2022-06-21 09:23:13.574279
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion()
    assert repr(v) == "SemanticVersion(None)"
    v = SemanticVersion("1.0.0")
    assert repr(v) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-21 09:23:22.922350
# Unit test for method __le__ of class SemanticVersion

# Generated at 2022-06-21 09:23:26.643800
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('1') >= _Numeric('1')
    assert not _Numeric('1') >= _Numeric('2')
    assert _Numeric('2') >= _Numeric('1')
    assert _Numeric('2') >= _Numeric('2')


# Generated at 2022-06-21 09:23:27.940996
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(1) == '1'
    assert repr('1') == "'1'"


# Generated at 2022-06-21 09:23:33.635238
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    a = _Numeric('1')
    b = _Numeric('2')
    try:
        assert a < b # expected success
    except:
        fail()

    b = _Numeric('1')
    try:
        assert a < b # expected failure
    except:
        pass

    b = _Numeric('0')
    try:
        assert a < b # expected failure
    except:
        pass

    a = _Numeric('0')
    b = _Numeric('1')
    try:
        assert a < b # expected success
    except:
        fail()

    b = _Numeric('0')
    try:
        assert a < b # expected failure
    except:
        pass

    a = _Numeric('1')
    b = _Alpha('2')

# Generated at 2022-06-21 09:23:35.681461
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    sv1 = SemanticVersion('1.2.3')
    sv2 = SemanticVersion('1.2.4')
    assert not sv1 >= sv2


# Generated at 2022-06-21 09:23:41.237847
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    result_number_number = _Numeric('12') <= _Numeric('3')
    result_number_str = _Numeric('12') <= '3'
    result_str_number = _Alpha('12') <= _Numeric('3')
    # result_str_str = _Alpha('12') <= '3'

    assert result_number_number is False
    assert result_number_str is False
    assert result_str_number is True
    # assert result_str_str is True


# Generated at 2022-06-21 09:23:52.235566
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    for version in ('0.0.0', '0.0.1', '1.0.0', '1.1.0', '2.0.0', '2.1.0', '2.1.1', '1.0.0-alpha', '1.0.0-alpha.1', '1.0.0-0.3.7', '1.0.0-x.7.z.92', '1.0.0-alpha+001', '1.0.0+20130313144700', '1.0.0-beta+exp.sha.5114f85'):
        ver = SemanticVersion(version)
        assert ver.vstring == version, 'Version number has been changed on initialisation.'
        assert ver.major != None, 'Major version number is missing.'

# Generated at 2022-06-21 09:23:55.733280
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    a = _Numeric(1)
    b = 1
    c = _Numeric('2')
    assert a == b
    assert b == a
    assert not a == c
    assert not c == a


# Generated at 2022-06-21 09:24:42.846013
# Unit test for constructor of class _Alpha
def test__Alpha():
    # Test constructor with a valid string
    string1 = 'test1'
    alpha1 = _Alpha(string1)

    assert alpha1.specifier == string1

    # Test constructor with an invalid parameter
    assert isinstance(_Alpha(1), _Alpha)



# Generated at 2022-06-21 09:24:49.407466
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    v_numeric_3 = _Numeric(3)
    v_numeric_5 = _Numeric(5)
    v_alpha_3 = _Alpha(3)
    v_alpha_5 = _Alpha(5)
    v_alpha_3_ = _Alpha('3')
    v_alpha_5_ = _Alpha('5')
    #self.assertTrue(v_numeric_3 < v_numeric_5)
    #self.assertTrue(v_numeric_3 < v_alpha_5)
    #self.assertTrue(v_alpha_3 < v_alpha_5)
    #self.assertTrue(v_alpha_3_ < v_alpha_5_)

# Generated at 2022-06-21 09:24:54.735596
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create a loose version which will be used as a starting point
    loose_version = LooseVersion('0.0.2-2')
    sv = SemanticVersion.from_loose_version(loose_version)

    # Assert that the version numbers are what we expect
    assert sv.major == 0
    assert sv.minor == 0
    assert sv.patch == 2
    assert sv.prerelease == (_Numeric(2),)

    # Assert that the version string is what we expect
    assert sv.vstring == '0.0.2-2'

    # Create a loose version which will be used as a starting point
    loose_version = LooseVersion('0.0.2-wildcard')
    sv = SemanticVersion.from_loose_version(loose_version)

    # Assert that the version numbers are

# Generated at 2022-06-21 09:25:00.905639
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('a') < _Alpha('A')
    assert _Alpha('1') < _Alpha('a')
    assert _Alpha('1') < _Alpha('A')
    assert not (_Alpha('b') < _Alpha('a'))
    assert not (_Alpha('2') < _Alpha('1'))
    assert not (_Alpha('A') < _Alpha('a'))
    assert not (_Alpha('a') < _Alpha('1'))
    assert not (_Alpha('A') < _Alpha('1'))



# Generated at 2022-06-21 09:25:07.185912
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a').__ge__('a') == True
    assert _Alpha('a').__ge__('b') == False
    assert _Alpha('a').__ge__(None) == False
    assert _Alpha('a').__ge__(True) == False
    assert _Alpha('a').__ge__(10) == False
    assert _Alpha('a').__ge__(_Numeric(10)) == False


# Generated at 2022-06-21 09:25:10.053301
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion(vstring='1.0.0')

    assert version.__repr__() == "SemanticVersion('1.0.0')"
    assert repr(version) == "SemanticVersion('1.0.0')"



# Generated at 2022-06-21 09:25:14.056480
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # Test when greater than
    assert _Alpha('1.4.2') >= _Alpha('1.3.3')

    # Test when equal to
    assert _Alpha('1.5.5') >= _Alpha('1.5.5')

    # Test when less than
    assert not (_Alpha('1.3.3') >= _Alpha('1.4.2'))


# Generated at 2022-06-21 09:25:18.775449
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha(1).__eq__(_Alpha(1)) is True
    assert _Alpha(1).__eq__(_Alpha(2)) is False
    assert _Alpha(1).__eq__('1') is True
    assert _Alpha(1).__eq__('2') is False


# Generated at 2022-06-21 09:25:25.321536
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(0) == 0
    assert _Numeric(1) == 1
    assert _Numeric(1.1) == 1
    assert _Numeric(0.99999999999999999999) == 1
    assert _Numeric(1.00000000000001) == 1

    assert _Numeric(0) == _Numeric(0)
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == _Numeric('1')
    assert _Numeric(1) == _Numeric('1.0')

    assert not _Numeric(1) == _Numeric(2)
    assert not _Numeric(1) == _Numeric('2')
    assert not _Numeric(1) == _Numeric('1.1')


# Generated at 2022-06-21 09:25:28.814645
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("z") <= _Alpha("z")
    assert _Alpha("z") <= _Alpha("aa")
    assert _Alpha("z") <= _Alpha("b")
    assert _Alpha("z") <= "z"
    assert not _Alpha("z") <= "a"
