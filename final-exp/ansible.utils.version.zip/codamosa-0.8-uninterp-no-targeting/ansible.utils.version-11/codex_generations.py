

# Generated at 2022-06-21 09:17:09.825894
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    """Test that the __repr__ method returns the correct string"""
    # Arrange
    semver = SemanticVersion("1.2.3")
    # Act
    result = repr(semver)
    # Assert
    assert result == "SemanticVersion('1.2.3')"

# Generated at 2022-06-21 09:17:13.969454
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric('1') > _Alpha('0')
    assert _Numeric('1') > 0
    assert _Numeric('1') > '0'


# Generated at 2022-06-21 09:17:23.570754
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('1.2.3')
    assert v1 > '1.2.2'
    v2 = SemanticVersion('1.2.3-dev')
    assert v1 > v2
    v3 = SemanticVersion('1.2.3-dev')
    assert v2 == v3
    v3 = SemanticVersion('1.0.0-rc.1+build.123')
    assert v3 < v1
    assert v3 < '1.0.0-rc.2'
    v4 = SemanticVersion('1.0.0-rc.1-beta+build.123')
    assert v4 < v3


# Generated at 2022-06-21 09:17:30.117902
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    from ..module_utils.basic import ansible_spec
    if ansible_spec.supports_ansible_module_version('2.4'):
        assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    if ansible_spec.supports_ansible_module_version('2.6'):
        assert SemanticVersion('2.6.0') <= SemanticVersion('2.6.0')
    assert SemanticVersion('2.6.0') <= '2.6.0'
    assert SemanticVersion('2.6.0') <= SemanticVersion('2.6.1')
    assert SemanticVersion('2.6.0') <= '2.6.1'
    assert SemanticVersion('1.0.1') <= '1.0.2'
    assert Semantic

# Generated at 2022-06-21 09:17:40.355341
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3-alpha') == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3-alpha') != SemanticVersion('1.2.0-alpha')
    assert SemanticVersion('1.2.3-alpha') != SemanticVersion('1.2.3-beta')
    assert SemanticVersion('1.2.3-alpha') != SemanticVersion('1.2.4-alpha')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-21 09:17:46.323126
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    A = _Alpha('1')
    B = _Numeric('2')
    C = '3'
    try:
        assert A.__lt__(B) is False
        assert A.__lt__(C) is True
        assert B.__lt__(A) is True
        assert B.__lt__(C) is True
        assert not B.__lt__('x')
    except ValueError:
        pass


# Generated at 2022-06-21 09:17:52.567197
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-SNAPSHOT')
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-alpha')
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-alpha.1')
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-1')
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-1.0')
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-beta')
    assert SemanticVersion('0.0.0') > SemanticVersion('0.0.0-beta.2')

# Generated at 2022-06-21 09:18:00.771530
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    """
    Make sure that _Alpha implements the correct comparison logic
    """
    assert _Alpha('c') < _Alpha('d')
    assert _Alpha('0') < _Alpha('d')
    assert _Alpha('c') < _Alpha('0')
    assert _Alpha('1') < _Alpha('0')
    assert _Alpha('01a') < _Alpha('02a')

    # These should raise a ValueError
    try:
        _Alpha('1') < 1
    except ValueError:
        pass
    else:
        assert False

    try:
        _Alpha('1') < _Numeric('1')
    except ValueError:
        pass
    else:
        assert False



# Generated at 2022-06-21 09:18:11.292244
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > '1.0.0-alpha.1' == True
    assert SemanticVersion('1.0.0-alpha.1') > '1.0.0-alpha.1' == False
    assert SemanticVersion('1.0.0-alpha.1') > '1.0.0-alpha' == True
    assert SemanticVersion('1.0.0-alpha.11') > '1.0.0-alpha.2' == True
    assert SemanticVersion('1.0.0-alpha') > '1.0.0-alpha.beta' == False
    assert SemanticVersion('1.0.0-alpha.beta') > '1.0.0-beta' == False

# Generated at 2022-06-21 09:18:17.649615
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-21 09:18:30.836789
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.2.3') != '1.2.3'
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.4-alpha')
    assert SemanticVersion('1.2.3-beta') != SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3-beta+1') != SemanticVersion('1.2.3-beta')



# Generated at 2022-06-21 09:18:34.894519
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a1 = _Alpha('a')
    a2 = _Alpha('a')
    a3 = _Alpha('b')
    assert a1 == a2
    assert not a1 == a3
    assert not a1 == 'a'
    assert a1 == 'a'


# Generated at 2022-06-21 09:18:41.354925
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(2)
    d = _Numeric(3)
    e = _Alpha('1')
    f = '1'
    g = 0
    h = _Alpha('0')
    i = _Numeric(0)

    assert a != b
    assert b != a
    assert b != c
    assert c != b
    assert b != d
    assert d != b
    assert a != e
    assert e != a
    assert a != f
    assert f != a
    assert a != g
    assert g != a
    assert a != h
    assert h != a
    assert a != i
    assert i != a
    assert b != e
    assert e != b
    assert b != f
    assert f != b

# Generated at 2022-06-21 09:18:52.627946
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.1.1') >= '1.1.1'
    assert SemanticVersion('1.1.1') >= '1.1.0'
    assert SemanticVersion('1.1.0') >= '0.2.3'
    assert not SemanticVersion('0.1.1') >= '1.1.0'
    assert SemanticVersion('0.2.3') >= '0.2.3-rc.1'
    assert SemanticVersion('0.2.3') >= '0.2.3-rc.0'
    assert not SemanticVersion('0.2.3-rc.1') >= '0.2.3'
    assert SemanticVersion('0.2.3-rc.1') >= '0.2.3-rc.1'

# Generated at 2022-06-21 09:18:55.496323
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != 1
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != _Alpha('1')


# Generated at 2022-06-21 09:19:01.838940
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.2.3') <= SemanticVersion('1.2.3')
    assert SemanticVersion('0.2.3') <= SemanticVersion('1.2.3')
    assert SemanticVersion('1.0.3') <= SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.0') <= SemanticVersion('1.2.3')

    assert SemanticVersion('1.2.3') >= SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') >= SemanticVersion('0.2.3')
    assert SemanticVersion('1.2.3') >= SemanticVersion('1.0.3')
    assert SemanticVersion('1.2.3') >= SemanticVersion('1.2.0')


# Generated at 2022-06-21 09:19:10.509310
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('0.0.0') <= SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') <= SemanticVersion('0.0.1')
    assert SemanticVersion('0.0.0') <= SemanticVersion('0.1.0')
    assert SemanticVersion('0.0.0') <= SemanticVersion('1.0.0')
    assert SemanticVersion('0.0.0') <= SemanticVersion('1.0.0-pre')
    assert SemanticVersion('0.0.0') <= SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('0.0.0') <= SemanticVersion('1.0.0-alpha.1')

# Generated at 2022-06-21 09:19:16.009505
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert ('foo' >= _Alpha('foo'))
    assert (_Alpha('foo') <= 'foo')
    assert ('foo' >= _Alpha('bar'))
    assert (_Alpha('bar') <= 'foo')
    assert (not ('foo' >= _Alpha('baz')))
    assert (not (_Alpha('baz') <= 'foo'))


# Generated at 2022-06-21 09:19:22.394574
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != 2
    assert 1 != _Numeric(1)
    assert _Numeric(1) != _Alpha('1')
    assert _Numeric(1) != _Alpha('2')
    assert _Alpha('1') != _Numeric(1)
    assert _Alpha('2') != _Numeric(1)


# Generated at 2022-06-21 09:19:33.597062
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    def assert_error(vstring):
        try:
            SemanticVersion(vstring)
        except ValueError:
            pass
        else:
            raise AssertionError('%r should raise a ValueError' % vstring)

    def assert_version(vstring, major=0, minor=0, patch=0, prerelease=(), buildmetadata=()):
        version = SemanticVersion(vstring)
        assert version.vstring == vstring
        assert version.major == major
        assert version.minor == minor
        assert version.patch == patch
        assert version.prerelease == prerelease
        assert version.buildmetadata == buildmetadata

    yield assert_error, ''
    yield assert_error, '1.2.3.4'
    yield assert_error, 'a'
    yield assert_error, '-a'
   

# Generated at 2022-06-21 09:19:40.157512
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)

# Generated at 2022-06-21 09:19:48.155612
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    module = AnsibleModule(
        argument_spec=dict(
            test_version=dict(type='str'),
        )
    )

    test_version = module.params['test_version']
    module.exit_json(
        msg="Checking if SemanticVersion('%s') >= '%s'" % (
            "0.1.0-beta.1",
            test_version
        ),
        changed=False,
        version_geq=SemanticVersion("0.1.0-beta.1") >= test_version
    )



# Generated at 2022-06-21 09:19:53.289899
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(2) <= _Numeric(1) == False
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 2
    assert _Numeric(2) <= 1 == False



# Generated at 2022-06-21 09:19:55.275727
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.0.0') != '1.0.0' 


# Generated at 2022-06-21 09:19:58.436112
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    try:
        # <class 'module'>:1
        SemanticVersion().__gt__('2.0.0')
        # This line should not exist, if it does, it means the __gt__ method of class SemanticVersion is broken
    except ValueError:
        pass


# Generated at 2022-06-21 09:20:00.185142
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert SemanticVersion(vstring='1.0.0').__repr__() == "SemanticVersion('1.0.0')"


# Generated at 2022-06-21 09:20:01.856869
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(0)) == '0'
    assert repr(_Numeric('0')) == '0'


# Generated at 2022-06-21 09:20:05.337568
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert not _Numeric(2) <= _Numeric(1)
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 2
    assert not _Numeric(2) <= 1


# Generated at 2022-06-21 09:20:07.553804
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    num1 = _Numeric(5)
    num2 = _Numeric(6)

    assert num1 == _Numeric(5)
    assert num2 == _Numeric(6)
    assert num1 != num2


# Generated at 2022-06-21 09:20:09.186742
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion(vstring='1.0.0')
    assert repr(v) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-21 09:20:21.589604
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    num1 = _Numeric(1)
    num2 = _Numeric(2)

    assert num1.__ge__(num2) is False


# Generated at 2022-06-21 09:20:32.720031
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Test with valid versions
    assert SemanticVersion('1.0.1') > SemanticVersion('1.0.0')
    assert SemanticVersion('1.1.0') > SemanticVersion('1.0.0')
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0')
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0')
    assert SemanticVersion('1.0.0-alpha') > SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha.1') > SemanticVersion('1.0.0-alpha.beta')
    assert SemanticVersion('1.0.0-alpha.beta') > SemanticVersion('1.0.0-beta')

# Generated at 2022-06-21 09:20:39.074482
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('0') == _Alpha('0') == _Alpha('0') == '0' == '0' == '0'
    assert _Alpha('a') == _Alpha('a') == _Alpha('a') == 'a' == 'a' == 'a'
    assert _Alpha('a0') == _Alpha('a0') == _Alpha('a0') == 'a0' == 'a0' == 'a0'
    assert _Alpha('a0a') == _Alpha('a0a') == _Alpha('a0a') == 'a0a' == 'a0a' == 'a0a'
    assert _Alpha('0') != _Alpha('a') != _Alpha('a0') != _Alpha('a0a') != 'a0a' != '0' != 'a' != 'a0' != 0
    assert _

# Generated at 2022-06-21 09:20:41.599802
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('') == _Alpha('') == ''
    # guess we don't need to test the else part of the function
    return


# Generated at 2022-06-21 09:20:44.918100
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1') == 1
    assert _Numeric(1) == 1
    assert _Numeric('1') == _Numeric(1)


# Generated at 2022-06-21 09:20:51.017274
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('foo') == 'foo'
    assert _Alpha('foo') == _Alpha('foo')
    assert _Alpha('foo') != 'bar'
    assert _Alpha('foo') != _Alpha('bar')
    assert _Alpha('foo') < 'bar'
    assert _Alpha('foo') < _Alpha('bar')
    assert _Alpha('foo') > _Alpha('bar')
    assert _Alpha('foo') <= _Alpha('bar')
    assert _Alpha('foo') <= _Alpha('foo')
    assert _Alpha('foo') >= _Alpha('foo')
    assert _Alpha('foo') >= _Alpha('bar')



# Generated at 2022-06-21 09:20:55.258277
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('2.1.16')
    assert (v1 > '1.1.17')
    assert (v1 > '2.1.15')
    assert (v1 > '2.1.16rc0')


# Generated at 2022-06-21 09:20:57.457709
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == repr(1)


# Generated at 2022-06-21 09:20:59.663301
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= 'a'
    assert not _Alpha('a') <= 'b'


# Generated at 2022-06-21 09:21:07.042592
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    vstring = '1.0.0'
    semver = SemanticVersion(vstring)
    assert semver.vstring == '1.0.0'
    assert semver.major == 1
    assert semver.minor == 0
    assert semver.patch == 0
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    vstring = '1.2.3'
    semver = SemanticVersion(vstring)
    assert semver.vstring == '1.2.3'
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    vstring = '1.2.3-rc1'

# Generated at 2022-06-21 09:21:29.786204
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion()) == "SemanticVersion(None)"


# Generated at 2022-06-21 09:21:32.753741
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    alpha_1 = _Alpha('1')
    alpha_2 = _Alpha('2')
    assert(alpha_1 < alpha_2)
    assert(not(alpha_2 < alpha_1))
    assert(not(alpha_1 < alpha_1))


# Generated at 2022-06-21 09:21:33.726456
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha(22) != _Alpha(66)


# Generated at 2022-06-21 09:21:45.059719
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-21 09:21:49.093750
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    instance_1 = _Numeric(1)
    instance_2 = _Numeric(2)
    assert instance_1 <= instance_1
    assert instance_1 <= instance_2
    assert instance_2 >= instance_1


# Generated at 2022-06-21 09:21:57.320190
# Unit test for method __eq__ of class SemanticVersion

# Generated at 2022-06-21 09:21:59.333623
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) < _Numeric(2)



# Generated at 2022-06-21 09:22:01.137148
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    with mock.patch.object(SemanticVersion, 'parse'):
        sv = SemanticVersion('1.2.3')
    assert repr(sv) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-21 09:22:03.341107
# Unit test for constructor of class _Numeric
def test__Numeric():
	numeric = _Numeric(7)
	assert numeric.specifier == 7
	

# Generated at 2022-06-21 09:22:14.953648
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-21 09:23:01.594667
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a = SemanticVersion("0.0.0")
    b = SemanticVersion("0.0.0")

    assert (a <= b) is True, "test 1 failed"
    assert (a >= b) is True, "test 2 failed"
    assert (a == b) is True, "test 3 failed"
    assert (a < b) is False, "test 4 failed"
    assert (a > b) is False, "test 5 failed"
    assert (a != b) is False, "test 6 failed"

    a = SemanticVersion("0.0.1")
    b = SemanticVersion("0.0.0")

    assert (a <= b) is False, "test 7 failed"
    assert (a >= b) is True, "test 8 failed"
    assert (a == b) is False, "test 9 failed"

# Generated at 2022-06-21 09:23:08.730218
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(2) < _Numeric(3)
    assert _Numeric(3) > _Numeric(2)
    assert not _Numeric(3) < _Numeric(3)
    assert not _Numeric(3) > _Numeric(3)
    assert not _Numeric(3) < _Alpha('3')
    assert _Numeric(3) > _Alpha('3')
    assert not _Numeric('3') < _Alpha('3')
    assert _Numeric('3') > _Alpha('3')



# Generated at 2022-06-21 09:23:10.637303
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert not _Numeric('1') < _Numeric('1')
    assert not _Numeric('1') > _Numeric('1')


# Generated at 2022-06-21 09:23:14.409846
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(1)
    b = _Numeric(1)
    assert a.__ne__(b) == False
    c = _Numeric(2)
    assert a.__ne__(c) == True

# Generated at 2022-06-21 09:23:23.920106
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-21 09:23:25.654694
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')


# Generated at 2022-06-21 09:23:27.349446
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alpha = _Alpha('abcd')
    alpha1 = _Alpha('b')
    assert alpha > alpha1



# Generated at 2022-06-21 09:23:29.324608
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    # Test unit test
    assert _Alpha('').__repr__() == "''"

    # Test unit test
    assert _Alpha('text').__repr__() == "'text'"



# Generated at 2022-06-21 09:23:34.619637
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test the from_loose_version method for the SemanticVersion class
    """
    loose_versions = {
        'v1': '1',
        'v2': '2.15.0',
        'v3': '3.36.1-beta',
        'v4': '4.8.10-alpha.beta',
        'v5': '5.8.10-alpha-beta',
        'v6': '6.8.10+build',
        'v7': '7.8.10-alpha.beta+build',
        'v8': '8.8.10-alpha-beta+build',
        'v9': '9.8.10-alpha-beta+build.123'
        }


# Generated at 2022-06-21 09:23:38.802252
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(0) == _Numeric(0)
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(0) <= _Numeric(0)
    assert _Numeric(0) >= _Numeric(0)
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= _Numeric(0)
    assert not _Numeric(0) == _Numeric(1)


# Generated at 2022-06-21 09:25:12.291880
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion("1.2.3") > SemanticVersion("0.2.0")
    assert SemanticVersion("1.1.0") > SemanticVersion("1.0.0")
    assert SemanticVersion("2.0.0") > SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3") > SemanticVersion("1.2.3-alpha")
    assert SemanticVersion("1.2.3") > SemanticVersion("1.2.3-alpha.1")
    assert SemanticVersion("1.2.3-alpha") > SemanticVersion("1.2.3-alpha.1")
    assert SemanticVersion("1.2.3-alpha.1") > SemanticVersion("1.2.3-alpha.beta")

# Generated at 2022-06-21 09:25:14.058394
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == '1'

    assert repr(_Numeric(2)) == '2'


# Generated at 2022-06-21 09:25:17.533963
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():

    class DummySemanticVersion:
        def __eq__(self, value):
            return True
        def __ne__(self, value):
            raise AssertionError

    assert SemanticVersion(1).__ne__(DummySemanticVersion()) is not None


# Generated at 2022-06-21 09:25:20.706897
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric("0")) == "0"
    assert repr(_Numeric("1")) == "1"
    assert repr(_Numeric("11")) == "11"


# Generated at 2022-06-21 09:25:26.383539
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Instantiating an object of class SemanticVersion
    version1 = SemanticVersion('0.0.1-alpha')
    # Instantiating an object of class SemanticVersion
    version2 = SemanticVersion('1.0.0')
    assert(version1 < version2)

    # Instantiating an object of class SemanticVersion
    version1 = SemanticVersion('1.0.0-alpha')
    # Instantiating an object of class SemanticVersion
    version2 = SemanticVersion('1.0.0')
    assert(version1 < version2)

    # Instantiating an object of class SemanticVersion
    version1 = SemanticVersion('1.0.0-alpha')
    # Instantiating an object of class SemanticVersion
    version2 = SemanticVersion('3.0.0')

# Generated at 2022-06-21 09:25:27.608009
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    _Alpha('a') > 'a'



# Generated at 2022-06-21 09:25:30.234855
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha("beta")) == "b'beta'"

    assert repr(_Alpha("[alpha,beta]")) == "b'[alpha,beta]'"



# Generated at 2022-06-21 09:25:41.327138
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    from ansible_collections.sivel.sivel_utils.test.test_sivel_utils.unit.test_semver import (
        compare_compare_key,
        compare_ne,
        compare_eq,
        compare_lt,
        compare_le,
        compare_gt,
        compare_ge
    )
    assert compare_ne(["0.0.0", "0.0.1"], compare_key=compare_compare_key)
    assert compare_ne(["0.0.1", "0.1.0"], compare_key=compare_compare_key)
    assert compare_ne(["0.1.0", "0.0.0"], compare_key=compare_compare_key)

# Generated at 2022-06-21 09:25:43.235631
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('0.0.0')) == 'SemanticVersion(\'0.0.0\')'


# Generated at 2022-06-21 09:25:53.170608
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(2) <= _Numeric(2)
    assert _Numeric(2) <= _Numeric(3)

    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 2
    assert _Numeric(2) <= 2
    assert _Numeric(2) <= 3

    assert _Numeric(1) <= '1'
    assert _Numeric(1) <= '2'
    assert _Numeric(2) <= '2'
    assert _Numeric(2) <= '3'

