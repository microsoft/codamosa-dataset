

# Generated at 2022-06-21 09:16:57.985836
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    obj = _Alpha('abc')
    assert obj <= 'abc'
    assert obj <= _Alpha('abc')
    assert obj <= 'bbb'
    assert not (obj <= 'aab')


# Generated at 2022-06-21 09:17:06.248901
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.2.3') < '1.3.3'
    assert SemanticVersion('1.3.3') > '1.2.3'
    assert SemanticVersion('1.2.3') < '2.2.3'
    assert SemanticVersion('2.2.3') > '1.2.3'
    assert SemanticVersion('1.2.3') < '1.2.4'
    assert SemanticVersion('1.2.4') > '1.2.3'


# Generated at 2022-06-21 09:17:17.089896
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    first_version = SemanticVersion('1.0.0')
    second_version = SemanticVersion('2.0.0')
    third_version = SemanticVersion('2.1.0')
    fourth_version = SemanticVersion('2.1.0-beta')
    fifth_version = SemanticVersion('2.1.0-beta.1')
    six_version = SemanticVersion('2.1.0-beta.2')
    seventh_version = SemanticVersion('2.1.0-beta.11')
    eighth_version = SemanticVersion('2.1.0-rc.1')
    ninth_version = SemanticVersion('2.2.0')

    try:
        first_version.__le__(None)
        assert False
    except Exception:
        assert True


# Generated at 2022-06-21 09:17:22.874882
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    alpha = _Alpha(1)
    assert alpha >= '1'
    assert alpha >= 1
    assert alpha >= _Alpha('1')
    assert alpha >= _Numeric(1)
    try:
        alpha >= _Numeric('1')
    except ValueError:
        pass
    else:
        raise AssertionError('Unexpected ValueError not raised')


# Generated at 2022-06-21 09:17:30.378890
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    s = SemanticVersion("1.4.4.4")
    assert s.__str__() == "1.4.4.4"
    assert s.major == 1
    assert s.minor == 4
    assert s.patch == 4
    assert s.prerelease == ()
    s = SemanticVersion("1.4.4")
    assert s.prerelease == ()
    s = SemanticVersion("1.4.4-alpha.1")
    assert s.major == 1
    assert s.minor == 4
    assert s.patch == 4
    assert s.prerelease == ("alpha", "1")
    s = SemanticVersion("1.4.4-alpha.beta")
    assert s.major == 1
    assert s.minor == 4
    assert s.patch == 4

# Generated at 2022-06-21 09:17:33.632841
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    class Dummy(SemanticVersion):
        def __init__(self):
            pass

    dummy = Dummy()
    assert _Alpha('test') != dummy
    assert _Alpha('test') == 'test'


# Generated at 2022-06-21 09:17:36.278728
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('1')) == repr('1')
    assert repr(_Alpha('hello')) == repr('hello')


# Generated at 2022-06-21 09:17:38.148799
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    a = SemanticVersion('1.0.0')
    b = SemanticVersion('2.0.0')
    assert a < b



# Generated at 2022-06-21 09:17:48.595381
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    assert v.parse("1.2.3") == None
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3

    # Valid version string
    v = SemanticVersion("1.2.3")
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3

    # Invalid version string
    try:
        v = SemanticVersion("not a semantic version")
    except ValueError:
        pass
    else:
        assert False

    # Invalid version string
    try:
        v = SemanticVersion("1.2.3.4")
    except ValueError:
        pass
    else:
        assert False

    # Valid version string
    v = SemanticVersion("1.2.3-rc.1")

# Generated at 2022-06-21 09:17:55.393166
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    This is a simple test of the SemanticVersion.from_loose_version
    method. It is called once, by the test_semantic_version.py
    unit test, and is here to add test coverage only.
    """
    assert SemanticVersion.from_loose_version('2.3.4') == '2.3.4'
    assert SemanticVersion.from_loose_version('2.3.4pre') == '2.3.4-pre'
    assert SemanticVersion.from_loose_version('2.3.4post') == '2.3.4+post'
    assert SemanticVersion.from_loose_version('2.3.4prepost') == '2.3.4-pre+post'

# Generated at 2022-06-21 09:18:14.483166
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < _Numeric('2.0')
    assert _Numeric('1') < '2'
    assert _Numeric('1') < 2

    assert not _Numeric('2') < _Numeric('1')
    assert not _Numeric('2') < _Numeric('1.0')
    assert not _Numeric('2') < '1'
    assert not _Numeric('2') < 1

    assert not _Numeric('1') < _Numeric('1')
    assert not _Numeric('1') < _Numeric('1.0')
    assert not _Numeric('1') < '1'
    assert not _Numeric('1') < 1



# Generated at 2022-06-21 09:18:16.977465
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('1.1.1')
    assert a >= '1.1.1'
    assert a >= _Alpha('1.1.1') == True
    assert a >= _Alpha('1.1.2') == False
    assert a >= _Alpha('1.1.0') == True


# Generated at 2022-06-21 09:18:27.606019
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.2.3') <= SemanticVersion('1.2.3')
    assert not SemanticVersion('1.2.3') <= SemanticVersion('1.2.2')
    assert SemanticVersion('1.2.3') <= SemanticVersion('1.2.4')
    assert not SemanticVersion('1.2.3') <= SemanticVersion('1.1.3')
    assert SemanticVersion('1.2.3') <= SemanticVersion('1.3.3')
    assert not SemanticVersion('1.2.3') <= SemanticVersion('0.2.3')
    assert SemanticVersion('1.2.3') <= SemanticVersion('2.2.3')

    assert SemanticVersion('1.2.3') <= SemanticVersion('1.2.3-alpha')

# Generated at 2022-06-21 09:18:28.253706
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    _Numeric(1).__ne__(1.0)



# Generated at 2022-06-21 09:18:38.031282
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v = SemanticVersion('1.2.3')
    assert v < '1.2.4'
    assert v < '1.2.3-alpha'
    assert v < '1.2.3+1.0.0'

    assert not v < '1.2.2'
    assert not v < '0.2.3'
    assert not v < '1.2.3'
    assert not v < '1.2.3-beta'
    assert not v < '1.2.3-alpha+1.0.0'

    #  case for prerelease
    v1 = SemanticVersion('1.2.3-alpha')
    assert v1 < '1.2.3'
    assert v1 < '1.2.3-beta'

# Generated at 2022-06-21 09:18:43.392526
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('rc')
    b = _Alpha('rc')
    c = _Alpha('beta')
    d = _Alpha('alpha')

    assert a > b is False
    assert a > c is False
    assert a > d is True


# Generated at 2022-06-21 09:18:49.050230
# Unit test for constructor of class _Alpha
def test__Alpha():
    _Alpha(1) == _Numeric(1)
    _Alpha(1) == 1
    _Alpha(1) != _Alpha('1')
    _Alpha(1) != 2
    _Alpha(1) < 2
    _Alpha(1) < _Alpha(2)
    _Alpha(1) < '2'
    _Alpha(1) < _Numeric(2)


# Generated at 2022-06-21 09:18:55.586617
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    # Tests for method __ge__ of class _Numeric
    # __ge__(self, other)

    v1 = _Numeric('1')
    v1a = _Numeric('1')
    v2 = _Numeric('2')

    assert v1 >= v1a
    assert not v1 > v1a

    assert v2 > v1
    assert not v1 > v2

    assert v2 >= v1
    assert v1 <= v2



# Generated at 2022-06-21 09:18:58.069895
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= _Numeric(1)
    assert not _Numeric(1) >= 2
    assert not _Numeric(1) >= _Numeric(2)


# Generated at 2022-06-21 09:19:03.316931
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion("1.2.3-alpha.1") < SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3-alpha.1") < SemanticVersion("1.2.3+build.1")
    assert SemanticVersion("1.2.3-alpha.1+build.1") < SemanticVersion("1.2.3")
    assert SemanticVersion("1.2.3-alpha.1+build.1") < SemanticVersion("1.2.3+build.1")
    assert SemanticVersion("1.2.3") < SemanticVersion("1.2.4")
    assert SemanticVersion("1.2.3") < SemanticVersion("1.3.3")
    assert SemanticVersion("1.2.3") < SemanticVersion("2.2.3")

# Generated at 2022-06-21 09:19:12.021768
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')


# Generated at 2022-06-21 09:19:23.545217
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    """
    This function will test __ne__ function of class _Alpha
    """

    # First check when semicolon separated version is greater than the given version
    alpha = _Alpha("3:16")
    assert alpha != '3:20', "alpha != 3:20 failed"

    # Then check when semicolon separated version is lesser than the given version
    alpha = _Alpha("3:20")
    assert alpha != '3:20', "alpha != 3:16 failed"

    # Then check when the given version is lesser than the semicolon separated version
    alpha = _Alpha("3:20")
    assert alpha != '3:16', "alpha != 3:16 failed"

    # Then check when the given version is greater than the semicolon separated version
    alpha = _Alpha("3:16")

# Generated at 2022-06-21 09:19:34.866369
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha.1') < SemanticVersion('1.0.0-alpha.2')

# Generated at 2022-06-21 09:19:45.459341
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha_1 = _Alpha('10')
    alpha_2 = _Alpha('1')
    alpha_3 = _Alpha('2')
    alpha_4 = _Alpha('20')
    # Matching
    assert alpha_1.__le__('10')
    assert alpha_2.__le__('1')
    assert alpha_3.__le__('2')
    assert alpha_4.__le__('20')
    # Less
    assert alpha_2.__le__('10')
    assert alpha_3.__le__('10')
    assert alpha_2.__le__('20')
    assert alpha_3.__le__('20')
    # Greater
    assert alpha_1.__le__('1') is False
    assert alpha_1.__le__('2') is False
    assert alpha_4.__le

# Generated at 2022-06-21 09:19:49.017293
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion("0.0.1")) == "SemanticVersion('0.0.1')"
    assert repr(SemanticVersion("0.0.1-alpha")) == "SemanticVersion('0.0.1-alpha')"


# Generated at 2022-06-21 09:19:50.745606
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.1')


# Generated at 2022-06-21 09:19:59.167890
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    # initialize assertEqual class
    assertEqual = AssertEqual()

    # initialise _Numeric instances
    large_num = _Numeric('100')
    medium_num = _Numeric('10')
    small_num = _Numeric('1')

    # validate that 'large_num' is larger than 'medium_num'
    assertEqual(large_num.__ge__(medium_num), True)

    # validate that 'medium_num' is smaller than 'large_num'
    assertEqual(medium_num.__ge__(large_num), False)

    # validate that 'small_num' is smaller than 'large_num'
    assertEqual(small_num.__ge__(large_num), False)



# Generated at 2022-06-21 09:20:03.434256
# Unit test for constructor of class _Numeric
def test__Numeric():
    # Check all possible valid input
    assert _Numeric(0)
    assert _Numeric(1)
    assert _Numeric(10000000)
    assert _Numeric(str(0))
    assert _Numeric(str(1))
    assert _Numeric(str(10000000))

    # Check all possible invalid input
    for invalid_input in [3.1, "a", "-5", "b", 1.2]:
        try:
            _Numeric(invalid_input)
        except ValueError:
            pass
        else:
            raise AssertionError("Expected invalid input %r to raise ValueError" % invalid_input)


# Generated at 2022-06-21 09:20:07.376848
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    version1 = SemanticVersion('1.0.1')
    version2 = SemanticVersion('1.0.0')
    assert version1 > version2, "Wrong comparision of SemanticVersion objects."
    assert isinstance(version1, SemanticVersion), "The object is not an instance of SemanticVersion."
    assert isinstance(version2, SemanticVersion), "The object is not an instance of SemanticVersion."
    assert version1 != version2, "The two objects are the same."



# Generated at 2022-06-21 09:20:09.633506
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("x") >= _Alpha("x")
    assert not (_Alpha("x") >= _Alpha("y"))
    assert not (_Alpha("x") >= "x")
    assert not ("x" >= _Alpha("x"))


# Generated at 2022-06-21 09:20:25.651426
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    n1 = _Numeric("1")
    n2 = _Numeric("2")
    assert n2.__ge__(n1)
    assert n1.__ge__(n1)
    assert not n1.__ge__(n2)

# Generated at 2022-06-21 09:20:32.301867
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    num = _Numeric(4)
    assert num == 4
    num = _Numeric('4')
    assert num == 4
    assert num == _Numeric(4)
    assert num == _Numeric('4')
    assert num != 5
    assert num != _Numeric(5)
    assert num != _Numeric('5')
    assert num != '4'
    assert num != _Alpha('4')


# Generated at 2022-06-21 09:20:38.848832
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Tests based off of the examples from https://semver.org/#spec-item-11
    # The different classes here allow for testing all of the different scenarios
    # of the spec example
    def check(x, y):
        assert (x < y) and not (y < x)
        assert (x <= y) and not (y <= x)
        assert (x != y) and (y != x)
        assert (y > x) and not (x > y)
        assert (y >= x) and not (x >= y)

    check(_Alpha('foo'), _Alpha('bar'))
    check(_Alpha('foo'), _Alpha('foo-1'))
    check(_Alpha('foo-1'), _Alpha('foo-2'))
    check(_Alpha('foo-2'), _Alpha('foo-bar'))

# Generated at 2022-06-21 09:20:40.304333
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('specifier')) == "'specifier'"


# Generated at 2022-06-21 09:20:44.327856
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('1') >= _Numeric('1')
    assert _Numeric('1') >= _Numeric('0') == _Numeric('1') >= 1
    assert not (_Numeric('1') >= _Numeric('2'))



# Generated at 2022-06-21 09:20:50.660273
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert(_Numeric(1).__le__(_Numeric(1)))
    assert(not _Numeric(1).__le__(_Numeric(0)))
    assert(_Numeric(1).__le__(_Alpha('1')))
    assert(not _Numeric(1).__le__(_Alpha('0')))
    assert(_Numeric(1).__le__(1))
    assert(not _Numeric(1).__le__(0))
    try:
        assert(not _Numeric(1).__le__(_Numeric('1')))
    except ValueError:
        pass


# Generated at 2022-06-21 09:20:55.258822
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(3) >= _Numeric(3)
    assert _Numeric(3) >= _Numeric(2)
    assert _Numeric(3) >= _Numeric(4) == False


# Generated at 2022-06-21 09:21:04.694270
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v1 = SemanticVersion('1.0.0-alpha.6')
    v2 = SemanticVersion('1.0.0-alpha.5')
    v3 = SemanticVersion('1.0.0-alpha')
    v4 = SemanticVersion('1.0.0-beta.2')
    v5 = SemanticVersion('1.0.0-beta.11')
    v6 = SemanticVersion('1.0.0-rc.1')
    v7 = SemanticVersion('1.0.0')
    v8 = SemanticVersion('2.0.0')
    v9 = SemanticVersion('1.1.0')
    v10 = SemanticVersion('1.0.1')
    v11 = SemanticVersion('1.0.0-beta.2+buildmetadata')
    v12 = Sem

# Generated at 2022-06-21 09:21:09.031448
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Tests for regular expressions should be in test_semver.py

    # Test for passing None
    f = SemanticVersion()
    assert isinstance(f, SemanticVersion)

    # Test for passing empty string
    f = SemanticVersion('')
    assert isinstance(f, SemanticVersion)
    assert not f.core

    # Test for passing empty string, but including a leading 'v'
    f = SemanticVersion('v')
    assert isinstance(f, SemanticVersion)
    assert not f.core

    # Test for passing all zeros
    f = SemanticVersion('0.0.0')
    assert isinstance(f, SemanticVersion)
    assert f.core == (0, 0, 0)

    # Test for passing all non-zero numbers
    f = SemanticVersion('1.2.3')


# Generated at 2022-06-21 09:21:11.440394
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != 2
    assert _Numeric(1) != '1'

# Generated at 2022-06-21 09:21:46.482500
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion("1.2.3")
    v2 = SemanticVersion("1.2.4")
    v3 = SemanticVersion("2.2.0")
    v4 = SemanticVersion("2.2.0-alpha.1")
    v5 = SemanticVersion("2.2.0-alpha.2")
    v6 = SemanticVersion("2.2.0-beta.1")
    v7 = SemanticVersion("2.2.0-beta.11")
    v8 = SemanticVersion("2.2.0-rc.1")
    v9 = SemanticVersion("2.2.0-rc.11")
    v10 = SemanticVersion("2.2.0-rc.12")

# Generated at 2022-06-21 09:21:50.430204
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('1') <= _Alpha('2')
    assert _Alpha('1') <= _Alpha('1')
    assert _Alpha('1') <= '2'
    assert _Alpha('1') <= '1'
    assert not _Alpha('1') <= _Numeric(1)


# Generated at 2022-06-21 09:21:53.490038
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    given_repr_value = '10'
    class_numeric = _Numeric(given_repr_value)
    expectation = eval(class_numeric.__repr__())
    assert expectation == given_repr_value


# Generated at 2022-06-21 09:22:00.170335
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha("1") > "1"
    assert _Alpha("-1") > "-1"
    assert _Alpha("a") > "a"
    assert _Alpha("a") > "0"
    assert _Alpha("-a") > "-0"
    assert _Alpha("-a") > "-b"
    assert _Alpha("-b") > "-a"
    assert _Alpha("-a") > "0"
    assert _Alpha("-0") > "0"
    assert _Alpha("a") > "0.1"
    assert _Alpha("-a") > "-0.1"
    assert _Alpha("-a") > "-b.1"
    assert _Alpha("-b") > "-a.1"
    assert _Alpha("-a") > "0.1"

# Generated at 2022-06-21 09:22:07.964092
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    m = SemanticVersion()
    m.parse('1.1.2')
    assert m.major == 1 and m.minor == 1 and m.patch == 2

    m = SemanticVersion()
    m.parse('1.1.2-alpha.1.2.3+build.metadata')
    assert m.major == 1 and m.minor == 1 and m.patch == 2
    assert m.prerelease == (1, 2, 3)
    assert m.buildmetadata == ('build', 'metadata')



# Generated at 2022-06-21 09:22:09.560466
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(0) != 0


# Generated at 2022-06-21 09:22:14.319880
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Arrange
    # Semantic version is greater than string
    first_version = SemanticVersion("2.0.0")
    second_version = "1.0.0"

    # Act
    is_greater_than = first_version > second_version

    # Assert
    assert is_greater_than

# Generated at 2022-06-21 09:22:20.754607
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    try:
        _Numeric(0).__ne__(1)
    except:
        raise AssertionError("ValueError was raised")
    if _Numeric(0).__ne__(0):
        raise AssertionError("_Numeric(0).__ne__(0) returned True")
    if not _Numeric(0).__ne__(1):
        raise AssertionError("_Numeric(0).__ne__(1) returned False")


# Generated at 2022-06-21 09:22:29.719393
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    """Unit test for method __lt__ of class _Numeric"""
    new_Numeric = _Numeric(10)
    # test __lt__(self, other) with numeric arg
    ret_value = new_Numeric.__lt__(15)
    # __lt__(self, other) should return True
    assert (ret_value == True), "%r != %r" % (ret_value, True)
    # test __lt__(self, other) with string arg
    ret_value = new_Numeric.__lt__('a')
    # __lt__(self, other) should return False
    assert (ret_value == False), "%r != %r" % (ret_value, False)
    # test __lt__(self, other) with _Alpha arg
    new_Alpha = _Alpha('a')
    ret_

# Generated at 2022-06-21 09:22:31.770079
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('2.1.0') <= '2.0.0'


# Generated at 2022-06-21 09:22:59.924735
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.2.3') >= SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') >= SemanticVersion('1.2.2')
