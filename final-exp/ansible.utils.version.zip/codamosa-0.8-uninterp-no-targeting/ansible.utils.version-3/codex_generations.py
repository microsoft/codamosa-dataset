

# Generated at 2022-06-21 09:17:05.946483
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    num = _Numeric(3)
    assert num > 2
    assert num > _Numeric(2)

    alpha = _Alpha(4)
    assert num > alpha

    num = _Numeric(42)
    assert not num > '42'

    try:
        assert num > 'z'
        assert False
    except ValueError:
        pass

    # Test with invalid values
    try:
        assert num > object
        assert False
    except ValueError:
        pass

    try:
        assert num > None
        assert False
    except ValueError:
        pass



# Generated at 2022-06-21 09:17:17.090220
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.1') <= SemanticVersion('1.1.1')
    assert SemanticVersion('1.1.0') <= SemanticVersion('1.1.1')
    assert SemanticVersion('1.1.1') <= SemanticVersion('1.1.1-pre')
    assert SemanticVersion('1.1.0') <= SemanticVersion('1.1.1-pre')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.1.1-pre')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.1.0-pre')

# Generated at 2022-06-21 09:17:18.380279
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(0)) == '0'


# Generated at 2022-06-21 09:17:26.228016
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a').__gt__(_Alpha('a')) == False
    assert _Alpha('a').__gt__(_Alpha('b')) == False
    assert _Alpha('a').__gt__(_Alpha('A')) == False
    assert _Alpha('A').__gt__(_Alpha('a')) == False
    assert _Alpha('a').__gt__(_Alpha(0)) == True
    assert _Alpha('a').__gt__(_Alpha('0')) == True
    assert _Alpha('a').__gt__(_Alpha('0a')) == True


# Generated at 2022-06-21 09:17:36.403598
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-21 09:17:46.440607
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    # A.1. Major version X (X.y.z | X > 0) MUST be incremented if any
    #     backwards incompatible changes are introduced to the public
    #     API. It MAY include minor and patch level changes. Patch and
    #     minor version MUST be reset to 0 when major version is
    #     incremented.
    assert SemanticVersion('1.2.3') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.2.3') < SemanticVersion('2.1.0')
    assert SemanticVersion('1.2.3') < SemanticVersion('2.2.0')

    # A.2. Minor version Y (x.Y.z | x > 0) MUST be incremented if new,
    #     backwards compatible functionality is introduced to the
    #     public API. It MAY be incre

# Generated at 2022-06-21 09:17:54.239275
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('0') == _Numeric('0')
    assert _Numeric('0') < _Numeric('1')
    assert _Numeric('10') < _Numeric('11')
    assert _Numeric('10') > _Numeric('0')
    assert _Numeric('1') == _Numeric(1)
    assert _Numeric('1') > _Numeric(0)
    assert _Numeric('1') < _Numeric(2)
    assert _Numeric('0') <= _Numeric('0')
    assert _Numeric('0') <= _Numeric('1')
    assert _Numeric('1') <= _Numeric('1')
    assert _Numeric('0') >= _Numeric('0')
    assert _Numeric('1') >= _Numeric('0')

# Generated at 2022-06-21 09:18:03.829985
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('0.0.0')
    v2 = SemanticVersion('0.0.1')
    assert v2 > v1
    v2 = SemanticVersion('0.0.0')
    assert not v1 > v2
    v2 = SemanticVersion('0.1.0')
    assert not v1 > v2
    v1 = SemanticVersion('1.1.1')
    v2 = SemanticVersion('2.2.2')
    assert not v1 > v2
    v2 = SemanticVersion('1.1.1')
    assert not v1 > v2
    v2 = SemanticVersion('1.2.0')
    assert not v1 > v2
    v1 = SemanticVersion('0.2.2')

# Generated at 2022-06-21 09:18:07.259980
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion('1.0.0')
    assert version.__repr__() == 'SemanticVersion(\'1.0.0\')'


# Generated at 2022-06-21 09:18:15.673026
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("1.2.3-alpha.1+001") == SemanticVersion("1.2.3-alpha.1+001")
    assert SemanticVersion("1.2.3-alpha.1+001") != SemanticVersion("1.2.3-alpha.2+001")
    assert SemanticVersion("1.2.3-alpha.1+001") != SemanticVersion("1.2.3-alpha.2+002")
    assert SemanticVersion("1.2.3-alpha.1+001") != SemanticVersion("1.2.3-beta.2+002")
    assert SemanticVersion("1.2.3-alpha.1+001") != SemanticVersion("1.2.4-beta.2+002")

# Generated at 2022-06-21 09:18:30.393598
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    a = SemanticVersion()
    b = SemanticVersion()
    assert a.__ge__(b)
    assert not b.__ge__(a)
    assert b.__ge__(b)
    assert a.__ge__(a)


# Generated at 2022-06-21 09:18:32.877428
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha('alpha')
    assert alpha.specifier == 'alpha'
    assert repr(alpha) == "'alpha'"


# Generated at 2022-06-21 09:18:40.513452
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
  assert _Alpha('alpha1') >= 'alpha1'
  assert _Alpha('alpha10') >= 'alpha1'
  assert _Alpha('alpha1') <= 'alpha10'
  assert _Alpha('alpha1') <= 'alpha2'
  assert _Alpha('alpha1') < 'alpha2'
  assert _Alpha('alpha1') <= 'alpha1'
  assert _Alpha('alpha1') >= 'alpha1'
  assert _Alpha('alpha1') == 'alpha1'
  assert _Alpha('alpha1') != 'alpha2'
  assert _Alpha('alpha1') != '10'
  assert _Alpha('alpha1') <= '10'
  assert _Alpha('alpha1') < '10'
  assert _Alpha('alpha1') != 'Alpha'
  assert _Alpha('alpha1') <= 'Alpha'
  assert _Alpha('alpha1')

# Generated at 2022-06-21 09:18:51.906191
# Unit test for constructor of class _Alpha
def test__Alpha():
    # test constructor
    assert _Alpha("a1.b1") == "a1.b1"
    assert _Alpha("a2") == "a2"
    assert _Alpha("a3") != "a4"
    assert _Alpha("a4") is not None
    assert _Alpha("a5") is not "a5"

    # test overloaded operators
    assert _Alpha("a6") == _Alpha("a6")
    assert _Alpha("a7") != _Alpha("a8")
    assert _Alpha("a9") < _Alpha("a10")
    assert _Alpha("a11") > _Alpha("a12")
    assert _Alpha("a13") <= _Alpha("a13")
    assert _Alpha("a14") >= _Alpha("a14")

    # test overloaded method

# Generated at 2022-06-21 09:18:59.996977
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    n3 = _Numeric(3)
    s1 = '1'
    s2 = '2'
    s3 = '3'
    a1 = _Alpha('1')
    a2 = _Alpha('2')
    a3 = _Alpha('3')

    assert n1 < n2
    assert n1 < s2
    assert n1 < a2
    assert s1 < n2
    assert s1 < s2
    assert s1 < a2
    assert a1 < n2
    assert a1 < s2
    assert a1 < a2

    assert not n1 > n2
    assert not n1 > s2
    assert not n1 > a2
    assert not s1 > n2
    assert not s

# Generated at 2022-06-21 09:19:06.524415
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a1 = _Alpha('a')
    a2 = _Alpha('b')
    s1 = text_type('a')
    s2 = text_type('b')
    assert a1 == a1
    assert a1 == s1
    assert s1 == a1
    assert not a1 == a2
    assert not a1 == s2
    assert not s1 == a2
    assert not a1 == 1
    assert not s1 == 1



# Generated at 2022-06-21 09:19:09.817377
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != 'b'
    assert 'a' != _Alpha('b')
    assert _Numeric(0) != _Alpha('a')
    assert _Alpha('a') != _Numeric(0)


# Generated at 2022-06-21 09:19:21.716750
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # check that repr of object is correct,
    # if it is, then parse result is correct
    repres = "SemanticVersion('0.0.0')"
    objSemanticVersion = SemanticVersion('0.0.0')
    assert repr(objSemanticVersion) == repres, "SemanticVersion parse is not correct"

    repres = "SemanticVersion('1.0.0')"
    objSemanticVersion = SemanticVersion('1.0.0')
    assert repr(objSemanticVersion) == repres, "SemanticVersion parse is not correct"

    repres = "SemanticVersion('1.2.3')"
    objSemanticVersion = SemanticVersion('1.2.3')
    assert repr(objSemanticVersion) == repres, "SemanticVersion parse is not correct"


# Generated at 2022-06-21 09:19:33.156400
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-21 09:19:40.326365
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('2.2.2-alpha') == '2.2.2-alpha'
    assert SemanticVersion('2.2.2+foo.bar') == '2.2.2+foo.bar'
    assert SemanticVersion('2.2.2-alpha+foo.bar') == '2.2.2-alpha+foo.bar'
    assert SemanticVersion('2.2.2-alpha.foo+foo.bar') == '2.2.2-alpha.foo+foo.bar'

# Generated at 2022-06-21 09:19:55.564817
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.basic import AnsibleModule

    def run_test(version, expected=None):
        module = AnsibleModule(
            argument_spec=dict(
                version=dict(type='str'),
            ),
            supports_check_mode=True
        )

        try:
            actual = SemanticVersion.from_loose_version(LooseVersion(version))
        except Exception as e:
            module.fail_json(msg=e)

        if expected is None:
            expected = version

        module.exit_json(changed=False, version=version, actual=text_type(actual), expected=expected)

    test1_version = '2.2.0'
    test1_expected = '2.2.0'
    run_test(test1_version, test1_expected)

    test

# Generated at 2022-06-21 09:20:03.210521
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    from ansible.module_utils.six import PY2, PY3

    # Scenario:
    #
    # Success:
    # If self.compare(other) >= 0 returns True
    # Else returns None
    #
    # Failure:
    # If self.compare(other) >= 0 returns True
    # Else returns ValueError

    s = SemanticVersion('1.2.3')

    # Success:
    # If self.compare(other) >= 0 returns True
    # Else returns None
    if PY2:
        assert (s == '1.2.3')
        assert (s >= '1.2.3')
        assert (s < '1.2.4')
        assert (s != '1.2.4')
        assert (s <= '1.2.4')

# Generated at 2022-06-21 09:20:07.177961
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    test for SemanticVersion.from_loose_version
    """

    for version in (
            '0.1.1', '0.0.0', '0.0.2', '1.1.1', '0.0.0-alpha+buildhash', '1.1.0-rc.0'
    ):
        loose_version = LooseVersion(version)
        semver = SemanticVersion.from_loose_version(loose_version)
        assert semver == version

# Generated at 2022-06-21 09:20:14.709578
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(
        LooseVersion('0.3.0')
    ) == SemanticVersion('0.3.0')
    assert SemanticVersion.from_loose_version(
        LooseVersion('0.3')
    ) == SemanticVersion('0.3.0')
    assert SemanticVersion.from_loose_version(
        LooseVersion('0.3.0-beta')
    ) == SemanticVersion('0.3.0-beta')
    assert SemanticVersion.from_loose_version(
        LooseVersion('0.3.0+build.123+foo.bar')
    ) == SemanticVersion('0.3.0+build.123+foo.bar')

# Generated at 2022-06-21 09:20:17.862043
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    """Test Case for ''assert ... != ...'' expression."""
    msg = '1.0.0'
    assert SemanticVersion('1.0.0') != msg


# Generated at 2022-06-21 09:20:19.842457
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    entrylist = [
        "__gt__",
        False,
    ]
    return entrylist


# Generated at 2022-06-21 09:20:31.035420
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    from ansible.module_utils.six import PY2, PY3
    # This is the same test that is in distutils.tests.test_version.TestVersion.test_ge
    if PY3:
        v1 = SemanticVersion('1.5.1')
        v2 = SemanticVersion('1.5.2b2')
        v3 = SemanticVersion('161.5.2b2')
        assert v1 >= v2
        assert v3 >= v2
    else:
        # Py2's implementation of distutils.version.Version is very different
        # and doesn't properly implement the __ge__ functionality
        # This is what makes equality testing so much more complicated in
        # the _cmp method above
        v1 = SemanticVersion('1.5.1')

# Generated at 2022-06-21 09:20:34.827110
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion(vstring='1.0.0-alpha.1')
    v2 = SemanticVersion(vstring='1.0.0')
    v3 = SemanticVersion(vstring='1.0.0+1234')
    v4 = SemanticVersion(vstring='1.0.1-alpha.1+1234')
    v5 = SemanticVersion(vstring='1.0.0-beta.1+1234')
    v6 = SemanticVersion(vstring='1.0.1+1234')
    v7 = SemanticVersion(vstring='2.0.0+1234')
    v8 = SemanticVersion(vstring='0.1.1+1234')
    v9 = SemanticVersion(vstring='1.1.1+1234')

# Generated at 2022-06-21 09:20:37.458931
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha('3.0').__ne__('3.0')
    assert _Alpha('3.0').__ne__('3.1')

# Generated at 2022-06-21 09:20:45.421620
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('1') == _Alpha('1')
    assert _Alpha('1') != 1
    assert _Alpha('1') != _Numeric('1')
    assert _Alpha('1') < '2'
    assert _Alpha('1') <= _Alpha('2')
    assert _Alpha('2') > _Alpha('1')
    assert _Alpha('2') >= _Alpha('1')
    assert _Alpha('foo') < _Numeric('1')
    try:
        _Alpha('1') > _Alpha('foo')
    except ValueError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 09:21:03.988683
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-21 09:21:06.223363
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(0)) == '0'
    assert repr(_Numeric(1)) == '1'
    assert repr(_Numeric(1337)) == '1337'
    assert repr(_Numeric(1337)) == str(1337)


# Generated at 2022-06-21 09:21:09.984575
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('a')
    assert a.__ne__('a') == False
    assert a.__ne__('b') == True
    a = _Alpha(1)
    assert a.__ne__(1) == False
    assert a.__ne__(2) == True


# Generated at 2022-06-21 09:21:13.301090
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    version = "1.0.0"
    semver = SemanticVersion(version)
    assert semver.__eq__(version)


# Generated at 2022-06-21 09:21:15.248496
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != 'b'
    assert _Alpha('a') != _Alpha('b')


# Generated at 2022-06-21 09:21:24.552420
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('0.0.0')
    assert SemanticVersion('1.0.0') > SemanticVersion('0.1.0')
    assert SemanticVersion('1.0.0') > SemanticVersion('0.10.0')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha.5')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha.beta')

# Generated at 2022-06-21 09:21:31.082624
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(5) >= _Numeric(5)
    assert _Numeric(5) >= 5
    assert not _Numeric(5) >= _Alpha('5')
    assert not _Numeric(5) >= _Alpha('6')
    assert not _Numeric(5) >= _Alpha('4')
    assert not _Numeric(5) >= _Numeric(6)
    assert not _Numeric(5) >= _Numeric(4)


# Generated at 2022-06-21 09:21:40.415395
# Unit test for constructor of class _Alpha
def test__Alpha():
   assert _Alpha('a') == 'a'
   assert _Alpha('a') == _Alpha('a')
   assert _Alpha('a') == _Alpha('a')
   assert _Alpha('a') == 'a'
   assert _Alpha('a') != 'b'
   assert _Alpha('b') != 'a'
   assert _Alpha('a') < 'b'
   assert _Alpha('a') < _Alpha('b')
   assert _Alpha('a') <= 'b'
   assert _Alpha('a') <= 'a'
   assert _Alpha('a') <= _Alpha('a')
   assert _Alpha('a') <= _Alpha('b')
   assert _Alpha('b') > 'a'
   assert _Alpha('b') > _Alpha('a')
   assert _Alpha('b') >= 'a'
   assert _Alpha('b')

# Generated at 2022-06-21 09:21:48.133881
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v1 = SemanticVersion('3.3.0')
    v2 = SemanticVersion('5.5.0')
    assert v1 < v2

    v1 = SemanticVersion('5.5.0')
    v2 = SemanticVersion('5.5.1')
    assert v1 < v2

    v1 = SemanticVersion('1.8.0')
    v2 = SemanticVersion('1.8.3')
    assert v1 < v2

    v1 = SemanticVersion('3.3.0')
    v2 = SemanticVersion('3.3.0-alpha.1')
    assert v1 < v2

    v1 = SemanticVersion('3.3.0-alpha.1')
    v2 = SemanticVersion('3.3.0-beta.1')

# Generated at 2022-06-21 09:21:51.808601
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    SV = SemanticVersion()
    assert SV.__repr__() == "SemanticVersion(None)"
    SV.vstring = "1.2.3"
    assert SV.__repr__() == "SemanticVersion('1.2.3')"


# Generated at 2022-06-21 09:21:59.943034
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    n = _Numeric(1)
    assert n.__ne__(1)
    assert n.__ne__(1.0)
    assert n.__ne__('1')
    assert not n.__ne__(2)
    assert not n.__ne__(2.0)
    assert not n.__ne__('2')
    assert not n.__ne__(_Numeric(1))
    assert not n.__ne__(_Numeric(1.0))


# Generated at 2022-06-21 09:22:06.862077
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = '1.2.0b1'
    lv = LooseVersion(v)
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == '1.2.0-0.b1'

    v = '1.2.0'
    lv = LooseVersion(v)
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == v


# Generated at 2022-06-21 09:22:16.472042
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') != 'b'
    assert _Alpha('a') < 'b'
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= 'a'

    assert not _Alpha('a') < 'a'
    assert not _Alpha('a') <= 'a'
    assert _Alpha('a') >= 'a'

    assert _Alpha('b') > 'a'
    assert _Alpha('b') >= 'a'
    assert _Alpha('b') >= 'b'

    assert not _Alpha('b') <= 'b'
    assert not _Alpha('b') < 'b'


# Generated at 2022-06-21 09:22:26.238083
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('A')
    assert _Alpha('a1') < _Alpha('a2')
    assert _Alpha('a1') < _Alpha('a20')
    assert _Alpha('a001') < _Alpha('a002')
    assert _Alpha('a001') < _Alpha('a020')
    assert _Alpha('a') < _Alpha('a-')
    assert _Alpha('a') < _Alpha('a.')
    assert _Alpha('a') < _Alpha('a00.')
    assert _Alpha('a00') < _Alpha('a00.')
    assert _Alpha('a') < _Alpha('a-rc')
    assert _Alpha('a') < _Alpha('a.-rc')

# Generated at 2022-06-21 09:22:29.966811
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('1') <= _Numeric('1')
    assert _Numeric('5') <= _Numeric('5')
    assert _Numeric('1') <= _Numeric('5')
    assert _Numeric('5') >= _Numeric('5')
    assert _Numeric('1') <= _Numeric('5')


# Generated at 2022-06-21 09:22:37.340284
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(2)
    d = _Numeric(5)
    assert (a > b) is False
    assert (a > c) is False
    assert (a > d) is True
    assert (b > c) is False
    assert (b > d) is True
    assert (c > d) is True


# Generated at 2022-06-21 09:22:44.048005
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha('a') > _Alpha('a')
    assert not _Alpha('a') > _Alpha('b')
    assert _Alpha('b') > _Alpha('a')
    assert not _Alpha('a') > 'a'
    assert not _Alpha('a') > 'b'
    assert _Alpha('b') > 'a'
    try:
        _Alpha('a') > _Numeric(1)
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-21 09:22:45.903595
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    versionA = SemanticVersion(vstring="0.0.1-alpha.beta")
    versionB = SemanticVersion(vstring="1.2.3+buildmetadata")

    assert versionA != versionB
    assert not (versionA != versionA)


# Generated at 2022-06-21 09:22:47.732532
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    num1 = _Numeric(1)
    num2 = _Numeric(2)
    assert num1 < num2


# Generated at 2022-06-21 09:22:52.210352
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > 'a'
    assert not _Alpha('a') > 'b'
    assert not _Alpha('a') > _Alpha('a')
    assert not _Alpha('a') > _Alpha('b')
    assert _Alpha('a') > _Numeric('0')
    assert not _Alpha('a') > _Numeric('1')
    assert not _Alpha('0') > _Numeric('0')



# Generated at 2022-06-21 09:23:12.306775
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= '1.0.0'
    assert SemanticVersion('1.0.0') <= '1.1.0'
    assert SemanticVersion('1.0.0') <= '2.0.0'
    assert SemanticVersion('1.0.0') <= '0.1.0'
    assert SemanticVersion('1.0.0') <= '0.0.2'

    assert (not SemanticVersion('1.0.0') <= '0.0.1')

    assert SemanticVersion('1.0.0-alpha') <= '1.0.0-alpha'
    assert SemanticVersion('1.0.0-alpha.1') <= '1.0.0-alpha.1'

# Generated at 2022-06-21 09:23:21.757193
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-21 09:23:29.958542
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a = SemanticVersion('2.0.0')
    b = SemanticVersion('2.0.1')
    assert( a <= SemanticVersion('2.0.0'))
    assert( a <= SemanticVersion('2.0.0-0'))
    assert( a <= SemanticVersion('2.0.0-1'))
    assert( a <= SemanticVersion('2.0.0-rc'))
    assert( a <= SemanticVersion('2.0.0-rc.1'))
    assert( a <= SemanticVersion('2.0.0+0'))
    assert( a <= SemanticVersion('2.0.0+1'))
    assert( a <= SemanticVersion('2.0.0+rc'))

# Generated at 2022-06-21 09:23:34.576408
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    numeric1 = _Numeric(1)
    numeric2 = _Numeric(2)
    numeric3 = _Numeric(3)
    numeric3_dup = _Numeric(3)

    assert numeric1 == 1
    assert not numeric1 == 2
    assert not numeric1 == '1'
    assert not numeric1 == object()

    assert not numeric2 == 1
    assert numeric2 == 2
    assert not numeric2 == '2'
    assert not numeric2 == object()

    assert not numeric2 == 3
    assert not numeric3 == 2
    assert numeric3 == 3
    assert numeric3 == numeric3_dup
    assert not numeric3 == '3'
    assert not numeric3 == object()



# Generated at 2022-06-21 09:23:36.871543
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('b') < _Alpha('c')
    assert _Alpha('b') <= _Alpha('c')
    assert _Alpha('b') <= _Alpha('b')
    assert not _Alpha('b') <= _Alpha('a')


# Generated at 2022-06-21 09:23:41.690345
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(2) >= _Numeric(1)
    assert not _Numeric(1) >= _Numeric(2)
    assert _Numeric(2) >= _Alpha('1.alpha')

if __name__ == '__main__':
    test__Numeric___ge__()

# Generated at 2022-06-21 09:23:45.072423
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha(b'test') < _Alpha(b'test')
    assert _Alpha(b'test') < _Alpha(b'test2')

    with pytest.raises(ValueError):
        _Alpha(b'test') < _Numeric(b'100')


# Generated at 2022-06-21 09:23:56.720074
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-21 09:24:05.576071
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    test_data = [
        ('1.2.3', '1.2.3', False),
        ('1.2.3-beta', '1.2.3-beta', False),
        ('1.2.3+1', '1.2.3+1', False),
        ('1.2.3-beta+1', '1.2.3-beta+1', False),
    ]
    for value1, value2, expected in test_data:
        ver1 = SemanticVersion(value1)
        ver2 = SemanticVersion(value2)
        assert ver1 != ver2 == expected



# Generated at 2022-06-21 09:24:09.374990
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('2.0.0')
    actual = v1 != v2
    assert actual is True, "Failed: %s != %s returned %s, expected %s" % (v1.vstring, v2.vstring, actual, True)


# Generated at 2022-06-21 09:24:39.179146
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test for version eq
    assert _Alpha('test') <= 'test'
    assert _Alpha('test') <= _Alpha('test')
    assert _Alpha('test') <= _Alpha('test')
    assert _Alpha('test') <= 'test'
    assert _Alpha('test') <= _Alpha('test')
    assert _Alpha('test') <= 'test'
    assert not (_Alpha('test') <= 'TEST')
    assert not (_Alpha('test') <= _Alpha('TEST'))
    assert not (_Alpha('test') <= 'TEST')
    assert not (_Alpha('test') <= 'TEST')

    # Test for version less than
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= _

# Generated at 2022-06-21 09:24:43.016126
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < 'b'
    assert _Alpha('c') < _Alpha('d')
    assert _Alpha('e') < _Numeric('2')
    assert not _Alpha('f') < _Alpha('f')
    assert not _Alpha('g') < _Alpha('g')



# Generated at 2022-06-21 09:24:49.535979
# Unit test for constructor of class _Numeric
def test__Numeric():
    class N(object):
        pass
    n = _Numeric(1)
    assert not isinstance(n, N)
    assert n == _Numeric(1)
    assert n != _Numeric(2)
    assert n == 1
    assert n != 2
    assert n <= _Numeric(1)
    assert n >= _Numeric(1)
    assert n <= 1
    assert n >= 1
    assert n < _Numeric(2)
    assert n < 2
    assert n > _Numeric(0)
    assert n > 0
    assert not n == _Numeric(0)
    assert not n == 0
    assert not n != _Numeric(1)
    assert not n != 1
    assert not n >= _Numeric(2)
    assert not n >= 2

# Generated at 2022-06-21 09:24:56.663875
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('pre.1') > _Alpha('pre.0')
    assert _Alpha('pre.1') > _Alpha('pre.0')
    assert _Alpha('alpha') > _Alpha('beta')
    assert _Alpha('alpha') > _Alpha('alpha.1')
    assert _Alpha('alpha.1') > _Alpha('alpha.beta')
    assert _Alpha('alpha.1') > _Alpha('alpha.beta.1')
    assert _Alpha('alpha.1') > _Alpha('alpha.beta.2')
    assert _Alpha('alpha.1') > _Alpha('alpha.beta.11')
    assert _Alpha('alpha.beta') > _Alpha('alpha.beta.1')
    assert _Alpha('alpha.beta') > _Alpha('alpha.beta.11')



# Generated at 2022-06-21 09:25:03.665484
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('1') == text_type('1')
    assert _Alpha('a') == text_type('a')
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('1') < text_type('2')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < text_type('b')
    assert _Alpha('1') < _Alpha('a')
    assert _Alpha('1') < text_type('a')
    assert _Alpha('1') > _Alpha('0')
    assert _Alpha('1') > text_type('0')
    assert _Alpha('a') > _Alpha('A')
    assert _Alpha('a') > text_type('A')


# Generated at 2022-06-21 09:25:07.519197
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)

    assert _Numeric(1) < 2

    assert 1 < _Numeric(2)

    assert not _Numeric(2) < 1


# Generated at 2022-06-21 09:25:10.737804
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == 1

    assert not _Numeric(1) == _Numeric(2)
    assert not _Numeric(1) == 2
    assert not _Numeric(1) == '1'


# Generated at 2022-06-21 09:25:13.415589
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('alpha') == _Alpha('alpha')
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('alpha') == 'ALPHA'
    assert _Alpha('alpha') == 'Beta'


# Generated at 2022-06-21 09:25:21.334099
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha_a = _Alpha('a')
    alpha_b = _Alpha('b')
    alpha_a_lower = _Alpha('A')
    assert not alpha_a == alpha_b
    assert alpha_a < alpha_b
    assert alpha_a <= alpha_b
    assert not alpha_a > alpha_b
    assert not alpha_a >= alpha_b
    assert alpha_a_lower == alpha_a
    assert not alpha_a_lower < alpha_a
    assert alpha_a_lower <= alpha_a
    assert not alpha_a_lower > alpha_a
    assert alpha_a_lower >= alpha_a


# Generated at 2022-06-21 09:25:29.895301
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    SV1 = SemanticVersion('0.3.5')

    assert SV1.__gt__('0.3.5') == False
    assert SV1.__gt__('0.3.24') == False
    assert SV1.__gt__('0.24.5') == False
    assert SV1.__gt__('24.3.5') == False

    assert SV1.__gt__('0.3.4') == True
    assert SV1.__gt__('0.2.5') == True
    assert SV1.__gt__('0.2.25') == True
    assert SV1.__gt__('0.3') == True
    assert SV1.__gt__('0') == True
    assert SV1.__gt__(0) == True


# Generated at 2022-06-21 09:25:45.350310
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    """ Test __repr__ of _Numeric class """
    test = _Numeric('0')
    assert test.__repr__() == '0'


# Generated at 2022-06-21 09:25:56.431804
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0')

    assert v1 == v2
    assert not (v1 != v2)

    v2 = SemanticVersion('1.0.1')

    assert v1 != v2
    assert not (v1 == v2)

    v2 = SemanticVersion('1.1.0')

    assert v1 != v2
    assert not (v1 == v2)

    v2 = SemanticVersion('2.0.0')

    assert v1 != v2
    assert not (v1 == v2)

    v2 = SemanticVersion('1.0.0-alpha')

    assert v1 != v2
    assert not (v1 == v2)


# Generated at 2022-06-21 09:26:00.364928
# Unit test for constructor of class _Alpha
def test__Alpha():
    #
    # Init
    #
    alpha = _Alpha("a")

    #
    # Verify
    #
    if alpha.specifier != "a":
        raise AssertionError("_Alpha().specifier is not 'a'")


# Generated at 2022-06-21 09:26:02.396191
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > '0.9.9'



# Generated at 2022-06-21 09:26:13.263189
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    v.parse('1.0.0')
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v.parse('1.0.0-alpha.1')
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert v.buildmetadata == ()

    v.parse('1.0.0-alpha.1.beta.1')
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0

# Generated at 2022-06-21 09:26:19.140763
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alpha = _Alpha('')
    assert alpha.__gt__('') == False
    assert alpha.__gt__('a') == False
    assert alpha.__gt__(1) == False
    assert alpha.__gt__(_Alpha('a')) == False
    assert alpha.__gt__(_Numeric('1')) == True
    assert alpha.__gt__(_Numeric(1)) == True


# Generated at 2022-06-21 09:26:22.159452
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    test_cases = (
        (1, 1, True),
        (1, 2, True),
        (2, 1, False),
    )
    for left, right, expected in test_cases:
        assert _Numeric(left).__ge__(_Numeric(right)) == expected



# Generated at 2022-06-21 09:26:32.026665
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    eq = [
        (_Numeric(0), _Numeric(0)),
        (_Numeric(1), _Numeric(1)),
        (_Numeric(0), 0),
        (_Numeric(1), 1),
    ]
    ne = [
        (_Numeric(0), _Numeric(1)),
        (_Numeric(1), _Numeric(0)),
        (_Numeric(0), 1),
        (_Numeric(1), 0),
    ]

    for a, b in eq:
        assert a <= b
        assert b <= a

    for a, b in ne:
        assert a != b
        assert b != a
        assert a <= b
        assert not b <= a
        assert not a > b
        assert b > a


# Generated at 2022-06-21 09:26:35.490243
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion()
    version.parse('1.2.3-alpha.1+build.5')
    assert (1,2,3) == version.core
    assert ('alpha', '1') == version.prerelease
    assert ('build', '5') == version.buildmetadata


# Generated at 2022-06-21 09:26:40.923508
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha(1)) == '1'
    assert repr(_Alpha('1')) == "'1'"
    assert repr(_Alpha('beta')) == "'beta'"
    assert repr(_Alpha('1.2')) == "'1.2'"
