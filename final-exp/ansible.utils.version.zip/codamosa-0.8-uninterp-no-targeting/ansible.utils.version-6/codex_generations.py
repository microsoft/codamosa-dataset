

# Generated at 2022-06-21 09:16:56.506518
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('0.0.0') < SemanticVersion('1.0.0')
    assert SemanticVersion('0.0.0') <= SemanticVersion('1.0.0')
    assert SemanticVersion('0.0.0') <= SemanticVersion('0.0.0')

    assert SemanticVersion('0.0.0-alpha.1') < SemanticVersion('0.0.0-alpha.2')
    assert SemanticVersion('0.0.0-alpha.1') <= SemanticVersion('0.0.0-alpha.2')
    assert SemanticVersion('0.0.0-alpha.1') <= SemanticVersion('0.0.0-alpha.1')

    assert SemanticVersion('0.0.0-alpha.1') < SemanticVersion('0.0.0-beta.1')

# Generated at 2022-06-21 09:16:57.984655
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha("a")
    assert a <= "a"
    assert a is not None


# Generated at 2022-06-21 09:17:07.226320
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('1') == '1'
    assert _Alpha('a') != 'b'
    assert _Alpha('a') != 1
    assert _Alpha('a') < 'b'
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= 'a'
    assert _Alpha('b') >= 'a'
    assert _Alpha('a') >= 'a'
    assert _Alpha('b') > 'a'
    assert _Alpha('1') > 0
    assert _Alpha('1') >= 0
    assert _Alpha('1') <= 1


# Generated at 2022-06-21 09:17:17.892588
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3') == '1.2.3'
    assert not SemanticVersion('1.2.3') == '2.3.4'
    assert not SemanticVersion('1.2.3') == '2.2.3'
    assert not SemanticVersion('1.2.3') == '1.3.3'
    assert not SemanticVersion('1.2.3') == '1.2.4'

    # prerelease
    assert not SemanticVersion('1.2.3-alpha.1') == '1.2.3'
    assert not SemanticVersion('1.2.3') == '1.2.3-alpha.1'

    assert SemanticVersion('1.2.3-alpha.1') == '1.2.3-alpha.1'
    assert not Sem

# Generated at 2022-06-21 09:17:27.715502
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.1')

    assert SemanticVersion('1.0.0.rc.1') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0.rc.1') < SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0.rc.1') < SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0.rc.1') < SemanticVersion('1.0.0')

# Generated at 2022-06-21 09:17:29.810228
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') != 'b'
    assert _Alpha('a') != _Alpha('b')



# Generated at 2022-06-21 09:17:32.611438
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    SV = SemanticVersion("2.0.0")

    assert repr(SV) == "SemanticVersion('2.0.0')"


# Generated at 2022-06-21 09:17:42.817117
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    # Compare int
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(0) <= _Numeric(1)
    assert _Numeric(0) >= _Numeric(0)
    # Compare str
    assert _Numeric(1) > _Numeric('0')
    assert _Numeric('0') < _Numeric(1)
    assert _Numeric('0') <= _Numeric(1)
    assert _Numeric('0') >= _Numeric('0')
    # Compare _Alpha
    assert _Numeric(1) > _Alpha('0')
    assert _Numeric(0) < _Alpha('1')
    assert _Numeric(0) <= _Alpha('1')
    assert _Numeric('0') >= _

# Generated at 2022-06-21 09:17:52.194872
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-21 09:18:01.513236
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('0.0.0') <= '0.0.1'
    assert SemanticVersion('1.0.0') <= '0.0.1'
    assert SemanticVersion('0.0.1') <= '0.0.1'
    assert SemanticVersion('1.1.1-1.0.0') <= '1.1.1-alpha'
    assert SemanticVersion('1.1.1-alpha') <= '1.1.1-alpha'
    assert SemanticVersion('1.1.1') <= '1.1.1-alpha'
    assert SemanticVersion('1.1.1-1.1.1') <= '1.1.1-1.a'

# Generated at 2022-06-21 09:18:13.135696
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    version1 = '1.2.3'
    version2 = '1.2.4'
    version3 = '1.2.4-beta1'

    semver1 = SemanticVersion(version1)
    semver2 = SemanticVersion(version2)
    semver3 = SemanticVersion(version3)

    assert semver1.__ne__(semver1) is False
    assert semver1.__ne__(semver2) is True
    assert semver1.__ne__(semver3) is True


# Generated at 2022-06-21 09:18:25.727761
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion("1") == SemanticVersion("1")
    assert SemanticVersion("1") == SemanticVersion("1.0")
    assert SemanticVersion("1") == SemanticVersion("1.0.0")
    assert SemanticVersion("1.2") == SemanticVersion("1.2.0")
    assert SemanticVersion("1.2.3") == SemanticVersion("1.2.3")
    assert SemanticVersion("1.0.0+foo") == SemanticVersion("1+foo")
    assert SemanticVersion("1.0.0-1+foo") == SemanticVersion("1-1+foo")
    assert SemanticVersion("1.0.0-1-2+foo") == SemanticVersion("1-1-2+foo")


# Generated at 2022-06-21 09:18:28.869987
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    obj = _Alpha('specifier')

    assert obj.__ne__('specifier') == False
    assert obj.__ne__(obj) == False
    assert obj.__ne__(None) == True



# Generated at 2022-06-21 09:18:38.425352
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test 1
    # Input: '1.2.3'
    # Output: (1, 2, 3)
    s = SemanticVersion()
    s.parse('1.2.3')
    assert s.major == 1
    assert s.minor == 2
    assert s.patch == 3
    assert s.prerelease == ()
    assert s.buildmetadata == ()
    # Test 2
    # Input: '1.2.3-alpha+123'
    # Output: (1, 2, 3, 'alpha', 123)
    s = SemanticVersion()
    s.parse('1.2.3-alpha.1+123')
    assert s.major == 1
    assert s.minor == 2
    assert s.patch == 3

# Generated at 2022-06-21 09:18:50.211236
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(5) >= 1
    assert _Numeric(5) >= _Numeric(1)
    assert _Numeric(5) >= text_type(1)
    assert _Numeric(5) >= _Numeric(5)
    assert _Numeric(5) >= text_type(5)
    assert _Numeric(5) >= _Alpha('5')
    assert _Numeric(5) >= _Alpha('6')
    assert _Numeric(5) >= [_Numeric(3), 5]
    assert not _Numeric(5) >= 6
    assert not _Numeric(5) >= _Numeric(6)
    assert not _Numeric(5) >= text_type(6)
    assert not _Numeric(5) >= _Alpha('7')

# Generated at 2022-06-21 09:18:51.867346
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('2') >= _Alpha('3') == False


# Generated at 2022-06-21 09:18:54.207968
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    testvalue =  "0.0.0"
    assert (not (Tag(testvalue) == testvalue))


# Generated at 2022-06-21 09:18:57.722560
# Unit test for constructor of class _Numeric
def test__Numeric():
    # For integer test
    value = _Numeric(5)
    assert isinstance(value, _Numeric)
    assert value == 5

    # For string test
    value = _Numeric("5")
    assert isinstance(value, _Numeric)
    assert value == 5


# Generated at 2022-06-21 09:19:03.071946
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    """Unit test for method __lt__ of class SemanticVersion"""

    vers_mine = SemanticVersion("1.4.2")
    vers_other = SemanticVersion("1.4.2")
    ok = vers_mine < vers_other
    assert ok == False


# Generated at 2022-06-21 09:19:10.761154
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    # Test if _Numeric__gt__ method returns expected result
    # given the data below.

    # testcase 1
    assert _Numeric('0') > 0

    # testcase 2
    assert not _Numeric('0') > 1

    # testcase 3
    assert not _Numeric('1') > 1

    # testcase 4
    assert _Numeric('2') > 1

    # testcase 5
    assert _Numeric('1') > '0'

    # testcase 6
    assert not _Numeric('1') > '2'

    # testcase 7
    assert _Numeric('2') > _Numeric('1')

    # testcase 8
    assert _Numeric('1') > _Alpha('0')


# Generated at 2022-06-21 09:19:22.826081
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(5) >= _Numeric(4)
    assert _Numeric(5) >= _Numeric(5)
    assert _Numeric(5) < _Numeric(6)
    assert not _Numeric(5) >= _Numeric(6)


# Generated at 2022-06-21 09:19:28.869685
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('x') < _Alpha('y')
    assert _Alpha('devel') < _Alpha('rc1')
    assert _Alpha('rc1') < _Alpha('rc2')
    assert _Alpha('rc1') < _Alpha('rc11')


# Generated at 2022-06-21 09:19:38.001988
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    for v in ('0.0.0', '1.2.3', '10.20.30', '1.2.3-4', '1.2.3-4alpha5', '1.2.3-4.5.6', '1.2.3-4.5.6alpha7', '1.2.3+build', '1.2.3+build.2.b8f12d7', '1.2.3-beta+build.11.e0f985a', '1.2.3-beta+exp.sha.5114f85'):
        try:
            res = SemanticVersion(v)
            assert res is not None
        except ValueError:
            print("Unable to parse %s" % v)
            assert False



# Generated at 2022-06-21 09:19:45.489679
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert not _Numeric('1') < _Numeric('1')
    assert not _Numeric('2') < _Numeric('1')

    # Test bvi
    assert not _Numeric('1') < _Numeric('1')
    assert not _Numeric('2') < _Numeric('1')
    assert _Numeric('1') < _Numeric('2')


# Generated at 2022-06-21 09:19:55.354426
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Test with valid inputs
    assert (SemanticVersion('1.6.1') == '1.6.1') is True
    assert (SemanticVersion('1.7.0') == '1.7.0') is True
    assert (SemanticVersion('2.0.0') == '2.0.0') is True
    assert (SemanticVersion('2.0.1') == '2.0.1') is True
    assert (SemanticVersion('2.1.0') == '2.1.0') is True
    assert (SemanticVersion('2.12.0') == '2.12.0') is True
    assert (SemanticVersion('1.0.0-alpha+001') == '1.0.0-alpha+001') is True

# Generated at 2022-06-21 09:20:00.638166
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    # A new instance of _Alpha with the specifier '2'
    obj_with_specifier_2 = _Alpha('2')
    # The repr() of that object
    repr_of_obj_with_specifier_2 = repr(obj_with_specifier_2)
    # Test that repr() on a new instance of _Alpha with the specifier '2' is '_Alpha(\'2\')'
    assert repr_of_obj_with_specifier_2 == "_Alpha('2')"


# Generated at 2022-06-21 09:20:03.117830
# Unit test for constructor of class _Numeric
def test__Numeric():
    n = _Numeric(1)
    assert n.specifier == 1
    assert n != '1'
    assert n != 1
    assert n == _Numeric('1')
    assert n == _Numeric(1)
    assert n != _Numeric('x')
    assert n != _Alpha('1')


# Generated at 2022-06-21 09:20:04.281429
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    obj = _Alpha(1)
    assert repr(obj) == '1'


# Generated at 2022-06-21 09:20:10.595875
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # test when both specifiers are identical
    assert not _Alpha('test') < _Alpha('test')

    # test when specifiers are different
    assert _Alpha('test') < _Alpha('test2')

    # test when specifiers are different in length
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('abc') < _Alpha('bcd')

    # test when specifiers are different in type
    assert _Alpha('a') < _Alpha(2)

    # test when other is a string
    assert _Alpha('b') < 'c'

    # test when other is not a string or a _Alpha
    assert _Alpha('b') < 1

    # test when other is not a string, a _Alpha, or an int

# Generated at 2022-06-21 09:20:15.726434
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3-alpha') != SemanticVersion('1.2.3-alpha.2')
    assert SemanticVersion('1.2.3-alpha') == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3-alpha.0') == SemanticVersion('1.2.3-alpha.00')
    assert SemanticVersion('1.2.3-alpha-0.0') == SemanticVersion('1.2.3-alpha-0')
    assert SemanticVersion('1.2.3-alpha_0') == SemanticVersion('1.2.3-alpha-0')
    assert SemanticVersion('1.2.3-alpha-10.1') == SemanticVersion('1.2.3-alpha-010.01')

    assert SemanticVersion

# Generated at 2022-06-21 09:20:23.459192
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion("0.0.1")
    v2 = SemanticVersion("0.0.1")
    assert v1 >= v2



# Generated at 2022-06-21 09:20:34.445202
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion("0.0.0") <= "0.0.0"
    assert SemanticVersion("1.0.0") <= "1.0.0"
    assert SemanticVersion("1.0.0") <= "1.0.0-alpha"
    assert not SemanticVersion("1.0.0-beta") <= "1.0.0-alpha"
    assert SemanticVersion("1.1.0") <= "1.1.0"
    assert SemanticVersion("1.1.0") <= "1.1.0-alpha"
    assert not SemanticVersion("1.1.0-beta") <= "1.1.0-alpha"
    assert SemanticVersion("1.1.1") <= "1.1.1"

# Generated at 2022-06-21 09:20:39.006925
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    test_case_data = [
        (1, 2),
        (2, 2),
        (3, 2),
    ]
    for item in test_case_data:
        a = _Numeric(item[0])
        b = _Numeric(item[1])
        assert (a < b) == (item[0] < item[1])


# Generated at 2022-06-21 09:20:40.828392
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    obj = _Numeric(1)
    assert obj.__repr__() == '1'


# Generated at 2022-06-21 09:20:50.211183
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.3.0')
    assert SemanticVersion('1.2.3') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3-0')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3-1')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3-1.0')

# Generated at 2022-06-21 09:20:57.589924
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('3') < _Numeric('4'), '3 < 4'
    assert _Numeric('3') < _Numeric('3.0.0'), '3 < 3.0.0'
    assert _Numeric('1') < _Numeric('1.1'), '1 < 1.1'
    assert _Numeric('1') < _Numeric('1.0.0.0.0.0'), '1 < 1.0.0.0.0.0'


# Generated at 2022-06-21 09:21:04.442941
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():

    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < '2'
    assert not (_Numeric('1') > '2')
    assert _Numeric('3') > _Numeric('2')
    assert _Numeric('2') < _Alpha('a')
    assert not (_Numeric('2') > _Alpha('a'))
    assert _Alpha('b') > _Numeric('2')
    assert not (_Alpha('a') < _Numeric('2'))
    assert _Numeric('3') > _Alpha('b')
    assert _Alpha('c') > _Numeric('3')



# Generated at 2022-06-21 09:21:05.397938
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha(1)) == repr(1)


# Generated at 2022-06-21 09:21:09.180936
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    # Function to Unit test method __eq__ of class _Numeric
    a = _Numeric(5)
    b = _Numeric(5)
    assert a == b   # Two Numbers are equal
    c = _Alpha("5")
    assert a == c   # Compare a number with a string


# Generated at 2022-06-21 09:21:14.745076
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert not _Numeric(0) > _Numeric(1)
    assert _Numeric(1) > 0
    assert not _Numeric(0) > 1

    assert _Numeric(1) > _Alpha('0')
    assert not _Numeric(0) > _Alpha('1')



# Generated at 2022-06-21 09:21:24.985033
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('01')
    assert a >= _Alpha('1')
    assert a >= '1'
    assert a >= _Numeric('1')
    assert a >= 1

    assert not a >= _Alpha('2')
    assert not a >= _Numeric('2')
    assert not a >= 2
    assert not a >= '2'

    assert a >= '0'
    assert a >= 0


# Generated at 2022-06-21 09:21:29.908954
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')
    assert _Alpha(2) == _Alpha(2)
    assert _Alpha(2) == 2
    assert 2 == _Alpha(2)


# Generated at 2022-06-21 09:21:32.584683
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('alpha') == _Alpha('alpha')
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('alpha') != _Alpha('beta')
    assert _Alpha('alpha') != 'beta'


# Generated at 2022-06-21 09:21:34.314797
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    sv = SemanticVersion('2.0.5')
    assert repr(sv) == "SemanticVersion('2.0.5')"


# Generated at 2022-06-21 09:21:40.061634
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    ver = SemanticVersion.from_loose_version(
        LooseVersion(
            '0.1.2a0.dev456+3d13c23e'
        )
    )
    assert ver.is_stable is False
    assert ver.major == 0
    assert ver.minor == 1
    assert ver.patch == 2
    assert ver.prerelease == (
        _Numeric('0'),
        _Alpha('a'),
        _Alpha('0'),
        _Alpha('dev'),
        _Numeric('456')
    )
    assert ver.buildmetadata == (
        _Alpha('3d13c23e')
    )

    ver = SemanticVersion.from_loose_version(
        LooseVersion(
            '1.2.3'
        )
    )
    assert ver.is_stable

# Generated at 2022-06-21 09:21:47.906540
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    s = SemanticVersion('1.0.0')
    assert s <= '1.0.0'
    assert not s <= '1.0.0-alpha'
    assert s <= '1.0.0-alpha.0'
    assert not s <= '1.0.0-alpha.0.nope'
    assert s <= '1.0.0-0.3.7'
    assert not s <= '1.0.0-0.3.7-beta'
    assert s <= '1.0.0-0.3.7-beta.1'
    assert not s <= '1.0.0-0.3.7-beta.1.nope'
    assert s <= '1.0.0-rc.1+build.1'

# Generated at 2022-06-21 09:21:53.918556
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('abc').__lt__(_Alpha('bcd'))
    assert _Alpha('abc').__lt__('bcd')
    assert not _Alpha('bcd').__lt__('abc')
    assert not _Alpha('bcd').__lt__(_Alpha('abc'))
    assert not _Alpha(123).__lt__(_Numeric(456))
    try:
        _Alpha(123).__lt__(123)
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 09:22:00.408007
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Call parse without argument
    sv = SemanticVersion('1.2.3')
    assert sv.parse('1.2.3') == SemanticVersion('1.2.3')

    # Call parse with invalid argument
    sv = SemanticVersion('1.2.3')

# Generated at 2022-06-21 09:22:11.631151
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import b
    from ansible.module_utils.six.moves import cStringIO
    from ansible.module_utils.common._semantic_version import SemanticVersion
    from ansible.module_utils.common._semantic_version import LooseVersion

    import sys
    sys_stdout_old = sys.stdout

# Generated at 2022-06-21 09:22:14.367808
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha('1.0.0-alpha.1').__repr__() == "'1.0.0-alpha.1'"



# Generated at 2022-06-21 09:22:39.904537
# Unit test for constructor of class _Alpha
def test__Alpha():
    # Instantiation of _Alpha class
    obj_str = _Alpha("str")
    assert obj_str.specifier == "str"

    # obj_str.specifier should not be equal to "string"
    assert obj_str.specifier != "string"

    obj_str_2 = _Alpha("str")
    # obj_str should be equal to obj_str_2
    assert obj_str == obj_str_2

    # obj_str should not be equal to "str"
    assert obj_str != "str"

    # obj_str should be of type str
    assert type(obj_str.specifier) == str


# Generated at 2022-06-21 09:22:48.978371
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(3) >= 3
    assert _Numeric(3) >= _Numeric(3)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric('2')
    assert _Numeric(1) <= '2'
    assert not _Numeric(3) >= '3'
    assert (1 <= _Numeric(2))
    assert ('1' <= _Numeric(2))
    assert not (_Numeric(3) >= '3')
    assert not (3 <= _Numeric(2))
    assert not (3 >= _Numeric(2))
    assert not ('3' <= _Numeric(2))
    assert not ('3' >= _Numeric(2))


# Generated at 2022-06-21 09:22:51.521509
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha("alpha") == "alpha"
    assert _Alpha("beta") >= "alpha"
    assert not _Alpha("alpha") > "alpha"
    assert _Alpha("rc") < "release"


# Generated at 2022-06-21 09:22:55.651479
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    n3 = _Numeric(3)
    assert n1 != n2
    assert n1 != n3
    assert n3 != n2


# Generated at 2022-06-21 09:23:05.064258
# Unit test for constructor of class _Numeric
def test__Numeric():

    assert _Numeric("7") == _Numeric("7")
    assert _Numeric("7") == 7
    assert _Numeric("7") != "7"

    assert _Numeric("7") < "8"
    assert _Numeric("7") < _Numeric("8")
    assert _Numeric("7") <= _Numeric("8")
    assert _Numeric("7") <= _Numeric("8")
    assert _Numeric("7") <= _Numeric("8")
    assert _Numeric("7") <= _Numeric("8")
    assert _Numeric("7") < _Numeric("8")
    assert _Numeric("7") < _Numeric("8")
    assert _Numeric("7") < _Numeric("8")
    assert _Numeric("7") < _Numeric("8")


# Generated at 2022-06-21 09:23:06.934015
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('10.0.0')) == "SemanticVersion('10.0.0')"

# Generated at 2022-06-21 09:23:09.646494
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(2) == False
    assert _Numeric(1) >= 1 == True
    assert _Numeric(1) >= _Alpha('1') == True


# Generated at 2022-06-21 09:23:17.524782
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():

    assert SemanticVersion("1.2.3").__repr__() == "'1.2.3'"
    assert SemanticVersion("1.2.3-4").__repr__() == "'1.2.3-4'"
    assert SemanticVersion("1.2.3+4").__repr__() == "'1.2.3+4'"

    assert (
        SemanticVersion("1.2.3-alpha.10.beta.0-x.7+build.2").__repr__()
        == "'1.2.3-alpha.10.beta.0-x.7+build.2'"
    )



# Generated at 2022-06-21 09:23:22.055937
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    version1 = SemanticVersion('1.0.0')
    version2 = SemanticVersion('2.0.0')
    version3 = SemanticVersion('2.0.0')
    assert version1 != version2
    assert version2 != version1
    assert not version3 != version3


# Generated at 2022-06-21 09:23:26.789521
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    test_cases = (
        (True, u'a', u'a'),
        (False, u'a', u'b'),
        (True, u'b', u'a'),
    )
    for (expected, a, b) in test_cases:
        assert expected == (_Alpha(a) >= _Alpha(b)), (a, b)


# Generated at 2022-06-21 09:23:35.439210
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert str(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"



# Generated at 2022-06-21 09:23:40.786201
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    v1 = SemanticVersion('1.1.1')
    assert(v1 < SemanticVersion('2.0.0'))
    assert(v1 < SemanticVersion('1.2.0'))
    assert(v1 < SemanticVersion('1.1.2'))
    assert(not v1 < SemanticVersion('1.1.1'))
    assert(not v1 < SemanticVersion('0.0.0'))
    assert(not v1 < SemanticVersion('1.1.1-rc.1'))
    assert(v1 < SemanticVersion('1.1.1-rc.2'))
    v2 = SemanticVersion('1.1.1-rc.5.5')
    assert(v1 < SemanticVersion('1.1.1-rc.5.6'))

# Generated at 2022-06-21 09:23:51.436493
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test for valid semver
    assert SemanticVersion('10.4.5').major == 10
    assert SemanticVersion('10.4.5').minor == 4
    assert SemanticVersion('10.4.5').patch == 5
    assert SemanticVersion('10.4.5').prerelease == ()
    assert SemanticVersion('10.4.5').buildmetadata == ()

    # Test for invalid semver
    try:
        SemanticVersion('10.4')
    except ValueError:
        pass
    except Exception as e:
        raise AssertionError("Raised wrong exception '%s' while handling invalid semver" % e)
    else:
        raise AssertionError("Failed to raise ValueError while handling invalid semver")

    # Test for valid semver with prerelease

# Generated at 2022-06-21 09:23:54.372194
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert _Numeric(1).__repr__() == '1'
    assert _Numeric('1').__repr__() == '1'


# Generated at 2022-06-21 09:23:56.289254
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == repr(1)
    assert repr(_Numeric('1')) == repr(1)


# Generated at 2022-06-21 09:24:03.177684
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    import random
    import string
    random.seed(1)
    a = SemanticVersion(vstring=''.join(random.choices(string.ascii_letters, k=random.randint(1, 10))))
    b = SemanticVersion(vstring=''.join(random.choices(string.ascii_letters, k=random.randint(1, 10))))
    c = a if random.random() > .5 else b
    return a != c or b != c or c != a or c != b



# Generated at 2022-06-21 09:24:11.500714
# Unit test for method __gt__ of class _Alpha

# Generated at 2022-06-21 09:24:19.108214
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    a = SemanticVersion('1.2.2-alpha1-beta1')
    b = SemanticVersion('1.2.2-alpha1')
    c = SemanticVersion('1.2.2-alpha2')
    d = SemanticVersion('1.2.2')
    e = SemanticVersion('1.2.3-alpha2')
    f = SemanticVersion('1.3.2-alpha2')
    g = SemanticVersion('2.2.2-alpha2')

    assert(a < b)
    assert(b == c)
    assert(c < d)
    assert(e > d)
    assert(f > d)
    assert(g > d)



# Generated at 2022-06-21 09:24:25.153523
# Unit test for method __le__ of class _Numeric

# Generated at 2022-06-21 09:24:31.148854
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    SemanticVersion("1.0.0")
    SemanticVersion("1.0.0-alpha.1")
    SemanticVersion("1.0.0+20130313144700")
    SemanticVersion("1.0.0-beta.11+exp.sha.5114f85")
    SemanticVersion("1.0.0-0.3.7")
    SemanticVersion("1.0.0-x.7.z.92")
    SemanticVersion("1.0.0-alpha")
    SemanticVersion("1.0.0-alpha.1")
    SemanticVersion("1.0.0-0.3.7")
    SemanticVersion("1.0.0-x.7.z.92")
    SemanticVersion("1.0.0-alpha+001")

# Generated at 2022-06-21 09:24:44.946694
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == 1


# Generated at 2022-06-21 09:24:48.293117
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('1') >= _Numeric('1')
    assert _Numeric('2') >= _Numeric('1')
    assert _Numeric('1') >= _Numeric('2')
    assert _Numeric('1') >= 1
    assert _Numeric('1') >= 0
    assert _Numeric('0') >= _Alpha('a')


# Generated at 2022-06-21 09:24:50.842985
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    sv1 = SemanticVersion(vstring='1.2.3')
    sv2 = SemanticVersion(vstring='1.2.3')
    assert sv1.__ne__(sv2) == False, 'sv1 and sv2 must be equals'


# Generated at 2022-06-21 09:24:52.569862
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == '1'


# Generated at 2022-06-21 09:24:58.590614
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    '''
    Unit test for method __lt__ of class SemanticVersion
    '''
    # This test is to check the following constraints of Semantic Versioning 2.0.0
    #
    # 1. A normal version number MUST take the form X.Y.Z where X, Y, and Z are non-negative integers,
    #    and MUST NOT contain leading zeroes. X is the major version, Y is the minor version, and Z
    #    is the patch version. Each element MUST increase numerically. For instance: 1.9.0 -> 1.10.0 -> 1.11.0.
    #
    # 2. A pre-release version MAY be denoted by appending a hyphen and a series of dot separated identifiers
    #    immediately following the patch version. Identifiers MUST comprise only ASCII alphanumerics and hyphen
    #    [0

# Generated at 2022-06-21 09:25:08.117836
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == _Numeric('1') is True
    assert _Numeric('2') == _Numeric('2') is True
    assert _Numeric('1') != _Numeric('1') is False
    assert _Numeric('2') != _Numeric('2') is False
    assert _Numeric('1') == '1' is True
    assert _Numeric('2') == '2' is True
    assert _Numeric('1') != '1' is False
    assert _Numeric('2') != '2' is False
    assert _Numeric('1') != '2' is True
    assert _Numeric('2') != '1' is True
    assert _Numeric('1') == 1 is True
    assert _Numeric('2') == 2 is True

# Generated at 2022-06-21 09:25:10.398495
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(1) >= _Numeric(2)


# Generated at 2022-06-21 09:25:11.923675
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion("1.2.3") >= "1.2.2"


# Generated at 2022-06-21 09:25:20.130820
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    c = _Numeric
    # test 1
    specifier1 = c('0')
    specifier2 = c('0')
    assert (specifier1 <= specifier2)
    # test 2
    specifier1 = c('0')
    specifier2 = c('1')
    assert (specifier1 <= specifier2)
    # test 3
    specifier1 = c('1')
    specifier2 = c('0')
    assert not (specifier1 <= specifier2)
    # test 4
    specifier1 = c('0')
    specifier2 = '0'
    assert (specifier1 <= specifier2)



# Generated at 2022-06-21 09:25:24.773755
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    """test__Alpha___ne__(v1: _Alpha, v2: _Alpha) -> bool"""

    # This is needed to make sure that the internal _Alpha instance
    # is constructed first before the string 'alpha'
    v1 = _Alpha('alpha')
    v2 = _Alpha('alpha')
    v3 = _Alpha('1')
    v4 = _Alpha('2')

    assert not v1.__ne__(v2)
    assert v1.__ne__(v3)
    assert v1.__ne__(v4)


# Generated at 2022-06-21 09:25:40.998134
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create an instance of class LooseVersion based on a sample input
    loose_version = LooseVersion('1.2.3.4-5')
    # Create an instance of class SemanticVersion by calling from_loose_version method of class SemanticVersion
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    # Assert that semantic_version is an instance of class SemanticVersion
    assert isinstance(semantic_version, SemanticVersion)
    # Assert that the vstring parameter of the semantic_version object is "1.2.3-4.5"
    assert semantic_version.vstring == "1.2.3-4.5"


# Generated at 2022-06-21 09:25:43.535230
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('1.2.2-beta')
    v2 = SemanticVersion('1.2.2-beta.0')
    assert v1 == v2


# Generated at 2022-06-21 09:25:54.855567
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    """Method __ge__ of class _Alpha, used in SemanticVersion"""
    # Arrange
    alpha1 = _Alpha("1.0.0")

    # Act/Assert
    assert alpha1 <= "1.0.0"
    assert alpha1 >= "1.0.0"
    assert "1.0.0" <= alpha1
    assert "1.0.0" >= alpha1

    assert not alpha1 <= "1.0.1"
    assert alpha1 >= "1.0.1"
    assert not "1.0.1" <= alpha1
    assert "1.0.1" >= alpha1

    assert alpha1 <= "1.0.1-alpha"
    assert not alpha1 >= "1.0.1-alpha"
    assert "1.0.1-alpha" <= alpha1

# Generated at 2022-06-21 09:25:58.406014
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric("1") == _Numeric("1")
    assert _Numeric("1") != _Numeric("42")
    assert _Numeric("1") != "1"
    assert _Numeric("1") != 42


# Generated at 2022-06-21 09:26:02.126251
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    a = _Numeric("1")
    b = _Numeric("2")
    c = _Numeric("2")
    d = _Numeric("3")
    assert a <= b
    assert b >= a
    assert b <= c
    assert b >= c
    assert c <= d
    assert c >= a
    assert d >= b



# Generated at 2022-06-21 09:26:06.989482
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha(1) == 1
    assert _Alpha(1) == _Alpha(1)
    assert _Alpha(1) != 2
    assert _Alpha(1) != _Alpha(2)
    assert _Alpha(1) != '2'
    assert _Alpha(1) != _Alpha('2')



# Generated at 2022-06-21 09:26:08.613423
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1


# Generated at 2022-06-21 09:26:10.871374
# Unit test for constructor of class _Alpha
def test__Alpha():
    specifier = 'test'
    alpha = _Alpha(specifier)
    assert alpha.specifier == specifier


# Generated at 2022-06-21 09:26:12.626547
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    a = _Numeric(1)
    b = _Numeric(2)
    assert a < b


# Generated at 2022-06-21 09:26:13.926839
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    _Numeric(5)
    _Numeric('5')


# Generated at 2022-06-21 09:26:35.102147
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    l = _Alpha('0')
    r = '0'
    assert l.__ge__(r) == True


# Generated at 2022-06-21 09:26:41.219090
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    n1m1 = _Numeric('1')
    n1m2 = _Numeric('2')
    n2m2a = _Numeric('2')
    assert not n1m1 < n1m2
    assert n1m1 < n2m2a
    assert not n1m1 < n1m1
