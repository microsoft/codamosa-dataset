

# Generated at 2022-06-21 09:17:04.469292
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    number = 1
    assert _Numeric(number).__repr__() == "1"


# Generated at 2022-06-21 09:17:11.582871
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('b') == 'b'
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != _Alpha('b')
    assert not _Alpha('a') == 'b'
    assert _Alpha('a') != 'b'
    assert _Alpha('a') < 'b'
    assert _Alpha('a') <= 'b'
    assert not _Alpha('a') > 'b'
    assert not _Alpha('a') >= 'b'
    assert _Alpha('b') > 'a'
    assert _Alpha('b') >= 'a'
    assert not _Alpha('b') < 'a'
    assert not _Alpha('b') <= 'a'
    assert _Alpha('a') < _Alpha('b')

# Generated at 2022-06-21 09:17:18.105381
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    from ansible.module_utils.compat.version import SemanticVersion
    #Test with vstring set to a value
    vstring = '1.0.0'
    sv = SemanticVersion(vstring)
    assert repr(sv) == "SemanticVersion('1.0.0')"
    #Test with vstring set to None
    vstring = None
    sv = SemanticVersion(vstring)
    assert repr(sv) == "SemanticVersion(None)"


# Generated at 2022-06-21 09:17:27.860702
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-21 09:17:34.390226
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('a')

    assert a == c
    assert not a != c

    assert a < b
    assert not a > b

    assert a <= b
    assert not a >= b

    assert b > a
    assert not b < a

    assert b >= a
    assert not b <= a

    assert a <= c
    assert a >= c

    assert not b <= c
    assert not b >= c



# Generated at 2022-06-21 09:17:44.548844
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    # Make sure __eq__ works for _Numeric
    a = _Numeric('1')
    b = _Numeric(1)
    c = _Numeric('2')
    d = _Numeric(2)
    e = '1'
    f = 2
    assert a == b
    assert a != c
    assert a != d
    assert a != e
    assert a != f
    assert b == a
    assert b != c
    assert b != d
    assert b != e
    assert b != f
    assert c != a
    assert c != b
    assert c == d
    assert c != e
    assert c != f
    assert d != a
    assert d != b
    assert d == c
    assert d != e
    assert d != f
    assert a != e
    assert b != e

# Generated at 2022-06-21 09:17:47.626694
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Test if method __gt__ of class SemanticVersion returns a boolean value
    # expected result: boolean
    assert isinstance(SemanticVersion.__gt__, type(SemanticVersion.__gt__))

# Generated at 2022-06-21 09:17:55.393410
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Major version zero (0.y.z) is for initial development. Anything MAY change at any time.
    # The public API SHOULD NOT be considered stable.
    # https://semver.org/#spec-item-4
    c = SemanticVersion('0.1.2')
    assert c.major == 0
    assert c.minor == 1
    assert c.patch == 2
    assert c.prerelease is None
    assert c.buildmetadata is None
    assert not c.is_prerelease
    assert not c.is_stable

    # Version 1.0.0 defines the public API. The way in which the version number is incremented
    # after this release is dependent on this public API and how it changes.
    # https://semver.org/#spec-item-1
    c = SemanticVersion('1.0.0')
   

# Generated at 2022-06-21 09:17:56.938433
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
  assert _Numeric('42') == _Numeric('42')


# Generated at 2022-06-21 09:18:06.903200
# Unit test for constructor of class _Alpha
def test__Alpha():
    x = _Alpha('a')
    assert x.specifier == 'a', 'Failed to create _Alpha: _Alpha.specifier should be a'
    assert x.__repr__() == "'a'", 'Failed to create _Alpha: _Alpha.__repr__() should be "a"'
    # Test __eq__, __ne__
    assert x == 'a', 'Failed to create _Alpha: _Alpha.__eq__() should return True'
    assert not x != 'a', 'Failed to create _Alpha: _Alpha.__ne__() should return False'
    # Test __lt__, __le__, __gt__, __ge__
    assert 'b' > x, 'Failed to create _Alpha: "b" > _Alpha("a") should return True'

# Generated at 2022-06-21 09:18:18.227247
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert str(_Numeric(1)) == str(_Numeric(1.0)) == str(_Numeric('1')) == '1'


# Generated at 2022-06-21 09:18:22.403580
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = '2.1.0'
    v2 = '2.1.0'
    version1 = SemanticVersion(v1)
    version2 = SemanticVersion(v2)
    result = version1.__ge__(version2)
    assert(result == True)


# Generated at 2022-06-21 09:18:24.661134
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha('a') != 'a'
    assert _Alpha('a') != 'b'
    assert not _Alpha('1') == 'a'



# Generated at 2022-06-21 09:18:25.940539
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha("alpha") == "alpha"


# Generated at 2022-06-21 09:18:30.217463
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('foo') <= _Alpha('foo')
    assert _Alpha('foo') <= _Alpha('bar')
    assert not _Alpha('foo') <= _Alpha('a')
    assert not _Alpha('foo') <= 'foo'
    assert not _Alpha('bar') <= _Numeric('0')


# Generated at 2022-06-21 09:18:39.266667
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    s_version_dict = {
        '1.0.0': None,
        '1.1.0': None,
        '2.0.0': None,
        '2.1.0': None,
        '2.1.1': None,
        '2.1.2': None,
        '2.2.0': None,
        '2.2.1': None,
        '2.2.2': None,
        '2.2.3': None,
    }

    #s_version_list = list(s_version_dict.keys())
    s_version_list = [sev_list[0] for sev_list in sorted(list(s_version_dict.items()))]
    print(s_version_list)


# Generated at 2022-06-21 09:18:43.975991
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    input_1 = '1.2.2'
    input_2 = '1.2.1'
    expected_result = True
    actual_result = SemanticVersion(input_1).__ge__(input_2)
    assert actual_result == expected_result


# Generated at 2022-06-21 09:18:54.617334
# Unit test for constructor of class _Numeric
def test__Numeric():
    # Testing object consistency
    n0 = _Numeric(0)
    n1 = _Numeric(1)
    nx = _Numeric(n1)

    assert n0.specifier == 0
    assert isinstance(n0.specifier, int)

    assert n1.specifier == 1
    assert isinstance(n1.specifier, int)

    assert nx.specifier == 1
    assert isinstance(nx.specifier, int)

    assert n0 == 0
    assert isinstance(n0 == 0, bool)

    assert n1 == 1
    assert isinstance(n1 == 1, bool)

    assert nx == 1
    assert isinstance(nx == 1, bool)

    # Testing comparison to str
    s0 = _Numeric('0')

# Generated at 2022-06-21 09:19:01.487480
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    version_1 = SemanticVersion('1.2.3')
    version_2 = SemanticVersion('1.2.3')
    version_3 = SemanticVersion('1.2.4')
    version_4 = SemanticVersion('1.2.3-alpha.1')
    version_5 = SemanticVersion('1.2.3-alpha.1')
    version_6 = SemanticVersion('1.2.3-alpha.2')
    version_7 = SemanticVersion('1.2.3+build.123')
    version_8 = SemanticVersion('1.2.3+build.123')
    version_9 = SemanticVersion('1.2.3+build.456')
    version_10 = SemanticVersion('1.2.3-alpha.1+build.123')
    version_11 = Semantic

# Generated at 2022-06-21 09:19:04.795985
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    class Test(object):
        def __init__(self, x):
            self.x = x
    # Test with an answer
    assert(_Alpha(Test(2)).__repr__() == '2')


# Generated at 2022-06-21 09:19:12.311732
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    """Verify __repr__ of _Numeric works as expected."""
    assert repr(_Numeric('1')) == '1'



# Generated at 2022-06-21 09:19:19.229851
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    d = _Alpha('d')
    e = _Alpha('e')

    assert a < b
    assert b > a
    assert a < e
    assert d > a
    assert d > b
    assert a == a
    assert b == b
    assert d == d
    assert a != b
    assert d != c


# Generated at 2022-06-21 09:19:26.134936
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Simple test to prove that we can compare alpha, numerics, and integers
    # This is required because comparing a string to an int will crash in py3
    text_lower = _Numeric('a')
    text_upper = _Numeric('b')

    int_lower = _Numeric('1')
    int_higher = _Numeric('2')

    assert text_lower < text_upper
    assert int_lower < int_higher
    assert text_lower < int_higher



# Generated at 2022-06-21 09:19:28.495950
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    _n = _Numeric(10)
    assert repr(_n) == '10'


# Generated at 2022-06-21 09:19:36.649089
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    result = _Numeric('101') < '102'
    assert not result
    result = _Numeric('102') < '102'
    assert not result
    result = _Numeric('103') < '102'
    assert not result
    result = _Numeric('102') < '103'
    assert result
    result = _Numeric('102') < _Alpha('103')
    assert result
    result = _Numeric('102') < 'xx'
    assert result
    result = _Numeric('102') < _Alpha('xx')
    assert result
    result = _Numeric('102') < 10
    assert not result


# Generated at 2022-06-21 09:19:41.854775
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # Given a SemanticVersion
    semantic_version = SemanticVersion('1.2.3')

    # When I evaluate it greater than or equal than a string value
    ge = semantic_version >= '1.2.3'

    # Then I expect it to return True
    assert ge is True



# Generated at 2022-06-21 09:19:45.323511
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != 2
    assert _Numeric(1) != '2'


# Generated at 2022-06-21 09:19:48.190440
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    x = _Numeric(5)
    assert x >= _Numeric(5)
    assert x >= 5
    assert not x >= 10

    v = SemanticVersion('3.3.3')
    assert x >= v


# Generated at 2022-06-21 09:19:53.610280
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    v1 = _Alpha('1')
    v2 = _Alpha('2')
    v3 = _Alpha('3')
    v4 = _Alpha('1')
    assert v1 == v1
    assert v1 == '1'
    assert '1' == v1
    assert v1 != v2
    assert v1 != v3
    assert v2 != v3
    assert v1 != v4



# Generated at 2022-06-21 09:19:55.274814
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('alpha')) == repr('alpha')


# Generated at 2022-06-21 09:20:05.648554
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    '''represents the class _Alpha'''
    class_object = _Alpha("alpha")
    assert repr(class_object) == repr("alpha")


# Generated at 2022-06-21 09:20:07.701628
# Unit test for constructor of class _Alpha
def test__Alpha():
    _Alpha('alpha')
    try:
        _Alpha(1)
    except TypeError:
        pass
    else:
        raise Exception('Type error not raised when passing int to _Alpha')



# Generated at 2022-06-21 09:20:13.110453
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a11 = _Alpha(11)
    a21 = _Alpha(21)
    a12 = _Alpha(12)
    a = _Alpha('a')
    a11b = _Alpha('11b')
    aab = _Alpha('aab')

    assert a11 >= a11
    assert a21 >= a11
    assert a11b >= a11
    assert not a11 >= a21
    assert not a11 >= a12
    assert not a11 >= a
    assert not aab >= a11b
    assert a11b >= aab


# Generated at 2022-06-21 09:20:17.094286
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():

    assert _Numeric(2) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert not _Numeric(2) <= _Numeric(1)


# Generated at 2022-06-21 09:20:22.059180
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    from nose.tools import assert_true, assert_false

    a = _Alpha('13')
    b = _Alpha('12')
    assert_true(a.__ge__(b))
    assert_true(a.__ge__('12'))
    assert_false(a.__ge__('14'))



# Generated at 2022-06-21 09:20:26.470535
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    a = SemanticVersion('1.2.3-alpha.1+build-metadata.0')
    b = SemanticVersion('1.2.3-alpha.1+build-metadata.0')
    assert a <= b

    a = SemanticVersion('1.2.3-alpha.1+build-metadata.0')
    b = SemanticVersion('1.2.3-alpha.1+build-metadata.0+extra.metadata')
    assert a <= b

    a = SemanticVersion('1.2.3-alpha.1+build-metadata.0')
    b = SemanticVersion('1.2.3-alpha.1+build-metadata.1')
    assert a <= b

    a = SemanticVersion('1.2.3-alpha.1+build-metadata.0')

# Generated at 2022-06-21 09:20:34.483898
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"
    assert repr(SemanticVersion('1.2.3-beta')) == "SemanticVersion('1.2.3-beta')"
    assert repr(SemanticVersion('1.2.3+build')) == "SemanticVersion('1.2.3+build')"
    assert repr(SemanticVersion('1.2.3-beta+build')) == "SemanticVersion('1.2.3-beta+build')"


# Generated at 2022-06-21 09:20:43.259051
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n1 = _Numeric(1)
    n2 = _Numeric(1)
    n3 = _Numeric(2)
    a1 = _Alpha('1')

    assert n1 == n2, '%r and %r should be equal' % (n1, n2)
    assert n1 == 1, '%r should be equal to 1' % n1
    assert 1 == n1, '1 should be equal to %r' % n1
    assert not n1 == n3, '%r and %r should not be equal' % (n1, n3)
    assert not n1 == a1, '%r and %r should not be equal' % (n1, a1)


# Generated at 2022-06-21 09:20:46.880401
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('b') <= _Alpha('b')
    assert not (_Alpha('b') <= _Alpha('a'))


# Generated at 2022-06-21 09:20:52.794232
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Testing for accept
    loose_version_list = [
        '0',
        '1.2.3',
        '1.2.3.4',
        '1.2.3.4.5',
        '1.2.3.4.5.6',
        '1.2.3.4-alpha',
        '1.2.3.4+alpha',
        '1.2.3.4-alpha+beta',
        '1.2.3+alpha',
        '1.2+alpha',
        '1+alpha'
    ]


# Generated at 2022-06-21 09:21:14.821456
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    for a, b in (
        ('1', '2'),
        ('a', 'b'),
        ('a', '1'),
        ('1', 'a'),
    ):
        assert _Alpha(a) < _Alpha(b)
        assert not _Alpha(b) < _Alpha(a)



# Generated at 2022-06-21 09:21:24.094258
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    r = SemanticVersion('2.1.1')
    assert r.major == 2
    assert r.minor == 1
    assert r.patch == 1
    assert r.prerelease == ()
    assert r.buildmetadata == ()

    r = SemanticVersion('2.1.1+build')
    assert r.major == 2
    assert r.minor == 1
    assert r.patch == 1
    assert r.prerelease == ()
    assert r.buildmetadata == ('build',)

    r = SemanticVersion('2.1.1-prerelease+build')
    assert r.major == 2
    assert r.minor == 1
    assert r.patch == 1
    assert r.prerelease == ('prerelease',)
    assert r.buildmetadata == ('build',)


# Generated at 2022-06-21 09:21:25.969318
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    numeric1 = _Numeric("1")
    numeric2 = _Numeric("2")
    assert numeric1 < numeric2


# Generated at 2022-06-21 09:21:35.346143
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    """
    Tests for: _Alpha.__lt__(other)
    """
    import unittest.mock

    # _Alpha.__lt__(other: None)
    # Tests if _Alpha.__lt__ returns a boolean
    with unittest.mock.patch('ansible.module_utils.basic._Alpha.__lt__', return_value=True):
        assert isinstance(_Alpha.__lt__(None, 'other'), bool), '_Alpha.__lt__ should return a boolean'

    # _Alpha.__lt__(other: _Alpha)
    # Tests if _Alpha.__lt__ with argument other=_Alpha returns a boolean

# Generated at 2022-06-21 09:21:38.191171
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    check_version = SemanticVersion(vstring='1.0.0')
    assert check_version == '1.0.0'
    assert not check_version == '2.0.0'
    assert check_version == SemanticVersion(vstring='1.0.0')
    assert not check_version == SemanticVersion(vstring='2.0.0')


# Generated at 2022-06-21 09:21:42.860356
# Unit test for constructor of class _Numeric
def test__Numeric():
    # Test construction from a valid int
    expected = _Numeric(123)
    actual = _Numeric(123)
    assert expected == actual

    # Test construction from a valid int-like string
    expected = _Numeric(123)
    actual = _Numeric('123')
    assert expected == actual


# Generated at 2022-06-21 09:21:44.453687
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert not _Numeric(1) == 2
    assert _Numeric(1) == 1


# Generated at 2022-06-21 09:21:54.221950
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    if False:
        print(text_type(SemanticVersion('1.2.3-alpha.0.x') < SemanticVersion('1.2.3-alpha.0.y')))
        print(text_type(SemanticVersion('1.2.3-alpha.1.x') < SemanticVersion('1.2.3-alpha.2')))
        print(text_type(SemanticVersion('1.2.3-alpha') < SemanticVersion('1.2.3-beta')))
        print(text_type(SemanticVersion('1.2.3-beta') < SemanticVersion('1.2.3-beta.0.x')))
        print(text_type(SemanticVersion('1.2.3-beta.1.x') < SemanticVersion('1.2.3-beta.2')))


# Generated at 2022-06-21 09:21:55.919114
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    e1 = _Alpha('a')
    e2 = _Alpha('b')
    assert e1 < e2


# Generated at 2022-06-21 09:21:59.479499
# Unit test for constructor of class _Alpha
def test__Alpha():
    alpha = _Alpha(1)
    assert alpha == 1
    assert alpha != 'a'
    assert alpha < 'a'
    assert alpha <= 'a'
    assert alpha <= 1
    assert alpha <= 2
    assert alpha > 'a' is False
    assert alpha > 1 is False
    assert alpha > '0'
    assert alpha >= 'a' is False
    assert alpha >= 1
    assert alpha >= '0'


# Generated at 2022-06-21 09:22:23.203776
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= 'a'
    assert not _Alpha('a') <= _Alpha('b')
    assert not _Alpha('a') <= 'b'
    assert _Alpha('b') <= _Alpha('b')
    assert _Alpha('b') <= 'b'
    assert _Alpha('b') <= _Alpha('a')
    assert _Alpha('b') <= 'a'
    assert _Alpha('b') <= _Numeric(1)


# Generated at 2022-06-21 09:22:25.301732
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('1')
    b = _Alpha('2')
    assert a.__ge__(b) == False


# Generated at 2022-06-21 09:22:28.635475
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    x = SemanticVersion('1.2.3-1')
    y = SemanticVersion('1.2.3-alpha')
    z = SemanticVersion('1.2.3')
    assert x == x
    assert x == y
    assert x != z


# Generated at 2022-06-21 09:22:40.005018
# Unit test for method __eq__ of class _Alpha

# Generated at 2022-06-21 09:22:48.270293
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a_test = _Alpha('a')
    b_test = _Alpha('b')
    c_test = _Alpha('c')
    if not (b_test >= a_test):
        raise AssertionError()
    if not (c_test >= a_test):
        raise AssertionError()
    if not (c_test >= b_test):
        raise AssertionError()
    if not (b_test >= b_test):
        raise AssertionError()
    if c_test >= 'c':
        raise AssertionError()
    if not (c_test >= 'a'):
        raise AssertionError()



# Generated at 2022-06-21 09:22:50.010313
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('1') < _Alpha('2')
    assert not _Alpha('2') < _Alpha('1')


# Generated at 2022-06-21 09:22:51.224498
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != _Alpha('b')


# Generated at 2022-06-21 09:23:02.108859
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion("1.0.0")
    assert v1.__gt__("0.0.0") == True
    assert v1.__gt__("2.0.0") == False
    assert v1.__gt__("1.0.0") == False
    assert v1.__gt__("1.0.0-pre.1") == True
    assert v1.__gt__("1.0.0-pre.1.1") == True
    assert v1.__gt__("1.0.0-pre.1.1.1.1.1") == True
    assert v1.__gt__("1.0.0-pre.1+x") == True
    assert v1.__gt__("1.0.0+x") == False


# Generated at 2022-06-21 09:23:10.379153
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    versions = (
        '1.2.3-pre-alpha',
        '1.2.3-alpha',
        '1.2.3-beta',
        '1.2.3-rc',
        '1.2.3-pre-release',
        '1.2.3-release',
        '1.2.3-post-release',
        '1.2.3-pre-1',
        '1.2.3-pre-2',
        '1.2.3-1',
        '1.2.3-2',
        '1.2.3+build-1',
        '1.2.3+build-2',
    )

    for version_a, version_b in zip(versions, versions[1:]):
        assert SemanticVersion(version_a) < SemanticVersion

# Generated at 2022-06-21 09:23:17.643506
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha(1) == 1

    assert _Alpha('a') != 'b'
    assert _Alpha(1) != 2

    assert _Alpha('a') < 'b'
    assert _Alpha(3) < 4

    assert _Alpha('a') <= 'a'
    assert _Alpha(3) <= 3

    assert _Alpha('b') > 'a'
    assert _Alpha(4) > 3

    assert _Alpha('a') >= 'a'
    assert _Alpha(3) >= 3


# Generated at 2022-06-21 09:23:39.471038
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    from ansible.module_utils._text import to_text

    version = SemanticVersion('2.0.0')
    assert version < '2.0.1'
    assert version < '2.0.0-alpha'
    assert version < '2.0.0+build.1'
    assert version < '2.0.0-alpha+build.1'
    assert version < '2.0.0-alpha.1+build.1'

    version = SemanticVersion('2.0.0-alpha')
    assert version < '2.0.0-alpha.1'
    assert version < '2.0.0-beta'
    assert version < '2.0.0-rc.1'
    assert version < '2.0.0-rc.1.2'

# Generated at 2022-06-21 09:23:49.359727
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    def x_should_be_greater_than_y(x, y):
        assert x > y
        assert x >= y
        assert not x < y
        assert not x <= y
        assert x_should_not_be_greater_than_y(x, y)

    def x_should_not_be_greater_than_y(x, y):
        assert not x > y
        assert not x >= y
        assert x < y
        assert x <= y
        assert not x_should_be_greater_than_y(x, y)

    x_should_be_greater_than_y(_Numeric('1'), _Numeric('0'))
    x_should_be_greater_than_y(_Numeric('0'), _Alpha('0'))
    x_should_be_greater

# Generated at 2022-06-21 09:23:58.169949
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('1') <= _Alpha('2')
    assert not (_Alpha('1') > _Alpha('2'))
    assert not (_Alpha('1') >= _Alpha('2'))
    assert not (_Alpha('2') < _Alpha('1'))
    assert not (_Alpha('2') <= _Alpha('1'))
    assert _Alpha('2') > _Alpha('1')
    assert _Alpha('2') >= _Alpha('1')
    assert _Alpha('1') < _Alpha('1.1')
    assert _Alpha('1') <= _Alpha('1.1')
    assert not (_Alpha('1') > _Alpha('1.1'))
    assert not (_Alpha('1') >= _Alpha('1.1'))

# Generated at 2022-06-21 09:24:03.627547
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert not _Numeric('1').__eq__(_Numeric('2'))
    assert _Numeric('1').__eq__(_Numeric('1'))
    assert not _Numeric('1').__eq__(_Numeric('a'))
    assert not _Numeric('1').__eq__('a')
    assert _Numeric('1').__eq__('1')


# Generated at 2022-06-21 09:24:06.138202
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert eval(repr(SemanticVersion('9.0.0'))) == SemanticVersion('9.0.0')


# Generated at 2022-06-21 09:24:12.467574
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(2) >= _Numeric(1)
    assert not _Numeric(1) >= _Numeric(2)
    assert _Numeric('1') >= _Numeric('1')
    assert _Numeric('2') >= _Numeric('1')
    assert not _Numeric('1') >= _Numeric('2')
    assert _Numeric(1) >= 1
    assert _Numeric(2) >= 1
    assert not _Numeric(1) >= 2
    assert _Numeric('1') >= 1
    assert _Numeric('2') >= 1
    assert not _Numeric('1') >= 2


# Generated at 2022-06-21 09:24:19.007704
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.2.3') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.3.0')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3+build')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3+build.1')



# Generated at 2022-06-21 09:24:26.158905
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    print('test_SemanticVersion___ge__')

    v1 = SemanticVersion('1.3.4')
    v2 = SemanticVersion('1.3.4')

    assert v1 >= v2
    assert not (v1 < v2)

    v1 = SemanticVersion('2.0.0')
    v2 = SemanticVersion('1.3.4')

    assert v1 >= v2
    assert not (v1 < v2)
    assert v2 < v1
    assert not (v2 >= v1)

    v1 = SemanticVersion('1.3.4')
    v2 = SemanticVersion('1.4.4')

    assert v1 < v2
    assert not (v1 >= v2)

    v1 = SemanticVersion('1.3.4')
    v2 = Sem

# Generated at 2022-06-21 09:24:30.401245
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    """
    Test Method __repr__
    of Class SemanticVersion
    """
    assert repr(SemanticVersion(vstring='0.1.2')) == "SemanticVersion('0.1.2')"


# Generated at 2022-06-21 09:24:40.204708
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    svt = SemanticVersion("1.2.3")
    other_svt = SemanticVersion("1.2.3")
    print("Test '__ge__': ", svt >= other_svt)
    print("Test '__ge__': ", SemanticVersion("1.2.3") >= SemanticVersion("1.2.3"))
    print("Test '__ge__': ", SemanticVersion("1.2.3") >= "1.2.3")
    print("Test '__ge__': ", SemanticVersion("1.2.3") >= "2.2.3")
    print("Test '__ge__': ", SemanticVersion("1.2.3") >= "0.2.3")
    print("Test '__ge__': ", SemanticVersion("1.2.3") >= "1.2.2")


# Generated at 2022-06-21 09:25:18.283554
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    # Positive tests
    assert repr(_Numeric('42')) == repr(42)
    assert repr(_Numeric(42)) == repr(42)
    assert repr(_Numeric(42.0)) == repr(42)

    # Negative tests
    try:
        _Numeric('42ab')
    except ValueError:
        pass
    else:
        assert False

    try:
        _Numeric('42.0')
    except ValueError:
        pass
    else:
        assert False

    # __repr__ is the same for _Alpha
    assert repr(_Alpha('42')) == repr(42)


# Generated at 2022-06-21 09:25:21.401753
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert not _Alpha('a') >= 'b'
    assert _Alpha('a') >= _Alpha('a')
    assert not _Alpha('a') >= _Alpha('b')


# Generated at 2022-06-21 09:25:22.781266
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    numeric = _Numeric(1)
    assert numeric.__repr__() == repr(1)


# Generated at 2022-06-21 09:25:32.137505
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.0.0') != SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0-1') != SemanticVersion('1.0.1-1')

# Generated at 2022-06-21 09:25:34.140745
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    pass



# Generated at 2022-06-21 09:25:36.804717
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= _Numeric(0)


# Generated at 2022-06-21 09:25:38.520793
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('1')) == repr('1')


# Generated at 2022-06-21 09:25:46.153702
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.0.0-alpha+001') == SemanticVersion('1.0.0-alpha+001')
    assert SemanticVersion('1.0.0-alpha+001.1') == SemanticVersion('1.0.0-alpha+001.1')
    assert SemanticVersion('1.0.0-alpha+001') != SemanticVersion('1.0.0-alpha+002')
    assert SemanticVersion('1.0.0-alpha+001.1') != SemanticVersion('1.0.0-beta+001')
    assert SemanticVersion('1.0.0-beta+001') == SemanticVersion('1.0.0-beta+001')

# Generated at 2022-06-21 09:25:49.687222
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion('1.2.3')
    assert repr(version) == 'SemanticVersion(\'1.2.3\')'


# Generated at 2022-06-21 09:25:57.327299
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= 2
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(2) >= 1
    assert not _Numeric(2) >= _Numeric(3)
    assert not _Numeric(2) >= 3
    assert _Numeric(3) >= _Numeric(2)
    assert _Numeric(3) >= 2


# Generated at 2022-06-21 09:26:35.314967
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    a = SemanticVersion('1.0.0-beta')
    assert a.__eq__('1.0.0-beta') == True
    assert a.__eq__('1.0.0-alpha') == False
    assert a.__eq__('1.0.0') == False
    assert a.__eq__(SemanticVersion('1.0.0-beta')) == True
    assert a.__eq__(SemanticVersion('1.0.0-alpha')) == False
    assert a.__eq__(SemanticVersion('1.0.0')) == False




# Generated at 2022-06-21 09:26:42.400728
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    """Unit test for __gt__ method of class SemanticVersion"""
    assert (SemanticVersion("0.1.2") > SemanticVersion("0.1.1")) is True
    assert (SemanticVersion("0.1.1") > SemanticVersion("0.1.1")) is False
    assert (SemanticVersion("0.1.1") > SemanticVersion("0.1.2")) is False