

# Generated at 2022-06-21 09:17:06.814830
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('b')
    b = _Alpha('a')
    c = _Alpha('b')

    assert a.__ge__(a) == True
    assert a.__ge__(b) == True
    assert a.__ge__(c) == True
    assert a.__ge__('a') == True
    assert a.__ge__('b') == True
    assert a.__ge__('c') == True

    assert b.__ge__(a) == False
    assert b.__ge__(b) == True
    assert b.__ge__(c) == False
    assert b.__ge__('a') == False
    assert b.__ge__('b') == True
    assert b.__ge__('c') == False

    assert c.__ge__(a) == True
    assert c

# Generated at 2022-06-21 09:17:14.386332
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('1.2.3') == '1.2.3'
    assert _Alpha('1.2.3') != 1
    assert _Alpha('1.2.3') != _Numeric('1.2.3')
    assert _Alpha('1.3.2') < '1.4.2'
    assert _Alpha('1.2.3') <= '1.2.3'
    assert _Alpha('1.3.2') > '1.3'
    assert _Alpha('1.3.2') >= '1.3.2'



# Generated at 2022-06-21 09:17:18.330363
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    from ansible_collections.netbox.netbox.plugins.module_utils import netbox_module_utils as nmu
    assert nmu.SemanticVersion('1.0.0') < nmu.SemanticVersion('2.0.0')


# Generated at 2022-06-21 09:17:27.534376
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    object1 = _Alpha("alpha")
    object2 = _Alpha("alpha")
    object3 = _Alpha("beta")
    object4 = _Alpha("charlie")
    object5 = "alpha"
    object6 = "beta"
    object7 = "charlie"
    object8 = _Numeric(0)
    # Test __ge__ for equal objects
    assert object1 >= object2
    # Test __ge__ for unequal objects
    assert object2 >= object3
    assert object2 >= object4
    assert object2 >= object5
    assert object2 >= object6
    assert object2 >= object7
    assert object2 >= object8
    # Test __ge__ for object1 and object3
    assert object3 >= object4


# Generated at 2022-06-21 09:17:37.445271
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('2.0.0')
    v3 = SemanticVersion('2.0.0')
    v4 = SemanticVersion('3.0.0')
    v5 = SemanticVersion('2.0.0-alpha.1')
    v6 = SemanticVersion('2.0.0-alpha.1')
    v8 = SemanticVersion('2.0.0-alpha.02')
    v9 = SemanticVersion('2.0.0-alpha.2')
    v10 = SemanticVersion('2.0.0-alpha.3')
    v11 = SemanticVersion('2.0.0-beta.1')
    v12 = SemanticVersion('2.0.0-beta.2')
    v13 = Semantic

# Generated at 2022-06-21 09:17:42.723458
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    """
    Test the _Version class method __ge__
    """

    assert not _Numeric(1) >= '1'
    assert not _Numeric(1) >= '2'
    assert _Numeric(1) >= _Numeric(1)
    assert not _Numeric(1) >= _Numeric(2)
    assert _Numeric(2) >= _Numeric(1)



# Generated at 2022-06-21 09:17:45.526668
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("2.0.0")
    assert v2__gt__v1()

# Generated at 2022-06-21 09:17:53.689093
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    def _assert(a, b, expected):
        if expected is True:
            assert a < b
        else:
            assert a >= b

    a = _Alpha('1')
    b = _Alpha('2')
    _assert(a, b, True)
    _assert(b, a, False)
    c = _Alpha('10')
    _assert(a, c, True)
    _assert(c, a, False)

    a = _Alpha('a')
    b = _Alpha('b')
    _assert(a, b, True)
    _assert(b, a, False)
    c = _Alpha('aa')
    _assert(a, c, True)
    _assert(c, a, False)

    a = _Alpha('a')
    b = _Alpha('b')

# Generated at 2022-06-21 09:18:03.171840
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    sv = SemanticVersion("0.0.1-rc.1")
    assert sv.vstring == "0.0.1-rc.1"
    assert sv.major == 0
    assert sv.minor == 0
    assert sv.patch == 1
    assert sv.core == (0, 0, 1)
    assert sv.prerelease == (_Numeric("rc"), _Numeric("1"))
    assert sv.buildmetadata == ()
    assert sv.is_prerelease
    assert not sv.is_stable
    
    sv = SemanticVersion("1.2.3")
    assert sv.vstring == "1.2.3"
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.core == (1, 2, 3)
    assert sv.prerelease

# Generated at 2022-06-21 09:18:09.087775
# Unit test for constructor of class _Alpha
def test__Alpha():
    from distutils.version import StrictVersion, LooseVersion

    assert repr(_Alpha('test')) == repr('test')
    assert repr(_Alpha('2')) == repr('2')
    assert repr(_Alpha(2)) == repr('2')
    assert repr(_Alpha(StrictVersion('2'))) == repr('2')
    assert repr(_Alpha(LooseVersion('2'))) == repr('2')


# Generated at 2022-06-21 09:18:23.623846
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    a = SemanticVersion('1.2.3')
    b = SemanticVersion('1.2.3')
    assert not (a > b)
    assert not (a > '1.2.3')
    assert not (a > '1.2.2')
    assert a > '1.2.1'
    assert a > '0.2.3'


# Generated at 2022-06-21 09:18:33.879290
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Test for case where a.specifier < b.specifier
    a = _Numeric(1)
    b = _Numeric(2)
    assert a < b
    assert not (a >= b)
    # Test for case where a.specifier == b.specifier
    a = _Numeric(1)
    b = _Numeric(1)
    assert a <= b
    assert a >= b
    # Test for case where a.specifier > b.specifier
    a = _Numeric(2)
    b = _Numeric(1)
    assert a > b
    assert not (a <= b)

    # Test for case where a.specifier < b
    a = _Numeric(1)
    b = 2
    assert a < b
    assert not (a >= b)
    # Test for case where

# Generated at 2022-06-21 09:18:36.697550
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha("dev")
    assert a != "dev"
    assert not a != "dev"
    assert a != _Alpha("dev")
    assert not a != _Alpha("dev")


# Generated at 2022-06-21 09:18:48.356141
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    class __Alpha_test1():
        def __init__(self):
            self.specifier = "test1"
    class __Alpha_test2:
        def __init__(self):
            self.specifier = "test2"
    test1 = __Alpha_test1()
    test2 = __Alpha_test2()
    test3 = "test3"
    test4 = None

    str_alpha = _Alpha("test")

    # Testing when both are _Alpha
    assert str_alpha.__eq__(str_alpha) == True
    assert str_alpha.__eq__(test1) == True
    assert str_alpha.__eq__(test2) == False
    # Testing when one is a string
    assert str_alpha.__eq__(test3) == True
    # Testing when one is None

# Generated at 2022-06-21 09:18:55.320771
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('1.2.3')
    b = _Alpha('1.2')
    assert a > b
    assert not b > a

    a = _Alpha('1.2.3')
    b = _Alpha('1.3')
    assert a < b
    assert not b < a

    a = _Alpha('1.2.3')
    b = _Alpha('1.2.3')
    assert a == b
    assert not b < a
    assert not a < b


# Generated at 2022-06-21 09:19:01.750815
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(2) >= _Numeric(1)
    assert not _Numeric(1) > _Numeric(2)
    assert not _Numeric(2) < _Numeric(1)

    assert _Numeric(1) <= 2
    assert _Numeric(2) >= 1
    assert not _Numeric(1) > 2
    assert not _Numeric(2) < 1

    assert 1 <= _Numeric(1)
    assert 2 >= _Numeric(2)
    assert not 1 > _Numeric(2)
    assert not 2 < _Numeric(1)

    assert _Numeric(2) <= _Alpha(2)
    assert _Numeric(1) <= _Alpha(2)
    assert not _Numeric(2) < _

# Generated at 2022-06-21 09:19:10.458926
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('4') > '3'
    assert SemanticVersion('4') > SemanticVersion('3')
    assert SemanticVersion('4.0') > '0'
    assert not SemanticVersion('4') > '4'
    assert SemanticVersion('4.0.0') > '4'
    assert not SemanticVersion('4.0.0') > '4.0'
    assert SemanticVersion('4.0.1') > '4.0'
    assert not SemanticVersion('4.0.0') > '4.0.0'
    assert not SemanticVersion('4.0.0') > '4.0.0-beta'
    assert SemanticVersion('4.0.0-beta.2') > '4.0.0-beta.1'

# Generated at 2022-06-21 09:19:15.900482
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    for x in ["a", "b", "c", "d", "e"]:
        for y in ["a", "b", "c", "d", "e"]:
            if x < y:
                assert _Alpha(x) <= _Alpha(y)
            else:
                assert not _Alpha(x) <= _Alpha(y)


# Generated at 2022-06-21 09:19:24.980003
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    r = _Alpha('a') > _Alpha('z')
    assert r == False
    r = _Alpha('z') > _Alpha('a')
    assert r == True
    r = _Alpha('a') > 'z'
    assert r == False
    r = _Alpha('z') > 'a'
    assert r == True
    try:
        r = _Alpha('a') > 1
    except ValueError as e:
        raise AssertionError from e
    try:
        r = _Alpha('a') > _Numeric('1')
    except ValueError as e:
        raise AssertionError from e


# Generated at 2022-06-21 09:19:27.042221
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)



# Generated at 2022-06-21 09:19:39.733490
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # testing invalid semantic version
    invalid_input = '2.0.0-beta'
    result = SemanticVersion(invalid_input)
    assert result.vstring == invalid_input
    try:
        result.parse(invalid_input)
        assert False
    except ValueError:
        assert True

    # testing valid semantic version
    valid_input = '2.0.0-beta.1+build.1'
    result = SemanticVersion(valid_input)
    assert result.vstring == valid_input
    assert result.major == 2
    assert result.minor == 0
    assert result.patch == 0
    assert result.prerelease == (_Numeric('beta'), _Numeric('1'))
    assert result.buildmetadata == (_Alpha('build'), _Numeric('1'))

    # testing valid semantic version


# Generated at 2022-06-21 09:19:42.440138
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(2)) == '2'
    assert repr(_Numeric('2')) == '2'


# Generated at 2022-06-21 09:19:50.237946
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    a = _Numeric(1)
    b = _Numeric(0)
    c = _Numeric(0)
    d = _Numeric(2)
    e = _Alpha('1')
    f = _Alpha('0')
    g = _Alpha('0')
    h = _Alpha('2')

    assert(a >= b)
    assert(not (b >= a))
    assert(a >= c)
    assert(not (a >= d))
    assert(a >= e)
    assert(not (a >= f))
    assert(a >= g)
    assert(not (a >= h))

# Generated at 2022-06-21 09:19:55.872998
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(0) != _Numeric(1)
    assert 0 != _Numeric(1)
    assert _Numeric(0) != 0
    assert _Numeric(0) != _Numeric(0)
    assert 0 != _Numeric(0)
    assert _Numeric(0) != 0
    assert _Numeric(0) != _Alpha("1")


# Generated at 2022-06-21 09:19:58.623639
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    """Test for case when _Numeric is greater than another _Numeric"""
    a = _Numeric(1)
    b = _Numeric(2)
    c = a > b
    assert c == False


# Generated at 2022-06-21 09:20:02.286815
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == 1
    assert not _Numeric(1) == _Numeric(2)
    assert not _Numeric(1) == 2
    assert not _Numeric(1) == _Alpha(1)
    assert not _Numeric(1) == '1'


# Generated at 2022-06-21 09:20:08.751041
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():

    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    d = _Alpha('d')
    e = _Alpha('e')
    f = _Alpha('f')
    g = _Alpha('g')
    h = _Alpha('h')
    i = _Alpha('i')
    j = _Alpha('j')
    k = _Alpha('k')
    l = _Alpha('l')
    m = _Alpha('m')
    n = _Alpha('n')
    o = _Alpha('o')
    p = _Alpha('p')
    q = _Alpha('q')
    r = _Alpha('r')
    s = _Alpha('s')
    t = _Alpha('t')
    u = _Alpha('u')
    v = _Alpha('v')
   

# Generated at 2022-06-21 09:20:16.595735
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # verify that version1 > version2
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3+1')

    # verify that version1 > version2
    assert SemanticVersion('1.2.3+1') < SemanticVersion('1.2.3+2')

    # verify that version1 > version2
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')

    # verify that version1 > version2
    assert SemanticVersion('1.2.3') < SemanticVersion('1.3.3')

    # verify that version1 > version2
    assert SemanticVersion('1.2.3') < SemanticVersion('2.2.3')


# Generated at 2022-06-21 09:20:23.026791
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('rc') > _Alpha('beta')
    assert _Alpha('rc') > _Alpha('alpha')
    assert _Alpha('rc') > _Alpha('0')
    assert _Alpha('rc') > _Alpha('1')
    assert _Alpha('rc') > 'beta'
    assert _Alpha('rc') > 'alpha'
    assert _Alpha('rc') > '0'
    assert _Alpha('rc') > '1'


# Generated at 2022-06-21 09:20:27.270082
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.20.4') == SemanticVersion('1.20.04')

    assert SemanticVersion('1.20.4') == '1.20.4'
    assert SemanticVersion('1.20.4') == '1.20.04'


# Generated at 2022-06-21 09:20:38.919218
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():

    # Unit test for method __le__ of class _Alpha
    # Method is static.
    # Input parameters
    #     a = Argument _Alpha
    #     b = Argument _Alpha
    # Expected return value
    #     boolean

    # Test 1. Normal case
    a = _Alpha("1")
    b = _Alpha("2")
    if (a.__le__(b) != True):
        print("#1 Failed")

    # Test 2. Normal case
    a = _Alpha("1")
    b = _Alpha("1")
    if (a.__le__(b) != True):
        print("#2 Failed")

    # Test 3. Normal case
    a = _Alpha("2")
    b = _Alpha("1")

# Generated at 2022-06-21 09:20:44.503295
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert bool(_Alpha('b') > _Alpha('a'))
    assert bool(_Alpha('a') > _Alpha('b')) is False
    assert bool(_Alpha('a') > 'a')
    assert bool(_Alpha('a') > 'b') is False
    assert bool('a' > _Alpha('b'))
    assert bool('a' > _Alpha('b')) is False


# Generated at 2022-06-21 09:20:51.919375
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    assert SemanticVersion('1.2.3').prerelease == ()
    assert SemanticVersion('1.2.3').buildmetadata == ()

    assert SemanticVersion('1.2.3-alpha').core == (1, 2, 3)
    assert SemanticVersion('1.2.3-alpha').prerelease == (_Alpha('alpha'),)
    assert SemanticVersion('1.2.3-alpha').buildmetadata == ()

    assert SemanticVersion('1.2.3+build').core == (1, 2, 3)
    assert SemanticVersion('1.2.3+build').prerelease == ()
    assert SemanticVersion('1.2.3+build').buildmetadata == (_Alpha('build'),)


# Generated at 2022-06-21 09:20:55.258259
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert not _Numeric(1).__lt__(_Numeric(1))
    assert _Numeric(0).__lt__(_Numeric(1))
    assert not _Numeric(1).__lt__(_Numeric(0))


# Generated at 2022-06-21 09:21:01.678319
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    ver1 = SemanticVersion('2.0.0')
    ver2 = SemanticVersion('2.0.0')
    assert(ver1 >= ver2)
    assert(ver1 == ver2)

    ver1 = SemanticVersion('1.0.0')
    ver2 = SemanticVersion('2.0.0')
    assert(~(ver1 >= ver2))
    assert(ver1 < ver2)


# Generated at 2022-06-21 09:21:03.304574
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    alpha = _Alpha(text_type('alpha'))
    assert repr(alpha) == repr(text_type('alpha'))



# Generated at 2022-06-21 09:21:06.446264
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(15)) == "15"
    assert repr(_Numeric(0)) == "0"
    assert repr(_Numeric(-15)) == "-15"
    assert repr(_Numeric('15')) == "15"
    assert repr(_Numeric('0')) == "0"
    assert repr(_Numeric('-15')) == "-15"


# Generated at 2022-06-21 09:21:09.557611
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    version = SemanticVersion('1.0.0')
    assert version.vstring == '1.0.0'
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0


# Generated at 2022-06-21 09:21:17.867066
# Unit test for constructor of class _Alpha
def test__Alpha():
    a1 = _Alpha('alpha')
    a2 = _Alpha('alpha')
    n1 = _Numeric(1)
    s1 = 'alpha'
    s2 = 'beta'

    assert a1 == a2
    assert a1 == s1
    assert a1 != n1
    assert a1 != s2

    assert a1 < s2
    assert a1 < n1

    assert a1 <= a2
    assert a1 <= s2
    assert a1 <= n1

    assert a1 > s1
    assert a1 > s2

    assert a1 >= a2
    assert a1 >= s1
    assert a1 >= s2



# Generated at 2022-06-21 09:21:28.757967
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3') == '1.2.3'
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3+4.5.6')
    assert SemanticVersion('1.2.3+4.5.6') == '1.2.3+4.5.6'
    assert SemanticVersion('1.2.3+4.5.6') == SemanticVersion('1.2.3+4.5.6')
    assert SemanticVersion('1.2.3-4.5.6') == '1.2.3-4.5.6'
    assert SemanticVersion('1.2.3-4.5.6') == SemanticVersion

# Generated at 2022-06-21 09:21:36.170944
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    vs1 = SemanticVersion('0.0.1')
    vs2 = SemanticVersion('0.0.1')
    assert vs1.__ne__(vs2) == False
    assert vs2.__ne__(vs1) == False


# Generated at 2022-06-21 09:21:39.629795
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    t = _Alpha('a')
    assert t == 'a'
    assert t != 'b'
    assert t != 1


# Generated at 2022-06-21 09:21:47.664164
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Check that comparing two SemanticVersion objects works correctly
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('2.0.0')

    expect = v1 <= v2
    actual = True

    assert expect == actual, "expected " + text_type(expect) + ", got " + text_type(actual)

    # Check that comparing a SemanticVersion with a string works correctly
    v1 = SemanticVersion('1.2.3')
    v2 = '2.0.0'

    expect = v1 <= v2
    actual = True

    assert expect == actual, "expected " + text_type(expect) + ", got " + text_type(actual)

    # Check that comparing a SemanticVersion with a LooseVersion works correctly

# Generated at 2022-06-21 09:21:50.131992
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # Given: a SemanticVersion object
    v = SemanticVersion('1.2.3')
    # When: compared with a string
    assert v >= v


# Generated at 2022-06-21 09:21:55.434007
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert (_Numeric(1) >= _Numeric(1)) is True
    assert (_Numeric(1) >= _Numeric(2)) is False
    assert (_Numeric(2) >= _Numeric(1)) is True
    assert (_Numeric(1) >= 1) is True
    assert (_Numeric(1) >= 2) is False
    assert (_Numeric(2) >= 1) is True


# Generated at 2022-06-21 09:22:00.100770
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    assert n1.__ge__(n1)  == True
    assert n1.__ge__(n2)  == False
    assert n2.__ge__(n1)  == True


# Generated at 2022-06-21 09:22:11.345348
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version1 = SemanticVersion()
    version2 = SemanticVersion()
    version1.__init__(vstring='0.0.1-alpha.1+build.1')
    version2.__init__(vstring='1.1.1')
    assert version1.major == 0
    assert version1.minor == 0
    assert version1.patch == 1
    assert version1.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert version1.buildmetadata == (_Alpha('build'), _Numeric('1'))
    assert version2.major == 1
    assert version2.minor == 1
    assert version2.patch == 1
    assert version2.prerelease == ()
    assert version2.buildmetadata == ()

    # Test invalid version numbers
    version1 = SemanticVersion()
    version2

# Generated at 2022-06-21 09:22:18.457641
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Arrange
    a1 = _Alpha("a")
    a2 = _Alpha("b")
    a3 = _Alpha("16")

    # Assert
    assert a1 < a2
    assert a2 > a1
    assert a3 > a2
    assert a3 > a1
    assert not a1 > a2
    assert not a2 < a1
    assert not a3 < a2
    assert not a3 < a1


# Generated at 2022-06-21 09:22:21.492055
# Unit test for constructor of class _Numeric
def test__Numeric():
    int_obj = _Numeric(2)
    zero_obj = _Numeric(0)

    assert int_obj.specifier == 2
    assert zero_obj.specifier == 0



# Generated at 2022-06-21 09:22:29.996894
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')

    assert SemanticVersion('1.0.0-alpha') == '1.0.0-alpha'
    assert SemanticVersion('1.0.0-alpha') == SemanticVersion('1.0.0-alpha')

    assert SemanticVersion('1.0.0-alpha.2') == '1.0.0-alpha.2'
    assert SemanticVersion('1.0.0-alpha.2') == SemanticVersion('1.0.0-alpha.2')

    assert SemanticVersion('1.0.0-alpha.1.b') == '1.0.0-alpha.1.b'

# Generated at 2022-06-21 09:22:48.128307
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    n = _Numeric(1)
    nn = _Numeric(2)
    a = _Alpha('a')
    aa = _Alpha('b')
    b = _Alpha('c')
    assert n <= n
    assert n <= nn
    assert n <= a
    assert n <= aa
    assert n <= b
    assert not n <= b
    assert nn <= nn
    assert nn <= a
    assert nn <= aa
    assert nn <= b
    assert not nn <= b
    assert a <= a
    assert a <= aa
    assert a <= b
    assert not a <= b
    assert aa <= aa
    assert aa <= b
    assert not aa <= b


# Generated at 2022-06-21 09:22:53.607238
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    version = _Numeric(2)
    assert version >= 1, "version >= 1 is False"
    assert version >= 2, "version >= 2 is False"
    assert version >= '1', "version >= '1' is False"
    assert version >= '2', "version >= '2' is False"
    assert version >= _Numeric(1), "version >= _Numeric(1) is False"
    assert version >= _Numeric(2), "version >= _Numeric(2) is False"


# Generated at 2022-06-21 09:22:57.081312
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('0.0.1-alpha')
    assert repr(v) == 'SemanticVersion(\'0.0.1-alpha\')'
