

# Generated at 2022-06-21 09:16:56.140186
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(0)
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= 1
    assert _Numeric(0) >= _Numeric(0)
    assert _Numeric(0) >= _Numeric(1)
    assert _Numeric(0) >= 0
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= 2
    assert not _Numeric(0) >= _Numeric(2)
    assert not _Numeric(0) >= 2


# Generated at 2022-06-21 09:17:04.070739
# Unit test for constructor of class _Alpha
def test__Alpha():
    """This unit test tests the constructor of class _Alpha.
    """
    assert _Alpha("1") == "1"
    assert _Alpha("1") != "2"
    assert _Alpha("1") < "2"
    assert _Alpha("1") <= "2"
    assert _Alpha("1") <= "1"
    assert _Alpha("1") > "0"
    assert _Alpha("1") >= "0"
    assert _Alpha("1") >= "1"
    try: assert _Alpha("1") >= 1
    except ValueError: pass
    else: assert False



# Generated at 2022-06-21 09:17:07.685120
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= _Numeric(1)
    assert not _Numeric(1) >= _Numeric(0)
    assert not _Numeric(1) >= _Alpha('1')


# Generated at 2022-06-21 09:17:08.922599
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    s = SemanticVersion()
    assert s.vstring is None


# Generated at 2022-06-21 09:17:11.254373
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    a1 = _Alpha('2')
    a2 = _Alpha('4')
    assert a1 < a2


# Generated at 2022-06-21 09:17:22.875352
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    n3 = _Numeric(3)
    n4 = _Numeric(4)
    n1_list = [n3, n4, n2]
    n2_list = [n1, n3, n4]

    assert n1 >= n2

# Generated at 2022-06-21 09:17:25.623988
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < text_type(2)
    assert 1 < _Numeric(2)
    assert 1 < 2


# Generated at 2022-06-21 09:17:28.830552
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('b') > _Alpha('a')
    assert not (_Alpha('a') < _Alpha('a'))


# Generated at 2022-06-21 09:17:37.874638
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    # Alpha class _eq__ test cases
    # The comparison is alpha vs either alpha or str
    # None should fail
    alpha_test_cases = [
        (_Alpha('a_alpha'), 'a_alpha', True),
        (_Alpha('b_alpha'), 'b_alpha', True),
        (_Alpha('a_alpha'), 'c_alpha', False),
        (_Alpha('a_alpha'), 'c_str', False),
        (None, 'd_str', False),
    ]

    for alpha_test_case in alpha_test_cases:
        assert alpha_test_case[0].__eq__(alpha_test_case[1]) == alpha_test_case[2]


# Generated at 2022-06-21 09:17:42.400676
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('0.0.1') == '0.0.1'
    assert SemanticVersion('0.0.1-alpha') == '0.0.1-alpha'
    assert SemanticVersion('0.0.1-alpha+build1') == '0.0.1-alpha+build1'


# Generated at 2022-06-21 09:17:54.943104
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Test 0
    v1 = SemanticVersion('3.3.5')
    v2 = SemanticVersion('3.3.5')
    assert not (v1 > v2)

    # Test 1
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('2.2.3')
    assert v1 < v2

    # Test 2
    v1 = SemanticVersion('2.2.3')
    v2 = SemanticVersion('1.2.3')
    assert v1 > v2

    # Test 3
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.2')
    assert v1 > v2

    # Test 4
    v1 = SemanticVersion('0.2.3')

# Generated at 2022-06-21 09:18:04.216303
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    from pytest import raises

    assert SemanticVersion('1.0.0').core == (1, 0, 0)
    assert SemanticVersion('1.0.0').is_stable
    assert not SemanticVersion('0.0.0').is_stable
    assert not SemanticVersion('0.0.0-alpha').is_stable
    assert not SemanticVersion('1.0.0-alpha').is_stable
    assert SemanticVersion('1.0.0-alpha').prerelease == (_Alpha('alpha'), )

    with raises(ValueError):
        SemanticVersion('1.0')

    with raises(ValueError):
        SemanticVersion('1.0-beta')

    assert SemanticVersion('1.0.0+build.id').buildmetadata == (_Alpha('build'), _Alpha('id'))

# Generated at 2022-06-21 09:18:14.451185
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a = _Numeric(1)
    b = _Numeric(2)

    assert a != b
    assert a < b
    assert a <= b
    assert not a > b
    assert not a >= b

    a = _Numeric(1)
    b = _Numeric(1)

    assert a == b
    assert not a < b
    assert a <= b
    assert not a > b
    assert a >= b

    a = _Numeric(3)
    b = _Numeric(2)

    assert a != b
    assert not a < b
    assert not a <= b
    assert a > b
    assert a >= b

    # Test with non-numeric value
    a = _Numeric(3)
    b = _Alpha("3")

    assert a == b
    assert not a < b
   

# Generated at 2022-06-21 09:18:19.577057
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    x = _Numeric(1)
    assert x != _Numeric(1)
    assert x != 1
    assert x != _Numeric(2)
    assert x != 2


# Generated at 2022-06-21 09:18:23.342005
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.3.3')
    assert SemanticVersion('1.2.3') < SemanticVersion('2.2.3')



# Generated at 2022-06-21 09:18:27.868988
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    """Test case for _Numeric.__repr__
    """
    n = _Numeric(1)
    expected = repr(1)
    actual = repr(n)
    assert expected == actual, \
        'Return value mismatch. Expected: %r, actual: %r' % (expected, actual)


# Generated at 2022-06-21 09:18:30.613458
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    assert a.specifier == 'a'
    assert repr(a) == repr('a')
    assert isinstance(a, _Alpha)



# Generated at 2022-06-21 09:18:35.853787
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v1 = SemanticVersion('v1.2.3')
    assert v1.__repr__() == 'SemanticVersion(\'v1.2.3\')'
    v2 = SemanticVersion('v1.2.3')
    assert v2.__repr__() == 'SemanticVersion(\'v1.2.3\')'


# Generated at 2022-06-21 09:18:40.453160
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == '1'
    assert repr(_Numeric('1')) == '1'
    assert repr(_Numeric(1.0)) == '1'
    assert repr(_Numeric('1.0')) == '1'


# Generated at 2022-06-21 09:18:48.552316
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert not _Alpha('1.0') >= _Alpha('1.1')
    assert _Alpha('1.0') >= _Alpha('1.0')
    assert _Alpha('1.0') >= _Alpha('0.1')
    assert _Alpha('1') >= _Alpha('1')
    assert not _Alpha('1.0') > _Alpha('1.0')
    assert _Alpha('1.0') > _Alpha('0.9')
    assert _Alpha('2.0') > _Alpha('1.1')


# Generated at 2022-06-21 09:18:58.561626
# Unit test for constructor of class SemanticVersion

# Generated at 2022-06-21 09:19:00.536350
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('alpha')) == repr('alpha')


# Generated at 2022-06-21 09:19:04.111127
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('a') != 'a'
    assert not (_Alpha('a') != _Alpha('a'))
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != _Numeric('a')


# Generated at 2022-06-21 09:19:05.844115
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'


# Generated at 2022-06-21 09:19:07.133609
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == _Numeric('1')


# Generated at 2022-06-21 09:19:09.817215
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    actual = SemanticVersion('1.2.3') != '1.2.3'
    expected = False
    assert actual == expected, 'Test failed because expected {0}, recieved {1}'.format(expected, actual)


# Generated at 2022-06-21 09:19:21.727529
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    """Test _Alpha.__lt__ method

    Stubs
    """
    alpha_equal_alpha = _Alpha('alpha') == _Alpha('alpha')
    alpha_equal_str = _Alpha('alpha') == 'alpha'
    assert alpha_equal_alpha and alpha_equal_str

    alpha_greater_numeric_eq = _Alpha('alpha') >= _Numeric(1)
    alpha_greater_str_eq = _Alpha('alpha') >= 'alpha'
    alpha_greater_alpha_eq = _Alpha('alpha') >= _Alpha('alpha')
    assert alpha_greater_numeric_eq and alpha_greater_str_eq and alpha_greater_alpha_eq

    alpha_less_numeric = _Alpha('alpha') < _Numeric(1)

# Generated at 2022-06-21 09:19:23.246424
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert (True == _Alpha('2').__gt__(_Alpha('1')))
    assert (False == _Alpha('1').__gt__(_Alpha('2')))
    assert (False == _Alpha('1').__gt__(_Alpha('1')))


# Generated at 2022-06-21 09:19:30.081589
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= 3
    assert _Numeric(1) <= 1
    assert not _Numeric(1) <= 0
    assert not _Numeric(1) <= _Alpha('a')
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(3)
    assert not _Numeric(1) <= _Numeric(0)


# Generated at 2022-06-21 09:19:32.562437
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    numeric = _Numeric(1)
    numeric2 = _Numeric(2)
    numeric2.__le__(numeric)



# Generated at 2022-06-21 09:19:49.614033
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('2.8.1').parse('2.8.1') == ('2', '8', '1')
    assert SemanticVersion('2.8.1-alpha').parse('2.8.1-alpha') == ('2', '8', '1')
    assert SemanticVersion('2.8.1-alpha+ae3d0f').parse('2.8.1-alpha+ae3d0f') == ('2', '8', '1')
    assert SemanticVersion('2.8.1-alpha-204.eadf-204+ae3d0f').parse('2.8.1-alpha-204.eadf-204+ae3d0f') == ('2', '8', '1')

# Generated at 2022-06-21 09:19:56.481644
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('2') > _Numeric('1')
    assert not _Numeric('1') > _Numeric('1')
    assert not _Numeric('2') > _Numeric('10')
    assert not _Numeric('1') > _Numeric('10')
    assert not _Numeric('1') > '10'
    assert _Numeric('1') > _Alpha('10')
    assert _Numeric('1') > _Alpha('0')
    assert _Numeric('1') > _Alpha('1')


# Generated at 2022-06-21 09:19:57.964309
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1).__ne__(_Numeric(1))


# Generated at 2022-06-21 09:20:00.601947
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha("a") == "a"
    assert _Alpha("a") == _Alpha("a")
    assert not _Alpha("a") == "b"
    assert not _Alpha("a") == _Alpha("b")


# Generated at 2022-06-21 09:20:07.206404
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    """Unit test for method __ne__ of class SemanticVersion"""
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.basic import AnsibleModule

    basic._ANSIBLE_ARGS = None

    class ArgSpec(object):
        def __init__(self):
            self.args = None
            self.kwargs = None

    args = ArgSpec()

    class FakeModule(AnsibleModule):
        pass

    basic._ANSIBLE_ARGS = args

    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('2.0.0')
    v3 = SemanticVersion('1.0.1')
    v4 = SemanticVersion('1.1.0')
    v5 = SemanticVersion

# Generated at 2022-06-21 09:20:11.035385
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    assert(a.specifier == 'a')
    assert(a == 'a')
    assert(a != 'b')
    assert(a < 'b')
    assert(a <= 'b')
    assert(a <= 'a')
    assert(a >= 'a')
    assert(a > '0')
    assert(a >= '0')


# Generated at 2022-06-21 09:20:15.222176
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(0) != _Numeric(0)
    assert not (_Numeric(0) != _Numeric(0))
    assert not (_Numeric(1) != _Numeric(1))
    assert _Numeric(0) != 126
    assert _Numeric(0) != _Alpha('0')


# Generated at 2022-06-21 09:20:19.695385
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('2') == 2
    assert 2 == _Numeric('2')
    assert _Numeric('2') != '2'
    assert '2' != _Numeric('2')
    assert _Numeric('2') == _Numeric('2')


# Generated at 2022-06-21 09:20:21.890777
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    a = _Alpha('a')
    assert a.__repr__() == "'a'"


# Generated at 2022-06-21 09:20:24.937511
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    numeric1 = _Numeric('1')
    numeric2 = _Numeric('2')

    assert numeric1 >= numeric1
    assert numeric1 >= numeric2
    assert numeric2 >= numeric1


# Generated at 2022-06-21 09:20:35.124737
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('1') > _Numeric('0')
    assert not _Numeric('1') > _Numeric('1')
    assert not _Numeric('1') > _Numeric('2')
    assert not _Numeric('1') > _Alpha('1')
    return


# Generated at 2022-06-21 09:20:41.723490
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('2') > _Numeric('1') == True
    assert _Numeric('1') > _Numeric('2') == False
    assert _Numeric('1') > _Alpha('2') == True
    assert _Numeric('2') > _Alpha('1') == False

    assert _Numeric('1') > '1' == False
    assert _Numeric('2') > '1' == True

    assert _Numeric('2') > 0 == True
    assert _Numeric('1') > 0 == False


# Generated at 2022-06-21 09:20:47.871911
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion("1.0.0") != SemanticVersion("1.0.0")
    assert SemanticVersion("1.0.0") != "1.0.0"
    assert not SemanticVersion("1.0.0") != SemanticVersion("1.0.0")
    assert not SemanticVersion("1.0.0") != "1.0.0"


# Generated at 2022-06-21 09:20:50.511614
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    version = _Alpha('alpha')
    result = repr(version)
    assert result == repr('alpha')
    version = _Alpha(0)
    result = repr(version)
    assert result == repr(0)


# Generated at 2022-06-21 09:21:01.503956
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test expected success
    ver = SemanticVersion()
    ver.parse('1.2.3')
    assert ver.major == 1
    assert ver.minor == 2
    assert ver.patch == 3
    assert ver.prerelease == ()
    assert ver.buildmetadata == ()

    ver = SemanticVersion()
    ver.parse('1.2.3-alpha.1')
    assert ver.major == 1
    assert ver.minor == 2
    assert ver.patch == 3
    assert ver.prerelease == (_Alpha('alpha'), _Numeric(1))
    assert ver.buildmetadata == ()

    ver = SemanticVersion()
    ver.parse('1.2.3+build.1')
    assert ver.major == 1
    assert ver.minor == 2
    assert ver.patch == 3

# Generated at 2022-06-21 09:21:06.100750
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1').specifier == 1
    assert _Numeric('01').specifier == 1
    assert _Numeric('001').specifier == 1
    assert _Numeric(1).specifier == 1
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(2) >= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)



# Generated at 2022-06-21 09:21:08.118872
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    alpha1 = _Alpha("Hello")
    alpha2 = "Hello"
    assert alpha1.__ne__(alpha2)


# Generated at 2022-06-21 09:21:14.185520
# Unit test for constructor of class _Alpha
def test__Alpha():
    a1 = _Alpha('1')
    a2 = _Alpha('1')
    b1 = _Alpha('2')
    s1 = '1'
    s2 = '2'

    assert a1 == a2
    assert a1 == s1
    assert a1 != a2
    assert a1 != s1
    assert a1 < b1
    assert a1 < s2


# Generated at 2022-06-21 09:21:23.371263
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha1 = _Alpha('alpha')
    alpha2 = _Alpha('beta')
    alpha3 = _Alpha('gamma')
    alpha4 = _Alpha('delta')
    alpha5 = _Alpha('alpha')

    assert alpha1 <= alpha1
    assert alpha1 <= alpha2
    assert alpha1 <= alpha3
    assert alpha1 <= alpha4
    assert alpha1 <= alpha5

    assert alpha2 <= alpha2
    assert alpha2 <= alpha3
    assert alpha2 <= alpha4

    assert alpha3 <= alpha3
    assert alpha3 <= alpha4

    assert alpha4 <= alpha4

    assert alpha1 <= 'alpha'
    assert alpha1 <= 'beta'
    assert alpha1 <= 'gamma'
    assert alpha1 <= 'delta'

    assert alpha2 <= 'beta'
    assert alpha2 <= 'gamma'

# Generated at 2022-06-21 09:21:28.342903
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion("1.1") == SemanticVersion("1.1"), "SemanticVersion equality failed"
    assert not SemanticVersion("1.1") == SemanticVersion("1.2"), "SemanticVersion equality failed"
    assert not SemanticVersion("1.1") == "1.1", "SemanticVersion equality failed"


# Generated at 2022-06-21 09:21:40.147362
# Unit test for method __gt__ of class SemanticVersion

# Generated at 2022-06-21 09:21:47.958009
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0')
    assert not SemanticVersion('1.0.0') >= SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.1') >= SemanticVersion('1.0.0')
    assert not SemanticVersion('1.0.0') >= SemanticVersion('1.1.0')
    assert SemanticVersion('1.1.0') >= SemanticVersion('1.0.0')
    assert not SemanticVersion('1.0.0') >= SemanticVersion('2.0.0')
    assert SemanticVersion('2.0.0') >= SemanticVersion('1.0.0')


# Generated at 2022-06-21 09:21:48.868599
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    pass # My code here


# Generated at 2022-06-21 09:21:56.408364
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    actual = SemanticVersion('2.2.2')
    assert actual.major == 2
    assert actual.minor == 2
    assert actual.patch == 2

    actual = SemanticVersion('2.2.2-alpha.1')
    assert actual.major == 2
    assert actual.minor == 2
    assert actual.patch == 2
    assert actual.prerelease == (_Alpha('alpha'), _Numeric(1))

    actual = SemanticVersion('2.2.2+1.alpha')
    assert actual.major == 2
    assert actual.minor == 2
    assert actual.patch == 2
    assert actual.buildmetadata == (_Numeric(1), _Alpha('alpha'))


# Generated at 2022-06-21 09:22:08.064738
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre')) == SemanticVersion('1.2.3-pre')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')

    assert SemanticVersion.from_loose_version(LooseVersion('v1.2')) == SemanticVersion('1.2.0')

# Generated at 2022-06-21 09:22:17.412935
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # (other)
    # Equal
    assert _Numeric(0) < _Numeric(0) is False
    assert _Numeric(1) < _Numeric(1) is False
    # Less than
    assert _Numeric(0) < _Numeric(1) is True
    assert _Numeric(1) < _Numeric(2) is True

    # (other)
    # Equal
    assert _Numeric(0) < 0 is False
    assert _Numeric(1) < 1 is False
    # Less than
    assert _Numeric(0) < 1 is True
    assert _Numeric(1) < 2 is True


# Generated at 2022-06-21 09:22:26.969052
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0-rc.1')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0-rc.2')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0-rc.1+sha.5114f85')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.1.0-rc.2+sha.5114f85')
   

# Generated at 2022-06-21 09:22:30.349042
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= _Alpha('b') is False
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert _Alpha('a') >= 'b' is False
    assert _Alpha('b') >= 'a'


# Generated at 2022-06-21 09:22:32.113087
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    # Testing that the method returns the correct representation
    assert repr(_Alpha('test')) == "'test'"


# Generated at 2022-06-21 09:22:36.024686
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    '''test the SemanticVersion constructor'''
    SemanticVersion('1.2.3')
    SemanticVersion('1.2.3-rc3')



# Generated at 2022-06-21 09:22:46.885975
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha('a') > 'b'
    assert _Alpha('a') > 'A'
    assert not _Alpha('A') > 'a'
    assert _Alpha('a') > '0'


# Generated at 2022-06-21 09:22:52.964887
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    """Test method __ge__ of class SemanticVersion"""

    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') >= SemanticVersion('0.0.1')
    assert SemanticVersion('1.0.0') >= SemanticVersion('0.1.0')
    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha') >= SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha') >= SemanticVersion('1.0.0-alpha.1')

# Generated at 2022-06-21 09:22:55.865956
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric(1)
    b = _Numeric(2)
    return a < b


# Generated at 2022-06-21 09:22:59.540734
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert (_Numeric('1') != 1)
    assert (_Numeric('1') != _Numeric('2'))
    assert not (_Numeric('1') != _Numeric('1'))



# Generated at 2022-06-21 09:23:06.185786
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('1')
    assert _Alpha('1') >= _Alpha('1')
    assert _Alpha('1') >= _Alpha('a')
    assert _Alpha('1') >= 'a'
    assert not _Alpha('a') >= '1'
    assert not _Alpha('a') >= _Alpha('b')
    assert _Alpha('a') >= _Alpha('a')
    assert _Alpha('a') >= 'a'
    assert 'a' >= _Alpha('a')
    assert 'a' >= 'a'
    assert not 'a' >= _Alpha('b')

# Unit tests for method __le__ of class _Alpha

# Generated at 2022-06-21 09:23:09.572560
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion()) == 'SemanticVersion(None)'
    assert repr(SemanticVersion('1.2.3-alpha.4+github245')) == 'SemanticVersion(\'1.2.3-alpha.4+github245\')'



# Generated at 2022-06-21 09:23:19.429705
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') < _Alpha('gamma')
    assert _Alpha('alpha') < _Alpha('delta')
    assert _Alpha('alpha') < _Alpha('epsilon')

    # Numeric precedence over Alpha
    assert not _Alpha('alpha') < _Numeric('1')
    assert not _Alpha('alpha') < _Alpha('1')
    assert not _Alpha('1') < _Numeric('1')

    # Alpha precedence over Alpha
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') < _Alpha('gamma')
    assert _Alpha('alpha') < _Alpha('delta')
    assert _Alpha('alpha') < _Alpha('epsilon')

    # Equal Alpha

# Generated at 2022-06-21 09:23:25.574815
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('alpha') != 'beta'
    assert _Alpha('alpha').specifier == 'alpha'
    assert _Alpha('alpha') < 'beta'
    assert _Alpha('alpha') <= 'beta'
    assert _Alpha('alpha') <= 'alpha'
    assert _Alpha('alpha') > 'alpha'
    assert _Alpha('alpha') >= 'alpha'
    assert _Alpha('alpha') >= 'beta'


# Generated at 2022-06-21 09:23:26.713890
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(5).specifier == 5


# Generated at 2022-06-21 09:23:32.751737
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    num1 = _Numeric(1)
    num2 = _Numeric(2)
    num3 = _Numeric(3)
    num_eps = _Numeric(1.0 - 1.0e-10)
    alp1 = _Alpha(1)
    alp2 = _Alpha(2)
    alp3 = _Alpha(3)
    alp_a = _Alpha('a')
    alp_b = _Alpha('b')
    assert num1 <= num1
    assert num1 <= num_eps
    assert num1 <= num2
    assert num1 <= num3
    assert num1 <= alp1
    assert num1 <= alp2
    assert num1 <= alp3
    assert num1 <= alp_a
    assert num1 <= alp_b

    assert num_eps <= num1

# Generated at 2022-06-21 09:23:45.583819
# Unit test for constructor of class _Alpha
def test__Alpha():
    # Ensure that _Alpha() works.
    # This is entirely to make py3 work like py2
    # and it's validity is not independant of
    # the other comparators
    a = _Alpha('test')

    # We should now be able to compare a string to a
    assert a == 'test'
    assert 'test' == a

    # We should also be able to compare a string to a numeric
    # as well
    assert a < 1
    assert a <= 1
    assert a != 1
    assert a > 0
    assert a >= 0

    # Make sure that the operators work
    # for the reverse
    assert 'test' < 1
    assert 'test' <= 1
    assert 'test' != 1
    assert 'test' > 0
    assert 'test' >= 0

    # We should also be able to compare different _Alpha

# Generated at 2022-06-21 09:23:51.665808
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert not _Numeric(1) < _Numeric(1)
    assert _Numeric(1) < _Numeric(2)
    # A _Numeric is smaller than a _Alpha
    assert _Numeric(1) < _Alpha('b')
    assert _Numeric(1) < 2


# Generated at 2022-06-21 09:23:57.272004
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    # Test cases for _Numeric.__ne__
    num1 = _Numeric(2)
    num2 = _Numeric(2)
    assert not num1.__ne__(num2), "Failure testing _Numeric.__ne__ case 1"

    num1 = _Numeric(2)
    num2 = _Numeric(3)
    assert num1.__ne__(num2), "Failure testing _Numeric.__ne__ case 2"


# Generated at 2022-06-21 09:23:58.977983
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == "1"

# Generated at 2022-06-21 09:24:09.192973
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    assert v.vstring is None
    assert v.major == None
    assert v.minor == None
    assert v.patch == None
    assert isinstance(v.prerelease, tuple)
    assert len(v.prerelease) == 0
    assert isinstance(v.buildmetadata, tuple)
    assert len(v.buildmetadata) == 0

    v.parse('1.2.3')
    assert v.vstring == '1.2.3'
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert isinstance(v.prerelease, tuple)
    assert len(v.prerelease) == 0
    assert isinstance(v.buildmetadata, tuple)
    assert len(v.buildmetadata) == 0


# Generated at 2022-06-21 09:24:13.668027
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= _Numeric(0)
    assert _Numeric(0) >= _Numeric(0)
    assert _Numeric(1) >= 1
    assert _Numeric(0) >= 0
    assert not _Numeric(0) >= 1


# Generated at 2022-06-21 09:24:20.911462
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert(SemanticVersion.from_loose_version(LooseVersion('0.1.8.3')) == SemanticVersion('0.1.8'))
    assert(SemanticVersion.from_loose_version(LooseVersion('0.1.8')) == SemanticVersion('0.1.8'))
    assert(SemanticVersion.from_loose_version(LooseVersion('0')) == SemanticVersion('0'))
    assert(SemanticVersion.from_loose_version(LooseVersion('0.0')) == SemanticVersion('0.0'))
    assert(SemanticVersion.from_loose_version(LooseVersion('0.0.0')) == SemanticVersion('0.0.0'))

# Generated at 2022-06-21 09:24:26.561842
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('ab') >= _Alpha('ac')
    assert _Alpha('ac') >= _Alpha('ac')
    assert not _Alpha('ab') >= _Alpha('aa')
    assert _Alpha('aa') >= 'ab'
    assert 'ab' >= _Alpha('aa')
    assert 'ab' >= _Alpha('ac')
    assert _Alpha('ac') >= 'ab'
    assert 'ab' >= _Alpha('ab')
    assert _Alpha('ab') >= 'ab'
    assert 'ab' >= _Alpha('aa')
    assert _Alpha('aa') >= 'ab'


# Generated at 2022-06-21 09:24:28.976573
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    if _Alpha('a') >= 'a':
        return True
    else:
        return False


# Generated at 2022-06-21 09:24:30.562720
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert _Numeric(1).__repr__() == "1"


# Generated at 2022-06-21 09:24:52.105552
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    testcases = (
        ((_Alpha('a'), _Alpha('a')), False),
        ((_Alpha('a'), 'a'), False),
        ((_Alpha('a'), _Alpha('b')), True),
        ((_Alpha('a'), _Alpha('0')), False),
        ((_Alpha('a'), _Alpha('_')), True),
        ((_Alpha('a'), _Alpha('-')), False),
        ((_Alpha('a'), _Numeric(10)), False),
    )

    for (args, expected) in testcases:
        assert args[0].__lt__(args[1]) is expected


# Generated at 2022-06-21 09:24:54.609217
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    class_ = _Alpha
    specifier = 'git'
    got = class_(specifier).__repr__()
    want = repr(specifier)
    assert got == want


# Generated at 2022-06-21 09:24:57.247326
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('b') >= 'a'
    assert not _Alpha('b') >= 'c'
    assert _Alpha('1') >= _Alpha('0')
    assert _Alpha('1') >= '0'
    assert not _Alpha('1') >= '2'


# Generated at 2022-06-21 09:25:01.521134
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(1) == 1
    assert _Numeric(1) != 2
    assert _Numeric(1) < 2
    assert _Numeric(1) <= 2
    assert _Numeric(2) > 1
    assert _Numeric(2) >= 1

    try:
        assert _Numeric(1) < '2'
        assert False, 'Comparison between _Numeric and string should raise ValueError'
    except ValueError:
        assert True


# Generated at 2022-06-21 09:25:06.322104
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(0).__le__(_Numeric(0))
    assert _Numeric(0).__le__(_Numeric(1))
    assert _Numeric(1).__le__(_Numeric(0))
    assert _Numeric(1).__le__(_Numeric(1))


# Generated at 2022-06-21 09:25:14.629136
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == _Alpha('a')

    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')

    assert _Alpha('a') != _Alpha('b')

    assert _Alpha('a') != 1
    assert 1 != _Alpha('a')

    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert 'a' < _Alpha('b')

    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= 'a'
    assert 'a' <= _Alpha('a')

    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('b') > 'a'
    assert 'b' > _Alpha('a')

    assert _Alpha('a') >= _Alpha('a')

# Generated at 2022-06-21 09:25:16.291414
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > _Alpha('b')



# Generated at 2022-06-21 09:25:19.771176
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
  version = SemanticVersion.from_loose_version(LooseVersion('1.24.1'))
  # True
  assert(version >= '1.24.1')


# Generated at 2022-06-21 09:25:23.669187
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a1 = _Alpha('alpha')
    a2 = _Alpha('alpha')
    a3 = _Alpha('beta')

    assert not a1.__eq__(None)
    assert a1.__eq__(a1)
    assert a1.__eq__(a2)
    assert a1 == a1
    assert a1 == a2
    assert not a1 == a3
    assert a1 != a3



# Generated at 2022-06-21 09:25:30.702579
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert (5 > 2) == (_Numeric(5) > _Numeric(2))
    assert (5 > 5) == (_Numeric(5) > _Numeric(5))
    assert (5 > 8) == (_Numeric(5) > _Numeric(8))
    assert (5 > _Alpha('2')) == (_Numeric(5) > _Alpha('2'))
    assert (5 > _Alpha('5')) == (_Numeric(5) > _Alpha('5'))
    assert (5 > _Alpha('8')) == (_Numeric(5) > _Alpha('8'))



# Generated at 2022-06-21 09:25:52.929251
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    t0 = SemanticVersion('1.2.3')
    t1 = SemanticVersion('1.2.3')
    assert t0.__ge__(t1) == True


# Generated at 2022-06-21 09:25:55.197875
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    actual = SemanticVersion(vstring='1.2.3')
    expected = 'SemanticVersion(\'1.2.3\')'
    assert actual == expected


# Generated at 2022-06-21 09:25:58.633645
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    sver = SemanticVersion('1.0.0')
    assert sver.major == 1
    assert sver.minor == 0
    assert sver.patch == 0
    assert sver.prerelease == ()
    assert sver.buildmetadata == ()

# Generated at 2022-06-21 09:26:01.122695
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert 10 == _Numeric(10)
    assert isinstance(10, int)
    assert isinstance(_Numeric(10), _Numeric)


# Generated at 2022-06-21 09:26:12.076936
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Testing simple version codes
    v = SemanticVersion("1.0.0")
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion("1.0.0")
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion("1.10.0")
    assert v.major == 1
    assert v.minor == 10
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion("1.0.10")
    assert v.major == 1

# Generated at 2022-06-21 09:26:13.756989
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('3.0.0') != '4.0.0'



# Generated at 2022-06-21 09:26:16.665821
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    old = _Numeric(1)
    assert old.__ne__(_Numeric(2))
    assert old.__ne__(2)
    assert not old.__ne__(old)


# Generated at 2022-06-21 09:26:24.191219
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-21 09:26:25.904897
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.0.0') < SemanticVersion('2.0.0')


# Generated at 2022-06-21 09:26:35.108843
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') == _Numeric('01')
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric('1') == 1
    assert _Numeric('1') == '1'
    assert _Numeric('1') != _Numeric('2')
    assert _Numeric('1') != _Numeric('01')
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric('1') != 2
    assert _Numeric('1') != '2'
    assert _Numeric('1') != _Alpha('1')
    assert _Numeric('1') != _Alpha('01')
    assert _Numeric(1) != _Alpha(1)
    assert _Numeric('1') != _