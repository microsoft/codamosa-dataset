

# Generated at 2022-06-21 09:16:54.649183
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    num1 = _Numeric('2')
    num2 = _Numeric('3')
    num3 = _Numeric('3')

    assert num1 < num2
    assert num2 > num1
    assert num2 == num3
    assert num2 >= num3
    assert num2 <= num3


# Generated at 2022-06-21 09:17:00.275869
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(2)
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(1) > _Numeric('2')
    assert _Numeric(2) > _Numeric('1')
    assert _Numeric('1') > _Numeric(2)
    assert _Numeric('2') > _Numeric(1)


# Generated at 2022-06-21 09:17:09.619968
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('2.0') == SemanticVersion('2.0.0')
    assert SemanticVersion('1.2') == SemanticVersion('1.2.0')

    assert SemanticVersion('1.0-alpha') == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0-0') == SemanticVersion('1.0.0-0')
    assert SemanticVersion('1.0-alpha.1') == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0-1') == SemanticVersion('1.0.0-1')

# Generated at 2022-06-21 09:17:13.717393
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > _Alpha('b')
    assert _Alpha('a') > 'b'
    assert not _Alpha('b') > 'a'
    assert not _Alpha('a') > _Numeric('1')


# Generated at 2022-06-21 09:17:17.710447
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert (_Alpha('abc') >= _Alpha('abc')) == True
    assert (_Alpha('abc') >= _Alpha('def')) == False
    assert (_Alpha('abc') >= 'abc') == True
    assert (_Alpha('abc') >= 'def') == False


# Generated at 2022-06-21 09:17:19.006739
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('alpha')) == "'alpha'"



# Generated at 2022-06-21 09:17:28.411773
# Unit test for method __gt__ of class _Alpha

# Generated at 2022-06-21 09:17:34.700460
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(1)
    b = _Numeric(2)
    c = _Numeric(1)
    d = _Alpha(1)
    e = _Alpha(2)
    assert a != b
    assert a != c
    assert a != d
    assert a != e
    assert b != c
    assert b != d
    assert b != e
    assert c != d
    assert c != e
    assert d != e


# Generated at 2022-06-21 09:17:44.706054
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # Test that comparing two versions that are equal
    # results in False
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0') == False

    # Test that a higher major version is greater than a lower version
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0') == True

    # Test that a higher minor version is greater than a lower version
    assert SemanticVersion('1.2.0') > SemanticVersion('1.1.0') == True

    # Test that a higher patch version is greater than a lower version
    assert SemanticVersion('1.1.2') > SemanticVersion('1.1.1') == True

    # Test that a greater stable version is greater than a lower prerelease

# Generated at 2022-06-21 09:17:51.196658
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    def __ge__(v1, v2):
        return v1 >= v2

    assert __ge__(_Alpha('a'), _Alpha('a')) == True
    assert __ge__(_Alpha('b'), _Alpha('a')) == True
    assert __ge__(_Alpha('a'), _Alpha('b')) == False

    assert __ge__(_Alpha('a'), 'a') == True
    assert __ge__(_Alpha('b'), 'a') == True
    assert __ge__(_Alpha('a'), 'b') == False


# Generated at 2022-06-21 09:18:00.848791
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    n_1 = _Numeric(1)
    n_10 = _Numeric(10)
    n_100 = _Numeric(100)
    assert n_10 >= n_1
    assert n_10 >= n_10
    assert not (n_10 >= n_100)


# Generated at 2022-06-21 09:18:02.556763
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    numeric = _Numeric('1')
    assert numeric.__repr__() == '1'


# Generated at 2022-06-21 09:18:04.281896
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha("foo") > _Alpha("bar")
    assert not _Alpha("bar") > _Alpha("foo")


# Generated at 2022-06-21 09:18:14.515892
# Unit test for constructor of class _Alpha
def test__Alpha():
    # pylint: disable=unused-variable
    alpha = _Alpha('alpha')
    assert alpha.specifier == 'alpha'
    assert repr(alpha) == "'alpha'"
    assert alpha == 'alpha'
    assert alpha == _Alpha('alpha')
    assert alpha != 'beta'
    assert alpha != _Alpha('beta')
    assert alpha < 'beta'
    assert alpha < _Alpha('beta')
    assert alpha <= 'alpha'
    assert alpha <= _Alpha('alpha')
    assert alpha <= 'beta'
    assert alpha <= _Alpha('beta')
    assert alpha >= 'alpha'
    assert alpha >= _Alpha('alpha')
    assert alpha >= 'beta'
    assert alpha >= _Alpha('beta')
    assert alpha > 'alpha'
    assert alpha > _Alpha('alpha')
    assert alpha > 'beta'
    assert alpha

# Generated at 2022-06-21 09:18:25.988871
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion("0.1.1")
    assert repr(version) == 'SemanticVersion(\'0.1.1\')'
    version = SemanticVersion("0.1.1-rc1")
    assert repr(version) == 'SemanticVersion(\'0.1.1-rc1\')'
    version = SemanticVersion("0.1.1_rc1")
    assert repr(version) == 'SemanticVersion(\'0.1.1_rc1\')'
    version = SemanticVersion("0.1.1-rc1+build1234")
    assert repr(version) == 'SemanticVersion(\'0.1.1-rc1+build1234\')'
    version = SemanticVersion("0.1.1+build1234")

# Generated at 2022-06-21 09:18:27.734306
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('a')) == "'a'"


# Generated at 2022-06-21 09:18:37.585032
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion("1.2.3") <= "1.2.4"
    assert SemanticVersion("1.2.3") <= "1.2.3"
    assert SemanticVersion("1.2.3") <= "1.2.3-alpha.1"
    assert SemanticVersion("1.2.3") <= "1.2.3-beta"
    assert SemanticVersion("1.2.3") <= "1.2.3+build.1"

    assert not SemanticVersion("1.2.3") <= "1.2.2"
    assert not SemanticVersion("1.2.3") <= "1.2.2-alpha.1"
    assert not SemanticVersion("1.2.3") <= "1.2.2-beta"

# Generated at 2022-06-21 09:18:39.657696
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('A')


# Generated at 2022-06-21 09:18:50.742955
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Numeric('1')

    if (a == a) != True:
        raise AssertionError('a == a')
    if (b == b) != True:
        raise AssertionError('b == b')
    if (a == b) != False:
        raise AssertionError('a == b')
    if (a == c) != False:
        raise AssertionError('a == c')
    if (b == c) != False:
        raise AssertionError('b == c')
    if (a == None) != False:
        raise AssertionError('a == None')
    if (b == None) != False:
        raise AssertionError('b == None')

# Generated at 2022-06-21 09:18:55.820420
# Unit test for constructor of class _Numeric
def test__Numeric():
    testobject = _Numeric(1)
    assert testobject.specifier == 1
    testobject = _Numeric('1')
    assert testobject.specifier == 1
    try:
        testobject = _Numeric('a')
    except ValueError:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 09:19:10.458410
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():

    # Since, according to the specification,
    # "A pre-release version has a lower precedence than a normal version"
    # (see https://semver.org/#spec-item-9), the following assertion
    # should not fail:
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha')

    # According to the specification,
    # "Precedence for two pre-release versions with the same major, minor, and
    #  patch version MUST be determined by comparing each dot separated identifier
    #  from left to right until a difference is found as follows:"
    # (see https://semver.org/#spec-item-11)
    #
    # "A larger set of pre-release fields has a higher precedence than a
    #  smaller set, if all of the preceding identifiers are equal."
    #

# Generated at 2022-06-21 09:19:16.288782
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Create object
    version_1 = SemanticVersion('1.0.0')

    # Test greater than 1
    assert version_1 <= '2.0.0'

    # Test equal to 1
    assert version_1 <= '1.0.0'

    # Test less than 1
    assert not version_1 <= '0.9.9'


# Generated at 2022-06-21 09:19:20.144340
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # Note: This is not a unit test. This is a sanity check.
    assert repr(SemanticVersion(vstring='1')) == 'SemanticVersion(\'1\')'



# Generated at 2022-06-21 09:19:22.027444
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    a = _Numeric(42)
    assert a >= 42
    assert not a >= 43


# Generated at 2022-06-21 09:19:23.298189
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1).__ne__(1)



# Generated at 2022-06-21 09:19:30.445569
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert eval(repr(SemanticVersion('1.2.3'))) == SemanticVersion('1.2.3')
    assert eval(repr(SemanticVersion('1.2.3-alpha.1.2'))) == SemanticVersion('1.2.3-alpha.1.2')
    assert eval(repr(SemanticVersion('1.2.3+build.10.11'))) == SemanticVersion('1.2.3+build.10.11')


# Generated at 2022-06-21 09:19:39.094206
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    alpha_1 = _Alpha('alpha_1')
    alpha_2 = _Alpha('alpha_2')
    alpha_3 = _Alpha('alpha_3')
    number_1 = _Numeric('1')
    number_2 = _Numeric('2')
    number_3 = _Numeric('3')
    assert alpha_1 < alpha_2
    assert not(alpha_1 >= alpha_2)
    assert alpha_1 < alpha_3
    assert not(alpha_1 >= alpha_3)
    assert not(number_1 < alpha_1)
    assert not(number_1 >= alpha_1)
    assert not(number_1 < alpha_2)
    assert not(number_1 >= alpha_2)
    assert not(number_1 < alpha_3)
    assert not(number_1 >= alpha_3)


# Generated at 2022-06-21 09:19:49.929810
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert(SemanticVersion().__repr__() == 'SemanticVersion(None)')
    assert(SemanticVersion('1.2.3-alpha').__repr__() == 'SemanticVersion(\'1.2.3-alpha\')')
    assert(SemanticVersion('1.2.3+build.3').__repr__() == 'SemanticVersion(\'1.2.3+build.3\')')
    assert(SemanticVersion('1.2.3-alpha+build.3').__repr__() == 'SemanticVersion(\'1.2.3-alpha+build.3\')')
    assert(SemanticVersion('1.2.3-alpha.1+build.3').__repr__() ==  'SemanticVersion(\'1.2.3-alpha.1+build.3\')')


# Generated at 2022-06-21 09:19:56.197197
# Unit test for constructor of class _Alpha
def test__Alpha():
    versions = [
        ('1', _Numeric('1')),
        ('23', _Numeric('23')),
        ('5-beta', _Alpha('5-beta')),
        ('1.0.0-x.7.z.92', _Alpha('1.0.0-x.7.z.92'))
    ]

    for version in versions:
        _semver = _Alpha(version[0])
        assert _semver == version[1]

# Generated at 2022-06-21 09:20:01.622073
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    obj = SemanticVersion('1.2.3')
    assert obj.__ne__('1.2.3') == False
    assert obj.__ne__('1.2.4') == True
    assert obj.__ne__('1.3.3') == True
    assert obj.__ne__(SemanticVersion('1.2.3')) == False
    assert obj.__ne__(SemanticVersion('1.2.4')) == True
    assert obj.__ne__(SemanticVersion('1.3.3')) == True

# Generated at 2022-06-21 09:20:12.955454
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # Comparison of string and integer, behaviour of python 2
    assert _Alpha("1") > 0
    assert _Alpha("1") > 1
    assert not _Alpha("1") > 2
    # Comparison of string and integer, behaviour of python 3
    assert not _Alpha("1") > 0
    assert not _Alpha("1") > 1
    assert not _Alpha("1") > 2
    # Comparison of string and string, behaviour of python 2
    assert _Alpha("1") > "0"
    assert _Alpha("1") > "1"
    assert not _Alpha("1") > "2"
    # Comparison of string and string, behaviour of python 3
    assert not _Alpha("1") > "0"
    assert not _Alpha("1") > "1"
    assert not _Alpha("1") > "2"
    # Comparison of string and string

# Generated at 2022-06-21 09:20:23.662233
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    """
    This function is designed to test the __ge__ method of
    class SemanticVersion of module ansible_collections.sivel.lib_version.
    """
    v1 = SemanticVersion("0.9.3")
    v2 = SemanticVersion("1.0.2")
    v3 = SemanticVersion("1.0.3-alpha.3")
    v4 = SemanticVersion("1.2.1")
    v5 = SemanticVersion("1.2.2")
    v6 = SemanticVersion("1.2.2-alpha.1")
    assert v1 >= v1
    assert not v1 >= v2
    assert not v1 >= v3
    assert not v1 >= v4
    assert not v1 >= v5
    assert not v1 >= v6

# Generated at 2022-06-21 09:20:25.009041
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('a')


# Generated at 2022-06-21 09:20:30.345889
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Numeric("1") >= _Numeric("1")
    assert _Numeric("1") >= _Alpha("1")
    assert _Numeric("1") >= "1"

    assert not _Alpha("a") >= _Numeric("1")
    assert _Alpha("a") >= _Alpha("a")
    assert _Alpha("a") >= "a"



# Generated at 2022-06-21 09:20:37.194172
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alphas = {
        _Alpha('a'): [
            _Alpha('a1'),
            _Alpha('b'),
            _Alpha('z'),
            _Alpha('1'),
            _Alpha('1.1')
        ],
        _Alpha('b'): [
            _Alpha('a'),
            _Alpha('a.1'),
            _Alpha('a1'),
            _Alpha('b1'),
            _Alpha('z'),
            _Alpha('1'),
            _Alpha('1.1')
        ]
    }

    for alpha, others in alphas.items():
        for other in others:
            assert alpha > other


# Generated at 2022-06-21 09:20:46.711694
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test invalid inputs
    # raise ValueError("%r is not a LooseVersion" % loose_version)
    #   AssertionError: ValueError not raised
    assert SemanticVersion.from_loose_version("1.1.1") != None

    # raise ValueError("Non integer values in %r" % loose_version)
    #   AssertionError: ValueError not raised
    assert SemanticVersion.from_loose_version("1.1.1") != None

    # Test valid input
    # AssertionError: '1.0' != '1.1'
    assert SemanticVersion.from_loose_version("1.1") == SemanticVersion("1.1.0")


# Generated at 2022-06-21 09:20:48.936402
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert(_Alpha('alpha') <= _Alpha('alpha'))
    assert(_Alpha('alpha') <= _Alpha('beta'))
    assert(not (_Alpha('beta') <= _Alpha('alpha')))


# Generated at 2022-06-21 09:20:59.854566
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    from pytest import raises
    from itertools import product

    # Test cases for method __ge__ of class SemanticVersion
    #
    # Each test case is a tuple of:
    # * desc: Description of the test case
    # * a: value to pass as first argument to method a.__ge__(b)
    # * b: value to pass as second argument to method a.__ge__(b)
    # * expected: expected return value of a.__ge__(b)

# Generated at 2022-06-21 09:21:02.527297
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    x = _Numeric(123)
    y = _Numeric(123)
    # Case A: x.__ne__(y) == True
    if x.__ne__(y):
        assert True
    else:
        assert False

# Generated at 2022-06-21 09:21:05.888356
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    version1 = SemanticVersion('1.2.3')
    version2 = SemanticVersion('1.3.3')
    version3 = SemanticVersion('1.2.4')

    assert version1 < version2
    assert version1 < version3
    assert not version1 < version1
    assert not version2 < version1
    assert not version3 < version1

# Generated at 2022-06-21 09:21:19.981179
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test 1 - text_type et al are to avoid a pyflakes error
    v1 = text_type("this.is.a.test")
    # Test 2
    v2 = text_type("1234")
    # Test 3
    v3 = text_type("1234.this.is.a.test")
    # Test 4
    v4 = text_type("this.is.a.test.1234")
    # Test 5
    v5 = text_type("that.is.a.test.1234")
    # Test 6
    v6 = text_type("this.is.a.test.1234.that.is.a.test.1234")
    # Test 7

# Generated at 2022-06-21 09:21:24.178301
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    numeric_1 = _Numeric(1)
    numeric_2 = _Numeric(2)

    assert numeric_1 <= numeric_1
    assert numeric_1 <= numeric_2
    assert numeric_1 <= 1
    assert numeric_1 <= 2


# Generated at 2022-06-21 09:21:31.040367
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Case where the input is a LooseVersion
    version = SemanticVersion.from_loose_version(
        LooseVersion('0.1.2')
    )
    assert version == '0.1.2'

    # Case where input is not a LooseVersion
    try:
        SemanticVersion.from_loose_version('0.1.2')
        assert False, 'ValueError not raised'
    except ValueError as e:
        assert 'is not a LooseVersion' in text_type(e)

# Generated at 2022-06-21 09:21:40.328712
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # SemanticVersion does not accept a LooseVersion as a parameter
    loose_version = LooseVersion('1.3.0')
    assert loose_version != SemanticVersion('1.3.0')
    assert loose_version != SemanticVersion(loose_version)

    # SemanticVersion(LooseVersion('1.3.0')) raises an exception
    with pytest.raises(TypeError, match=r"object.*int"):
        SemanticVersion(loose_version)

    # But SemanticVersion.from_loose_version works
    assert loose_version == SemanticVersion.from_loose_version(loose_version)

    with pytest.raises(ValueError, match=r"3\.0\.1-alpha_1 is not a LooseVersion"):
        SemanticVersion.from_loose_

# Generated at 2022-06-21 09:21:44.921726
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    num = _Numeric('12')
    assert num.__le__(13) is True
    assert num.__le__('23') is True
    assert num.__le__(_Alpha('12')) is False
    assert num.__le__(num) is True
    num2 = _Numeric(23)
    assert num.__le__(num2) is True


# Generated at 2022-06-21 09:21:55.433969
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    print("test_SemanticVersion___lt__()")

    version1 = SemanticVersion("1.0.1")
    version2 = SemanticVersion("1.0.2")
    version3 = SemanticVersion("1.0.1a1")
    version4 = SemanticVersion("1.0.1a2")
    version5 = SemanticVersion("1.0.2a1")
    version6 = SemanticVersion("1.0.2a2")
    version7 = SemanticVersion("1.0.1b1")
    version8 = SemanticVersion("1.0.1b2")

    assert version1 < version2, "version1 < version2"
    assert version1 < version3, "version1 < version3"
    assert version1 < version4, "version1 < version4"

# Generated at 2022-06-21 09:22:02.374588
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    """Unit test for method __ne__ of class _Alpha"""
    _alpha_1 = _Alpha('_alpha_1')
    _alpha_2 = _Alpha('_alpha_2')
    assert _alpha_1.__ne__(_alpha_2) == True
    assert _alpha_1.__ne__(_Alpha(_alpha_1.specifier)) == False
    assert _alpha_1.__ne__(_alpha_1.specifier) == False


# Generated at 2022-06-21 09:22:13.808375
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Given
    v_string = "1.0.0"

    my_SemanticVersion = SemanticVersion()

    # When
    my_SemanticVersion.parse(v_string)

    # Then
    assert my_SemanticVersion.major == 1
    assert my_SemanticVersion.minor == 0
    assert my_SemanticVersion.patch == 0
    assert my_SemanticVersion.prerelease == ()
    assert my_SemanticVersion.buildmetadata == ()

    # Given
    v_string = "1.0.0-alpha.1"

    my_SemanticVersion = SemanticVersion()

    # When
    my_SemanticVersion.parse(v_string)

    # Then
    assert my_SemanticVersion.major == 1
    assert my_SemanticVersion.minor == 0
    assert my_Sem

# Generated at 2022-06-21 09:22:22.542310
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha("1.0.0") == "1.0.0"
    assert not _Alpha("1.0.0") == "1.0.1"

# Generated at 2022-06-21 09:22:24.031439
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(10)) == '10', '_Numeric.__repr__ is broken'



# Generated at 2022-06-21 09:22:44.950181
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():

    # Creates a SemanticVersion instance with a version number
    v1 = SemanticVersion("1.0.0")
    assert v1.major==1, "major is not 1"
    assert v1.minor==0, "minor is not 0"
    assert v1.patch==0, "patch is not 0"
    assert v1.prerelease==(), "prerelease is not empty"
    assert v1.buildmetadata==(), "buildmetadata is not empty"
    assert v1.is_stable, "v1 is not stable"

    # Creates a SemanticVersion instance with a prerelease version number
    v2 = SemanticVersion("1.0.0-beta.1")
    assert v2.major==1, "major is not 1"
    assert v2.minor==0, "minor is not 0"


# Generated at 2022-06-21 09:22:46.728801
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == _Alpha('a')


# Generated at 2022-06-21 09:22:48.946542
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('42') == 42
    assert _Numeric('42') != 43
    assert _Numeric('42') != '42'
    assert _Numeric('42') != _Alpha('42')


# Generated at 2022-06-21 09:22:51.983418
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    arg1 = _Alpha('first')
    arg2 = _Alpha('second')
    arg3 = 'first'

    result = arg1.__eq__(arg2)
    assert not result

    result = arg1.__eq__(arg3)
    assert result


# Generated at 2022-06-21 09:22:53.185696
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(5) == repr(_Numeric(5))


# Generated at 2022-06-21 09:23:03.999491
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    def call(vstring1, vstring2):
        return (
            SemanticVersion(vstring1),
            SemanticVersion(vstring2),
            SemanticVersion(vstring1) <= SemanticVersion(vstring2)
        )

# Generated at 2022-06-21 09:23:10.674942
# Unit test for method __gt__ of class SemanticVersion

# Generated at 2022-06-21 09:23:20.652910
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion(None) is not None
    # test all the cases of invalid version
    invalid_version = ['1.2.3', '1.2.3.4', '1.0', '1.1.1a', '1.1.1-alpha', '1.0.0+20130313144700', '1.0.0-rc.1+build.123']
    for version in invalid_version:
        try:
            SemanticVersion(version)
            print("FAIL: Version %s should be invalid, but constructor accepts it" % version)
        except ValueError:
            pass
        except Exception as e:
            print("FAIL: Invalid exception %s" % e)
    # test all the cases of valid version

# Generated at 2022-06-21 09:23:26.569142
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    num1 = _Numeric('1')
    num2 = _Numeric('2')
    assert not num1.__gt__(num2)
    assert num2.__gt__(num1)
    assert not num1.__gt__(_Alpha('2'))
    assert num2.__gt__(_Alpha('1'))
    assert num1.__gt__(_Alpha('0'))
    assert not num1.__gt__(_Alpha('1'))


# Generated at 2022-06-21 09:23:28.898972
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == 2
    assert not _Numeric(1) == _Numeric('1')


# Generated at 2022-06-21 09:24:09.936775
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    _Numeric(1) < _Numeric(2)
    _Numeric(1) < 2

    try:
        _Numeric(1) < _Alpha('a')
        raise AssertionError('_Numeric(1) < _Alpha(\'a\') should fail')
    except ValueError:
        pass

    try:
        _Numeric(1) < 'a'
        raise AssertionError('_Numeric(1) < \'a\' should fail')
    except ValueError:
        pass


# Generated at 2022-06-21 09:24:18.770910
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
	a = _Alpha("1.0.0")
	b = _Alpha("1.0.0")
	c = _Alpha("1.0.1")
	d = _Alpha("2.0.0")
	e = _Alpha("1.1.0")
	# test 1
	assert a.__gt__(b) == False
	# test 2
	assert a.__gt__(c) == False
	# test 3
	assert a.__gt__(d) == False
	# test 4
	assert a.__gt__(e) == False
	# test 5
	assert b.__gt__(a) == False
	# test 6
	assert b.__gt__(c) == False
	# test 7
	assert b.__gt__(d) == False
	# test 8
	assert b

# Generated at 2022-06-21 09:24:22.426125
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    version_a = SemanticVersion('1.4.4')
    version_b = SemanticVersion('1.4.3')
    assert version_a > version_b
    assert version_b < version_a
    assert version_a >= version_b
    assert version_b <= version_a
    assert not version_a == version_b



# Generated at 2022-06-21 09:24:25.302926
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # Testing operation 'SemanticVersion(%r)'
    s_version=SemanticVersion('1.2.3-rc1+bz99999')
    assert repr(s_version) == "SemanticVersion('1.2.3-rc1+bz99999')"


# Generated at 2022-06-21 09:24:35.339946
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0a1') == SemanticVersion('1.0.0a1')
    assert SemanticVersion('1.0.0a1') == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion('1.0.0-alpha.1') == SemanticVersion('1.0.0a1')
    assert SemanticVersion('1.0.0-alpha.1') == SemanticVersion('1.0.0-alpha.01')
    assert SemanticVersion('1.0.0-alpha1') == SemanticVersion('1.0.0-alpha.1')

# Generated at 2022-06-21 09:24:44.632174
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    sv = SemanticVersion('1.2.3')
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()

    sv = SemanticVersion('1.2.3-alpha.0')
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == (_Numeric('alpha'), _Numeric('0'))
    assert sv.buildmetadata == ()

    sv = SemanticVersion('1.2.3-alpha.0+20130313144700')
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3

# Generated at 2022-06-21 09:24:50.993122
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.10.0') > SemanticVersion('1.9.10')
    assert SemanticVersion('1.10.0') > SemanticVersion('1.9.9')
    assert SemanticVersion('1.10') > SemanticVersion('1.9.9')
    assert SemanticVersion('1.9.9') > SemanticVersion('1.9.8')
    assert SemanticVersion('2.0') > SemanticVersion('1.9.8')
    assert SemanticVersion('1.0') > SemanticVersion('0.9.0')
    assert SemanticVersion('1.0') > SemanticVersion('0.9.8')
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0')

# Generated at 2022-06-21 09:24:53.232785
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == 'SemanticVersion(\'1.2.3\')'



# Generated at 2022-06-21 09:24:55.936909
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert _Numeric(0) >= _Numeric(0)
    assert _Numeric(0) >= _Numeric(0)
    assert _Numeric(0) >= _Alpha(0)
    assert _Numeric(0) >= _Alpha('0')

# Generated at 2022-06-21 09:24:57.034280
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    pass


# Generated at 2022-06-21 09:25:36.376836
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert _Alpha('a').__repr__() == repr('a')
    assert _Alpha('b').__repr__() == repr('b')
    assert _Alpha('c').__repr__() == repr('c')
    assert _Alpha('1').__repr__() == repr('1')
    assert _Alpha('2').__repr__() == repr('2')
    assert _Alpha('3').__repr__() == repr('3')


# Generated at 2022-06-21 09:25:45.200016
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    def test(v1, v2, expected):
        assert SemanticVersion(v1).__gt__(SemanticVersion(v2)) == expected

    test('2.0.0', '1.0.0', True)
    test('1.0.0', '2.0.0', False)
    test('1.0.1', '1.0.0', True)
    test('1.0.0', '1.0.1', False)
    test('0.0.0', '0.0.1', False)
    test('0.1.0', '0.0.1', True)
    test('0.0.1', '0.1.0', False)
    test('0.0.0-alpha.1', '0.0.0', False)

# Generated at 2022-06-21 09:25:53.091152
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # when lhs == rhs
    res = _Alpha('1') <= _Alpha('1')
    assert res is True

    # when lhs < rhs
    res = _Alpha('1') <= _Alpha('2')
    assert res is True

    # when lhs > rhs
    res = _Alpha('2') <= _Alpha('1')
    assert res is False

    # when lhs is an int
    res = _Alpha('1') <= 1
    assert res is True


# Generated at 2022-06-21 09:25:57.326828
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < _Alpha('2')
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(2) > _Alpha('1')
    assert _Numeric(2) == _Numeric(2)



# Generated at 2022-06-21 09:26:00.913847
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    x = SemanticVersion('1.2.3-alpha-234')
    y = SemanticVersion('1.2.3-alpha-234')
    assert not x.__gt__(y)
    assert y.__gt__(x)


# Generated at 2022-06-21 09:26:11.894733
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    __tracebackhide__ = True


# Generated at 2022-06-21 09:26:21.528153
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    """ Unit tests for the equality operator of SemanticVersion. """
    a = SemanticVersion('1.2.3')
    b = SemanticVersion('1.2.3')
    c = SemanticVersion('1.2.4')
    d = SemanticVersion('1.3.3')
    e = SemanticVersion('2.2.3')
    f = SemanticVersion('1.2.3-alpha.1')
    g = SemanticVersion('1.2.3-alpha.beta')
    h = SemanticVersion('1.2.3-beta.2')
    i = SemanticVersion('1.2.3-beta.11')
    j = SemanticVersion('1.2.3-rc.1')
    k = SemanticVersion('1.2.3')

    assert a == b
    assert not a

# Generated at 2022-06-21 09:26:24.641405
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(SemanticVersion('1.0.0').__repr__()) == repr(SemanticVersion('1.0.0').vstring)


# Generated at 2022-06-21 09:26:34.209919
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('test') < _Alpha('test2')
    assert _Alpha('test') < _Alpha('test1')
    assert _Alpha('test') < _Alpha('test-1')
    assert _Alpha('test') < _Alpha('test+1')
    assert _Alpha('test') < _Alpha('test_1')
    assert _Alpha('test') < _Alpha('test.1')
    assert _Alpha('test') < _Alpha('test/1')
    assert _Alpha('test') < _Alpha('test%1')
    assert _Alpha('test') < _Alpha('test|1')
    assert _Alpha('test') < _Alpha('test 1')

    assert _Alpha('test') < 'test'
    assert _Alpha('test') < 'test1'
    assert _Alpha('test') < 'test-1'
    assert _

# Generated at 2022-06-21 09:26:35.483877
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion("1.1.1")
    v2 = SemanticVersion("1.1.1.0")
    assert v1 >= v2
