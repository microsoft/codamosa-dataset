

# Generated at 2022-06-21 09:17:03.924606
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    _alpha_instance_1 = _Alpha("1")
    _alpha_instance_2 = _Alpha("1")
    _alpha_instance_3 = _Alpha("2")

    assert _alpha_instance_1.__ne__(_alpha_instance_2) is False
    assert _alpha_instance_1.__ne__(_alpha_instance_3) is True


# Generated at 2022-06-21 09:17:07.300400
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('abc') == _Alpha('abc')
    assert _Alpha('abc') == 'abc'

    assert not _Alpha('abc') == _Alpha('xyz')
    assert not _Alpha('abc') == 'xyz'


# Generated at 2022-06-21 09:17:13.799769
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha("a") >= _Alpha("a")
    assert _Alpha("b") >= _Alpha("a")
    assert not _Alpha("a") >= _Alpha("b")
    assert _Alpha("a") >= "a"
    assert _Alpha("b") >= "a"
    assert not _Alpha("a") >= "b"
    assert not _Alpha("a") >= _Numeric("a")
    assert not _Alpha("a") >= _Numeric("b")


# Generated at 2022-06-21 09:17:24.082160
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.0")
    assert v1.__eq__(v2) == True

    v1 = SemanticVersion("1.0.0")
    v2 = "1.0.0"
    assert v1.__eq__(v2) == True

    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.1")
    assert v1.__eq__(v2) == False

    v1 = SemanticVersion("1.0.0")
    v2 = "1.0.1"
    assert v1.__eq__(v2) == False


# Generated at 2022-06-21 09:17:28.545408
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > 0
    assert _Numeric(1) > _Numeric(0)
    assert not _Numeric(1) > _Numeric(1)
    assert not _Numeric(1) > _Numeric(2)
    assert not _Numeric(1) > _Alpha(1)
    try:
        _Numeric(1) > _Alpha('a')
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-21 09:17:31.485958
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    import pytest
    v1 = SemanticVersion("0.0.1-pre.alpha")
    assert repr(v1) == "SemanticVersion('0.0.1-pre.alpha')"


# Generated at 2022-06-21 09:17:41.508947
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3-alpha') == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3+build.1') == SemanticVersion('1.2.3+build.1')
    assert SemanticVersion('1.2.3-alpha+build.1') == SemanticVersion('1.2.3-alpha+build.1')
    assert SemanticVersion('1.2.3-alpha.1+build.1') == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-21 09:17:51.494481
# Unit test for constructor of class _Alpha
def test__Alpha():
    """Unit test for constructor of class _Alpha"""
    assert _Alpha('alpha') == 'alpha'
    assert _Alpha('alpha') != 'beta'
    assert _Alpha('alpha') < 'beta'
    assert _Alpha('alpha') <= 'beta'
    assert not _Alpha('alpha') > 'beta'
    assert not _Alpha('alpha') >= 'beta'
    assert _Alpha('alpha') > 'alpha'
    assert _Alpha('alpha') < 'alpha'
    assert _Alpha('alpha') >= 'alpha'
    assert _Alpha('alpha') <= 'alpha'
    assert _Alpha('alpha') == _Alpha('alpha')
    assert _Alpha('alpha') != _Alpha('beta')
    assert _Alpha('alpha') < _Alpha('beta')
    assert _Alpha('alpha') <= _Alpha('beta')

# Generated at 2022-06-21 09:17:55.663296
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    a = _Numeric(5)
    assert not a.__ne__(5)
    assert not a.__ne__(_Numeric(5))
    assert a.__ne__(4)
    assert a.__ne__(_Numeric(4))
    assert a.__ne__("5")
    assert a.__ne__(_Alpha("5"))



# Generated at 2022-06-21 09:18:00.062467
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    for vstring in (
        '1.0.0',
        '1.2.3',
        '1.2.3-alpha.10.beta.0+build.unicorn.rainbow',
    ):
        version = SemanticVersion(vstring)
        assert version.core == SemanticVersion(vstring).core



# Generated at 2022-06-21 09:18:15.201900
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    n3 = _Numeric(3)
    a1 = _Alpha('a')
    a2 = _Alpha('b')

    list_tests = [
        (n1, n2, False),
        (n2, n2, False),
        (n3, n2, True),
        (n1, a1, False),
        (a1, n1, True),
        (a1, a2, False),
        (a2, a1, True),
    ]


# Generated at 2022-06-21 09:18:26.287510
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.2') == SemanticVersion('1.2.0')
    assert SemanticVersion('1.2') == '1.2.0'
    assert not SemanticVersion('0.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('0.2.3') == '0.2.3'
    assert not SemanticVersion('1.20.3') == SemanticVersion('1.2.3')
    assert SemanticVersion('1.20.3') == '1.20.3'
    assert not SemanticVersion('1.2.3') == '1.2'
    assert SemanticVersion('0.2.3') == '0.2.3'
   

# Generated at 2022-06-21 09:18:29.834156
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    a = SemanticVersion('1.2.3.4-5.6+7.8')
    assert repr(a) == "SemanticVersion('1.2.3.4-5.6+7.8')"


# Generated at 2022-06-21 09:18:31.098620
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('alpha')) == "'alpha'"


# Generated at 2022-06-21 09:18:39.796138
# Unit test for constructor of class _Numeric
def test__Numeric():
    class _NumericTest(object):
        test_arg_is_str_str = _Numeric('5')
        test_arg_is_str_int = _Numeric('5')
        test_arg_is_int_int = _Numeric(5)

        test_arg_is_int_str = _Numeric(5)
        test_arg_is_int_int = _Numeric(5)
        test_arg_is_int_int = _Numeric(5)

    assert _NumericTest.test_arg_is_str_str == _NumericTest.test_arg_is_str_int
    assert _NumericTest.test_arg_is_str_str == _NumericTest.test_arg_is_int_str

# Generated at 2022-06-21 09:18:43.232054
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    ver1 = SemanticVersion('1.9.9')
    ver2 = SemanticVersion('2.0.0')
    assert (ver1 >= ver2) == False


# Generated at 2022-06-21 09:18:53.970284
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    if _Alpha('alpha') == 'alpha':
        print('PASS: _Alpha("alpha") == "alpha"')
    else:
        print('FAIL: _Alpha("alpha") == "alpha"')

    if _Alpha('alpha') == _Alpha('alpha'):
        print('PASS: _Alpha("alpha") == _Alpha("alpha")')
    else:
        print('FAIL: _Alpha("alpha") == _Alpha("alpha")')

    if _Alpha('alpha2') == 'alpha2':
        print('PASS: _Alpha("alpha2") == "alpha2"')
    else:
        print('FAIL: _Alpha("alpha2") == "alpha2"')

    if _Alpha('alpha') == 'Alpha':
        print('FAIL: _Alpha("alpha") == "Alpha"')

# Generated at 2022-06-21 09:18:59.479488
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    testcase = [
        {'expected': False, 'other': 'a', 'specifier': 'a'},
        {'expected': True, 'other': '1', 'specifier': 'a'},
        {'expected': True, 'other': 1, 'specifier': '1'},
        {'expected': False, 'other': 1, 'specifier': 1},
        ]
    for case in testcase:
        _numeric = _Numeric(case['specifier'])
        assert case['expected'] == _numeric.__ne__(case['other'])


# Generated at 2022-06-21 09:19:09.498792
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('a0')
    assert _Alpha('a') < _Alpha('0')
    assert not (_Alpha('a') < _Alpha('a'))
    assert not (_Alpha('a') < _Alpha('9'))

    assert 'a' < _Alpha('b')
    assert 'a' < _Alpha('a0')
    assert _Alpha('a') < '0'
    assert not ('a' < _Alpha('a'))
    assert not (_Alpha('a') < '9')

    try:
        assert _Alpha('a') < 1
        assert False  # pragma: no cover
    except ValueError:
        pass


# Generated at 2022-06-21 09:19:13.358979
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert not _Numeric(2) <= _Numeric(1)


# Generated at 2022-06-21 09:19:36.382664
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.3.4')) == SemanticVersion('2.0.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.0')) == SemanticVersion('1.0.0-alpha.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta.12')) == SemanticVersion('1.0.0-beta.12')
   

# Generated at 2022-06-21 09:19:39.886756
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('1.3.3')
    v2 = SemanticVersion('1.2.3')
    assert v1 > v2


# Generated at 2022-06-21 09:19:47.687265
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < 'b'
    assert _Alpha('a') < 'b'
    assert not _Alpha('b') < 'a'
    assert not _Alpha('b') < 'a'
    assert not _Alpha('b') < 'b'
    assert _Alpha('b') < 'c'
    assert not _Alpha('c') < 'b'
    assert _Alpha('2') < '3'
    assert not _Alpha('3') < '2'
    assert not _Alpha('2') < '2'



# Generated at 2022-06-21 09:19:57.483503
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    """Test for method __lt__ of class SemanticVersion"""

    ############# LEFT SIDE ===============
    left = SemanticVersion("0.0.1")

    ############# RIGHT SIDE ===============
    right = SemanticVersion("0.0.2")

    ############# EXPECTED VALUE ===========

    ###############################
    #                             #
    #   INTERPRETED RESULT TABLE  #
    #                             #
    #  +--------------------------------------+
    #  |           TO BE TESTED                |
    #  +--------------------------------------+
    #  |                                      |
    #  |      left < right      |       Y      |
    #  +--------------------------------------+
    #  |                                      |
    #  |      left == right      |       N      |
    #  +--------------------------------------

# Generated at 2022-06-21 09:19:58.790439
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert _Numeric('1') < _Numeric('2')
    # Unit test for method __lt__ of class _Alpha

# Generated at 2022-06-21 09:20:01.223210
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # testing alphabet lower than alphabet
    assert _Alpha('a') < _Alpha('b')
    # testing alphabet lower than number
    assert _Alpha('a') < _Numeric('1')
    # testing number lower than alphabet
    assert _Numeric('1') > _Alpha('a')
    # testing alphabet lower than number, which is greater than alphabet
    assert not _Alpha('a') < _Numeric('2')


# Generated at 2022-06-21 09:20:03.237282
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    n1 = _Numeric('11')
    n2 = _Numeric('22')
    n3 = _Numeric('11')

    assert n1 != n2
    assert not n1 != n3



# Generated at 2022-06-21 09:20:05.289358
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('b')
    b = _Alpha('a')
    c = _Alpha('a')

    assert a >= b
    assert b >= c

    b = 'a'
    assert a >= b
    assert b >= c



# Generated at 2022-06-21 09:20:07.769535
# Unit test for constructor of class _Numeric
def test__Numeric():
    nums = [1, 1.0, '1', '1.0']
    for num in nums:
        assert _Numeric(num).specifier == 1, '_Numeric.specifier is {} and not 1'.format(_Numeric(num).specifier)


# Generated at 2022-06-21 09:20:10.432936
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('1.0')
    b = _Alpha('2.0')
    c = _Alpha('1.0')
    assert a != b
    assert not a != c
    assert a != '1.0'
    assert not a != 1
    assert not a != 1.0


# Generated at 2022-06-21 09:21:00.512776
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Alpha('2')
    assert _Numeric(1) <= '2'

    assert not _Numeric(1) <= 0
    assert not _Numeric(1) <= _Numeric(0)
    assert not _Numeric(1) <= _Alpha('0')
    assert not _Numeric(1) <= '0'

    assert not _Numeric(1) <= _Alpha('1')
    assert not _Numeric(1) <= '1'


# Generated at 2022-06-21 09:21:02.702450
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    version1 = SemanticVersion('1.1.1')
    version2 = SemanticVersion('1.1.1')
    assert not version1.__ne__(version2)


# Generated at 2022-06-21 09:21:08.255125
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    # Test when comparing two _Alpha objects
    a1 = _Alpha("a")
    a2 = _Alpha("a")
    assert a1 == a2

    a1 = _Alpha("a")
    a2 = _Alpha("b")
    assert a1 != a2

    # Test when comparing one _Alpha object to a string
    a1 = _Alpha("a")
    a2 = "b"
    assert a1 != a2

    a1 = _Alpha("a")
    a2 = "a"
    assert a1 == a2



# Generated at 2022-06-21 09:21:13.671332
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < 2
    assert 1 < _Numeric(2)
    assert _Numeric(1) < _Alpha('2')
    try:
        assert _Numeric(1) < '2'
    except ValueError:
        pass



# Generated at 2022-06-21 09:21:19.059089
# Unit test for constructor of class _Alpha
def test__Alpha():
    # Test properties of _Alpha instances
    A0 = _Alpha('a')
    assert A0.specifier == 'a'
    assert A0.specifier == 'a'
    assert A0 == 'a'
    assert A0 == _Alpha('a')
    assert A0 != _Alpha('b')
    assert A0 != 'b'
    assert A0 < 'b'
    assert A0 < 'a1'
    assert A0 < 'a0'
    assert A0 <= 'a'
    assert A0 <= 'b'
    assert A0 <= 'a1'
    assert A0 > 'a0'
    assert A0 > '0a'
    assert A0 >= 'a'
    assert A0 >= 'a0'
    assert A0 >= '0a'
    assert A0 != 1

# Generated at 2022-06-21 09:21:21.787709
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == _Numeric('1')
    assert _Numeric('1') != _Numeric('2')


# Generated at 2022-06-21 09:21:29.989892
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    # Test 2 different version objects
    version_1 = SemanticVersion('1.0.0')
    version_2 = SemanticVersion('1.0.1')
    assert version_1 != version_2

    # Test 2 equal version objects
    version_3 = SemanticVersion('1.0.0')
    assert version_1 == version_3

    # Test string is not equal
    assert version_1 != '1.0.0'

    # Test comparison to another version is not equal
    version_4 = LooseVersion('1.0.0')
    assert version_1 != version_4


# Generated at 2022-06-21 09:21:33.680104
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    # Test with valid value
    semver = SemanticVersion('1.2.3')

    assert semver.__repr__() == 'SemanticVersion(\'1.2.3\')'

    # Test with invalid value
    semver = SemanticVersion('asdf')

    assert semver.__repr__() == 'SemanticVersion(\'asdf\')'


# Generated at 2022-06-21 09:21:44.463296
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    # Test case 1: 1 > 2
    result = _Numeric(1) > _Numeric(2)
    if result:
        print("Test case 1: fail")
    else:
        print("Test case 1: pass")

    # Test case 2: 1 > 0, 1 is greater than 0
    result = _Numeric(1) > _Numeric(0)
    if result:
        print("Test case 2: pass")
    else:
        print("Test case 2: fail")

    # Test case 3: 1>1
    result = _Numeric(1) > _Numeric(1)
    if result:
        print("Test case 3: fail")
    else:
        print("Test case 3: pass")



# Generated at 2022-06-21 09:21:54.222364
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    check_ = _Alpha("2")
    other = _Alpha("1")
    assert check_.__ge__(other) == True
    assert check_.__ge__(text_type("1")) == True
    assert check_.__ge__(1) == False
    check_ = _Alpha("1")
    other = _Alpha("2")
    assert check_.__ge__(other) == False
    assert check_.__ge__(text_type("1")) == False
    assert check_.__ge__(2) == False
    check_ = _Alpha("1")
    other = _Alpha("1")
    assert check_.__ge__(other) == True
    assert check_.__ge__(text_type("1")) == True
    assert check_.__ge__(1) == False
    check_ = _Alpha("1.2.3")

# Generated at 2022-06-21 09:23:13.232061
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    obj = _Alpha("foo")
    assert obj.__repr__() == "'foo'"


# Generated at 2022-06-21 09:23:22.575828
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    import unittest

    # Use the unittest library to define a test suite
    class _Numeric___ge___TestCase(unittest.TestCase):
        def test__Numeric___ge___1(self):
            version1 = _Numeric('1')
            version2 = _Numeric('1')
            assert version1 == version2

        def test__Numeric___ge___2(self):
            version1 = _Numeric('1')
            version2 = _Numeric('2')
            assert version1 < version2

        def test__Numeric___ge___3(self):
            version1 = _Numeric('2')
            version2 = _Numeric('1')
            assert version1 > version2

    # Use the unittest library to define a test suite
    suite = unittest.TestLoader().loadTestsFrom

# Generated at 2022-06-21 09:23:27.785364
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test method from_loose_version of class SemanticVersion
    """
    from ansible.module_utils.compat.version import LooseVersion
    vstring = '2.2.0-alpha-1.1+abc'
    v1 = SemanticVersion(vstring)
    v2 = SemanticVersion.from_loose_version(LooseVersion(vstring))
    assert v1._cmp(v2) == 0


# Generated at 2022-06-21 09:23:35.014342
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion('1.2.3') < SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') < SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.4')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.3.0')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3-alpha')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion('1.2.3') < SemanticVersion('1.2.3-alpha.7')

# Generated at 2022-06-21 09:23:36.525947
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric('1') == _Numeric(1)
    assert _Numeric(1) == _Numeric('1')


# Generated at 2022-06-21 09:23:45.037021
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # try to compare SemanticVersion with itself, should return True
    assert(SemanticVersion('0.0.1') == SemanticVersion('0.0.1'))

    # try to compare SemanticVersion with another version
    assert(SemanticVersion('1.2.3') != SemanticVersion('2.3.4'))
    assert(SemanticVersion('1.2.3') != SemanticVersion('1.3.4'))
    assert(SemanticVersion('1.2.3') != SemanticVersion('1.2.4'))

    # example from semver.org
    # 1.0.0-alpha < 1.0.0-alpha.1 < 1.0.0-alpha.beta < 1.0.0-beta < 1.0.0-beta.2 < 1.0.0-beta.11 < 1

# Generated at 2022-06-21 09:23:52.278177
# Unit test for constructor of class _Numeric
def test__Numeric():
    numeric = _Numeric('1')
    assert numeric.specifier == 1
    numeric = _Numeric('23')
    assert numeric.specifier == 23

    try:
        numeric = _Numeric('not_numeric')
        assert False, 'Accepted "not_numeric"'
    except ValueError:
        pass
    except Exception:
        assert False, 'Received different exception than expected'


# Generated at 2022-06-21 09:23:54.111943
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert False, "No test defined for method __lt__ of class _Numeric"


# Generated at 2022-06-21 09:23:55.874534
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    from samsorter._version import _Numeric
    assert repr(_Numeric(1)) == '1'


# Generated at 2022-06-21 09:24:02.000955
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    test_case = [
        # test_values, expected
        ((_Numeric(4), _Numeric(4)), False),
        ((_Numeric(4), _Numeric(5)), True),
        ((_Numeric(4), _Alpha(4)), False),
    ]

    for (test_values, expected) in test_case:
        actual = test_values[0].__ne__(*test_values[1:])
        print_test_result(expected, actual, test_values)


# Generated at 2022-06-21 09:24:37.637659
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    s = '1.2.3'
    v = SemanticVersion(s)
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    s = '0.0.0'
    v = SemanticVersion(s)
    assert v.major == 0
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    s = '1.2.3-alpha.1'
    v = SemanticVersion(s)
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease[0] == _Alpha('alpha')
    assert v.pre

# Generated at 2022-06-21 09:24:41.065911
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('alpha') == _Alpha('alpha')
    assert _Alpha('alpha') == 'alpha'
    assert 'alpha' == _Alpha('alpha')
    assert _Alpha('alpha') != 'beta'
    assert 'beta' != _Alpha('alpha')


# Generated at 2022-06-21 09:24:42.643713
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert _Numeric(3).__repr__() == '3'


# Generated at 2022-06-21 09:24:47.552724
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(2) <= _Numeric(1) is False
    assert _Numeric(1) <= _Alpha('2')
    assert _Numeric(1) <= _Alpha('1')
    assert _Numeric(2) <= _Alpha('1') is False
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 1
    assert _Numeric(2) <= 1 is False


# Generated at 2022-06-21 09:24:50.574562
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    version = "1.0.0"
    v = SemanticVersion(version)
    assert v >= version == True
    assert v >= "0.1.0" == True
    assert v >= "1.0.1" == False
    assert v >= "2.0.0" == False
    assert v >= "1.0.1-beta" == False


# Generated at 2022-06-21 09:24:53.619639
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(0) >= _Numeric(0)
    assert _Numeric(0) >= _Alpha('0')
    assert not _Numeric(0) >= _Numeric(1)
    assert not _Numeric(0) >= _Alpha('1')
    assert not _Numeric(1) >= _Numeric(0)
    assert not _Numeric(1) >= _Alpha('0')
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) >= _Alpha('1')


# Generated at 2022-06-21 09:24:54.868912
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
	sv1 = SemanticVersion('2.4.0')
	sv2 = SemanticVersion('2.4.0')
	return sv1 <= sv2


# Generated at 2022-06-21 09:24:55.770326
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric("1") < _Numeric("2")


# Generated at 2022-06-21 09:24:56.864529
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    a = _Alpha('test')
    assert repr(a) == repr('test')



# Generated at 2022-06-21 09:24:59.170719
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    """Test the __ge__ method of _Numeric"""

    x = _Numeric(1)
    y = _Numeric(1)
    z = _Numeric(2)

    assert x.__ge__(y)
    assert y.__ge__(x)
    assert not y.__ge__(z)
    assert not x.__ge__(z)



# Generated at 2022-06-21 09:25:51.648717
# Unit test for constructor of class _Numeric
def test__Numeric():
    n = _Numeric(1)
    assert n.specifier == 1
    n = _Numeric('1')
    assert n.specifier == 1
    try:
        n = _Numeric('a')
    except ValueError:
        pass


# Generated at 2022-06-21 09:25:54.589172
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    v1 = _Numeric("1")
    v2 = _Numeric("2")
    assert v1 != v2, "v1 == v2"
    assert v2 != v1, "v2 == v1"


# Generated at 2022-06-21 09:26:02.998618
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    arbitrary_vstring = '1a2.3b4-5c6+7d8-9e0'

    # Test that expected arguments of the correct type are accepted
    assert SemanticVersion.from_loose_version(LooseVersion(arbitrary_vstring))

    # Test that expected arguments of an incorrect type raise an exception
    with pytest.raises(ValueError) as exception_info:
        SemanticVersion.from_loose_version(arbitrary_vstring)
    assert str(exception_info.value) == \
        "%r is not a LooseVersion" % arbitrary_vstring

    # Test that expected arguments with unexpected content raise an exception

# Generated at 2022-06-21 09:26:05.117062
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)


# Generated at 2022-06-21 09:26:07.030409
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.2.3') != SemanticVersion('1.2.4')


# Generated at 2022-06-21 09:26:08.658108
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(0) < _Numeric(1)



# Generated at 2022-06-21 09:26:17.845106
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != 'b'
    assert _Alpha('b') != _Alpha('a')
    assert _Alpha('b') == 'b'
    assert _Alpha('a') < 'b'
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') > 'a'
    assert _Alpha('a') > _Alpha('a')
    assert _Alpha('a') > 'A'
    assert _Alpha('a') < 'A'
    assert _Alpha('a') >= 'A'
    assert _Alpha('a') <= 'A'


# Generated at 2022-06-21 09:26:22.130464
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    try:
        SemanticVersion('')
    except Exception as e:
        assert 'invalid semantic version' in text_type(e)

    try:
        SemanticVersion('1,2,3')
    except Exception as e:
        assert 'invalid semantic version' in text_type(e)


# Generated at 2022-06-21 09:26:26.962157
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    numeric_one = _Numeric(1)
    numeric_two = _Numeric(2)

    assert numeric_one <= numeric_two
    assert numeric_one >= numeric_one
    assert numeric_one >= _Alpha('1')
    assert numeric_one >= 1
    assert not numeric_one >= numeric_two


# Generated at 2022-06-21 09:26:30.616722
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    x = _Numeric(3)
    y = _Numeric(3)
    z = _Numeric(5)
    assert x.__eq__(y) is True
    assert x.__eq__(z) is False

