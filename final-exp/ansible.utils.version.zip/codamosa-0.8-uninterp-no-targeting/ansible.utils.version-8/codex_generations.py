

# Generated at 2022-06-21 09:17:05.846638
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    test_SemanticVersion_from_loose_version
    """
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3-4'))
    assert version.vstring == "1.2.3-4"
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.is_prerelease
    assert not version.is_stable

    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert version.vstring == "1.2.3"
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert not version.is_prerelease
    assert version.is_stable


# Generated at 2022-06-21 09:17:17.057480
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha('foo') == 'foo'
    assert _Alpha('foo') == _Alpha('foo')
    assert _Alpha('foo') != 'bar'
    assert _Alpha('foo') != _Alpha('bar')
    assert _Alpha('1.2.3') == '1.2.3'

# Generated at 2022-06-21 09:17:27.176094
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    sv = SemanticVersion()

    with_build_metadata = '1.2.3-beta+abc123'
    sv.parse(with_build_metadata)
    assert sv.vstring == with_build_metadata
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == (_Alpha('beta'),)
    assert sv.buildmetadata == (_Alpha('abc123'),)

    sv.parse('1.2.3-beta-abc123')
    assert sv.prerelease == (_Alpha('beta'), _Alpha('abc123'))

    sv.parse('1.2.3-beta.abc123')
    assert sv.prerelease == (_Alpha('beta'), _Alpha('abc123'))

    sv.parse('1.2.3-1234.5678')


# Generated at 2022-06-21 09:17:34.347500
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v1 = SemanticVersion(vstring='1.0.0')
    assert v1.__repr__() == "SemanticVersion('1.0.0')"

    v2 = SemanticVersion(vstring='1.0.0-alpha')
    assert v2.__repr__() == "SemanticVersion('1.0.0-alpha')"

    v3 = SemanticVersion(vstring='1.0.0-1.alpha')
    assert v3.__repr__() == "SemanticVersion('1.0.0-1.alpha')"


# Generated at 2022-06-21 09:17:36.617857
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion()
    ans = version.__repr__()
    assert ans == 'SemanticVersion(None)'



# Generated at 2022-06-21 09:17:39.856501
# Unit test for method __ne__ of class _Alpha

# Generated at 2022-06-21 09:17:49.946291
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert not SemanticVersion('1.2.3') >= SemanticVersion('2.2.3')
    assert SemanticVersion('2.2.3') >= SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') >= SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') >= '1.2.3'

    assert not SemanticVersion('1.2.3-beta.3') >= SemanticVersion('1.2.3-beta.4')
    assert not SemanticVersion('1.2.3-beta.3') >= SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3-beta.4') >= SemanticVersion('1.2.3-beta.3')

# Generated at 2022-06-21 09:17:55.393494
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)

    assert n1 == n1  # Equal
    assert n2 == n2  # Equal
    assert n1 != n2  # Not equal
    assert not n1 == n2  # Not equal
    assert not n2 == n1  # Not equal
    assert not _Numeric(1) == 'foo' # Not equal
    assert _Numeric(1) == 1  # Equal
    assert 1 == _Numeric(1)  # Equal
    assert not 1 == _Numeric(2)  # Not equal
    assert not _Numeric(1) == 2  # Not equal


# Generated at 2022-06-21 09:17:58.937829
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) == 1
    assert _Numeric(1) != 2


# Generated at 2022-06-21 09:18:08.616510
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric("1") == 1
    assert _Numeric("1") == _Numeric("1")
    assert _Numeric("1") != "1"
    assert _Numeric("1") != _Numeric("2")
    assert _Numeric("2") != "1"
    assert _Numeric("1") < _Numeric("2")
    assert _Numeric("1") <= _Numeric("2")
    assert _Numeric("1") <= _Numeric("1")
    assert _Numeric("2") > _Numeric("1")
    assert _Numeric("2") >= _Numeric("1")
    assert _Numeric("1") >= _Numeric("1")
    assert _Numeric("1") <= _Alpha("1")


# Generated at 2022-06-21 09:18:26.877166
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    x = _Numeric("1")
    y = _Numeric("1")
    assert x == y, "'x' must be equal to 'y'"
    y = _Numeric("3")
    assert x != y, "'x' must not be equal to 'y'"
    y = "1"
    assert x == y, "'x' must be equal to 'y'"
    y = "3"
    assert x != y, "'x' must not be equal to 'y'"
    y = 3
    assert x == y, "'x' must be equal to 'y'"
    y = 5
    assert x != y, "'x' must not be equal to 'y'"

# Unit tests for method __lt__ of class _Numeric

# Generated at 2022-06-21 09:18:30.129644
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'


# Generated at 2022-06-21 09:18:39.238171
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('0.0.1') > SemanticVersion('0.0.0')  # basic ascending
    assert SemanticVersion('0.0.1') > SemanticVersion('0.0.1-1')  # basic prerelease
    assert SemanticVersion('0.0.1') > SemanticVersion('0.0.1-0')  # basic prerelease
    assert SemanticVersion('0.0.1-0') > SemanticVersion('0.0.1-0-0')  # basic prerelease
    assert SemanticVersion('0.0.1-alpha') > SemanticVersion('0.0.1-0-0')  # basic prerelease
    assert not SemanticVersion('0.0.1-alpha') > SemanticVersion('0.0.1-alpha')  # basic prerelease
    assert not Semantic

# Generated at 2022-06-21 09:18:43.588064
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion("1.2.3-a.b.c+1.2.3")) == "SemanticVersion('1.2.3-a.b.c+1.2.3')"



# Generated at 2022-06-21 09:18:46.046589
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('a')) == "'a'"
    assert repr(_Alpha('abc')) == "'abc'"
    assert repr(_Alpha(10)) == "'10'"


# Generated at 2022-06-21 09:18:48.041104
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__(): return _Alpha('0.3.2') <= '0.3.2'

# Generated at 2022-06-21 09:18:50.821136
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    alpha1 = _Alpha('a')
    alpha2 = _Alpha('a')
    assert alpha1 == alpha2

    alpha3 = _Alpha('b')
    assert alpha1 != alpha3


# Generated at 2022-06-21 09:18:57.651188
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(0) < _Numeric(1)
    assert _Numeric(1) > 0
    assert _Numeric(0) < 1

    # Although this test fails for LooseVersion
    # LooseVersion does not handle prerelease versions
    # LooseVersion is also not a drop in replacement for distutils.version.Version
    assert SemanticVersion('1.0.0-alpha') < SemanticVersion('1.0.0')


# Generated at 2022-06-21 09:19:04.534592
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    x = _Numeric(0)
    y = _Numeric(0)
    assert x <= y  # Equal is less than or equal
    x = _Numeric(1)
    y = _Numeric(0)
    assert x > y  # Greater
    x = _Numeric(0)
    y = _Numeric(1)
    assert x < y  # Less than


# Generated at 2022-06-21 09:19:07.094448
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('alpha') <= 'alpha'
    assert _Alpha('alpha') <= 'beta'
    assert not _Alpha('alpha') <= 'A'


# Generated at 2022-06-21 09:19:17.924101
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Alpha('a1')
    assert _Alpha('a') < _Alpha('aA')
    assert not _Alpha('a') < _Alpha('a')
    assert not _Alpha('a1') < _Alpha('a')


# Generated at 2022-06-21 09:19:29.557344
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():

    def test(self, version_string, expected_value, version_string2=None):
        print("Testing __lt__: {0}, {1}, {2}".format(self, version_string, version_string2))
        version = SemanticVersion(version_string)
        assert self.__lt__(version) == expected_value
        if version_string2 is not None:
            assert self.__lt__(SemanticVersion(version_string2)) == expected_value

    test(SemanticVersion("1.2.3"), False, "2.1.2")
    test(SemanticVersion("1.0.0a"), True, "1.0.0")
    test(SemanticVersion("1.0.0-rc.1"), True, "1.0.0")

# Generated at 2022-06-21 09:19:30.924687
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != 1


# Generated at 2022-06-21 09:19:36.761578
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('1') != _Numeric('2')
    assert _Numeric('1') != int('2')
    assert _Numeric('1') != '2'
    assert _Numeric('1') != _Alpha('2')
    assert int('1') != _Numeric('2')
    assert '1' != _Numeric('2')
    assert _Alpha('1') != _Numeric('2')


# Generated at 2022-06-21 09:19:40.393805
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
   """
   Args:
      string used to initialize the _Alpha object

   Returns:
      expected result
   """
   assert _Alpha("alpha").__repr__() == "'alpha'"


# Generated at 2022-06-21 09:19:44.201040
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')

    # Input will be converted to _Alpha
    assert _Alpha('a') < 'b'


# Generated at 2022-06-21 09:19:49.771775
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > _Numeric(0)
    assert _Alpha('a') > _Alpha('a')
    #assert _Alpha('a') > _Alpha('b')
    #assert _Alpha('') > _Alpha('b')
    assert _Alpha('') > _Numeric(0)
    assert _Alpha('a') > 'a'
    #assert _Alpha('a') > 'b'
    #assert _Alpha('') > 'b'


# Generated at 2022-06-21 09:19:53.531131
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    obj = SemanticVersion("1.0.0-alpha")

    actual_result = obj.__repr__()
    expected_result = "SemanticVersion('1.0.0-alpha')"

    assert (actual_result == expected_result)


# Generated at 2022-06-21 09:19:57.806492
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    res = _Alpha('1') <= text_type('1')
    res1 = _Alpha('1') <= _Numeric('1')
    res2 = _Alpha('1') <= 1
    res3 = _Alpha('1') <= _Alpha('1')
    assert res == res1 and res1 == res2 and res2 == res3


# Generated at 2022-06-21 09:20:04.832808
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():

    assert _Alpha(1) >= _Alpha(1) == True
    assert _Alpha(2) >= _Alpha(2) == True
    assert _Alpha(3) >= _Alpha(3) == True
    assert _Alpha(4) >= _Alpha(4) == True
    assert _Alpha(5) >= _Alpha(5) == True
    assert _Alpha('1') >= _Alpha('1') == True
    assert _Alpha('2') >= _Alpha('2') == True
    assert _Alpha('3') >= _Alpha('3') == True
    assert _Alpha('4') >= _Alpha('4') == True
    assert _Alpha('5') >= _Alpha('5') == True
    assert _Alpha(1) >= _Alpha(2) == False
    assert _Alpha(2) >= _Alpha(3) == False
    assert _Alpha(3)

# Generated at 2022-06-21 09:20:17.257245
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Test 31 of 39 for method __lt__
    assert _Alpha('a').__lt__(_Alpha('b')) is True
    # Test 32 of 39 for method __lt__
    assert not _Alpha('b').__lt__(_Alpha('a'))
    # Test 33 of 39 for method __lt__
    assert not _Alpha('a').__lt__(_Alpha('a'))
    # Test 34 of 39 for method __lt__
    assert _Alpha('a').__lt__('b') is True
    # Test 35 of 39 for method __lt__
    assert not _Alpha('b').__lt__('a')
    # Test 36 of 39 for method __lt__
    assert not _Alpha('a').__lt__('a')
    # Test 37 of 39 for method __lt__

# Generated at 2022-06-21 09:20:20.289090
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert not _Numeric(1) <= _Alpha(1)
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)


# Generated at 2022-06-21 09:20:26.021142
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('alpha')
    b = _Alpha('beta')
    assert a > b
    assert not b > a

    assert not a > 'alpha'
    assert 'beta' > a

    assert not a > 1
    assert not 1 > b

    assert not a > _Numeric('1')
    assert not _Numeric('2') > b


# Generated at 2022-06-21 09:20:29.482756
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == 1
    assert _Numeric(1) != 2
    assert _Numeric(1) != _Alpha(1)
    assert _Numeric(1) != _Numeric(2)


# Generated at 2022-06-21 09:20:32.637105
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    fst_numeric = _Numeric(42)
    snd_numeric = _Numeric(43)
    assert fst_numeric < snd_numeric


# Generated at 2022-06-21 09:20:35.707455
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha("a") > "a"
    assert not _Alpha("a") > "b"
    assert not _Alpha("b") > "a"
    assert _Alpha("b") > "a"
    assert not _Alpha("b") > 3



# Generated at 2022-06-21 09:20:42.949863
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():

    result = _Alpha('1') <= _Alpha('1')
    assert result == True
    result = _Alpha('1') <= _Alpha('2')
    assert result == True
    result = _Alpha('2') <= _Alpha('1')
    assert result == False
    result = _Alpha('1') <= '1'
    assert result == True
    result = _Alpha('1') <= '2'
    assert result == True
    result = _Alpha('2') <= '1'
    assert result == False
    result = _Alpha('1') <= 1
    assert result == False


# Generated at 2022-06-21 09:20:48.679809
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # Test case 1:
    a = _Alpha('alpha')
    b = _Alpha('bravo')
    assert not a >= b

    # Test case 2:
    a = _Alpha('bravo')
    b = _Alpha('bravo')
    assert a >= b

    # Test case 3:
    a = _Alpha('charlie')
    b = _Alpha('bravo')
    assert a >= b



# Generated at 2022-06-21 09:20:59.347416
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():

    a = _Numeric('1')
    b = _Numeric('2')
    assert a < b

    a = _Numeric('0')
    b = _Numeric('1')
    assert a < b

    a = _Numeric('0')
    b = _Numeric('0')
    assert not a < b

    a = _Numeric('1')
    b = _Numeric('0')
    assert not a < b

    a = _Numeric('1.0')
    b = _Numeric('1')
    assert not a < b

    a = _Numeric('1')
    b = _Numeric('1.0')
    assert a < b

    a = _Numeric('1.0')
    b = _Numeric('1')
    assert not a < b


# Generated at 2022-06-21 09:21:03.945068
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = '1.0.0'
    v2 = '2.0.0'
    lv1 = SemanticVersion(v1)
    lv2 = SemanticVersion(v2)

    assert lv1 < lv2
    assert lv1 <= lv2
    assert lv2 > lv1
    assert lv2 >= lv1

    assert not lv1 == lv2
    assert lv1 != lv2
    assert not lv2 == lv1
    assert lv2 != lv1

    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0')
    assert SemanticVersion('2.0.0') >= SemanticVersion('1.0.0')

# Generated at 2022-06-21 09:21:21.397598
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    import sys, traceback

    method = SemanticVersion.__lt__

    # Tests to be run:

# Generated at 2022-06-21 09:21:31.676612
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('1.2.3')
    assert v1 > '1.1.3'
    assert v1 > '1.1.3-beta'
    assert v1 > '1.2.2-beta'
    assert v1 > '1.2.2-beta+build.2'
    assert v1 > '1.2.2-beta+build.1-extra'
    assert v1 > '1.2.2'
    assert v1 > '1.2.2+build.1'
    assert v1 > '1.2.2+build.1-extra'
    assert v1 > '1.2.3'

    v2 = SemanticVersion('1.2.3-alpha.1')
    assert v2 > '1.2.3-alpha'

# Generated at 2022-06-21 09:21:36.296601
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(7) != 8
    assert not _Numeric(7) != 7
    assert not _Numeric(7) != '7'
    assert _Numeric(7) != _Alpha('7')
    assert _Numeric(7) != _Numeric(8)
    assert not _Numeric(7) != _Numeric(7)
    assert not _Numeric(7) != _Numeric('7')


# Generated at 2022-06-21 09:21:46.302303
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    ver = SemanticVersion('0.0.2')
    assert ver.major == 0
    assert ver.minor == 0
    assert ver.patch == 2
    assert ver.prerelease == ()
    assert ver.buildmetadata == ()
    ver = SemanticVersion('0.0.2-beta.1')
    assert ver.major == 0
    assert ver.minor == 0
    assert ver.patch == 2
    assert ver.prerelease == (0, 'beta', 1)
    assert ver.buildmetadata == ()
    ver = SemanticVersion('0.0.2+build.1')
    assert ver.major == 0
    assert ver.minor == 0
    assert ver.patch == 2
    assert ver.prerelease == ()
    assert ver.buildmetadata == ('build', 1)

# Generated at 2022-06-21 09:21:55.408167
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    from ansible.module_utils.six import PY3
    if PY3:
        import io
        import sys
        from io import StringIO
        sys.stdin = StringIO('foo')
    else:
        import StringIO
        import sys
        sys.stdin = StringIO.StringIO('foo')
    res = SemanticVersion('0.0.0')
    res = SemanticVersion('0.1.0')
    res = SemanticVersion('0.2.0')
    res = SemanticVersion('0.3.0')
    res = SemanticVersion('1.0.0-alpha')
    res = SemanticVersion('1.0.0-beta')
    res = SemanticVersion('1.0.0-rc.1')
    res = SemanticVersion('1.0.0')
    res

# Generated at 2022-06-21 09:21:57.494654
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    num1 = _Numeric('1.0.0')
    num2 = _Numeric('1.0.1')
    print(num2.__gt__(num1))


# Generated at 2022-06-21 09:22:08.641764
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion('42.42.42')
    assert version.major == 42
    assert version.minor == 42
    assert version.patch == 42
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version = SemanticVersion('42.42.42-alpha.1')
    assert version.major == 42
    assert version.minor == 42
    assert version.patch == 42
    assert version.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert version.buildmetadata == ()

    version = SemanticVersion('42.42.42-alpha.1+foo.bar')
    assert version.major == 42
    assert version.minor == 42
    assert version.patch == 42
    assert version.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert version

# Generated at 2022-06-21 09:22:11.114450
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('2.0.0')) == "SemanticVersion('2.0.0')"


# Generated at 2022-06-21 09:22:22.382051
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert str(SemanticVersion('0.9.9-alpha.1+001')) == '0.9.9-alpha.1+001'
    assert str(SemanticVersion('1.0.0-x.7.z.92')) == '1.0.0-x.7.z.92'
    assert str(SemanticVersion('1.0.0-alpha')) == '1.0.0-alpha'
    assert str(SemanticVersion('1.0.0-alpha.1')) == '1.0.0-alpha.1'
    assert str(SemanticVersion('1.0.0-alpha.beta')) == '1.0.0-alpha.beta'
    assert str(SemanticVersion('1.0.0-beta')) == '1.0.0-beta'
    assert str

# Generated at 2022-06-21 09:22:27.430190
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha('1.0.0') > _Alpha('1.0.0')
    assert not _Alpha('1') > _Alpha('1')
    assert not _Alpha('1') > _Alpha('1.0')
    assert not _Alpha('1') > _Alpha('01')
    assert not _Alpha('a') > _Alpha('a')
    assert not _Alpha('') > _Alpha('')
    assert not _Alpha('1.0.0') > '1.0.0'
    assert not _Alpha('1.0.0') > '1.0'
    assert not _Alpha('1.0') > '1.0'
    assert not _Alpha('1') > '1'
    assert not _Alpha('a') > 'a'
    assert not _Alpha('') > ''


# Generated at 2022-06-21 09:22:41.727627
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('4.0.0') > SemanticVersion('3.0.0')


# Generated at 2022-06-21 09:22:49.935667
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    import unittest

    if sys.version_info.major < 3:
        class TestSemanticVersionFromLooseVersion(unittest.TestCase):
            def test_version_str_all_ints(self):
                loose = LooseVersion("1.2.3")
                sver = SemanticVersion("1.2.3")
                self.assertEqual(sver, SemanticVersion.from_loose_version(loose))

            def test_str_version_w_decimals(self):
                loose = LooseVersion("1.2.3.4")
                sver = SemanticVersion("1.2.3")
                self.assertEqual(sver, SemanticVersion.from_loose_version(loose))

            def test_version_w_ints(self):
                loose

# Generated at 2022-06-21 09:22:52.979551
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    """Class to easily allow comparing strings

    Largely this exists to make comparing an integer and a string on py3
    so that it works like py2.
    """
    alpha = _Alpha(specifier='test')
    assert repr(alpha) == "'test'"


# Generated at 2022-06-21 09:23:02.646237
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test with same _Alpha
    assert not bool(_Alpha('z') <= _Alpha('z'))
    # Test with same str
    assert not bool(_Alpha('z') <= 'z')
    # Test with less _Alpha
    assert bool(_Alpha('a') <= _Alpha('z'))
    # Test with less str
    assert bool(_Alpha('a') <= 'z')
    # Test with greater _Alpha
    assert not bool(_Alpha('z') <= _Alpha('a'))
    # Test with greater str
    assert not bool(_Alpha('z') <= 'a')
    # Test with number
    assert isinstance(_Alpha('a') <= 1, NotImplemented)
