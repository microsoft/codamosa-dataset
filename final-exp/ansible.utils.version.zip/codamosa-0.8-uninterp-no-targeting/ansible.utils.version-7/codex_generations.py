

# Generated at 2022-06-21 09:17:07.008640
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    with open('tests/unit/module_utils/test_semantic_version.txt', 'r') as f:
        lines = f.readlines()

    for line in lines:
        try:
            (actual, expect) = line.strip().split(':')
            actual = SemanticVersion(actual)
            expect = SemanticVersion(expect)
            if actual >= expect:
                print('Passed SemanticVersion(%s) >= SemanticVersion(%s)' % (actual.vstring, expect.vstring))
            else:
                print('Failed SemanticVersion(%s) >= SemanticVersion(%s)' % (actual.vstring, expect.vstring))
        except:
            print('Failed to compare %s' % line.strip())



# Generated at 2022-06-21 09:17:17.608349
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('1') < _Alpha('2')
    assert _Alpha('2') > _Alpha('1')
    assert _Alpha('2') == _Alpha('2')
    assert _Alpha('2') >= _Alpha('2')
    assert _Alpha('2') <= _Alpha('2')

    # Make sure it also works with str
    assert _Alpha('1') < '2'
    assert _Alpha('2') > '1'
    assert _Alpha('2') == '2'

    # Make sure it also works with int
    assert _Alpha('2') > 1
    assert _Alpha('1') < 2
    assert not _Alpha('2') > '2'
    assert not _Alpha('2') == 2

    # Make sure it also works with _Numeric
    assert _Alpha('2') > _Numeric('2')

# Generated at 2022-06-21 09:17:24.785880
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert(_Numeric("5") < _Numeric("6"))
    assert(not _Numeric("5") < _Numeric("5"))
    assert(not _Numeric("6") < _Numeric("5"))
    with pytest.raises(ValueError):
        _Numeric("5") < _Alpha("6")
    assert(not _Numeric("5") < _Alpha("5"))
    with pytest.raises(ValueError):
        _Numeric("6") < _Alpha("5")


# Generated at 2022-06-21 09:17:29.168810
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # Test if method __ge__ of class SemanticVersion
    # raises ValueError when underscore of __ge__ is removed

    sv1 = SemanticVersion("0.0.1")
    sv2 = SemanticVersion("0.1.0")

    # Function assert_raises checks if function calls raise the exception
    from nose.tools import assert_raises

    # assert_raises checks if function calls raise the exception
    assert_raises(ValueError, sv1.__ge__, sv2)
    assert sv1 >= sv2

# Generated at 2022-06-21 09:17:34.432020
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    input_version = LooseVersion("2.4.0.dev1")
    expected_version = "2.4.0-dev1"
    actual_version = SemanticVersion.from_loose_version(input_version)
    assert str(actual_version) == expected_version



# Generated at 2022-06-21 09:17:44.598342
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha("a")
    b = _Alpha("b")
    c = _Alpha("c")
    x = _Alpha("x")
    y = _Alpha("y")
    z = _Alpha("z")
    zero = _Alpha("0")
    one = _Alpha("1")
    two = _Alpha("2")
    A = _Alpha("A")
    B = _Alpha("B")
    C = _Alpha("C")
    X = _Alpha("X")
    Y = _Alpha("Y")
    Z = _Alpha("Z")
    dash = _Alpha("-")
    _0 = _Alpha("0")
    _1 = _Alpha("1")
    _2 = _Alpha("2")

    assert a < b
    assert a < c
    assert a < x
    assert a < y
   

# Generated at 2022-06-21 09:17:46.397425
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion("1") != "2"
    assert "2" != SemanticVersion("1")


# Generated at 2022-06-21 09:17:48.715780
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    classa = _Alpha("")
    assert classa.specifier == ""
    assert repr(classa) == repr("")


# Generated at 2022-06-21 09:17:51.772054
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert not _Alpha('a') > _Alpha('a')
    assert not _Alpha('a') > _Alpha('b')
    assert not _Alpha('b') > _Alpha('a')
    assert _Alpha('b') > _Alpha('a')


# Generated at 2022-06-21 09:18:00.994965
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    def _test__Alpha___lt__(self):
        a = _Alpha(self)
        b = _Alpha(other)
        return text_type(a) + ' < ' + text_type(b) + '\t' + text_type(a < b)
    for self in range(10):
        for other in range(10):
            print(_test__Alpha___lt__(self, other))
    for self in range(10):
        for other in 'abc':
            print(_test__Alpha___lt__(self, other))
    for self in 'abc':
        for other in range(10):
            print(_test__Alpha___lt__(self, other))
    for self in 'abc':
        for other in 'abc':
            print(_test__Alpha___lt__(self, other))


# Generated at 2022-06-21 09:18:10.999438
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.2.3') != '1.2.3'


# Generated at 2022-06-21 09:18:13.723960
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('a') > _Alpha('aa')
    assert _Alpha('aa') > _Alpha('b')
    assert not _Alpha('b') > _Alpha('b')
    assert not _Alpha('a') > _Alpha('b')


# Generated at 2022-06-21 09:18:25.846239
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('1.0.0')
    assert v1 == v2
    v1 = SemanticVersion('1.0.0+abc')
    v2 = SemanticVersion('1.0.0+bcd')
    assert v1 == v2
    v1 = SemanticVersion('1.0.0-alpha')
    v2 = SemanticVersion('1.0.0-alpha')
    assert v1 == v2
    v1 = SemanticVersion('1.0.0-alpha')
    v2 = SemanticVersion('1.0.0-beta')
    assert not v1 == v2
    v1 = SemanticVersion('1.0.1')
    v2 = SemanticVersion('1.1.0')

# Generated at 2022-06-21 09:18:27.615532
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion('2.0.0') is not None


# Generated at 2022-06-21 09:18:30.346243
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    lt = _Numeric('1') < _Numeric('2')
    assert lt == True
    ge = _Numeric('1') >= _Numeric('2')
    assert ge == False



# Generated at 2022-06-21 09:18:38.183889
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    # _Numeric.__ne__ should return the logical negation of _Numeric.__eq__

    # Check that the negation of __eq__ returns True when the two sides are equal
    assert (_Numeric('one_a') != _Numeric('one_a')) == (not (_Numeric('one_a') == _Numeric('one_a')))

    # Check that the negation of __eq__ returns False when the two sides are not equal
    assert (_Numeric('one_a') != _Numeric('one_b')) == (not (_Numeric('one_a') == _Numeric('one_b')))


# Generated at 2022-06-21 09:18:39.965527
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha("a") == "a"

# Generated at 2022-06-21 09:18:45.752650
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('1') <= _Numeric('1')
    assert _Numeric('1') <= _Numeric('2')
    assert not _Numeric('2') <= _Numeric('1')

    assert _Numeric('1') <= 1
    assert _Numeric('1') <= 2
    assert not _Numeric('2') <= 1


# Generated at 2022-06-21 09:18:49.881468
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion().parse("1.2.3-alpha.1.2+5.sha.5114f85") == (
        1, 2, 3, ("alpha", 1, 2), ("5", "sha", "5114f85"))


# Generated at 2022-06-21 09:18:52.971728
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('123') != _Numeric('123')
    assert _Numeric(123) != _Numeric(123)
    assert _Numeric(123) != 123



# Generated at 2022-06-21 09:19:08.767210
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    lhs = SemanticVersion('0.0.0')
    rhs = SemanticVersion('0.0.0')
    assert not (lhs == rhs)
    lhs = SemanticVersion('0.0.0+foo')
    assert not (lhs == rhs)
    rhs = SemanticVersion('0.0.0+foo')
    assert (lhs == rhs)
    lhs = SemanticVersion('0.0.1')
    assert not (lhs == rhs)
    rhs = SemanticVersion('0.0.1')
    assert (lhs == rhs)
    lhs = SemanticVersion('0.0.0-alpha')
    assert not (lhs == rhs)
    rhs = SemanticVersion('0.0.0-alpha')

# Generated at 2022-06-21 09:19:10.670579
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    sv1 = SemanticVersion("1.0.0")
    sv2 = SemanticVersion("1.0.0")
    assert sv1 == sv2


# Generated at 2022-06-21 09:19:21.582178
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert not SemanticVersion('') != ''
    assert not SemanticVersion('1.0.0') != '1.0.0'
    assert not SemanticVersion('1.0.0') != Version('1.0.0')
    assert not SemanticVersion('1.0.0') != LooseVersion('1.0.0')
    assert not SemanticVersion('1.0.0-alpha') != '1.0.0-alpha'
    assert not SemanticVersion('1.0.0+20190101') != '1.0.0+20190101'
    assert not SemanticVersion('1.0.0-alpha.4+20190101') != '1.0.0-alpha.4+20190101'


# Generated at 2022-06-21 09:19:24.822515
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(2) >= _Numeric(2)
    assert not _Numeric(2) >= _Numeric(3)
    assert _Numeric(3) >= _Numeric(2)


# Generated at 2022-06-21 09:19:36.185792
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion("1.2.3")
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion("12.2.3")
    assert v.major == 12
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion("12.2.3-beta1.4")
    assert v.major == 12
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == (_Numeric(4), _Alpha('beta1'))
    assert v.buildmetadata == ()


# Generated at 2022-06-21 09:19:47.924907
# Unit test for constructor of class _Alpha
def test__Alpha():
    '''

    Compares an _Alpha object to a string, and ensures that the
    comparison yields the expected result.

    '''
    assert _Alpha('1.2.3.4') == '1.2.3.4'
    assert _Alpha('1.2.3.4a') == '1.2.3.4a'
    assert _Alpha('1.2.3.4a') != '1.2.3.4b'
    assert _Alpha('1.2.3.4a') < '1.2.3.4b'
    assert _Alpha('1.2.3.4b') > '1.2.3.4a'
    assert _Alpha('1.2.3.4') > '1.2.3.4a'
    assert _Alpha('1.2.3.4a')

# Generated at 2022-06-21 09:19:53.686727
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    # _Numeric is greater than _Alpha
    assert _Numeric('9') != _Alpha('a')
    assert _Alpha('a') != _Numeric('9')
    # is greater than variable
    assert _Alpha('a') != '9'
    assert '9' != _Alpha('a')
    # is greater than string
    assert _Alpha('a') != '10'
    assert '10' != _Alpha('a')



# Generated at 2022-06-21 09:20:02.138705
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('0.0.0') < SemanticVersion('0.0.1')
    assert SemanticVersion('0.0.0') < SemanticVersion('0.1.0')
    assert SemanticVersion('0.0.0') < SemanticVersion('1.0.0')
    assert SemanticVersion('0.0.0-alpha') < SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0-alpha') < SemanticVersion('0.0.0-alpha.1')
    assert SemanticVersion('0.0.0-alpha.1') < SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0-alpha.1') < SemanticVersion('0.0.0-alpha.2')

# Generated at 2022-06-21 09:20:08.593514
# Unit test for constructor of class _Alpha
def test__Alpha():
    assert _Alpha("1") == "1"
    assert _Alpha("1") == _Alpha("1")
    assert _Alpha("1") != "2"
    assert _Alpha("1") != _Alpha("2")
    assert _Alpha("1") < "2"
    assert _Alpha("1") < _Alpha("2")
    assert _Alpha("1") <= "2"
    assert _Alpha("1") <= _Alpha("2")
    assert _Alpha("1") <= "1"
    assert _Alpha("1") <= _Alpha("1")
    assert _Alpha("1") > "0"
    assert _Alpha("1") > _Alpha("0")
    assert _Alpha("1") >= "0"
    assert _Alpha("1") >= _Alpha("0")
    assert _Alpha("1") >= "1"

# Generated at 2022-06-21 09:20:10.044500
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    with pytest.raises(ValueError):
        SemanticVersion('1.0.0') < '1.0.0'


# Generated at 2022-06-21 09:20:29.730766
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(0) < _Numeric(1)

    assert _Numeric(1) < 2
    assert _Numeric(0) < 1

    assert not _Numeric(1) < _Numeric(0)
    assert not _Numeric(2) < _Numeric(1)

    assert not _Numeric(1) < 0
    assert not _Numeric(2) < 1

    assert not _Numeric(0) < _Numeric(0)
    assert not _Numeric(1) < _Numeric(1)

    assert not _Numeric(0) < 0
    assert not _Numeric(1) < 1


# Generated at 2022-06-21 09:20:35.529993
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric('1') == 1
    assert _Numeric('12') == 12
    assert _Numeric('123') == 123
    assert _Numeric('1').specifier == 1
    assert _Numeric('12').specifier == 12
    assert _Numeric('123').specifier == 123
    assert int(_Numeric('1')) == 1
    assert int(_Numeric('12')) == 12
    assert int(_Numeric('123')) == 123

# Generated at 2022-06-21 09:20:37.113941
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1) == 1
    assert _Numeric(2) != 1


# Generated at 2022-06-21 09:20:47.692871
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    """Unit test for method __eq__ of class _Alpha"""
    assert _Alpha('a') == 'a'
    assert _Alpha('b') == 'b'
    assert _Alpha('0') == '0'
    assert _Alpha('1') == '1'

    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('b') == _Alpha('b')
    assert _Alpha('0') == _Alpha('0')
    assert _Alpha('1') == _Alpha('1')

    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('b') != _Alpha('a')
    assert _Alpha('0') != _Alpha('1')
    assert _Alpha('1') != _Alpha('0')

    assert _Alpha('z') != _Alpha('a')
    assert _Alpha('a') != _Alpha

# Generated at 2022-06-21 09:20:52.367979
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    # Check for non-equality for non-equal numeric argument
    assert _Numeric(1) != _Numeric(2)

    # Check for non-equality for equal non-numeric argument
    assert _Numeric(1) != _Alpha(1)

    # Check for non-equality for equal numeric argument
    assert not (_Numeric(1) != _Numeric(1))


# Generated at 2022-06-21 09:20:56.895812
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= _Numeric(1)
    assert not _Numeric(1) >= 2
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= _Alpha('1')



# Generated at 2022-06-21 09:21:05.217796
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    a = SemanticVersion("1.4.4")
    b = SemanticVersion("1.4.4-rc1")
    c = SemanticVersion("1.4.4-rc2")
    d = SemanticVersion("1.4.5")
    e = SemanticVersion("1.5.0")
    f = SemanticVersion("2.0.0")
    # Test with.
    assert(a >= a)
    assert(a >= b)
    assert(a >= c)
    assert(a >= d)
    assert(a >= e)
    assert(a >= f)
    assert(b >= a)
    assert(b >= b)
    assert(b >= c)
    assert(b >= d)
    assert(b >= e)
    assert(b >= f)
    assert(c >= a)

# Generated at 2022-06-21 09:21:06.719531
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('0.0.1-alpha') < SemanticVersion('0.0.1-alpha')

# Generated at 2022-06-21 09:21:10.197486
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric('0') > _Numeric('0')
    assert _Numeric('0') < _Numeric('1')
    assert _Numeric('1') > _Numeric('0')
    assert _Numeric('0') == _Numeric('0')


# Generated at 2022-06-21 09:21:14.783129
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha('a').__ne__('a')
    assert _Alpha('a').__ne__('b')
    assert not _Alpha('a').__ne__(_Alpha('a'))
    assert _Alpha('a').__ne__(_Alpha('b'))


# Generated at 2022-06-21 09:21:52.431945
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    obj1 = _Numeric(1)
    obj2 = _Numeric(2)
    obj3 = obj1
    obj4 = 1
    obj5 = 4
    obj6 = _Numeric(1)

    # Test equal
    assert (obj1 == obj3) is True
    assert (obj1 == obj4) is True
    assert (obj1 == obj6) is True

    # Test not equal
    assert (obj1 == obj2) is False
    assert (obj1 == obj5) is False



# Generated at 2022-06-21 09:21:58.757429
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    num1 = _Numeric('123')
    num2 = _Numeric('123')
    num3 = _Numeric('456')
    num4 = _Numeric('456')

    assert num1 == num2
    assert num2 == num1
    assert not num1 == num3
    assert num3 == num4
    assert num4 == num3
    assert num4 == 456
    assert num4 == 456
    assert 456 == num4

    # Test if the wrong type is compared
    try:
        assert num1 == '123'
    except AssertionError:
        pass
    else:
        raise AssertionError

    assert not num1 == '123'


# Generated at 2022-06-21 09:22:01.024683
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    a=_Numeric(1)
    b=_Numeric(2)
    assert a<=a
    assert a<b
    assert not b<=a


# Generated at 2022-06-21 09:22:11.494019
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    s = SemanticVersion('1.0.0')
    assert s >= '1.0.0'
    assert s >= '0.0.1'
    assert s >= '0.1.0'
    assert s >= '1.0.0-alpha'
    assert s >= '1.0.0-alpha.1'
    assert s >= '1.0.0-0.3.7'
    assert s >= '1.0.0-x.7.z.92'
    assert s >= '1.0.0-alpha.beta'
    assert s >= '1.0.0+0.0.0'
    assert s >= '1.0.0+exp.sha.5114f85'


# Generated at 2022-06-21 09:22:13.444002
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(10)) == '10'



# Generated at 2022-06-21 09:22:15.504458
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.0.0-alpha') >= SemanticVersion('1.0.0')


# Generated at 2022-06-21 09:22:22.423405
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    # Test comparing an int and an _Numeric
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(2) >= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(1) == _Numeric(1)


# Generated at 2022-06-21 09:22:26.316615
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(0) == _Numeric(0)
    assert _Numeric(0) == 0
    assert 0 == _Numeric(0)
    assert _Numeric(0) != _Numeric(1)
    assert _Numeric(0) != 1
    assert 1 != _Numeric(0)


# Generated at 2022-06-21 09:22:32.619027
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    # Test case for vstring that is less than other
    vstring = '1.0.0'
    other = '1.1.0'
    semver = SemanticVersion(vstring)
    other_semver = SemanticVersion(other)
    assert semver.__lt__(other_semver)

    # Test case for vstring that is greater than other
    vstring = '1.1.0'
    other = '1.0.0'
    semver = SemanticVersion(vstring)
    other_semver = SemanticVersion(other)
    assert semver.__lt__(other_semver) is False

    # Test case for vstring that is equal to other
    vstring = '1.0.0'
    other = '1.0.0'

# Generated at 2022-06-21 09:22:34.874405
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert "'test'" == repr(_Alpha('test'))


# Generated at 2022-06-21 09:22:56.217382
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert False == _Alpha('a') >= 'b'
    assert False == _Alpha('a') >= '0'
    assert False == _Alpha('a') >= _Numeric('1')
    assert False == _Alpha('a') >= _Alpha('b')
    assert True == _Alpha('a') >= 'a'
    assert True == _Alpha('a') >= _Alpha('a')


# Generated at 2022-06-21 09:23:00.897612
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(1) >= 1
    assert _Numeric(1) >= _Numeric(1)
    assert not _Numeric(1) >= 2
    assert not _Numeric(1) >= _Numeric(2)
    assert not _Numeric(1) >= _Alpha(1)


# Generated at 2022-06-21 09:23:08.394390
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"
    assert repr(SemanticVersion('1.2.3-alpha')) == "SemanticVersion('1.2.3-alpha')"
    assert repr(SemanticVersion('1.2.3-1')) == "SemanticVersion('1.2.3-1')"
    assert repr(SemanticVersion('1.2.3-1+build')) == "SemanticVersion('1.2.3-1+build')"
    assert repr(SemanticVersion('1.2.3+build')) == "SemanticVersion('1.2.3+build')"



# Generated at 2022-06-21 09:23:10.875157
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
        if not((_Numeric("1") < _Numeric("2")) and not(_Numeric("2") < _Numeric("1")) and (_Numeric("1") <= _Numeric("1"))):
            raise AssertionError


# Generated at 2022-06-21 09:23:14.975080
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion.from_loose_version(LooseVersion('2.0.0'))
    v2 = SemanticVersion.from_loose_version(LooseVersion('2.0.0'))
    assert v2 >= v1


# Generated at 2022-06-21 09:23:24.411081
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-21 09:23:25.408511
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    x = _Numeric(2)
    y = _Numeric(4)
    assert x == 2
    assert x != y


# Generated at 2022-06-21 09:23:29.897549
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    v1 = SemanticVersion('1.0.0')
    v2 = SemanticVersion('2.0.0')
    assert v1.__gt__ == v1.__lt__
    assert v2.__gt__ == v2.__lt__
    assert v1.__gt__(v2) == v2.__lt__(v1)
    assert v1.__gt__(v2) is True
    assert v2.__gt__(v1) is False



# Generated at 2022-06-21 09:23:31.436842
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    v = SemanticVersion('0.1.2')
    assert repr(v) == 'SemanticVersion(\'0.1.2\')'


# Generated at 2022-06-21 09:23:33.292055
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    result = SemanticVersion.__repr__(SemanticVersion(vstring='5.5.5'))
    assert result == 'SemanticVersion(\'5.5.5\')'


# Generated at 2022-06-21 09:23:51.551193
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():

    assert not (_Alpha('a') != _Alpha('a'))
    assert not (_Alpha('a') != 'a')
    assert _Alpha('a') != 'b'
    assert _Alpha('a') != _Alpha('b')


# Generated at 2022-06-21 09:23:56.718800
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(4) > _Numeric(2)
    assert _Numeric(4) > 2
    assert not _Numeric(4) > 4
    assert _Numeric(4) > _Alpha('3')
    assert _Numeric(4) > '3'
    assert not _Numeric(4) > _Alpha('4')
    assert not _Numeric(4) > '4'


# Generated at 2022-06-21 09:24:07.194728
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    num1 = _Numeric(1)
    num2 = _Numeric(2)
    num3 = _Numeric(3)
    num4 = _Numeric(4)
    num5 = _Numeric(5)
    num6 = _Numeric(6)
    num7 = _Numeric(7)
    num8 = _Numeric(8)
    num9 = _Numeric(9)
    num10 = _Numeric(10)
    num11 = _Numeric(11)
    num12 = _Numeric(12)
    num13 = _Numeric(13)
    num14 = _Numeric(14)
    num15 = _Numeric(15)
    num16 = _Numeric(16)
    num17 = _Numeric(17)
    num18 = _Numeric(18)
   

# Generated at 2022-06-21 09:24:13.852232
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2b2')) == SemanticVersion('0.1.2-b2')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2b2.dev1')) == SemanticVersion('0.1.2-b2.dev1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3b4')) == SemanticVersion('1.2.3-b4')

# Generated at 2022-06-21 09:24:21.060672
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    """Unit test for method __gt__ of class SemanticVersion"""
    import copy

    test_version = SemanticVersion('0.0.0')

    expected = 0
    actual = test_version._cmp('0.0.0')
    assert actual == expected

    expected = 0
    actual = test_version._cmp(SemanticVersion('0.0.0'))
    assert actual == expected

    expected = 0
    actual = test_version._cmp('0.0.0-alpha.1')
    assert actual == expected

    expected = 0
    actual = test_version._cmp('0.0.0-alpha')
    assert actual == expected

    expected = 0
    actual = test_version._cmp('0.0.0+abc.1')
    assert actual == expected

    expected = 0
    actual = test_version._cmp

# Generated at 2022-06-21 09:24:23.497417
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.0")
    assert v1 == v2
    assert not v1 != v2



# Generated at 2022-06-21 09:24:25.004790
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(0) > _Numeric(1)
    assert _Numeric(0) > _Alpha('a')



# Generated at 2022-06-21 09:24:26.014552
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr('foo') == repr(_Alpha('foo'))

# Generated at 2022-06-21 09:24:31.803284
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test function for testing method SemanticVersion.from_loose_version"""

    def assertFromLooseVersionEqual(loose_version, semver):
        """Helper function to perform testing"""
        semver_from_loose = SemanticVersion.from_loose_version(loose_version)
        assert semver_from_loose == semver, \
            "Failed test converting %s to %s from %s" % \
            (loose_version, semver, semver_from_loose)

    assertFromLooseVersionEqual("1.2.3", SemanticVersion("1.2.3"))
    assertFromLooseVersionEqual("1.2.3-pre", SemanticVersion("1.2.3-pre"))

# Generated at 2022-06-21 09:24:41.483154
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    caster_a = _Alpha('a')
    caster_b = _Alpha('b')
    caster_A = _Alpha('A')
    caster_B = _Alpha('B')
    caster_str_a = _Alpha(str('a'))
    caster_str_b = _Alpha(str('b'))

    assert caster_a == caster_a
    assert caster_a == 'a'
    assert caster_a == caster_str_a
    assert 'a' == caster_a
    assert caster_str_a == caster_a
    assert not caster_a == caster_b
    assert not caster_a == 'b'
    assert not caster_a == caster_str_b
    assert not 'b' == caster_a
    assert not caster_str_b == caster_a
    assert not caster_a == caster_A

# Generated at 2022-06-21 09:25:27.649780
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    pass


# Generated at 2022-06-21 09:25:39.251541
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('0.0.9')
    assert SemanticVersion('1.0.0') > SemanticVersion('0.0.0')
    assert SemanticVersion('0.1.0') > SemanticVersion('0.0.9')
    assert SemanticVersion('1.1.0') > SemanticVersion('1.0.9')
    assert SemanticVersion('1.1.2') > SemanticVersion('1.1.1')
    # Prerelease versions have a lower precedence than the associated normal version
    # https://semver.org/#spec-item-11
    assert SemanticVersion('1.1.1') > SemanticVersion('1.1.1-alpha')

# Generated at 2022-06-21 09:25:43.122126
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < 'b'
    assert 'a' < _Alpha('b')
    assert not _Alpha('b') < _Alpha('a')
    assert not _Alpha('b') < 'a'
    assert not 'b' < _Alpha('a')


# Generated at 2022-06-21 09:25:48.731050
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    """Test method __ge__ of class SemanticVersion."""
    assert SemanticVersion('0.0.1') >= SemanticVersion('0.0.1-beta1')
    assert SemanticVersion('0.0.1') >= SemanticVersion('0.0.1')
    assert SemanticVersion('0.0.1') >= SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') >= SemanticVersion('0.0.1-beta1')
    assert SemanticVersion('0.0.0') >= SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.1') >= SemanticVersion('0.0.0')
    assert SemanticVersion('0.0.0') >= SemanticVersion('0.0.0')

# Generated at 2022-06-21 09:25:52.114749
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert not _Numeric(1) < _Numeric(0)
    assert not _Numeric(0) < _Numeric(0)
    assert _Numeric(0) < _Numeric(1)


# Generated at 2022-06-21 09:26:00.293741
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert not _Alpha('1.2.3') != '1.2.3'
    assert _Alpha('1.2.3') != '1.2.4'
    assert not _Alpha('1.2.3') != _Alpha('1.2.3')
    assert not _Alpha('1.2.3') != _Numeric('1.2.3')
    assert _Alpha('1.2.3') != _Numeric('1.2.4')
    assert _Alpha('1.2.3') != _Alpha('1.2.4')
    assert not _Alpha('1.2.3') != 2
    assert _Alpha('1.2.3') != 1



# Generated at 2022-06-21 09:26:02.847741
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    # Verify that _Numeric.__ne__() correctly handles comparison with
    # _Numeric, str, and int objects.
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != '1'
    assert _Numeric(1) != 2


# Generated at 2022-06-21 09:26:08.743636
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    n1 = _Numeric('1')
    n2 = _Numeric('2')
    a1 = _Alpha('1')
    a2 = _Alpha('2')

    assert (n1 <= n1)
    assert (n1 <= a1)
    assert (n1 <= n2)
    assert (not n1 <= a2)



# Generated at 2022-06-21 09:26:12.082623
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    ver1 = SemanticVersion("2.0.0")
    ver2 = SemanticVersion("2.0.0")

    assert (ver1 == ver2)


if __name__ == '__main__':
    test_SemanticVersion___gt__()

# Generated at 2022-06-21 09:26:14.087582
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    value = "hello_world"
    result = repr(_Alpha(value))
    assert repr(value) == result
