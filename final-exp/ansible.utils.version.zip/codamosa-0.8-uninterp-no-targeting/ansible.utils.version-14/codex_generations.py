

# Generated at 2022-06-21 09:17:18.026333
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion('1.2.3')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version = SemanticVersion('1.2.3-pre.1')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Numeric(1),)
    assert version.buildmetadata == ()

    version = SemanticVersion('1.2.3-pre.1+meta.1')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Numeric(1),)

# Generated at 2022-06-21 09:17:27.802640
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # test_SemanticVersion___gt__
    # Given
    # When
    # Then
    assert SemanticVersion('1.2.3') > '1.2.2'
    assert SemanticVersion('1.2.3') > '1.2.3-alpha.1'
    assert SemanticVersion('1.2.3') > '1.2.3-alpha.2'
    assert SemanticVersion('1.2.3') > '1.2.3-beta.1'
    assert SemanticVersion('1.2.3') > '1.2.3-beta.2'
    assert SemanticVersion('1.2.3') > '1.2.3-beta.11'
    assert SemanticVersion('1.2.3') > '1.2.3-rc.1'
    assert SemanticVersion

# Generated at 2022-06-21 09:17:37.722358
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    # The versions are equal
    assert not SemanticVersion('10.2.3') > SemanticVersion('10.2.3')
    # The first version is greater than the second
    assert SemanticVersion('10.2.4') > SemanticVersion('10.2.3')
    # The first version prerelease has a greater minor version
    assert SemanticVersion('10.3.3') > SemanticVersion('10.2.3')
    # The second version is a prerelease (a patch version does not matter in this case)
    assert SemanticVersion('10.2.4') > SemanticVersion('10.2.3-alpha.0')
    # The first version has a prerelease (a patch version does not matter in this case)

# Generated at 2022-06-21 09:17:41.248803
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    for specifier in ['a', '0', 'abc0-def_ghi.jkl']:
        alpha = _Alpha(specifier)
        assert isinstance(alpha, _Alpha)
        assert repr(alpha) == repr(specifier)


# Generated at 2022-06-21 09:17:51.284750
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    sv1 = SemanticVersion('1.2.3')
    sv2 = SemanticVersion('1.2.3')
    assert sv1 == sv2
    assert sv1.__eq__(sv2)
    assert sv2.__eq__(sv1)
    assert not sv1 != sv2
    assert not sv1.__ne__(sv2)
    assert not sv2.__ne__(sv1)
    assert sv1 is not sv2

    sv1 = SemanticVersion('1.2.3-alpha1.2')
    sv2 = SemanticVersion('1.2.3-alpha1.2')
    assert sv1 == sv2
    assert sv1.__eq__(sv2)
    assert sv2.__eq__(sv1)
    assert not sv1 != sv2

# Generated at 2022-06-21 09:17:52.534300
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric(1)) == repr(1)


# Generated at 2022-06-21 09:17:59.971611
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    print("--- Testing __gt__ of class _Alpha ---")

    # Test 1
    try:
        a = _Alpha("a")
        b = _Numeric(1)

        if a > b:
            print("Test 1 failed")
            return
    except ValueError:
        pass
    print("Test 1 passed")

    # Test 2
    try:
        a = _Alpha("a")
        b = _Alpha("b")

        if a > b:
            print("Test 2 failed")
            return
    except ValueError:
        print("Test 2 passed")
        return

    print("Test 2 passed")


# Generated at 2022-06-21 09:18:10.471546
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    sv = SemanticVersion()
    # Test position cases
    sv.parse('1.0.1-rc.1+build.1')
    assert sv.major == 1
    assert sv.minor == 0
    assert sv.patch == 1
    assert sv.prerelease == (_Numeric('rc'), _Numeric('1'))
    assert sv.buildmetadata == (_Alpha('build'), _Numeric('1'))

    # Test with build metadata only
    sv.parse('1.0.1+build.1')
    assert sv.major == 1
    assert sv.minor == 0
    assert sv.patch == 1
    assert sv.prerelease == ()
    assert sv.buildmetadata == (_Alpha('build'), _Numeric('1'))

    # Test with prerelease only

# Generated at 2022-06-21 09:18:15.621464
# Unit test for constructor of class _Numeric
def test__Numeric():
    n = _Numeric('3')
    assert n.specifier == 3
    n = _Numeric('3.0')
    assert n.specifier == 3
    n = _Numeric('3.1')
    assert n.specifier == 3
    n = _Numeric('3.1x')
    assert n.specifier == 3
    assert n == 3
    assert n != 4
    assert n > 2
    assert n < 4
    assert n <= 3
    assert n >= 2
    assert n >= 3


# Generated at 2022-06-21 09:18:26.866695
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():

    # Test for same type and value
    a = _Alpha('01')
    assert a == _Alpha('01')
    assert not a != _Alpha('01')

    # Test for same type and different value
    assert not a == _Alpha('99')
    assert a != _Alpha('99')

    # Test for different type and same value
    assert a == '01'
    assert not a != '01'

    # Test for different type and different value
    assert not a == '99'
    assert a != '99'

    # Test for same type and value
    a = _Alpha('a')
    assert a == _Alpha('a')
    assert not a != _Alpha('a')

    # Test for same type and different value
    assert not a == _Alpha('d')
    assert a != _Alpha('d')

    # Test for different

# Generated at 2022-06-21 09:18:50.782297
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    testCases = [
        # testCases format: [numeric1, numeric2, expectedResult]
        [_Numeric(1), _Numeric(2), True],
        [_Numeric(2), _Numeric(2), True],
        [_Numeric(2), _Numeric(1), False],
        [_Numeric(1), _Alpha(2), False],
        [_Numeric(1), _Alpha('a'), True],
        [_Numeric(1), _Alpha('z'), True],
        [_Numeric(1), _Alpha('A'), True],
        [_Numeric(1), _Alpha('Z'), True],
    ]
    for numeric1, numeric2, expectedResult in testCases:
        if numeric1.__le__(numeric2) != expectedResult:
            raise Assertion

# Generated at 2022-06-21 09:18:53.597662
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(eval(repr(SemanticVersion("1.2.3")))) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-21 09:18:57.755156
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) > 0
    assert not _Numeric(1) > _Numeric(1)
    assert not _Numeric(1) > 1
    assert _Numeric(1) > _Alpha('a')
    assert _Numeric(1) > 'a'


# Generated at 2022-06-21 09:19:00.479050
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert not _Numeric(14) > _Alpha('14')


# Generated at 2022-06-21 09:19:09.880720
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    x = _Numeric(1)
    y = _Numeric(2)
    z = _Numeric(2)
    a = _Alpha(1)
    b = _Alpha(2)

    assert x < y
    assert x <= y
    assert y > x
    assert y >= x

    assert y <= z
    assert y >= z

    assert not x < x
    assert not x <= x
    assert not x > x
    assert not x >= x

    assert not x > y
    assert not x >= y
    assert not y < x
    assert not y <= x

    assert x < a
    assert x <= a
    assert a > x
    assert a >= x

    assert not a < y
    assert not a <= y
    assert not y < a
    assert not y <= a

    assert not a < b


# Generated at 2022-06-21 09:19:15.558284
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    """
    __ne__(self, other)
    """
    # Init method attributes
    test_class = _Alpha('__ne__')
    other = '__ne__'

    # Execute the method.
    result = test_class.__ne__(other)

    # Verify the result.
    assert result == False



# Generated at 2022-06-21 09:19:17.816633
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha('a')
    assert a.specifier == 'a'


# Generated at 2022-06-21 09:19:29.464704
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    lhs = SemanticVersion("1.2.3")
    rhs = "1.2.3"
    expected = True
    actual = lhs.__ge__(rhs)
    assert expected == actual, "__ge__(%r, %r) should be %r but was %r" % (lhs, rhs, expected, actual)

    lhs = SemanticVersion("1.2.3")
    rhs = SemanticVersion("1.2.3")
    expected = True
    actual = lhs.__ge__(rhs)
    assert expected == actual, "__ge__(%r, %r) should be %r but was %r" % (lhs, rhs, expected, actual)

    lhs = SemanticVersion("2.2.3")

# Generated at 2022-06-21 09:19:37.362595
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    '''Unit test for method __eq__ of class _Alpha'''
    data = [
        (_Alpha("10"), "10", True),
        (_Alpha("10"), 10, False),
        (_Alpha("10"), _Numeric("10"), False),
        (_Alpha("10"), _Alpha("10"), True),
        (_Alpha("10"), _Alpha("matt"), False),
    ]

    for (left, right, expected) in data:
        actual = left == right
        if actual != expected:
            raise AssertionError("%r == %r should be %r, not %r" % (left, right, expected, actual))



# Generated at 2022-06-21 09:19:41.914813
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    sv = SemanticVersion('1.2.3-alpha+sha.52b8f51')
    assert repr(sv) == 'SemanticVersion(\'1.2.3-alpha+sha.52b8f51\')'

# Generated at 2022-06-21 09:20:01.272237
# Unit test for constructor of class _Numeric
def test__Numeric():
    class _NumericTest(object):
        def test_exceptions(self):
            # This should fail because there is no specifier
            try:
                _Numeric()
            except (ValueError, TypeError):
                pass
            else:
                assert False, '_Numeric should have raised a ValueError/TypeError'

            # This should fail because the specifier is not a string or integer
            try:
                _Numeric(['a', 'b'])
            except (ValueError, TypeError):
                pass
            else:
                assert False, '_Numeric should have raised a ValueError/TypeError'

        def test_good(self):
            assert _Numeric('1').specifier == 1
            assert _Numeric(1).specifier == 1

# Generated at 2022-06-21 09:20:07.151898
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Test without the buildmetadata
    v1 = SemanticVersion('1.2.3-alpha.1')
    assert v1.__le__(v1)
    v2 = SemanticVersion('1.2.3-alpha.2')
    assert v1.__le__(v2)
    assert not v2.__le__(v1)
    v3 = SemanticVersion('1.2.3-alpha.1')
    assert v1.__le__(v3)

    # Test with the buildmetadata
    v4 = SemanticVersion('1.2.3-alpha.1+build.1')
    assert v4.__le__(v4)
    v5 = SemanticVersion('1.2.3-alpha.2+build.1')
    assert v4.__le__(v5)
   

# Generated at 2022-06-21 09:20:13.006156
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-21 09:20:14.036071
# Unit test for constructor of class _Numeric
def test__Numeric():
    _Numeric(1)
    _Numeric("1")


# Generated at 2022-06-21 09:20:16.507630
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert (SemanticVersion('1.2.3') != '1.2.3') is False
    return


# Generated at 2022-06-21 09:20:22.615785
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == repr(1)
    assert repr(_Numeric(1)) == repr(1)
    assert repr(_Numeric('2')) == repr(2)
    assert repr(_Numeric(2)) == repr(2)
    assert repr(_Numeric('3')) == repr(3)
    assert repr(_Numeric(3)) == repr(3)


# Generated at 2022-06-21 09:20:25.796718
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert not _Numeric('1') < _Numeric('1')
    assert not _Numeric('2') < _Numeric('1')



# Generated at 2022-06-21 09:20:35.795753
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():

    instance = _Alpha('aa')

    assert instance > 'aa'
    assert not instance > 'ab'
    assert not instance > 'aA'
    assert not instance > 'a'
    assert not instance > 'b'

    assert not instance > _Alpha('aa')
    assert not instance > _Alpha('ab')
    assert not instance > _Alpha('aA')
    assert instance > _Alpha('a')
    assert not instance > _Alpha('b')

    assert not instance > 0
    assert instance > 1

    assert not instance > _Numeric(0)
    assert instance > _Numeric(1)

    instance = _Alpha('ab')

    assert instance > 'aa'
    assert not instance > 'ab'
    assert not instance > 'aA'
    assert instance > 'a'
    assert not instance > 'b'

   

# Generated at 2022-06-21 09:20:36.920929
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr( _Numeric(5) ) == '5'


# Generated at 2022-06-21 09:20:47.655173
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    import unittest
    class test__Numeric___gt__(unittest.TestCase):
        def test_it(self):
            self.assertTrue(_Numeric('1') > _Numeric('0'), msg="1 > 0")
            self.assertTrue(_Numeric('1') > _Numeric('3'), msg="1 > 3")
            self.assertTrue(_Numeric('1') > _Numeric('3'), msg="1 > 3")
            self.assertFalse(_Numeric('1') > _Numeric('1'), msg="1 > 1")
            self.assertFalse(_Numeric('-1') > _Numeric('1'), msg="-1 > 1")
            self.assertFalse(_Numeric('1.1') > _Numeric('1'), msg="1.1 > 1")

# Generated at 2022-06-21 09:21:04.663743
# Unit test for constructor of class _Numeric
def test__Numeric():
      assert _Numeric(42) == 42
      assert _Numeric(42).__repr__() == '42'
      assert _Numeric(42) != 43
      assert _Numeric(42) < 43
      assert _Numeric(42) <= 43
      assert _Numeric(42) > 41
      assert _Numeric(42) >= 41
      assert _Numeric(42) == _Numeric(42)
      assert _Numeric(42) != _Numeric(43)
      assert _Numeric(42) < _Numeric(43)
      assert _Numeric(42) <= _Numeric(43)
      assert _Numeric(42) > _Numeric(41)
      assert _Numeric(42) >= _Numeric(41)


# Generated at 2022-06-21 09:21:05.559398
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():

    assert _Alpha(1) != '1'



# Generated at 2022-06-21 09:21:08.254890
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    expected_output = False
    excepted_output = SemanticVersion('1.0.0') <= SemanticVersion('2.0.0')

    assert excepted_output == expected_output


# Generated at 2022-06-21 09:21:17.940347
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.2.3') == '1.2.3'
    assert SemanticVersion('1.2.3') != '1.2.4'
    assert SemanticVersion('1.2.3') != '1.2.4'
    assert SemanticVersion('1.2.3') != '1.2.4-rc5'
    assert SemanticVersion('1.2.3') != '1.2.4-rc5+20130313144700'
    assert SemanticVersion('1.2.3') != '1.2.3-rc5'
    assert SemanticVersion('1.2.3') != '1.2.3+20130313144700'

# Generated at 2022-06-21 09:21:22.025313
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion('0.0.0')
    v2 = SemanticVersion('0.0.0')
    eq_(v1.__ge__(v2), True)

    v1 = SemanticVersion('0.0.0')
    v2 = SemanticVersion('1.0.0')
    eq_(v1.__ge__(v2), False)

    v1 = SemanticVersion('0.0.0')
    v2 = SemanticVersion('0.1.0')
    eq_(v1.__ge__(v2), False)

    v1 = SemanticVersion('0.0.0')
    v2 = SemanticVersion('0.0.1')
    eq_(v1.__ge__(v2), False)

    v1 = SemanticVersion('0.0.0')


# Generated at 2022-06-21 09:21:29.201678
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    alpha = _Alpha('a')
    assert alpha < 'b'
    assert alpha < 1
    assert not alpha < 'a'
    try:
        alpha < 1.1
        assert False
    except ValueError:
        assert True

    alpha = _Alpha('1.2')
    assert alpha < '2'
    assert alpha < 2
    assert not alpha < 1.1
    try:
        alpha < 'a'
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-21 09:21:32.268615
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(2).__ne__(2)
    assert _Numeric(3).__ne__(2)
    assert _Numeric(2).__ne__('2')
    assert _Numeric(2).__ne__(_Alpha('2'))


# Generated at 2022-06-21 09:21:34.949923
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric('3') != '3'
    assert _Numeric('3') != 3
    assert _Numeric('3') != _Numeric('5')
    assert _Numeric('3') != _Alpha('3')



# Generated at 2022-06-21 09:21:40.370953
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    """Unit test for SemanticVersion.__gt__"""

    semver_1 = SemanticVersion("1.2.3")
    semver_2 = SemanticVersion("2.2.3")
    print("semver_1 ",semver_1)
    print("semver_2 ",semver_2)
    assert semver_1 < semver_2
    assert semver_1 <= semver_2
    assert semver_1 != semver_2
    assert semver_1 >= semver_1
    assert semver_1 == semver_1
    assert semver_1 <= semver_1
    assert semver_2 > semver_1
    assert semver_2 >= semver_1
    assert semver_2 != semver_1
    assert semver_2 <= semver_2
    assert sem

# Generated at 2022-06-21 09:21:42.256006
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('foo')) == repr('foo'), 'Invalid output for method __repr__'


# Generated at 2022-06-21 09:22:01.470985
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_v = LooseVersion('0.0.1')
    semver = SemanticVersion.from_loose_version(loose_v)
    assert loose_v == semver


# Generated at 2022-06-21 09:22:12.997206
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test creation of SemanticVersion from LooseVersion
    sv = SemanticVersion.from_loose_version(LooseVersion("1.3.3"))
    assert isinstance(sv, SemanticVersion)
    assert text_type(sv) == "1.3.3"
    sv = SemanticVersion.from_loose_version(LooseVersion("1.3.3rc2"))
    assert isinstance(sv, SemanticVersion)
    assert text_type(sv) == "1.3.3-rc.2"
    sv = SemanticVersion.from_loose_version(LooseVersion("1.3.3.4.5"))
    assert isinstance(sv, SemanticVersion)
    assert text_type(sv) == "1.3.3"

# Generated at 2022-06-21 09:22:19.256660
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha("0")
    b = _Alpha("1")
    c = _Alpha("0")
    assert not a.__ne__(a), "__ne__() should return False when comparing object with itself."
    assert a.__ne__(b), "__ne__() should return True when comparing two different objects."
    assert not a.__ne__(c), "__ne__() should return False when comparing two equal objects."


# Generated at 2022-06-21 09:22:28.635114
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    t1 = _Alpha('15')
    t2 = _Alpha('15.1')
    t3 = _Alpha('15.1.1')

    assert t1 >= t2
    assert t2 >= t3
    assert t1 >= t3
    assert t1 >= '15'
    try:
        assert t1 >= 15
    except:
        pass
    try:
        assert t1 >= _Numeric(15)
    except:
        pass
    try:
        assert t1 >= 15.1
    except:
        pass
    try:
        assert t1 >= _Numeric(15.1)
    except:
        pass

# Generated at 2022-06-21 09:22:35.143503
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert (SemanticVersion('1.0.0') != '2.0.0') is True
    assert (SemanticVersion('1.0.0') != SemanticVersion('2.0.0')) is True
    assert (SemanticVersion('1.0.0') != '1.0.0') is False
    assert (SemanticVersion('1.0.0') != SemanticVersion('1.0.0')) is False



# Generated at 2022-06-21 09:22:45.984072
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Input variables to the method parse of class SemanticVersion
    args = list()
    args.append('')
    args.append('0.0.0')
    args.append('0.1.0')
    args.append('0.1.1')
    args.append('1.0.0')
    args.append('1.1.0')
    args.append('1.1.1')
    args.append('1.1.1-alpha')
    args.append('1.1.1-alpha.1')
    args.append('1.1.1+20130313144700')

    # Expected results from the method parse of class SemanticVersion
    exp = list()
    exp.append(ValueError)
    exp.append('0.0.0')

# Generated at 2022-06-21 09:22:48.408611
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.0.0') >= '1.0.0'
    assert not SemanticVersion('0.0.1') >= '0.0.0'


# Generated at 2022-06-21 09:22:50.405272
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    result = [_Numeric(1), '1']
    result.sort()
    if not (result == [1, '1']):
        return False
    return True


# Generated at 2022-06-21 09:22:51.951661
# Unit test for constructor of class _Alpha
def test__Alpha():
    res = _Alpha('a')
    assert res.specifier == 'a'


# Generated at 2022-06-21 09:22:53.186903
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(0) < _Numeric(1)


# Generated at 2022-06-21 09:23:24.179916
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    n = _Numeric('50')
    assert repr(n) == '50'

# Generated at 2022-06-21 09:23:28.649566
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(8) >= _Numeric(7)
    assert _Numeric(8) >= 8

    # Equality
    assert _Numeric(8) >= 8
    assert 8 >= _Numeric(8)

    assert not _Numeric(7) > _Numeric(8)
    assert not 7 > _Numeric(8)
    assert not _Numeric(7) > 8


# Generated at 2022-06-21 09:23:35.545252
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    n1 = _Numeric(1)
    n2 = _Numeric(2)
    assert n1 < n2
    assert n1 <= n2
    assert n2 > n1
    assert n2 >= n1
    assert n1 <= n1
    assert n1 >= n1
    assert not n1 < n1
    assert not n1 > n1

    a1 = _Alpha('a')
    assert n1 < a1
    assert n1 <= a1
    assert a1 > n1
    assert a1 >= n1
    assert not n1 > a1
    assert not n1 >= a1
    assert not a1 < n1
    assert not a1 <= n1


# Generated at 2022-06-21 09:23:44.049955
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version_string = "1.2.3-alpha.1.2+build.11.e0f985a"
    semantic_version = SemanticVersion(version_string)
    assert semantic_version.vstring == version_string
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert semantic_version.prerelease[0] == "alpha"
    assert semantic_version.prerelease[1] == 1
    assert semantic_version.prerelease[2] == 2
    assert semantic_version.buildmetadata[0] == "build"
    assert semantic_version.buildmetadata[1] == 11
    assert semantic_version.buildmetadata[2] == "e0f985a"

# Ensure that we can parse "loose" version strings

# Generated at 2022-06-21 09:23:48.300011
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    x = SemanticVersion('1.0.0')
    y = SemanticVersion('0.9.0')
    if x >= y:
        print ("test __Numeric___ge__ true")
    assert (x >= y)


# Generated at 2022-06-21 09:23:54.420283
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    v1 = SemanticVersion('1.2.4')
    v2 = SemanticVersion('1.2.4-alpha1')
    v3 = SemanticVersion('1.2.4+12345')

    assert v1 >= v1
    assert v1 >= v3
    assert v3 >= v1
    assert not v1 >= v2
    assert not v2 >= v1


# Generated at 2022-06-21 09:23:59.183597
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    # Test with a string
    v1 = SemanticVersion('1.2.3')
    assert v1.__ne__('1.2.3') == False

    # Test with another string
    assert v1.__ne__('1.2.4') == True

    # Test with asemantic version
    v2 = SemanticVersion('1.2.4')
    assert v1.__ne__(v2) == True

    # Test with asemantic version
    v3 = SemanticVersion('1.2.3')
    assert v1.__ne__(v3) == False



# Generated at 2022-06-21 09:23:59.875697
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric(20) >= _Numeric(20)


# Generated at 2022-06-21 09:24:09.304545
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('0.0.1+buildmetadata') >= SemanticVersion('0.0.1+buildmetadata')
    assert SemanticVersion('0.0.1+buildmetadata') >= SemanticVersion('0.0.1')
    assert SemanticVersion('0.0.1+buildmetadata') >= SemanticVersion('0.0.1-prerelease')
    assert SemanticVersion('0.0.1+buildmetadata') >= '0.0.1+buildmetadata'
    assert SemanticVersion('0.0.1+buildmetadata') >= '0.0.1'
    assert SemanticVersion('0.0.1+buildmetadata') >= '0.0.1-prerelease'

    assert SemanticVersion('0.0.1+buildmetadata') >= SemanticVersion('0.1.0')

# Generated at 2022-06-21 09:24:11.076760
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('10') < 100
    assert _Numeric(10) < _Numeric('100')
    assert _Numeric(10) < _Alpha(100)


# Generated at 2022-06-21 09:25:14.216030
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0')

# Generated at 2022-06-21 09:25:23.236409
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    def test(st, major, minor, patch, prerelease, buildmetadata):
        assert st.major == major
        assert st.minor == minor
        assert st.patch == patch
        assert st.prerelease == tuple(_Numeric(x) if x.isdigit() else _Alpha(x) for x in prerelease)
        assert st.buildmetadata == tuple(_Numeric(x) if x.isdigit() else _Alpha(x) for x in buildmetadata)

    test(SemanticVersion("1.2.3"), 1, 2, 3, (), ())
    test(SemanticVersion("10.20.30"), 10, 20, 30, (), ())
    test(SemanticVersion("1.2.3-rc1"), 1, 2, 3, ("rc1",), ())

# Generated at 2022-06-21 09:25:33.660619
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.0.0') >= '1.0.0'
    assert not SemanticVersion('1.0.0') >= '1.0.1'
    assert not SemanticVersion('1.0.1') >= '1.0.0'
    assert SemanticVersion('1.0.0') >= '1.0.0-alpha'
    assert not SemanticVersion('1.0.0') >= '1.0.0-beta'
    assert not SemanticVersion('1.0.0-alpha') >= '1.0.0'
    assert not SemanticVersion('1.0.0-alpha') >= '1.0.0-beta'
    assert SemanticVersion('1.0.0-alpha') >= '1.0.0-alpha'

# Generated at 2022-06-21 09:25:43.234223
# Unit test for constructor of class _Alpha
def test__Alpha():
    # When a str, not the same
    assert isinstance(_Alpha('a'), _Alpha)
    assert _Alpha('a') != 'a'
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('b') != _Alpha('a')

    # When the same, they are equal
    assert _Alpha('a') == 'a'
    assert _Alpha('b') == _Alpha('b')

    # Standard equality
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('b') != _Alpha('a')

    # Strings can be less than or equal to, but not greater than
    assert _Alpha('a') < 'b'
    assert 'a' < _Alpha('b')
    assert _Alpha('a') <= 'a'


# Generated at 2022-06-21 09:25:54.471773
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    #Test when the first argument is greater than the second one
    arg1 = _Numeric(12)
    arg2 = _Numeric(10)
    expected = True
    actual = arg1 > arg2
    assert actual == expected

    #Test when the first argument is equal to the second one
    arg1 = _Numeric(10)
    arg2 = _Numeric(10)
    expected = False
    actual = arg1 > arg2
    assert actual == expected

    #Test when the first argument is lesser than the second one
    arg1 = _Numeric(10)
    arg2 = _Numeric(12)
    expected = False
    actual = arg1 > arg2
    assert actual == expected

    #Test when the first argument is a string and the second one is an integer
    arg1 = _Alpha("10")
    arg2

# Generated at 2022-06-21 09:26:02.944841
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion('1.2.3') == SemanticVersion('1.2.3')

    assert SemanticVersion('1.1.1') == '1.1.1'
    assert SemanticVersion('0.0.0') == '0.0.0'
    assert SemanticVersion('2.2.2') == '2.2.2'

    # < MAJOR
    assert SemanticVersion('0.0.1') == '0.0.1'

    # > MAJOR
    assert SemanticVersion('2.2.2') == '2.2.2'

    # < MINOR
    assert SemanticVersion('0.0.0') == '0.0.0'

    # > MINOR

# Generated at 2022-06-21 09:26:12.446116
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    """Unit test for method __ge__"""
    # Tests simple version comparison
    version1 = SemanticVersion('1.0.0')
    version2 = SemanticVersion('0.0.1')
    assert version1 >= version2

    # Tests comparison of prereleases
    version1 = SemanticVersion('1.0.0-alpha')
    version2 = SemanticVersion('1.0.0-beta')
    assert version1 >= version2

    # Tests comparison of buildmetadata
    version1 = SemanticVersion('1.0.0+build.1')
    version2 = SemanticVersion('1.0.0+build.2')
    assert version1 >= version2


# Generated at 2022-06-21 09:26:21.902265
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.1.1') <= '1.1.1'
    assert SemanticVersion('1.1.1') <= '1.1.2'
    assert SemanticVersion('1.1.1') <= '1.2.1'
    assert SemanticVersion('1.1.1') <= '2.1.1'
    assert SemanticVersion('1.1.1') <= '1.1.1-rc1'
    assert SemanticVersion('1.1.1-rc1') <= '1.1.1-rc1'
    assert SemanticVersion('1.1.1-rc1') <= '1.1.1-rc2'
    assert SemanticVersion('1.1.1-rc1') <= '1.1.1'

# Generated at 2022-06-21 09:26:24.682081
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('1')) == "'1'"
    assert repr(_Alpha('alpha')) == "'alpha'"


# Generated at 2022-06-21 09:26:33.155872
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    s = SemanticVersion('1.2.3-alpha.1+cmp')

    # test __lt__
    assert (s < '1.2.3') is False

    # this is safe since prerelease version are not considered stable
    # in fact, can be consider as a bug to be fixed in the future
    # for this reason, a prerelease version is ALWAYS greater than nothing
    assert (s < '') is True
    assert (s < '1.2.3-alpha') is False

    # test __le__
    assert s <= '1.2.3'
    assert s <= '1.2.3-alpha.1'


if __name__ == '__main__':
    test_SemanticVersion___le__()