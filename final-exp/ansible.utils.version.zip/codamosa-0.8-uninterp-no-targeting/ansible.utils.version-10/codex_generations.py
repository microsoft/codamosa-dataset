

# Generated at 2022-06-21 09:17:03.586547
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    expected = repr(1)
    result = repr(_Numeric(1))
    assert expected == result


# Generated at 2022-06-21 09:17:11.180934
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    """Unit test function:
    SemanticVersion._Alpha.__eq__()
    """
    a1 = _Alpha('a')
    b1 = _Alpha('b')
    assert(a1 == a1)
    assert(a1 != b1)
    assert(not a1 == 1)
    assert('a' == a1)
    assert(b1 == 'b')
    assert(1 != a1)
    try:
        a1 == 1
    except ValueError:
        pass
    else:
        raise AssertionError("Unexpected behavior")
    try:
        b1 == 1
    except ValueError:
        pass
    else:
        raise AssertionError("Unexpected behavior")
    try:
        a1 == _Numeric(3)
    except ValueError:
        pass

# Generated at 2022-06-21 09:17:15.205312
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('alpha') >= _Alpha('alpha')
    assert _Alpha('alpha') >= 'alpha'
    assert not _Alpha('alpha') >= _Alpha('beta')
    assert not _Alpha('alpha') >= 'beta'


# Generated at 2022-06-21 09:17:17.435775
# Unit test for constructor of class _Alpha
def test__Alpha():
    _assert_equal(_Alpha('foo').specifier, 'foo')
    _assert_raises(ValueError, _Alpha, None)


# Generated at 2022-06-21 09:17:18.749087
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert not _Numeric(1) > _Numeric(1)
    

# Generated at 2022-06-21 09:17:23.126243
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('a')
    b = _Alpha('b')
    assert a < b
    assert not (a > b)
    # a is not greater than or equal to b
    assert not (a >= b)


# Generated at 2022-06-21 09:17:26.983057
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha("b")
    b = _Alpha("b")
    c = _Alpha("c")
    assert a < c
    assert b < c
    assert c > a
    assert c > b
    assert a <= c
    assert b <= c
    assert c >= a
    assert c >= b


# Generated at 2022-06-21 09:17:28.795905
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric('1') <= _Numeric('2')
    assert not _Numeric('2') <= _Numeric('1')


# Generated at 2022-06-21 09:17:32.654264
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    version = SemanticVersion('1.2.3+build1')
    assert version.__repr__() == "SemanticVersion(\'1.2.3+build1\')", \
        "__repr__ should return the correct string"


# Generated at 2022-06-21 09:17:36.747929
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    """Test SemanticVersion Class"""
    ver = '0.7.2'
    version_object = SemanticVersion(ver)
    assert isinstance(version_object, SemanticVersion)

# Unit test to test is_stable method of class SemanticVersion

# Generated at 2022-06-21 09:17:51.574656
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('3') >= _Numeric('3')
    assert _Numeric('3') >= _Numeric('2')
    assert _Numeric('3') >= _Numeric('1')
    assert _Numeric('3') >= _Numeric('0')
    assert _Numeric('3') >= _Numeric('-1')
    assert _Numeric('3') >= _Numeric('-2')
    assert _Numeric('3') >= _Numeric('-3')
    assert _Numeric('3') >= _Numeric('4')


# Generated at 2022-06-21 09:18:00.809577
# Unit test for method __ge__ of class _Numeric
def test__Numeric___ge__():
    assert _Numeric('1') >= _Numeric('1')
    assert _Numeric('1') >= _Numeric('0')
    assert _Numeric('1') >= _Numeric('0.0')
    assert _Numeric('1') >= _Numeric('1.0')
    assert _Numeric('1') >= _Numeric('2')
    assert _Numeric('1') >= _Numeric('2.2')
    assert not _Numeric('1') >= _Numeric('1-1')
    assert _Numeric('1') >= _Numeric('1+123')

    assert not _Numeric('1') >= _Alpha('1')
    assert _Numeric('1') >= _Alpha('0')
    assert _Numeric('1') >= _Alpha('0.0')

# Generated at 2022-06-21 09:18:11.335849
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():

    class AlphaTest1:

        def __init__(self, specifier):
            self.specifier = specifier

        def __repr__(self):
            return repr(self.specifier)

        def __lt__(self, other):
            if isinstance(other, AlphaTest1):
                return self.specifier < other.specifier
            elif isinstance(other, str):
                return self.specifier < other
            elif isinstance(other, NumericTest1):
                return False

            raise ValueError

        def __eq__(self, other):
            if isinstance(other, AlphaTest1):
                return self.specifier == other.specifier
            elif isinstance(other, str):
                return self.specifier == other

            return False


# Generated at 2022-06-21 09:18:16.070235
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    # Test with a _Alpha greater than another _Alpha
    assert _Alpha('a') >= _Alpha('b')
    # Test with a str greater than a _Alpha
    assert _Alpha('a') >= 'b'
    # Test with a _Alpha greater than a str
    assert 'b' >= _Alpha('a')

    # Test with equal _Alpha
    assert _Alpha('a') >= _Alpha('a')
    # Test with equal str
    assert 'a' >= _Alpha('a')
    assert _Alpha('a') >= 'a'



# Generated at 2022-06-21 09:18:19.821918
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion("1.0.0")) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-21 09:18:25.393952
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():  # noqa: N802
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(2) <= _Numeric(1) is False
    assert _Numeric(1) <= 2
    assert _Numeric(1) <= 1
    assert _Numeric(2) <= 1 is False



# Generated at 2022-06-21 09:18:29.206586
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert not _Alpha('a') == _Alpha('b')
    assert not _Alpha('a') == 'b'
    assert not _Alpha('a') == 1


# Generated at 2022-06-21 09:18:33.789343
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    a = _Numeric("1")
    b = _Numeric("2")
    # test for less than
    assert a < b
    # test for greater than
    assert not b < a

    c = _Alpha("1")
    # test for less than, 1 < 2
    assert a < c


# Generated at 2022-06-21 09:18:40.856052
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.1')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.1.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('2.0.0')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0-alpha+build')
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0-alpha.1')

# Generated at 2022-06-21 09:18:52.236455
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert not (SemanticVersion('1.0.0') == '1.0.1')
    assert not (SemanticVersion('1.0.0') == '1.1.0')
    assert not (SemanticVersion('1.0.0') == '2.0.0')

    assert SemanticVersion('1.0.0-alpha') == '1.0.0-alpha'
    assert not (SemanticVersion('1.0.0-alpha') == '1.0.0-alpha.1')
    assert not (SemanticVersion('1.0.0-alpha') == '1.0.0-alpha.beta')
    assert not (SemanticVersion('1.0.0-alpha') == '1.0.0-beta')

# Generated at 2022-06-21 09:19:04.534941
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert not SemanticVersion('0.0.1') != SemanticVersion('0.0.1')
    assert SemanticVersion('0.0.1') != SemanticVersion('0.0.2')
    assert SemanticVersion('0.0.1') != SemanticVersion('0.1.1')
    assert SemanticVersion('0.0.1') != SemanticVersion('1.0.1')



# Generated at 2022-06-21 09:19:07.989912
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    input_a = _Alpha("rc")
    input_b = "rc"
    expected = True
    actual = input_a > input_b
    assert expected == actual
    print("test__Alpha___ge__(): Actual = expected = %s" % str(actual))



# Generated at 2022-06-21 09:19:09.530801
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert SemanticVersion('1.0.0') != '1.0.0'


# Generated at 2022-06-21 09:19:15.951732
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    a = _Alpha('a')
    assert a != 'a', 'Alpha != str'
    assert a != _Alpha('a'), 'Alpha != Alpha'
    assert a != _Numeric('1'), 'Alpha != Numeric'
    assert a != 123, 'Alpha != int'
    try:
        a != 3.2
        assert False, 'Alpha != float'
    except ValueError:
        pass


# Generated at 2022-06-21 09:19:20.943799
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    a = _Numeric(1)
    assert a.__gt__(0)
    assert a.__gt__(-1)
    assert not a.__gt__(1)
    assert not a.__gt__(2)
    assert not a.__gt__('2')


# Generated at 2022-06-21 09:19:25.304058
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha('a') < 'b'
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('a') < _Numeric('b')


# Generated at 2022-06-21 09:19:27.195303
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(1) == repr(_Alpha('1'))


# Generated at 2022-06-21 09:19:37.434543
# Unit test for method __ge__ of class SemanticVersion

# Generated at 2022-06-21 09:19:39.236738
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    assert SemanticVersion() is not None


# Generated at 2022-06-21 09:19:50.047805
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    """
    Test __lt__ method of SemanticVersion class
    """
    assert (SemanticVersion('0.0.0+0') < '1.0.0+0') == True
    assert (SemanticVersion('0.0.1+0') < '1.0.0+0') == True
    assert (SemanticVersion('0.0.0+0') < '1.1.0+0') == True
    assert (SemanticVersion('0.0.0+0') < '1.0.1+0') == True
    assert (SemanticVersion('0.0.0+0') < '1.0.0+1') == True
    assert (SemanticVersion('1.0.0+0') < '1.0.0+0') == False

# Generated at 2022-06-21 09:20:03.988432
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Testing SemanticVersion.from_loose_version method
    """

# Generated at 2022-06-21 09:20:06.513243
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    alpha = _Alpha('abc')
    assert alpha < 'def'
    assert alpha < _Alpha('def')
    assert not alpha < 'abc'
    assert not alpha < _Alpha('abc')
    assert not alpha < _Numeric(1)


# Generated at 2022-06-21 09:20:12.455723
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    """Unit tests for the comparison method __lt__ of the class SemanticVersion
    
    
    :return: True if all the tests pass, False otherwise
    :rtype: bool
    """
    # Initialization
    # Declaration of the tested instances
    v1 = SemanticVersion("1.0.0")
    v2 = SemanticVersion("1.0.1")
    v3 = SemanticVersion("1.1.0")
    v4 = SemanticVersion("2.0.0")
    v5 = SemanticVersion("1.0.0-alpha")
    v6 = SemanticVersion("1.0.0-alpha.1")
    v7 = SemanticVersion("1.0.0-alpha.beta")
    v8 = SemanticVersion("1.0.0-beta")

# Generated at 2022-06-21 09:20:16.589495
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    # test for valid semver
    semver = SemanticVersion()
    semver.parse("42.0.1")

    # test for invalid semver
    with pytest.raises(ValueError, match="invalid semantic version '42.0.1.2'"):
        semver.parse("42.0.1.2")



# Generated at 2022-06-21 09:20:27.722601
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    # Test cases from http://semver.org/#spec-item-11
    assert _Alpha('rc1') < _Alpha('rc2')
    assert _Alpha('rc1') < _Numeric('rc2')
    assert _Alpha('rc1') < _Alpha('rc10')

    # Test cases from http://semver.org/#spec-item-10
    assert _Alpha('rc1') < _Alpha('beta')
    assert _Alpha('beta') < _Alpha('alpha')

    # Additional tests
    assert _Alpha('rc') < _Alpha('rc1')
    assert _Alpha('rc1') < _Alpha('rc2')
    assert _Alpha('rc1') < _Alpha('rc10')
    assert _Alpha('rc1') < _Alpha('beta')
    assert _Alpha('beta') < _Alpha('alpha')
    assert _Alpha

# Generated at 2022-06-21 09:20:36.844368
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('1.0.0') >= '0.9.9'
    assert SemanticVersion('6.0.0') >= '1.0.0'
    assert SemanticVersion('2.3.0') >= '2.3.0'
    assert SemanticVersion('0.0.0') >= '0.0.0'
    assert SemanticVersion('1.1.1') >= '0.0.0'
    assert SemanticVersion('1.1.1') >= '2.0.0' is False
    assert SemanticVersion('1.1.1') >= '1.0.1'
    assert SemanticVersion('1.1.1') >= '1.1.0'
    assert SemanticVersion('1.0.0') >= '0.9.9'

# Generated at 2022-06-21 09:20:47.576813
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import datetime


# Generated at 2022-06-21 09:20:49.820299
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    test__Alpha___ne___0 = _Alpha(specifier='test')
    test__Alpha___ne___1 = _Alpha(specifier='foo')
    assert test__Alpha___ne___0 != test__Alpha___ne___1


# Generated at 2022-06-21 09:20:53.239286
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    version1 = SemanticVersion('10.0.0')
    version2 = SemanticVersion('10.0.0')
    assert not version1.__ne__(version2)



# Generated at 2022-06-21 09:20:58.794689
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():

    assert _Numeric("1") > _Numeric("0")
    assert _Numeric("1") > _Alpha("0")
    assert _Numeric("1") > _Alpha("a")
    assert _Numeric("0") > _Alpha("a")
    assert _Numeric("1") < _Alpha("a")



# Generated at 2022-06-21 09:21:09.859424
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == 'a'
    assert _Alpha('a') == _Alpha('a')


# Generated at 2022-06-21 09:21:11.599383
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    foo = _Alpha('bar')
    assert repr(foo) == repr('bar')



# Generated at 2022-06-21 09:21:14.857150
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(1) != 2
    assert _Numeric(1) != _Alpha('2')


# Generated at 2022-06-21 09:21:25.325604
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Valid versions
    # Major
    assert SemanticVersion('0').core == (0, 0, 0)
    assert SemanticVersion('0.0').core == (0, 0, 0)
    assert SemanticVersion('0.0.0').core == (0, 0, 0)
    # Minor
    assert SemanticVersion('1.0').core == (1, 0, 0)
    assert SemanticVersion('1.0.0').core == (1, 0, 0)
    # Patch
    assert SemanticVersion('1.1.1').core == (1, 1, 1)

    # Invalid versions
    # Major
    try:
        SemanticVersion('1')
    except ValueError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-21 09:21:30.594301
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    test_alpha = _Alpha(1)
    assert not test_alpha.__ne__(1)
    assert not test_alpha.__ne__('1')
    assert test_alpha.__ne__(2)
    assert test_alpha.__ne__('2')
    assert test_alpha.__ne__(_Numeric(1))


# Generated at 2022-06-21 09:21:37.584520
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    for p in ('1.2.3', '2.1.2', '2.2.1',
              '0.0.7', '1.0.0', '2.0.0',
              '1.2.3-alpha', '1.2.3-pre',
              '1.2.3+build', '1.2.3+build.2.b8f12d7',
              '1.2.3-alpha+build'):
        v = SemanticVersion(p)
        assert v.__ne__(p) is False
        assert v.__ne__(text_type(p)) is False

        p2 = p.replace('alpha', 'beta')
        v2 = SemanticVersion(p2)
        assert v2.__ne__(p2) is False
        assert v2.__

# Generated at 2022-06-21 09:21:41.299443
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1) == _Numeric(1)
    assert not _Numeric(1) == 5
    assert _Numeric(1) == _Numeric(3)
    assert _Numeric(1) == '3'


# Generated at 2022-06-21 09:21:48.601589
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    """Unit test for method __ge__ of class SemanticVersion"""

    def do_test(v1, v2, expected):
        """Perform a test for __ge__"""
        v1_obj = SemanticVersion(v1)
        v2_obj = SemanticVersion(v2)
        # pylint: disable=line-too-long
        actual = v1_obj.__ge__(v2_obj)
        # pylint: enable=line-too-long
        if actual != expected:
            print("FAILED: __ge__({v1:r}, {v2:r}) == {actual:r}, expected {expected:r}".format(
                v1=v1,
                v2=v2,
                actual=actual,
                expected=expected
            ))

    # Invalid versions
    do

# Generated at 2022-06-21 09:21:50.387702
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1234') == SemanticVersion('1234.0.0')

# Generated at 2022-06-21 09:21:53.146495
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != _Numeric(2)
    assert _Numeric(2) != _Numeric(3)
    assert _Numeric(3) != _Numeric(4)


# Generated at 2022-06-21 09:22:14.947707
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    """test__Numeric___repr__()"""
    assert repr(_Numeric('2')) == repr(2)
    assert repr(_Numeric('3')) == repr(3)


# Generated at 2022-06-21 09:22:25.031776
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    '''Ensures SemanticVersion is behaving as expected'''
    # Expect IOError as vstring is not provided
    try:
        SemanticVersion()
    except ValueError as e:
        assert 'invalid semantic version' in str(e)

    # Expect ValueError as vstring is not valid
    try:
        SemanticVersion('4.6.8')
    except ValueError as e:
        assert 'invalid semantic version' in str(e)

    # Reject I/O version
    try:
        SemanticVersion('>=2.0')
    except ValueError as e:
        assert 'invalid semantic version' in str(e)

    # Accept SemVer version and add 0's for non existent minor and patch versions

# Generated at 2022-06-21 09:22:27.605275
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    # Test for a greater than or equal to check
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.2')

    assert v1 >= v2


# Generated at 2022-06-21 09:22:29.538345
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('a')) == '_Alpha(\'a\')'


# Generated at 2022-06-21 09:22:41.643019
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    if not _Alpha('foo').__ne__('bar'):
        raise AssertionError

    if not _Alpha('foo').__ne__(b'bar'):
        raise AssertionError

    if not _Alpha('foo').__ne__(u'bar'):
        raise AssertionError

    if _Alpha('foo').__ne__(_Alpha('foo')):
        raise AssertionError

    if _Alpha('foo').__ne__('foo'):
        raise AssertionError

    if _Alpha('foo').__ne__(b'foo'):
        raise AssertionError

    if _Alpha('foo').__ne__(u'foo'):
        raise AssertionError

    if not _Alpha('foo').__ne__(_Alpha('bar')):
        raise AssertionError


# Generated at 2022-06-21 09:22:49.197033
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # it should correctly compare two _Alpha objects
    assert _Alpha('a') <= _Alpha('a')
    assert not _Alpha('a') <= _Alpha('b')
    # it should compare an _Alpha to a string
    assert not _Alpha('a') <= 'b'
    assert _Alpha('a') <= 'a'
    # it should raise ValueError if comparing a number to an _Alpha
    #  to support :ansible/ansible#56271
    try:
        _Alpha('a') <= _Numeric(1)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError for _Alpha(a) <= _Numeric(1)")


# Generated at 2022-06-21 09:22:55.374278
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('b') > _Alpha('a')
    assert _Alpha('a') < _Alpha('b')
    assert _Alpha('b') <= _Alpha('b')
    assert _Alpha('a') != _Alpha('b')
    assert _Alpha('a') != _Numeric(1)


# Generated at 2022-06-21 09:22:57.206346
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    n = _Numeric(1)
    assert repr(n) == '1'


# Generated at 2022-06-21 09:22:59.506100
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    assert (SemanticVersion("0.0.0") != SemanticVersion("0.0.1"))


# Generated at 2022-06-21 09:23:07.824624
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # Test different cases of __gt__
    assert _Alpha("1") > _Alpha("0")
    assert _Alpha("1") > _Alpha("0")
    assert _Alpha("1") > _Alpha("1") == False
    assert _Alpha("0") > _Alpha("1") == False
    assert _Alpha("1") > _Numeric("0")
    assert _Alpha("1") > _Numeric("0")
    assert _Alpha("1") > _Numeric("1") == False
    assert _Alpha("0") > _Numeric("1") == False
    assert _Alpha("1") > "0"
    assert _Alpha("1") > "0"
    assert _Alpha("1") > "1" == False
    assert _Alpha("0") > "1" == False
    assert _Alpha("1") > "0"
   

# Generated at 2022-06-21 09:23:45.455411
# Unit test for method __eq__ of class SemanticVersion

# Generated at 2022-06-21 09:23:49.358564
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    for specifier in [0, 1, 10, 100]:
        assert repr(_Numeric(specifier)) == repr(specifier)


# Generated at 2022-06-21 09:23:58.169514
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion("1.2.3-alpha.8") >= "1.2.3-alpha.8"
    assert SemanticVersion("1.2.3-alpha.8") >= "1.2.3"
    assert SemanticVersion("1.2.3-alpha.8") >= "1.2"
    assert SemanticVersion("1.2.3-alpha.8") >= "1"
    # AssertionError: assert False
    # assert SemanticVersion("1.2.3-alpha.8") >= "1.2.3-beta"

    # AssertionError: assert False
    # assert SemanticVersion("1.2.3-alpha.8") >= "1.2.3-alpha.8+abc"
    # AssertionError: assert False
    # assert SemanticVersion("1.2.

# Generated at 2022-06-21 09:24:08.521757
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    tmp_version = SemanticVersion('5.6.7')
    assert tmp_version._cmp('5.6.7') == 0
    assert tmp_version.__le__('5.6.7') == True
    assert tmp_version.__le__('5.6.8') == True
    assert tmp_version.__le__('5.6.6') == False
    assert tmp_version.__le__('5.5.7') == False
    assert tmp_version.__le__('4.6.7') == False
    assert tmp_version.__le__('6.6.7') == True
    assert tmp_version.__le__('5.7.7') == True
    assert tmp_version.__le__('5.6.7-alpha.1') == True

# Generated at 2022-06-21 09:24:14.755094
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    """
    Method that tests if __ge__ method works correctly
    """
    assert SemanticVersion("1.0.0") >= SemanticVersion("0.0.0")
    assert SemanticVersion("1.0.0") >= SemanticVersion("0.0.0")
    assert SemanticVersion("1.0.0") >= SemanticVersion("1.0.0")
    assert SemanticVersion("1.1.0") >= SemanticVersion("1.1.0")
    assert SemanticVersion("1.1.0") >= SemanticVersion("1.1.0-1.0")
    assert SemanticVersion("1.1.0") >= SemanticVersion("1.1.0+1.0")

# Generated at 2022-06-21 09:24:17.452676
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    import unittest
    class __Numeric___eq__(unittest.TestCase):
        def test__Numeric___eq__(self):
            self.assertFalse(_Numeric(6) == None)
    unittest.main()


# Generated at 2022-06-21 09:24:20.941869
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    a = SemanticVersion("1.2.3-4.5")
    assert a.vstring == "1.2.3-4.5"
    assert a.major == 1
    assert a.minor == 2
    assert a.patch == 3
    assert a.prerelease == (4, 5)
    assert a.buildmetadata == ()


# Generated at 2022-06-21 09:24:28.004156
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    # Test python 2 and 3
    import sys
    # Python 2
    if sys.version_info < (3, 0):
        ver_a = SemanticVersion('1.2.3')
        # Bytes
        ver_a_b = SemanticVersion(b'1.2.3')
        # Unicode
        ver_a_u = SemanticVersion(u'1.2.3')
        # Test if __eq__ allows bytes other than str
        assert ver_a == ver_a_b
        # Test if __eq__ allows unicode other than str
        assert ver_a == ver_a_u
    
    # Python 3
    if sys.version_info >= (3, 0):
        ver_a = SemanticVersion('1.2.3')
        # Bytes
        ver_a_b = SemanticVersion

# Generated at 2022-06-21 09:24:36.893043
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    # test
    _numeric = _Numeric(2)
    assert _numeric.__gt__(1) == True
    assert _numeric.__gt__(3) == False
    assert _numeric.__gt__('0') == True
    assert _numeric.__gt__('1') == True
    assert _numeric.__gt__('4') == False
    assert _numeric.__gt__(_Numeric(1)) == True
    assert _numeric.__gt__(_Numeric(3)) == False
    assert _numeric.__gt__(_Alpha('3')) == False
    assert _numeric.__gt__(_Alpha('5')) == False


# Generated at 2022-06-21 09:24:45.603631
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    import unittest

    class _NumericTest(unittest.TestCase):
        def test_version_integer_to_integer(self):
            v = _Numeric(1)
            self.assertTrue(v < 2)
            self.assertFalse(v < 1)
            self.assertFalse(v < 0)

        def test_version_string_to_string(self):
            v = _Numeric('1')
            self.assertTrue(v < '2')
            self.assertFalse(v < '1')
            self.assertFalse(v < '0')

        def test_version_integer_to_string(self):
            v = _Numeric(1)
            self.assertTrue(v < '2')
            self.assertFalse(v < '1')

# Generated at 2022-06-21 09:25:29.597366
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose = LooseVersion('0.1.0')
    semantic = SemanticVersion.from_loose_version(loose)
    assert isinstance(semantic, SemanticVersion)
    assert str(semantic) == '0.1.0'

    loose = LooseVersion('0.1.0.dev1')
    semantic = SemanticVersion.from_loose_version(loose)
    assert isinstance(semantic, SemanticVersion)
    assert str(semantic) == '0.1.0-dev1'

    loose = LooseVersion('0.1.0a2')
    semantic = SemanticVersion.from_loose_version(loose)
    assert isinstance(semantic, SemanticVersion)
    assert str(semantic) == '0.1.0-a2'

    loose = Loose

# Generated at 2022-06-21 09:25:35.166737
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) == 1
    assert not _Numeric(1) == 2
    assert not _Numeric(1) == _Alpha(1)
    assert not _Numeric(1) == '1'


# Generated at 2022-06-21 09:25:44.324155
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-21 09:25:51.581308
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    assert _Numeric(2) > _Numeric(1)
    assert _Numeric(1) > 0
    assert not _Numeric(1) == 0
    assert not 0 == _Numeric(1)
    assert not _Numeric(1) > 'a'
    try:
        _Numeric(1) > 'b'
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 09:25:54.219337
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha = _Alpha('a')
    str_alpha = _Alpha('b')
    number = _Numeric(1)
    assert alpha <= str_alpha
    assert alpha <= number



# Generated at 2022-06-21 09:25:57.753719
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.2.3")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert repr(semver) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-21 09:26:02.126399
# Unit test for constructor of class _Numeric
def test__Numeric():
    assert _Numeric(5) == _Numeric(5)
    assert _Numeric(5) != _Numeric(6)
    assert _Numeric(5) < _Numeric(6)
    assert _Numeric(5) <= _Numeric(6)
    assert _Numeric(6) > _Numeric(5)
    assert _Numeric(6) >= _Numeric(5)


# Generated at 2022-06-21 09:26:13.013019
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    This method tests if ``SemanticVersion`` can be created from a ``LooseVersion``
    """

    loose_versions = ['1.2.3', '2.3.4', '3.4.5']
    ambiguous_versions = ['1.2.3a', '2.3.4b', '3.4.5c']
    complex_versions = ['1.2.3-alpha.1.2+build1.2.3', '1.2.3-alpha.1.2+build1.2.3-alpha.1.2+build1.2.3', '1.2.3-alpha.1.2+build1.2.3']

    for loose_version in loose_versions:
        semantic_version = SemanticVersion.from_loose_version(LooseVersion(loose_version))

# Generated at 2022-06-21 09:26:21.298920
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # equal
    assert (_Alpha("a") > _Alpha("a")) == False
    # greater
    assert (_Alpha("b") > _Alpha("a")) == True
    assert (_Alpha("B") > _Alpha("a")) == True
    assert (_Alpha("b") > _Alpha("A")) == True
    assert (_Alpha("B") > _Alpha("A")) == True
    # less
    assert (_Alpha("a") > _Alpha("b")) == False
    assert (_Alpha("a") > _Alpha("B")) == False
    assert (_Alpha("A") > _Alpha("b")) == False
    assert (_Alpha("A") > _Alpha("B")) == False


# Generated at 2022-06-21 09:26:26.150074
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert _Alpha('1') > _Alpha('0')
    assert _Alpha('0') < _Alpha('1')
    assert _Alpha('1') > '0'
    assert _Alpha('0') < '1'
    assert '1' > _Alpha('0')
    assert '0' < _Alpha('1')

