

# Generated at 2022-06-21 09:17:02.249374
# Unit test for method __eq__ of class SemanticVersion

# Generated at 2022-06-21 09:17:05.446760
# Unit test for constructor of class _Alpha
def test__Alpha():
    text = 'A'
    a = _Alpha(text)
    if a.specifier != text:
        raise AssertionError("'a' doesn't match provided text")



# Generated at 2022-06-21 09:17:08.777563
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.2.3').__gt__('1.1.1') is True
    assert SemanticVersion('1.2.3').__gt__('1.2.3') is False
    assert SemanticVersion('1.2.3').__gt__('1.2.4') is False

# Generated at 2022-06-21 09:17:19.429315
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
    version1 = '1.2.3-alpha'
    version2 = '1.2.3-beta'
    version3 = '1.2.3'
    version4 = '1.2.4-beta'
    version5 = '2.0.0-beta'

    assert SemanticVersion(version1) != SemanticVersion(version2)
    assert SemanticVersion(version1) != SemanticVersion(version3)
    assert SemanticVersion(version1) != SemanticVersion(version4)
    assert SemanticVersion(version1) != SemanticVersion(version5)

    assert SemanticVersion(version2) != SemanticVersion(version1)
    assert SemanticVersion(version2) != SemanticVersion(version3)
    assert SemanticVersion(version2) != SemanticVersion(version4)
    assert SemanticVersion

# Generated at 2022-06-21 09:17:28.651260
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that it works with simple string
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version('1.2.3').vstring == '1.2.3'

    # Test that it works with LooseVersion object
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'

    # Test that it works with prerelease

# Generated at 2022-06-21 09:17:36.361353
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    """Unit test for method __lt__ of class _Alpha"""

    # _Alpha is __lt__ int
    assert not _Alpha(1) < 1

    # _Alpha is __lt__ str
    assert not _Alpha(1) < '1'

    # _Alpha is __lt__ _Alpha
    assert not _Alpha(1) < _Alpha('1')

    # _Alpha is not __lt__ _Numeric
    assert _Alpha('a') < _Numeric(1)

    # _Alpha is __lt__ _Alpha
    assert _Alpha('a') < _Alpha('b')


# Generated at 2022-06-21 09:17:43.044706
# Unit test for constructor of class _Alpha
def test__Alpha():
    a = _Alpha("1")
    assert a == "1"
    assert a < "2"
    assert a <= "2"
    assert a <= "1"
    assert a > "0"
    assert a >= "2"
    assert a >= "1"

    a = _Alpha("a")
    assert a == "a"
    assert a > "1"
    assert a >= "1"
    assert a >= "a"
    assert a < "b"
    assert a <= "1"
    assert a <= "a"


# Generated at 2022-06-21 09:17:47.189697
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    # same type
    assert _Alpha('a') != _Alpha('b')
    # same type, same value
    assert not _Alpha('a') != _Alpha('a')
    # different type
    assert not _Alpha('a') != 'a'


# Generated at 2022-06-21 09:17:54.522442
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    from ansible.module_utils.six import PY3
    assert SemanticVersion('1.1.1') <= SemanticVersion('2.2.2')
    assert SemanticVersion('1.2.1') <= SemanticVersion('1.2.2')
    assert SemanticVersion('1.1.1') <= SemanticVersion('1.1.1')
    assert SemanticVersion('0.0.5') <= SemanticVersion('2.2.2')
    assert SemanticVersion('0.0.5') <= SemanticVersion('10.0.0')
    assert SemanticVersion('0.0.5') <= SemanticVersion('0.0.5')
    assert SemanticVersion('2.2.2') >= SemanticVersion('0.0.5')
    assert SemanticVersion('1.2.2') >= SemanticVersion

# Generated at 2022-06-21 09:17:56.693836
# Unit test for method __lt__ of class SemanticVersion
def test_SemanticVersion___lt__():
    assert SemanticVersion("0.0.1") < SemanticVersion("0.0.2")


# Generated at 2022-06-21 09:18:13.098464
# Unit test for constructor of class SemanticVersion
def test_SemanticVersion():
    v1 = SemanticVersion()
    assert (v1.vstring == None)
    assert (v1.major == None and v1.minor == None and v1.patch == None)
    assert (v1.prerelease == () and v1.buildmetadata == ())

    v2 = SemanticVersion('0.0.0')
    assert (v2.vstring == '0.0.0')
    assert (v2.major == 0 and v2.minor == 0 and v2.patch == 0)
    assert (v2.prerelease == () and v2.buildmetadata == ())

    v3 = SemanticVersion('1.2.3-alpha.1+rc.2')
    assert (v3.vstring == '1.2.3-alpha.1+rc.2')

# Generated at 2022-06-21 09:18:21.311432
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('a') >= _Alpha('c')
    assert _Alpha('a') >= _Alpha('a')
    assert not _Alpha('a') >= _Alpha('A')
    assert not _Alpha('a') >= _Alpha('b')
    assert _Alpha('b') >= _Alpha('a')
    assert _Alpha('c') >= _Alpha('a')


# Generated at 2022-06-21 09:18:25.761910
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('0.0.1') == '0.0.1'
    assert SemanticVersion('0.0.1') != '0.0.2'
    assert SemanticVersion('0.0.1') != '0.0.0'

    # major
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert SemanticVersion('1.0.0') != '0.0.0'
    assert SemanticVersion('1.0.0') != '2.0.0'

    # minor
    assert SemanticVersion('0.1.0') == '0.1.0'
    assert SemanticVersion('0.1.0') != '0.0.0'
    assert SemanticVersion('0.1.0') != '0.2.0'

    #

# Generated at 2022-06-21 09:18:28.260634
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    assert repr(SemanticVersion('1.2.3')) == "SemanticVersion('1.2.3')"


# Generated at 2022-06-21 09:18:30.346815
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha("b")
    b = "b"
    assert(a.__ge__(b) is True)


# Generated at 2022-06-21 09:18:39.358470
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    spec_v1 = SemanticVersion('1.1.1')
    spec_v2 = SemanticVersion('1.1.1+a')
    spec_v3 = SemanticVersion('1.1.2')
    spec_v4 = SemanticVersion('1.2.1')
    spec_v5 = SemanticVersion('1.1.1-pre.1')
    spec_v6 = SemanticVersion('1.1.1-rc.1')
    spec_v7 = SemanticVersion('1.1.1-rc.2')
    spec_v8 = SemanticVersion('1.1.1-rc.1+a')
    spec_v9 = SemanticVersion('1.1.1-rc.1.1')

# Generated at 2022-06-21 09:18:46.604246
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    assert (_Alpha('a') > 'b') == False
    assert (_Alpha('a') > 'a') == False
    assert (_Alpha('b') > 'a') == True

    assert (_Alpha('a') > _Alpha('b')) == False
    assert (_Alpha('a') > _Alpha('a')) == False
    assert (_Alpha('b') > _Alpha('a')) == True

    assert (_Alpha('a') > _Numeric('1')) == True


# Generated at 2022-06-21 09:18:48.231502
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    n = _Numeric(1)
    assert(n == 1)



# Generated at 2022-06-21 09:18:57.847720
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    a = SemanticVersion()
    a.parse('1.0.0')
    assert a.major == 1
    assert a.minor == 0
    assert a.patch == 0
    assert a.prerelease == ()
    assert a.buildmetadata == ()

    b = SemanticVersion()
    b.parse('1.0.0')
    assert b.major == 1
    assert b.minor == 0
    assert b.patch == 0
    assert b.prerelease == ()
    assert b.buildmetadata == ()

    assert a == b

    c = SemanticVersion()
    c.parse('1.0.0-rc.1.2+meta.data')
    assert c.major == 1
    assert c.minor == 0
    assert c.patch == 0

# Generated at 2022-06-21 09:19:06.662808
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion("1.2.4") == "1.2.4"
    assert SemanticVersion("1.2.4") == SemanticVersion("1.2.4")
    assert not SemanticVersion("3.2.4") == "1.2.4"
    assert not SemanticVersion("1.2.4") == "3.2.4"
    assert not SemanticVersion("1.2.4") == "1.4.4"
    assert not SemanticVersion("1.4.4") == "1.2.4"



# Generated at 2022-06-21 09:19:21.415415
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    """Verify method __gt__ of class SemanticVersion"""
    base_version = SemanticVersion('1.2.3')
    greater_version = SemanticVersion('1.2.4')

    assert(base_version < greater_version)

    lesser_version = SemanticVersion('1.2.2')

    assert(base_version > lesser_version)



# Generated at 2022-06-21 09:19:32.988880
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-beta')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-rc')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.0-dev')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.-1')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.a')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.a')
    assert SemanticVersion('1.0.0') > SemanticVersion('1.0.a')

# Generated at 2022-06-21 09:19:34.434437
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    assert repr(_Numeric('1')) == '1'


# Generated at 2022-06-21 09:19:40.841850
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    assert _Alpha('') >= _Alpha(''), 'Fails for _Alpha(\'\') >= _Alpha(\'\')'
    assert _Alpha('a') >= _Alpha('a'), 'Fails for _Alpha(\'a\') >= _Alpha(\'a\')'
    assert not _Alpha('a') >= _Alpha('b'), 'Fails for not _Alpha(\'a\') >= _Alpha(\'b\')'
    assert _Alpha('a.a') >= _Alpha('a.a'), 'Fails for _Alpha(\'a.a\') >= _Alpha(\'a.a\')'
    assert not _Alpha('a.a') >= _Alpha('b.b'), 'Fails for not _Alpha(\'a.a\') >= _Alpha(\'b.b\')'
    assert _Alpha('a.a') >= _

# Generated at 2022-06-21 09:19:43.484514
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('') == ''

test__Alpha___eq__()


# Generated at 2022-06-21 09:19:44.976739
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    assert repr(_Alpha('a')) == "'a'"


# Generated at 2022-06-21 09:19:52.344284
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    """Unit test for method __le__ of class _Numeric"""
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert not _Numeric(2) <= _Numeric(1)

    assert _Numeric(1) <= 2
    assert _Numeric(1) <= 1
    assert not _Numeric(2) <= 1

    assert _Numeric(1) <= _Alpha('2')
    assert _Numeric(1) <= _Alpha('1')
    assert not _Numeric(2) <= _Alpha('1')


# Generated at 2022-06-21 09:19:55.738446
# Unit test for method __eq__ of class _Alpha
def test__Alpha___eq__():
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert not _Alpha('a') == _Alpha('b')
    assert not _Alpha('a') == 'b'


# Generated at 2022-06-21 09:20:03.298560
# Unit test for constructor of class _Alpha
def test__Alpha():
    t = _Alpha('alpha')
    assert t.specifier == 'alpha', "specifier error, expect alpha, get %s" % (t.specifier)
    assert repr(t) == "'alpha'", "repr error, expect 'alpha', get %s" % (repr(t))
    assert t == 'alpha', "_Alpha object equal error, expect 'alpha', get %s" % (t)
    assert t != 'beta', "_Alpha object not equal error, expect 'beta', get %s" % (t)
    assert t < 'beta', "_Alpha object less than error, expect 'beta', get %s" % (t)
    assert t <= 'beta', "_Alpha object less or equal than error, expect 'beta', get %s" % (t)

# Generated at 2022-06-21 09:20:07.820954
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert not _Numeric(1) < 'a'
    assert _Numeric(1) < 'b'
    assert _Numeric(1) < 2
    assert _Numeric(1) < _Numeric(4)
    assert _Numeric(1) < _Alpha('3')
    try:
        _Numeric(1) < 2.5
    except ValueError:
        assert True
    else:
        assert False

    try:
        _Numeric(1) < 1
    except ValueError:
        assert True
    else:
        assert False



# Generated at 2022-06-21 09:20:24.613035
# Unit test for method __repr__ of class SemanticVersion
def test_SemanticVersion___repr__():
    """__repr__() of an object should return a string showing the details of that object.

    In this case, it should return the string representation of the vstring attribute
    """
    assert repr(SemanticVersion('1.0.0')) == "SemanticVersion('1.0.0')"


# Generated at 2022-06-21 09:20:35.291598
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    #
    # Example 1
    #

    version_a = SemanticVersion('10.1.2')
    version_b = SemanticVersion('10.1.2')

    if not version_a >= version_b:
        msg = 'unexpected result'
        raise AssertionError(msg)

    #
    # Example 2
    #

    version_a = SemanticVersion('10.1.3')
    version_b = SemanticVersion('10.1.2')

    if not version_a >= version_b:
        msg = 'unexpected result'
        raise AssertionError(msg)

    #
    # Example 3
    #

    version_a = SemanticVersion('10.1.2')
    version_b = SemanticVersion('10.1.3')


# Generated at 2022-06-21 09:20:37.583536
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    # Unit test for method __gt__ of class _Alpha
    # Evaluation of __gt__
    assert _Alpha('b') > 'a'



# Generated at 2022-06-21 09:20:39.167590
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('1.0.0') != '1.0.0'


# Generated at 2022-06-21 09:20:49.245110
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    # 1 _Numeric instance is less than or equal another _Numeric instance with a greater int value.
    assert _Numeric('1').__le__(_Numeric('2')) is True
    # 2 _Numeric instance is less than or equal another _Numeric instance with the same int value.
    assert _Numeric('2').__le__(_Numeric('2')) is True
    # 3 _Numeric instance is not less than or equal another _Numeric instance with a lesser int value.
    assert _Numeric('3').__le__(_Numeric('2')) is False
    # 1 _Numeric instance is less than or equal another int with a greater value.
    assert _Numeric('1').__le__(2) is True
    # 2 _Numeric instance is less than or equal another int with the same value.

# Generated at 2022-06-21 09:20:52.806493
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    """Test method _Numeric.__eq__

    https://semver.org/#spec-item-11
    """
    assert _Numeric('3') == _Numeric('3')
    assert _Numeric('3') == 3



# Generated at 2022-06-21 09:21:00.279012
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    n1 = _Numeric("1")
    n2 = _Numeric("2")
    n3 = _Numeric("3")
    i1 = 1
    i2 = 2
    i3 = 3

    assert n1 < n2
    assert n1 < i2
    assert n1 < n3
    assert n1 < i3
    assert n3 > n2
    assert n3 > i2
    assert n3 > n1
    assert n3 > i1



# Generated at 2022-06-21 09:21:07.453206
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    # Test when other is numeric
    numeric = _Numeric(1)
    numeric2 = _Numeric(2)
    assert numeric <= numeric2

    # Test when other is numeric, but !=
    numeric2 = _Numeric(1)
    assert numeric <= numeric2

    # Test when other is numeric, but <
    numeric2 = _Numeric(0)
    assert not numeric <= numeric2

    # Test when other is alpha
    numeric2 = _Alpha('2')
    assert numeric <= numeric2

    # Test when other is alpha, but !=
    numeric2 = _Alpha('1')
    assert numeric <= numeric2

    # Test when other is alpha, but <
    numeric2 = _Alpha('0')
    assert not numeric <= numeric2

    # Test when other is int
    numeric2 = 2
    assert numeric <= numeric2

   

# Generated at 2022-06-21 09:21:17.508840
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-21 09:21:20.039439
# Unit test for method __repr__ of class _Numeric
def test__Numeric___repr__():
    actual = repr(_Numeric('1'))
    expected = repr(1)
    assert actual == expected
    # assert repr(_Numeric('1')) == repr(1)


# Generated at 2022-06-21 09:22:08.683046
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test case 1:
    # Test with missing build metadata
    # Expectation:
    # version to be valid
    version = '1.1.1'
    obj = SemanticVersion()
    obj.parse(version)
    assert obj.major == 1
    assert obj.minor == 1
    assert obj.patch == 1
    assert obj.prerelease == ()

    # Test case 2:
    # Test with missing pre-release versions
    # Expectation:
    # version to be valid
    version = '1.1.1+buildmetadata'
    obj = SemanticVersion()
    obj.parse(version)
    assert obj.major == 1
    assert obj.minor == 1
    assert obj.patch == 1
    assert obj.buildmetadata == ('buildmetadata',)
    assert obj.prerelease == ()

    # Test

# Generated at 2022-06-21 09:22:10.744176
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    klass = _Alpha('test')
    assert repr(klass) == repr('test')


# Generated at 2022-06-21 09:22:16.845845
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    # Testing against an Alpha
    assert _Numeric('1') < _Alpha('a')
    # Testing against a numeric
    assert _Numeric('1') < _Numeric('2')

    try:
        assert _Numeric('a') < _Numeric('b')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')


# Generated at 2022-06-21 09:22:26.567940
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """ Test method parse of class SemanticVersion """

    # Test the critical cases from the spec
    # https://semver.org/#spec-item-11
    S = SemanticVersion

    assert S('0.0.4').parse('1.0.0') > S('1.0.0').parse('0.9.0')
    assert S('1.0.0').parse('2.0.0') > S('2.0.0').parse('1.1.0')
    assert S('2.0.0').parse('2.1.0') > S('2.1.0').parse('2.0.0')
    assert S('2.1.0').parse('2.1.1') > S('2.1.1').parse('2.1.0')

    # Test prerelease version precedence with no build metadata

# Generated at 2022-06-21 09:22:37.666734
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion()
    version.parse('1.2.3')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()
    assert len(version.core) == 3
    assert isinstance(version.core[0], int)
    assert isinstance(version.core[1], int)
    assert isinstance(version.core[2], int)
    assert version.is_stable

    version = SemanticVersion()
    version.parse('1.2.3-beta.1')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Alpha('beta'), _Numeric('1'))
    assert version.buildmetadata

# Generated at 2022-06-21 09:22:39.416901
# Unit test for method __ne__ of class _Alpha
def test__Alpha___ne__():
    assert _Alpha('0') != '0'
    assert _Alpha('0') != _Alpha('1')



# Generated at 2022-06-21 09:22:41.866107
# Unit test for method __ne__ of class SemanticVersion
def test_SemanticVersion___ne__():
  assert SemanticVersion('1.2.3') != '1.2.3'


# Generated at 2022-06-21 09:22:50.023198
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Simple, identical versions
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.3')
    assert v1 <= v2
    assert v2 <= v1

    # Simple, similar versions
    v1 = SemanticVersion('1.2.3')
    v2 = SemanticVersion('1.2.4')
    assert v1 <= v2
    assert not v2 <= v1

    # Identical versions with different prerelease
    v1 = SemanticVersion('1.2.3-alpha.1')
    v2 = SemanticVersion('1.2.3-alpha.2')
    assert v1 <= v2
    assert not v2 <= v1

    # Identical versions with different build metadata

# Generated at 2022-06-21 09:22:56.036918
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    s = [_Numeric(1), _Numeric(2), _Numeric('1')]
    expected = [
        [True, True, True],
        [True, True, True],
        [True, True, True],
    ]
    for idx, l in enumerate(expected):
        for idy, e in enumerate(l):
            assert s[idx] <= s[idy] == e


# Generated at 2022-06-21 09:23:01.790730
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    test_1 = _Numeric('1')
    test_2 = _Numeric('2')
    test_3 = _Numeric('3')
    assert test_1 != test_2 != test_3 != test_1
    assert test_1 == _Numeric('1')
    assert test_2 == _Numeric('2')
    assert test_3 == _Numeric('3')


# Generated at 2022-06-21 09:23:44.808376
# Unit test for method __ge__ of class SemanticVersion
def test_SemanticVersion___ge__():
    assert SemanticVersion('2.0.0') >= '1.0.0'
    assert SemanticVersion('1.1.0') >= '1.0.0'
    assert SemanticVersion('1.0.1') >= '1.0.0'
    assert SemanticVersion('1.0.0') >= '1.0.0'

    assert SemanticVersion('1.0.0') >= SemanticVersion('1.0.0')

    assert SemanticVersion('2.0.0') >= SemanticVersion('1.0.0')
    assert SemanticVersion('1.1.0') >= SemanticVersion('1.0.0')
    assert SemanticVersion('1.0.1') >= SemanticVersion('1.0.0')

# Generated at 2022-06-21 09:23:48.899334
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert _Alpha("a") < _Alpha("b")
    assert not (_Alpha("b") < _Alpha("a"))
    assert not (_Alpha("b") < _Alpha("b"))


# Generated at 2022-06-21 09:23:52.929212
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    alpha = _Alpha('a')
    # Greater than a string
    assert alpha > 'a'
    assert not alpha > 'b'
    # Not greater than a number
    assert not alpha > 1
    assert alpha > 0


# Generated at 2022-06-21 09:23:59.632398
# Unit test for method __eq__ of class SemanticVersion
def test_SemanticVersion___eq__():
    assert SemanticVersion('1.0.0') == '1.0.0'
    assert not SemanticVersion('1.0.0') == '2.0.0'

    assert not SemanticVersion('1.0.0') == '1.0.0-beta'
    assert not SemanticVersion('1.0.0') == '1.0.0-beta+2'
    assert not SemanticVersion('1.0.0') == '1.0.0+1'

    assert SemanticVersion('1.0.0-alpha') == '1.0.0-alpha'
    assert not SemanticVersion('1.0.0-alpha') == '1.0.0-beta'
    assert not SemanticVersion('1.0.0-alpha') == '1.0.0-beta+1'

    assert Sem

# Generated at 2022-06-21 09:24:08.668818
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric('1')
    assert _Numeric(1) <= _Alpha('1')
    assert _Numeric(1) <= _Alpha('2')
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 2
    assert not _Numeric(2) <= _Numeric(1)
    assert not _Numeric(2) <= 2
    assert not _Numeric(2) <= _Alpha('1')
    try:
        _Numeric(1) <= '1'
        assert False
    except ValueError:
        pass



# Generated at 2022-06-21 09:24:12.639024
# Unit test for method __gt__ of class _Alpha
def test__Alpha___gt__():
    a = _Alpha('alpha')
    b = _Alpha('beta')

    assert a < b
    assert a <= b
    assert b > a
    assert b >= a

    a = _Alpha('alpha')
    b = _Alpha('alpha')

    assert a == b
    assert a >= b
    assert a <= b

    a = _Alpha('alpha')
    b = _Alpha('beta')

    assert not a == b
    assert a != b


# Generated at 2022-06-21 09:24:14.088205
# Unit test for method __ge__ of class _Alpha
def test__Alpha___ge__():
    a = _Alpha('test')
    assert a >= 'test'


# Generated at 2022-06-21 09:24:18.419383
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert not _Numeric(1) == _Numeric(1)
    assert not _Numeric(3) == _Alpha("3")
    assert not _Numeric("3") == 3
    assert _Numeric("3") == _Numeric("3")
    assert _Numeric("1") == _Alpha("1")
    assert _Numeric("1") != 2
    assert not _Numeric("1") != 1


# Generated at 2022-06-21 09:24:25.605096
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric('1') < _Numeric('2')
    assert not (_Numeric('2') < _Numeric('1'))
    assert _Numeric('1') < _Numeric('2.0')
    assert not (_Numeric('2.0') < _Numeric('1'))
    assert _Numeric('1') < _Numeric('1.0')
    assert not (_Numeric('1.0') < _Numeric('1'))
    assert _Numeric('2') < _Numeric('2.0')
    assert not (_Numeric('2.0') < _Numeric('2'))
    assert _Numeric('2') < _Numeric('2')
    assert not (_Numeric('2') < _Numeric('2'))
    assert _Numeric('2') > _Numeric('1')
   

# Generated at 2022-06-21 09:24:30.683448
# Unit test for method __eq__ of class _Numeric
def test__Numeric___eq__():
    assert _Numeric(0) == _Numeric(0)
    assert _Numeric(1) == _Numeric(1)
    assert not _Numeric(0) == _Numeric(1)
    assert not _Numeric(1) == _Numeric(0)

    assert _Numeric(0) == 0
    assert _Numeric(1) == 1
    assert not _Numeric(0) == 1
    assert not _Numeric(1) == 0

    assert not _Numeric(0) == _Alpha(0)
    assert not _Numeric(1) == _Alpha('1')

    assert not _Numeric(0) == _Alpha(0)


# Generated at 2022-06-21 09:25:11.282064
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('1.2.3') <= SemanticVersion('2.0.0')
    assert not (SemanticVersion('1.2.3') <= SemanticVersion('1.2.0'))
    assert SemanticVersion('1.2.3') <= SemanticVersion('1.2.3')
    assert not (SemanticVersion('1.2.3') <= SemanticVersion('1.2.3-beta.4'))
    assert SemanticVersion('1.2.3') <= SemanticVersion('1.2.3-beta.4+sha.5678901')
    assert SemanticVersion('1.2.3') <= SemanticVersion('1.2.3+sha.5678901')


# Generated at 2022-06-21 09:25:20.790365
# Unit test for method __gt__ of class SemanticVersion
def test_SemanticVersion___gt__():
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.2')
    assert SemanticVersion('1.2.1') > SemanticVersion('1.2.0')
    assert SemanticVersion('1.1.0') > SemanticVersion('1.0.0')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.2-alpha')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.2-alpha.1')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.1')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.2.1-alpha')
    assert SemanticVersion('1.2.3') > SemanticVersion('1.1.0')

# Generated at 2022-06-21 09:25:28.777455
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    assert SemanticVersion('0.0.1').__le__(SemanticVersion('0.0.1'))
    assert SemanticVersion('0.0.1').__le__(SemanticVersion('0.0.2'))
    assert SemanticVersion('0.0.1').__le__(SemanticVersion('0.0.3'))
    assert SemanticVersion('0.1.1').__le__(SemanticVersion('0.2.2'))
    assert SemanticVersion('0.1.1').__le__(SemanticVersion('1.2.2'))

    assert not SemanticVersion('0.0.2').__le__(SemanticVersion('0.0.1'))
    assert not SemanticVersion('0.0.3').__le__(SemanticVersion('0.0.2'))
   

# Generated at 2022-06-21 09:25:33.291132
# Unit test for method __repr__ of class _Alpha
def test__Alpha___repr__():
    test_cases = [
        ('test', "_Alpha('test')"),
        ('1', "_Alpha('1')"),
    ]
    for specifier, result in test_cases:
        assert repr(_Alpha(specifier)) == result


# Generated at 2022-06-21 09:25:43.083703
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # Version with prerelease field
    test_version_1 = SemanticVersion('1.2.3-rc.6')
    # Same version with prerelease field
    test_version_2 = SemanticVersion('1.2.3-rc.6')

    # Test if versions are equal
    assert test_version_1 == test_version_2
    # Test the <= operator
    assert test_version_1 <= test_version_2

    # Version with prerelease field
    test_version_1 = SemanticVersion('1.2.3-rc.6')
    # Version with prerelease field
    test_version_2 = SemanticVersion('1.2.3-rc.7')

    # Test if versions are equal
    assert test_version_1 != test_version_2
    # Test the <= operator
    assert test_version_

# Generated at 2022-06-21 09:25:47.460421
# Unit test for method __le__ of class SemanticVersion
def test_SemanticVersion___le__():
    # test_SemanticVersion___le_____self_other___self_eq_other
    assert SemanticVersion('1.0.0') <= SemanticVersion('1.0.0')
    # test_SemanticVersion___le_____self_other___self_lt_other
    assert not (SemanticVersion('1.0.0') <= SemanticVersion('1.0.1'))
    # test_SemanticVersion___le_____self_other___self_gt_other
    assert SemanticVersion('1.0.1') <= SemanticVersion('1.0.0')


# Generated at 2022-06-21 09:25:58.396943
# Unit test for method __lt__ of class SemanticVersion

# Generated at 2022-06-21 09:26:02.097742
# Unit test for method __gt__ of class _Numeric
def test__Numeric___gt__():
    numeric = _Numeric('01')
    assert numeric.__gt__(0) == True
    assert numeric.__gt__(1) == False
    assert numeric.__gt__(2) == False
    try:
        numeric.__gt__('a')
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-21 09:26:04.677297
# Unit test for method __ne__ of class _Numeric
def test__Numeric___ne__():
    assert _Numeric(1) != 1
    assert _Numeric(1) != _Numeric(2)


# Generated at 2022-06-21 09:26:11.335191
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    """Unit test for method __lt__ of class _Numeric"""
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) > _Numeric(0)
    assert _Numeric(1) == _Numeric(1)
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) >= _Numeric(1)
    assert _Numeric(1) != _Numeric(2)
