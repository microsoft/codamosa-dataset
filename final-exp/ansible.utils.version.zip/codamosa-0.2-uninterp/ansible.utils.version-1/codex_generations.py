

# Generated at 2022-06-17 15:46:05.947811
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test valid version strings
    assert SemanticVersion('0.0.0').core == (0, 0, 0)
    assert SemanticVersion('0.0.0').prerelease == ()
    assert SemanticVersion('0.0.0').buildmetadata == ()
    assert SemanticVersion('0.0.0').is_prerelease is False
    assert SemanticVersion('0.0.0').is_stable is False

    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    assert SemanticVersion('1.2.3').prerelease == ()
    assert SemanticVersion('1.2.3').buildmetadata == ()
    assert SemanticVersion('1.2.3').is_prerelease is False
    assert SemanticVersion('1.2.3').is_stable is True


# Generated at 2022-06-17 15:46:14.817442
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test valid semantic version strings
    assert SemanticVersion('1.0.0').core == (1, 0, 0)
    assert SemanticVersion('1.0.0').prerelease == ()
    assert SemanticVersion('1.0.0').buildmetadata == ()
    assert SemanticVersion('1.0.0-alpha').core == (1, 0, 0)
    assert SemanticVersion('1.0.0-alpha').prerelease == (_Alpha('alpha'),)
    assert SemanticVersion('1.0.0-alpha').buildmetadata == ()
    assert SemanticVersion('1.0.0-alpha.1').core == (1, 0, 0)
    assert SemanticVersion('1.0.0-alpha.1').prerelease == (_Alpha('alpha'), _Numeric('1'))

# Generated at 2022-06-17 15:46:19.700521
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion object
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver.vstring == '1.2.3'

    # Test with a string that has a prerelease
    semver = SemanticVersion.from_loose_version('1.2.3-alpha')
    assert semver.vstring == '1.2.3-alpha'

    # Test with a string that has a build metadata
    semver = SemanticVersion.from_loose_version('1.2.3+build.1')

# Generated at 2022-06-17 15:46:23.870285
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:46:27.697402
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-17 15:46:36.378082
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test valid semver
    assert SemanticVersion('1.2.3').major == 1
    assert SemanticVersion('1.2.3').minor == 2
    assert SemanticVersion('1.2.3').patch == 3
    assert SemanticVersion('1.2.3').prerelease == ()
    assert SemanticVersion('1.2.3').buildmetadata == ()

    # Test valid semver with prerelease
    assert SemanticVersion('1.2.3-alpha.1').major == 1
    assert SemanticVersion('1.2.3-alpha.1').minor == 2
    assert SemanticVersion('1.2.3-alpha.1').patch == 3
    assert SemanticVersion('1.2.3-alpha.1').prerelease == (_Alpha('alpha'), _Numeric('1'))

# Generated at 2022-06-17 15:46:47.801384
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5')) == SemanticVersion('1.2.3-4.5')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4')) == SemanticVersion('1.2.3+4')
   

# Generated at 2022-06-17 15:46:54.025399
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert not _Alpha('b') <= _Alpha('a')
    assert not _Alpha('b') <= 'a'
    assert _Alpha('a') <= _Numeric(1)
    assert not _Alpha('a') <= _Numeric(0)
    assert not _Alpha('b') <= _Numeric(1)


# Generated at 2022-06-17 15:47:06.366663
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:47:15.922601
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that a LooseVersion is converted to a SemanticVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    # Test that a LooseVersion with a prerelease is converted to a SemanticVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')

    # Test that a LooseVersion with a build metadata is converted to a SemanticVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')

    # Test that a LooseVersion with a prerelease and build metadata is converted to a SemanticVersion
    assert Semantic

# Generated at 2022-06-17 15:47:36.344811
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-17 15:47:49.028950
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for valid input
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:47:58.439854
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    # Test with a string
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')

    # Test with a non-LooseVersion
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with a LooseVersion with non-integer values

# Generated at 2022-06-17 15:48:05.671436
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion object
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    # Test with a string and prerelease

# Generated at 2022-06-17 15:48:14.949733
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    loose_version = LooseVersion('1.2.3-alpha')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3-alpha'

    loose_version = LooseVersion('1.2.3-alpha.1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3-alpha.1'

    loose_version = LooseVersion('1.2.3-alpha.1.2')

# Generated at 2022-06-17 15:48:25.624902
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+build')) == SemanticVersion('1.0.0+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha+build')) == SemanticVersion('1.0.0-alpha+build')

# Generated at 2022-06-17 15:48:33.960960
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.3'

    loose_version = LooseVersion('1.2.3-alpha.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.3-alpha.1'

    loose_version = LooseVersion('1.2.3+build.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.3+build.1'

    loose_version = LooseVersion('1.2.3-alpha.1+build.1')
    semantic_

# Generated at 2022-06-17 15:48:48.365311
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'

    # Test with a string that is not a LooseVersion
    try:
        SemanticVersion.from_loose_version('1.2.3.4')
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    # Test with a string that has non-integer values

# Generated at 2022-06-17 15:49:00.508523
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2')) == SemanticVersion('1.2.3-alpha.1.2')

# Generated at 2022-06-17 15:49:06.901964
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for correct conversion of LooseVersion to SemanticVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0.3.7')) == SemanticVersion('1.0.0-0.3.7')

# Generated at 2022-06-17 15:49:27.100846
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')

# Generated at 2022-06-17 15:49:35.940971
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')

# Generated at 2022-06-17 15:49:44.697088
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for valid input
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:49:55.143440
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5')) == SemanticVersion('1.2.3-4.5')

# Generated at 2022-06-17 15:50:07.579493
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2')) == SemanticVersion('1.2.3-alpha.1.2')

# Generated at 2022-06-17 15:50:15.294684
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for valid LooseVersion
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    # Test for invalid LooseVersion
    loose_version = LooseVersion('1.2.3.4')
    try:
        SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test for invalid LooseVersion
    loose_version = LooseVersion('1.2.3.4.5')
    try:
        SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        pass

# Generated at 2022-06-17 15:50:21.015231
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2')) == SemanticVersion('1.2.3-alpha.1.2')

# Generated at 2022-06-17 15:50:33.904320
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0.3.7')) == SemanticVersion('1.0.0-0.3.7')

# Generated at 2022-06-17 15:50:48.903048
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2')) == SemanticVersion('1.2.3-alpha.1.2')

# Generated at 2022-06-17 15:50:58.277648
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.0.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.0.0'

    # Test with a string
    loose_version = '1.0.0'
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.0.0'

    # Test with a string that has a prerelease
    loose_version = '1.0.0-beta.1'
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.0.0-beta.1'

    # Test with

# Generated at 2022-06-17 15:51:23.062480
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    # Test with a string
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')

    # Test with a non LooseVersion
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with a LooseVersion with a non integer version

# Generated at 2022-06-17 15:51:35.789245
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.2.3'

    # Test with a string
    loose_version = '1.2.3'
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.2.3'

    # Test with a string that contains a prerelease
    loose_version = '1.2.3-alpha.1'
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.2.3-alpha.1'

    # Test with

# Generated at 2022-06-17 15:51:45.754810
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'

    # Test with a non-LooseVersion
    try:
        SemanticVersion.from_loose_version(1)
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with a LooseVersion with non-integer values

# Generated at 2022-06-17 15:51:57.064753
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3
    from ansible.module_utils.compat.version import LooseVersion

    # Test for valid LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.2.3'

    # Test for invalid LooseVersion
    loose_version = LooseVersion('1.2.3.4')
    if PY3:
        with pytest.raises(ValueError):
            SemanticVersion.from_loose_version(loose_version)
    else:
        semver = SemanticVersion.from_loose_version(loose_version)
        assert semver.vstring == '1.2.3'

# Generated at 2022-06-17 15:52:08.892089
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:52:17.664505
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0.3.7')) == SemanticVersion('1.0.0-0.3.7')

# Generated at 2022-06-17 15:52:29.310397
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5.6')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5.6.7')) == SemanticVersion('1.2.3')

# Generated at 2022-06-17 15:52:40.213509
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build')) == SemanticVersion('1.2.3-alpha.1+build')

# Generated at 2022-06-17 15:52:51.375321
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-17 15:52:59.554009
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')

# Generated at 2022-06-17 15:54:13.221221
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-17 15:54:24.132917
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:54:32.012002
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a valid LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with a valid LooseVersion with prerelease
    loose_version = LooseVersion('1.2.3-alpha')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3-alpha'

    # Test with a valid LooseVersion with buildmetadata
    loose_version = LooseVersion('1.2.3+build.1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3+build.1'

   

# Generated at 2022-06-17 15:54:43.266579
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'

    # Test with non LooseVersion
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with non LooseVersion string

# Generated at 2022-06-17 15:54:53.742364
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.3'

    # Test with a string
    loose_version = '1.2.3'
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.2.3'

    # Test with a non LooseVersion
    loose_version = '1.2.3'
    try:
        SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        pass
    else:
        assert False, "Should have raised ValueError"

    # Test with a non string
    loose_version

# Generated at 2022-06-17 15:55:00.246108
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    # Test with a string
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')

    # Test with a non-LooseVersion
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    except ValueError:
        pass
    else:
        assert False

    # Test with a non-LooseVersion string
    try:
        SemanticVersion.from_loose_version('1.2.3.4')
    except ValueError:
        pass

# Generated at 2022-06-17 15:55:07.629955
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with LooseVersion
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    loose_version = LooseVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3-alpha.1')

    loose_version = LooseVersion('1.2.3+build.1')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3+build.1')

    loose_version = LooseVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:55:12.889915
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.2.3'

    # Test with a LooseVersion with a prerelease
    loose_version = LooseVersion('1.2.3-alpha.1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.2.3-alpha.1'

    # Test with a LooseVersion with a build metadata
    loose_version = LooseVersion('1.2.3+build.1')
    semver = SemanticVersion.from_loose

# Generated at 2022-06-17 15:55:24.281208
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+build')) == SemanticVersion('1.0.0+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha+build')) == SemanticVersion('1.0.0-alpha+build')

# Generated at 2022-06-17 15:55:33.515752
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for valid input
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2')) == SemanticVersion('1.2.3-alpha.1.2')