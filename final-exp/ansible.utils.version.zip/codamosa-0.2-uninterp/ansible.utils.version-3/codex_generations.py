

# Generated at 2022-06-17 15:45:59.300454
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3

    # Test for invalid input
    # Test for non LooseVersion input
    try:
        SemanticVersion.from_loose_version(None)
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    # Test for non integer values
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.2.3a'))
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

    # Test for non integer values
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.2.3.a'))
    except ValueError:
        pass
    else:
        assert False, "Expected ValueError"

   

# Generated at 2022-06-17 15:46:10.389817
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < _Numeric(1.1)
    assert _Numeric(1) < _Numeric('2')
    assert _Numeric(1) < _Numeric('1.1')
    assert _Numeric(1) < 2
    assert _Numeric(1) < 1.1
    assert _Numeric(1) < _Alpha('2')
    assert _Numeric(1) < _Alpha('1.1')
    assert _Numeric(1) < _Alpha('a')
    assert _Numeric(1) < _Alpha('1a')
    assert _Numeric(1) < _Alpha('a1')
    assert _Numeric(1) < _Alpha('1a1')
    assert _Numeric(1) < _Alpha

# Generated at 2022-06-17 15:46:20.342310
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(3)
    assert _Numeric(1) <= _Numeric(4)
    assert _Numeric(1) <= _Numeric(5)
    assert _Numeric(1) <= _Numeric(6)
    assert _Numeric(1) <= _Numeric(7)
    assert _Numeric(1) <= _Numeric(8)
    assert _Numeric(1) <= _Numeric(9)
    assert _Numeric(1) <= _Numeric(10)
    assert _Numeric(1) <= _Numeric(11)
    assert _Numeric(1) <= _Numeric(12)

# Generated at 2022-06-17 15:46:31.588748
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for valid input
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')

# Generated at 2022-06-17 15:46:43.381330
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(1.0)
    assert _Numeric(1) <= _Numeric('1')
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 1.0
    assert _Numeric(1) <= '1'
    assert _Numeric(1) <= _Alpha('1')
    assert _Numeric(1) <= _Alpha('2')
    assert _Numeric(1) <= _Alpha('1.0')
    assert _Numeric(1) <= _Alpha('1')
    assert _Numeric(1) <= _Alpha('2')
    assert _Numeric(1) <= _Alpha('1.0')

# Generated at 2022-06-17 15:46:52.846668
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-17 15:47:03.550569
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for valid input
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build')) == Sem

# Generated at 2022-06-17 15:47:14.676682
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1+build.1')) == SemanticVersion('1.0.0-alpha.1+build.1')

# Generated at 2022-06-17 15:47:23.101823
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'

    # Test with a non LooseVersion
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with a LooseVersion with non integer values

# Generated at 2022-06-17 15:47:32.493324
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert _Numeric(1) < _Numeric(2)
    assert _Numeric(1) < _Numeric('2')
    assert _Numeric(1) < 2
    assert _Numeric(1) < '2'
    assert not _Numeric(1) < _Numeric(1)
    assert not _Numeric(1) < _Numeric('1')
    assert not _Numeric(1) < 1
    assert not _Numeric(1) < '1'
    assert not _Numeric(2) < _Numeric(1)
    assert not _Numeric(2) < _Numeric('1')
    assert not _Numeric(2) < 1
    assert not _Numeric(2) < '1'
    assert not _Numeric(1) < _Alpha('1')

# Generated at 2022-06-17 15:47:54.913298
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:48:04.840162
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2.3')) == SemanticVersion('1.2.3-alpha.1.2.3')

# Generated at 2022-06-17 15:48:09.688267
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Alpha('1')
    assert _Numeric(1) <= _Alpha('2')
    assert _Numeric(1) <= 1
    assert _Numeric(1) <= 2
    assert not _Numeric(2) <= _Numeric(1)
    assert not _Numeric(2) <= _Alpha('1')
    assert not _Numeric(2) <= 1


# Generated at 2022-06-17 15:48:18.076190
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert not _Alpha('b') <= _Alpha('a')
    assert not _Alpha('b') <= 'a'
    assert _Alpha('a') <= _Numeric(1)
    assert not _Alpha('b') <= _Numeric(1)
    assert not _Alpha('a') <= _Numeric(2)
    assert not _Alpha('b') <= _Numeric(2)


# Generated at 2022-06-17 15:48:28.389799
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('A')
    assert _Alpha('a') <= _Alpha('B')
    assert _Alpha('a') <= _Alpha('1')
    assert _Alpha('a') <= _Alpha('2')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= 'A'
    assert _Alpha('a') <= 'B'
    assert _Alpha('a') <= '1'
    assert _Alpha('a') <= '2'
    assert 'a' <= _Alpha('a')
    assert 'a' <= _Alpha('b')
    assert 'a' <= _Alpha('A')
    assert 'a' <= _

# Generated at 2022-06-17 15:48:38.304377
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with valid LooseVersion
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    # Test with invalid LooseVersion
    loose_version = LooseVersion('1.2.3a')
    try:
        SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # Test with non LooseVersion
    try:
        SemanticVersion.from_loose_version('1.2.3')
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')


# Generated at 2022-06-17 15:48:48.323883
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils.semver import SemanticVersion
    # Test for valid input
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-alpha")) == SemanticVersion("1.0.0-alpha")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-alpha.1")) == SemanticVersion("1.0.0-alpha.1")

# Generated at 2022-06-17 15:49:00.510980
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2')) == SemanticVersion('1.2.3-alpha.1.2')

# Generated at 2022-06-17 15:49:06.941182
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+build.1')) == SemanticVersion('1.0.0+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1+build.1')) == SemanticVersion('1.0.0-alpha.1+build.1')

# Generated at 2022-06-17 15:49:17.404811
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)
    assert _Numeric(1) <= _Numeric(2)

# Generated at 2022-06-17 15:49:34.086161
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build')) == SemanticVersion('1.2.3-alpha.1+build')

# Generated at 2022-06-17 15:49:48.836761
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2')) == SemanticVersion('1.2.3-alpha.1.2')

# Generated at 2022-06-17 15:50:01.514789
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')

# Generated at 2022-06-17 15:50:11.968386
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for invalid input
    try:
        SemanticVersion.from_loose_version(None)
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid input not detected")

    try:
        SemanticVersion.from_loose_version(1)
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid input not detected")

    try:
        SemanticVersion.from_loose_version(LooseVersion("1.0.0"))
    except ValueError:
        pass
    else:
        raise AssertionError("Invalid input not detected")

    # Test for valid input
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")

# Generated at 2022-06-17 15:50:22.899549
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'

    # Test with a string with a prerelease
    semver = SemanticVersion.from_loose_version('1.2.3-alpha.1')
    assert semver == '1.2.3-alpha.1'

    # Test with a string with a buildmetadata
    semver = SemanticVersion.from_loose_version('1.2.3+build.1')

# Generated at 2022-06-17 15:50:31.409923
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert not _Alpha('b') <= _Alpha('a')
    assert not _Alpha('b') <= 'a'
    assert not _Alpha('b') <= _Numeric('1')
    assert not _Alpha('b') <= 1


# Generated at 2022-06-17 15:50:40.107076
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    loose_version = LooseVersion('1.2.3-alpha')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3-alpha'

    loose_version = LooseVersion('1.2.3-alpha+build')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3-alpha+build'

    loose_version = LooseVersion('1.2.3+build')

# Generated at 2022-06-17 15:50:51.965221
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-1.alpha')) == Semantic

# Generated at 2022-06-17 15:50:58.654925
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert not _Alpha('b') <= _Alpha('a')
    assert not _Alpha('b') <= 'a'
    assert not 'a' <= _Alpha('b')


# Generated at 2022-06-17 15:51:10.392531
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    # Test with a string
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')

    # Test with a non LooseVersion
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with a LooseVersion with non integer values

# Generated at 2022-06-17 15:51:24.245714
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')

# Generated at 2022-06-17 15:51:35.971603
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5')) == SemanticVersion('1.2.3-4.5')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4')) == SemanticVersion('1.2.3+4')
   

# Generated at 2022-06-17 15:51:41.601463
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion object
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'

    # Test with a string that has a prerelease
    semver = SemanticVersion.from_loose_version('1.2.3-alpha')
    assert semver == '1.2.3-alpha'

    # Test with a string that has a buildmetadata
    semver = SemanticVersion.from_loose_version('1.2.3+build.1')

# Generated at 2022-06-17 15:51:51.630500
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5')) == SemanticVersion('1.2.3-4.5')
   

# Generated at 2022-06-17 15:52:00.908114
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')

# Generated at 2022-06-17 15:52:13.595393
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha1')) == SemanticVersion('1.2.3-alpha1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build1')) == SemanticVersion('1.2.3+build1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha1+build1')) == SemanticVersion('1.2.3-alpha1+build1')

# Generated at 2022-06-17 15:52:23.140726
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a valid LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')

# Generated at 2022-06-17 15:52:32.506788
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-17 15:52:41.871376
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'

    # Test with a string that has a prerelease
    semver = SemanticVersion.from_loose_version('1.2.3-alpha.1')
    assert semver == '1.2.3-alpha.1'

    # Test with a string that has a buildmetadata
    semver = SemanticVersion.from_loose_version('1.2.3+build.1')

# Generated at 2022-06-17 15:52:50.649991
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')

# Generated at 2022-06-17 15:53:12.493981
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'

    # Test with a non-LooseVersion
    try:
        SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    except ValueError:
        pass
    else:
        assert False, 'Expected ValueError'

    # Test with a LooseVersion with non-integer values

# Generated at 2022-06-17 15:53:20.646638
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0.3.7')) == SemanticVersion('1.0.0-0.3.7')

# Generated at 2022-06-17 15:53:30.002415
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')

# Generated at 2022-06-17 15:53:41.212122
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.2.3'

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver.vstring == '1.2.3'

    # Test with a non-LooseVersion
    try:
        SemanticVersion.from_loose_version(1)
    except ValueError as e:
        assert str(e) == "1 is not a LooseVersion"
    else:
        assert False, "Expected ValueError"

    # Test with a LooseVersion with non-integer values

# Generated at 2022-06-17 15:53:49.734310
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a valid LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    # Test with a valid LooseVersion with prerelease
    loose_version = LooseVersion('1.2.3-alpha.1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == (_Alpha('alpha'), _Numeric('1'))
   

# Generated at 2022-06-17 15:54:00.815601
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')

# Generated at 2022-06-17 15:54:10.336857
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
   

# Generated at 2022-06-17 15:54:21.923919
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    # Test with a LooseVersion with a prerelease
    loose_version = LooseVersion('1.2.3-alpha')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == (_Alpha('alpha'),)
    assert semver.buildmetadata == ()



# Generated at 2022-06-17 15:54:30.813593
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion object
    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.2.3')

    # Test with a string
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')

    # Test with a string that has a prerelease
    assert SemanticVersion.from_loose_version('1.2.3-alpha') == SemanticVersion('1.2.3-alpha')

    # Test with a string that has a buildmetadata
    assert SemanticVersion.from_loose_version('1.2.3+build') == SemanticVersion('1.2.3+build')

    # Test with a string that has a prerelease

# Generated at 2022-06-17 15:54:36.566588
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')

# Generated at 2022-06-17 15:55:06.428274
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')

# Generated at 2022-06-17 15:55:18.405471
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3'
    assert semver.is_stable

    # Test with a string
    semver = SemanticVersion.from_loose_version('1.2.3')
    assert semver == '1.2.3'
    assert semver.is_stable

    # Test with a SemanticVersion
    semver = SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    assert semver == '1.2.3'
    assert semver.is_stable

    # Test with a non-LooseVersion

# Generated at 2022-06-17 15:55:27.662849
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0.3.7')) == SemanticVersion('1.0.0-0.3.7')

# Generated at 2022-06-17 15:55:33.697146
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion
    from ansible.module_utils.six.moves import zip

    for vstring in ('1.2.3', '1.2.3-alpha', '1.2.3-alpha.1', '1.2.3+build', '1.2.3-alpha+build', '1.2.3-alpha.1+build'):
        loose_version = LooseVersion(vstring)
        semver = SemanticVersion.from_loose_version(loose_version)
        assert semver.vstring == vstring
        assert semver.major == loose_version.version[0]
        assert semver.minor == loose_version.version[1]
        assert semver.patch == loose_version.version[2]