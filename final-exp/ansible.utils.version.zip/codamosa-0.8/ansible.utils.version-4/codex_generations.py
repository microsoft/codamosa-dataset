

# Generated at 2022-06-11 18:42:35.121224
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    s = SemanticVersion('2.3.4')
    assert s.major == 2
    assert s.minor == 3
    assert s.patch == 4
    assert s.core == (2, 3, 4)
    assert s.prerelease == ()
    assert s.buildmetadata == ()

    s = SemanticVersion('2.3.4-alpha1')
    assert s.major == 2
    assert s.minor == 3
    assert s.patch == 4
    assert s.core == (2, 3, 4)
    assert s.prerelease == (_Alpha('alpha1'),)
    assert s.buildmetadata == ()

    s = SemanticVersion('2.3.4-alpha1.beta1')
    assert s.major == 2
    assert s.minor == 3
    assert s.patch == 4
    assert s

# Generated at 2022-06-11 18:42:46.805026
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test: No LooseVersion provided
    try:
        SemanticVersion.from_loose_version('')
    except ValueError as e:
        assert 'is not a LooseVersion' in text_type(e)
    else:
        assert False, 'ValueError not raised'

    # Test: LooseVersion includes non-integer values
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.2.3a5'))
    except ValueError as e:
        assert 'Non integer values in' in text_type(e)
    else:
        assert False, 'ValueError not raised'

    # Test: LooseVersion is too large

# Generated at 2022-06-11 18:42:58.698867
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Happy path
    for vstring in ('0.1.1', '1.0.0', '1.0.0-alpha.0', '1.0.0+foo9.bar'):
        assert SemanticVersion(vstring).vstring == vstring

    # Major version is an integer
    with pytest.raises(ValueError):
        SemanticVersion('a.0.0')
    # Minor version is an integer
    with pytest.raises(ValueError):
        SemanticVersion('0.a.0')
    # Patch version is an integer
    with pytest.raises(ValueError):
        SemanticVersion('0.0.a')
    # Prerelease version is all alpha numeric and dashes (.) separated

# Generated at 2022-06-11 18:43:11.110890
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Unit test for method from_loose_version of class SemanticVersion
    """
    # positive tests
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert sv.vstring == '1.2.3'
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3-a.b.c'))
    assert sv.vstring == '1.2.3-a.b.c'
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3+a.b.c'))
    assert sv.vstring == '1.2.3+a.b.c'

# Generated at 2022-06-11 18:43:23.681981
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:43:34.319105
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion('1.2.3')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.core == (1, 2, 3)
    assert v.is_stable

    v = SemanticVersion('1.2.3-alpha')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.core == (1, 2, 3)
    assert v.prerelease == (_Alpha('alpha'),)
    assert not v.is_stable

    v = SemanticVersion('1.2.3-alpha.1+build')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.core == (1, 2, 3)
   

# Generated at 2022-06-11 18:43:41.549405
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    module = AnsibleModule(argument_spec=dict())

    loose_version = LooseVersion('2.10.3')
    semver = SemanticVersion.from_loose_version(loose_version)

    assert semver == '2.10.3'
    assert semver.is_stable

    loose_version_with_prerelease = LooseVersion('1.2.3beta')
    semver = SemanticVersion.from_loose_version(loose_version_with_prerelease)

    assert semver == '1.2.3-beta'
    assert not semver.is_stable


# Generated at 2022-06-11 18:43:54.721357
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """Unit test for method parse of class SemanticVersion"""
    version = '3.2.1-alpha.1+build.001'
    sv = SemanticVersion(version)
    assert sv.core == (3, 2, 1)
    assert sv.prerelease == (_Alpha('alpha'), _Numeric(1))
    assert sv.buildmetadata == (_Alpha('build'), _Numeric(1))

    version = '3.2.1+build.001'
    sv = SemanticVersion(version)
    assert sv.core == (3, 2, 1)
    assert sv.prerelease == ()
    assert sv.buildmetadata == (_Alpha('build'), _Numeric(1))

    version = '3.2.1'
    sv = SemanticVersion(version)
    assert sv.core == (3, 2, 1)

# Generated at 2022-06-11 18:44:01.329924
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = SemanticVersion.from_loose_version("1.2.3.dev1")
    assert str(v) == "1.2.3-dev1"

    v = SemanticVersion.from_loose_version("1.2.3.a4")
    assert str(v) == "1.2.3-a4"

    v = SemanticVersion.from_loose_version("1.2.3.a4.b5")
    assert str(v) == "1.2.3-a4.b5"

    v = SemanticVersion.from_loose_version("1.2.3.a4.b5.rc")
    assert str(v) == "1.2.3-a4.b5.rc"


# Generated at 2022-06-11 18:44:10.690050
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """Unit test for method parse of class SemanticVersion"""
    version = SemanticVersion()

    version.parse('0.0.4')
    assert version.major == 0
    assert version.minor == 0
    assert version.patch == 4
    assert version.prerelease is None
    assert version.buildmetadata is None

    version.parse('1.0.0-alpha')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ('alpha', )
    assert version.buildmetadata is None

    version.parse('1.0.0-alpha.1')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ('alpha', '1')

# Generated at 2022-06-11 18:44:22.990941
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:44:35.431561
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0b1')) == SemanticVersion('1.0.0-b1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.b1')) == SemanticVersion('1.0.0-b1')

# Generated at 2022-06-11 18:44:48.839880
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:45:00.275170
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    loose_version = LooseVersion('10.2.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 10
    assert semantic_version.minor == 2
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()

    loose_version = LooseVersion('10.2.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 10
    assert semantic_version.minor == 2
    assert semantic_version.patch == 1
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()


# Generated at 2022-06-11 18:45:07.164946
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')).vstring == '1.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2-alpha')).vstring == '1.2.0-alpha'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2+alpha')).vstring == '1.2.0+alpha'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')).vstring == '1.2.3-alpha'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+alpha')).vstring == '1.2.3+alpha'

# Generated at 2022-06-11 18:45:20.097045
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE
    from ansible.module_utils.parsing.convert_bool import BOOLEANS_FALSE
    from ansible.module_utils.six import string_types

    bool_true_value = BOOLEANS_TRUE[0]
    bool_false_value = BOOLEANS_FALSE[0]

    loose_versions = []
    semantic_versions = []

    # Provide invalid loose versions, the method should raise ValueError

    # Version is None, the method should rais ValueError
    loose_version = None
    semantic_version = None

# Generated at 2022-06-11 18:45:33.511843
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    lv = LooseVersion('0.36.0')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 0
    assert sv.minor == 36
    assert sv.patch == 0
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()

    lv = LooseVersion('0.36.0.dev0')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.major == 0
    assert sv.minor == 36
    assert sv.patch == 0
    assert sv.prerelease == (0,)
    assert sv.buildmetadata == ()

    lv = LooseVersion('1.36.0.post1.dev0')
    sv = SemanticVersion.from_loose_version(lv)

# Generated at 2022-06-11 18:45:40.236967
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Returned value is an instance of the class SemanticVersion
    assert(isinstance(SemanticVersion.from_loose_version(LooseVersion('1.0.0')), SemanticVersion))
    # Check some valid inputs
    assert(SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == '1.0.0')
    assert(SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == '1.2.3')
    assert(SemanticVersion.from_loose_version(LooseVersion('1.0-alpha.0')) == '1.0.0-alpha.0')
    assert(SemanticVersion.from_loose_version(LooseVersion('1.0-alpha')) == '1.0.0-alpha')


# Generated at 2022-06-11 18:45:51.609084
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import iteritems

# Generated at 2022-06-11 18:45:59.261251
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test parsing of 2.1.0 (stable, no prerelease)
    loose_version = LooseVersion('2.1.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 2
    assert semantic_version.minor == 1
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == tuple()
    assert semantic_version.buildmetadata == tuple()

    # Test parsing of 2.1.0-alpha.1 (prerelease)
    loose_version = LooseVersion('2.1.0-alpha.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 2
    assert semantic_version.minor == 1

# Generated at 2022-06-11 18:46:16.440274
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Arrange
    test_data = [];

    # Test 1
    test_data.append((
        semver.SemanticVersion('1.0.0'),
        semver.SemanticVersion.from_loose_version(semver.LooseVersion('1.0.0'))
    ))

    # Test 2
    test_data.append((
        semver.SemanticVersion('1.0.0'),
        semver.SemanticVersion.from_loose_version(semver.LooseVersion('1.0.0.0'))
    ))

    # Test 3
    test_data.append((
        semver.SemanticVersion('1.0.0'),
        semver.SemanticVersion.from_loose_version(semver.LooseVersion('1_0_0'))
    ))

    #

# Generated at 2022-06-11 18:46:27.443112
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test passing a loose version could generate a semantic version
    loose_version = LooseVersion('2.0.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == SemanticVersion('2.0.0')

    # Test passing a version with pre-release could generate a semantic version
    loose_version = LooseVersion('2.0.0-a.b.c.d')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == SemanticVersion('2.0.0-a.b.c.d')

    # Test passing a version with pre-release and build metadata could generate a semantic version

# Generated at 2022-06-11 18:46:35.628592
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    v1 = "1.12.0"
    v2 = "1.12.0-dev.1"
    assert SemanticVersion.from_loose_version(LooseVersion(v1)).vstring == v1
    assert SemanticVersion.from_loose_version(LooseVersion(v2)).vstring == v2

# Generated at 2022-06-11 18:46:45.458423
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Check SemanticVersion.from_loose_version() method

    In the case of Python 2, the input version must be encoded as
    a unicode object.
    """
    import sys

    # Case 1: input version is encoded as a unicode object
    if sys.version_info[0] == 2:
        version = u'2.0.0a0'
        lv = LooseVersion(version)
        sv = SemanticVersion.from_loose_version(lv)
        assert sv.vstring == version

    # Case 2: input version is a unicode object
    version = u'2.0.0a0'
    lv = LooseVersion(version)
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == version

    # Case 3: input version is a

# Generated at 2022-06-11 18:46:57.166333
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("2.0.0")).is_stable == SemanticVersion("2.0.0").is_stable
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-1+metadata")).is_stable == SemanticVersion("1.0.0-1+metadata").is_stable
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.0")) != SemanticVersion("0.0.0").is_stable

# Generated at 2022-06-11 18:47:06.547762
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test the method SemanticVersion.from_loose_version.

    This method take a LooseVersion and try to build a SemanticVersion
    out of it. It is used to add SemanticVersion functionalities to
    LooseVersion.

    Note : this tests are not perfect, especially the one with the
    prerelease, because the method can be affected by the way the
    constructor parse the string.
    """

    # test with a simple version
    v = '1.1.1'
    s = SemanticVersion(v)
    l = SemanticVersion.from_loose_version(LooseVersion(v))
    assert s == l

    # test with a prerelease version
    v = '1.1.1-rc1'
    s = SemanticVersion(v)
    l = SemanticVersion.from_loose_version

# Generated at 2022-06-11 18:47:16.838587
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test valid cases
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("2.11")) == SemanticVersion("2.11.0")
    assert SemanticVersion.from_loose_version(LooseVersion("4.a10.2")) == SemanticVersion("4.a10.2")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0-alpha")) == SemanticVersion("1.0.0-alpha")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0-b2")) == SemanticVersion("1.0.0-b2")
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-11 18:47:25.371493
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0-SNAPSHOT')) == SemanticVersion('1.0.0-SNAPSHOT')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0-SNAPSHOT+abcdefg')) == SemanticVersion('1.0.0-SNAPSHOT+abcdefg')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0+abcdefg')) == SemanticVersion('1.0.0+abcdefg')


if __name__ == '__main__':
    test_SemanticVersion_from_loose_version()

# Generated at 2022-06-11 18:47:33.269870
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3

    # Test: PY2
    try:
        # pylint: disable=E0611,F0401
        from distutils.version import LooseVersion
    except ImportError:
        pass
    else:
        assert SemanticVersion.from_loose_version(
            LooseVersion('0.1.2')
        ) == SemanticVersion('0.1.2')

        assert SemanticVersion.from_loose_version(
            LooseVersion('1.2.0-1')
        ) == SemanticVersion('1.2.0-1')

        assert SemanticVersion.from_loose_version(
            LooseVersion('1.2.3-1')
        ) == SemanticVersion('1.2.3-1')

        assert Semantic

# Generated at 2022-06-11 18:47:42.612685
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:03.416820
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.compat.version import LooseVersion
    
    v1 = LooseVersion("1.2.3+build.42")
    v2 = LooseVersion("1.2.3.4-pre42")

    # py2 and py3 LooseVersion gets initialized differently
    # So we need to convert LooseVersion to SemanticVersion
    # to make sure we test the same behavior
    if PY2:
        v1_cvt = v1.version

# Generated at 2022-06-11 18:48:13.747423
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.0")) == SemanticVersion("1.2.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.0rc1")) == SemanticVersion("1.2.0-rc1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.0rc1+1")) == SemanticVersion("1.2.0-rc1+1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1")) == SemanticVersion("1.0.0")

# Generated at 2022-06-11 18:48:24.013417
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2
    from ansible.module_utils.compat.version import LooseVersion

    # type checking should fail if LooseVersion not provided
    if PY2:
        try:
            sv = SemanticVersion.from_loose_version("1.2.3")
        except ValueError:
            pass
        else:
            assert False, "ValueError not thrown as expected"

    # LooseVersion with non-integer values should fail
    try:
        SemanticVersion.from_loose_version(LooseVersion("1.2.3a"))
    except ValueError:
        pass
    else:
        assert False, "ValueError not thrown as expected"

    # LooseVersioun with - or + should create prerelease or buildmetadata

# Generated at 2022-06-11 18:48:36.528422
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:44.151428
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test if the method from_loose_version of class SemanticVersion works as expected"""
    # Create the loose version
    loose_version = LooseVersion('0.1.0')
    # Create a SemanticVersion using the from_loose_version method
    version = SemanticVersion.from_loose_version(loose_version)
    # Assert that the created version is correct
    assert version == '0.1.0'

# Generated at 2022-06-11 18:48:57.548923
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('2001-01-20T10:20:25') == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version('1.0.dev1') == SemanticVersion('1.0.0-dev1')
    assert SemanticVersion.from_loose_version('1.2.dev5') == SemanticVersion('1.2.0-dev5')
    assert SemanticVersion.from_loose_version('1.2.dev5+12') == SemanticVersion('1.2.0-dev5+12')
    assert SemanticVersion.from_loose_version('1.2.dev5+12.git') == SemanticVersion('1.2.0-dev5+12.git')
    assert SemanticVersion.from_loose

# Generated at 2022-06-11 18:49:03.289837
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3a4')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert (semantic_version.major == 1 and
            semantic_version.minor == 2 and
            semantic_version.patch == 3 and
            semantic_version.prerelease == ('_Alpha', _Numeric(4)))

    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert (semantic_version.major == 1 and
            semantic_version.minor == 2 and
            semantic_version.patch == 3 and
            semantic_version.prerelease == ())

    loose_version = LooseVersion('1.2.3alpha')
    semantic_version = Semantic

# Generated at 2022-06-11 18:49:10.146788
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0-alpha+001')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0-alpha+1'
    loose_version = LooseVersion('1.0.0-alpha.beta+001')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0-alpha.beta+1'


# Generated at 2022-06-11 18:49:21.408523
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """test_SemanticVersion_from_loose_version
    """
    # Test simple version without prerelease or build metadata
    # vstring of LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    # vstring of string
    assert SemanticVersion.from_loose_version('1.2.3').vstring == '1.2.3'

    # Test version with prerelease
    # vstring of LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')).vstring == '1.2.3-alpha.1'
    # vstring of string

# Generated at 2022-06-11 18:49:33.950577
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1'))
    assert version.vstring == '1.0.0-alpha.1'
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert isinstance(version.prerelease[0], _Alpha)
    assert version.prerelease[0] == 'alpha'
    assert isinstance(version.prerelease[1], _Numeric)
    assert version.prerelease[1] == 1

    version = SemanticVersion.from_loose_version(LooseVersion('1.0.0+foobar'))
    assert version.vstring == '1.0.0+foobar'
    assert version.major == 1
    assert version.minor == 0

# Generated at 2022-06-11 18:50:26.770919
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.0')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-0')) == SemanticVersion('1.2.3-0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-0.1')) == SemanticVersion('1.2.3-0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+0')) == SemanticVersion('1.2.3')
    assert Sem

# Generated at 2022-06-11 18:50:39.665631
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Unit test for method from_loose_version of class SemanticVersion
    """

    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+0.0.0.0')).vstring == '1.2.3+0.0.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+0.0.0.0')).major == 1
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+0.0.0.0')).minor == 2
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+0.0.0.0')).patch == 3

# Generated at 2022-06-11 18:50:53.201664
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import unittest
    import ansible.module_utils.compat.version

    tc = unittest.TestCase('assertEqual')

    tc.assertEqual(SemanticVersion.from_loose_version(ansible.module_utils.compat.version.LooseVersion('2.0.0')), SemanticVersion('2.0.0'))
    tc.assertEqual(SemanticVersion.from_loose_version(ansible.module_utils.compat.version.LooseVersion('2.0.0-alpha.2')), SemanticVersion('2.0.0-alpha.2'))

    tc.assertRaises(ValueError, SemanticVersion.from_loose_version, ansible.module_utils.compat.version.LooseVersion('2.0-alpha.2'))

# Generated at 2022-06-11 18:50:56.868163
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semver = SemanticVersion.from_loose_version("0.0.1.dev1")
    assert semver.core == (0, 0, 1)
    assert semver.prerelease == ("dev", 1)



# Generated at 2022-06-11 18:51:08.872546
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")).vstring == "1.2.3"
    assert SemanticVersion.from_loose_version(LooseVersion("1.2")).vstring == "1.2.0"
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3.4")).vstring == "1.2.3"
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha")).vstring == "1.2.3-alpha"
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3.4-alpha")).vstring == "1.2.3-alpha"

# Generated at 2022-06-11 18:51:20.039455
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Unit test for method from_loose_version of class SemanticVersion

    This function must be defined within the same module
    where SemanticVersion is defined, so that it can be
    found by the import machinery.

    This method is called from unit tests.
    """
    from distutils.version import LooseVersion

    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

# Generated at 2022-06-11 18:51:31.531470
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    import pytest
    vloose = LooseVersion("1.2.0")
    vsemver = SemanticVersion.from_loose_version(vloose)
    assert vsemver == SemanticVersion("1.2")
    vloose = LooseVersion("1.2.3")
    vsemver = SemanticVersion.from_loose_version(vloose)
    assert vsemver == SemanticVersion("1.2.3")
    vloose = LooseVersion("1.2.3-alpha")
    vsemver = SemanticVersion.from_loose_version(vloose)
    assert vsemver == SemanticVersion("1.2.3-alpha")

# Generated at 2022-06-11 18:51:43.295447
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = SemanticVersion()
    v.from_loose_version(LooseVersion("1.0.0"))
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    v.from_loose_version(LooseVersion("1.0.0rc1"))
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Numeric("rc"), _Numeric("1"))
    v.from_loose_version(LooseVersion("1.0.0-rc1.alpha"))
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == (_Numeric("rc"), _Numeric("1"), _Alpha("alpha"))
   

# Generated at 2022-06-11 18:51:53.273348
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:52:04.412228
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion.from_loose_version(LooseVersion("1.2.3"))
    assert v1 == '1.2.3'

    v2 = SemanticVersion.from_loose_version(LooseVersion("1.2.3.4"))
    assert v2 == '1.2.3'

    v3 = SemanticVersion.from_loose_version(LooseVersion("1.2"))
    assert v3 == '1.2.0'

    v4 = SemanticVersion.from_loose_version(LooseVersion("1"))
    assert v4 == '1.0.0'

    v5 = SemanticVersion.from_loose_version(LooseVersion("1.2.3-beta"))
    assert v5 == '1.2.3-beta'
