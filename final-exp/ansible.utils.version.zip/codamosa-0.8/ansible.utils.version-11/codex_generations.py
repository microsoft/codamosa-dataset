

# Generated at 2022-06-11 18:42:30.181283
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:42:42.672759
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    #valid_vstrings = {
    my_ver1 = "2.2.2"
    my_ver2 = "1.1.1-dev.1"
    #}
    print("Testing parse method of class SemanticVersion")
    print("my_ver1 is ", my_ver1)
    #for vstring in valid_vstrings:
    #    print("vstring is ", vstring)
    #    print("valid_vstring[vstring] is ", valid_vstrings[vstring])
    my_version = SemanticVersion(my_ver1)
    #my_version.parse("2.2.2")
    #assert my_version.major == 2
    #assert my_version.minor == 2
    #assert my_version.patch == 2
    #assert my_version.prerelease == ()
   

# Generated at 2022-06-11 18:42:51.515315
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import re
    import sys
    lv = LooseVersion('1.0.0')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == '1.0.0'

    lv = LooseVersion('1.0.0.dev0')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == '1.0.0-dev0'

    lv = LooseVersion('1.0.0+abc.123')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == '1.0.0+abc.123'

    lv = LooseVersion('1.0.0.dev0+abc.123')

# Generated at 2022-06-11 18:42:58.266650
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion('1.2.3')
    assert (v.major, v.minor, v.patch, v.prerelease, v.buildmetadata) == (1, 2, 3, (), ())
    v = SemanticVersion('1.2.3-4')
    assert (v.major, v.minor, v.patch, v.prerelease, v.buildmetadata) == (1, 2, 3, (_Numeric(4),), ())
    v = SemanticVersion('1.2.3-alpha')
    assert (v.major, v.minor, v.patch, v.prerelease, v.buildmetadata) == (1, 2, 3, (_Alpha('alpha'),), ())
    v = SemanticVersion('1.2.3-alpha.4')

# Generated at 2022-06-11 18:43:10.805190
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.5.5')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.5.5'
    assert semver.major == 1
    assert semver.minor == 5
    assert semver.patch == 5

    loose_version = LooseVersion('0.5.5')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '0.5.5'
    assert semver.major == 0
    assert semver.minor == 5
    assert semver.patch == 5

    loose_version = LooseVersion('1.5.5-beta')

# Generated at 2022-06-11 18:43:23.511889
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    import mock

    semantic_version = SemanticVersion()
    with mock.patch.object(semantic_version, 'version_re') as patch_version_re:
        patch_version_re.match = lambda: None
        try:
            semantic_version.parse('0.0.0')
            assert False, "Invalid semver did not throw error"
        except ValueError:
            pass

    semantic_version = SemanticVersion()
    with mock.patch.object(semantic_version, 'version_re') as patch_version_re:
        match = mock.Mock()
        match.group = lambda: None
        patch_version_re.match = lambda: match


# Generated at 2022-06-11 18:43:34.194660
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    valid_cases = [
        '0.0.2',
        '1.2.3',
        '1.2.33.44.555',
        '1.2.33.44.555-alpha',
        '1.2.33.44.555-alpha.3',
        '1.2.33.44.555-alpha.3+build.1',
        '1.2.33.44.555-alpha.3.asdf.asdf.asdf+build.1',
        '1.2.33.44.555-alpha.3.asdf.asdf.asdf+build.1.2',
        '1.2.33.44.555-alpha.3.asdf.asdf.asdf+build.1.2.3',
    ]

# Generated at 2022-06-11 18:43:44.813896
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    # New SemanticVersion instance
    semver = SemanticVersion()

    # Version specifications in invalid or unhandled form

# Generated at 2022-06-11 18:43:57.015362
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version_string = "1.2.3+pre-release"
    semver = SemanticVersion(version_string)
    assert isinstance(semver, SemanticVersion)

    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    version_string = "1.2.3-pre-release"
    semver = SemanticVersion(version_string)
    assert isinstance(semver, SemanticVersion)

    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ('pre', 'release')
    assert semver.buildmetadata == ()


# Generated at 2022-06-11 18:44:08.540581
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """Unit test for method parse of class SemanticVersion"""
    version = '12.34.56'
    v1 = SemanticVersion(version)
    assert v1.vstring == version
    assert v1.major == 12
    assert v1.minor == 34
    assert v1.patch == 56
    assert v1.prerelease == tuple()
    assert v1.buildmetadata == tuple()

    version = '12.34.56-rc.1234.5678'
    v1 = SemanticVersion(version)
    assert v1.vstring == version
    assert v1.major == 12
    assert v1.minor == 34
    assert v1.patch == 56

# Generated at 2022-06-11 18:44:16.331800
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha1')) == SemanticVersion('1.2.3-alpha1')


# Generated at 2022-06-11 18:44:22.941013
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test if non LooseVersion object raises an error
    s = SemanticVersion()
    with pytest.raises(ValueError):
        s.from_loose_version('2.3.4.5')

    # Test if non integer values raises an error
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(LooseVersion('2.4.4a'))

    # Test if correctly parsed version is correctly returned
    assert SemanticVersion.from_loose_version(LooseVersion('2.4.4+abc')) == SemanticVersion('2.4.4+abc')

    # Test if correctly parsed version with missing parts is correctly returned
    assert SemanticVersion.from_loose_version(LooseVersion('2')) == SemanticVersion('2.0.0')


#

# Generated at 2022-06-11 18:44:29.804446
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    v = '4.0.0'
    assert v == str(SemanticVersion.from_loose_version(LooseVersion(v)))

    v = '1.2.beta2'
    assert '1.2.0-beta2' == str(SemanticVersion.from_loose_version(LooseVersion(v)))

    v = '1.1.3.4'
    assert '1.1.3' == str(SemanticVersion.from_loose_version(LooseVersion(v)))


# Generated at 2022-06-11 18:44:38.791131
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('12.4.3')).vstring == '12.4.3'
    assert SemanticVersion.from_loose_version(LooseVersion('12.4.3-rc1')).vstring == '12.4.3-rc1'
    assert SemanticVersion.from_loose_version(LooseVersion('12.4.3+build1')).vstring == '12.4.3+build1'
    assert SemanticVersion.from_loose_version(LooseVersion('12.4.3-rc1+build1')).vstring == '12.4.3-rc1+build1'

# Generated at 2022-06-11 18:44:50.041866
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version('1.2.3-alpha') == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version('1.2.3+build') == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version('1.2.3-alpha+build') == SemanticVersion('1.2.3-alpha+build')
    assert SemanticVersion.from_loose_version('1.2.3a.b+build') == SemanticVersion('1.2.3-a.b+build')

# Generated at 2022-06-11 18:45:01.286906
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    import os.path
    scriptDirectory = os.path.abspath(os.path.dirname(__file__))
    testDirectory = os.path.join(scriptDirectory, 'test_SemanticVersion_from_loose_version')
    if not os.path.exists(testDirectory):
        os.makedirs(testDirectory)
    # Write an example distutils.version.LooseVersion object
    lv_vstring = 'foo_1.2.3'
    lv_version = '[1, 2, 3, \'foo\']'
    lv_vstring_filename = os.path.join(testDirectory, 'looseversion_vstring.txt')
    lv_version_filename = os.path.join(testDirectory, 'looseversion_version.txt')

# Generated at 2022-06-11 18:45:11.224613
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+alpha')).vstring == '1.2.3+alpha'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')).vstring == '1.2.3-alpha'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+alpha')).vstring == '1.2.3-alpha.1+alpha'
    # Test leading zeros (gh#62888)
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.003')).vstring

# Generated at 2022-06-11 18:45:22.123340
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:45:31.707341
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3.dev1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3-dev1'
    loose_version = LooseVersion('1.2.3.dev1+abc.def')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3-dev1+abc.def'

# Generated at 2022-06-11 18:45:40.062123
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion"""
    from ansible.module_utils.six import PY2
    from distutils.version import LooseVersion
    if PY2:
        from ansible.module_utils.compat.version import LooseVersion as LooseVersion2x
    else:
        LooseVersion2x = LooseVersion

    # Test one version format
    version = "10.3.22"
    loose_version = LooseVersion(version)
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == version

    # Test one version format
    version = "10.3.22-pre1"
    loose_version = LooseVersion(version)

# Generated at 2022-06-11 18:45:57.960342
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test if convertion works as expected
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == \
        SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == \
        SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.4')) == \
        SemanticVersion('1.2.4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.4-beta')) == \
        SemanticVersion('1.2.4-beta')

# Generated at 2022-06-11 18:46:08.970070
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    for vstring in [
        '1.5',
        '1.5.3',
        '1.5.3-beta1',
        '1.5.3-beta1.1',
        '1.5.3-beta1.1+build1.2.3',
        '1.5.3-beta1.1.1+build1.2.3',
    ]:
        loose = LooseVersion(vstring)
        semantic = SemanticVersion.from_loose_version(loose)

        if isinstance(semantic, text_type):
            # Py2 returns a unicode type
            semantic = semantic.encode('utf-8')
        assert loose.vstring == semantic
        assert semantic == vstring


# Generated at 2022-06-11 18:46:16.547765
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0-rc.1+build.1')
    semver = SemanticVersion.from_loose_version(loose_version)

    assert semver.major == 1
    assert semver.minor == 0
    assert semver.patch == 0
    assert semver.prerelease == (_Numeric('rc'), _Numeric('1'))
    assert semver.buildmetadata == (_Alpha('build'), _Numeric('1'))

# Generated at 2022-06-11 18:46:20.606464
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = LooseVersion('1.0.0-beta.1')
    semver = SemanticVersion.from_loose_version(version)
    assert semver == '1.0.0-beta.1'



# Generated at 2022-06-11 18:46:29.831111
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('123.456.789')) == SemanticVersion('123.456.789')
    assert SemanticVersion.from_loose_version(LooseVersion('123.456.789')) != SemanticVersion('123.456.789+alpha1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.123')) == SemanticVersion('1.2.3-alpha.123')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')

# Generated at 2022-06-11 18:46:39.016377
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    faux_version = LooseVersion(text_type(__version__))
    semver = SemanticVersion.from_loose_version(faux_version)
    assert(semver.major == __version_info__[0])
    assert(semver.minor == __version_info__[1])
    assert(semver.patch == __version_info__[2])

__all__ = [
    'SEMVER_RE',
    'SemanticVersion',
]

# Generated at 2022-06-11 18:46:47.619829
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test case for LooseVersion that does not have a buildmetadata
    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert not semantic_version.prerelease
    assert not semantic_version.buildmetadata

    # Test case for a LooseVersion that has a buildmetadata
    loose_version = LooseVersion('1.2.3-alpha+001')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3

# Generated at 2022-06-11 18:46:58.126488
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests with valid strings
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-rc.1")) == SemanticVersion("1.0.0-rc.1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0+build.1")) == SemanticVersion("1.0.0+build.1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-rc.1+build.1")) == SemanticVersion("1.0.0-rc.1+build.1")

# Generated at 2022-06-11 18:47:03.699944
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("0.1.2")
    assert SemanticVersion.from_loose_version(loose_version) == "0.1.2"

    loose_version = LooseVersion("0.1.2.dev4")
    assert SemanticVersion.from_loose_version(loose_version) == "0.1.2-dev4"



# Generated at 2022-06-11 18:47:14.354851
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert isinstance(version, SemanticVersion)
    assert version == '1.2.3'
    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1'))
    assert isinstance(version, SemanticVersion)
    assert version == '1.2.3-alpha.1'


if __name__ == '__main__':
    import sys
    import os
    import doctest
    doctest.testmod()

    if len(sys.argv) > 1 and os.path.exists(sys.argv[1]):
        path = sys.argv.pop(1)

# Generated at 2022-06-11 18:47:26.131006
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose = LooseVersion("test-1.50-2")
    semver = SemanticVersion("1.50.2")
    assert SemanticVersion.from_loose_version(loose) == semver


# These are unit tests from python's distutils.version.Version
#
# The only reason they are not in the typical unit test format
# is that I don't want to have to modify them all with py2/3
# compatability in mind


# Generated at 2022-06-11 18:47:33.492015
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    v = SemanticVersion.from_loose_version(LooseVersion('2.4.4'))
    assert v.vstring == '2.4.4'

    v = SemanticVersion.from_loose_version(LooseVersion('2.4.4-dev'))
    assert v.vstring == '2.4.4-dev'

    v = SemanticVersion.from_loose_version(LooseVersion('2.4.4.post1.dev1'))
    assert v.vstring == '2.4.4-post1.dev1'

    v = SemanticVersion.from_loose_version(LooseVersion('2.4.4.post1'))

# Generated at 2022-06-11 18:47:42.641097
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import inspect
    import os

    # Get the version (e.g. 0.0.6) as string from the filename of this module (e.g. module_utils/facts/version.py)
    file = inspect.getfile(inspect.currentframe())
    version = file.replace('/', '.').split('.')[-2]

    # Get the distribution (e.g. dist-el8) as string from the environment variable PYTHON_DISTRIBUTION (e.g. dist-el8)
    # This variable is defined in the Dockerfile when building the distribution
    distribution = os.getenv('PYTHON_DISTRIBUTION', 'dist-undefined')

    # The expected result is a tuple of the version (e.g. 0.0.6) as string and the distribution (e.g. dist-el

# Generated at 2022-06-11 18:47:56.026898
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:05.072456
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion."""
    # SemanticVersion expects semver compliance
    assert SemanticVersion('1.0.0') == SemanticVersion('1.0.0')
    # LooseVersion is not semver compliant
    assert SemanticVersion('1.0.0') != LooseVersion('1.0.0')

    # Create a SemanticVersion from a LooseVersion
    assert SemanticVersion('1.0.0') == SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    # Ensure that prerelease builds are preserved
    assert SemanticVersion('1.2.3rc1') == SemanticVersion.from_loose_version(LooseVersion('1.2.3rc1'))

    # Ensure that non-integer parts of the Lo

# Generated at 2022-06-11 18:48:14.922296
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # test for non-LooseVersion objects
    non_LooseVersions = (
        list(),
        dict(),
        tuple(),
        int(),
        float(),
        str(),
        object(),
        object,
        object(),
    )

    for i in non_LooseVersions:
        try:
            SemanticVersion.from_loose_version(i)
        except ValueError:
            continue
        else:
            assert False, "should not be able to convert %r to SemanticVersion" % i

    # test for non-integer values
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.2a.3'))
    except ValueError:
        pass

# Generated at 2022-06-11 18:48:22.525787
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')).vstring == '1.1.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1-1')).vstring == '1.1.1-1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1.1')).vstring == '1.1.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1+1')).vstring == '1.1.1+1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1.1-1+1')).vstring == '1.1.1-1+1'
    assert Semantic

# Generated at 2022-06-11 18:48:34.746288
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1a')) == SemanticVersion('1.0.0-a')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2b')) == SemanticVersion('1.2.0-b')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3c')) == SemanticVersion('1.2.3-c')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4c')) == SemanticVersion('1.2.3-4c')

# Generated at 2022-06-11 18:48:38.413035
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check that we can pass a LooseVersion object and get a SemanticVersion object
    loose = LooseVersion('1.2.3')
    strict = SemanticVersion.from_loose_version(loose)
    assert isinstance(strict, SemanticVersion)


# Generated at 2022-06-11 18:48:47.987360
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2

    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) != SemanticVersion('1.0.0+a')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) != SemanticVersion('1.0.0-a')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-a')) == SemanticVersion('1.0.0-a')

# Generated at 2022-06-11 18:49:03.338725
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # test that an invalid parameter is caught
    invalid_parameters = [
      None,
      0,
      False
    ]
    for parameter in invalid_parameters:
        try:
            version = SemanticVersion.from_loose_version(parameter)
            raise AssertionError("%r must raise an exception" % parameter)
        except ValueError:
            pass


    # test that a valid parameter is accepted

# Generated at 2022-06-11 18:49:08.953445
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:49:21.014670
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("0.0.0")), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("0.0.0-1")), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("0.0.0-1.0")), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("0.0.0-1a")), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("0.0.0-1.0a")), SemanticVersion)

# Generated at 2022-06-11 18:49:33.672178
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_invalid = LooseVersion("1.2.3")
    loose_version_invalid.version = ("1", "2", "3", "qwerty")
    loose_version_invalid_type = LooseVersion("1.2.3")
    loose_version_invalid_type.version = (1, 2, 3, "qwerty")
    loose_version_invalid_buildmetadata = LooseVersion("1.2.3")
    loose_version_invalid_buildmetadata.version = (1, 2, 3, "alpha", "qwerty")
    loose_version_valid = LooseVersion("1.2.3")
    loose_version_valid.version = (1, 2, 3, "alpha")

    # Make sure that we catch when the input isn't a LooseVersion

# Generated at 2022-06-11 18:49:46.092960
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Check that input data type is of type LooseVersion
    test_input = []
    try:
        SemanticVersion.from_loose_version(test_input)
    except ValueError:
        pass
    else:
        print('FAIL: Expected ValueError but no exception raised')
        exit(1)

    # Check that input data contains only numeric values
    test_input = LooseVersion('1.2.A')
    try:
        SemanticVersion.from_loose_version(test_input)
    except ValueError:
        pass
    else:
        print('FAIL: Expected ValueError but no exception raised')
        exit(1)

    # Check that input data does not contain trailing characters
    test_input = LooseVersion('1.2.3A')

# Generated at 2022-06-11 18:49:52.562160
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    loose_version = LooseVersion("2.7.18")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 2
    assert semver.minor == 7
    assert semver.patch == 18
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

# Generated at 2022-06-11 18:50:02.817031
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1')).vstring == '0.0.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.4-alpha.1')).vstring == '1.2.4-alpha.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')).vstring == '1.2.3-alpha.1+build.1'

# Generated at 2022-06-11 18:50:14.753414
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion
    from ansible.module_utils.compat.version import LooseVersion


# Generated at 2022-06-11 18:50:26.429801
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def assert_raises(exc_info, msg, func, *args):
        try:
            func(*args)
        except exc_info as exc:
            assert msg in str(exc), "Exception {} does not contain message '{}'".format(exc, msg)
        else:
            raise RuntimeError("{} does not raise exception {} with message '{}'".format(func, exc_info, msg))

    assert_raises(TypeError, "list is not a LooseVersion", SemanticVersion.from_loose_version, ['v1.0.0'])
    assert_raises(ValueError, "Non integer values in LooseVersion", SemanticVersion.from_loose_version, 'v0.11.0')

# Generated at 2022-06-11 18:50:39.435177
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    result = SemanticVersion.from_loose_version(LooseVersion("1"))
    assert type(result) == SemanticVersion
    assert result.core == (1,0,0)
    #assert repr(result) == "SemanticVersion(u'1.0.0')"
    assert str(result) == "1.0.0"

    result = SemanticVersion.from_loose_version(LooseVersion("2"))
    assert type(result) == SemanticVersion
    assert result.core == (2,0,0)
    #assert repr(result) == "SemanticVersion(u'2.0.0')"
    assert str(result) == "2.0.0"

    result = SemanticVersion.from_loose_version(LooseVersion("1.2"))
    assert type(result) == Sem

# Generated at 2022-06-11 18:50:59.977095
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion('1.2.3')._cmp(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == 0
    assert SemanticVersion('1.2.3')._cmp(SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev01'))) == 0
    assert SemanticVersion('1.2.3')._cmp(SemanticVersion.from_loose_version(LooseVersion('1.2.3a'))) == 0
    assert SemanticVersion('1.2.3').is_stable

    assert SemanticVersion('1.2.3.dev01')._cmp(SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev01'))) == 0

# Generated at 2022-06-11 18:51:10.189422
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test we get a SemanticVersion instance
    sver = SemanticVersion.from_loose_version(LooseVersion('1.5.5'))
    assert isinstance(sver, SemanticVersion)
    # Test we get the correct version string
    assert sver.vstring == '1.5.5'
    # Test we get the correct major, minor, and patch
    assert sver.major == 1
    assert sver.minor == 5
    assert sver.patch == 5
    # Test we get the correct prerelease and buildmetadata
    assert sver.prerelease == ()
    assert sver.buildmetadata == ()
    # Test we get the correct is_stable
    assert sver.is_stable is True
    # Test we get the correct is_prerelease
    assert sver.is_prerelease is False
   

# Generated at 2022-06-11 18:51:21.509098
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1.0.0.1') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1.0.0.1.2') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1.0.0.1.2.3') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1.0.0-alpha.1') == SemanticVersion('1.0.0-alpha.1')

# Generated at 2022-06-11 18:51:31.895229
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    expected = SemanticVersion("1.2.3")
    loose_version = LooseVersion("1.2.3")
    assert SemanticVersion.from_loose_version(loose_version) == expected

    expected = SemanticVersion("1.2.3")
    loose_version = LooseVersion("1.2.3.dev1")
    assert SemanticVersion.from_loose_version(loose_version) == expected

    expected = SemanticVersion("1.2.3")
    loose_version = LooseVersion("1.2.3b")
    assert SemanticVersion.from_loose_version(loose_version) == expected

    expected = SemanticVersion("1.2.3")

# Generated at 2022-06-11 18:51:43.349305
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import u
    from ansible.module_utils.distro import LooseVersion

    # Testing with a LooseVersion with prerelease
    input_loose_version = LooseVersion('2.7.5a0')
    expected_semantic_version = SemanticVersion('2.7.5-0')
    assert SemanticVersion.from_loose_version(input_loose_version) == expected_semantic_version

    # Testing with a LooseVersion without prerelease
    input_loose_version = LooseVersion('2.7.5')
    expected_semantic_version = SemanticVersion('2.7.5')
    assert SemanticVersion.from_loose_version(input_loose_version) == expected_semantic_version

    # Testing with a LooseVersion with only

# Generated at 2022-06-11 18:51:53.344475
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check that it works for a basic version of
    # Major = 3
    # Minor = 4
    # Patch = 2
    version = SemanticVersion.from_loose_version(LooseVersion('3.4.2'))
    assert version.major == 3
    assert version.minor == 4
    assert version.patch == 2
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # Check if it discards the extra part of the version string
    # which is the characters 'abc1-2.3'
    version = SemanticVersion.from_loose_version(LooseVersion('3.4.2abc1-2.3'))
    assert version.major == 3
    assert version.minor == 4
    assert version.patch == 2
    assert version.prerelease == ()

# Generated at 2022-06-11 18:51:59.432470
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion """

    import distutils.version

    test_version = distutils.version.LooseVersion('1.2')
    assert SemanticVersion.from_loose_version(test_version).vstring == '1.2.0'