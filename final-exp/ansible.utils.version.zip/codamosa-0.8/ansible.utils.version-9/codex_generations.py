

# Generated at 2022-06-11 18:42:29.846821
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose = LooseVersion("1.0.0")
    sem = SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(loose) == sem
    assert SemanticVersion.from_loose_version(sem) == sem
    assert SemanticVersion.from_loose_version("1.0.0") == sem


# Generated at 2022-06-11 18:42:42.406333
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # A basic test that the _cmp method works as expected
    assert SemanticVersion('1.2.3')._cmp('1.2.3') == 0

    # A basic test that passing a SemanticVersion in works as expected
    assert SemanticVersion('1.2.3')._cmp(SemanticVersion('1.2.3')) == 0

    # Test that the _cmp method works with a simple dev release
    assert SemanticVersion('1.2.3-dev')._cmp('1.2.3') == -1

    # Test that the _cmp method works with a single pre release
    # dev release
    assert SemanticVersion('1.2.3-dev')._cmp('1.2.3-alpha') == -1

    # Test that the _cmp method works with a multi part pre release
    # dev release
    assert Semantic

# Generated at 2022-06-11 18:42:49.618828
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Empty version
    loose_version = LooseVersion("")
    assert SemanticVersion.from_loose_version(loose_version).vstring == "0.0.0"

    # Int version
    loose_version = LooseVersion("1")
    assert SemanticVersion.from_loose_version(loose_version).vstring == "1.0.0"

    # Float version
    loose_version = LooseVersion("1.2")
    assert SemanticVersion.from_loose_version(loose_version).vstring == "1.2.0"

    # String version
    # As seen in test_LooseVersion_parse, LooseVersion is not able to parse string version.
    # However, the "str" version can be converted to float and then be compared.
    # So that we can compare SemanticVersion

# Generated at 2022-06-11 18:43:01.606012
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:43:12.755881
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a string
    SemanticVersion.from_loose_version("9.9.9")
    # Test with a list
    SemanticVersion.from_loose_version(["9", "9", "9"])
    # Test with an integer
    SemanticVersion.from_loose_version(9)
    # Test with an instance of SemanticVersion
    SemanticVersion.from_loose_version(SemanticVersion("9.9.9"))
    # Test with an alpha release
    SemanticVersion.from_loose_version("9.9.9a6")
    # Test with an alpha release and build metadata
    SemanticVersion.from_loose_version("9.9.9a6+build.1.2.3")
    # Test with a bare integer and build metadata
    SemanticVersion.from_

# Generated at 2022-06-11 18:43:24.480043
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Valid conversions as per PyPA versions
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')) == SemanticVersion('1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1+a.b')) == SemanticVersion('1.1.1+a.b')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1+a.b-7')) == SemanticVersion('1.1.1+a.b-7')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1-alpha1')) == SemanticVersion('1.1.1-alpha1')

# Generated at 2022-06-11 18:43:34.676686
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2

    if PY2:
        return
    """Unit test for method from_loose_version of class SemanticVersion
    """
    from ansible.module_utils.distro import LooseVersion
    from ansible.module_utils.distro import SemanticVersion
    from ansible.module_utils.distro import _Numeric

    # Test correct LooseVersion
    correct_loose_version = LooseVersion('2.2-2')
    correct_semantic_version = SemanticVersion.from_loose_version(correct_loose_version)
    assert(correct_semantic_version.major == 2)
    assert(correct_semantic_version.minor == 2)
    assert(correct_semantic_version.patch == 0)

# Generated at 2022-06-11 18:43:45.835319
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    s_v = SemanticVersion.from_loose_version(LooseVersion('3.4.0'))
    assert s_v.major == 3
    assert s_v.minor == 4
    assert s_v.patch == 0
    s_v = SemanticVersion.from_loose_version(LooseVersion('1.2.0-rc.2+2.build.4'))
    assert s_v.major == 1
    assert s_v.minor == 2
    assert s_v.patch == 0
    assert s_v.prerelease == ('rc', '2')
    assert s_v.buildmetadata == ('2', 'build', '4')
    # test error cases

# Generated at 2022-06-11 18:43:57.372456
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:44:08.610863
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test a valid version
    version_test_valid = {
        "version_valid": "1.0.0",
        "major": 1,
        "minor": 0,
        "patch": 0,
        "prerelease": (),
        "buildmetadata": ()
    }
    sv = SemanticVersion(version_test_valid["version_valid"])
    assert sv.major == version_test_valid["major"]
    assert sv.minor == version_test_valid["minor"]
    assert sv.patch == version_test_valid["patch"]
    assert sv.prerelease == version_test_valid["prerelease"]
    assert sv.buildmetadata == version_test_valid["buildmetadata"]

    # Test an invalid version
    version_test_invalid = "1.0"

# Generated at 2022-06-11 18:44:21.695007
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class TestVersion(LooseVersion):
        def __init__(self, s):
            # override LooseVersion __init__ to support '~' version
            LooseVersion.__init__(self, s.replace('~', ''))

    assert SemanticVersion.from_loose_version(LooseVersion('1.0.10')).vstring == '1.0.10'
    assert SemanticVersion.from_loose_version(LooseVersion('1.10.0')).vstring == '1.10.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.10-rc')).vstring == '1.0.10-rc'

# Generated at 2022-06-11 18:44:34.298543
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # setup
    loose_version = '1.3.0'
    semantic_version = '1.3.0'

    # test
    result = SemanticVersion.from_loose_version(loose_version)
    expected = SemanticVersion(semantic_version)

    # assert
    assert result == expected

    # setup
    loose_version = '1.3.0-alpha.2'
    semantic_version = '1.3.0-alpha.2'

    # test
    result = SemanticVersion.from_loose_version(loose_version)
    expected = SemanticVersion(semantic_version)

    # assert
    assert result == expected

    # setup
    loose_version = '1.3.0-alpha.2+build.43'

# Generated at 2022-06-11 18:44:48.305634
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """Test the parse method of SemanticVersion."""
    semver = SemanticVersion()

    version = '0.0.1'
    semver.parse(version)
    assert (semver.major, semver.minor, semver.patch) == (0, 0, 1)
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    version = '1.0.0-alpha'
    semver.parse(version)
    assert (semver.major, semver.minor, semver.patch) == (1, 0, 0)
    assert semver.prerelease == (_Alpha('alpha'),)
    assert semver.buildmetadata == ()

    version = '2.2.3-alpha.1'
    semver.parse(version)

# Generated at 2022-06-11 18:44:51.788888
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion('1.0.1b3+abcdefabcdefabcdefabc')
    v = SemanticVersion.from_loose_version(lv)
    print(v)

# Generated at 2022-06-11 18:45:02.258875
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        SemanticVersion.from_loose_version("1.0.0")
    except ValueError:
        assert False, "Got ValueError when trying to convert 1.0.0"

    try:
        SemanticVersion.from_loose_version("1.0.0-alpha.1")
    except ValueError:
        assert False, "Got ValueError when trying to convert 1.0.0-alpha.1"

    try:
        SemanticVersion.from_loose_version("1.0.0-build1+sha.6f06f6f")
    except ValueError:
        assert False, "Got ValueError when trying to convert 1.0.0-build1+sha.6f06f6f"


# Generated at 2022-06-11 18:45:11.360952
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # test that it converts a LooseVersion into a SemanticVersion
    loose_version = LooseVersion('foo-1.0.0bar')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.0.0'

    # test that it converts a version with a build metadata into a SemanticVersion
    loose_version = LooseVersion('1.0.0-foo.bar+baz')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '1.0.0-foo.bar'

    # test that it converts a version with a prerelease into a SemanticVersion
    loose_version = LooseVersion('1.0.0-foo.bar+baz')

# Generated at 2022-06-11 18:45:21.183192
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
	assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
	assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
	assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+12345')) == SemanticVersion('1.2.3+12345')
	assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+12345')) == SemanticVersion('1.2.3-alpha+12345')


# Generated at 2022-06-11 18:45:27.561755
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion is not intialized, an exception ValueError is expected
    try:
        SemanticVersion.from_loose_version(None)
    except Exception as e:
        assert e.__str__() == "None is not a LooseVersion"
    else:
        assert False

    # LooseVersion has non integer values, an exception ValueError is expected
    try:
        SemanticVersion.from_loose_version(LooseVersion("1.0beta"))
    except Exception as e:
        assert e.__str__() == "Non integer values in LooseVersion ('1.0beta')"
    else:
        assert False

    # LooseVersion has integer values, but the version string is not a valid semantic version

# Generated at 2022-06-11 18:45:37.262226
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.1')) == '0.1.1'
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.1-rc1.0')) == '0.1.1-rc1.0'

    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')) == '1.1.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1-rc1.0')) == '1.1.1-rc1.0'



# Generated at 2022-06-11 18:45:49.004093
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:45:55.599626
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(
        LooseVersion('0.9.1+test')
    ) == SemanticVersion('0.9.1+test')

# Generated at 2022-06-11 18:46:08.014683
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0a0')) == SemanticVersion('1.0.0-a0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0-a0')) == SemanticVersion('1.0.0-a0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0-a0')) == SemanticVersion('1.0.0-a0')
    assert SemanticVersion.from_loose

# Generated at 2022-06-11 18:46:20.332512
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')

    # This is the first example from the spec
    # https://semver.org/#is-there-a-suggested-regular-expression-regex-to-check-a-semver-string

# Generated at 2022-06-11 18:46:29.715540
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    " test_SemanticVersion_from_loose_version "
    from ansible.module_utils.common.version import LooseVersion
    from ansible.module_utils.six import ensure_text

    assert ensure_text(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == '1.2.3'
    assert ensure_text(SemanticVersion.from_loose_version(LooseVersion('1.2.3-1'))) == '1.2.3-1'
    assert ensure_text(SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))) == '1.2.3'

# Generated at 2022-06-11 18:46:42.804709
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.parsing.convert_bool import boolean


# Generated at 2022-06-11 18:46:55.161213
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test when loose_version is not a LooseVersion
    try:
        SemanticVersion.from_loose_version('1.0')
        assert False
    except ValueError:
        pass

    # Test when loosely_version has non-integer constituent parts
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.0.1a'))
        assert False
    except ValueError:
        pass

    # Test equivalence between loosely_version and stringified SemanticVersion

# Generated at 2022-06-11 18:47:05.992985
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.0")) == SemanticVersion("0.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3")
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.0-alpha")) == SemanticVersion("0.0.0-alpha")
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.0-alpha.1")) == SemanticVersion("0.0.0-alpha.1")
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-11 18:47:15.823472
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    versions = [
        ('1.1.1.1+20130313144700.123', '1.1.1'),
        ('1.1.1', '1.1.1'),
        ('1.1', '1.1.0'),
        ('1', '1.0.0'),
        ('0.2.4b1', '0.2.4-b1'),
        ('0.0.0', '0.0.0'),
    ]
    for loose_string, semver_string in versions:
        loose_version = LooseVersion(loose_string)
        semver_version = SemanticVersion.from_loose_version(loose_version)

        assert semver_version.vstring == semver_string

# Generated at 2022-06-11 18:47:26.385602
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # This is the equivalent of
    # distutils.version.LooseVersion('1.2.3.dev2+githash')
    v1 = LooseVersion('1.2.3.dev2+githash')
    assert(isinstance(v1, LooseVersion))

    # Check that we are creating a SemanticVersion from a LooseVersion
    v2 = SemanticVersion.from_loose_version(v1)
    assert(isinstance(v2, SemanticVersion))

    # Check that we can compare the two
    assert(v1 > v2)
    assert(v2 == '1.2.3')
    assert(v1 != v2)


# Generated at 2022-06-11 18:47:33.582804
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    This function tests the functionality of the function ``from_loose_version``
    of class ``SemanticVersion``.
    """
    loose = LooseVersion('1.0')
    semver = SemanticVersion.from_loose_version(loose)
    assert semver.major == 1
    assert semver.minor == 0
    assert semver.patch == 0
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    loose = LooseVersion('1.0.5')
    semver = SemanticVersion.from_loose_version(loose)
    assert semver.major == 1
    assert semver.minor == 0
    assert semver.patch == 5
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    loose = Loose

# Generated at 2022-06-11 18:47:47.042922
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha+build')) == SemanticVersion('1.2.3-alpha+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build')) == SemanticVersion('1.2.3+build')

# Generated at 2022-06-11 18:47:58.718446
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.distro import Distro
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import PY3

    module = AnsibleModule(
        argument_spec=dict(
            version=dict(type='str'),
            gte=dict(type='str'),
            lt=dict(type='str'),
        ),
    )

    distro = Distro(module)

    if not PY3:
        assert SemanticVersion.from_loose_version(distro.version_info(major=True)).vstring == '1'
        assert SemanticVersion.from_loose_version(distro.version_info(major=True)).major == 1


# Generated at 2022-06-11 18:48:08.869989
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Given a LooseVersion with a valid non-semver string
    loose_version = LooseVersion('test')
    # When I attempt to construct a SemanticVersion
    # Then I should see a ValueError
    try:
        SemanticVersion.from_loose_version(loose_version)
        assert False
    except ValueError:
        assert True

    # Given a LooseVersion initialized with a semver string
    loose_version = LooseVersion('1.0.0')
    # When I attempt to construct a SemanticVersion
    # Then I should see a ValueError
    try:
        SemanticVersion.from_loose_version(loose_version)
        assert False
    except ValueError:
        assert True

    # Given a LooseVersion initialized with a semver string and a
    # non-integer version
    loose

# Generated at 2022-06-11 18:48:20.766812
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-pre")) == SemanticVersion("1.0.0-pre")

# Generated at 2022-06-11 18:48:31.667976
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Ensure that SemanticVersion.from_loose_version produces proper
    results
    """

    loose_version_strings = [
        '0.0.1',
        '1.12.3',
        '1.0.3-pre.2',
        '1.0.3-rc.3',
        '1.0.3-pre.1+build.9',
        '1.0.3+build.9',
    ]

    for loose_version_string in loose_version_strings:
        loose_version = LooseVersion(loose_version_string)
        sv = SemanticVersion.from_loose_version(loose_version)
        assert isinstance(sv, SemanticVersion)
        assert isinstance(sv.major, int)
        assert isinstance(sv.minor, int)


# Generated at 2022-06-11 18:48:42.667503
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Invalid version
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('1.2a')
    # Invalid type
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('1.2.3')
    # Invalid type
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(1)

    # Basic Version
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4a.b.c')) == SemanticVersion('1.2.3-4a.b.c')
    assert SemanticVersion

# Generated at 2022-06-11 18:48:55.753597
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests for expected failures
    errors = ['', 'abc', '-abc', 'abc-', 'abc.123', 'abc-123']
    for error in errors:
        try:
            SemanticVersion.from_loose_version(LooseVersion(error))
        except ValueError:
            pass
        else:
            assert False, 'expected failure for %s' % error

    # Tests for expected passes

# Generated at 2022-06-11 18:49:03.865292
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha.1")) == SemanticVersion("1.2.3-alpha.1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3+20130313144700")) == SemanticVersion("1.2.3+20130313144700")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-rc1+20130313144700")) == SemanticVersion("1.2.3-rc1+20130313144700")

# Generated at 2022-06-11 18:49:09.316938
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    import pytest
    assert SemanticVersion.from_loose_version(LooseVersion('1'))._cmp('1.0.0') == 0
    assert SemanticVersion.from_loose_version(LooseVersion('1.0'))._cmp('1.0.0') == 0
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3'))._cmp('1.2.3') == 0
    assert SemanticVersion.from_loose_version(LooseVersion('1.0rc1'))._cmp('1.0.0rc1') == 0

# Generated at 2022-06-11 18:49:21.323358
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')) == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0a1')) == SemanticVersion('1.0.0-a1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0a0.1')) == SemanticVersion('1.0.0-a0.1')
    assert SemanticVersion

# Generated at 2022-06-11 18:49:39.189893
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with LooseVersion
    assert(SemanticVersion.from_loose_version(LooseVersion("v0.2.2")) == SemanticVersion("0.2.2"))
    # Test with LooseVersion string argument
    assert(SemanticVersion.from_loose_version(LooseVersion("1.2.4")) == SemanticVersion("1.2.4"))
    # Test with dictionary argument
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version({})
    # Test with None argument
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(None)
    # Test with invalid LooseVersion argument

# Generated at 2022-06-11 18:49:46.583453
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    expected = ('1', '2', '3', 'beta.2+build.invalid', ('beta', 2, 'build', 'invalid'))
    loose = LooseVersion('1.2.3-beta.2+build.invalid')
    version = SemanticVersion.from_loose_version(loose)
    assert (
        version.major, version.minor, version.patch,
        version.vstring, version.prerelease + version.buildmetadata
    ) == expected


# Generated at 2022-06-11 18:49:59.225598
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:50:12.416992
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    for vstring, expected_vstring in (
            ('4', '4.0.0'),
            ('4.2', '4.2.0'),
            ('4.2.1', '4.2.1'),
            ('4.2.1-alpha', '4.2.1-alpha'),
            ('4.2.1-1', '4.2.1-1'),
            ('4.2.1+build.1', '4.2.1+build.1'),
            ('4.2.1-alpha.1+build.1', '4.2.1-alpha.1+build.1'),
    ):
        loose_version = LooseVersion(vstring)
        actual = SemanticVersion.from_loose_version(loose_version)
        assert actual == SemanticVersion(expected_vstring)

# Generated at 2022-06-11 18:50:24.644447
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    Test the SemanticVersion.from_loose_version method
    '''
    assert SemanticVersion.from_loose_version(LooseVersion('0.9.9')) == SemanticVersion('0.9.9')
    assert SemanticVersion.from_loose_version(LooseVersion('0.9.9.5')) == SemanticVersion('0.9.9')
    assert SemanticVersion.from_loose_version(LooseVersion('0.9.9.5+exp.sha.5114f85')) == SemanticVersion('0.9.9+exp.sha.5114f85')

# Generated at 2022-06-11 18:50:37.129728
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert v1.vstring == '1.2.3'

    v2 = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert v2.vstring == '1.2.3'

    v3 = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5'))
    assert v3.vstring == '1.2.3'

    v4 = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4+5'))
    assert v4.vstring == '1.2.3+5'


# Generated at 2022-06-11 18:50:46.091402
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion('3.3')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv == '3.3.0'

    lv = LooseVersion('3.3.2')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv == '3.3.2'

    lv = LooseVersion('3.3.2-alpha')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv == '3.3.2-alpha'

    lv = LooseVersion('3.3.2-alpha2')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv == '3.3.2-alpha2'


# Generated at 2022-06-11 18:50:54.141822
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # SemanticVersion.from_loose_version()
    s = '14.0.0.0-final'
    v = LooseVersion(s)
    sem_v = SemanticVersion.from_loose_version(v)
    assert (sem_v == '14.0.0-final'), "Expected '14.0.0-final', got '%s'" % sem_v.vstring


# Generated at 2022-06-11 18:51:03.081436
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils.six import PY3

    # simple conversion from a LooseVersion
    lv = LooseVersion('1.2.3')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == '1.2.3'

    # check for the presence of a loose version prerelease value
    lv = LooseVersion('1.2.3-foo')
    # Py2 has this class as a named tuple, Py3 replaces it with a list
    assert isinstance(lv.version, (list, tuple))

    # Py2 has this class as a named tuple, Py3 replaces it with a list
    assert isinstance(lv.version[0], int)

# Generated at 2022-06-11 18:51:11.994777
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils.compat.semver import SemanticVersion

    class TestClass:
        def __init__(self, vstring):
            self.vstring = vstring
            self.version = vstring.split('.')

    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')).vstring == '1.2.3-alpha'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build01')).vstring == '1.2.3+build01'