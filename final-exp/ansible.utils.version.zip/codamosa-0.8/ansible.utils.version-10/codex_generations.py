

# Generated at 2022-06-11 18:42:23.673218
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    # Parsing a string with an invalid semantic version should raise an exception
    try:
        SemanticVersion("1.a.0")
    except ValueError:
        pass
    else:
        raise Exception("Exception not raised")

    try:
        SemanticVersion("a.1.0")
    except ValueError:
        pass
    else:
        raise Exception("Exception not raised")

    try:
        SemanticVersion("1.1.1.1")
    except ValueError:
        pass
    else:
        raise Exception("Exception not raised")

    try:
        SemanticVersion("1.1.1-a")
    except ValueError:
        pass
    else:
        raise Exception("Exception not raised")


# Generated at 2022-06-11 18:42:36.125278
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """Test the parse method of SemanticVersion"""

# Generated at 2022-06-11 18:42:47.637161
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:42:59.625670
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from distutils.version import LooseVersion
    SemanticVersion.from_loose_version(LooseVersion("1.2.3"))
    # This should work, too
    SemanticVersion.from_loose_version("1.2.3")

    # This one, not so much
    try:
        SemanticVersion.from_loose_version(12)
        assert False
    except ValueError:
        pass

    # This one should work, too
    SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha"))

    # This one, not so much
    try:
        SemanticVersion.from_loose_version(LooseVersion("1.2.3b"))
        assert False
    except ValueError:
        pass

    # Builder metadata should be ignored

# Generated at 2022-06-11 18:43:07.712428
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # assert with valid version string
    try:
        semantic_version_object = SemanticVersion('1.2.3')
        assert semantic_version_object.major == 1
        assert semantic_version_object.minor == 2
        assert semantic_version_object.patch == 3
        assert semantic_version_object.prerelease == ()
        assert semantic_version_object.buildmetadata == ()
    except Exception as e:
        assert False, "should not raise an exception"

    # assert with invalid version string
    try:
        semantic_version_object = SemanticVersion('foo')
        assert False, "should raise an exception"
    except ValueError as e:
        pass

    # assert with version string with prerelease

# Generated at 2022-06-11 18:43:20.188820
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version1 = LooseVersion('0.0.0-alpha.1')
    semver1 = SemanticVersion.from_loose_version(loose_version1)
    assert semver1.vstring == '0.0.0-alpha.1'
    loose_version2 = LooseVersion('1.2.3')
    semver2 = SemanticVersion.from_loose_version(loose_version2)
    assert semver2.vstring == '1.2.3'

    # Test that ValueError is raised when input is wrong type
    with pytest.raises(ValueError):
        semver1 = SemanticVersion.from_loose_version('0.0.0-alpha.1')
    # Test that ValueError is raised when input has non-integer components

# Generated at 2022-06-11 18:43:31.844806
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """ Unit test for method parse of class SemanticVersion """

    # This test case covers single digit major, minor, and patch numbers,
    # pre-release, and build metadata
    vstring = '1.2.3-alpha.1+12345'
    semver = SemanticVersion(vstring)

    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == (
        _Numeric(1),
        _Alpha('alpha'),
        _Numeric(1)
    )
    assert semver.buildmetadata == (
        _Alpha('12345')
    )

    # Test case for trying to parse an invalid vstring
    # should raise a ValueError

# Generated at 2022-06-11 18:43:40.977187
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """Tests that method parse of class SemanticVersion works as expected."""
    result = SemanticVersion('0.10.0')
    assert result.major == 0
    assert result.minor == 10
    assert result.patch == 0
    assert result.prerelease == ()
    assert result.buildmetadata == ()
    assert result.is_prerelease is False
    assert result.is_stable is False
    assert result.matching_major('0.1.1') is True
    assert result.matching_minor('0.10.1') is True
    assert result.matching_patch('0.10.0') is True
    assert result.matching_major('1.1.1') is False
    assert result.matching_minor('1.11.1') is False

# Generated at 2022-06-11 18:43:54.252157
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.1')) == SemanticVersion('1.0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.1+build')) == SemanticVersion('1.0.1+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.1-prerelease.1')) == SemanticVersion('1.0.1-prerelease.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.1-prerelease.1+build')) == SemanticVersion('1.0.1-prerelease.1+build')

    assert SemanticVersion.from_loose_version(LooseVersion('v1.0.1')) == Sem

# Generated at 2022-06-11 18:44:01.120517
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1+build.1')) == SemanticVersion('1.2.3-alpha.1+build.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
   

# Generated at 2022-06-11 18:44:22.147217
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion
    assert SemanticVersion.from_loose_version(lv('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(lv('1.2.3a')) == SemanticVersion('1.2.3-a')
    assert SemanticVersion.from_loose_version(lv('1.2.3.4')) == SemanticVersion('1.2.3.4')
    assert SemanticVersion.from_loose_version(lv('1.2.3-4')) == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version(lv('1.2.3.4-5')) == SemanticVersion('1.2.3.4-5')

# Generated at 2022-06-11 18:44:30.831439
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.distro_facts.version import SemanticVersion
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils._text import to_text

    def SemanticVersion_from_loose_version(loose_version):
        return to_text(SemanticVersion.from_loose_version(loose_version))

    assert SemanticVersion_from_loose_version(LooseVersion('1.2.3-alpha.1+build.123')) == '1.2.3-alpha.1+build.123'
    assert SemanticVersion_from_loose_version(LooseVersion('1.2.3-alpha.1')) == '1.2.3-alpha.1'

# Generated at 2022-06-11 18:44:39.375357
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:44:50.375111
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

# Generated at 2022-06-11 18:45:01.514135
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # in case of LooseVersion
    v1 = LooseVersion("1.0")
    v2 = LooseVersion("1.1")
    v3 = LooseVersion("1.1.1")
    v4 = LooseVersion("1.1.1.1")

    # from_loose_version method returns SemanticVersion
    assert isinstance(SemanticVersion.from_loose_version(v1), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(v2), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(v3), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(v4), SemanticVersion)

    # 'from_loose_version' method with LooseVersion

# Generated at 2022-06-11 18:45:06.107007
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    r = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert r == '1.2.3'
    r = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert r == '1.2.3.4'
    r = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5'))
    assert r == '1.2.3.4.5'
    r = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5.6'))
    assert r == '1.2.3.4.5'

# Generated at 2022-06-11 18:45:19.299698
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test against string values
    assert SemanticVersion.from_loose_version('0.0.0a1') != '0.0.0a2'
    assert SemanticVersion.from_loose_version('0.0.0a1') < '0.0.0a2'
    assert SemanticVersion.from_loose_version('0.0.0a2') > '0.0.0a1'
    assert SemanticVersion.from_loose_version('0.0.0a1') != '0.0.0a1.dev1'
    assert SemanticVersion.from_loose_version('0.0.0a1') < '0.0.0a1.dev1'

# Generated at 2022-06-11 18:45:32.492417
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:45:40.405594
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    target = SemanticVersion("1.2.3-alpha.1")
    assert SemanticVersion.from_loose_version(LooseVersion("v1.2.3-alpha.1")) == target
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha.1")) == target
    assert SemanticVersion.from_loose_version(SemanticVersion("1.2.3-alpha.1")) == target
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == target
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha.1+build1")) == target

# Generated at 2022-06-11 18:45:51.652524
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.version_compare import SemanticVersion
    from ansible.module_utils.compat.version import LooseVersion

    module = AnsibleModule(argument_spec={}, supports_check_mode=False)

    # Invalid value
    try:
        SemanticVersion.from_loose_version([])
    except ValueError as e:
        module.exit_json(msg='is_error: %r, error_message: %r' % (isinstance(e, ValueError), str(e)))

    # Valid value, invalid type

# Generated at 2022-06-11 18:46:08.212222
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with string and parsed versions
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version('1.2.3+build') == SemanticVersion('1.2.3+build')
    assert SemanticVersion.from_loose_version('1.2.3-alpha') == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version('1.2.3-alpha+build') == SemanticVersion('1.2.3-alpha+build')

    a = SemanticVersion.from_loose_version(SemanticVersion('1.2.3'))
    b = SemanticVersion('1.2.3')
    assert a == b

    a = Sem

# Generated at 2022-06-11 18:46:20.493669
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test if SemanticVersion is initialized correctly
    #
    # Args:
    #   loose_version: instance of class LooseVersion
    #   expected_version: expected result as string of instance of class SemanticVersion
    #
    # Returns:
    #   True when an invalid value is passed.
    #   False when a valid value is passed.
    def test(loose_version, expected_version):
        test_sversion = SemanticVersion.from_loose_version(loose_version)
        assert isinstance(test_sversion, SemanticVersion), "Must be an instance of SemanticVersion."
        assert str(test_sversion) == expected_version, "Must be set to %s." % expected_version

    # Valid values

# Generated at 2022-06-11 18:46:29.775362
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test1: explicit version number
    loose_version = LooseVersion("2020.2.3")
    assert SemanticVersion.from_loose_version(loose_version) == "2020.2.3"

    # Test2: explicit version number with prerelease
    loose_version = LooseVersion("2020.2.3-rc1")
    assert SemanticVersion.from_loose_version(loose_version) == "2020.2.3-rc1"

    # Test3: explicit version number with prerelease and buildmetadata
    loose_version = LooseVersion("2020.2.3-rc1+abc.x.y.z")
    assert SemanticVersion.from_loose_version(loose_version) == "2020.2.3-rc1+abc.x.y.z"

    # Test4: explicit

# Generated at 2022-06-11 18:46:42.842509
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    instance = SemanticVersion.from_loose_version(LooseVersion('1:1.0'))
    assert instance.major == 1
    assert instance.minor == 0
    assert instance.patch == 0

    instance = SemanticVersion.from_loose_version(LooseVersion('invalid'))
    assert instance.major == 0
    assert instance.minor == 0
    assert instance.patch == 0

    # This is a very loose version, should still work
    instance = SemanticVersion.from_loose_version(LooseVersion('1.1.1-alpha+debian0'))
    assert instance.major == 1
    assert instance.minor == 1
    assert instance.patch == 1
    assert instance.prerelease == (_Alpha('alpha'),)
    assert instance.buildmetadata == tuple()


# Generated at 2022-06-11 18:46:55.197214
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:47:04.390667
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("0.0.0")) == SemanticVersion("0.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-alpha.1")) == SemanticVersion("1.0.0-alpha.1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-alpha.1+1")) == SemanticVersion("1.0.0-alpha.1+1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-1.2.3+4.5.6")) == SemanticVersion("1.0.0-1.2.3+4.5.6")

# Generated at 2022-06-11 18:47:15.044418
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # test from_loose_version method
    # the input is a LooseVersion object and the output is a SemanticVersion object
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.0')) == SemanticVersion('2.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.0.1')) == SemanticVersion('2.0.0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.0-1')) == SemanticVersion('2.0.0-1')
    assert SemanticVersion.from_loose_version(LooseVersion('2.0.0-1.0')) == SemanticVersion('2.0.0-1.0')
    assert SemanticVersion.from_

# Generated at 2022-06-11 18:47:27.244088
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1+build')) == SemanticVersion('1.0.0-alpha.1+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-1.0')) == SemanticVersion('1.0.0-1.0')

# Generated at 2022-06-11 18:47:33.651240
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Version is without 'v' prefix
    loose_version = LooseVersion("1.0.0+build.1")
    abs_version = SemanticVersion("1.0.0+build.1")
    sem_version = SemanticVersion.from_loose_version(loose_version)
    assert sem_version == abs_version, ('from_loose_version: version {0} should be equals to version {1}'
                                        .format(sem_version, abs_version))

    # Version is with 'v' prefix
    loose_version = LooseVersion("v1.0.0+build.1")
    abs_version = SemanticVersion("1.0.0+build.1")
    sem_version = SemanticVersion.from_loose_version(loose_version)
    assert sem_version == abs_

# Generated at 2022-06-11 18:47:42.667977
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.4.4")) == SemanticVersion("1.4.4")
    assert SemanticVersion.from_loose_version(LooseVersion("1.4.4-1")) == SemanticVersion("1.4.4-1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.4.4.1.1")) == SemanticVersion("1.4.4")
    assert SemanticVersion.from_loose_version(LooseVersion("1.4.4.3")) == SemanticVersion("1.4.4")
    assert SemanticVersion.from_loose_version(LooseVersion("1.4.4-1.1.1")) == SemanticVersion("1.4.4-1.1.1")

# Generated at 2022-06-11 18:48:02.482793
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Expected to return true
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1')) == SemanticVersion('0.0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1-rc1.0')) == SemanticVersion('0.0.1-rc1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1-a1b2c3')) == SemanticVersion('0.0.1-a1b2c3')
    # Expected to raise ValueError
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1a')) == ValueError

# Generated at 2022-06-11 18:48:12.120325
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.11-alpha.1')) == SemanticVersion('1.11-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.11-dev.0+1.g6444444444444444444444444444444444444444')) == SemanticVersion('1.11-dev.0+1.g6444444444444444444444444444444444444444')

# Generated at 2022-06-11 18:48:23.258384
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    result = SemanticVersion.from_loose_version(LooseVersion('1.10.12-alpha.1'))
    assert result == SemanticVersion('1.10.12-alpha.1')

    result = SemanticVersion.from_loose_version(LooseVersion('1.10.12-alpha.1+build123'))
    assert result == SemanticVersion('1.10.12-alpha.1+build123')

    result = SemanticVersion.from_loose_version(LooseVersion('1.10.12-10.8'))
    assert result == SemanticVersion('1.10.12-10.8')

    result = SemanticVersion.from_loose_version(LooseVersion('1.10.12.10'))
    assert result == SemanticVersion('1.10.12')


# Generated at 2022-06-11 18:48:35.761493
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
   assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
   assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
   assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.0')) == SemanticVersion('1.2.3')
   assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.0.0')) == SemanticVersion('1.2.3')
   # Test for non-integer values

# Generated at 2022-06-11 18:48:47.513905
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import random
    import string
    from ansible.module_utils.common.version import SemanticVersion, LooseVersion

    # Generate random alphanumeric string of length between 0 and 3
    def gen_alphanum_str(length):
        string.ascii_letters + string.digits
        return ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(random.randint(0, 3)))
    
    # Generate a random LooseVersion with core version, prerelease, and buildmetadata
    def gen_loose_version():
        core_length = random.randint(0, 3)
        core = tuple(random.randint(0, 10) for _ in range(core_length))
        prerelease_length = random.randint(0, 3)
        pre

# Generated at 2022-06-11 18:48:54.153429
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # input arguments
    loose_version = LooseVersion('2.0.0')

    # method to test
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # expected result
    expected_result = SemanticVersion('2.0.0')

    assert semantic_version == expected_result, "Unexpected result"


# Generated at 2022-06-11 18:49:02.118273
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3

    versions = [
        "0.0.1",
        "1.0.0",
        "2.0.0",
        "1.1.0",
        "1.0.1",
        "0.1.2",
        "0.0.0",
    ]

    if PY3:
        versions = tuple(text_type(v) for v in versions)

    for version in versions:
        loose = LooseVersion(version)
        s = SemanticVersion.from_loose_version(loose)
        assert text_type(loose) == text_type(s)


# Unit tests for class SemanticVersion

# Generated at 2022-06-11 18:49:12.287819
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.5.26')) == SemanticVersion('0.5.26')
    assert SemanticVersion.from_loose_version(LooseVersion('0.5')) == SemanticVersion('0.5.0')

# Generated at 2022-06-11 18:49:22.270513
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.0.0'

    loose_version = '1.0.1'
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.0.1'

    loose_version = LooseVersion('1.0.1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.0.1'

    loose_version = '1.2.3-alpha'
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == '1.2.3-alpha'

    loose_

# Generated at 2022-06-11 18:49:34.579316
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.0.0'
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch == 0
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()

    loose_version = LooseVersion('1.0.0-alpha.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '1.0.0-alpha.1'
    assert semantic_version.major == 1
    assert semantic_version.minor == 0
    assert semantic_version.patch

# Generated at 2022-06-11 18:50:03.690435
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2
    if PY2:
        from distutils.version import LooseVersion

        assert(SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3'))
        assert(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha'))
        assert (SemanticVersion.from_loose_version(LooseVersion('1.2.3.alpha')) == SemanticVersion('1.2.3-alpha'))
        assert (SemanticVersion.from_loose_version(LooseVersion('1.2.3-5')) == SemanticVersion('1.2.3-5'))

# Generated at 2022-06-11 18:50:07.436442
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0.4')
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion('1.0.4')



# Generated at 2022-06-11 18:50:13.088915
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semver_string = '1.1.0'
    semver = SemanticVersion(semver_string)
    loose_version = LooseVersion(semver_string)
    semver_from_loose_version = SemanticVersion.from_loose_version(loose_version)
    assert semver == semver_from_loose_version

# Generated at 2022-06-11 18:50:25.324424
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    with pytest.raises(ValueError) as exc_info:
        SemanticVersion.from_loose_version(1)
    assert "1 is not a LooseVersion" in str(exc_info.value)

    with pytest.raises(ValueError) as exc_info:
        SemanticVersion.from_loose_version("2.3")
    assert "2.3 is not a LooseVersion" in str(exc_info.value)

    with pytest.raises(ValueError) as exc_info:
        SemanticVersion.from_loose_version("2.3-4.5")
    assert "2.3-4.5 is not a LooseVersion" in str(exc_info.value)

    with pytest.raises(ValueError) as exc_info:
        SemanticVersion.from_

# Generated at 2022-06-11 18:50:38.107064
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Case 1: Case where a "LooseVersion" is supplied
    assert SemanticVersion.from_loose_version(LooseVersion('15.2.2')) == SemanticVersion('15.2.2')
    # Case 2: Case where a "SemanticVersion" is supplied
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(SemanticVersion('15.2.2'))
    # Case 3: Case where a "str" is supplied
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('15.2.2')
    # Case 4: Case where a non-version string is supplied
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('1.2.3.dev1')



# Generated at 2022-06-11 18:50:46.553297
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == '1.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == '1.2.3-alpha.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.alpha.1')) == '1.2.3-alpha.1'

# Generated at 2022-06-11 18:50:58.613708
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    result = SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5.6+7.8.9'))
    assert result.major == 1
    assert result.minor == 2
    assert result.patch == 3
    assert result.prerelease == (_Numeric(4), _Numeric(5), _Numeric(6))
    assert result.buildmetadata == (_Numeric(7), _Numeric(8), _Numeric(9))
    # LooseVersion string without metadata
    result = SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5.6'))
    assert result.major == 1
    assert result.minor == 2
    assert result.patch == 3

# Generated at 2022-06-11 18:51:08.340132
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases = [
        ('1.2.3.1', '1.2.3'),
        ('1.2.3-1', '1.2.3-1'),
        ('1.2.3.final', '1.2.3'),
        ('1.2.3-1.final', '1.2.3-1'),
        ('1.2.3.1+2.3', '1.2.3+2.3'),
    ]

    for loose, semver in test_cases:
        assert text_type(SemanticVersion.from_loose_version(
            LooseVersion(loose)
        )) == semver


# Generated at 2022-06-11 18:51:19.549544
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Test with a number
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('0')), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion(0)), SemanticVersion)

    # Test with a string
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('0.0.0')), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('0.0.0.0')), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('0.0.0-0.0')), SemanticVersion)

# Generated at 2022-06-11 18:51:31.296233
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test the output of SemanticVersion.from_loose_version
    with specific LooseVersion input (which is meant to
    be generated from distutils.version.LooseVersion)
    """
    from ansible.module_utils.basic import AnsibleModule

    lversion = LooseVersion("10.0.0")
    input = SemanticVersion.from_loose_version(lversion)
    expected = SemanticVersion("10.0.0")
    assert input == expected, "%s != %s" % (input, expected)

    lversion = LooseVersion("10.0.0-1")
    input = SemanticVersion.from_loose_version(lversion)
    expected = SemanticVersion("10.0.0-1")
    assert input == expected, "%s != %s" % (input, expected)