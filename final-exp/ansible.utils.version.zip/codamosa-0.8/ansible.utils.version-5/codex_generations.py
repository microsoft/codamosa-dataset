

# Generated at 2022-06-11 18:42:36.449856
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert sv.vstring == '1.2.3'
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert sv.vstring == '1.2.3'
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3a'))
    assert sv.vstring == '1.2.3-a'
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2a.3'))
    assert sv.vstring == '1.2-a.3'

# Generated at 2022-06-11 18:42:41.605662
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv_str = LooseVersion('0.0.1-beta.1')
    sv_str = SemanticVersion.from_loose_version(lv_str)
    assert sv_str == '0.0.1-beta.1'

    lv_0 = LooseVersion('0')
    sv_0 = SemanticVersion.from_loose_version(lv_0)
    assert sv_0 == '0.0.0'

    lv_1 = LooseVersion('1')
    sv_1 = SemanticVersion.from_loose_version(lv_1)
    assert sv_1 == '1.0.0'

    lv_1_1 = LooseVersion('1.1')
    sv_1_1 = SemanticVersion.from_loose_version(lv_1_1)
   

# Generated at 2022-06-11 18:42:51.203667
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:43:02.250669
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion('123.456.789')
    assert v.vstring == '123.456.789'
    assert v.major == 123
    assert v.minor == 456
    assert v.patch == 789
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion('123.456.789-beta')
    assert v.vstring == '123.456.789-beta'
    assert v.major == 123
    assert v.minor == 456
    assert v.patch == 789
    assert v.prerelease == ('beta',)
    assert v.buildmetadata == ()

    v = SemanticVersion('123.456.789+build')
    assert v.vstring == '123.456.789+build'
    assert v.major == 123
    assert v

# Generated at 2022-06-11 18:43:13.172030
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion('1.2.3').parse('1.2.3') == (1, 2, 3, (), ())
    assert SemanticVersion('1.2.3-alpha.1+foo.bar.baz').parse('1.2.3-alpha.1+foo.bar.baz') == (1, 2, 3, ('alpha', '1'), ('foo', 'bar', 'baz'))
    assert SemanticVersion('1.2.3.alpha').parse('1.2.3.alpha') == (1, 2, 3, ('alpha',), ())
    assert SemanticVersion('1.2.3.alpha.beta').parse('1.2.3.alpha.beta') == (1, 2, 3, ('alpha', 'beta'), ())

# Generated at 2022-06-11 18:43:24.778921
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion()
    version.parse('1.0.0')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version.parse('1.0.0-alpha')
    assert version.major == 1
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == (_Alpha('alpha'),)
    assert version.buildmetadata == ()

    version.parse('0.1.0-beta.1')
    assert version.major == 0
    assert version.minor == 1
    assert version.patch == 0
    assert version.prerelease == (_Alpha('beta'), _Numeric(1))
    assert version.buildmetadata == ()


# Generated at 2022-06-11 18:43:33.092929
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_0 = LooseVersion('1.2.3')
    semver_0 = SemanticVersion.from_loose_version(loose_version_0)
    assert semver_0.major == loose_version_0.version[0]
    assert semver_0.minor == loose_version_0.version[1]
    assert semver_0.patch == loose_version_0.version[2]

    loose_version_1 = LooseVersion('1.2dev3')
    semver_1 = SemanticVersion.from_loose_version(loose_version_1)
    assert semver_1.major == loose_version_1.version[0]
    assert semver_1.minor == loose_version_1.version[1]
    assert semver_1.patch == 0


# Generated at 2022-06-11 18:43:42.889888
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    class TestCase(object):

        def __init__(
            self,
            vstring,
            major=None,
            minor=None,
            patch=None,
            prerelease=None,
            buildmetadata=None,
        ):
            self.vstring = vstring
            self.major = major
            self.minor = minor
            self.patch = patch
            self.prerelease = prerelease
            self.buildmetadata = buildmetadata


# Generated at 2022-06-11 18:43:55.870042
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:44:08.034512
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    v.parse('v1.2.3a')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == (_Alpha('a'),)
    assert v.buildmetadata == ()
    assert v.is_stable == False

    v.parse('v1.2.3')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()
    assert v.is_stable == True

    v.parse('1.2.3+build')
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.build

# Generated at 2022-06-11 18:44:23.967943
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def test_loose_version(loose_version, expected_semver):
        semver = SemanticVersion.from_loose_version(loose_version)
        assert semver._cmp(expected_semver) == 0

    # Loose versions taken from
    # https://github.com/mgedmin/check-manifest
    test_loose_version(
        LooseVersion('1.2.3'),
        SemanticVersion('1.2.3'),
    )
    test_loose_version(
        LooseVersion('1.2.3dev'),
        SemanticVersion('1.2.3-dev'),
    )
    test_loose_version(
        LooseVersion('1.2.3dev1'),
        SemanticVersion('1.2.3-dev.1'),
    )
   

# Generated at 2022-06-11 18:44:31.321092
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert SemanticVersion("0.0.4").major == 0
    assert SemanticVersion("0.0.4").minor == 0
    assert SemanticVersion("0.0.4").patch == 4
    assert SemanticVersion("0.0.4").prerelease == ()
    assert SemanticVersion("0.0.4").buildmetadata == ()
    assert SemanticVersion("0.0.4-rc.1").prerelease == ("rc", _Numeric("1"))
    assert SemanticVersion("0.0.4+20130313144700").buildmetadata == ("20130313144700",)
    assert SemanticVersion("1.0.0-rc.1+20130313144700").buildmetadata == ("20130313144700",)
    assert SemanticVersion("1.0.0").buildmetadata == ()

# Generated at 2022-06-11 18:44:34.982778
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.16.0")
    # Act
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    # Assert
    assert semantic_version == "1.16.0"


# Generated at 2022-06-11 18:44:41.529976
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:44:51.249329
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_versions = {
            '1': '1.0.0',
            '1.2': '1.2.0',
            '1.2.3': '1.2.3',
            '1.2.3-foo': '1.2.3-foo',
            '1.2.3-1.2': '1.2.3-1.2',
            '1.2.3+bar': '1.2.3+bar',
            '1.2.3+foo.bar': '1.2.3+foo.bar',
            '1.2.3-a.b.c+foo.bar': '1.2.3-a.b.c+foo.bar',
            }

    for loose_version, expected_result in loose_versions.items():
        result = SemanticVersion

# Generated at 2022-06-11 18:45:01.979362
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Argument is not a LooseVersion
    try:
        SemanticVersion.from_loose_version(None)
        assert False
    except ValueError:
        assert True

    # Test with a LooseVersion with a marker '-'
    try:
        loose_v = LooseVersion('1.2.3-alpha')
        semantic_v = SemanticVersion.from_loose_version(loose_v)
        assert semantic_v.major == 1
        assert semantic_v.minor == 2
        assert semantic_v.patch == 3
        assert semantic_v.prerelease == ('alpha',)
    except ValueError:
        assert False

    # Test with a LooseVersion with a marker '+'

# Generated at 2022-06-11 18:45:07.178125
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = LooseVersion('1.10.1b')
    s1 = SemanticVersion.from_loose_version(v1)
    assert isinstance(s1, SemanticVersion)

    v2 = LooseVersion('1.10.1')
    s2 = SemanticVersion.from_loose_version(v2)
    assert isinstance(s2, SemanticVersion)

# Generated at 2022-06-11 18:45:20.096291
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = '1'
    v2 = '1.2'
    v3 = '1.2.3'
    v4 = '1.2.3.4'
    v5 = '1.2.3.4.5'
    v6 = '1.2.3.4.5.6'
    v7 = '1.2.3-4.5.6'
    v8 = '1.2.3+4.5.6'
    v9 = '1.2.3-4+4.5.6'
    v10 = '1.2.3+4-4.5.6'
    v11 = '1.2.3-4.5.6+4'
    v12 = '1.2.3+4.5.6-4'

# Generated at 2022-06-11 18:45:33.465845
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion()
    version.parse('2.0.0-alpha.1')

    assert version.major == 2
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert version.core == (2, 0, 0)

    assert version.is_stable is False
    assert version.is_prerelease

    version.parse('1.0.0')

    assert version.prerelease == ()
    assert version.is_stable
    assert not version.is_prerelease

    version.parse('0.1.1-rc.1.2')

    assert version.prerelease == (_Alpha('rc'), _Numeric('1'), _Numeric('2'))
    assert not version.is_stable

# Generated at 2022-06-11 18:45:35.738896
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.2f.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    print('SemanticVersion obtained from LooseVersion: {}'.format(semantic_version))


# Generated at 2022-06-11 18:45:51.653176
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import reload_module
    reload_module(ansible.module_utils.compat.version)

    LooseVersion = ansible.module_utils.compat.version.LooseVersion

    # Test with a strict semver input
    v = LooseVersion('1.18.6')
    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.18.6')

    # Test with a non strict semver input
    v = LooseVersion('foo-bar.baz 1.2.3-alpha+1')
    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.2.3-alpha+1')

    # Test with a loose version that is a string
    v = 'foo 1.2.3-alpha'

# Generated at 2022-06-11 18:45:59.316166
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(
        LooseVersion('10.6.16')
    ).vstring == '10.6.16'

    assert SemanticVersion.from_loose_version(
        LooseVersion('10.6.16b2')
    ).vstring == '10.6.16-b2'

    assert SemanticVersion.from_loose_version(
        LooseVersion('10.6.16')
    ).is_stable is True

    assert SemanticVersion.from_loose_version(
        LooseVersion('10.6.16b2')
    ).is_stable is False

    assert SemanticVersion.from_loose_version(
        LooseVersion('10.6.16')
    ).is_prerelease is False

    assert SemanticVersion.from_loose_

# Generated at 2022-06-11 18:46:04.509659
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # simple case
    assert SemanticVersion.from_loose_version(
        LooseVersion('2.0')
    ) == SemanticVersion('2.0.0')

    # prerelease
    assert SemanticVersion.from_loose_version(
        LooseVersion('2.0.0rc1-1')
    ) == SemanticVersion('2.0.0-rc1.1')

    # build metadata
    assert SemanticVersion.from_loose_version(
        LooseVersion('2.0.0+build201912221603')
    ) == SemanticVersion('2.0.0+build201912221603')

    # mixed
    assert SemanticVersion.from_loose_version(
        LooseVersion('2.0.0rc1-1+build201912221603')
    )

# Generated at 2022-06-11 18:46:16.294382
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    assert SemanticVersion('1.2.3') == SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert SemanticVersion('1.2.4') == SemanticVersion.from_loose_version(LooseVersion('1.2.4'))
    assert SemanticVersion('1.2.5') == SemanticVersion.from_loose_version(LooseVersion('1.2.5'))
    assert SemanticVersion('2.2.5') == SemanticVersion.from_loose_version(LooseVersion('2.2.5'))
    assert SemanticVersion('0.2.5') == SemanticVersion.from_loose_version(LooseVersion('0.2.5'))

    assert SemanticVersion('1.2.3-beta1') == SemanticVersion

# Generated at 2022-06-11 18:46:27.363924
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test of SemanticVersion.from_loose_version"""
    class TestCase:
        """Test case.
        """

        def __init__(self, expected, input):
            self.expected = expected
            self.input = input

    def is_equal_semantic_versions(expected, actual):
        """Compare two SemanticVersion instances.

        Return True if the SemanticVersions are equal.
        """
        return expected._cmp(actual) == 0


# Generated at 2022-06-11 18:46:41.126680
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Check base functionality
    loose_version = LooseVersion('v1.0.0alpha1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == loose_version.vstring

    # Check py3 functionality
    loose_version = LooseVersion('v1.0.0alpha1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == loose_version.vstring

    # Check for ValueError on non LooseVersion input
    loose_version = "v1.0.0alpha1"
    exception_raised = False
    try:
        semantic_version = SemanticVersion.from_loose_version(loose_version)
    except ValueError:
        exception_raised = True
    assert exception

# Generated at 2022-06-11 18:46:47.390388
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    sv = SemanticVersion.from_loose_version(LooseVersion('10.20.30-40'))
    assert sv.major == 10
    assert sv.minor == 20
    assert sv.patch == 30
    assert sv.prerelease == (_Numeric(40),)
    assert sv.buildmetadata == ()



# Generated at 2022-06-11 18:46:52.925156
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion does not respect the prerelease or build metadata strings
    # SemanticVersion is a subclass of Version
    # Therefore we do not test LooseVersion < SemanticVersion comparisons

    assert SemanticVersion.from_loose_version(LooseVersion('2.2.1+abc-1')) == SemanticVersion('2.2.1+abc-1')
    assert SemanticVersion.from_loose_version(LooseVersion('2.2.1.a.bbb-1')) == SemanticVersion('2.2.1-a.bbb-1')
    assert SemanticVersion.from_loose_version(LooseVersion('2.2-1')) == SemanticVersion('2.2.0-1')


# Generated at 2022-06-11 18:47:05.322544
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:47:15.849258
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    class MyClass(object):
        def __init__(self, vstring):
            self.vstring = vstring

    # Input and expected output

# Generated at 2022-06-11 18:47:33.173406
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    if hasattr(SemanticVersion, 'from_loose_version'):
        # SemanticVersion.from_loose_version() Return SemanticVersion built
        # from LooseVersion string
        assert SemanticVersion.from_loose_version(LooseVersion('0.9.2')) == SemanticVersion('0.9.2')
        # SemanticVersion.from_loose_version() Return SemanticVersion built
        # from LooseVersion instance
        assert SemanticVersion.from_loose_version(LooseVersion('1.9.2')) == SemanticVersion('1.9.2')
        # SemanticVersion.from_loose_version() Return SemanticVersion built
        # from LooseVersion instance with pre-release

# Generated at 2022-06-11 18:47:42.583941
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion
    sample_version = Version('1.0.0')
    loose_version = LooseVersion('1.0.0')
    assert SemanticVersion.from_loose_version(loose_version) == sample_version
    loose_version = LooseVersion('1.0')
    assert SemanticVersion.from_loose_version(loose_version) == sample_version
    loose_version = LooseVersion('1')
    assert SemanticVersion.from_loose_version(loose_version) == sample_version
    loose_version = LooseVersion('1.0.0.a')
    sample_version = Version('1.0.0-a')
    assert SemanticVersion.from_loose_version(loose_version) == sample_version


# Generated at 2022-06-11 18:47:55.982252
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        # Try to import LooseVersion
        from ansible.module_utils.compat.version import LooseVersion
    except ImportError:
        raise Exception("LooseVersion does not exist. Might be a Python version < 2.7.")

    # Loose version with version as string
    loose_version_string = LooseVersion("1.2.3")

    # Create SemanticVersion object from LooseVersion object
    semantic_version_string = SemanticVersion.from_loose_version(loose_version_string)

    # Loose version with version as list
    loose_version_list = LooseVersion(['1', '2', '3'])

    # Create SemanticVersion object from LooseVersion object
    semantic_version_list = SemanticVersion.from_loose_version(loose_version_list)

    #

# Generated at 2022-06-11 18:48:05.072755
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:16.442122
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    Test that the method from_loose_version
    returns a SemanticVersion object.
    '''

# Generated at 2022-06-11 18:48:24.849442
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('2.0.9')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert (semantic_version.vstring == loose_version.vstring)
    loose_version = LooseVersion('2.3.4b1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert (semantic_version.vstring == '2.3.4-b1')
    loose_version = LooseVersion('2.3.4')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert (semantic_version.vstring == loose_version.vstring)

# Generated at 2022-06-11 18:48:37.266216
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases_valid = [
        ['0.4.2', '0.4.2+0'],
        ['0.4.2.b', '0.4.2+b'],
        ['0.4.2-b.3', '0.4.2+b.3'],
        ['0.4.2', '0.4.2'],
        ['0.4.2.b', '0.4.2.b'],
        ['0.4.2-b.3', '0.4.2-b.3'],
        ['0.4.2', '0.4.2-0']
    ]
    test_cases_invalid = [
        '0.4.2',
        '0.4.2-b'
    ]

# Generated at 2022-06-11 18:48:47.684711
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_versions = [
        '0.0.0',
        '1.2.3',
        '1.2.3.dev0',
        '1.2.3.a0',
        '1.2.3a0',
        '1.2.3a0.post0',
        '1.2.3b0.post0',
        '1.2.3rc0.post0',
        '1.2.3.post0.dev0',
        '1.2.3b0.post0.dev0',
        '1.2.3rc0.post0.dev0',
    ]
    for version in loose_versions:
        loose_version = LooseVersion(version)
        semver = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-11 18:48:59.634461
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Unit test for from_loose_version method of class SemanticVersion

    Returns:
        bool: True if all tests passed, otherwise False
    """
    from ansible.module_utils.compat.version import LooseVersion
    result = True


# Generated at 2022-06-11 18:49:04.427264
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create a LooseVersion
    loose = LooseVersion('1.2.3')

    # Convert LooseVersion to SemanticVersion
    semver = SemanticVersion.from_loose_version(loose)

    # Test comparison between LooseVersion and SemanticVersion
    assert semver == loose


# Generated at 2022-06-11 18:49:46.745472
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # When LooseVersion version attribute is not set
    loose_version = LooseVersion()
    try:
        SemanticVersion.from_loose_version(loose_version)
    except ValueError as error:
        assert "LooseVersion() is not a LooseVersion" in str(error)

    # When LooseVersion version attribute contains non-integer value
    try:
        loose_version = LooseVersion("1.0a")
        SemanticVersion.from_loose_version(loose_version)
    except ValueError as error:
        assert "Non integer values in LooseVersion('1.0a')" in str(error)

    # Pre-releases with less than three segments are appended with '.0'
    loose_version = LooseVersion("1.0.0")

# Generated at 2022-06-11 18:49:59.433197
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # from_loose_version is a classmethod
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0-2')) == SemanticVersion('0.0.0-2')
    assert SemanticVersion.from_loose_version(LooseVersion('3.3.0-beta.2')) == SemanticVersion('3.3.0-beta.2')
    assert SemanticVersion.from_loose_version(LooseVersion('4.5.0-alpha.5')) == SemanticVersion('4.5.0-alpha.5')

    # loose_version.vstring must have a '+' or a '-' to convert properly
    assert Semantic

# Generated at 2022-06-11 18:50:12.001630
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import semver
    version_list = ['0.0.0', '1.0.0', '1.0.0-alpha', '1.0.0+metadata', '0.0.1-alpha']
    for version in version_list:
        loose_version = semver.parse_version_info(version)
        semver_version = SemanticVersion.from_loose_version(loose_version)
        assert str(semver_version.major) == str(loose_version.major) and str(semver_version.minor) == str(
            loose_version.minor) and str(semver_version.patch) == str(loose_version.patch)
# Unit tests for class SemanticVersion



# Generated at 2022-06-11 18:50:24.552463
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    #
    # Tests with a valid input
    #

    # Test with string
    v = SemanticVersion.from_loose_version('1.0.0')
    assert(v.vstring == '1.0.0')

    # Test with LooseVersion
    v = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert(v.vstring == '1.0.0')

    # Test with SemanticVersion
    v = SemanticVersion.from_loose_version(SemanticVersion('1.0.0'))
    assert(v.vstring == '1.0.0')

    # Test with list with int
    v = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))

# Generated at 2022-06-11 18:50:36.552330
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a LooseVersion but without leading v
    assert SemanticVersion.from_loose_version(LooseVersion('3.3.3')).vstring == '3.3.3'
    # Test with a LooseVersion with leading v
    assert SemanticVersion.from_loose_version(LooseVersion('v3.3.3')).vstring == '3.3.3'
    # Test with a simple string without leading v
    assert SemanticVersion.from_loose_version('3.3.3').vstring == '3.3.3'
    # Test with a simple string with leading v
    assert SemanticVersion.from_loose_version('v3.3.3').vstring == '3.3.3'
    # Test with a LooseVersion but with leading v and a prerelease
    assert Sem

# Generated at 2022-06-11 18:50:41.972902
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion
    from ansible.module_utils.common.version import LooseVersion

    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')).vstring == '1.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'

    assert SemanticVersion.from_loose_version(LooseVersion('1')).core == (1, 0, 0)
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')).core == (1, 2, 0)
    assert Semantic

# Generated at 2022-06-11 18:50:55.704005
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == '1.2.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha'))) == '1.2.3-alpha'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.2'))) == '1.2.3-alpha.2'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.4'))) == '1.2.3+build.4'

# Generated at 2022-06-11 18:51:08.014856
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Assert expected results
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.1'))) == '1.1.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.1+1'))) == '1.1.0+1'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.1alpha'))) == '1.1.0-alpha'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.1alpha0.b1'))) == '1.1.0-alpha0.b1'

    # Assert errors
    try:
        SemanticVersion.from_loose_version(LooseVersion('1.1a'))
    except ValueError:
        pass


# Generated at 2022-06-11 18:51:13.962088
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Loose version v1.0
    v1 = LooseVersion('1.0')
    assert str(SemanticVersion.from_loose_version(v1)) == '1.0.0'

    # Loose version v2.3
    v2 = LooseVersion('2.3')
    assert str(SemanticVersion.from_loose_version(v2)) == '2.3.0'

    # Loose version v3.2.1
    v3 = LooseVersion('3.2.1')
    assert str(SemanticVersion.from_loose_version(v3)) == '3.2.1'

    # Loose version v4.11.2-alpha.1
    v4 = LooseVersion('4.11.2-alpha.1')

# Generated at 2022-06-11 18:51:23.044661
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    valid_versions = [
        '0.0.0foo-bar',
        '0.0.0foo+bar',
        '0.0.0',
        '0.0.0foo',
        '0.0',
        '0',
    ]
    invalid_versions = [
        '0.0.0foo-barbaz',
        '0.0.0foo+barbaz',
        '0.0.0foo+barbaz123',
        '0.0.0foo+barbaz123.456',
        '0.0.0foo-barbaz123.456',
        '0.0.0foo+b+a+r+b-a-z',
    ]

# Generated at 2022-06-11 18:52:04.905794
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.4.4')) == SemanticVersion('1.2.3-alpha.4.4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+alpha.4.4')) == SemanticVersion('1.2.3+alpha.4.4')

    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.4')) == SemanticVersion('1.2.3-4.4')