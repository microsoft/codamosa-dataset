

# Generated at 2022-06-11 18:42:29.787937
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        SemanticVersion().from_loose_version('1.2')
        assert False
    except ValueError:
        assert True
    try:
        SemanticVersion().from_loose_version(('1', '2'))
        assert False
    except ValueError:
        assert True
    try:
        SemanticVersion().from_loose_version('1.2-1')
        assert False
    except ValueError:
        assert True
    try:
        SemanticVersion().from_loose_version('1.2-1')
        assert False
    except ValueError:
        assert True
    try:
        SemanticVersion().from_loose_version('1.2-1.foo')
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-11 18:42:40.204724
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """
    Test the method parse of class SemanticVersion
    """
    test_list = [
        ('4.2.0', (4, 2, 0)),
        ('1.2.3', (1, 2, 3)),
        ('1.2.3+5', (1, 2, 3)),
        ('1.2.3-5', (1, 2, 3)),
        ('1.2.3-5+9', (1, 2, 3)),
        ('1.2.3-5.8.10+9', (1, 2, 3)),
    ]
    for vstring, result in test_list:
        assert SemanticVersion(vstring).core == result

# Generated at 2022-06-11 18:42:50.291253
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # test non-semver string
    vstring = '2019.12.0'
    version = SemanticVersion(vstring)
    assert version.vstring == vstring
    assert version.major == 2019
    assert version.minor == 12
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # test non-semver string with identifier
    vstring = '2019.12.0-rc'
    version = SemanticVersion(vstring)
    assert version.vstring == vstring
    assert version.major == 2019
    assert version.minor == 12
    assert version.patch == 0
    assert version.prerelease == (_Alpha('rc'),)
    assert version.buildmetadata == ()

    # test non-semver string with identifier

# Generated at 2022-06-11 18:43:01.321778
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # We expect to be able to pass a LooseVersion to this method
    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    # We expect to get back a SemanticVersion, to be able to compare them
    # together, we need to build a LooseVersion from it
    loose_semantic_version = LooseVersion('%s.%s.%s' % semantic_version.core)
    # We expect to see them both as the same version
    assert loose_version == loose_semantic_version
    # We expect to not see them as different versions
    assert loose_version != LooseVersion('1.2.4')


# Generated at 2022-06-11 18:43:12.558987
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:43:24.321980
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    # Test valid semantic version
    print("\n# Test valid semantic version")
    test_semver = SemanticVersion("2.2.2")
    assert test_semver.major == 2
    assert test_semver.minor == 2
    assert test_semver.patch == 2
    assert len(test_semver.prerelease) == 0
    assert len(test_semver.buildmetadata) == 0

    # Test valid semantic version with prerelease
    print("\n# Test valid semantic version with prerelease")
    test_semver = SemanticVersion("2.2.2-test.test2.test3")
    assert test_semver.major == 2
    assert test_semver.minor == 2
    assert test_semver.patch == 2
    assert len(test_semver.prerelease) == 3


# Generated at 2022-06-11 18:43:34.545535
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = SemanticVersion.from_loose_version(LooseVersion("1.2.3.4"))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion.from_loose_version(LooseVersion("1.2.3"))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion.from_loose_version(LooseVersion("1.2.post4"))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 0

# Generated at 2022-06-11 18:43:45.486448
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    errstr = 'method parse of class SemanticVersion produces wrong result for input {0}'

    assert SemanticVersion('1.2.3').major == 1, errstr.format('1.2.3')
    assert SemanticVersion('1.2.3').minor == 2, errstr.format('1.2.3')
    assert SemanticVersion('1.2.3').patch == 3, errstr.format('1.2.3')
    assert SemanticVersion('1.2.3').prerelease == (), errstr.format('1.2.3')
    assert SemanticVersion('1.2.3').buildmetadata == (), errstr.format('1.2.3')


# Generated at 2022-06-11 18:43:51.156250
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    semver = SemanticVersion()
    semver.parse("1.2.3")

    assert semver.major == 1, "major of semver must be 1"
    assert semver.minor == 2, "minor of semver must be 2"
    assert semver.patch == 3, "patch of semver must be 3"


# Generated at 2022-06-11 18:43:56.564513
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')
    d = _Alpha('d')
    e = _Alpha('e')
    f = _Alpha('f')
    g = _Alpha('g')
    h = _Alpha('h')
    i = _Alpha('i')
    j = _Alpha('j')
    k = _Alpha('k')
    l = _Alpha('l')
    m = _Alpha('m')
    n = _Alpha('n')
    o = _Alpha('o')
    p = _Alpha('p')
    q = _Alpha('q')
    r = _Alpha('r')
    s = _Alpha('s')
    t = _Alpha('t')
    u = _Alpha('u')
    v = _Alpha('v')
   

# Generated at 2022-06-11 18:44:17.701811
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion(text_type('1.2.3-rc.1'))
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion(text_type('1.2.3-rc.1'))

    loose_version = LooseVersion(text_type('1.2.3'))
    assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion(text_type('1.2.3'))

if __name__ == '__main__':
    print(test_SemanticVersion_from_loose_version())

# Generated at 2022-06-11 18:44:29.004257
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # This list of cases is not exhaustive, it just covers some special cases
    # The following are not covered by this test:
    #   - local version
    #   - version with epoch
    #   - version in PEP440 format
    #   (these format are not handled by LooseVersion)

    # Case 1: one number
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')

    # Case 2: two numbers
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')

    # Case 3: three numbers
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    # Case

# Generated at 2022-06-11 18:44:33.527890
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Test a valid version string
    sv = SemanticVersion()
    sv.parse('2.8.15+1.2.3')
    assert sv.major == 2
    assert sv.minor == 8
    assert sv.patch == 15
    assert sv.prerelease == ()
    assert sv.buildmetadata == ('1', '2', '3')

    # Test an invalid version string
    sv = SemanticVersion()
    try:
        sv.parse('2.8.15-1,2.3')
        assert False
    except ValueError:
        pass



# Generated at 2022-06-11 18:44:47.741267
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    SemanticVersion.from_loose_version(LooseVersion('1.1.1'))
    SemanticVersion.from_loose_version(LooseVersion('1.2'))
    SemanticVersion.from_loose_version(LooseVersion('1'))
    SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre'))
    SemanticVersion.from_loose_version(LooseVersion('1.2.3-4'))
    SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5'))
    SemanticVersion.from_loose_version(LooseVersion('1.2.3+5.5'))

# Generated at 2022-06-11 18:44:59.799810
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:45:10.895828
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1.2') == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')

    assert SemanticVersion.from_loose_version('1.2.3-4') == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version('1.2.3-4.5.6') == SemanticVersion('1.2.3-4.5.6')
    assert SemanticVersion.from_loose_version('1.2.3-beta') == SemanticVersion('1.2.3-beta')

# Generated at 2022-06-11 18:45:20.183631
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
  vstring = "1.0.0-alpha+001"
  expected_major = 1
  expected_minor = 0
  expected_patch = 0
  expected_prerelease = ('alpha',)
  expected_buildmetadata = ('001',)
  semantic_version = SemanticVersion(vstring=vstring)
  semantic_version.parse(vstring)
  assert semantic_version.major == expected_major
  assert semantic_version.minor == expected_minor
  assert semantic_version.patch == expected_patch
  assert semantic_version.prerelease == expected_prerelease
  assert semantic_version.buildmetadata == expected_buildmetadata



# Generated at 2022-06-11 18:45:33.556448
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # case exact
    assert SemanticVersion.from_loose_version('1.0') == '1.0.0'
    assert SemanticVersion.from_loose_version('1.0.0') == '1.0.0'
    assert SemanticVersion.from_loose_version('1.0.0.0') == '1.0.0'
    assert SemanticVersion.from_loose_version('1.0.0.0.0.0') == '1.0.0'
    assert SemanticVersion.from_loose_version('1.0.0.1') == '1.0.0.1'

    # case with build metadata
    assert SemanticVersion.from_loose_version('1.0+amd64') == '1.0.0+amd64'
    assert SemanticVersion

# Generated at 2022-06-11 18:45:43.575150
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Give a valid vstring as input with semantic_version.parse()
    # It should return a SemanticVersion object with major, minor and patch initialized to expected integers
    # It should return a SemanticVersion object with prerelease and buildmetadata initialized to expected tuples
    # It should raise a ValueError when an invalid vstring is given
    vstring1 = '1.2.3'
    vstring2 = '2.4.6-alpha.1.2'
    vstring3 = '3.6.9+build.4.5.6'
    vstring4 = '4.8.12-beta+build.5.6.7.8'
    vstring5 = '0.0.0-0.1.0+zero'
    vstring6 = '1.4.7+build.4.5.6'
    vstring

# Generated at 2022-06-11 18:45:51.036341
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('3.11.26')) == SemanticVersion('3.11.26')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.16+gite9359db')) == SemanticVersion('1.0.16+gite9359db')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.16-rc.1+gite9359db')) == SemanticVersion('1.0.16-rc.1+gite9359db')


# Generated at 2022-06-11 18:46:06.594734
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import unittest
    import ansible.module_utils.compat.version

    class TestSemanticVersionFromLooseVersion(unittest.TestCase):
        """Verify that SemanticVersion.from_loose_version() converts a LooseVersion instance to a SemanticVersion instance."""

        def test(self):
            loose_version = ansible.module_utils.compat.version.LooseVersion("1.0")
            semver = SemanticVersion.from_loose_version(loose_version)
            self.assertIsInstance(semver, SemanticVersion)
            self.assertIs(semver, loose_version)

    unittest.main(module=__name__)

# Generated at 2022-06-11 18:46:18.517117
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("0.11.4")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 0
    assert semver.minor == 11
    assert semver.patch == 4
    assert semver.is_stable is True

    loose_version = LooseVersion("0.11.4.post1")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 0
    assert semver.minor == 11
    assert semver.patch == 4
    assert semver.prerelease == ('post', 1)
    assert semver.is_stable is False

    loose_version = LooseVersion("0.11.4.post1+abc")

# Generated at 2022-06-11 18:46:26.294664
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases = [
        (LooseVersion("1.1.1"), SemanticVersion("1.1.1")),
        (LooseVersion("1.1.1-alpha"), SemanticVersion("1.1.1-alpha")),
        (LooseVersion("1.1.0+build_metadata"), SemanticVersion("1.1.0+build_metadata")),
    ]
    for loose_version, expected in test_cases:
        actual = SemanticVersion.from_loose_version(loose_version)
        assert actual == expected

# Generated at 2022-06-11 18:46:39.725769
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')) == SemanticVersion('1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1.1')) == SemanticVersion('1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1.1.1')) == SemanticVersion('1.1.1')

    assert LooseVersion('1.1.1') < LooseVersion('1.1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')) == SemanticVersion.from_loose_version(LooseVersion('1.1.1.1'))

    assert SemanticVersion.from_lo

# Generated at 2022-06-11 18:46:53.156625
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-rc1')) == SemanticVersion('1.2.3-rc1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.6')) == SemanticVersion('1.2.3+build.6')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.6-rc1')) == SemanticVersion('1.2.3+build.6-rc1')

    # The following are valid LooseVersion strings, but invalid Semantic Version strings
    assert SemanticVersion.from_lo

# Generated at 2022-06-11 18:46:59.882301
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion('1.2.3')
    lv1 = LooseVersion(v1.vstring)
    assert v1 == SemanticVersion.from_loose_version(lv1)
    assert isinstance(v1, SemanticVersion)

# Generated at 2022-06-11 18:47:07.642675
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:47:17.599162
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Unit test for method from_loose_version of class SemanticVersion
    """

# Generated at 2022-06-11 18:47:28.510178
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.4')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.core == (1, 2, 4)
    assert semver.is_prerelease == False
    assert semver.is_stable == True

    loose_version = LooseVersion('1.2.4-rc1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.core == (1, 2, 4)
    assert semver.prerelease == ('rc', 1)
    assert semver.is_prerelease == True
    assert semver.is_stable == False

    loose_version = LooseVersion('1.2.4.post2')
    semver = SemanticVersion.from_loose_

# Generated at 2022-06-11 18:47:40.125952
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import SemanticVersion

    # Simple version
    s = '2.2.2'
    v = SemanticVersion.from_loose_version(LooseVersion(s))
    assert str(v) == s

    # Simple version with build metadata
    s = '2.2.2+build.metadata'
    v = SemanticVersion.from_loose_version(LooseVersion(s))
    assert str(v) == s

    # Simple version with prerelease and build metadata
    s = '2.2.2-rc.2+build.metadata'
    v = SemanticVersion.from_loose_version(LooseVersion(s))
    assert str(v) == s

    # Numeric prerelease
    s = '2.2.2-rc.2'
   

# Generated at 2022-06-11 18:47:57.944653
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')).vstring == '1.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev0')).vstring == '1.2.3.dev0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev0+local')).vstring == '1.2.3.dev0+local'

# Generated at 2022-06-11 18:48:08.366006
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Tests for method from_loose_version of class SemanticVersion
    """

    from ansible.module_utils.six import PY2

    # Sanity checks for method from_loose_version
    # Assert that a ValueError is thrown when version is not a LooseVersion
    try:
        SemanticVersion.from_loose_version(1)
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"
    try:
        SemanticVersion.from_loose_version("1")
    except ValueError:
        pass
    else:
        assert False, "ValueError not raised"

    # Assert that a ValueError is thrown when version is a LooseVersion with non-integer values

# Generated at 2022-06-11 18:48:16.383838
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('0.2.3')) == SemanticVersion('0.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('0.2.3-alpha')) == SemanticVersion('0.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+foo')) == SemanticVersion('1.2.3+foo')

# Generated at 2022-06-11 18:48:23.621301
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    SemanticVersion_from_loose_version_result = SemanticVersion.from_loose_version(
        LooseVersion("7.18.0+rpi1-1"))
    assert SemanticVersion_from_loose_version_result.major == 7
    assert SemanticVersion_from_loose_version_result.minor == 18
    assert SemanticVersion_from_loose_version_result.patch == 0
    assert SemanticVersion_from_loose_version_result.prerelease == ()
    assert SemanticVersion_from_loose_version_result.buildmetadata == ("rpi1",)

# Generated at 2022-06-11 18:48:36.128961
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:47.590183
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('5')) == SemanticVersion('5.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('5.1')) == SemanticVersion('5.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('5.1.3')) == SemanticVersion('5.1.3')
    assert SemanticVersion.from_loose_version(LooseVersion('5.1.3-rc1')) == SemanticVersion('5.1.3-rc1')
    assert SemanticVersion.from_loose_version(LooseVersion('5.1.3+build2')) == \
            SemanticVersion('5.1.3+build2')
    assert SemanticVersion.from_loose

# Generated at 2022-06-11 18:48:55.179453
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that a LooseVersion instance is suitable for conversion to SemanticVersion
    input_version = LooseVersion('1.2.3.4.5.6-7')
    expected_output = SemanticVersion('1.2.3-7')
    output = SemanticVersion.from_loose_version(input_version)
    assert output == expected_output
    assert isinstance(output, SemanticVersion)


# Generated at 2022-06-11 18:49:03.590886
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3.4')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version.vstring == '1.2.3'

    loose_version = LooseVersion('1.2.3alpha3')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version.vstring == '1.2.3-alpha3'

    loose_version = LooseVersion('1.2.3-alpha3')
    version = SemanticVersion.from_loose_version(loose_version)
    assert version.vstring == '1.2.3-alpha3'

    loose_version = LooseVersion('1.2.3+foo')

# Generated at 2022-06-11 18:49:12.748017
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:49:22.539047
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose1 = LooseVersion("1.0.0")
    loose2 = LooseVersion("1.1.1")
    loose3 = LooseVersion("1.1.2")
    loose4 = LooseVersion("1.1.2.dev1")
    loose5 = LooseVersion("1.1.2.dev2")
    loose6 = LooseVersion("1.1.2.dev3")
    loose7 = LooseVersion("1.1.2.dev4")
    loose8 = LooseVersion("1.2.dev1")

    sem1 = SemanticVersion("1.0.0")
    sem2 = SemanticVersion("1.1.1")
    sem3 = SemanticVersion("1.1.2")
    sem4 = SemanticVersion("1.1.2-dev1")
    sem5

# Generated at 2022-06-11 18:49:39.802764
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert (
               SemanticVersion.from_loose_version(LooseVersion('1.2.3')) ==
               SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
           )

    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')

    assert SemanticVersion

# Generated at 2022-06-11 18:49:49.459377
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.0.0'

    loose_version = LooseVersion('1.1.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.1.1'

    loose_version = LooseVersion('1.0.0a')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '1.0.0-a'

    loose_version = LooseVersion('1.1.1.1b')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
   

# Generated at 2022-06-11 18:50:01.291027
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test the creation of a SemanticVersion object using the
    method `from_loose_version` of the class `SemanticVersion`
    """
    # Create a loose version
    loose_version = LooseVersion(__version__)
    # Create a SemanticVersion object using `from_loose_version`
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    # Check that the created SemanticVersion has the expected properties
    assert isinstance(semantic_version, SemanticVersion)
    assert semantic_version.vstring == __version__
    assert semantic_version.major == 1
    assert semantic_version.minor == 1
    assert semantic_version.patch == 1
    assert semantic_version.prerelease == ()
    assert semantic_version.buildmetadata == ()
    # Check that the

# Generated at 2022-06-11 18:50:14.353378
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    import platform
    if sys.version_info[0:2] == (2, 6):
        import imp
        import types
        import unittest
        from distutils.version import LooseVersion
        from ansible.module_utils.version.semver import SemanticVersion
        from ansible.module_utils.version.semver import _Alpha
        from ansible.module_utils.version.semver import _Numeric

        if platform.system() == 'Darwin':
            pkg_resources = imp.new_module('pkg_resources')

# Generated at 2022-06-11 18:50:26.226525
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')

    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.456.78')) == SemanticVersion('1.2.3+build.456.78')

    assert SemanticVersion.from_lo

# Generated at 2022-06-11 18:50:39.235575
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # no loose version
    try:
        SemanticVersion.from_loose_version(None)
    except ValueError as e:
        assert str(e) == "None is not a LooseVersion"
    # wrong type
    try:
        SemanticVersion.from_loose_version(SemanticVersion())
    except ValueError as e:
        assert str(e) == "SemanticVersion('None') is not a LooseVersion"
    # loose version with 'dev'
    try:
        SemanticVersion.from_loose_version(LooseVersion("2.2.1.dev"))
    except ValueError as e:
        assert str(e) == """Non integer values in LooseVersion ('2.2.1', 'dev')"""
    # loose version with 'post'

# Generated at 2022-06-11 18:50:53.052746
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:51:05.102481
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5')) == SemanticVersion('1.2.3-4.5')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4.5')) == SemanticVersion('1.2.3+4.5')

# Generated at 2022-06-11 18:51:17.055016
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Cases that should work with no errors
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.alpha.1')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.alpha.1.2')) == SemanticVersion('1.0.0-alpha.1.2')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.beta.1')) == SemanticVersion('1.0.0-0.beta.1')

# Generated at 2022-06-11 18:51:29.369905
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """ Method from_loose_version should return correct SemanticVersion,
        otherwise raise ValueError.
    """
    from ansible.module_utils.compat.version import LooseVersion

    # Testing ValueError

# Generated at 2022-06-11 18:51:49.173268
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.distro import distro_info
    from ansible.module_utils.six import PY3


# Generated at 2022-06-11 18:51:56.387930
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3-3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert semantic_version.prerelease == (_Numeric(3),)
    assert not semantic_version.buildmetadata

    loose_version = LooseVersion('1.2.3-rc1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3
    assert semantic_version.prerelease == (_Alpha('rc'), _Numeric(1))
    assert not semantic_version.build

# Generated at 2022-06-11 18:52:05.265282
# Unit test for method from_loose_version of class SemanticVersion