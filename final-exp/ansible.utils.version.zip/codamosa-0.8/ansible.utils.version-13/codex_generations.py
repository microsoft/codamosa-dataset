

# Generated at 2022-06-11 18:42:35.914432
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # test version with normal format
    version = SemanticVersion('1.2.3')
    assert version.vstring == '1.2.3'
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # test major version with 0
    version = SemanticVersion('0.2.3')
    assert version.vstring == '0.2.3'
    assert version.major == 0
    assert version.minor == 2
    assert version.patch == 3

    # test pre-release version with prerelease and build metadata
    version = SemanticVersion('1.2.3-rc1+build5')
    assert version.vstring == '1.2.3-rc1+build5'

# Generated at 2022-06-11 18:42:47.454530
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """Test valid and invalid versions"""
    def test_version(version, result):
        """Test version and compare result to expected result"""
        semantic_version = SemanticVersion(version)
        core = semantic_version.core
        prerelease = semantic_version.prerelease
        buildmetadata = semantic_version.buildmetadata
        assert semantic_version.vstring == version, "%s != %s" % (semantic_version.vstring, version)
        assert result['core'] == semantic_version.core, "core %s != %s" % (result['core'], core)
        assert result['prerelease'] == prerelease, "prerelease %s != %s" % (result['prerelease'], prerelease)
        assert result['buildmetadata'] == buildmetadata, "buildmetadata %s != %s" % (result['buildmetadata'], buildmetadata)

# Generated at 2022-06-11 18:42:59.409061
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    if (_Alpha('a') <= _Alpha('a')):
        pass
    else:
        raise RuntimeError("test__Alpha___le__() #1 failed")

    if (_Alpha('a') <= 'a'):
        pass
    else:
        raise RuntimeError("test__Alpha___le__() #2 failed")

    if ('a' <= _Alpha('a')):
        pass
    else:
        raise RuntimeError("test__Alpha___le__() #3 failed")

    if (_Alpha('a') <= _Alpha('b')):
        pass
    else:
        raise RuntimeError("test__Alpha___le__() #4 failed")

    if (_Alpha('a') <= 'b'):
        pass
    else:
        raise RuntimeError("test__Alpha___le__() #5 failed")


# Generated at 2022-06-11 18:43:11.586051
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1-dev1')) == SemanticVersion('0.1.0-dev1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1-dev2')) == SemanticVersion('0.1.0-dev2')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1-dev3')) == SemanticVersion('0.1.0-dev3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.4.6.92-1+deb8u1')) == SemanticVersion('1.4.6-92-1')

# Generated at 2022-06-11 18:43:24.019792
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose = LooseVersion('1.2.3-1')
    assert str(SemanticVersion.from_loose_version(loose)) == '1.2.3-1'
    loose = LooseVersion('1.2.3-abc')
    assert str(SemanticVersion.from_loose_version(loose)) == '1.2.3-abc'
    loose = LooseVersion('1.2.3+metadata')
    assert str(SemanticVersion.from_loose_version(loose)) == '1.2.3+metadata'
    loose = LooseVersion('1.2')
    assert str(SemanticVersion.from_loose_version(loose)) == '1.2.0'
    loose = LooseVersion('1')

# Generated at 2022-06-11 18:43:32.335565
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    expected_major = 1
    expected_minor = 1
    expected_patch = 1
    expected_prerelease = ()
    expected_buildmetadata = ()

    semver = SemanticVersion()
    semver.parse('1.1.1')

    assert semver.major == expected_major , 'SemanticVersion parse error: Expected major to be %s but got %s' % (expected_major,semver.major)
    assert semver.minor == expected_minor , 'SemanticVersion parse error: Expected minor to be %s but got %s' % (expected_minor,semver.minor)
    assert semver.patch == expected_patch , 'SemanticVersion parse error: Expected patch to be %s but got %s' % (expected_patch,semver.patch)
    assert semver.prerelease == expected

# Generated at 2022-06-11 18:43:38.421597
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion('0.0.2-BETA.2+build.42')
    assert v.major == 0
    assert v.minor == 0
    assert v.patch == 2
    assert v.prerelease == (0, 'BETA', 2)
    assert v.buildmetadata == ('build', 42)


# Generated at 2022-06-11 18:43:50.627588
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a None
    try:
        SemanticVersion.from_loose_version(None)
    except ValueError as exc:
        assert str(exc) == "'None' is not a LooseVersion"

    # Test string
    try:
        SemanticVersion.from_loose_version('abc')
    except ValueError as exc:
        assert str(exc) == "'abc' is not a LooseVersion"

    # Test a loose version
    ver = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert ver == SemanticVersion('1.2.3')

    # Test a loose version
    ver = SemanticVersion.from_loose_version(LooseVersion('1.2.3-rc1.ab.c-1.2'))
    assert ver == Semantic

# Generated at 2022-06-11 18:43:56.213848
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('3.3.3-dev1') == SemanticVersion('3.3.3-dev1')
    assert SemanticVersion.from_loose_version('3.3.3-dev1+d54f01') == SemanticVersion('3.3.3-dev1+d54f01')
    assert SemanticVersion.from_loose_version('3.3.3+d54f01') == SemanticVersion('3.3.3+d54f01')
    assert SemanticVersion.from_loose_version('3.3.3') == SemanticVersion('3.3.3')
    assert SemanticVersion.from_loose_version('3.3') == SemanticVersion('3.3.0')

# Generated at 2022-06-11 18:44:08.316726
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    if sys.version_info < (3,):
        assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3")
        assert SemanticVersion.from_loose_version(LooseVersion("1.2")) == SemanticVersion("1.2.0")
        assert SemanticVersion.from_loose_version(LooseVersion("1")) == SemanticVersion("1.0.0")
    else:
        assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3")
        assert SemanticVersion.from_loose_version(LooseVersion("1.2")) == SemanticVersion("1.2.0")
        assert SemanticVersion.from_loose_

# Generated at 2022-06-11 18:44:28.937405
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:44:38.444163
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-rc1')) == '1.0.0-rc1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0rc1')) == '1.0.0-rc1'

# Generated at 2022-06-11 18:44:49.296293
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Setup
    loose_version = LooseVersion("2015.8.8")

    # Execute
    semantic_version = SemanticVersion.from_loose_version(loose_version)

    # Verify
    assert semantic_version._cmp("2015.8.8") == 0
    assert semantic_version._cmp("2015.8.8a") < 0
    assert semantic_version._cmp("2015.8.8b") < 0
    assert semantic_version._cmp("2016.8.8a") < 0
    assert semantic_version._cmp("2015.9.8a") < 0
    assert semantic_version._cmp("2015.7.8b") > 0
    assert semantic_version._cmp("2014.8.8c") > 0

# Generated at 2022-06-11 18:45:00.690449
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test different versions of ansible for example
    # Test ansible_facts.distribution_version
    ansible_facts = (
        '2.6.3',
        '2.6.3.0',
        '2.6.3.0.0',
        '2.6.3.0.0.0',
        '2.6.3.0.0.0.0',
        '2.6.3.0.0.0.0.0',
        '2.6.3.0.0.0.0.0.0',
        '2.7.0',
        '2.8.0',
        '2.9.0',
    )
    for fact in ansible_facts:
        version = SemanticVersion.from_loose_version(LooseVersion(fact))
       

# Generated at 2022-06-11 18:45:08.637955
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test passing a string
    assert SemanticVersion.from_loose_version("1.2.3") == SemanticVersion("1.2.3")
    # Test passing a LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3")
    # Test passing a SemanticVersion
    assert SemanticVersion.from_loose_version(SemanticVersion("1.2.3")) == SemanticVersion("1.2.3")


# Generated at 2022-06-11 18:45:20.832397
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test for SemanticVersion.from_loose_version"""
    # invalid input
    invalid_input = [1, 2, 3.1, [1, 2, 3], None, True]
    for x in invalid_input:
        try:
            SemanticVersion.from_loose_version(x)
            assert False
        except ValueError:
            pass
        except Exception:
            assert False

    # invalid input type
    class A:
        pass

    try:
        SemanticVersion.from_loose_version(A())
        assert False
    except ValueError:
        pass
    except Exception:
        assert False

    # invalid version
    invalid_input_version = ['1.2.3-alpha.beta', 'a.b.c']

# Generated at 2022-06-11 18:45:30.272161
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # checking for comparasion of alpha class object with string
    a = _Alpha('abc')
    b = 'abc'
    assert (a <= b)
    # checking for comparasion of alpha class object with alpha class object
    a = _Alpha('abc')
    b = _Alpha('abc')
    assert (a <= b)
    # checking for comparasion of alpha class object with numeric class object
    a = _Alpha('a')
    b = _Numeric(10)
    assert not (a <= b)

# Generated at 2022-06-11 18:45:39.486536
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion"""
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('v1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('=1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('v1.0.0-alpha')) == Semantic

# Generated at 2022-06-11 18:45:51.227790
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:45:55.507376
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2


# Generated at 2022-06-11 18:46:06.573553
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("2.0.1")
    sem_ver = SemanticVersion.from_loose_version(loose_version)
    assert sem_ver.major == 2
    assert sem_ver.minor == 0
    assert sem_ver.patch == 1
    assert not sem_ver.prerelease
    assert not sem_ver.buildmetadata
    assert sem_ver.is_stable

    loose_version = LooseVersion("2.0.1-1.2.a1+abcd.1234")
    sem_ver = SemanticVersion.from_loose_version(loose_version)
    assert sem_ver.major == 2
    assert sem_ver.minor == 0
    assert sem_ver.patch == 1

# Generated at 2022-06-11 18:46:18.465871
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    assert SemanticVersion.from_loose_version('0.2.2') == SemanticVersion('0.2.2')
    assert SemanticVersion.from_loose_version('0.2.2-alpha') == SemanticVersion('0.2.2-alpha')
    assert SemanticVersion.from_loose_version('0.2.2-alpha+20190411.1') == SemanticVersion('0.2.2-alpha+20190411.1')
    assert SemanticVersion.from_loose_version('0.2.2-3') == SemanticVersion('0.2.2-3')
    assert SemanticVersion.from_loose_version('0.2.2-3.4') == SemanticVersion('0.2.2-3.4')
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-11 18:46:22.605705
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version_string = '4.6.12'
    loose_version = LooseVersion(version_string)
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == version_string

# Generated at 2022-06-11 18:46:27.076153
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('x')
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'x'


# Generated at 2022-06-11 18:46:40.892620
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion('0.0.0')
    assert lv.version == (0, 0, 0)

    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == '0.0.0'
    assert sv.core == (0, 0, 0)
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()

    lv = LooseVersion('1.2.3')
    assert lv.version == (1, 2, 3)

    sv = SemanticVersion.from_loose_version(lv)
    assert sv.vstring == '1.2.3'
    assert sv.core == (1, 2, 3)
    assert sv.prerelease == ()
    assert sv.buildmetadata == ()


# Generated at 2022-06-11 18:46:44.530274
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    _Alpha('a') <= _Alpha('a')
    _Alpha('a') <= _Alpha('b')
    _Alpha('a') <= 'a'
    _Alpha('a') <= 'b'


# Generated at 2022-06-11 18:46:52.831888
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Arrange
    version_string = "3.1.99"
    loose_version = LooseVersion(version_string)

    # Act
    semver = SemanticVersion.from_loose_version(loose_version)

    # Assert
    assert(semver.major == 3)
    assert(semver.minor == 1)
    assert(semver.patch == 99)
    assert(semver.prerelease == ())
    assert(semver.buildmetadata == ())

# Generated at 2022-06-11 18:47:05.203373
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3+abcd")) == SemanticVersion("1.2.3+abcd")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2+abcd")) == SemanticVersion("1.2.0+abcd")
    assert SemanticVersion.from_loose_version(LooseVersion("1+abcd")) == SemanticVersion("1.0.0+abcd")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-beta")) == SemanticVersion("1.2.3-beta")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2-beta")) == SemanticVersion("1.2.0-beta")

# Generated at 2022-06-11 18:47:15.773300
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test equivalence
    for loose_ver in ['1.2.4', '1.2.4-alpha.1', '1.2.4-alpha.beta', '1.2.4-1.beta', '1.2.4-1.2.beta', '1.2.4-beta+exp.sha.5114f85']:
        assert SemanticVersion.from_loose_version(LooseVersion(loose_ver))._cmp(SemanticVersion(loose_ver)) == 0

    # Test that it fails on <=1.1119
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.4-beta.1'))._cmp(SemanticVersion('1.2.4-beta.1')) == 1

    # Test that it fails on >1.12.0
   

# Generated at 2022-06-11 18:47:27.867132
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    # Test 1
    class AlphaTest:
        alpha1 = _Alpha('beta')
        alpha2 = _Alpha('alpha')

    expected_result = True
    result = AlphaTest.alpha1 <= AlphaTest.alpha2
    assert result == expected_result, 'Expected "%s" but got "%s"' % (expected_result, result)

    # Test 2
    class AlphaTest:
        alpha1 = _Alpha('beta')
        alpha2 = _Alpha('beta')

    expected_result = True
    result = AlphaTest.alpha1 <= AlphaTest.alpha2
    assert result == expected_result, 'Expected "%s" but got "%s"' % (expected_result, result)

    # Test 3
    class AlphaTest:
        alpha1 = _Alpha('beta')
        alpha2 = _Alpha('gamma')

# Generated at 2022-06-11 18:47:55.840607
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.9.1-1')) == SemanticVersion('1.9.1-1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.9.1-1+spam')) == SemanticVersion('1.9.1-1+spam')
    assert SemanticVersion.from_loose_version(LooseVersion('1.9.1-1spam')) == SemanticVersion('1.9.1-1spam')
    assert SemanticVersion.from_loose_version(LooseVersion('1.9.1-spam')) == SemanticVersion('1.9.1-spam')
    assert SemanticVersion.from_loose_version(LooseVersion('1.9.1-spam'))

# Generated at 2022-06-11 18:48:04.984079
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def _test_SemanticVersion_from_loose_version(version, expected):
        loose = LooseVersion(version)
        semantic = SemanticVersion.from_loose_version(loose)
        semantic_version = str(semantic)
        assert semantic_version == expected, \
            "Loose version `{0}` was converted to Semantic Version `{1}` instead of `{2}`".format(version, semantic_version, expected)

    # these test cases come from the README.md file in the SemanticVersion repository
    _test_SemanticVersion_from_loose_version('1.0.0', '1.0.0')
    _test_SemanticVersion_from_loose_version('2.0.0-alpha', '2.0.0-alpha')
    _test_SemanticVersion

# Generated at 2022-06-11 18:48:14.885231
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == '1.2.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2'))) == '1.2.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))) == '1.2.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5'))) == '1.2.3'

# Generated at 2022-06-11 18:48:22.514410
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion

    # For matching versions, SemanticVersion and LooseVersion should behave the same
    matching_version_list = [
        "1.2.3",
        "9.9.9-alpha.1.2.3",
        "1.2.3+4",
        "9.9.9-ALPHA.1.2.3+4",
    ]
    for version in matching_version_list:
        assert version == SemanticVersion(version)
        assert LooseVersion(version) == SemanticVersion.from_loose_version(LooseVersion(version))

    # LooseVersion("0.0.0.a") == "a"
    assert LooseVersion("0.0.0.a") == "a"
    # SemanticVersion("0

# Generated at 2022-06-11 18:48:34.746809
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:42.141840
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:55.528663
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert '1.0.0' == SemanticVersion.from_loose_version(LooseVersion('1.0.0')).vstring
    assert '1.0.0-alpha' == SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')).vstring
    assert '1.0.0-1' == SemanticVersion.from_loose_version(LooseVersion('1.0.0-1')).vstring
    assert '1.0.0-alpha.1' == SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha.1')).vstring
    assert '1.0.0+1' == SemanticVersion.from_loose_version(LooseVersion('1.0.0+1')).vstring

# Generated at 2022-06-11 18:49:03.771274
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Test negative cases
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('1.0.0-v2.0.1+g1f8dea6')

    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('1.0.0-v2.0.1+abc123')

    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('')

    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(1)

    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(0.1)

    # Test valid cases
    expected = SemanticVersion('1.0.0')

# Generated at 2022-06-11 18:49:08.251772
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.12.0')
    version = SemanticVersion.from_loose_version(loose_version)
    assert type(version) == SemanticVersion
    assert version.vstring == '1.12.0'

# Generated at 2022-06-11 18:49:20.165426
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2-alpha')) == SemanticVersion('0.1.2-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2')) == SemanticVersion('0.1.2')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+beta4')) == SemanticVersion('1.2.3+beta4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.post1')) == SemanticVersion('1.2.3')

# Generated at 2022-06-11 18:49:38.766706
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Return None if input is not a LooseVersion
    try:
        SemanticVersion.from_loose_version('a')
    except ValueError as e:
        pass
    except Exception as e:
        assert False, \
            "Unexpected exception: {}".format(e)
    else:
        assert False, "Unexpected success"

    # Return None if input version is not an integer
    lv = LooseVersion('2.6b')
    try:
        SemanticVersion.from_loose_version(lv)
    except ValueError as e:
        pass
    except Exception as e:
        assert False, \
            "Unexpected exception: {}".format(e)
    else:
        assert False, "Unexpected success"

    # Return SemanticVersion if input is a LooseVersion
    lv = Loose

# Generated at 2022-06-11 18:49:48.870302
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3

    v = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert isinstance(v, SemanticVersion)

    # LooseVersion('1.0.0') is equivalent to SemanticVersion('1.0.0')
    assert v == '1.0.0'

    v = SemanticVersion.from_loose_version(LooseVersion('1.0.0+2.3'))
    assert isinstance(v, SemanticVersion)

    # LooseVersion('1.0.0+2.3') is equivalent to SemanticVersion('1.0.0+2.3')
    assert v == '1.0.0+2.3'


# Generated at 2022-06-11 18:50:00.782607
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # String versions
    assert str(SemanticVersion.from_loose_version(LooseVersion('1'))) == '1.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.7'))) == '1.7.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.7.2'))) == '1.7.2'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.7.2.dev1'))) == '1.7.2'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.7.2a1'))) == '1.7.2'

# Generated at 2022-06-11 18:50:14.134979
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test invalid version types
    for version in [None, 12345, dict(), set()]:
        assert 'invalid version' in SemanticVersion.from_loose_version(version).message

    # Test empty versions
    for version in ["", "1", "1.2", "1.2.3"]:
        assert SemanticVersion.from_loose_version(version).vstring == version

    # Test versions with prepended zeros
    for version in ["1", "01", "001", "1.2", "01.02", "001.002", "1.2.3", "01.02.03", "001.002.003"]:
        assert SemanticVersion.from_loose_version(version).vstring == SemanticVersion(version).vstring

    # Test versions with trailing zeros

# Generated at 2022-06-11 18:50:26.184384
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test the conversion of a LooseVersion to a SemanticVersion."""
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.0')) == SemanticVersion('1.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.3.0.0-alpha')) == SemanticVersion('1.3.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.3.0.0-alpha.0.0.0')) == Semantic

# Generated at 2022-06-11 18:50:29.709507
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose = LooseVersion('1.2.3abc123')
    assert SemanticVersion.from_loose_version(loose).vstring == '1.2.3'


# Generated at 2022-06-11 18:50:41.683037
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for not supplying a LooseVersion
    try:
        SemanticVersion.from_loose_version('0.1.2')
    except:
        pass
    else:
        assert False, 'SemanticVersion.from_loose_version should throw an exception when not supplying a LooseVersion'

    # Test for invalid data
    try:
        SemanticVersion.from_loose_version(LooseVersion('0.1.2'))
    except:
        pass
    else:
        assert False, 'SemanticVersion.from_loose_version should throw an exception on invalid data'

    # Test for normal valid input

# Generated at 2022-06-11 18:50:55.424470
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion

    for vstring in (
        '1.6.10',
        '1.6.10+abc.123',
        '1.6.10-1.2.3',
        '1.6.10-1.2.3+abc.123',
    ):
        lv = LooseVersion(vstring)
        sv = SemanticVersion.from_loose_version(lv)
        assert sv.vstring == vstring

    try:
        SemanticVersion.from_loose_version('1.6.10')
        assert False
    except ValueError:
        pass

    try:
        SemanticVersion.from_loose_version(['1', '6', '10'])
        assert False
    except ValueError:
        pass

   

# Generated at 2022-06-11 18:51:07.972001
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert v1.major == 1
    assert v1.minor == 2
    assert v1.patch == 3
    assert v1.prerelease == ()

    v2 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-rc1.4'))
    assert v2.major == 1
    assert v2.minor == 2
    assert v2.patch == 3
    assert v2.prerelease == ('rc1', 4)

    v3 = SemanticVersion.from_loose_version(LooseVersion('1.2-rc1.4'))
    assert v3.major == 1
    assert v3.minor == 2
    assert v3.patch == 0

# Generated at 2022-06-11 18:51:15.321301
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = LooseVersion('1.0.0')
    s1 = SemanticVersion.from_loose_version(v1)
    assert repr(s1) == repr(SemanticVersion('1.0.0'))
    with pytest.raises(ValueError) as exc:
        SemanticVersion.from_loose_version(1)
    assert "invalid semantic version '1'" in str(exc.value)


# Generated at 2022-06-11 18:51:43.453389
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.0')) == SemanticVersion('1.2.0')

    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0')) == SemanticVersion('1.0.0')

# Generated at 2022-06-11 18:51:53.416464
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:52:04.536874
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    class MockLooseVersion(object):
        def __init__(self, vstring):
            self.vstring = vstring

        def __repr__(self):
            return 'MockLooseVersion(%r)' % self.vstring

        @property
        def version(self):
            return self.vstring.split('.')

    assert SemanticVersion.from_loose_version(MockLooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(MockLooseVersion('1.2.3-12')) == SemanticVersion('1.2.3-12')