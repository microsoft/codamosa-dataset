

# Generated at 2022-06-11 18:42:35.942909
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.six import string_types


# Generated at 2022-06-11 18:42:47.455742
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Parse versions like a loose version
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.2')) == SemanticVersion('1.0.0')

    # Parse versions with prerelease components

# Generated at 2022-06-11 18:42:59.409342
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5.6')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2-3')) == SemanticVersion('1.2.0')

# Generated at 2022-06-11 18:43:11.586677
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    def _assert(vstring, t):
        assert SemanticVersion(vstring).major == t[0]
        assert SemanticVersion(vstring).minor == t[1]
        assert SemanticVersion(vstring).patch == t[2]
        assert SemanticVersion(vstring).prerelease == t[3]
        assert SemanticVersion(vstring).buildmetadata == t[4]

    _assert('1.4.3-pre1', (1, 4, 3, (_Numeric('pre1'),), ()))
    _assert('1.4.3-pre1.alp1', (1, 4, 3, (_Numeric('pre1'), _Alpha('alp1')), ()))

# Generated at 2022-06-11 18:43:23.978749
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:43:34.381010
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.11.2')) == SemanticVersion('0.11.2')
    #assert SemanticVersion.from_loose_version(LooseVersion('0.11.2-1')) == SemanticVersion('0.11.2-1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.11.2-a')) == SemanticVersion('0.11.2-a')
    assert SemanticVersion.from_loose_version(LooseVersion('0.11.2-a.1')) == SemanticVersion('0.11.2-a.1')

# Generated at 2022-06-11 18:43:45.327111
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == '1.2.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))) == '1.2.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3dev-r123'))) == '1.2.3-r123'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev0+g123'))) == '1.2.3+g123'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.0'))) == '1.2.0'

# Generated at 2022-06-11 18:43:57.150521
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Py2
    try:
        from distutils.version import LooseVersion
    except ImportError:
        pass
    else:
        # Simplest test cases
        assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
        assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
        assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
        assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5')) == SemanticVersion('1.2.3')

        # Ensure that prerelease status is not incorrectly set

# Generated at 2022-06-11 18:44:08.541292
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    class Case:
        def __init__(self, loose_version, semantic_version=None):
            self.loose_version = loose_version
            self.semantic_version = semantic_version

        def __repr__(self):
            return repr((self.loose_version, self.semantic_version))

    # Cases for valid loose version to semantic version conversion

# Generated at 2022-06-11 18:44:20.301151
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:44:37.846856
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:44:41.615672
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = '5.5.0'
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.vstring == '5.5.0'


# Generated at 2022-06-11 18:44:51.267965
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    # SemanticVersion_from_loose_version() is a method of class SemanticVersion for converting loose version
    # into semantic version.
    # This function will be called by the tests for SemanticVersion_from_loose_version() method
    '''
    from ansible.module_utils.common.version import SemanticVersion
    loose_version = LooseVersion('1.0.0')
    x = SemanticVersion.from_loose_version(loose_version)
    assert x.vstring == '1.0.0'
    loose_version = LooseVersion('1.0.0-RC1')
    x = SemanticVersion.from_loose_version(loose_version)
    assert x.vstring == '1.0.0-RC1'

# Generated at 2022-06-11 18:45:01.997917
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.version import SemanticVersion


# Generated at 2022-06-11 18:45:12.649571
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_lo

# Generated at 2022-06-11 18:45:22.811394
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test loose version 1.2.3
    loose_version = LooseVersion("1.2.3")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert (semver.major, semver.minor, semver.patch) == (1,2,3)
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    # Test loose version 1.2.3-4
    loose_version = LooseVersion("1.2.3-4")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert (semver.major, semver.minor, semver.patch) == (1,2,3)
    assert semver.prerelease == (4,)
    assert semver.buildmetadata == ()

   

# Generated at 2022-06-11 18:45:36.390436
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test simple versions
    assert SemanticVersion.from_loose_version(LooseVersion('1')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')).vstring == '1.2.0'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).vstring == '1.2.3'

    # Test with prerelease
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-1')).vstring == '1.2.3-1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-a')).vstring == '1.2.3-a'
    assert SemanticVersion.from_lo

# Generated at 2022-06-11 18:45:48.041791
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests for valid inputs.
    assert repr(SemanticVersion.from_loose_version(LooseVersion('1.0.0'))) == "SemanticVersion('1.0.0')"
    assert repr(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == "SemanticVersion('1.2.3')"
    assert repr(SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))) == "SemanticVersion('1.2.3')"
    assert repr(SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5'))) == "SemanticVersion('1.2.3')"

# Generated at 2022-06-11 18:45:56.528642
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.1.dev1+abc.def.gh')) == SemanticVersion('0.1.1-dev1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.1+abc.def.gh')) == SemanticVersion('0.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.1')) == SemanticVersion('0.1.1')



# Generated at 2022-06-11 18:46:04.029029
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    test_cases = {
        '1': SemanticVersion('1.0.0'),
        '2.1': SemanticVersion('2.1.0'),
        '3.2.1': SemanticVersion('3.2.1'),
        '4.3.2-alpha': SemanticVersion('4.3.2-alpha'),
        '5.4.3-beta+build.metadata': SemanticVersion('5.4.3-beta+build.metadata'),
    }

    for test in test_cases:
        loose_version = LooseVersion(test)
        semver = SemanticVersion.from_loose_version(loose_version)
        assert semver == test_cases[test]

# Generated at 2022-06-11 18:46:18.554305
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class TestVersion(LooseVersion):
        version_re = re.compile(r'(?P<major>\d)\.(?P<minor>\d)\.(?P<patch>\d)')
        def parse(self, vstring):
            match = self.version_re.match(vstring)
            if not match:
                raise ValueError("Invalid version string '%s'" % vstring)
            self.major = int(match.group('major'))
            self.minor = int(match.group('minor'))
            self.patch = int(match.group('patch'))
    assert SemanticVersion.from_loose_version(TestVersion('1.2.3')) == SemanticVersion('1.2.3')

# Generated at 2022-06-11 18:46:26.036897
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("0.3.1+1.2-3.4")

    version = SemanticVersion.from_loose_version(loose_version)

    assert version.major == 0
    assert version.minor == 3
    assert version.patch == 1
    assert version.prerelease == (1, 2)
    assert version.buildmetadata == (3, 4)

    # Ensure that we are actually creating a new object
    assert id(version) != id(loose_version)


# Generated at 2022-06-11 18:46:39.273505
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.9')) == SemanticVersion('1.0.9')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.9+beta')) == SemanticVersion('1.0.9+beta')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.9-beta')) == SemanticVersion('1.0.9-beta')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.9-beta.1')) == SemanticVersion('1.0.9-beta.1')

# Generated at 2022-06-11 18:46:47.782932
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1.0.0') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1.0') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1') == SemanticVersion('1.0.0')

    assert SemanticVersion.from_loose_version('1.0.0.alpha') == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version('1.0.0.2.c') == SemanticVersion('1.0.0-2.c')

    assert SemanticVersion.from_loose_version('1.0.0.alpha-1') == SemanticVersion('1.0.0-alpha-1')

# Generated at 2022-06-11 18:46:58.216657
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:47:07.853994
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('2.2.1')) == SemanticVersion('2.2.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.6dev')) == SemanticVersion('1.6.0-dev')
    assert SemanticVersion.from_loose_version(LooseVersion('1.6.rc2')) == SemanticVersion('1.6.0-rc.2')
    assert SemanticVersion.from_loose_version(LooseVersion('0')) == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')) == SemanticVersion('0.0.0')

# Generated at 2022-06-11 18:47:17.607684
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3

    loose_version = LooseVersion('1.2.3.4')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.minor == 2
    assert semantic_version.patch == 3

    loose_version = LooseVersion('1.2.3.4.5')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.major == 1
    assert semantic_version.min

# Generated at 2022-06-11 18:47:25.959245
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test SemanticVersion.from_loose_version()
    """
    test_version_str = "1.2.3"
    test_version = SemanticVersion(test_version_str)
    target_version_str = "1.2.3"

    test_version_from_loose = SemanticVersion.from_loose_version(test_version)

    str_match = ( (test_version_from_loose.vstring == target_version_str) or
                  (test_version_from_loose.vstring == target_version_str + "+0") )
    assert str_match, \
        ( "Unable to convert " + test_version_str + " to " +
          target_version_str + " : " + test_version_from_loose.vstring)

# Unit

# Generated at 2022-06-11 18:47:31.345608
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """test method SemanticVersion.from_loose_version()
    """
    with pytest.raises(ValueError) as excinfo:
        SemanticVersion.from_loose_version('1')
    assert str(excinfo.value) == "LooseVersion must have exactly one dot"

    with pytest.raises(ValueError) as excinfo:
        SemanticVersion.from_loose_version('1a')
    assert str(excinfo.value) == "LooseVersion must have exactly one dot"

# Generated at 2022-06-11 18:47:41.978389
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    version = SemanticVersion().parse('1.2.3')
    assert version.vstring == '1.2.3'
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version = SemanticVersion().parse('1.2.3-alpha.1')
    assert version.vstring == '1.2.3-alpha.1'
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert version.buildmetadata == ()

    version = SemanticVersion().parse('1.2.3+build.1')

# Generated at 2022-06-11 18:47:59.347528
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import assertRaisesRegex

    assertRaisesRegex(TypeError, ".*not a LooseVersion.*", SemanticVersion.from_loose_version, "1.2.3.4")
    assertRaisesRegex(TypeError, ".*not a LooseVersion.*", SemanticVersion.from_loose_version, SemanticVersion("1.2.3"))
    assertRaisesRegex(ValueError, ".*is not a LooseVersion.*", SemanticVersion.from_loose_version, LooseVersion("1.2.3.4.5"))
    assertRaisesRegex(ValueError, ".*Non integer values in.*", SemanticVersion.from_loose_version, LooseVersion("1.2.a"))

# Generated at 2022-06-11 18:48:09.299773
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import collections
    LooseVersion = collections.namedtuple("LooseVersion", ["vstring", "version"])
    loose_version = LooseVersion("1", [1])
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == "1.0.0+0"
    loose_version = LooseVersion("1.2", [1, 2])
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == "1.2.0+0"
    loose_version = LooseVersion("1.2.3", [1, 2, 3])
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == "1.2.3+0"


# Generated at 2022-06-11 18:48:18.143701
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3+4.5.6")) == SemanticVersion("1.2.3+4.5.6")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-4.5.6")) == SemanticVersion("1.2.3-4.5.6")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3.post1")) == SemanticVersion("1.2.3")

# Generated at 2022-06-11 18:48:25.753533
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3+meta')
    assert SemanticVersion.from_loose_version(loose_version) == loose_version
    loose_version = LooseVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(loose_version) == loose_version
    loose_version = LooseVersion('1.2.3.4')
    assert SemanticVersion.from_loose_version(loose_version) == loose_version
    loose_version = LooseVersion('1.2.3.4-alpha')
    assert SemanticVersion.from_loose_version(loose_version) == loose_version


# Generated at 2022-06-11 18:48:37.676494
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv = LooseVersion('1.0')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv == '1.0.0'

    lv = LooseVersion('1.0.0')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv == '1.0.0'

    lv = LooseVersion('1.0-1')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv == '1.0.0-1'

    lv = LooseVersion('1.0-1.0')
    sv = SemanticVersion.from_loose_version(lv)
    assert sv == '1.0.0-1.0'

    lv = LooseVersion('1.0+1.0')


# Generated at 2022-06-11 18:48:43.496362
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha1'))) == "1.2.3-alpha1"
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3+build1'))) == "1.2.3+build1"


# Generated at 2022-06-11 18:48:50.129178
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1')) == SemanticVersion('0.0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1~rc1')) == SemanticVersion('0.0.1-rc1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1-rc1.0')) == SemanticVersion('0.0.1-rc1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1-rc1.0+git.hash')) == SemanticVersion('0.0.1-rc1.0+git.hash')

# Generated at 2022-06-11 18:49:00.859311
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    loose_version = LooseVersion('0.1.2')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == LooseVersion('0.1.2')

    loose_version = LooseVersion('0.1.2+1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == LooseVersion('0.1.2')

    loose_version = LooseVersion('0.1.2-1.2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == LooseVersion('0.1.2-1.2.3')


# Generated at 2022-06-11 18:49:11.616160
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a LooseVersion with three ints
    result_1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert result_1.vstring == '1.2.3'

    # Test a LooseVersion with three ints, a prerelease and buildmetadata
    result_2 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-beta.2+42'))
    assert result_2.vstring == '1.2.3-beta.2+42'
    assert result_2.core == (1, 2, 3)
    assert result_2.prerelease == (_Alpha('beta'), _Numeric('2'))
    assert result_2.buildmetadata == (
        _Numeric('42'),
    )

    # Test a Loose

# Generated at 2022-06-11 18:49:18.819964
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion.from_loose_version(LooseVersion('0.1.2'))
    assert v1.major == 0
    assert v1.minor == 1
    assert v1.patch == 2

    v2 = SemanticVersion.from_loose_version(LooseVersion('1.2'))
    assert v2.major == 1
    assert v2.minor == 2
    assert v2.patch == 0

    v3 = SemanticVersion.from_loose_version(LooseVersion('1'))
    assert v3.major == 1
    assert v3.minor == 0
    assert v3.patch == 0

    v4 = SemanticVersion.from_loose_version(LooseVersion('0.1.2-alpha.1+fork.1'))

# Generated at 2022-06-11 18:49:46.705521
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2-post2')) == \
        SemanticVersion('0.1.2-post2')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1+post2')) == \
        SemanticVersion('0.1.0+post2')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2-post2+extra-data')) == \
        SemanticVersion('0.1.2-post2+extra-data')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.2+extra-data')) == \
        SemanticVersion('0.1.2+extra-data')
    assert SemanticVersion.from_loose_

# Generated at 2022-06-11 18:49:59.380576
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:50:08.352524
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test case #1:
    # Test that passing a ``LooseVersion`` yields a ``SemanticVersion``
    ansible_version = SemanticVersion.from_loose_version(LooseVersion('2.8.2'))
    assert isinstance(ansible_version, SemanticVersion)

    # Test case #2:
    # Test that passing a string does not yield a ``SemanticVersion``
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('2.8.2')


# Generated at 2022-06-11 18:50:14.724596
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that invalid LooseVersion raises an error
    try:
        SemanticVersion.from_loose_version('1.2.3a')
    except Exception as e:
        assert isinstance(e, ValueError)

    # Test that the Version object is created correctly
    assert (SemanticVersion.from_loose_version('1.2.3') ==
            SemanticVersion('1.2.3'))



# Generated at 2022-06-11 18:50:26.429643
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def test_version(l, v):
        assert SemanticVersion.from_loose_version(l) == v

    test_version(LooseVersion('1.9.9'), SemanticVersion('1.9.9'))
    test_version(LooseVersion('1.a.0'), SemanticVersion('1.0.0'))
    test_version(LooseVersion('1.0.b'), SemanticVersion('1.0.0'))
    test_version(LooseVersion('1.0'), SemanticVersion('1.0.0'))
    test_version(LooseVersion('1'), SemanticVersion('1.0.0'))

    test_version(LooseVersion('1.9.9-alpha'), SemanticVersion('1.9.9-alpha'))

# Generated at 2022-06-11 18:50:39.432466
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.1.1a1')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.1.1-a1'
    loose_version = LooseVersion('1.1.1')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.1.1'
    loose_version = LooseVersion('1')
    assert SemanticVersion.from_loose_version(loose_version) == LooseVersion('1.0.0')
    loose_version = LooseVersion('1.0a1')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.0.0-a1'

# Generated at 2022-06-11 18:50:47.100008
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    cmp_version_1 = SemanticVersion('1.12.1')
    cmp_version_2 = SemanticVersion('1.12.2')
    cmp_version_3 = SemanticVersion('1.12.2-alpha')
    cmp_version_4 = SemanticVersion('1.12.2-alpha+build.1234.9.9')

    # Create LooseVersion instance and testing with them
    lv_instance_1 = LooseVersion('1.12.1')
    result_1 = cmp_version_1.from_loose_version(lv_instance_1)
    assert result_1 == cmp_version_1

    lv_instance_2 = LooseVersion('1.12.2')

# Generated at 2022-06-11 18:50:58.795094
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Sample of invalid values
    invalid_values = [
        '',                  # Empty string
        None,                # None
        b'',                 # Byte string
        (1, 0, 0),           # Tuple
        [1, 0, 0],           # List
        {'1.0.0': 'a'},      # Dict
        {1, 0, 0},           # Set
        object(),            # Object
        LooseVersion('1'),   # LooseVersion
        Version('1'),        # Version
        SemanticVersion('1'),# SemanticVersion
    ]

    for v in invalid_values:
        try:
            SemanticVersion.from_loose_version(v)
            assert False
        except ValueError:
            assert True

    # Sample of valid values

# Generated at 2022-06-11 18:51:03.881134
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Arrange
    lv = LooseVersion(text_type('1.2.3.4'))
    expected = SemanticVersion(text_type('1.2.3'))

    # Act
    sv = SemanticVersion.from_loose_version(lv)

    # Assert
    assert expected == sv

# Generated at 2022-06-11 18:51:15.830420
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion provides a method for making sure that
    # the version is a valid version.  This test makes
    # sure that this method remains consistent with it
    # by verifying that the LooseVersion method doesn't
    # allow a bad version
    v = LooseVersion('1')
    try:
        v.parse('1asdf')
        assert False
    except ValueError:
        pass

    # Test that we can handle normal versions
    semver = SemanticVersion.from_loose_version(LooseVersion('1'))
    assert semver == SemanticVersion('1')

    # Test that we can handle versions with a prerelease
    semver = SemanticVersion.from_loose_version(LooseVersion('1-2'))
    assert semver == SemanticVersion('1.0.0-2')

    # Test

# Generated at 2022-06-11 18:51:47.307931
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.3.3')) == SemanticVersion('1.3.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.3.2')) < SemanticVersion('1.3.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.3.4')) > SemanticVersion('1.3.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.3')) == SemanticVersion('1.3.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')

# Generated at 2022-06-11 18:51:49.141384
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    version = SemanticVersion.from_loose_version(sys.version_info)
    assert version



# Generated at 2022-06-11 18:51:56.362783
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Create an object of class LooseVersion
    loose_version_object = LooseVersion("1.2.3")
    # Test if the method converts an object of class LooseVersion into SemanticVersion
    assert isinstance(SemanticVersion.from_loose_version(loose_version_object), SemanticVersion)
    # Test if the method raises a ValueError if the input is not a LooseVersion
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(SemanticVersion("1.2.3"))
    # Test if the method accepts a prerelease version
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')), SemanticVersion)
    # Test if the method accepts a version with build metadata

# Generated at 2022-06-11 18:52:05.244898
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test method from_loose_version of class SemanticVersion.
    """