

# Generated at 2022-06-11 18:42:23.401214
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    from ansible.module_utils.semver import SemanticVersion
    from ansible.errors import AnsibleModuleError

    def check_parse(version, expected):
        try:
            s_version = SemanticVersion(version)
        except ValueError as e:
            raise AnsibleModuleError('version %s not accepted: %s' % (version, e))
        assert (s_version.major, s_version.minor, s_version.patch, s_version.prerelease, s_version.buildmetadata) == expected, 'failed to parse %s' % version


# Generated at 2022-06-11 18:42:28.720042
# Unit test for method __lt__ of class _Alpha
def test__Alpha___lt__():
    assert not _Alpha(1) < _Alpha(1)
    assert _Alpha(1) < _Alpha('a')
    assert not _Alpha('a') < _Alpha(1)
    assert _Alpha('a') < _Alpha('b')
    assert not _Alpha('b') < _Alpha('a')


# Generated at 2022-06-11 18:42:40.942730
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:42:49.915496
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') == _Alpha('a')
    assert _Alpha('a') == 'a'
    assert 'a' == _Alpha('a')
    assert _Alpha('a') <= 'a'
    assert 'a' <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('a') <= 'b'
    assert _Alpha('a') <= _Numeric(2)
    assert _Alpha('a') <= 2
    assert 'a' <= _Alpha('b')
    assert 'a' <= 'b'
    assert 'a' <= _Numeric(2)
    assert 'a' <= 2



# Generated at 2022-06-11 18:43:01.848376
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # This will raise ValueError for invalid versions
    assert SemanticVersion('10.4.7').core == (10, 4, 7)
    assert SemanticVersion('1.2.3').core == (1, 2, 3)
    assert SemanticVersion('1.2.3-rc.1.2.3+build.11.e0f985a').core == (1, 2, 3)
    assert SemanticVersion('1.2.3-rc.1.2.3+build.11.e0f985a').prerelease == (1, 2, 3)
    assert SemanticVersion('1.2.3-rc.1.2.3+build.11.e0f985a').buildmetadata == (11, 'e0f985a')

# Generated at 2022-06-11 18:43:12.947446
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # **NOTE**: This test suite uses ansible.module_utils.compat.version.LooseVersion
    # rather than distutils.version.LooseVersion to test against. This is
    # because the distutils.version.LooseVersion has a different implementation
    # in py2 vs py3 and this creates a brittle test as well as a lot of boilerplate
    # code to test the same function.
    from ansible.module_utils.compat.version import LooseVersion

    # None of these should error
    LooseVersion("1.0")
    LooseVersion("1.0-alpha.1")
    LooseVersion("1.0+123456789")
    LooseVersion("1.0-alpha.1+123456789")

    # These should all error

# Generated at 2022-06-11 18:43:19.276014
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha_1 = _Alpha('alpha-1')
    alpha_2 = _Alpha('alpha-2')

    # 'alpha-2' is greater than 'alpha-1'
    assert not alpha_1 <= alpha_2

    # 'alpha-1' is less than 'alpha-2'
    assert alpha_1 <= _Alpha('alpha-1')


# Generated at 2022-06-11 18:43:31.542473
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    d = SemanticVersion()
    d.parse('1.2.3')
    assert d.major == 1
    assert d.minor == 2
    assert d.patch == 3
    assert d.prerelease == ()
    assert d.buildmetadata == ()
    assert d.is_stable

    d = SemanticVersion()
    d.parse('1.2.3-alpha.1')
    assert d.major == 1
    assert d.minor == 2
    assert d.patch == 3
    assert d.prerelease == (_Alpha('alpha'), _Numeric('1'))
    assert d.buildmetadata == ()
    assert not d.is_stable

    d = SemanticVersion()
    d.parse('1.2.3-alpha.1+build')
    assert d.major == 1

# Generated at 2022-06-11 18:43:40.504292
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Unit test for method parse of class SemanticVersion
    version = SemanticVersion('1.2.3')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version = SemanticVersion('1.2.3-alpha-2.beta')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == (_Alpha('alpha'), _Numeric('2'), _Alpha('beta'))
    assert version.buildmetadata == ()

    version = SemanticVersion('1.2.3+build.42')
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3

# Generated at 2022-06-11 18:43:50.112440
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert (_Alpha('abc') <= _Alpha('abc')), "abc should be <= to abc"
    assert (_Alpha('abc') <= 'abc'), "abc should be <= to abc"
    assert (not (_Alpha('abc') <= _Alpha('abd'))), "abc should not be <= to abd"
    assert (not (_Alpha('abc') <= 'abd')), "abc should not be <= to abd"
    assert (not (_Alpha('abc') <= _Numeric('0'))), "abc should not be ≤ to 0"
    return



# Generated at 2022-06-11 18:44:09.097348
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0-0')) == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha')) == SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+buildmetadata')) == SemanticVersion('1.0.0+buildmetadata')

# Generated at 2022-06-11 18:44:18.542181
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class DummyLooseVersion(object):
        vstring = '1.2.3+foobar'
        version = (1, 2, 3)

    v = SemanticVersion.from_loose_version(DummyLooseVersion())
    assert v == '1.2.3+foobar'

    # A real LooseVersion object should also work
    from ansible.module_utils.six.moves.urllib.request import parse_http_list
    assert SemanticVersion.from_loose_version(parse_http_list.__version__) == parse_http_list.__version__

# Generated at 2022-06-11 18:44:29.345737
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lv1 = LooseVersion("1.0")
    sv1 = SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(lv1) == sv1

    lv2 = LooseVersion("1.0.dev345")
    sv2 = SemanticVersion("1.0.0-dev345")
    assert SemanticVersion.from_loose_version(lv2) == sv2

    lv3 = LooseVersion("1.2.3-rc2")
    sv3 = SemanticVersion("1.2.3-rc2")
    assert SemanticVersion.from_loose_version(lv3) == sv3

    lv4 = LooseVersion("2.2.0rc2")
    sv4 = SemanticVersion("2.2.0-rc2")

# Generated at 2022-06-11 18:44:35.321107
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import unittest
    class TestSemanticVersionFromLooseVersion(unittest.TestCase):
        def test_LooseVersion_int(self):
            loose_version = LooseVersion('1.2.3')
            semantic_version = SemanticVersion.from_loose_version(loose_version)
            self.assertEqual(semantic_version.vstring, '1.2.3')

        def test_LooseVersion_str(self):
            loose_version = LooseVersion('1.2a.3')
            self.assertEqual(loose_version.base_version, '1.2.3')
            semantic_version = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-11 18:44:48.799351
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.1")).vstring == "1.0.1"
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.1-alpha")).vstring == "1.0.1-alpha"
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.1+foobar")).vstring == "1.0.1+foobar"
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.1-alpha+foobar")).vstring == "1.0.1-alpha+foobar"

# Generated at 2022-06-11 18:45:00.231703
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert str(semver) == '1.2.3'
    loose_version = LooseVersion('1.2.3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert str(semver) == '1.2.3'
    loose_version = LooseVersion('1.2.3~rc1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert str(semver) == '1.2.3-rc1'
    loose_version = LooseVersion('1.2.3~rc1-git')
    semver = SemanticVersion.from_loose_

# Generated at 2022-06-11 18:45:11.166960
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('0') == SemanticVersion('0.0.0')
    assert SemanticVersion.from_loose_version('0.8') == SemanticVersion('0.8.0')
    assert SemanticVersion.from_loose_version('0.8.1') == SemanticVersion('0.8.1')
    assert SemanticVersion.from_loose_version('0.8.1-beta') == SemanticVersion('0.8.1-beta')
    assert SemanticVersion.from_loose_version('0.8.1-beta+20150901') == SemanticVersion('0.8.1-beta+20150901')

# Generated at 2022-06-11 18:45:19.031494
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # pylint: disable=bad-whitespace
    data = [
        {
            'example': '1.2.3.4',
            'expected': SemanticVersion('1.2.3'),
        },
        {
            'example': '1.2.3',
            'expected': SemanticVersion('1.2.3'),
        },
        {
            'example': '1.2',
            'expected': SemanticVersion('1.2.0'),
        },
        {
            'example': '1',
            'expected': SemanticVersion('1.0.0'),
        },
    ]
    for item in data:
        assert SemanticVersion.from_loose_version(LooseVersion(item['example'])) == item['expected']

# Generated at 2022-06-11 18:45:32.224219
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Test function from_loose_version of class SemanticVersion
    """
    from ansible.module_utils.version import LooseVersion
    from ansible.module_utils.compat.version import SemanticVersion

    loose_version = LooseVersion('2.2')
    ver = SemanticVersion.from_loose_version(loose_version)
    assert ver.major == 2
    assert ver.minor == 2
    assert ver.patch == 0
    assert ver.prerelease == ()
    assert ver.buildmetadata == ()

    loose_version = LooseVersion('2.2.0')
    ver = SemanticVersion.from_loose_version(loose_version)
    assert ver.major == 2
    assert ver.minor == 2
    assert ver.patch == 0
    assert ver.prerelease == ()


# Generated at 2022-06-11 18:45:40.322715
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha("a")
    b = _Alpha("b")
    c = _Alpha("c")
    x = _Alpha("x")
    y = _Alpha("y")
    z = _Alpha("z")
    d1 = _Alpha("d1")
    d2 = _Alpha("d2")
    d3 = _Alpha("d3")
    a1 = _Alpha("a1")
    a2 = _Alpha("a2")
    a3 = _Alpha("a3")

    assert a < b
    assert b > a
    assert a <= b
    assert b >= a
    assert a <= a
    assert a == a
    assert a >= a
    assert a >= b
    assert a2 < a3
    assert a3 > a2
    assert d2 < d3
    assert d3 > d2

# Generated at 2022-06-11 18:46:01.409992
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils.six import PY3
    if PY3:
        major = 1
        minor = 1
        patch = 0
    else:
        major = '1'
        minor = '1'
        patch = '0'
    lv = LooseVersion(['a', major, minor, patch])
    sv = SemanticVersion.from_loose_version(lv)
    # test whether the string representation of sv is equal to '1.1.0'
    assert(str(sv) == '1.1.0')


# Generated at 2022-06-11 18:46:08.814907
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0'))._cmp(SemanticVersion('0.0.0')) == 0

    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0'))._cmp(SemanticVersion('0.0.0-alpha.1')) == 1

    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1'))._cmp(SemanticVersion('0.0.0-alpha.1')) == 1

# Generated at 2022-06-11 18:46:21.126372
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion('0.0.1') == SemanticVersion.from_loose_version(LooseVersion('0.0.1'))
    assert SemanticVersion('0.0.1-beta1') == SemanticVersion.from_loose_version(LooseVersion('0.0.1~beta1'))
    assert SemanticVersion('0.0.1-beta1+build1.0') == SemanticVersion.from_loose_version(LooseVersion('0.0.1~beta1+build1.0'))

    assert SemanticVersion('0.0.1-alpha.12') == SemanticVersion.from_loose_version(LooseVersion('0.0.1~alpha12'))
    assert SemanticVersion('0.0.1-alpha.12') == SemanticVersion.from_loose_

# Generated at 2022-06-11 18:46:30.080267
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:46:43.186415
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:46:55.456515
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion """

    # Check if the method raises a ValueError if input is None
    try:
        result = SemanticVersion.from_loose_version(None)
        raise AssertionError("A ValueError should have been raised")
    except ValueError:
        pass

    # Check if the method raises a ValueError if input is not a LooseVersion
    try:
        loose_version = "1.2.3"
        result = SemanticVersion.from_loose_version(loose_version)
        raise AssertionError("A ValueError should have been raised")
    except ValueError:
        pass

    # Check if the method returns the expected semantic version
    loose_version = "1.2.3.final-4"

# Generated at 2022-06-11 18:47:04.504664
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3-beta'))
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == ('beta',)
    assert sv.is_stable is True

    sv = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 3
    assert sv.prerelease == ()
    assert sv.is_stable is True

    sv = SemanticVersion.from_loose_version(LooseVersion('1.2'))
    assert sv.major == 1
    assert sv.minor == 2
    assert sv.patch == 0
    assert sv.pre

# Generated at 2022-06-11 18:47:15.174072
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test successful creation of SemanticVersion from LooseVersion
    loose_version = LooseVersion('1.2.3.4')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semver, SemanticVersion)
    assert semver == loose_version

    loose_version = LooseVersion('1.2.3-alpha.1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semver, SemanticVersion)
    assert semver == loose_version

    loose_version = LooseVersion('1.2.3.4+build.5')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semver, SemanticVersion)

# Generated at 2022-06-11 18:47:27.385665
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import re
    import collections
    from ansible.module_utils.compat.version import LooseVersion
    from ansible.module_utils.compat.semantic_version import SemanticVersion


# Generated at 2022-06-11 18:47:38.934557
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # https://semver.org/#spec-item-2
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-alpha+001')) == SemanticVersion('1.0.0-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+20130313144700')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta+exp.sha.5114f85')) == SemanticVersion('1.0.0-beta.exp.sha.5114f85')
    # https://semver.org/#spec-item-10

# Generated at 2022-06-11 18:48:08.713368
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:17.095385
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import builtins

    assert SemanticVersion.from_loose_version(builtins.range(3)) == SemanticVersion('0.0.1')
    assert SemanticVersion.from_loose_version('0.13.1+dev') == SemanticVersion('0.13.1+dev')
    assert SemanticVersion.from_loose_version('0.13.1-dev') == SemanticVersion('0.13.1-dev')



# Generated at 2022-06-11 18:48:25.785065
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semver = SemanticVersion.from_loose_version(LooseVersion('1.20.0'))
    assert semver.vstring == '1.20.0'

    # Reusing semver instance to test semantic version equality
    # Loose version equality already tested in ansible test_utils.py
    assert LooseVersion('1.20.0') == semver

    semver = SemanticVersion.from_loose_version(LooseVersion('1.20.0-alpha+meta'))
    assert semver.vstring == '1.20.0-alpha+meta'
    assert LooseVersion('1.20.0-alpha+meta') == semver

    semver = SemanticVersion.from_loose_version(LooseVersion('1.0.0-0.3.7'))
    assert semver.v

# Generated at 2022-06-11 18:48:37.717576
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1.2') == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version('1.2.3-4') == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version('1.2.3+4') == SemanticVersion('1.2.3+4')
    assert SemanticVersion.from_loose_version('1.2.3+4pre') == SemanticVersion('1.2.3+4pre')
    assert SemanticVersion.from_loose_version('1.2.3-alpha.1.2.3+4build.5')

# Generated at 2022-06-11 18:48:47.867038
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.5.0-beta.2')) == SemanticVersion('1.5.0-beta.2')
    assert SemanticVersion.from_loose_version(LooseVersion('1.5.0.beta.2')) == SemanticVersion('1.5.0-beta.2')
    assert SemanticVersion.from_loose_version(LooseVersion('1.5.2-beta.2')) == SemanticVersion('1.5.2-beta.2')
    assert SemanticVersion.from_loose_version(LooseVersion('1.5-beta.2')) == SemanticVersion('1.5.0-beta.2')

# Generated at 2022-06-11 18:48:59.705638
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')) == SemanticVersion('1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1-alpha')) == SemanticVersion('1.1.1-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1+buildinfo')) == SemanticVersion('1.1.1+buildinfo')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1-alpha+buildinfo')) == SemanticVersion('1.1.1-alpha+buildinfo')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2-alpha')) == SemanticVersion('1.2-alpha')

# Generated at 2022-06-11 18:49:10.832161
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    try:
        sv = SemanticVersion.from_loose_version('11.10')
        assert sv.major == 11 and sv.minor == 10 and sv.patch == 0 and \
               sv.prerelease == () and sv.buildmetadata == ()
        print("'SemanticVersion.from_loose_version({!r})' -> {!r} (OK)".format('11.10', sv))
    except ValueError as e:
        print("'SemanticVersion.from_loose_version({!r})' -> ValueError: {!r} (FAILED)".format('11.10', e))


# Generated at 2022-06-11 18:49:21.565431
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4')) == SemanticVersion('1.2.3+4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) == SemanticVersion('1.2.3-4')

# Generated at 2022-06-11 18:49:34.083362
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1')) == SemanticVersion('1.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1-5.5')) == SemanticVersion('1.1.1-5.5')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1-5.5.5.5')) == SemanticVersion('1.1.1-5.5.5.5')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.1-alpha.1')) == SemanticVersion('1.1.1-alpha.1')

# Generated at 2022-06-11 18:49:46.176980
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.1')) == SemanticVersion('1.0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4.5.6.7')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1.2.3')) == SemanticVersion('1.2.3-alpha.1.2.3')

# Generated at 2022-06-11 18:50:29.948381
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    vloose = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(vloose) == SemanticVersion('1.2.3')

    vloose = LooseVersion('3.0a1')
    assert SemanticVersion.from_loose_version(vloose) == SemanticVersion('3.0.0-alpha.1')


# Generated at 2022-06-11 18:50:41.825700
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # python 2.6 does not support the 'marker' for re.sub
    def replace(string, marker, replacement):
        return re.sub(r'(?<=\d)(' + marker + r')(?=\d)', replacement, string)

    # python 2.6 has a different format for the __repr__ output, remove those
    def clean(string):
        return string.replace('LooseVersion', '')

    strict = ('(%r, %r)', 'SemanticVersion(%r)', '%r', '%r')
    lax = ('LooseVersion(%r)', 'LooseVersion(%r)')

# Generated at 2022-06-11 18:50:55.565158
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves.urllib.parse import urlparse
    from ansible.module_utils._text import to_text

    # Test a loose version string with prerelease and build metadata
    loose_version_string = "0.0.2-alpha.1+sha.5114f85"
    loose_version = LooseVersion(loose_version_string)
    exception = None
    result = None
    try:
        result = SemanticVersion.from_loose_version(loose_version)
    except ValueError as exc:
        exception = exc
    assert result is not None
    assert exception is None
    assert result.core == (0, 0, 2)
    assert result.prerelease == ("alpha", "1")
    assert result.buildmetadata == ("sha", "5114f85")

# Generated at 2022-06-11 18:51:08.014441
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def do_test(loose_version, semantic_version):
        ver = SemanticVersion.from_loose_version(loose_version)
        assert ver.vstring == semantic_version

    do_test('1', '1')
    do_test('1.2', '1.2')
    do_test('1.2.3', '1.2.3')
    do_test('1.2.3-alpha', '1.2.3-alpha')
    do_test('1.2.3-alpha.1', '1.2.3-alpha.1')
    do_test('1.2.3-alpha.1+build', '1.2.3-alpha.1+build')

# Generated at 2022-06-11 18:51:13.942678
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:51:16.322398
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')

# Generated at 2022-06-11 18:51:28.569660
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    if SemanticVersion.from_loose_version(LooseVersion('1.2.0')) != SemanticVersion('1.2.0'):
        raise AssertionError('SemanticVersion.from_loose_version(LooseVersion(\'1.2.0\')) != SemanticVersion(\'1.2.0\')')

    if SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) != SemanticVersion('1.2.3'):
        raise AssertionError('SemanticVersion.from_loose_version(LooseVersion(\'1.2.3.4\')) != SemanticVersion(\'1.2.3\')')


# Generated at 2022-06-11 18:51:35.855261
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Assertions for the validity of method from_loose_version of class SemanticVersion
    assert(SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3"))
    assert(SemanticVersion.from_loose_version(LooseVersion("1.2")) == SemanticVersion("1.2.0"))
    assert(SemanticVersion.from_loose_version(LooseVersion("1")) == SemanticVersion("1.0.0"))
    assert(SemanticVersion.from_loose_version(LooseVersion("1.2.3b4")) == SemanticVersion("1.2.3-b4"))

# Generated at 2022-06-11 18:51:41.834231
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:51:52.214132
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.10.0')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 1
    assert semver.minor == 10
    assert semver.patch == 0
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    loose_version = LooseVersion('1.10.0rc1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.major == 1
    assert semver.minor == 10
    assert semver.patch == 0
    assert semver.prerelease == ('rc', 1)
    assert semver.buildmetadata == ()

    loose_version = LooseVersion('1.10.rc1')
    semver = Semantic