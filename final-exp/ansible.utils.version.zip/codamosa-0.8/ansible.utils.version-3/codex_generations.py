

# Generated at 2022-06-11 18:42:28.766577
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion().parse('0.0.1-dev')
    assert v.major == 0
    assert v.minor == 0
    assert v.patch == 1
    assert v.prerelease == ('dev', )

    v = SemanticVersion().parse('0.0.1-dev.0')
    assert v.major == 0
    assert v.minor == 0
    assert v.patch == 1
    assert v.prerelease == ('dev', '0')

    try:
        v = SemanticVersion().parse('0.0.1:0')
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-11 18:42:40.997478
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    import pytest

    sut = SemanticVersion()

    # Test normal version numbers
    vstring = "1.0.0"
    sut.parse(vstring)
    assert sut.major == 1
    assert sut.minor == 0
    assert sut.patch == 0

    # Test with prerelease
    sut.parse("1.0.0-rc")
    assert sut.major == 1
    assert sut.minor == 0
    assert sut.patch == 0
    assert sut.prerelease == (_Alpha("rc"), )

    # Test with buildmetadata
    sut.parse("1.0.0+20200726.6")
    assert sut.major == 1
    assert sut.minor == 0
    assert sut.patch == 0

# Generated at 2022-06-11 18:42:50.823303
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    expected = SemanticVersion(vstring="3.3.7-rc1+build2.b8f12d7.dirty")
    result = SemanticVersion.from_loose_version(LooseVersion("3.3.7-rc1+build2.b8f12d7.dirty"))
    assert expected == result
    expected = SemanticVersion(vstring="3.3.7+build2.b8f12d7.dirty")
    result = SemanticVersion.from_loose_version(LooseVersion("3.3.7+build2.b8f12d7.dirty"))
    assert expected == result
    expected = SemanticVersion(vstring="3.3.7-rc1")
    result = SemanticVersion.from_loose_version(LooseVersion("3.3.7-rc1"))
   

# Generated at 2022-06-11 18:43:02.201849
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    l0 = SemanticVersion()
    l0.parse('0.0.0')
    assert l0.major == 0
    assert l0.minor == 0
    assert l0.patch == 0
    assert not l0.prerelease
    assert not l0.buildmetadata
    
    l0.parse('1.2.3-4+5')
    assert l0.major == 1
    assert l0.minor == 2
    assert l0.patch == 3
    assert l0.prerelease == (4,)
    assert l0.buildmetadata == (5,)

    l0.parse('1.2.3-4.5+6')
    assert l0.major == 1
    assert l0.minor == 2
    assert l0.patch == 3
    assert l0.prerelease == (4, 5)

# Generated at 2022-06-11 18:43:09.561907
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    """ Unit test for method SemanticVersion._parse.

        Tests:
            - normal parsing
            - invalid semantic version strings
    """
    # normal parsing
    v = SemanticVersion('1.0.0')
    assert v.vstring == '1.0.0'
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion('0.0.0')
    assert v.vstring == '0.0.0'
    assert v.major == 0
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    v = SemanticVersion('1.0.0-alpha.1')


# Generated at 2022-06-11 18:43:23.229847
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_string = "0.0.2-alpha2"
    loose_version = LooseVersion(loose_version_string)
    version = SemanticVersion()
    version.from_loose_version(loose_version)
    assert version.vstring == loose_version_string
    loose_version_string = "0.0.2"
    loose_version = LooseVersion(loose_version_string)
    version = SemanticVersion()
    version.from_loose_version(loose_version)
    assert version.vstring == loose_version_string
    loose_version_string = "0.0.2+build_metadata"
    loose_version = LooseVersion(loose_version_string)
    version = SemanticVersion()

# Generated at 2022-06-11 18:43:33.944818
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test for method from_loose_version of class SemanticVersion"""
    from ansible.module_utils.compat.version import LooseVersion

    # test with all numeric
    str_version = '0.2.3'
    loose_version = LooseVersion(str_version)
    strict_version = SemanticVersion.from_loose_version(loose_version)
    assert strict_version.major == 0
    assert strict_version.minor == 2
    assert strict_version.patch == 3
    assert str_version == strict_version.vstring

    # test with leading characters
    str_version = 'a0.2.3'
    loose_version = LooseVersion(str_version)
    strict_version = SemanticVersion.from_loose_version(loose_version)
    assert strict_version

# Generated at 2022-06-11 18:43:42.941915
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests that the tested method returns a SemanticVersion object

    # Positive tests with semantic versions
    assert isinstance(SemanticVersion.from_loose_version('1.0.0'), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version('1.2.3'), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version('1.2.3-0'), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version('1.2.3-1'), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version('1.2.3-1.0'), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version('1.2.3-1.0.0'), SemanticVersion)
   

# Generated at 2022-06-11 18:43:55.914152
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:44:08.115828
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()

    # Test invalid semantic version
    try:
        v.parse("abcd")
    except ValueError as e:
        assert("invalid semantic version 'abcd'" in str(e))

    v = SemanticVersion("1.2.3-prerelease.1+buildmetadata")

    assert(v.major == 1)
    assert(v.minor == 2)
    assert(v.patch == 3)
    assert(v.prerelease == (_Numeric(1),))
    assert(v.buildmetadata == ())
    assert(v.core == (1, 2, 3))
    assert(v.is_prerelease)
    assert(v.is_stable is False)

    v = SemanticVersion("1.2.3-prerelease.1+buildmetadata.1")


# Generated at 2022-06-11 18:44:22.991608
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha.1")) == SemanticVersion("1.2.3-alpha.1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha1")) == SemanticVersion("1.2.3-alpha1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha1+build1")) == SemanticVersion("1.2.3-alpha1+build1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3+build1")) == SemanticVersion("1.2.3+build1")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-1")) == Sem

# Generated at 2022-06-11 18:44:35.431254
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils._text import to_native
    from .__init__ import MODULE_UTILS_PATH
    import os
    import sys

    current_path = os.path.dirname(os.path.abspath(__file__))
    sys.path.append(os.path.join(current_path, '..'))
    sys.path.append(MODULE_UTILS_PATH)
    sys.stdout.write('\n' + to_native(sys.path))

    import pytest


# Generated at 2022-06-11 18:44:48.841844
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    Test: SemanticVersion.from_loose_version
    '''

    import os

    import sys
    sys.path.append(os.path.dirname(__file__))
    import compare_version_test_data

    for (version_string, _, exception_message, _) in compare_version_test_data.test_data:
        # If exception_message not None, then we should throw an exception.
        # If exception_message is None, then we should NOT throw an exception
        if exception_message is not None:
            try:
                SemanticVersion(version_string)
                # This is bad, we should have thrown an exception
                assert False
            except ValueError:
                # This is good, we should have thrown an exception
                pass

# Generated at 2022-06-11 18:45:00.275094
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:45:11.165152
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semver = SemanticVersion.from_loose_version(LooseVersion('1.10.0'))
    assert semver == '1.10.0'

    semver = SemanticVersion.from_loose_version(LooseVersion('1.10.0foo'))
    assert semver == '1.10.0'

    semver = SemanticVersion.from_loose_version(LooseVersion('1.10.0+foo.1'))
    assert semver == '1.10.0'

    semver = SemanticVersion.from_loose_version(LooseVersion('1.10.0-foo.1'))
    assert semver == '1.10.0'


# Generated at 2022-06-11 18:45:19.340412
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.3")) == SemanticVersion("1.0.3")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.3-beta")) == SemanticVersion("1.0.3-beta")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.3+dev")) == SemanticVersion("1.0.3+dev")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.3-beta+dev")) == SemanticVersion("1.0.3-beta+dev")

# Generated at 2022-06-11 18:45:31.147134
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert(str(SemanticVersion.from_loose_version(LooseVersion('0.1.0'))) == '0.1.0')
    assert(str(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == '1.2.3')
    assert(str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-4'))) == '1.2.3-4')
    assert(str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-4+5-6.7'))) == '1.2.3-4+5-6.7')


# Generated at 2022-06-11 18:45:38.885789
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common.version import LooseVersion

# Generated at 2022-06-11 18:45:50.589911
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    This method test from_loose_version() of class SemanticVersion
    '''
    # Test case:
    # Input:
    #   - LooseVersion object
    # Expected output:
    #   - SemanticVersion object
    loose_version = LooseVersion("2.4.1")
    result = SemanticVersion.from_loose_version(loose_version)
    assert result.major == 2
    assert result.minor == 4
    assert result.patch == 1
    assert result.prerelease == ()
    assert result.buildmetadata == ()

    # Test case:
    # Input:
    #   - Non LooseVersion object
    # Expected output:
    #   - ValueError

# Generated at 2022-06-11 18:46:01.445370
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert v1.core == (1, 2, 3)

    v2 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre1'))
    assert v2.core == (1, 2, 3)
    assert v2.prerelease == ('pre1',)

    v3 = SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre1.pre2.alpha'))
    assert v3.core == (1, 2, 3)
    assert v3.prerelease == ('pre1', 'pre2', 'alpha')


# Generated at 2022-06-11 18:46:19.240710
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # we only use the LooseVersion class of the module_utils.version module
    from ansible.module_utils.version import LooseVersion

    # LooseVersion test cases

# Generated at 2022-06-11 18:46:29.261134
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1.0')) == SemanticVersion('1.1.0')

# Generated at 2022-06-11 18:46:42.607038
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class TestData:
        def __init__(self, expected_error, version, version_string):
            self.expected_error = expected_error
            self.version = version
            self.version_string = version_string


# Generated at 2022-06-11 18:46:55.163400
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # When there is no loose version, raise exception
    try:
        SemanticVersion.from_loose_version(None)
        assert False
    except ValueError:
        pass

    # When there is invalid loose version, raise exception
    try:
        SemanticVersion.from_loose_version('1.2.3(*&^%$')
        assert False
    except ValueError:
        pass

    # When there is only one version, convert it to a tuple
    assert SemanticVersion.from_loose_version('1.2').core == (1, 2, 0)

    # When there is two versions, convert them to a tuple
    assert SemanticVersion.from_loose_version('1.2.3').core == (1, 2, 3)

    # When there is three versions, convert them to a tuple
    assert Sem

# Generated at 2022-06-11 18:47:04.352619
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    lversion = LooseVersion('1.1.1.2.3')
    sversion = SemanticVersion.from_loose_version(lversion)
    assert len(sversion.core) == len(lversion.version)

    lversion = LooseVersion('1.1.1b.2.3')
    sversion = SemanticVersion.from_loose_version(lversion)
    assert len(sversion.core) == len(lversion.version)

    lversion = LooseVersion('1.1.1.2.3')
    sversion = SemanticVersion.from_loose_version(lversion)
    assert len(sversion.core) == len(lversion.version)

    lversion = LooseVersion('1.1.1.2.3')
    sversion = SemanticVersion.from_lo

# Generated at 2022-06-11 18:47:15.001951
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    '''
    Unit test for method from_loose_version of class SemanticVersion
    '''
    # Unit test target: from_loose_version, expected value is v2
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    v2 = SemanticVersion('1.0.0')
    assert v1 == v2

    # Unit test target: from_loose_version, expected value is v2
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.0.0rc2'))
    v2 = SemanticVersion('1.0.0-rc.2')
    assert v1 == v2

    # Unit test target: from_loose_version, expected value is v2
    v1 = SemanticVersion.from_lo

# Generated at 2022-06-11 18:47:27.195374
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3
    loose_version = LooseVersion('1.0.1-beta.2+custom.build.timestamp')
    if PY3:
        semver = SemanticVersion.from_loose_version(loose_version)
        assert semver.major == 1, "Major version should be 1"
        assert semver.minor == 0, "Minor version should be 0"
        assert semver.patch == 1, "Patch version should be 1"
        assert semver.prerelease[0] == 'beta', "Prerelease version should be 'beta'"
        assert semver.prerelease[1] == 2, "Prerelease version should be 2"
        assert semver.buildmetadata[0] == 'custom', "Build metadata version should be 'custom'"
        assert semver.buildmetadata

# Generated at 2022-06-11 18:47:33.650734
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0+foo.bar")) == SemanticVersion("1.0.0+foo.bar")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-alpha+foo.bar")) == SemanticVersion("1.0.0-alpha+foo.bar")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0-alpha.1+foo.bar")) == SemanticVersion("1.0.0-alpha.1+foo.bar")
    assert SemanticVersion

# Generated at 2022-06-11 18:47:45.022048
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # test case1
    v1 = LooseVersion('1.0')
    v2 = SemanticVersion.from_loose_version(v1)
    assert str(v2) == '1.0.0'

    # test case2
    v1 = LooseVersion('1.0.0.0')
    v2 = SemanticVersion.from_loose_version(v1)
    assert str(v2) == '1.0.0'

    # test case3
    v1 = LooseVersion('1.0.0')
    v2 = SemanticVersion.from_loose_version(v1)
    assert str(v2) == '1.0.0'

    # test case4
    v1 = LooseVersion('1.0.0.0.0')
    v2 = Semantic

# Generated at 2022-06-11 18:47:57.944866
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Initialization of the LooseVersion object
    vstring = '1.0.0-alpha.12+build.11'
    loose_version = LooseVersion(vstring)
    # The method converts LooseVersion object to SemanticVersion object
    semver = SemanticVersion.from_loose_version(loose_version)
    # The converted version number is correct
    print('[DEBUG] semver: {}'.format(semver))
    assert semver == SemanticVersion(vstring)
    # It raises ValueError exception if the argument is not LooseVersion object
    try:
        # The method does not accept integer argument
        semver = SemanticVersion.from_loose_version(12345)
        assert False, 'ERROR: should not be executed'
    except ValueError:
        pass
    # LooseVersion must contain numeric

# Generated at 2022-06-11 18:48:22.753835
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a valid LooseVersion instance
    try:
        from_loose_version = SemanticVersion.from_loose_version(LooseVersion('1.0.1'))
    except ValueError:
        assert False, "from_loose_version method of class SemanticVersion did not handle valid input"
    assert from_loose_version.vstring == "1.0.1", "from_loose_version method of class SemanticVersion did not handle valid input"

    # Test with a valid LooseVersion instance but with extra characters after major.minor.patch

# Generated at 2022-06-11 18:48:34.978760
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    loose_version = LooseVersion('5.0')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    expected = SemanticVersion('5.0.0')
    assert semantic_version == expected

    loose_version = LooseVersion('2')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    expected = SemanticVersion('2.0.0')
    assert semantic_version == expected

    loose_version = LooseVersion('2.8')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    expected = SemanticVersion('2.8.0')
    assert semantic_version == expected

    loose_version = LooseVersion('2.8.1')
    semantic_version = SemanticVersion.from_

# Generated at 2022-06-11 18:48:42.224468
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Note: the method only works with LooseVersion instances that
    # contain a version that is exclusively comprised of int values.
    # It also works with the non-core version information
    # (i.e. -rc, -alpha, +build1, etc.)
    loose_version_string = "1.2.3"
    loose_version_list = [1, 2, 3]
    loose_version_str_list = ["1", "2", "3"]
    loose_version_int_list = [1, 2, 3]
    loose_version_string_extra = "1.2.3-rc"
    loose_version_list_extra = [1, 2, 3, "-rc"]
    loose_version_str_list_extra = ["1", "2", "3", "-rc"]
    loose_version_int_list

# Generated at 2022-06-11 18:48:55.579961
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test case 1
    loose_version = LooseVersion('v3.3.0-beta.10')
    expected_semantic_version = SemanticVersion('3.3.0-beta.10')
    assert SemanticVersion.from_loose_version(loose_version) == expected_semantic_version

    # Test case 2
    loose_version = LooseVersion('v3.5.5-beta.10+build.20200525')
    expected_semantic_version = SemanticVersion('3.5.5-beta.10+build.20200525')
    assert SemanticVersion.from_loose_version(loose_version) == expected_semantic_version

    # Test case 3
    loose_version = LooseVersion('v4.4.4')

# Generated at 2022-06-11 18:49:03.799657
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:49:11.293253
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("2019.7.0-dev0")
    assert SemanticVersion.from_loose_version(loose_version) == '2019.7.0-dev0'

    loose_version = LooseVersion("2019.10.0-dev")
    assert SemanticVersion.from_loose_version(loose_version) == '2019.10.0-dev'

    loose_version = LooseVersion("2019.7.0")
    assert SemanticVersion.from_loose_version(loose_version) == '2019.7.0'

# Generated at 2022-06-11 18:49:21.702955
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4')) == SemanticVersion('1.2.3+4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5+6')) == SemanticVersion('1.2.3-4.5+6')

# Generated at 2022-06-11 18:49:34.167189
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0')).major == 0
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.0')).core == (0, 0, 0)
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')).core == (1, 2, 3)
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.dev.4')).core == (1, 2, 3)
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.4.post1.dev')).core == (1, 2, 4)
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.4.post1.dev')).pre

# Generated at 2022-06-11 18:49:46.259740
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5.6')) == SemanticVersion('1.2.3-4.5.6')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4.5.6')) == SemanticVersion('1.2.3+4.5.6')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4.5.6+7.8.9')) == SemanticVersion('1.2.3-4.5.6+7.8.9')

# Generated at 2022-06-11 18:49:53.191110
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    inputs = [
        '2.2.25',
        '2.2.25.1',
        '2.2.25-1',
        '2.2.25-1.1',
    ]
    for input_value in inputs:
        loose = LooseVersion(input_value)
        SemanticVersion.from_loose_version(loose)



# Generated at 2022-06-11 18:50:29.090008
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.0.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1.0")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("1")) == SemanticVersion("1.0.0")
    assert SemanticVersion.from_loose_version(LooseVersion("0.2.0")) == SemanticVersion("0.2.0")
    assert SemanticVersion.from_loose_version(LooseVersion("0.2")) == SemanticVersion("0.2.0")

# Generated at 2022-06-11 18:50:41.341060
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version_list = [
        LooseVersion('0'),
        LooseVersion('1.2'),
        LooseVersion('1.2.3'),
        LooseVersion('1.2.3.4'),
        LooseVersion('1.2-a'),
        LooseVersion('1.2.3-a'),
        LooseVersion('1.2.3-a.b'),
        LooseVersion('1.2.3-a.b.c'),
        LooseVersion('1.2+a'),
        LooseVersion('1.2.3+a'),
        LooseVersion('1.2.3+a.b'),
        LooseVersion('1.2.3+a.b.c'),
    ]

# Generated at 2022-06-11 18:50:48.635282
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.6.3.dev1')) == SemanticVersion('0.6.3-dev1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.6.3.dev1')) != SemanticVersion('0.6.3.dev2')



# Generated at 2022-06-11 18:50:59.345722
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    from ansible.module_utils.six import PY2

    # Test correct object constructor
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("1.0.0")), SemanticVersion)

    # ASSUMPTION: LooseVersion always returns a tuple of ints from LooseVersion.version
    # This may be an incorrect assumption, but it is the only way to make this work
    # on both py2 and py3.

    # Test correct version with no extra
    v = LooseVersion("1.0.0")
    assert SemanticVersion.from_loose_version(v).vstring == "1.0.0"

    # Test odd length version with no extra
    v = LooseVersion("1.0")

# Generated at 2022-06-11 18:51:09.948176
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1')) == SemanticVersion('0.0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1-dev')) == SemanticVersion('0.0.1-dev')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1+build.metadata')) == SemanticVersion('0.0.1+build.metadata')
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1-dev+build.metadata')) == SemanticVersion('0.0.1-dev+build.metadata')

# Generated at 2022-06-11 18:51:21.350788
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')).vstring == '1.0.0'
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1')).vstring == '0.0.1'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2a3')).vstring == '1.2.0-a3'
    assert SemanticVersion.from_loose_version(LooseVersion('1.2a3.4')).vstring == '1.2.0-a3.4'
    assert SemanticVersion.from_loose_version(LooseVersion('0.0.1.dev')).vstring == '0.0.1-dev'
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-11 18:51:28.931453
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:51:36.151841
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test basic functionality
    loose_version = LooseVersion("2.0.0")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '2.0.0'

    # Test version with pre-release
    loose_version = LooseVersion("2.0.0-pre")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '2.0.0-pre'
    assert semantic_version.is_prerelease is True

    # Test version with build metadata
    loose_version = LooseVersion("2.0.0+build")
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == '2.0.0+build'

# Generated at 2022-06-11 18:51:42.598805
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import ansible.module_utils.semver

    vstring = '9.9.9.9-99.99'
    loose_version = ansible.module_utils.semver.LooseVersion(vstring)
    semantic_version = ansible.module_utils.semver.SemanticVersion.from_loose_version(loose_version)
    assert semantic_version == ansible.module_utils.semver.SemanticVersion(vstring)

# Generated at 2022-06-11 18:51:48.344530
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test success
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    # Test failure
    try:
        SemanticVersion.from_loose_version('1.2.3')
        assert False
    except ValueError:
        assert True
