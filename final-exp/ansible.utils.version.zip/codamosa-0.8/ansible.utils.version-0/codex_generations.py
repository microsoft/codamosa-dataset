

# Generated at 2022-06-11 18:42:29.919844
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    assert not SemanticVersion('1.2.3')
    assert SemanticVersion('1.2.3') == '1.2.3'
    assert SemanticVersion('1.2.3').major == 1
    assert SemanticVersion('1.2.3').minor == 2
    assert SemanticVersion('1.2.3').patch == 3
    assert not SemanticVersion('1.2.3').prerelease
    assert not SemanticVersion('1.2.3').buildmetadata
    assert SemanticVersion('1.2.3+4.5.6').buildmetadata == ('4', '5', '6')
    assert SemanticVersion('1.2.3-4.5.6').prerelease == ('4', '5', '6')

# Generated at 2022-06-11 18:42:40.735037
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('b') <= _Alpha('c')
    
    assert _Alpha('a') <= 'a'
    assert _Alpha('a') <= 'b'
    assert _Alpha('b') <= 'c'

    assert not _Alpha('a') <= _Alpha('A')
    assert not _Alpha('a') <= _Alpha('Z')
    assert not _Alpha('z') <= _Alpha('a')

    assert not _Alpha('a') <= 'A'
    assert not _Alpha('a') <= 'Z'
    assert not _Alpha('z') <= 'a'


# Generated at 2022-06-11 18:42:50.398467
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.3.4-alpha4+sha.7d865e')
    assert str(SemanticVersion.from_loose_version(loose_version)) == '0.3.4-alpha4+sha.7d865e'
    assert str(LooseVersion('0.3')) == '0.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('0.3'))) == '0.3.0'
    assert str(LooseVersion('0.3-alpha')) == '0.3-alpha'
    assert str(SemanticVersion.from_loose_version(LooseVersion('0.3-alpha'))) == '0.3.0-alpha'


# Generated at 2022-06-11 18:43:01.966136
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """This method returns a SemanticVersion instance.

    The input is a LooseVersion.
    This method is designed to take a LooseVersion
    and attempt to construct a SemanticVersion from it.

    This is useful where you want to do simple version math
    without requiring users to provide a compliant semver.
    """


# Generated at 2022-06-11 18:43:12.986525
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert not 'a' < _Alpha('b')
    assert 'a' <= _Alpha('b')
    assert not 'b' <= _Alpha('a')

    assert _Alpha('a') < _Alpha('b')
    assert not _Alpha('b') < _Alpha('a')

    assert not _Alpha('b') <= _Alpha('b')
    assert _Alpha('a') <= _Alpha('a')

    assert not _Alpha('b') < _Alpha('b')
    assert not _Alpha('a') < _Alpha('a')

    assert 'a' < _Alpha('b')
    assert _Alpha('a') < 'b'

    assert not 'b' < 'a'
    assert not _Alpha('b') < _Alpha('a')

    assert not 'b' <= 'a'

# Generated at 2022-06-11 18:43:21.721057
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for a good value
    loose_version = LooseVersion("1.0.0b2")
    # Test for an error
    try:
        SemanticVersion.from_loose_version(loose_version)
        assert True
    except:
        assert False
    # Test with a bad value
    try:
        bad_version = "1.0.0b2"
        SemanticVersion.from_loose_version(bad_version)
        assert False
    except:
        assert True


# Generated at 2022-06-11 18:43:26.594406
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')

    assert (a <= b) is True
    assert (a <= c) is True
    assert (a >= b) is False
    assert (a >= c) is True


# Generated at 2022-06-11 18:43:34.348799
# Unit test for method __lt__ of class _Numeric
def test__Numeric___lt__():
    assert (_Numeric(0) < _Numeric(1)) is True
    assert (_Numeric(0) < _Numeric(0)) is False
    assert (_Numeric(0) < _Numeric(0.0)) is False
    assert (_Numeric(0) < _Numeric(1.0)) is True
    assert (_Numeric(0) < _Numeric('1')) is True
    assert (_Numeric(0) < _Alpha('1')) is True
    assert (_Numeric(0) < _Alpha('0')) is False

if __name__ == '__main__':
    test__Numeric___lt__()

# Generated at 2022-06-11 18:43:42.967507
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # test
    v1 = SemanticVersion()

    for vstring in ('v1.2.3', '1.2.3', '1.2.3-prerelease', '1.2.3-prerelease.0',
                    '1.2.3-prerelease.0.0', '1.2.3-prerelease.2.0', '1.2.3+build.metadata.1',
                    '1.2.3+build.metadata.1.0'):
        v = SemanticVersion(vstring)
        v1.parse(vstring)
        assert v.vstring == v1.vstring == vstring
    # Negative test

# Generated at 2022-06-11 18:43:54.767169
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    numeric = _Numeric(2)
    numeric_1 = _Numeric(1)
    numeric_2 = _Numeric(2)
    numeric_3 = _Numeric(3)
    alpha = _Alpha('a')
    assert numeric_1 <= numeric
    assert numeric_2 <= numeric
    assert numeric_3 <= numeric
    assert numeric_1 <= numeric_1
    assert numeric_2 <= numeric_2
    assert numeric_3 <= numeric_3
    assert numeric_1 <= alpha
    assert numeric_2 <= alpha
    assert numeric_3 <= alpha
    assert not numeric <= numeric_1
    assert numeric <= numeric_2
    assert not numeric <= numeric_3
    assert not numeric <= alpha


# Generated at 2022-06-11 18:44:10.330353
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    print

# Generated at 2022-06-11 18:44:21.636196
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('1.3.3')
    result = SemanticVersion.from_loose_version(loose_version).vstring
    assert result == '1.3.3', 'SemanticVersion ignores a preexisting + modifier'

    loose_version = LooseVersion('1.3.4-4')
    result = SemanticVersion.from_loose_version(loose_version).vstring
    assert result == '1.3.4', 'SemanticVersion ignores a preexisting - modifier'

    loose_version = LooseVersion('1.3.4+4')
    result = SemanticVersion.from_loose_version(loose_version).vstring
    assert result == '1.3.4', 'SemanticVersion ignores a preexisting - modifier'


# Generated at 2022-06-11 18:44:30.751673
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
	
	import datetime
	
	start_time = datetime.datetime.now()

	import ansible.module_utils.versions
	from ansible.module_utils.versions import LooseVersion
	
	print('Unit test started at ', start_time)

	assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-rc.1+exp.sha.5114f85')).vstring == '1.0.0-rc.1+exp.sha.5114f85'

	assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-rc.1')).vstring == '1.0.0-rc.1'


# Generated at 2022-06-11 18:44:36.664592
# Unit test for method __le__ of class _Numeric
def test__Numeric___le__():
    assert _Numeric(1) <= _Numeric(1)
    assert _Numeric(1) <= _Numeric(2)
    assert not _Numeric(2) <= _Numeric(1)

    assert not _Numeric(1) <= _Alpha('a')
    assert _Numeric(2) <= _Alpha('a')
    assert not _Alpha('a') <= _Numeric(1)
    assert _Alpha('a') <= _Numeric(2)


# Generated at 2022-06-11 18:44:40.191943
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert not _Alpha('a') <= _Alpha('b')  # ascii 'a' < ascii 'b'
    assert _Alpha('b') <= _Alpha('b')
    assert _Alpha('b') <= _Alpha('c')

    assert _Alpha('b') <= 'b'
    assert not _Alpha('a') <= 'b'
    assert _Alpha('b') <= 'c'


# Generated at 2022-06-11 18:44:50.768158
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert not SemanticVersion('2.0.0') < SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('2.0.0') > SemanticVersion('1.0.0-alpha')
    assert SemanticVersion('1.0.0-alpha.1') < SemanticVersion('1.0.0-alpha.beta')
    assert not SemanticVersion('1.0.0-alpha.1') > SemanticVersion('1.0.0-alpha.beta')
    assert SemanticVersion('1.0.0-alpha.beta') < SemanticVersion('1.0.0-beta')
    assert not SemanticVersion('1.0.0-alpha.beta') > SemanticVersion('1.0.0-beta')
    assert SemanticVersion('1.0.0-beta.2') < SemanticVersion

# Generated at 2022-06-11 18:45:01.679768
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    s = '0.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion(s))) == s
    s = '0.0.0-0'
    assert str(SemanticVersion.from_loose_version(LooseVersion(s))) == s
    s = '0.0.0-0+0'
    assert str(SemanticVersion.from_loose_version(LooseVersion(s))) == s
    s = '0.0.0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion(s))) == s
    s = '0.0.0-0.0+0.0'
    assert str(SemanticVersion.from_loose_version(LooseVersion(s))) == s

# Generated at 2022-06-11 18:45:11.683455
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.0.0')
    assert str(SemanticVersion.from_loose_version(loose_version)) == '0.0.0'

    loose_version = LooseVersion('0.0.1')
    assert str(SemanticVersion.from_loose_version(loose_version)) == '0.0.1'

    loose_version = LooseVersion('0.1.0')
    assert str(SemanticVersion.from_loose_version(loose_version)) == '0.1.0'

    loose_version = LooseVersion('0.1.1')
    assert str(SemanticVersion.from_loose_version(loose_version)) == '0.1.1'

    # Should work for a LooseVersion with a prerelease version
    loose_version

# Generated at 2022-06-11 18:45:20.050402
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    This function is used to test function from_loose_version of class SemanticVersion
    :return:
    """
    try:
        assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
        assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    except ValueError:
        print("Testcase test_SemanticVersion_from_loose_version failed")



# Generated at 2022-06-11 18:45:33.467306
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    vstring = '1.0.0-alpha'
    sv = SemanticVersion()
    sv.parse(vstring)

    assert isinstance(sv, SemanticVersion)
    assert hasattr(sv, 'vstring')
    assert hasattr(sv, 'major')
    assert hasattr(sv, 'minor')
    assert hasattr(sv, 'patch')
    assert hasattr(sv, 'prerelease')
    assert hasattr(sv, 'buildmetadata')

    assert sv.vstring == vstring
    assert sv.major == 1
    assert sv.minor == 0
    assert sv.patch == 0
    assert sv.prerelease == (_Alpha('alpha'),)
    assert sv.buildmetadata == ()

    # These should raise ValueError

# Generated at 2022-06-11 18:45:59.560655
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Tests with the same expected output
    loose_version = LooseVersion('1.0.0')
    semantic_version = SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(loose_version) == semantic_version

    loose_version = LooseVersion('1.0.0-alpha')
    semantic_version = SemanticVersion('1.0.0-alpha')
    assert SemanticVersion.from_loose_version(loose_version) == semantic_version

    loose_version = LooseVersion('1.0.0+build.metadata')
    semantic_version = SemanticVersion('1.0.0+build.metadata')
    assert SemanticVersion.from_loose_version(loose_version) == semantic_version


# Generated at 2022-06-11 18:46:10.957481
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test method from_loose_version of class SemanticVersion:
        - take a LooseVersion and attempt to construct a SemanticVersion from it
        - this is useful where you want to do simple version math without requiring users to provide a compliant semver
    """

    loose_version = LooseVersion("6.9.0")
    semver = SemanticVersion(loose_version)
    assert semver == "6.9.0", "Failed to build a SemanticVersion compatible object from a LooseVersion object"
    loose_version = LooseVersion("7.10.1")
    semver = SemanticVersion(loose_version)
    assert semver == "7.10.1", "Failed to build a SemanticVersion compatible object from a LooseVersion object"

# Generated at 2022-06-11 18:46:18.766330
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.version import SemanticVersion

    t = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert t == '1.2.3'

    t = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4-5'))
    assert t == '1.2.3-5'

    t = SemanticVersion.from_loose_version(LooseVersion('1.2.3-5.6'))
    assert t == '1.2.3-5.6'

    t = SemanticVersion.from_loose_version(LooseVersion('1.2.3-5.6-7'))
    assert t == '1.2.3-5.6-7'

    t = Sem

# Generated at 2022-06-11 18:46:28.970195
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:46:42.484457
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1.0.0a') == SemanticVersion('1.0.0-a')
    assert SemanticVersion.from_loose_version('1.0.0b') == SemanticVersion('1.0.0-b')
    assert SemanticVersion.from_loose_version('1.0.0-c') == SemanticVersion('1.0.0-c')
    assert SemanticVersion.from_loose_version('1.0.0pre') == SemanticVersion('1.0.0-pre')
    assert SemanticVersion.from_loose_version('1.0.0-pre') == SemanticVersion('1.0.0-pre')

# Generated at 2022-06-11 18:46:53.152800
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    tvstrings = [
        '1.2.3',
        '1.2.3b1',
        '1.2.3.dev1',
        '1.2.3.dev',
        '1.2.3.post1',
    ]
    for vstring in tvstrings:
        loose_version = LooseVersion(vstring)
        semver = SemanticVersion.from_loose_version(loose_version)
        assert isinstance(semver, SemanticVersion)
        assert semver.vstring == vstring
        assert semver.core == (1, 2, 3)


# Generated at 2022-06-11 18:47:05.441486
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3

    versions = {
        '1.2.3': SemanticVersion('1.2.3'),
        '1.2.3a': SemanticVersion('1.2.3-a'),
        '1.2.3-a.b': SemanticVersion('1.2.3-a.b'),
        '1.2.3-a.b.c0': SemanticVersion('1.2.3-a.b.c.0'),
        '1.2.3a+foo.bar': SemanticVersion('1.2.3-a+foo.bar'),
        '1.2.3a.b.c+foo.bar': SemanticVersion('1.2.3-a.b.c+foo.bar'),
    }


# Generated at 2022-06-11 18:47:15.999148
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit tests for SemanticVersion.from_loose_version()"""

    try:
        from ansible.module_utils.compat.version import LooseVersion
    except Exception as e:
        raise Exception("Failed to import LooseVersion: {0}".format(e))

    try:
        SemanticVersion.from_loose_version(LooseVersion("2.7.0"))
    except Exception as e:
        raise Exception("Failed to create SemanticVersion: {0}".format(e))

    try:
        SemanticVersion.from_loose_version(LooseVersion("2"))
    except Exception as e:
        raise Exception("Failed to create SemanticVersion: {0}".format(e))


# Generated at 2022-06-11 18:47:24.781553
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    cases = (
        ('1.0.0', '1.0.0'),
        ('1.0.0+unstable', '1.0.0'),
        ('1.0.0-alpha.1+unstable', '1.0.0-alpha.1'),
        ('1.0.0a1', '1.0.0-a1'),
    )

    for expected, vstring in cases:
        v = SemanticVersion.from_loose_version(LooseVersion(vstring))
        assert v == SemanticVersion(expected)

# Generated at 2022-06-11 18:47:32.960377
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    old_version = LooseVersion('4.10.0.dev8009a')
    new_version = SemanticVersion.from_loose_version(old_version)
    assert new_version == old_version
    assert new_version.is_prerelease
    assert not new_version.is_stable

    old_version = LooseVersion('4.10.0a1')
    new_version = SemanticVersion.from_loose_version(old_version)
    assert new_version == old_version
    assert new_version.is_prerelease
    assert not new_version.is_stable

    old_version = LooseVersion('4.10.0')
    new_version = SemanticVersion.from_loose_version(old_version)
    assert new_version == old_version

# Generated at 2022-06-11 18:47:46.568636
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:47:58.636769
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test success
    # Test when vstring does not contain prerelease or buildmetadata
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2')) == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')

    # Test when vstring contains prerelease
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')

# Generated at 2022-06-11 18:48:08.791110
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+foo.bar-baz')) == SemanticVersion('1.0.0+foo.bar-baz')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')

# Generated at 2022-06-11 18:48:20.678811
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a normal version
    v1 = LooseVersion('1.2.3')
    v2 = SemanticVersion.from_loose_version(v1)
    assert v2 == '1.2.3'

    # Test with a prerelease version
    v1 = LooseVersion('1.2.3-pre')
    v2 = SemanticVersion.from_loose_version(v1)
    assert v2 == '1.2.3-pre'

    # Test with a build metadata
    v1 = LooseVersion('1.2.3+build')
    v2 = SemanticVersion.from_loose_version(v1)
    assert v2 == '1.2.3+build'

    # Test with a prerelease version and build metadata

# Generated at 2022-06-11 18:48:27.797776
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # when
    sv = SemanticVersion.from_loose_version(LooseVersion('1.0.0+abc'))

    # then
    assert sv.major == 1
    assert sv.minor == 0
    assert sv.patch == 0
    assert sv.prerelease == tuple()
    assert sv.buildmetadata == ('abc', )

    # given
    sv_other = SemanticVersion('1.0.1')

    # when
    sv = SemanticVersion.from_loose_version(LooseVersion('1.0.0+abc'))

    # then
    assert sv == sv_other
    assert sv.major == 1
    assert sv.minor == 0
    assert sv.patch == 0
    assert sv.prerelease == tuple()
    assert sv.buildmetadata == ('abc', )

# Generated at 2022-06-11 18:48:34.116889
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for exact version
    vstring = '0.9.0'
    sversion = SemanticVersion(vstring)
    lversion = LooseVersion(vstring)
    sversion_test = SemanticVersion.from_loose_version(lversion)
    assert sversion == sversion_test

    # Test for multiple dot version
    vstring = '0.9.0.5'
    sversion = SemanticVersion(vstring)
    lversion = LooseVersion(vstring)
    sversion_test = SemanticVersion.from_loose_version(lversion)
    assert sversion == sversion_test

    # Test for alpha version
    vstring = '0.9.0.5pre1'
    sversion = SemanticVersion(vstring)
    lversion = LooseVersion(vstring)
   

# Generated at 2022-06-11 18:48:41.859307
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # New with Py3.4 is the releaseversion function which does things
    # in a new and different way.
    #
    # We will use this to test from_loose_version()
    from distutils.version import StrictVersion
    from ansible.module_utils.compat.version import LooseVersion


# Generated at 2022-06-11 18:48:49.286193
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:59.518301
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    import os
    import warnings

    try:
        path = os.path.dirname(os.path.realpath(__file__))
        if sys.version_info[0] == 3:
            result = exec(open(os.path.join(path, 'unit/unit_tests_SemanticVersion_from_loose_version.py')).read(),globals())
        else:
            result = execfile(os.path.join(path, 'unit/unit_tests_SemanticVersion_from_loose_version.py'),globals())
    except Exception as err:
        raise err

    for key, value in result.items():
        globals()[key] = value

# Generated at 2022-06-11 18:49:10.676300
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2

    version = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    if PY2:
        assert str(version) == "1.0.0"
    else:
        assert text_type(version) == "1.0.0"

    version = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    if PY2:
        assert str(version) == "1.2.3"
    else:
        assert text_type(version) == "1.2.3"

    version = SemanticVersion.from_loose_version(LooseVersion('1.2'))
    if PY2:
        assert str(version) == "1.2.0"


# Generated at 2022-06-11 18:49:25.234238
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    import unittest

    class TestSemanticVersionFromLooseVersion(unittest.TestCase):
        # Tests for SemanticVersion.from_loose_version
        def setUp(self):
            self.oldversion = sys.version_info[:3]


# Generated at 2022-06-11 18:49:36.087862
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # test invalid inputs
    try:
        SemanticVersion.from_loose_version("some_invalid_input")
        assert False
    except ValueError:
        pass

    # test valid inputs
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("1.0.0")), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("1.2.3")), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("1.2.3-beta.1")), SemanticVersion)
    assert isinstance(SemanticVersion.from_loose_version(LooseVersion("1.2.3+alpha.1")), SemanticVersion)

# Generated at 2022-06-11 18:49:41.489204
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    Loose = LooseVersion('v2.0.9-1-g302a7c1')
    sv = SemanticVersion.from_loose_version(Loose)
    assert sv == '2.0.9-1-g302a7c1'

# Generated at 2022-06-11 18:49:49.885991
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Success case
    loose_version_0 = LooseVersion("v1.2.3")
    assert "v1.2.3" == str(SemanticVersion.from_loose_version(loose_version_0))

    # Failure case
    with pytest.raises(ValueError) as e_info:
        SemanticVersion.from_loose_version("v1.2.3")
    assert "invalid semantic version 'v1.2.3'" == str(e_info.value)

    # Failure case
    with pytest.raises(ValueError) as e_info:
        SemanticVersion.from_loose_version("v1.2.3-alpha.1.2")

# Generated at 2022-06-11 18:50:01.428784
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:50:14.451117
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_components = (
        (1, 0, 0),
        (1, 0, 0, 1),
        (1, 0, 0, 1, 'alpha'),
        (1, 0, 0, 1, 'alpha', 1),
        (1, 0, 0, 1, 'alpha', 1, 'alpha'),
        (1, 0, 0, 1, 'alpha', 1, 'alpha', 1),
    )

    loose_versions = {}
    for version in loose_version_components:
        # version is a tuple
        version_component_list = list(version)

        # convert version_component_list to a list of str

# Generated at 2022-06-11 18:50:26.294592
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves.urllib.parse import urlsplit
    from ansible.module_utils.six.moves.urllib.error import HTTPError
    from ansible.module_utils.urls import open_url
    from ansible.module_utils.distribution import Distribution
    from ansible.module_utils._text import to_native
    import sys

    def check_distribution_semver(url, distro_name, version, version_prefix=''):
        # Fetch a list of all versions of a given software package
        try:
            response = open_url(url)
        except HTTPError as e:
            msg = "Failed to fetch %s list: %s" % (distro_name, to_native(e))

# Generated at 2022-06-11 18:50:39.287247
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3'))) == '1.2.3'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha'))) == '1.2.3-alpha'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.beta'))) == '1.2.3-alpha.beta'
    assert str(SemanticVersion.from_loose_version(LooseVersion('1.2.3+build4'))) == '1.2.3+build4'

# Generated at 2022-06-11 18:50:53.054174
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """This method is designed to take a ``LooseVersion``
    and attempt to construct a ``SemanticVersion`` from it

    This is useful where you want to do simple version math
    without requiring users to provide a compliant semver.
    """

    # check that the conversion of a LooseVersion into a SemanticVersion works
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')

    # check that the conversion of a LooseVersion into a SemanticVersion works
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-abc')) == SemanticVersion('1.0.0-abc')

    # check that the conversion of a LooseVersion into a SemanticVersion works
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-11 18:51:01.781196
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Should accept a LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+build.1')) == SemanticVersion('1.2.3+build.1')

    # Should ignore extra release data

# Generated at 2022-06-11 18:51:17.575951
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta'))
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-beta+build'))
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+build'))

# Unit tests for class SemanticVersion

# Generated at 2022-06-11 18:51:29.566365
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # examples that should work fine
    try:
        SemanticVersion.from_loose_version('1.1.1')
        SemanticVersion.from_loose_version('1.1.1-alpha')
        SemanticVersion.from_loose_version('1.1.1-1')
        SemanticVersion.from_loose_version('1.1.1-1.foo')
        SemanticVersion.from_loose_version('1.1.1-foo.bar')
        SemanticVersion.from_loose_version('1.1.1+foo')
        SemanticVersion.from_loose_version('1.1.1+foo.bar')
    except ValueError:
        assert False

    # examples that should raise ValueError

# Generated at 2022-06-11 18:51:36.613943
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:51:47.800901
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Make sure we can turn a LooseVersion into a SemanticVersion
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-pre')) == SemanticVersion('1.0.0-pre')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0+build')) == SemanticVersion('1.0.0+build')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0-pre+build')) == SemanticVersion('1.0.0-pre+build')

    # Special case, if the LooseVersion is a integer, convert to string
    assert Semantic

# Generated at 2022-06-11 18:51:55.618830
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import zip

# Generated at 2022-06-11 18:52:00.292929
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Create a SemanticVersion object from a LooseVersion object"""
    loose_version = LooseVersion('2.1.a')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert(semver == '2.1.0')

    loose_version = LooseVersion('2.1.0')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert(semver == '2.1.0')

    loose_version = LooseVersion('2.1.0-alpha3')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert(semver == '2.1.0-alpha3')

    loose_version = LooseVersion('2.1.0+metadata')
    semver = Semantic