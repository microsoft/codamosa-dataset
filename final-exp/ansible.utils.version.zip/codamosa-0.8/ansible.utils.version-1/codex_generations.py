

# Generated at 2022-06-11 18:42:26.937659
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.distro import LooseVersion
    from ansible.module_utils.distro import SemanticVersion

    for version in ['1.9.4-0.4.alpha', '1.0.0+4711']:
        loose_version = LooseVersion(version)
        semantic_version = SemanticVersion.from_loose_version(loose_version)
        assert semantic_version == version

# Generated at 2022-06-11 18:42:36.006378
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:42:47.499384
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = SemanticVersion.from_loose_version('5.5.5')
    assert v == SemanticVersion('5.5.5')

    v = SemanticVersion.from_loose_version('5.5.5+abc')
    assert v == SemanticVersion('5.5.5+abc')

    v = SemanticVersion.from_loose_version('5.5.5-xyz')
    assert v == SemanticVersion('5.5.5-xyz')

    v = SemanticVersion.from_loose_version('5.5.5-xyz+123')
    assert v == SemanticVersion('5.5.5-xyz+123')

    v = SemanticVersion.from_loose_version('0.5.5')
    assert v == SemanticVersion('0.5.5')

# Generated at 2022-06-11 18:42:59.453082
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # LooseVersion object with an invalid number of parts
    loose_version1 = LooseVersion('1')
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(loose_version1)
    # LooseVersion object with a non integer number in its version
    loose_version2 = LooseVersion('1.0.0a')
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(loose_version2)
    # LooseVersion object with a valid version
    loose_version3 = LooseVersion('1.0.0')
    # Conversion of LooseVersion to Semantic Version
    semantic_version = SemanticVersion.from_loose_version(loose_version3)
    # Testing Semantic Version

# Generated at 2022-06-11 18:43:07.599197
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Import module utils_version
    module = __import__('ansible.module_utils.version', fromlist=['utils_version'])
    # Create an object that represents a version
    v = module.utils_version.LooseVersion('1.12.0')
    # Create class object SemanticVersion from class LooseVersion
    s = module.utils_version.SemanticVersion.from_loose_version(loose_version=v)
    # Check that the object was created successfully
    assert isinstance(s, module.utils_version.SemanticVersion)
    # Check that the object was created successfully
    assert isinstance(s, module.utils_version.Version)
    # Check that the object was created successfully
    assert isinstance(s, module.utils_version.SemVerBase)
    # Check that the object was created successfully


# Generated at 2022-06-11 18:43:11.712768
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha("0")
    b = _Alpha("1")
    c = _Alpha("a")
    d = _Alpha("b")
    assert a < b
    assert a <= b
    assert a <= a
    assert c < d
    assert c <= d
    assert c <= c


# Generated at 2022-06-11 18:43:24.021784
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def test(expected, lv):
        result = SemanticVersion.from_loose_version(lv)
        assert result == expected
    lv = LooseVersion('1.2.3')
    test('1.2.3', lv)
    lv = LooseVersion('1.0.10')
    test('1.0.10', lv)
    lv = LooseVersion('1.11.0')
    test('1.11.0', lv)
    lv = LooseVersion('1.2.3-alpha.1.2+meta.data')
    test('1.2.3-alpha.1.2+meta.data', lv)
    lv = LooseVersion('1.2.3-alpha.1+meta.data')

# Generated at 2022-06-11 18:43:32.335773
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test for a simple version
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    # Test for a version with more than 3 parts
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert v.major == 1
    assert v.minor == 2
    assert v.patch == 3
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    # Test for a version with non-integer parts
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha'))

# Generated at 2022-06-11 18:43:42.860379
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """ Testing SemanticVersion.from_loose_version function
    """
    from ansible.module_utils.compat.version import LooseVersion

    # Version LooseVersion is not a LooseVersion
    try:
        SemanticVersion.from_loose_version(Version('1.0.0'))
    except ValueError:
        pass
    else:
        raise AssertionError('ValueError not raised')

    # LooseVersion is a LooseVersion
    try:
        assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')).vstring == '1.0.0'
    except ValueError:
        raise AssertionError('Loose version with version, no prerelease nor buildmetadata, not parsed')

    # LooseVersion is a LooseVersion with build metadata

# Generated at 2022-06-11 18:43:55.825361
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    default = SemanticVersion()
    assert default.major == None and default.minor == None and default.patch == None and default.buildmetadata == () and default.prerelease == () and default.vstring == None, \
        (default.major, default.minor, default.patch, default.buildmetadata, default.prerelease, default.vstring)


# Generated at 2022-06-11 18:44:17.837093
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    alpha0 = _Alpha('a')
    alpha1 = _Alpha('b')
    alpha2 = _Alpha('10')
    alpha3 = _Alpha('11')
    assert (alpha0 <= alpha0)
    assert (alpha0 <= alpha1)
    assert (alpha0 <= alpha2)
    assert (alpha0 <= alpha3)
    assert (alpha1 <= alpha1)
    assert (alpha1 <= alpha2)
    assert (alpha1 <= alpha3)
    assert (alpha2 <= alpha2)
    assert (alpha2 <= alpha3)
    assert (alpha3 <= alpha3)
    return



# Generated at 2022-06-11 18:44:29.036706
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    '''Test that _Alpha.__le__ behaves correctly
    '''

    # Check that comparing an instance of _Alpha to a string
    # returns True if the specifier is less than the string
    alpha = _Alpha('a')
    assert alpha <= 'b'

    # Check that comparing an instance of _Alpha to a string
    # returns False if the specifier is not less than the string
    alpha = _Alpha('b')
    assert not alpha <= 'a'

    # Check that two _Alpha instances with different specifiers
    # are not equal
    alpha1 = _Alpha('a')
    alpha2 = _Alpha('b')
    assert not alpha1 <= alpha2

    # Check that two _Alpha instances with equal specifiers
    # are equal
    alpha1 = _Alpha('a')
    alpha2 = _Alpha('a')
    assert alpha

# Generated at 2022-06-11 18:44:35.351138
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    a = LooseVersion('1.2.3')
    b = SemanticVersion.from_loose_version(a)
    assert type(b) is SemanticVersion
    assert b.vstring == '1.2.3'
    assert b.major == 1
    assert b.minor == 2
    assert b.patch == 3
    assert b.prerelease is None
    assert b.buildmetadata is None



# Generated at 2022-06-11 18:44:48.841136
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('9.0.1')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '9.0.1'
    loose_version = LooseVersion('9.0.1-2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '9.0.1-2.3'
    loose_version = LooseVersion('9.0.1+2.3')
    semantic_version = SemanticVersion.from_loose_version(loose_version)
    assert semantic_version.vstring == '9.0.1+2.3'

# Generated at 2022-06-11 18:45:00.274638
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    print("Running test__Alpha___le__ ...")
    assert _Alpha("a") <= _Alpha("a")
    assert _Alpha("b") >= _Alpha("a")
    assert _Alpha("a") <= "a"
    assert _Alpha("b") >= "a"
    assert _Alpha("a") <= _Alpha("b")
    assert _Alpha("a") <= "b"
    assert _Alpha("a") <= _Numeric(1)
    assert _Alpha("a") >= _Numeric(0)
    assert _Alpha("a") == _Alpha("a")
    assert _Alpha("b") == "b"
    assert _Alpha("b") != "a"
    assert not _Alpha("b") < "b"
    assert not _Alpha("a") > "a"
    #assert _Numeric(1) <= _Alpha("a

# Generated at 2022-06-11 18:45:04.918921
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('foo') <= _Alpha('foo')
    assert _Alpha('foo') <= _Alpha('goo')
    assert not (_Alpha('goo') <= _Alpha('foo'))


# Generated at 2022-06-11 18:45:08.839326
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('alpha') <= _Alpha('alpha')
    assert _Alpha('alpha') <= _Alpha('beta')
    assert _Alpha('alpha') <= 'beta'
    assert _Alpha('alpha') <= _Numeric('2')
    assert not _Alpha('alpha') <= _Alpha('alpha')


# Generated at 2022-06-11 18:45:21.009297
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """Unit test that validates from_loose_version"""

# Generated at 2022-06-11 18:45:30.017559
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.0.0'))
    assert v1.major == 1
    assert v1.major == 1
    v2 = SemanticVersion.from_loose_version(LooseVersion('1.0.1'))
    assert v2.major == 1
    assert v2.major == 1


# Generated at 2022-06-11 18:45:36.594419
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha('a') <= _Alpha('a')
    assert _Alpha('a') <= _Alpha('b')
    assert _Alpha('b') > _Alpha('a')

    assert _Alpha('a') <= _Numeric(1)
    assert _Alpha('a') <= _Numeric(2)
    assert _Alpha('b') <= _Numeric(1)
    assert _Alpha('b') > _Numeric(2)


# Generated at 2022-06-11 18:45:51.749397
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    with pytest.raises(ValueError):
        # Must have vstring in LooseVersion
        SemanticVersion.from_loose_version(LooseVersion())
    with pytest.raises(ValueError):
        # Must have at least a major version
        SemanticVersion.from_loose_version(LooseVersion('0.0'))
    loose_version = LooseVersion('0.0.1+2.3-alpha.234')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert(semver.major == 0)
    assert(semver.minor == 0)
    assert(semver.patch == 1)
    assert(semver.prerelease == (_Alpha('alpha'), _Numeric(234)))

# Generated at 2022-06-11 18:45:59.342206
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    version = SemanticVersion.from_loose_version("12.0")
    assert version.major == 12
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    version = SemanticVersion.from_loose_version("12.0.0-alpha.1")
    assert version.major == 12
    assert version.minor == 0
    assert version.patch == 0
    assert version.prerelease == ("alpha", _Numeric(1))
    assert version.buildmetadata == ()

    version = SemanticVersion.from_loose_version("12.0.0-alpha.1+20181212.1")
    assert version.major == 12
    assert version.minor == 0
    assert version.patch == 0
    assert version.pre

# Generated at 2022-06-11 18:46:11.220824
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = LooseVersion('1.2.3')

    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.2.3')

    v = LooseVersion('1.2.3-rc1')

    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.2.3-rc1')

    v = LooseVersion('1.2.3-alpha.3')

    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.2.3-alpha.3')

    v = LooseVersion('1.2.3-3')

    assert SemanticVersion.from_loose_version(v) == SemanticVersion('1.2.3-3')


# Generated at 2022-06-11 18:46:13.061105
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("1") <= '1'
    assert _Alpha("1") <= _Numeric("1")
    assert _Alpha('a') <= _Alpha('z')


# Generated at 2022-06-11 18:46:25.131948
# Unit test for method __le__ of class _Alpha

# Generated at 2022-06-11 18:46:37.829950
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # test_SemanticVersion_from_loose_version: Test input type LooseVersion
    loose_version = LooseVersion('1.7.0')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert str(semver) == '1.7.0'

    # test_SemanticVersion_from_loose_version: Test input type Version
    version = Version('1.7.0')
    semver = SemanticVersion.from_loose_version(version)
    assert str(semver) == '1.7.0'

    # test_SemanticVersion_from_loose_version: Test input type tuple
    version = ('1', '7', '0')
    semver = SemanticVersion.from_loose_version(version)
    assert str(semver)

# Generated at 2022-06-11 18:46:46.607456
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def test(version):
        loose_version = LooseVersion(version)
        assert SemanticVersion.from_loose_version(loose_version) == SemanticVersion(version)

    test('1.0.0')
    test('1.0.0-1')
    test('1.0.0+1')
    test('1.0.0-1+1')
    test('1.9.9')
    test('1.9.9-1')
    test('1.9.9+1')
    test('1.9.9-1+1')

    test('1.0.0alpha')
    test('1.0.0alpha.1')
    test('1.0.0alpha1')
    test('1.0.0-alpha.1')

# Generated at 2022-06-11 18:46:52.397681
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Call method from_loose_version of class SemanticVersion
    v = SemanticVersion.from_loose_version('a.b.c.d-alpha123.456+b.c.d.e')
    assert v.major == 0
    assert v.minor == 0
    assert v.patch == 0
    assert len(v.prerelease) == 3
    assert v.prerelease[0] == 'alpha'
    assert v.prerelease[1] == 123
    assert v.prerelease[2] == 456
    assert len(v.buildmetadata) == 4
    assert v.buildmetadata[0] == 'b'
    assert v.buildmetadata[1] == 'c'
    assert v.buildmetadata[2] == 'd'
    assert v.buildmetadata[3] == 'e'
    # Call

# Generated at 2022-06-11 18:47:04.879951
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    expected = '1.0.0'
    loose_version = LooseVersion('1.0.0')
    sv = SemanticVersion.from_loose_version(loose_version)
    assert str(sv) == expected, '%s == %s' % (sv, expected)

    expected = '1.0.1'
    loose_version = LooseVersion('1.0.1')
    sv = SemanticVersion.from_loose_version(loose_version)
    assert str(sv) == expected, '%s == %s' % (sv, expected)

    expected = '2.0.0'
    loose_version = LooseVersion('2.0.0')
    sv = SemanticVersion.from_loose_version(loose_version)

# Generated at 2022-06-11 18:47:15.537073
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test default usage
    v1 = SemanticVersion.from_loose_version(LooseVersion("1.2.3"))
    assert str(v1) == "1.2.3"

    # Test default usage with different version
    v1 = SemanticVersion.from_loose_version(LooseVersion("2.3.4"))
    assert str(v1) == "2.3.4"

    # Test trying to convert non-looseversion
    try:
        v1 = SemanticVersion.from_loose_version(SemanticVersion("2.3.4"))
    except ValueError:
        pass
    else:
        assert False

    # Test trying to convert a LooseVersion with a non-numeric version part

# Generated at 2022-06-11 18:47:30.264881
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('abc')
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version(loose_version)

    loose_version = LooseVersion('1.2.3')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.2.3'

    loose_version = LooseVersion('1.2.3.post456.dev789')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.2.3'

    loose_version = LooseVersion('1.2.3.dev456.post789')
    assert SemanticVersion.from_loose_version(loose_version).vstring == '1.2.3'


# Generated at 2022-06-11 18:47:36.693750
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('1')
    val = a <= '0'
    assert val is False
    val = a <= '1'
    assert val is True
    val = a <= '2'
    assert val is True
    val = a <= _Alpha('1')
    assert val is True
    val = a <= _Alpha('2')
    assert val is True


# Generated at 2022-06-11 18:47:46.453998
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    print(text_type('Testing method __le__ of class _Alpha...'))
    if _Alpha('a') <= _Alpha('b'):
        print(text_type('Method __le__ of class _Alpha works as expected.'))
    else:
        print(text_type('Method __le__ of class _Alpha does not work as expected'))
    if _Alpha('a') <= 'b':
        print(text_type('Method __le__ of class _Alpha works as expected.'))
    else:
        print(text_type('Method __le__ of class _Alpha does not work as expected'))
    if _Alpha('a') <= _Numeric(1):
        print(text_type('Method __le__ of class _Alpha works as expected.'))

# Generated at 2022-06-11 18:47:58.638062
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('4.5.6.7')) == SemanticVersion('4.5.6')
    assert SemanticVersion.from_loose_version(LooseVersion('8.9.10.11.12.13')) == SemanticVersion('8.9.10')
    assert SemanticVersion.from_loose_version(LooseVersion('14.15.16.17-alpha')) == SemanticVersion('14.15.16-alpha')
    assert SemanticVersion

# Generated at 2022-06-11 18:48:08.791411
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:20.679872
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version('1.2.3-rc1') == SemanticVersion('1.2.3-rc1')
    assert SemanticVersion.from_loose_version('1.2.3+build42') == SemanticVersion('1.2.3+build42')
    assert SemanticVersion.from_loose_version('1.2.3-rc1+build42') == SemanticVersion('1.2.3-rc1+build42')
    assert SemanticVersion.from_loose_version('1.2.3.1') == SemanticVersion('1.2.3')

# Generated at 2022-06-11 18:48:27.970708
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    for version in (
        "1.0",
        "1.0.0",
        "1.0.0+1.2.3",
        "1.2.3-beta.1",
        "1.2.3-1.2.3",
        "1.2.3~1.2.3",
        "1.0.0.dev1",
        "1.0.0.post1",
    ):
        assert SemanticVersion.from_loose_version(LooseVersion(version)) == SemanticVersion(version)

# Generated at 2022-06-11 18:48:38.805744
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY2, PY3
    from ansible.module_utils.basic import AnsibleModule, json
    import sys
    import copy

    if PY3:
        module_args = {
            'version': '0.1.2.dev1',
            'version_match': "0.1.2",
            'version_match_py2': "0.1.2.0",
        }
    else:
        module_args = {
            'version': '0.1.2.dev1',
            'version_match': "0.1.2",
            'version_match_py2': "0.1.2.0",
        }


# Generated at 2022-06-11 18:48:48.100791
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('0.1.1')
    assert SemanticVersion('0.1.1') == SemanticVersion.from_loose_version(loose_version)
    loose_version = LooseVersion('0.1.1~dev4')
    assert SemanticVersion('0.1.1-dev4') == SemanticVersion.from_loose_version(loose_version)
    loose_version = LooseVersion('0.1.1~dev4+test')
    assert SemanticVersion('0.1.1-dev4+test') == SemanticVersion.from_loose_version(loose_version)
    loose_version = LooseVersion('0.1.1~dev4-test')
    assert SemanticVersion('0.1.1-dev4') == SemanticVersion.from_loose

# Generated at 2022-06-11 18:48:59.839144
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:49:21.015588
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    cases = [
        [_Alpha('a'), 'a', True],
        [_Alpha('a'), _Alpha('a'), True],
        [_Alpha('a'), _Alpha('b'), True],
        [_Alpha('a'), 'b', True],
        [_Alpha('b'), 'a', False],
        [_Alpha('b'), _Alpha('a'), False],
        [_Alpha('b'), _Alpha('b'), True],
        #
        # Test if Py3 behavior matches Py2 behavior
        #
        # Note Py3 throws TypeError and is not caught here
        # Python 2.7.10 (default, Nov  7 2015, 11:20:09)
        # Python 2.7.12 (default, Dec  4 2017, 14:50:18)
        #
        [_Alpha('b'), 5, False],
    ]

# Generated at 2022-06-11 18:49:33.673231
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Import the class
    from ansible.module_utils.semver import SemanticVersion

    # List of inputs

# Generated at 2022-06-11 18:49:46.092411
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert (SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion('1.2.3'))
    assert (SemanticVersion.from_loose_version(LooseVersion("1.2.3a")) == SemanticVersion('1.2.3-a'))
    assert (SemanticVersion.from_loose_version(LooseVersion("1.2.3b")) == SemanticVersion('1.2.3-b'))
    assert (SemanticVersion.from_loose_version(LooseVersion("1.2.3a.4.5")) == SemanticVersion('1.2.3-a.4.5'))

# Generated at 2022-06-11 18:49:58.604022
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Verify TypeError exception is thrown when parameter is not an instance of LooseVersion
    for vstring in ('', 'foo', ['foo'], {'foo': 'bar'}, 0):
        try:
            SemanticVersion.from_loose_version(vstring)
        except TypeError:
            pass
        else:
            assert False, "TypeError exception not thrown when parameter is '%s'" % vstring

    # Verify TypeError exception is thrown when version does not contain integer values

# Generated at 2022-06-11 18:50:11.477198
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """ Unit testing class SemanticVersion method from_loose_version """
    from ansible.module_utils.six import six

    # Test invalid input
    try:
        SemanticVersion.from_loose_version(six.text_type())
        assert True == False
    except ValueError:
        pass

    # Test alpha version with release
    assert SemanticVersion.from_loose_version(LooseVersion("0.1.4a")) == SemanticVersion("0.1.4a")
    assert SemanticVersion.from_loose_version(LooseVersion("0.1.4a1")) == SemanticVersion("0.1.4a1")

    # Test numeric version
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3")) == SemanticVersion("1.2.3")



# Generated at 2022-06-11 18:50:21.043796
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    a = _Alpha('a')
    b = _Alpha('b')
    c = _Alpha('c')

    assert 'a' <= 'b'
    assert a <= b
    assert a <= 'b'

    assert 'b' >= 'a'
    assert b >= a
    assert b >= 'a'

    assert 'a' < 'c'
    assert a < c
    assert a < 'c'

    assert 'c' > 'a'
    assert c > a
    assert c > 'a'


# Generated at 2022-06-11 18:50:28.692787
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion('1.2.3') == SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert SemanticVersion('1.2.3') == SemanticVersion.from_loose_version(LooseVersion('1.2.3a1'))
    assert SemanticVersion('1.2.3') == SemanticVersion.from_loose_version(LooseVersion('1.2.3rc1'))
    assert SemanticVersion('1.2.3') == SemanticVersion.from_loose_version(LooseVersion('1.2.3.0'))
    assert SemanticVersion('1.2.3') == SemanticVersion.from_loose_version(LooseVersion('1.2.3.0.a1'))

# Generated at 2022-06-11 18:50:41.020516
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert v == '1.2.3'
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre1'))
    assert v == '1.2.3-pre1'
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre1.2.3-pre1'))
    assert v == '1.2.3-pre1.2.3-pre1'
    v = SemanticVersion.from_loose_version(LooseVersion('1.2.3-pre1.2+build3'))

# Generated at 2022-06-11 18:50:54.823043
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    assert _Alpha("a") <= "b"
    assert _Alpha("a") <= "a"
    assert not (_Alpha("a") <= "A")
    assert _Alpha("a") <= _Alpha("b")
    assert _Alpha("a") <= _Alpha("a")
    assert not (_Alpha("a") <= _Alpha("A"))
    assert not (_Alpha("a") <= _Numeric(1))
    assert not (_Alpha("a") <= 1)

    try:
        _Alpha("a") <= object()
    except ValueError:
        pass
    else:
        assert False, "_Alpha('a') <= object() should have raised a ValueError"

    try:
        _Alpha("a") <= _Alpha(1)
    except ValueError:
        pass

# Generated at 2022-06-11 18:51:03.507867
# Unit test for method __le__ of class _Alpha
def test__Alpha___le__():
    class MyAlpha(_Alpha):
        def __init__(self, specifier):
            self.specifier = specifier

    a = MyAlpha('2')
    b = MyAlpha('3')
    c = MyAlpha('4')

    assert a.__le__(b) == True
    assert a.__le__(c) == True

    assert b.__le__(a) == False
    assert b.__le__(c) == True

    assert c.__le__(a) == False
    assert c.__le__(b) == False

    assert c.__ge__(a) == True
    assert c.__ge__(b) == True

    assert a.__ge__(b) == False
    assert a.__ge__(c) == False

    assert b.__ge__(a) == True


# Generated at 2022-06-11 18:51:22.577598
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class TestLooseVersion(LooseVersion):
        def __init__(self, vstring):
            super(TestLooseVersion, self).__init__(vstring)
            self.version = (int(v) for v in self.version)

    assert SemanticVersion.from_loose_version(TestLooseVersion('0.2.3')).vstring == '0.2.3'
    assert SemanticVersion.from_loose_version(TestLooseVersion('0.2.3-beta.4')).vstring == '0.2.3-beta.4'
    assert SemanticVersion.from_loose_version(TestLooseVersion('0.2.3-beta.4+build123')).vstring == '0.2.3-beta.4+build123'
    assert SemanticVersion.from_lo

# Generated at 2022-06-11 18:51:32.381905
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion('4.3.7') == SemanticVersion.from_loose_version(LooseVersion('4.3.7'))
    assert SemanticVersion('4.3.7-alpha.1') == SemanticVersion.from_loose_version(LooseVersion('4.3.7-alpha.1'))
    assert SemanticVersion('4.3.7-alpha.1+build.1234') == SemanticVersion.from_loose_version(LooseVersion('4.3.7-alpha.1+build.1234'))
    assert SemanticVersion('1.2.3') == SemanticVersion.from_loose_version(LooseVersion('1.2.3-1'))

# Generated at 2022-06-11 18:51:43.707519
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    assert SemanticVersion.from_loose_version('0.0.0') == LooseVersion('0.0.0')
    assert SemanticVersion.from_loose_version('1.0.0') == LooseVersion('1.0.0')
    assert SemanticVersion.from_loose_version('0.1.0') == LooseVersion('0.1.0')
    assert SemanticVersion.from_loose_version('1.1.0') == LooseVersion('1.1.0')
    assert SemanticVersion.from_loose_version('1.1.1') == LooseVersion('1.1.1')

    assert SemanticVersion.from_loose_version('1.0.0.1') == LooseVersion('1.0.0')
    assert SemanticVersion.from_loose_

# Generated at 2022-06-11 18:51:53.582180
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a normal conversion
    v1 = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert v1.vstring == '1.2.3'

    # Test conversion from a SemanticVersion
    v2 = SemanticVersion.from_loose_version(v1)
    assert v1 == v2

    # Test some non tuple values for loose_version
    with pytest.raises(ValueError):
        SemanticVersion.from_loose_version('1.2.3')
    with pytest.raises(ValueError):
        s = SemanticVersion()
        SemanticVersion.from_loose_version(s)

    # Test some non integer values in loose_version.version
    with pytest.raises(ValueError):
        SemanticVersion.from_lo

# Generated at 2022-06-11 18:52:04.646401
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    v = LooseVersion('2020.11.1')
    sv = SemanticVersion.from_loose_version(v)
    assert sv.is_stable
    assert sv.major == 2020
    assert sv.minor == 11
    assert sv.patch == 1

    v = LooseVersion('2020.11')
    sv = SemanticVersion.from_loose_version(v)
    assert sv.is_stable
    assert sv.major == 2020
    assert sv.minor == 11
    assert sv.patch == 0

    v = LooseVersion('2020')
    sv = SemanticVersion.from_loose_version(v)
    assert sv.is_stable
    assert sv.major == 2020
    assert sv.minor == 0
    assert sv.patch == 0

    # Try some prereleases
    v = Loose