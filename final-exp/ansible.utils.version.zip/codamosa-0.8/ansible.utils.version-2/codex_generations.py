

# Generated at 2022-06-11 18:42:41.210901
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    test1 = '0.1.2'
    test1_parse = SemanticVersion('0.1.2')
    test2 = '0.1.2.3.4.5'
    test2_parse = SemanticVersion('0.1.2.3.4.5')
    test3 = '0.1.2-a.b.c.d'
    test3_parse = SemanticVersion('0.1.2-a.b.c.d')
    test4 = '0.1.2-1.2.3.4+a.b.c.d'
    test4_parse = SemanticVersion('0.1.2-1.2.3.4+a.b.c.d')


# Generated at 2022-06-11 18:42:50.952644
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    def test_valid(vstring):
        v = SemanticVersion()
        v.parse(vstring)
        return v

    def test_invalid(vstring):
        v = SemanticVersion()
        #try:
        #    v.parse(vstring)
        #except ValueError:
        #    pass
        #else:
        #    raise AssertionError("ValueError not raised for %r" % vstring)
        #finally:
        #    return v

    # 1.0.0-alpha
    assert test_valid("1.0.0-alpha").major == 1
    assert test_valid("1.0.0-alpha").minor == 0
    assert test_valid("1.0.0-alpha").patch == 0

# Generated at 2022-06-11 18:42:56.750599
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_2_2_1 = LooseVersion("2.2.1")
    semver = SemanticVersion.from_loose_version(loose_version_2_2_1)
    assert semver.vstring == loose_version_2_2_1.vstring



# Generated at 2022-06-11 18:43:09.336137
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():

    # Test: parse an empty argument
    version_string = ''
    try:
        test_version = SemanticVersion(version_string)
    except ValueError:
        pass
    else:
        raise AssertionError("Expected exception ValueError when parsing '%s'" % version_string)

    # Test: parse a non-empty argument

# Generated at 2022-06-11 18:43:22.922340
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3.4')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha')) == SemanticVersion('1.2.3-alpha')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-alpha.1')) == SemanticVersion('1.2.3-alpha.1')

# Generated at 2022-06-11 18:43:23.442422
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    pass

# Generated at 2022-06-11 18:43:32.890863
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert True
    #assert SemanticVersion.from_loose_version('6.4.0') == SemanticVersion('6.4.0')
    #assert SemanticVersion.from_loose_version('6.4.0-pre') == SemanticVersion('6.4.0-pre')
    #assert SemanticVersion.from_loose_version('6.4.0-pre.1') == SemanticVersion('6.4.0-pre.1')
    #assert SemanticVersion.from_loose_version('6.4.0-pre.1-beta') == SemanticVersion('6.4.0-pre.1.beta')


# Generated at 2022-06-11 18:43:42.888732
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # LooseVersion to SemanticVersion
    loose_version1 = LooseVersion("1")
    semver1 = SemanticVersion.from_loose_version(loose_version1)
    assert semver1 == SemanticVersion("1.0.0")

    loose_version2 = LooseVersion("2.0")
    semver2 = SemanticVersion.from_loose_version(loose_version2)
    assert semver2 == SemanticVersion("2.0.0")

    loose_version3 = LooseVersion("3.0.0")
    semver3 = SemanticVersion.from_loose_version(loose_version3)
    assert semver3 == SemanticVersion("3.0.0")

    loose_version4 = LooseVersion("3.0.0-a1")
    semver4

# Generated at 2022-06-11 18:43:55.868321
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    # Simple version
    v = SemanticVersion('2.0.0')
    assert v.major == 2
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    # Only Major and minor
    v = SemanticVersion('2.0')
    assert v.major == 2
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    # Only Major
    v = SemanticVersion('2')
    assert v.major == 2
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ()
    assert v.buildmetadata == ()

    # Only Major and prerelease

# Generated at 2022-06-11 18:44:08.034298
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    v = SemanticVersion()
    assert v.parse('1.0.0') is None
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == tuple()
    assert v.buildmetadata == tuple()

    v.parse('1.0.0-alpha')
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ('alpha',)
    assert v.buildmetadata == tuple()

    v.parse('1.0.0-alpha.beta')
    assert v.major == 1
    assert v.minor == 0
    assert v.patch == 0
    assert v.prerelease == ('alpha', 'beta')
    assert v.buildmetadata == tuple()


# Generated at 2022-06-11 18:44:28.971689
# Unit test for method parse of class SemanticVersion

# Generated at 2022-06-11 18:44:35.025656
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    invalid_vstrings = [
        "a.b.c",
        "1",
        "1.2",
        "1.2.3.4.5",
        "1.2.3.a",
        "1.2.3-1.2.3-1.2.3",
        "1.2.3+1.2.3+1.2.3",
    ]
    for vstring in invalid_vstrings:
        try:
            SemanticVersion.from_loose_version(LooseVersion(vstring))
        except ValueError:
            pass
        else:
            # Should raise ValueError
            assert False


# Generated at 2022-06-11 18:44:48.799491
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    from ansible.module_utils import semantic_version


# Generated at 2022-06-11 18:45:00.232197
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import distutils.version

# Generated at 2022-06-11 18:45:11.164078
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version('1') == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version('1.2') == SemanticVersion('1.2.0')
    assert SemanticVersion.from_loose_version('1.2.3') == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version('1.2.3-4') == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version('1.2.3+4') == SemanticVersion('1.2.3+4')
    assert SemanticVersion.from_loose_version('1.2.3-4+5') == SemanticVersion('1.2.3-4+5')


# Generated at 2022-06-11 18:45:22.085176
# Unit test for method parse of class SemanticVersion
def test_SemanticVersion_parse():
    ver = SemanticVersion()
    ver.parse('1.2.3-alpha.1+build.1')
    assert ver.major == 1
    assert ver.minor == 2
    assert ver.patch == 3
    assert ver.prerelease[0] == 'alpha'
    assert ver.prerelease[1] == 1
    assert ver.prerelease[2] == 'build'
    assert ver.prerelease[3] == 1
    ver.parse('1.2.3')
    assert ver.major == 1
    assert ver.minor == 2
    assert ver.patch == 3
    assert ver.prerelease == ()
    ver.parse('1.2.3-12.1')
    assert ver.major == 1
    assert ver.minor == 2
    assert ver.patch == 3

# Generated at 2022-06-11 18:45:35.770816
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    semver = SemanticVersion.from_loose_version(LooseVersion('1.2.3'))
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    semver = SemanticVersion.from_loose_version(LooseVersion('1.2.3.4'))
    assert semver.major == 1
    assert semver.minor == 2
    assert semver.patch == 3
    assert semver.prerelease == ()
    assert semver.buildmetadata == ()

    # Release - a single letter (a) or a number (1) is parsed as a pre-release

# Generated at 2022-06-11 18:45:47.645837
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.1')) == SemanticVersion('1.0.1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1')) == SemanticVersion('1.0.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.0.0.0.0.0.0')) == SemanticVersion('1.0.0')

# Generated at 2022-06-11 18:45:58.964428
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    def try_SemanticVersion_from_loose_version(loose_version_string, semantic_version_string):
        try:
            v1 = SemanticVersion().from_loose_version(LooseVersion(loose_version_string))
        except Exception as e:
            raise ValueError("unable to convert LooseVersion '%s' to SemanticVersion" % loose_version_string) from e
        try:
            v2 = SemanticVersion(semantic_version_string)
        except ValueError:
            raise ValueError("unable to initialize SemanticVersion '%s'" % semantic_version_string)


# Generated at 2022-06-11 18:46:06.199456
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion
    # https://semver.org/#spec-item-4
    # Versions with a leading "v" (e.g. "v1.2.3") are no longer allowed.
    # Versions are denoted by a string of numeric identifiers separated by a single "." character.

# Generated at 2022-06-11 18:46:20.828984
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test 0 - Tests an non Compliant Version string
    try:
        SemanticVersion.from_loose_version(LooseVersion("1.1.1.1"))
    except ValueError as e:
        assert str(e) == "Non integer values in LooseVersion ('1', '1', '1', '1')"
    else:
        raise AssertionError

    # Test 1 - Tests an integer based version string
    version = SemanticVersion.from_loose_version(LooseVersion("1.2.3"))
    assert version.major == 1
    assert version.minor == 2
    assert version.patch == 3
    assert version.prerelease == ()
    assert version.buildmetadata == ()

    # Test 2 - Tests a version string with a normal pre-release string
    version = SemanticVersion.from_loose_

# Generated at 2022-06-11 18:46:29.943392
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.compat.version import LooseVersion

    # test basic functionality
    version = SemanticVersion.from_loose_version(LooseVersion(0))
    assert version.vstring == "0.0.0"
    version = SemanticVersion.from_loose_version(LooseVersion(1))
    assert version.vstring == "1.0.0"
    version = SemanticVersion.from_loose_version(LooseVersion(0, 1))
    assert version.vstring == "0.1.0"
    version = SemanticVersion.from_loose_version(LooseVersion(0, 1, 2))
    assert version.vstring == "0.1.2"

# Generated at 2022-06-11 18:46:43.184676
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.common._version import SemanticVersion, LooseVersion
    
    assert SemanticVersion.from_loose_version(LooseVersion('1.1')) == SemanticVersion('1.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1+1')) == SemanticVersion('1.1.0+1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1-1')) == SemanticVersion('1.1.0-1')
    assert SemanticVersion.from_loose_version(LooseVersion('1.1-1+1')) == SemanticVersion('1.1.0-1+1')


# Generated at 2022-06-11 18:46:55.455783
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Successfull version
    loose_version = LooseVersion('0.5.5')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semver, SemanticVersion)
    assert semver.vstring == '0.5.5'
    assert semver.major == 0
    assert semver.minor == 5
    assert semver.patch == 5

    # Successfull version
    loose_version = LooseVersion('1.10.1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert isinstance(semver, SemanticVersion)
    assert semver.vstring == '1.10.1'
    assert semver.major == 1
    assert semver.minor == 10
    assert semver.patch == 1

# Generated at 2022-06-11 18:47:04.504133
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test that a LooseVersion is converted to SemanticVersion correctly.
    from ansible.module_utils.common.version import LooseVersion
    assert SemanticVersion.from_loose_version(LooseVersion('0.1')) == SemanticVersion('0.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.0')) == SemanticVersion('0.1.0')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1.1')) == SemanticVersion('0.1.1')
    assert SemanticVersion.from_loose_version(LooseVersion('0.1-foo')) == SemanticVersion('0.1.0-foo')

# Generated at 2022-06-11 18:47:15.215495
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Vaid LooseVersion objects and expected SemanticVersion output
    test_data = (
        {
            'loose_version': LooseVersion("0.10.3"),
            'semver': SemanticVersion("0.10.3"),
        },
        {
            'loose_version': LooseVersion("1.2.2-alpha"),
            'semver': SemanticVersion("1.2.2-alpha"),
        },
        {
            'loose_version': LooseVersion("0.0.1+build2"),
            'semver': SemanticVersion("0.0.1+build2"),
        },
    )

    for test in test_data:
        assert SemanticVersion.from_loose_version(
            test['loose_version']
        ) == test['semver']


# Generated at 2022-06-11 18:47:23.928727
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test correct versions
    assert (SemanticVersion.from_loose_version(LooseVersion('2.0.0')).core == (2, 0, 0))
    assert (SemanticVersion.from_loose_version(LooseVersion('2.0.0a')).core == (2, 0, 0))
    assert (SemanticVersion.from_loose_version(LooseVersion('2.0.0a1')).core == (2, 0, 0))
    assert (SemanticVersion.from_loose_version(LooseVersion('2.0.0a0.123')).core == (2, 0, 0))
    assert (SemanticVersion.from_loose_version(LooseVersion('2.0.0+123')).core == (2, 0, 0))

# Generated at 2022-06-11 18:47:32.560349
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:47:42.493601
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert(
        SemanticVersion.from_loose_version(
            LooseVersion('1.2.3')
        ) ==
        SemanticVersion('1.2.3')
    )

    assert(
        SemanticVersion.from_loose_version(
            LooseVersion('1.2.3b3')
        ) ==
        SemanticVersion('1.2.3-b3')
    )

    assert(
        SemanticVersion.from_loose_version(
            LooseVersion('1.2.3.4')
        ) ==
        SemanticVersion('1.2.3.4')
    )


# Generated at 2022-06-11 18:47:55.937969
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six import PY3

    # Test a normal Loose Version
    assert SemanticVersion.from_loose_version(LooseVersion("2.2.1")) == SemanticVersion("2.2.1")

    # Test a Loose Version that has pre-release information
    assert SemanticVersion.from_loose_version(LooseVersion("2.2.1b0")) == SemanticVersion("2.2.1")

    # Test a Loose Version that has build metadata
    assert SemanticVersion.from_loose_version(LooseVersion("2.2.1dev")) == SemanticVersion("2.2.1")

    # Test a Loose Version that has both pre-release and build metadata

# Generated at 2022-06-11 18:48:23.459530
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    """
    Test that SemanticVersion can create a semantic version from a loose version
    """
    sver = SemanticVersion.from_loose_version(LooseVersion('2.3.4'))
    assert sver.vstring == '2.3.4'

    sver = SemanticVersion.from_loose_version(LooseVersion('2.3.4-rc1'))
    assert sver.vstring == '2.3.4-rc1'

    sver = SemanticVersion.from_loose_version(LooseVersion('test'))
    assert sver.vstring == '0.0.0-test'

    sver = SemanticVersion.from_loose_version(LooseVersion('1.2.3+github1'))

# Generated at 2022-06-11 18:48:35.974391
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:48:47.589112
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Test python-version-independent cases
    # py2 and py3 do not have the same results
    # because of the len() function on a string
    # therefore, cases are tested which are the same
    # on py2 and py3
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3')) == SemanticVersion('1.2.3')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3-4')) == SemanticVersion('1.2.3-4')
    assert SemanticVersion.from_loose_version(LooseVersion('1.2.3+4')) == SemanticVersion('1.2.3+4')

# Generated at 2022-06-11 18:48:59.596009
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with a string
    if hasattr(text_type, '__mod__'):
        vstring = text_type('1.2.3-alpha.1+abcd')
        sv = SemanticVersion(vstring)
        lv = LooseVersion(vstring)
    else:
        vstring = '1.2.3-alpha.1+abcd'
        sv = SemanticVersion(vstring)
        lv = LooseVersion(vstring)

    assert str(vstring), str(SemanticVersion.from_loose_version(lv))

    # Test with a LooseVersion
    lv = LooseVersion('1.2.3-alpha.1+abcd')
    assert str(vstring), str(SemanticVersion.from_loose_version(lv))

# When executed, run unit test

# Generated at 2022-06-11 18:49:10.706844
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    try:
        from ansible.module_utils.six import PY2
    except ImportError:
        PY2 = False

    # Test with a LooseVersion input
    assert SemanticVersion.from_loose_version(LooseVersion('47.11.0.alpha1')) == SemanticVersion('47.11.0-alpha1')

    # Test that a ValueError is raised with a non LooseVersion
    bad_inputs = ['1.2.3', 1.2, {'a': 'b'}, [1, 2, 3, 4], lambda: 'blah']

# Generated at 2022-06-11 18:49:21.526722
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():

    # Check for empty LooseVersion
    for version in ('', '   '):
        loose_version = LooseVersion(version)
        try:
            SemanticVersion.from_loose_version(loose_version)
        except ValueError:
            pass
        else:
            raise AssertionError(
                "Expect a ValueError while converting LooseVersion(%r)" % version)

    # Check for a non LooseVersion
    for version in (
        (1, 2, 3),
        object(),
        object,
        SemanticVersion
    ):
        try:
            SemanticVersion.from_loose_version(version)
        except ValueError:
            pass
        else:
            raise AssertionError(
                "Expect a ValueError while converting %r to SemanticVersion" % version)

    # Check

# Generated at 2022-06-11 18:49:34.083285
# Unit test for method from_loose_version of class SemanticVersion

# Generated at 2022-06-11 18:49:46.177954
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import sys
    import unittest
    import ansible.module_utils.common.version as version_utils

    class TestSemanticVersion(unittest.TestCase):
        def test_from_loose_version(self):
            """Test the method SemanticVersion.from_loose_version"""
            self.assertEqual(
                version_utils.SemanticVersion.from_loose_version(version_utils.LooseVersion('1.0.0')),
                version_utils.SemanticVersion('1.0.0')
            )

# Generated at 2022-06-11 18:49:58.704700
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    import unittest.mock

    def test_case(expected, loose_version):
        with unittest.mock.patch('ansible_collections.ansible.community.version.SemanticVersion.__init__') as mock__init__:
            SemanticVersion.from_loose_version(loose_version)
            assert mock__init__.call_args_list == [unittest.mock.call(expected)]

    test_case('1.2+dev', LooseVersion('1.2.0-dev'))
    test_case('1.2+dev', LooseVersion('1.2.1-dev'))
    test_case('1.2.3+dev', LooseVersion('1.2.3-dev'))

# Generated at 2022-06-11 18:50:11.621259
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test with None
    version = SemanticVersion.from_loose_version(None)
    assert version == None

    # Test with a LooseVersion object
    version = SemanticVersion.from_loose_version(LooseVersion("1.0.0"))
    assert version == "1.0.0"

    # Test with an incompatible object
    try:
        version = SemanticVersion.from_loose_version("1.0.0")
    except ValueError as e:
        assert str(e) == "'1.0.0' is not a LooseVersion"
    else:
        assert False and "An exception should have been raised"

    # Test with a valid string
    version = SemanticVersion.from_loose_version(LooseVersion("1.0.0"))

# Generated at 2022-06-11 18:50:49.394451
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3-alpha")) == SemanticVersion("1.2.3-alpha")
    assert SemanticVersion.from_loose_version(LooseVersion("1.2.3+a")) == SemanticVersion("1.2.3+a")

# Generated at 2022-06-11 18:50:59.580140
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    tv = LooseVersion('10.4.0')
    sv = SemanticVersion.from_loose_version(tv)
    assert sv.major == 10
    assert sv.minor == 4
    assert sv.patch == 0

    tv = LooseVersion('10.4.0.dev1')
    sv = SemanticVersion.from_loose_version(tv)
    assert sv.major == 10
    assert sv.minor == 4
    assert sv.patch == 0
    assert sv.prerelease == ('dev1',)

    tv = LooseVersion('10.3.3b3')
    sv = SemanticVersion.from_loose_version(tv)
    assert sv.major == 10
    assert sv.minor == 3
    assert sv.patch == 3
    assert sv.prerelease == ('b3',)



# Generated at 2022-06-11 18:51:09.980194
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_good_vstring = "1.8.1"
    semantic_version_good_vstring = SemanticVersion("1.8.1")
    loose_version_bad_vstring_non_integer = "1.8.1a"
    loose_version_bad_vstring_empty = "1.8.1"
    loose_version_bad_vstring_non_loose_version_object = "1.8.1"

    assert SemanticVersion.from_loose_version(LooseVersion(loose_version_good_vstring)) == semantic_version_good_vstring
    assert SemanticVersion.from_loose_version(LooseVersion(loose_version_bad_vstring_non_integer)) == semantic_version_good_vstring
    assert SemanticVersion.from_loose_version

# Generated at 2022-06-11 18:51:21.349874
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion("1.1.1b1.dev10+g48ac2a2")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == "1.1.1-b1"

    loose_version = LooseVersion("1.1.1rc1.dev10+g48ac2a2")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == "1.1.1-rc1"

    loose_version = LooseVersion("1.1.1")
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver == "1.1.1"

    loose_version = LooseVersion("1.1.1b1")
   

# Generated at 2022-06-11 18:51:28.930769
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    # Test a few valid loose version strings
    loose_versions = (
        LooseVersion('1'),
        LooseVersion('1.2'),
        LooseVersion('1.0.0'),
        LooseVersion('1.2.3'),
        LooseVersion('1.2.3+1.2.3'),
        LooseVersion('1.2.3-10.20.30'),
        LooseVersion('1.2.3-1.2.3+1.2.3'),
    )
    for loose_version in loose_versions:
        semver = SemanticVersion.from_loose_version(loose_version)
        assert text_type(semver) == text_type(loose_version)

    # Test one invalid loose version
    loose_version = LooseVersion('1.2.3.4')

# Generated at 2022-06-11 18:51:36.151370
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    from ansible.module_utils.six.moves import unittest

    class TestFromLooseVersion(unittest.TestCase):
        def test_from_loose_version(self):
            from ansible.module_utils.common.version import SemanticVersion

            self.assertEqual(
                SemanticVersion.from_loose_version(
                    LooseVersion('1.0.0')
                ),
                SemanticVersion('1.0.0')
            )
            self.assertEqual(
                SemanticVersion.from_loose_version(
                    LooseVersion('1.0.1')
                ),
                SemanticVersion('1.0.1')
            )

# Generated at 2022-06-11 18:51:42.195657
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version_1 = LooseVersion("1.0.0")
    loose_version_2 = LooseVersion("1.0.0-rc.1")
    loose_version_3 = LooseVersion("1.0.0rc.1")
    loose_version_4 = LooseVersion("1.0.0b")
    loose_version_5 = LooseVersion("1.0.0-1234+build.1234")
    loose_version_6 = LooseVersion("1.0.0.3")
    loose_version_7 = LooseVersion("1.0.0.3-1")
    loose_version_8 = LooseVersion("1.0.0.3-1+build.3")
    loose_version_9 = LooseVersion("1.0.0.3+build.3")
   

# Generated at 2022-06-11 18:51:52.495774
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    loose_version = LooseVersion('5.0.0')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.core == (5, 0, 0)
    assert semver.is_prerelease is False
    assert semver.is_stable is True

    loose_version = LooseVersion('5.0.0-rc1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.core == (5, 0, 0)
    assert semver.is_prerelease is True
    assert semver.is_stable is False

    loose_version = LooseVersion('5.0.0-rc1')
    semver = SemanticVersion.from_loose_version(loose_version)
    assert semver.core

# Generated at 2022-06-11 18:52:03.705528
# Unit test for method from_loose_version of class SemanticVersion
def test_SemanticVersion_from_loose_version():
    class TestVersion(object):
        def __init__(self, vstring):
            self.vstring = vstring

        def __repr__(self):
            return repr(self.vstring)

    # Test data taken from tests/test_semver.py