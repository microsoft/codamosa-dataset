

# Generated at 2022-06-25 07:18:49.482759
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    if PY2:
        return

    import ansible.plugins.action.pause
    ansible_plugins_action_pause_ActionModule = ansible.plugins.action.pause.ActionModule

    import tempfile
    tmp = tempfile.TemporaryDirectory()
    new_stdin = None
    task_vars = {
        'test_var': 'test_val'}

    ansible_plugins_action_pause_ActionModule_instance = ansible_plugins_action_pause_ActionModule(new_stdin, tmp, task_vars)
    try:
        ansible_plugins_action_pause_ActionModule_instance.run()
    except Exception as e:
        print(e)


# Generated at 2022-06-25 07:18:54.451543
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    my_task = {}
    my_task['vars'] = {}
    my_connection = {}
    my_self = {}
    my_self['_task'] = my_task
    my_self['_connection'] = my_connection

    class my_ActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None, **kwargs):
            return

    my_am = my_ActionModule(my_self, my_self)


    # First test case
    my_am.run(tmp='tmp_0', task_vars={})
    my_task = {}
    my_task['vars'] = {}
    my_task['vars']['ansible_system_capabilities'] = {}

# Generated at 2022-06-25 07:18:57.392979
# Unit test for function clear_line
def test_clear_line():

    class MockStdout(object):
        def __init__(self):
            self.buffer = []

        def write(self, data):
            assert isinstance(data, bytes)
            self.buffer.append(data)

    stdout = MockStdout()
    clear_line(stdout)
    assert stdout.buffer == [MOVE_TO_BOL, CLEAR_TO_EOL]

# Generated at 2022-06-25 07:19:02.167249
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionmodule_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert type(actionmodule_0) == ActionModule
    try:
        actionmodule_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None)
    except TypeError:
        pass
    try:
        actionmodule_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj="str")
    except TypeError:
        pass

# Unit tests for AnsibleTimeoutExceeded class

# Generated at 2022-06-25 07:19:04.501988
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule(task=None)
    #assert isinstance(action_module_0.run(), dict)


# Generated at 2022-06-25 07:19:07.558908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.plugins.action.pause import ActionModule
    action_module_0 = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-25 07:19:13.900550
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # ActionModule.run(self, tmp=None, task_vars=None)
    # Calls superclass.run(tmp, task_vars)
    from ansible.plugins.action.pause import ActionModule
    tmp = None
    task_vars = None
    super_result = True
    class Superclass():
        def run(tmp, task_vars):
            return super_result
    action_obj = ActionModule(task=None)
    action_obj.superclass = Superclass()
    result = action_obj.run(tmp, task_vars)
    assert result == super_result
    assert isinstance(result, dict)
    # Calls superclass.run(tmp, task_vars)
    result = action_obj.run(None, None)
    assert result == super_result


# Generated at 2022-06-25 07:19:23.733561
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Tests ActionModule.run()
    """

    # Setup mock objects
    class module_test():
        def __init__(self):
            self.params = dict()
        def fail_json(self, **kwargs):
            self.fail_json_received = kwargs
            raise Exception("fail_json called")

    # Setup parameters
    module_test_obj = module_test()

    # Invoke method
    try:
        kwargs = dict()
        ActionModule().run(module_test_obj, **kwargs)
    except Exception as e:
        assert "fail_json called" == e.message, "Unexpected exception thrown"
        assert 'failed' in module_test_obj.fail_json_received, "Missing 'failed' in fail_json call"

# Generated at 2022-06-25 07:19:30.235461
# Unit test for constructor of class ActionModule
def test_ActionModule():
    #
    # Test that errors are raised when invalid parameters are passed
    #
    from ansible.playbook.play_context import PlayContext

    invalid_args = dict(
        foo='bar',
        bar='foo',
        baz='boz',
    )

    action_module = ActionModule(dict(
        _task=dict(
            args=invalid_args,
        ),
        _play_context=PlayContext(),
    ))

    #
    # Test that the parent constructor is called, passing a task
    # object with no args
    #
    valid_args = dict(
        prompt="What is my purpose?",
        echo=True,
    )


# Generated at 2022-06-25 07:19:31.440528
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-25 07:19:50.077831
# Unit test for function clear_line
def test_clear_line():
    print("test_clear_line")
    int_0 = 2
    var_0 = clear_line(int_0)
    if var_0 == None:
        print("unit test returned: ok")
    else:
        print("unit test returned: %s" % var_0)

if __name__ == '__main__':
    test_case_0()
    test_clear_line()

# Generated at 2022-06-25 07:19:55.887743
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()
    assert result == dict(changed=False,
                         delta=None,
                         rc=0,
                         start=None,
                         stderr='',
                         stdout='',
                         stop=None,
                         user_input='')


# Generated at 2022-06-25 07:20:05.396233
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {'args': {'echo': True, 'minutes': '2', 'prompt': '', 'seconds': ''}}
    action_module._task.get_name = lambda : ''
    assert action_module.run()['delta'] == 0

    action_module._task = {'args': {'echo': True, 'minutes': '', 'prompt': '', 'seconds': ''}}
    action_module._task.get_name = lambda : ''
    assert action_module.run()['delta'] == 0

    action_module._task = {'args': {'echo': True, 'minutes': '', 'prompt': '', 'seconds': '2'}}
    action_module._task.get_name = lambda : ''
    assert action_module.run

# Generated at 2022-06-25 07:20:15.848929
# Unit test for function clear_line
def test_clear_line():
    var_0 = b'test'
    stdin_fd = var_0
    sys.stdin = io.open(sys.stdin.fileno())
    sys.stdout = io.open(sys.stdout.fileno())

    # Test begin
    stdin_fd = sys.stdin.buffer
    stdout_fd = sys.stdout.buffer
    old_settings = termios.tcgetattr(stdin_fd)
    tty.setraw(stdin_fd)
    tty.setraw(stdout_fd)
    termios.tcflush(stdin_fd, termios.TCIFLUSH)
    stdin_fd.write(var_0[:2])
    stdin_fd.flush()
    clear_line(sys.stdout.buffer)

# Generated at 2022-06-25 07:20:19.474622
# Unit test for function is_interactive
def test_is_interactive():
    # Write your unit test here
    # This is a basic test case which will assert on the boolean value
    # returned by is_interactive
    assert is_interactive()
    print('is_interactive basic test case passed!')


# Generated at 2022-06-25 07:20:23.247290
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True


# Generated at 2022-06-25 07:20:26.111560
# Unit test for function is_interactive
def test_is_interactive():
    assert is_interactive(False)
    assert is_interactive(True)


test_case_0()
test_is_interactive()

# Generated at 2022-06-25 07:20:26.775301
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 07:20:29.267856
# Unit test for function clear_line
def test_clear_line():
    stdout = 1
    print(u'Inputs')
    print(u'\tstdout = ' + str(stdout))
    test_case_0()



# Generated at 2022-06-25 07:20:33.564856
# Unit test for function clear_line
def test_clear_line():
    try:
        test_case_0()
    except:
        print("FAILED: test_case_0")


# Generated at 2022-06-25 07:20:56.639853
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Set up the arguments and expected results for the test
    tmp = None
    task_vars = None
    expected = dict(changed=False, rc=0, stderr='', stdout='', start=None, stop=None, delta=None, echo=None, user_input=None)
    expected['failed'] = False
    expected['msg'] = ''


    # Invoke the run method and check the results
    actual = ActionModule.run(tmp, task_vars)
    if actual != expected:
        raise AssertionError("Expected %s, got %s" % (expected, actual))


# Generated at 2022-06-25 07:20:59.248134
# Unit test for function clear_line
def test_clear_line():
    with pytest.raises(AnsibleError) as excinfo:
        test_case_0()
    assert 'user requested abort' in to_text(excinfo.value)


# Generated at 2022-06-25 07:21:11.498467
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionBase.action_plugins.keys()
    var_1 = ActionBase.action_plugins['command']
    var_2 = ActionBase.action_plugins['raw']
    var_3 = ActionBase.action_plugins['script']
    var_4 = ActionBase.action_plugins['shell']
    var_5 = ActionBase.action_plugins['systemd']
    var_6 = ActionBase.action_plugins['copy']
    var_7 = ActionBase.action_plugins['synchronize']
    var_8 = ActionBase.action_plugins['fetch']
    var_9 = ActionBase.action_plugins['unarchive']
    var_10 = ActionBase.action_plugins['async_status']
    var_11 = ActionBase.action_plugins['async_wrapper']

# Generated at 2022-06-25 07:21:14.363253
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = dict()
    var_2 = dict()
    var_3 = ActionModule(var_1, var_2)

# Generated at 2022-06-25 07:21:16.207880
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule('arg_0')
    assert isinstance(obj, object)
    assert isinstance(obj, ActionBase)
    assert hasattr(obj, 'run')


# Generated at 2022-06-25 07:21:23.444793
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Run the test case with arguments
    int_0 = -39
    str_0 = "7]^Z{l[9"
    list_0 = [
        int_0,
        int_0,
        str_0]
    dict_0 = {
        'E': str_0,
        'S': list_0}
    int_1 = -39
    str_1 = "7]^Z{l[9"
    list_1 = [
        int_1,
        int_1,
        str_1]
    dict_1 = {
        'E': str_1,
        'S': list_1}
    set_0 = {
        list_0}

# Generated at 2022-06-25 07:21:30.616104
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.role import Role
    from ansible.playbook.block import Block

    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host, Group

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager.set_inventory(inventory)



# Generated at 2022-06-25 07:21:35.107177
# Unit test for function clear_line
def test_clear_line():
    out0 = sys.stdout
    in0 = sys.stdin
    err0 = sys.stderr
    sys.stdout = io.BytesIO()
    sys.stdin = io.BytesIO()
    sys.stderr = io.BytesIO()
    test_case_0()
    sys.stdout = out0
    sys.stdin = in0
    sys.stderr = err0
    assert True


# Generated at 2022-06-25 07:21:36.845801
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Test method run")


# Generated at 2022-06-25 07:21:42.628653
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class_1 = ActionModule()
    int_0 = 7
    var_0 = class_1.run(int_0)
    int_1 = -39
    var_1 = class_1.run(int_0, int_1)


# Generated at 2022-06-25 07:22:23.078410
# Unit test for function clear_line
def test_clear_line():
    assert test_case_0() == 0

# Generated at 2022-06-25 07:22:24.397530
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule.run()
    print(mod)

test_ActionModule_run()

# Generated at 2022-06-25 07:22:30.665692
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 07:22:36.883923
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Calls the constructor for ActionModule with the given keyword arguments
    action_module_ins = ActionModule(parameters={"minutes": "10"})
    print(action_module_ins.run())

# Generated at 2022-06-25 07:22:39.809920
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    mod = ActionModule()
    args = dict( seconds = int )
    mod._execute_module = lambda *args: dict(ansible_facts=dict())
    mod._task.args = args
    mod.run(tmp='/tmp/tmp', task_vars=dict())

# Generated at 2022-06-25 07:22:43.199258
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule("action_plugins")
    test_case_0()
    return 0


# Generated at 2022-06-25 07:22:47.117175
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 07:22:49.388961
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule([''], '', '', '', '', tell=lambda x: print(x))
    assert True


# Generated at 2022-06-25 07:22:52.980767
# Unit test for method run of class ActionModule
def test_ActionModule_run():
  module_args = dict()
  task_vars = dict()
  my_obj = AnsibleActionModule(module_name='pause', module_args=module_args, task_vars=task_vars)
  my_obj.run()

# Generated at 2022-06-25 07:22:54.160793
# Unit test for function is_interactive
def test_is_interactive():
    assert is_interactive(-1) == False
    assert is_interactive(0) == True
    assert is_interactive(1) == False

# Generated at 2022-06-25 07:23:56.675888
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = [(1, "item, item_0"), (2, "item, item_1")]
    tmp = [("k", "v")]
    val_1 = (1, 2)
    var_0 = ActionModule(task_vars, tmp)
    var_1 = var_0.run(val_1)
    assert var_1 == 0, "Incorrect return value from method run of class ActionModule"
    assert var_0._task.args['seconds'] == 1, "Incorrect value of attribute _task.args['seconds']"
    assert var_0._task.args['minutes'] == 2, "Incorrect value of attribute _task.args['minutes']"
    assert var_0._task.args['prompt'] == "k", "Incorrect value of attribute _task.args['prompt']"

# Generated at 2022-06-25 07:24:03.474615
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("Testing run")

    var_0 = {}
    var_0["FOO"]="BAR"
    var_0["ANSIBLE_MODULE_ARGS"]=var_0

    # Initialize object
    am = ActionModule(var_0, {})
    am._task = {}
    am._task_vars = {}
    am._task_vars["ansible_connection"] = "local"
    am._connection = {}
    am._connection = {"_new_stdin": {"fileno": test_case_0}}
    am._loader = {}
    am._loader.get_basedir = get_basedir
    am._templar = {}
    am._templar.template = template

    # Test endpoint with no arguments
    var_0 = am.run(None, None)
    print("PASS")

# Generated at 2022-06-25 07:24:07.232581
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\n**********************\nRunning unit test for \'run\' method of class \'ActionModule\'\n**********************")

    # Constructor test
    actionModule = ActionModule()

    # create a test case
    test_case_0()

# run all unit tests
test_ActionModule_run()


# Generated at 2022-06-25 07:24:08.781143
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    tmp = 'Answer is: '
    task_vars = dict()

    obj = ActionModule(tmp, task_vars)
    obj.run(tmp, task_vars)


# Generated at 2022-06-25 07:24:13.332849
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    obj = ActionModule('test')

    # Attempt to set "to" as object attribute
    with pytest.raises(AttributeError) as excinfo:
        obj.to = 'test'
    assert 'can\'t set attribute' in str(excinfo.value)
    # Attempt to set "tmp_path" as object attribute
    with pytest.raises(AttributeError) as excinfo:
        obj.tmp_path = 'test'
    assert 'can\'t set attribute' in str(excinfo.value)
    # Attempt to set "check_mode" as object attribute
    with pytest.raises(AttributeError) as excinfo:
        obj.check_mode = 'test'
    assert 'can\'t set attribute' in str(excinfo.value)
    # Attempt to set "no_log" as object attribute

# Generated at 2022-06-25 07:24:15.886303
# Unit test for function is_interactive
def test_is_interactive():
    # Should return false if the pipe is not interactive
    int_0 = -39
    var_1 = is_interactive(int_0)
    assert var_1 == False

#Unit test for function is_interactive

# Generated at 2022-06-25 07:24:18.276511
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # @todo: Add unit tests for ActionModule.run()
    pass


# Generated at 2022-06-25 07:24:21.326341
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_obj = ActionModule()
    assert not action_module_obj.run()

import pytest


# Generated at 2022-06-25 07:24:25.954124
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Unit test to ensure __init__ correctly initializes class member
    # variables
    actionModule0 = ActionModule()
    assert actionModule0._VALID_ARGS == frozenset({'seconds', 'echo', 'minutes', 'prompt'}) and actionModule0.BYPASS_HOST_LOOP == True


# Generated at 2022-06-25 07:24:32.833388
# Unit test for function clear_line
def test_clear_line():
    var_0 = '\r'
    var_1 = '\x1b[K'
    var_2 = curses.tigetstr('cr')
    var_3 = curses.tigetstr('el')
    var_4 = var_0
    var_5 = var_1
    var_6 = var_4
    var_7 = var_5
    if var_2 is None:
        var_2 = var_6
    else:
        var_2 = var_2
    if var_3 is None:
        var_3 = var_7
    else:
        var_3 = var_3
    var_8 = getpgrp()
    var_9 = tcgetpgrp(int_0)
    var_10 = var_8 == var_9
    var_11 = var_

# Generated at 2022-06-25 07:25:43.069131
# Unit test for constructor of class ActionModule
def test_ActionModule():
    print(">>")
    print(">> Running test for constructor of class ActionModule")
    print(">>")

    test_case_0()

# Invoke test_ActionModule() only if this module is invoked as a main module
if __name__ == '__main__':
    test_ActionModule()

# Generated at 2022-06-25 07:25:50.352711
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    actionbase_0 = ActionBase()
    tmp_0 = None
    task_vars_0 = dict()
    actionmodule_0 = ActionModule()
    start_0 = time.time()
    result_0 = actionmodule_0.run(tmp_0, task_vars_0)
    stop_0 = time.time()
    delta_0 = int(stop_0 - start_0)
    print("%s%s", result_0, delta_0)

# Generated at 2022-06-25 07:25:53.404572
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # define local variables
    tmp = None
    task_vars = None

    action_module = ActionModule(
        task=None,
        connection=None,
        play_context=None,
        loader=None,
        templar=None,
        shared_loader_obj=None
     )

    # unit tests for method run
    returned_obj = action_module.run(tmp=tmp, task_vars=task_vars)
    assert returned_obj is not None


# Run unit test
test_case_0()
test_ActionModule_run()

# Generated at 2022-06-25 07:26:00.628848
# Unit test for constructor of class ActionModule

# Generated at 2022-06-25 07:26:05.558149
# Unit test for function clear_line
def test_clear_line():
    int_0 = None
    var_0 = clear_line(int_0)
    assert type(var_0) == type(int_0)
    
    int_0 = -39
    var_0 = clear_line(int_0)
    assert type(var_0) == type(int_0)
    
    int_0 = -28
    var_0 = clear_line(int_0)
    assert type(var_0) == type(int_0)
    
    int_0 = -14
    var_0 = clear_line(int_0)
    assert type(var_0) == type(int_0)
    
    int_0 = -6
    var_0 = clear_line(int_0)
    assert type(var_0) == type(int_0)
    


# Generated at 2022-06-25 07:26:11.096203
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    data_0 = dict()
    data_0['tmp'] = None
    data_0['task_vars'] = dict()
    data_0['task_vars']['ansible_check_mode'] = False
    data_0['task_vars']['ansible_verbosity'] = 1
    data_0['task_vars']['ansible_version'] = dict()
    data_0['task_vars']['ansible_version']['full'] = '2.6.1'
    data_0['task_vars']['ansible_version']['major'] = 2
    data_0['task_vars']['ansible_version']['minor'] = 6
    data_0['task_vars']['ansible_version']['revision'] = 1

# Generated at 2022-06-25 07:26:12.741721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_0 = ActionModule(connection = None)
    test_case_0()


# Generated at 2022-06-25 07:26:15.193718
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule()

    # Test AnsibleTimeoutException
    try:
        module.run({}, {})
    except AnsibleError:
        pass


# Unit tests for methods in ActionModule

# Generated at 2022-06-25 07:26:16.057497
# Unit test for function clear_line
def test_clear_line():

    # Test Case 0
    test_case_0()

# Generated at 2022-06-25 07:26:19.030445
# Unit test for function clear_line
def test_clear_line():
    for int_0 in range(10):
        assert(clear_line(int_0) == True)
