

# Generated at 2022-06-25 07:18:32.263500
# Unit test for function clear_line
def test_clear_line():
    pass


# Generated at 2022-06-25 07:18:33.731767
# Unit test for function clear_line
def test_clear_line():
    var_1 = sys.stdout
    clear_line(var_1)


# Generated at 2022-06-25 07:18:36.161250
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule('test string')
    var_1 = None
    try:
        var_0.run(var_1)
    except Exception as arg_2:
        print(arg_2)
    return


# Generated at 2022-06-25 07:18:47.035819
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert(ActionModule.run.__doc__ is not None)
    var_0 = ActionModule('', {}, {}, {})
    var_0.BYPASS_HOST_LOOP = True
    var_1 = dict()
    var_2 = dict()
    var_2['changed'] = False
    var_2['delta'] = None
    var_2['rc'] = 0
    var_2['start'] = None
    var_2['stderr'] = ''
    var_2['stop'] = None
    var_2['user_input'] = b''
    var_2['echo'] = True
    var_2['stdout'] = ''
    var_3 = var_0.run(var_1, var_2)
    var_4 = dict()
    var_4['echo'] = True


# Generated at 2022-06-25 07:18:49.561088
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    print("\nTest ActionModule_run()")
    # Place your code that tests run here
    test_case_0()

# Generated at 2022-06-25 07:18:50.826940
# Unit test for function clear_line
def test_clear_line():
    stdout = sys.stdout
    clear_line(stdout)


# Generated at 2022-06-25 07:19:03.552476
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    print('')
    # Test results from the various paths through the run() method
    # are added to this list.
    tests = []

    action_module = ActionModule(
        task=dict(
            args=dict(
                echo=True,
                minutes=2,
                prompt='Are you sure?',
                seconds=None,
            ),
            name='pause',
        ),
        connection=None,
        play_context=None,
    )
    result = action_module.run()

    tests.append(
        dict(
            (k, result[k]) for k in ('changed','rc','stderr','stdout','start','stop','delta','user_input','echo','failed','msg',)
        )
    )


# Generated at 2022-06-25 07:19:05.606168
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = {}
    var_1 = {}
    var_2 = ActionModule.run(var_0, var_1)

# Generated at 2022-06-25 07:19:06.575623
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_0.run()

# Generated at 2022-06-25 07:19:13.287089
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_arg = dict()
    var_arg['prompt'] = 'prompt'
    var_arg['echo'] = False
    var_tmp = None
    var_task_vars = dict()
    var_task_vars['ansible_connection'] = 'connection'
    var_task_vars['ansible_connection_user'] = 'connection_user'
    var_task_vars['ansible_host'] = 'host'
    var_task_vars['ansible_python_interpreter'] = 'python_interpreter'
    var_task_vars['ansible_user_id'] = 'user_id'
    var_task_vars['ansible_verbosity'] = 'verbosity'
    var_task_vars['ansible_version'] = 'version'
    var_task_

# Generated at 2022-06-25 07:19:26.748345
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create an instance of ActionModule
    var_1 = ActionModule({}, {}, {})
    # Call the run method of ActionModule on an instance
    var_1.run()

# Generated at 2022-06-25 07:19:32.416644
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = is_interactive()
    var_2 = is_interactive(var_1)
    var_3 = tmp(var_2)
    var_4 = task_vars(var_3)
    # test_case_0
    var_5 = (var_4)
    #
    var_6 = var_5.copy()
    var_7 = var_6['changed']
    var_8 = not var_7
    var_6['changed'] = var_8
    var_6['rc'] = 1
    var_9 = var_6['stderr']
    var_10 = ''
    var_11 = var_9 == var_10
    var_12 = not var_11
    var_6['stderr'] = var_12

# Generated at 2022-06-25 07:19:33.490060
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_0 = ActionModule()


# Generated at 2022-06-25 07:19:39.329029
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Create the class to be tested
    obj = ActionModule('task', 'connection', 'play_context', new_stdin='new_stdin')

    # Create dummy variables for method run
    tmp = None
    task_vars = None

    # Invoke the method being tested
    result = obj.run(tmp, task_vars)

    # Check for expected result
    assert result is not None

# Generated at 2022-06-25 07:19:42.708406
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()
    var_1 = None
    var_1 = var_0.run(tmp=var_1)

# Generated at 2022-06-25 07:19:47.367237
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # test case 0
    global var_0 # get the reference to the current value of the variable
    var_0 = None # create a new value for the variable
    try:
        test_case_0()
    except Exception:
        var_0 = 'test_case_0() raised an exception'
    assert var_0 is None # make sure the test case passed

# Generated at 2022-06-25 07:19:48.762308
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a_Module = ActionModule()

test_ActionModule()
test_case_0()

# Generated at 2022-06-25 07:19:55.821537
# Unit test for method run of class ActionModule

# Generated at 2022-06-25 07:19:57.069437
# Unit test for function is_interactive
def test_is_interactive():
    var_0 = is_interactive()
    assert var_0 == False



# Generated at 2022-06-25 07:20:06.271066
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = 'echo'
    var_2 = 'seconds'
    var_3 = 'minutes'
    var_4 = 'prompt'
    var_args = {var_1: True, var_2: 0, var_3: 0, var_4: 'prompt'}
    var_5 = ActionModule(var_args)
    var_6 = var_5._VALID_ARGS
    var_7 = "foo"
    var_8 = dict(bar=var_7)
    var_9 = var_5.run(var_8)
    var_10 = "changed"
    var_11 = var_10 in var_9
    var_12 = 'bar'
    var_13 = var_9[var_12]
    var_14 = "rc"
    var_15 = var

# Generated at 2022-06-25 07:20:33.408090
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_a = ActionModule({}, {}, {})
    var_a.run()


# Generated at 2022-06-25 07:20:39.018393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    testcase = ActionModule(task=None)
    try:
        testcase.run()
    except Exception as e:
        print("Test case 0 failed.\n" + str(e))


# Generated at 2022-06-25 07:20:46.532473
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    test_args = dict(
        _connection=dict(
            _new_stdin=dict(
                buffer=dict(
                    write=test_case_0
                )
            )
        )
    )
    am = ActionModule(test_args)
    am.run()



# Generated at 2022-06-25 07:20:48.808579
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert isinstance(ActionModule('test'), ActionModule)

# Unit test to cover is_interactive

# Generated at 2022-06-25 07:20:59.280488
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    task_vars = dict(
        ii=is_interactive()
    )
    action = ActionModule(task=dict(action=dict(module='pause', args=dict(seconds=5))), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action._display = Display()
    result = action.run(tmp=None, task_vars=task_vars)
    assert result['delta'] >= int(5)
    task_vars = dict(
        ii=is_interactive()
    )
    action = ActionModule(task=dict(action=dict(module='pause', args=dict(minutes=10))), connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
   

# Generated at 2022-06-25 07:21:02.247657
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = TestActionModule()
    var_2 = {}
    var_3 = {}
    var_4 = var_1.run(var_2, var_3)

# Generated at 2022-06-25 07:21:03.602860
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule()
    assert module


# Generated at 2022-06-25 07:21:15.779518
# Unit test for function is_interactive
def test_is_interactive():
    import os
    import tempfile
    if os.isatty(sys.stdin.fileno()) and os.isatty(sys.stdout.fileno()):
        a = is_interactive()
        assert isinstance(a, bool)
    else:
        tmpfd_in, tmpname_in = tempfile.mkstemp()
        tmpfd_out, tmpname_out = tempfile.mkstemp()
        oldfd_in = os.dup(sys.stdin.fileno())
        oldfd_out = os.dup(sys.stdout.fileno())
        os.close(sys.stdin.fileno())
        os.close(sys.stdout.fileno())
        os.dup2(tmpfd_in, sys.stdin.fileno())

# Generated at 2022-06-25 07:21:19.439337
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule(None, None)
    var_1 = None
    var_2 = None
    var_0.run(var_1, var_2)


# Generated at 2022-06-25 07:21:22.037443
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule(task=None, connection=None, _play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(obj, ActionModule)

# Test case for run() method of class ActionModule

# Generated at 2022-06-25 07:22:17.596746
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_1 = ActionModule()


# Generated at 2022-06-25 07:22:20.523010
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = AnsibleTimeoutExceeded()
    var_1 = test_case_0()
    var_2 = ActionModule()
    var_3 = [{}]
    var_4 = var_2.run(var_3, var_3)
    return var_4

test_ActionModule_run()

# Generated at 2022-06-25 07:22:23.997723
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    params = dict()
    action_module = ActionModule()
    result = action_module.run(params)
    assert result is not None


# Generated at 2022-06-25 07:22:25.058489
# Unit test for function clear_line
def test_clear_line():
    # Tests for function 'clear_line'
    assert callable(clear_line)


# Generated at 2022-06-25 07:22:32.265055
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case no. 0: Test run of is_interactive method
    # Input parameter(s): None
    #
    # Expected result:
    # - call_count: 1
    # - return_value: False
    # - returned_value_count: 1
    # - returned_value: False

    assert test_case_0() == False

# Generated at 2022-06-25 07:22:42.061738
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_1 = ActionModule()
    var_1.set_runner(dict())
    var_1._task.args = {"prompt":"Press enter to continue: ","seconds":"5"}
    var_1._task.action = "pause"
    var_1._connection = object()
    var_1._connection._new_stdin = None
    var_1.run()
    var_1._task.args = {"prompt":"Press enter to continue: ","minutes":"1"}
    var_1.run()
    var_1._task.args = {"prompt":"Press enter to continue: "}
    var_1.run()

# Generated at 2022-06-25 07:22:46.174059
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module.set_options(direct=None)
    action_module.get_option = None
    action_module.run(tmp=None, task_vars=None)

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 07:22:47.373181
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

test_ActionModule()

# Generated at 2022-06-25 07:22:52.969610
# Unit test for function is_interactive
def test_is_interactive():
    test_cases = [
        {
            "input": {
                "fd": None,
            },
            "check": False
        }
    ]
    test_case_0()

    test_case_results = [False]
    for idx, t in enumerate(test_cases):
        assert test_case_results[idx] == is_interactive(**t["input"])



# Generated at 2022-06-25 07:22:54.539407
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        test_case_0()
    except Exception:
        print('Fail test_case_0')
        raise

# Generated at 2022-06-25 07:25:10.932399
# Unit test for constructor of class ActionModule
def test_ActionModule():
    temp = ActionModule()


# Generated at 2022-06-25 07:25:11.796451
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_0 = ActionModule()

    var_0.run()

# Generated at 2022-06-25 07:25:13.613380
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    match = re.match(r"[a-zA-Z]{2}", "AB")
    assert match.group(0) == "AB"

# Generated at 2022-06-25 07:25:22.098408
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    var_input = W_input()
    var_input.input_var = None
    var_input.sleep_time = None
    var_input.text = None
    var_input.stdin_fd = None
    var_input.old_settings = None
    var_input.interactive = None
    var_input.key_pressed = None
    var_input.__enter__ = W_input.__enter__
    var_input.__exit__ = W_input.__exit__
    var_input.input = W_input.input
    var_input.sleep = W_input.sleep
    var_input.read = W_input.read
    var_input.exec_file = W_input.exec_file
    var_input.new_settings = None
    var_input.backspace = None
    var_

# Generated at 2022-06-25 07:25:23.259693
# Unit test for function clear_line
def test_clear_line():
    # TODO: Change the following lines to implement the unit test
    raise Exception("Test case not implemented")


# Generated at 2022-06-25 07:25:29.009923
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    var_0 = ActionModule()
    var_1 = dict()

    var_0.run(var_1)

    var_2 = dict()
    var_2['minutes'] = 10

    var_0.run(var_2)

    var_3 = dict()
    var_3['seconds'] = 5

    var_0.run(var_3)

    var_4 = dict()
    var_4['prompt'] = 'prompt'

    var_0.run(var_4)

    var_5 = dict()
    var_5['prompt'] = 'prompt'
    var_5['seconds'] = 5

    var_0.run(var_5)

    var_6 = dict()
    var_6['prompt'] = 'prompt'

# Generated at 2022-06-25 07:25:29.817359
# Unit test for method run of class ActionModule
def test_ActionModule_run():
	assert True


# Generated at 2022-06-25 07:25:30.715723
# Unit test for constructor of class ActionModule
def test_ActionModule():
    var_271 = test_case_0()

# Generated at 2022-06-25 07:25:36.461904
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Case 0: test that the method does not error
    #         when is_interactive returns False
    #         (meaning that stdin is not interactive)

    test_0 = ActionModule()
    # intercept stdout before calling method so that
    # we can inspect the output
    sys.stdout = io.BytesIO()
    test_0.run(task_vars={'ansible_check_mode': False})
    sys.stdout.seek(0)
    output_0 = sys.stdout.read()
    sys.stdout.close()
    sys.stdout = sys.__stdout__

    lines_0 = output_0.split('\n')

# Generated at 2022-06-25 07:25:41.344015
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    action_module._task = {}
    action_module._task['args'] = {'prompt': 'prompt'}
    action_module._task['get_name'] = lambda: 'get_name'
    ansible_tmp = 'ansible_tmp'
    task_vars = {}
    result = action_module.run(ansible_tmp, task_vars)
    assert result['changed'] == False
    assert result['rc'] == 0
    assert result['stderr'] == ''
    assert result['start'] == None
    assert result['stop'] == None
    assert result['delta'] == None
    assert result['echo'] == True
    assert result['user_input'] == ''
