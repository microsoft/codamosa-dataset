

# Generated at 2022-06-21 02:37:21.310039
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    assert issubclass(AnsibleTimeoutExceeded, Exception)
    assert AnsibleTimeoutExceeded().__str__() == ""


# Generated at 2022-06-21 02:37:24.927012
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    try:
        raise AnsibleTimeoutExceeded
    except AnsibleTimeoutExceeded:
        pass
    except: # cover Py3 exception chaining
        raise


# Generated at 2022-06-21 02:37:34.559482
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils import basic

    # Create an AnsibleModule object
    basic._ANSIBLE_ARGS = None
    setattr(__builtin__, 'ANSIBLE_MODULE_ARGS', dict(echo=True, prompt='Unit test'))
    setattr(__builtin__, 'ANSIBLE_MODULE_CONSTANTS', dict())
    module = basic.AnsibleModule(argument_spec=dict())

    # Create an ActionModule object
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    action_module._task = None
    action_module._connection = None
    action_module._play_context = None
    action_module._loader = None
    action_module._templar

# Generated at 2022-06-21 02:37:37.074846
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    test_obj = AnsibleTimeoutExceeded()
    assert isinstance(test_obj, Exception)

# Generated at 2022-06-21 02:37:39.808124
# Unit test for function timeout_handler
def test_timeout_handler():
    raise AnsibleTimeoutExceeded


# Generated at 2022-06-21 02:37:40.969350
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:37:46.273252
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    try:
        raise AnsibleTimeoutExceeded
    except AnsibleTimeoutExceeded:
        pass
    except Exception as e:
        result = False
        sys.stderr.write(e.message)

    assert True

# Generated at 2022-06-21 02:37:49.263351
# Unit test for constructor of class ActionModule
def test_ActionModule():
    obj = ActionModule()
    assert obj._VALID_ARGS == frozenset(('echo', 'minutes', 'prompt', 'seconds'))


# Generated at 2022-06-21 02:37:53.811382
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(None, None)
    except AnsibleTimeoutExceeded:
        pass
    else:
        assert False, "AnsibleTimeoutExceeded was not raised by timeout_handler()"

# Generated at 2022-06-21 02:37:56.098065
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    try:
        raise AnsibleTimeoutExceeded()
    except AnsibleTimeoutExceeded as e:
        pass


# Generated at 2022-06-21 02:38:11.779566
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False

# Generated at 2022-06-21 02:38:15.681527
# Unit test for function clear_line
def test_clear_line():
    class Tester(object):
        def __init__(self):
            self.data = b''

        def write(self, data):
            self.data += data

    clear_line(Tester())
    assert Tester.data == b'\x1b[\r\x1b[K'


# Generated at 2022-06-21 02:38:18.857526
# Unit test for function timeout_handler
def test_timeout_handler():
    exc_info = None
    try:
        timeout_handler(signal.SIGALRM, None)
    except Exception as e:
        exc_info = sys.exc_info()
    assert exc_info[0] == AnsibleTimeoutExceeded

# Generated at 2022-06-21 02:38:20.763512
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(signal.SIGALRM, None)
    except AnsibleTimeoutExceeded:
        pass

# Generated at 2022-06-21 02:38:29.311457
# Unit test for function clear_line
def test_clear_line():
    # we cannot open a file with read/write access using 'with' statement in python2.6
    stdout = open('./stdout', 'w+')

    clear_line(stdout)
    stdout.seek(0)
    clear_line_result = stdout.read()
    stdout.close()

    assert(clear_line_result == '\x1b[\r\x1b[K')

# Generated at 2022-06-21 02:38:34.028157
# Unit test for function clear_line
def test_clear_line():
    from io import BytesIO

    # Create a mock stdout that can be used to capture the output from clear_line
    stdout = BytesIO()

    clear_line(stdout)
    assert stdout.getvalue() == MOVE_TO_BOL + CLEAR_TO_EOL

# Generated at 2022-06-21 02:38:43.783189
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # In this test we will create an object of class ActionModule and call
    # its run method.  The run method will take a dictionary composed of
    # the following structure:
    # {'tmp': PATH_TO_DIRECTORY, 'task_vars': {VARIABLES} }
    # In this unit test we will pass a dummy value for the task_vars and
    # a path to a text file for the tmp argument.
    import os
    import tempfile
    from ansible.module_utils._text import to_bytes

    pause = ActionModule(dict(), {}, {}, False, '/home')
    fd, tmpfile = tempfile.mkstemp()
    fd2, task_varsfile = tempfile.mkstemp()
    args = dict()
    args['minutes'] = 1
    pause._task

# Generated at 2022-06-21 02:38:48.495159
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    try:
        raise AnsibleTimeoutExceeded
    except Exception as e:
        assert e.__class__.__name__ == 'AnsibleTimeoutExceeded'

# Generated at 2022-06-21 02:38:51.693029
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    exc = AnsibleTimeoutExceeded("error")
    assert exc.args[0] == "error"


# Generated at 2022-06-21 02:39:04.558803
# Unit test for function is_interactive
def test_is_interactive():

    def _test_is_interactive(fd, expected):
        assert expected == is_interactive(fd)

    # Create a new process group
    pgid = os.getpid()
    os.setpgid(pgid, pgid)

    # Create dummy file descriptors
    stdin = os.open('/dev/null', os.O_RDWR)
    stdout = os.open('/dev/null', os.O_RDWR)

    # Test function
    _test_is_interactive(stdin, False) # stdin is not a TTY
    _test_is_interactive(stdout, False) # stdout is not a TTY

    stdin_dup = os.dup(stdin)
    stdout_dup = os.dup(stdout)


# Generated at 2022-06-21 02:39:25.444499
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    try:
        raise AnsibleTimeoutExceeded
    except AnsibleTimeoutExceeded as e:
        assert str(e) == 'AnsibleTimeoutExceeded', 'AnsibleTimeoutExceeded string representation failed'

# Generated at 2022-06-21 02:39:28.468984
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(None, None)
    except AnsibleTimeoutExceeded:
        pass

# Generated at 2022-06-21 02:39:32.762298
# Unit test for function is_interactive
def test_is_interactive():

    # Test that is_interactive returns False if given no arguments
    assert False == is_interactive()

    # Test that is_interactive returns False if stdin is not a TTY
    stdin_fd = sys.stdin.fileno()
    sys.stdin = open('/dev/null', 'r')
    assert not is_interactive(stdin_fd)
    sys.stdin = sys.__stdin__

# Generated at 2022-06-21 02:39:41.333338
# Unit test for function is_interactive
def test_is_interactive():
    """Unit test to test is_interactive func"""
    if sys.version_info[0] == 2:
        import cStringIO
        try:
            # Python 2.6+
            import unittest2 as unittest
        except ImportError:
            # Python 2.4 or 2.5
            import unittest
    else:
        import unittest
        import io

    def create_fake_file(isatty):
        class FakeFile:
            def isatty(self):
                return isatty

        return FakeFile()

    def create_fake_stdin(isatty=False, fileno_val=None):
        class FakeStdin:
            def isatty(self):
                return isatty
            def fileno(self):
                return fileno_val

        return FakeStdin()

# Generated at 2022-06-21 02:39:43.063327
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    e = AnsibleTimeoutExceeded()
    assert isinstance(e, Exception)


# Generated at 2022-06-21 02:39:45.867383
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    error = AnsibleTimeoutExceeded()
    assert isinstance(error, AnsibleError)


# Generated at 2022-06-21 02:39:54.823991
# Unit test for constructor of class ActionModule
def test_ActionModule():
    if PY3:
        raise AssertionError("Can't run unit tests on PY3")

    import __builtin__
    class Connection():
        def __init__(self):
            self._new_stdin = open('/dev/null', 'r')

    class Task():
        def __init__(self):
            self.name = 'test'
            self.args = {'echo': True, 'prompt': 'Press enter to continue'}

    am = ActionModule()
    am._connection = Connection()
    am._task = Task()
    am.run()

# Generated at 2022-06-21 02:40:02.272871
# Unit test for function is_interactive
def test_is_interactive():
    class TestFD(object):
        def __init__(self, tty_value, pgid):
            self.tty_value = tty_value
            self.pgid = pgid
        def isatty(self):
            return self.tty_value
        def tcgetpgrp(self):
            return self.pgid

    assert is_interactive(TestFD(True, 0)) == False
    assert is_interactive(TestFD(True, 1)) == False
    assert is_interactive(TestFD(True, 2)) == True

    assert is_interactive(None) == False

# Generated at 2022-06-21 02:40:13.066368
# Unit test for function is_interactive
def test_is_interactive():
    class FakeFile(object):
        def __init__(self, fake_fileno, isatty=False):
            self.fileno = fake_fileno
            self.isatty = isatty

        def isatty(self):
            return self.isatty

    # Use an arbitrary non-negative integer for file descriptors.
    test_fileno = 42

    # Test the case that getpgrp() returns something not equal to
    # tcgetpgrp(stdin_fd) and isatty() returns True.  This should return True.

# Generated at 2022-06-21 02:40:16.700672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import copy
    import tempfile
    # write a temp test file so that we can give stdin for the pause
    # module and trigger the read(1) in the is_interactive method
    test_file = tempfile.NamedTemporaryFile(prefix='ansible_test_stdin')
    test_file.write(b'\n')
    test_file.seek(0)
    test_dict = dict(
        seconds=1,
        minutes=1
    )
    test_module = copy.deepcopy(ActionModule)
    test_module.run(test_file, task_vars=test_dict)

# Generated at 2022-06-21 02:40:49.129072
# Unit test for function is_interactive
def test_is_interactive():
    # is_interactive() has to be tested using external code since it depends on
    # an external library
    pass

# Generated at 2022-06-21 02:40:50.785800
# Unit test for function is_interactive
def test_is_interactive():
    assert is_interactive(0) == is_interactive(1) == is_interactive(2)

# Generated at 2022-06-21 02:40:54.617222
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert isinstance(action._VALID_ARGS, frozenset)
    assert action._VALID_ARGS == set(('echo', 'minutes', 'prompt', 'seconds'))

# Generated at 2022-06-21 02:40:56.991070
# Unit test for constructor of class ActionModule
def test_ActionModule():
    mod = ActionModule()

    assert mod._VALID_ARGS == frozenset(('echo', 'minutes', 'prompt', 'seconds'))


# Generated at 2022-06-21 02:41:01.832638
# Unit test for function clear_line
def test_clear_line():
    class FakeStream:
        class FakeFile:
            def write(self,value):
                self.value = value

            def flush(self):
                pass

        def __init__(self):
            self.fake = self.FakeFile()

    old_stdout = sys.stdout
    fs = FakeStream()
    sys.stdout = fs
    clear_line(fs)
    sys.stdout = old_stdout

    assert fs.fake.value == b'\x1b[' + MOVE_TO_BOL + CLEAR_TO_EOL

# Generated at 2022-06-21 02:41:09.936053
# Unit test for function is_interactive
def test_is_interactive():
    assert is_interactive(0) == True
    assert is_interactive(1) == True
    assert is_interactive(2) == True
    assert is_interactive(3) == False
    assert is_interactive(4) == False
    assert is_interactive(5) == False
    assert is_interactive(6) == False
    assert is_interactive(7) == False
    assert is_interactive(8) == False

# Generated at 2022-06-21 02:41:14.632786
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(15, 1)
    except Exception as e:
        assert type(e) == AnsibleTimeoutExceeded

# Generated at 2022-06-21 02:41:20.884439
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(signal.SIGALRM, None)
    except AnsibleTimeoutExceeded:
        pass
    else:
        print("timeout_handler did not raise AnsibleTimeoutExceeded exception")
        sys.exit(1)

if __name__ == '__main__':
    test_timeout_handler()

# Generated at 2022-06-21 02:41:24.463294
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule()
    assert am is not None, "ActionModule constructor should not return None"

# Generated at 2022-06-21 02:41:30.957128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    hostname = "localhost"
    port = 22
    remote_user = 'root'
    connection = Connection(host=hostname, port=port, remote_user=remote_user)

    module_name = 'pause'

    task_vars = dict()

    # Generate args for task
    args = {'prompt': 'What is the magic word?', 'minutes':1}

    action_mock = ActionModule(connection, module_name, args, task_vars)
    try:
        action_mock.run()
    except AnsibleError:
        pass



# Generated at 2022-06-21 02:42:33.101999
# Unit test for function clear_line
def test_clear_line():
    try:
        io = sys.stdout.buffer
    except AttributeError:
        io = sys.stdout
    clear_line(io)
    return True


# Generated at 2022-06-21 02:42:35.065526
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    # This test passes if it is possible to create an instance of the exception
    AnsibleTimeoutExceeded()


# Generated at 2022-06-21 02:42:47.527732
# Unit test for function is_interactive
def test_is_interactive():
    from unittest import TestCase
    from tempfile import TemporaryFile

    class TestIsInteractive(TestCase):
        def setUp(self):
            self.tmpfile = TemporaryFile()

        def test_is_interactive_false(self):
            '''Check for false in a non-interactive environment'''
            self.assertFalse(is_interactive(self.tmpfile.fileno()))

        def test_is_interactive_true(self):
            '''Check for true in an interactive environment'''
            self.assertTrue(is_interactive(sys.stdin.fileno()))

        def tearDown(self):
            self.tmpfile.close()

    import unittest
    unittest.main()

# Generated at 2022-06-21 02:42:52.500499
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(signal.SIGALRM, None)
    except AnsibleTimeoutExceeded:
        pass
    else:
        raise Exception("AnsibleTimeoutExceeded not raised by SIGALRM")

# Generated at 2022-06-21 02:43:02.034648
# Unit test for function is_interactive
def test_is_interactive():
    if PY3:
        from os import fdopen
        from io import BytesIO
        from pty import STDOUT_FILENO, openpty

        master, slave = openpty()
        f = fdopen(master, 'rb', 0)
        assert is_interactive(slave)
        f.close()

        buf = BytesIO()
        assert not is_interactive(buf.fileno())
        buf.close()

        devnull = open('/dev/null', 'rb')
        assert not is_interactive(devnull.fileno())
        devnull.close()

        assert is_interactive(STDOUT_FILENO)
    else:
        from StringIO import StringIO
        from pty import STDOUT_FILENO
        buf = StringIO()

# Generated at 2022-06-21 02:43:05.636960
# Unit test for function timeout_handler
def test_timeout_handler():
    with pytest.raises(AnsibleTimeoutExceeded):
        timeout_handler(signal.SIGALRM, None)

# Generated at 2022-06-21 02:43:19.191891
# Unit test for function is_interactive
def test_is_interactive():
    from ansible.module_utils.basic import AnsibleModule
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch

    module = AnsibleModule(argument_spec={})

    # Pretend to be running in the background
    mock_getpgrp = patch.object(ActionModule, 'getpgrp', return_value=1)
    mock_getpgrp.start()
    mock_tcgetpgrp = patch.object(ActionModule, 'tcgetpgrp', return_value=2)
    mock_tcgetpgrp.start()
    assert is_interactive() == False

    # Pretend to be running in the foreground
    mock_tcgetpgrp.stop()

# Generated at 2022-06-21 02:43:22.083214
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Constructor is used during action plugins loading and then the object is discarded
    # and it is never used. We can only test if it obtains the config from task
    # and pass it to base class
    try:
        action_module = ActionModule({'a': 'b'}, None, None)
    except Exception as e:
        assert False, "Failed to instantiate ActionModule: %s" % str(e)

# Generated at 2022-06-21 02:43:31.246413
# Unit test for function is_interactive
def test_is_interactive():
    # is_interactive(fd) returns True if the given fd is an interactive
    # terminal. The function checks if the given fd is a TTY and if the process
    # is running in the foreground in the terminal.
    #
    # In order to test this, we need to first ensure that the current process is
    # running in the foreground in a pty. We can do this by first forking and
    # attaching the pty to the child process. We can then check that is_interactive
    # returns True for the child process's stdin fd.
    #
    # More technical details about this process can be found in the comments for
    # is_interactive.
    #
    # Make sure this test has a TTY
    try:
        assert isatty(sys.stdin.fileno())
    except Exception:
        raise

# Generated at 2022-06-21 02:43:37.157801
# Unit test for function timeout_handler
def test_timeout_handler():
    status = {'failed': False, 'msg': ''}

    try:
        timeout_handler(None, None)
    except AnsibleTimeoutExceeded:
        status['failed'] = True
        status['msg'] = 'Failed to raise exception'
        return status

    return status


# Generated at 2022-06-21 02:46:06.305886
# Unit test for function clear_line
def test_clear_line():
    class FakeStdout(object):
        def __init__(self):
            self.value = ''

        def write(self, text):
            self.value += text

    assert clear_line(FakeStdout()) == None

# Generated at 2022-06-21 02:46:14.523364
# Unit test for function is_interactive
def test_is_interactive():
    import fcntl
    import os

    # Make a pipe
    (read_fd, write_fd) = os.pipe()

    # Make the read_fd non-blocking
    flags = fcntl.fcntl(read_fd, fcntl.F_GETFL)
    fcntl.fcntl(read_fd, fcntl.F_SETFL, flags | os.O_NONBLOCK)

    # We should be interactive if there is an input device associated
    # with stdin and stdin is in the foreground process group
    assert is_interactive(0)

    # Set stdin to the read end of our pipe.  We should not be
    # interactive since we are not in the foreground process group.
    os.dup2(read_fd, 0)
    assert not is_inter

# Generated at 2022-06-21 02:46:23.969109
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class MyActionModule(ActionModule):
        def __init__(self, tmp=None, task_vars=None):
            self.run_result = {}
            self.run_task_vars = task_vars
            self.run_tmp = tmp

        def run(self, tmp=None, task_vars=None):
            self.run_result = super(MyActionModule, self).run(self.run_tmp, self.run_task_vars)
            self.run_task_vars = task_vars
            return self.run_result


# Generated at 2022-06-21 02:46:34.808414
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """Tests ActionModule's constructor"""
    display = Display()

    # Test if a valid task is created successfully by ActionModule
    task = dict(action='pause', args=dict(seconds=10, prompt="What's your name? ", echo=False))
    conn = object()
    tmp = object()
    task_vars = dict()
    action_mod = ActionModule(task, conn, tmp, task_vars)
    assert action_mod is not None
    assert action_mod._task.action == 'pause'
    assert action_mod._task.args['minutes'] is None
    assert action_mod._task.args['seconds'] == 10
    assert action_mod._task.args['prompt'] == "What's your name? "
    assert action_mod._task.args['echo'] is False
    assert action_mod._connection

# Generated at 2022-06-21 02:46:36.812239
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    args = dict(prompt='hello world')
    action = ActionModule(dict(), dict(), args, dict())
    result = action.run()
    assert result.get('msg') == None

# Generated at 2022-06-21 02:46:41.674911
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(signal.SIGALRM, None)
    except AnsibleTimeoutExceeded:
        pass
    else:
        raise AssertionError('timeout_handler did not raise AnsibleTimeoutExceeded')


# Generated at 2022-06-21 02:46:46.929049
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(None, None)
    except AnsibleTimeoutExceeded:
        pass
    else:
        assert False, "timeout_handler did not raise AnsibleTimeoutExceeded after being called"

# Generated at 2022-06-21 02:46:52.736290
# Unit test for function clear_line
def test_clear_line():
    import StringIO
    buf = StringIO.StringIO()
    buf.write(b"abc")
    clear_line(buf)
    # These two should be equivalent
    assert "\r\x1b[K" == buf.getvalue()
    assert b"\r\x1b[K" == buf.getvalue()

