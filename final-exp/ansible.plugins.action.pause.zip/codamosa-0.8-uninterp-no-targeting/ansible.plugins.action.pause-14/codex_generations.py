

# Generated at 2022-06-21 02:37:33.852197
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    ''' Test using mocker patch '''
    from ansible.plugins.action.pause import ActionModule
    from ansible.module_utils.six import PY3
    from ansible.utils.path import unfrackpath
    from ansible.module_utils.parsing.convert_bool import boolean
    from ansible.module_utils._text import to_text, to_bytes

    class MockDisplayClass(object):
        def __init__(self):
            self.messages = []
            self.progress_bar_message = None

        def display(self, msg, color=None, stderr=False, screen_only=False, log_only=False):
            self.messages.append(msg)


# Generated at 2022-06-21 02:37:40.316829
# Unit test for function is_interactive
def test_is_interactive():
    old_stdin = sys.stdin
    old_stdout = sys.stdout

    sys.stdin = open('/dev/null', 'r')
    sys.stdout = open('/dev/null', 'w')
    assert is_interactive() == False
    sys.stdin.close()

    sys.stdin = open('/dev/tty', 'r')
    sys.stdout = open('/dev/tty', 'w')
    assert is_interactive() == True
    sys.stdin.close()
    sys.stdout.close()

    sys.stdin = open('/dev/tty', 'r')
    sys.stdout = open('/dev/null', 'w')
    assert is_interactive() == False
    sys.stdin.close()


# Generated at 2022-06-21 02:37:45.010233
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(None, None)
    except AnsibleTimeoutExceeded:
        pass
    else:
        raise AssertionError("AnsibleTimeoutExceeded not raised")

# Generated at 2022-06-21 02:37:51.977446
# Unit test for function clear_line
def test_clear_line():
    class Buffer:
        def __init__(self):
            self.written = b''

        def write(self, value):
            self.written += value
            return self.written

    old_stdout = sys.stdout
    stdout = Buffer()
    sys.stdout = stdout
    try:
        clear_line(stdout)
        assert sys.stdout.written == b'\x1b[\r\x1b[K', 'Failed to clear line'
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-21 02:37:55.393976
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    # pylint: disable=invalid-name
    e = AnsibleTimeoutExceeded("timeout!!!")
    assert isinstance(e, Exception)
    assert to_text(e) == "timeout!!!"
    assert to_native(e) == "timeout!!!"

# Generated at 2022-06-21 02:38:04.014765
# Unit test for function is_interactive
def test_is_interactive():
    # isatty() returns True if fd is associated with a terminal
    # tcgetpgrp() returns the process group of the process currently
    # connected to the terminal.

    # By setting the process group of the terminal to 1, we can ensure
    # tcgetprgp() does not match getpgrp() - the calling process is not
    # a process group leader and is therefore running in the background

    # isatty() returns False if fd is 0, 1, or 2
    for fd in (0, 1, 2):
        # Calling isatty() on stdin, stdout, or stderr returns False (os.isatty())
        assert not isatty(fd), 'isatty() returns False if fd is 0, 1, or 2'

    # The process group of the terminal is always 1, so if the calling

# Generated at 2022-06-21 02:38:05.745615
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    with pytest.raises(AnsibleTimeoutExceeded):
        ansible_timeout_exceeded = AnsibleTimeoutExceeded()
        raise ansible_timeout_exceeded


# Generated at 2022-06-21 02:38:13.030626
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():

    # Test the constructor with the positionals
    try:
        raise AnsibleTimeoutExceeded("message")
    except AnsibleTimeoutExceeded as e:
        assert e.message == "message"
    else:
        assert False

    # Test the constructor without the positionals
    try:
        raise AnsibleTimeoutExceeded()
    except AnsibleTimeoutExceeded as e:
        assert e.message == "ansible task timed out"
    else:
        assert False

# Generated at 2022-06-21 02:38:24.592227
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.helpers import load_list_of_blocks
    from ansible.playbook.role.include import RoleInclude
    from ansible.playbook.role.task_include import TaskInclude as RoleTaskInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.utils.vars import combine_vars

   

# Generated at 2022-06-21 02:38:36.843909
# Unit test for function is_interactive
def test_is_interactive():
    # Create a pipe
    import os
    import os.path
    reader, writer = os.pipe()
    try:
        # On Linux, the pipe ends may be non-blocking
        import fcntl
        flags = fcntl.fcntl(reader, fcntl.F_GETFL)
        flags |= os.O_NONBLOCK
        fcntl.fcntl(reader, fcntl.F_SETFL, flags)
        flags = fcntl.fcntl(writer, fcntl.F_GETFL)
        flags |= os.O_NONBLOCK
        fcntl.fcntl(writer, fcntl.F_SETFL, flags)
    except Exception:
        pass

    # Is fd a tty?

# Generated at 2022-06-21 02:38:53.785410
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 02:38:56.343424
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch("signal.getsignal") as mock_getsignal:
        mock_getsignal.return_value = False
        timeout_handler(None, None)
        mock_getsignal.assert_called_once_with(signal.SIGALRM)


# Generated at 2022-06-21 02:39:01.265220
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    """
    Test method run of class ActionModule

    """
    from ansible.errors import AnsibleError
    from ansible.executor.task_result import TaskResult
    from ansible.module_utils._text import to_text
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.plugins.action.pause import ActionModule

    ###########################################################################
    # Test when a prompt is entered as an argument
    task = dict(action=dict(module='pause', args=dict(prompt='Please press any key...')))

    def _input_tripwire(*args, **kwargs):
        raise IOError('TEST: input was called')
    saved_input = ActionModule.action_plugins.builtin.input
    ActionModule.action_plugins.builtin.input = _input_

# Generated at 2022-06-21 02:39:04.442265
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pa_mo_ins = ActionModule()
    pa_mo_ins._task.args = {'minutes': 1}
    pa_mo_ins._connection._new_stdin = io.BytesIO()
    pa_mo_ins.run()

# Generated at 2022-06-21 02:39:17.953296
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play

    class ActionModuleMock(object):
        BYPASS_HOST_LOOP = True

    class TaskMock(object):
        def __init__(self):
            self._parent = self
            self._role = self
            self._task = self
            self._connection = self
            self.no_log = False

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, sources=['localhost,'])
    variable_manager.set_inventory(inventory)

# Generated at 2022-06-21 02:39:19.549791
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert ActionModule.run()

# Generated at 2022-06-21 02:39:26.082639
# Unit test for function clear_line
def test_clear_line():
    import cStringIO

    # Clear the line with no content
    stdout = cStringIO.StringIO()
    clear_line(stdout)
    assert stdout.getvalue() == b'\r\x1b[K'
    stdout.close()


# Generated at 2022-06-21 02:39:32.432474
# Unit test for function is_interactive
def test_is_interactive():
    class DummyConnection(object):
        _new_stdin = None

    fd = None
    try:
        dummy_connection = DummyConnection()
        dummy_connection._new_stdin = open('/dev/tty', 'rb')
        fd = dummy_connection._new_stdin.fileno()
        assert is_interactive(fd)
    except OSError:
        sys.stderr.write("Warning unable to open /dev/tty\n")
        pass
    finally:
        if fd is not None:
            dummy_connection._new_stdin.close()

# Generated at 2022-06-21 02:39:35.069597
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    exc = AnsibleTimeoutExceeded()
    assert isinstance(exc, AnsibleTimeoutExceeded)

# Generated at 2022-06-21 02:39:37.755198
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    result = AnsibleTimeoutExceeded()
    expected = "Exception('AnsibleTimeoutExceeded',)"
    assert repr(result) == expected



# Generated at 2022-06-21 02:40:11.813462
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(None, None)
    except AnsibleTimeoutExceeded:
        pass
    else:
        raise AssertionError


# Generated at 2022-06-21 02:40:18.895277
# Unit test for function is_interactive
def test_is_interactive():
    # Interactive tests are only possible in a PTY
    if not HAS_CURSES:
        return

    # Non-standard fd numbers are unlikely to be a PTY
    if is_interactive(0):
        raise AssertionError

    # TCGETPGRP returns success if fd is a PTY
    if not is_interactive(1):
        raise AssertionError

# Generated at 2022-06-21 02:40:31.229936
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Test the run method of the ActionModule class
    # Tests with 'echo'
    module = ActionModule(None, {'echo': 'yes'})
    module._task = Mock()
    module._task.get_name.return_value = 'test_task'
    module._task.args = {'echo': 'yes'}
    module._connection = Mock()
    module._connection._new_stdin = Mock()
    module._connection._new_stdin.buffer.fileno.return_value = 3
    isatty.return_value = True
    module._c_or_a = Mock()
    module._c_or_a.return_value = True

    # Test with seconds
    time.time.return_value = 1234
    result = module.run()
    assert result['delta'] == 0
    assert result

# Generated at 2022-06-21 02:40:36.010961
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(None, None)
    except AnsibleTimeoutExceeded:
        pass
    except AnsibleError:
        raise AssertionError("Unexpected exception")
    else:
        raise AssertionError("Did not get expected exception")


# Generated at 2022-06-21 02:40:37.706787
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    t = AnsibleTimeoutExceeded()
    assert str(t) == 'AnsibleTimeoutError'

# Generated at 2022-06-21 02:40:48.367324
# Unit test for function is_interactive
def test_is_interactive():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    def mock_isatty(fd):
        return fd < 4

    def mock_tcgetpgrp(fd):
        return fd

    def mock_getpgrp():
        return 0

    class FakeFile(io.BytesIO):
        def fileno(self):
            return 0

    old_isatty, builtins.isatty = builtins.isatty, mock_isatty
    old_tcgetpgrp, os.tcgetpgrp = os.tcgetpgrp, mock_tcgetpgrp
    old_getpgrp, os.getpgrp = os.getpgrp, mock_getpgrp

    assert is_interactive(0)

# Generated at 2022-06-21 02:40:50.485275
# Unit test for function timeout_handler
def test_timeout_handler():
    try:
        timeout_handler(0, 1)
    except ValueError:
        assert True
    else:
        assert False

# Generated at 2022-06-21 02:40:52.002774
# Unit test for function timeout_handler
def test_timeout_handler():
    # test exception name
    assert timeout_handler.func_name == 'timeout_handler'

# Generated at 2022-06-21 02:40:52.864055
# Unit test for function timeout_handler
def test_timeout_handler():
    assert True

# Generated at 2022-06-21 02:40:57.941202
# Unit test for function clear_line
def test_clear_line():
    import io
    import unittest

    # Mock file descriptor
    class MockFile(io.BytesIO):
        def fileno(self):
            return 1

    # Create the mock stdin and stdout
    if PY3:
        stdin = io.BufferedReader(MockFile())
        stdout = io.BufferedWriter(MockFile())
    else:
        stdin = io.BytesIO()
        stdout = io.BytesIO()

    # Run test
    clear_line(stdout)

    # Verify the stdout buffer
    stdout.seek(0)
    if PY3:
        contents = stdout.readline()
    else:
        contents = stdout.getvalue()
    assert contents == '\r\x1b[K'


# Unit test to verify the `echo` argument

# Generated at 2022-06-21 02:41:34.920453
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.basic import AnsibleModule

    # This is a very basic test for the run method of class ActionModule
    # It does not test for any errors or for the parameters of the method.
    # It only tests if it does not crash and the returned result contains
    # the correct parameters.

# Generated at 2022-06-21 02:41:36.051379
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    exc = AnsibleTimeoutExceeded()
    assert exc.message == 'AnsibleTimeoutExceeded'

# Generated at 2022-06-21 02:41:42.838778
# Unit test for function is_interactive
def test_is_interactive():
    # Set up fake file descriptor with an associated terminal
    import tempfile
    fd = tempfile.TemporaryFile()
    assert is_interactive(fd.fileno())

    # Set up fake file descriptor without an associated terminal
    fd = tempfile.TemporaryFile()
    fd.close()
    assert not is_interactive(fd.fileno())

# Generated at 2022-06-21 02:41:56.210518
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class TestActionModule_run:
        class TestActionBase:
            _task = None
            _connection = None
            def __init__(self):
                self._task = TestActionModule_run.TestTask()
                self._connection = TestActionModule_run.TestConnection()

        class TestTask:
            args = dict()
            def get_name(self):
                return "some task name"

        class TestConnection:
            _new_stdin = None
            def __init__(self):
                self._new_stdin = TestActionModule_run.TestStdin()
        class TestStdin:
            def fileno(self):
                return 0

    task_vars = dict()

    # test without any arguments

# Generated at 2022-06-21 02:41:59.523187
# Unit test for constructor of class ActionModule
def test_ActionModule():
    try:
        result = ActionModule()
    except Exception:
        result = False
    assert result == False


# Generated at 2022-06-21 02:42:08.630809
# Unit test for function clear_line
def test_clear_line():
    # Test case setup
    class StringIO(io.StringIO):
        def buffer(self):
            return self
    stdout = StringIO()

    # Write to stdout to establish a known test case
    stdout.write("This is a test")
    actual = stdout.getvalue()
    expected = "This is a test"
    assert actual == expected
    assert len(actual) == len(expected)

    # Call clear_line with the stdout StringIO object
    clear_line(stdout)

    # Check that the buffer is empty
    actual = stdout.getvalue()
    expected = ""
    assert actual == expected
    assert len(actual) == len(expected)


# Generated at 2022-06-21 02:42:18.443787
# Unit test for function clear_line
def test_clear_line():
    from io import StringIO

    class StdoutStream(object):
        def __init__(self):
            self.written_data = StringIO()

        def write(self, output):
            self.written_data.write(output)

        def flush(self):
            pass

    my_stdout = StdoutStream()
    clear_line(my_stdout)

    assert MOVE_TO_BOL in my_stdout.written_data.getvalue()
    assert CLEAR_TO_EOL in my_stdout.written_data.getvalue()

# Generated at 2022-06-21 02:42:27.716459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import os
    import tempfile
    class Task:
        def __init__(self):
            self.args = {
                'echo': 'yes'
            }
    class Connection:
        def __init__(self):
            self._new_stdin = os.fdopen(os.dup(2),'r')

    connection = Connection()
    tmp = tempfile.mkdtemp(prefix='ansible-')
    task = Task()
    am = ActionModule(task, connection, tmp, task_vars={})
    result = am.run(task_vars={})
    assert result['failed'] == False
    assert result['rc'] == 0
    assert result['stderr'] == ''
    assert result['user_input'] == u''

# Generated at 2022-06-21 02:42:35.728293
# Unit test for constructor of class ActionModule
def test_ActionModule():
    connection = MagicMock()
    task = MagicMock()
    loader = None
    templar = None

    action_module = ActionModule(connection=connection, task=task, loader=loader, templar=templar)

    assert action_module._connection == connection
    assert action_module._task == task
    assert action_module._loader == loader
    assert action_module._templar == templar


# Generated at 2022-06-21 02:42:38.785215
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    assert str(AnsibleTimeoutExceeded('a')) == 'a'


# Generated at 2022-06-21 02:43:54.414681
# Unit test for function clear_line
def test_clear_line():
    # we cannot test this function directly since it uses
    # a global variable but we can test it in the context
    # of the action module
    from ansible.module_utils.six import StringIO
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.playbook_executor import PlaybookExecutor
    import ansible.constants as C
    import json

    # execute pause module and check if clear_line was called
    module = dict(
        pause={
            'seconds': '1'
        }
    )

# Generated at 2022-06-21 02:43:55.323721
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-21 02:43:58.853114
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    try:
        raise AnsibleTimeoutExceeded
    except AnsibleTimeoutExceeded:
        pass
    else:
        raise ValueError("Failed to raise AnsibleTimeoutExceeded")


# Generated at 2022-06-21 02:44:01.419346
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    new_exception = AnsibleTimeoutExceeded()
    assert new_exception is not None

# Generated at 2022-06-21 02:44:04.578019
# Unit test for function is_interactive
def test_is_interactive():
    assert is_interactive(0) == isatty(0)
    assert is_interactive(None) == False

# Generated at 2022-06-21 02:44:10.550115
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    ansible_timeout_exceeeded_obj = AnsibleTimeoutExceeded()
    assert str(ansible_timeout_exceeeded_obj) == ''
    ansible_timeout_exceeeded_obj.args = ("asdf",)
    assert str(ansible_timeout_exceeeded_obj) == "('asdf',)"


# Generated at 2022-06-21 02:44:19.912749
# Unit test for function clear_line
def test_clear_line():
    from unittest import TestCase
    from .test_helper import TestConnection
    from .test_helper import valid_output

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            if task_vars is None:
                task_vars = dict()
            result = super(TestActionModule, self).run(tmp, task_vars)

            # Clear the output
            clear_line(self._connection._new_stdout)

            # Print the string to be cleared
            stdout = self._connection._new_stdout
            stdout.write(b'Test')
            stdout.flush()

            # Clear the string printed earlier
            clear_line(self._connection._new_stdout)
            stdout.flush()

            # Print another character
            std

# Generated at 2022-06-21 02:44:21.087428
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert not ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-21 02:44:31.127825
# Unit test for function is_interactive
def test_is_interactive():
    import os
    import tempfile

    real_stdin = sys.stdin
    real_stdout = sys.stdout
    real_stderr = sys.stderr
    real_stdin_fd = os.dup(sys.stdin.fileno())
    real_stdout_fd = os.dup(sys.stdout.fileno())


# Generated at 2022-06-21 02:44:41.922128
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import datetime
    import pytest
    import time
    import unittest
    sys.path.insert(0, './lib/ansible/module_utils/')
    from ansible.module_utils import basic

    class FakeModule(object):
        def __init__(self, **kwargs):
            self.__dict__.update(kwargs)

        def fail_json(self, **kwargs):
            self.__dict__.update(kwargs)
            raise Exception(kwargs)

    class TestAnsibleModule(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-21 02:46:08.042870
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    try:
        raise AnsibleTimeoutExceeded
    except AnsibleTimeoutExceeded:
        pass


# Generated at 2022-06-21 02:46:11.120223
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    # Arrange
    exc = AnsibleTimeoutExceeded()

    # Assert
    assert isinstance(exc, Exception)
    assert exc.__class__.__name__ == 'AnsibleTimeoutExceeded'



# Generated at 2022-06-21 02:46:17.192393
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert module.run(tmp=None, task_vars={'test': 'ok'}) == {}

# Generated at 2022-06-21 02:46:27.132678
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # import mock so we can patch builtins.__import__
    import mock

    # import modules for testing and set up mock for imports
    import modules.action.pause as pause_mod
    import modules.action.pause.ActionModule as ActionModule
    from modules.action.pause.ActionModule import test_ActionModule_run as real_test_ActionModule_run
    mock.sentinel = object()
    mock.patch.dict('sys.modules', {
        'modules.action.pause': mock.sentinel,
        'modules.action.pause.ActionModule': mock.sentinel,
        'modules.action.pause.ActionModule.test_ActionModule_run': mock.sentinel
    })

    # test that patching imports worked
    assert sys.modules['modules.action.pause'] == mock.sentinel

# Generated at 2022-06-21 02:46:35.064760
# Unit test for function is_interactive
def test_is_interactive():
    import tempfile
    import os

    tmp_file_name = tempfile.mkstemp()[1]

    # stdin default value is interactive
    assert is_interactive()

    # stdin of a TTY is interactive
    tmp_file_fd = os.open(tmp_file_name, os.O_RDONLY)
    assert is_interactive(tmp_file_fd)
    os.close(tmp_file_fd)

    # stdin of a file is not interactive
    tmp_file = open(tmp_file_name)
    assert not is_interactive(tmp_file.fileno())
    tmp_file.close()

    os.remove(tmp_file_name)

# Generated at 2022-06-21 02:46:39.038795
# Unit test for constructor of class AnsibleTimeoutExceeded
def test_AnsibleTimeoutExceeded():
    #execute
    ansibleTimeoutExceeded = AnsibleTimeoutExceeded()
    #assert
    assert isinstance(ansibleTimeoutExceeded, Exception)

# Generated at 2022-06-21 02:46:42.963430
# Unit test for function clear_line
def test_clear_line():
    # create an in-memory file-like object to test on
    from io import BytesIO
    f = BytesIO()
    clear_line(f)
    # Check that the contents are a valid terminal escape sequence
    assert f.getvalue() == b'\r\x1b[K'

# Generated at 2022-06-21 02:46:54.817924
# Unit test for function clear_line
def test_clear_line():
    '''Test helper function clear_line'''
    class FakeStdout(object):
        def __init__(self):
            self.output = b''

        def write(self, output):
            self.output += output

    # Test that output gets cleared when the terminal supports "el"
    stdout = FakeStdout()
    stdout.write(b'test')
    clear_line(stdout)
    assert(stdout.output == b'\x1b[K')

    # Test that output gets cleared when the terminal doesn't support "el"
    stdout = FakeStdout()
    stdout.write(b'test')
    CLEAR_TO_EOL = b''
    clear_line(stdout)
    assert(stdout.output == b'\r')

