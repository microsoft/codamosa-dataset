

# Generated at 2022-06-22 05:46:02.107226
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[Field()])
    assert one_of.help_text == ""
    assert one_of.name == None



# Generated at 2022-06-22 05:46:04.697928
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch(name="NeverMatch")
    result, error = field.validate_or_error(10)
    assert error == {"NeverMatch" : "This never validates."}
    assert result is None


# Generated at 2022-06-22 05:46:07.361414
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f = OneOf([])
    assert f.validate(1) == None


# Generated at 2022-06-22 05:46:18.309124
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = "foo"
    field1 = String(max_length=2)
    field2 = String(min_length=3)
    field3 = String(max_length=3)

    # Tests IfThenElse with if_clause and then_clause specified
    test_if_then1 = IfThenElse(if_clause=field1, then_clause=field2)
    test_if_then2 = IfThenElse(if_clause=field1, then_clause=field3)
    test_if_then3 = IfThenElse(if_clause=field2, then_clause=field3)
    test_if_then4 = IfThenElse(if_clause=field3, then_clause=field1)
    assert test_if_then1.validate(value) == "foo"


# Generated at 2022-06-22 05:46:25.646588
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    print('Testing method validate of class AllOf...', end='')

    assert AllOf([Integer(), String()]).validate('7') is None
    assert AllOf([Integer(), String()]).validate('foo') is None
    try:
        AllOf([Integer(), String()]).validate('f00')
        assert False # Should not get here
    except Field.ValidationError as e:
        assert e.code == 'no_match'
        assert e.path == []

    print('Passed.')


# Generated at 2022-06-22 05:46:28.866061
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    myNeverMatch = NeverMatch()
    assert isinstance(myNeverMatch, Field)
    assert isinstance(myNeverMatch.errors, dict)


# Generated at 2022-06-22 05:46:31.570784
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    m = NeverMatch()

    with pytest.raises(ValidationError, match="This never validates."):
        m.validate(None)


# Generated at 2022-06-22 05:46:37.123011
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    if_clause = Integer()
    then_clause = String()
    else_clause = Integer()
    ite = IfThenElse(if_clause, then_clause, else_clause)

    assert ite.validate(10) == "10"
    assert ite.validate("10") == "10"

# Generated at 2022-06-22 05:46:41.632930
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class TestClass(AllOf):
        def __init__(self, **kwargs):
            fields_ = [Any(), Any(), Any()]
            super().__init__(all_of=fields_, **kwargs)
    
    obj = TestClass()
    obj.validate(0)


# Generated at 2022-06-22 05:46:43.991539
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(AssertionError):
        field.validate(None, strict=True)

# Generated at 2022-06-22 05:46:50.458972
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), Field)


# Generated at 2022-06-22 05:46:58.902993
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = []
    one_of.append(String())
    one_of.append(Integer())
    one_of.append(Number())
    field_one_of = OneOf(one_of)
    field_one_of.validate(12)
    field_one_of.validate('12')
    field_one_of.validate(12.5)
    assertRaisesMessage(ValidationError, field_one_of.validate(12.4, strict=True))
    assertRaisesMessage(ValidationError, field_one_of.validate(True))
    assertRaisesMessage(ValidationError, field_one_of.validate([]))


# Generated at 2022-06-22 05:47:08.828440
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    # if_clause is true, then_clause is used.
    if_then_else = IfThenElse(Integer(), String())
    assert if_then_else.validate('1234') == '1234'

    # if_clause is false, else_clause is used.
    if_then_else = IfThenElse(Integer(), String(), Integer())
    assert if_then_else.validate(1234) == 1234

    # neither clause is used.
    if_then_else = IfThenElse(String(), Integer())
    assert if_then_else.validate(1234) == 1234

    # All clauses are used.
    if_then_else = IfThenElse(Integer(), String(), Integer(), True)

# Generated at 2022-06-22 05:47:15.565502
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf([Integer(minimum=1), Integer(maximum=10)], description="all of")
    a.validate(5)
    try:
        a.validate(15)
        raise AssertionError("a should raise a validation error")
    except (Exception) as e:
        if e.message != 'non_field_errors':
            raise AssertionError("e should be non_field_errors")
    try:
        a.validate(0)
        raise AssertionError("a should raise a validation error")
    except (Exception) as e:
        if e.message != 'non_field_errors':
            raise AssertionError("e should be non_field_errors")


# Generated at 2022-06-22 05:47:25.401084
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Integer(max_value=5)]).validate(1) == 1
    try:
        OneOf([Integer(max_value=5)]).validate(6)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        OneOf([Integer(max_value=5), String()]).validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "multiple_matches"
    assert OneOf([Integer(max_value=5), String()]).validate("hi") == "hi"


# Generated at 2022-06-22 05:47:33.287450
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # test with no error
    all_of = [Int(), Float()]
    field = AllOf(all_of)
    assert field.validate(42) == 42
    # test with error
    all_of = [Int(), Boolean()]
    field = AllOf(all_of)
    with pytest.raises(ValidationError) as e_info:
        field.validate(42)
    assert e_info.value.messages == {"all_of": "Did not match all of the valid types."}

# Generated at 2022-06-22 05:47:36.518197
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    t = NeverMatch()
    with pytest.raises(ValueError):
        t.validate(1)


# Generated at 2022-06-22 05:47:39.843103
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = [TypesystemDict(name="Person", fields={'validations': 5}), TypesystemDict(name="Person", fields={'validations': 9})]
    f = AllOf(all_of)
    assert f.validate(1) == 1



# Generated at 2022-06-22 05:47:47.006242
# Unit test for constructor of class OneOf
def test_OneOf():
    class FakeType(typesystem.Field):
        pass
    
    fake_type = FakeType()
    
    fake_list_of_fields = [fake_type]
    
    field = typesystem.Fields.OneOf(
        one_of= fake_list_of_fields
    )
    assert field.one_of == fake_list_of_fields


# Generated at 2022-06-22 05:47:48.509813
# Unit test for method validate of class Not
def test_Not_validate():
    """Unit test for method validate of class Not"""
    Not.validate(None)

# Generated at 2022-06-22 05:47:58.162855
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    instance = OneOf(one_of = [Integer(), String()])
    value = 123
    assert instance.validate(value) == value

    value = "123"
    assert instance.validate(value) == value

    value = 1.23
    with pytest.raises(instance.validation_error):
        instance.validate(value)


# Generated at 2022-06-22 05:48:09.329879
# Unit test for method validate of class Not

# Generated at 2022-06-22 05:48:15.315502
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # if clause is True
    ite = IfThenElse(String("true"))
    assert ite.validate("true") == "true"
    # if clause is False
    ite = IfThenElse(String("true"), then_clause=String("then"), else_clause=String("else"))
    assert ite.validate("else") == "else"

# Generated at 2022-06-22 05:48:20.618707
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause=String(max_length=6)
    then_clause=String(max_length=3)
    else_clause=String(max_length=2)
    
    try:
        s = IfThenElse(if_clause, then_clause, else_clause)
    except Exception as e:
        assert(False)
    

# Generated at 2022-06-22 05:48:24.612292
# Unit test for constructor of class Not
def test_Not():
    data = {"a": "b"}
    schema = Not({"a": Any()})
    schema.validate(data)
    data = {"a": "b"}
    schema = Not({"a": "b"})
    try:
        schema.validate(data)
    except:
        pass



# Generated at 2022-06-22 05:48:26.361308
# Unit test for method validate of class AllOf
def test_AllOf_validate():
  value = 123
  strict = False
  field = AllOf([Int()])
  field.validate(value, strict)

# Generated at 2022-06-22 05:48:33.812403
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    print("Testing IfThenElse constructor...")
    # Test 1
    if_clause = string_field()
    then_clause = string_field()
    else_clause = list_field()
    ifthenelse = IfThenElse(if_clause, then_clause, else_clause)
    # Test 2
    if_clause = string_field()
    ifthenelse = IfThenElse(if_clause)
    print("IfThenElse constructor passed tests")


# Generated at 2022-06-22 05:48:37.134204
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        oneof = OneOf([])
    except AssertionError as e:
        assert str(e) == "assert 'allow_null' not in kwargs"


# Generated at 2022-06-22 05:48:38.113735
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf


# Generated at 2022-06-22 05:48:44.514840
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None
    then_clause = None
    else_clause = None
    obj1 = IfThenElse(if_clause, then_clause, else_clause)
    assert obj1.if_clause == None
    assert obj1.then_clause != None
    assert obj1.else_clause != None


# Generated at 2022-06-22 05:48:48.606928
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String

    f = Not(String(max_length=10))
    assert f is not None

# Generated at 2022-06-22 05:48:50.861143
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        one_of = OneOf(one_of=[])
        return False
    except AssertionError:
        return True

test_OneOf()

#Unit test for constructor of class AllOf

# Generated at 2022-06-22 05:48:55.346050
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf(
        all_of=[String("test"), Boolean("test")]
    )
    res, _ = f.validate_or_error("test")
    assert res == "test"
    res, _ = f.validate_or_error(True)
    assert res is True
    res, _ = f.validate_or_error(False)
    assert res is False
    res, _ = f.validate_or_error("test1")
    assert res == "test1"



# Generated at 2022-06-22 05:49:00.164213
# Unit test for constructor of class Not
def test_Not():
    # test null case
    not_type = Not(Any())
    assert not_type.negated == Any()

    # test valid case
    not_type = Not(String())
    assert not_type.negated == String()

    # test invalid cases
    try:
        Not(None)
    except:
        assert True
        return
    assert False


# Generated at 2022-06-22 05:49:03.766009
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    msg = None
    try:
        n.validate(None)
    except Exception as e:
        msg = str(e)
    assert msg == "[never] This never validates."



# Generated at 2022-06-22 05:49:08.505685
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([String(), Integer()], title="OneOf field")
    data = "string"
    result = one_of.validate(data)
    # result should be equal to data since method validate returns data
    # this test is to check that data was correctly validated
    # and that no error was raised during the validation
    assert result == data


# Generated at 2022-06-22 05:49:10.709075
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated = "false")



# Generated at 2022-06-22 05:49:12.904489
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    value = "a string"
    candidate = "another string"
    field.validate(value)

# Generated at 2022-06-22 05:49:21.127662
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem

    class NotValidator(typesystem.Schema):
        not_validate = typesystem.Not(typesystem.String())

    schema = NotValidator()

    assert schema.validate({"not_validate": "5"})["not_validate"] == "5"
    assert schema.validate({"not_validate": 5})["not_validate"] == 5

    try:
        schema.validate({"not_validate": None})
        assert False
    except typesystem.ValidationError as error:
        assert error.code == "negated"



# Generated at 2022-06-22 05:49:27.168660
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Unit test for method validate of class AllOf
    """
    field = AllOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate('a') == 'a'
    error = None
    try:
        field.validate(1.1)
    except ValidationError as exc:
        error = exc
    assert error is not None
    assert error.error_code == 'invalid_type'

# Generated at 2022-06-22 05:49:33.022513
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([Field()])
    assert all_of

# Generated at 2022-06-22 05:49:45.376426
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    ifThenElse = IfThenElse(if_clause, then_clause, else_clause)
    assert ifThenElse.if_clause == if_clause
    assert ifThenElse.then_clause == then_clause
    assert ifThenElse.else_clause == else_clause
    ifThenElse = IfThenElse(if_clause, then_clause)
    assert ifThenElse.if_clause == if_clause
    assert ifThenElse.then_clause == then_clause
    assert ifThenElse.else_clause == Any()
    ifThenElse = IfThenElse(if_clause)
    assert ifThenElse.if_clause == if_clause

# Generated at 2022-06-22 05:49:47.117302
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()]).validate(1)

    # test default constructor
    isinstance(OneOf.__new__(OneOf), OneOf)

# Generated at 2022-06-22 05:49:49.108406
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [String(max_length=10)]
    assert OneOf(one_of=fields).one_of == fields

# Generated at 2022-06-22 05:49:52.851161
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    ite = IfThenElse(if_clause, then_clause, else_clause, description='json schema')
    assert ite is not None

# Generated at 2022-06-22 05:49:56.033212
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf(all_of=[])
    assert a.all_of == []

# Generated at 2022-06-22 05:49:56.674897
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-22 05:49:58.463120
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(NeverMatch.validation_error):
        Field.validate(NeverMatch())


# Generated at 2022-06-22 05:50:01.462062
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer, String
    field = AllOf([Integer, String])

    assert field.all_of[0] == Integer
    assert field.all_of[1] == String



# Generated at 2022-06-22 05:50:05.562086
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    # try to validate with `None` and expect a `ValidationError`
    try:
        not_field.validate(None)
    except ValidationError as error:
        assert str(error) == ("Field value did not validate: "
                              "Must not match.")
    else:
        assert False
    # validate with a numeric value
    not_field.validate(1)

# Generated at 2022-06-22 05:50:15.679754
# Unit test for method validate of class Not
def test_Not_validate():
   notField=Not(negated="testField")
   assert notField.errors['negated']=="Must not match."



# Generated at 2022-06-22 05:50:26.845664
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Field
    from typesystem.types import Number
    field = IfThenElse(
        if_clause=Number(),
        then_clause=Number(maximum=1),
        else_clause=Number(minimum=1)
    )
    assert field.validate(2) == 2
    assert field.validate(-1) == -1
    assert field.validate(0) == 0
    assert field.validate(0.5) == 0.5
    assert field.validate(0.99) == 0.99
    assert field.validate(-0.99) == -0.99
    assert field.validate(1.01) == 1.01
    assert field.validate(-1.01) == -1.01


# Generated at 2022-06-22 05:50:33.157680
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class Class1: pass
    class Class2: pass
    value_1 = Class1()
    value_2 = Class2()
    field_1 = OneOf(["1", "2"])
    assert field_1.validate(value_1) == ['1', '2']
    field_2 = OneOf([Class1, Class2])
    assert field_2.validate(value_2) == [Class1, Class2]

# Generated at 2022-06-22 05:50:38.507108
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_IfThenElse=IfThenElse(if_clause=False, then_clause=2, else_clause=3)
    assert test_IfThenElse.then_clause.validate(2)==2
    assert test_IfThenElse.else_clause.validate(3)==3

# Generated at 2022-06-22 05:50:41.935092
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    '''
    TESTS:
    1) raise self.validation_error("never")
    '''

# Generated at 2022-06-22 05:50:49.566482
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String
    from typesystem.fields import Number
    from typesystem.fields import Integer
    from typesystem.fields import Boolean
    from typesystem.fields import Array

    a = AllOf([String(), Number()], description="An AllOf field", required="Field is required")

    try:
        a.validate('Hello')
    except Exception as e:
        assert isinstance(e, ValueError)

    try:
        a.validate(123)
    except Exception as e:
        assert isinstance(e, ValueError)

    try:
        a.validate(True)
    except Exception as e:
        assert isinstance(e, ValueError)


# Generated at 2022-06-22 05:50:53.777986
# Unit test for method validate of class Not
def test_Not_validate():
    def test_Not_validate_sub_1():
        # Define arguments
        schema = {}
        value = {}
        strict = False

        # Evaluate operation
        result = Not(**schema).validate(value, strict)

        # Verify
        assert result == value
    try:
        test_Not_validate_sub_1()
    except Exception as e:
        assert False


# Generated at 2022-06-22 05:50:55.261290
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)
    assert field.negated is None


# Generated at 2022-06-22 05:51:05.407618
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Integer
    from typesystem import Object
    from typesystem import String
    from typesystem import fields
    # Only integers and strings allowed.
    class Number(fields.AllOf):
        schema = [Integer(), String()]
    # Only objects with name and age allowed.
    class Person(fields.AllOf):
        schema = [
            Object(
                {'name': String(), 'age': Integer()}
            )
        ]
    # Only integers and objects with name and age allowed.
    class EitherNumberOrPerson(fields.AllOf):
        schema = [Number(), Person()]

    assert EitherNumberOrPerson().validate({"name": "Walter", "age": 11})
    assert EitherNumberOrPerson().validate(1)

# Generated at 2022-06-22 05:51:14.663208
# Unit test for constructor of class OneOf
def test_OneOf():
    # noinspection PyUnusedLocal
    test_field = OneOf([
        String("hello"),
        String("how are you",help="Check if everything is fine", title="Checking"),
        String("a"),
        String("b")
    ])
    # Expected Type: <class '__main__.OneOf'>
    assert type(test_field) == OneOf
    # Expected Value: 'This never validates.'
    assert test_field.errors['never'] == "This never validates."
    # Expected Value: None
    assert test_field.one_of == [String("hello"), String("how are you",help="Check if everything is fine", title="Checking"), String("a"), String("b")]
    # Expected Value: None
    assert test_field.validate(True) == None
    # Expected

# Generated at 2022-06-22 05:51:26.730853
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate(1) == 1
    try:
        field.validate(None)
        assert False
    except Exception as error:
        assert error.detail == {'never': 'This never validates.'}


# Generated at 2022-06-22 05:51:28.579071
# Unit test for constructor of class Not
def test_Not():
    f = Not(Boolean())
    assert f.negated is Boolean()
    assert f.allow_null == True
    assert f.null_values == {None, float("nan"), float("-inf"), float("inf")}

# Generated at 2022-06-22 05:51:33.244431
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(
        [
            typesystem.Boolean(default=False),
            typesystem.Integer(),
            typesystem.String(),
            typesystem.Null(default=None),
        ]
    )
    # Tests for type String
    # Tests for type Boolean
    # Tests for type Integer
    # Tests for type Null

# Generated at 2022-06-22 05:51:43.998782
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([
        {"type": "number"},
        {"type": "string"},
    ]).validate(10) == 10
    assert OneOf([
        {"type": "number"},
        {"type": "string"},
    ]).validate("10") == "10"
    try:
        OneOf([
            {"type": "number"},
            {"type": "string"},
        ]).validate([])
        assert False
    except Exception as e:
        assert e
    try:
        OneOf([
            {"type": "number"},
            {"type": "string"},
        ]).validate(10.0)
        assert False
    except Exception as e:
        assert e

# Generated at 2022-06-22 05:51:47.737199
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf(fields = [OneOf([Int(),String()]),OneOf([Int(),String()])])
    one_of_field.validate(5)
    one_of_field.validate('asdf')

# Generated at 2022-06-22 05:51:51.150988
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = [types.Boolean(), types.Boolean()]
    of = AllOf(all_of = all_of)
    val = True
    assert of.validate(val) == val

# Generated at 2022-06-22 05:51:54.856689
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([String()], error='no_match')
    assert field.error_messages == {'no_match': 'Must match all permitted types.'}
    assert field.all_of == [String()]


# Generated at 2022-06-22 05:51:56.240939
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    aField = NeverMatch()
    returnValue = aField.validate(value=None)
    # Check outcome
    assert returnValue == None


# Generated at 2022-06-22 05:52:05.671703
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert ite.if_clause == Any()
    assert ite.then_clause == Any()
    assert ite.else_clause == Any()
    ite = IfThenElse(if_clause=Any(), then_clause=Any())
    assert ite.if_clause == Any()
    assert ite.then_clause == Any()
    assert ite.else_clause == Any()
    ite = IfThenElse(if_clause=Any())
    assert ite.if_clause == Any()
    assert ite.then_clause == Any()
    assert ite.else_clause == Any()

# Generated at 2022-06-22 05:52:07.167248
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Boolean(), String())
    field.validate(True)

# Generated at 2022-06-22 05:52:37.264371
# Unit test for constructor of class Not
def test_Not():
    class IntField(Field):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.errors = {"invalid": "xxxx"}

        def validate(self, value):
            return value

    str_field = IntField()

    not_field = Not(str_field)

    assert not_field.negated == str_field
    assert not_field.errors == {"negated": "Must not match."}


if __name__ == "__main__":
    import pytest

    pytest.main(["-s", "test_schema.py"])

# Generated at 2022-06-22 05:52:38.761964
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert True


# Generated at 2022-06-22 05:52:43.713121
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String

    ite = IfThenElse(String(max_length=3), String(max_length=5))
    print(ite.if_clause)
    print(ite.then_clause)
    print(ite.else_clause)


# Generated at 2022-06-22 05:52:47.503256
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([String(), Integer()])
    value = field.validate('a')
    assert value == 'a', f'{value} not equal to {"a"}'


# Generated at 2022-06-22 05:52:52.422837
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ifthenelse = IfThenElse(if_clause=Any())
    assert ifthenelse.if_clause.validate(1) == 1
    assert ifthenelse.then_clause.validate('1') == '1'
    assert ifthenelse.else_clause.validate(1) == 1

# Generated at 2022-06-22 05:52:53.506242
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True



# Generated at 2022-06-22 05:53:01.154750
# Unit test for method validate of class Not
def test_Not_validate():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise NotImplementedError()
    n = Not(B())
    n.validate(None)
    try:
        n.validate(1)
        raise AssertionError()
    except FieldError as e1:
        assert e1.field_name == "not"
        assert str(e1) == "Must not match."
    n = Not(A())
    try:
        n.validate(1)
        raise AssertionError()
    except FieldError as e2:
        assert e2.field_name == "not"

# Generated at 2022-06-22 05:53:06.539011
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    test_obj = IfThenElse(if_clause, then_clause, else_clause)
    assert test_obj.if_clause == if_clause
    assert test_obj.then_clause == then_clause
    assert test_obj.else_clause == else_clause

# Generated at 2022-06-22 05:53:09.411206
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match.validate(8) == 'This never validates.'


# Generated at 2022-06-22 05:53:18.690409
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Nest(Field):
        def __init__(self, cond: bool, value: typing.Any, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.cond = cond
            self.value = value

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return self.value

    # Test case 1
    if_clause = Nest(True, 2)
    then_clause = Nest(True, 3)
    else_clause = Nest(True, 4)
    conditional = IfThenElse(if_clause, then_clause, else_clause)
    assert conditional.validate(5) == 3

    # Test case 2
    if_clause = Nest

# Generated at 2022-06-22 05:53:43.915962
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    fields = [
        {"description": "OneOf field first item", "key1": "string"},
        {"description": "OneOf field second item", "key2": "string"},
        {"description": "OneOf field third item", "key3": "string"},
    ]

    value = {"key1": "one"}
    field = OneOf(
        [Dictionary(fields=fields[i]) for i in range(len(fields))],
        description="OneOf field",
    )
    field.validate(value, strict=True)

    value = {"key2": "two"}
    field = OneOf(
        [Dictionary(fields=fields[i]) for i in range(len(fields))],
        description="OneOf field",
    )
    field.validate(value, strict=True)


# Generated at 2022-06-22 05:53:50.917541
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """
    Test NeverMatch constructor
    """
    assert NeverMatch()
    assert NeverMatch(description="Hello, World")
    assert NeverMatch(description="Hello, World", name="MyNeverMatch")
    assert NeverMatch(description="Hello, World", name="MyNeverMatch", required=True)
    assert NeverMatch(description="Hello, World", name="MyNeverMatch", required=False)
    assert NeverMatch(description="Hello, World", name="MyNeverMatch", required=False, default="a")



# Generated at 2022-06-22 05:53:54.210919
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate(1) == {}


# Generated at 2022-06-22 05:53:55.982417
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(), Any(), Any())
    field.validate(1)

# Generated at 2022-06-22 05:53:57.193296
# Unit test for constructor of class OneOf
def test_OneOf():
    f = OneOf([])
    assert f.one_of == []


# Generated at 2022-06-22 05:53:59.210928
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    basic_field = NeverMatch()
    try:
        basic_field.validate(3)
    except:
        pass
    else:
        assert False


# Generated at 2022-06-22 05:54:03.178763
# Unit test for method validate of class Not
def test_Not_validate():
    s = Not(Any(gte=10))
    str(s.validate(5))
    str(s.validate(10))
    str(s.validate(20))



# Generated at 2022-06-22 05:54:05.337951
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    x = NeverMatch()
    with pytest.raises(x.validation_error):
        x.validate('some value')


# Generated at 2022-06-22 05:54:07.397629
# Unit test for method validate of class Not
def test_Not_validate():
    print('Testing method validate of class Not')
    x = Not(None)
    assert x.validate(None) is None


# Generated at 2022-06-22 05:54:18.649353
# Unit test for constructor of class OneOf
def test_OneOf():
    with pytest.raises(AssertionError):
        OneOf(one_of = [Field()], allow_null = True)
    with pytest.raises(AssertionError):
        OneOf(one_of = [Field()], allow_null = False)
    with pytest.raises(AssertionError):
        OneOf(one_of = [Field()])
    with pytest.raises(AssertionError):
        OneOf([Field()], allow_null = True)
    with pytest.raises(AssertionError):
        OneOf([Field()], allow_null = False)
    with pytest.raises(AssertionError):
        OneOf([Field()])
    OneOf(one_of = [Field()])
    OneOf([Field()])


# Generated at 2022-06-22 05:54:53.994825
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Checks IfThenElse(Field.validate)
    """
    #Setup
    if_clause = Field(allow_null=False)
    then_clause = Field(allow_null=False)
    else_clause = Field(allow_null=False)
    test_obj = IfThenElse(if_clause, then_clause, else_clause)

    #Assertion Error Case
    with pytest.raises(Field.validation_error):
        test_obj.validate("hello", True)
    
    #Normal Case
    test_obj.validate(None, True)

# Generated at 2022-06-22 05:54:57.781480
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    msg = 'assert False'
    with pytest.raises(AssertionError) as excinfo:
        raise AssertionError(msg)
    assert msg == str(excinfo.value)


# Generated at 2022-06-22 05:54:59.736597
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field=AllOf(all_of=[])
    assert field.validate(5)==5


# Generated at 2022-06-22 05:55:01.740119
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Array

    AllOf(all_of=[Array(min_length=1)])

# Generated at 2022-06-22 05:55:07.540706
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Integer, Object, String
    schema = Object(
        properties={
            "foo": Integer(),
            "bar": IfThenElse(if_clause=Object(properties={}, required=("foo",)), then_clause=String(), else_clause=Integer()),
        }
    )
    schema.validate({"bar": 1})
    schema.validate({"foo": 1, "bar": "string"})



# Generated at 2022-06-22 05:55:10.561661
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    field = Not(String())
    assert field.negated is not None

# Generated at 2022-06-22 05:55:12.346187
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field  = NeverMatch()
    assert isinstance(field, NeverMatch)

    

# Generated at 2022-06-22 05:55:15.174337
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Any())
    assert field is not None

# Generated at 2022-06-22 05:55:20.534883
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = 0
    while x < 11:
        x += 1
        if x < 5:
            assert IfThenElse(Number(min_value=3), String(), String()).validate(x) == '3'
        else:
            assert IfThenElse(Number(min_value=3), String(), String()).validate(x) == '4'


# Generated at 2022-06-22 05:55:25.600612
# Unit test for method validate of class Not
def test_Not_validate():
    # set up
    not_ = Not(negated=String())
    input_ = "not a string"
    # run
    output = not_.validate(input_)
    # assert
    assert output == "not a string"

