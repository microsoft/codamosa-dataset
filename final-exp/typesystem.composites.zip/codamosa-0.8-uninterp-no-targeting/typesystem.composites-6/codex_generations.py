

# Generated at 2022-06-22 05:45:57.375228
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    serialized = field.serialize()
    assert serialized['type'] == 'never'
    return field


# Generated at 2022-06-22 05:45:59.078078
# Unit test for constructor of class OneOf
def test_OneOf():
    s = OneOf(one_of = [1,2])
    assert s.validate(2) == 2

# Generated at 2022-06-22 05:46:00.997586
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    with pytest.raises(n.validation_error):
        n.validate(1)


# Generated at 2022-06-22 05:46:03.990475
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch("never_match")
    try:
        nm.validate("never_match")
    except AssertionError as e:
        print("Whenever this function is called, an exception is raised:", e)


# Generated at 2022-06-22 05:46:06.539683
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:46:07.315304
# Unit test for constructor of class Not
def test_Not():
    not_type = Not(None)
    assert not_type != None

# Generated at 2022-06-22 05:46:11.363115
# Unit test for method validate of class Not
def test_Not_validate():
    not_field=Not(Int())
    assert not_field.validate(2) == 2
    assert not_field.validate(2000000000) is None
    try:
        not_field.validate('string')
    except:
        assert True


# Generated at 2022-06-22 05:46:19.031430
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import typesystem
    class TestFields(typesystem.Schema):
        test = OneOf([typesystem.Integer, typesystem.Float])

    typesystem.validate_or_error(TestFields, {"test": 5})
    typesystem.validate_or_error(TestFields, {"test": 5.0})
    try:
        typesystem.validate_or_error(TestFields, {"test": "5.0"})
        assert False
    except typesystem.ValidationError:
        pass


# Generated at 2022-06-22 05:46:21.523456
# Unit test for method validate of class Not
def test_Not_validate():
    not_schema = Not(Integer())
    assert not_schema.validate("Ola") == "Ola"

# Generated at 2022-06-22 05:46:23.283794
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        NeverMatch().validate(1)
        assert(False)
    except Exception as e:
        assert(True)


# Generated at 2022-06-22 05:46:35.593736
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Integer
    from typesystem.errors import ValidationError
    from typesystem.fields import Not
    from typesystem import Schema

    class NotInteger(Schema):
        field_a = Not(Integer())
    
    #test valid case
    test_schema = NotInteger()
    try:
        test_schema.validate({'field_a': 1.0})
    except ValidationError:
        assert False
    #test not integer case
    try:
        test_schema.validate({'field_a': 1})
        assert False
    except ValidationError:
        return


# Generated at 2022-06-22 05:46:39.116784
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    is_valid = IfThenElse(
        Int(max_value=4),
        Int(additional_properties=True),
        Int(additional_properties=False))
    is_valid.validate(5)

# Generated at 2022-06-22 05:46:46.745162
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestField(Field):
        errors = {"test_field": "This is a test error"}
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise self.validation_error("test_field")
    test_field = TestField()
    with_test_field = IfThenElse(test_field, then_clause=Any(), else_clause=Any())
    _, error = with_test_field.validate_or_error("A string", strict=True)
    assert error == "This is a test error"

# Generated at 2022-06-22 05:46:58.002591
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    value_valid = [None, 'a', 1, [1, 2, 3], {'a': 'b'}, True, False]
    value_invalid = ['abc', 'abc', 'abc', 'abc', 'abc', 'abc', 'abc']
    tag = 'negated'
    for i in range(len(value_valid)):
        try:
            field.validate(value_valid[i])
        except Exception as e:
            assert False, {
                'message': 'Not should validate ' + str(value_valid[i]) + ' as a valid value',
                'exception': str(e)
            }

# Generated at 2022-06-22 05:47:01.998986
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    assert AllOf([String(), String()]).all_of == [String(), String()]



# Generated at 2022-06-22 05:47:04.040836
# Unit test for constructor of class Not
def test_Not():
    bool_field = Not(SomeField())
    assert bool_field.negated == SomeField()


# Generated at 2022-06-22 05:47:11.746607
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.base.types import Number
    from typesystem.decorators import validator

    class MyField(IfThenElse):
        if_clause = Number(maximum=10)
        then_clause = Number(minimum=5)
        else_clause = Number(minimum=20)

    field = MyField()

    # test if_clause
    assert field.validate(9) == 9
    assert field.validate(200) == 200

    # test else_clause
    assert field.validate(11) == 11

    # test then_clause
    assert field.validate(6) == 6


# Generated at 2022-06-22 05:47:13.807249
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Field())
    output = field.validate([1,2,3])
    assert output == [1,2,3]


# Generated at 2022-06-22 05:47:15.427138
# Unit test for constructor of class Not
def test_Not():
    field_test = Not(negated = Any())
    # test correct initialization
    assert field_test.negated == Any()


# Generated at 2022-06-22 05:47:20.085086
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(max_length=1), String(max_length=2)], )
    assert field.validate('abc') == 'abc'


# Generated at 2022-06-22 05:47:26.005063
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    response = field.validate('test_string')
    assert response == None



# Generated at 2022-06-22 05:47:33.699076
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(type="string")
    then_clause = Field(type="int")
    else_clause = Field(type="boolean")
    ifThenElse = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    assert ifThenElse.validate("abc") == "abc"
    assert ifThenElse.validate(1) == 1
    assert ifThenElse.validate(True) == True

# Generated at 2022-06-22 05:47:36.567413
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(AllOf([Any()]), nullable=False)
    not_.validate(1)


# Generated at 2022-06-22 05:47:38.615912
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    instance = NeverMatch()
    with pytest.raises(instance.validation_error):
        instance.validate('a string')

# Generated at 2022-06-22 05:47:40.989123
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never":"This never validates."}

# Generated at 2022-06-22 05:47:42.443612
# Unit test for constructor of class OneOf
def test_OneOf():
    # Add your own tests here
    print("Test passed")

if __name__ == "__main__":
    test_OneOf()

# Generated at 2022-06-22 05:47:48.758222
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Integer(), String()])
    field.validate(1)
    field.validate('a string')
    with raises(ValidationError):
        field.validate(1.1)
    with raises(ValidationError):
        field.validate(True)
    with raises(ValidationError):
        field.validate({'foo': 'bar'})

# Generated at 2022-06-22 05:47:52.896169
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Create a field object
    field = NeverMatch()
    # Assert that the default values are correct
    assert field.name == "NeverMatch"
    assert field.description is None
    assert field.required is False
    assert field.allow_null is False
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:47:54.483875
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(1) is 1


# Generated at 2022-06-22 05:48:03.040108
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(AllOf([String(min_length=1), String(min_length=2)]))
    assert field.validate("a") is None
    assert field.validate("") is None
    assert field.validate("ab") is None
    field = Not(AllOf([String(min_length=1), String(max_length=1)]))
    assert field.validate("") is None
    assert field.validate("a") is None
    assert field.validate("ab") is None
    field = Not(AllOf([String(min_length=1), String(max_length=1)]))
    assert field.validate("") is None
    assert field.validate("") is None
    assert field.validate("") is None


# Generated at 2022-06-22 05:48:06.862386
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-22 05:48:09.425458
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    allof = AllOf([String(),Integer()])
    value = "123"
    assert(allof.validate(value) == "123")


# Generated at 2022-06-22 05:48:13.358720
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Creating a NeverMatch object with no error messages
    obj = NeverMatch("test")
    assert obj.label == "test"
    assert obj.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:48:17.432319
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.errors import ValidationError
    from typesystem.validators import Minimum
    from typesystem.fields import Bool
    IfThenElse(Bool(default='false'), Integer(Minimum(10))).validate(2)

# Generated at 2022-06-22 05:48:26.311163
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.errors import ValidationError

    def assert_no_validation_error(error: ValidationError):
        assert error.errors == {}
        assert error.path == ()

    not_integer = Not(Integer())
    assert not_integer.validate(None) is None
    # match_count = 0
    _, error = not_integer.validate_or_error(1)
    assert_no_validation_error(error)

    _, error = not_integer.validate_or_error("abc")
    assert_no_validation_error(error)

    _, error = not_integer.validate_or_error(1.0)
    assert_no_validation_error(error)

    # Not(Object({"a": Integer()}))
    # Not(Object({"a": Integer

# Generated at 2022-06-22 05:48:27.889704
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    with pytest.raises(AssertionError):
        IfThenElse(Field())

# Generated at 2022-06-22 05:48:29.388801
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()


# Generated at 2022-06-22 05:48:35.110756
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[])
    assert one_of.name == None
    assert one_of.description == None
    assert one_of.one_of == []
    assert one_of.allow_null == False
    assert one_of.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}
    assert one_of.formats == {}


# Generated at 2022-06-22 05:48:36.953515
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())

# Generated at 2022-06-22 05:48:39.233929
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    instance = AllOf([AllOf([])])
    assert instance.validate([], strict=False) == []



# Generated at 2022-06-22 05:48:49.606769
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        Not(negated=Field(), allow_null=True)



# Generated at 2022-06-22 05:48:54.118928
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Integer])

    # Should raise for no match
    with pytest.raises(ValidationError) as e:
        field.validate('abc')
    assert e.value.code == 'no_match'

    # Should raise for multiple matches
    with pytest.raises(ValidationError) as e:
        field.validate(1.1)
    assert e.value.code == 'multiple_matches'

    # Should pass for single match
    assert field.validate(1) == 1

# Generated at 2022-06-22 05:48:57.691542
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf
    # self, all_of: typing.List[Field]
    f = AllOf([])
    assert f


# Generated at 2022-06-22 05:48:59.076182
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf()


# Generated at 2022-06-22 05:49:02.016737
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        NeverMatch().validate("")
        assert False
    except:
        assert True


# Generated at 2022-06-22 05:49:03.389061
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # NeverMatch test 1
    NeverMatch().validate(None)



# Generated at 2022-06-22 05:49:05.156394
# Unit test for constructor of class OneOf
def test_OneOf():  
  one_of = OneOf([Int(), String()])
  assert one_of


# Generated at 2022-06-22 05:49:09.106320
# Unit test for constructor of class OneOf
def test_OneOf():
    name = "name"
    field = OneOf([Field(name=name, required=True)], name=name)
    assert field.name == name
    assert field.one_of == [Field(name=name, required=True)]
    assert field.required == False


# Generated at 2022-06-22 05:49:12.625088
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = 3
    b = 3
    s = IfThenElse(if_clause=(a == b))
    assert(4, s.validate(4))
    assert(5, s.validate(5))

# Generated at 2022-06-22 05:49:16.629947
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.types import String
    field1 = String()
    field2 = String()
    inputs = [field1, field2]

    all_of = AllOf(inputs, name="name")


# Generated at 2022-06-22 05:49:25.563501
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    value = "Hi there"
    result, error = field.validate_or_error(value)
    assert error
    assert result == value
    error = field.validate_or_error(2)[1]
    assert not error

# Generated at 2022-06-22 05:49:27.462671
# Unit test for constructor of class OneOf
def test_OneOf():
    x = OneOf([Field()])
    assert isinstance(x, OneOf)



# Generated at 2022-06-22 05:49:28.340704
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True == True

# Generated at 2022-06-22 05:49:30.820896
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert(all_of.all_of == [])



# Generated at 2022-06-22 05:49:42.094071
# Unit test for constructor of class OneOf
def test_OneOf():
    import typesystem.error_messages as error_messages
    from typesystem.fields import Integer

    one_of = OneOf(one_of=[Integer()])
    assert one_of.one_of == [Integer()]

    one_of = OneOf(one_of=[Integer(), Integer()])
    assert one_of.one_of == [Integer(), Integer()]

    one_of = OneOf(one_of=[Integer(), Integer()])
    assert one_of.one_of == [Integer(), Integer()]

    one_of = OneOf(one_of=[Integer()])
    assert one_of.one_of == [Integer()]

    one_of = OneOf(one_of=[Integer(error_messages=error_messages.DEFAULT_ERROR_MESSAGES)])
    assert one_of.one

# Generated at 2022-06-22 05:49:44.731337
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    #create the instance object of class AllOf
    all_of = AllOf()
    #try to validate a list of types and value returns None
    assert all_of.validate([1,2,3,4,5]) == None

# Generated at 2022-06-22 05:49:48.494132
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field_1 = Integer()
    field_2 = String()
    field_3 = Number()
    field_4 = AllOf([field_1, field_2, field_3])
    result, error = field_4.validate_or_error(1, strict=False)
    assert result == 1
    assert error is None


# Generated at 2022-06-22 05:49:49.460149
# Unit test for constructor of class Not
def test_Not():
    assert(Not.__init__)



# Generated at 2022-06-22 05:49:50.924477
# Unit test for constructor of class OneOf
def test_OneOf():
    assert type(OneOf([])).__name__ is "OneOf"

# Generated at 2022-06-22 05:49:54.356355
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    try:
        assert False, "unreachable"
    except AssertionError:
        _err = sys.exc_info()
        raise _err[0](_err[1]).with_traceback(_err[2])


# Generated at 2022-06-22 05:50:00.794566
# Unit test for constructor of class Not
def test_Not():
    assert (Not(negated = Int())).negated == Int()


# Generated at 2022-06-22 05:50:02.943791
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of=[])


# Generated at 2022-06-22 05:50:13.413573
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import sys
    import os
    import pytest

    curPath = os.path.abspath(os.path.dirname(__file__))
    rootPath = os.path.split(curPath)[0]
    sys.path.append(rootPath)

    from typesystem.fields.tests.test_field import TestField

    class TestIfThenElse(TestField, IfThenElse):
        pass

    class TestA:
        pass

    class TestB:
        pass

    test1 = TestIfThenElse(if_clause=TestField(cls=TestField), then_clause=TestField(cls=TestA))
    assert isinstance(test1.if_clause, TestField)
    assert isinstance(test1.then_clause, TestField)

# Generated at 2022-06-22 05:50:14.732394
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([]).validate(123)



# Generated at 2022-06-22 05:50:17.491397
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([Field(description="description")])
    assert one_of.description == "description"

# Generated at 2022-06-22 05:50:18.142258
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert True

# Generated at 2022-06-22 05:50:19.387428
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    NeverMatch().validate("a", strict=False)

# Generated at 2022-06-22 05:50:23.612598
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated="hello")
    assert n.validate("goodbye") == "goodbye"
    # This is the only thing I can't test!
    # assert n.validate("hello") == "hello"


# Generated at 2022-06-22 05:50:26.842838
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch(name="test")
    try:
        field.validate(1)
    except Exception as e:
        assert e.code == field.errors["never"]


# Generated at 2022-06-22 05:50:30.272934
# Unit test for method validate of class Not
def test_Not_validate():
    false = Not(negated=Any())
    value = false.validate({})
    assert value == {}



# Generated at 2022-06-22 05:50:39.496101
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    assert f.validate("abc") == "abc"
    try:
        f.validate(None)
        raise AssertionError
    except (TypeError, ValueError):
        pass


# Generated at 2022-06-22 05:50:41.115104
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors['never'] == 'This never validates.'



# Generated at 2022-06-22 05:50:42.787581
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf([Any()])
    all_of.validate(None)


# Generated at 2022-06-22 05:50:44.219676
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Any())

# Generated at 2022-06-22 05:50:46.073957
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        Not(S().allow_null(True))

# Generated at 2022-06-22 05:50:50.343305
# Unit test for constructor of class OneOf
def test_OneOf():
    null = None
    d = {'one_of': [null]}
    o = OneOf(one_of=d['one_of'])
    assert o.one_of == d['one_of']


# Generated at 2022-06-22 05:50:53.885671
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(type(1), type(""))
    value = 1
    assert type(field.validate(value)) is int
    value = ""
    assert type(field.validate(value)) is str

# Generated at 2022-06-22 05:50:58.387613
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(negated=Field())
    assert not_.validate(value=True) is True
    assert not_.validate(value=Field()) is Field()
    assert not_.validate(value=Not(negated=Field())) is Not(negated=Field())
    

# Generated at 2022-06-22 05:51:01.127089
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(json.loads("{'type': 'integer'}"),"","")
    assert ite.validate("1") == "1"

# Generated at 2022-06-22 05:51:02.380070
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True)


# Generated at 2022-06-22 05:51:14.569321
# Unit test for constructor of class OneOf
def test_OneOf():
    a = "abc"
    assert a == a

# Generated at 2022-06-22 05:51:17.819557
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    type = NeverMatch()
    input = 1
    # Here check if output == input
    output = type.validate(input, strict = False)
    assert output == input


# Generated at 2022-06-22 05:51:28.726490
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Case 1: if_clause, then_clause and else_clause are values
    if_clause = 23
    then_clause = "hello"
    else_clause = 23.3
    schema = IfThenElse(if_clause, then_clause, else_clause)
    assert schema.validate(23) == "hello"
    assert schema.validate(34) == 23.3

    # Case 2: if_clause is a value and then_clause and else_clause is a
    # Fields
    if_clause = 23
    then_clause = Any()
    else_clause = List(Any())
    schema = IfThenElse(if_clause, then_clause, else_clause)
    assert schema.validate(23)

    # Case 3: if_cl

# Generated at 2022-06-22 05:51:31.010132
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_field = NeverMatch()
    assert test_field.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:51:38.399341
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Test that Not.validate works correctly.
    """
    from typesystem.fields import String
    
    field = Not(String(max_length=3))
    assert field.validate("Short string") is None
    assert field.validate("Long string") == "Long string"

    field = Not(String(allow_null=True))
    assert field.validate(None) is None
    assert field.validate("Test") == "Test"


# Generated at 2022-06-22 05:51:41.392612
# Unit test for method validate of class Not
def test_Not_validate():
    try:
        Not(Any()).validate("not the right value")
        assert False
    except FieldValidationError:
        assert True

# Generated at 2022-06-22 05:51:42.384255
# Unit test for constructor of class Not
def test_Not():
    not_type = Not(String())


# Generated at 2022-06-22 05:51:47.637704
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([1, "hi", 1.5])
    assert a.one_of == [1, "hi", 1.5]
    assert a.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert a.allow_null == False


# Generated at 2022-06-22 05:51:51.414670
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    with pytest.raises(ValidationError) as ex:
        f.validate(9)
    assert ex.value.detail == {"never": "This never validates."}


# Generated at 2022-06-22 05:51:54.289851
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause=String(),
        then_clause=String(),
        else_clause=Integer()
    )

# Generated at 2022-06-22 05:52:45.490095
# Unit test for method validate of class AllOf
def test_AllOf_validate():

    field = AllOf()
    assert field.validate(False) == False



# Generated at 2022-06-22 05:52:54.424424
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    testArgs = (
        {
            "one_of": [],
            "if_clause": Field(),
            "then_clause": Field(),
            "else_clause": Field(),
            "negated": Field(),
            "all_of": [],
            "type": "boolean",
            "description": "test",
            "format": "test",
            "title": "test",
            "help_text": "test",
        },
    )
    with pytest.raises(AssertionError):
        NeverMatch(*testArgs)



# Generated at 2022-06-22 05:52:58.484498
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    t = NeverMatch()
    with pytest.raises(AssertionError):
        t.validate(None)
    with pytest.raises(AssertionError):
        t.validate(1)


# Generated at 2022-06-22 05:53:04.248419
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()

    try:
        IfThenElse(if_clause, then_clause, else_clause, allow_null=True)
        assert False
    except AssertionError:
        assert True

    try:
        IfThenElse(if_clause, then_clause, else_clause)
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-22 05:53:15.834562
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class MyField(Field):
        pass
    
    f = IfThenElse(MyField)
    assert isinstance(f, IfThenElse)
    assert f.if_clause == MyField
    assert f.then_clause == Any()
    assert f.else_clause == Any()
    
    f = IfThenElse(MyField, MyField)
    assert isinstance(f, IfThenElse)
    assert f.if_clause == MyField
    assert f.then_clause == MyField
    assert f.else_clause == Any()
    
    f = IfThenElse(MyField, MyField, MyField)
    assert isinstance(f, IfThenElse)
    assert f.if_clause == MyField
    assert f.then_clause == MyField
    assert f.else_clause

# Generated at 2022-06-22 05:53:19.475376
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(AssertionError, match='never'):
        field.validate("example")


# Generated at 2022-06-22 05:53:23.626351
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer
    try:
        OneOf([Integer()]).validate(1)
    except Exception as e:
        assert type(e) == TypeError
        assert str(e) == "__init__() missing 1 required positional argument: 'one_of'"


# Generated at 2022-06-22 05:53:31.826072
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    value = {"foo": "bar"}
    field = AllOf([Any(default={"foo": "bar"})])
    try:
        field.validate(value)
    except Exception as e:
        assert False, "Unexpected Exception: {}".format(e)
    value = {"foo": "bar"}
    field = AllOf([Any(default={"foo": "bar"}), Any(default={"foo": "bar"})])
    try:
        field.validate(value)
    except Exception as e:
        assert False, "Unexpected Exception: {}".format(e)
    value = {"bar": "foo"}
    field = AllOf([Any(default={"foo": "bar"}), Any(default={"foo": "bar"})])

# Generated at 2022-06-22 05:53:43.226714
# Unit test for constructor of class Not
def test_Not():
    import typesystem
    Not = typesystem.fields.Not
    List = typesystem.fields.List
    T = typesystem.types.Text
    char_list = List(T(format="char"))

    # trying to create an instance with a wrong type of negated
    try:
        instance = Not(negated=T())
    except TypeError as err:
        assert "negated must be an instance of Field" in str(err)
    else:
        assert False, "Did not catch exception"

    # trying to create an instance with a correct type of negated
    instance = Not(negated=char_list)
    assert isinstance(instance, typesystem.fields.BaseField)
    assert isinstance(instance.negated, typesystem.fields.List)
    assert instance.negated.items.__class__ == typesystem.types

# Generated at 2022-06-22 05:53:54.455586
# Unit test for constructor of class Not
def test_Not():
    # set up dict
    import json
    import os

    filename = "test_Not.json"
    if os.path.isfile(filename):
        os.remove(filename)

    # use the appropriate arg to set the object
    test_obj = Not(negated=True)

    # dump to json file
    with open(filename, "a") as outfile:
        json.dump(test_obj.to_primitive(), outfile)

    # compare with expected
    expected_filename = "expected_" + filename
    if os.path.isfile(expected_filename):
        import filecmp

        if filecmp.cmp(filename, expected_filename):
            print("test_Not: PASS")
        else:
            print("test_Not: FAIL")

# Generated at 2022-06-22 05:54:47.304545
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a is not None


# Generated at 2022-06-22 05:54:51.841661
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Any(), Any()]
    all_schema = AllOf(all_of)
    assert all_schema.all_of == all_of

    all_schema = AllOf(all_of, description="It's a schema")
    assert all_schema.all_of == all_of
    assert all_schema.description == "It's a schema"



# Generated at 2022-06-22 05:54:54.092833
# Unit test for method validate of class Not
def test_Not_validate():
    negated = AllOf([Any()])
    obj = Not(negated)
    assert obj.negated == negated

# Generated at 2022-06-22 05:55:00.951106
# Unit test for method validate of class Not
def test_Not_validate():
    # test that Not validates if negated does not match
    negated = Field()
    negated.validate_or_error = lambda value, strict: (None, 'error')
    not_negated = Not(negated)
    assert not_negated.validate(None) == None

    # test that Not raises a validation error if negated matches
    assert_raises(Field.validation_error, not_negated.validate, None)

# Generated at 2022-06-22 05:55:11.168609
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Field(True), then_clause=Field(True), else_clause=Field(False)).validate(True) == True
    assert IfThenElse(if_clause=Field(False), then_clause=Field(True), else_clause=Field(False)).validate(True) == False
    assert IfThenElse(if_clause=Field(True)).validate(True) == True
    assert IfThenElse(if_clause=Field(True), then_clause=Field(False)).validate(True) == False
    assert IfThenElse(if_clause=Field(False), else_clause=Field(False)).validate(True) == False


# Generated at 2022-06-22 05:55:13.742116
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Field(), Field())
    assert field.if_clause
    assert field.then_clause
    assert field.else_clause


# Generated at 2022-06-22 05:55:16.222484
# Unit test for method validate of class Not
def test_Not_validate():
    test = Not('a')
    assert test.validate('a') == 'a'

# Generated at 2022-06-22 05:55:16.720079
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass

# Generated at 2022-06-22 05:55:27.327447
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    ifThenElse1 = IfThenElse(if_clause=Field(type="string", max_length=20), then_clause=Field(type="string", max_length=10))
    try:
        ifThenElse1.validate(value="no", strict=False)
    except ValidationError:
        pass
    else:
        assert False


    ifThenElse2 = IfThenElse(if_clause=Field(type="string", max_length=20), then_clause=Field(type="string", max_length=10))
    try:
        ifThenElse2.validate(value="no", strict=False)
    except ValidationError:
        pass
    else:
        assert False



# Generated at 2022-06-22 05:55:29.455869
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}
