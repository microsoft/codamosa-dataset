

# Generated at 2022-06-22 05:46:03.691886
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-22 05:46:05.806841
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    # Act

    # Assert
    pass


# Generated at 2022-06-22 05:46:07.739492
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:46:09.690822
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    obj = NeverMatch()
    assert obj.validate("foo") == "foo"



# Generated at 2022-06-22 05:46:10.749182
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(1, 1, 1)

# Generated at 2022-06-22 05:46:15.205736
# Unit test for constructor of class AllOf
def test_AllOf():
    # instance = AllOf(all_of: typing.List[Field], **kwargs: typing.Any) -> None
    instance = AllOf(all_of=[], allow_null=True, default=True, description=True, enum=[True])
    assert isinstance(instance, AllOf)

# Generated at 2022-06-22 05:46:23.084728
# Unit test for constructor of class Not
def test_Not():
    from jsonclasses import jsonclass, JSONObject, types

    @jsonclass(class_graph='test_graph_Not_1')
    class NotSchema(JSONObject):
        field: types.not_(types.str.with_metadata(metadata={'$ref': '#/definitions/Field1'}))

    try:
        NotSchema.validate_json({'field': 'test_string'})
        assert False
    except ValueError:
        assert True
    else:
        assert False, 'expected error'


# Generated at 2022-06-22 05:46:33.680375
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    import json
    str_field = String(max_length=10)
    all_field = AllOf([str_field])
    assert all_field.name == None
    assert all_field.description == None
    assert all_field.all_of == [str_field]
    assert all_field.name == None
    assert all_field.description == None
    assert json.loads(json.dumps(all_field.get_schema())) == {
        '$schema': 'http://json-schema.org/draft-07/schema#',
        'allOf': [
            {
                'maxLength': 10,
                'type': 'string'
            }
        ],
        'type': 'object'
    }

# Generated at 2022-06-22 05:46:35.584903
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=field)
    assert field.clean(None) == None

# Generated at 2022-06-22 05:46:38.246354
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Given
    test = OneOf([Field], name="test")
    # When
    # Then
    assert test.validate("test") == "test"

# Generated at 2022-06-22 05:46:43.540627
# Unit test for constructor of class OneOf
def test_OneOf():
    myOneOf = OneOf(field1, field2)
    assert myOneOf.one_of == [field1, field2]


# Generated at 2022-06-22 05:46:44.897924
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([Field()]).all_of == [Field()]

# Generated at 2022-06-22 05:46:46.034728
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass


# Generated at 2022-06-22 05:46:49.270475
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.__dict__ == {'name': 'NeverMatch', 'errors': {'never': 'This never validates.'}, 'required': True, 'context': None, 'allow_null': False}


# Generated at 2022-06-22 05:46:51.774752
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    data = 5
    field = OneOf([])
    assert field.validate(data) == data


# Generated at 2022-06-22 05:46:55.586321
# Unit test for method validate of class Not
def test_Not_validate():
    class ChildField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value + 1

    test_field = Not(ChildField())
    assert test_field.validate(0) == 0

# Generated at 2022-06-22 05:46:57.045199
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    i = IfThenElse(Any(),Integer(),Integer())
    assert type(i) == IfThenElse


# Generated at 2022-06-22 05:47:04.691807
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Schema, String
    from typesystem.fields import Not
    from typesystem.exceptions import ValidationError

    class PersonSchema(Schema):
        name = String()
        age = Not(String())

    person = PersonSchema(
        {
            "name": "John",
            "age": 'I am a string, but I should raise an error'
        }
    )
    try:
        person.validate()
    except ValidationError as e:
        assert e.field == 'age'
        assert e.value == 'I am a string, but I should raise an error'
        assert e.code == 'negated'
    else:
        assert False, 'ValidationError should have been raised'


# Generated at 2022-06-22 05:47:06.429165
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()])

# Generated at 2022-06-22 05:47:12.149327
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import unittest

    class TestAllOf_validate(unittest.TestCase):
        def test_it(self):

            # Arrange
            all_of = []
            kwargs = {}
            field = AllOf(all_of=all_of, **kwargs)
            value = None
            strict = False

            # Act
            result = field.validate(value=value, strict=strict)

            # Assert
            self.assertEqual(result, None)


    unittest.main()

# Generated at 2022-06-22 05:47:22.192521
# Unit test for constructor of class Not
def test_Not():
    # Test valid values
    negated = Number()
    not_field = Not(negated)
    data = 1
    not_field.validate(data)

    # Test exception
    data = 2
    raises(ValidationError, not_field.validate, data)

# Generated at 2022-06-22 05:47:23.998670
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(NeverMatch.validation_error):
        NeverMatch().validate('abc')


# Generated at 2022-06-22 05:47:26.978120
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Boolean, Integer
    a = AllOf([Boolean(), Integer()])
    assert a is not None


# Generated at 2022-06-22 05:47:36.254623
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([lambda _: _])

    print("type(field): {}".format(type(field)))
    print("type(field.validate): {}".format(type(field.validate)))
    print("type(field.all_of): {}".format(type(field.all_of)))
    # type(field): <class 'typesystem.contrib.draft7_extras.AllOf'>
    # type(field.validate): <class 'method'>
    # type(field.all_of): <class 'list'>

    assert type(field) == AllOf
    assert type(field.validate) == method
    assert type(field.all_of) == list



# Generated at 2022-06-22 05:47:37.255338
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert True


# Generated at 2022-06-22 05:47:38.917573
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    val = OneOf(one_of=[String()]).validate(1)
    assert val == 1

# Generated at 2022-06-22 05:47:41.877689
# Unit test for constructor of class AllOf
def test_AllOf():
    test = AllOf(all_of = [Field()])
    assert test is not None


# Generated at 2022-06-22 05:47:43.243452
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NoneMatch()



# Generated at 2022-06-22 05:47:47.643410
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Object()
    then_clause = Object()
    else_clause = Object()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(None) is None

# Generated at 2022-06-22 05:47:50.618387
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String

    field = IfThenElse(String().min_length(2), then_clause=String().max_length(3))
    field.validate("AB")



# Generated at 2022-06-22 05:47:55.646702
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError, match='This never validates.'):
        field.validate(data)


# Generated at 2022-06-22 05:48:05.683894
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
   Unit test for method validate of class OneOf.
    """
    # Case 1: Input:
    # [1,2,3,4]   [1,2,3,4]    2
    # Output:
    # Nothing  No error
    # Case 2: Input:
    # [1,2,3,4]   [1,2,3,4]    5
    # Output:
    # Error "no match"
    # Case 3: Input:
    # [1,2,3,4]   [1,2,3,4]    "random"
    # Output:
    # Error "multiple matches"

    # Case 1:

# Generated at 2022-06-22 05:48:09.851735
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Initialize a NeverMatch object
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}
    # Assert method validate raises Exception
    with pytest.raises(Exception):
        field.validate({"never": "This never validates."}, strict=True)


# Generated at 2022-06-22 05:48:15.559887
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Test if a value validate
    """
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    field = Not(
        negated=Integer(),
    )
    try:
        field.validate(2)
    except ValidationError:
        assert True
    else:
        assert False


# Generated at 2022-06-22 05:48:22.436436
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    num = 3
    if_clause = Field(type="integer")
    then_clause = Field(type="integer")
    else_clause = Field(type="string")
    if_then_else_clause = IfThenElse(if_clause, then_clause, else_clause)
    assert type(if_then_else_clause.validate(num)) is int
    assert type(if_then_else_clause.validate(str(num))) is str



# Generated at 2022-06-22 05:48:30.011455
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    print("Begin unit test for method validate of class AllOf")
    A = AllOf([Integer(), String()], required=["a", "b", "c"])
    A.validate({"a": 1, "b": "2", "c": "3"})
    try:
        A.validate({"a": 1, "b": 2, "c": 3})
    except FieldErrors as e:
        print("Test passed")
    else:
        print("Unit test for method validate of class AllOf FAILED")



# Generated at 2022-06-22 05:48:31.904560
# Unit test for constructor of class AllOf
def test_AllOf():

    from typesystem.fields import String

    a = AllOf([String(), String()])
    assert a.all_of == [String(), String()]

# Generated at 2022-06-22 05:48:43.697797
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # This test uses the class OneOf and verifies the method validate
    # To run this test, use: python -m pytest framework/validators/advanced.py::test_OneOf_validate
    # To run all tests related to the file advanced.py, use: python -m pytest tests/unit/framework/validators/test_advanced.py
    # To run all unit tests, use: python -m pytest tests/unit/
    value = {'foo': 'bar'}
    objIf = {"type": "string"}

    field = OneOf(one_of=[String(name="foo"), Object(name="bar")])
    assert field.validate(value) is not None


# Generated at 2022-06-22 05:48:47.345178
# Unit test for constructor of class Not
def test_Not():
    from .fields import Integer

    negated = Integer()
    not_field = Not(negated)
    assert not_field.negated == negated
    assert not_field.errors == {"negated": "Must not match."}


# Generated at 2022-06-22 05:48:51.416510
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Integer, String
    from typesystem.exceptions import ValidationError
    field = Not(Integer)
    assert field.validate(3) == None
    assert field.errors['negated'] == 'Must not match.'
    try:
        field.validate(3.0)
    except ValidationError as e:
        assert e.code == 'negated'



# Generated at 2022-06-22 05:49:00.774265
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Boolean(), Integer()])
    value = field.validate(0)
    assert value is not None


# Generated at 2022-06-22 05:49:10.776874
# Unit test for method validate of class Not
def test_Not_validate():
    class Book:
        def __init__(self, id, name, genres):
            self.id = id
            self.name = name
            self.genres = genres
        def print_details(self):
            print("Book details:")
            print("%s, %s, %s" % (self.id, self.name, self.genres))
            print("\n")
        def test_ID(self):
            if (self.id <= 0):
                raise self.validation_error("negated")

    class Validator(Field):
        def __init__(self, id, name, genres, **kwargs):
            assert "allow_null" not in kwargs
            super(Validator, self).__init__(**kwargs)
            self.id = id
            self.name = name
            self

# Generated at 2022-06-22 05:49:12.215907
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = [Field(),Field(),Field()]
    a

# Generated at 2022-06-22 05:49:14.037499
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=None)


# Generated at 2022-06-22 05:49:16.671292
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Any(), NeverMatch()])
    assert field.validate(5) == 5
    with pytest.raises(ValidationError):
        field.validate(5.0, strict=True)


# Generated at 2022-06-22 05:49:21.486228
# Unit test for method validate of class Not
def test_Not_validate():
    schema = Not(Integer())
    schema.validate(1.0)
    schema.validate('a')
    with pytest.raises(schema.validation_error):
        schema.validate(1)

    schema = Not(Any())
    with pytest.raises(schema.validation_error):
        schema.validate(None)


# Generated at 2022-06-22 05:49:22.498723
# Unit test for constructor of class Not
def test_Not():
    assert(Not is not None)

# Generated at 2022-06-22 05:49:24.810699
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String

    field = AllOf([String()])
    assert field


# Generated at 2022-06-22 05:49:36.448031
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    validate = OneOf.validate
    no_matchErr = OneOf.errors["no_match"]
    multiple_matchesErr = OneOf.errors["multiple_matches"]

    # testing for empty list of child fields
    try:
        validate("test", [])
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
        assert str(e) == no_matchErr

    field1 = String()
    field2 = String()
    # testing for null value
    try:
        validate(None, [field1, field2])
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
        assert str(e) == no_matchErr

    # testing for null value

# Generated at 2022-06-22 05:49:37.976590
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("1") is None

# Generated at 2022-06-22 05:49:44.068018
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.required == True
    assert field.allow_null == False


# Generated at 2022-06-22 05:49:52.439374
# Unit test for constructor of class OneOf
def test_OneOf():
    assert(issubclass(OneOf, Field))

    #Test with a list of fields of size 0
    try:
        OneOf([])
    except AssertionError:
        assert(True)
    else:
        assert(False)

    #Test with a list of fields of size 1
    try:
        OneOf([Field()])
    except AssertionError:
        assert(True)
    else:
        assert(False)

    #Test with a list of fields of size 2
    try:
        OneOf([Field(),Field()])
    except AssertionError:
        assert(False)
    else:
        assert(True)



# Generated at 2022-06-22 05:49:54.309927
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    allOf = AllOf()
    assert_equal(allOf.validate(3),3)

# Generated at 2022-06-22 05:50:06.603454
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class User(Model):
        email = String()

    class UserProfile(Model):
        first_name = String()
        last_name = String()

    class UserProfileIncludingEmail(Model):
        first_name = String()
        last_name = String()
        email = String()

    class UserAuth(Model):
        user = ModelField(User)
        profile = ModelField(IfThenElse(
            'full_profile',
            UserProfileIncludingEmail(),
            UserProfile()
        ))
        full_profile = Boolean()


    user = UserAuth(
        user = User(email = "bob@bob.com"),
        profile = UserProfile(first_name = 'bob', last_name = 'bob'),
        full_profile = False
    )


# Generated at 2022-06-22 05:50:17.005618
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())

    def test_negated(v: typing.Any) -> None:
        _, error = n.validate_or_error(v)
        assert not error, "{} failed to match".format(v)

    def test_matches(v: typing.Any) -> None:
        _, error = n.validate_or_error(v)
        assert error, "{} should not match".format(v)

    test_negated(None)
    test_negated(False)
    test_negated(True)
    test_negated(1)
    test_negated(1.1)
    test_negated(b"")
    test_negated("")
    test_negated([])
    test_negated({})



# Generated at 2022-06-22 05:50:18.442582
# Unit test for constructor of class OneOf
def test_OneOf():
    f = OneOf([Field()])
    assert f.validate(None) == None

# Generated at 2022-06-22 05:50:22.449362
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # given
    test_object = NeverMatch()
    # when
    # then
    with pytest.raises(test_object.validation_error):
        test_object.validate(1)


# Generated at 2022-06-22 05:50:26.092300
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    data = None
    try:
        nm = NeverMatch()
        nm.validate(data)
    except Exception as e:
        assert type(e) == nm.validation_error
        assert e.code == 'never'

# Generated at 2022-06-22 05:50:31.093017
# Unit test for constructor of class OneOf
def test_OneOf():
    # check that nothing is changed in the constructor of OneOf
    try:
        with pytest.raises(AssertionError):
            OneOf(one_of = [], allow_null = True)
    except:
        assert False, "Error in the constructor of class OneOf"
    else:
        assert True



# Generated at 2022-06-22 05:50:36.454138
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse_validate_field = IfThenElse(if_clause=String(), then_clause=String(), else_clause=String())
    assert IfThenElse_validate_field.validate("test") == "test"
    assert IfThenElse_validate_field.validate("test")

# Generated at 2022-06-22 05:50:48.384447
# Unit test for constructor of class OneOf
def test_OneOf():
    # missing keyword
    try:
        OneOf()
        assert False
    except TypeError:
        pass
    # missing field
    try:
        OneOf(None)
        assert False
    except TypeError:
        pass
    # missing field
    try:
        OneOf([None])
        assert False
    except TypeError:
        pass



# Generated at 2022-06-22 05:50:50.994348
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-22 05:50:54.097945
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_field = OneOf(one_of=[Field()])
    assert one_of_field.one_of == [Field()]


# Generated at 2022-06-22 05:50:55.272125
# Unit test for constructor of class AllOf
def test_AllOf():
    from _60_asserting.ex_15_schema_validator import AllOf

# Generated at 2022-06-22 05:51:06.582573
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class Animal(Field):
        def validate(self, value, strict=False):
            if value not in('cat', 'dog'):
                raise ValidationError("Not an animal")
            return value

    class Cat(Animal):
        errors = {"not_a_cat": "not a cat"}

        def validate(self, value, strict=False):
            if value != 'cat':
                raise self.validation_error("not_a_cat")
            return super().validate(value, strict)

    class Dog(Animal):
        errors = {"not_a_dog": "not a dog"}

        def validate(self, value, strict=False):
            if value != 'dog':
                raise self.validation_error("not_a_dog")
            return super().validate(value, strict)

    cat = Cat()
   

# Generated at 2022-06-22 05:51:10.645253
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Any(), Any()])
    assert one_of.validate(123) == 123
    try:
        assert one_of.validate(set()) is None
        assert False, 'Expected Exception but not received'
    except:
        pass

# Generated at 2022-06-22 05:51:16.423547
# Unit test for constructor of class OneOf
def test_OneOf():
    r = OneOf([])
    assert r.errors == {'no_match': 'Did not match any valid type.',
                        'multiple_matches': 'Matched more than one type.'}
    assert r.one_of == []

    # check if the error isn't raised by the constructor
    r = OneOf([Any()])
    assert r.errors == {'no_match': 'Did not match any valid type.',
                        'multiple_matches': 'Matched more than one type.'}
    assert r.one_of == [Any()]

    # check if it raises error
    try:
        r = OneOf([Any()], allow_null=True)
        assert False
    except Exception:
        pass



# Generated at 2022-06-22 05:51:18.966032
# Unit test for constructor of class AllOf
def test_AllOf():
    aof = AllOf([Any], description="any")
    assert aof.all_of == [Any]
    assert aof.description == "any"


# Generated at 2022-06-22 05:51:20.833730
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    with pytest.raises(AssertionError):
        IfThenElse(if_clause=None, then_clause=None, else_clause=None, allow_null=True)

# Generated at 2022-06-22 05:51:22.631935
# Unit test for constructor of class AllOf
def test_AllOf():
    text1 = AllOf([Text()], required=True, description="Test")
    assert text1


# Generated at 2022-06-22 05:51:51.694874
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []



# Generated at 2022-06-22 05:51:56.479917
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    from typesystem import Schema
    from typesystem.exceptions import ValidationError

    if_clause = String(max_length=2)
    then_clause = String(min_length=3)
    else_clause = String()

    ifthenelse = IfThenElse(if_clause, then_clause, else_clause)

    assert ifthenelse.if_clause == if_clause
    assert ifthenelse.then_clause == then_clause
    assert ifthenelse.else_clause == else_clause

    ifthenelse_2 = IfThenElse(if_clause, then_clause)

    assert ifthenelse_2.if_clause == if_clause
    assert ifthenelse_2.then_clause == then_clause


# Generated at 2022-06-22 05:51:59.651227
# Unit test for constructor of class AllOf
def test_AllOf():
    foo = "foo"
    bar = "bar"
    f1 = Field()
    f2 = Field()
    f3 = Field()
    assert AllOf( [f1, f2, f3])

# Generated at 2022-06-22 05:52:06.560268
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Arrange
    from typesystem.primitives import String
    all_of_obj = AllOf(all_of=[String(), String()])

    # Act
    try:
        all_of_obj.validate("John")
        returned = True
    except:
        returned = False

    # Assert
    assert returned


# Generated at 2022-06-22 05:52:08.969418
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([BaseString()]).validate("") == ""
    assert AllOf([BaseString(), MaxLength(5)]).validate("Hello") == "Hello"



# Generated at 2022-06-22 05:52:12.412671
# Unit test for constructor of class AllOf
def test_AllOf():
  all_of_list: typing.List[Field] = [Field()]
  assert AllOf(all_of_list) is not None

# Generated at 2022-06-22 05:52:22.124514
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    try :   
        f=IfThenElse(String,String,String)
        f.validate("testing")
    except : raise AssertionError("f.validate(\"testing\") should not have raised an exception")
    try :   
        f=IfThenElse(Date,Date,Date)
        f.validate("testing")
    except : raise AssertionError("f.validate(\"testing_2\") should not have raised an exception")
    try :   
        f=IfThenElse(Date,Date,Date)
        f.validate(datetime.datetime.now())
    except : raise AssertionError("f.validate(datetime.datetime.now()) should not have raised an exception")

# Generated at 2022-06-22 05:52:30.854876
# Unit test for constructor of class AllOf
def test_AllOf():
    # True
    all_of_field = AllOf([String(), Numeric()])
    assert 'all_of' in all_of_field.errors
    assert all_of_field.validate("123", strict=False) == "123"
    assert all_of_field.validate("abc", strict=False) == "abc"

    # False
    all_of_field = AllOf([Numeric()])
    assert 'all_of' in all_of_field.errors
    assert all_of_field.validate("123", strict=False) == "123"


# Generated at 2022-06-22 05:52:38.694932
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    string_field = String()
    array_field = Array(items=Integer())
    all_of_1 = AllOf([string_field, array_field], 
        name='all_of_1',
        description='all_of_1',
        required=True,
        validate_always=False,
        allow_coerce=True,
        allow_null=True,
        error_messages={})
    value = 'a'
    assert all_of_1.validate(value) == value, 'return value should be value'


# Generated at 2022-06-22 05:52:40.720154
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    x = AllOf([typesystem.Integer()])
    assert x.validate(10) == 10
    

# Generated at 2022-06-22 05:53:34.705733
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(description="test for NeverMatch").description == "test for NeverMatch"



# Generated at 2022-06-22 05:53:45.544611
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([], name="a", default="a")
    assert a.one_of == []
    assert a.name == "a"
    assert a.default == "a"
    b = OneOf([], name="b", default="b")
    assert b.one_of == []
    assert b.name == "b"
    assert b.default == "b"
    c = OneOf([], name="c", default="c")
    assert c.one_of == []
    assert c.name == "c"
    assert c.default == "c"
    d = OneOf([], name="d", default="d")
    assert d.one_of == []
    assert d.name == "d"
    assert d.default == "d"


# Generated at 2022-06-22 05:53:47.375127
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=None)
    assert isinstance(not_field, Not), "Not initialized correctly"

# Generated at 2022-06-22 05:53:50.954259
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Boolean, Number

    class Test(AllOf):
        def __init__(self):
            super().__init__(all_of=[Boolean(), Number()])

    t = Test()
    t.validate(True)

# Generated at 2022-06-22 05:53:58.373687
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Test AllOf.validate
    # Test AllOf's validate function with sub-usage of validate function within itself
    # -> This means call the validate function in class Field in the function validate in class AllOf
    # Expect: None
    print("AllOf.validate: test AllOf.validate with sub-usage of validate function")

    all_of = AllOf([AllOf([Field("a", str)])])
    all_of.validate("a")


# Generated at 2022-06-22 05:54:01.808213
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(AssertionError):
        field.validate(23)



# Generated at 2022-06-22 05:54:03.179369
# Unit test for constructor of class Not
def test_Not():
    n = Not(1)
    assert type(n) == Not

# Generated at 2022-06-22 05:54:04.938831
# Unit test for constructor of class Not
def test_Not():
    assert (Not(negated=AllOf(all_of=[Any()])) != None)

# Generated at 2022-06-22 05:54:07.775903
# Unit test for constructor of class OneOf
def test_OneOf():
    nullable_type = OneOf([types.Null(),types.String()], nullable=True)
    non_nullable_type = OneOf([types.Null(),types.String()])


# Generated at 2022-06-22 05:54:12.038551
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    value = 1
    if_then_else = IfThenElse(if_clause, then_clause, else_clause, value)
    assert(value == if_then_else.validate(value, strict = False))