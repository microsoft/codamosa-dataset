

# Generated at 2022-06-22 05:46:06.207090
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Field
    field = Field(**{'if_clause': {}})
    assert isinstance(field.if_clause, Field)
    assert isinstance(field.then_clause, Field)
    assert isinstance(field.else_clause, Field)

    field = Field(**{'if_clause': {}})
    assert isinstance(field.if_clause, Field)
    assert isinstance(field.then_clause, Field)
    assert isinstance(field.else_clause, Field)

# Generated at 2022-06-22 05:46:07.409595
# Unit test for constructor of class Not
def test_Not():
    n = Not(negated=None)

# Generated at 2022-06-22 05:46:16.705682
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IntField(Field):
        """
        A field class that matches any integer.
        """
        errors = {"type": "Must be an integer."}

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if isinstance(value, int):
                return value
            raise self.validation_error("type")

    intField = IntField()
    ifThenElseField = IfThenElse(intField)

    assert ifThenElseField.validate(2) == 2
    assert ifThenElseField.validate(3) == 3
    assert ifThenElseField.validate(4) == 4



# Generated at 2022-06-22 05:46:28.336718
# Unit test for constructor of class OneOf
def test_OneOf():
    def oneOf_validate(self, value, strict=False):
        candidate = None
        match_count = 0
        for child in self.one_of:
            validated, error = child.validate_or_error(value, strict=strict)
            if error is None:
                match_count += 1
                candidate = validated

        if match_count == 1:
            return candidate
        elif match_count > 1:
            raise self.validation_error("multiple_matches")
        raise self.validation_error("no_match")
    try:
        oneOf_validate(OneOf([Field(), Array(items=Field()), Boolean()]), 1)
    except:
        pass
    try:
        oneOf_validate(OneOf([Float(), Number()]), 1.0)
    except:
        pass

# Generated at 2022-06-22 05:46:29.420574
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf


# Generated at 2022-06-22 05:46:31.648520
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf(all_of=[String(), Number()])
    all_of.validate(value={"a": 123})

# Generated at 2022-06-22 05:46:33.459120
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[Any(min_length=3)])
    assert field.validate("abc") == "abc"



# Generated at 2022-06-22 05:46:40.755500
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test = Any()
    types = [test]
    assert OneOf(types).validate(1) == 1
    types = [
        test
    ]
    try:
        OneOf(types).validate(1)
        assert False
    except Exception as e:
        assert e.message == "Did not match any valid type."

    types = [
        Field(),
        Field(),
        Field(),
    ]
    try:
        OneOf(types).validate(1)
        assert False
    except Exception as e:
        assert e.message == "Did not match any valid type."

# Generated at 2022-06-22 05:46:50.743556
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Exercise all paths through constructor
    if_clause1 = Any()
    then_clause1 = Any()
    else_clause1 = Any()
    obj1 = IfThenElse(if_clause1,then_clause1,else_clause1)
    # Exercise 2nd constructor path
    if_clause2 = Any()
    then_clause2 = Any()
    else_clause2 = None
    obj2 = IfThenElse(if_clause2,then_clause2,else_clause2)
    # Exercise 3rd constructor path
    if_clause3 = Any()
    then_clause3 = None
    else_clause3 = Any()
    obj3 = IfThenElse(if_clause3,then_clause3,else_clause3)
    # Exercise 4th constructor

# Generated at 2022-06-22 05:46:53.020734
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), Field)
    assert NeverMatch().errors == {"never": "This never validates."}



# Generated at 2022-06-22 05:47:00.290883
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of_field = AllOf(all_of=[Field(name="a", required=True), Field(name="b", required=True)])
    try:
        all_of_field.validate(value={"a": 2, "b": 3})
    except Exception as e:
        print(e)
    try:
        all_of_field.validate(value={"a": 2})
    except Exception as e:
        print(e)


# Generated at 2022-06-22 05:47:01.849227
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf([Any()])
    all_of.validate(True)

# Generated at 2022-06-22 05:47:03.951767
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with raises(ValidationError):
        field.validate(None)

# Generated at 2022-06-22 05:47:08.004862
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    schema = AllOf([
        Int(),
        Float(),
    ])
    assert schema.validate('3') == 3
    assert schema.validate('3.3') == 3.3
    assert schema.validate(3.3) == 3.3



# Generated at 2022-06-22 05:47:09.210896
# Unit test for constructor of class Not
def test_Not():
    n = Not(None)
    assert n.negated == None


# Generated at 2022-06-22 05:47:14.381731
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # define the classes for if-then-else
    input_class = IfThenElse(validator, then_clause, else_clause)
    # test the condition when 'value' passes the if-clause validation
    output = input_class.validate(value)
    assert output == then_clause.validate(value)
    # test the condition when 'value' fails the if-clause validation
    output = input_class.validate(value)
    assert output == else_clause.validate(value)

# Generated at 2022-06-22 05:47:15.099304
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import OneOf



# Generated at 2022-06-22 05:47:26.256893
# Unit test for method validate of class Not
def test_Not_validate():
    negated = Field()
    negated.errors = {'negated': 'Must not match.'}
    if_clause = Field()
    then_clause = Field()
    then_clause.errors = {'then': "Then-Clause"}
    else_clause = Field()
    else_clause.errors = {'else': "Else-Clause"}
    try:
        negated.validate('')
    except:
        assert False
    else:
        assert True

    not_validate = Not(negated)
    try:
        not_validate.validate('')
    except:
        assert False
    else:
        assert True
    if_then_else_validate = IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-22 05:47:36.773184
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import typesystem
    # Build OneOf item
    item = typesystem.OneOf(one_of=[
        typesystem.String(max_length=2),
        typesystem.Integer(max_value=2),
        typesystem.Float(max_value=2),
    ])
    # Test with string value
    try:
        result = item.validate('1')
    except ValueError as e:
        print(e)
    # Test with integer value
    try:
        result = item.validate(1)
    except ValueError as e:
        print(e)
    # Test with float value
    try:
        result = item.validate(1.0)
    except ValueError as e:
        print(e)
    # Test with invalid string value

# Generated at 2022-06-22 05:47:37.723096
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass


# Generated at 2022-06-22 05:47:43.715773
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Add your test here
    assert True # "Placeholder test."

# Generated at 2022-06-22 05:47:47.973716
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(error="Any"), Any(error="Any"), Any(error="Any"))
    assert field.validate(None, strict=False) is None
    assert field.validate(None, strict=True) is None



# Generated at 2022-06-22 05:47:57.095548
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import String, Integer
    from typesystem.fields import AllOf
    import pytest
    test_field = AllOf(all_of=[String(), Integer()])
    assert test_field.validate('test') == 'test'
    with pytest.raises(Exception) as exception:
        test_field.validate(['test'])
    assert str(exception.value) == 'Must be a string.'
    with pytest.raises(Exception) as exception:
        test_field.validate([])
    assert str(exception.value) == 'Must be a string.'
    with pytest.raises(Exception) as exception:
        test_field.validate(1)
    assert str(exception.value) == 'Must be a string.'


# Generated at 2022-06-22 05:48:00.969620
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(),then_clause=Any())
    assert field.validate('') == ''
    print('Test If Then Else passed!')




# Generated at 2022-06-22 05:48:11.128530
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import json
    from typesystem.fields import Integer
    from io import StringIO
    if_clause = Integer(maximum=10)
    then_clause = Integer(maximum=20)
    else_clause = Integer(minimum=30)
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert json.loads(StringIO(field.schema.json()).read()) == {
        "$schema": "http://json-schema.org/draft-07/schema#",
        "oneOf": [
            {
                "allOf": [
                    {"maximum": 10, "type": "integer"},
                    {"maximum": 20, "type": "integer"},
                ]
            },
            {"minimum": 30, "type": "integer"},
        ],
    }

# Generated at 2022-06-22 05:48:14.469997
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	field = NeverMatch()
	pass


# Generated at 2022-06-22 05:48:15.825608
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert isinstance(AllOf, object)



# Generated at 2022-06-22 05:48:17.326529
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[])


# Generated at 2022-06-22 05:48:19.264513
# Unit test for constructor of class Not
def test_Not():
    type = Not(negated=1)
    assert(type.negated == 1)


# Generated at 2022-06-22 05:48:27.031009
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field1 = Field()
    def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
        return value
    field1.validate= validate.__get__(object)
    field2 = Field()
    def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
        raise self.validation_error("not_a_string")
    field2.validate= validate.__get__(object)
    field = OneOf(one_of=[field1, field2])
    assert field.validate(value="banana") == "banana"
    # Should raise error
    try:
        field.validate(value=12)
    except Exception as e:
        assert e.errors == ['Did not match any valid type.']

# Generated at 2022-06-22 05:48:35.853742
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("some value") == "some value"

# Generated at 2022-06-22 05:48:46.336322
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(label="IF", required=True)
    then_clause = Field(label="IF", required=True)
    else_clause = Field(label="ELSE", required=True)
    ite = IfThenElse(
        if_clause=if_clause,
        then_clause=then_clause,
        else_clause=else_clause,
        label="IF-THEN-ELSE",
    )
    value = "foo"
    ite.validate(value)
    value = "bar"
    ite.validate(value)


if __name__ == "__main__":
    test_IfThenElse_validate()

# Generated at 2022-06-22 05:48:55.150678
# Unit test for method validate of class Not
def test_Not_validate():
    def not_validate_entry(value):
        schema = Not(String())
        schema.validate(value)
    
    def not_validate_exit(value):
        schema = Not(String())
        try:
            schema.validate(value)
        except ValidationError as e:
            return
        assert False
    
    assert not_validate_exit(None) == None
    assert not_validate_exit('') == None
    assert not_validate_exit(0) == None
    assert not_validate_exit(False) == None
    assert not_validate_exit(1.2) == None
    assert not_validate_entry('f') == None
    assert not_validate_entry(True) == None
    assert not_validate_entry(1) == None

# Generated at 2022-06-22 05:49:06.824016
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import Integer
    not_integer = Not(Integer())
    assert not_integer.negated.__class__.__name__ == 'Integer'
    assert not_integer.negated.title is None
    assert not_integer.negated.description is None
    assert not_integer.negated.minimum is None
    assert not_integer.negated.maximum is None
    assert not_integer.negated.multiple_of is None
    assert not_integer.negated.format is None
    assert not_integer.negated.default is None
    assert not_integer.negated.required is None
    assert not_integer.negated.strict is None
    assert not_integer.negated.allow_null is None
    assert not_integer.negated.const is None

# Generated at 2022-06-22 05:49:09.851434
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    print (n.validate(11))
    print (n.validate(11,False))
    print (n.validate(11,True))


# Generated at 2022-06-22 05:49:10.822374
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-22 05:49:20.447762
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class T(AllOf):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(all_of, **kwargs)
            self.all_of = all_of

    class F(AllOf):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(all_of, **kwargs)

    class T2(AllOf):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__()


# Generated at 2022-06-22 05:49:25.007174
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test = OneOf([Integer(), String()])
    assert test.validate(23) == 23
    assert test.validate("23") == "23"
    try:
        test.validate([])
        raise AssertionError
    except AssertionError:
        raise AssertionError
    except Exception:
        pass


# Generated at 2022-06-22 05:49:30.865917
# Unit test for constructor of class AllOf
def test_AllOf():
    allof = AllOf([Any()])
    assert allof.all_of == [Any()]
    assert allof.allow_null == True
    assert allof.description == None
    assert allof.name == 'all_of'
    assert allof.required == True
    assert allof.title == None
    assert allof.widget == None


# Generated at 2022-06-22 05:49:32.437631
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    AllOf([])


# Generated at 2022-06-22 05:49:40.104008
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse()

# Generated at 2022-06-22 05:49:44.553421
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(
        if_clause=Field(type="string"),
        then_clause=Field(type="string"),
        else_clause=Field(type="string"),
        **{"allow_null": None}
    )
    val = x.validate("foo")
    assert val == "foo"
    assert type(val) == str

# Generated at 2022-06-22 05:49:45.912934
# Unit test for constructor of class OneOf
def test_OneOf():
    x = OneOf(one_of=[])
    assert x is not None


# Generated at 2022-06-22 05:49:48.765521
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Boolean()], name='one_of', error_messages={})
    value = None
    strict = None
    result = field.validate(value, strict)
    assert result is None

# Generated at 2022-06-22 05:49:54.167877
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import types
    from typesystem.fields import Schema

    class SomeSchema(Schema):
        one_of = types.one_of([types.string(), types.integer()])

    assert SomeSchema().validate({"one_of": "a string"}) == {"one_of": "a string"}
    assert SomeSchema().validate({"one_of": 1}) == {"one_of": 1}

# Generated at 2022-06-22 05:49:58.838205
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import String as StringType
    all_of = AllOf(all_of=[StringType()])
    assert all_of.all_of[0] == String()


# Generated at 2022-06-22 05:50:01.926568
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []
    assert field.allow_null == False


# Generated at 2022-06-22 05:50:09.940745
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of=[])
    assert field.all_of == []
    assert field.allow_null == True
    assert field.description == ''
    assert field.name is None
    assert field.title == ''
    assert field.validators == ()
    assert field.errors == {'invalid': 'Not a valid value.'}
    assert field.allowed_types == ()
    assert field.error_codes == {'invalid', 'required'}
    assert field.error_messages == {'invalid': 'Not a valid value.', 'required': 'This field is required.'}



# Generated at 2022-06-22 05:50:13.810699
# Unit test for constructor of class Not
def test_Not():
    test_case = Not(negated= Field.Int())
    assert test_case.__class__.__name__ == 'Not'

# Test __repr__() method of class Not

# Generated at 2022-06-22 05:50:15.404424
# Unit test for constructor of class AllOf
def test_AllOf():
    # SUT
    allOf = AllOf([])
    assert allOf


# Generated at 2022-06-22 05:50:31.793280
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch(name='match')
    try:
        field.validate(None)
        assert False
    except Exception as e:
        assert str(e) == 'match: This never validates.'

# Generated at 2022-06-22 05:50:34.097609
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    field = OneOf([String(), String()])
    field.validate(["a", "b"])

# Generated at 2022-06-22 05:50:44.381526
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    clause_if = Boolean()
    clause_then = Boolean()
    clause_else = Boolean()
    f = IfThenElse(clause_if, clause_then, clause_else)
    assert f.if_clause == clause_if
    assert f.then_clause == clause_then
    assert f.else_clause == clause_else
    f = IfThenElse(clause_if, clause_then)
    assert f.if_clause == clause_if
    assert f.then_clause == clause_then
    assert f.else_clause == Any()
    f = IfThenElse(clause_if)
    assert f.if_clause == clause_if
    assert f.then_clause == Any()
    assert f.else_clause == Any()

# Generated at 2022-06-22 05:50:45.546050
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert 1 == 1


# Generated at 2022-06-22 05:50:46.516703
# Unit test for constructor of class OneOf
def test_OneOf():
    fn = OneOf([])


# Generated at 2022-06-22 05:50:58.333734
# Unit test for constructor of class Not

# Generated at 2022-06-22 05:51:00.262366
# Unit test for method validate of class Not
def test_Not_validate():
    Not(negated=String(max_length=5)).validate("Hello")


# Generated at 2022-06-22 05:51:02.379841
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any(), Any()]).one_of == [Any(), Any()]
    assert OneOf([Any()]).one_of == [Any()]



# Generated at 2022-06-22 05:51:03.388043
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()


# Generated at 2022-06-22 05:51:05.629265
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nevermatch = NeverMatch()
    assert nevermatch.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:51:44.790363
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    a = NeverMatch()
    b = a.validate("aa")


# Generated at 2022-06-22 05:51:48.341393
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Integer())
    field.validate(1)
    try:
        field.validate(2)
    except Exception as e:
        if "Must not match" in str(e):
            assert True
        else:
            assert False
    else:
        assert False



# Generated at 2022-06-22 05:51:59.504608
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IfthenelseTest(IfThenElse):
        def __init__(self, parameters: Any, **kwargs: typing.Any):
            super().__init__(**kwargs)
            self.parameters = parameters

    # data set
    test1 = IfthenelseTest(
        1, if_clause=Field(), then_clause=[8, 6, 7], else_clause=[1, 2, 3]
    )
    assert test1.validate(1) == [8, 6, 7]
    test2 = IfthenelseTest(
        None, if_clause=Field(), then_clause=[8, 6, 7], else_clause=[1, 2, 3]
    )
    assert test2.validate(1) == [1, 2, 3]
    test3 = Ifthenelse

# Generated at 2022-06-22 05:52:00.866673
# Unit test for constructor of class Not
def test_Not():
    assert (Not(negate=Field()))

# Generated at 2022-06-22 05:52:05.628028
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class TestAllOf(AllOf):
        def __init__(self, all_of: typing.List[Field]) -> None:
            super().__init__(all_of)

    x = TestAllOf(all_of=[])
    y = TestAllOf(all_of=[])

    x.validate({})
    y.validate({})
    assert x.validate({}) == {}


# Generated at 2022-06-22 05:52:07.498843
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Int(), Int(), Int()).validate(3) == 3
    

# Generated at 2022-06-22 05:52:19.055151
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    condition = Field()
    then_clause = Field()
    else_clause = Field()
    obj = IfThenElse(condition, then_clause, else_clause)
    assert obj.if_clause is condition
    assert obj.then_clause is then_clause
    assert obj.else_clause is else_clause

    obj = IfThenElse(condition, else_clause=else_clause)
    assert obj.if_clause is condition
    assert isinstance(obj.then_clause, Any)
    assert obj.else_clause is else_clause

    obj = IfThenElse(condition, then_clause=then_clause)
    assert obj.if_clause is condition
    assert obj.then_clause is then_clause

# Generated at 2022-06-22 05:52:30.168004
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(Integer(), Float())
    b = IfThenElse(Integer())
    c = IfThenElse(Integer(), Float(), Integer())
    d = IfThenElse(Integer(), else_clause=Float())
    assert a.if_clause.type == "integer"
    assert a.then_clause.type == "number"
    assert b.if_clause.type == "integer"
    assert b.then_clause.type == "any"
    assert c.if_clause.type == "integer"
    assert c.then_clause.type == "number"
    assert c.else_clause.type == "integer"
    assert d.if_clause.type == "integer"
    assert d.then_clause.type == "any"

# Generated at 2022-06-22 05:52:31.610799
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([str])



# Generated at 2022-06-22 05:52:41.524979
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    test the constructor
    """
    # None of the required parameters are None
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    # The constructor of class IfThenElse should not raise any exception
    assert IfThenElse(if_clause, then_clause, else_clause) is not None

    # Only one of the required parameters are None
    if_clause = Field()
    then_clause = None
    else_clause = Field()
    # The constructor of class IfThenElse should not raise any exception
    assert IfThenElse(if_clause, then_clause, else_clause) is not None

    if_clause = None
    then_clause = Field()
    else_clause = Field()
    # The constructor of class IfThen

# Generated at 2022-06-22 05:53:50.453763
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(Exception) as exception:
        result = field.validate(None)
    assert str(exception.value) == '{"never": ["This never validates."]}'

    result = field.validate_or_error(None)
    assert result == (None, {'never': ["This never validates."]})


# Generated at 2022-06-22 05:53:55.238239
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[Num(), Str()])
    output = field.validate(1)
    assert output == 1
    field.validate("")
    field.validate(None)

# Generated at 2022-06-22 05:54:01.934035
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    single = OneOf(one_of=[Integer()])
    # Case 1: no match
    with pytest.raises(single.validation_error):
        single.validate(value="", strict=False)
    # Case 2: exactly one match
    assert 1 == single.validate(value=1, strict=False)
    # Case 3: more than one match
    two_ints = OneOf(one_of=[Integer(), Integer()])
    with pytest.raises(two_ints.validation_error):
        two_ints.validate(value=1, strict=False)


# Generated at 2022-06-22 05:54:03.271585
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field is not None


# Generated at 2022-06-22 05:54:08.007099
# Unit test for constructor of class AllOf
def test_AllOf():
    # all_of can be list or tuple, but not other iterable type
    all_of = [Any(), Any()]
    _ = AllOf(all_of)
    with pytest.raises(AssertionError):
        _ = AllOf(())
    with pytest.raises(AssertionError):
        _ = AllOf(set())



# Generated at 2022-06-22 05:54:09.363518
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Field(), Field(), Field()])
    field.validate(False)

# Generated at 2022-06-22 05:54:16.583441
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        a = IfThenElse()
        assert False
    except AssertionError:
        raise AssertionError()
    try:
        a = IfThenElse(if_clause = 'a')
        assert False
    except AssertionError:
        raise AssertionError()
    try:
        a = IfThenElse(if_clause = Field())
        assert False
    except AssertionError:
        raise AssertionError()


# Generated at 2022-06-22 05:54:20.071745
# Unit test for constructor of class AllOf
def test_AllOf():
    import json

    options = {"two": 3}
    schema = AllOf([], options)

    assert schema.metadata == options
    assert json.dumps(schema.get_schema(), indent=4) == json.dumps({
        "allOf":[]
    }, indent=4)

# Generated at 2022-06-22 05:54:22.413115
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    This test is to test the constructor of IfThenElse class
    """
    ifClause = Field()
    thenClause = Field()
    elseClause = Field()
    IfThenElse(ifClause, thenClause, elseClause)

# Generated at 2022-06-22 05:54:24.919839
# Unit test for constructor of class Not
def test_Not():
    # Create validator
    field = Not(None, allow_null=False)
    assert type(field) is Not
    assert field.allow_null == False
