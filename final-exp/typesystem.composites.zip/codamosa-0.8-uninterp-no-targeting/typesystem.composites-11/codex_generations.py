

# Generated at 2022-06-22 05:46:07.663788
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Any, String

    def validate_all_of_with_strict_mode():
        # Given
        x = AllOf([String(), String()])
        given_input_value = "hello"
        given_strict_mode = True
        expected_output = "hello"
        # When
        actual_output=x.validate(given_input_value,given_strict_mode)
        # Then
        assert actual_output == expected_output

    def validate_all_of_without_strict_mode():
        # Given
        x = AllOf([String(), String()])
        given_input_value = "hello"
        given_strict_mode = False
        expected_output = "hello"
        # When

# Generated at 2022-06-22 05:46:14.636383
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from . import Int, String
    from .validators import Equals
    test_class = IfThenElse(if_clause=Equals(1), then_clause=Int(), else_clause=String())
    test_class.validate(1)
    test_class.validate("s")
    try:
        test_class.validate(2)
    except Exception as e:
        assert e.args[0] == "Expected 's', got '2' (type: <class 'int'>) instead."

# Generated at 2022-06-22 05:46:15.311987
# Unit test for constructor of class AllOf
def test_AllOf():
    pass

# Generated at 2022-06-22 05:46:19.605924
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import String
    from typesystem.fields import Integer
    all_of_field = AllOf(all_of=[String(), Integer()])
    x=all_of_field.validate(value="42")
    assert x=="42"


# Generated at 2022-06-22 05:46:29.426668
# Unit test for constructor of class Not
def test_Not():
    # import
    from typesystem.fields import String
    
    # define test data
    test_data = "this is not a string"
    metadata = {
        "required": True,
        "description": "Testing not",
        "title": "not",
    }
    
    # define the field
    field = Not(String(**metadata), metadata)
    _, error = field.validate_or_error(test_data)
    assert error == None
    test_data = "this is a string"
    _, error = field.validate_or_error(test_data)
    assert error["code"] == "negated"


# Generated at 2022-06-22 05:46:34.892315
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = field.String(required=True)
    b = field.String(required=True)
    instance = OneOf([a,b])
    check_type(instance, "aaaa")
    check_type(instance, "bbbb")
    try:
        instance.validate(None)
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-22 05:46:36.296676
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    return NeverMatch()


# Generated at 2022-06-22 05:46:38.351880
# Unit test for constructor of class Not
def test_Not():
    def test_Not():
        """
        This is a test for the constructor of Not.
        """
    test_Not()

# Generated at 2022-06-22 05:46:43.453177
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    
    field = IfThenElse(if_clause, then_clause, else_clause)
    
    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert field.else_clause == else_clause
    
test_IfThenElse()

# Generated at 2022-06-22 05:46:44.095259
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-22 05:46:57.962784
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    s = IfThenElse(
        if_clause=None,
        then_clause=String(),
        else_clause=Integer(),
        name="test"
    )
    assert s.if_clause is None
    assert s.then_clause._name == "String()"
    assert s.else_clause._name == "Integer()"
    assert s.name == "test"

    s = IfThenElse(
        if_clause=None
    )
    assert s.if_clause is None
    assert s.then_clause._name == "Any()"
    assert s.else_clause._name == "Any()"
    assert s.name is None



# Generated at 2022-06-22 05:47:01.380980
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import pytest    
    try:
        IfThenElse(None,None).validate(None)
        assert 1==0
    except AssertionError:
        pytest.xfail("Should have failed")
    try:
        IfThenElse(None,None,None).validate(None)
        assert 1==0
    except AssertionError:
        pytest.xfail("Should have failed")



# Generated at 2022-06-22 05:47:09.886884
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    assert IfThenElse(if_clause={}, then_clause={}).validate({}) == {}

    # No need to test else-clause because it's optional
    # assert IfThenElse(if_clause={}, then_clause={}, else_clause={}).validate({}) == {}

    assert IfThenElse(if_clause={"type": "string"}).validate("") == ""

    assert IfThenElse(if_clause={"type": "number"}).validate(10) == 10

    assert IfThenElse(if_clause={"type": "number"}).validate(10) == 10

    assert IfThenElse(if_clause={"type": "string", "minLength": 1}) \
           .validate("") == ""


# Generated at 2022-06-22 05:47:13.026634
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    data = [
        4,
        5,
        6,
        7
    ]
    # Action
    field = OneOf(data)
    result = field.validate(5)
    # Assert
    assert result == 5


# Generated at 2022-06-22 05:47:19.468751
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    lst = list()
    lst.append(String(max_length=5))
    lst.append(Integer(max_value=5))
    try:
        testSchema = OneOf(lst)
        testSchema.validate(3)
    except TypeSystemError:
        assert False
    except ValueError:
        assert False


# Generated at 2022-06-22 05:47:20.385292
# Unit test for constructor of class Not
def test_Not():
    assert issubclass(Not, Field)

# Generated at 2022-06-22 05:47:28.036149
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Test for method validate of class OneOf
    """
    one_of = OneOf([Integer(), String()])
    assert one_of.validate(123) == 123
    assert one_of.validate("abc") == "abc"
    # test to raise errors.MultipleMatched
    with pytest.raises(error.MultipleMatched) as exception_info:
        one_of.validate(['abc', 123]) == "abc"
    assert "Matched more than one type" in str(exception_info.value)
    # test to raise errors.NoMatched
    with pytest.raises(error.NoMatched) as exception_info:
        one_of.validate(['abc', 'xyz']) == "abc"

# Generated at 2022-06-22 05:47:32.261517
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([]).validate(None) == None
    class Foo:
        def __init__(self, name):
            self.name = name
    assert OneOf([Foo('foo')]).validate(Foo('foo')) == Foo('foo')


# Generated at 2022-06-22 05:47:35.553387
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    assert nm.validate(1) == 1

# Generated at 2022-06-22 05:47:42.415898
# Unit test for constructor of class AllOf
def test_AllOf():
    """ test for the constructor of AllOf class """
    field_list = [
        'Boolean',
        'DateTime',
        'Number',
        'Object',
        'String',
        'Array',
        'Enum',
        'Dict',
        'List',
        'Structure',
        'Union',
        'Constant',
        'Function',
        'Anything',
        'NeverMatch',
        'OneOf',
        'AllOf',
        'Not',
        'IfThenElse'
    ]
    my_field = AllOf(field_list)
    assert (my_field.all_of == field_list)

# Generated at 2022-06-22 05:47:47.996515
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf(all_of = [])

    assert a.validate(2) == 2


# Generated at 2022-06-22 05:47:53.923016
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(AllOf(items=[NeverMatch()]))
    # Unit test for constructor of class OneOf
    one_of = OneOf(one_of=[Any()])
    # Unit test for constructor of class IfThenElse
    if_then_else = IfThenElse(
        if_clause=AllOf(items=[NeverMatch()]),
        then_clause=AllOf(items=[NeverMatch()]),
        else_clause=AllOf(items=[NeverMatch()]),
    )


# Generated at 2022-06-22 05:47:57.774419
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    test = IfThenElse(if_clause, then_clause, else_clause)
    value = {"if_clause":1, "then_clause": 2, "else_clause": 3}
    ret = test.validate(value)
    assert ret == value

# Generated at 2022-06-22 05:47:59.965792
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    all_of = AllOf([String()])
    assert all_of.all_of == [String()]

# Generated at 2022-06-22 05:48:01.559465
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.label == "never_match"

# Generated at 2022-06-22 05:48:06.696078
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=Any()).validate("abc") == "abc"
    try:
        Not(negated=Not(negated=Any())).validate("abc")
        raise Exception("not supposed to reach here")
    except Exception as e:
        assert str(e) == "Must not match."

# Generated at 2022-06-22 05:48:08.065804
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # TODO: Check implementation
    pass


# Generated at 2022-06-22 05:48:14.391439
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()

    ite = IfThenElse(if_clause, then_clause, else_clause)

    assert ite.if_clause==if_clause
    assert ite.then_clause==then_clause
    assert ite.else_clause==else_clause



# Generated at 2022-06-22 05:48:15.994008
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([], description="")
    assert field


# Generated at 2022-06-22 05:48:23.208150
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Integer, Number
    # test "negated" error being in errors
    try:
        float_number_field = Not(negated = Number())
    except:
        assert False
    else:
        assert float_number_field.errors == {"negated": "Must not match."}
    # test "negated" error not being in errors
    try:
        int_number_field = Not(negated = Integer())
    except:
        assert False
    else:
        assert int_number_field.errors == {}



# Generated at 2022-06-22 05:48:27.229062
# Unit test for constructor of class AllOf
def test_AllOf():
    test = AllOf([Field()])
    assert test

# Generated at 2022-06-22 05:48:33.760476
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = never_match = NeverMatch()
    then_clause = Int()
    else_clause = String()
    ifThenElse = IfThenElse(if_clause, then_clause, else_clause)
    ifThenElse.validate(1)
    ifThenElse.validate("a")
    assert ifThenElse.validate(1) == 1
    assert ifThenElse.validate("a") == "a"

# Generated at 2022-06-22 05:48:35.105395
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf is not None


# Generated at 2022-06-22 05:48:39.327727
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    Unit test for constructor of class IfThenElse
    """
    assert IfThenElse({'if_clause': 'if_clause', 'then_clause': 'then_clause', 'else_clause': 'else_clause'}, allow_null=False)


# Generated at 2022-06-22 05:48:40.647278
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()



# Generated at 2022-06-22 05:48:52.094430
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_ = Field()
    then = Field()
    else_ = Field()
    obj = IfThenElse(if_, then, else_)
    assert obj.if_clause == if_
    assert obj.then_clause == then
    assert obj.else_clause == else_
    obj = IfThenElse(if_, then)
    assert obj.if_clause == if_
    assert obj.then_clause == then
    assert obj.else_clause.__class__.__name__ == "Any"
    obj = IfThenElse(if_)
    assert obj.if_clause == if_
    assert obj.then_clause.__class__.__name__ == "Any"
    assert obj.else_clause.__class__.__name__ == "Any"

# Generated at 2022-06-22 05:49:02.593946
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([Field(allow_null=False), Field(allow_null=True)], allow_null=True)
    assert a.all_of[0].allow_null is False
    assert a.all_of[1].allow_null is True
    assert a.allow_null is True
    assert a.strict is False
    a = AllOf([Field(allow_null=False), Field(allow_null=True)], allow_null=False)
    assert a.all_of[0].allow_null is False
    assert a.all_of[1].allow_null is False
    assert a.allow_null is False
    assert a.strict is False
    a = AllOf([Field(allow_null=False), Field(allow_null=False)], allow_null=False)
    assert a.all_of

# Generated at 2022-06-22 05:49:06.144688
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_field = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any()
    )

    assert type(test_field) == IfThenElse
    assert test_field.if_clause.__class__ == Any
    assert test_field.then_clause.__class__ == Any
    assert test_field.else_clause.__class__ == Any


# Generated at 2022-06-22 05:49:08.658980
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    Check the IfThenElse constructor without arguments
    """
    ite = IfThenElse()
    assert isinstance(ite, IfThenElse)


# Generated at 2022-06-22 05:49:18.931617
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    field = IfThenElse(String(min_length=1))
    assert isinstance(field.if_clause, String)
    assert isinstance(field.then_clause, Any)
    assert isinstance(field.else_clause, Any)
    field = IfThenElse(String(min_length=1), then_clause=String(max_length=3), else_clause=String(max_length=5))
    assert isinstance(field.if_clause, String)
    assert isinstance(field.then_clause, String)
    assert isinstance(field.else_clause, String)

# Generated at 2022-06-22 05:49:27.761154
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Given
    sub_field_1 = Field(required=False)
    sub_field_2 = Field(required=True)
    field = AllOf([sub_field_1, sub_field_2])

    # When, Then
    expected_result = 42
    assert field.validate(42) == expected_result



# Generated at 2022-06-22 05:49:31.061044
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem

    class MyAllOf(typesystem.AllOf):
        def __init__(self, all_of: typing.List[typesystem.Field]) -> None:
            super().__init__(all_of)

    assert MyAllOf.__name__ == "MyAllOf"
    assert MyAllOf.__doc__ == "Must match all of the sub-items."

# Generated at 2022-06-22 05:49:42.497234
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Integer()
    then_clause = String()
    else_clause = String()

    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert field.else_clause == else_clause

    field = IfThenElse(if_clause, then_clause)
    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert isinstance(field.else_clause, Any)

    field = IfThenElse(if_clause)
    assert field.if_clause == if_clause
    assert isinstance(field.then_clause, Any)
    assert isinstance

# Generated at 2022-06-22 05:49:47.713583
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f1 = String()
    f2 = Integer()
    f3 = String()
    f = IfThenElse(f1, f2, f3, allow_null=True, default=None)
    result = f.validate(1)
    # This is an error.
    # Instead of the value 1 it should be '1'
    # assert result == 1

# Generated at 2022-06-22 05:49:58.985066
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test for method validate (line 456)
    # Testing passing the conditions
    passed = True
    try:
        field = IfThenElse(
            Boolean(required=True),
            then_clause=Integer(minimum=3),
            else_clause=String(min_length=5),
        )
        field.validate(True, True)
        field.validate(False, True)
    except Exception:
        passed = False
    assert passed

    # Test for method validate (line 456)
    # Testing raise error if conditions are not met
    passed = False

# Generated at 2022-06-22 05:50:02.334799
# Unit test for constructor of class Not
def test_Not():
    str_field = String()
    field = Not(str_field, max_length=10)
    assert field.negated == str_field
    assert field.errors == {"negated": "Must not match."}
    assert field.max_length == 10


# Generated at 2022-06-22 05:50:04.514837
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(
        negated=Any(),
    )
    value = 1
    assert field.validate(value) == 1



# Generated at 2022-06-22 05:50:08.856536
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    obj = IfThenElse(if_clause, then_clause, else_clause)
    assert obj.validate("some-value") == "some-value"


# Generated at 2022-06-22 05:50:12.488307
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        NeverMatch.validate(1)
        raise Exception("This should raise")
    except Exception as e:
        # Expected
        assert e.args[0] == "This never validates."


# Generated at 2022-06-22 05:50:19.975606
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    AllOf([]).validate(None)
    AllOf([Any()]).validate({"foo":"bar"})
    AllOf([Any()]).validate(None)
    AllOf([Any(), Any(), Any()]).validate(None)
    AllOf([Any(), Any(), Any()]).validate({"data":{"moo":"moo"}})
    AllOf([Any(), Any(), Any()]).validate({"data":{"moo":10}})
    with raises(ValidationError):
        AllOf([Boolean(), Any(), Any()]).validate({"data":{"moo":"moo"}})


# Generated at 2022-06-22 05:50:28.805867
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-22 05:50:32.533671
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(Any(), Any(), Any())
    assert ite.if_clause is not None
    assert ite.then_clause is not None
    assert ite.else_clause is not None


# Generated at 2022-06-22 05:50:36.050962
# Unit test for constructor of class AllOf
def test_AllOf():
    validate = AllOf(Boolean()).validate
    error = AllOf(Boolean()).validate_or_error
    assert validate(True) == True
    assert validate(False) == False
    assert error(True)[1] is None
    assert error(False)[1] is None
    assert error(0)[1] is not None


# Generated at 2022-06-22 05:50:37.631269
# Unit test for constructor of class OneOf
def test_OneOf():
    one = OneOf(None)
    assert one is not None

# Generated at 2022-06-22 05:50:40.258145
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf(one_of=[
        Int(maximum=10),
        Int(minimum=10)
    ]).validate(12) == 12


# Generated at 2022-06-22 05:50:44.972688
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([
        Integer(max_value=10),
        Integer(min_value=10)
    ])
    print(one_of.validate(5))
    print(one_of.validate(11))


if __name__ == "__main__":
    test_OneOf_validate()

# Generated at 2022-06-22 05:50:47.542550
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test the type of the field
    assert(isinstance(NeverMatch(), Field))
    assert(isinstance(NeverMatch().validate(None), typing.Any))


# Generated at 2022-06-22 05:50:54.629432
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    
    from typesystem.fields import Integer

    if_clause = Integer(minimum=1, maximum=100)
    then_clause = Integer(maximum=50)
    else_clause = Integer(maximum=10)
    ite = IfThenElse(if_clause, then_clause, else_clause)

    value = 50

    validated = ite.validate(value)
    assert validated == value


# Generated at 2022-06-22 05:50:56.539207
# Unit test for constructor of class OneOf
def test_OneOf():
    to_test = OneOf([])
    assert to_test.one_of == []



# Generated at 2022-06-22 05:50:59.362871
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()], allow_null=True)
    value, error = field.validate_or_error(None)
    assert value is None
    assert error is None

# Generated at 2022-06-22 05:51:23.485708
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Test validate method of class Field in case of the field is of type OneOf.
    """
    one_of_int_string = OneOf([types.Integer(), types.String])
    assert one_of_int_string.validate(3) == 3
    assert one_of_int_string.validate("3") == "3"
    with pytest.raises(ValueError) as error_info:
        one_of_int_string.validate(3.0)


# Generated at 2022-06-22 05:51:28.364986
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Field())
    n.validate(None)
    try:
        res, err = n.validate_or_error(None, False)
        assert err is None
        assert res is None
    except:
        assert False
    try:
        n.validate(1)
        assert False
    except:
        assert True

# Generated at 2022-06-22 05:51:29.051388
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	assert NeverMatch()

# Generated at 2022-06-22 05:51:32.131184
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    Test case for constructor of class IfThenElse
    """
    ifthenelse_obj = IfThenElse(Any(), Any())
    ifthenelse_obj.validate('value')

# Generated at 2022-06-22 05:51:36.765777
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Schema
    schema = Schema(fields={"field" : AllOf([AllOf([AllOf([Any()]), Any()]), Any()])})
    assert schema.validate({"field" : 1}) == {"field" : 1}
    assert schema.validate_or_error({"field" : 1}) == ({"field" : 1}, None)



# Generated at 2022-06-22 05:51:39.054233
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Arrange
    field = NeverMatch()

    # Act
    with pytest.raises(field.validation_error):
        field.validate("foo")


# Generated at 2022-06-22 05:51:40.530565
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated="")
    assert field.negated == ""

# Generated at 2022-06-22 05:51:47.541279
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create a class which contains the method to unit test
    class Test():
        def validate(self, value, strict=False):
            errors = None

    # Create a instance of the class to unit test
    test = Test()

    # Create a reference to the method to unit test
    target = OneOf.validate

    # Call the method to unit test
    result = target(test, value, strict)

    # Check the result
    assert result == None # TODO: implement your test here


# Generated at 2022-06-22 05:51:57.955990
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = types.Number()
    b = types.String()
    c = types.Integer()
    d = types.Text()
    OneOf_instance = OneOf([a,b,c,d])
    string = types.String(name="string")
    string.validate("a string")
    number = types.Number(name="number")
    number.validate(3.14)
    text = types.Text(name="text")
    text.validate("This is a string")
    # assert "no_match" in OneOf_instance.validate(string)
    # assert "multiple_matches" in OneOf_instance.validate(number)
    # assert OneOf_instance.validate(text) is None



# Generated at 2022-06-22 05:52:07.098355
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test if the function can act as the interface
    c = IfThenElse(Any(), Any())
    c.validate(1)

    # Test if the result is correct
    test_data = [
        [{"if": Any(), "then": Any(), "else": Any()}, 1, 1],
        [{"if": Any(), "then": Any(), "else": Any()}, "abc", None],
        [{"if": Int(gt=11), "then": Int(lt=0), "else": Int(gt=0)}, 5, None],
        [{"if": Int(gt=11), "then": Int(lt=0), "else": Int(gt=0)}, 20, 20],
    ]

    error = None
    test_result = []
    expected_result = []

    for test in test_data:
        expected

# Generated at 2022-06-22 05:52:41.599864
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-22 05:52:52.686357
# Unit test for method validate of class Not
def test_Not_validate():
    if_clause = Field(name='test-if')
    then_clause = Field(name='test-then')
    else_clause = Field(name='test-else')
    test_if_then_else = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause);
    expected_result = then_clause.validate(value=1)
    assert expected_result == test_if_then_else.validate(value=1)
    #expected_result = else_clause.validate(value=1)
    #assert expected_result == test_if_then_else.validate(value=1, strict=True)

# Generated at 2022-06-22 05:52:55.114185
# Unit test for constructor of class Not
def test_Not():
    negated = NeverMatch()
    if(Not(negated)):
        print("pass\n")
    else:
        print("fail\n")

# Generated at 2022-06-22 05:52:59.573252
# Unit test for constructor of class OneOf
def test_OneOf():
    test_OneOf = OneOf([])
    assert test_OneOf.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}
    assert test_OneOf.one_of == []

# Generated at 2022-06-22 05:53:00.568606
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test = NeverMatch()
    print(test.errors)
    return


# Generated at 2022-06-22 05:53:04.826337
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Boolean(True), Boolean(False))
    assert field.if_clause == Boolean(True)
    assert field.then_clause == Boolean(False)
    assert field.else_clause == Any()


# Generated at 2022-06-22 05:53:09.853743
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema = OneOf([String(), Integer()])
    assert schema.validate("123") == "123"
    assert schema.validate(123) == 123
    assert schema.validate(123.0) == ValueError
    assert schema.validate(None) == ValueError


# Generated at 2022-06-22 05:53:12.508686
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert x.validate('a') == 'a'

# Generated at 2022-06-22 05:53:13.959445
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field


# Generated at 2022-06-22 05:53:16.228170
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    assert f.validate(None) == None
    assert f.validate('') == ''
