

# Generated at 2022-06-22 05:46:02.635864
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause=None,
        then_clause=None,
        else_clause=None
    )

    assert field.if_clause is not None
    assert field.then_clause is not None
    assert field.else_clause is not None

# Generated at 2022-06-22 05:46:09.011363
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(1, 2, 3)
    assert ite.if_clause == 1
    assert ite.then_clause == 2
    assert ite.else_clause == 3
    ite = IfThenElse(1, then_clause=2)
    assert ite.if_clause == 1
    assert ite.then_clause == 2
    assert ite.else_clause == Any()

# Generated at 2022-06-22 05:46:10.170300
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Integer(max_value=100), String()])
    field.validate(50)
    field.validate("sadf")


# Generated at 2022-06-22 05:46:15.465375
# Unit test for constructor of class OneOf
def test_OneOf():
    result = {"one_of": [Any()]}
    my_OneOf = OneOf([Any()])
    assert my_OneOf.__dict__ == result
    assert my_OneOf.metadata == {}
    assert my_OneOf.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}



# Generated at 2022-06-22 05:46:17.581281
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf(all_of=[])
    assert a.validate(3) == 3

# Generated at 2022-06-22 05:46:20.963560
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import typesystem
    from typesystem import fields

    field = typesystem.NeverMatch()
    with pytest.raises(typesystem.ValidationError):
        field.validate(123)

# Generated at 2022-06-22 05:46:32.100285
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any(), NeverMatch()])
    assert field.validate(1) == 1
    try:
        field.validate(2)
    except Exception as exc:
        assert str(exc) == 'Must match exactly one of the sub-items, but matched more than one.'
        assert exc.code == 'multiple_matches'
        assert exc.field == field
        assert exc.validator == 'one_of'
        assert exc.value == 2
    try:
        field.validate(3)
    except Exception as exc:
        assert str(exc) == 'Must match exactly one of the sub-items, but not matched.'
        assert exc.code == 'no_match'
        assert exc.field == field
        assert exc.validator == 'one_of'
        assert exc.value == 3

# Unit

# Generated at 2022-06-22 05:46:36.812312
# Unit test for constructor of class OneOf
def test_OneOf():
    # given
    field = Field(
    )
    one_of = [
        field,
    ]
    kwargs={
    }

    # when
    instance = OneOf(one_of, **kwargs)

    # then
    assert instance.one_of == one_of


# Generated at 2022-06-22 05:46:38.503424
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__doc__ is not None



# Generated at 2022-06-22 05:46:48.794536
# Unit test for constructor of class OneOf
def test_OneOf():
    # init function
    string1 = '{"a": {"b": {"c": [1,2,3]}}}'
    string2 = '{"a": {"b": {"c": [4,5,6]}}}'
    
    test = OneOf(one_of = [])
    assert test.one_of == [], f"expected = [], actual = {test.one_of}"

    # validate function
    value = '{"a": {"b": {"c": [1,5,3]}}}'
    error = None
    assert test.validate_or_error(value, strict = False) == (value, error)
    
    value = '{"a": {"b": {"c": [5,5,5]}}}'
    error = None

# Generated at 2022-06-22 05:46:54.037510
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause = Boolean(),
                      then_clause = String()
                      ).validate(True) == 'True'

# Generated at 2022-06-22 05:46:57.806333
# Unit test for constructor of class OneOf
def test_OneOf():
    """
    The constructor for OneOf has an assertion that requires one_of to be a
    list of Field.
    """
    with pytest.raises(AssertionError):
        OneOf(one_of=typing.List[Field]())


# Generated at 2022-06-22 05:46:58.592027
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert False


# Generated at 2022-06-22 05:47:03.950403
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer, String
    test1 = AllOf(all_of=[Integer(), Integer()])
    test2 = AllOf(all_of=[Integer(), String()])
    assert test1.validate(1) == 1
    assert test2.validate(1) is None

# Generated at 2022-06-22 05:47:13.253428
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String
    from typesystem.types import JSONSchema

    schema = JSONSchema(
        {"if": Integer(), "then": String(), "else": String()}, name="IfThenElse"
    )
    # success case
    result = schema.validate({"if": 3, "then": "a", "else": "b"})
    assert result == {"if": 3, "then": "a", "else": "b"}
    # success case
    result = schema.validate({"if": 2, "then": "a", "else": "b"})
    assert result == {"if": 2, "then": "a", "else": "b"}
    # fail case

# Generated at 2022-06-22 05:47:22.275897
# Unit test for method validate of class Not
def test_Not_validate():
    class User:
        name: str
        age: int

    class Schema(main.BaseSchema):
        name: str
        age: Not(int)

    schema = Schema(context={"user_model": User()})
    assert schema.validate({"name": "Flask", "age": "Not a number"}) == {"name": "Flask", "age": "Not a number"}
    assert schema.validate({"name": "Flask", "age": 1}) == {"name": "Flask", "age": 1}


# Generated at 2022-06-22 05:47:23.141675
# Unit test for constructor of class Not
def test_Not():
    assert Not(None).negated == None

# Generated at 2022-06-22 05:47:27.477611
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors['never'] == "This never validates."
    nm = NeverMatch(name='a')
    assert nm.name == 'a'


# Generated at 2022-06-22 05:47:30.665101
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Integer(max_value=100)])
    assert field.validate(5) == 5


# Generated at 2022-06-22 05:47:38.241387
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    x = AllOf([Integer()], name="x")
    y = AllOf([String()], name="y")
    z = AllOf([x, y], name="z")
    #t1
    z.validate({"x": 3, "y": "hi"}, strict=True)
    #t2
    z.validate({"x": "3", "y": "hi"}, strict=True)
    #t3
    z.validate({"x": 3, "y": 3}, strict=True)
    #t4
    assert z.validate({"x": "3", "y": 3}, strict=True) == ({"x": "3", "y": 3})


# Generated at 2022-06-22 05:47:48.949511
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # function that returns the sum of two numbers
    def add(num1, num2):
        return num1+num2
    # Create an instance of IfThenElse class to test above method
    ifthenelse = IfThenElse(String(),Number(),Number())
    assert ifthenelse.validate("number",strict=False) == 0
    assert ifthenelse.validate("number",strict=True) == 0
    assert ifthenelse.validate("number",strict=False) == 0

# Generated at 2022-06-22 05:47:54.346789
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String, Integer

    class MyAllOf(AllOf):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__([String(), Integer()], **kwargs)

    all_of = MyAllOf(label="test")
    assert all_of.validate(123) == 123
    assert all_of.validate("123") == "123"



# Generated at 2022-06-22 05:47:57.623163
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.fields import Boolean
    from typesystem.fields import Integer
    a = AllOf([String(), Boolean(), Integer()], nullable=True)
    assert isinstance(a, AllOf)
    assert isinstance(a, Field)


# Generated at 2022-06-22 05:48:08.502902
# Unit test for constructor of class Not
def test_Not():
    negated = Field()
    negated_val = 'abcd'
    negated_strict = False
    negated_result = 'pass'
    # set the validate method
    def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
        if (value == negated_val) and (strict == negated_strict):
            return negated_result
    negated.validate = validate.__get__(negated, type(negated))

    # set the validate_or_error method
    def validate_or_error(self, value: typing.Any, strict: bool = False) -> typing.Any:
        if (value == negated_val) and (strict == negated_strict):
            return negated_result, None
        return negated_result, 'error'

# Generated at 2022-06-22 05:48:12.687933
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any())
    assert field.validate(3) == 3

    field = IfThenElse(if_clause=Any(), then_clause=None)
    assert field.validate(3) == 3

    field = IfThenElse(if_clause=NeverMatch(), else_clause=None)
    assert field.validate(3) == 3

# Generated at 2022-06-22 05:48:15.217394
# Unit test for method validate of class Not
def test_Not_validate():
    items = 'hello'
    validator=Not(items)
    assert validator.validate(items)


# Generated at 2022-06-22 05:48:21.743150
# Unit test for constructor of class OneOf
def test_OneOf():
    a=Field()
    b=Field(required=True)
    c=Field()
    d=Field()
    e=Field()
    o=OneOf([a,b,c],description='test',label='test',help_text='test')
    assert o.one_of==[a,b,c]
    assert o.description=='test'
    assert o.label=='test'
    assert o.help_text=='test'


# Generated at 2022-06-22 05:48:23.120558
# Unit test for constructor of class AllOf
def test_AllOf():
    test1 = AllOf([Field()])
    assert test1

# Generated at 2022-06-22 05:48:32.400183
# Unit test for method validate of class Not
def test_Not_validate():
    x = {
        'description': 'description',
        'nullable': False,
        'required': False,
        'read_only': False,
        'write_only': False,
        'allow_empty': True,
        'default': None,
        'error_messages': {
            'required': 'This field is required.',
            'invalid': 'Value may not be null.',
        },
        'source': None}
    y = Not(Number(**x))
    # y.validate(null)
    # y.validate("a")
    # y.validate(1)
    assert y.validate("a") == "a"


# Generated at 2022-06-22 05:48:33.812445
# Unit test for constructor of class Not
def test_Not():
    AllOf.__init__()
    Not.__init__()


# Generated at 2022-06-22 05:48:44.198004
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f1 = Field(required=True)
    f2 = Field(required=True)

    assert True == AllOf([f1, f2], required=True).validate('test')
    assert True == AllOf([f1, f2], required=True).validate('test')

    try:
        AllOf([f1, f2], required=True).validate(None)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-22 05:48:51.857856
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = Integer(minimum=3)
    b = Integer(minimum=5)
    one_of = OneOf([a,b])
    assert one_of.validate(3) == 3
    assert one_of.validate(5) == 5
    assert_raises(ValidationError, one_of.validate, 2)
    assert_raises(ValidationError, one_of.validate, 4)
    assert_raises(ValidationError, one_of.validate, 6)

test_OneOf_validate()
    

# Generated at 2022-06-22 05:48:56.780019
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    def test_ref_class(cls):
        assert cls.if_clause == cls.if_clause
        assert cls.then_clause == cls.then_clause
        assert cls.else_clause == cls.else_clause
        assert cls.if_clause != cls.then_clause
        assert cls.if_clause != cls.else_clause

    test_ref_class(IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()))
    test_ref_class(IfThenElse(if_clause=Any()))

# Generated at 2022-06-22 05:48:58.642737
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    assert None == n.validate(None)
    assert 1 == n.validate(1)

# Generated at 2022-06-22 05:49:07.641936
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_statement = IfThenElse(int,
                        then_clause=str,
                        else_clause=bool)
    # 1. If-clause is satisfied, then-clause is satisfied
    if_statement.validate(1)
    # 2. If-clause is not satisfied, then-clause is not satisfied
    if_statement.validate(1.1)
    # 3. If true, then validate on then-clause, else validate on else-clause
    assert if_statement.validate(1) == "1"
    assert if_statement.validate(1.1) == True



# Generated at 2022-06-22 05:49:13.504041
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(0) == 0
    assert not_field.validate(1) == 1
    assert not_field.validate("0") == "0"
    assert not_field.validate("1") == "1"
    assert not_field.validate(None) == None


# Generated at 2022-06-22 05:49:17.331894
# Unit test for constructor of class Not
def test_Not():
    assert str(Not(negated=Any())) == "Not(negated=Any())"
    assert str(Not(negated=None)) == "Not(negated=Any())"


# Generated at 2022-06-22 05:49:19.878537
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    candidate = None
    match_count = 0

    error_list = []

    if error_list == []:
        return True
    else: 
        return False


# Generated at 2022-06-22 05:49:22.824497
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__name__ == "OneOf"
    assert OneOf.__qualname__ == "OneOf"
    assert OneOf.__module__ == "typesystem.json_schema.fields"


# Generated at 2022-06-22 05:49:34.473199
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Define a valid type from the set of types in one_of
    valid_type = typesystem.Integer()
    # Define an invalid type from the set of types in one_of
    invalid_type = typesystem.String()

    # Define a value that only valid type can accept
    valid_value = 2
    # Define a value that the valid and invalid types can both accept
    invalid_value = '2'

    # Instantiate OneOf field with valid_type and invalid_type
    oneOf_field = typesystem.OneOf([valid_type, invalid_type])

    # Assert that valid_value will validate as valid
    assert oneOf_field.validate(valid_value)

    # Assert that invalid_value will fail validation

# Generated at 2022-06-22 05:49:44.515905
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = {'a': 'b'}
    then_clause = {'a': 'b'}
    else_clause = {'a': 'b'}

    assert IfThenElse(if_clause, then_clause, else_clause).validate({'a':'b'}) == then_clause.validate({'a':'b'})
    assert IfThenElse(if_clause, then_clause, else_clause).validate({'b':'c'}) == else_clause.validate({'b':'c'})


# Generated at 2022-06-22 05:49:45.022890
# Unit test for constructor of class OneOf
def test_OneOf():
    pass

# Generated at 2022-06-22 05:49:47.007957
# Unit test for constructor of class AllOf
def test_AllOf():
    """
    Testing the constructor of class AllOf
    """
    AllOf(all_of=["Test2", "Test3"], strict="Test1")



# Generated at 2022-06-22 05:49:47.674035
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert True

# Generated at 2022-06-22 05:49:48.996462
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    print(nm)
    return 0


# Generated at 2022-06-22 05:49:53.511541
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    result, error = field.validate_or_error(10)
    assert error is None

    field = Not(Integer(ge=10))
    result, error = field.validate_or_error(10)
    assert error == {"negated": "Must not match."}


# Generated at 2022-06-22 05:49:56.968555
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        NeverMatch().validate(True)
    except Exception as e:
        assert e.message == "This never validates."



# Generated at 2022-06-22 05:49:57.939060
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    AllOf(all_of=[int, float])

# Generated at 2022-06-22 05:50:01.996844
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import String

    name = String(max_length=10)
    email = String(max_length=10)

    all_of = AllOf([name, email])
    all_of.validate("test@test.test")

test_AllOf_validate()


# Generated at 2022-06-22 05:50:03.858701
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(2, 2)
    assert a.then_clause == 2


# Generated at 2022-06-22 05:50:09.468844
# Unit test for method validate of class Not
def test_Not_validate():
    a = Not(Number())
    b = Not(Number(), allow_null=True)
    assert a.validate(1) == 1 and a.validate(None) == 1
    assert b.validate(1) == 1 and b.validate(None) == None



# Generated at 2022-06-22 05:50:12.235297
# Unit test for constructor of class AllOf
def test_AllOf():
    field1 = AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[])])])
    assert field1 is not None



# Generated at 2022-06-22 05:50:17.453203
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Simple OneOf validation
    # format: off
    x = OneOf(
        one_of=[
            String(),
            Integer()
        ],
        strict=True
    )
    assert x.validate("string") == "string"
    assert x.validate(1) == 1
    # format: on


# Generated at 2022-06-22 05:50:21.432766
# Unit test for constructor of class AllOf
def test_AllOf():
    from tests.fixtures import schema
    f = AllOf(
        all_of=[schema.builtin_field_number, schema.builtin_field_string]
    )
    assert isinstance(f, AllOf)

# Generated at 2022-06-22 05:50:23.401146
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(String())
    assert f
    assert f.validate('ssss')


# Generated at 2022-06-22 05:50:25.763999
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    with pytest.raises(AssertionError):
        IfThenElse(if_clause=None, allow_null=True)

# Generated at 2022-06-22 05:50:37.631961
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(min_length=2)
    then_clause = Field(max_length=4)
    else_clause = Field(max_length=5)
    test_instance = IfThenElse(if_clause, then_clause, else_clause)
    # Valid values
    assert test_instance.validate('ab') == 'ab'
    assert test_instance.validate('abc') == 'abc'
    assert test_instance.validate('abcde') == 'abcde'
    # Invalid values
    from typesystem.exceptions import ValidationError
    with pytest.raises(ValidationError):
        # value must be of type str
        test_instance.validate(0)

# Generated at 2022-06-22 05:50:47.037847
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class Object:
        def __init__(self, data: typing.Any) -> None:
            self.data = data

# Generated at 2022-06-22 05:50:49.092737
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch(name="my_field")
    print(n.name)  # my_field


# Generated at 2022-06-22 05:50:54.893035
# Unit test for constructor of class Not
def test_Not():
    class TestNot():
        def __init__(self):
            self.construction_string = "test_string"
            self.test_field = Not(String(max_length=4))

    test_not = TestNot()
    assert test_not.test_field.negated.max_length == 4


# Generated at 2022-06-22 05:51:01.735205
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(None) == 'None'
    assert NeverMatch().validate('test') == 'test'
    assert NeverMatch().validate(1) == 1
    assert NeverMatch().validate(True) == True


# Generated at 2022-06-22 05:51:10.495093
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # initialise
    file = open("attributes.json", "r")

    # load data into dictionary
    attributes = load(file)
    file.close()
    json_dict = {"attributes": attributes}
   
    # create IfThenElse field 
    field = IfThenElse(attributes["name"], attributes["age"])

    # create JSON object
    obj = JsonObject(json_dict)

    # create schema
    schema = Schema(obj)

    # unit test
    assert isinstance(field.validate("alice"), str)
    assert isinstance(field.validate(15), int)

# Generated at 2022-06-22 05:51:11.899812
# Unit test for constructor of class OneOf
def test_OneOf():
    t = OneOf([])
    assert t.one_of==[]

# Generated at 2022-06-22 05:51:13.366916
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[Any()])
    assert field.validate(None) == None


# Generated at 2022-06-22 05:51:24.854054
# Unit test for constructor of class OneOf
def test_OneOf():
    '''
    Test the constructor of class ``OneOf``
    '''

    class test_OneOf(unittest.TestCase):
        '''
        Testcase for the constructor of class ``OneOf``
        '''

        # initialization logic for the test case
        def setUp(self):
            '''
            Initialize test variables
            '''

            self.one_of = Field()
            self.kwargs = {'description':'description'}
            self.test_oneof = OneOf(self.one_of, **self.kwargs)

        def test_oneof_instance(self):
            '''
            Test for the instance of ``OneOf``
            '''

            self.assertIsInstance(self.test_oneof, OneOf)


# Generated at 2022-06-22 05:51:27.206371
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(field.validation_error):
        assert field.validate("something")


# Generated at 2022-06-22 05:51:32.033939
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem
    typed_int = typesystem.Integer()
    typed_str = typesystem.String()
    all_of_field = AllOf([typed_int, typed_str])
    with pytest.raises(ValueError):
        all_of_field.validate("Hello world")

test_AllOf_validate()

# Generated at 2022-06-22 05:51:36.127942
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    ite = IfThenElse(if_clause, then_clause, else_clause)
    res = ite.validate(None)
    assert res == None

# Generated at 2022-06-22 05:51:41.438255
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Test case AllOf.validate
    """
    # Initialization and setup
    all_of = AllOf(all_of=[])
    # Expected output
    expected_output = []
    # Performing the test
    actual_output = all_of.validate(expected_output)
    # Verifying the results
    assert actual_output == expected_output


# Generated at 2022-06-22 05:51:42.884985
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}

# Generated at 2022-06-22 05:51:51.741139
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert hasattr(a, 'errors')


# Generated at 2022-06-22 05:51:52.407113
# Unit test for constructor of class Not
def test_Not():
    assert True

# Generated at 2022-06-22 05:51:53.562771
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	foo = NeverMatch()


# Generated at 2022-06-22 05:51:55.010987
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    value = None
    assert field.validate(value)

# Generated at 2022-06-22 05:51:57.166744
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([])
    assert field.validate(1) == 1


# Generated at 2022-06-22 05:52:03.873646
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Test different values:
    # - Test passing value
    # - Test passing None
    # - Test passing value and passing strict
    nevermatch_field = NeverMatch()
    with pytest.raises(FieldValidationError):
        nevermatch_field.validate('Hello')
    with pytest.raises(FieldValidationError):
        nevermatch_field.validate(None)
    with pytest.raises(FieldValidationError):
        nevermatch_field.validate('Hello', strict=True)



# Generated at 2022-06-22 05:52:08.093595
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nvMtch = NeverMatch(label=None, description=None, required=True, write_only=False, allow_null=False)
    with raises(nvMtch.validation_error):
        nvMtch.validate(None)

# Generated at 2022-06-22 05:52:13.185830
# Unit test for constructor of class AllOf
def test_AllOf():
    field1 = Field()
    field2 = Field()
    field_list = [field1, field2]
    allOf_test = AllOf(field_list)
    assert allOf_test.all_of == field_list


# Generated at 2022-06-22 05:52:20.857036
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    #basic
    try:
        _NeverMatch = NeverMatch(**{'description': 'description'})
        flag = 1
    except TypeError:
        flag = 0
    assert flag == 0, "TypeError"

    #advanced
    try:
        _NeverMatch = NeverMatch()
        flag = 1
    except TypeError:
        flag = 0
    assert flag == 0, "TypeError"


# Generated at 2022-06-22 05:52:23.104854
# Unit test for constructor of class OneOf
def test_OneOf():
    A = OneOf(one_of = [
        CharField(max_length = 100)
    ])
    assert A.one_of[0].max_length == 100


# Generated at 2022-06-22 05:52:39.778662
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Arrange
    field = NeverMatch()

    # Act
    with pytest.raises(field.validation_error):
        field.validate(None)



# Generated at 2022-06-22 05:52:40.932664
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[]) == OneOf()

# Generated at 2022-06-22 05:52:43.012583
# Unit test for constructor of class OneOf
def test_OneOf():

    myOneOf = OneOf(['test'])
    assert myOneOf.one_of == ['test']

# Generated at 2022-06-22 05:52:45.700429
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        field = NeverMatch()
    except Exception:
        assert True
    else:
        assert False

# Generated at 2022-06-22 05:52:49.212487
# Unit test for constructor of class AllOf
def test_AllOf():
	try :
		x = AllOf(all_of=[],allow_null=False)
	except:
		assert False
	assert True


# Generated at 2022-06-22 05:52:53.505506
# Unit test for method validate of class Not
def test_Not_validate():
    try:
        Not(String()).validate(1)
    except ValidationError as e:
        if e.error != "negated":
            return False
        if e.value != 1:
            return False
    except:
        return False
    return True

# Generated at 2022-06-22 05:52:54.401404
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of = [Int(), Bool()])


# Generated at 2022-06-22 05:52:55.902641
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()])

# Generated at 2022-06-22 05:53:03.349084
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Test for correct handling of constructor, with provided values for optional
    # parameters "then_clause" and "else_clause"
    type = IfThenElse(True, True, False)
    assert type.if_clause == True
    assert type.then_clause == True
    assert type.else_clause == False

    # Test to ensure that optional parameters default to None if not provided
    type = IfThenElse(True)
    assert type.then_clause == None
    assert type.else_clause == None

# Tests for the class' validate() method

# Generated at 2022-06-22 05:53:14.794380
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Create an instance of AllOf to test
    all_of = AllOf([Integer(), String(), Float()])
    # Make sure that the instance has attribute "all_of"
    assert all_of.all_of is not None
    # Make sure that the instance has the method "validate"
    assert callable(all_of.validate())
    # Make sure that the instance raises error for improper input
    try:
        all_of.validate("Hello, World!")
        print("Expected validation error")
    except ValueError as e:
        print("Successfully returned a validation error")
    try:
        all_of.validate(1)
        print("Expected validation error")
    except ValueError as e:
        print("Successfully returned a validation error")
    # Make sure that the instance returns the correct output

# Generated at 2022-06-22 05:54:16.581160
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=True)\
        .validate("something") == "something"
    assert IfThenElse(if_clause=False)\
        .validate("something") == "something"
    assert IfThenElse(if_clause=False, else_clause=False)\
        .validate("something") is None

# Generated at 2022-06-22 05:54:18.559371
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[])
    assert one_of.one_of == []

# Generated at 2022-06-22 05:54:25.748565
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import json as m_json
    import typing as m_typing
    import typesystem as m_typesystem
    import typesystem.fields as m_typesystem_fields
    import typesystem.types as m_typesystem_types
    ####
    class Integer(m_typesystem_fields.Integer):
        def validate(self, value: int, strict: bool = False) -> typing.Any:
            return super().validate(value, strict=strict)
    ####
    class Number(m_typesystem_fields.Number):
        def validate(self, value: float, strict: bool = False) -> typing.Any:
            return super().validate(value, strict=strict)
    # end class Number
    ####

# Generated at 2022-06-22 05:54:27.986288
# Unit test for constructor of class AllOf
def test_AllOf():
    obj = AllOf(a)
    assert obj.all_of == a

# Generated at 2022-06-22 05:54:31.920240
# Unit test for method validate of class Not
def test_Not_validate():
    error_msg = "Must not match."
    nf = Not(NeverMatch())
    assert error_msg == nf.errors['negated']
    assert nf.validate(None) == None
    assert nf.validate(123) == 123


# Generated at 2022-06-22 05:54:40.625260
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # test case 1
    obj = OneOf([], label="OneOf", description="", required=False, allow_null=False,
                id="oneOf", schema={'type': 'string'})
    value = ""
    strict = False
    obj.validate(value, strict)
    # test case 2
    obj = OneOf([], label="OneOf", description="", required=False, allow_null=False,
                id="oneOf", schema={'type': 'string'})
    value = ""
    strict = False
    obj.validate(value, strict)


# Generated at 2022-06-22 05:54:45.366346
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = typing.List[typing.Any]
    t_clause = IfThenElse(
        if_clause=a,
        then_clause=a,
        else_clause=a,
        description="",
    )

    assert t_clause.validate([]) == []



# Generated at 2022-06-22 05:54:47.494410
# Unit test for constructor of class AllOf
def test_AllOf():
    print()

    a = AllOf([])
    print(a)
    assert isinstance(a, AllOf)


# Generated at 2022-06-22 05:54:48.794717
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf([]), Field)

# Generated at 2022-06-22 05:54:54.300646
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(if_clause=Int(), then_clause=Str(), else_clause=Int())
    assert schema.validate(1) == 1
    assert schema.validate("1") == "1"

# Generated at 2022-06-22 05:55:26.610460
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_never_match = NeverMatch(name="test")
    assert test_never_match != None


# Generated at 2022-06-22 05:55:30.455308
# Unit test for constructor of class AllOf
def test_AllOf():
    anyField = Any()

    # Test with all valid parameters
    field = AllOf([anyField])
    assert field.all_of == [anyField]

    # Test with invalid parameter
    with pytest.raises(AssertionError):
        AllOf(None)



# Generated at 2022-06-22 05:55:36.205311
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Int()).validate(1.0) == 1.0
    assert Not(Int()).validate(1) == 1
    assert Not(Float()).validate(1) == 1
    assert Not(String()).validate(1) == 1
    with pytest.raises(typesystem.Error) as excinfo:
        Not(Any()).validate(1)
    excinfo.match('Must not match.')


# Generated at 2022-06-22 05:55:46.686412
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(
        if_clause=IfThenElse(
            if_clause=Field(),
            then_clause = Field(default=None),
        ),
        then_clause = Field(default=None),
        else_clause = Field(default=None),
    ).validate(True) == True
    assert IfThenElse(
        if_clause=Field(),
        then_clause = Field(default=None),
        else_clause = Field(default=None),
    ).validate(False) == None
    assert IfThenElse(
        if_clause=Field(),
        then_clause = Field(default=True),
        else_clause = Field(default=False),
    ).validate(True) == True

# Generated at 2022-06-22 05:55:51.445015
# Unit test for method validate of class Not
def test_Not_validate():
    Field = Not({})
    try:
        Field.validate(None, strict = True)
        assert False
    except Exception as E:
        assert E.messages == {'negated': 'Must not match.'}


# Generated at 2022-06-22 05:56:00.039511
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = NeverMatch(name="if_clause")
    then_clause = NeverMatch(name="then_clause")
    else_clause = NeverMatch(name="else_clause")
    if_then_else = IfThenElse(
        if_clause=if_clause, then_clause=then_clause, else_clause=else_clause
    )
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause
