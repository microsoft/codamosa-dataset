

# Generated at 2022-06-22 05:46:06.580506
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer, Float, String
    from typesystem.types import OneOf, Object

    schema = Object(properties={
        "id": Integer(),
        "score": Float()
    })

    data = {"id": 32}

    one_of_field = OneOf([schema, String()])
    print(one_of_field.validate(data))
    print(one_of_field.validate("\"test\""))

    # Valid - the first one matches.
    # Invalid - multiple ones match.
    # Invalid - none of them match.


# Generated at 2022-06-22 05:46:10.184952
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(0) == 0
    assert field.validate(1) == 1

# Generated at 2022-06-22 05:46:18.205628
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import typesystem
    ifField = typesystem.Integer()
    thenField = typesystem.String()
    elField = typesystem.Boolean()
    ifThenElseField = IfThenElse(ifField, thenField, elField)
    assert isinstance(ifThenElseField, typesystem.Field)
    assert isinstance(ifThenElseField.if_clause, typesystem.Integer)
    assert isinstance(ifThenElseField.then_clause, typesystem.String)
    assert isinstance(ifThenElseField.else_clause, typesystem.Boolean)


# Generated at 2022-06-22 05:46:28.177158
# Unit test for constructor of class Not
def test_Not():
    # Test 1 - see if valid instance of Not can be generated and can be
    # validated
    try:
        not_field = Not(Any())
        assert(not_field.validate(43) == 43)
    except Exception as e:
        raise Exception("test_Not() 1 - unexpected exception: " + str(e))

    # Test 2 - see if exception if raised when input is a field of None type
    try:
        not_field = Not(None)
    except Exception as e:
        assert(type(e) == AssertionError)
    else:
        raise Exception("test_Not() 2 - expected exception failed to be raised")


# Generated at 2022-06-22 05:46:33.943332
# Unit test for method validate of class Not
def test_Not_validate():
    # Setup
    class Int(Not):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(
                negated=Number(**kwargs),
                **kwargs
            )
    # Exercise
    field = Int()

    # Verify
    assert field.validate(1) is None
    # Cleanup - none necessary

# Generated at 2022-06-22 05:46:38.043134
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    try:
        from typesystem.fields import AllOf, Integer
        a=AllOf([Integer()])
        a.validate(3)
    except Exception as e:
        assert False
    else:
        assert True


# Generated at 2022-06-22 05:46:38.719108
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass

# Generated at 2022-06-22 05:46:41.385959
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    t = NeverMatch()
    try:
        t.validate(None)
    except Exception as e:
        assert str(e) == "This never validates."


# Generated at 2022-06-22 05:46:49.944001
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # IfThenElse(if_clause=None,then_clause=None,else_clause=None)
    ite = IfThenElse(if_clause=None,then_clause=None,else_clause=None)
    # ite.validate(value=None,strict=False) => None
    assert ite.validate(value=None,strict=False) is None
    # ite.validate(value=None,strict=True) => TypeError
    try:
        ite.validate(value=None,strict=True)
    except TypeError as err:
        assert True
    else:
        assert False

# Generated at 2022-06-22 05:46:52.446361
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch(label="test")
    never_match_alt = NeverMatch(l="test")
    assert never_match.label == none_match_alt.label


# Generated at 2022-06-22 05:47:00.758018
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """
    Test constructor of class NeverMatch
    """
    # Test 1:
    try:
        field = NeverMatch()
    except AssertionError:
        pass
    else:
        assert False

    # Test 2:
    try:
        field = NeverMatch(allow_null=True)
    except AssertionError:
        pass
    else:
        assert False


# Generated at 2022-06-22 05:47:05.952846
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    def get_field():
        return IfThenElse(
            Integer(max_value=5),
            then_clause=Integer(max_value=10),
            else_clause=Integer(max_value=1),
        )
    field = get_field()
    assert field.validate(6) == 10
    assert field.validate(2) == 2


# Generated at 2022-06-22 05:47:06.863440
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(1,2,3)
    pass

# Generated at 2022-06-22 05:47:14.834384
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Schema
    from typesystem.fields import String, Integer

    class SubType(Schema):
        s = String(max_length=10)

    schema = SubType()
    obj = SubType({"s": "integration-test"})
    oneof = OneOf(
        [
            Schema({"i": Integer()}),
            SubType({"s": String(max_length=5)}),
        ]
    )
    oneof.validate(obj, strict=True)
    # fail case
    try:
        oneof.validate(obj, strict=True)
    except Exception as e:
        assert(isinstance(e, oneof.validation_error))
        assert(e.code == "no_match" or e.code == "multiple_matches")

# Generated at 2022-06-22 05:47:22.359237
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem.fields import ValidationError
    field = NeverMatch()
    field.validation_error = ValidationError
    value = "123"
    try:
        field.validate(value, strict = False)
    except ValidationError:
        print("Validation Error: True")
    else:
        print("Validation Error: False")


# Generated at 2022-06-22 05:47:27.355002
# Unit test for constructor of class Not
def test_Not():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    Γ = Not(negated=A(), help_text="Not A")

    # Valid
    Γ.validate(A())
    Γ.validate(B())

    # Invalid
    with pytest.raises(ValidationError):
        Γ.validate(A())

# Generated at 2022-06-22 05:47:33.586800
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    string_field = String()
    integer_field = Integer()
    allof_field = AllOf([integer_field, string_field])
    with pytest.raises(TypeSystemError) as exc:
        allof_field.validate(10)
    assert str(exc.value) == (
        "10 is not a 'string'\n"
        "10 is not a 'integer'"
    )



# Generated at 2022-06-22 05:47:35.688269
# Unit test for constructor of class AllOf
def test_AllOf():
    assert not isinstance(AllOf, Field)


# Generated at 2022-06-22 05:47:37.110273
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert isinstance(x, NeverMatch)


# Generated at 2022-06-22 05:47:41.941009
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # type: () -> None
    IfThenElse = from_string('''
    If:
    - Null
    Then:
    - Null
    Else:
    - Null
    ''')
    json_validator = IfThenElse(If=[Null()], Then=[Null()], Else=[Null()])
    json_validator.validate(None)
    json_validator.validate(None)
    assert True

test_IfThenElse_validate()

# Generated at 2022-06-22 05:48:11.670098
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([typesystem.Integer(), typesystem.String()])
    assert f.validate(7) == 7
    assert f.validate('hi') == 'hi'
    with pytest.raises(typesystem.ValidationError):
        f.validate(True)


# Generated at 2022-06-22 05:48:16.205249
# Unit test for constructor of class OneOf
def test_OneOf():
    all_of_field1 = AllOf([Any(), Any()])
    all_of_field2 = AllOf([Any(), Any()])

    one_of_field1 = OneOf([all_of_field1, all_of_field2])



# Generated at 2022-06-22 05:48:17.271652
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-22 05:48:20.411932
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(field.ValidationError) as excinfo:
        field.validate('')
    assert excinfo.value.code == 'never'


# Generated at 2022-06-22 05:48:22.236477
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert isinstance(field, OneOf)



# Generated at 2022-06-22 05:48:23.264506
# Unit test for constructor of class AllOf
def test_AllOf():
    assert issubclass(AllOf, Field)

# Generated at 2022-06-22 05:48:24.615472
# Unit test for constructor of class Not
def test_Not():
    field = Not(Number())
    assert field.negated == Number()

# Generated at 2022-06-22 05:48:28.158945
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.errors['never'] == 'This never validates.'
    try:
        field.validate(None, False)
    except Exception as e:
        print(e)


# Generated at 2022-06-22 05:48:33.813959
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch(optional=True)
    else_clause = NeverMatch()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    # Any value can validate else_clause
    if_then_else.validate(None)

# Generated at 2022-06-22 05:48:34.768459
# Unit test for constructor of class AllOf
def test_AllOf():
    pass

# Generated at 2022-06-22 05:48:41.925044
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()

# Generated at 2022-06-22 05:48:52.957903
# Unit test for method validate of class Not
def test_Not_validate():
    not_fields = []
    # Check the field with only schema
    f = Not(Any())
    v = f.validate("")
    assert f.validate("") == v

    # Check the field with only schema
    f = Not(Any())
    v = f.validate("")
    assert f.validate("") == v

    # Check the field with only schema
    f = Not(Any())
    v = f.validate("")
    assert f.validate("") == v

    # Check the field with only schema
    f = Not(Any())
    v = f.validate("")
    assert f.validate("") == v

    # Check the field with only schema
    f = Not(Any())
    v = f.validate("")
    assert f.validate("") == v

    #

# Generated at 2022-06-22 05:48:57.424035
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Any(), OneOf([Any()])]).validate(1) == 1
    error = OneOf([Any(), OneOf([Any()])]).validate_or_error(2)
    assert issubclass(error.__class__, ValidationError)

# Generated at 2022-06-22 05:49:02.459672
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer, String

    errors = {'multiple_matches': 'Matched more than one type.', 'no_match': 'Did not match any valid type.'}
    d1 = OneOf([Integer, String], name='test', errors=errors)

test_OneOf()

# Generated at 2022-06-22 05:49:12.308343
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    return
    from typesystem import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem import fields
    import pytest
    import json

    my_schema = Schema(fields=[
        IfThenElse(
            if_clause=String(min_length=3),
            then_clause=String(max_length=6),
            else_clause=String(max_length=3)
        )
    ])

    value_a = my_schema.validate({"en": "abcdef"})
    assert value_a == {"en": "abcdef"}

    value_b = my_schema.validate({"en": "ab"})
    assert value_b == {"en": "ab"}


# Generated at 2022-06-22 05:49:14.871508
# Unit test for constructor of class OneOf
def test_OneOf():
    field = Field()
    one_of = OneOf([field])
    assert one_of is not None


# Generated at 2022-06-22 05:49:17.243664
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.types import Integer
    one_of = OneOf([Integer()])
    assert one_of


# Generated at 2022-06-22 05:49:23.753989
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Item(typesystem.Schema):
        name = fields.String()
    class Cart(typesystem.Schema):
        items = fields.Array(
            IfThenElse(
                fields.String(),
                then_clause=Item(),
            )
        )
    cart1 = Cart({"items":["test"]})
    assert cart1.is_valid()
    cart2 = Cart({"items":[]})
    assert cart2.is_valid()

# Generated at 2022-06-22 05:49:26.891734
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([Integer()])
    v = f.validate(1)
    assert v == 1

    with pytest.raises(ValidationError):
        f.validate("1")



# Generated at 2022-06-22 05:49:29.178001
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    value = "test"
    strct = False
    assert NeverMatch().validate(value, strct) == None


# Generated at 2022-06-22 05:49:37.188223
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__init__

# Generated at 2022-06-22 05:49:38.080567
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-22 05:49:39.792896
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(label='a').label == 'a'


# Generated at 2022-06-22 05:49:45.993317
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated = None)
    field.validate(None)
    assert_field_error(field, 'negated')
    assert field.validate(1) == 1
    assert field.validate(0) == 0
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate('test_string') == 'test_string'


# Generated at 2022-06-22 05:49:48.883140
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    inst = IfThenElse(Integer(), String())
    assert inst.validate(1) == "1"
    assert inst.validate("one") == "one"

    inst = IfThenElse(Integer(), then_clause=String(), else_clause=Integer())
    assert inst.validate(1) == "1"
    assert inst.validate("one") == 1

# Generated at 2022-06-22 05:49:51.152760
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([], error_messages={})
    field.validate({"a": {"b": 1}}, strict=False)



# Generated at 2022-06-22 05:49:52.139187
# Unit test for method validate of class Not
def test_Not_validate():
    pass



# Generated at 2022-06-22 05:49:53.136479
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True


# Generated at 2022-06-22 05:49:56.323126
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(ValidationError):
        NeverMatch().validate(0)


# Generated at 2022-06-22 05:50:05.020517
# Unit test for constructor of class OneOf
def test_OneOf():
    length = AllOf(
        [
            Field(min_length=1),
            Field(min_length=2),
            Field(min_length=3),
            Field(min_length=4),
        ]
    )
    # Success case
    length.validate("My name is Mayank.")
    with pytest.raises(TypesystemError) as excinfo:
        result = length.validate("")
    assert str(excinfo.value) == "Did not match any valid type."
    # Failure case
    assert str(excinfo.value) == "Did not match any valid type."
    with pytest.raises(TypesystemError) as excinfo:
        result = length.validate("My name is Mayank.", strict=True)
    assert str(excinfo.value) == "Matched more than one type."



# Generated at 2022-06-22 05:50:14.732600
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field, Field)
    assert field.errors == {'never': 'This never validates.'}


# Generated at 2022-06-22 05:50:15.563104
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Field(), Field()]) is not None

# Generated at 2022-06-22 05:50:27.216256
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # logging.basicConfig(level=logging.DEBUG)
    # in order to test the method validate
    # we need different errors for 'then' and for 'else'.
    # We use 2 string fields for that.
    # The implementation of the IfThenElse field requires
    # if_clause or else_clause to not be None. It is perfectly ok
    # to have then_clause or else_clause equel to None.

    if_clause = String()
    then_clause = String(min_length=1)
    else_clause = String(max_length=0)
    field = IfThenElse(if_clause)
    assert field.validate("") == ""
    field = IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-22 05:50:28.277781
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf is not None

# Generated at 2022-06-22 05:50:30.247565
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[Any()])
    field.validate(1)


# Generated at 2022-06-22 05:50:31.360196
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)


# Generated at 2022-06-22 05:50:38.049710
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Assertion error if 'allow_null' exists in kwargs
    assertRaises(AssertionError, NeverMatch, allow_null=True)

    # expect a value of None to be invalid
    nm = NeverMatch()
    r = nm.validate(None)
    assert r == 'never'
    r = nm.validate(None, strict=False)
    assert r == 'never'


# Generated at 2022-06-22 05:50:47.791506
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    def check_AllOf_validate_raises_assertion_error(all_of):
        try:
            AllOf(all_of)
        except AssertionError:
            pass
        else:
            raise AssertionError("AllOf test failed")

    check_AllOf_validate_raises_assertion_error(None)
    check_AllOf_validate_raises_assertion_error("Integer")
    check_AllOf_validate_raises_assertion_error([1, 2.0, "foobar"])

    def check_AllOf_validate_returns_expected(all_of, expected):
        all_of = AllOf(all_of)
        assert all_of.validate(expected) == expected


# Generated at 2022-06-22 05:50:50.778689
# Unit test for constructor of class Not
def test_Not():
    f = Not(empty)
    assert f.negated is empty
    assert f.errors == {"negated": "Must not match."}



# Generated at 2022-06-22 05:50:51.839748
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  x = NeverMatch()


# Generated at 2022-06-22 05:51:09.941137
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    allOf = AllOf(all_of=[])
    allOf.validate(value=None, strict=False)


# Generated at 2022-06-22 05:51:11.993624
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    field.validate(None)


# Generated at 2022-06-22 05:51:16.495591
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class Name(Field):
        pass
    class Surname(Field):
        pass
    class FullName(Field):
        pass

    if_name = IfThenElse(Name(), then_clause=Name(), else_clause=Surname())
    assert str(if_name) == "IfThenElse(Name() OR Surname())"

    if_name = IfThenElse(Name(), then_clause=Name(), else_clause=FullName())
    assert str(if_name) == "IfThenElse(Name() OR FullName())"

# Generated at 2022-06-22 05:51:18.460547
# Unit test for constructor of class OneOf
def test_OneOf():
    import typing
    
    field = Field(name='name')
    assert field.name == 'name'

    field = Field(name='name', description='description')
    assert field.name == 'name'
    assert field.description == 'description'


# Generated at 2022-06-22 05:51:21.556053
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(name="test_name")
    assert field.name == "test_name"
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:51:32.032089
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Schema
    from json import loads
    from datetime import datetime
    from sensai.errorhandler import exitProgram
    from typesystem import String, Integer, Array, DateTime
    # Test for all of, where all validaiton is successful
    def all_of_validate():
        schema = Schema(
                type="object",
                allOf=[{
                    "type": "object",
                    "properties": {
                        "username":  {"type": "string"},
                        "password":  {"type": "string"},
                    }
                },
                {
                    "type": "object",
                    "properties": {
                        "username":  {"type": "string"},
                        "password":  {"type": "string"},
                    },
                    "required": ["username", "password"]
                }
            ])

# Generated at 2022-06-22 05:51:35.723226
# Unit test for constructor of class OneOf
def test_OneOf():
    a = Field(name="a")
    b = Field(name="b")
    list1 = []
    list1.append(a)
    list1.append(b)
    f = OneOf(one_of=list1)
    return f

# Generated at 2022-06-22 05:51:37.741423
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any()) 
    not_field.validate(None)



# Generated at 2022-06-22 05:51:40.698004
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    dd = AllOf([String(),Integer()])
    try:
        dd.validate('654')
    except:
        print('ok')
    else:
        print('not ok')



# Generated at 2022-06-22 05:51:45.960550
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    """
    input_string = '{"some_key": "some_value"}'
    with pytest.raises(AssertionError) as execinfo:
        parsed_json = json.loads(input_string)
    assert "Error parsing JSON" in str(execinfo.value)
    """



# Generated at 2022-06-22 05:52:26.619541
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Age(Field):
        def validate(self,value,strict=False):
            return value >= 18
    class IsAdult(Field):
        def validate(self,value,strict=False):
            return "You are adult"
    class IsNotAdult(Field):
        def validate(self,value,strict=False):
            return "You are not adult"
    age = Age()
    is_adult = IsAdult()
    is_not_adult = IsNotAdult()
    if_clause = age
    then_clause = is_adult
    else_clause = is_not_adult
    assert IfThenElse(if_clause,then_clause,else_clause).validate(18) == "You are adult"

# Generated at 2022-06-22 05:52:28.689307
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(items=[])
    assert not hasattr(field, "allow_null")

# Generated at 2022-06-22 05:52:38.847449
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test json schema key 'name'
    assert OneOf([], name='name').name == 'name'
    # Test json schema key 'title'
    assert OneOf([], title='title').title == 'title'
    # Test json schema key 'description'
    assert OneOf([], description='description').description == 'description'
    # Test json schema key 'default'
    assert OneOf([], default='default').default == 'default'
    # Test json schema key 'read_only'
    assert OneOf([], read_only=True).read_only == True
    # Test json schema key 'write_only'
    assert OneOf([], write_only=True).write_only == True
    # Test json schema key 'required'
    assert OneOf([], required=True).required == True
    # Test json schema key 'allow_null'

# Generated at 2022-06-22 05:52:45.647259
# Unit test for method validate of class Not
def test_Not_validate():
    # Create input
    input_value = 5
    strict_value = True

    # Create expected results
    expected_return_value = 5

    field = Not(negated=None)

    # Call method under test
    test_return_value = field.validate(value=input_value, strict=strict_value)

    # Assert that method under test behaves as expected
    assert test_return_value == expected_return_value


# Generated at 2022-06-22 05:52:48.081279
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with raises(ValidationError):
        field.validate(1)


# Generated at 2022-06-22 05:52:57.372494
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse("test", "then", "else").validate('test') == 'then'
    assert IfThenElse("test", "then", "else").validate('not_test') == 'else'
    assert IfThenElse("test", None, "else").validate('test') == 'test'
    assert IfThenElse("test", "then", None).validate('not_test') == 'not_test'
    assert IfThenElse("test", None, None).validate('test') == 'test'
    assert IfThenElse("test", None, None).validate('not_test') == 'not_test'

# Generated at 2022-06-22 05:53:00.075757
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_field = OneOf([])
    assert(one_of_field.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."})


# Generated at 2022-06-22 05:53:01.557975
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(None)
    print(not_field.errors)
    not_field.validate(None)

# Generated at 2022-06-22 05:53:06.538920
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test = IfThenElse(AllOf([], required=True), None, None, required=True)
    assert test.if_clause is not None
    assert test.then_clause is not None
    assert test.else_clause is not None
    assert test.if_clause.required and test.then_clause.required and test.else_clause.required


# Generated at 2022-06-22 05:53:07.870412
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[]) is not None

# Generated at 2022-06-22 05:54:10.085042
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    N = NeverMatch()


# Generated at 2022-06-22 05:54:13.994792
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    a = NeverMatch()
    try:
        a.validate(10)
    except a.ValidationError as e:
        assert type(e) == a.ValidationError
        assert e.code == "never"


# Generated at 2022-06-22 05:54:21.656819
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer
    from typesystem import String
    from typesystem import Boolean
    from typesystem import Field
    from typesystem import Any
    from typesystem import OneOf

    field = OneOf([Integer(), Integer(), Integer()])
    type(field).__name__ == 'OneOf'
    
    field = OneOf([Integer(), String(), Boolean()])
    type(field).__name__ == 'OneOf'
    field.validate(1)
    field.validate('str')
    field.validate(True)

    field = OneOf([String(), String(), String()])
    field.validate('str')
    field.validate('str')
    field.validate('str')
    
    field = OneOf([String(), Integer(), Boolean()])
    field.validate('str')

    field = OneOf

# Generated at 2022-06-22 05:54:24.749059
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Number
    t1 = IfThenElse(if_clause=String(), then_clause=Number(), else_clause=Number())
    assert t1.validate(1) == 1
    assert t1.validate('a') == 0

# Generated at 2022-06-22 05:54:25.743794
# Unit test for constructor of class OneOf
def test_OneOf():
    x = OneOf([
        String(),
        Integer(),
        ])
    assert x is not None


# Generated at 2022-06-22 05:54:31.346396
# Unit test for method validate of class Not
def test_Not_validate():
  print("--------------START OF TEST Not.validate-----------------")
  # Case: Validator is: {"type": "string"}
  # Case: Validator is: {"type": "string"}
  # Case: Validator is: {"type": "string"}
  print("--------------END OF TEST Not.validate-----------------")


# Generated at 2022-06-22 05:54:36.116964
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.errors == {"never": "This never validates."}
    assert a.allow_null == False


# Generated at 2022-06-22 05:54:44.784387
# Unit test for constructor of class AllOf
def test_AllOf():
    """
    Test if the constructor of 'AllOf' is correct
    """
    field1 = Field()
    field2 = Field()
    field3 = Field()
    
    assert field1.name == None
    assert field2.name == None
    assert field3.name == None
    
    objAllOf = AllOf([field1, field2, field3])
    
    assert objAllOf.name == None
    assert objAllOf.all_of == [field1, field2, field3]
    assert isinstance(objAllOf, Field)


# Generated at 2022-06-22 05:54:49.140145
# Unit test for constructor of class Not
def test_Not():
    def negated():
        return False

    negated = Field(validators=[negated])
    not_field = Not(negated=negated)
    assert not_field.negated == negated
    assert not_field.errors == {"negated": "Must not match."}
    assert not_field.validator is None


# Generated at 2022-06-22 05:55:01.181334
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_1 = Int(min_value=5)
    field_2 = String()
    field_3 = String()
    ite = IfThenElse(if_clause=field_1, then_clause=field_2, else_clause=field_3)
    assert ite.validate(value=2) == '2'
    assert ite.validate(value=5) == '5'
    ite_not = IfThenElse(if_clause=field_1, then_clause=field_3)
    assert ite_not.validate(value=5) == '5'
    ite_not = IfThenElse(if_clause=field_1, else_clause=field_3)
    assert ite_not.validate(value=5) == '5'