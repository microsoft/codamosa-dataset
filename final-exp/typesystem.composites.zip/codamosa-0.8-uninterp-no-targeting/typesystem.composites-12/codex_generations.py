

# Generated at 2022-06-22 05:46:07.243870
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import sys
    import json
    import io

    def capture_stdout(func, *args):
        captured = io.StringIO()                  # Create StringIO object
        sys.stdout = captured                    # and redirect stdout.
        try:
            func(*args)
        finally:
            sys.stdout = sys.__stdout__           # Reset redirect.
        return captured.getvalue()                # Get stdout and close stream.

    expected = '''{
  "errors": {
    "never": "This never validates."
  }
}'''
    captured_json = capture_stdout(NeverMatch.schema().to_json, indent=2)

    expected_json = json.loads(expected)
    captured_json = json.loads(captured_json)

# Generated at 2022-06-22 05:46:09.989088
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # arrange
    the_field=AllOf(all_of=[])
    # act
    the_field.validate(value="")
    # assert
    assert True

# Generated at 2022-06-22 05:46:12.795246
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String

    field = Not(String())
    value = "text"
    field.validate(value)

    assert True


# Generated at 2022-06-22 05:46:15.515774
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_array = [
        'abc12',
        123,
    ]
    schema = OneOf(test_array)
    schema.validate('abc12')

# Generated at 2022-06-22 05:46:22.114362
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    print("Testing method validate() of class AllOf")
    all_of = AllOf([Int(minimum=5)])
    res = all_of.validate(6)
    assert res == 6
    # The next statement should raise an exception because the function supports
    # only Int values >= 5.
    try:
        res = all_of.validate(3)
    except ValidationError as e:
        assert True
        pass


# Generated at 2022-06-22 05:46:24.028291
# Unit test for constructor of class Not
def test_Not():
    test_not = Not(negated=Any())
    assert test_not is not None


# Generated at 2022-06-22 05:46:28.177011
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Create an instance of Field
    my_AllOf = AllOf([])
    # Check that instance is created correctly and raises "not_implemented" error
    assert my_AllOf.validate() == NotImplementedError


# Generated at 2022-06-22 05:46:30.922951
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(negated=None)
    assert not_.negated is None
    assert not_.errors['negated'] == 'Must not match.'


# Generated at 2022-06-22 05:46:34.037958
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf(
        all_of=[
            1,
            2,
            'a'
        ]
    )
    assert a.all_of == [1, 2, 'a']


# Generated at 2022-06-22 05:46:38.610098
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf(one_of=[])
    assert o.one_of == []
    assert o.errors == {'multiple_matches': 'Matched more than one type.', 'no_match': 'Did not match any valid type.'}


# Generated at 2022-06-22 05:46:44.381473
# Unit test for constructor of class OneOf
def test_OneOf():
    OneOf()

# Generated at 2022-06-22 05:46:46.321828
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.validate(1) == 1



# Generated at 2022-06-22 05:46:54.572735
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    item = {'mediaType': 'application/vnd.microsoft.documentdb.document'}
    if_clause = {'type': 'object', 'properties': {'mediaType': {'type': 'string', 'enum': ['application/vnd.microsoft.documentdb.document']}}, 'required': ['mediaType'], 'additionalProperties': False}
    then_clause = {'type': 'object', 'properties': {}, 'additionalProperties': False}
    else_clause = NeverMatch()
    # then_clause = None, else_clause = None
    one_of = OneOf(one_of=[if_clause, then_clause, else_clause])
    print(one_of.validate(item))

# Generated at 2022-06-22 05:47:01.369794
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem
    class Char(typesystem.String):
        def validate(self, value):
            if len(value) != 1:
                self.fail('Char')
        def validate_char(self, value):
            if len(value) != 1:
                self.fail('Char')
    class Char_Not(typesystem.Not):
        def validate(self, value):
            if len(value) == 1:
                self.fail('not_char')
    class Char_Length(typesystem.Number):
        def validate(self, value):
            if len(value) != 1:
                self.fail('not_char_length')

# Generated at 2022-06-22 05:47:05.141412
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch(name='never_match')
    try:
        nm.validate(1)
        assert False, "My code did not throw"
    except ValueError as e:
        assert str(e) == "This never validates."


# Generated at 2022-06-22 05:47:09.127920
# Unit test for constructor of class Not
def test_Not():
    import json
    from typesystem.field import String

    a = String(max_length=5)
    b = Not(a)
    assert json.dumps(b.schema(), indent=2) == """{
  "$schema": "http://json-schema.org/draft-07/schema#",
  "definitions": {},
  "properties": {},
  "type": "object"
}"""

# Generated at 2022-06-22 05:47:12.352474
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Success case
    field = NeverMatch()
    assert field.name is None
    assert field.description is None
    assert field.required is False
    assert field.errors == {"never": "This never validates."}

    # Failure cases
    # TODO


# Generated at 2022-06-22 05:47:14.802747
# Unit test for constructor of class OneOf
def test_OneOf():
    print("Testing OneOf.__init__()")

    # Test arguments with optional argument
    field = typesystem.Boolean()
    subfields = [field]
    field = OneOf(subfields)


# Generated at 2022-06-22 05:47:19.376755
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  field = NeverMatch()
  assert field.description == ""
  assert field.error_messages["never"] == "This never validates."
  assert field.parent == None


# Generated at 2022-06-22 05:47:20.301423
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert True


# Generated at 2022-06-22 05:47:30.750872
# Unit test for constructor of class Not
def test_Not():
    Not(negated=Field())

# Generated at 2022-06-22 05:47:32.385562
# Unit test for constructor of class Not
def test_Not():
    test = Not(negated=Field())
    assert test.negated is not None
    # return None

# Generated at 2022-06-22 05:47:38.912381
# Unit test for constructor of class AllOf
def test_AllOf():
    # Defining a list of fields
    field_list = []
    field_list.append(Field())
    field_list.append(Field())

    # Testing constructor
    all_of_test = AllOf(field_list)
    assert isinstance(all_of_test, AllOf)
    assert all_of_test.all_of == field_list


# Generated at 2022-06-22 05:47:41.877460
# Unit test for constructor of class AllOf
def test_AllOf():
    '''
    Tests the constructor for class AllOf
    '''
    assert AllOf.__init__

# Generated at 2022-06-22 05:47:45.568105
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        Field(name='a'),
        Field(name='b'),
    ])
    expected = 'a'
    field.validate(expected, strict=True)



# Generated at 2022-06-22 05:47:49.577282
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [
        Field(),
        Field(),
        Field(),
        Field(),
        Field(),
    ]
    obj = AllOf(all_of)

    assert obj.all_of == all_of


# Generated at 2022-06-22 05:47:58.333246
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem import validators

    if_clause = String("Keyboard")
    then_clause = String("4")
    else_clause = String("6")

    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("Keyboard", True) == "4"
    assert if_then_else.validate("Mouse", True) == "6"
    validators.validate_type("IfThenElse", if_then_else, "Keyboard", True)
    validators.validate_type("IfThenElse", if_then_else, "Mouse", True)


# Generated at 2022-06-22 05:48:09.524851
# Unit test for constructor of class OneOf
def test_OneOf():
    field1 = Field(name="test1")
    field2 = Field(name="test2")
    field3 = Field(name="test3")
    field4 = Field(name="test4")
    field5 = Field(name="test5")
    field6 = Field(name="test6")
    field7 = Field(name="test7")
    field8 = Field(name="test8")
    field9 = Field(name="test9")
    field10 = Field(name="test10")
    field11 = Field(name="test11")
    field12 = Field(name="test12")
    field13 = Field(name="test13")
    field14 = Field(name="test14")
    field15 = Field(name="test15")
    field16 = Field(name="test16")

# Generated at 2022-06-22 05:48:11.767017
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    t = AllOf(all_of=[Any()])
    t.validate(1)



# Generated at 2022-06-22 05:48:15.884236
# Unit test for constructor of class Not
def test_Not():
    # Input arguments of the constructor
    negated = Field()

    obj = Not(negated) # type: ignore

    # Fields
    assert isinstance(obj.negated, Field)

    # Methods
    # obj.validate(obj, strict=False)

# Generated at 2022-06-22 05:48:29.285868
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from . import none_field, integer_field, string_field
    from .utils import none_validation_error

    field = OneOf([integer_field, string_field])
    assert field.validate(1) == 1
    assert field.validate("foo") == "foo"
    with none_validation_error():
        field.validate(None)
    with none_validation_error():
        field.validate([])


# Generated at 2022-06-22 05:48:39.956528
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import Boolean, Text
    from typesystem.exceptions import ValidationError
    # one then_clause
    field = IfThenElse(
        Boolean(),
        then_clause=Text(max_length=10),
    )
    assert field.validate(True) == ""
    assert field.validate(False) == ""
    try:
        field.validate(None)
    except ValidationError as e:
        assert e.message == "Has to be a boolean."
    # one then_clause, one else_clause
    field = IfThenElse(
        Boolean(),
        then_clause=Text(max_length=10),
        else_clause=Text(max_length=5)
    )
    assert field.validate(True) == ""

# Generated at 2022-06-22 05:48:44.774993
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    try:
        assert not_field.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."

# Generated at 2022-06-22 05:48:46.295521
# Unit test for constructor of class AllOf
def test_AllOf():
    fld = AllOf([])
    assert fld._value is None

# Generated at 2022-06-22 05:48:49.197324
# Unit test for constructor of class AllOf
def test_AllOf():
    response = AllOf(all_of=[])
    assert hasattr(response, 'all_of')
    assert response.all_of == []


# Generated at 2022-06-22 05:48:51.348447
# Unit test for constructor of class OneOf
def test_OneOf():
    list = [Field]
    one_of = OneOf(list)
    assert one_of.one_of == list



# Generated at 2022-06-22 05:48:53.416855
# Unit test for method validate of class Not
def test_Not_validate():
    if_clause = Integer()
    negated = Not(if_clause)
    try:
        negated.validate(1)
    except ValidationError:
        return
    assert False, "Exception expected"

# Generated at 2022-06-22 05:48:57.542686
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any(required=True))
    value, error = field.validate_or_error(None)
    assert value is None

    value, error = field.validate_or_error(1)
    assert value == 1

# Generated at 2022-06-22 05:49:01.441848
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem
    schema = typesystem.AllOf([typesystem.Integer(maximum=20), typesystem.Integer(minimum=10)])
    assert schema.validate(15) == 15
    with raises(typesystem.ValidationError):
        schema.validate(30)


# Generated at 2022-06-22 05:49:02.459607
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	instance = NeverMatch()
	assert instance != None

# Generated at 2022-06-22 05:49:14.907566
# Unit test for constructor of class AllOf
def test_AllOf():
    # all_of is not provided
    try:
        all_of_field = AllOf()
    except:
        print("all_of is not provided")
    # all_of is empty
    try:
        all_of_field = AllOf([])
    except:
        print("all_of is empty")
    # all_of is not a list
    try:
        all_of_field = AllOf(1)
    except:
        print("all_of is not a list")
    # all_of is a list that has element which is not a Field
    try:
        all_of_field = AllOf([1])
    except:
        print("all_of is a list that has element which is not a Field")

# Generated at 2022-06-22 05:49:16.888385
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(one_of=[1,2,'3'], _metadata='metadata')


# Generated at 2022-06-22 05:49:18.757188
# Unit test for constructor of class AllOf
def test_AllOf():
    typesystem.fields.AllOf([AllOf([Any()])])
    assert True



# Generated at 2022-06-22 05:49:20.637677
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer

    field = AllOf([Integer()])
    assert type(field) == AllOf


# Generated at 2022-06-22 05:49:22.399721
# Unit test for constructor of class AllOf
def test_AllOf():
    # Init for test
    AllOf([])
    # Expect success, no exception
    assert True


# Generated at 2022-06-22 05:49:24.457170
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field()).negated == Field()

# Generated at 2022-06-22 05:49:26.792484
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  never_match = NeverMatch()
  assert never_match.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:49:35.573832
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    intf = IfThenElse(Int(min_value=10), Int(min_value=15), Int(min_value=20))
    assert intf.validate(25) == 25
    assert intf.validate(15) == 15
    assert intf.validate(10) == 10

    assert intf.validate(5) == IfThenElse.errors["condition"]
    assert intf.validate(10.0) == IfThenElse.errors["then_clause"]
    assert intf.validate(15.0) == IfThenElse.errors["else_clause"]

# Generated at 2022-06-22 05:49:41.484978
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Pass
    all_of = AllOf([Int(), Int()])
    all_of.validate(10)

    # Fail
    all_of = AllOf([Int(), Int()])
    with pytest.raises(ValidationError):
        all_of.validate(10.1)

# Generated at 2022-06-22 05:49:43.535807
# Unit test for constructor of class Not
def test_Not():
    assert Not(AllOf([], message_templates={"foo": "bar"}))



# Generated at 2022-06-22 05:49:59.123388
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        OneOf(one_of=[1,2,3])
    except:
        print('OneOf constructor passes unit test')
        return True


# Generated at 2022-06-22 05:50:04.213851
# Unit test for constructor of class AllOf
def test_AllOf():
    argAllOf = [
        Field()
    ]
    argkwargs = {
        "name": "",
        "description": "",
        "default": None
    }
    test = AllOf(argAllOf, **argkwargs)
    assert test is not None


# Generated at 2022-06-22 05:50:06.050381
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Any()).validate("test") == "test"
    with pytest.raises(FieldValueError):
        Not(String()).validate("test")



# Generated at 2022-06-22 05:50:09.174355
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    instance = NeverMatch(key="value", key1="value1")
    assert instance.key == "value"
    assert instance.key1 == "value1"
# unit test for method validate of class NeverMatch

# Generated at 2022-06-22 05:50:11.002042
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([])

# Generated at 2022-06-22 05:50:13.173798
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated = String())
    assert field.validate('asdsa') is None


# Generated at 2022-06-22 05:50:22.749918
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String(max_length=100)

    class Dog(typesystem.Schema):
        name = typesystem.String(max_length=100)

    class Pet(typesystem.Schema):
        pet = typesystem.OneOf([Person, Dog])

    pet = Pet({"pet": {"name": "Fido"}})
    assert pet.is_valid()
    pet = Pet({"pet": {"name": "Fido", "age": 12}})
    assert not pet.is_valid()
    pet = Pet({"pet": {"name": "Fido", "age": "two"}})
    assert pet.is_valid()



# Generated at 2022-06-22 05:50:26.842589
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    '''
    Test validate method of class NeverMatch
    '''
    error = "This never validates."
    never_match = NeverMatch()
    try:
        never_match.validate(100)
    except Exception as err:
        assert str(err) == error

# Generated at 2022-06-22 05:50:28.749376
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:50:33.784044
# Unit test for method validate of class Not
def test_Not_validate():
    nested_schema = Not(
        Field(name="bar"),
    )
    assert nested_schema.validate({"foo": "bar"}) == {"foo": "bar"}
    with pytest.raises(nested_schema.validation_error):
        nested_schema.validate({"bar": "foo"})


# Generated at 2022-06-22 05:50:57.209994
# Unit test for method validate of class Not
def test_Not_validate():

    # Test 1: A positive case: when the input value is not negated
    test_result1 = Not(
        Integer(),
        label="test"
    ).validate(
        10
    )
    assert test_result1 == 10

    # Test 2: A positive case: when the input value is negated
    test_result2 = Not(
        Integer(),
        label="test"
    ).validate(
        "string"
    )
    assert test_result2 == "string"

    # Test 3: A negative case: when the input value is negated
    test_result3 = (
        Not(
            Integer(),
            label="test"
        ).validate(
            10
        )
    ) == 10
    assert test_result3 == False



# Generated at 2022-06-22 05:51:01.362891
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    x = OneOf([Field(type="integer"), Field(type="string")])
    assert x.validate(1) == 1
    assert x.validate("abc") == "abc"
    try:
        x.validate([])
        assert False, "should fail"
    except ValidationError:
        pass
    try:
        x.validate(1.1)
        assert False, "should fail"
    except ValidationError:
        pass



# Generated at 2022-06-22 05:51:03.572532
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Setup
    one_of = OneOf([Int, Bool], required=True)
    value = True

    # Exercise
    actual = one_of.validate(value)

    # Verify
    assert actual == True


# Generated at 2022-06-22 05:51:04.965157
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass


# Generated at 2022-06-22 05:51:07.615102
# Unit test for method validate of class Not
def test_Not_validate():
    arg1 = NeverMatch()
    field = Not(negated = arg1)
    field.validate(value = None)



# Generated at 2022-06-22 05:51:13.513529
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import String, Integer
    one_of = OneOf([String, Integer])

    assert one_of.validate("test") == "test"
    assert one_of.validate(1) == 1
    try:
        one_of.validate(1.0)
    except Exception as e:
        assert e.args[0] == 'Did not match any valid type.'

    try:
        one_of.validate(True)
    except Exception as e:
        assert e.args[0] == 'Did not match any valid type.'



# Generated at 2022-06-22 05:51:15.074385
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    vm = NeverMatch()
    assert vm


# Generated at 2022-06-22 05:51:22.423913
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class Allof(AllOf):
        errors = {
            "no_match": "Did not match any valid type.",
            "multiple_matches": "Matched more than one type.",
        }
    lst = [1, 2, 3]
    assert Allof(lst).validate(1) == 1
    assert Allof(lst).validate([1]) == 1
    assert raises(ValidationError, Allof, lst).validate([2, 3, 4])

# Generated at 2022-06-22 05:51:30.552313
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import String
    from pyspark.sql import Row

    not_ = Not(String())
    try:
        assert not_.validate("7") == "7"
    except Exception as e:
        assert 0

    try:
        not_.validate(7)
    except Exception as e:
        assert 1

    not_ = Not(Row())
    try:
        not_.validate("7")
    except Exception as e:
        assert 1
    try:
        assert not_.validate(Row(7)) == Row(7)
    except Exception as e:
        assert 0

# Generated at 2022-06-22 05:51:33.535266
# Unit test for constructor of class Not
def test_Not():
    field = Not('a')
    assert field.negated == 'a'
    assert field.allow_null ==False
    assert field.errors == {'negated': 'Must not match.'}


# Generated at 2022-06-22 05:51:48.137683
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    try:
        a = AllOf([Field(),Field()])
        a.validate(None)
    except Exception as e: 
        print(e)

   
test_AllOf_validate()

# Generated at 2022-06-22 05:51:49.371728
# Unit test for constructor of class Not
def test_Not():
    assert Not(Any())


# Generated at 2022-06-22 05:52:00.352505
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class Test_Field(Field):
        errors = {
            'test_error': 'Test error for test_AllOf_validate'
        }

        def validate(self, value, strict=False):
            raise self.validation_error('test_error')

    class Test_Field_2(Field):
        errors = {
            'test_error_2': 'Test error for test_AllOf_validate_2'
        }

        def validate(self, value, strict=False):
            raise self.validation_error('test_error_2')
    
    test_Field_obj = Test_Field()
    test_Field_obj_2 = Test_Field_2()

    all_of_field = AllOf(all_of=[test_Field_obj, test_Field_obj_2])

# Generated at 2022-06-22 05:52:09.008152
# Unit test for constructor of class Not
def test_Not():
    import json
    import typesystem
    schema = typesystem.Schema(
        title="Not",
        description="Not test",
        content={"machinename": Not(typesystem.String())}
    )
    data = json.dumps({"machinename": "test:test"}, ensure_ascii=True)
    try:
        schema.validate(data)
    except Exception as err:
        assert str(err) == '{"machinename": "Must not match."}'


# Generated at 2022-06-22 05:52:11.528389
# Unit test for method validate of class OneOf
def test_OneOf_validate():
	# one_of = [Boolean(min_length=2)]
	pass

# Generated at 2022-06-22 05:52:12.629290
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch.validate(True)

# Generated at 2022-06-22 05:52:14.548046
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    assert f.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:52:21.918207
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    field = IfThenElse(if_clause, then_clause, else_clause)
    # Call method validate with params: value, strict=strict
    try:
        raise NotImplementedError()
    except NotImplementedError:
        pass


# Generated at 2022-06-22 05:52:30.463246
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Case 1: If the user passes None or nothing, the default value should be set to the Any() Field
    # Case 2: initializing of the instance variables
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()

    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert field.else_clause == else_clause

    field = IfThenElse(if_clause, else_clause=else_clause)
    assert field.if_clause == if_clause
    assert field.then_clause == Any()
    assert field.else_clause == else_clause

    if_clause = None

# Generated at 2022-06-22 05:52:31.648528
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    
    assert isinstance(NeverMatch(), Field)



# Generated at 2022-06-22 05:53:27.373999
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Int()
    else_clause = Str()
    test = IfThenElse(if_clause, else_clause = else_clause)
    assert test.if_clause == if_clause
    assert test.else_clause == else_clause
    assert test.then_clause == Any()

# Generated at 2022-06-22 05:53:31.683176
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match = NeverMatch()
    if never_match.validate(1) == 1:
        print("Test Passed - NeverMatch - method validate")
    else:
        print("Test Failed - NeverMatch - method validate")

# Generated at 2022-06-22 05:53:36.218629
# Unit test for constructor of class AllOf
def test_AllOf():
    one = Field()
    two = Field()
    all = AllOf(one)
    assert all.all_of is one
    all = AllOf([one, two])
    assert all.all_of is [one, two]


# Generated at 2022-06-22 05:53:39.954144
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field(default="if")
    then_clause = Field(default="then")
    else_clause = Field(default="else")
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-22 05:53:40.937103
# Unit test for constructor of class Not
def test_Not():
    pass


# Generated at 2022-06-22 05:53:45.491082
# Unit test for method validate of class Not
def test_Not_validate():
    notField = Not(Field())
    assert notField.validate(1, strict=False) == 1
    try:
        notField.validate("1", strict=False)
    except ValueError:
        pass
    else:
        assert False


# Generated at 2022-06-22 05:53:47.344635
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    allof = AllOf([Any()])
    print(allof.validate([]))


# Generated at 2022-06-22 05:53:54.068917
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    # 1. Create classes than inherit from class Field
    class SubclassField1(Field):
        type = "SubclassField1"

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "SubclassField1"

    class SubclassField2(Field):
        type = "SubclassField2"

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "SubclassField2"

    class SubclassField3(Field):
        type = "SubclassField3"

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "SubclassField3"

    # 2. Create object of class SubclassField1, SubclassField2, SubclassField3


# Generated at 2022-06-22 05:53:55.405056
# Unit test for constructor of class AllOf
def test_AllOf():
    x = AllOf([])
    assert x is not None


# Generated at 2022-06-22 05:53:59.126390
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    # Check that it raises an error
    with pytest.raises(ValueError):
        field.validate(1, strict=False)


# Generated at 2022-06-22 05:55:14.078767
# Unit test for constructor of class Not
def test_Not():
    n = Not('not')
    assert n.negated == 'not'


# Generated at 2022-06-22 05:55:16.145664
# Unit test for constructor of class OneOf
def test_OneOf():
    f = OneOf(OneOf)
    assert f is not None

# Generated at 2022-06-22 05:55:21.466821
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=IfThenElse(if_clause=AllOf(all_of=[Any(), Any(), Any()]), then_clause=OneOf(one_of=[Any()]), else_clause=AllOf(all_of=[Any(), Any(), Any()])))
    value = 1
    assert field.validate(value=value) == value



# Generated at 2022-06-22 05:55:27.944216
# Unit test for constructor of class OneOf
def test_OneOf():
    test_OneOf_0 = OneOf(one_of=[])
    # Can't compute assert condition expression 'test_OneOf_0.one_of == []'
    # test_OneOf_1 = OneOf(one_of=['one_of'])
    # AssertionError: AssertionError: Missing required argument 'one_of' in call to OneOf
    return


# Generated at 2022-06-22 05:55:35.221096
# Unit test for method validate of class Not
def test_Not_validate():
    # Case 1: good value
    not_field = Not(negated=Any("foo"))
    expected =  1
    actual = not_field.validate(1)
    assert actual == expected, "Fails: to validate pattern: {}, {}, value {}".format("Not", "Case 1", actual)

    # Case 2: bad value
    not_field = Not(negated=Any("foo"))
    actual = not_field.validate("foo")
    assert actual != actual, "Fails: to validate pattern: {}, {}, value {}".format("Not", "Case 2", actual)



# Generated at 2022-06-22 05:55:36.448797
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    instance = OneOf([Boolean(), Null()])
    instance.validate(None)

# Generated at 2022-06-22 05:55:38.835373
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=False, then_clause=True).validate(True)


# Generated at 2022-06-22 05:55:40.357282
# Unit test for constructor of class AllOf
def test_AllOf():
    assert isinstance(AllOf([Any()]), AllOf)


# Generated at 2022-06-22 05:55:47.308545
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.types import Type
    from typesystem.fields import String

    class Type1(Type):
        field1 = String("message1")

    class Type2(Type):
        field2 = String("message2")

    class Type3(Type):
        field3 = String("message3")

    data = Type3(field3="123")

    one_of = OneOf([Type1, Type2, Type3])

    # Test call to validate with value data that should return a Type3 instance
    assert isinstance(one_of.validate(data), Type3) is True



# Generated at 2022-06-22 05:55:59.034256
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String, Integer
    
    # optional types are not allowed
    try:
        IfThenElse(String(), Integer())
    except Exception as e:
        print(e)
    
    # optional types are not allowed
    try:
        IfThenElse(String(), then_clause=Integer())
    except Exception as e:
        print(e)
        
    # optional types are not allowed
    try:
        IfThenElse(String(), else_clause=Integer())
    except Exception as e:
        print(e)
    
    # optional types are not allowed
    try:
        IfThenElse(if_clause=String(), then_clause=Integer())
    except Exception as e:
        print(e)
        
    # optional types are not allowed