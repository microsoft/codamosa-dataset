

# Generated at 2022-06-22 05:46:00.538423
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    child_one = Field()
    child_two = Field()

    field = OneOf(one_of=[child_one, child_two])
    
    with pytest.raises(ValidationError):
        field.validate('xyz')

# Generated at 2022-06-22 05:46:03.838980
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # arrange
    field = NeverMatch(name="field_name", description="field_description")
    value = "test_value"

    # act
    with pytest.raises(field.validation_error):
        field.validate(value)


# Generated at 2022-06-22 05:46:13.644846
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of = ["one", "two", "three"])
    assert field.validate("one") == "one"
    assert field.validate("two") == "two"
    assert field.validate("three") == "three"
    try:
        field.validate("four")
        assert False
    except ValidationError as e:
        assert "no_match" in e.messages
    except:
        assert False
    try:
        field.validate("one", "two")
        assert False
    except ValidationError as e:
        assert "multiple_matches" in e.messages
    except:
        assert False

# Generated at 2022-06-22 05:46:15.564505
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse(None)
    except TypeError:
        pass
    else:
        assert False

# Generated at 2022-06-22 05:46:16.379707
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-22 05:46:21.949961
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print('Unit test for method validate of class OneOf')
    test_obj = OneOf(one_of=[{'key1': 'int'}, {'key1': 'float'}])
    print(test_obj.validate('4'))
    print(test_obj.validate(4))
    print(test_obj.validate(4.2))



# Generated at 2022-06-22 05:46:29.041709
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class TestField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    class TestAllOf(AllOf):
        def __init__(self, all_of: typing.List[Field]) -> None:
            super().__init__(all_of)

    test_case = [TestField()]
    assert TestAllOf(test_case).validate(2, True) == 2



# Generated at 2022-06-22 05:46:38.145152
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema = OneOf([Any(name='Any'), Integer(name='Integer')])
    with raises(ValidationError) as ve:
        schema.validate(None)
    assert ve.value.as_dict == the_error_for_value
    assert ve.value.path == []
    assert ve.value.value_name == 'Any'
    assert ve.value.reason == 'required'
    with raises(ValidationError) as ve:
        schema.validate(1)
    assert ve.value.as_dict == the_error_for_value
    assert ve.value.path == []
    assert ve.value.value_name == 'Integer'
    assert ve.value.reason == 'integer'
    with raises(ValidationError) as ve:
        schema.validate(1.1)

# Generated at 2022-06-22 05:46:40.888595
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(
        [
            Field(),
            Field(),
        ]
    )
    field.validate(
        value=1,
        strict=False
    )

# Generated at 2022-06-22 05:46:43.990979
# Unit test for constructor of class Not
def test_Not():
    data = "some_data"
    negated = String()
    n = Not(negated)
    assert n.negated == negated
    assert n.validate(data).get() == data


# Generated at 2022-06-22 05:46:51.172095
# Unit test for constructor of class OneOf
def test_OneOf():
    test = OneOf([])
    assert test.one_of == []



# Generated at 2022-06-22 05:46:53.019142
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(if_clause,then_clause,else_clause)


# Generated at 2022-06-22 05:47:01.146139
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Boolean
    from typesystem.errors import ValidationError
    from typesystem.fields import Integer
    field = AllOf([Boolean, Integer])
    value = True

    # Test 1: Match all of the sub-items
    try:
        field.validate(value)
        print('test 1 pass')
    except:
        print('test 1 fail')

    # Test 1: Match all of the sub-items
    try:
        field.validate(1)
        print('test 1 pass')
    except:
        print('test 1 fail')

    # Test 2: Match none of the sub-items
    try:
        field.validate('1')
        print('test 2 fail')
    except ValidationError:
        print('test 2 pass')



# Generated at 2022-06-22 05:47:04.408508
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    i = IfThenElse(10, 20, 30)
    i.validate(5)
    # assert i.validate(5) == 30
    # assert i.validate(10) == 20



# Generated at 2022-06-22 05:47:10.388849
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf(
        [
            Field(
                title="First Field",
                description="First Field Desc",
                name="first",
                errors={"required": "first field required"},
            ),
            Field(
                title="Second Field",
                description="Second Field Desc",
                name="second",
                errors={"required": "second field required"},
            ),
        ]
    )
    one_of_field.validate("first")



# Generated at 2022-06-22 05:47:14.007448
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    t = AllOf([Always(), Always()])

    @test_case
    def test_not_error():
        assert t.validate(1) == 1

    @test_case
    def test_error():
        with raises(ValidationError, "All of the sub-fields did not validate."):
            t.validate(None)



# Generated at 2022-06-22 05:47:14.749519
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()



# Generated at 2022-06-22 05:47:20.042121
# Unit test for constructor of class Not
def test_Not():
    a = Not(None, allow_null=True)
    assert a.allow_null == True
    assert a.negated == None
    assert a.errors == {'negated': 'Must not match.'}


# Generated at 2022-06-22 05:47:26.829688
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([
        String('id', max_length=20),
        Integer('id')
    ])

    assert isinstance(one_of, Field)
    assert one_of.one_of == [
        String('id', max_length=20),
        Integer('id')
    ]
    assert one_of.errors == {
        "no_match": "Did not match any valid type.",
        "multiple_matches": "Matched more than one type.",
    }
    assert one_of.name is None
    assert one_of.description is None
    assert one_of.required is False


# Generated at 2022-06-22 05:47:30.356909
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_field = NeverMatch()
    assert test_field.errors == {"never": "This never validates."}



# Generated at 2022-06-22 05:47:41.370045
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String

    field = IfThenElse(
        if_clause=String(),
        then_clause=String(),
        else_clause=String(),
        description="if-then-else",
    )
    assert field.if_clause._cls == String
    assert field.then_clause._cls == String
    assert field.else_clause._cls == String
    assert field.description == "if-then-else"



# Generated at 2022-06-22 05:47:42.990217
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = ["A", "B"]
    theClass = AllOf(all_of)
    assert theClass.all_of == all_of


# Generated at 2022-06-22 05:47:47.758303
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[]).one_of == []
    assert OneOf(one_of=[Integer()]).one_of == [Integer()]
    assert OneOf(one_of=[Integer(), Float()]).one_of == [Integer(), Float()]


# Generated at 2022-06-22 05:47:57.663180
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Base case 1
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    value = field = None
    strict = False
    if_then_else = IfThenElse(
        if_clause=if_clause,
        then_clause=then_clause,
        else_clause=else_clause,
    )
    result = if_then_else.validate(value, strict=strict)
    assert result == None

    # Base case 2
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    value = field = None
    strict = True

# Generated at 2022-06-22 05:47:58.252324
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()

# Generated at 2022-06-22 05:47:59.196947
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-22 05:48:02.246793
# Unit test for constructor of class Not
def test_Not():
    f = Not(Any())
    assert f.negated == Any()
    with pytest.raises(AssertionError):
        f = Not(Any(), allow_null=False)



# Generated at 2022-06-22 05:48:08.203953
# Unit test for constructor of class OneOf
def test_OneOf():
    # Constructor for OneOf where field has no validation
    one_of = OneOf([Any()])
    assert one_of.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert not one_of.allow_null
    assert one_of.one_of == [Any()]


# Generated at 2022-06-22 05:48:19.671934
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import sys
    import os
    import types
    from typesystem import Number
    from typesystem.base import Message
    from unittest import TestCase
    from typesystem.fields import Any, String
    from typesystem.exceptions import ValidationError

    import pytest

    class TestAllOf(TestCase):

        @classmethod
        def setUpClass(cls):
            cls.system_module = sys.modules["typesystem"]
            del sys.modules["typesystem"]

        @classmethod
        def tearDownClass(cls):
            sys.modules["typesystem"] = cls.system_module

        def setUp(self):
            import typesystem
            self.old_AllOf = typesystem.fields.AllOf
            typesystem.fields.AllOf = AllOf
            self.old_Number = typesystem.fields

# Generated at 2022-06-22 05:48:24.824825
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Str(), Int()])
    """
    Is a valid AllOf
    """
    understood = "This is a test"
    field.validate(understood)
    """
    Not valid AllOf
    """
    not_understood = "Not understood"
    try:
        field.validate(not_understood)
    except:
        assert 1



# Generated at 2022-06-22 05:48:38.062191
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(None)
    assert not_field.validate(None) == None
    

# Generated at 2022-06-22 05:48:39.581868
# Unit test for constructor of class Not
def test_Not():
    assert issubclass(Not, Field)
    assert hasattr(Not, 'errors')

# Generated at 2022-06-22 05:48:45.614270
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    f = IfThenElse(if_clause, then_clause, else_clause)
    f.validate(1)

    f = IfThenElse(if_clause)
    f.validate(1)

# Generated at 2022-06-22 05:48:47.193723
# Unit test for constructor of class OneOf
def test_OneOf():
    field = list()
    field.append(OneOf(field))

# Generated at 2022-06-22 05:48:54.387029
# Unit test for method validate of class Not
def test_Not_validate():
    import typing
    from typesystem.fields import Not
    
    
    
    
    class NewNot(Not):
    
        errors = {
            "negated": "Must not match."
        }
    
        def __init__(self, negated: Field, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.negated = negated
    
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            _, error = self.negated.validate_or_error(value, strict=strict)
            if error:
                return value
            raise self.validation_error("negated")
    


    # We are testing the following method
    # class

# Generated at 2022-06-22 05:48:56.743234
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    print(NeverMatch().errors)


# Generated at 2022-06-22 05:49:07.786561
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import unittest
    import sys
    class Test_IfThenElse(unittest.TestCase):
        maxDiff = None
        def test1(self):
            field = IfThenElse(Int(), Int(), Int())
            with self.assertRaisesRegex(typesystem.Error, "Expected type 'int', got '1.1' instead."):
                field.validate('1.1')
        def test2(self):
            field = IfThenElse(Int(), Int(), Int())
            with self.assertRaisesRegex(typesystem.Error, "Expected type 'int', got '1.1' instead."):
                field.validate(1.1)
        def test3(self):
            field = IfThenElse(Int(), Int(), Int())

# Generated at 2022-06-22 05:49:10.407535
# Unit test for constructor of class AllOf
def test_AllOf():
    alpha = Field()
    beta = Field()
    gama = AllOf([alpha, beta])
    assert gama.all_of == [alpha, beta]


# Generated at 2022-06-22 05:49:12.814974
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Field()).if_clause == Field()
    assert IfThenElse(Field(), else_clause=Field()).else_clause == Field()


# Generated at 2022-06-22 05:49:15.003769
# Unit test for constructor of class Not
def test_Not():
    a = Field()
    b = Not(a)
    assert a == b.negated

# Generated at 2022-06-22 05:49:36.046162
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f = IfThenElse({'minLength': 4, 'maxLength': 10}, {'minLength': 6, 'maxLength': 6})
    assert f.validate('12345') is None
    assert f.validate('123456') is None
    assert f.validate('1234567') is None
    
    f = IfThenElse({'minLength': 4, 'maxLength': 10}, {'minLength': 6, 'maxLength': 6}, {'minLength': 0, 'maxLength': 3})
    assert f.validate('12345') is None
    assert f.validate('123456') is None
    assert f.validate('1234567') is None
    assert f.validate('123') is None
    assert f.validate('1234') is None
    assert f.validate('1') is None
   

# Generated at 2022-06-22 05:49:38.812875
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = []
    assert isinstance(AllOf(all_of), AllOf)


# Generated at 2022-06-22 05:49:41.190692
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()

    assert f.allow_null is False
    assert f.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:49:42.799305
# Unit test for constructor of class OneOf
def test_OneOf():
  oneOf = OneOf([])
  assert oneOf


# Generated at 2022-06-22 05:49:49.832470
# Unit test for constructor of class Not
def test_Not():
    string = "A string"
    not_string = Not(String())
    number = 123
    not_number = Not(Number())
    boolean = True
    not_boolean = Not(Boolean())
    none = None
    not_none = Not(NoneType())

    assert not_string.validate(number) == number
    assert not_number.validate(string) == string
    assert not_boolean.validate(number) == number
    assert not_none.validate(string) == string



# Generated at 2022-06-22 05:49:52.707554
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse(if_clause=OneOf([Integer(), PositiveInteger()]), then_clause=PositiveInteger(), else_clause=Integer())
    print(a.validate(1))

# Generated at 2022-06-22 05:49:56.669490
# Unit test for method validate of class Not
def test_Not_validate():
    fi = Not(AllOf([String(), String()]))
    d = fi.validate(["String", "String"])
    assert d == ["String", "String"]



# Generated at 2022-06-22 05:49:58.034762
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), NeverMatch) == True


# Generated at 2022-06-22 05:50:00.177490
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match_field = NeverMatch()
    with pytest.raises(FieldValidationError):
        never_match_field.validate(None)

# Generated at 2022-06-22 05:50:06.601757
# Unit test for method validate of class Not
def test_Not_validate():
    test = Not(negated=Any())

    assert test.validate(None) is None
    assert test.validate(NotImplemented) is NotImplemented
    assert test.validate(True) is True
    assert test.validate(12) == 12
    assert test.validate(1.2) == 1.2
    assert test.validate(None) is None



# Generated at 2022-06-22 05:50:21.275720
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    try:
        assert IfThenElse(Integer(gt=0), Integer(lt=0)).validate(23) == 23
    except Exception:
        return False
    return True


# Generated at 2022-06-22 05:50:25.876895
# Unit test for constructor of class Not
def test_Not():
    not_type = Not(Any())
    result = not_type.validate(9)
    expected = 9
    assert result == expected
    assert not_type.to_json_schema() == {'type': 'not', 'negated': {'type': 'any'}}


# Generated at 2022-06-22 05:50:37.325563
# Unit test for method validate of class Not
def test_Not_validate():
    with pytest.raises(TypeSystemError) as e:
        Not(None).validate(1)
    assert e.value.code == "negated"
    assert e.value.messages == {
        "code": "negated",
        "message": "Must not match.",
        "field": "",
    }

    # No error
    assert Not(NeverMatch()).validate(1) is None
    # Negated validation error
    with pytest.raises(TypeSystemError) as e:
        Not(NeverMatch()).validate(1)
    assert e.value.code == "negated"
    assert e.value.messages == {
        "code": "negated",
        "message": "Must not match.",
        "field": "",
    }

# Generated at 2022-06-22 05:50:46.555913
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.base import ValidationError
    from typesystem.fields import String
    from typesystem.forms import Form

    class MyForm(Form):
        fields = {"name": String()}

    form = MyForm({"name": "foo"})
    assert form.is_valid()

    form = MyForm({"name": 1})
    assert not form.is_valid()
    assert form.errors == {'name': ['Must be a string.']}

    class MyForm(Form):
        fields = {"name": AllOf([String(), String(max_length=3)])}

    form = MyForm({"name": "foo"})
    assert form.is_valid()

    form = MyForm({"name": "foobar"})
    assert not form.is_valid()

# Generated at 2022-06-22 05:50:53.306656
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    assert isinstance(OneOf([Integer(), String()]).validate(1), int)
    assert isinstance(OneOf([Integer(), String()]).validate("hi!"), str)
    assert OneOf([Integer(), String()]).validate("hi!") == "hi!"
    assert OneOf([Integer(), String()]).validate(1) == 1


### END ###

# Generated at 2022-06-22 05:50:54.840380
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of=[])
    assert field



# Generated at 2022-06-22 05:51:02.596658
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test valid
    f = OneOf([Any(), Any()])
    f.validate(1)
    f.validate(True)
    # Test invalid
    try:
        f = OneOf([Any(), NeverMatch()])
        f.validate(1)
    except Exception as e:
        assert True  # invalid
    else:
        assert False # valid
    try:
        f = OneOf([NeverMatch(), NeverMatch()])
        f.validate(1)
    except Exception as e:
        assert True  # invalid
    else:
        assert False # valid

# Generated at 2022-06-22 05:51:07.239779
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.examples import Number

    not_instance = Not(Number())
    assert not_instance.validate("not a number") == "not a number"
    try:
        not_instance.validate(5)
        assert False
    except:
        assert True

# Generated at 2022-06-22 05:51:08.305182
# Unit test for constructor of class Not
def test_Not():
    assert isinstance(Not(None), Not)

# Generated at 2022-06-22 05:51:14.501639
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    from typesystem import types

    class User(typesystem.Schema):
        name = IfThenElse(
            if_clause=types.Integer(),
            then_clause=types.String(),
            else_clause=types.String(),
        )

    user = User({"name": "Ada"})
    assert user.name == "Ada"
    assert user.validate() == {"name": "Ada"}

    user = User({"name": "Ada Lovelace"})
    assert user.errors == {"name": ["Must be an integer."]}

# Generated at 2022-06-22 05:51:23.407858
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("abc") is None


# Generated at 2022-06-22 05:51:26.939708
# Unit test for constructor of class OneOf
def test_OneOf():
	one_of_object = OneOf([Field(type_name='Integer'), Field(type_name='String')])
	assert one_of_object.one_of == [Field(type_name='Integer'), Field(type_name='String')]

# Generated at 2022-06-22 05:51:28.946251
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:51:29.562261
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()

# Generated at 2022-06-22 05:51:30.653132
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(None)



# Generated at 2022-06-22 05:51:42.110249
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (line 59)
    class String(Field):
        errors = {"type": "must be a string"}
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if not isinstance(value, str):
                raise self.validation_error("type")
            return value
    class Integer(Field):
        errors = {"type": "must be an integer"}
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if not isinstance(value, int):
                raise self.validation_error("type")
            return value
    not_string = Not(String())
    not_int = Not(Integer())

    # Test with string
    error = None

# Generated at 2022-06-22 05:51:47.968030
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Prepare
    from typesystem.fields import Integer, String
    field = IfThenElse(if_clause=Integer(), then_clause=String(), else_clause=Integer())
    value = 10
    strict = False

    # Execute
    result = field.validate(value=value, strict=strict)

    # Assert
    assert type(result) is str
    assert result == '10'



# Generated at 2022-06-22 05:51:52.245913
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    schema = IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    assert schema.if_clause != None
    assert schema.then_clause != None
    assert schema.else_clause != None


# Generated at 2022-06-22 05:51:55.063445
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    with pytest.raises(nm.validation_error):
        nm.validate("this doesn't work")


# Generated at 2022-06-22 05:51:56.167101
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass


# Generated at 2022-06-22 05:52:13.662514
# Unit test for method validate of class Not
def test_Not_validate():
    # Given
    test_field = Not(negated=Any())
    value = 4

    # When
    result, error = test_field.validate_or_error(value)

    # Then
    assert result == value
    assert error is None

# Generated at 2022-06-22 05:52:17.349867
# Unit test for constructor of class Not
def test_Not():
    not_object = Not(TestField(name = "Test Field"), required = True)
    assert not_object.label == "Test Field"
    assert not_object.description is None
    assert not_object.required == True
    assert not_object.allow_null == False


# Generated at 2022-06-22 05:52:21.587022
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer, String

    of = [Integer(), String]

    test = OneOf(of)

    assert test.errors == {
        'no_match': 'Did not match any valid type.',
        'multiple_matches': 'Matched more than one type.'}
    assert test.one_of == of



# Generated at 2022-06-22 05:52:23.897485
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(ValidationError) as e:
        NeverMatch(name="field").validate(None)
    assert e.value.source == {"field": "This never validates."}



# Generated at 2022-06-22 05:52:31.797521
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Make some data that would be valid in the then clause
    test_data = [1, 2, 3]
    # Create a dummy sub-field representing the then clause
    dummy_then_clause = Field(name="then clause")
    # Create the conditional field
    conditional = IfThenElse(if_clause=Any(), then_clause=dummy_then_clause)
    # Check that the test_data was validated against the then clause
    assert conditional.validate(test_data) == dummy_then_clause.validate(test_data)



# Generated at 2022-06-22 05:52:34.470203
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf(all_of=[])
    assert a.validate(1,strict=False) == 1

# Generated at 2022-06-22 05:52:46.027017
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.number import Integer
    from typesystem.object import Object
    from typesystem.string import String
    from .any import Any
    obj_sub_schema = {"a": String()}
    obj_sub_schema_schema = {"a": String()}
    if_sub_schema = {"if": Any(subtype_of=[Integer, String]), "then": Any()}
    else_sub_schema = {"else": Any()}
    then_sub_schema = {"then": Any()}
    #
    one_of_sub_schema = {"oneOf": [Any(subtype_of=[Integer, String]), Any()]}
    not_sub_schema = {"not": Any, "then": Any()}

# Generated at 2022-06-22 05:52:50.780538
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    fields = [String(),Integer()]
    testObject = AllOf(fields)
    
    try:
        testObject.validate('123')
    except Exception as e:
        assert str(e) == 'Not match'
    else:
        assert False


# Generated at 2022-06-22 05:53:01.962732
# Unit test for method validate of class Not
def test_Not_validate():
    not_Any = Not(Any())
    # Here we use assert_raises() to check if the resulting error is valid
    assert_raises(not_Any.validation_error, not_Any.validate, None)
    assert_raises(not_Any.validation_error, not_Any.validate, "")
    assert_raises(not_Any.validation_error, not_Any.validate, "string")
    assert_raises(not_Any.validation_error, not_Any.validate, 0)
    assert_raises(not_Any.validation_error, not_Any.validate, 1)
    assert_raises(not_Any.validation_error, not_Any.validate, 3.14)

# Generated at 2022-06-22 05:53:05.001393
# Unit test for constructor of class Not
def test_Not():
    # test_Not_init
    try :
        Not(None)
    except AssertionError:
        pass
    else :
        assert False


# Generated at 2022-06-22 05:53:24.272850
# Unit test for method validate of class Not
def test_Not_validate():
  from typesystem import String
  a = String()
  b = Not(negated=a)
  # negated test
  c = "hello world"
  d = b.validate(c)
  assert d == c
  # negated test
  c = None
  try:
    d = b.validate(c)
  except Exception:
    d = "error"
  assert d == "error"



# Generated at 2022-06-22 05:53:26.810305
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    not_String = Not(String())
    assert not_String.negated.__dict__ == String().__dict__



# Generated at 2022-06-22 05:53:38.147609
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    try:
        field.validate(123)
        assert False
    except Field.Error as e:
        assert e.type == "never"
        assert str(e) == "123 is not a valid 'never': This never validates."

    field = NeverMatch(name="foobar")
    try:
        field.validate(123)
        assert False
    except Field.Error as e:
        assert e.type == "never"
        assert str(e) == "123 is not a valid 'foobar': This never validates."

    field = NeverMatch(label="Foo Bar")
    try:
        field.validate(123)
        assert False
    except Field.Error as e:
        assert e.type == "never"

# Generated at 2022-06-22 05:53:40.206242
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    type = NeverMatch()
    print(type.errors)
    print(type)

# Generated at 2022-06-22 05:53:44.847912
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Int()).then_clause == Any()
    assert IfThenElse(Int()).else_clause == Any()
    assert IfThenElse(Int(), then_clause=Str(), else_clause=Int()).then_clause == Str()
    assert IfThenElse(Int(), then_clause=Str(), else_clause=Int()).else_clause == Int()

# Generated at 2022-06-22 05:53:46.298758
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    b = NeverMatch()


# Generated at 2022-06-22 05:53:51.190856
# Unit test for constructor of class OneOf
def test_OneOf():
    field1 = Field()
    field2 = Field()
    field3 = Field()
    fields = [field1, field2, field3]
    test = OneOf(fields)
    assert test.one_of[0] == field1
    assert test.one_of[1] == field2
    assert test.one_of[2] == field3

# Generated at 2022-06-22 05:53:53.900088
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any()).negated == Any()


# Generated at 2022-06-22 05:53:56.686663
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Constructor test
    n = NeverMatch()
    assert n.errors == {"never": "This never validates."}

# Unit tests for constructor and validate method of class OneOf

# Generated at 2022-06-22 05:53:58.186857
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    type = NeverMatch()
    assert '"This never validates."' in str(type.validate("test"))

# Generated at 2022-06-22 05:54:14.234491
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])



# Generated at 2022-06-22 05:54:16.559635
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # check that NeverMatch.validate() throws a validation error, since it never validates
    with pytest.raises(Field.validation_error):
        NeverMatch().validate(1)

# Generated at 2022-06-22 05:54:20.161442
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    my_IfThenElse = IfThenElse(if_clause = 1, then_clause = 1, else_clause = 1)
    assert my_IfThenElse.validate(if_clause = 1, then_clause = 1, else_clause = 1) is None
    print("test_IfThenElse_validate: Test passed")


# Generated at 2022-06-22 05:54:23.571365
# Unit test for constructor of class OneOf
def test_OneOf():
    int_field = typesystem.Integer()
    string_field = typesystem.String()
    test_field = typesystem.OneOf([int_field, string_field])
    assert test_field.one_of[0] == int_field
    assert test_field.one_of[1] == string_field


# Generated at 2022-06-22 05:54:25.587782
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer

    field = AllOf(all_of=[Integer(), Integer()])
    assert field.validate(14) == 14



# Generated at 2022-06-22 05:54:32.786762
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(typing.List[int], then_clause=Any(), else_clause=Any()).if_clause == typing.List[int]
    assert IfThenElse(typing.List[int], then_clause=Any(), else_clause=Any()).then_clause == Any()
    assert IfThenElse(typing.List[int], then_clause=Any(), else_clause=Any()).else_clause == Any()

# Generated at 2022-06-22 05:54:33.991685
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    field.validate(3)
    assert True


# Generated at 2022-06-22 05:54:36.182340
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of
    assert all_of.all_of == []


# Generated at 2022-06-22 05:54:38.197570
# Unit test for constructor of class AllOf
def test_AllOf():
  assert AllOf([Any()], name="AllOf")


# Generated at 2022-06-22 05:54:41.852123
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field, Field) == True
    assert field.allow_null == False
    assert field.required == True

# Unit tests for constructor of class OneOf

# Generated at 2022-06-22 05:55:16.037702
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem
    # all_of = [typesystem.Integer(), typesystem.String()]
    all_of = [typesystem.Integer(), typesystem.DateTime()]
    x = typesystem.AllOf(all_of)
    x.validate("123")
    print("test_AllOf_validate OK!")


# Generated at 2022-06-22 05:55:21.393351
# Unit test for constructor of class IfThenElse
def test_IfThenElse():

    if_clause = Any()
    then_clause = Int()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)

    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert field.else_clause == else_clause

# Generated at 2022-06-22 05:55:30.961279
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class FieldA:
        def validate_or_error(self, value, strict=False):
            return 1, None

    fieldA = FieldA()
    class FieldB:
        def validate_or_error(self, value, strict=False):
            return 2, None

    fieldB = FieldB()
    class FieldC:
        def validate_or_error(self, value, strict=False):
            return 3, None

    fieldC = FieldC()
    field = IfThenElse(fieldA, fieldB, fieldC)
    assert field.validate(1) == 2
    assert field.validate(1) == 2

test_IfThenElse_validate()

# Generated at 2022-06-22 05:55:35.880046
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated = NeverMatch())
    assert not_field.negated.validate(1) == 1
    try:
        not_field.negated.validate(2)
    except Exception as err:
        exception_msg = str(err)
        assert exception_msg == "This never validates."


# Generated at 2022-06-22 05:55:37.413247
# Unit test for constructor of class AllOf
def test_AllOf():
    allOf = AllOf([])
    assert isinstance(allOf, AllOf)

# Generated at 2022-06-22 05:55:42.408647
# Unit test for constructor of class Not
def test_Not():
    a = Field()
    b = Not(a)
    assert b.negated is a
    assert b.allow_null is a.allow_null
    assert b.default is a.default
    assert b.extra is a.extra
    assert b.metadata is a.metadata


# Generated at 2022-06-22 05:55:48.637148
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    json_data = {"a": 1, "b": "Hello", "c": {"name": "World!"}}
    field = AllOf([
        Field(name="a", subtype=int),
        Field(name="b", subtype=str),
        Field(name="c", subtype=dict)
    ])
    field.validate(json_data)


# Generated at 2022-06-22 05:55:52.982759
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    '''
    Test validate method of class NeverMatch

    :return:
    '''
    try:
        n = NeverMatch()
        n.validate("hello")
    except Exception as e:
        assert str(e) == "This never validates."