

# Generated at 2022-06-22 05:46:01.406667
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    # Test with a String.
    myNot = Not(String())
    assert myNot.validate(456) == 456
    # Test with not a String.
    assert myNot.validate(456) == 456
    # Test with not a String.
    try:
        myNot.validate("Not a number")
        assert False
    except ValidationError as e:
        assert e.code == "negated"


# Generated at 2022-06-22 05:46:07.884958
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # code
    class MyAllOf(AllOf):
        def validate(self, value, strict=False):
            for child in self.all_of:
                child.validate(value, strict=strict)
            return value
    # input
    import typesystem
    class MyField(typesystem.String):
        def validate(self, value, strict=False):
            return value
    field = MyField()
    field1 = MyField()
    field2 = MyField()
    all_of = [field1, field2]
    # execution
    obj = MyAllOf(all_of)
    # output
    assert obj.all_of == [field1, field2]
    assert obj != field
    assert obj == obj
    obj.validate('string')
    obj.validate('')
    obj.valid

# Generated at 2022-06-22 05:46:14.478140
# Unit test for method validate of class Not
def test_Not_validate():
    # Create an instance of a field
    field = Not(Boolean())

    # Test whether validate method works correctly
    # when given input value is a boolean
    # Expected output: None
    assert field.validate(True) is None
    assert field.validate(False) is None

    # Test whether validate method works correctly
    # when given input value is not a boolean
    # Expected output: value
    assert field.validate(88) == 88


# Generated at 2022-06-22 05:46:21.894398
# Unit test for method validate of class AllOf
def test_AllOf_validate():
  all_of = AllOf([Integer(), Integer()])
  assert all_of.validate(2) == 2
  with pytest.raises(ValueError) as exception_info:
    all_of.validate("1")
  assert exception_info.value.message == "Expected an integer."
  with pytest.raises(ValueError) as exception_info:
    all_of.validate(1.1)
  assert exception_info.value.message == "Expected an integer."


# Generated at 2022-06-22 05:46:24.282857
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(Field.validation_error):
        field.validate(0)


# Generated at 2022-06-22 05:46:26.649363
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors['never'] == "This never validates."


# Generated at 2022-06-22 05:46:27.795231
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-22 05:46:37.223602
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    a = 1
    # Test without then_clause and else_clause
    if_clause = Integer(maximum=5)
    #if_clause.verbose_name = 'if_clause_ic'
    #if_clause.verbose_name_plural = 'if_clause_ic'
    field = IfThenElse(if_clause)
    #field.verbose_name = 'field_ic'
    #field.verbose_name_plural = 'field_ic'
    try:
        field.validate(a)
    except Exception as e:
        raise AssertionError('Occured error when validate %s with \
            if_clause.maximum=5,then_clause=None, else_clause=None' % a)

# Generated at 2022-06-22 05:46:42.084823
# Unit test for constructor of class Not
def test_Not():
    from typesystem.types import String, Integer
    from typesystem.fields import Not
    from typesystem.errors import ValidationError
    my_not = Not(negated=Integer())
    try:
        my_not.validate('not_int')
    except ValidationError as e:
        assert (e.message == 'Must not match.')



# Generated at 2022-06-22 05:46:47.121333
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from ..typesystem_mock import mock_schema

    # initialize object
    input_obj = AllOf(
        all_of=[
            mock_schema(key="a", type=int),
            mock_schema(key="b", type=int),
        ]
    )
    # return values of the mock
    return_val = 99

    # run the validate method to be tested
    result = input_obj.validate(return_val)

    # test assertions



# Generated at 2022-06-22 05:46:51.769391
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(None, "hi")
    assert field.one_of == [None, "hi"]

# Generated at 2022-06-22 05:46:55.262028
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf(all_of=[s.String(),s.Integer()])
    a.validate("") # None
    a.validate("12") # ValueError
    a.validate(1) # None

# Generated at 2022-06-22 05:46:57.689912
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf(all_of=[])
    a.validate(0)
    a.validate('')
    a.validate(None)
    # no exception raised


# Generated at 2022-06-22 05:47:03.076154
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([String(), Number()]).validate("test") == "test"
    assert OneOf([String(), Number()]).validate(123) == 123
    try:
        OneOf([String(), Number()]).validate(None)
    except Exception as error:
        assert error.args[0] == "Did not match any valid type."
    try:
        OneOf([String(), Number()]).validate(2.5)
    except Exception as error:
        assert error.args[0] == "Matched more than one type."



# Generated at 2022-06-22 05:47:07.966502
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    ite = IfThenElse(Integer(max_value=10), Integer(min_value=8), Integer(min_value=1))

    # test case 1
    assert ite.validate(9) == 9

    # test case 2
    assert ite.validate(11) == 11


# Generated at 2022-06-22 05:47:12.189170
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Set up instance
    nevermatch = NeverMatch()

    try:
        # Call method
        nevermatch.validate(1)
    except NeverMatch.ValidationError as v_err:
        # Verify that exception message includes expected 'never'
        assert str(v_err).lower().find('never') >= 0
    else:
        assert False


# Generated at 2022-06-22 05:47:13.346611
# Unit test for constructor of class Not
def test_Not():
    f = Not(negated='test')
    assert f.negated == 'test'

# Generated at 2022-06-22 05:47:14.802385
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf([Text(max_length=2)])
    assert o.validate("ab") == "ab"

# Generated at 2022-06-22 05:47:18.356945
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of_field = AllOf([Any()])
    all_of_field.validate('Hello')
    # Return Type: None


# Generated at 2022-06-22 05:47:27.285007
# Unit test for constructor of class Not

# Generated at 2022-06-22 05:47:31.579957
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(String())
    n.validate('test')

# Generated at 2022-06-22 05:47:32.786904
# Unit test for constructor of class Not
def test_Not():
    import typing
    from typesystem.fields import Field
    Not(negated=Field)

# Generated at 2022-06-22 05:47:37.156488
# Unit test for constructor of class OneOf
def test_OneOf():
    s = OneOf([], label='OneOf', description='', required=False)
    s.validate_or_error('2')
    s.validate_or_error('3')


# Generated at 2022-06-22 05:47:39.148719
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=None)
    assert field.errors == {"negated": "Must not match."}


# Generated at 2022-06-22 05:47:43.088964
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    instance = NeverMatch()
    with pytest.raises(AttributeError) as excinfo:
        result = instance.validate(value = 0)


# Generated at 2022-06-22 05:47:53.342243
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Case where match_count == 1
    one_of_field = OneOf([Any()], name="OneOf")
    try:
        one_of_field.validate("a")
    except ValidationError:
        assert False

    # Case where match_count = 0
    one_of_field = OneOf([NeverMatch()], name="OneOf")
    try:
        one_of_field.validate("a")
        assert False
    except ValidationError:
        pass

    # Case where match_count > 1
    one_of_field = OneOf([Any(), Any()], name="OneOf")
    try:
        one_of_field.validate("a")
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-22 05:47:55.313034
# Unit test for method validate of class Not
def test_Not_validate():
    value = 123
    field = Not(String())
    assert field.validate(value) == value

# Generated at 2022-06-22 05:48:01.957586
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem

    type_str = typesystem.String()
    type_int = typesystem.Integer()

    type_ifElse = IfThenElse(type_str, then_clause=type_str, else_clause=type_int)

    assert type_ifElse.validate("5") == "5"
    assert type_ifElse.validate(5) == 5
    assert type_ifElse.validate(5.5) == 5

# Generated at 2022-06-22 05:48:09.852503
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Schema

    class AllOfTester(Schema):
        tester = AllOf(["String", "Integer"])

    AllOfTester().validate({"tester": "String"})
    AllOfTester().validate({"tester": "Integer"})
    try:
        AllOfTester().validate({"tester": "Wrong"})
    except Exception as e:
        assert "No valid substructure" in e.messages.get("tester")

        # Unit test for constructor of class IfThenElse



# Generated at 2022-06-22 05:48:21.445589
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Literal(True), then_clause=Literal(1)).validate(
        value=1
    ) == 1
    assert IfThenElse(if_clause=Literal(False), then_clause=Literal(1)).validate(
        value=1
    ) == 1
    assert IfThenElse(if_clause=Literal(True), then_clause=String()).validate(
        value=1
    ) == 1
    assert IfThenElse(if_clause=Literal(True), then_clause=String()).validate(
        value=True
    ) == True

# Generated at 2022-06-22 05:48:28.320395
# Unit test for constructor of class OneOf
def test_OneOf():
    list = [Any()]
    field = OneOf(list)
    assert field.one_of == list
    assert field.errors == \
    {
    "no_match": "Did not match any valid type.",
    "multiple_matches": "Matched more than one type."
    }


# Generated at 2022-06-22 05:48:30.326796
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        OneOf(one_of=[])
    except AssertionError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-22 05:48:40.734300
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        String()
    ])
    assert field.validate("foo") == "foo"
    try:
        field.validate(1) # raises Assertion Error
    except AssertionError:
        pass
    try:
        field.validate("bar", strict=True) # raises Assertion Error
    except AssertionError:
        pass
    try:
        field.validate("foo", strict=False) # raises Assertion Error
    except AssertionError:
        pass
    field = OneOf([
        String()
    ], description="A description")
    assert field.validate("foo") == "foo"
    field = OneOf([
        String()
    ], required=True)
    assert field.validate("foo") == "foo"

# Generated at 2022-06-22 05:48:48.478757
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field(required=True)
    then_clause = Field(required=True)
    else_clause = Field(required=True)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert isinstance(if_then_else, IfThenElse)
    assert isinstance(if_then_else.then_clause, Any)
    assert isinstance(if_then_else.else_clause, Any)

# Generated at 2022-06-22 05:48:50.156136
# Unit test for method validate of class Not
def test_Not_validate():
    a = Not({"type": "string"})
    b = a.validate(1)
    assert b == 1



# Generated at 2022-06-22 05:48:52.850831
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """
    Tests that instantiating a NeverMatch object throws an AssertionError when
    an allow_null kwarg is provided.
    """
    with pytest.raises(AssertionError):
        NeverMatch(allow_null = True)


# Generated at 2022-06-22 05:48:54.517866
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Create an instance of Field
    field = Field()
    value = 1
    strict = False
    field.validate(value, strict)
    
    

# Generated at 2022-06-22 05:49:00.350863
# Unit test for method validate of class OneOf

# Generated at 2022-06-22 05:49:04.239781
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite=IfThenElse( if_clause=Integer(),then_clause=Integer(minimum=5), else_clause=Integer(minimum=4) )
    assert ite.validate(3)==3
    assert ite.validate(5)==5

# Generated at 2022-06-22 05:49:09.537112
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = UndefinedField()
    print(a.validate(1))
    b = IntegerField()
    print(b.validate(1))
    c = AllOf([a, b])
    print(c.validate(1))
    d = AllOf([a, b], name="d")
    print(d.validate(1))


# Generated at 2022-06-22 05:49:21.969431
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Assert that validation is successful if the value matches all subitems.
    """
    import typesystem

    class SubItem(typesystem.Integer):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            value = super().validate(value, strict=strict)
            if value % 2:
                raise self.validation_error("not even")
            return value

    class CustomSchema(AllOf):
        all_of = [
            SubItem(max_value=10),
            SubItem(min_value=5),
        ]

    assert CustomSchema().validate(6) == 6
    assert CustomSchema().validate(8) == 8


# Generated at 2022-06-22 05:49:25.296697
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        my_OneOf = OneOf([1])
    except TypeError:
        print("pass")
    except AssertionError:
        print("pass")


# Generated at 2022-06-22 05:49:34.899015
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([Any()])
    
    # valid
    assert f.validate(None, strict=True) is None
    assert f.validate(1, strict=True) == 1
    assert f.validate(2.0, strict=True) == 2.0
    assert f.validate("3", strict=True) == "3"
    assert f.validate(True, strict=True) == True
    assert f.validate(False, strict=True) == False
    
    # invalid -- AllOf should not raise an error
    assert f.validate(object(), strict=True) == object()



# Generated at 2022-06-22 05:49:37.897278
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Integer(),String(),Integer())
    assert field.validate("1234") == "1234"
    assert field.validate(1234) == 1234


# Generated at 2022-06-22 05:49:46.955299
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse_instance = IfThenElse(if_clause=1, then_clause=2, else_clause=3)
    IfThenElse_instance.validate(1, strict=False)
    IfThenElse_instance.validate(2, strict=False)
    IfThenElse_instance.validate(3, strict=False)

    IfThenElse_instance = IfThenElse(if_clause=1, then_clause=2)
    IfThenElse_instance.validate(1, strict=False)
    IfThenElse_instance.validate(2, strict=False)
    IfThenElse_instance.validate(3, strict=False)

    IfThenElse_instance = IfThenElse(if_clause=1, else_clause=3)

# Generated at 2022-06-22 05:49:51.265882
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
	with pytest.raises(AssertionError):
		NeverMatch(allow_null=True)
	nm = NeverMatch()
	with pytest.raises(ValidationError, match="This never validates."):
		nm.validate(value=1)


# Generated at 2022-06-22 05:49:53.821547
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Arrange
    m = NeverMatch()
    value = "5"
    # Act
    # Assert
    assert m.validate(value) == "5"



# Generated at 2022-06-22 05:49:58.035051
# Unit test for constructor of class AllOf
def test_AllOf():
    class A(AllOf):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__([], **kwargs)
    a = A()



# Generated at 2022-06-22 05:50:00.480420
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert (IfThenElse(if_clause=None, then_clause=None, else_clause=None).all_of() == [Any()])

# Generated at 2022-06-22 05:50:02.893723
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of = [1, 2, 3])

# Generated at 2022-06-22 05:50:07.050999
# Unit test for constructor of class Not
def test_Not():
    not_test = Not(int)
    assert not_test.negated == int

# Generated at 2022-06-22 05:50:11.512808
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    fields = [String(max_length=20),Integer(minimum=0,maximum=10)]
    field = AllOf(fields)
    assert field.validate("hola") == "hola"
    assert field.validate(1) == 1
    assert field.validate("hola") != 1


# Generated at 2022-06-22 05:50:13.133721
# Unit test for constructor of class OneOf
def test_OneOf():
    type = OneOf()
    assert type is not None


# Generated at 2022-06-22 05:50:16.389573
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    try:
        field.validate_or_error(1)
    except ValueError as ve:
        assert 'This never validates' in str(ve)
        assert 'never' in str(ve)


# Generated at 2022-06-22 05:50:18.138107
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    with pytest.raises(TypesystemError):
        n.validate(5)

# Generated at 2022-06-22 05:50:19.805280
# Unit test for constructor of class OneOf
def test_OneOf():
	assert OneOf([Boolean(), Float(), Integer()], description='desc')


# Generated at 2022-06-22 05:50:24.891538
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert '{}' is IfThenElse(Any()).validate({})
    assert '{}' is IfThenElse(Any(),then_clause=Any()).validate({})
    assert '{}' is IfThenElse(Any(),then_clause=Any(),else_clause=Any()).validate({})
    assert '{1:1}' is IfThenElse(Any(),then_clause=Any(),else_clause=Any()).validate({1:1})


# Generated at 2022-06-22 05:50:26.411775
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([1]).one_of == [1]


# Generated at 2022-06-22 05:50:31.411763
# Unit test for method validate of class OneOf
def test_OneOf_validate():
  f = OneOf([StringField()])
  # expected error message:
  #  {'one_of': ['Did not match any valid type.']}
  assert f.validate(123) == {'one_of': ['Did not match any valid type.']}
  assert f.validate("hello") == "hello"



# Generated at 2022-06-22 05:50:37.938274
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import jsonschema
    from typesystem.exceptions import ValidationError

    field = NeverMatch()
    try:
        field.validate(0)
    except ValidationError as e:
        assert str(e) == "This never validates."
        assert e.data == 0
        assert e.field == field
    else:  # pragma: no cover
        assert False, "Did not raise"

    try:
        field.validate(0, strict=True)
    except jsonschema.ValidationError:
        pass
    else:  # pragma: no cover
        assert False, "Did not raise"



# Generated at 2022-06-22 05:50:42.240348
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    assert n.validate(None) == None

# Generated at 2022-06-22 05:50:46.355551
# Unit test for constructor of class AllOf
def test_AllOf():
    allOf = AllOf(base_type=dict, all_of=[Field(name="a", base_type=str)])
    assert allOf.all_of[0].name == "a" 
    allOf.validate({"a": 1})


# Generated at 2022-06-22 05:50:50.624098
# Unit test for constructor of class AllOf
def test_AllOf():
    subitem = Field()
    all_of = AllOf(all_of=[subitem], key="foo")
    assert all_of.all_of == [subitem]
    assert all_of.key == "foo"



# Generated at 2022-06-22 05:50:53.304907
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field


# Generated at 2022-06-22 05:50:55.208802
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch()
    assert obj.__class__.__name__ == 'NeverMatch'



# Generated at 2022-06-22 05:50:57.107367
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Field(),Field()])
    field.validate("Hello")


# Generated at 2022-06-22 05:50:59.524450
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass
# Error when a field that does not exist was passed
# Error when a field that does not exist was passed


# Generated at 2022-06-22 05:51:01.789505
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        field = OneOf([])
    except Exception as e:
        return False
    return True



# Generated at 2022-06-22 05:51:12.743744
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    type_if = Field()
    type_then = Field()
    type_else = Field()
    type_ifthenelse = IfThenElse(type_if, type_then, type_else)

    type_if.validate = MagicMock(return_value=None)
    type_then.validate = MagicMock()
    type_ifthenelse.validate(None)
    assert type_if.validate.call_count == 1
    assert type_then.validate.call_count == 1

    type_then.validate = MagicMock()
    type_if.validate = MagicMock(return_value='not none')
    type_ifthenelse.validate(None)
    assert type_if.validate.call_count == 1
    assert type_then.validate.call_count == 0

# Generated at 2022-06-22 05:51:18.345909
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    value = "value"
    try:
        field.validate(value)
    except NeverMatch.validation_error as e:
        if e.code == "never":
            pass
        else:
            raise e
    except Exception as e:
        assert False


# Generated at 2022-06-22 05:51:26.991421
# Unit test for constructor of class Not
def test_Not():
    # Test for constructor of class Not
    print("\nUnit test for constructor of class Not")

    # Test normal situations
    test_Not = Not(Any())
    print("Test normal situations")
    print(test_Not)

    # Test exception
    test_Not = Not(Any(), allow_null = False)
    print("\nTest exception")
    print(test_Not)


# Generated at 2022-06-22 05:51:35.587010
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from . import String, Number, OneOf, StringUnion, NumberUnion
    if_clause = OneOf([String, Number])
    then_clause = StringUnion()
    else_clause = NumberUnion()
    field = IfThenElse(if_clause, then_clause, else_clause, description="this is a description")
    # test correct validation
    assert field.validate(1) == 1
    assert field.validate("this") == "this"
    # test incorrect validation
    try:
        field.validate({"key": "value"})
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-22 05:51:38.352399
# Unit test for constructor of class Not
def test_Not():
    a_field = Not(AllOf)
    if type(a_field) == Not:
        print("test_Not: Passed")
    else:
        print("test_Not: Failed")

# Generated at 2022-06-22 05:51:44.252305
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # the __init__ method of class NeverMatch doesn't contain the way to input parameters,
    # so we cannot create the instance of this class directly.
    # we can use the instance that has been created in the test of another method.
    # test utils
    field = NeverMatch()
    # function validation
    with pytest.raises(Exception):
        field.validate(1)



# Generated at 2022-06-22 05:51:46.525726
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(Field.ValidationError):
        field.validate(True)


# Generated at 2022-06-22 05:51:51.310177
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Field()).if_clause == Field()
    assert IfThenElse(if_clause=Field()).then_clause == Any()
    assert IfThenElse(if_clause=Field()).else_clause == Any()
    assert IfThenElse(if_clause=Field(), then_clause=Field()).then_clause == Field()
    assert IfThenElse(if_clause=Field(), else_clause=Field()).else_clause == Field()

# Generated at 2022-06-22 05:51:52.457336
# Unit test for constructor of class Not
def test_Not():
    pass


# Generated at 2022-06-22 05:51:57.224678
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    test_IfThenElse()
    test for constructor of class IfThenElse
    """
    f = IfThenElse(String(),Integer(),Float())
    assert f.if_clause == String()
    assert f.then_clause == Integer()
    assert f.else_clause == Float()



# Generated at 2022-06-22 05:51:58.662219
# Unit test for method validate of class Not
def test_Not_validate():
    field_not  = Not(None)
    field_not.validate()

# Generated at 2022-06-22 05:52:00.448235
# Unit test for constructor of class AllOf
def test_AllOf():
    test_field = AllOf([], name="test_field")
    assert test_field.name == "test_field"

# Generated at 2022-06-22 05:52:08.690187
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert (IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()))



# Generated at 2022-06-22 05:52:16.777153
# Unit test for method validate of class Not
def test_Not_validate():
    never = NeverMatch()
    not_never = Not(negated=never)
    assert not_never.validate(None) is None
    assert_raises_with_message(never.validation_error("never"), never.validate, 42)
    assert_raises_with_message(never.validation_error("never"), never.validate, "hello")
    assert_raises_with_message(never.validation_error("never"), never.validate, {})


# Generated at 2022-06-22 05:52:17.743829
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	pass

# Generated at 2022-06-22 05:52:19.461711
# Unit test for constructor of class Not
def test_Not():
    assert Not is not None


# Generated at 2022-06-22 05:52:22.656143
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    with pytest.raises(AssertionError):
        IfThenElse(Boolean(), then_clause=None)
    with pytest.raises(AssertionError):
        IfThenElse(Boolean(), else_clause=None)

# Generated at 2022-06-22 05:52:25.809716
# Unit test for constructor of class Not
def test_Not():
    notNull = Not(Any())
    assert notNull.negated == Any()
    assert notNull.errors == {"negated": "Must not match."}

# Generated at 2022-06-22 05:52:30.709388
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from unittest import TestCase

    class Test(TestCase):
        def test_constructor(self):
            t = AllOf(all_of=[String()])
            self.assertEqual(t.all_of,[String()])
            self.assertEqual(t.errors, {})


# Generated at 2022-06-22 05:52:37.544320
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import json
    import typing
    from typesystem import Schema
    from typesystem.fields import Integer, String

    class TestSchema(Schema):
        field = AllOf([Integer(), String()])
    
    test10 = TestSchema({"field": "10"}, strict=False)
    test11 = TestSchema({"field": 10}, strict=False)
    test12 = TestSchema({"field": [1,2,3]}, strict=False)
    print(test10, test11, test12)
    

# Generated at 2022-06-22 05:52:39.214864
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([str]).validate('a') == 'a'

# Generated at 2022-06-22 05:52:43.063986
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Any(), then_clause=Any())
    assert field.if_clause.__class__.__name__ == 'Any'
    assert field.then_clause.__class__.__name__ == 'Any'



# Generated at 2022-06-22 05:52:51.224823
# Unit test for constructor of class AllOf
def test_AllOf():
    assert issubclass(AllOf, Field)
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-22 05:52:59.149547
# Unit test for constructor of class OneOf

# Generated at 2022-06-22 05:53:00.939092
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never = NeverMatch()
    assert never.errors == {"never": "This never validates."}

# Generated at 2022-06-22 05:53:01.536714
# Unit test for constructor of class AllOf
def test_AllOf():
    pass

# Generated at 2022-06-22 05:53:10.402319
# Unit test for method validate of class Not
def test_Not_validate():
    instance_not = Not(negated=Any())
    value, error = instance_not.validate_or_error(40)
    assert value == 40 and error == None

    value, error = instance_not.validate_or_error(40.40)
    assert value == 40.40 and error == None

    value, error = instance_not.validate_or_error("hello")
    assert value == "hello" and error == None

    value, error = instance_not.validate_or_error([])
    assert value == [] and error == None

    value, error = instance_not.validate_or_error({"key": "value"})
    assert value == {"key": "value"} and error == None

    value, error = instance_not.validate_or_error(True)
    assert value == True and error

# Generated at 2022-06-22 05:53:16.946580
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test = IfThenElse(if_clause=1, then_clause=2, else_clause=3)
    assert test.if_clause.validate(1, False) == 1
    assert test.then_clause.validate(2, False) == 2
    assert test.else_clause.validate(3, False) == 3
    assert test.validate(1, False) == 2
    assert test.validate(3, False) == 3


# Generated at 2022-06-22 05:53:18.351546
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate(1) == 1

# Generated at 2022-06-22 05:53:21.049087
# Unit test for method validate of class Not
def test_Not_validate():
    v1 = 'a'
    n = Not(String())
    n.validate(v1)
    


# Generated at 2022-06-22 05:53:24.406096
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=Any(), then_clause=Any())
    assert field.if_clause == Any()
    assert field.then_clause == Any()
    assert field.else_clause == Any()

# Generated at 2022-06-22 05:53:25.603389
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    return None


# Generated at 2022-06-22 05:53:46.094269
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer

    class Pet(typesystem.Schema):
        identifier = Integer(minimum=1)
        name = typesystem.String()

    class Person(typesystem.Schema):
        pet = IfThenElse(
            if_clause=typesystem.Object(
                properties={"kind": typesystem.String(const="cat")}
            ),
            then_clause=Pet,
            else_clause=typesystem.String(),
        )

    person = Person({"pet": {"identifier": 10, "name": "Paws"}})

    assert person.validate() is True
    assert person["pet"].validate() is True
    assert person["pet"]["identifier"].validate() is True
    assert person["pet"]["name"].validate() is True

# Generated at 2022-06-22 05:53:52.874738
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    assert isinstance(if_then_else, IfThenElse)
    assert isinstance(if_then_else.if_clause, Field)
    assert isinstance(if_then_else.then_clause, Field)
    assert isinstance(if_then_else.else_clause, Field)

# Generated at 2022-06-22 05:53:58.186019
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test default values of attributes
    field = OneOf([
        Int(),
        Str(),
    ])

    assert field.errors == {
        "no_match": "Did not match any valid type.",
        "multiple_matches": "Matched more than one type.",
    }

    assert field.one_of == [Int(), Str()]


# Generated at 2022-06-22 05:54:03.227694
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(NeverMatch().validate({}, strict=False)) == {}, 'test_Not_validate assert#1 has failed.'
    assert Not(NeverMatch().validate({}, strict=True)) == {}, 'test_Not_validate assert#2 has failed.'

# Generated at 2022-06-22 05:54:08.712742
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = Field(name="one_of", one_of=[Field(name="1"), Field(name="2"), Field(name="3")])
    assert one_of.name == "one_of"
    assert one_of.one_of[0].name == "1"
    assert one_of.one_of[1].name == "2"
    assert one_of.one_of[2].name == "3"


# Generated at 2022-06-22 05:54:09.766303
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    i = IfThenElse(String(),Integer())
    i.validate(1)
    i.validate('1')


# Generated at 2022-06-22 05:54:13.957287
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Integer, String

    all_of = AllOf([Integer(), String(min_length=1, max_length=3)])
    assert all_of.validate(2) == 2
    assert all_of.validate("ha") == "ha"


# Generated at 2022-06-22 05:54:16.193131
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        Not(fields.Integer(), allow_null=False)


# Generated at 2022-06-22 05:54:16.843330
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(Integer())

# Generated at 2022-06-22 05:54:17.915027
# Unit test for constructor of class AllOf
def test_AllOf():
    one_of = [1]
    super().__init__(all_of = one_of)


# Generated at 2022-06-22 05:54:39.481208
# Unit test for method validate of class Not
def test_Not_validate():
    testField = Not(Field())
    try:
        testField.validate(True)
        assert True
    except:
        assert False



# Generated at 2022-06-22 05:54:42.761103
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(FieldError) as e:
        field.validate(None)
        assert e.code == 'never'


# Generated at 2022-06-22 05:54:44.975555
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nMatch = NeverMatch(**{'name': 'value'})
    assert nMatch.name == 'value'


# Generated at 2022-06-22 05:54:47.543978
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause = String(),
        then_clause = String(),
        else_clause = String()
    )


# Generated at 2022-06-22 05:54:50.182302
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated = Field())
    assert not_field.negated == Field()


# Generated at 2022-06-22 05:54:57.202837
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    '''It should test validate method of class AllOf'''
    from typesystem.fields import String

    field = AllOf([String(max_length=3), String(min_length=3)])
    field.validate('foo')

    try:
        field.validate('foooo')
    except:
        return
    assert False, 'It should raise an error'


# Generated at 2022-06-22 05:54:58.734723
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(None,None,None) is not None

# Generated at 2022-06-22 05:55:10.234490
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class if_clause(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class then_clause(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class else_clause(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    assert IfThenElse(if_clause()).validate("if_was_none") == "if_was_none"
    assert IfThenElse(if_clause(), then_clause()).validate("if_was_none") == "if_was_none"

# Generated at 2022-06-22 05:55:21.852757
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf([])
    assert all_of.validate([]) == []
    all_of = AllOf([Int()])
    assert all_of.validate(1) == 1
    all_of = AllOf([Float()])
    assert all_of.validate(1.1) == 1.1
    all_of = AllOf([Int(),Float(),String()])
    assert all_of.validate(1.1) == 1.1
    all_of = AllOf([Float(),String()])
    assert all_of.validate(1.1) == 1.1
    all_of = AllOf([Int(),String()])
    assert all_of.validate(1) == 1
    all_of = AllOf([String(),Int()])

# Generated at 2022-06-22 05:55:27.076009
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    _, error = not_field.validate_or_error(1)
    assert error is None

    _, error = not_field.validate_or_error(2)
    assert error is None

    _, error = not_field.validate_or_error(None)
    assert error is None
