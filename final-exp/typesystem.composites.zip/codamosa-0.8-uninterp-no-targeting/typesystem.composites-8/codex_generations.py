

# Generated at 2022-06-22 05:46:10.089240
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String
    m = AllOf([String(max_length=5), String(min_length=5)])
    m.validate("12345")

    from typesystem.fields import Integer
    m = AllOf([String(max_length=5), Integer()])
    with pytest.raises(ValidationError) as e:
        m.validate("12345")
    assert e.value.category == "validation"



# Generated at 2022-06-22 05:46:12.044553
# Unit test for constructor of class Not
def test_Not():
    from typesystem import String
    not_string = Not(String())
    assert not_string is not None


# Generated at 2022-06-22 05:46:14.790640
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    value = [1,2,3]
    t = OneOf([])
    t.validate(value)
    assert value == [1,2,3]

# Generated at 2022-06-22 05:46:17.685657
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(ValidationError) as e:
        NeverMatch().validate(None)
    assert e.value.messages == {"never"}


# Generated at 2022-06-22 05:46:29.315890
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem
    class Person(typesystem.Schema):
        age = typesystem.Number(description='Age in years')
        name = typesystem.String(description='Person\'s name')
    class Dog(typesystem.Schema):
        age = typesystem.Number(description='Age in years')
        name = typesystem.String(description='Dog\'s name')
    class Cat(typesystem.Schema):
        age = typesystem.Number(description='Age in years')
        name = typesystem.String(description='Cat\'s name')

    # Make the field
    field = AllOf([Person(), Dog(), Cat()])
    # Make the value to be validated
    value = {
        'age': 4,
        'name': 'Phillip'
    }
    # Validate
    field.validate(value)



# Generated at 2022-06-22 05:46:38.327621
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert(NeverMatch().render() == {'$schema': 'http://json-schema.org/draft-07/schema#', 'title': 'NeverMatch', 'type': 'null'})
    assert(NeverMatch(description="description of NeverMatch").render() == {'$schema': 'http://json-schema.org/draft-07/schema#', 'title': 'NeverMatch', 'type': 'null'})
    assert(NeverMatch().validate_or_error(None) == (None, None))
    assert(NeverMatch().validate_or_error(0) == ("0 is not of type 'null'", "never"))

# Generated at 2022-06-22 05:46:46.374587
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestField(Field):
        def validate(self, value, strict=False):
            return True

    class TestField2(Field):
        def validate(self, value, strict=False):
            return False

    if_clause = TestField()
    then_clause = TestField()
    else_clause = TestField2()
    ifThenElse = IfThenElse(if_clause, then_clause, else_clause)

    result = ifThenElse.validate(1)  # should return True
    if result != True:
        print('test_IfThenElse_validate() failed')

# Generated at 2022-06-22 05:46:48.657491
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(), None, None)
    value = 123
    assert field.validate(value) == value

# Generated at 2022-06-22 05:46:59.066918
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.exceptions import ValidationError
    from typesystem.primitives import String
    from typesystem.utils import to_camel_case

    some_field = String(max_length=5)

    field = Not(some_field)

    # Call method validate of class Not with correct value
    try:
        field.validate("test")
    except ValidationError:
        assert False

    # Call method validate of class Not with incorrect value
    try:
        field.validate("test123")
        assert False
    except ValidationError as e:
        error = e.as_serializable()
        assert error["name"] == "Not"
        assert error["code"] == to_camel_case("negated")
        assert error["value"] == "test123"
        assert error["path"] == field.absolute_path

# Generated at 2022-06-22 05:47:01.328625
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(required=True, description="f")
    assert field

# Generated at 2022-06-22 05:47:07.175770
# Unit test for constructor of class Not
def test_Not():
    schema = Not(String())
    assert isinstance(schema, Not)
    assert isinstance(schema.negated, String)

# Generated at 2022-06-22 05:47:08.307995
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(key='test') is not None


# Generated at 2022-06-22 05:47:14.717725
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(String(), String())
    out1, _ = field.validate_or_error("a")
    assert out1 == "a"
    out2, _ = field.validate_or_error(None)
    assert out2 == None
    field = IfThenElse(String(), String(), Else(String()))
    out3, _ = field.validate_or_error(None)
    assert out3 == "None"
    field = IfThenElse(String(), Else(String()), String())
    out4, _ = field.validate_or_error(None)
    assert out4 == None


# Generated at 2022-06-22 05:47:15.204052
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert 1 == 1

# Generated at 2022-06-22 05:47:25.619926
# Unit test for constructor of class AllOf
def test_AllOf():
    import pytest
    from typesystem.fields import Type, Regex

    with pytest.raises(AssertionError):
        field = AllOf(all_of=[Type("str")], allow_null=False)

    field = AllOf(all_of=[Type("str"), Type("int")])
    assert field.validate("hello") == "hello"
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(object()) == object()

    field = AllOf(all_of=[Regex('\d+')])
    for value in '12345':
        field.validate(value)


# Generated at 2022-06-22 05:47:36.471976
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    field = IfThenElse(if_clause, then_clause, else_clause)

    # The value is validated by if_clause and then_clause with no error
    # But if_clause raises, so then_clause should not be validated.
    if_clause.validate_or_error = MagicMock(return_value=(1, None))
    then_clause.validate_or_error = MagicMock(return_value=(1, None))
    assert field.validate_or_error(1)[0] == 1
    if_clause.validate_or_error.assert_called_once_with(1)
    then_clause.validate_or_error.assert_

# Generated at 2022-06-22 05:47:38.517992
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  test_NeverMatch = NeverMatch(name="NeverMatch")
  assert test_NeverMatch.name == "NeverMatch"


# Generated at 2022-06-22 05:47:39.990936
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-22 05:47:50.323934
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = String(max_length=2)
    then_clause = String(max_length=3)
    else_clause = String(max_length=4)
    cond = IfThenElse(if_clause=if_clause, then_clause=then_clause, 
            else_clause=else_clause)
    # expected value
    assert cond.validate("12") == "12"
    # if clause is negative
    assert cond.validate("123") == "123"
    # else clause is negative
    assert cond.validate("12345") == "12345"


# Generated at 2022-06-22 05:47:53.536941
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(IfThenElse(None, None, None))
    assert ite.if_clause == IfThenElse(None, None, None)
    assert ite.then_clause == Any()
    assert ite.else_clause == Any()

# Generated at 2022-06-22 05:47:58.617612
# Unit test for constructor of class AllOf
def test_AllOf():
    # Not validating x because we want to test if validation happens
    x = AllOf([Any()])
    assert isinstance(x, Field)


# Generated at 2022-06-22 05:48:01.419560
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}
    assert field.allow_null == False
    assert field.description == None


# Generated at 2022-06-22 05:48:03.125389
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf(
        [
            int(),
            float(),
        ]
    )


# Generated at 2022-06-22 05:48:07.186740
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError) as excinfo:
        field.validate('test_string')
    excinfo.match(r'This never validates.')


# Generated at 2022-06-22 05:48:10.084971
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    item = AllOf(all_of=[Any(), Any()])
    result = item.validate([1, 2, 3])
    assert result == [1, 2, 3]


# Generated at 2022-06-22 05:48:11.794023
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_field = NeverMatch(name='name', description='description')
    assert test_field.name == 'name'
    assert test_field.description == 'description'



# Generated at 2022-06-22 05:48:16.313469
# Unit test for method validate of class Not
def test_Not_validate():
    """
    test_Not_validate check the method validate of class Not
    """
    simple_integer = 5
    simple_string = "simple_string"
    not_field = Not(negated=Any)
    not_field.validate(simple_integer)



# Generated at 2022-06-22 05:48:18.695725
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match.validate is not None
    assert never_match.errors is not None


# Generated at 2022-06-22 05:48:21.341306
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Boolean(True, True))
    value = True
    expected = True
    actual = field.validate(value)
    assert actual == expected

# Generated at 2022-06-22 05:48:21.943976
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf(Field)

# Generated at 2022-06-22 05:48:32.155832
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    num = 2
    if_clause = IsInt()
    then_clause = IsNumber()
    else_clause = IsString()
    ife = IfThenElse(if_clause, then_clause, else_clause)
    assert ife.validate(num) == num

# Generated at 2022-06-22 05:48:33.177433
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    pass



# Generated at 2022-06-22 05:48:35.032980
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nevm = NeverMatch()
    with pytest.raises(FieldValidationError):
        nevm.validate(1)

# Generated at 2022-06-22 05:48:35.662327
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-22 05:48:36.693330
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  a = NeverMatch()


# Generated at 2022-06-22 05:48:37.672538
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf(all_of=[])

# Generated at 2022-06-22 05:48:40.380610
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem
    instance = AllOf(all_of=[typesystem.String()])
    assert isinstance(instance, typesystem.AllOf)


# Generated at 2022-06-22 05:48:45.401631
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    assert field.if_clause == Field()
    assert field.then_clause == Field()
    assert field.else_clause == Field()


# Generated at 2022-06-22 05:48:52.206678
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Boolean, Integer
    from typesystem.exceptions import ValidationError

    field = OneOf([Boolean(), Integer()])

    assert field.validate(True)

    with pytest.raises(ValidationError) as exc:
        field.validate(1.1)
    assert exc.value.code == "no_match"

    with pytest.raises(ValidationError) as exc:
        field.validate("string")
    assert exc.value.code == "no_match"

    with pytest.raises(ValidationError) as exc:
        field.validate(None)
    assert exc.value.code == "no_match"



# Generated at 2022-06-22 05:48:54.068972
# Unit test for constructor of class IfThenElse

# Generated at 2022-06-22 05:49:09.536771
# Unit test for method validate of class Not
def test_Not_validate():
    field_correct = Not(negated = typing.Any())
    field_incorrect = Not(negated = typing.Any())
    assert field_correct.validate("True") == "True"
    assert field_correct.validate("False") == "False"

    assert field_incorrect.validate("True") == "True"
    assert field_incorrect.validate("False") == "False"
    print("Test method validate for class Not passed.")



# Generated at 2022-06-22 05:49:11.103445
# Unit test for constructor of class OneOf
def test_OneOf():
    assert 'one_of' in OneOf.__dict__


# Generated at 2022-06-22 05:49:15.276779
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = String()
    actual = IfThenElse(if_clause)
    expected = IfThenElse(if_clause, None, None)
    assert actual == expected
    print(actual)



# Generated at 2022-06-22 05:49:17.643095
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[Any()], allow_empty=True, allow_coerce=True)


# Generated at 2022-06-22 05:49:20.132472
# Unit test for method validate of class Not
def test_Not_validate():
    schema = Not(Any())
    value = "abc"
    expected = value
    assert schema.validate(value) == expected

# Unit tests for method validate of class IfThenElse

# Generated at 2022-06-22 05:49:31.112352
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer

    # if
    if_clause = Integer(minimum=1)
    # then
    then_clause = Integer(maximum=10)
    # else
    else_clause = Integer(maximum=100)

    # if / then
    if_then_else = IfThenElse(if_clause, then_clause)
    # print(f"\n{if_then_else}")
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(10) == 10
    try:
        if_then_else.validate(0)
    except Exception as e:
        assert f"{e}" == "Invalid value: 0. Must be at least 1."


# Generated at 2022-06-22 05:49:41.192486
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Call AllOf.validate() and check if the correct result is returned.
    """

    # create a list of Fields
    test_field1 = Field(name="test1")
    test_field2 = Field(name="test2")
    all_of = [test_field1, test_field2]

    # create a new instance of AllOf
    all_of_field = AllOf(all_of)

    # define a test value
    test_value = "Hello world"

    # call method validate of class AllOf
    test_result = all_of_field.validate(test_value)

    # check the returned result
    assert test_result == test_value


# Generated at 2022-06-22 05:49:43.281791
# Unit test for constructor of class AllOf
def test_AllOf():
    my_AllOf = AllOf(None)
    assert isinstance(my_AllOf, AllOf)


# Generated at 2022-06-22 05:49:47.680087
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Integer()
    then_clause = Integer()
    else_clause = Integer()
    field = IfThenElse(if_clause, else_clause, then_clause)   
    assert field.validate(1) == 1
    assert field.validate('a') == 0



# Generated at 2022-06-22 05:49:49.786571
# Unit test for constructor of class Not
def test_Not():
    # You should use custom validation instead.
    not_test = Not(Field())
    assert not_test.negated.__class__ == Field()

# Generated at 2022-06-22 05:50:00.966575
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[String()], allow_null=True, description="test", title="t")

# Generated at 2022-06-22 05:50:02.543569
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()]) # no error is raised

# Generated at 2022-06-22 05:50:05.924426
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = IfThenElse(if_clause=Field(name="if_clause"), then_clause=Field(name="then_clause"))
    assert if_clause.validate(value={})


# Generated at 2022-06-22 05:50:14.771937
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer, String
    from typesystem import ValidationError

    field = OneOf([Integer(), String()])
    assert field.validate("foo") == "foo"
    assert field.validate(5) == 5
    try:
        field.validate(None)
        assert False, "Did not raise validation error"
    except ValidationError as exc:
        assert exc.code == "no_match"
    try:
        field.validate({"foo": "bar"})
        assert False, "Did not raise validation error"
    except ValidationError as exc:
        assert exc.code == "no_match"


# Generated at 2022-06-22 05:50:24.224834
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    t1 = IfThenElse(Object({'a': String}), else_clause=Object({'b': String}))
    t2 = IfThenElse(Object({'a': String}), Object({'b': String}))
    t3 = IfThenElse(Object({'a': String}))
    t4 = IfThenElse(Object({'a': String}), Object({'b': String}), Object({'c': String}))
    assert t1.then_clause.fields == {}
    assert t1.else_clause.fields == {'b': String}
    assert t2.then_clause.fields == {'b': String}
    assert t2.else_clause.fields == {}
    assert t4.then_clause.fields == {'b': String}
    assert t4.else_clause

# Generated at 2022-06-22 05:50:29.169358
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[])
    assert field.validate(1) == 1
    field = AllOf(all_of=[Any()])
    assert field.validate(1) == 1
    field = AllOf(all_of=[Any(), Any()])
    assert field.validate(1) == 1


# Generated at 2022-06-22 05:50:32.047326
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    assert OneOf(one_of=[String(max_length=2)]).one_of == [String(max_length=2)]


# Generated at 2022-06-22 05:50:33.592988
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-22 05:50:40.551287
# Unit test for constructor of class Not
def test_Not():
  f = Not(
    negated=Any(),
    description="test_Not",
    name="test_Not",
    enum=[],
    meta=[]
  )
  assert(f.negated==Any())
  assert(f.description=="test_Not")
  assert(f.name=="test_Not")
  assert(f.enum==[])
  assert(f.meta==[])


# Generated at 2022-06-22 05:50:44.138043
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer
    f = AllOf([Integer(), Integer()])
    assert(f.validate(42))
    with pytest.raises(Exception):
        f.validate(13)


# Generated at 2022-06-22 05:51:19.451440
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-22 05:51:22.181506
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(Field.validation_error):
        n = NeverMatch()
        n.validate(None)

# Generated at 2022-06-22 05:51:24.483070
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer

    x = OneOf([Integer()])
    print("OneOf test: ", x)



# Generated at 2022-06-22 05:51:26.415099
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("") == NeverMatch.validation_error("never")


# Generated at 2022-06-22 05:51:33.195327
# Unit test for constructor of class OneOf
def test_OneOf():
    f1 = String()
    f2 = Integer()
    field = OneOf(one_of=[f1, f2])
    assert field.one_of == [f1, f2]
    try:
        field = OneOf(one_of=[f1, f2], allow_null=True)
        raise Exception("Expecting an AssertionError when passing allow_null arg")
    except AssertionError:
        pass
    except Exception as e:
        raise e


# Generated at 2022-06-22 05:51:37.213316
# Unit test for constructor of class Not
def test_Not():
    """
    If we pass in a negated field, we should get an error when validating
    """
    test = Not(Integer())
    assert test.validate(0) is not None
    assert test.validate("test") is not None


# Generated at 2022-06-22 05:51:40.906099
# Unit test for constructor of class OneOf
def test_OneOf():
    d = Any()
    d2 = NeverMatch()
    ifThenElse = IfThenElse(d, then_clause=d2)
    d = OneOf([d, d2], then_clause=d2)
    return d





# Generated at 2022-06-22 05:51:44.938195
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    value = "Some Value"
    expected = "Some Value"
    assert test.validate(value) == expected



# Generated at 2022-06-22 05:51:47.617571
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = None
    then_clause = None
    else_clause = None
    if_clause.validate()

# Generated at 2022-06-22 05:51:49.265980
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    actual = NeverMatch().validate()
    assert actual == None
    

# Generated at 2022-06-22 05:52:30.513459
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_field = IfThenElse(if_clause=Field(), then_clause=Field())
    assert isinstance(test_field, Field)

# Generated at 2022-06-22 05:52:40.085735
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Compound

    import json

    class Example(Compound):
        first_name = String(max_length=50)
        last_name = String(max_length=50)

    class Test(Compound):
        all_of = AllOf([Example(),String(min_length=2)])

    obj = Test({"all_of":{'first_name':'alan','last_name':'turing'}})
    assert obj.is_valid() == True
    assert json.dumps(obj.serialize()) == '{"all_of":{"first_name":"alan","last_name":"turing"}}'

    obj = Test({"all_of":"hi"})
    assert obj.is_valid() == True
    assert json.dumps(obj.serialize()) == '{"all_of":"hi"}'

# Generated at 2022-06-22 05:52:51.170843
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        String(),
        Integer(),
    ])
    #
    value = None
    valid, error = field.validate_or_error(value)
    assert error is not None
    assert not valid
    #
    value = False
    valid, error = field.validate_or_error(value)
    assert error is not None
    assert not valid
    #
    value = 1
    valid, error = field.validate_or_error(value)
    assert error is None
    assert valid == 1
    #
    value = "abc"
    valid, error = field.validate_or_error(value)
    assert error is None
    assert valid == "abc"


# Generated at 2022-06-22 05:53:02.299857
# Unit test for constructor of class Not
def test_Not():
    from unittest import TestCase
    from typesystem import Integer
    from .test_fields_register import PositiveInteger
    class test_Not(TestCase):
        def test_init(self):
            negated = Integer(min_value=0)
            not_negated = Not(negated)
            self.assertEqual(not_negated.negated, negated)

    # Unit test for method of class Not
    class test_Not_validate(TestCase):
        def test_validate(self):
            not_positive_integer = Not(PositiveInteger())
            positive_error, positive_value = not_positive_integer.validate_or_error(1)
            self.assertIsNone(positive_error)
            self.assertEqual(positive_value, 1)


# Generated at 2022-06-22 05:53:06.634964
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import SimpleType

    b = AllOf([String(), String()])

    # Check members were set correctly
    assert b.all_of[0] == String()
    assert b.all_of[1] == String()

    class TestType(SimpleType):
        field = AllOf([String(), String()])


# Generated at 2022-06-22 05:53:12.701964
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[String(), Number()])
    assert field.validate("10") == "10"
    with pytest.raises(ValidationError):
        field.validate(None)
    with pytest.raises(ValidationError):
        field.validate(10.0)
    with pytest.raises(ValidationError):
        field.validate("hello")


# Generated at 2022-06-22 05:53:15.444180
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    instance = NeverMatch()
    value = 1
    strict = True
    assert instance.validate(value, strict) == None


# Generated at 2022-06-22 05:53:18.611870
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert 'never' in field.errors
    assert field.errors['never'] == 'This never validates.'


# Generated at 2022-06-22 05:53:19.362041
# Unit test for constructor of class OneOf
def test_OneOf():
    pass



# Generated at 2022-06-22 05:53:22.732564
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    with pytest.raises(AssertionError) as exception:
        IfThenElse(if_clause=Integer(), allow_null=False)
    assert "allow_null" in str(exception)

# Generated at 2022-06-22 05:55:47.084656
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = [1, 2, 3]
    test_IfThenElse = IfThenElse(if_clause=Any())
    assert test_IfThenElse.validate(value) == [1, 2, 3]
    test_IfThenElse = IfThenElse(if_clause=Any(), then_clause=IfThenElse(if_clause=Any()))
    assert test_IfThenElse.validate(value) == [1, 2, 3]
    test_IfThenElse = IfThenElse(if_clause=Any(), else_clause=IfThenElse(if_clause=Any()))
    assert test_IfThenElse.validate(value) == [1, 2, 3]

# Generated at 2022-06-22 05:55:51.010151
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf(all_of=[Any(), Any()])
    x = 'foo'
    result = a.validate(x, strict=False)
    print(result)

# Generated at 2022-06-22 05:55:54.042000
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([])
    try:
        field.validate([])
    except Field.ValidationError:
        pass
    else:
        assert False, "Should have raised a validation error"


# Generated at 2022-06-22 05:55:57.722643
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(AllOf([String(), String()]))
    field.validate(["a", "b"])
    with pytest.raises(ValidationError):
        field.validate(["a", "a"])

