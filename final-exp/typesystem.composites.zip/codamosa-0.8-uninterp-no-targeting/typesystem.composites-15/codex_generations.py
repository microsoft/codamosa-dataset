

# Generated at 2022-06-22 05:46:04.390187
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [1,2,3]
    t = OneOf(fields)
    assert t.one_of == fields
    assert t.errors['no_match'] == 'Did not match any valid type.'
    assert t.errors['multiple_matches'] == 'Matched more than one type.'
    assert t.allow_null == False


# Generated at 2022-06-22 05:46:15.869057
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.base import ValidationError
    from typesystem.primitives import String as s
    from typesystem.primitives import Integer as i
    from typesystem.primitives import Boolean as b
    from typesystem.exceptions import ValidationError

    class Age(IfThenElse):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(
                if_clause=b(True),
                then_clause=s(),
                else_clause=i(),
                **kwargs
            )

    age = Age()
    assert age.validate("26") == "26"
    assert age.validate(26) == 26
    try:
        age.validate(True)
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-22 05:46:17.529955
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([String()])
    assert field.one_of == [String()]

# Generated at 2022-06-22 05:46:29.156262
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class TestField(AllOf):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(all_of, **kwargs)

    class TestField1(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class TestField2(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    test_allOf_field = TestField([TestField1(), TestField2()])
    assert test_allOf_field.validate("hello") == "hello"
    assert test_allOf_field.validate("123") == "123"


# Generated at 2022-06-22 05:46:33.722532
# Unit test for constructor of class Not
def test_Not():
    # Test for case when negated is None
    try:
        n = Not(None)
        n.validate(1)
        assert False
    except Exception as err:
        assert err.message == 'Must not match.'

    # Test for case when negated is not None
    n = Not(Integer())
    n.validate('hi')



# Generated at 2022-06-22 05:46:35.846662
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not("hello")
    assert field.validate("hello") == "hello"


# Generated at 2022-06-22 05:46:44.237001
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([
        Field(
            description = "A test field",
            label = "test",
            name = "test"
        )
    ])
    assert a.errors == {'multiple_matches': 'Matched more than one type.', 'no_match': 'Did not match any valid type.'}
    assert a.one_of == [Field(
        description="A test field",
        label="test",
        name="test"
    )]
    assert a.required == False
    assert a.type_name == "one_of"
    assert a.validators is None


# Generated at 2022-06-22 05:46:46.144679
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert type(field.validate("foo")) == Field.ValidationError

# Generated at 2022-06-22 05:46:47.644856
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf()
    # assert isinstance(field, Field)

# Generated at 2022-06-22 05:46:52.252794
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class Foo(Field):
        def __init__(self, **kwargs):
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
    IfThenElse(Foo(), Foo(), Foo())

# Generated at 2022-06-22 05:46:57.985582
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated='test_negated')

# Generated at 2022-06-22 05:47:03.450575
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    array = AllOf([Integer(), String()])
    try:
        array.validate(1)
    except ValidationError:
        return
    raise AssertionError("AllOf validate did not raise ValidationError")

# Generated at 2022-06-22 05:47:07.319595
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate(10) is None
    try:
        field.validate(10)
    except Exception as excinfo:
        assert str(excinfo) == 'never'


# Generated at 2022-06-22 05:47:15.188528
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class Person:
        def __init__(self,name,age,gender):
            self.name = name
            self.age = age
            self.gender = gender

    class Name(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            name = value.name
            if type(name) != str:
                raise ValidationError('The name is not string.')
            else:
                return value

    class Age(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            age = value.age
            if type(age) != int:
                raise ValidationError('The age is not integer.')
            else:
                return value


# Generated at 2022-06-22 05:47:17.938885
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)
    assert field


# Generated at 2022-06-22 05:47:20.712108
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String())
    with pytest.raises(FieldValidationError):
        not_field.validate(1)

# Generated at 2022-06-22 05:47:22.453971
# Unit test for constructor of class AllOf
def test_AllOf():
    # TBD
    return True


# Generated at 2022-06-22 05:47:34.546193
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
	def test_validate(self):
		assert if_clause.validate(1, strict=False)==1
		assert else_clause.validate(1, strict=False) == 1
		assert else_clause.validate(2, strict=False) == 2
		assert elif_clause.validate(2, strict=False) == 2
		assert if_clause.validate(3, strict=False) == 3
		assert then_clause.validate(3, strict=False) == 3
		assert if_clause.validate(4, strict=False) == 4
		assert then_clause.validate(4, strict=False) == 4
		assert elif_clause.validate(5, strict=False) == 5
		assert else_clause

# Generated at 2022-06-22 05:47:41.918703
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from . import String

    x = IfThenElse(String)
    assert x.if_clause == String
    assert x.then_clause == Any()
    assert x.else_clause == Any()

    x = IfThenElse(String, then_clause=String("a"))
    assert x.if_clause == String
    assert x.then_clause == String("a")
    assert x.else_clause == Any()

    x = IfThenElse(String, String("a"), String("b"))
    assert x.if_clause == String
    assert x.then_clause == String("a")
    assert x.else_clause == String("b")

# Generated at 2022-06-22 05:47:47.414402
# Unit test for constructor of class Not
def test_Not():
    import unittest
    import datetime
    from typesystem.fields import String

    class NotTests(unittest.TestCase):
        def test_init(self):
            not_ = Not(String(min_length=5))
            assert not_.negated is not None

    unittest.main()

# Generated at 2022-06-22 05:47:53.331744
# Unit test for constructor of class Not
def test_Not():
    N = Not(Negated = String())
    assert N.negated == String()
    assert N.errors == {"negated": "Must not match."}


# Generated at 2022-06-22 05:47:59.771059
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(str)
    assert ite
    assert ite.if_clause is str
    assert ite.then_clause is not None
    assert ite.then_clause is Any
    assert ite.else_clause is not None
    assert ite.else_clause is Any
    ite = IfThenElse(str,then_clause=int)
    assert ite.then_clause is int
    ite = IfThenElse(str,else_clause=int)
    assert ite.else_clause is int

# Unit test to validate if_clause

# Generated at 2022-06-22 05:48:02.104883
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        a = NeverMatch(allow_null=True)


# Generated at 2022-06-22 05:48:04.852806
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.__class__.__name__ == 'NeverMatch'


# Generated at 2022-06-22 05:48:07.094928
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    test = field.validate(1)
    expected = "This never validates."
    assert test == expected


# Generated at 2022-06-22 05:48:10.358398
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    """

    """
    try:
        NeverMatch().validate(0)
    except NotImplementedError:
        pass
    else:
        assert False


# Generated at 2022-06-22 05:48:12.007879
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(AllOf(["a", "b"]), AllOf(["a", "b"])).if_clause.all_of == ["a", "b"]


# Generated at 2022-06-22 05:48:13.876018
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([String()]).all_of == [String()]

# Generated at 2022-06-22 05:48:19.266983
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with no matching items
    t = OneOf([Integer, String])
    assert t.validate_or_error('none')[1]
    # Test with one matching item
    assert t.validate_or_error(10)[0]
    # Test with multiple matching items
    assert t.validate_or_error('value')[1]


# Generated at 2022-06-22 05:48:24.969391
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class SomeField(Field):
        def __init__(self):
            super().__init__()

    class OtherField(Field):
        def __init__(self):
            super().__init__()

    assert IfThenElse(if_clause=SomeField())
    assert IfThenElse(if_clause=SomeField(), then_clause=OtherField())
    assert IfThenElse(if_clause=SomeField(), else_clause=OtherField())
    assert IfThenElse(if_clause=SomeField(), then_clause=OtherField(), else_clause=OtherField())

# Generated at 2022-06-22 05:48:30.742055
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(1, True) == 1


# Generated at 2022-06-22 05:48:40.556763
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import datetime
    from typesystem.fields import String, DateTime
    from typesystem.exceptions import ValidationError
    import pytest

    class AllOfTest(AllOf):
        def __init__(self, all_of: typing.List[Field]) -> None:
            super().__init__(all_of = all_of)

    tester = AllOfTest(all_of = [String(min_length=1, max_length=2), DateTime(format = '%Y-%m-%dT%H:%M:%S%z')])
    with pytest.raises(ValidationError) as error:
        tester.validate(value=11)
    assert error.value.detail == "Value was not of type 'string'"

# Generated at 2022-06-22 05:48:43.282318
# Unit test for constructor of class OneOf
def test_OneOf():
    assert "allow_null" not in {"allow_null": "asd"}



# Generated at 2022-06-22 05:48:45.779854
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert_hasattr(IfThenElse(Any()), 'if_clause')
    assert_hasattr(IfThenElse(Any()), 'then_clause')
    assert_hasattr(IfThenElse(Any()), 'else_clause')

# Generated at 2022-06-22 05:48:53.680919
# Unit test for constructor of class OneOf
def test_OneOf():
	one_of = OneOf(
		[
			Field(),
			Any()
		],
		nullable=True,
		name="myOneOf",
		description="A oneOf implementation"
	)

	# Should pass because it matches the first condition
	one_of.validate("a string", strict=True)

	# Should pass because it matches the second condition
	one_of.validate(42)

	# Should fail because it doesn't match any conditions
	with pytest.raises(ValidationError):
		one_of.validate(None)


# Generated at 2022-06-22 05:48:59.486504
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([types.Integer, types.Number])
    try:
        f.validate(42)
    except:
        assert False
    try:
        f.validate(3.1)
    except:
        assert False
    try:
        f.validate("abc")
        assert False
    except:
        assert True



# Generated at 2022-06-22 05:49:01.255185
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert True


# Generated at 2022-06-22 05:49:06.212554
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # arrange
    new = NeverMatch()
    # act
    try:
        result = new.validate(3)
    except Exception as ex:
        # assert
        assert ex.detail['loc'] == ['']
        assert ex.detail['msg'] == "This never validates."
        assert ex.detail['type'] == "never"


# Generated at 2022-06-22 05:49:15.573857
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    o = OneOf([Integer])
    assert (o.validate(42) == 42)
    assert raises(o.validation_error, lambda: o.validate("42"))
    assert raises(o.validation_error, lambda: o.validate(True))

    o = OneOf([String, Integer])
    assert (o.validate(42) == 42)
    assert (o.validate("42") == "42")
    assert raises(o.validation_error, lambda: o.validate(True))
    o = OneOf([String, Integer, Boolean])
    assert (o.validate(42) == 42)
    assert (o.validate("42") == "42")
    assert (o.validate(True) == True)
    assert (o.validate(False) == False)


# Unit

# Generated at 2022-06-22 05:49:17.509634
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    

# Generated at 2022-06-22 05:49:21.679691
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass

# Generated at 2022-06-22 05:49:24.253272
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem
    class A(typesystem.Schema):
        b = Not(typesystem.Integer())
    assert A({"b": 1}) is not None


# Generated at 2022-06-22 05:49:27.364718
# Unit test for method validate of class Not
def test_Not_validate():
    err_msg = 'Must not match.'
    actual = Not(String()).validate(10)
    expected = 10
    assert actual == expected, 'Expected different validation result'


# Generated at 2022-06-22 05:49:28.493931
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-22 05:49:28.958734
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-22 05:49:33.201509
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String

    schema = AllOf([String(), String()])
    assert schema.validate("test") == "test"
    assert schema.errors == {}



# Generated at 2022-06-22 05:49:44.168343
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    T = typing.TypeVar('T')
    # valid
    if_clause = String()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate('foo') == 'foo'
    # valid
    if_clause = NeverMatch()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate('foo') == 'foo'
    # invalid
    if_clause = String()
    then_clause = String()
    else_clause = Integer()
    if_then

# Generated at 2022-06-22 05:49:46.389790
# Unit test for constructor of class Not
def test_Not():
    from typesystem.integer import Integer

    integer = Integer()
    not_integer = Not(integer, description="Not an integer")
    assert not_integer.description == "Not an integer"

# Generated at 2022-06-22 05:49:49.741114
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Int()
    then_clause = String()
    else_clause = String()
    assert isinstance(if_clause, Field)
    assert isinstance(then_clause, Field)
    assert isinstance(else_clause, Field)


# Generated at 2022-06-22 05:49:51.153052
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    t = NeverMatch(name="Test NeverMatch")


# Generated at 2022-06-22 05:50:01.978590
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [int, float]
    one_of = OneOf(fields)
    assert one_of.one_of == fields

# Generated at 2022-06-22 05:50:03.811800
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    schema = AllOf([Int(), Int()])
    schema.validate(1)


# Generated at 2022-06-22 05:50:09.782109
# Unit test for constructor of class Not
def test_Not():
    not_object = Not(negated=AllOf([Any(), Any(), AllOf([Any(), Any()])]))
    # yes, it is a little weird to set 'validate' to a string, but we're
    # only testing the construction
    assert not_object.errors == {'validate': 'Must not match.'}
    assert not_object.negated.all_of == [Any(), Any(), AllOf([Any(), Any()])]


# Generated at 2022-06-22 05:50:11.771726
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    assert f.validate("global_x") == None


# Generated at 2022-06-22 05:50:13.535112
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[])
    assert one_of



# Generated at 2022-06-22 05:50:14.813847
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of = ["all_of"])



# Generated at 2022-06-22 05:50:24.275230
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause
    if_then_else = IfThenElse(if_clause, then_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert type(if_then_else.else_clause) == Any

# Generated at 2022-06-22 05:50:36.178694
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String

    #  test cases:
    #   :return:
    #   "fields": [
    #     {
    #       "fields": [
    #         {
    #           "name": "name",
    #           "type": "string"
    #         },
    #         {
    #           "name": "age",
    #           "type": "integer"
    #         }
    #       ],
    #       "type": "object"
    #     }
    #   ],
    #   "name": "Person",
    #   "type": "object"
    # }

    fields = AllOf([String(max_length=10),String(min_length=5)])
    try:
        fields.validate('')
    except Exception as e:
        print

# Generated at 2022-06-22 05:50:38.097126
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n.errors == {"never": "This never validates."}



# Generated at 2022-06-22 05:50:41.469423
# Unit test for constructor of class Not
def test_Not():
    string_not_null = Not(String(allow_null=False))
    assert string_not_null.negated.allow_null == False

    string_null = Not(String)
    assert string_null.negated.allow_null == True

# Generated at 2022-06-22 05:50:58.496430
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        AllOf([])
    except TypeError:
        assert(False)


# Generated at 2022-06-22 05:51:09.789955
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    if_then_else = IfThenElse(if_clause,then_clause,else_clause)

    # Testing 'no matches'
    assert if_then_else.validate(1)

    # Testing 'multiple matches'
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    if_then_else = IfThenElse(if_clause,then_clause,else_clause)
    try:
        if_then_else.validate(1)
    except:
        pass

    # Testing 'match'
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_cl

# Generated at 2022-06-22 05:51:11.510952
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf is not None


# Generated at 2022-06-22 05:51:13.366941
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Field())
    assert type(not_field) == Not
    assert not_field.negated == Field()


# Generated at 2022-06-22 05:51:20.539966
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.errors import ValidationError
    field = IfThenElse(Integer(0, max_value=5), Integer(min_value=0, max_value=10))
    assert field.validate(4) == 4
    with pytest.raises(ValidationError):
        field.validate(6)
    with pytest.raises(ValidationError):
        field.validate(-1)

# Generated at 2022-06-22 05:51:21.132746
# Unit test for constructor of class Not
def test_Not():
    assert(True)

# Generated at 2022-06-22 05:51:22.956694
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf([Field(),Field()])
    all_of.validate("{1,2}")

# Generated at 2022-06-22 05:51:30.295558
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    one_of1 = OneOf([String()])
    value = "test string"
    assert one_of1.validate(value) == value

    one_of2 = OneOf([String(), String()])
    value = "test string"
    assert one_of2.validate(value) == value

    one_of3 = OneOf([String(), String(), String()])
    value = "test string"
    assert one_of3.validate(value) == value


# test OneOf when no valid type

# Generated at 2022-06-22 05:51:35.493925
# Unit test for constructor of class Not
def test_Not():
    # set up test case
    field = Field()
    negated = Field()

    # call constructor
    test_Not = Not(negated)

    # assert test case
    assert negated is test_Not.negated
    assert field is test_Not.negated.parent
    assert field.parent is test_Not
    assert test_Not.errors == {"negated": "Must not match."}

# Generated at 2022-06-22 05:51:38.621596
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String, Integer
    all_of = AllOf([String, Integer])
    actual = all_of.validate('1')
    print(actual)


# Generated at 2022-06-22 05:51:58.408871
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a_field=IfThenElse(Int(minimum=4,maximum=10),Int(minimum=0),Int(minimum=-1))
    result1,result2,result3=None,None,None
    try:
        result1=a_field.validate(0)
    except Exception as error:
        print('Not Passed 1')
        print(error)
    try:
        result2=a_field.validate(5)
    except Exception as error:
        print('Not Passed 2')
        print(error)
    try:
        result3=a_field.validate(11)
    except Exception as error:
        print('Not Passed 3')
        print(error)
    if result1 == -1 and result2 == 5 and result3 == -1:
        print('Passed')

# Generated at 2022-06-22 05:52:00.254773
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Any())
    assert not_field.negated == Any()



# Generated at 2022-06-22 05:52:02.732981
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  test_field1 = NeverMatch()
  assert test_field1.errors == {"never": "This never validates."}
  # Unit test for constructor of class OneOf

# Generated at 2022-06-22 05:52:05.185455
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String, Integer

    field = OneOf([String(), Integer()])
    assert field.one_of == [String(), Integer()]
    assert field.name == 'one_of'
    assert field.description == ''
    assert field.error_messages == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}



# Generated at 2022-06-22 05:52:09.546820
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(IfThenElse(AllOf([Int()]), then_clause=Int()), else_clause=Int()).validate([2]) == [2]
    assert IfThenElse(IfThenElse(AllOf([Int()]), then_clause=Int()), else_clause=Int()).validate(3) == 3

# Generated at 2022-06-22 05:52:17.251937
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict = {"c": 'a'}
    c1 = String(name='c')
    c2 = String(name='c')
    #c3 = NeverMatch(name='c')
    c3 = NeverMatch(name='c')
    one_of = OneOf([c1,c2,c3])
    try:
        one_of.validate(dict['c'])
    except Exception as e:
        print(e)
        print(e.detail)


# Generated at 2022-06-22 05:52:20.478826
# Unit test for constructor of class OneOf
def test_OneOf():
	# Create an object of class OneOf
	obj_OneOf = OneOf([])
	# Test the name of the class
	assert(obj_OneOf.__class__.__name__ == "OneOf")


# Generated at 2022-06-22 05:52:26.681443
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate(None) == None
    assert field.validate(1) == None
    assert field.validate(object()) == None
    assert field.validate(None, strict=True) == None
    assert field.validate(1, strict=True) == None
    assert field.validate(object(), strict=True) == None


# Generated at 2022-06-22 05:52:27.250513
# Unit test for method validate of class Not
def test_Not_validate():
	assert true

# Generated at 2022-06-22 05:52:30.464753
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    try:
        n.validate('test')
    except Exception as e:
        assert e.args[0] == "This never validates."


# Generated at 2022-06-22 05:53:27.514785
# Unit test for constructor of class Not
def test_Not():
    neg = Not(Int)
    assert neg.negated == Int


# Generated at 2022-06-22 05:53:34.718246
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None
    then_clause = None
    else_clause = None
    assert IfThenElse(if_clause, then_clause, else_clause).if_clause == Any()
    assert IfThenElse(if_clause, then_clause, else_clause).then_clause == Any()
    assert IfThenElse(if_clause, then_clause, else_clause).else_clause == Any()



# Generated at 2022-06-22 05:53:42.153735
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    one = 1
    zero = 0
    field1 = IfThenElse(if_clause=one, then_clause=zero)
    # We expect error since both if_clause and then_clause are primitive types
    # therefore they don't have the method validate()
    # This is not a test failure but rather a protcetion
    error = field1.validate(value=zero)

    assert error.code == 'invalid_type'



# Generated at 2022-06-22 05:53:43.557682
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch(name='field')
    obj.validate(None)

# Generated at 2022-06-22 05:53:47.349446
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # set parameters
    kwargs = {}
    # instantiate object
    obj1 = NeverMatch(**kwargs)
    # assertions
    assert obj1

# Generated at 2022-06-22 05:53:48.572363
# Unit test for constructor of class Not
def test_Not():
    assert Not.__init__ != None


# Generated at 2022-06-22 05:53:51.096470
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    try:
        nm.validate(1)
    except Exception as e:
        assert str(e) == "This never validates."

# Generated at 2022-06-22 05:54:01.616413
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem
    from typesystem import fields
    class Query(typesystem.Schema):
        hello = fields.String(max_length=10)
        world = fields.String(max_length=10)

    class Hello(typesystem.Schema):
        name = fields.String(max_length=10)
        age = fields.Integer(minimum=0, maximum=99)

    class Person(typesystem.Schema):
        name = fields.String(max_length=10)
        age = fields.Integer(minimum=0, maximum=99)
        
    class Post(typesystem.Schema):
        title = fields.String(max_length=10)
        subtitle = fields.String(max_length=10)


# Generated at 2022-06-22 05:54:03.767498
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    t = IfThenElse(if_clause=typesystem.Boolean(), then_clause=typesystem.Boolean())
    t.validate(True)

# Generated at 2022-06-22 05:54:04.359734
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-22 05:55:21.920916
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String
    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("hello") == "hello"
    try:
        field.validate(None)
        assert False, "Should throw"
    except Exception as err:
        assert err.args[0] == "Did not match any valid type."
    try:
        field.validate(1.2)
        assert False, "Should throw"
    except Exception as err:
        assert err.args[0] == "Matched more than one type."


# Generated at 2022-06-22 05:55:27.490671
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_ = IfThenElse(Any)
    value, error = field_.validate_or_error(0)
    assert error is None
    assert value == 0

    field_ = IfThenElse(Field(const=0), then_clause=Field(const=1))
    value, error = field_.validate_or_error('something else')
    assert error is None
    assert value == 1

# Generated at 2022-06-22 05:55:36.912686
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True)
    assert NeverMatch().validate(True) == True
    assert NeverMatch().validate(False) == False
    assert NeverMatch().validate(None) == None
    assert NeverMatch().validate([]) == []
    assert NeverMatch().validate(()) == ()
    assert NeverMatch().validate({}) == {}
    assert NeverMatch().validate("") == ""
    assert NeverMatch().validate("test") == "test"
    assert NeverMatch().validate(0) == 0
    assert NeverMatch().validate(1) == 1
    assert NeverMatch().validate(12.34) == 12.34
    assert NeverMatch().validate(1.0e100) == 1.0e100

# Generated at 2022-06-22 05:55:38.933221
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    my_NeverMatch = NeverMatch()
    assert my_NeverMatch


# Generated at 2022-06-22 05:55:42.305126
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print("Test OneOf_validate")
    field = OneOf(strict=True, one_of=[Integer(minimum=5, maximum=10)])
    field.validate(6)


# Generated at 2022-06-22 05:55:45.458040
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass


# Generated at 2022-06-22 05:55:46.741985
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match is not None


# Generated at 2022-06-22 05:55:49.879530
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of: Field = OneOf()
    assert type(one_of) is OneOf
    

# Generated at 2022-06-22 05:55:51.543609
# Unit test for method validate of class Not
def test_Not_validate():
    # Instanciate class Not
    not_field = Not(Any())
    assert not_field.validate(0) == 0

# Generated at 2022-06-22 05:55:52.686816
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert 0