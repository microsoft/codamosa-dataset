

# Generated at 2022-06-22 05:46:04.211484
# Unit test for constructor of class AllOf
def test_AllOf():
    def test_one():
        S = typesystem.Schema([{"all_of": [{"type": "integer"}]}])
        S.validate([1])
        try:
            S.validate([1, 2])
            return False
        except:
            return True

    if (test_one()):
        print('Test Success!')
    else:
        print('Test Failure!')

# Generated at 2022-06-22 05:46:09.489257
# Unit test for constructor of class Not
def test_Not():
    # Test a valid input.
    f = Field()
    notf = Not(f)
    assert notf.negated is f
    assert not hasattr(notf, 'field_name')

    # Test an invalid input.
    with pytest.raises(TypeError):
        notf2 = Not()

# Generated at 2022-06-22 05:46:11.423174
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert not IfThenElse(Any(), Any(), None).validate(3)




# Generated at 2022-06-22 05:46:14.634363
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Any(), Any()], description="Hello")

    result = field.validate("Hi", strict=False)
    assert result == "Hi"


# Generated at 2022-06-22 05:46:17.166771
# Unit test for constructor of class OneOf
def test_OneOf():
    truthy = True
    falsy = False
    test_case = [1, 2, 3, 4, 5]
    assert OneOf(test_case)

# Generated at 2022-06-22 05:46:18.677566
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().name == 'NeverMatch'



# Generated at 2022-06-22 05:46:23.392612
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([String(max_length=5), String(max_length=10)])
    with pytest.raises(AssertionError):
        a = OneOf([String(max_length=5), String(max_length=10)], allow_null=True)


# Generated at 2022-06-22 05:46:30.449401
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.types import List, String

    assert AllOf([]).name == "AllOf"
    assert AllOf([List(items=String())]).name == "AllOf"
    assert AllOf([List(items=String())], name="Test").name == "Test"
    assert AllOf([List(items=String())], title="Test").title == "Test"
    assert AllOf([List(items=String())], description="Test").description == "Test"


# Generated at 2022-06-22 05:46:33.427995
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    if_clause = IfThenElse(Field(),Field(),Field())
    value = 1

    # Act
    sut = if_clause.validate(value)

    # Assert
    assert sut == value

# Generated at 2022-06-22 05:46:35.913856
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        _ = OneOf(one_of=[Any(), Any()])
    except Exception:
        assert False
    assert True


# Generated at 2022-06-22 05:46:41.484726
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    

# Generated at 2022-06-22 05:46:51.173860
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test1 = OneOf([])
    assert test1.validate(7) == 7

    test2 = OneOf([Field()])
    assert test2.validate(7) == 7

    test3 = OneOf([Field(max_length=1)])
    assert test3.validate("ab") == "ab"

    test4 = OneOf([Field(), Field(max_length=1)])
    assert test4.validate("ab") == "ab"

    # test5 = OneOf([Field(max_length=1), Field(max_length=2)])
    # assert test5.validate("ab") == "ab"

    with pytest.raises(FieldError) as e:
        OneOf([Field(), Field(max_length=1)]).validate("ab")

# Generated at 2022-06-22 05:46:53.021994
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch()
    assert obj.errors == {'never': 'This never validates.'}


# Generated at 2022-06-22 05:46:58.152258
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(OneOf([String(), String()]))
    # test with unpacking errors
    assert f.validate({"foo": "qux", "bar": 2}) == {"foo": "qux", "bar": 2}
    # test without unpacking errors
    assert f.validate({"foo": "qux", "bar": 2}) == {"foo": "qux", "bar": 2}


# Generated at 2022-06-22 05:47:04.541410
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem import schema
    from typesystem import ref

    class AllOfSchema(schema.Type):
        s = AllOf([String(), ref.SchemaRef("Other", "A")])

    class Other(schema.Type):
        a = String(max_length=10)

    schema = AllOfSchema()
    assert str(schema) == '''\
{"type": "object", "additionalProperties": false, "properties": {"s": {"allOf": [{"type": "string"}, {"$ref": "#/definitions/Other"}]}}}'''

# Generated at 2022-06-22 05:47:06.589129
# Unit test for constructor of class Not
def test_Not():
    not_field = Not("not")
    assert not_field.negated == "not"

# Generated at 2022-06-22 05:47:14.539407
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    parent_relation = [
        {
            "title": "child",
            "type": "object",
            "properties": {
                "id": {"title": "id", "type": "string"},
                "name": {"title": "name", "type": "string"},
            },
            "required": ["id", "name"],
        },
        {
            "title": "child",
            "type": "object",
            "properties": {"id": {"title": "id", "type": "string"}},
            "required": ["id"],
        },
    ]
    field = F(parent_relation)
    param = {
        "id": "123",
        "name": "123",
    }
    expect = None
    assert field.validate(param) == expect
    param = {"id": "123"}
   

# Generated at 2022-06-22 05:47:16.510533
# Unit test for method validate of class Not
def test_Not_validate():
    not_obj = Not(negated=Field())
    assert not_obj.validate(1) == 1
    try:
        not_obj.validate(1, strict=True)
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-22 05:47:24.712962
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import pytest
    from typesystem import Integer

    class A(AllOf):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(all_of=[
                Integer(minimum=0, maximum=100),
                Integer(minimum=100, maximum=200),
            ], **kwargs)

    a = A()

    assert a.validate(100)==100

    #assert a.validate(150) == 100
    with pytest.raises(Exception):
        a.validate(150)

# Generated at 2022-06-22 05:47:35.914586
# Unit test for constructor of class AllOf
def test_AllOf():
    field_1 = String(max_length=1)
    field_2 = String(max_length=3)
    field_3 = String(max_length=5)
    field_4 = String(max_length=7)
    field = AllOf([field_1, field_2, field_3, field_4])
    assert field != None
    field_5 = AllOf([field_1, field_2, field_3, field_4])
    field_6 = AllOf([field_4, field_3, field_2, field_1])
    assert field == field_5
    assert field != field_6
    string_1 = "12345"
    string_2 = "1234567890"

# Generated at 2022-06-22 05:47:46.056824
# Unit test for method validate of class Not
def test_Not_validate():
    if_clause = {"type": "string"}
    then_clause = {"type": "number"}
    else_clause = {"type": "list"}

    field = IfThenElse(if_clause, then_clause, else_clause)
    # True condition
    v, e = field.validate_or_error("test")
    assert field.validate("test") == "test"
    assert field.validate(1) == "test"
    assert field.validate([2,3]) == "test"
    # False condition
    v, e = field.validate_or_error(1)
    assert field.validate("test") == "test"
    assert field.validate(1) == "test"
    assert field.validate([2,3]) == "test"

# Generated at 2022-06-22 05:47:51.289067
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf([Integer(), String()], min_length=2, max_length=10)
    field.validate(10)
    field.validate("10")

    try:
        field.validate(1)
    except:
        pass
    else:
        raise Exception("Did not raise error when no match.")


# Generated at 2022-06-22 05:47:53.771922
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String(), title="Negated")
    try:
        field.validate(123)
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-22 05:47:57.223737
# Unit test for method validate of class Not
def test_Not_validate():
    number_field = NumberField()
    not_field = Not(number_field)
    value = "test_value"
    result = not_field.validate(value)
    assert value == result


# Generated at 2022-06-22 05:48:08.276580
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class testAllOf(AllOf):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(all_of, **kwargs)
        
        def test_validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return super().validate(value, strict)

    # All of the sub-items are valid
    field = testAllOf([
        Field(type="string"),
        Field(type="integer"),
    ])
    value, error = field.test_validate(123, False)
    assert error == None

    # One of the sub-items is invalid
    field = testAllOf([
        Field(type="string"),
        Field(type="integer"),
    ])
    value,

# Generated at 2022-06-22 05:48:10.477441
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(negated=Any())
    not_.validate('Hello')


# Generated at 2022-06-22 05:48:12.296800
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Unit test for method validate of class Not
    """
    not_field = Not(negated=Number())
    assert not_field.validate("string") == "string"



# Generated at 2022-06-22 05:48:15.265692
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    with pytest.raises(AssertionError):
        ite = IfThenElse(1, 2, allow_null=True)

# Unit tests for constructor of class OneOf

# Generated at 2022-06-22 05:48:16.847047
# Unit test for constructor of class OneOf
def test_OneOf():
    test = OneOf([
        String()
    ])
    print(test)


# Generated at 2022-06-22 05:48:18.373222
# Unit test for constructor of class Not
def test_Not():
    assert isinstance(Not(Negated = Field()), Not)


# Generated at 2022-06-22 05:48:23.304905
# Unit test for method validate of class AllOf
def test_AllOf_validate():
	import typesystem
	target = AllOf([typesystem.Boolean, typesystem.Integer])
	target.validate(True)
	target.validate(123, strict=False)


# Generated at 2022-06-22 05:48:24.307537
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()


# Generated at 2022-06-22 05:48:34.052768
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class PhoneNumberField(Field):
        errors = {
            "invalid": "Not a valid phone number."
        }
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if type(value) == str and len(value) == 10 and value.isnumeric():
                return value
            raise self.validation_error("invalid")
    
    class PhoneNumberForm(Form):
        #The AllOf field must validate phone number if the input is a string
        number = AllOf([PhoneNumberField(), Str()])

    form = PhoneNumberForm({"number" : "1234567890"})
    assert form.is_valid() == True


# Generated at 2022-06-22 05:48:36.150820
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem
    assert typesystem.Not(typesystem.String()).validate("abc") == "abc"

# Generated at 2022-06-22 05:48:47.966407
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Any()).validate(1) == 1
    assert IfThenElse(Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(
        Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(NeverMatch()).validate(1) == 1
    assert IfThenElse(NeverMatch(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(
        NeverMatch(), else_clause=NeverMatch()).validate(1) == 1

# Generated at 2022-06-22 05:48:50.862343
# Unit test for method validate of class Not
def test_Not_validate():
    # Given
    value = "1"
    strict = False
    field = Not(negated=Any())
    expected = value
    # When
    actual = field.validate(value=value, strict=strict)
    # Then
    assert actual == expected


# Generated at 2022-06-22 05:48:53.221005
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    test = AllOf(all_of=[Any()])
    assert test.validate(2) == 2



# Generated at 2022-06-22 05:48:55.647309
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().__init__(**{'kwargs': typing.Any}) == None

# Generated at 2022-06-22 05:48:56.474431
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  obj=NeverMatch()

# Generated at 2022-06-22 05:48:58.357985
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(field=String(), description="check if not string", required=False)
    assert field.validate("") == ""


# Generated at 2022-06-22 05:49:10.062998
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import String

    # test the case with exact one type match
    field = OneOf([String(max_length=10), String(min_length=8)])
    field.validate("HelloWorld")

    # test the case with multiple type match
    field = OneOf([String(min_length=3), String(min_length=8)])
    try:
        field.validate("HelloWorld")
    except Exception as e:
        print(e)

    # test the case with no type match
    field = OneOf([String(min_length=10), String(min_length=8)])
    try:
        field.validate("HelloWorld")
    except Exception as e:
        print(e)



# Generated at 2022-06-22 05:49:11.552191
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([])
    assert a


# Generated at 2022-06-22 05:49:14.185379
# Unit test for constructor of class Not
def test_Not():
    try:
        Not(None)
    except TypeError as e:
        assert e.args[0] == "__init__() missing 1 required positional argument: 'negated'"


# Generated at 2022-06-22 05:49:22.907766
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    f = OneOf([String(max_length=5), String(min_length=7)])
    # Test 1
    value = "Test"
    with pytest.raises(ValueError) as e:
        f.validate(value)
    assert e.value.args[0] == "Did not match any valid type."
    assert f.validate(value, strict=True) == "Test"
    # Test 2
    value = "Testing"
    with pytest.raises(ValueError) as e:
        f.validate(value)
    assert e.value.args[0] == "Matched more than one type."
    assert f.validate(value, strict=True) == "Testing"


# Generated at 2022-06-22 05:49:26.841649
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Constructor
    IfThenElse(if_clause=NeverMatch(), then_clause=Any())
    IfThenElse(if_clause=NeverMatch(), then_clause=Any(), else_clause=Any())
    IfThenElse(if_clause=NeverMatch())

# Generated at 2022-06-22 05:49:30.231906
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    print("Constructor")
    try:
        IfThenElse(1, 2, 3)
    except Exception as e:
        print("Constructor Exception:", e)


# Generated at 2022-06-22 05:49:36.944514
# Unit test for constructor of class AllOf
def test_AllOf():
    # pylint: disable=unused-argument
    def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
        assert "allow_null" not in kwargs
        super().__init__(**kwargs)
        self.all_of = all_of

    assert self
    assert all_of
    assert "allow_null"
    assert typing
    assert List
    assert Field
    assert super


# Generated at 2022-06-22 05:49:37.853138
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True

# Generated at 2022-06-22 05:49:41.914961
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f = OneOf([field_a, field_b])
    f.validate(value_a)
    f = OneOf([field_a,field_c])
    f.validate(value_a)

# Generated at 2022-06-22 05:49:52.330883
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.exceptions import ValidationError

    class A(Field):
        errors = {"a_error": "this is a error"}

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise ValidationError("a_error")

    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "bbb"

    class C(Field):
        errors = {"c_error": "this is a error"}

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise ValidationError("c_error")


# Generated at 2022-06-22 05:49:56.920258
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors["never"] == "This never validates."

# Generated at 2022-06-22 05:49:59.822577
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Integer
    from typesystem.fields import String
    a = IfThenElse(String(), Integer(), Integer(min_length=10))
    a.validate(10)
    a.validate('abc')

# Generated at 2022-06-22 05:50:07.470987
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A(IfThenElse):
        pass
    A.validate("Hello")
    A.validate("Hello", strict=True)
    A.validate("Hello","Hello")
    A.validate("Hello","Hello",strict=True)
    A.validate("Hello",then_clause="Hello")
    A.validate("Hello",then_clause="Hello",strict=True)
    A.validate("Hello",else_clause="Hello")
    A.validate("Hello",else_clause="Hello",strict=True)
    A.validate("Hello",then_clause="Hello",else_clause="Hello")
    A.validate("Hello",then_clause="Hello",else_clause="Hello",strict=True)

# Generated at 2022-06-22 05:50:13.949449
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test the method validate of the class IfThenElse

    """
    a = 123
    if_clause = lambda value: value>100
    then_clause = lambda value: value
    else_clause = lambda value: Exception("value must be greater than 100")
    
    value = a if if_clause(a) else else_clause(a)
    then_clause = then_clause(value)
    assert (value == then_clause)



# Generated at 2022-06-22 05:50:18.360526
# Unit test for constructor of class AllOf
def test_AllOf():
    a = Field(name='a', choices={1, 2, 3})
    b = Field(name='b', max_length=2)
    all_of = AllOf([a, b])
    assert all_of.all_of == [a, b]


# Generated at 2022-06-22 05:50:19.072916
# Unit test for constructor of class Not
def test_Not():
    assert Not

# Generated at 2022-06-22 05:50:19.756819
# Unit test for constructor of class Not
def test_Not():
    assert True

# Generated at 2022-06-22 05:50:21.866850
# Unit test for method validate of class Not
def test_Not_validate():
    # Not(negated=None)
    pass


# Generated at 2022-06-22 05:50:32.856248
# Unit test for method validate of class Not

# Generated at 2022-06-22 05:50:33.741066
# Unit test for constructor of class AllOf
def test_AllOf():
    assert isinstance(AllOf, type)

# Generated at 2022-06-22 05:50:41.115478
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = [Integer()]
    assert OneOf(one_of).errors == {
        'multiple_matches': 'Matched more than one type.',
        'no_match': 'Did not match any valid type.'
    }
    # Ensures that the constructor of the super class is called
    assert Field.__init__.called


# Generated at 2022-06-22 05:50:43.124203
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
  from typesystem.fields import String

  IfThenElse(if_clause=String(), then_clause=String(), else_clause=String())



# Generated at 2022-06-22 05:50:51.569843
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    # else_clause = Field()
    x = IfThenElse(if_clause)
    assert x.if_clause == if_clause
    assert x.then_clause == Any()
    assert x.else_clause == Any()
    x = IfThenElse(if_clause, then_clause)
    assert x.if_clause == if_clause
    assert x.then_clause == then_clause
    assert x.else_clause == Any()
    # x = IfThenElse(if_clause, then_clause, else_clause)
    # assert x.if_clause == if_clause
    # assert x.then_clause == then_clause
    # assert x.else_cl

# Generated at 2022-06-22 05:50:54.257409
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Any(), then_clause = None)
    assert field.then_clause._default == None


# Generated at 2022-06-22 05:51:01.228323
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = "a"
    then_clause = "b"
    else_clause = "c"
    regular_kwarg = "d"
    test_instance = IfThenElse(if_clause, then_clause, else_clause, regular_kwarg=regular_kwarg)
    assert test_instance.if_clause == if_clause
    assert test_instance.then_clause == then_clause
    assert test_instance.else_clause == else_clause

# Generated at 2022-06-22 05:51:03.969211
# Unit test for constructor of class AllOf
def test_AllOf():
    print("Testing AllOf constructor")
    field = AllOf(all_of=[])
    assert field.all_of == []
    # Test that expected exception is thrown
    with pytest.raises(AssertionError):
        field = AllOf(all_of=[], allow_null=True)


# Generated at 2022-06-22 05:51:05.066753
# Unit test for constructor of class OneOf
def test_OneOf():
    my_field = OneOf([String(max_length=10), Integer()])
    assert isinstance(my_field, OneOf)

# Generated at 2022-06-22 05:51:06.838088
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    print(field.validate(value=None))

# Generated at 2022-06-22 05:51:07.926192
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf == OneOf


# Generated at 2022-06-22 05:51:08.948905
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        NeverMatch(
            allow_null=False
        )

# Generated at 2022-06-22 05:51:27.672983
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
        pass
    class C(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise "1"
        pass
    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
        pass
    a=A()
    b=B()
    c=C()
    l=[a,b]
    l_false=[a,c]
    all_of=AllOf(l)
    all_of.validate(3)
    all_of_false=AllOf(l_false)

# Generated at 2022-06-22 05:51:29.190645
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate("foo") == "foo"

# Generated at 2022-06-22 05:51:30.653091
# Unit test for constructor of class Not
def test_Not():
	test = Not(negated=Field())
	assert test.negated == Field()

# Generated at 2022-06-22 05:51:32.031617
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([String(), Integer(), Boolean()])


# Generated at 2022-06-22 05:51:34.190943
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    x = NeverMatch()
    assert x.validate(3) == "This never validates."

# Generated at 2022-06-22 05:51:36.358782
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(None, None, None).__dict__ == {'else_clause': Any(), 'then_clause': Any()}

# Generated at 2022-06-22 05:51:39.382629
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Integer(minimum=3), String(), String()).validate(2) == 3
    assert IfThenElse(Integer(maximum=1), String(), String()).validate(2) == 2


# Generated at 2022-06-22 05:51:45.391293
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer
    field_a = Integer()
    field_b = Not(field_a)
    assert field_b.validate("abc") is "abc"
    try:
        field_b.validate(123)
    except ValidationError as e:
        assert str(e) == 'Must not match.'



# Generated at 2022-06-22 05:51:47.109219
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n is not None


# Generated at 2022-06-22 05:51:55.643386
# Unit test for constructor of class IfThenElse
def test_IfThenElse():

    assert IfThenElse(1, then_clause=2, else_clause=3).if_clause == 1
    assert IfThenElse(1, then_clause=2, else_clause=3).then_clause == 2
    assert IfThenElse(1, then_clause=2, else_clause=3).else_clause == 3
    assert IfThenElse(1, then_clause=2, else_clause=None).else_clause == Any()
    assert IfThenElse(1, then_clause=None, else_clause=2).then_clause == Any()

# Generated at 2022-06-22 05:52:14.597443
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field=IfThenElse(if_clause=Field(name='test_if_clause'), then_clause=Field(name='test_then_clause'), else_clause=Field(name='test_else_clause'))
    value=0
    assert field.validate(value)==value

# Generated at 2022-06-22 05:52:17.995951
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate("test") == "test"

# Generated at 2022-06-22 05:52:25.948844
# Unit test for method validate of class Not
def test_Not_validate():
    x = {
    "type": "object",
    "properties": {
        "value1": {"type": "number"}
    },
    "not": {
        "type": "number"
    }
}

    y = {
    "type": "object",
    "properties": {
        "value1": {"type": "string"}
    },
    "not": {
        "type": "number"
    }
}
    from typesystem import Schema, fields

    class XSchema(Schema):
        value1 = fields.Integer()

    z = XSchema(strict=True)
    z.validate(y)

# Generated at 2022-06-22 05:52:28.838008
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    n.validate(None)
    with pytest.raises(AssertionError):
        n.validate(None, strict=False)

# Generated at 2022-06-22 05:52:39.008926
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String
    from typesystem.utils import get_object_info
    class OddDecode(Field):
        def validate(self, value: typing.Any, strict: bool = False):
            required = value % 2
            # print(f'required {required}')
            if required == 1:
                return value / 2
            raise self.validation_error(f'required {required}')
    class MinMaxDecode(Field):
        def __init__(self,min,max,**kwargs):
            self.min = min
            self.max = max
            super().__init__(**kwargs)

# Generated at 2022-06-22 05:52:44.032719
# Unit test for constructor of class OneOf
def test_OneOf():
    # define args
    one_of = [Field(), Field()]
    kwargs = {'description': 'abc'}

    # create class object
    field = OneOf(one_of, **kwargs)

    # test for type
    assert isinstance(field, OneOf)



# Generated at 2022-06-22 05:52:48.421597
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Test validating with Not
    """
    from typesystem import Schema, fields

    class NotField(Schema):
        """
        Test conditional subitem matching
        """

        field = fields.Not(fields.Integer(min_value=0))

    assert NotField({"field": 1}).is_valid()
    assert not NotField({"field": -1}).is_valid()

# Generated at 2022-06-22 05:52:49.791519
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()])


# Generated at 2022-06-22 05:52:50.455856
# Unit test for constructor of class AllOf
def test_AllOf():
    pass

# Generated at 2022-06-22 05:53:00.204648
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # value = {'a': [1, '2', 3]}
    # flag = False
    value = 'abc'
    flag = True
    # try:
    #     AllOf(all_of=[{'type': 'array'}, {'type': 'integer'}]).validate(value)
    # except ValidationError as e:
    #     print(e.message)
    #     flag = True
    try:
        AllOf(all_of=[{'type': 'integer'}, {'type': 'array'}]).validate(value)
    except ValidationError as e:
        print(e.message)
        flag = False
    assert flag


# Generated at 2022-06-22 05:53:55.073979
# Unit test for constructor of class Not
def test_Not():
    test_field = Not(negated = Int())
    assert test_field.negated == Int()
    assert test_field.errors == {"negated": "Must not match."}


# Generated at 2022-06-22 05:54:03.306482
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    This unit test will verify the correct behavior of __init__ method in class IfThenElse:
        1. Verify if_clause.
        2. Verify then_clause.
        3. Verify else_clause.
        4. Verify raise exception if one of the parameters is null.
    """

    # Create the arguments for IfThenElse constructor
    if_clause = Field(name="age")
    then_clause = Field(name="address")
    else_clause = Field(name="name")

    # Verify if_clause
    if_then_else = IfThenElse(if_clause)
    assert if_then_else.if_clause.name == "age"

    # Verify then_clause
    assert if_then_else.then_clause.name == "address"

    # Verify else_cl

# Generated at 2022-06-22 05:54:05.874856
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    definition1 = {'if': {'type': 'string'}, 'then': {'type': 'integer'},
                   'else': {'type': 'number'}}
    IfThenElse(definition1)

# Generated at 2022-06-22 05:54:06.579235
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf()
    assert a is not None


# Generated at 2022-06-22 05:54:13.131542
# Unit test for method validate of class Not
def test_Not_validate():
    print("Test  method validate of class Not")
    json_schema = {
        "type": "object",
        "additionalProperties": False,
        "properties": {
            "name": {
                "type": "string",
                "pattern": "^[a-zA-Z](?:[a-zA-Z0-9-_]*[a-zA-Z0-9])?$",
            },
            "age": {"type": "number"},
        },
    }
    class_ = typesystem.from_json_schema(json_schema)
    # good data
    class_.validate({"name": "abc", "age": 10})
    # bad data - key missing

# Generated at 2022-06-22 05:54:17.466697
# Unit test for method validate of class Not
def test_Not_validate():
    # Create a Not object
    # TODO: Probably not the way to create a Not object.
    not_ = Not(negated=None)
    # Call method validate of class Not
    value = not_.validate(value=None, strict=False)
    # Check value
    assert value == None


# Generated at 2022-06-22 05:54:20.213542
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch(description='does not match')
    assert never_match is not None
    assert never_match is not None
    assert never_match.errors == {"never": "This never validates." }


# Generated at 2022-06-22 05:54:21.255503
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([])
    assert a != None


# Generated at 2022-06-22 05:54:22.172186
# Unit test for constructor of class OneOf
def test_OneOf():
    pass
    # TODO: implement your unit test here


# Generated at 2022-06-22 05:54:28.269901
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
  if_clause = Field()
  then_clause = Field()
  else_clause = Field()
  a = IfThenElse(if_clause, then_clause, else_clause)
  assert a.if_clause == if_clause
  assert a.then_clause == then_clause
  assert a.else_clause == else_clause

  a = IfThenElse(if_clause, then_clause)
  assert a.if_clause == if_clause
  assert a.then_clause == then_clause
  assert a.else_clause == Any()

  a = IfThenElse(if_clause)
  assert a.if_clause == if_clause
  assert a.then_clause == Any()
  assert a.else_clause == Any