

# Generated at 2022-06-22 05:46:05.683885
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer

    all_of = AllOf([
        Integer(minimum=1),
        Integer(maximum=3)
    ])

    assert all_of.validate(1) == 1
    assert all_of.validate(2) == 2
    assert all_of.validate(3) == 3
    try:
        all_of.validate(4)
        assert False
    except:
        pass

# Generated at 2022-06-22 05:46:07.623888
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    f = AllOf([String()])
    assert f is not None


# Generated at 2022-06-22 05:46:13.312516
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem
    class Not(typesystem.String):
        def __init__(self, allow_null=True, **kwargs):
            super().__init__(**kwargs)
        def validate(self, value, strict=False):
            self.validate(value, strict=strict)
    
    mystring = Not()
    mystring.validate("test")


# Generated at 2022-06-22 05:46:16.842093
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, "abcd", 3]) == [1, "abcd", 3]
    assert field.validate({"abc": 3, "xyz": "abcd"}) == {"abc": 3, "xyz": "abcd"}
    assert field.validate({"abc": 3, "xyz": "abcd", "nested": [1, 2]}) == {"abc": 3, "xyz": "abcd", "nested": [1, 2]}



# Generated at 2022-06-22 05:46:19.711537
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    s = AllOf([Integer(), Positive()])
    s.validate(5)
    s.validate(-5)
    s.validate('banana')



# Generated at 2022-06-22 05:46:23.478911
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=Str())
    value, error = n.validate_or_error("a")
    assert error is None
    assert value == "a"
    value, error = n.validate_or_error(1)
    assert error == "Must not match."
    assert value is None

# Generated at 2022-06-22 05:46:28.871422
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(AllOf([AllOf([AllOf([AllOf([Any()])])])]),
    then_clause=AllOf([AllOf([AllOf([AllOf([Any()])])])]),
    else_clause=AllOf([OneOf([AllOf([AllOf([AllOf([Any()])])])])]))

# Generated at 2022-06-22 05:46:32.748399
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    test_field = NeverMatch("test")
    err = None
    try:
        test_field.validate("x")
    except ValueError as exc:
        err = exc
    assert err is not None
    assert str(err) == "Field 'test': This never validates."


# Generated at 2022-06-22 05:46:38.043178
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Setup
    field = String()
    # Exercise
    if_then_else = IfThenElse(field, field)
    # Verify
    assert if_then_else.if_clause == field
    assert if_then_else.then_clause == field
    assert if_then_else.else_clause == Any()

# Generated at 2022-06-22 05:46:43.690190
# Unit test for method validate of class Not
def test_Not_validate():
    my_not = Not(String())
    assert my_not.validate("wow") == "wow"
    try:
        assert my_not.validate(4) == 4
        assert False
    except ValidationError:
        assert True
    try:
        assert my_not.validate(True) == True
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-22 05:46:51.943824
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_value = 2
    oneof = OneOf([typesystem.Boolean, typesystem.Integer])
    o_result = oneof.validate(test_value)
    assert(o_result == test_value)

# Generated at 2022-06-22 05:46:56.024003
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([
        Field(type='integer', minimum=5),
        Field(type='string'),
        Field(type='array', items=[Field(type='integer')]),
    ], label="test_OneOf_validate").validate(1) == 1

# Generated at 2022-06-22 05:46:57.213252
# Unit test for constructor of class Not
def test_Not():
    assert(Not(negated=Any()))


# Generated at 2022-06-22 05:46:59.911333
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import Integer, String

    x = Not(String(max_length=3))
    assert x.validate('4313') == '4313'

    x = Not(Integer())
    assert x.validate('4313') == '4313'


# Generated at 2022-06-22 05:47:01.077310
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert(False == NeverMatch().validate("test"))

# Generated at 2022-06-22 05:47:01.802805
# Unit test for constructor of class OneOf
def test_OneOf():
    pass

# Generated at 2022-06-22 05:47:03.145729
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Not)



# Generated at 2022-06-22 05:47:08.005282
# Unit test for constructor of class Not
def test_Not():
    """
    Unit test for class Not constructor.
    """
    class Int(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            try:
                return int(value)
            except (ValueError, TypeError):
                raise self.validation_error()

    a = Not(Int())

# Generated at 2022-06-22 05:47:12.534888
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    a1 = OneOf([String(max_length=5),])
    a2 = OneOf(one_of=[String(max_length=5),])
    a3 = OneOf([String(max_length=5),], label='test')
    a4 = OneOf(one_of=[String(max_length=5),], label='test')
    

# Generated at 2022-06-22 05:47:13.461753
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(Any())

# Generated at 2022-06-22 05:47:22.317649
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    field = AllOf([String()])
    assert isinstance(field, Type)
    assert isinstance(field, Field)
    assert field.name == "all_of"


# Generated at 2022-06-22 05:47:24.393890
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    f = IfThenElse(1,2,3)
    assert f.if_clause == 1
    assert f.then_clause == 2
    assert f.else_clause == 3

# Generated at 2022-06-22 05:47:31.965019
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.types import String

    class TestFieldAllOf(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
    a = AllOf([TestFieldAllOf()])
    assert isinstance(a, AllOf)
    assert a.all_of[0] == TestFieldAllOf()


# Generated at 2022-06-22 05:47:41.531332
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    new_field = IfThenElse(
        if_clause = "if_clause",
        then_clause = "then_clause",
        else_clause = "else_clause",
        title = "title",
        description = "description",
        name = "name",
    )

    assert new_field.title == "title"
    assert new_field.description == "description"
    assert new_field.name == "name"
    assert new_field.if_clause == "if_clause"
    assert new_field.then_clause == "then_clause"
    assert new_field.else_clause == "else_clause"

# Generated at 2022-06-22 05:47:42.583617
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(default=42).default == 42

# Generated at 2022-06-22 05:47:48.903337
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([], allow_null=True)
    value, error = field.validate_or_error(None)
    assert value is None
    assert error is None
    value, error = field.validate_or_error(1)
    assert error == {"code": "no_match", "message": "Did not match any valid type."}



# Generated at 2022-06-22 05:47:52.032597
# Unit test for constructor of class OneOf
def test_OneOf():
    # if
    class testField(Field):
        pass
    one_of = [testField]
    # when
    result = OneOf(one_of)
    # that
    assert result is not None


# Generated at 2022-06-22 05:47:55.034859
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String

    x = String()
    IfThenElse(x, "abc").validate("abc")


# Generated at 2022-06-22 05:47:57.501177
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Tests the validate method of the class OneOf
    field1 = Field()
    field2 = Field()
    value = 1
    strict = False
    assert OneOf([field1, field2]).validate(value, strict) == value


# Generated at 2022-06-22 05:47:58.869183
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Field("test"), Field("test2")) is not None

# Generated at 2022-06-22 05:48:11.367560
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Structure, String, Number
    from typesystem.exceptions import ValidationError

    class SampleSchema(Structure):
        a = IfThenElse(Number(), String())

    input_errors = [
        dict(x="x value", y="y value", a=2),
        dict(x="x value", y="y value", a="two"),
    ]
    success_case = dict(x="x value", y="y value", a=1)

    for error_case in input_errors:
        print(error_case)
        schema = SampleSchema(error_case)
        try:
            schema.validate()
        except ValidationError as e:
            print(e)
            assert True

    schema = SampleSchema(success_case)
    schema.validate()
    assert True

#

# Generated at 2022-06-22 05:48:15.162382
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(None)  == None



# Generated at 2022-06-22 05:48:19.262892
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    all_of = OneOf([])
    print(all_of.validate(5))
    print(all_of.validate([]))
    print(all_of.validate({}))
    print(all_of.validate("string"))


# Generated at 2022-06-22 05:48:20.092628
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    help(OneOf.validate)

# Generated at 2022-06-22 05:48:22.337392
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print("\n\n\n")
    print(" ------ Test method validate of class OneOf ------ ")
    
    

# Generated at 2022-06-22 05:48:25.936520
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=Any(), then_clause=NeverMatch())
    assert field.if_clause is not None
    assert field.then_clause is not None
    assert field.else_clause is not None


# Generated at 2022-06-22 05:48:32.691422
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Boolean(), Object({}))
    assert field.if_clause == Boolean()
    assert field.then_clause == Object({})
    assert field.else_clause == Any()
    field = IfThenElse(Boolean(), Object({}), Integer())
    assert field.if_clause == Boolean()
    assert field.then_clause == Object({})
    assert field.else_clause == Integer()


# Generated at 2022-06-22 05:48:42.595795
# Unit test for constructor of class AllOf
def test_AllOf():
    import typing
    from typesystem.fields import Field

    testing = AllOf(
        [
            Field(),
            Field()
        ],
        default='A default value',
        description='Testing',
        help_text='Testing help text',
        title='Testing title',
        name='Testing name'
    )

    assert testing.all_of == [
        Field(),
        Field()
    ]
    assert testing.default == 'A default value'
    assert testing.description == 'Testing'
    assert testing.help_text == 'Testing help text'
    assert testing.title == 'Testing title'
    assert testing.name == 'Testing name'
    assert testing.format == 'default'
    assert testing.errors == {}
    assert testing.validators == []
    assert testing.get_default() == 'A default value'
    assert testing

# Generated at 2022-06-22 05:48:43.616578
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	assert (NeverMatch(name='Title'))

# Generated at 2022-06-22 05:48:48.529675
# Unit test for constructor of class AllOf
def test_AllOf():
    a = Field()
    b = Field()
    c = Field()
    d = Field()
    assert a.validate('a') == 'a'
    assert b.validate('b') == 'b'
    assert c.validate('c') == 'c'
    assert d.validate('d') == 'd'


# Generated at 2022-06-22 05:48:58.648475
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf([])
    assert o.one_of == []
    assert o.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}


# Generated at 2022-06-22 05:49:02.214828
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    obj = NeverMatch()
    result = obj.validate(None)
    assert isinstance(result, Exception) == True


# Generated at 2022-06-22 05:49:12.135804
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # test case 1
    ite = IfThenElse(if_clause=Int())
    result = ite.validate(12)

    assert result == 12

    # test case 2
    ite = IfThenElse(if_clause=Int(), then_clause=String())
    result = ite.validate(12)

    assert result == "12"

    # test case 3
    try:
        ite = IfThenElse(if_clause=Int(), then_clause=String(), else_clause=String())
        ite.validate(12)
    except Exception:
        result = 1

    assert result == 1

    # test case 4

# Generated at 2022-06-22 05:49:18.843815
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    print(if_then_else.if_clause)
    print(if_then_else.then_clause)
    print(if_then_else.else_clause)

test_IfThenElse()

# Generated at 2022-06-22 05:49:20.408079
# Unit test for constructor of class AllOf
def test_AllOf():
    aField = AllOf(all_of=[])
    assert aField.all_of == []


# Generated at 2022-06-22 05:49:21.393717
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # TODO
    pass


# Generated at 2022-06-22 05:49:24.400244
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    field = OneOf([], required=False)
    value = None

    # Act
    result = field.validate(value)

    # Assert
    assert result == value

# Generated at 2022-06-22 05:49:28.401323
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse( if_clause = Int(maximum = 5), then_clause = Int(minimum = 0), else_clause = Int(maximum = 10) )
    assert(ite.validate(3) == 3)
    assert(ite.validate(8) == 8)

# Generated at 2022-06-22 05:49:32.370538
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Lazy import of typesystem, but required for correct type annotation
    from typesystem import Schema
    # Lazy import of json, but required for correct type annotation
    import json
    # Lazy import of pytest, but required for correct type annotation
    import pytest
    
    class S(Schema):
        field = NeverMatch()
    with pytest.raises(Exception) as excinfo:
        S({"field": "value"})
    assert json.loads(excinfo.value.args[0]) == {
        "__errors__": [{"field": ["This never validates."]}]
    }


# Generated at 2022-06-22 05:49:35.864324
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.types import String, Integer

    field_1 = OneOf([String(), Integer()])
    value = "value"
    result, _error = field_1.validate_or_error(value)
    assert result == value


# Generated at 2022-06-22 05:49:53.400878
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = IfThenElse(Number(), String())
    assert isinstance(x, IfThenElse)

# Generated at 2022-06-22 05:49:57.749652
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause=Any()
    then_clause=Any()
    else_clause=Any()
    a=IfThenElse(if_clause,then_clause,else_clause,description="")

# Generated at 2022-06-22 05:50:03.165020
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Array, Number, String
    schema = AllOf([Number(), String()])
    assert isinstance(schema.fields[0], Number)
    assert isinstance(schema.fields[1], String)

    schema = AllOf([Array(items=Number()), String()])
    assert isinstance(schema.fields[0].items, Number)
    assert isinstance(schema.fields[1], String)

    

# Generated at 2022-06-22 05:50:03.959346
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([Field()])



# Generated at 2022-06-22 05:50:09.125893
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Boolean, Integer

    field = IfThenElse(Boolean(), then_clause=Integer())
    assert field.validate(True) == 0
    assert field.validate(False) == 0

    field = IfThenElse(Boolean(), Integer(), Boolean())
    assert field.validate(True) == 0
    assert field.validate(False) is True

# Generated at 2022-06-22 05:50:12.625090
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    with pytest.raises(AssertionError):
        n = NeverMatch(allow_null=True)


# Generated at 2022-06-22 05:50:14.602354
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    with pytest.raises(typesystem.ValidationError):
        f.validate(5)


# Generated at 2022-06-22 05:50:18.823166
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Integer()])
    r_0, e_0 = one_of.validate_or_error('This is a unit test string')
    assert r_0 == 'This is a unit test string'
    r_1, e_1 = one_o

# Generated at 2022-06-22 05:50:30.581696
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Field(required=True)])
    assert field.required

    field = OneOf([Field(required=False)])
    assert not field.required

    field = OneOf([Field(required=True), Field(required=False)])
    assert field.required

    field = OneOf([Field(required=False), Field(required=False)])
    assert not field.required

    # field = OneOf([Field(required=False), Field(required=True)])
    # assert field.required

    field = OneOf([Field(required=True), Field(required=True)])
    assert field.required

    field = OneOf([Field(required=False), Field(required=False), Field(required=False)])
    assert not field.required


# Generated at 2022-06-22 05:50:42.049952
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(String(max_length=3), List(items=String()))
    assert ite.validate("") == []
    assert ite.validate("abcd") == ["a", "b", "c"]

    ite = IfThenElse(String(max_length=3), List(items=String()), String())
    assert ite.validate("") == "[]"
    assert ite.validate("abcd") == "ab"

    ite = IfThenElse(String(max_length=3), List(items=String()), None)
    assert ite.validate("") == []
    assert ite.validate("abcd") == "ab"

    ite = IfThenElse(String(max_length=3), None, List(items=String()))
    assert ite.valid

# Generated at 2022-06-22 05:51:22.861228
# Unit test for constructor of class OneOf
def test_OneOf():
    @fields({
        'title': fields.String,
        'year': fields.Integer
    })

    class Movie:
        def __init__(self, title):
            self.title = title
            self.year = year
        
        class MySchema(Schema):
            id = fields.Integer()
            title = fields.String()
            year = fields.Integer()

        movie = Movie("Die Hard", 1988)
        result = MySchema().dump(movie)
        assert result.data == {'title': 'Die Hard', 'year': 1988}
        assert result.errors == {}

    assert 1==1


# Generated at 2022-06-22 05:51:24.659111
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {'never': 'This never validates.'}

# Generated at 2022-06-22 05:51:30.025475
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    f = IfThenElse(if_clause=None)
    assert f.if_clause is None
    assert f.then_clause is not None
    assert f.else_clause is not None


__all__ = [
    "NeverMatch",
    "OneOf",
    "AllOf",
    "Not",
    "IfThenElse",
]

# Generated at 2022-06-22 05:51:33.642787
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(
        then_clause=Integer(), else_clause=Float(), if_clause=Any()).validate(1.1) == 1.1

# Generated at 2022-06-22 05:51:41.299165
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    T1 = typesystem.Integer(minimum=100)
    T2 = typesystem.Integer(maximum=100)
    T3 = typesystem.Integer()
    T = OneOf([T1,T2,T3])
    assert T.validate(100) == 100
    assert T.validate('100') == 100
    assert T.validate(90) == 90
    assert T.validate(110) == 110
    try:
        T.validate(101)
    except typesystem.ValidationError:
        pass
    else:
        assert False
    

# Generated at 2022-06-22 05:51:41.894642
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-22 05:51:45.607204
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.fields import Boolean
    from typesystem.fields import Integer
    field = OneOf([String(), Integer(), Boolean()])
    assert isinstance(field, OneOf)



# Generated at 2022-06-22 05:51:46.198287
# Unit test for constructor of class Not
def test_Not():
    assert True

# Generated at 2022-06-22 05:51:47.204027
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()

# Generated at 2022-06-22 05:51:48.810413
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch, Field)


# Generated at 2022-06-22 05:54:23.085938
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import NeverMatch
    try:
        NeverMatch().validate(1)
        assert False
    except ValidationError as e:
        assert e.error_code == "never"


# Generated at 2022-06-22 05:54:25.112818
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    class N(NeverMatch):
        None
    nm=N()
    try:
        val=nm.validate("dummy",True)
    except:
        val=""
    assert val==""


# Generated at 2022-06-22 05:54:25.943172
# Unit test for constructor of class Not

# Generated at 2022-06-22 05:54:26.927322
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    result = IfThenElse(Number(), String())
    assert result.__class__ == IfThenElse

# Generated at 2022-06-22 05:54:34.210445
# Unit test for method validate of class Not
def test_Not_validate():
    """Tests validate"""
    # Test with not validating field
    if_clause = Field()
    test_field = Not(if_clause)
    _, error = test_field.validate_or_error(2.5)
    assert error is None
    # Test with validating field
    if_clause = Field(max_length=3)
    test_field = Not(if_clause)
    _, error = test_field.validate_or_error("Hello, world!")
    assert error is not None


# Generated at 2022-06-22 05:54:35.992352
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate("", strict=False) == ""


# Generated at 2022-06-22 05:54:39.215806
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate({}) is None

    not_field = Not(object)
    assert not_field.validate({}) is None

# Generated at 2022-06-22 05:54:40.241828
# Unit test for constructor of class AllOf
def test_AllOf():
  AllOf(all_of=[])


# Generated at 2022-06-22 05:54:50.475564
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem import Error

    # Initialization
    not_field = Not(String())
    not_field_null = Not(String(allow_null=True))

    # Getting error message
    assert not_field.get_error_message('negated') == 'Must not match.'

    # Validating
    assert not_field.validate(3) == 3
    try:
        assert not_field.validate('test')
    except Error as e:
        assert e.code == 'negated'
        assert e.message == 'Must not match.'

    # Validating with strict
    try:
        assert not_field.validate(3, strict=True)
    except Error as e:
        assert e.code == 'invalid_type'

# Generated at 2022-06-22 05:54:55.956141
# Unit test for constructor of class AllOf
def test_AllOf():
    import typing
    from typesystem.fields import AllOf, Any, Field, String
    _list = [Any()]
    f = AllOf(_list)
    assert f.all_of == _list
    del _list
    del f