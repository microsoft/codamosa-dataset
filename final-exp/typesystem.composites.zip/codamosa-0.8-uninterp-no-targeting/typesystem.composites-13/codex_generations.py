

# Generated at 2022-06-22 05:46:03.775745
# Unit test for method validate of class Not
def test_Not_validate():
    x = Not(negated=Any())
    assert x.validate(1) == 1

# Generated at 2022-06-22 05:46:08.500434
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test an instance of class OneOf
    test = OneOf(one_of=[])
    assert test.validate("1") is "1"
    assert test.validate("2") is None
    assert test.validate("3") is None


# Generated at 2022-06-22 05:46:19.603666
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # type: () -> None
    """Unit test for method validate of class OneOf."""
    import sys
    import unittest
    import unittest.mock
    from typesystem.fields import String
    from typesystem import ValidationError
    from .test_typesystem_fields import TEST_SCHEMA

    class TestField(Field):
        """A test field designed for black box testing."""

        def validate(self, value, strict=False):
            """Validate a value."""
            if value not in ("one", "two"):
                raise ValidationError(
                    {"key": "value"}, meta={"key1": "value1"}
                )

    class TestOneOf(unittest.TestCase):
        """Test class for OneOf."""


# Generated at 2022-06-22 05:46:21.546491
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match = NeverMatch()
    assert never_match.validate("Hello World") == None

# Generated at 2022-06-22 05:46:24.397479
# Unit test for constructor of class AllOf
def test_AllOf():
    f = AllOf([Any()])
    f.validate(0)
    f.validate(0.0)
    f.validate("")
    f.validate(None)
    f.validate(False)
    f.validate(True)
    f.validate({})
    f.validate([])


# Generated at 2022-06-22 05:46:28.066370
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    myfield = OneOf([types.String,types.Integer])
    assert myfield.validate("Hello World!") == "Hello World!"
    assert myfield.validate(1) == 1
 

# Generated at 2022-06-22 05:46:29.577923
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf(one_of=[Any()]), Field)


# Generated at 2022-06-22 05:46:36.686673
# Unit test for constructor of class AllOf
def test_AllOf():
    import json
    import typesystem
    class Person(typesystem.Schema):
        age = typesystem.Integer(minimum=18, maximum=99)
    class PersonProxy(typesystem.Schema):
        person = AllOf(all_of=[Person()])
    person_proxy = PersonProxy()
    person_proxy.validate({"person": {"age": 18}})
    try:
        person_proxy.validate({"person": {"age": 16}})
    except Exception as e:
        assert e.message == {"person": {"age": ["Must be at least 18."]}}
test_AllOf()

# Generated at 2022-06-22 05:46:39.616445
# Unit test for constructor of class Not
def test_Not():
    error= {"required": "This field is required."}
    not_field=Not(negated=Field(errors=error))
    assert not_field.negated.errors == error

# Generated at 2022-06-22 05:46:43.062179
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=False)
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True)


# Generated at 2022-06-22 05:46:48.707328
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of = [])
    assert field.one_of == []

# Generated at 2022-06-22 05:46:51.413922
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-22 05:46:53.873622
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(None)
    assert field.if_clause is None
    assert field.then_clause is not None
    assert field.else_clause is not None

# Generated at 2022-06-22 05:46:58.002209
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    error = None
    no_error = None
    try:
        field = NeverMatch(name="NeverMatch")
        no_error = field.validate({})
    except Exception as err:
        error = err
    pass
    assert error is not None
    assert no_error is None


# Generated at 2022-06-22 05:47:03.044327
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Text, Integer)
    assert field.if_clause == Text
    assert field.then_clause == Integer
    assert field.else_clause == Any()


# Generated at 2022-06-22 05:47:08.894760
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(
        one_of=[Field()],
        description="oneOf",
        name="oneOf",
    )
    assert one_of.errors['no_match'] == "Did not match any valid type."
    assert one_of.errors['multiple_matches'] == "Matched more than one type."
    assert one_of.description == "oneOf"
    assert one_of.name == "oneOf"


# Generated at 2022-06-22 05:47:12.770411
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test for OneOf
    item_1 = OneOf([])
    item_2 = OneOf([None])
    item_3 = OneOf([{}])
    assert isinstance(item_1, OneOf)
    assert isinstance(item_2, OneOf)
    assert isinstance(item_3, OneOf)


# Generated at 2022-06-22 05:47:14.679209
# Unit test for constructor of class Not
def test_Not():
    def test_Not_init_Null():
        assert_raises(AssertionError, Not, True)


# Generated at 2022-06-22 05:47:17.219757
# Unit test for method validate of class OneOf
def test_OneOf_validate():
	one_of = OneOf([String(max_length=10), Integer()])
	print(one_of.validate("Hello"))
	print(one_of.validate(123))
	# print(one_of.validate(123.45))

if __name__ == '__main__':
	test_OneOf_validate()

# Generated at 2022-06-22 05:47:20.170756
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.data_type == 'string', 'data_type should be string'


# Generated at 2022-06-22 05:47:25.083394
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[Any(), Any()]) is not None


# Generated at 2022-06-22 05:47:26.571937
# Unit test for constructor of class Not
def test_Not():
    # Test for all None
    assert Not(None).negated is None


# Generated at 2022-06-22 05:47:31.094656
# Unit test for constructor of class AllOf
def test_AllOf():
    f = AllOf(
        # x: typing.List[Field]
        x = [1,2]
    )
    assert f.all_of == [1,2]

# Generated at 2022-06-22 05:47:41.753654
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f = IfThenElse( { 'key1': 'value1' }, { 'key2': [{ 'key3': 'value3' }, { 'key4': { 'key5': 'value5' } }] } )
    f.validate({ 'key1': 'value1', 'key2' : [{ 'key3': 'value3' }, { 'key4': { 'key5': 'value5' } }] })
    try:
        f.validate({ 'key1': 'value1', 'key5' : [{ 'key3': 'value3' }, { 'key4': { 'key5': 'value5' } }] })
        assert False
    except BaseException:
        pass

# Generated at 2022-06-22 05:47:44.021003
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x.errors == {"never": "This never validates."}

# Generated at 2022-06-22 05:47:45.670356
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    child = NeverMatch()
    assert child.__class__ == NeverMatch


# Generated at 2022-06-22 05:47:47.973417
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(Field.validation_error):
        NeverMatch().validate(None)


# Generated at 2022-06-22 05:47:49.411004
# Unit test for constructor of class OneOf
def test_OneOf():
    # Create instance of class OneOf
    assert OneOf is not None

# Generated at 2022-06-22 05:47:54.962209
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    #if_clause: Field, then_clause: Field = None, else_clause: Field = None
    if_value = 1
    then_value = 2
    else_value = 3
    my_def = IfThenElse(
        if_clause = if_value,
        then_clause = then_value,
        else_clause = else_value)

    assert my_def.validate == then_value

# Generated at 2022-06-22 05:47:56.406925
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True)


# Generated at 2022-06-22 05:48:01.513922
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match = NeverMatch()
    assert never_match.validate(4) == "This never validates."


# Generated at 2022-06-22 05:48:02.108949
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-22 05:48:03.644429
# Unit test for constructor of class AllOf
def test_AllOf():
    inst = AllOf([])
    assert inst.all_of == []

# Generated at 2022-06-22 05:48:13.977524
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    one_of_validator = OneOf([String(), Integer()], name="OneOf")

    assert one_of_validator.validate("test_string") == "test_string"
    assert one_of_validator.validate(1234) == 1234

    try:
        one_of_validator.validate(False)
    except ValidationError as err:
        assert err.code == "no_match"
        print(err.message)

    try:
        one_of_validator.validate(1234.5)
    except ValidationError as err:
        assert err.code == "no_match"
        print(err.message)



# Generated at 2022-06-22 05:48:24.396283
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test validating using a simple dictionary
    # of fields
    simple_dict = {
        "one_of": [
            "type1", "type2"
        ]
    }
    field = OneOf(
        one_of=simple_dict["one_of"]
    )
    
    # Test matching against a valid value
    matched_value = "type1"
    field_val = field.validate(matched_value)
    assert field_val == matched_value
    
    # Test matching against a non valid value
    non_matched_value = "type"
    with pytest.raises(ValidationError) as exception:
        field_val = field.validate(non_matched_value)
    assert str(exception.value) == 'no_match'

# Generated at 2022-06-22 05:48:35.658911
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with a perfect match
    one_of_field = OneOf([Number(), String()])
    number_input = 1
    string_input = '1'
    output = one_of_field.validate(number_input)
    assert output == number_input
    output = one_of_field.validate(string_input)
    assert output == string_input
    # Test with multiple matches
    output = one_of_field.validate(1.0)
    expected_error = one_of_field.validation_error("multiple_matches")
    assert output == expected_error
    # Test with no match
    output = one_of_field.validate(True)
    expected_error = one_of_field.validation_error("no_match")
    assert output == expected_error

# Unit test

# Generated at 2022-06-22 05:48:39.132205
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    field.validate("foo") == "foo"
    field.validate(123) == 123
    raises(field.validate, ["bar", "baz"])

test_OneOf_validate()

# Generated at 2022-06-22 05:48:41.198875
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.validate(1)

# Generated at 2022-06-22 05:48:43.709237
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(None, None)
    assert IfThenElse(None, None, None)

# Generated at 2022-06-22 05:48:45.245590
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x is not None

# Generated at 2022-06-22 05:48:53.190776
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import unittest
    a = IfThenElse(if_clause=AllOf(value=10), then_clause=AllOf(value=20))
    assert a.validate(10) != 10


# Generated at 2022-06-22 05:48:58.499238
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause=Field(),
        then_clause=Any(),
        else_clause=Any()
    )
    assert field.if_clause is not None
    assert field.then_clause is not None
    assert field.else_clause is not None


# Generated at 2022-06-22 05:49:05.642022
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Any()
    then_clause = Integer(0, 100)
    else_clause = String(max_length=500)
    ifThenElse = IfThenElse(if_clause, then_clause, else_clause)

    assert ifThenElse.if_clause == if_clause
    assert ifThenElse.then_clause == then_clause
    assert ifThenElse.else_clause == else_clause

# Generated at 2022-06-22 05:49:10.176159
# Unit test for method validate of class Not
def test_Not_validate():
    i = Not(Number())
    i.validate(None)
    i.validate(10)
    i.validate(10.5)
    i.validate(True)
    i.validate('test')
    i.validate([1, 2, 3])
    i.validate({'key': 'value'})



# Generated at 2022-06-22 05:49:11.901504
# Unit test for method validate of class Not
def test_Not_validate():
    schema = Not(Integer())
    assert schema.validate(-1) == -1



# Generated at 2022-06-22 05:49:15.601355
# Unit test for constructor of class Not
def test_Not():
    """
    Test the constructor of class Not
    """
    assert Not(negated = integer()).negated is not None
    assert Not(negated = float()).negated is not None


# Generated at 2022-06-22 05:49:19.535874
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # arrange
    if_clause = None
    then_clause = None
    else_clause = None

    # act
    IfThenElse(if_clause, then_clause, else_clause)

    # assert
    assert True # did not throw

# Generated at 2022-06-22 05:49:26.043102
# Unit test for constructor of class OneOf
def test_OneOf():
    class TestOneOf():
        def test_one_of(self):
            one_of = OneOf([])
            _, error = one_of.validate_or_error('a')
            assert error
            assert error['code'] == 'no_match'

            one_of = OneOf([String()])
            _, error = one_of.validate_or_error(1)
            assert error
            assert error['code'] == 'no_match'



# Generated at 2022-06-22 05:49:27.835720
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.typing import String

    typesystem = AllOf([String(), String()])
    assert typesystem.all_of


# Generated at 2022-06-22 05:49:31.441236
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from .string import String
    from .integer import Integer
    from .number import Number
    from .boolean import Boolean
    from .object import Object

    class MyIfThenElse(IfThenElse):
        def __init__(self):
            super().__init__(String(), Number())
    
    assert MyIfThenElse().validate("10") == "10"
    with pytest.raises(ValueError):
        MyIfThenElse().validate(10)



# Generated at 2022-06-22 05:49:45.377461
# Unit test for method validate of class Not
def test_Not_validate():

    # if the value is not valid and can be printed, then the function raises the error.
    field = Not(String("This is a string"))
    try:
        field.validate("Not a string")
    except ValueError as e:
        assert str(e) == "Must not match."

    # if the value is valid, then there is no error
    field = Not(String("This is a string"))
    try:
        field.validate(1)
    except:
        assert True == False

    # if the value is valid, then there is no error
    field = Not(Integer("This is an integer"))
    try:
        field.validate("Not a string")
    except:
        assert True == False


# Generated at 2022-06-22 05:49:50.635449
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    integer_field = typesystem.Integer(minimum=0)
    string_field = typesystem.String()

    if_clause = typesystem.Integer(minimum=5)
    then_clause = typesystem.String()
    else_clause = typesystem.Integer(maximum=10)

    ief = typesystem.IfThenElse(
        if_clause=if_clause, then_clause=then_clause, else_clause=else_clause
    )

    integer_validation_data = [("integer", integer_field)]
    string_validation_data = [("string", string_field)]
    both_validation_data = [("both", ief)]

    validation_data = (
        integer_validation_data + string_validation_data + both_validation_data
    )

   

# Generated at 2022-06-22 05:49:56.856248
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Setup
    if_clause = Integer(maximum=10)
    then_clause = Integer(minimum=10)
    else_clause = Integer(minimum=0)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    # Execute & Verify
    assert if_then_else.validate(9) == 9
    assert if_then_else.validate(10) == 10
    assert if_then_else.validate(11) == 11

# Generated at 2022-06-22 05:49:58.978935
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        nm = NeverMatch(name="test", help="test")
        assert False
    except:
        assert True



# Generated at 2022-06-22 05:50:00.318733
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:50:03.859104
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([Any(), Any()])
    value = ["1"]
    strict = False
    field.validate(value, strict)
    assert True


# Generated at 2022-06-22 05:50:07.783371
# Unit test for constructor of class Not
def test_Not():
    negated = Field()

    assert Not(negated).negated == negated
    assert Not(negated).errors["negated"] == "Must not match."
    assert Not(negated).nullable == False
    assert not Not(negated).has_default()


# Generated at 2022-06-22 05:50:09.734394
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:50:18.337503
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field1 = Integer(minimum=5)
    field2 = String()
    field3 = String(max_length=3)

    field4 = IfThenElse(if_clause=field1, then_clause=field2)
    field5 = IfThenElse(if_clause=field1, then_clause=field2, else_clause=field3)

    # Then clause should be used
    assert field4.validate(10) == 10
    assert field5.validate(10) == 10

    # Else clause should be used
    assert field4.validate(3) == "3"
    assert field5.validate(3) == "3"

# Generated at 2022-06-22 05:50:19.073327
# Unit test for constructor of class AllOf
def test_AllOf():
    pass

# Generated at 2022-06-22 05:50:37.003684
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Unittest for method validate of class IfThenElse when if_clause is matched

    if_clause = Integer()
    i = IfThenElse(if_clause=if_clause)
    assert i.validate(5) == 5


# Generated at 2022-06-22 05:50:38.457331
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(description="foo", title="bar")



# Generated at 2022-06-22 05:50:40.306498
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate("hello") == "hello"

# Generated at 2022-06-22 05:50:46.110321
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause, then_clause, else_clause = Field(), Field(), Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_clause == if_then_else.if_clause
    assert then_clause == if_then_else.then_clause
    assert else_clause == if_then_else.else_clause

# Generated at 2022-06-22 05:50:47.644574
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    field.validate(None)

# Generated at 2022-06-22 05:50:56.852730
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    list_type = List(value_type=Integer())
    schema = IfThenElse(
        if_clause=List(value_type=Integer()),
        then_clause=List(value_type=Integer()),
        else_clause=List(value_type=Integer()),
        optional=True,
        default=[]
    )
    assert(schema.validate([1, 2, 3]) == [1, 2, 3])
    assert(schema.validate([1, 2, "3"]) is None)
    assert(schema.validate(None) == [])

# Generated at 2022-06-22 05:50:58.061775
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(negated=None)
    assert not_ is not None


# Generated at 2022-06-22 05:51:09.421158
# Unit test for constructor of class NeverMatch
def test_NeverMatch():

    # Test type of argument "errors"
    errors = {"never": "This never validates."}
    try:
        NeverMatch(errors=errors)
    except Exception as inst:
        if isinstance(inst, AssertionError):
            print('Assignement of argument "errors" raise a AssertionError')
        elif isinstance(inst, TypeError):
            print('Assignement of argument "errors" raise a TypeError')
        elif isinstance(inst, ValueError):
            print('Assignement of argument "errors" raise a ValueError')
        else:
            print('Assignement of argument "errors" raise a exception')
    else:
        print('Assignement of argument "errors" does not raise')

    # Test type of argument "help_text"

# Generated at 2022-06-22 05:51:09.866350
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass



# Generated at 2022-06-22 05:51:15.493938
# Unit test for constructor of class Not
def test_Not():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    not_clause = Field()
    not_schema = Not(not_clause, if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    assert not_schema.negated == not_clause
    assert not_schema.if_clause == if_clause
    assert not_schema.then_clause == then_clause
    assert not_schema.else_clause == else_clause


# Generated at 2022-06-22 05:52:01.846092
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Given
    if_clause1 = Field(
        name="if_clause1",
        description="Test for then_clause",
        enum=["A"],
        allow_null=True
    )
    then_clause1 = Field(
        name="then_clause1",
        description="Test for then_clause",
        enum=["B"],
        allow_null=True
    )
    else_clause1 = Field(
        name="else_clause1",
        description="Test for else_clause",
        enum=["C"],
        allow_null=True
    )

    # Then
    cond1 = IfThenElse("if_clause1","then_clause1", "else_clause1")


# Generated at 2022-06-22 05:52:14.168933
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # should not error for valid input
    if_clause = IfThenElse(Any(), None, None)
    if_clause.validate(1, strict=False)
    if_clause.validate("string", strict=False)
    if_clause.validate([1, 2, 3], strict=False)
    if_clause.validate(None, strict=False)

    # should error for invalid input
    try:
        if_clause.validate(1, strict=True)
    except Exception:
        pass
    else:
        assert False, "should not have succeeded"

    # should not error for valid input
    if_clause = IfThenElse(Any(), None, None)
    if_clause.validate({}, strict=False)


# Generated at 2022-06-22 05:52:25.876047
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    n = 10
    f1 = Field()
    f2 = Field()
    o1 = OneOf([f1, f2])
    o2 = OneOf([f2])
    o3 = OneOf([f2, Field()])
    for i in range(n):
        for v in [1, 2, 3]:
            if v in [1, 2]:
                result = o1.validate(v, strict=False)
                if v in [2]:
                    assert result == v
                    result = o3.validate(v, strict=False)
                    assert result == v
                else:
                    assert result == 2
            else:
                try:
                    result = o1.validate(v, strict=False)
                except:
                    pass
                else:
                    assert False

# Generated at 2022-06-22 05:52:30.018432
# Unit test for constructor of class OneOf
def test_OneOf():
	field = OneOf([])
	try:
		field.validate("asd")
	except Exception as e:
		assert(str(e) == "Did not match any valid type.")
	else:
		assert(False)
	

# Generated at 2022-06-22 05:52:34.656268
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf([Integer()])
    assert one_of_field.validate(10) == 10
    with pytest.raises(ValidationError) as exc_info:
        one_of_field.validate("abc")
    assert exc_info.value.as_dict() == {"field": "no_match"}



# Generated at 2022-06-22 05:52:36.576241
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {'never': 'This never validates.'}


# Generated at 2022-06-22 05:52:41.594718
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # these two should fail
    try:
        NeverMatch(allow_null=True)
        assert False
    except AssertionError:
        pass
    try:
        NeverMatch()
        assert False
    except AssertionError:
        pass
    # this should pass
    NeverMatch(description="never matches")


# Generated at 2022-06-22 05:52:54.054044
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import json

    # Create an AllOf object with 3 Typesystem field objects
    test_field = AllOf(
        [
            Field(
                type="string",
                min_length=5,
                max_length=20,
                name="string_field",
                description="String field",
            ),
            Field(
                type="integer",
                name="integer_field",
                description="Integer field",
            ),
            Field(
                type="boolean",
                name="boolean_field",
                description="Boolean field",
            ),
        ]
    )

    # Test validation of a value that satisfies all of the AllOf field objects
    assert test_field.validate(True) == True

    # Test validation of a value that satisfies only one of the AllOf field objects

# Generated at 2022-06-22 05:53:00.546838
# Unit test for constructor of class Not
def test_Not():
    # array
    assert Not([1, 2, 3])
    # border value
    assert Not(1)
    assert Not([1])
    assert Not(1.1)
    # value out of range
    assert not Not(-1)
    # value out of range
    assert not Not(None)
    # value not in range
    assert not Not("abc")
    assert not Not("123")
    return


# Generated at 2022-06-22 05:53:06.712050
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a, b = Field(), Field()
    allof = AllOf([a, b])

    a.validate = b.validate = Mock(return_value=True)
    allof.validate(1)

    assert a.validate.called_once_with(1)
    assert b.validate.called_once_with(1)

    # check strict mode
    a.validate = b.validate = Mock(return_value=True)
    allof.validate(1, strict=True)

    assert a.validate.called_once_with(1, strict=True)
    assert b.validate.called_once_with(1, strict=True)

    a.validate = Mock(side_effect=AssertionError)
    with pytest.raises(AssertionError):
        allof

# Generated at 2022-06-22 05:53:35.946530
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class TestField(Field):
        pass

    class TestOneOf(OneOf):

        def __init__(self, **kwargs: typing.Any):
            list_field = [TestField()]
            super().__init__(one_of=list_field, **kwargs)

    # Case 1: valid
    test_one_of = TestOneOf()
    result = test_one_of.validate("test")

    assert(result is not None)

    # Case 2: invalid
    with pytest.raises(Exception):
        test_one_of = TestOneOf()
        test_one_of.validate(None)

    # Case 3: valid
    test_one_of = TestOneOf()
    result = test_one_of.validate("test", strict=True)


# Generated at 2022-06-22 05:53:38.316521
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch(label="None")
    with pytest.raises(Exception):
        field.validate(123)


# Generated at 2022-06-22 05:53:39.124534
# Unit test for constructor of class OneOf
def test_OneOf():
    pass

# Generated at 2022-06-22 05:53:40.206613
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass


# Generated at 2022-06-22 05:53:45.130276
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    # First test, the negated value is not valid
    field.validate(1)

    # Second test, the negated value is valid
    try:
        field.validate("test")
    except Exception as e:
        assert str(e) == "Must not match."

# Generated at 2022-06-22 05:53:48.724594
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([Any()], help_text="A help text")
    assert field.help_text == "A help text"
    assert field.all_of == [Any()]



# Generated at 2022-06-22 05:53:51.737137
# Unit test for constructor of class Not
def test_Not():
    try:
        Not(None)
    except AssertionError:
        return
    raise AssertionError("Test failed: expected AssertionError, but no error occurred")


# Generated at 2022-06-22 05:53:56.525965
# Unit test for constructor of class OneOf
def test_OneOf():
    int_type = Field()
    string_type = Field()
    field = OneOf([int_type, string_type])
    assert field.one_of[0] == int_type
    assert field.one_of[1] == string_type


# Generated at 2022-06-22 05:54:03.305727
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer

    field = OneOf([
        Integer(min_value=4),
        Integer(max_value=2),
    ])

    try:
        field.validate(2)
        print("Negative test did not generate expected validation error")
    except Exception as e:
        print("Negative test generated expected validation error")

    try:
        field.validate(3)
        print("Negative test did not generate expected validation error")
    except Exception as e:
        print("Negative test generated expected validation error")

    try:
        field.validate(4)
    except Exception as e:
        print("Positive test generated unexpected validation error")


# Generated at 2022-06-22 05:54:14.108306
# Unit test for constructor of class OneOf
def test_OneOf():
    class Cat:
        def __init__(self):
            self.name = 'abc'
    class Dog:
        def __init__(self):
            self.name = 'xyz'
    class Cow:
        def __init__(self):
            self.name = 'adf'
    cat = Cat()
    dog = Dog()
    cow = Cow()
    class CatField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value.name.startswith('a'):
                return value
            raise ValueError('Cat')

    one_of = [CatField(), Dog()]
    one_of_field = OneOf(one_of)
    assert one_of_field.validate(cat) == cat

# Generated at 2022-06-22 05:54:56.431550
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass

# Generated at 2022-06-22 05:55:06.276544
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Unit test for method validate of class AllOf
    """
    from typesystem import fields
    from typesystem.schema import Schema
    
    class MySchema(Schema):
        """
        MySchema class
        """
        my_field = fields.AllOf(
            [
                fields.Integer(),
                fields.GT(100)
            ]
        )

    my_object = MySchema({'my_field': 100})
    my_object.validate()
    
    assert my_object.errors == {"my_field": ["gt"]}
    
    my_object = MySchema({'my_field': 101})
    my_object.validate()
    
    assert my_object.errors == {}


# Generated at 2022-06-22 05:55:07.898902
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=1)


# Generated at 2022-06-22 05:55:16.914785
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Array, Number

    all_of = AllOf([Array(items=Number()), Array(min_length=1)])
    all_of.validate([1, 2, 3])

    try:
        all_of.validate([1, 2, 3.2])
    except ValueError:
        pass
    else:
        assert False, "failed"

    try:
        all_of.validate([])
    except ValueError:
        pass
    else:
        assert False, "failed"

    try:
        AllOf([])
    except ValueError:
        pass
    else:
        assert False, "failed"



# Generated at 2022-06-22 05:55:27.531230
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
    ).validate(1) == 1
    assert IfThenElse(
        if_clause=Any(),
        else_clause=Any(),
    ).validate(1) == 1
    try:
        IfThenElse(
            if_clause=NeverMatch(),
            then_clause=Any(),
        ).validate(1) == 1
        raise Exception("Should not happen")
    except Field.ValidationError:
        pass
    try:
        IfThenElse(
            if_clause=NeverMatch(),
            else_clause=Any(),
        ).validate(1) == 1
        raise Exception("Should not happen")
    except Field.ValidationError:
        pass

# Generated at 2022-06-22 05:55:37.216420
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = SimpleIntegerField()
    b = SimpleStringField()
    c = IfThenElse(a, then_clause=b)
    assert c.validate(8) == '8'
    assert c.validate('8') == '8'

    a = SimpleIntegerField()
    b = SimpleStringField()
    c = IfThenElse(a, else_clause=b)
    assert c.validate(8) == 8
    assert c.validate('8') == '8'

    a = SimpleIntegerField()
    b = SimpleStringField()
    d = SimpleIntegerField()
    c = IfThenElse(a, then_clause=b, else_clause=d)
    assert c.validate(8) == '8'
    assert c.validate('8') == 8


# Generated at 2022-06-22 05:55:39.909018
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	assert isinstance(NeverMatch(), Field)
	assert NeverMatch.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:55:43.178348
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.validators import MaxLength
    field = OneOf([String(MaxLength(100))])
    field.validate("hello")


# Generated at 2022-06-22 05:55:49.464144
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typing import List
    from typesystem.fields import String

    field = IfThenElse(
        if_clause=String(max_length=4),
        then_clause=List(String(max_length=3)),
        else_clause=List(String(max_length=5)),
    )
    assert field.validate(["ABC", "ABC", "A"]) == ["ABC", "ABC", "A"]



# Generated at 2022-06-22 05:55:58.890067
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = typesystem.Integer(minimum=0, maximum=10)
    then_clause = typesystem.String(max_length=10)
    else_clause = typesystem.String(min_length=10)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    for value in ["", "X", "ABC", "1234567890"]:
        assert if_then_else.validate(value) == value

    for value in ["12345678901", "1234567890123"]:
        with pytest.raises(typesystem.ValidationError):
            if_then_else.validate(value)