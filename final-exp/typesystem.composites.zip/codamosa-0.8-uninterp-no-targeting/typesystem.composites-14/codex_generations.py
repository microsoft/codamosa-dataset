

# Generated at 2022-06-22 05:45:57.246895
# Unit test for constructor of class Not
def test_Not():
    field = Not(1, name="test_Not")
    assert field.errors == {"negated": "Must not match."}


# Generated at 2022-06-22 05:45:58.934481
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([typesystem.String()])
    field.validate('a')


# Generated at 2022-06-22 05:46:01.157782
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    field = Not(String(), max_length=20, label="hello")
    assert field.max_length == 20
    assert field.label == "hello"

# Generated at 2022-06-22 05:46:04.668075
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([], description='d').description == 'd'
    assert OneOf([str], description='d').description == 'd'
    assert OneOf([str, int], description='d').description == 'd'
    assert OneOf([str, int, float], description='d').description == 'd'

# Generated at 2022-06-22 05:46:06.967039
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field, NeverMatch)


# Generated at 2022-06-22 05:46:13.960598
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Object, String

    class Person(Object):
        id: String(allow_null=True)

    class ObjectWithAllOf(Object):

        allof: AllOf(all_of=[Person, String(max_length=5)])

    test_object = ObjectWithAllOf(allof="Hello")
    test_object.validate()

    test_object = ObjectWithAllOf(allof=Person(id="Hello"))
    test_object.validate()



# Generated at 2022-06-22 05:46:16.909532
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(negated=None)
    assert(not_.negated is None)
    assert(not_.errors == {"negated": "Must not match."})


# Generated at 2022-06-22 05:46:17.945803
# Unit test for constructor of class AllOf
def test_AllOf():
    assert hasattr(AllOf, '__init__')

# Generated at 2022-06-22 05:46:24.032322
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    condition = Integer(min_value=0)
    then_clause = String(max_length=5)
    else_clause = String(max_length=8)
    test_field = IfThenElse(if_clause=condition, then_clause=then_clause, else_clause=else_clause)

    assert test_field.validate(5) == "5"



# Generated at 2022-06-22 05:46:25.544268
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of


# Generated at 2022-06-22 05:46:31.648461
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
  n = NeverMatch()
  try:
     n.validate(42)
  except Exception as e:
     assert type(e) == TypeError


# Generated at 2022-06-22 05:46:33.095007
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([1,2,3])


# Generated at 2022-06-22 05:46:36.504545
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert isinstance(not_field,Not)
    # Test that constructor works when negated field is passed
    assert not_field.negated is not None


# Generated at 2022-06-22 05:46:39.066224
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([])
    try:
        f.validate('test')
    except Exception as ex:
        assert str(ex) == 'test'

# Generated at 2022-06-22 05:46:43.841441
# Unit test for constructor of class Not
def test_Not():
    class Integer(Field):
        def validate(self, value):
            return int(value)

    class Number(Field):
        def validate(self, value):
            return float(value)

    field = Not(Integer())

    field.validate(1.5)
    field.validate('1.5')



# Generated at 2022-06-22 05:46:46.085268
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:46:48.223976
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf()
    if one_of:
        print('pass')
    else:
        print('fail')


# Generated at 2022-06-22 05:46:52.538221
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # tests the constructor of the class NeverMatch
    error_msg = {"never":"This never validates."}
    a = NeverMatch(errors=error_msg)
    assert a.errors == error_msg

test_NeverMatch()


# Generated at 2022-06-22 05:46:53.541210
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch() is not None


# Generated at 2022-06-22 05:46:59.880059
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Type, Integer, Number
    import json

    class AllOfType(Type):
        field = AllOf([Number(), Integer()])

    # success
    data = {'field': 1.1}
    result = AllOfType(data).to_builtin()
    assert result == data

    # fail
    data = {'field': 'hello'}
    with pytest.raises(Exception) as e_info:
        result = AllOfType(data)
    assert str(e_info.value) == 'Expected type float at fields.'


# Generated at 2022-06-22 05:47:07.559081
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = IfThenElse(Field(type="int"), Field(type="str"), Field(type="str"))
    assert if_clause.validate(1) == "1"
    assert if_clause.validate("1") == "1"


# Generated at 2022-06-22 05:47:14.890513
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_field = IfThenElse(None, None)
    assert test_field.validate(None) == None

    # ensure that the field can be used with default values
    # for then_clause and else_clause
    test_field = IfThenElse(None)
    assert test_field.validate(None) == None

    # this field should be used to test if the error
    # messages are consistent
    test_field = IfThenElse(None, None, None)
    with pytest.raises(ValidationError) as e:
        test_field.validate(None)
    assert e.value.code == 'missing'
    assert e.value.path == []
    assert e.value.schema_path == []

# Generated at 2022-06-22 05:47:20.546469
# Unit test for constructor of class Not
def test_Not():
    print('Unit test for constructor of class Not')
    not_field = Not(negated=Any())
    if not_field is not None:
        print('--- constructor of class Not is Not None')
    else:
        print('--- constructor of class Not is None')

# Generated at 2022-06-22 05:47:22.616730
# Unit test for constructor of class Not
def test_Not():
    x = Not(Any())
    assert x.negated == Any()


# Generated at 2022-06-22 05:47:34.268123
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.integer import Integer
    from typesystem.string import String
    from typesystem.fields import IfThenElse
    if_clause = Integer(maximum=100)
    then_clause = String()
    else_clause = String()
    field = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    # Unit test: if value is smaller than 100, check value against then_clause
    value = 100
    result = field.validate(value, strict=False)
    assert result == ""
    # Unit test: if value is bigger than 100, check value against else_clause
    value = 101
    result = field.validate(value, strict=False)
    assert result == ""

# Generated at 2022-06-22 05:47:35.428736
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass # TODO


# Generated at 2022-06-22 05:47:36.840701
# Unit test for constructor of class AllOf
def test_AllOf():
  field = AllOf([])
  assert field.all_of == []


# Generated at 2022-06-22 05:47:39.804607
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    result = NeverMatch(description='description', title='title', allow_null=True)
    assert result.description == 'description'
    assert result.title == 'title'
    assert result.allow_null == True


# Generated at 2022-06-22 05:47:47.797793
# Unit test for constructor of class OneOf
def test_OneOf():
  # Fixtures and setup
  first_schema = String('first')
  second_schema = String('second')
  third_schema = String('third')
  one_of_schema = OneOf([first_schema, second_schema, third_schema])

  # Exercise

  # Verify
  assert one_of_schema.one_of == [first_schema, second_schema, third_schema]



# Generated at 2022-06-22 05:47:57.781425
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Should match exactly one of the sub-items...
    assert(OneOf(one_of = [Field(description='Test field')]).validate({
        'description': 'Test field'
    }) == {
        'description': 'Test field'
    })
    # ...and reject 'None'
    with raises(ValidationError):
        OneOf(one_of = [Field(description='Test field')]).validate(None)
    # ...and reject with an error message
    with raises(ValidationError) as e:
        OneOf(one_of = [Field(description='Test field')]).validate(None)
        assert(e.value.detail == 'Did not match any valid type.')
    # ...and reject when field is missing

# Generated at 2022-06-22 05:48:01.557615
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf()



# Generated at 2022-06-22 05:48:02.764216
# Unit test for constructor of class Not
def test_Not():
    schema = Not(Any())
    schema.validate(1)

# Generated at 2022-06-22 05:48:10.282422
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem
    from typesystem import fields
    from typesystem import structure

    s = structure.Structure(name="S")
    s.add_field(name="name", field=fields.String())
    s.add_field(name="age", field=fields.Integer())

    all_of = AllOf([
        s,
        fields.Integer(),
    ])

    errors = all_of.validate_or_error({})
    print(errors)
    assert False



# Generated at 2022-06-22 05:48:21.668028
# Unit test for constructor of class AllOf
def test_AllOf():
    print('Unit test for constructor of class AllOf')
    x = AllOf([],None,'','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','','',)

# Generated at 2022-06-22 05:48:27.384059
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Str(), Int()])
    assert field.validate('str') == 'str'
    assert field.validate(1) == 1
    assert field.validate(None)
    assert field.validate(1.1)
    assert field.validate(True)
    assert field.validate([1])
    try:
        field.validate('abc')
    except Exception as e:
        assert e.code == 'multiple_matches'
    try:
        field.validate({'key1': 1})
    except Exception as e:
        assert e.code == 'no_match'


# Generated at 2022-06-22 05:48:29.760645
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Field(), Field()]
    AllOf(all_of)


# Generated at 2022-06-22 05:48:30.689505
# Unit test for constructor of class OneOf
def test_OneOf():
    A = OneOf([Field()])

# Generated at 2022-06-22 05:48:33.663593
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = String()
    then_clause = String()
    else_clause = String()
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-22 05:48:36.940018
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Setup
    Field_instance = NeverMatch()
    
    # Testing with assertion
    assert Field_instance.validate([1, 2, 3]) == ([1, 2, 3])


# Generated at 2022-06-22 05:48:48.798326
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class TestOneOf(OneOf):
        def __init__(self, one_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(one_of, **kwargs)

    field = TestOneOf([Map(keys=Str()), List(items=Int())])
    assert None is field.validate([])
    assert None is field.validate({})
    try:
        field.validate([2])
        raise AssertionError
    except ValidationError as e:
        assert "no_match" == e.code
    try:
        field.validate(["hi"])
        raise AssertionError
    except ValidationError as e:
        assert "no_match" == e.code

# Generated at 2022-06-22 05:48:57.493745
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    from typesystem import String
    from typesystem import OneOf

    schema_min = IfThenElse(String(), Integer(), then_clause=Integer(minimum=3))
    schema_default = IfThenElse(String(), Integer(default=4), else_clause=Integer(default=4))
    schema_min_default = IfThenElse(
        String(),
        Integer(minimum=3, default=4),
        else_clause=Integer(minimum=3, default=4),
    )

# Generated at 2022-06-22 05:48:59.889849
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        field = NeverMatch()
        field.validate(True)
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-22 05:49:03.720409
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([Any(), Any()]).validate(123) == 123
    assert AllOf([Any(), Any()]).validate("123") == "123"
    assert AllOf([Any(), Any()]).validate(None) is None


# Generated at 2022-06-22 05:49:09.857616
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import Integer
    if_clause = Integer()
    then_clause = Integer()
    else_clause = Integer()
    val = IfThenElse(if_clause, then_clause, else_clause)
    assert val.validate(2) is not None
    #assert val.validate(None) is not None
    assert val.validate("2") is not None
    #assert val.validate(3.14) is not None

# Generated at 2022-06-22 05:49:13.621217
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse({}, nullable=True)
    except Exception as e:
        assert isinstance(e, TypeError)
    else:
        assert False
    IfThenElse({}, nullable=True, if_clause=Any())


# Generated at 2022-06-22 05:49:15.910347
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import String, Number
    field = AllOf([String, Number])
    value = "a"
    strict = True
    assert field.validate(value, strict=strict) == value

# Generated at 2022-06-22 05:49:20.710870
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Boolean(description="This should be False", allow_null=False))
    _, error = field.validate_or_error(None)
    assert error is None
    _, error = field.validate_or_error(True)
    assert error is None
    _, error = field.validate_or_error(False)
    assert error is not None



# Generated at 2022-06-22 05:49:22.496683
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated = String())
    assert field.negated == String()

# Generated at 2022-06-22 05:49:24.699906
# Unit test for constructor of class AllOf
def test_AllOf():
    print("test_AllOf" )
    a = AllOf([])
    assert(isinstance(a,AllOf))



# Generated at 2022-06-22 05:49:25.819208
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch() is not None


# Generated at 2022-06-22 05:49:30.911905
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        Not(Int(), allow_null=False)



# Generated at 2022-06-22 05:49:33.250728
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nev = NeverMatch()
    assert nev.errors == {"never": "This never validates."}

# Generated at 2022-06-22 05:49:39.533889
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Valid constructor
    IfThenElse(AllOf([]))
    IfThenElse(AllOf([]), AllOf([]))
    IfThenElse(AllOf([]), AllOf([]), AllOf([]))

# Generated at 2022-06-22 05:49:50.219676
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    not_field.validate(1)
    not_field.validate(True)
    not_field.validate("test")
    not_field.validate(None)
    not_field.validate({"a": 1})
    not_field.validate([1,2,3])
    not_field.validate({1,2,3})
    # Cannot use type validator as Not validation
    negated = Int()
    not_field = Not(negated=negated)
    # Type error, since value is int
    with pytest.raises(TypeError):
        not_field.validate(1)
    # Type error, since value is bool
    with pytest.raises(TypeError):
        not_field.validate(True)


# Generated at 2022-06-22 05:49:58.065407
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(None, None, None).if_clause == None
    assert IfThenElse(None, None, None).then_clause == Any()
    assert IfThenElse(None, None, None).else_clause == Any()
    assert IfThenElse(None, None).if_clause == None
    assert IfThenElse(None, None).then_clause == Any()
    assert IfThenElse(None, None).else_clause == Any()
    assert IfThenElse(None).if_clause == None
    assert IfThenElse(None).then_clause == Any()
    assert IfThenElse(None).else_clause == Any()

# Generated at 2022-06-22 05:50:00.225497
# Unit test for constructor of class Not
def test_Not():
    assert(issubclass(Not, Field))
    assert(Not.__init__(None) is None)


# Generated at 2022-06-22 05:50:03.373312
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String())
    assert not_field.validate(3) == 3
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate('') == ''



# Generated at 2022-06-22 05:50:04.741426
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    AllOf([Any()], "test_field").validate(1) == 1



# Generated at 2022-06-22 05:50:08.763309
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    expected_if_clause = Field()
    expected_then_clause = Field()
    expected_else_clause = Field()
    ifthenelse = IfThenElse(expected_if_clause, expected_then_clause, expected_else_clause)
    assert ifthenelse.if_clause == expected_if_clause
    assert ifthenelse.then_clause == expected_then_clause
    assert ifthenelse.else_clause == expected_else_clause

# Generated at 2022-06-22 05:50:09.473164
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert True

# Generated at 2022-06-22 05:50:19.427688
# Unit test for method validate of class Not
def test_Not_validate():
    testField = Not(Field())
    # If follow the positive case
    testPassed = True
    try:
        result = testField.validate("test")
    except Exception as e:
        testPassed = False
    result = testPassed
    expected = True
    assert result == expected
    # If follow the negative case
    testPassed = True
    try:
        result = testField.validate("test")
    except Exception as e:
        testPassed = False
    result = testPassed
    expected = True
    assert result == expected
    return None

# Generated at 2022-06-22 05:50:31.040442
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """Unit test for method validate of class AllOf"""

    class A(Field):
        errors = {
            "not_a": "A is not equal to 'a'."
        }

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value != 'a':
                raise self.validation_error("not_a")
            return value

    class B(Field):
        errors = {
            "not_b": "B is not equal to 'b'."
        }

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value != 'b':
                raise self.validation_error("not_b")
            return value


# Generated at 2022-06-22 05:50:42.387346
# Unit test for constructor of class OneOf
def test_OneOf():
    import json

    one_of = OneOf(one_of = [Field(1), Field(2)])
    assert one_of.validate(1)
    assert one_of.validate(2)
    assert one_of.serialize(1) == 1
    assert one_of.serialize(2) == 2
    assert json.loads(one_of.serialize(1)) == 1
    assert json.loads(one_of.serialize(2)) == 2
    assert one_of.deserialize(1) == 1
    assert one_of.deserialize(2) == 2
    assert json.loads(one_of.serialize(1)) == 1
    assert json.loads(one_of.serialize(2)) == 2
    assert one_of.validate(3) == False


# Unit test

# Generated at 2022-06-22 05:50:50.624469
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    myOneOf1=OneOf([],required=True)
    myOneOf1.validate(value='1234',strict=False)
    myOneOf1.validate(value='1234',strict=True)
    myOneOf1.validate(value=1234,strict=False)
    myOneOf1.validate(value=1234,strict=True)
    myOneOf1.validate(value=True,strict=False)
    myOneOf1.validate(value=True,strict=True)
    myOneOf1.validate(value=12.34,strict=False)
    myOneOf1.validate(value=12.34,strict=True)
    myOneOf1.validate(value={},strict=False)

# Generated at 2022-06-22 05:50:53.460813
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    val = 123
    field = NeverMatch
    result, error = field.validate_or_error(val)
    assert result == None
    assert error.code == "never"


# Generated at 2022-06-22 05:50:56.965826
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.name == "NeverMatch"
    assert nm.allow_null == False
    assert nm.errors == {"never": "This never validates."}


# Generated at 2022-06-22 05:50:59.347917
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    string = IfThenElse(if_clause=String(), then_clause=String())
    string.validate(value="asd")
    string.validate(value="123")


# Generated at 2022-06-22 05:51:01.244909
# Unit test for method validate of class Not
def test_Not_validate():
    test_field_name = 'test'
    n = Not(Integer(), name=test_field_name)
    assert n.validate(123) == 123
    assert n.validate('123') == '123'


# Generated at 2022-06-22 05:51:03.483297
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of = [])
    assert one_of.one_of == []


# Generated at 2022-06-22 05:51:05.965346
# Unit test for constructor of class Not
def test_Not():
    assert str(Not(Any())) == "not typesystem.fields.Any"



# Generated at 2022-06-22 05:51:13.776735
# Unit test for method validate of class Not
def test_Not_validate():
    class Address(Schema):
        street = String()
        city = String()

    class Person(Schema):
        name = String()
        address = Not(Instance(Address))

    person = Person()
    with raises(ValidationError, match="Must not match."):
        person.validate(dict(name="John Doe", address=dict(city="Some City")))

    person.validate(dict(name="John Doe"))

# Generated at 2022-06-22 05:51:16.991395
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ft = IfThenElse(1,2,3)
    assert ft.if_clause == 1
    assert ft.then_clause == 2
    assert ft.else_clause == 3

# Generated at 2022-06-22 05:51:17.562528
# Unit test for constructor of class OneOf
def test_OneOf():
    p = OneOf([1])

# Generated at 2022-06-22 05:51:25.218380
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    cls = IfThenElse(if_clause, then_clause, else_clause)
    assert cls.if_clause is if_clause
    assert cls.then_clause is then_clause
    assert cls.else_clause is else_clause

    cls = IfThenElse(if_clause, else_clause=else_clause)
    assert cls.if_clause is if_clause
    assert isinstance(cls.then_clause, Any)
    assert cls.else_clause is else_clause

# Generated at 2022-06-22 05:51:26.782251
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    field = Not(String(max_length=3))

# Generated at 2022-06-22 05:51:29.619268
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(string(), int()).validate("42") == 42
    assert IfThenElse(string(), int()).validate(None) == None

# Generated at 2022-06-22 05:51:37.385386
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from .contrib.fields import IfThenElse
    from .main import String
    if_clause = String()
    then_clause = String()
    else_clause = String()
    test = IfThenElse(if_clause, then_clause, else_clause)
    assert test.if_clause is if_clause
    assert test.then_clause is then_clause
    assert test.else_clause is else_clause



# Generated at 2022-06-22 05:51:42.110718
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any(),
        required=True,
    )
    assert field.if_clause is not None
    assert field.then_clause is not None
    assert field.else_clause is not None

# Generated at 2022-06-22 05:51:44.778798
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    try:
        assert field.validate(10)
        assert False
    except:
        assert True

# Generated at 2022-06-22 05:51:48.967810
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(String(max_length=5), Int(), else_clause=String())
    value = field.validate("12345")
    assert value == 12345, "validate(value) doesn't work as expected"
    # TODO: add more tests



# Generated at 2022-06-22 05:51:54.136368
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer
    schema = AllOf([Integer(), Integer()])
    schema.validate(1)
    assert True
    

# Generated at 2022-06-22 05:51:57.516672
# Unit test for constructor of class AllOf
def test_AllOf():
    with pytest.raises(AssertionError) as error:
        AllOf(None, allow_null=False)
    assert str(error.value) == 'AllOf fields cannot be null.'

# Generated at 2022-06-22 05:52:04.177124
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    int_type = OneOf([Int()], name="IntType")

    # success
    int_type.validate(1)
    int_type.validate(True)
    int_type.validate(False)
    int_type.validate(None)

    # fail
    try:
        int_type.validate(3.14)
    except ValidationError:
        print('Test passed: 3.14 is not an int.')
    else:
        raise Exception('Test failed: 3.14 is not an int.')


# Generated at 2022-06-22 05:52:14.651433
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    
    # Assertion error if the object is not of type OneOf
    with pytest.raises(AssertionError):
        OneOf([])

    # Assertion error if the object is not of type OneOf
    with pytest.raises(AssertionError):
        OneOf([1,2], [3])

    # Assertion error if the object is not of type OneOf
    with pytest.raises(AssertionError):
        OneOf({})

    # Assertion error if the object is not of type OneOf
    with pytest.raises(AssertionError):
        OneOf("")
    
    # Assertion error if the object is not of type OneOf
    with pytest.raises(AssertionError):
        OneOf(True)

    # Assertion error if the

# Generated at 2022-06-22 05:52:19.595174
# Unit test for constructor of class OneOf
def test_OneOf():
    a = Field()
    b = Field()
    c = OneOf([a, b])
    assert c.one_of == [a, b]


# Generated at 2022-06-22 05:52:28.622000
# Unit test for constructor of class Not
def test_Not():
    # From https://json-schema.org/understanding-json-schema/reference/appendix.html
    # Example 10
    schema = {
        "allOf": [{"$ref": "#/definitions/positive_integer"}],
        "definitions": {
            "positive_integer": {"multipleOf": {"const": 1}, "minimum": {"const": 0}}
        },
        "type": "integer",
    }
    # Note: "const", "multipleOf", and "minimum" are not defined in
    # https://json-schema.org/understanding-json-schema/reference/appendix.html#positive-integer
    # so using Any() for them.
    pos_int = AllOf(
        [Any(), Any(), Any()], name="positive_integer", description="positive_integer"
    )

# Generated at 2022-06-22 05:52:30.400233
# Unit test for constructor of class Not
def test_Not():
    try:
        Not(negated=Field(), description='None')
    except TypeError:
        assert False


# Generated at 2022-06-22 05:52:38.116366
# Unit test for constructor of class AllOf
def test_AllOf():
    """Unit test for constructor of class AllOf"""
    import json
    import pkg_resources
    import typesystem
    # Load example JSON Schema JSON data into Python data structure
    json_data = pkg_resources.resource_string(__name__, "data/AllOf.json").decode("utf-8")
    data = json.loads(json_data)
    # Construct an object for testing
    obj = typesystem.AllOf(**data)
    # Encode back to JSON and compare with source
    assert json.dumps(obj.json_schema(), sort_keys=True) == json_data



# Generated at 2022-06-22 05:52:38.798819
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-22 05:52:39.721778
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	obj = NeverMatch()
	assert isinstance(obj, NeverMatch)


# Generated at 2022-06-22 05:52:57.634703
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # pylint: disable=E1129

    # Setup
    from typesystem import Array, Boolean, Integer, Number, String

    field = NeverMatch(
        name="Some Field",
        description="Some description",
        default="Some default",
        required=True,
        strict=False,
        choices="Some choices",
        items=String(),
    )

    # Exercise
    # Verify
    with pytest.raises(field.validation_error.cls) as error:
        field.validate(value=None, strict=False)
    assert error.value.data == {"code": "never", "pointer": "/Some Field"}

# Generated at 2022-06-22 05:53:03.305942
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(1, then_clause=2).validate(1) == 2
    assert IfThenElse(1, else_clause=2).validate(2) == 2
    assert IfThenElse(1, then_clause=2, else_clause=3).validate(1) == 2
    assert IfThenElse(1, then_clause=2, else_clause=3).validate(2) == 3

# Generated at 2022-06-22 05:53:05.086033
# Unit test for constructor of class AllOf
def test_AllOf():
    allOf = AllOf([String()])
    assert allOf.all_of == [String()]


# Generated at 2022-06-22 05:53:06.674872
# Unit test for constructor of class AllOf
def test_AllOf():
	allof = AllOf([])


# Generated at 2022-06-22 05:53:08.813125
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_IfThenElse = IfThenElse(Field(), Field(), Field())
    assert test_IfThenElse



# Generated at 2022-06-22 05:53:20.401966
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    i=IfThenElse(Any())
    assert type(i) is IfThenElse
    assert isinstance(i.if_clause, Any)
    assert isinstance(i.then_clause, Any)
    assert isinstance(i.else_clause, Any)

    i2=IfThenElse(Any(),then_clause=Any())
    assert type(i2) is IfThenElse
    assert isinstance(i2.if_clause, Any)
    assert isinstance(i2.then_clause, Any)
    assert isinstance(i2.else_clause, Any)

    i3=IfThenElse(Any(),else_clause=Any())
    assert type(i3) is IfThenElse
    assert isinstance(i3.if_clause, Any)

# Generated at 2022-06-22 05:53:26.922345
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class U(AllOf):
        def __init__(self, *args):
            super().__init__(*args)

    fields = [
        Field(),
    ]

    U(fields).validate(None)

    # Fails since it aborts after the first failure.
    with pytest.raises(FieldError):
        U([
            Field(format='invalid_format'),
            Field(),
        ]).validate(None)


# Generated at 2022-06-22 05:53:35.826623
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class MyClass(AllOf):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(all_of, **kwargs)
            self.all_of = all_of
    allOf = MyClass()
    allOf.all_of = [ 
        'a',
        'b'
        ]
    allOf.validate( 1 )
    allOf.all_of = [ ]
    allOf.validate( { } )


# Generated at 2022-06-22 05:53:37.269793
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test = NeverMatch()
    assert test is not None


# Generated at 2022-06-22 05:53:45.705078
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.fields import Integer

    not_string = Not(String())

    try:
        not_string.validate('test')
    except Field.ValidationError as e:
        assert e.as_json()['errors'][0]['error'] == 'negated'
    
    not_int = Not(Integer())

    try:
        not_int.validate(5)
    except Field.ValidationError as e:
        assert e.as_json()['errors'][0]['error'] == 'negated'

# Generated at 2022-06-22 05:53:59.429536
# Unit test for constructor of class OneOf
def test_OneOf():
  assert OneOf(one_of = ["a"]) == OneOf(one_of = ["a"])
  assert OneOf(one_of = ["a"]) != OneOf(one_of = ["b"])
  assert OneOf(one_of = ["a"]) != OneOf(one_of = ["a", "b"])

# Generated at 2022-06-22 05:54:03.601448
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test simple OneOf, with one field
    # Input parameters:
    one_of = [Field()]
    one_of_object = OneOf(one_of)
    assert one_of_object.one_of == one_of


# Generated at 2022-06-22 05:54:04.176829
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf()

# Generated at 2022-06-22 05:54:10.003691
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Instance of class OneOf
    OneOf_instance = OneOf(one_of=[Any()])
    # If strict is False
    Allowed_types = [dict, list, int, float, bool, str]
    for allowed_type in Allowed_types:
        # Input value
        value = allowed_type()
        # Expecting the method will return value
        assert OneOf_instance.validate(value, strict=False) == value


# Generated at 2022-06-22 05:54:15.313452
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=Boolean(),
        then_clause=String(),
        else_clause=Integer(),
    )
    assert field.validate(True, strict=False) is True
    assert field.validate(False, strict=False) == 0



# Generated at 2022-06-22 05:54:21.326356
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer, String
    field = OneOf([Integer(),String()])
    name = field.__class__.__name__
    doc = field.__doc__
    assert name == "OneOf"
    assert doc == "Must match exactly one of the sub-items.\n\nYou'll almost always want to just use `Union` instead of this, which is an\n\"anyOf\" test.\n"


# Generated at 2022-06-22 05:54:22.728835
# Unit test for constructor of class AllOf
def test_AllOf():
    '''Test constructor of class AllOf'''
    all_of = AllOf([Any()])
    assert all_of != None


# Generated at 2022-06-22 05:54:28.699181
# Unit test for method validate of class Not
def test_Not_validate():
    if_clause = Field()
    _, error = if_clause.validate_or_error(1, strict=false)
    null_clause = Field(null=True)
    _, error1 = null_clause.validate_or_error(1, strict=false)
    if_clause = Field(null=true)
    _, error2 = if_clause.validate_or_error(1, strict=false)
    not_valid = Field(null=False)
    _, error2 = not_valid.validate_or_error(1, strict=false)
    if error or error1 or error2:
        print(error or error1 or error2)



# Generated at 2022-06-22 05:54:31.055390
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer

    class C(AllOf):
        all_of = [Integer()]

    c = C()




# Generated at 2022-06-22 05:54:34.891319
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Arrange
    field = NeverMatch()
    value = 42

    # Act
    try:
        field.validate(value)
        passed = False
    except ValidationError:
        passed = True

    # Assert
    assert passed == True


# Generated at 2022-06-22 05:55:00.757221
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf({})
    assert AllOf([Field()])
    assert AllOf([Field(name="field")], name="name")

# Generated at 2022-06-22 05:55:01.437418
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass


# Generated at 2022-06-22 05:55:04.477316
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf(one_of=['a','b','c'])
    aVal = a.validate('a')
    assert aVal == 'a'
    aFail = a.validate('d')
    assert aFail == 'd'


# Generated at 2022-06-22 05:55:06.779175
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=1).negated == 1
    assert Not(negated=int).negated == int


# Generated at 2022-06-22 05:55:10.127850
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(
        if_clause = None,
        then_clause = None,
        else_clause = None
    )

# Generated at 2022-06-22 05:55:18.789477
# Unit test for constructor of class OneOf
def test_OneOf():
    #Fail with just type
    field = Field(type="String")
    try:
        field = OneOf([field])
    except AssertionError:
        assert True
    else:
        assert False

    #Fail with None instead of list
    field = Field(type="String")
    try:
        field = OneOf(None)
    except AssertionError:
        assert True
    else:
        assert False

    #Success with list of fields
    field = Field(type="String")
    field = OneOf([field])
    assert True



# Generated at 2022-06-22 05:55:21.606210
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    Field.__init__(IfThenElse, if_clause='sad', then_clause=None, else_clause=None)

# Generated at 2022-06-22 05:55:25.252689
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Given
    field = NeverMatch()

    # When/Then
    with pytest.raises(field.validation_error):
        field.validate(1)


# Generated at 2022-06-22 05:55:26.737277
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # pass
    NeverMatch()
    print("NeverMatch constructor: Pass")

# Generated at 2022-06-22 05:55:27.702117
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch
