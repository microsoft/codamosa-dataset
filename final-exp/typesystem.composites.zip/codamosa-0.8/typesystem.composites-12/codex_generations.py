

# Generated at 2022-06-12 15:28:43.621873
# Unit test for constructor of class OneOf
def test_OneOf():
    field=OneOf([Field(name="Field1"), Field(name="Field2"), Field(name="Field3")])
    assert field.errors=={"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert field.one_of==[Field(name="Field1"), Field(name="Field2"), Field(name="Field3")]


# Generated at 2022-06-12 15:28:46.237839
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(String(), then_clause = Integer()).validate(True) == True


# Generated at 2022-06-12 15:28:47.691161
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    pass # TODO: implement your test here


# Generated at 2022-06-12 15:28:48.286019
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-12 15:28:52.996432
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # 1st attempt to validate [1, 2, 3] with Integer if_clause
    ite = IfThenElse(
        Integer(), #if_clause
        Number(), #then_clause
        )
    ite.validate([1, 2, 3])

    # 2nd attempt to validate [1, 2, 3] with Integer if_clause
    ite = IfThenElse(
        Integer(), #if_clause
        Number(), #then_clause
        )
    ite.validate(True)

# Generated at 2022-06-12 15:28:56.428261
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import Boolean, Integer

    field = Not(Boolean(default=True, allow_null=True))
    value = field.validate(1)
    assert value == 1
    value = field.validate(False)
    assert value == False



# Generated at 2022-06-12 15:29:00.462957
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test fails when the validate method of class IfThenElse is not defined.
    assert IfThenElse.validate(1,1)==1


# Generated at 2022-06-12 15:29:02.856296
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    t = OneOf([])
    assert t.validate(None, True) == None


# Generated at 2022-06-12 15:29:06.782654
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse(String(max_length=10), String(max_length=20))
    # Condition met
    assert a.validate("1234567") == "1234567"
    # Condition not met
    assert a.validate("12345678901234567890") == "12345678901234567890"

# Generated at 2022-06-12 15:29:09.402567
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Method to test validate method of class OneOf
    """
    oneof_clause = OneOf([Any(), Any()])
    assert oneof_clause.validate(1) == 1


# Generated at 2022-06-12 15:29:15.127177
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(None,None)
    assert not_.validate(1) == 1
    #assert not_.validate(None) == None

# Generated at 2022-06-12 15:29:19.363840
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Any())
    assert field.negated == Any()
    assert field.errors == {"negated": "Must not match."}
    assert field.allow_null == True
    assert field.default == ""


# Generated at 2022-06-12 15:29:21.008791
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf([], name = "String"), Field)

# Generated at 2022-06-12 15:29:24.948964
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    s = IfThenElse(Number(), then_clause=String(), else_clause=String())
    s.validate(10)
    s.validate("a")

    # Assert

# Generated at 2022-06-12 15:29:33.736460
# Unit test for method validate of class Not
def test_Not_validate():
    # create a field to check condition
    field = Field(name="prop1")
    # create a Not field
    field2 = Not(field)
    # check condition: field must not match
    is_valid, errors = field2.validate_or_error("val1")
    assert is_valid
    assert errors=={}
    # check condition: field must match
    is_valid, errors = field2.validate_or_error(2)
    assert not is_valid
    assert errors=={'negated': "Must not match."}


# Generated at 2022-06-12 15:29:38.842766
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    assert field.validate('123') == '123'
    with pytest.raises(ValidationError) as err_info:
        field.validate(12345678901)
    assert err_info.value.error_type == "multiple_matches"

# Generated at 2022-06-12 15:29:41.953965
# Unit test for method validate of class Not
def test_Not_validate():
    o = Not(Integer())
    assert o.validate(10) == 10
    try:
        o.validate(1.1)
    except Exception as e:
        assert str(e) == 'Must not match.'
    return


# Generated at 2022-06-12 15:29:48.603458
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    if_clause = Integer(min_value=0)
    then_clause = String()
    else_clause = String(pattern=r'^[a-zA-Z]{3}$')
    test = IfThenElse(if_clause, then_clause, else_clause)

    result = test.validate(0)
    assert(result == '0')

    result = test.validate(30)
    assert(result == '30')

    result = test.validate(-1)
    assert(result == '-1')

    result = test.validate('ABC')
    assert(result == 'ABC')

    result = test.validate('ABCD')
    assert(result == 'ABCD')


# Generated at 2022-06-12 15:29:57.614566
# Unit test for method validate of class Not
def test_Not_validate():
    a1 = 10
    a2 = 'abc'
    # a3 = 10.5
    # a4 = 
    dict1 = {'a': 10, 'b': 'abc'}
    dict2 = {}
    list1 = [10, 'abc']
    list2 = [10, 'abc', 10.5, dict1, dict2, list1, list2]

    with pytest.raises(typesystem.Error) as excinfo:
        Not(Any()).validate(a1)
    assert excinfo.value.code == "negated"

    with pytest.raises(typesystem.Error) as excinfo:
        Not(Any()).validate(a2)
    assert excinfo.value.code == "negated"

    assert Not(Any()).validate(a1) == a1


# Generated at 2022-06-12 15:29:58.231420
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-12 15:30:04.486256
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer
    not_field = Not(Integer())
    assert not_field.validate("1")
    try:
        not_field.validate(1)
    except ValueError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:30:06.148255
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__init__(one_of = 'one_of') == None


# Generated at 2022-06-12 15:30:08.333165
# Unit test for constructor of class OneOf
def test_OneOf():
    child1 = Field()
    child2 = Field()
    child3 = Field()
    OneOf(one_of=[child1, child2, child3])


# Generated at 2022-06-12 15:30:10.192190
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()


# Generated at 2022-06-12 15:30:11.012399
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf



# Generated at 2022-06-12 15:30:18.344050
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([None, 'test'])
    try:
        field.validate(None)
    except:
        raise AssertionError("OneOf should validate None")
    try:
        field.validate('test')
    except:
        raise AssertionError("OneOf should validate 'test'")
    try:
        field.validate('test2')
    except:
        pass
    else:
        raise AssertionError("OneOf should not validate 'test2'")

# Generated at 2022-06-12 15:30:20.343191
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-12 15:30:27.467665
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import fields, types

    class Condition(fields.Field):
        def validate(self, value, strict=False):
            if value == 42:
                return value
            raise self.validation_error('error')
    condition = Condition()

    class Then(fields.Field):
        def validate(self, value, **kwargs):
            return 42
    then = Then()

    class Else(fields.Field):
        def validate(self, value, **kwargs):
            return 43
    else_clause = Else()

    if_then_else = types.IfThenElse(condition, then, else_clause)
    assert if_then_else.validate(42) == 42
    assert if_then_else.validate(43) == 43


# Generated at 2022-06-12 15:30:28.068670
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()

# Generated at 2022-06-12 15:30:31.844597
# Unit test for constructor of class Not
def test_Not():
    not_test = Not(None)
    assert isinstance(not_test, Field)
    with pytest.raises(AssertionError):
        Not(None, allow_null=None)


# Generated at 2022-06-12 15:30:36.212893
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    err = 0
    e_msg = []
    try:
        test = NeverMatch(description="NeverMatch", name="test")
    except:
        err += 1
        e_msg.append("NeverMatch not initialized")


# Generated at 2022-06-12 15:30:39.074124
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=OneOf(one_of=[Any()]))
    not_field.validate(0)
    with raises(ValidationError):
        not_field.validate(None)


# Generated at 2022-06-12 15:30:41.871792
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    o = NeverMatch(name="NeverMatch direct constructor test")
    assert o.name == "NeverMatch direct constructor test"
    assert o.required == False


# Generated at 2022-06-12 15:30:46.086435
# Unit test for method validate of class Not
def test_Not_validate():
    field = None
    try:
        field = Not(None)
    except Exception as e:
        assert isinstance(e, AssertionError)
        assert str(e) == "__init__() got an unexpected keyword argument 'allow_null'"
        return
    assert field is not None

# Generated at 2022-06-12 15:30:55.662882
# Unit test for constructor of class AllOf
def test_AllOf():
    import json
    import unittest

    class TestAllOf(unittest.TestCase):
        def test(self):
            import typesystem
            inner_schema = {
                "type":"object",
                "properties":{
                    "name":"string",
                    "age":"integer"
                }
            }
            all_of = [
                typesystem.String(if_clause=typesystem.Integer(),then_clause=typesystem.String()),
                typesystem.Object(schema=json.loads(json.dumps(inner_schema))),
                typesystem.Array(items=typesystem.Integer()),
                typesystem.Number()
            ]
            _schema = typesystem.AllOf(all_of=all_of)

# Generated at 2022-06-12 15:30:57.881780
# Unit test for constructor of class AllOf
def test_AllOf():
    f = AllOf([
        Any(),
        Any()
    ])
    # check type of f
    assert type(f) == AllOf



# Generated at 2022-06-12 15:31:09.076111
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    try:
        from typesystem.base import ValidationError
    except:
        from typesystem import ValidationError
    from typesystem.fields import Integer
    from solution import IfThenElse
    field = IfThenElse(
        if_clause=Integer(minimum=0),
        then_clause=Integer(minimum=1),
        else_clause=Integer(maximum=-1),
    )
    field.validate(5)
    field.validate(-5)
    try:
        field.validate(0)
    except ValidationError:
        pass
    else:
        raise AssertionError('IfThenElse.validate failed, with 0')
    try:
        field.validate(1)
    except ValidationError:
        pass

# Generated at 2022-06-12 15:31:14.538719
# Unit test for constructor of class Not
def test_Not():
    class Boolean(Field):
        def validate(self, value, strict=False):
            return True

    b = Boolean()
    not_b = Not(b)
    assert not_b.validate(False)
    try:
        not_b.validate(True)
    except Exception as e:
        assert not_b.errors["negated"] == e.args[0]


# Generated at 2022-06-12 15:31:21.787384
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer

    field = IfThenElse(
        if_clause=Integer(minimum=0, maximum=100),
        then_clause=Integer(minimum=0, maximum=100),
        else_clause=Integer(minimum=100, maximum=1000),
    )
    assert field.validate("10") == 10
    assert field.validate("1000") == 1000

    field = IfThenElse(
        if_clause=Integer(minimum=60, maximum=100),
        then_clause=Integer(minimum=60, maximum=100),
        else_clause=Integer(minimum=100, maximum=1000),
    )
    assert field.validate("10") == 10
    assert field.validate("1000") == 1000

# Generated at 2022-06-12 15:31:26.720085
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    class TestIfThenElse(IfThenElse):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)

    ite = TestIfThenElse(if_clause=Any(validate=lambda x: False), then_clause=Integer(), else_clause=Integer())

    assert ite.validate(True) == 1
    assert ite.validate(False) == 1
    assert ite.validate(6) == 1
    assert ite.validate(6.0) == 1

# Generated at 2022-06-12 15:31:31.250679
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n.errors == {"never" : "This never validates."}


# Generated at 2022-06-12 15:31:40.473590
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import pytest
    from typesystem import Schema

    data = {"name": "Tester", "age": 25}
    schema = Schema(
        {
            "name": str,
            "age": IfThenElse(
                if_clause={"type": "integer"},
                then_clause={
                    "type": "integer",
                    "minimum": 21,
                    "maximum": 65,
                },
                else_clause={
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 12,
                },
            ),
        }
    )
    assert schema.validate(data) == data
    assert schema.validate({"name": "Annie", "age": 1}) == {"name": "Annie", "age": 1}

# Generated at 2022-06-12 15:31:43.537391
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test = IfThenElse(if_clause=Text(), then_clause=Text(), else_clause=Text())
    test.validate("test")


# Generated at 2022-06-12 15:31:50.145603
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(Integer(),Integer(),Integer())
    value1 = 10
    value2 = 'true'
    print('Test of class IfThenElse')
    print('Test 1')
    assert schema.validate(value1) == 10
    print('value1: {}'.format(value1))
    print('schema: {}'.format(schema))
    print('Test 2')
    assert schema.validate(value2) == None
    print('value2: {}'.format(value2))
    print('schema: {}'.format(schema))

# Generated at 2022-06-12 15:31:55.560740
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any(), description="not_field")
    # The input value is not None, so the function validate should return a value
    assert "not_field" == not_field.description
    value = not_field.validate("value")
    assert value == "value"
    # The input value is not None, so the function validate should return a value
    not_field2 = Not(Any(), description="not_field2", nullable=False)
    assert not_field2.nullable == False
    value = not_field2.validate("value")
    assert value == "value"

#Unit test for method validate of class AllOf

# Generated at 2022-06-12 15:31:57.912376
# Unit test for constructor of class Not
def test_Not():
    testField = Not(negated=None)
    assert testField != None


# Generated at 2022-06-12 15:32:05.665923
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    #Define test case inputs and expected outputs
    #Note that OneOf is used as a mixin, so we can't use it directly
    test_case_inputs = [[-1, 0, 1], [1, 2, 3]]
    test_case_outputs = [[-1, 0, 1], [1, 2, 3]]

    for i in range(len(test_case_inputs)):
        #Compare arguments with expected outputs and raise AssertionError if not match
        assert OneOf(test_case_inputs[i]).validate(test_case_outputs[i]) == test_case_inputs[i]


# Generated at 2022-06-12 15:32:08.239911
# Unit test for constructor of class Not
def test_Not():
    str_field = String(format="email")
    not_str_field = Not(str_field)
    assert not_str_field.negated == str_field
    assert not_str_field.validate("string") is ValueError

# Generated at 2022-06-12 15:32:08.858831
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert True

# Generated at 2022-06-12 15:32:11.557872
# Unit test for constructor of class Not
def test_Not():
    def constructor(negated):
        return Not(negated)

    result = constructor(None)
    assert isinstance(result, Not)


# Generated at 2022-06-12 15:32:25.686759
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_true(value):
        if_this = Field(validators=[lambda v: True])
        then_this = Field(validators=[lambda v: "✅"])
        else_that = Field(validators=[lambda v: "❌"])
        actual = IfThenElse(if_this, then_this, else_that).validate(value)
        assert actual == "✅"

    def test_false(value):
        if_this = Field(validators=[lambda v: False])
        then_this = Field(validators=[lambda v: "✅"])
        else_that = Field(validators=[lambda v: "❌"])
        actual = IfThenElse(if_this, then_this, else_that).validate(value)
        assert actual == "❌"

# Generated at 2022-06-12 15:32:30.668865
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String, Integer
    S = String()
    I = Integer()
    IIf = IfThenElse(S, I)
    assert IIf.validate('mahesh') == 'mahesh'
    #assert IIf.validate(10) == 10



# Generated at 2022-06-12 15:32:40.369871
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for no_match
    one_of_field = OneOf(True)
    assert one_of_field.validate(True) == True
    one_of_field = OneOf(False)
    assert one_of_field.validate(False) == False
    # Test for multiple_matches
    one_of_field = OneOf(True, False)
    try:
        one_of_field.validate(True)
        raise AssertionError("Expected ValidationError")
    except ValidationError as e:
        assert e.code == "multiple_matches"
    try:
        one_of_field.validate(False)
        raise AssertionError("Expected ValidationError")
    except ValidationError as e:
        assert e.code == "multiple_matches"
    # Test

# Generated at 2022-06-12 15:32:42.511502
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    n.validate("a")


# Generated at 2022-06-12 15:32:43.474756
# Unit test for constructor of class Not
def test_Not():
    pass


# Generated at 2022-06-12 15:32:48.805256
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(if_clause=Field(keyword='test'))

    #test case 1
    try:
        ite.validate(value=None)
    except NotImplementedError:
        assert True
    #test case 2
    try:
        ite.validate(value='test')
    except NotImplementedError:
        assert True
    #test case 3
    try:
        ite.validate(value='not_a_test')
    except NotImplementedError:
        assert True

# Generated at 2022-06-12 15:32:59.814203
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    print("test_IfThenElse_validate()")

    assert IfThenElse(if_clause=Any(), then_clause=Integer()).validate(True) == True
    assert IfThenElse(if_clause=Any(), then_clause=Integer()).validate(False) == False

    assert IfThenElse(if_clause=Any(), then_clause=Integer()).validate(True) == True
    assert IfThenElse(if_clause=Any(), then_clause=Integer()).validate(False) == False

    assert IfThenElse(if_clause=Any(), then_clause=Integer()).validate(True) == True
    assert IfThenElse(if_clause=Any(), then_clause=Integer()).validate(False) == False


# Generated at 2022-06-12 15:33:01.452797
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    def testfun():
        NeverMatch(type_name="string")
    assertRaises(AssertionError, testfun)

# Generated at 2022-06-12 15:33:08.708852
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.types import JSONSchema
    from typesystem.types import Type
    from typesystem.types import Union
    from typesystem.types import List

    if_clause = Integer(maximum=10)
    then_clause = Integer(minimum=5)
    else_clause = Integer(minimum=15)
    my_type = IfThenElse(if_clause, then_clause, else_clause)

    value_1 = 5
    value_2 = 15
    value_3 = 10
    assert my_type.validate(value_1) is value_1
    assert my_type.validate(value_2) is value_2
    assert my_type.validate(value_3) is None

    if_clause = Integer(maximum=10)
    then

# Generated at 2022-06-12 15:33:14.695963
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test function to validate the method validate of class IfThenElse
    test_obj = IfThenElse(if_clause=Any(), then_clause=None, else_clause=None)
    assert test_obj.validate(value=None) is None
    assert test_obj.validate(value=False) is False
    assert test_obj.validate(value=True) is True

# Generated at 2022-06-12 15:33:24.282430
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test class IfThenElse, method validate
    """
    from typing import Any
    from typesystem.fields import String
    from typesystem.typing import JSON

    # Test if_clause is None
    if_clause = None
    then_clause = String()
    else_clause = String()
    ite = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    x: Any = ite.validate(value="Lorem")
    assert x
    assert isinstance(x, JSON)

    # Test then_clause is None
    if_clause = String()
    then_clause = None
    else_clause = String()

# Generated at 2022-06-12 15:33:31.333817
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.base import ValidationError

    class TestField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise ValidationError(self.errors["not_valid"])

    test_field = TestField()
    negated_test_field = Not(test_field)

    assert negated_test_field.validate("kek") == "kek"

    try:
        negated_test_field.validate("kek", strict=True)
    except ValidationError as e:
        assert e.message == "Must not match."


test_Not_validate()

# Generated at 2022-06-12 15:33:36.075941
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(Integer(0,10))
    a = IfThenElse(Integer(0,10), then_clause=Float(-5,5))
    a = IfThenElse(Integer(0,10), else_clause=Float(-5,5))
    a = IfThenElse(Integer(0,10), then_clause=Float(-5,5), else_clause=Float(-5,5))

# Generated at 2022-06-12 15:33:37.444826
# Unit test for constructor of class Not
def test_Not():
    notField = Not(Field())
    assert notField != None


# Generated at 2022-06-12 15:33:43.006286
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """method validate of class IfThenElse"""
    # Arrange
    field_one = Field(name="field_one", required=True)
    field_two = Field(name="field_two")
    field_three = Field(name="field_three")
    test_field = IfThenElse(condition=field_one, then_clause=field_two, else_clause=field_three)
    # Act
    result = test_field.validate({"field_two": 1}, strict=False)
    # Assert
    assert result == {"field_two": 1}

# Generated at 2022-06-12 15:33:48.881391
# Unit test for constructor of class AllOf
def test_AllOf():
    class NewAllOf(AllOf):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
    a = NewAllOf([Field(max_length=1), Field(min_length=1)], required=False)
    assert a.all_of[0].__class__ == Field
    assert a.all_of[1].__class__ == Field


# Generated at 2022-06-12 15:33:54.364056
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Int(), Int()], description="OneOf").validate(1) == 1
    error = OneOf([Int(), Int()], description="OneOf").validate("foo")
    # print(error)
    assert "no_match" in error
    error = OneOf([Int(), Float()], description="OneOf").validate("foo")
    # print(error)
    assert "multiple_matches" in error


# Generated at 2022-06-12 15:33:58.434971
# Unit test for method validate of class Not
def test_Not_validate():
    class NotNull(Field):

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value is None:
                raise ValidationError('Field may not be null')
            return value

    not_null = Not(NotNull())
    try:
        not_null.validate(None)
    except ValidationError:
        pass

# Generated at 2022-06-12 15:34:02.862988
# Unit test for method validate of class Not
def test_Not_validate():
    """Test case for method validate of class Not."""
    f = Not(Any(value_type=int))
    assert f.validate("abc") == "abc"

    # f = Not(Any(value_type=int))
    # assert f.validate(123) == 123



# Generated at 2022-06-12 15:34:10.674221
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.exceptions import ValidationError

    class Int(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return int(value)

    class Max(Field):
        errors = {"max_value": "Ensure this value is less than or equal to {max_value}."}

        def __init__(self, max_value: int, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.max_value = max_value


# Generated at 2022-06-12 15:34:23.490028
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_field = NeverMatch(name='NeverMatchField')
    assert type(test_field) == NeverMatch
    assert type(test_field.errors) == dict
    assert test_field.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:34:24.769962
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {'never': 'This never validates.'}
    

# Generated at 2022-06-12 15:34:28.845443
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Integer()
    then_clause = Float()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(1.0)

    field = IfThenElse(if_clause, then_clause)
    assert field.validate(1.0)

    field = IfThenElse(if_clause)
    assert field.validate(1)

test_IfThenElse()

# Generated at 2022-06-12 15:34:30.543220
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    t = NeverMatch()
    #  t.errors = {"never": "This never validates."}
    #  assert t.errors == {"never": "This never validates."}
    

# Generated at 2022-06-12 15:34:35.290731
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test if the object of class IfThenElse throws an error when
    # the if_clause does not match
    # Arrange
    # create numerical field with minimum value
    if_clause = Field.of(int, "int_field")
    # create numerical field with minimum value
    then_clause = Field.of(int, "int_field")
    # create numerical field with minimum value
    else_clause = Field.of(int, "int_field")
    field = IfThenElse(if_clause, then_clause, else_clause)
    value = 1
    # Act
    # test with the string "1"
    # Assert
    # Expect the test to throw an error
    with pytest.raises(ValidationError):
        field.validate(value, strict=True)

    # Test

# Generated at 2022-06-12 15:34:44.257471
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    class FieldTest(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class FieldTestFalse(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return False

    class FieldTestTrue(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return True

    one = FieldTest(label="one")
    two = FieldTest(label="two")
    three = FieldTest(label="three")
    four = FieldTestTrue(label="four")

    my_field = IfThenElse(if_clause=one, then_clause=two, else_clause=three)

# Generated at 2022-06-12 15:34:44.797910
# Unit test for constructor of class Not
def test_Not():
    assert Not(Any())

# Generated at 2022-06-12 15:34:46.670557
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True # TODO: implement your test here


# Generated at 2022-06-12 15:34:48.418232
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """
    Unit test for constructor of class NeverMatch
    """
    pass


# Generated at 2022-06-12 15:34:49.338839
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    OneOf()

# Generated at 2022-06-12 15:35:07.759074
# Unit test for constructor of class Not
def test_Not():
    test = Not('negated.errors')
    assert test.errors == {'negated': 'Must not match.'}



# Generated at 2022-06-12 15:35:17.465280
# Unit test for constructor of class Not
def test_Not():
    import unittest
    from typesystem.fields import Boolean

    class NotTest(unittest.TestCase):
    
        def test_fails(self):
            field = Not(Boolean())
    
            with self.assertRaises(field.validation_error) as cm:
                field.validate(True)
    
            assert str(cm.exception) == 'Must not match.'
    
        def test_passes(self):
            field = Not(Boolean())
    
            value = field.validate(False)
    
            assert value is False

    # Execute the unit test
    unittest.main()

# Generated at 2022-06-12 15:35:19.206063
# Unit test for constructor of class Not
def test_Not():
    negated = Not()
    if not(isinstance(negated, Field)):
        raise RuntimeError('Not is not a Field')

# Generated at 2022-06-12 15:35:24.055388
# Unit test for constructor of class OneOf
def test_OneOf():
    field1 = Field()
    field2 = Field()
    field3 = Field()
    print (field1, field2, field3)
    oneOf = OneOf([field1, field2, field3])
    print (oneOf)
    for field in oneOf.one_of:
        print (field)


# Generated at 2022-06-12 15:35:27.248871
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [types.String()]
    field = AllOf(all_of)
    assert field.all_of == all_of


# Generated at 2022-06-12 15:35:32.258232
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([])
    b = AllOf([], description='a')
    c = AllOf([], description='a', all_of=[b])
    d = AllOf([], description='a', all_of=[b, c])
    assert a
    assert b
    assert c
    assert d
    assert a.all_of == []
    assert b.all_of == []
    assert c.all_of == [b]
    assert d.all_of == [b, c]

# Generated at 2022-06-12 15:35:32.611878
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])

# Generated at 2022-06-12 15:35:34.038430
# Unit test for constructor of class Not
def test_Not():
    n = Not(IfThenElse(Any(), Any(), Any()))
    assert n.negated == IfThenElse(Any(), Any(), Any())


# Generated at 2022-06-12 15:35:44.151691
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = FieldSchema({}, required=True)
    if_clause.get_attributes_from_fields()
    then_clause = FieldSchema({}, required=True)
    then_clause.get_attributes_from_fields()
    else_clause = FieldSchema({}, required=True)
    else_clause.get_attributes_from_fields()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    try:
        if_then_else.validate(1)
    except ValidationError as err:
        assert err.code == "missing_field" and err.field == "value"
    if_then_else.validate({'value': 1})

# Generated at 2022-06-12 15:35:51.427252
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestClass(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    test_class = TestClass()

    if_clause = test_class
    then_clause = test_class
    else_clause = test_class
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    result_actual = if_then_else.validate(123)
    result_expected = 123
    assert result_actual == result_expected

# Generated at 2022-06-12 15:36:35.144872
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Field(const=True), then_clause=Field(const=1)).validate(1) == 1
    assert IfThenElse(if_clause=Field(const=True), then_clause=Field(const=1)).validate(2) == 1
    
    assert IfThenElse(if_clause=Field(const=False), then_clause=Field(const=1)).validate(1) == 1
    assert IfThenElse(if_clause=Field(const=False), then_clause=Field(const=1)).validate(2) == 2

    assert IfThenElse(if_clause=Field(const=True), then_clause=Field(const=1), else_clause=Field(const=2)).validate(1) == 1

# Generated at 2022-06-12 15:36:37.662558
# Unit test for constructor of class Not
def test_Not():
    negated = True
    assert (Not(negated)).negated == True



# Generated at 2022-06-12 15:36:40.844070
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(
        one_of=[
            Field(default_error="Invalid"),
            Field(default_error="Invalid"),
            Field(default_error="Invalid"),
        ]
    )


# Generated at 2022-06-12 15:36:45.506087
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    assert x.if_clause is None
    assert x.then_clause is None
    assert x.else_clause is None



# Generated at 2022-06-12 15:36:49.348572
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Given
    field = NeverMatch()

    # When
    result = field.errors.get("never")

    # Then
    assert result ==  "This never validates."


# Generated at 2022-06-12 15:36:52.879246
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    a = String()
    b = String()
    c = String()
    print("test_OneOf:")
    one_of = OneOf([a,b,c])
    print(one_of)
    return one_of

one_of = test_OneOf()


# Generated at 2022-06-12 15:37:01.250568
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    IfThenElse is a conditional schema where either then_clause or else_clause must be present
    """
    # Test if the constructor throws an error when then_clause and else_clause are both not present
    try:
        field = IfThenElse(if_clause=Field())
        assert False
    except AssertionError:
        assert True
    
    # Test if the constructor throws an error when then_clause is not present
    try:
        field = IfThenElse(if_clause=Field(), else_clause=Field())
        assert False
    except AssertionError:
        assert True
    
    # Test if the constructor throws an error when else_clause is not present

# Generated at 2022-06-12 15:37:10.362237
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # if_clause = Field, then_clause = None, else_clause = None
    # expected = Field, Any, Any
    if_clause = None
    then_clause = None
    else_clause = None
    if_clause = Field()
    assert isinstance(if_clause, Field)
    test_IFT = IfThenElse(if_clause, then_clause, else_clause)
    expected = Field
    assert isinstance(test_IFT.if_clause, expected)
    assert isinstance(test_IFT.then_clause, Any)
    assert isinstance(test_IFT.else_clause, Any)

    # if_clause = Field, then_clause = Field, else_clause = Field
    # expected = Field, Field, Field

# Generated at 2022-06-12 15:37:12.921666
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[])
    assert one_of.one_of == []


# Generated at 2022-06-12 15:37:14.485999
# Unit test for constructor of class Not
def test_Not():
    t = Not(negated='a', label='b')
    assert t.label == 'b'
    return t



# Generated at 2022-06-12 15:38:32.982274
# Unit test for constructor of class Not
def test_Not():

    field = Not(Field())
    assert field.negated == Field()
    assert field.error["negated"] == "Must not match."


# Generated at 2022-06-12 15:38:42.464064
# Unit test for constructor of class Not
def test_Not():
    def test_Not_name_type_and_error_message():
        f = Not(Negated())
        assert f.name == "Not"
        assert f.type == "not"
        assert f.type_name == Negated.type_name
        assert f.error_message == Negated.error_message
        assert f.error_code == Negated.error_code

    def test_Not_validate_happy_path():
        f = Not(Negated())
        assert f.validate(None) is None
        assert f.validate('') is None
        assert f.validate('my test string') is None
        assert f.validate([]) is None
        assert f.validate({}) is None
        assert f.validate({'a':1}) is None
