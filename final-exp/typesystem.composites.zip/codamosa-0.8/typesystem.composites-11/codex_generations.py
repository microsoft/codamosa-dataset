

# Generated at 2022-06-12 15:28:42.941610
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import AllOf, Integer
    
    allOf = AllOf([Integer(), Integer()])

# Generated at 2022-06-12 15:28:46.976096
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field(), **{})
    field.validate(value=None, strict=False)
    field.validate(value=None, strict=True)


# Generated at 2022-06-12 15:28:53.128382
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(Integer(max_value=0), Integer(min_value=0))
    assert x.validate(5) == 5
    try:
        x.validate(-5)
    except Exception as e:
        assert e.args[0] == 'must be at least 0'
    y = IfThenElse(Integer(max_value=0), else_clause=Integer(min_value=0))
    try:
        y.validate(-5)
    except Exception as e:
        assert e.args[0] == 'must be at least 0'
    assert y.validate(5) == 5



# Generated at 2022-06-12 15:28:55.600890
# Unit test for method validate of class Not
def test_Not_validate():
    class IntField(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            return int(value)

    Not(IntField()).validate("a")

# Generated at 2022-06-12 15:29:07.039793
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test normal case
    list_of_fields = [Field(name="field1"), Field(name="field2")]
    field = 'field1'
    one_of = OneOf(one_of=list_of_fields)
    value = one_of.validate(field)
    assert value == field
    # Test case where multiple fields are matched
    one_of = OneOf(one_of=[Field(), Field()])
    try:
        # Should raise ValidationError
        one_of.validate(field)
    except Exception as e:
        assert isinstance(e, one_of.validation_error)
        assert isinstance(e, ValueError)




# Generated at 2022-06-12 15:29:08.636980
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    typesystem.fields.IfThenElse(typesystem.fields.Any(), typesystem.fields.Any())


# Generated at 2022-06-12 15:29:15.235675
# Unit test for method validate of class Not
def test_Not_validate():
    from . import BaseField
    from . import Boolean
    from . import String
    from . import Integer
    
    f = BaseField(String(max_length=20))
    f1 = BaseField(Integer())
    f2 = Not(f.validate(True))
    f3 = Not(f1.validate(1))
    assert f2.validate(True)
    assert f3.validate(1)

# Generated at 2022-06-12 15:29:25.527943
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause = Union(fields = [
            String(min_length = 3, max_length = 5),
            Integer(min_value = 1, max_value = 3)
        ]),
        then_clause = String(min_length = 2, max_length = 10),
        else_clause = Integer(min_value = 3, max_value = 8)
    )
    assert field.validate("abc", strict = True) == "abc"
    assert field.validate("abc", strict = False) == "abc"
    assert field.validate("abcde", strict = True) == "abcde"
    assert field.validate("abcde", strict = False) == "abcde"

# Generated at 2022-06-12 15:29:27.863763
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Integer())
    value = 'hi'
    field.validate(value)
    assert value == 'hi'


# Generated at 2022-06-12 15:29:31.018358
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Checks whether the validate method of class Not
    indeed validates the value.
    """
    # Initializing a dictionary
    dictionary = {
        "key1" : 1,
        "key2" : 2
    }

    # Initializing Not object
    not_obj = Not(negated = Any())

    # Asserting the value
    assert not_obj.validate(dictionary) == dictionary

# Generated at 2022-06-12 15:29:37.830680
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    val = "a"
    assert 3 == IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field(default=3)).validate(val)


# Generated at 2022-06-12 15:29:41.434432
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import Boolean

    int_field = IfThenElse(if_clause=Boolean(), then_clause=Boolean(), else_clause=Integer())

    assert int_field.validate(True) == True
    assert int_field.validate(False) == 0

# Generated at 2022-06-12 15:29:42.376973
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-12 15:29:45.217099
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    assert field.validate('a') == 'a'
    try:
        field.validate(1)
    except ValidationError as e:
        assert e.code == 'negated'


# Generated at 2022-06-12 15:29:47.537923
# Unit test for method validate of class Not
def test_Not_validate():
    obj = Not(Field())
    assert obj.validate(1) == 1


# Generated at 2022-06-12 15:29:55.206229
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    error=""
    value=""
    value2=""
    try:
        if_clause = String(pattern="\d+")
        else_clause = String(pattern="\s+")
        then_clause = String(pattern="\w+")
        value = IfThenElse(if_clause,else_clause,then_clause).validate(123)
        value2 = IfThenElse(if_clause,else_clause,then_clause).validate("abc ")
    except Exception as e:
        error=str(e)

    assert error == ""
    assert value == 123
    assert value2 == "abc "

# Generated at 2022-06-12 15:29:57.341358
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=None, then_clause=None, else_clause=None, allow_null=False)
    assert field



# Generated at 2022-06-12 15:30:01.900202
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    first = int(3)
    second = str('hello')
    assert IfThenElse(3, then_clause = second).validate(first) == 'hello'

# test for method validate_or_error of class IfThenElse

# Generated at 2022-06-12 15:30:03.306652
# Unit test for constructor of class AllOf
def test_AllOf():
  assert AllOf(one_of = [])


# Generated at 2022-06-12 15:30:05.224796
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True)


# Generated at 2022-06-12 15:30:18.781655
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Config:
        pass
    config = Config()
    config.email = 'test'
    config.test = True
    config.boolean = False
    IfThenElse(
        if_clause=Boolean(required=True),
        then_clause=Email(),
        else_clause=String(max_length=3),
        required=True
    ).validate(config.test)
    assert config.email == 'test'
    IfThenElse(
        if_clause=Boolean(required=True),
        then_clause=Email(),
        else_clause=String(max_length=3),
        required=True
    ).validate(config.boolean)
    assert config.test == 'tes'

# Generated at 2022-06-12 15:30:22.516820
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    for case in CASES:
        with pytest.raises(field.validation_error):
            field.validate(case["valid"])


# Generated at 2022-06-12 15:30:30.383309
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    one_of = OneOf([String(max_length=5), String(max_length=3)])
    one_of.validate("1234")
    one_of.validate("123")
    one_of.validate("1")
    with pytest.raises(one_of.validation_error) as e:
        one_of.validate("1234567")
        assert e.json_schema.get("errors") == ["no_match"]


# Generated at 2022-06-12 15:30:37.987224
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Array(items=Integer)
    then_clause = Array(items=String)
    else_clause = Array(items=Number)

    value1 = ["1", "2", "3"]
    value2 = [1, 2, 3]

    print(IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause).validate(value1))
    print(IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause).validate(value2))


test_IfThenElse_validate()

# Generated at 2022-06-12 15:30:41.783017
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(None,None,None,None)
    assert IfThenElse(Field(None,None),Field(None,None),Field(None,None),None)
 

# Generated at 2022-06-12 15:30:50.967228
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # create a schema for test
    schema = IfThenElse(
        if_clause=Number(gt=-1),
        then_clause=String(),
        else_clause=Number(lt=-1)
    )

    # the results should be true, cause the test cases are in schema
    assert schema.validate(-1) == -1
    assert schema.validate(-2) == -2
    assert schema.validate(-3) == -3

    # the results should be false, cause the test cases are out of schema
    assert schema.validate(0) == 0
    assert schema.validate(1) == 1
    assert schema.validate(2) == 2
    assert schema.validate(10) == 10


# Generated at 2022-06-12 15:30:51.966020
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()


# Generated at 2022-06-12 15:30:53.750638
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import String, Number
    from typesystem.fields import Boolean

    String()
    Number()
    Boolean()

# Generated at 2022-06-12 15:31:01.547290
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IPField(Field):
        errors = {"ip": "Invalid IP Address."}

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            import re
            if re.match(r"^(\d{1,3}.){3}\d{1,3}$", value):
                return value
            else:
                raise self.validation_error("ip")
    
    ip1 = '123.123.123.123'
    ip2 = '123.456.789.012'

    ifField = IfThenElse(IPField(), IPField(), IPField())
    ifField.validate(ip1)
    try:
        ifField.validate(ip2)
    except Exception as e:
        assert e.args[0] == 'Invalid IP Address.'

# Generated at 2022-06-12 15:31:07.894260
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Not(Any()), then_clause=Any(), else_clause=Int(1, 5))
    assert field.validate("a") == 3
    assert field.validate("x") == 1
    assert field.validate("a") == 1
    assert field.validate("a") == 1.2

If = IfThenElse

# Generated at 2022-06-12 15:31:11.570285
# Unit test for constructor of class AllOf
def test_AllOf():
    x = AllOf([])
    assert x

# Generated at 2022-06-12 15:31:18.282668
# Unit test for constructor of class Not
def test_Not():
    schema = Not(String(max_length=10))
    assert schema.negated == String(max_length=10)
    assert schema.errors == {'negated': 'Must not match.'}
    assert schema.description is None
    assert not schema.name
    assert schema.format is None
    assert schema.default == Not.default
    assert schema.required is False
    assert schema.serialized_name == Not.serialized_name
    assert schema.match_none is False
    assert schema.allow_null is False
    assert not schema.empty
    assert schema.any is False
    assert schema.on_unknown == Not.on_unknown
    assert schema.options == Not.options
    assert schema.type_options == Not.default_type_options



# Generated at 2022-06-12 15:31:21.082500
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    fields_list = [Number(maximum=2), Number(minimum=1), Number(maximum=3)]
    assert IfThenElse(*fields_list, *[1]).validate(1) == 1

# Generated at 2022-06-12 15:31:27.899210
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate for class OneOf
    import unittest
    from unittest.mock import Mock
    from unittest.mock import patch
    from typesystem import Schema

    from .mock.error import Error
    from .mock.json import JSON

    empty = type("Empty", tuple(), {})

    class Test(Schema):
        field = OneOf([Integer(1), Integer(2)])

    # Check that one of two numbers works
    error, result = Test().validate_or_error({"field": 1})
    assert not error

    error, result = Test().validate_or_error({"field": 2})
    assert not error

    # Check that the wrong numbers don't work
    error, result = Test().validate_or_error({"field": 3})
    assert error
   

# Generated at 2022-06-12 15:31:35.918960
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Any()])
    with pytest.raises(Field.validation_error) as exc_info:
        field.validate(value=42)
    assert exc_info.value.args[0] == 'no_match'

    field = OneOf(one_of=[NeverMatch()])
    with pytest.raises(Field.validation_error) as exc_info:
        field.validate(value=42)
    assert exc_info.value.args[0] == 'no_match'


# Generated at 2022-06-12 15:31:36.297021
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-12 15:31:36.984858
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field is not None


# Generated at 2022-06-12 15:31:41.123340
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String

    class AllOf(Field):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.all_of = all_of

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            for child in self.all_of:
                child.validate(value, strict=strict)
            return value

    field = OneOf([String(), AllOf([String(), String()], default='my default')], default='my default')
    


# Generated at 2022-06-12 15:31:50.187344
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    o1 = OneOf([Int()], allow_null=False)
    assert o1.validate(1) == 1
    assert o1.validate(1.5) == 1.5
    try:
        o1.validate(1.5, strict=True)
        raise AssertionError()
    except ValueError:
        pass
    o1.to_primitive(1)
    o1.to_primitive(1.5)
    try:
        o1.to_primitive(1.5, strict=True)
        raise AssertionError()
    except ValueError:
        pass
    assert o1.get_json_schema() == {"anyOf": [{"type": "integer"}, {"type": "number"}]}

# Generated at 2022-06-12 15:31:52.862578
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String(max_length=10))
    not_field.validate("something")
    try:
        not_field.validate("more than ten characters")
    except Exception as e:
        assert True



# Generated at 2022-06-12 15:31:57.372150
# Unit test for constructor of class AllOf
def test_AllOf():
    obj = AllOf(all_of=[])
    assert obj != None

# Generated at 2022-06-12 15:32:06.662796
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    try:
        testfield = IfThenElse(
            if_clause=Integer(), then_clause=Integer(), else_clause=String()
        )
        testvalue = "test123"
        testfield.validate(testvalue)
        print("test_IfThenElse_validate_1 passed")
        print("test_IfThenElse_validate_2 passed")
        print("test_IfThenElse_validate_3 passed")
    except Exception:
        print("test_IfThenElse_validate_1 failed")

# Generated at 2022-06-12 15:32:07.430891
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()

# Generated at 2022-06-12 15:32:12.952625
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    tester = IfThenElse(if_clause=Any(), then_clause=Any())
    assert tester.validate(5) == 5
    assert tester.validate(5.8) == 5.8
    assert tester.validate('String') == 'String'
    assert tester.validate([6, 7, 8]) == [6, 7, 8]
    assert tester.validate({'key': 'value'}) == {'key': 'value'}
    assert tester.validate(True) == True
    assert tester.validate(None) == None

    tester = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert tester.validate(5) == 5
    assert tester.validate(5.8) == 5

# Generated at 2022-06-12 15:32:23.154614
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Mock()
    then_clause = Mock()
    else_clause = Mock()
    obj = IfThenElse(if_clause, then_clause, else_clause)

    # validates then_clause
    value = MagicMock()
    if_clause.validate_or_error.return_value = True, None
    assert obj.validate(value) is then_clause.validate.return_value
    then_clause.validate.assert_called_once_with(value, False)

    # validates else_clause
    value = MagicMock()
    if_clause.validate_or_error.return_value = False, Exception
    assert obj.validate(value) is else_clause.validate.return_value
    else_clause.valid

# Generated at 2022-06-12 15:32:25.084595
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer

    assert OneOf(one_of=[Integer(maximum=3), Integer(minimum=2)]).validate(2) == 2
    assert OneOf(one_of=[Integer(maximum=3), Integer(minimum=2)]).validate(3) == 3



# Generated at 2022-06-12 15:32:28.343574
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch(), else_clause=NeverMatch())
    error = None
    try:
        x.validate()
    except ValidationError as e:
        error = e
    assert error.path == []
    assert error.code == 'negated'
    assert error.message == "Must not match."

# Generated at 2022-06-12 15:32:33.197301
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Field(), then_clause=Field())
    assert field.validate(value={}, strict=False) == values
    with pytest.raises(ValidationError):
        field.validate(value={}, strict=True)

# Generated at 2022-06-12 15:32:33.820714
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert 1 == 2

# Generated at 2022-06-12 15:32:41.652598
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test1 = {
        "two": 2,
        "three": 3
    }
    test2 = {
        "two": 2,
        "three": 3
    }
    test3 = {
        "two": 2,
        "three": 2
    }
    test4 = {
        "two": 2,
        "three": 3
    }
    test5 = {
        "two": 2,
        "three": 3
    }
    test6 = {
        "two": 2,
        "three": 3
    }
    test7 = {
        "two": 2,
        "three": 3,
        "four": []
    }
    test8 = {
    }

# Generated at 2022-06-12 15:32:50.936433
# Unit test for constructor of class AllOf
def test_AllOf():
    import json
    from typesystem import Structure, String, Array
    # get str of list with indent
    def str_of_list(lst, indent=4):
        return json.dumps(lst, indent=indent)
    a = String()
    b = String()
    c = String()
    s = Structure(a = AllOf([Array(a),Array(b),Array(c)]))
    assert s.validate([1,2,3]) == [1,2,3]

# Generated at 2022-06-12 15:33:01.318119
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # test when match_count=1
    # Arrange
    one_of_field = OneOf([Field()])
    value = 'abc'
    strict = True
    expected = value

    # Act
    actual = one_of_field.validate(value, strict)
    print("actual is : ", actual)

    # Assert
    assert actual==expected

     # test when match_count>1
    # Arrange
    one_of_field = OneOf([Field(), Field()])
    value = 'abc'
    strict = True
    expected = "Matched more than one type."

    # Act
    try:
        actual = one_of_field.validate(value, strict)
    except Exception as e:
        actual = e.args[0]
        print("actual is : ", actual)

    # Assert

# Generated at 2022-06-12 15:33:08.333369
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(int)
    assert ite.then_clause.get_primitive_type() == Any.get_primitive_type()
    assert ite.else_clause.get_primitive_type() == Any.get_primitive_type()

    ite = IfThenElse(int, int)
    assert ite.then_clause.get_primitive_type() == int
    assert ite.else_clause.get_primitive_type() == Any.get_primitive_type()

    ite = IfThenElse(int, int, int)
    assert ite.then_clause.get_primitive_type() == int
    assert ite.else_clause.get_primitive_type() == int

# Generated at 2022-06-12 15:33:11.348165
# Unit test for method validate of class Not
def test_Not_validate():
    from .integer import Integer
    schema = Not(Integer())
    assert schema.validate(2) is not None


# Generated at 2022-06-12 15:33:16.641751
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ifField = String()
    thenField = String()
    elseField = Int()
    result = IfThenElse(if_clause = ifField, then_clause = thenField, else_clause = elseField)

    # Tests for attributes
    assert result.if_clause == ifField
    assert result.then_clause == thenField
    assert result.else_clause == elseField

# Generated at 2022-06-12 15:33:17.608077
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass # TODO: implement your test here



# Generated at 2022-06-12 15:33:18.232038
# Unit test for method validate of class Not
def test_Not_validate():
    pass

# Generated at 2022-06-12 15:33:21.721010
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Field())
    assert isinstance(not_field, Not)
    assert not_field.negated == Field()
    assert not_field.errors == {"negated": "Must not match."}



# Generated at 2022-06-12 15:33:22.934960
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.allow_null is False



# Generated at 2022-06-12 15:33:29.203713
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestCondition(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return len(value) % 2 == 0

    class TestThen(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return int(value)

    class TestElse(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "Even"

    ifthenelse = IfThenElse(TestCondition(), TestThen(), TestElse())
    assert ifthenelse.validate(23) == "Even"
    assert ifthenelse.validate(24) == 24

# Generated at 2022-06-12 15:33:36.454164
# Unit test for method validate of class Not
def test_Not_validate():
    # ValueError should be raised if the value is Null
    negated = NeverMatch()
    not_match = Not(negated)
    try:
        not_match.validate(None)
    except ValueError:
        pass
    else:
        print("Not value is Null, ValueError should be raised.")
    # ValueError should not be raised if the value is not Null
    not_match.validate(1)


# Generated at 2022-06-12 15:33:37.803976
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.validate(123)


# Generated at 2022-06-12 15:33:39.488476
# Unit test for constructor of class AllOf
def test_AllOf():
    # Initialize a AllOf object
    test = AllOf([Any()])
    assert test



# Generated at 2022-06-12 15:33:41.164968
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    global f
    f = NeverMatch()
    # test for type of f
    assert type(f) == NeverMatch


# Generated at 2022-06-12 15:33:44.581334
# Unit test for constructor of class Not
def test_Not():
    not_valid_field = Not(None)
    assert not_valid_field.negated == None
    assert not_valid_field.errors == {
        "negated": "Must not match."
    }



# Generated at 2022-06-12 15:33:50.912866
# Unit test for method validate of class Not
def test_Not_validate():
    Not_field = Not(Boolean(), **{"description": "Comment"})
    with pytest.raises(ValidationError) as data:
        Not_field.validate(True, strict=False)
    assert data.value.detail["loc"][0] == "Comment"
    assert data.value.detail["loc"][1] == "Not"
    assert data.value.detail["loc"][2] == "negated"


# Generated at 2022-06-12 15:33:52.146305
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_obj = AllOf(all_of=[])

# Generated at 2022-06-12 15:33:53.056525
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    t: NeverMatch = NeverMatch()


# Generated at 2022-06-12 15:34:00.939911
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(AllOf([Str(), Int()]))
    assert field.validate("a") == "a"
    assert field.validate(1) == 1
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate(None) is None
    assert field.validate("a", strict=True) == "a"
    assert field.validate(1, strict=True) == 1
    assert field.validate(False, strict=True) == False
    assert field.validate([], strict=True) == []
    assert field.validate(None, strict=True) is None



# Generated at 2022-06-12 15:34:02.182374
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x.validate() is None


# Generated at 2022-06-12 15:34:07.525051
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_NeverMatch_1 = NeverMatch()
    assert isinstance(test_NeverMatch_1.errors, dict)
    assert test_NeverMatch_1.errors == {"never": "This never validates."}
    assert test_NeverMatch_1.allow_null is False


# Generated at 2022-06-12 15:34:08.298742
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()



# Generated at 2022-06-12 15:34:09.062759
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  pass


# Generated at 2022-06-12 15:34:15.486036
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # assert True, "Tests not implemented."
    print("Unit test for constructor of class NeverMatch")
    
    with pytest.raises(AssertionError):
        new_NeverMatch = NeverMatch(allow_null = True)
    with pytest.raises(AssertionError):
        new_NeverMatch = NeverMatch(allow_null = False)
    with pytest.raises(AssertionError):
        new_NeverMatch = NeverMatch()
    return


# Generated at 2022-06-12 15:34:22.909338
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class Int(Field):
        def __init__(self,**kwargs:typing.Any):
            super().__init__(**kwargs)
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if type(value) is not int:
                raise self.validation_error("not_int")
            return value
    if_clause = Int(description="Even number")
    then_clause = Int(description="Should be even")
    else_clause = Int(description="Should be odd")
    condition = IfThenElse(if_clause, then_clause, else_clause)
    try:
        condition.validate(1)
    except ValueError as e:
        assert str(e).find("Should be odd") >= 0

# Generated at 2022-06-12 15:34:24.861501
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    new_inst = OneOf([Field('apples'), Field('bananas')])
    result = new_inst.validate('apples')
    assert result == 'apples'


# Generated at 2022-06-12 15:34:30.837548
# Unit test for constructor of class OneOf
def test_OneOf():
    print('Testing OneOf...', end='')
    f1 = OneOf([Boolean()])
    assert f1.validate(True)
    assert f1.validate(True) == True
    assert f1.validate(False) == False
    assert f1.validate(False) == False
    assert f1.validate(1) is None
    assert f1.validate(1.0) is None
    assert f1.validate('') is None
    assert f1.validate('a') is None
    assert f1.validate([]) is None
    assert f1.validate({}) is None

    f2 = OneOf([Integer()])
    assert f2.validate(1) == 1
    assert f2.validate(1.0) == 1
    assert f2.validate

# Generated at 2022-06-12 15:34:40.222989
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import math

    ife = IfThenElse(
        if_clause=Integer(),
        then_clause=Integer(minimum=10),
        else_clause=Integer(maximum=0),
    )

    for value in [-100, -1, -math.inf, 0.0, -0.0, 1, 10, math.inf, "hello"]:
        assert ife.validate(value) ==  value

    for value in [2, 3, 4, 5, 6, 7, 8, 9, -2, -3, -4, -5, -6, -7, -8, -9, "hello world"]:
        with pytest.raises(ife.validation_error):
            ife.validate(value)

# Generated at 2022-06-12 15:34:41.555790
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-12 15:34:45.392563
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    obj = OneOf([Field()])
    obj.validate(123)
    obj.validate(True)

    obj = OneOf([Field(), Field()])
    obj.validate(123)
    obj.validate(True)

    obj = OneOf([Field(), Field(), Field()])
    obj.validate(123)
    obj.validate(True)

    # TODO: add more tests here



# Generated at 2022-06-12 15:34:58.659292
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf(
        [
            {
                "type": "object",
                "properties": {
                    "foo": {"type": "string"},
                    "bar": {"type": "integer"},
                },
            },
            {"type": "integer"},
        ]
    )
    # should be OK
    one_of_field.validate(123)
    one_of_field.validate({"foo": "a", "bar": 1})

    with raises(TypeError):
        # should raise TypeError because no_match
        one_of_field.validate("abc")

    with raises(TypeError):
        # should raise TypeError because multiple_matches
        one_of_field.validate({"foo": "a", "bar": 1, "baz": "d"})


# Unit

# Generated at 2022-06-12 15:35:00.128605
# Unit test for constructor of class AllOf
def test_AllOf():
    # Given
    item = AllOf([])

    # Then
    assert item is not None


# Generated at 2022-06-12 15:35:03.550593
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(int, int)
    expected = 1
    actual = x.validate(1)
    assert actual == expected
    y = IfThenElse(int, int)
    expected = 1.0
    actual = y.validate(1.0)
    assert actual == expected 
    print("IfThenElse.validate() test passed")

# Generated at 2022-06-12 15:35:14.626063
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class MyInt(Field):
        def validate(self, value, strict):
            return int(value)

    class MyFloat(Field):
        def validate(self, value, strict):
            return float(value)

    one_of_list = [MyInt(), MyFloat()]
    OneOf(one_of_list).validate("1")
    OneOf(one_of_list).validate("1.0")
    try:
        OneOf(one_of_list).validate("1.1")
        assert False
    except ValidationError:
        pass
    try:
        OneOf(one_of_list).validate("foo")
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-12 15:35:16.873083
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {'never': 'This never validates.'}


# Generated at 2022-06-12 15:35:18.337094
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Any())
    assert not_field.negated is not None


# Generated at 2022-06-12 15:35:19.777418
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(Exception):
        field = NeverMatch(nullable=True)



# Generated at 2022-06-12 15:35:21.826703
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = []

    AllOf(all_of)



# Generated at 2022-06-12 15:35:23.247440
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # TODO: Add your test case below.
    pass


# Generated at 2022-06-12 15:35:24.676374
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated="test")
    assert not_field.negated == "test"


# Generated at 2022-06-12 15:35:38.735958
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Create an instance of class NeverMatch
    never_match = NeverMatch()
    # Test fail to create an instance of class NeverMatch
    # Create an instance of class NeverMatch with unknown parameter
    try:
        never_match = NeverMatch(unknown_parameter=1)
    except TypeError as e:
        assert e.args[0] == "'unknown_parameter' is an invalid keyword argument for this function"



# Generated at 2022-06-12 15:35:40.046351
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf



# Generated at 2022-06-12 15:35:41.234267
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])



# Generated at 2022-06-12 15:35:43.200724
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    # Create a new instance of OneOf
    x = OneOf(one_of=[])

    # Invoke method validate of x
    x.validate()



# Generated at 2022-06-12 15:35:52.580638
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_field = Dict(properties={"A": Int(), "B": Int()})
    then_field = Dict(properties={"C": Int(), "D": Int()})
    else_field = Dict(properties={"E": Int(), "F": Int()})
    valid_input = {"A": 2, "B": 3}
    valid_input_2 = {"E": 2, "F": 3}
    assert IfThenElse(if_field, then_field, else_field).validate(valid_input) == valid_input
    assert IfThenElse(if_field, then_field, else_field).validate(valid_input_2) == valid_input_2
    invalid_input = {"A": "a", "B": "b", "C": "c", "D": "d"}
    assert IfThenElse

# Generated at 2022-06-12 15:35:53.926796
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[])


# Generated at 2022-06-12 15:35:54.784093
# Unit test for constructor of class OneOf
def test_OneOf():
    assert one_of is not None


# Generated at 2022-06-12 15:36:01.356769
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # create IfThenElse object
    oz = IfThenElse(
        if_clause=Integer(),
        then_clause=Integer(),
        else_clause=String()
    )

    assert oz.validate(1) == 1
    assert oz.validate("1") == "1"
    # create IfThenElse object with no then_clause
    oz = IfThenElse(
        if_clause=Integer(),
        else_clause=String()
    )

    assert oz.validate(1) == 1
    assert oz.validate("1") == "1"
    # create IfThenElse object with no else_clause
    oz = IfThenElse(
        if_clause=Integer(),
        then_clause=Integer()
    )

    assert oz.validate(1) == 1
    assert oz

# Generated at 2022-06-12 15:36:04.033186
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.validators import MinLengthValidator

    # Check that the constructor works for an instance with valid data
    Not(negated = String(validators=[MinLengthValidator(1)]))


# Generated at 2022-06-12 15:36:06.194392
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(None) is None


# Generated at 2022-06-12 15:36:22.419285
# Unit test for constructor of class AllOf
def test_AllOf():
    x = AllOf([], description="abc")
    assert x.description == "abc"


# Generated at 2022-06-12 15:36:26.848623
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field1 = String()
    field2 = Integer()
    one_of_field = OneOf([field1, field2])
    try:
        one_of_field.validate("hello")
        assert False
    except FieldValidationError as e:
        assert e.code == "multiple_matches"
    try:
        one_of_field.validate(2)
        assert False
    except FieldValidationError as e:
        assert e.code == "multiple_matches"
    try:
        one_of_field.validate(2.2)
        assert False
    except FieldValidationError as e:
        assert e.code == "no_match"


test_OneOf_validate()

# Generated at 2022-06-12 15:36:28.741794
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.errors["never"] == "This never validates."
    assert a.options["never"] == "This never validates."


# Generated at 2022-06-12 15:36:32.926837
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Any()
    then_clause = AllOf([Boolean(), DateTime()])
    else_clause = AllOf([Boolean(), Number()])
    ite = IfThenElse(if_clause,then_clause,else_clause)
    assert ite.validate(1) == 1
    assert ite.validate(True) == True

# Generated at 2022-06-12 15:36:35.041847
# Unit test for constructor of class OneOf
def test_OneOf():
    t = OneOf([String()])
    print("t is {} ".format(t))


if __name__ == "__main__":
    test_OneOf()

# Generated at 2022-06-12 15:36:37.194831
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__init__(None, [Any()], title='oneOf')

# Generated at 2022-06-12 15:36:38.203213
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[Field()])

# Generated at 2022-06-12 15:36:39.411363
# Unit test for constructor of class Not
def test_Not():
   test=Not(Any())
   assert test is not None


# Generated at 2022-06-12 15:36:41.359285
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([int, float])
    return one_of.validate(1)


# Generated at 2022-06-12 15:36:43.853902
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  field = NeverMatch()
  assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:37:15.444471
# Unit test for constructor of class OneOf
def test_OneOf():
    # str = "1"
    assert OneOf(["1", "2"].__init__([Field(), Field()])) == "1", "Not OneOf"

# Generated at 2022-06-12 15:37:19.982412
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    a = IfThenElse(if_clause,then_clause,else_clause)
    a.validate(1)# Can't assert without returning value

# Generated at 2022-06-12 15:37:25.851285
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # implicit constructor
    test_validate = IfThenElse(if_clause=String())
    assert test_validate.validate("a") == "a"

    # implicit constructor 2
    test_validate = IfThenElse(if_clause=String(), then_clause=Number(), else_clause=Number())
    assert test_validate.validate("a") == 1
    assert test_validate.validate(10) == 10
    
    # explicit constructor
    test_validate = IfThenElse(if_clause=String(max_length=10), then_clause=Number(), else_clause=Number())
    assert test_validate.validate("a") == 1
    assert test_validate.validate(10) == 10

# Generated at 2022-06-12 15:37:28.472044
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String

    class MyOneOf(OneOf):
        pass

    x = MyOneOf(one_of=[String()])
    assert x


# Generated at 2022-06-12 15:37:30.249114
# Unit test for constructor of class Not
def test_Not():
    not_test = Not(Any())
    assert not_test.negated is not None

# Generated at 2022-06-12 15:37:38.657612
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String

    class UserEmail(String):
        def validate(self, value, strict=False):
            if value != "test@test.com":
                raise self.validation_error("email")

    class UserName(String):
        def validate(self, value, strict=False):
            if value != "test_name":
                raise self.validation_error("name")

    class User(IfThenElse):
        def __init__(self, user_type):
            self.user_type = user_type

        def if_clause(self, value):
            if value == "person":
                return UserEmail()
            else:
                return UserName()

        def then_clause(self, value):
            return value


# Generated at 2022-06-12 15:37:39.724055
# Unit test for constructor of class Not
def test_Not():
    assert 'negated' in Not.errors

# Generated at 2022-06-12 15:37:41.122716
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__init__ is not Field.__init__


# Generated at 2022-06-12 15:37:44.297779
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause = AllOf ([NeverMatch(), NeverMatch()]),
        then_clause = AllOf ([NeverMatch(), NeverMatch()]),
        else_clause = AllOf ([NeverMatch(), NeverMatch()])
    )
    field.validate()


# Generated at 2022-06-12 15:37:45.458339
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Magnitude(), else_clause=Not(Any())).validate(0) == 0
    


# Generated at 2022-06-12 15:38:08.154124
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem import types

    # test with 2 types
    field = OneOf([String(), Integer()], name="test")
    assert field.one_of[0].__class__.__name__ == "String"
    assert field.one_of[1].__class__.__name__ == "Integer"
    assert field.name == "test"
    # test with 3 types
    field = OneOf([String(), Integer(), types.Boolean()], name="test")
    assert field.one_of[0].__class__.__name__ == "String"
    assert field.one_of[1].__class__.__name__ == "Integer"
    assert field.one_of[2].__class__.__name__ == "Boolean"

# Generated at 2022-06-12 15:38:10.090573
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Number, String

    assert OneOf([Number(), String()], description="one of number or string")


# Generated at 2022-06-12 15:38:12.113753
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String

    assert AllOf([String()])


# Generated at 2022-06-12 15:38:17.205689
# Unit test for constructor of class OneOf
def test_OneOf():
  one_of_list = [String()]
  one_of_field = OneOf(one_of_list)
  assert one_of_field.one_of == one_of_list
  assert one_of_field.errors["no_match"] == "Did not match any valid type."
  assert one_of_field.errors["multiple_matches"] == "Matched more than one type."


# Generated at 2022-06-12 15:38:18.711174
# Unit test for constructor of class Not
def test_Not():
    test_field = Not(negated = Field())
    assert test_field.negated == Field()


# Generated at 2022-06-12 15:38:21.155623
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [
        Int(),
        String(),
        Float(),
        Dict({"a": Number, "b": Number}, additional_properties=False)
    ]
    obj = AllOf(all_of)
    assert obj.all_of == all_of


# Generated at 2022-06-12 15:38:22.296129
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = None
    one_of = OneOf(one_of)


# Generated at 2022-06-12 15:38:23.117254
# Unit test for constructor of class AllOf
def test_AllOf():
    test_field = AllOf([])
    assert test_field != None


# Generated at 2022-06-12 15:38:24.837116
# Unit test for constructor of class AllOf
def test_AllOf():
    # Arrange
    some_fields = [Field, Any, NeverMatch]

    # Act
    result = AllOf(some_fields)

    # Assert
    assert result.all_of == some_fields


# Generated at 2022-06-12 15:38:27.533053
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([String(min_length=1)], label='A')
    assert a.label == 'A'