

# Generated at 2022-06-12 15:28:49.322382
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String

    if_clause = String()
    then_clause = String()
    else_clause = String()

    field = IfThenElse(if_clause, then_clause, else_clause)
    value = 'Hello World'

    ret = field.validate(value, True)
    assert ret == value


# Generated at 2022-06-12 15:28:53.064478
# Unit test for constructor of class AllOf
def test_AllOf():
    class A(Field):
        pass

    class B(Field):
        pass

    test = AllOf([A(), B()])
    assert test.all_of == [A(), B()]

# Generated at 2022-06-12 15:29:00.803663
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import typesystem

    class TestSchema(typesystem.Schema):
        oneof = typesystem.OneOf(
            one_of=[typesystem.String(), typesystem.Boolean()]
        )

    schema = TestSchema()
    # try with a boolean value
    schema.validate({"oneof": False})
    schema.validate({"oneof": True})

    # try with a string type
    schema.validate({"oneof": ""})
    schema.validate({"oneof": " "})

    # try with a number type
    try:
        schema.validate({"oneof": 0})
    except typesystem.ValidationError as ve:
        if ve.error_code != "no_match":
            raise

# Generated at 2022-06-12 15:29:03.619402
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate("mystring") == "mystring"
    #fail
    assert field.validate("mystring") == "mystring_fail"

# Generated at 2022-06-12 15:29:05.838929
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    field = Not(String())
    assert field.negated.__class__.__name__ == 'String'


# Generated at 2022-06-12 15:29:17.357575
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.tests.testcases import DummyRequests

    if_clause = String(max_length=10)
    then_clause = String(max_length=8)
    else_clause = String(max_length=16)

    ite = IfThenElse(if_clause, then_clause, else_clause)
    assert ite.validate("12345678") == "12345678"

    if_clause = String(max_length=10)
    then_clause = String(max_length=8)

    ite = IfThenElse(if_clause, then_clause, else_clause)
    assert ite.validate("1234567890123456") == "1234567890123456"


# Generated at 2022-06-12 15:29:20.510628
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Any())
    assert len(not_field.errors) == 1
    assert not_field.errors == {"negated": "Must not match."}

# Generated at 2022-06-12 15:29:28.102497
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field1 = typesystem.String(max_length=8)
    field2 = typesystem.String(max_length=8)
    field3 = typesystem.String(max_length=8)
    test = IfThenElse(field1, field2, field3)
    # Then clause validates
    assert test.validate("abcdefgh") == "abcdefgh"
    # Else clause validates
    assert test.validate("abcde") == "abcde"

# Generated at 2022-06-12 15:29:37.443353
# Unit test for constructor of class Not
def test_Not():
	f = types.Not(SimpleField(name = 'test'))
	f2 = types.Not(SimpleField(name = 'test2'))
	f3 = types.Not(SimpleField(name = 'test3'))
	f4 = types.Not(SimpleField(name = 'test4'))

	assert(f.negated is f.negated)
	assert(f.negated is not f2.negated)
	assert(f.negated is not f3.negated)
	assert(f.negated is not f4.negated)


# Generated at 2022-06-12 15:29:38.502172
# Unit test for constructor of class AllOf
def test_AllOf():
    f = AllOf([Boolean()])

# Generated at 2022-06-12 15:29:44.060653
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    not_null = IfThenElse(Any())
    assert not_null.validate("") == ""
    assert not_null.validate(1) == 1
    assert not_null.validate(True) == True


# Generated at 2022-06-12 15:29:46.076001
# Unit test for constructor of class Not

# Generated at 2022-06-12 15:29:46.995207
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch

# Generated at 2022-06-12 15:29:50.392460
# Unit test for constructor of class AllOf
def test_AllOf():
    # Unit test for constructor of class AllOf
    # Calling AllOf(all_of=[]) raises AssertionError
    with pytest.raises(AssertionError):
        AllOf(all_of=[])


# Generated at 2022-06-12 15:29:53.563301
# Unit test for method validate of class Not
def test_Not_validate():
    null_field = Not(Any())
    tester = null_field.validate("test_test")
    assert "test_test" == tester, "Not.validate() method should return value of variable tester"

# Generated at 2022-06-12 15:29:56.150757
# Unit test for constructor of class OneOf
def test_OneOf():
    # Create the class
    o1 = OneOf([])
    # Test default values were set correctly
    assert o1.one_of == []
    assert o1 not in o1.one_of
    

# Generated at 2022-06-12 15:29:57.549521
# Unit test for constructor of class Not
def test_Not():
    x = Not(negated="hello")
    assert x.negated == "hello"


# Generated at 2022-06-12 15:30:07.166578
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = "value"
    strict = True
    expected = Field()
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual is expected
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = "value"
    strict = False
    expected = Field()
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual is expected

# Generated at 2022-06-12 15:30:12.758641
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Boolean(),String()], name = 'test', description = 'testOneOf')

    # check if constructor worked correctly
    assert isinstance(field, OneOf)
    assert isinstance(field.one_of[0], Boolean)
    assert isinstance(field.one_of[1], String)


# Unit tests for validate OneOf

# Generated at 2022-06-12 15:30:14.604147
# Unit test for constructor of class AllOf
def test_AllOf():
    pass


# Generated at 2022-06-12 15:30:26.210460
# Unit test for method validate of class Not
def test_Not_validate():
    # Create objects for testing
    not_field = Not(Any())
    not_field2 = Not(Any())
    not_field3 = Not(Any())

    # Test method validate of class Not
    from typesystem.exceptions import ValidationError
    from copy import deepcopy
    assert not_field.validate(0) == 0
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(0.0) == 0.0
    assert not_field.validate('') == ''
    assert deepcopy(not_field.validate([])) == []
    assert deepcopy(not_field.validate({})) == {}
    assert not_field.validate({})

# Generated at 2022-06-12 15:30:27.963012
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-12 15:30:30.719561
# Unit test for method validate of class Not
def test_Not_validate():
    a = Not(Int())
    b = "Hello"
    assert a.validate(b) == b



# Generated at 2022-06-12 15:30:32.656446
# Unit test for method validate of class Not
def test_Not_validate():
    """
    This test is used to test method validate of class Not
    """
    f = Not(Type(int))
    assert f.validate(5)

# Generated at 2022-06-12 15:30:40.778268
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert(IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate("value") == "value")
    assert(IfThenElse(if_clause=NeverMatch(), then_clause=Any(), else_clause=Any()).validate("value") == "value")
    assert(IfThenElse(if_clause=Any(), then_clause=NeverMatch(), else_clause=Any()).validate("value") == "value")
    assert(IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=NeverMatch()).validate("value") == "value")
    assert(IfThenElse(if_clause=Any(), then_clause=NeverMatch(), else_clause=NeverMatch()).validate("value") == "value")

# Generated at 2022-06-12 15:30:42.823785
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print("Testing constructor of class NeverMatch")
    assert len(NeverMatch(description = "This never validates.").description) == 22


# Generated at 2022-06-12 15:30:43.842469
# Unit test for constructor of class Not
def test_Not():
    assert Not({})


# Generated at 2022-06-12 15:30:49.313706
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    
    # Add your code here.
    try:
        o = OneOf([String(), Integer()])
        o.validate("house")
    except Exception as e:
        print(e)
    try:
        o.validate(1)
    except Exception as e:
        print(e)
    try:
        o.validate(True)
    except Exception as e:
        print(e)

# Generated at 2022-06-12 15:30:51.407236
# Unit test for constructor of class OneOf
def test_OneOf():
    # Bad arguments
    try:
        OneOf()
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-12 15:30:53.053205
# Unit test for constructor of class OneOf
def test_OneOf():
    f1 = Field()
    f2 = Field()
    OneOf([f1, f2])



# Generated at 2022-06-12 15:31:00.199722
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Any, Array, Boolean, Choice, Integer, Number, Object, String
    from typesystem import Field, Invalid, Schema, String

    schema = Schema(fields={"test": OneOf([Boolean(), String()])})

    assert schema.validate({"test": False}) == {"test": False}
    assert schema.validate({"test": "Hello"}) == {"test": "Hello"}
    with pytest.raises(Invalid):
        schema.validate({"test": 1})



# Generated at 2022-06-12 15:31:10.975940
# Unit test for constructor of class OneOf
def test_OneOf():
    # Create fields for the oneof
    test_field=Field(name='test1')
    test2_field=Field(name='test2')
    test3_field=Field(name='test3')
    test4_field=Field(name='test4')
    # Create a list of the fields
    fields=[test_field,test2_field,test3_field]
    # Test if an error is raised if one_of is not a list
    try:
        test_oneof = OneOf(one_of=3)
    except AssertionError:
        assert True
    # Test if an error is raised if one_of is an empty list
    try:
        test_oneof = OneOf(one_of=[])
    except AssertionError:
        assert True
    # Test if an error is raised if there are

# Generated at 2022-06-12 15:31:12.171322
# Unit test for method validate of class Not
def test_Not_validate():
    schema = Not(String())
    schema.validate("some string")


# Generated at 2022-06-12 15:31:14.109522
# Unit test for constructor of class OneOf
def test_OneOf():
    field= OneOf([])
    assert field.errors=={'no_match':'Did not match any valid type.','multiple_matches':'Matched more than one type.'}

# Generated at 2022-06-12 15:31:22.085189
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf([
        Integer(),
        List(items=Integer()),
        Float()
    ])

    assert one_of_field.validate([2.0]) == [2.0]
    assert one_of_field.validate(2) == 2
    assert one_of_field.validate([2]) == [2]
    assert one_of_field.validate([2.0, 2.0]) == [2.0, 2.0]
    assert one_of_field.validate(2.0) == 2.0

    try:
        one_of_field.validate([1.0, 1])
    except Invalid as e:
        assert str(e) == 'multiple_matches'
    except Exception as e:
        assert False


# Generated at 2022-06-12 15:31:24.137055
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem import Composite
    a = NeverMatch()
    assert a.errors == {'never': 'This never validates.'}
    assert isinstance(a, Composite)


# Generated at 2022-06-12 15:31:25.533521
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-12 15:31:27.955183
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=None).validate(value=None) == None
    # pass


# Generated at 2022-06-12 15:31:29.017799
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass


# Generated at 2022-06-12 15:31:31.343962
# Unit test for method validate of class Not
def test_Not_validate():
    not_schema = Not(Email())
    not_schema.validate("lzf")

# Generated at 2022-06-12 15:31:35.562023
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-12 15:31:38.167010
# Unit test for method validate of class Not
def test_Not_validate():
    obj = Not(negated = IfThenElse(if_clause = NeverMatch(), then_clause = NeverMatch(), else_clause = NeverMatch()))
    assert obj.validate(value = 2) == 2

# Generated at 2022-06-12 15:31:41.770376
# Unit test for method validate of class Not
def test_Not_validate():
    _value = "aaaaaaaaa"
    not_field = Not("aaaaaaaaa", [])
    _, error = not_field.validate_or_error(_value, strict=True)
    assert error == "Must not match."


# Generated at 2022-06-12 15:31:44.450868
# Unit test for constructor of class AllOf
def test_AllOf():
    with pytest.raises(AssertionError, match = ".*allow_null.*"):
        a = AllOf(field, allow_null=True)


# Generated at 2022-06-12 15:31:47.107926
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Input: value = []
    # Output: False
    assert Field.validate(OneOf(one_of = [Field(), Field()]), value = []) == False

# Generated at 2022-06-12 15:31:54.982136
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class Address(Field):
        def __init__(self, address_1: str, address_2: str, city: str, state: str, zip_code: str, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.address_1 = address_1
            self.address_2 = address_2
            self.city = city
            self.state = state
            self.zip_code = zip_code

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            value = super().validate(value, strict=strict)

# Generated at 2022-06-12 15:31:59.044685
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated='a')
    assert not_field.validate('b') == 'b'
    try:
        assert not_field.validate('a')
        assert False
    except ValueError:
        assert True


# Generated at 2022-06-12 15:32:00.401256
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass


# Generated at 2022-06-12 15:32:02.537797
# Unit test for constructor of class Not
def test_Not():
    from typesystem import String, Number
    field = Not(Number())
    assert isinstance(field, Not)

    assert field.validate(1) is None
    assert isinstance(field.validate("a"), String)
    assert isinstance(field.validate("a"), String)


# Generated at 2022-06-12 15:32:05.665409
# Unit test for constructor of class AllOf
def test_AllOf():
    field1 = Field(name='f1')
    field2 = Field(name='f2')
    field_list = [field1, field2]
    allof_field = AllOf(field_list)

    assert allof_field.all_of == field_list



# Generated at 2022-06-12 15:32:16.744656
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    import uuid
    field_test_name = "NeverMatch"
    field_test_type = "Field"

    n = NeverMatch()

    assert n.name == None
    assert n.error_messages == {"never": "This never validates."}
    assert n.allow_null == False

    n = NeverMatch(name="NeverMatch")

    assert n.name == "NeverMatch"
    assert n.error_messages == {"never": "This never validates."}
    assert n.allow_null == False


# Generated at 2022-06-12 15:32:18.552259
# Unit test for constructor of class AllOf
def test_AllOf():
  assert len(AllOf.errors) == 0
  assert AllOf.errors is not None



# Generated at 2022-06-12 15:32:20.487696
# Unit test for constructor of class AllOf
def test_AllOf():
    allof = AllOf(list(range(1,10)));
    assert allof.all_of == list(range(1,10))

# Generated at 2022-06-12 15:32:28.498469
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = {"type": "boolean"}
    then_clause = {"type": "integer"}
    else_clause = {"type": "string"}
    ite1 = IfThenElse(if_clause, then_clause, else_clause)
    ite2 = IfThenElse(if_clause, then_clause)
    ite3 = IfThenElse(if_clause, else_clause=else_clause)
    ite4 = IfThenElse(if_clause)
    assert ite1.if_clause.as_primitive() == if_clause
    assert ite2.if_clause.as_primitive() == if_clause
    assert ite3.if_clause.as_primitive() == if_clause
    assert ite4.if_

# Generated at 2022-06-12 15:32:29.408118
# Unit test for constructor of class AllOf
def test_AllOf():
    s = AllOf([Field()])


# Generated at 2022-06-12 15:32:32.412941
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Int(), Str()], name='1').validate(100), 'error 1'


# Generated at 2022-06-12 15:32:36.687521
# Unit test for constructor of class Not
def test_Not():
    # Arrange
    # Act
    field = Not(Any())
    # Assert
    assert field is not None
    assert type(field) == Not
    assert field.negated is not None
    assert type(field.negated) == Any


# Generated at 2022-06-12 15:32:39.360206
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field_NeverMatch = NeverMatch(description="Doesn't ever match.")
    assert field_NeverMatch.description == "Doesn't ever match."
    assert field_NeverMatch.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:32:45.412265
# Unit test for method validate of class OneOf
def test_OneOf_validate(): # noqa
    # Remove if not used in your own unit tests.
    from typesystem.fields import String

    field = OneOf([String(), String()])
    value = field.validate("foo")
    value2 = field.validate("foo2")
    value3 = field.validate("foo3")
    assert "foo" == value
    assert "foo2" == value2
    assert "foo3" == value3

# Generated at 2022-06-12 15:32:47.003512
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        field = NeverMatch()
    except Exception as e:
        assert type(e) == AssertionError
        assert str(e) == "AssertionError"


# Generated at 2022-06-12 15:32:57.975686
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of = [Any(description="description")])
    assert field.one_of[0].description == "description" 


# Generated at 2022-06-12 15:32:59.543709
# Unit test for constructor of class Not
def test_Not():
    n = Not(negated=Any())
    assert n.negated == Any()

# Generated at 2022-06-12 15:33:05.126615
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Test method validate of class OneOf
    """
    # Create sample Field() object
    field = OneOf(["int", "float", "str"])

    # Get the output of method validate
    output, error = field.validate_or_error(5, strict=False)

    # Assert if the output is an integer
    assert (type(output) == int)

    # Assert if no error is thrown
    assert (error is None)


# Generated at 2022-06-12 15:33:06.087770
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a

# Generated at 2022-06-12 15:33:08.251417
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    except:
        assert False

# Generated at 2022-06-12 15:33:12.459905
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = OneOf([], title='title_1')
    try:
        a.validate(None)
    except Exception as e:
        assert(str(e) == 'no_match')
    
    

# Generated at 2022-06-12 15:33:22.778135
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # edge case: no match
    no_match = [NeverMatch()]
    try:
        OneOf(no_match).validate(None, strict=False)
        assert False, 'Expected ValidationError to be raised'
    except ValidationError as e:
        error_msg_dict = e.error_dict()
        assert len(error_msg_dict) == 1
        assert error_msg_dict['__root__'] == ['Did not match any valid type.']

    # edge case: multiple match
    multiple_match = [Field(),Field()]
    try:
        OneOf(multiple_match).validate(None, strict=False)
        assert False, 'Expected ValidationError to be raised'
    except ValidationError as e:
        error_msg_dict = e.error_dict()

# Generated at 2022-06-12 15:33:26.331062
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Integer(), String()])
    one_of.validate(10)
    one_of.validate('dd')

    try:
        one_of.validate(1.1)
    except Exception as e:
        assert e.args[0] == {'code': 'no_match', 'field': None}

# Generated at 2022-06-12 15:33:28.136784
# Unit test for constructor of class Not
def test_Not():
    def test_bad():
        Not("a")
    def test_good():
        Not(Any)

    test_bad()
    test_good()


# Generated at 2022-06-12 15:33:34.945127
# Unit test for constructor of class AllOf
def test_AllOf():
    import json
    import typesystem
    class AllOf(typesystem.Field):
        def __init__(self, all_of, **kwargs):
            super().__init__(**kwargs)
            self.all_of = all_of
    class NotEmpty(typesystem.Field):
        def validate(self, value, strict=True):
            if not value:
                self.fail("empty")
            return value
    class MinLength(typesystem.Field):
        def __init__(self, min_length, **kwargs):
            super().__init__(**kwargs)
            self.min_length = min_length
        def validate(self, value, strict=True):
            if len(value) < self.min_length:
                self.fail("min_length")
            return value

# Generated at 2022-06-12 15:33:53.953798
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Check if the validate() method of class OneOf is working properly.
    """
    one_of = OneOf([Integer(), Integer()])
    assert one_of.validate(5) == 5


# Generated at 2022-06-12 15:33:59.064984
# Unit test for constructor of class AllOf
def test_AllOf():
    # Create all of field
    all_of = AllOf([Dict({"x": Integer()}), Dict({"y": Integer()})])

    # Check if input dictionary passes
    assert all_of.validate({"x": 1, "y": 2}) == {"x": 1, "y": 2}

    # Check if error raised if input dictionary does not pass
    with pytest.raises(FieldError):
        all_of.validate({"x": 1})



# Generated at 2022-06-12 15:34:08.371511
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class IfThenElse_test(Field):
        def __init__(
            self,
            if_clause: Field,
            then_clause: Field = None,
            else_clause: Field = None,
            **kwargs: typing.Any
        ) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.if_clause = if_clause
            self.then_clause = Any() if then_clause is None else then_clause
            self.else_clause = Any() if else_clause is None else else_clause

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value


# Generated at 2022-06-12 15:34:18.038111
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    def test_OneOf_validate1():
        class Integer(Field):
            def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
                if type(value) != int:
                    raise self.validation_error(1)
                return value
        # write a unit test, where value = 0
        # no assertion
        # write a unit test, when value = 1
        # no assertion
        

    def test_OneOf_validate2():
        class Integer(Field):
            def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
                if type(value) != int:
                    raise self.validation_error(1)
                return value


# Generated at 2022-06-12 15:34:24.216060
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf(one_of=[Int(), Str()]).validate(1)
    assert OneOf(one_of=[Int(), Str()]).validate("abc")
    try:
        OneOf(one_of=[Int(), Str()]).validate(1.2)
    except Exception as e:
        assert e.args[0] == "Did not match any valid type."



# Generated at 2022-06-12 15:34:24.680063
# Unit test for constructor of class Not
def test_Not():
    assert Not

# Generated at 2022-06-12 15:34:27.586386
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Reminder: validate is a method of class OneOf
    # Arrange
    field = OneOf(
        one_of=[
            Field(),
        ]
    )
    value = [None]*1

    # Act
    with pytest.raises(ValueError):
        field.validate(
            value=value
        )



# Generated at 2022-06-12 15:34:31.652699
# Unit test for constructor of class Not
def test_Not():
    # Test for validations of field [if_clause]
    # Test for field [negated]
    with pytest.raises(AssertionError) as execinfo:
        Not(negated = "field_negated")
    assert "Field must be a Field, not: str" in str(execinfo.value)



# Generated at 2022-06-12 15:34:34.453538
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    
    assert one_of1.validate(1) == 1
    assert one_of4.validate(1) == 1



# Generated at 2022-06-12 15:34:35.366125
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Any())


# Generated at 2022-06-12 15:34:54.024281
# Unit test for constructor of class Not
def test_Not():
    expected = '{"negated": "Must not match."}'

    assert Not(negated = 0).errors == expected


# Generated at 2022-06-12 15:34:56.195858
# Unit test for constructor of class AllOf
def test_AllOf():
    def test_AllOf(all_of, kwargs):
        assert "allow_null" not in kwargs
        AllOf(all_of, **kwargs)



# Generated at 2022-06-12 15:35:02.959108
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from .test_schema import Athlete
    from .test_schema import Address
    from .test_schema import Schema
    
    schema = Schema([OneOf([Athlete, Address])])
    print(schema.validate([{"name": "john"}, {"name": "sarah", "sport": "basketball"}]))
    print(schema.validate([{"name": "john", "age": 8}, {"name": "sarah", "sport": "basketball"}]))
    print(schema.validate([{"name": "john"}, {"name": "sarah", "sport": 8}]))
    
test_OneOf_validate()

# Generated at 2022-06-12 15:35:10.158044
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field1 = IfThenElse(Any(), Any(), Any())
    assert field1.if_clause.TYPE == "any"
    assert field1.then_clause.TYPE == "any"
    assert field1.else_clause.TYPE == "any"

    field2 = IfThenElse(Any())
    assert field2.if_clause.TYPE == "any"
    assert field2.then_clause.TYPE == "any"
    assert field2.else_clause.TYPE == "any"

test_IfThenElse()

# Generated at 2022-06-12 15:35:11.988877
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x=IfThenElse(String)


# Generated at 2022-06-12 15:35:16.236870
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(1,2,3).if_clause == 1
    assert IfThenElse(1,2,3).then_clause == 2
    assert IfThenElse(1,2,3).else_clause == 3

# Generated at 2022-06-12 15:35:17.987489
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_lst = [Any(), Any()]
    assert isinstance(AllOf(all_of_lst), Field)

# Generated at 2022-06-12 15:35:23.168391
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf([
        String(pattern=re.compile('test_OneOf')),
        String(max_length=10),
    ])
    test_OneOf_validate_1 = one_of_field.validate("test_OneOf")
    assert test_OneOf_validate_1 == "test_OneOf"



# Generated at 2022-06-12 15:35:26.906978
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(None)
    assert isinstance(not_field, Not)
    assert not_field.negated == None
    assert not_field.errors == {"negated": "Must not match."}


# Generated at 2022-06-12 15:35:28.111213
# Unit test for constructor of class Not

# Generated at 2022-06-12 15:36:49.089686
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(field_a, then_clause = field_b, else_clause = field_d)
    assert field.if_clause == field_a
    assert field.then_clause == field_b
    assert field.else_clause == field_d

# Generated at 2022-06-12 15:36:50.873941
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    f1 = IfThenElse(if_clause=Field(), then_clause=Field())
    assert not f1.errors


# Generated at 2022-06-12 15:36:51.940633
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    
    Field = IfThenElse(1, 2, 3)
    

# Generated at 2022-06-12 15:36:56.676529
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(String(), Int())
    field.validate("2")
    field.validate(2)
    field.validate("2", strict=True)
    field.validate(2, strict=True)
    try:
        field.validate("2", strict=False)
    except Exception:
        pass
    else:
        assert False, "IfThenElse field should not validate with strict=False"



# Generated at 2022-06-12 15:36:59.032790
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-12 15:37:02.046064
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    with raises(AssertionError):
        IfThenElse(if_clause, then_clause, else_clause, 'allow_null')

# Generated at 2022-06-12 15:37:05.667609
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    print("Test If Then Else")
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    rule = IfThenElse(if_clause, then_clause, else_clause)
    assert rule.if_clause == if_clause
    assert rule.then_clause == then_clause
    assert rule.else_clause == else_clause

# Generated at 2022-06-12 15:37:08.457297
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert type(IfThenElse(1, 2, 3)) == IfThenElse
    assert type(IfThenElse(1, 2)) == IfThenElse
    assert type(IfThenElse(1)) == IfThenElse

# Generated at 2022-06-12 15:37:12.485499
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_field = String("if")
    then_field = String("then")
    else_field = String("else")
    test = IfThenElse(if_field, then_field, else_field)
    if_field.validate("true")
    then_field.validate("true")
    else_field.validate("true")
    test.validate("true")

# Generated at 2022-06-12 15:37:14.665268
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    IfThenElse(if_clause, then_clause, else_clause)