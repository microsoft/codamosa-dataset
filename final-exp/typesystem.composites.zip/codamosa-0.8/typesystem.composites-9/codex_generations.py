

# Generated at 2022-06-12 15:28:41.769884
# Unit test for constructor of class Not
def test_Not():
    field = Not(AllOf([Any(), Any()]))
    assert field.errors.get("negated") == "Must not match."


# Generated at 2022-06-12 15:28:42.805599
# Unit test for method validate of class Not
def test_Not_validate():
    Person = Field("Person")
    Not(Person).validate("Amit")

# Generated at 2022-06-12 15:28:50.277283
# Unit test for method validate of class Not
def test_Not_validate():
    pass
    # def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
    #     _, error = self.negated.validate_or_error(value, strict=strict)
    #     if error:
    #         return value
    #     raise self.validation_error("negated")


not_test = Not(String(max_length=10))

# unit test for method validate of class IfThenElse

# Generated at 2022-06-12 15:28:53.436696
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nevermatch = NeverMatch()
    assert nevermatch.allow_null is False
    assert nevermatch.errors == {"never": "This never validates."}



# Generated at 2022-06-12 15:28:54.749242
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(Any())
    not_.validate('test')

# Generated at 2022-06-12 15:28:55.326641
# Unit test for constructor of class Not
def test_Not():
    negated = Not(Any())


# Generated at 2022-06-12 15:28:58.845189
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = String()
    then_clause = String()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate("passed") == "passed"
    assert field.validate(1, strict=True) == "1"

# Generated at 2022-06-12 15:29:02.096812
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Any())
    if not_field is None:
        raise AssertionError("Not")


# Generated at 2022-06-12 15:29:11.908281
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from .array import Array
    from .object import Object
    from .string import String
    from .number import Number

    # str = String(min_length = 2, max_length = 6)
    str = String(choices = ["baba", "kyky", "bobo", "momo", "gogo"])
    str.validate("baba")
    str.validate("bobo")
    str.validate("momo")
    str.validate("gogo")

    # num = Number(min_value = 0, max_value = 99)
    num = Number(choices = [1, 2, 3, 4, 5, 6, 7, 8, 9])
    num.validate(1)
    num.validate(2)
    num.validate(3)
    num.validate(4)

# Generated at 2022-06-12 15:29:23.381899
# Unit test for method validate of class Not
def test_Not_validate():
    try:
        not_object = Not(Integer())
        assert not_object.validate("string") == "string"
        assert not_object.validate(1) == 1
        assert not_object.validate(1.234) == 1.234
        assert not_object.validate(0.1) == 0.1
        assert not_object.validate(True) == True
        assert not_object.validate(()) == ()
        assert not_object.validate(None) == None
        assert not_object.validate([1, 2, 3]) == [1, 2, 3]
        assert not_object.validate({'a':1, 'b':2}) == {'a':1, 'b':2}
    except Exception as e:
        print("test_Not_validate: ", e)
       

# Generated at 2022-06-12 15:29:38.886328
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    field_0 = Field()
    field_1 = Field()
    one_of = OneOf([field_0, field_1])
    value = 1

    value_0, error_0 = field_0.validate_or_error(value)
    value_1, error_1 = field_1.validate_or_error(value)

    if error_0 is None and error_1 is not None:
        assert one_of.validate(value) == value_0
    elif error_0 is not None and error_1 is None:
        assert one_of.validate(value) == value_1



# Generated at 2022-06-12 15:29:46.968545
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Int(), String()]).validate(4) == 4
    assert OneOf([Int(), String()]).validate("ok") == "ok"
    error = OneOf([Int(), String()]).validate_or_error(4.2)[1]
    assert error.code == "no_match"
    error = OneOf([Int(), String()]).validate_or_error(None)[1]
    assert error.code == "no_match"
    error = OneOf([Int(), String()]).validate_or_error(True)[1]
    assert error.code == "no_match"
    error = OneOf([Int(), String()]).validate_or_error({})[1]
    assert error.code == "no_match"
    error = OneOf([Int(), String()]).validate_or_error([])

# Generated at 2022-06-12 15:29:50.036598
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)
    assert field.negated is None
    assert field.allow_null is False
    assert field.errors == {"negated": "Must not match."}



# Generated at 2022-06-12 15:29:58.448006
# Unit test for constructor of class Not
def test_Not():
    import attr
    import pytest
    import typesystem
    class User(ty.Schema):
        name = ty.String()
    class UserWithAge(ty.Schema):
        name = ty.String()
        age = ty.Integer()
    class UserWithAgeAndEmail(ty.Schema):
        name = ty.String()
        age = ty.Integer()
        email = ty.String()

# Generated at 2022-06-12 15:30:09.069171
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # count how many test cases pass
    cnt = 0
    # count how many test cases fail
    fail = 0
    # count how many test cases have an exception happened during testing
    error = 0
    # count how many test cases are not checked due to exception
    na = 0
    # test cases
    # test_case(boolean, boolean) in condition if_clause
    # test_case(boolean, boolean) in condition then_clause
    # test_case(boolean, boolean) in condition else_clause
    # test_case(boolean, boolean) in validation one_of
    
    # test
    pass_cond = True
    if not (pass_cond):
        # condition
        pass_cond = True
        if not (pass_cond):
            # test case 1
            pass_cond = True
           

# Generated at 2022-06-12 15:30:14.812072
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Str()
    then_clause = Str()
    else_clause = Str()

    # value is a string, if_clause matches, result should be validated by then_clause
    value = "test"
    expected_result = value
    if_clause.validate(value)
    then_clause.validate(value)   # validate the value so we don't get an error when validating
    test_result = IfThenElse(if_clause, then_clause, else_clause).validate(value)
    assert expected_result == test_result

    # value is an integer, if_clause matches, result should be validated by else_clause
    value = 1
    expected_result = value
    if_clause.validate(value)

# Generated at 2022-06-12 15:30:22.050519
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = String(max_length=5)
    then_clause = String(max_length=2)
    else_clause = String(max_length=2)
    # If clause succeeds
    value = "abcdefg"
    field = IfThenElse(if_clause, then_clause)
    try:
        field.validate(value, strict=True)
    except ValidationError as e:
        assert e.messages == "Must be no longer than 2 characters."
    else:
        assert False, "previous line should have thrown an exception"
    # If clause fails
    value = "123"
    field = IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-12 15:30:25.371397
# Unit test for constructor of class AllOf
def test_AllOf():
    f1 = String()
    f2 = String()
    f3 = String()
    allOf = AllOf([f1,f2,f3],name='string')
    #assert allOf.all_of == [f1,f2,f3]
    assert allOf.name == 'string'


# Generated at 2022-06-12 15:30:26.767240
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field())
    assert field.validate(2) == 2

# Generated at 2022-06-12 15:30:30.622581
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Field(),Field()])
    value = "a"
    strict = True
    result = field.validate(value,strict)
    assert result == "a"


# Generated at 2022-06-12 15:30:39.730449
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Schema, String, Integer
    caso = IfThenElse(String(), then_clause=Integer(max_value=10), else_clause=Integer(min_value=-10))
    assert caso.validate(value="hello") == 0
    assert caso.validate(value=12) == 10
    assert caso.validate(value=-12) == -12



# Generated at 2022-06-12 15:30:42.311751
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch(allow_null=True)
        assert False, "expected a TypeError exception"
    except TypeError:
        pass

# Generated at 2022-06-12 15:30:46.925098
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    tested_class = IfThenElse(if_clause, then_clause, else_clause)
    result = tested_class.validate("not_empty")
    assert result == "not_empty"


# Generated at 2022-06-12 15:30:52.790848
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import json
    
    field = IfThenElse(
        if_clause=Field(type="string"),
        then_clause=Field(type="string", max_length=5),
        else_clause=Field(type="boolean")
    )

    value = "foobar"
    assert json.dumps(field.validate(value)) == value

    value = 4
    assert json.dumps(field.validate(value)) == "true"

# Generated at 2022-06-12 15:30:54.184189
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(None)
    assert not_field

# Generated at 2022-06-12 15:31:01.846783
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Test the case where the then and else clause are the same type
    fieldIf = IfThenElse(
        if_clause = Integer(min_value = 0),
        then_clause = Integer(max_value = 1),
        else_clause = Integer(max_value = 2)
        )
    int1 = 1
    int2 = 2
    # Test the case when the if_clause is true
    if_true = fieldIf.validate(int1)
    exp_true = 1
    assert if_true==exp_true, "The validate method does not work correctly for the case that the if_clause is true."

    # Test the case when the if_clause is false
    if_false = fieldIf.validate(int2)
    exp_false = 2

# Generated at 2022-06-12 15:31:06.079581
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String, Float
    f = OneOf([String, Integer, Float])
    assert f.validate('3') == '3'
    assert f.validate(4) == 4
    assert f.validate(4.0) == 4.0
    try:
        f.validate(5.5j)
        assert False
    except:
        assert True
    try:
        f.validate(4j)
        assert False
    except:
        assert True
    try:
        f.validate('a')
        assert False
    except:
        assert True


# Generated at 2022-06-12 15:31:12.415629
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Case: test whether clause is valid
    field = IfThenElse(if_clause=Boolean(), then_clause=Any(), else_clause=Any())
    assert field._validate(False) == False

    # Case: test whether clause is invalid
    with pytest.raises(ValidationError):
        field._validate(1)

    # Case: test whether else clause is valid
    field = IfThenElse(if_clause=Boolean(), then_clause=Any(), else_clause=Integer())
    assert field._validate(1) == 1


# Generated at 2022-06-12 15:31:17.234130
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_value = "Sir"
    from typesystem.fields.primitives import String
    from typesystem.fields.combination import IfThenElse
    if_clause = IfThenElse(
        if_clause=String(max_length=3),
        then_clause=String(min_length=4),
        else_clause=String(pattern=r"[A-Za-z]+ [A-Za-z]+"),
    )
    result = if_clause.validate(test_value)
    assert result == test_value

# Generated at 2022-06-12 15:31:21.259911
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Array, String

    array = Array(items=OneOf([String(max_length=10), String(max_length=20)]))
    assert array.full_clean(["hello", "world"]) is None
    assert array.full_clean(["hello", "world", "world"]) is not None
    assert "max_length" in array.errors()[1]
    assert "max_length" in array.errors()[2]



# Generated at 2022-06-12 15:31:33.622206
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-12 15:31:37.184552
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        10,
        then_clause=lambda value: value * 2,
        else_clause=lambda value: value * 3
    )
    assert field.validate(5) == 30
    assert field.validate(10) == 20

# Generated at 2022-06-12 15:31:47.200319
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import pytest
    from pprint import pprint
    from typesystem.fields import IfThenElse
    from typesystem.fields import String, Number
    ite = IfThenElse(if_clause=Number(minimum=4), then_clause=String, else_clause=Number())

    def validate_and_pprint(value, strict=True):
        try:
            return ite.validate(value, strict=strict)
        except Exception as e:
            return f'Exception: {e}'

    assert validate_and_pprint(4) == 4
    assert validate_and_pprint(4.4) == '4.4'
    assert validate_and_pprint(3.3) == 3.3
    assert validate_and_pprint(3) == 3


# Generated at 2022-06-12 15:31:55.042248
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # The purpose of this unit test is to test the method validate of class OneOf
    # The method validate of class OneOf should check if the value passed as a parameter of
    # validate matches exactly one of the sub-items.

    # The method validate of class OneOf has a parameter strict(defaulted to False) which is not
    # used in the body of validate.
    # The method validate of class OneOf has a parameter value that should be tested if it matches
    # exactly one of the sub-items.

    # Test 1: Ensure that validate returns value if it matches exactly one of the sub-item
    # Setup
    from typesystem.fields import String, Integer
    from typesystem.types import Type

    one_of = OneOf([String(), Integer()])

    # Exercise
    integer_value = 1234

# Generated at 2022-06-12 15:32:00.392380
# Unit test for constructor of class Not
def test_Not():
    def test_result(a: bool, b: bool, c: bool, d: bool, e: bool) -> bool:
        return not a and b and c and d and e
    field = Not(True, a=1, b=2, c=3)
    assert field.attributes == {'a': 1, 'b': 2, 'c': 3}

# Generated at 2022-06-12 15:32:01.198763
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert isinstance(all_of, AllOf)


# Generated at 2022-06-12 15:32:03.281607
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    OneOf(one_of=[1]).validate(1)
    # test_OneOf_validate_output = '''
    #
    # '''

# Generated at 2022-06-12 15:32:10.243020
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
     # check that the fields have the right default values
     field = IfThenElse(if_clause=Field())
     # the field "if_clause" should have been initialized
     assert field.if_clause is not None
     # the fields "then_clause" and "else_clause" should have the default values Any()
     assert field.then_clause is not None
     assert type(field.then_clause) is Any
     assert field.else_clause is not None
     assert type(field.else_clause) is Any

     # immediately return True for validation
     field = IfThenElse(if_clause=Field(), then_clause=Any())
     assert field.validate(True)

     # immediately return False for validation

# Generated at 2022-06-12 15:32:17.965052
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    int_field = Field(type="integer")
    str_field = Field(type="string")
    list_field = Field(type="list")
    dict_field = Field(type="dictionary")
    of_field = OneOf([int_field, str_field, list_field, dict_field])
    # of_field.validate([1, 2, 3])
    print(of_field.validate([1, 2, 3]))


if __name__ == "__main__":
    test_OneOf_validate()

# Generated at 2022-06-12 15:32:21.389091
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    my_field = Field()
    my_other_field = Field()
    test_field = IfThenElse(my_field, my_other_field)
    value, error = test_field.validate_or_error(1)
    assert(value == 1)



# Generated at 2022-06-12 15:32:37.686451
# Unit test for method validate of class Not
def test_Not_validate():
    negated = Int(maximum=100)
    obj = Not(negated)
    assert obj.validate(101) == 101
    assert obj.validate(10) != 10



# Generated at 2022-06-12 15:32:44.330336
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = OneOf([], allow_null=True)
    b = OneOf(
        [
            Field(allow_null=True),
            Field(allow_null=True),
        ]
    )
    c = OneOf(
        [
            Field(allow_null=True),
            Field(allow_null=True),
            Field(allow_null=True),
        ]
    )
    assert a.validate(None) == None
    assert b.validate(1) == 1
    assert c.validate(2) == 2

# Generated at 2022-06-12 15:32:48.685321
# Unit test for constructor of class AllOf
def test_AllOf():
    schema = AllOf([])
    assert schema.all_of == []
    assert schema.allow_coerce is True
    assert schema.allow_null is True
    assert schema.error_messages == Field.default_error_messages
    assert schema.name is None
    assert schema.description is None

    schema = AllOf([String()], max_length=10)
    assert schema.all_of[0].max_length == 10


# Generated at 2022-06-12 15:32:52.950668
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    my_OneOf = OneOf(one_of=None)
    # This field doesn't accept null so it fails if value is None
    assert my_OneOf.validate(None) == (None, 'no_match')

    # Not working yet
    # one_of = [Integer(max_value=5), String(max_length=5)]
    # my_OneOf = OneOf(one_of=one_of)
    # assert my_OneOf.validate(1) == 1
    # assert my_OneOf.validate('abcdef') == ('abcdef', 'multiple_matches')



# Generated at 2022-06-12 15:32:53.818766
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)



# Generated at 2022-06-12 15:33:03.247372
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test AllOf.validate
    """
    schema = IfThenElse(Int(), String())
    value = String().validate(schema.validate(2))
    assert isinstance(value, str)
    value = String().validate(schema.validate(3))
    assert isinstance(value, str)

    schema = IfThenElse(Int(), String(), Number())
    value = Int().validate(schema.validate(2))
    assert isinstance(value, int)
    value = String().validate(schema.validate(3))
    assert isinstance(value, str)
    value = Number().validate(schema.validate(4))
    assert isinstance(value, float)

# Generated at 2022-06-12 15:33:08.632705
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer
    from typesystem.errors import ValidationError
    from typesystem.fields import Not
    try:
        Not(Integer()).validate("1")
    except ValidationError as err:
        assert err.args[0] == {'type': 'string', 'data': '1', 'schema': {'negated': 'Must not match.'}}
    try:
        Not(Integer()).validate(1)
    except ValidationError as err:
        assert err.args[0] == {'type': 'integer', 'data': 1, 'schema': {'negated': 'Must not match.'}}

# Generated at 2022-06-12 15:33:15.039820
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer

    fieldIf = Integer(minimum=1)
    fieldThen = Integer(minimum=2)
    fieldElse = Integer(minimum=3)
    field = IfThenElse(if_clause=fieldIf, then_clause=fieldThen, else_clause=fieldElse)

    assert field.validate(5) == 5
    assert field.validate(1) == 1

# Generated at 2022-06-12 15:33:16.448082
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate("blah")

# Generated at 2022-06-12 15:33:19.672228
# Unit test for constructor of class Not
def test_Not():
    # Check if any of the initial parameters is None, then assert error
    try:
        Not(None)
    except AssertionError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:34:02.465724
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestClass:
        def __init__(self, if_clause: Field, then_clause: Field, else_clause: Field):
            self.if_clause = if_clause
            self.then_clause = then_clause
            self.else_clause = else_clause
    def test_method_validate(case_data):
        obj = TestClass(**case_data)
        obj.validate("str")
        return "pass"

# Generated at 2022-06-12 15:34:10.416154
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    def list2field(list1:typing.List[typing.Any],index:int) -> Field:
        #index >= 0 and len(list1)>index
        return Any(value = list1[index])
    list1 = [1,2,3,4]
    assert str(OneOf([list2field(list1,0)]).validate(list1[0])) == str(1)
    assert str(OneOf([list2field(list1,0)]).validate(list1[1])) == "no_match"
    assert str(OneOf([list2field(list1,2),list2field(list1,3)]).validate(list1[2])) == str(3)

# Generated at 2022-06-12 15:34:13.404483
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.allow_null is False
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:34:17.961099
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer, String

    fields = [Integer(), String()]
    x = OneOf(fields)
    assert x.validate(5) == 5
    assert x.validate("abc") == "abc"
    try:
        x.validate(False)
    except Exception as e:
        assert str(e) == "Did not match any valid type."

# Generated at 2022-06-12 15:34:21.767616
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # type: () -> None
    MyIfThenElse = IfThenElse(String(max_length=3), Int(), None)
    data = None
    assert MyIfThenElse.validate(data) == None
    data = "hello"
    assert MyIfThenElse.validate(data) == None
    data = "a"
    assert MyIfThenElse.validate(data) == "a"

# Generated at 2022-06-12 15:34:24.055201
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(None, None)
    ite.validate(1)
    try:
        ite.validate(None)
    except:
        assert True
    else:
        assert False

# Generated at 2022-06-12 15:34:25.762250
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  error = {"never": "This never validates."}
  neverMatch = NeverMatch()
  assert neverMatch.errors == error

# Test validation of class NeverMatch

# Generated at 2022-06-12 15:34:26.731500
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(Field).__class__ == AllOf


# Generated at 2022-06-12 15:34:35.878554
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_field_one = Field()
    one_of_field_two = Field()
    one_of_fields_value = [one_of_field_one, one_of_field_two]
    one_of_field_value = Field()
    one_of_strict_value = False
    one_of_expected_value = None
    
    # Perform the test
    one_of_test_instance = OneOf(one_of_fields_value)
    one_of_returned_value = one_of_test_instance.validate(one_of_field_value, one_of_strict_value)
    
    # Return the result
    assert one_of_returned_value == one_of_expected_value


# Generated at 2022-06-12 15:34:39.545110
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    arr = [1,2,3,4,5]
    schema = OneOf(one_of= arr)
    value = 5
    for item in arr:
        if (schema.validate(value= item) != value):
            raise AssertionError()

# Generated at 2022-06-12 15:35:33.499291
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        Integer(minimum=0),
        Integer(minimum=1),
        Integer(maximum=0),
    )

    # According to the rules specified, the value of a IfThenElse field
    # must be matched by the following fields:
    #
    # - Integer(minimum=1)
    # - Integer(maximum=0)
    #
    # The test below verifies that the value equals 1, and it is in the
    # following rule.
    #
    # Integer(minimum=0)
    #   => True
    # IfThenElse(
    #   Integer(minimum=0),
    #   Integer(minimum=1),
    #   Integer(maximum=0),
    # )
    #   => True
    # Integer(minimum=1)
    #   => True
    #
    #

# Generated at 2022-06-12 15:35:43.832187
# Unit test for method validate of class Not
def test_Not_validate():
    def valid_validate_v1(field, value, strict=False):
        _, error = field.validate_or_error(value, strict=strict)
        return not error
    def valid_validate_v2(field, value, strict=False):
        try:
            field.validate(value, strict=strict)
        except Exception as e:
            return False
        return True

    def check(field, value):
        assert valid_validate_v1(field,value)
        assert valid_validate_v2(field,value)
    # Test 1:
    fi = Not(String()) # should succeed
    check(fi,"String")
    # Test 2:
    fi = Not(Integer()) # should fail

# Generated at 2022-06-12 15:35:44.320829
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-12 15:35:50.968195
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(123)
    then_clause = Field(456)
    else_clause = Field(abc)
    ifthenelse = IfThenElse(if_clause, then_clause, else_clause)
    assert ifthenelse.validate(123) == 456
    assert ifthenelse.validate(abc) == abc
    # assert ifthenelse.validate("xyz") is False
    # assert ifthenelse.validate("xyz") is False

# Generated at 2022-06-12 15:35:57.801712
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    import json

    from typesystem import Structure

    class TestSchema(Structure):
        field1 = OneOf(one_of=[Any()])
        field2 = OneOf(one_of=[Any(), Any()])
        field3 = OneOf(
            one_of=[
                Structure(fields={"field3.1": Any()}),
                Structure(fields={"field3.2": Any()}),
            ]
        )
        field4 = OneOf(one_of=[Any(), Any(), Any()])

    schema = TestSchema()
    data = {"field1": "dummy"}
    assert schema.validate(data) == data
    data = {"field2": "dummy"}
    assert schema.validate(data) == data
    data = {"field3": {"field3.1": "dummy"}}


# Generated at 2022-06-12 15:36:05.832223
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(label="if_clause")
    then_clause = Field(label="then_clause")
    else_clause = Field(label="else_clause")
    value = IfThenElse(if_clause, then_clause, else_clause)
    value.validate(5) # if_clause and then_clause are None, else_clause return null

    if_clause = Field(label="if_clause")
    then_clause = Field(label="then_clause", null=False)
    else_clause = Field(label="else_clause")
    value = IfThenElse(if_clause, then_clause, else_clause)
    value.validate(5) # if_clause and then_clause are None, else_clause

# Generated at 2022-06-12 15:36:10.209864
# Unit test for method validate of class Not
def test_Not_validate():
    """
    test method validate of class Not
    """
    field_not = Not(Any())
    # when value is an int, validates
    value = 1
    field_not.validate(value)

    # when value is a string and negate field is String, validates
    field_not_negated = Not(String())
    value = 'hello'
    field_not_negated.validate(value)

# Generated at 2022-06-12 15:36:15.329406
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    choice = IfThenElse(
        IfThenElse(
            if_clause = 3,
            then_clause = 3,
            else_clause = 4
        ),
        then_clause = 4,
        else_clause = 5
    )
    assert(choice.validate(3) == 3)
    assert(choice.validate(4) == 4)
    assert(choice.validate(5) == 5)
    assert(choice.validate(6) == 5)

# Generated at 2022-06-12 15:36:18.138181
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    test_IfThenElse = IfThenElse(if_clause, then_clause, else_clause)
    assert test_IfThenElse.validate('value') == 'value'

# Generated at 2022-06-12 15:36:21.933687
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A(Field):
        def validate(self, value):
            return "A"
    class B(Field):
        def validate(self, value):
            return "B"
    class C(Field):
        def validate(self, value):
            return "C"

    a = A()
    b = B()
    c = C()
    d = IfThenElse(a, b, c)
    with pytest.raises(Exception):
        d.validate("notA")



# Generated at 2022-06-12 15:37:52.690680
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Integer())
    n.validate('a')

# Generated at 2022-06-12 15:37:55.928516
# Unit test for method validate of class Not
def test_Not_validate():
    errors = {"negated": "Must not match."}
    if_clause = typing.List[Field]()
    then_clause = typing.List[Field]()
    else_clause = typing.List[Field]()
    kwargs = {}
    kwargs["errors"] = errors
    kwargs["if_clause"] = if_clause
    kwargs["then_clause"] = then_clause
    kwargs["else_clause"] = else_clause
    obj = IfThenElse(**kwargs)
    obj.validate(0, strict=True)

# Generated at 2022-06-12 15:38:06.209981
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    json_schema = {
        "type": "object",
        "properties": {
            "prop1": {
                "type": "object",
                "properties": {
                    "prop11": {"type": "number"},
                    "prop12": {"type": "string"},
                },
                "if": {
                    "properties": {
                        "prop11": {"const": 1}
                    }
                },
                "then": {
                    "properties": {
                        "prop12": {"const": "A"}
                    }
                },
                "else": {
                    "properties": {
                        "prop12": {"const": "B"}
                    }
                },
            },
        },
        "required": ["prop1"],
    }

    schema = typesystem.schema_from_json_schema(json_schema)


# Generated at 2022-06-12 15:38:08.091036
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}
    assert field.validate(None) == None


# Generated at 2022-06-12 15:38:15.270085
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Int(), then_clause=Int()).validate(1) == 1
    assert IfThenElse(if_clause=Int(), then_clause=Int()).validate(1.0) == 1
    assert IfThenElse(if_clause=Int(), else_clause=Int()).validate(1.0) == 1
    assert IfThenElse(if_clause=Int(), else_clause=Int()).validate("lol") == "lol"


# Generated at 2022-06-12 15:38:22.243057
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    def test_name_1(schema):
        value = 3
        assert schema.validate(value) == value
    # Test for single one_of field.
    field = OneOf(one_of=[Integer(min_value=0)])
    test_name_1(field)


    # Test for multiple one_of fields.
    def test_name_2(schema):
        value = 12
        assert schema.validate(value) == value
    field = OneOf(one_of=[Integer(min_value=12),Integer(min_value=0)])
    test_name_2(field)


    # Test for multiples and single one_of field
    def test_name_3(schema):
        value = 12
        assert schema.validate(value) == value

# Generated at 2022-06-12 15:38:23.838156
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(AllOf([Int(), Double()]), AllOf([Int()])).validate(5) == 5
    IfThenElse(AllOf([Int()]), AllOf([Int(), Double()])).validate(5.5) == 5.5

# Generated at 2022-06-12 15:38:32.979888
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class ifType(Field):
        pass
    class thenType(Field):
        pass
    class elseType(Field):
        pass
    if_clause = ifType()
    then_clause = thenType()
    else_clause = elseType()

    test = IfThenElse(if_clause, then_clause, else_clause)
    assert test.validate(1) == 1
    # The function test.validate is called on value 1
    # The function if_clause.validate is called on value 1
    # The error is not None
    # The function else_clause.validate is called on value 1
    # The function elseType.validate is called on value 1
    # The value 1 is returned


# Generated at 2022-06-12 15:38:37.637409
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(Boolean(), Integer(), String())
    assert ite.validate(True) == 0
    assert ite.validate(False) == ""
    assert ite.validate(None) == ""

