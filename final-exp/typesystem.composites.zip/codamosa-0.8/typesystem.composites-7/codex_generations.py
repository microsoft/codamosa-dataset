

# Generated at 2022-06-12 15:28:45.316002
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    source = OneOf([Integer(minimum=1, maximum=10), Integer(minimum=100, maximum=200)])

    assert source.validate(1) == 1
    assert source.validate(100) == 100

    with raises(Invalid):
        source.validate(11)

    with raises(Invalid):
        source.validate(0)

    with raises(Invalid):
        source.validate(50)

    with raises(Invalid):
        source.validate(201)



# Generated at 2022-06-12 15:28:53.329344
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A(Field):
        def __init__(self):
            super().__init__()
        def validate(self, value,strict=False):
            return value

    class B(Field):
        def __init__(self):
            super().__init__(name="if clause")
        def validate(self, value,strict=False):
            return value

    class C(Field):
        def __init__(self):
            super().__init__()
        def validate(self, value,strict=False):
            return value

    class D(Field):
        def __init__(self):
            super().__init__()
        def validate(self, value,strict=False):
            return value

    # mocks
    a = A()
    b = B()
    c = C()

# Generated at 2022-06-12 15:28:56.141742
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    exception = None

    try:
        assert error == None
        assert error == None
    except Exception as e:
        exception = e
    assert exception.args[0] == "error"



# Generated at 2022-06-12 15:29:01.914166
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(None)
    assert n.validate(None) == None
    try:
        n.validate(True)
        assert False
    except:
        pass


# Generated at 2022-06-12 15:29:03.981800
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Check that field constructor creates an instance as expected
    assert NeverMatch(name="field", label="Test Field")



# Generated at 2022-06-12 15:29:14.069111
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    def test_OneOf_validate_list_of_fields(list_of_fields=[]):
        s = OneOf(list_of_fields)
        s.validate(None)
    test_OneOf_validate_list_of_fields()
    test_OneOf_validate_list_of_fields([])
    test_OneOf_validate_list_of_fields(['',''])
    test_OneOf_validate_list_of_fields([Any()])
    test_OneOf_validate_list_of_fields([Any(), Any()])
    try:
        test_OneOf_validate_list_of_fields([Any(), Any(), Any()])
    except typesystem.ValidationError as e:
        pass
    from typesystem.fields import Integer

# Generated at 2022-06-12 15:29:16.911528
# Unit test for constructor of class Not
def test_Not():
    def negated(x):
        return x > 0
    f = Not(negated)


# Generated at 2022-06-12 15:29:23.577949
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    try:
        if_clause = IfThenElse(Any())
        then_clause = IfThenElse(Any())
        else_clause = IfThenElse(Any())
        if_clause.validate([1,2], strict=True)
        then_clause.validate([1,2], strict=True)
        else_clause.validate([1,2], strict=True)
    except Exception as e:
        print(e)

    print("IfThenElse class is OK.")

# Generated at 2022-06-12 15:29:26.126645
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    fields = [OneOf, AllOf, Not]
    field = OneOf(one_of=fields)
    field.validate(value=6) # OneOf.__init__() test

# Generated at 2022-06-12 15:29:28.817309
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(String(max_length=10))
    field_value = f.validate('123456789')
    assert field_value == True


# Generated at 2022-06-12 15:29:35.113021
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(fields=[NeverMatch()])
    validated, error = field.validate_or_error(1, strict=False)
    assert validated is None
    assert error == "Did not match any valid type."


# Generated at 2022-06-12 15:29:38.930318
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_object = OneOf([Any(), Any()], default="default", description="some description")
    assert one_of_object.one_of[0].validate("test") == "test"


# Generated at 2022-06-12 15:29:40.468199
# Unit test for method validate of class Not
def test_Not_validate():
    Not(int()).validate("1")

# Generated at 2022-06-12 15:29:48.312242
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    one_of = OneOf(one_of=[String()])
    assert one_of.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert one_of.one_of[0].__class__.__name__ == "String"
    try:
        OneOf(one_of=[], allow_null=True)
    except AssertionError as e:
        assert "allow_null" in str(e)
    try:
        OneOf(one_of=[])
    except TypeError as e:
        assert "'one_of'" in str(e)


# Generated at 2022-06-12 15:29:57.377472
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from tools import TypesystemDict
    from typesystem.fields import String, Integer, Number, Object, Array

    class Example(TypesystemDict):
        username: String(max_length=20)
        age: Integer(maximum=18)
        weight: Number(maximum=80)
        friends: Array(items=Integer)

    g = Example()
    g.username = 'mint'
    g.age = 17
    g.weight = 65
    g.friends = [1, 2, 3]

    # example of json_schema_support
    type_field = OneOf(
        one_of=[Integer(maximum=2), String(max_length=20), Number(maximum=80)],
    )
    assert type_field.validate(1) == 1
    assert type_field.validate('mint') == 'mint'

# Generated at 2022-06-12 15:29:59.544065
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer

    a = OneOf([Integer()])

# Generated at 2022-06-12 15:30:05.763146
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Int()
    then_clause = Str()
    else_clause = List(items=Any())
    my_class = IfThenElse(if_clause, then_clause, else_clause)
    value = my_class.validate(4)
    assert isinstance(value, str)
    value = my_class.validate("4")
    assert isinstance(value, list)
    assert value == []

# Generated at 2022-06-12 15:30:07.332983
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    import typesystem
    field = typesystem.NeverMatch(name='Name')
    assert field



# Generated at 2022-06-12 15:30:11.967468
# Unit test for constructor of class Not
def test_Not():
    # Test non-strict mode
    dict = {
      "test_key1": "test_value1",
      "test_key2": "test_value2"
    }
    # Assert that we can construct a Not object from a dict
    not_ = Not(dict)
    assert not_.negated == dict

    # Test strict mode
    with pytest.raises(TypeError) as info:
        Not({})
    assert "Strict type checking" in str(info.value)



# Generated at 2022-06-12 15:30:17.556117
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    obj = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    value = True
    assert obj.validate(value) == value

    obj = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    value = 1
    assert obj.validate(value) == value

# Generated at 2022-06-12 15:30:23.000265
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    Field_mock = Field()
    assert(NeverMatch(name = 'NeverMatch_field',
                        description = 'Never Match field',
                        required = True,
                        allow_null = False) == Field_mock)


# Generated at 2022-06-12 15:30:23.703575
# Unit test for constructor of class AllOf
def test_AllOf():
    a_field = AllOf([])


# Generated at 2022-06-12 15:30:27.405519
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.name is None
    assert field.description is None
    assert field.validators == ()
    assert field.default is None
    assert field.alias is None



# Generated at 2022-06-12 15:30:35.907949
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    d = {
        'one_of': [
            {'type': 'string'},
            {'type': 'integer'}
        ]
    }
    a = OneOf(**d)
    assert a.validate("a") == "a"
    assert a.validate(1) == 1
    try:
        a.validate(True)
        assert False
    except:
        pass
    try:
        a.validate(1.2)
        assert False
    except:
        pass
    try:
        a.validate([])
        assert False
    except:
        pass
test_OneOf_validate()

# Generated at 2022-06-12 15:30:40.984015
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Structure
    class MyStructure(Structure):
        a = "text"
        b = 2
        x = Not(a)
    # Test a positive case.
    s = MyStructure(b="my_b")
    r = s.validate()
    # Test a negative case.
    s = MyStructure(b="my_b", x="my_a")
    try:
        r = s.validate()
    except ValueError as e:
        assert "not match" in str(e)



# Generated at 2022-06-12 15:30:41.953232
# Unit test for method validate of class Not
def test_Not_validate():
    typesystem.schema.main()


# Generated at 2022-06-12 15:30:43.717374
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Integer

    field = Not(Integer())
    assert field.negated is Integer()


# Generated at 2022-06-12 15:30:45.185238
# Unit test for method validate of class Not
def test_Not_validate():
    assert not Not(String(min_length=1)).validate(None)

# Generated at 2022-06-12 15:30:49.722616
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.errors import ValidationError
    from typesystem.fields import String

    negated = String()
    not_field = Not(negated)
    with pytest.raises(ValidationError, match="Must not match."):
        not_field.validate("123")

    not_field.validate(None)


# Generated at 2022-06-12 15:30:51.832359
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    not_field.validate(1)
    not_field.validate(True)

# Generated at 2022-06-12 15:30:56.172333
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(one_of=[])
    value = 1
    strict = True
    one_of.validate(value=value, strict=strict)


import pytest


# Generated at 2022-06-12 15:30:59.902603
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([1, 2, 3, 4])
    field = OneOf((1, 2, 3, 4))
    field = OneOf([1, 2, 3, 4], name="test_OneOf_list")
    field = OneOf((1, 2, 3, 4), name="test_OneOf_tuple")
    

# Generated at 2022-06-12 15:31:02.714319
# Unit test for constructor of class Not
def test_Not():
    from typesystem.types import String

    f = Not(String())
    assert f.negated is not None


# Generated at 2022-06-12 15:31:06.652750
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(int,then_clause=int,else_clause=str).validate(10) == 10
    assert IfThenElse(int,then_clause=int,else_clause=str).validate("Hello") == "Hello"

# Generated at 2022-06-12 15:31:09.718957
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-12 15:31:11.474871
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one = OneOf([Field(key='one'), Field(key='two')])
    one.validate({'one': 1})
    assert True

# Generated at 2022-06-12 15:31:18.458674
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import unittest
    import typesystem
    from typesystem.fields import String, Boolean

    class TestOneOf(unittest.TestCase):

        def test_validate(self):
            field = typesystem.OneOf([String(max_length=10), Boolean()])

            try:
                field.validate('hello world')
            except typesystem.ValidationError:
                self.fail('ValidationError raised unexpectedly!')
            else:
                self.assertEqual(field.validate('hello world'), 'hello world')
            try:
                field.validate(True)
            except typesystem.ValidationError:
                self.fail('ValidationError raised unexpectedly!')
            else:
                self.assertEqual(field.validate(True), True)

# Generated at 2022-06-12 15:31:20.963658
# Unit test for method validate of class Not
def test_Not_validate():
    val = "12"
    field = Not(Integer())
    output = field.validate(val)
    assert output == val

# Generated at 2022-06-12 15:31:24.351892
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(name="field")
    assert field.name == "field"
    # Test for coverage
    (validated, error) = field.validate_or_error(1)
    assert error.code == "never"
    assert error.message == "This never validates."


# Generated at 2022-06-12 15:31:33.475544
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer

    # when negated field matches
    field = Not(Integer())
    try:
        field.validate(1)
    except ValidationError as err:
        # then ValidationError is raised
        assert str(err) == 'Must not match.'
    else:
        # else (should not happen)
        assert False

    # when negated field does not match
    field = Not(Integer())
    assert field.validate(1.0) == 1.0



# Generated at 2022-06-12 15:31:39.326866
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test all conditions
    field = OneOf(one_of=[Any(), String()])
    assert (field.validate("Hello") is not None)
    assert (field.validate("Hello") == "Hello")
    assert (field.validate("Hello") == "Hello")


# Generated at 2022-06-12 15:31:40.780920
# Unit test for constructor of class Not
def test_Not():
    s = Not(NeverMatch())
    assert s.errors["negated"] == "Must not match."

# Generated at 2022-06-12 15:31:47.347061
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # testing if clause
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    with pytest.raises(ValidationError):
        assert IfThenElse(if_clause=NeverMatch(), then_clause=Any(), else_clause=Any()).validate(1) == 1

    # testing then clause
    assert IfThenElse(if_clause=Any(), then_clause=Integer(max_value=5), else_clause=Any()).validate(1) == 1
    with pytest.raises(ValidationError):
        assert IfThenElse(if_clause=Any(), then_clause=Integer(max_value=5), else_clause=Any()).validate(10) == 1

    # testing else

# Generated at 2022-06-12 15:31:52.831127
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    Any()
    # Tests that OneOf passes when value matches exactly one type in one_of parameter
    f1=Field(key="f1", required=True, allow_null=True)
    f2=Field(key="f2", required=True, allow_null=True)
    one_of_field=OneOf(one_of=[f1,f2])
    assert one_of_field.validate(2) == 2
    assert one_of_field.validate("hello") == "hello"

    # Tests that OneOf passes when value is None and allow_null is true
    one_of_field=OneOf(one_of=[f2])
    assert one_of_field.validate(None) is None

    # Tests that OneOf raises ValidationError when value does not match any type in one_of parameter

# Generated at 2022-06-12 15:31:56.553687
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n.allow_null == False
    assert n.errors == {"never": "This never validates."}
    assert n.name == "NeverMatch"
    assert n.python_type == None


# Generated at 2022-06-12 15:32:01.227565
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import typesystem
    integer = typesystem.Integer()
    string = typesystem.String()
    field = typesystem.IfThenElse(integer, string)
    assert field
    assert field.if_clause == integer
    assert field.then_clause == string
    assert field.else_clause == typesystem.Any()


# Generated at 2022-06-12 15:32:08.308541
# Unit test for method validate of class Not
def test_Not_validate():
    # test default case
    assert Not(negated=Any()).validate(None) == None

    # test case expected case
    assert Not(negated=Any()).validate(0) == 0

    # test some other possible cases
    assert Not(negated=Any()).validate(True) == True
    assert Not(negated=Any()).validate([]) == []
    assert Not(negated=Any()).validate({}) == {}
    assert Not(negated=Any()).validate(()) == ()
    assert Not(negated=Any()).validate(set()) == set()
    assert Not(negated=Any()).validate('') == ''



# Generated at 2022-06-12 15:32:17.476388
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from .fields import String, Integer
    from .exceptions import ValidationError, ConversionError
    oneof = OneOf([Integer(), String()])
    assert oneof.validate(1)==1
    assert oneof.validate('a')=='a'
    try:
        oneof.validate(True)
        assert False
    except ValidationError as e:
        assert e.code == 'no_match'
        assert e.meta == {}
    try:
        oneof.validate(1, 2)
        assert False
    except ValidationError as e:
        assert e.code == 'multiple_matches'
        assert e.meta == {}

# Generated at 2022-06-12 15:32:26.557919
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # type: () -> None
    class MyField(OneOf):
        pass

    field = MyField([Integer, String])
    field.validate(123)
    field.validate("123")

    with pytest.raises(ValidationError, match="no_match"):
        field.validate(True)
    with pytest.raises(ValidationError, match="multiple_matches"):
        field.validate(None)
    # Unicode string
    field.validate("123")
    # Bytes
    field.validate(b"123")
    # Non-unicode string
    with pytest.raises(ValidationError, match="does_not_match"):
        field.validate(chr(0x1F4A9))
    # Unit test for method validate of class IfThenElse


# Generated at 2022-06-12 15:32:32.548859
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # These should not raise any exception
    _ = NeverMatch(default=4)
    _ = NeverMatch()
    # These should raise an exception
    try:
        _ = NeverMatch(allow_null=True)
    except:
        assert True
    try:
        _ = NeverMatch(None)
    except:
        assert True


# Generated at 2022-06-12 15:32:42.142748
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Test case OneOf validation
    """
    field = OneOf()

    field.one_of = [
        String()
    ]
    out, error = field.validate_or_error("SomeStr")
    assert out == "SomeStr"
    assert error is None

    field.one_of = [
        String(),
        Integer()
    ]

    out, error = field.validate_or_error("SomeStr")
    assert out == "SomeStr"
    assert error is None

    out, error = field.validate_or_error("SomeStr", strict=True)
    assert out == "SomeStr"
    assert error is None

    out, error = field.validate_or_error("1")
    assert out == "1"
    assert error is None

    out, error = field.validate

# Generated at 2022-06-12 15:32:43.433861
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf.validate(None, [Any()]) == None

# Generated at 2022-06-12 15:32:45.881764
# Unit test for constructor of class OneOf
def test_OneOf():
    assert hasattr(OneOf, '__init__')
    assert callable(OneOf.__init__)
    assert isinstance(OneOf.__init__, types.MethodType)


# Generated at 2022-06-12 15:32:47.369526
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String

    field = Not(String())
    assert field.validate("a") == "a"
    field.validate(1)



# Generated at 2022-06-12 15:32:51.862056
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Field
    from typesystem.types import Integer

    class A(AllOf):
        def __init__(self) -> None:
            super().__init__(all_of=[Integer()])
    a = A()
    assert isinstance(a, Field)
    assert isinstance(a.all_of[0], Integer)



# Generated at 2022-06-12 15:32:54.547963
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        AllOf(all_of=['a','b','c'])
    except Exception as e:
        assert(e.__str__() == 'AllOf Fields must be instances of Field.')


# Generated at 2022-06-12 15:32:58.258449
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer, String
    field = OneOf([Integer(), String()])
    field.validate(1)
    field.validate("foobar")
    field.validate([])

# Generated at 2022-06-12 15:33:04.220920
# Unit test for constructor of class Not
def test_Not():
    # Test 1:
    first = Not(Integer())
    assert isinstance(first.negated, Integer)
    # Test 2:
    second = Not(String())
    assert isinstance(second.negated, String)
    # Test 3:
    third = Not(Boolean())
    assert isinstance(third.negated, Boolean)
    # Test 4:
    fourth = Not(List())
    assert isinstance(fourth.negated, List)


# Generated at 2022-06-12 15:33:08.251456
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String

    field = Not(String())
    assert field.validate("test") == "test"
    assert field.validate(123) == 123
    assert field.validate({}) == {}
    assert field.validate([]) == []


# Generated at 2022-06-12 15:33:09.900853
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(negated='fieldname')


# Generated at 2022-06-12 15:33:19.317417
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print("test OneOf validate")
    assert OneOf([Int()], name="test").validate(1) == 1
    assert OneOf([Str()], name="test").validate("s") == "s"
    with pytest.raises(ValidationError):
        OneOf([Str()], name="test").validate("s1")
        OneOf([Str()], name="test").validate("s2")
        OneOf([Str()], name="test").validate("s3")


# Generated at 2022-06-12 15:33:27.532692
# Unit test for method validate of class Not
def test_Not_validate():
    # 
    not_ = Not(String())
    assert not_.validate("a") == "a"
    #
    with pytest.raises(ValidationError) as excinfo:
        not_.validate(123)
    assert excinfo.value.code == 'negated'
    # 
    not_ = Not(Dict({
        'a' : String(),
        'f' : Number(),
    }))
    assert not_.validate({
        'a' : 'a',
        'b' : 3.2,
        'c' : [1, 2, 3]
    }) == {
        'a' : 'a',
        'b' : 3.2,
        'c' : [1, 2, 3]
    }
    #

# Generated at 2022-06-12 15:33:29.488670
# Unit test for constructor of class OneOf
def test_OneOf():
    oo = OneOf([], **dict())

    # Unit test for method validate of class OneOf
    def test_validate():
        oo.validate(123)


# Generated at 2022-06-12 15:33:33.647439
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    '''
    Testing the constructor
    '''
    field1 = IfThenElse(String())
    # Ensure that if_clause is set
    assert(field1.if_clause == String())
    # Ensure that else_clause is set
    assert(field1.else_clause == Any())
    # Ensure that then_clause is set
    assert(field1.then_clause == Any())

# Generated at 2022-06-12 15:33:35.186110
# Unit test for constructor of class OneOf
def test_OneOf():
    test = OneOf()
    assert test is not None


# Generated at 2022-06-12 15:33:37.881399
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    a = String()
    b = String()
    t = AllOf([a, b])
    assert t.all_of == [a, b]


# Generated at 2022-06-12 15:33:44.380027
# Unit test for constructor of class Not
def test_Not():
    import typesystem

    class Invalid(typesystem.String):
        min_length = 20000

    class Valid(typesystem.String):
        min_length = 100

    # item, the value that is expected to return error
    item = "abc123"
    # negated, the value that is expected to not return error
    negated = "a"*20000

    # assert that negated match error
    notClause = Not(Invalid());
    _, error = notClause.validate_or_error(negated, strict=False)
    assert error is None

    # assert that item returns error
    _, error = notClause.validate_or_error(item, strict=False)
    assert error



# Generated at 2022-06-12 15:33:45.651217
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True

# Generated at 2022-06-12 15:33:47.600171
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Field(), Field()])
    result = one_of.validate(10)
    assert result == 10


# Generated at 2022-06-12 15:33:48.188310
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])

# Generated at 2022-06-12 15:33:52.189628
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True # TODO: implement your test here


# Generated at 2022-06-12 15:33:55.218601
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer, Float, String
    # Assert that the field does not raise an exception
    try:
        temp = OneOf(one_of=[Integer(), Float(), String()])
    except Exception as e:
        raise e


# Generated at 2022-06-12 15:34:04.769525
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f1 = OneOf([Int(), Float()])
    with pytest.raises(ValidationError):
        f1.validate(True)
    with pytest.raises(ValidationError):
        f1.validate(None)
    assert f1.validate(1) == 1
    assert f1.validate(2.0) == 2.0

    f2 = OneOf([Int(), List()])
    with pytest.raises(ValidationError):
        f2.validate(True)
    with pytest.raises(ValidationError):
        f2.validate(None)
    assert f2.validate(1) == 1
    assert f2.validate([]) == []

    f3 = OneOf([Int(), Float()], optional=True)

# Generated at 2022-06-12 15:34:07.487561
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case 1
    # test case for validate
    foo = OneOf(one_of=[Any()])
    with pytest.raises(ValidationError):
        foo.validate(None)    
    

# Generated at 2022-06-12 15:34:13.018186
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(
        one_of=[
            String(),
            Integer(),
            Boolean(),
        ]
    )
    assert field.validate("a string") == "a string"
    assert field.validate(42) == 42
    assert field.validate(True) is True
    with pytest.raises(typesystem.exceptions.ValidationError) as excinfo:
        field.validate(1.2)
    assert excinfo.value.code == "no_match"
    with pytest.raises(typesystem.exceptions.ValidationError) as excinfo:
        field.validate(["a list"])
    assert excinfo.value.code == "no_match"

# Generated at 2022-06-12 15:34:14.450294
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name = "NeverMatch").errors['never'] == "This never validates."

# Generated at 2022-06-12 15:34:22.242284
# Unit test for method validate of class Not
def test_Not_validate():
    import json
    import jsonref
    from numpy import dtype

    #Construct an instance of the Not class with default input values

# Generated at 2022-06-12 15:34:24.974660
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(if_clause=Field())
    assert isinstance(ite.if_clause, Field)
    assert isinstance(ite.then_clause, Any)
    assert isinstance(ite.else_clause, Any)


# Generated at 2022-06-12 15:34:26.164211
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    sample = OneOf(Fields)
    sample.validate('123')


# Generated at 2022-06-12 15:34:27.100289
# Unit test for constructor of class OneOf
def test_OneOf():
   a = OneOf([Text(), String(), String(length=3)], description="this object")

# Generated at 2022-06-12 15:34:31.063829
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    field = OneOf([String(), String()])
    assert field.validate("foo") == "foo"



# Generated at 2022-06-12 15:34:41.475824
# Unit test for method validate of class Not
def test_Not_validate():
    # true
    assert Not(negated=Any()).validate(1) == 1
    assert Not(negated=Any()).validate(0.0) == 0.0
    assert Not(negated=Any()).validate(True) == True
    assert Not(negated=Any()).validate(False) == False
    assert Not(negated=Any()).validate({}) == {}
    assert Not(negated=Any()).validate([]) == []
    assert Not(negated=Any()).validate(None) == None
    assert Not(negated=Any()).validate("") == ""

    # false

# Generated at 2022-06-12 15:34:43.728965
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None
    then_clause = None
    else_clause = None
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)


# Generated at 2022-06-12 15:34:44.993472
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test = NeverMatch()
    assert test.errors == {"never": "This never validates."}



# Generated at 2022-06-12 15:34:47.822883
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    field.validate(None)

if __name__ == "__main__":
    test_Not_validate()

# Generated at 2022-06-12 15:34:48.752300
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()

# Generated at 2022-06-12 15:34:53.086117
# Unit test for constructor of class OneOf
def test_OneOf():
    int_field = OneOf(1, error="this is not 1")
    # assert type(int_field) == Field
    # assert int_field.errors == {'max_value': 'Ensure this value is less than or equal to 10.', 'min_value': 'Ensure this value is greater than or equal to 0.'}
    print(int_field)

# Generated at 2022-06-12 15:34:56.305826
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(String())
    n.validate("test")
    try:
        n.validate(1)
        assert False, "Should have failed"
    except ValidationError as e:
        assert e.field_name == ""


# Generated at 2022-06-12 15:34:57.213058
# Unit test for constructor of class OneOf
def test_OneOf():
    None


# Generated at 2022-06-12 15:35:01.444371
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Number(min_value=5))
    assert_equal(field.validate(4), 4)
    assert_equal(field.errors, {})

    with assert_raises(ValidationError) as error:
        field.validate(5)

    assert_equal(field.errors, {'negated': 'Must not match.'})



# Generated at 2022-06-12 15:35:09.409035
# Unit test for method validate of class Not
def test_Not_validate():
    
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(123) == 123

    


# Generated at 2022-06-12 15:35:13.160464
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=NeverMatch())
    assert not_field.validate("foo")
    # Test for the error
    
    
    
    

# Generated at 2022-06-12 15:35:14.580264
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), Field)


# Generated at 2022-06-12 15:35:17.465047
# Unit test for method validate of class Not
def test_Not_validate():
    s = Not("test")
    assert s.get_validation_error("test") is not None

    s = Not("test")
    assert s.validate("nottest") is None

# Generated at 2022-06-12 15:35:23.247735
# Unit test for constructor of class OneOf
def test_OneOf():
    # Should have no error messages
    o = OneOf([Int(), Float()])
    assert o.errors == {
        "no_match": "Did not match any valid type.",
        "multiple_matches": "Matched more than one type.",
    }
    # Should be strict
    assert o.strict
    # Should have correct one_of
    assert o.one_of == [Int(), Float()]


# Generated at 2022-06-12 15:35:27.372909
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=Any())
    # Valid case
    n.validate(1, False)
    # Invalid case
    try: 
        n.validate(None, False)
        raise AssertionError()
    except:
        pass

# Generated at 2022-06-12 15:35:28.539660
# Unit test for constructor of class OneOf
def test_OneOf():
    field=OneOf([])
    return


# Generated at 2022-06-12 15:35:30.278710
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(name="id")
    assert field.errors["never"] == "This never validates."


# Generated at 2022-06-12 15:35:33.199810
# Unit test for method validate of class Not
def test_Not_validate():
    '''Test if it prints error message when the error is raised'''
    try:
        assert Field.validation_error('negated')
    except AttributeError:
        print('Testing if the Not class returns the error message for the given error')
        print('AttributeError: '+ str(AttributeError))


# Generated at 2022-06-12 15:35:34.097562
# Unit test for constructor of class Not
def test_Not():
    n = Not(negated=None)
    assert n.negated is None

# Generated at 2022-06-12 15:35:37.652337
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-12 15:35:39.671267
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)


# Generated at 2022-06-12 15:35:42.540508
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field=IfThenElse(String(),Number())
    assert field.if_clause == String()
    assert field.then_clause == Number()
    assert field.else_clause == Any()


# Generated at 2022-06-12 15:35:43.912491
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate(None) == None


# Generated at 2022-06-12 15:35:45.316249
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([NeverMatch()])
    assert not None

# Generated at 2022-06-12 15:35:48.549431
# Unit test for constructor of class AllOf
def test_AllOf():
    validate_1 = Field()
    validate_2 = Field()
    all_of = AllOf([validate_1, validate_2])
    assert all_of.all_of == [validate_1, validate_2]


# Generated at 2022-06-12 15:35:49.952250
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([1,2,3]) != None


# Generated at 2022-06-12 15:35:51.120501
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer
    assert OneOf([Integer()])

# Generated at 2022-06-12 15:35:54.054008
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Basic test for constructor of class NeverMatch
    # Test basic functionality
    NeverMatch(name="test_NeverMatch", description="Just a test")
    NeverMatch()
    NeverMatch(field_name="test_NeverMatch")
    NeverMatch(error_messages={"never": "This never validates."})


# Generated at 2022-06-12 15:35:55.981319
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {'never': 'This never validates.'}
    pass


# Generated at 2022-06-12 15:36:02.271043
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate(0) == True
    assert NeverMatch().validate(False) == False
    assert NeverMatch().validate(True) == False
    assert 'never' in str(NeverMatch().__dict__)


# Generated at 2022-06-12 15:36:04.350294
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    import pytest
    n = NeverMatch()
    with pytest.raises(AssertionError):
        n = NeverMatch(allow_null=True)

# Generated at 2022-06-12 15:36:06.240527
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    a = Not(String())
    pass


# Generated at 2022-06-12 15:36:08.366017
# Unit test for constructor of class OneOf
def test_OneOf():
    my_oneof = OneOf([], field_name='my_oneof')
    assert (my_oneof.field_name == 'my_oneof')


# Generated at 2022-06-12 15:36:09.470119
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    assert AllOf([String(), String()])

# Generated at 2022-06-12 15:36:10.209939
# Unit test for constructor of class Not
def test_Not():
    n = Not(Any())

# Generated at 2022-06-12 15:36:17.949903
# Unit test for constructor of class Not
def test_Not():
    # Unit test for constructor of class Not
    type_checker = MonkeyType()
    log = type_checker.log
    value = Not(negated=None)
    assert len(log) == 7
    assert log[0] == \
    'src/typesystem/utils.py:113: note: Call to function "__init__" defined at src/typesystem/fields.py:430'
    assert log[1] == '    def __init__(self, negated: Field, **kwargs: typing.Any) -> None:'
    assert log[2] == '    def __init__(self, negated: None, **kwargs: typing.Any) -> None:'
    assert log[3] == '    def __init__(self, negated: Optional[Field], **kwargs: typing.Any) -> None:'

# Generated at 2022-06-12 15:36:20.106773
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf(all_of=['a'])
    assert a.__init__(all_of=['a']) == None


# Generated at 2022-06-12 15:36:25.096105
# Unit test for constructor of class OneOf
def test_OneOf():
    from typing import List
    from typesystem.fields import Integer
    from typesystem import Array

    one_of = Integer() | Array()
    assert isinstance(one_of, OneOf)
    assert isinstance(one_of.one_of, List)
    assert isinstance(one_of.one_of[0], Integer)
    assert isinstance(one_of.one_of[1], Array)

# Generated at 2022-06-12 15:36:26.979010
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field


# Generated at 2022-06-12 15:36:42.803246
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Integer, String, Tuple
    # 
    myInt = Integer()
    # 
    myString = String()
    # 
    myTuple = Tuple(one_of=[myInt, myString])
    # 
    myNot = Not(negated=myTuple)
    # 
    assert myNot.validate(1) == 1
    # 
    assert myNot.validate("a") == "a"
    # 
    try:
        # 
        myNot.validate(["a", "b"])
        # 
    except ValidationError as e:
        # 
        assert e.code == "negated"
        # 
    else:
        # 
        raise AssertionError("Expected an exception.")

# Generated at 2022-06-12 15:36:44.061762
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([
    ])

# Generated at 2022-06-12 15:36:52.409558
# Unit test for constructor of class Not
def test_Not():
    assert issubclass(Not, Field)
    # Check that 'assert "allow_null" not in kwargs' in constructor passes.
    assertNot(None)
    # Check default values for fields
    assertNot().errors == {"negated": "Must not match."}
    assertNot().negated == None
    # Check 'assert "allow_null" not in kwargs' in constructor passes.
    assertNot(negated=None)
    # Check that 'self.negated = negated' in constructor passes.
    assertNot(None).negated == None
    assertNot().negated == None
    assertNot(negated=None).negated == None


# Generated at 2022-06-12 15:36:54.034156
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    #Arrange
    test = NeverMatch()
    #Act
    #Assert
    assert test.errors == {"never": "This never validates."}

# Generated at 2022-06-12 15:36:55.829862
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(None)
    assert not_field.errors['negated'] == "Must not match."

# Generated at 2022-06-12 15:36:56.998215
# Unit test for constructor of class Not
def test_Not():
    n = Not(negated=None)
    assert n.negated is None

# Generated at 2022-06-12 15:37:02.592126
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test 1
    schema = [
                {
                    "type": "integer",
                    "minimum": 1,
                    "maximum": 10
                },
                {
                    "type": "integer",
                    "minimum": 5,
                    "maximum": 15
                }
            ]

    expected = OneOf(from_json(schema), title="test", description="test")
    assert isinstance(expected, OneOf)
    assert expected.title == "test"
    assert expected.description == "test"
    assert isinstance(expected.one_of, list)


# Generated at 2022-06-12 15:37:04.141446
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]

# Generated at 2022-06-12 15:37:05.199739
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-12 15:37:07.421619
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    oneOf_ob1 = OneOf(one_of= [])
    assert oneOf_ob1.validate(1) == 1

# Generated at 2022-06-12 15:37:21.530907
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    print(field.validate(1))


# Generated at 2022-06-12 15:37:22.366897
# Unit test for constructor of class Not
def test_Not():
    f = Not(Field())

# Generated at 2022-06-12 15:37:27.258205
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test that function throws an exception when first argument is not a list
    try:
        field = AllOf('a', required=True)
        has_err = False
    except AssertionError:
        has_err = True
    assert has_err

    # Test that function raises an exception when first argument is an empty list
    try:
        field = AllOf([], required=True)
        has_err = False
    except AssertionError:
        has_err = True
    assert has_err

    # Test that function raises an exception when second argument is not a boolean
    try:
        field = AllOf([String()], required='a')
        has_err = False
    except AssertionError:
        has_err = True
    assert has_err

    # Test that function raises an exception when keyword argument is not valid
   

# Generated at 2022-06-12 15:37:34.217895
# Unit test for constructor of class OneOf
def test_OneOf():
    """
    Check if OneOf has the fields that it requires.
    """
    data = OneOf(allow_empty=True)
    # Test for field 'one_of' in data class
    assert hasattr(data, 'one_of')
    # Test for field 'errors' in data class
    assert hasattr(data, 'errors')
    # Test for field 'allow_empty' in data class
    assert hasattr(data, 'allow_empty')


# Generated at 2022-06-12 15:37:34.955231
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Test method validate of class OneOf
    """

# Generated at 2022-06-12 15:37:36.898722
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert isinstance(all_of, AllOf)
    assert isinstance(all_of, Field)


# Generated at 2022-06-12 15:37:44.805564
# Unit test for constructor of class OneOf
def test_OneOf():
    from .fields import String, Number
    from .constraints import MaxLength
    from .exceptions import ValidationError
    from .validators import validate

    class Schema(types.Schema):
        foo = OneOf([
            String(max_length=5),
            Number(max_value=10),
        ])

    assert validate(Schema, {"foo": 1}) == {"foo": 1}
    assert validate(Schema, {"foo": "hello"}) == {"foo": "hello"}
    with pytest.raises(ValidationError) as exc_info:
        validate(Schema, {"foo": "hello world"})
    assert exc_info.value.as_dict() == {
        "foo": ["Too long."]
    }

# Generated at 2022-06-12 15:37:46.938866
# Unit test for constructor of class Not
def test_Not():
    notClause = Not(None)
    assert notClause.negated == None
    assert notClause.errors == {'negated': 'Must not match.'}
    assert type(notClause) == Not

# Unit test test_validate() function of class Not

# Generated at 2022-06-12 15:37:47.710540
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nevermatch = NeverMatch()

# Generated at 2022-06-12 15:37:50.331619
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Schema, String, Integer
    from typesystem.fields import Array

    class AllOfSchema(Schema):
        class Meta:
            fields = ('data',)
        data = Array(AllOf([String(), Integer()]))

    try:
        allof = AllOfSchema(data=['string', 1])
    except:
        allof = None

    assert allof



# Generated at 2022-06-12 15:38:34.473041
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(if_clause=Any(), then_clause=Int(), else_clause=Int())
    ite = IfThenElse(if_clause=Any())
    ite = IfThenElse(if_clause=Any(), then_clause=Int())
    ite = IfThenElse(if_clause=Any(), else_clause=Int())

# Generated at 2022-06-12 15:38:37.196718
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        args = [Any()]
        OneOf(args)
    except TypeError as e:
        assert str(e) == 'OneOf(): incompatible constructor arguments. The following arguments are given: [<typesystem.fields.Any object at 0x04949930>], but the following arguments are required: one_of'
    else:
        raise AssertionError
