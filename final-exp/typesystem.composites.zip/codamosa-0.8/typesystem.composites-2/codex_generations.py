

# Generated at 2022-06-12 15:28:36.842251
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.errors == {"never": "This never validates."}
    return a


# Generated at 2022-06-12 15:28:38.676281
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import validate

    errors = validate(Not(Any(min_length=5)), "")
    assert errors["__root__"] == "Must not match."

# Generated at 2022-06-12 15:28:41.253967
# Unit test for constructor of class OneOf
def test_OneOf():
    field1 = Field()
    field2 = Field()

    ob = OneOf([field1, field2])
    ob.validate(3)
    assert ob.one_of == [field1, field2]


# Generated at 2022-06-12 15:28:41.739972
# Unit test for constructor of class Not
def test_Not():
    None

# Generated at 2022-06-12 15:28:52.272782
# Unit test for method validate of class Not
def test_Not_validate():
    from collections import namedtuple
    from . import String, Integer, Boolean
    import unittest

    class MyTest(unittest.TestCase):
        def test1(self):
            s = String()
            i = Integer()
            b = Boolean()
            field = Not(s)
            test_data = [
                (True,'a'),
                (False,1),
                (False,True)
            ]
            for p,t in test_data:
                try:
                    self.assertEqual(field.validate(t), t)
                    if p:
                        self.assertTrue(False)
                except:
                    if not p:
                        self.assertTrue(False)

    t = MyTest()
    t.test1()

# Generated at 2022-06-12 15:29:00.213262
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Tests that if the if clause passes then the then clause is used
    validator = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=String(),
    )
    assert validator.validate(1) == 1
    validator = IfThenElse(
        if_clause=Any(),
        then_clause=None,
        else_clause=String(),
    )
    assert validator.validate(1) == 1

    # Tests that if the if clause fails then the else clause is used
    validator = IfThenElse(
        if_clause=String(),
        then_clause=Any(),
        else_clause=Any(),
    )
    assert validator.validate(1) == 1

# Generated at 2022-06-12 15:29:09.862269
# Unit test for constructor of class Not
def test_Not():
    dataType = Not(String())

# Generated at 2022-06-12 15:29:22.428258
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A(object):
        a = 1
    # if_clause = Field(), then_clause = None, else_clause = None
    Field1 = IfThenElse(Field(), None, None)
    value = 1
    result = Field1.validate(value)
    assert result == value

    # if_clause = Field(), then_clause = Field(), else_clause = None
    Field2 = IfThenElse(Field(), Field(), None)
    value = A()
    result = Field2.validate(value)
    assert result == value

    # if_clause = Field(), then_clause = Field(), else_clause = Field()
    Field3 = IfThenElse(Field(), Field(), Field())
    value = A()
    result = Field3.validate(value)
    assert result == value



# Generated at 2022-06-12 15:29:26.386616
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from . import BaseError

    class UnitTestCase(unittest.TestCase):
        def test_validate(self):
            field = IfThenElse(
                if_clause = Str(),
                then_clause = Str(),
                else_clause = Str()
            )
            field.validate(1) # will raise an exception

    unittest.main()

test_IfThenElse_validate()

# Generated at 2022-06-12 15:29:34.916898
# Unit test for method validate of class Not
def test_Not_validate():
    try:
        test_field = Not(Integer())
        test_field.validate(1.1)
    except ValidationError as e:
        if "Must not match" == e.message and e.code == "negated":
            pass
        else:
            assert False

    try:
        test_field = Not(Integer())
        test_field.validate(2)
        assert False
    except ValidationError as e:
        if "Must not match" == e.message and e.code == "negated":
            assert False



# Generated at 2022-06-12 15:29:38.847271
# Unit test for method validate of class Not
def test_Not_validate():
    notTest = Not(Any())
    assert notTest.validate("test") == "test"

# Generated at 2022-06-12 15:29:40.989462
# Unit test for constructor of class Not
def test_Not():
    error = None
    try:
        Not(Field())
    except Exception as err:
        error = err
    assert error == None



# Generated at 2022-06-12 15:29:44.504160
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    This function checks the correct behavior of the validate method of class OneOf.
    """
    field = OneOf([Float()], name="OneOf_validate_test")
    expected_result = 12.5
    result = field.validate(12.5)
    assert result == expected_result



# Generated at 2022-06-12 15:29:45.834218
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[int])

    # TODO: add more unit tests


# Generated at 2022-06-12 15:29:51.093973
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = None
    then_clause = None
    else_clause = None
    if_clause = {}
    then_clause = {}
    else_clause = {}
    if_clause.validate(if_clause)
    then_clause.validate(then_clause)
    else_clause.validate(else_clause)
    return _



# Generated at 2022-06-12 15:29:52.825271
# Unit test for method validate of class Not
def test_Not_validate():
    val = Not(negated="_value")
    val._validate("_value")


# Generated at 2022-06-12 15:29:53.731294
# Unit test for constructor of class OneOf
def test_OneOf():
	assert OneOf.__init__



# Generated at 2022-06-12 15:29:55.325509
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(String(), allow_null=False)
    assert "Negated" in not_.validate("Negated")

# Generated at 2022-06-12 15:29:57.070011
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Null())
    assert not_field.validate(value=1) == 1
    assert not_field.validate(value=None) == None


# Generated at 2022-06-12 15:30:06.276883
# Unit test for method validate of class OneOf
def test_OneOf_validate():
	arr = [Type(True), Type(False), Type(3)]
	t = OneOf(arr)
	assert t.validate(True) == True
	assert t.validate(3) == 3
	try:
		t.validate([1,2,3])
		assert False
	except ValidationError:
		assert True
	except Exception:
		assert False

	arr = [Type(1), Type(2), Type(3)]
	t = OneOf(arr)
	try:
		t.validate([1,2,3])
		assert False
	except:
		assert True

# Generated at 2022-06-12 15:30:12.253043
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []

    field = OneOf([], description="foo")
    assert field.one_of == []
    assert field.description == "foo"

# Generated at 2022-06-12 15:30:13.231229
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])

# Generated at 2022-06-12 15:30:20.931550
# Unit test for method validate of class Not
def test_Not_validate():
    # create an instance of 'Field'
    field = Field()
    # create an instance of 'Not'
    not_ = Not(field)
    # try with any value different from none
    value = b'1'
    not_value = not_.validate(value)
    assert value == not_value
    # try with a value equal to none
    not_.negated.errors['negated'] = 'Must not match'
    none_value = not_.validate(None)
    assert value == none_value
    # try with a value different from none and not equal to the value of the negated field
    none_value = not_.validate(b'3')
    assert value == none_value

# Generated at 2022-06-12 15:30:24.210507
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test parameters
    one_of = [Field(name="test_field_name", required=True)]
    value = 'test_value'
    strict = True

    result = OneOf.validate(one_of,value,strict)

    assert value == result


# Generated at 2022-06-12 15:30:35.137533
# Unit test for constructor of class OneOf
def test_OneOf():
    # Create a fake field that will always validate
    class FakeField:
        def __init__(self):
            pass

        def validate_or_error(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value, None

    # Create a fake field that will never validate
    class FakeNotField:
        def __init__(self):
            pass

        def validate_or_error(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value, "validation_error"

    
    # Create an instance of OneOf
    one_of = OneOf([FakeField(), FakeNotField()])
    # Test first case "matched exactly one"
    try:
        one_of.validate(0)
    except:
        assert False
    # Test second case

# Generated at 2022-06-12 15:30:35.989949
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()


# Generated at 2022-06-12 15:30:41.995568
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=Field(type="boolean"))
    assert n.validate(True) == True
    assert n.validate(False) == False
    try:
        n.validate(None)
    except Exception as e:
        assert e.error_messages.get("negated") is not None
        assert e.error_messages.get("negated") == "Must not match."
    else:
        raise AssertionError("Input value None should not pass validation")


# Generated at 2022-06-12 15:30:45.416997
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    #type: () -> None
    instance = IfThenElse(None, None, None)
    input_value = None
    output = instance.validate(input_value)
    assert output == input_value, "Output should be equal to input value"

# Generated at 2022-06-12 15:30:51.454773
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import AllOf
    from typesystem.fields import Integer
    from typesystem.fields import String

    all_of = AllOf([Integer(), String()])
    for input_ in [1, "test"]:
        all_of.validate(input_)
    for input_ in [1.5, None, True]:
        try:
            all_of.validate(input_)
        except Exception:
            pass
        else:
            assert False



# Generated at 2022-06-12 15:30:52.374444
# Unit test for constructor of class Not
def test_Not():
    not_object = Not(negated = 5)
    assert not_object is not None


# Generated at 2022-06-12 15:31:06.807584
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    import unittest
    from typesystem.fields import Integer, Number

    class TestOneOf(unittest.TestCase):
        def test_OneOf_validate_more_than_one_true(self):
            try:
                field = OneOf([Integer(), Number()])
                field.validate(1)
            except Exception as e0:
                assert e0.args[0] == "Matched more than one type."
            else:
                assert False

        def test_OneOf_validate_more_than_one_false(self):
            try:
                field = OneOf([Integer(), Number()])
                field.validate(1)
            except Exception as e0:
                assert e0.args[0] == "Matched more than one type."
            else:
                assert False
    unittest.main

# Generated at 2022-06-12 15:31:18.662013
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import datetime
    c = IfThenElse(
        if_clause=str,
        then_clause=datetime.datetime,
        else_clause=datetime.date
    )
    str_test1 = '2020-01-01'
    str_test2 = '2020-01-01 11:11:11'
    str_test3 = '2020-01-02'
    str_test4 = '2020-01-02 11:11:11'

    assert c.validate(str_test1) == datetime.datetime.strptime(str_test1, '%Y-%m-%d')

# Generated at 2022-06-12 15:31:21.204180
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer, String

    field = AllOf([Integer(), String()])
    field.validate('foo')


# Generated at 2022-06-12 15:31:22.414534
# Unit test for constructor of class Not
def test_Not():
    Not({'a': 1}).validate({'a': 1})


# Generated at 2022-06-12 15:31:23.842486
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated = Integer())
    field.validate(value = "string")


# Generated at 2022-06-12 15:31:34.200842
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    
    IfThenElse(String(max_length=5), String(max_length=8)).validate('abcdefghi')
    IfThenElse(String(max_length=5), String(max_length=8)).validate('abcdefgh')
    
    try:
        IfThenElse(String(max_length=5), String(max_length=8)).validate('abcde')
        assert False, "Invalid validation"
    except ValidationError:
        pass

test_IfThenElse_validate.im_class.__name__ = 'test_IfThenElse_validate'

# Generated at 2022-06-12 15:31:42.686307
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Setup
    if_clause = Field(allow_null=True)
    then_clause = Field()
    else_clause = Field(allow_null=True)
    mock_kwargs = {'foo': 'bar'}

    # Exercise
    if_then_else = IfThenElse(if_clause, then_clause, else_clause, **mock_kwargs)

    # Verify
    assert if_then_else.allow_null == False
    assert if_then_else.if_clause is if_clause
    assert if_then_else.then_clause is then_clause
    assert if_then_else.else_clause is else_clause
    assert if_then_else.kwargs == {'foo': 'bar'}


# Generated at 2022-06-12 15:31:44.157431
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert type(NeverMatch(label="Hello!")) is NeverMatch

# Generated at 2022-06-12 15:31:47.153207
# Unit test for constructor of class AllOf
def test_AllOf():
  allOf1 = AllOf(all_of=["allOf"])
  assert allOf1
  allOf2 = AllOf(all_of=["another allOf"])
  assert allOf2


# Generated at 2022-06-12 15:31:48.127673
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf


# Generated at 2022-06-12 15:32:02.121970
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create instance of class
    instance = OneOf([])
    # Get data
    method_to_test = instance.validate
    # Create args
    args = [(None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), (None,), ]
    # Expected exceptions

# Generated at 2022-06-12 15:32:07.622419
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # empty IfThenElse
    assert IfThenElse() == {
        'type': 'object',
        'properties': {},
        'additionalProperties': True
    }
    # IfThenElse with one Field
    assert IfThenElse(Field(description='test'), **{'description': 'test2'}) == {
        'properties': {
            'description': {'type': 'string', 'description': 'test'}
        },
        'additionalProperties': False,
        'type': 'object',
        'description': 'test2'
    }

# Generated at 2022-06-12 15:32:17.526694
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    def test_1():
        if_clause = Any()
        then_clause = Bool()
        else_clause = Str()
        value = True

        if_then_else = IfThenElse(if_clause, then_clause, else_clause)
        actual = if_then_else.validate(value)

        assert actual is True

    def test_2():
        if_clause = Str()
        then_clause = Bool()
        else_clause = Str()
        value = True

        if_then_else = IfThenElse(if_clause, then_clause, else_clause)
        actual = if_then_else.validate(value)

        assert actual == value
        
    test_1()
    test_2()

# Generated at 2022-06-12 15:32:20.232959
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_it = IfThenElse()
    assert test_it.validate(4) == 4
    assert test_it.validate(None) == None
    assert test_it.validate(False) == False

# Generated at 2022-06-12 15:32:21.157516
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([str])



# Generated at 2022-06-12 15:32:23.111393
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Any()])
    assert field.one_of == [Any()]


# Generated at 2022-06-12 15:32:28.589076
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    t = IfThenElse(
        Number(),
        Number(minimum=5),
        Number(minimum=10)
    )
    assert t.validate(5) == 5
    assert t.validate(10) == 10
    assert t.validate(11) == 11
    with pytest.raises(t.validation_error):
        t.validate(3)
    t = IfThenElse(
        Number(),
        Number(),
        Number(minimum=10)
    )
    with pytest.raises(t.validation_error):
        t.validate('test')



# Generated at 2022-06-12 15:32:31.480803
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([],)
    assert field.one_of == []


# Generated at 2022-06-12 15:32:35.666795
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String

    field = IfThenElse(Integer(gt=1), Integer(gt=4), String())
    value = field.validate(3)
    assert value == 3
    value = field.validate(0)
    assert value == ""

# Generated at 2022-06-12 15:32:37.129601
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf([Any()]), OneOf)


# Generated at 2022-06-12 15:32:48.454733
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause='schema1')

    # case invalid data
    data = {}
    assert field.validate(data) == data

    # case valid data
    data = 'schema1'
    assert field.validate(data) == data


# Generated at 2022-06-12 15:32:54.595951
# Unit test for constructor of class Not
def test_Not():
    not_fail = Not(negated=False)
    not_success = Not(negated=True)
    assert not_fail.validate_or_error(False) == (False, None)
    assert not_fail.validate_or_error(True) == (True, None)
    assert not_success.validate_or_error(False) == (False, None)
    assert not_success.validate_or_error(True) == (True, None)


# Generated at 2022-06-12 15:32:58.305012
# Unit test for constructor of class AllOf
def test_AllOf():
    string = String()
    field_list = [string, string]

    field = AllOf(field_list)
    assert field.allow_null == False
    assert field.all_of == field_list


# Generated at 2022-06-12 15:33:01.878588
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = 1
    then_clause = 2
    else_clause = 3
    test = IfThenElse(if_clause, then_clause, else_clause)
    assert test.validate(1) == 2
    assert test.validate(2) == 3

# Generated at 2022-06-12 15:33:03.377501
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-12 15:33:09.358899
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Declaration of variables
    else_clause = None
    then_clause = None
    if_clause = None
    value = None
    strict = False
    strictOut = True
    
    
    #pass 'then_clause' a number
    then_clause = 1
    #pass 'else_clause' a number
    else_clause = 1
    
    
    
    
    
    
    
    
    
    
    
    
    #call the method validate from class IfThenElse with the arguments (then_clause, else_clause, if_clause)
    IfThenElse(then_clause, else_clause, if_clause).validate(value, strict)
    #pass 'then_clause' a number
    then_clause = 0
    #pass 'else_

# Generated at 2022-06-12 15:33:17.124611
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test Only for construction
    # Test for construction with correct args
    test = OneOf([], name="")

    # Test for construction with wrong args
    try:
        test = OneOf([], name="", allow_null=False)
    except:
        pass

    # Test for construction with correct args
    test = OneOf([Any()], name="")

    # Test for construction with wrong args
    try:
        test = OneOf([Any()], name="", allow_null=False)
    except:
        pass


# Generated at 2022-06-12 15:33:23.755877
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Integer()
    then_clause = String()
    else_clause = Integer()
    # type of value must be same to that of condition 'if' clause
    value = 5
    #put value
    a=IfThenElse(if_clause,then_clause,else_clause)
    b=a.validate(value)
    #if
    assert b == 5
    #else
    value=5.5
    c=a.validate(value)
    assert c == 5.5

# Generated at 2022-06-12 15:33:25.484765
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from . import String
    assert IfThenElse(String(), String()).validate(if_clause='1', then_clause='2') == '2'

# Generated at 2022-06-12 15:33:30.856763
# Unit test for method validate of class Not
def test_Not_validate():
    class test_Field(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise Field.validation_error("test")

    not_field = Not(test_Field())

    with pytest.raises(Field.ValidationError) as excinfo:
        not_field.validate("123")
    assert excinfo.value.code == "negated"

    not_field.validate("1234")



# Generated at 2022-06-12 15:33:52.148602
# Unit test for constructor of class Not
def test_Not():
    s = Not(negated = 'field')
    assert type(s) is Not

# Generated at 2022-06-12 15:33:52.671046
# Unit test for method validate of class Not
def test_Not_validate():
    pass

# Generated at 2022-06-12 15:33:56.626809
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate("spam") == "spam"
    with pytest.raises(field.validation_error) as failed:
        field.validate(None)
    assert failed.value.code == "negated"
    assert str(failed.value) == "Must not match."


# Generated at 2022-06-12 15:33:59.278847
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # validator = OneOf('name', one_of=[String(), Number()])
    # assert validator.validate(1) == 1
    # validator.validate('')
    assert True

# Generated at 2022-06-12 15:33:59.833529
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()

# Generated at 2022-06-12 15:34:03.126120
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert 1 == IfThenElse(Integer(), Integer(max_value=10), Integer(max_value=20)).validate(1)
    assert 2 == IfThenElse(Integer(max_value=2), Integer(max_value=10), Integer(max_value=20)).validate(2)
    assert 3 == IfThenElse(Integer(max_value=2, min_value=1), Integer(max_value=10), Integer(max_value=20)).validate(3)
    assert 4 == IfThenElse(Integer(max_value=2, min_value=4), Integer(max_value=10), Integer(max_value=20)).validate(4)

# Generated at 2022-06-12 15:34:10.862795
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert (1, None) == IfThenElse(Structure({'id': Boolean(strict=False)}), Integer(strict=False)).validate_or_error({'id': True})
    assert (1, None) == IfThenElse(Structure({'id': Boolean(strict=False)}), Integer(strict=False), String(strict=False)).validate_or_error({'id': True})
    assert (1, None) == IfThenElse(Structure({'id': Boolean(strict=False)}), Integer(strict=False)).validate_or_error({'id': True})
    assert (1, None) == IfThenElse(Structure({'id': Boolean(strict=False)}), Integer(strict=False)).validate_or_error({'id': True})

# Generated at 2022-06-12 15:34:14.214833
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # fields = [Field1, Field2]
    # one_of_type = OneOf(fields)
    # values = [value1, value2]
    # one_of_type.validate(values)
    pass

# Generated at 2022-06-12 15:34:18.726642
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class OneOfField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    field = OneOf([OneOfField()])
    value = 1
    assert field.validate(value) == value, "value is not equal to the return value of the validate method of class OneOf"


# Generated at 2022-06-12 15:34:24.053388
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(subtype_accumulator[0:3])
    with pytest.raises(Exception):
        one_of.validate(subtype_test_values[0])
    with pytest.raises(Exception):
        one_of.validate(subtype_test_values[1:4])


# Generated at 2022-06-12 15:34:45.704548
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Schema


# Generated at 2022-06-12 15:34:49.252557
# Unit test for constructor of class Not
def test_Not():
    notMatch = Not(NeverMatch())
    with pytest.raises(Not.validation_error) as excinfo:
        notMatch.validate(1)
        assert str(excinfo.value) == "Must not match."


# Generated at 2022-06-12 15:34:54.254445
# Unit test for constructor of class Not
def test_Not():
    not_test = Not(negated=Field(name="Negated field"))
    assert len(not_test.errors) == 1, "Not has wrong number of errors."
    assert 'negated' in not_test.errors, "Not does not have 'negated' error."
    assert not_test.negated.name == "Negated field", "Not's negated field is incorrect."


# Generated at 2022-06-12 15:34:55.943317
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.error_messages import ErrorMessage, JSON_SCHEMA_FORMAT

    field = OneOf(one_of=[String()])
    assert isinstance(field, Field)


# Generated at 2022-06-12 15:35:03.064242
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(then_clause = Field(constraints = {"min_length": 3}),
                       else_clause = Field(constraints = {"min_length": 1}),
                       if_clause = Field(constraints = {"min_length": 2}))
    assert field.validate("12") == "12"
    assert field.validate("123") == "123"
    with pytest.raises(ValidationError, match = "Must be at least 3 characters"):
        field.validate("1234")
    with pytest.raises(ValidationError, match = "Must be at least 1 character"):
        field.validate("1")



# Generated at 2022-06-12 15:35:05.478522
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = String()
    then_clause = String()
    else_clause = String()
    value = "test"
    x = IfThenElse(if_clause, then_clause, else_clause)
    assert x.validate(value) == value

#############

# Generated at 2022-06-12 15:35:09.460919
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # test the case error is None
    test_object = IfThenElse(Any())
    assert test_object.validate(True) == True

    # test the case error is not None
    assert test_object.validate(None) is None



# Generated at 2022-06-12 15:35:14.392060
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String
    field = OneOf([Integer(), String()])
    expected = "not an integer"
    try:
        result = field.validate("not an integer")
    except Exception as e:
        assert str(e) == expected


# Generated at 2022-06-12 15:35:17.308565
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_value = 'hola'
    expected_output = 'hola'
    assert OneOf([]).validate(test_value) == expected_output


# Generated at 2022-06-12 15:35:20.333451
# Unit test for method validate of class Not
def test_Not_validate():
    schema = Not(Field(label="field"))
    try:
        schema.validate(None)
        assert True
    except:
        assert False

    try:
        schema.validate(5)
        assert False
    except:
        assert True


# Generated at 2022-06-12 15:35:43.762911
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(1,2,3) is not None

# Generated at 2022-06-12 15:35:47.627536
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test validate method of class IfThenElse
    """
    int_field = Field()
    ite_field = IfThenElse(int_field)
    try:
        ite_field.validate("abc")
        assert False
    except:
        assert True

# Generated at 2022-06-12 15:35:52.968746
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = typesystem.String(required=True)
    b = typesystem.String(required=True)
    c = typesystem.String(required=True)
    fields = typesystem.AllOf([a, b, c])

    assert fields.validate({"a": "abc", "b": "def", "c": "ghi"}) == {
        "a": "abc",
        "b": "def",
        "c": "ghi",
    }


# Generated at 2022-06-12 15:35:55.320018
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    class Example(Integer, String):
        pass
    field = Example()

    field.validate("hello")
    field.validate(123)

# Generated at 2022-06-12 15:35:59.560898
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Integer(min_value=1), Integer(min_value=10)])
    field.validate(10)
    field.validate(1)
    try:
        field.validate(9)
    except FieldValidationError as error:
        assert error.key == 'no_match'
    try:
        field.validate(3)
    except FieldValidationError as error:
        assert error.key == 'multiple_matches'

# Generated at 2022-06-12 15:36:05.783375
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    # Good values.
    field.validate(None)
    field.validate(123)
    field.validate("hi")
    field.validate({"a": True})

    # Bad values.
    field.validate(1234, strict=True)
    field.validate(1234)

    # field = OneOf([
    #     Int(),
    #     Str(),
    # ])

    # field.validate(123)
    # field.validate("hi")
    # field.validate(1234)

# Generated at 2022-06-12 15:36:10.701124
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([IntegerField(), StringField()]).validate(2) == 2
    assert OneOf([IntegerField(), StringField()]).validate("2") == "2"
    try:
        OneOf([IntegerField(), StringField()]).validate(2.0)
        assert False
    except ValidationError:
        pass
    try:
        OneOf([IntegerField(), StringField()]).validate([1,2])
        assert False
    except ValidationError:
        pass
    try:
        OneOf([IntegerField(), StringField()]).validate({})
        assert False
    except ValidationError:
        pass
    try:
        OneOf([IntegerField(), StringField()]).validate(None)
        assert False
    except ValidationError:
        pass



# Generated at 2022-06-12 15:36:15.746045
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Test(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
            
    f = IfThenElse(Test(nullable=False), Test(nullable=False), Test(nullable=False))
    assert f.validate(42) == 42
    assert ['This field is not nullable.'] == f.validate(None)
    assert f.validate("hello") == "hello"


# Generated at 2022-06-12 15:36:19.538299
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause = Dict(properties={"id": Integer()}),
        then_clause = Dict(properties={"age": Integer()}),
        else_clause = Dict(properties={"name": String()})
    )
    assert field.validate({"id":1}) == {"age": 1}
    assert field.validate({"name":"test"}) == {"name": "test"}

# Generated at 2022-06-12 15:36:20.512429
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse('1', '2', '3')

# Generated at 2022-06-12 15:36:34.862862
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch() is not None

# Generated at 2022-06-12 15:36:39.758057
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test TypeError exception case
    with pytest.raises(TypeError):
        # initializing class instance
        field = OneOf(["Field", "Field", "Field"], name="Field")

        # calling method validate with valid arguments
        value = "Field"
        strict = False
        field.validate(value, strict=False)



# Generated at 2022-06-12 15:36:41.889429
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test the constructor 
    n = NeverMatch()
    assert n.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:36:49.126098
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = MockField(name='if_clause')
    then_clause = MockField(name='then_clause')

    field = IfThenElse(if_clause, then_clause)
    assert field.name == 'IfThenElse'
    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert field.else_clause == Any()



# Generated at 2022-06-12 15:36:52.946439
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Integer, String
    field1 = IfThenElse(if_clause = Integer(), then_clause = String())
    assert field1.if_clause is not None
    assert field1.then_clause is not None
    assert field1.else_clause is not None
    assert field1.description is None
    assert field1.title is None

# Generated at 2022-06-12 15:36:53.730118
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-12 15:37:02.016344
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema_a = {
        "title": "A",
        "type": "object",
        "properties": {
            "a": {"type": "integer", "enum": [1, 2]},
            "b": {"type": "integer"},
        },
        "required": ["a"],
    }

    schema_b = {
        "title": "B",
        "type": "object",
        "properties": {
            "a": {"type": "integer", "enum": [3, 4]},
            "b": {"type": "integer"},
        },
        "required": ["a"],
    }


# Generated at 2022-06-12 15:37:05.408265
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Int(),Str(),Float()])
    field.validate(1)
    field.validate('a')
    field.validate(1.0)
    try:
        field.validate(True)
    except:
        print('test_OneOf_validate passed')
test_OneOf_validate()


# Generated at 2022-06-12 15:37:15.087605
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    correct_form={'id':'a','group':'1','name':'z','age':'20','team':'2','grade':'100'}
    incorrect_form={'id':'a','group':'1','name':'z','age':'20','team':'2','grade':'200'}
    result_correct_form=IfThenElse(Field(key='grade', constrain=lambda x: x<=100), Field(key='grade', constrain=lambda x: x<=100)).validate(correct_form)
    result_incorrect_form=IfThenElse(Field(key='grade', constrain=lambda x: x<=100), Field(key='grade', constrain=lambda x: x<=100)).validate(incorrect_form)
    assert result_correct_form==correct_form
    assert result

# Generated at 2022-06-12 15:37:16.060523
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(Field())
    assert a is not None

# Generated at 2022-06-12 15:37:56.736519
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(), None)
    assert field.validate(None) == None
    field2 = IfThenElse(Any(), None, None)
    assert field2.validate(None) == None
    field3 = IfThenElse(NeverMatch())
    assert field3.validate(None) == None

# Generated at 2022-06-12 15:38:06.923278
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class PrimitiveField(Field):
        def __init__(self,name: str,value: typing.Any):
            super().__init__(name=name)
            self.value = value

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == self.value:
                return value
            return Any().validate(value,strict=strict)

    x = PrimitiveField("my_field",1)
    y = PrimitiveField("my_field",0)


    # Test case when the if clause matches
    obj = IfThenElse(if_clause=x,then_clause=x)
    obj.validate(1)

    # Test case when the if clause matches but then clause fails, else clause passes

# Generated at 2022-06-12 15:38:13.193478
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import json
    schema = IfThenElse(
             if_clause = Any(),
             then_clause = Any(),
             else_clause = Any(),
             name = "test_ifthenelse",
             )
      
    # Test for valid value
    
    value = "valid"
    schema.validate(value)
    
    # Test for invalid value
    with pytest.raises(ValidationError):
        value = "invalid"
        print(schema.validate(value))

# Generated at 2022-06-12 15:38:20.955695
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Testcase 1
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    field = IfThenElse(if_clause, then_clause, else_clause)
    val = ''
    with pytest.raises(typesystem.ValidationError):
        # when not in else clause
        field.validate(val)
    # Testcase 2
    if_clause = Any()
    then_clause = Any()
    else_clause = None
    field = IfThenElse(if_clause, then_clause, else_clause)
    val = ''
    with pytest.raises(typesystem.ValidationError):
        # when not in else clause
        field.validate(val)
    # Testcase 3

# Generated at 2022-06-12 15:38:23.582975
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse(Int(),Float())
    b = IfThenElse(Int(),Float(minimum=1,maximum=10))
    assert a.validate(1)==1.0
    assert b.validate(1,strict=True)==1.0
    assert b.validate(20,strict=True)==1.0

# Generated at 2022-06-12 15:38:26.515767
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.fields import Integer
    field = OneOf([String(), Integer()])
    assert field.validate("1") == "1"
    assert field.validate(1) == 1
    try:
        field.validate(1.5)
        assert False
    except ValidationError:
        pass
    try:
        field.validate(1.5, strict=True)
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-12 15:38:31.476872
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print("Testing NeverMatch", end="")
    nm = NeverMatch()
    # Test validation
    try:
        value = nm.validate(1)
        print("... failed")
        raise AssertionError("Should not have passed validation.", value)
    except Exception as e:
        pass
    print("... passed")
