

# Generated at 2022-06-12 15:28:41.086357
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    assert f.validate(1) == 1


# Generated at 2022-06-12 15:28:47.104179
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import (
        Array,
        Boolean,
        Float,
        Integer,
        String,
        Null,
    )

    # test if clause
    field = IfThenElse(if_clause=Null())

    # test then clause
    field = IfThenElse(if_clause=Null(), then_clause=Null())

    # test else clause
    field = IfThenElse(if_clause=Null(), else_clause=Null())

    # test then and else clause
    field = IfThenElse(if_clause=Null(), then_clause=Null(), else_clause=Null())

    # test if clause and then clause

# Generated at 2022-06-12 15:28:48.513120
# Unit test for method validate of class Not
def test_Not_validate():
    not_1 = Not({})
    assert not_1.validate({}) == {}

# Generated at 2022-06-12 15:28:54.759904
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Cases covered:
    - Normal or Normal = Normal
    """

    meth = IfThenElse.validate
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()

    value = 42
    strict = False
    
    if_clause.validate_or_error = lambda x, s=None: [x, None]
    then_clause.validate_or_error = lambda x, s=None: [x, None]

    assert meth(if_clause, then_clause, else_clause, value, strict) == value
    assert meth(if_clause, then_clause, else_clause, value, strict) == 42
    
    
if __name__ == "__main__":
    import pytest

# Generated at 2022-06-12 15:28:55.257191
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([
        Field()
    ])

# Generated at 2022-06-12 15:28:57.394135
# Unit test for constructor of class AllOf
def test_AllOf():
    str_list = ['0','1','2','3','4','5','6','7','8','9']
    field = AllOf(str_list)


# Generated at 2022-06-12 15:28:59.080213
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf.__init__

# Generated at 2022-06-12 15:29:04.410999
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Input parameters for constructor:
    one_of = [str, int, float]
    # Expected output The following line is filtered out by black
    expected_output: typing.Any = 5
    one_of_obj = OneOf(one_of)
    output = one_of_obj.validate(5)
    assert output == expected_output

# Generated at 2022-06-12 15:29:06.999142
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    a = OneOf([Integer()])
    with pytest.raises(ValidationError):
        a.validate("")
    with pytest.raises(ValidationError):
        a.validate("", False)



# Generated at 2022-06-12 15:29:18.121623
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(
        if_clause=Field(),
        then_clause=Field(),
    ).validate(value=None, strict=False) == None
    assert IfThenElse(
        if_clause=Field(),
        else_clause=Field(),
    ).validate(value=None, strict=False) == None
    assert IfThenElse(
        if_clause=Field(),
        then_clause=Field(),
        else_clause=Field(),
    ).validate(value=None, strict=False) == None
    assert IfThenElse(
        if_clause=Field(),
        then_clause=Field(),
        else_clause=Field(),
    ).validate(value=None, strict=True) == None

# Generated at 2022-06-12 15:29:23.047813
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(1)

# Generated at 2022-06-12 15:29:24.822237
# Unit test for constructor of class AllOf
def test_AllOf():
    d = AllOf([1, 2, 3])
    assert d.all_of == [1, 2, 3]


# Generated at 2022-06-12 15:29:37.253144
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    all_nulls = OneOf([])
    assert all_nulls.errors['no_match'] == 'Did not match any valid type.'
    assert all_nulls.errors['multiple_matches'] == 'Matched more than one type.'
    assert all_nulls.validate('one') == None
    assert all_nulls.validate(['two', 2, 3.0]) == None
    two_ints = OneOf([Integer(), Integer()])
    assert two_ints.validate(1) == 1
    assert two_ints.validate(1.0) == None
    assert two_ints.validate(['one']) == None
    assert two_ints.validate(['one', 2, 3.0]) == None
    one_of_two = OneOf([String(), Integer()])
    assert one_of_two

# Generated at 2022-06-12 15:29:40.296256
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(1, then_clause=10, else_clause=100)
    assert x.validate(10) == 10
    assert x.validate(100) == 100

# Generated at 2022-06-12 15:29:43.577152
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_schema = OneOf(one_of=[{'a':1},{'b':2},{'c':3}])
    test_data = {'a':1}
    test_output = test_schema.validate(test_data)

    assert type(test_output) is dict
    assert test_output == test_data

# Generated at 2022-06-12 15:29:46.345504
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import String

    # Create an object of class String with the name attribute
    negated = String(name="name")
    # Create an object of class Not with the attribute negated
    objectNot = Not(negated=negated)

    assert objectNot.validate(3) == 3

# Generated at 2022-06-12 15:29:55.786392
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    int_field = Field(type=int, required=True)
    string_field = Field(type=str, required=True)

    assert int_field.validate(1)

    if_field = IfThenElse(
        if_clause=int_field,
        then_clause=int_field,
        else_clause=string_field,
        required=True,
    )
    assert 1 == if_field.validate(1)
    assert 'a' == if_field.validate('a')

    if_field = IfThenElse(
        if_clause=string_field,
        then_clause=int_field,
        else_clause=int_field,
        required=True,
    )
    assert 1 == if_field.validate('a')

# Generated at 2022-06-12 15:29:56.199481
# Unit test for method validate of class Not
def test_Not_validate():
    pass

# Generated at 2022-06-12 15:30:06.787394
# Unit test for method validate of class Not
def test_Not_validate():
    # create Not object
    not_object = Not(Int())

    # test when value is None
    assert not_object.validate(None) is None

    # test with value not None
    assert not_object.validate(1) is None
    assert not_object.validate(0) is None
    assert not_object.validate(1.0) is None
    assert not_object.validate('1') is None
    assert not_object.validate('abc') is None

    # test with invalid value
    try:
        not_object.validate('abc')
    except ValueError:
        pass

    # create Not object
    not_object = Not(Str())

    # test when value is None
    assert not_object.validate(None) is None

    # test with value not None
    assert not_

# Generated at 2022-06-12 15:30:08.343398
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f = OneOf([Any(), Any(), Any()])
    f.validate("abc")


# Generated at 2022-06-12 15:30:16.796578
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = TrueField()
    then_clause = FalseField()
    else_clause = Any()
    my_var = IfThenElse(if_clause, then_clause, else_clause)
    my_var.validate(1)
    assert not my_var.validate(0)



# Generated at 2022-06-12 15:30:20.883721
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not({'a': int, 'b': int})
    assert field.validate({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert field.validate(1) == 1



# Generated at 2022-06-12 15:30:22.914394
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=AllOf(all_of=[Any()]))
    assert field.validate(None) == None

# Generated at 2022-06-12 15:30:23.616376
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch('never match')


# Generated at 2022-06-12 15:30:27.853491
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_if_clause(value):
        if value % 2 == 0:
            return value + 1
        else:
            return value - 1

    if_clause = Field(validators=[test_if_clause])
    then_clause = Field(validators=[lambda x: x*x])
    field = IfThenElse(if_clause=if_clause, then_clause=then_clause)
    assert field.validate(2) == 5
    assert field.validate(3) == 8


# Generated at 2022-06-12 15:30:37.996199
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    clause_1 = None
    clause_2 = None
    clause_3 = None
    valid_value = 5
    invalid_value = 10
    
    # 1.
    clause_1 = None
    clause_2 = None
    clause_3 = None
    valid_value = 5
    invalid_value = 10
    ifthenelse_schema = IfThenElse(clause_1, clause_2, clause_3)
    assert(ifthenelse_schema.validate(valid_value) == valid_value)
    assert(ifthenelse_schema.validate(invalid_value) == invalid_value)

    # 2.
    clause_1 = None
    clause_2 = Clause(5)
    clause_3 = None
    valid_value = 5
    invalid_value = 10
    ifthenelse_sche

# Generated at 2022-06-12 15:30:39.767319
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print(NeverMatch())
    assert True


# Generated at 2022-06-12 15:30:41.239021
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field != None

# Generated at 2022-06-12 15:30:42.562004
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(name='one_of')


# Generated at 2022-06-12 15:30:48.014150
# Unit test for constructor of class AllOf
def test_AllOf():
    # When passed an iterable, it should assign to the all_of variable
    field = AllOf(all_of=["a", "b", "c"])
    assert field.all_of == ("a", "b", "c")
    # When passed a non-iterable, it should throw a TypeError
    with raises(TypeError):
        AllOf(all_of="test")



# Generated at 2022-06-12 15:30:50.345775
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-12 15:30:59.250378
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Type error
    assert IfThenElse(1).validate(value="fail", strict=False) is None
    # False
    false_value = IfThenElse(Boolean(label="false", default=False)).validate(value=1, strict=False)
    assert false_value is 1
    # True
    true_value = IfThenElse(Boolean(label="true", default=True)).validate(value=0, strict=False)
    assert true_value is 0
    # False, False
    false_false_value = IfThenElse(Boolean(label="false", default=False), Boolean(label="false", default=False)).validate(value=1, strict=False)
    assert false_false_value is 1
    # False, True

# Generated at 2022-06-12 15:31:10.129382
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(Any(), Any())
    assert ite.validate(10) == 10
    assert ite.validate(10.0) == 10.0
    assert ite.validate(10) == 10
    assert ite.validate(10.0) == 10.0
    ite = IfThenElse(None, Any())
    assert ite.validate(10) == 10
    assert ite.validate(10.0) == 10.0
    assert ite.validate(10) == 10
    assert ite.validate(10.0) == 10.0
    ite = IfThenElse(Any(), None)
    assert ite.validate(10) == 10
    assert ite.validate(10.0) == 10.0
    assert ite.validate(10)

# Generated at 2022-06-12 15:31:18.052112
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    assert field.validate("this is a string") == "this is a string"
    assert field.validate(123) == 123
    try:
        field.validate([])
        assert False, "A ValueError should have been raised"
    except ValueError as error:
        assert error.args == ("Did not match any valid type.",)
    try:
        field.validate([0, 1, 2])
        assert False, "A ValueError should have been raised"
    except ValueError as error:
        assert error.args == ("Matched more than one type.",)


# Generated at 2022-06-12 15:31:20.741581
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    res, error = field.validate_or_error(123)
    assert res is 123
    assert error is None



# Generated at 2022-06-12 15:31:26.584015
# Unit test for constructor of class OneOf
def test_OneOf():
    values = [1, 2, 3, 4, 5]
    f1 = OneOf([values])
    f2 = OneOf(values)
    # f3 = OneOf('values')
    # f4 = OneOf(values, values)
    # f5 = OneOf(values, values)
    # f6 = OneOf(values, values)

# Generated at 2022-06-12 15:31:34.717490
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse.validate(value='a', if_clause='a', then_clause='a', else_clause='b')
    IfThenElse.validate(value=6, if_clause=6, then_clause='a', else_clause='b')
    IfThenElse.validate(value=7, if_clause=7, then_clause=1, else_clause=2)
    IfThenElse.validate(value=8, if_clause=8, then_clause=2, else_clause=1)


# Generated at 2022-06-12 15:31:40.981325
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(None)
    # value = "abc"
    # assert field.validate(value) == value
    # expected_error = {"negated": "Must not match."}
    # value = "abc"
    # assert field.validate(value) == value
    # expected_error = {"negated": "Must not match."}
    value = 2
    expected_error = {"negated": "Must not match."}
    try:
        field.validate(value)
    except Exception as e:
        error = e.detail
    assert error == expected_error

# Generated at 2022-06-12 15:31:42.094321
# Unit test for constructor of class Not
def test_Not():
    a = Not(True)
    assert a



# Generated at 2022-06-12 15:31:46.402744
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ItE = IfThenElse(
        if_clause = Dict(),
        then_clause = Dict(properties={"name": Text()}),
        else_clause = Dict(properties={"name": Text()})
    )
    assert {} == ItE.validate({'name': 123})


# Generated at 2022-06-12 15:31:50.996663
# Unit test for constructor of class Not
def test_Not():
    # Given
    a_field = None
    # When
    not_field = Not(a_field)
    # Then
    assert not_field.negated == a_field

# Generated at 2022-06-12 15:31:55.240047
# Unit test for constructor of class OneOf
def test_OneOf():
    # Should return True if constructor runs without error
    type_list = [Integer(), String(), Float(allow_null=False)]
    field = OneOf(type_list)
    assert field
    # Should return False as allow_null is set to True
    type_list = [Integer(allow_null=True), String(allow_null=True), Float(allow_null=True)]
    field = OneOf(type_list)
    assert field is False


# Generated at 2022-06-12 15:32:02.935158
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.typing import JSONSchemaType
    # Test if the type of field is JSONSchemaType type
    field = Not(String(), additional_properties=False, name="name_Not")
    assert isinstance(field, JSONSchemaType)
    # Test if the type of negated is JSONSchemaType type
    assert isinstance(field.negated, JSONSchemaType)
    # Test if the type of field.errors is a dictionary 
    assert isinstance(field.errors, dict)


# Generated at 2022-06-12 15:32:04.059999
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Number

    all_of = [Number()]
    assert AllOf(all_of=all_of)


# Generated at 2022-06-12 15:32:07.916334
# Unit test for constructor of class OneOf
def test_OneOf():
    def test_constructor():
        field = OneOf(one_of=[])
        assert field.one_of == []
        assert field.allow_null == False

    execute_list = [
        test_constructor
    ]

    for test in execute_list:
        try:
            test()
        except:
            print(f"Failed {test.__name__}")



# Generated at 2022-06-12 15:32:10.530728
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)
    assert field.negated == None
    assert field.errors == {"negated": "Must not match."}

# Unit test to make sure Not is validating correctly

# Generated at 2022-06-12 15:32:13.791587
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Field())
    field.validate(None)
    try:
        field.validate(1)
        assert False
    except:
        assert True


# Generated at 2022-06-12 15:32:14.340328
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)

# Generated at 2022-06-12 15:32:20.718211
# Unit test for method validate of class Not
def test_Not_validate():
    field_1 = Not(String())
    assert field_1.validate(5) == 5
    assert field_1.validate(None) == None
    assert field_1.validate(True) == True
    assert field_1.validate(False) == False
    assert field_1.validate({'a': 5}) == {'a': 5}
    assert field_1.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-12 15:32:22.440570
# Unit test for constructor of class OneOf
def test_OneOf():
    type_ = OneOf(one_of = [])
    assert type_.one_of == []


# Generated at 2022-06-12 15:32:28.729891
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    s = String()
    n = Not(s)
    assert n.negated is s

# Generated at 2022-06-12 15:32:29.291518
# Unit test for constructor of class AllOf
def test_AllOf():
	pass

# Generated at 2022-06-12 15:32:31.480966
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()


# Generated at 2022-06-12 15:32:33.766590
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(negated=Any())
    f._validate(value=dict(a=1, b=2), strict=False)



# Generated at 2022-06-12 15:32:39.711605
# Unit test for constructor of class OneOf
def test_OneOf():
    string = typesystem.String()
    list = typesystem.List(items=typesystem.String())
    one_of = typesystem.OneOf(one_of=[string, list])

    # Test for object initialization
    try:
        assert isinstance(one_of, typesystem.OneOf)
        assert one_of.one_of == [string, list]
    except:
        print("Test for object initialization is Failed")
        one_of = None
        assert one_of


# Generated at 2022-06-12 15:32:44.169154
# Unit test for constructor of class AllOf
def test_AllOf():
    def test_AllOf(self, allOf: typing.List[Field], **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.allOf = allOf


# Generated at 2022-06-12 15:32:45.016401
# Unit test for constructor of class Not
def test_Not():
    _ = Not(negated=None)

# Generated at 2022-06-12 15:32:46.543708
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_field = NeverMatch()
    assert isinstance(test_field, Field)


# Generated at 2022-06-12 15:32:47.588494
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    N = NeverMatch()
    assert N.errors == {"never": "This never validates."}

# Generated at 2022-06-12 15:32:48.619263
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field())
    assert field.validate('a')

# Generated at 2022-06-12 15:33:01.109575
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from .fields import String, Integer
    
    ite = IfThenElse(
        if_clause = Integer(),
        then_clause = String(),
        else_clause = Integer()
    )
    
    for value in [3, '3']:
        assert ite.validate(value) == value

# Generated at 2022-06-12 15:33:02.388448
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # initialize class IfThenElse
    assert IfThenElse.__init__

# Generated at 2022-06-12 15:33:04.530426
# Unit test for constructor of class AllOf
def test_AllOf():
  fields: typing.List[Field] = []
  f = AllOf(fields)
if __name__ == "__main__":
    test_AllOf()

# Generated at 2022-06-12 15:33:07.141402
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert None == NeverMatch(description="description").description
    assert {"never": "This never validates."} == NeverMatch().errors


# Generated at 2022-06-12 15:33:14.795083
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = IfThenElse(String(max_length=3), String(min_length=4), String(min_length=2))
    field.validate("abc")
    field.validate("abcd")
    field.validate("ab")
    try:
        field.validate("a")
    except ValidationError:
        pass
    else:
        assert False, "IfThenElse.validate() failed"

# Generated at 2022-06-12 15:33:16.308839
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field()).negated == Field()


# Generated at 2022-06-12 15:33:19.136443
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.__class__.__name__ == "NeverMatch"
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:33:23.249546
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    # test __init__ of class NeverMatch
    assert str(n.validation_error.errors) == "{'never': 'This never validates.'}"
    assert n.validation_error.code == "never"
    with pytest.raises(ValidationError):
        n.validate(1)


# Generated at 2022-06-12 15:33:24.945088
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String
    one_field = OneOf(one_of=[Integer(), String()])
    assert one_field.validate(123) == 123
    assert one_field.validate('abc') == 'abc'


# Generated at 2022-06-12 15:33:26.171716
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True

# Generated at 2022-06-12 15:33:58.349404
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    obj = IfThenElse(AllOf([Int()]), None, None)
    obj.validate(10)

# Generated at 2022-06-12 15:34:00.712326
# Unit test for constructor of class OneOf
def test_OneOf():
    array_of_int = OneOf([Integer()])
    assert array_of_int is not None


# Generated at 2022-06-12 15:34:03.672705
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(field1, field2, field3)
    assert field.if_clause == field1
    assert field.then_clause == field2
    assert field.else_clause == field3



# Generated at 2022-06-12 15:34:05.713360
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field1 = IfThenElse(Integer(), Integer())
    field2 = IfThenElse(Integer(), Integer(), Integer())
    field3 = IfThenElse(Integer())

# Generated at 2022-06-12 15:34:09.002629
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf([Any()]),OneOf)
    error=None
    try:
        assert isinstance(OneOf([Any()],min_length=1),OneOf)
    except Exception as e:
        error=e
    assert isinstance(error,AssertionError)


# Generated at 2022-06-12 15:34:10.052473
# Unit test for constructor of class OneOf
def test_OneOf():
    # your code
    assert 1 == 1


# Generated at 2022-06-12 15:34:12.959781
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    error = not_field.validate('test')
    assert type(error) == None



# Generated at 2022-06-12 15:34:15.527491
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import String
    not_string = Not(String(), allow_null=True)
    assert not_string.validate("string") == "string"


# Generated at 2022-06-12 15:34:17.209580
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:34:20.370311
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    not_string = Not(String())
    try:
        not_string.validate(True)
    except ValidationError:
        assert(True)
    else:
        assert(False)


# Generated at 2022-06-12 15:34:43.601619
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse()
    # assert x.validate() == "passed"
    print("Passed test for validate method of class IfThenElse")
test_IfThenElse_validate()

# Generated at 2022-06-12 15:34:44.860903
# Unit test for method validate of class Not
def test_Not_validate():
    not_obj = Not(Number(minimum=0,maximum=0))
    not_obj.validate(-1)

# Generated at 2022-06-12 15:34:46.447788
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-12 15:34:55.779823
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=Integer(minimum=0),
        then_clause=Integer(minimum=1),
        else_clause=Integer(minimum=3)
    )
    print(field.validate(0)) # should print 1
    print(field.validate(-1)) # should print 3
    print(" ")

    field = IfThenElse(
        if_clause=Integer(minimum=0),
        then_clause=Integer(minimum=1),
        else_clause=None
    )
    print(field.validate(0)) # should print 1
    print(field.validate(-1)) # should print None
    print(" ")


# Generated at 2022-06-12 15:34:58.393088
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Any(), NeverMatch()])
    val, err = field.validate_or_error(1)
    assert val == 1
    assert err is None


# Generated at 2022-06-12 15:35:01.280374
# Unit test for method validate of class Not
def test_Not_validate():
    t = Not(negated = "dd")
    result,error = t.validate_or_error("dd")
    assert error is not None
    error,result = t.validate_or_error("not dd")
    assert error is None
    assert result == "not dd"

# Generated at 2022-06-12 15:35:04.055991
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Float())
    result, error = field.validate_or_error(1.)
    
    assert result is None
    assert error is not None
    assert error.code == 'negated'
    assert error.message == 'Must not match.'



# Generated at 2022-06-12 15:35:08.901202
# Unit test for constructor of class OneOf
def test_OneOf():
    import pytest
    from typesystem.fields import String
    foo_field = OneOf([String()])
    assert foo_field.__class__.__name__ == "OneOf"
    assert foo_field.one_of[0].__class__.__name__ == "String"

# Generated at 2022-06-12 15:35:11.471155
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    thing = OneOf(one_of=[])
    assert thing.validate('test') == 'test'


# Generated at 2022-06-12 15:35:16.145814
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = 12
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    assert then_clause.validate(value) == 12
    assert else_clause.validate(value) == 12


# Generated at 2022-06-12 15:35:53.029054
# Unit test for method validate of class Not
def test_Not_validate():
    with open('schema.json', 'r') as json_file:
        json_schema = json.load(json_file)
    def test_with_schema(schema: dict):
        def test_with_value(value):
            f = Field.from_json(schema)
            # method validate of class Not
            assert (f.validate(value) == value), \
            "Test method validate of class Not failed for value: " + str(value)
        for value in instance_generator.generate(schema):
            test_with_value(value)
    for value in json_schema['properties'].values():
        if value['type'] == "object":
            test_with_schema(value)


# Generated at 2022-06-12 15:35:57.440779
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
        f1 = StringField(min_length=3)
        f2 = StringField(max_length=3)
        f3 = IfThenElse(f1, then_clause=f2)
        print(f3.validate("12345"))
        print(f3.validate("123"))
        print(f3.validate("12"))

test_IfThenElse_validate()

# Generated at 2022-06-12 15:35:59.622744
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    field = IfThenElse(if_clause,then_clause,else_clause)
    field.validate(12)

# Generated at 2022-06-12 15:36:08.263352
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(Any(), Any()).validate('any')
    IfThenElse(Any(), Any(), Any()).validate('any')
    IfThenElse(Any(), Any()).validate(True)
    IfThenElse(Any(), Any(), Any()).validate(False)
    try:
        IfThenElse(Any(), Any()).validate(False)
        assert False
    except AssertionError as e:
        print('AssertionError raised as expected')
    try:
        IfThenElse(Any(), Any()).validate(None)
        assert False
    except AssertionError as e:
        print('AssertionError raised as expected')

# Generated at 2022-06-12 15:36:11.326604
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    field.validate(value=1)
    # This should be tested but it is not
    # field.validate(value='s')


# Generated at 2022-06-12 15:36:14.799675
# Unit test for method validate of class Not
def test_Not_validate():
    def test_not_validate():
        field1 = Not(negated=Field(required=False))
        field1.validate(1)
        try:
            field1.validate(None)
            return False
        except Exception:
            return True

    assert test_not_validate()



# Generated at 2022-06-12 15:36:20.113274
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    
    '''
    Test case 1
    '''
    field = IfThenElse(if_clause=String(), then_clause=String(), else_clause=String())
    assert field.validate("y", strict=False) == "y"
    assert field.validate("n", strict=False) == "n"
    '''
    Test case 2
    '''
    field = IfThenElse(if_clause = Integer(), then_clause=Integer(), else_clause=Integer())
    assert field.validate(2, strict=False) == 2
    assert field.validate(3, strict=False) == 3

# Generated at 2022-06-12 15:36:24.777621
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    new_IfThenElse = IfThenElse("if_clause", "then_clause", "else_clause")
    new_IfThenElse.validate("if_clause", strict=True)
    new_IfThenElse.validate("then_clause", strict=True)
    new_IfThenElse.validate("else_clause", strict=True)

# Generated at 2022-06-12 15:36:26.977783
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf
    import typesystem
    assert OneOf([typesystem.types.String()])


# Generated at 2022-06-12 15:36:29.096999
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    assert field.validate("str") is "str"
    with pytest.raises(ValidationError, match="Must not match."):
        field.validate(42)

# Generated at 2022-06-12 15:37:08.457287
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Check why method IfThenElse.validate returns None
    x = IfThenElse(if_clause=Not(negated=Field('a')), then_clause=Field('b'))
    assert x.validate('c') == None
    assert x.validate('a') == 'a'

# Generated at 2022-06-12 15:37:09.741866
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf([int]), OneOf)



# Generated at 2022-06-12 15:37:14.941878
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_field = IfThenElse(Boolean(), then_clause=Number())
    # Case: If clause is True
    result, _ = test_field.validate_or_error(True)
    assert result == 0.0
    # Case: if clause is False
    result, _ = test_field.validate_or_error(False)
    assert result == True
    # Case: if clause is not a Boolean
    with pytest.raises(typesystem.ValidationError):
        test_field.validate('Foo')

# Generated at 2022-06-12 15:37:17.783980
# Unit test for method validate of class Not
def test_Not_validate():
    # Create instance of class Not
    not_field = Not(IfThenElse(1, 1, 1))

    # Check if method validate works correctly on valid input
    assert(not_field.validate(0) == 0)

    # Check if method validate raises ValidationError on invalid input

# Generated at 2022-06-12 15:37:19.534573
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass # TODO: implement your test here


# Generated at 2022-06-12 15:37:25.713738
# Unit test for method validate of class Not
def test_Not_validate():
    import json
    # Fail as not match
    class ChildrenFieldValidator(Field):
        def validate(self, value, strict=False) -> Any:
            value = super().validate(value)
            return value

    not_field = Not(ChildrenFieldValidator(allow_null=True))
    value = "10"
    if_clause = not_field.negated
    _, error = if_clause.validate_or_error(value, strict=True)
    assert (error is None)

    _, error = not_field.validate_or_error(value, strict=True)
    assert (error is not None)
    assert (json.loads(json.dumps(error.to_primitive())) ==
            {'negated': 'Must not match.'})

# Generated at 2022-06-12 15:37:33.616337
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
  field = IfThenElse(if_clause=String(max_length=5), then_clause=String(max_length=10), else_clause=String(max_length=15))
  result = field.validate("abcd")
  assert result == "abcd"
  try:
    result = field.validate("abcdefghijklmnopqrstuvwxyz")
  except ValidationError:
    assert True
  else:
    assert False, "Field 'String' failed to prevent the input string of more than 15 characters"



# Generated at 2022-06-12 15:37:40.685021
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.base import ValidationError
    from typesystem import Schema

    d = {"name": "value"}
    # Check InstanceOf
    try:
        IfThenElse(if_clause=InstanceOf(dict), \
                    then_clause=Schema({"name": String()})
                    ).validate(d)
    except ValidationError:
        assert False

    # Check InstanceOf
    try:
        IfThenElse(if_clause=InstanceOf(dict), \
                    then_clause=Schema({"name": String()}),
                    else_clause=String()
                    ).validate(d)
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-12 15:37:42.502502
# Unit test for method validate of class Not
def test_Not_validate():
    id_ = Not(String())
    expected = 'string'
    actual = id_.validate(expected)
    assert expected == actual


# Generated at 2022-06-12 15:37:43.875548
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    i=IfThenElse(Field,Field)
    assert i.validate(0) == 0