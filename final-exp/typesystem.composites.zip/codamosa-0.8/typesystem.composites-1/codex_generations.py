

# Generated at 2022-06-12 15:28:48.033291
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    o = IfThenElse(if_clause, then_clause, else_clause)
    assert o.validate(None) is None

# Generated at 2022-06-12 15:28:52.649081
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    test = IfThenElse(if_clause, then_clause, else_clause)
    try:
        test.validate(1)
    except test.validation_error as e:
        assert e.code == "never", e.code
        assert e.field == test, e.field
    else:
        assert False



# Generated at 2022-06-12 15:28:57.393809
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any()
    ).validate(
        value=True, strict=True
    )
    IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any()
    ).validate(
        value=False, strict=False
    )

# Generated at 2022-06-12 15:29:01.337932
# Unit test for method validate of class Not
def test_Not_validate():
    s = Not(AllOf([String(), Email()]))
    assert s.validate(123) == 123



# Generated at 2022-06-12 15:29:03.439319
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  nm = NeverMatch(name="testnm")
  # Test __init__() for class NeverMatch
  assert nm


# Generated at 2022-06-12 15:29:06.992327
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=NeverMatch()).validate(5) == 5
    assert IfThenElse(if_clause=Any(), then_clause=NeverMatch(), else_clause=Any()).validate(5) == 5



# Generated at 2022-06-12 15:29:10.426454
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()

    assert getattr(f, "errors", None) == {"never": "This never validates."}
    assert f.validate(None) == {}
    assert f.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:29:12.949618
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse([])
    b = a.validate("a")
    assert b == 'a'

# Generated at 2022-06-12 15:29:15.274190
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(None)
    assert not_.validate(None) == None


# Generated at 2022-06-12 15:29:18.264815
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nevermatch_field = NeverMatch()
    assert nevermatch_field.errors == {'never': 'This never validates.'}


# Generated at 2022-06-12 15:29:24.263201
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String, Integer
    field = OneOf([String(), Integer()])
    field.validate(None)

# Generated at 2022-06-12 15:29:27.432692
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of=[Any(), Any()], description="")
    assert field
    assert field.all_of
    assert len(field.all_of) == 2


# Generated at 2022-06-12 15:29:29.385466
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        # pass
        AllOf([Any()])
    except:
        assert False

# Generated at 2022-06-12 15:29:37.036873
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import json
    # get the test items
    with open("../tests/oneOf.json") as f:
        oneOf_json = json.load(f)
    # create the object of class OneOf
    integer_field = OneOf(one_of=oneOf_json["oneOf"])
    # test the validate method
    assert integer_field.validate(oneOf_json["test_value"]) == "passed"


# Generated at 2022-06-12 15:29:38.451203
# Unit test for constructor of class Not
def test_Not():
    n = Not(None)
    assert n.negated == None

# Generated at 2022-06-12 15:29:40.587370
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    val = field.validate("some_value")
    assert val == "some_value"


# Generated at 2022-06-12 15:29:42.887284
# Unit test for constructor of class Not
def test_Not():
    field = Not(Any())
    assert field.negated.__dict__ == Any().__dict__
    assert field.errors == {"negated": "Must not match."}


# Generated at 2022-06-12 15:29:45.290243
# Unit test for constructor of class AllOf
def test_AllOf():
    num = types.Queryset()
    string = types.String()
    field = types.AllOf([num,string])
    assert field.all_of == [num,string]


# Generated at 2022-06-12 15:29:47.127203
# Unit test for constructor of class Not
def test_Not():
    assert hasattr(Not, '__init__')


# Generated at 2022-06-12 15:29:48.937770
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    neverMatch = NeverMatch()
    assert neverMatch.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:29:57.479143
# Unit test for method validate of class Not
def test_Not_validate():
    my_not = Not(Boolean())
    assert my_not.validate(value=1) == 1
    with pytest.raises(ValidationError) as excinfo:
        my_not.validate(value=True)
    assert 'Must not match.' in str(excinfo.value)

# Generated at 2022-06-12 15:30:01.238029
# Unit test for constructor of class AllOf
def test_AllOf():
    f = AllOf(all_of = [])
    assert f is not None
    assert f.all_of is not None
    assert f.all_of == []


# Generated at 2022-06-12 15:30:02.640870
# Unit test for constructor of class OneOf
def test_OneOf():
    test = OneOf([])
    assert test != None


# Generated at 2022-06-12 15:30:03.769579
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    obj = IfThenElse(if_clause=Any())

# Generated at 2022-06-12 15:30:04.783492
# Unit test for constructor of class AllOf
def test_AllOf():
	assert AllOf([])
	

# Generated at 2022-06-12 15:30:12.340684
# Unit test for method validate of class Not
def test_Not_validate():
    class Num(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if not isinstance(value, int):
                raise self.validation_error("not_an_integer")
            return value

    class NumNotTwo(Not):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if not isinstance(value, int):
                raise self.validation_error("not_an_integer")
            return value

    num = Num()
    numNotTwo = NumNotTwo(negated = Num())

    assert numNotTwo.validate(1) == 1
    assert numNotTwo.validate(2) == 2

    print("Succesfully passed unit test")


# Generated at 2022-06-12 15:30:16.126416
# Unit test for constructor of class OneOf
def test_OneOf():
    import typesystem
    one_of = typesystem.OneOf([typesystem.String()])
    if not one_of:
        raise Exception("Unexpected behavior with OneOf and constructor")


# Generated at 2022-06-12 15:30:21.357902
# Unit test for method validate of class Not
def test_Not_validate():
    not_candiate = Not(negated=Any())
    # Should not raise any error
    assert not_candiate.validate(True) == True
    assert not_candiate.validate(False) == False
    assert not_candiate.validate(None) == None
    # Should raise an error
    try:
        not_candiate.validate(1)
    except:
        assert True
    else:
        assert False

    try:
        not_candiate.validate("a")
    except:
        assert True
    else:
        assert False



# Generated at 2022-06-12 15:30:25.171562
# Unit test for method validate of class Not
def test_Not_validate():
    # Arrange
    field = Not(Any(allow_null=True))

    # Act and Assert
    assert field.validate_or_error(None) == (None, None)
    with pytest.raises(field.type_error_class):
        field.validate(None) == (None, None)



# Generated at 2022-06-12 15:30:32.395768
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.types import TypeDefinition
    from typesystem.base import ValidationError
    Not(String()).validate("hello")
    try:
        Not(String()).validate(1)
    except ValidationError as err:
        print(err.full_messages()[0])
    assert err.full_messages()[0] == "Must not match."
    # Test2
    Not(String()).validate(1, strict=True)


# Generated at 2022-06-12 15:30:37.123178
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(1, then_clause=2, else_clause=3)
    assert a.if_clause == 1
    assert a.then_clause == 2
    assert a.else_clause == 3


# Generated at 2022-06-12 15:30:39.916793
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(int)
    try:
        field.validate(1)
    except ValueError as e:
        assert str(e) == "Must not match."
    else:
        assert False

# Generated at 2022-06-12 15:30:49.497172
# Unit test for constructor of class OneOf
def test_OneOf():
    import json
    from typesystem.fields import String
    from typesystem.types.object import Object

    class Test:
        schema = Object(properties={"title": String(max_length=10)})
        test_json = '{"title": "Short Title"}'

    one_of_json_test_schema = OneOf(
        one_of=[
            Test.schema,
            Object(properties={"description": String(max_length=100)})
        ]
    )

    # Unit test for function validate
    one_of_json_test = one_of_json_test_schema.validate(json.loads(Test.test_json))
    assert one_of_json_test['title'] == "Short Title"



# Generated at 2022-06-12 15:30:51.201805
# Unit test for constructor of class AllOf
def test_AllOf():
    #check if we can instantiate with a list of fields
    assert AllOf([Any(), Any()])


# Generated at 2022-06-12 15:30:53.710802
# Unit test for method validate of class Not
def test_Not_validate():
    # Create objects
    not_field = Not(AllOf([AllOf([Any(), Any()])]), allow_null=False)
    assert not_field.validate(None) == None

# Generated at 2022-06-12 15:30:54.270771
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True

# Generated at 2022-06-12 15:30:55.826629
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[])
    assert one_of.one_of == []


# Generated at 2022-06-12 15:30:58.949692
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(AllOf([Field(required=True), Field(max_length=10)]))
    value, error = field.validate_or_error({})
    assert field.validation_error("negated", value=value) == error


# Generated at 2022-06-12 15:31:07.083617
# Unit test for method validate of class Not
def test_Not_validate():

    class FakeField:
        def __init__(self, name):
            self.name = name

        def validate_or_error(self, value, strict=False):
            if self.name == "negated":
                return None, None
            return None, "bad error"

    field_not = Not(negated=FakeField("negated"))
    field_negated = Not(negated=FakeField("not_negated"))

    assert field_not.validate(True) is True
    assert field_negated.validate(True) is True

# Generated at 2022-06-12 15:31:13.356028
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    assert Not(String()).validate(123) == 123
    from typesystem.exceptions import ValidationError
    try:
        Not(String()).validate("string")
        raise Exception("validate of class Not: case 1 failed")
    except ValidationError:
        pass


# Generated at 2022-06-12 15:31:16.615236
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = None
    field = OneOf(one_of)


# Generated at 2022-06-12 15:31:17.583759
# Unit test for method validate of class OneOf
def test_OneOf_validate():
  pass


# Generated at 2022-06-12 15:31:18.562744
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=Any())
    n.validate("23")

# Generated at 2022-06-12 15:31:21.748073
# Unit test for method validate of class Not
def test_Not_validate():
	not_test = Not(String(max_length=1))
	assert not_test.validate("h") == None
	assert not_test.validate(10) == 10



# Generated at 2022-06-12 15:31:22.931738
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Any()])
    assert isinstance(field, OneOf)

# Generated at 2022-06-12 15:31:26.147892
# Unit test for method validate of class Not
def test_Not_validate():
    not_object = Not(String())
    assert not_object.validate(5) == 5
    try:
        not_object.validate("5")
    except Exception as e:
        assert "Must not match" == str(e)
    else:
        raise Exception("Test not_object.validate() failed")


# Generated at 2022-06-12 15:31:33.120375
# Unit test for constructor of class AllOf
def test_AllOf():
    '''
    Desrcription:
        Unit test for AllOf

    Args:
        AllOf(all_of: typing.List[Field]): all_of is a list of fields
        **kwargs:
            AllowNull: Defer Nullable handling to another class
            **kwargs: Extra options to be stored as `self.options`.

    Returns:
        None
    '''
    fields = [String, Integer]

# Generated at 2022-06-12 15:31:38.083285
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import String

    class TestNot(Not):
        def __init__(self, negated: Field) -> None:
            super().__init__(negated)

    field = TestNot(String(max_length=10))
    # Checks if the field is negated
    assert field.validate("test") == "test"
    assert field.validate("teststring") == "test"

# Generated at 2022-06-12 15:31:45.332116
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Unit test for method validate of class Not
    """
    # test case 1:
    #   test with valid value (error = None)
    #   Check if the returned value is valid
    #   Expected: returns inputted value
    field = Not(String())
    try:
        field.validate(123)
    except Exception as e:
        message = e.message
        assert(message == "Must not match.")
    
    # test case 2:
    #   test with invalid value (error = True)
    #   Check if the returned value is valid
    #   Expected: returns inputted value
    field = Not(String())
    try:
        field.validate("abc")
    except Exception as e:
        message = e.message
        assert(message == "Must not match.")


# Generated at 2022-06-12 15:31:46.640201
# Unit test for constructor of class OneOf
def test_OneOf():
    oneOf = OneOf([])
    assert oneOf != None


# Generated at 2022-06-12 15:31:51.729117
# Unit test for constructor of class OneOf
def test_OneOf():
    list_field_1 = Field()
    list_field_2 = Field()
    test_field = OneOf(list_field_1, list_field_2)
    assert test_field.one_of == [list_field_1, list_field_2]

# Generated at 2022-06-12 15:31:54.832912
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = typesystem.Not(typesystem.String())
    with pytest.raises(typesystem.ValidationError):
        not_field.validate("String")
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None



# Generated at 2022-06-12 15:31:58.881477
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.base import Type

    def all_of(self, all_of: typing.List[Type], **kwargs: typing.Any) -> None:
        self = {}
        self.all_of = all_of

    all_of({}, [AllOf])


# Generated at 2022-06-12 15:32:03.403381
# Unit test for method validate of class Not
def test_Not_validate():
    """Test validate of class Not"""
    t = None
    f = None
    value = None
    strict = False
    not_field = Not(String(pattern="^[a-zA-Z]{0,10}$"))
    not_field.validate(value, strict)
    return True



# Generated at 2022-06-12 15:32:04.261138
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-12 15:32:08.252185
# Unit test for constructor of class OneOf
def test_OneOf():
    boolean = typing.cast(Field, bool)
    integer = typing.cast(Field, int)
    t = OneOf(one_of=[boolean, integer])
    assert t.validate(1), "1 is an integer"
    assert t.validate(True), "True is a boolean"
    assert not t.validate(3.14), "3.14 is not one of the options given"

# Generated at 2022-06-12 15:32:13.081753
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_1_field = Field()
    one_of_2_field = Field()
    field = OneOf([one_of_1_field, one_of_2_field])
    value = 'str'
    strict = False
    result = field.validate(value, strict)
    assert result == value


# Generated at 2022-06-12 15:32:14.330877
# Unit test for constructor of class OneOf
def test_OneOf():
    oneof = OneOf([NeverMatch()])
    oneof.validate(12)

# Generated at 2022-06-12 15:32:16.290297
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[])
    assert field.one_of == []

# Generated at 2022-06-12 15:32:19.155210
# Unit test for constructor of class OneOf
def test_OneOf():
    type_one = typing.TypeVar('T')
    one_of = OneOf(one_of=[type_one])
    assert one_of.one_of == [type_one]


# Generated at 2022-06-12 15:32:24.676375
# Unit test for constructor of class OneOf
def test_OneOf():

    from typesystem.fields import Integer

    field = OneOf(one_of = [Integer()])
    assert field.name is None
    assert field.error_messages == OneOf.errors
    assert field.one_of == [Integer()]


# Generated at 2022-06-12 15:32:28.287846
# Unit test for method validate of class Not
def test_Not_validate():
    field_not = Not(Boolean())

    # If there is an error then the value is ok to be accepted.
    assert field_not.validate("a value that is not a boolean") == "a value that is not a boolean"
    # If there is no error then the value is rejected.
    with pytest.raises(ValidationError):
        field_not.validate(True)



# Generated at 2022-06-12 15:32:34.762451
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer, String

    field1 = AllOf([Integer(), String()])
    field2 = AllOf([Integer(), String()], description='this is a description')
    print(field1.description)
    print(field2.description)
    assert field1.description == 'this is an AllOf type'
    assert field2.description == 'this is a description'


# Generated at 2022-06-12 15:32:35.864231
# Unit test for constructor of class AllOf
def test_AllOf():
    class MyAllOf(AllOf):
        all_of: typing.List[Field]
    mao1 = MyAllOf(all_of=[])

# Generated at 2022-06-12 15:32:42.393390
# Unit test for constructor of class AllOf
def test_AllOf():

    # Try to create AllOf object with appropriate types of fields.
    # Excepted result: Object is created.
    test_field1 = Field()
    test_field2 = Field()
    try:
        test_AllOf = AllOf([test_field1, test_field2])
        assert test_AllOf is not None
    except Exception:
        assert False

    # Try to create AllOf object with inappropriate types of fields.
    # Excepted result: AssertionError is raised.
    test_field3 = Field()
    try:
        test_AllOf = AllOf([test_field3, 1])
    except AssertionError:
        assert True
    except Exception:
        assert False

    # Try to create AllOf object with None value of fields.
    # Excepted result: AssertionError is raised.

# Generated at 2022-06-12 15:32:50.013662
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.base import ValidationError
    from typesystem.fields import String

    class TestNot(Not):
        def __init__(self):
            super().__init__(negated=String(min_length=3))

    field = TestNot()
    field.validate("aaa")
    try:
        field.validate("aa")
    except ValidationError as exc:
        assert exc.code == "negated"
    else:
        assert False, "Should have failed."
    try:
        field.validate(None)
        # Expected to fail because the negated field is required, but the
        # parent field is not.
    except ValidationError as exc:
        assert exc.code == "required"
    else:
        assert False, "Should have failed."


# Generated at 2022-06-12 15:32:58.762633
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test valid inputs
    field = AllOf([Any()])
    assert field.required
    assert len(field.errors) == 1
    assert field.all_of[0] == Any()

    # Test invalid inputs
    try:
        AllOf(all_of = [None])
        assert False
    except AssertionError:
        assert True

    try:
        AllOf(all_of = "not a list")
        assert False
    except AssertionError:
        assert True

    # Test default values
    field = AllOf([])
    assert field.required


# Generated at 2022-06-12 15:33:01.536255
# Unit test for constructor of class AllOf
def test_AllOf():
    # arrange
    all_of = AllOf(all_of=['int'])
    # act

    # assert
    assert all_of.all_of == ['int']
    # Unit test for constructor of class Not

# Generated at 2022-06-12 15:33:02.820631
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(NeverMatch()).validate("Anything") == "Anything"

# Generated at 2022-06-12 15:33:06.709935
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.types import Type

    x = OneOf([String()], name='x')
    assert x.name == 'x'
    assert isinstance(x, Type)
    assert x.validate('hello') == 'hello'


# Generated at 2022-06-12 15:33:14.258522
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer
    a = OneOf([Integer()])
    print(a.one_of)
    b = a.one_of[0]
    print(type(b))
    print(b)
    assert b.errors['validator_failed'] == 'Could not convert to int.'



# Generated at 2022-06-12 15:33:14.897647
# Unit test for constructor of class AllOf
def test_AllOf():
    assert 1 == 1

# Generated at 2022-06-12 15:33:17.513093
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String

    field = OneOf([String()])
    # Test if self.one_of is set
    assert len(field.one_of) == 1

# Generated at 2022-06-12 15:33:21.033768
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([Field(), Field(name="one_of")])
    assert [one_of.name, one_of.one_of[1].name] == ["one_of", "one_of"]

# Generated at 2022-06-12 15:33:21.979601
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([]).one_of == []

# Generated at 2022-06-12 15:33:22.531694
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-12 15:33:23.985764
# Unit test for constructor of class AllOf
def test_AllOf():
    global AllOf
    t = AllOf([int])
    assert t is not None


# Generated at 2022-06-12 15:33:29.085907
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.types import Integer

    field = OneOf([String(), Integer()])

    #assert 1 == field.validate(1)
    #assert "bill" == field.validate("bill")
    #try:
    #    field.validate(None)
    #except:
    #    pass
    #else:
    #    assert False, "did not raise an error as expected"
    #assert {"no_match": "Did not match any valid type."} == field.errors



# Generated at 2022-06-12 15:33:33.000699
# Unit test for constructor of class OneOf
def test_OneOf():
    with pytest.raises(AssertionError) as excinfo:
        OneOf(one_of=[Any(), Int()], allow_null=False)
    assert str(excinfo.value) == '"allow_null" not in kwargs' + \
                                 '\n        super().__init__(**kwargs)'

# Generated at 2022-06-12 15:33:36.033653
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_list = [Field(), Field()]
    one_of = OneOf(one_of_list, required=True)
    assert one_of.one_of == one_of_list


# Generated at 2022-06-12 15:33:42.379915
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_field = IfThenElse(String(),Boolean(),Integer())
    assert test_field.if_clause == String()
    assert test_field.then_clause == Boolean()
    assert test_field.else_clause == Integer()
#end of unit test class IfThenElse



# Generated at 2022-06-12 15:33:50.066282
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer

    _OneOf = OneOf([Integer(minimum=0), Integer(maximum=0)])
    _OneOf.validate(1)
    _OneOf.validate(-1)
    try:
        _OneOf.validate(2)
    except Exception as error:
        assert error.detail['code'] == 'no_match'
    try:
        _OneOf.validate(-5)
    except Exception as error:
        assert error.detail['code'] == 'no_match'


# Generated at 2022-06-12 15:33:50.652064
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-12 15:33:51.913343
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([Field()])
    assert all_of

# Generated at 2022-06-12 15:34:01.087920
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem
    field1 = typesystem.Integer()
    field2 = typesystem.Integer()
    field3 = typesystem.Integer()
    item1 = typesystem.Integer()
    item2 = typesystem.Integer()
    item3 = typesystem.Integer()
    c = [item1, item2, item3]

    test1 = AllOf(c)
    test2 = AllOf(c, default=field1)
    test3 = AllOf(c, description="description")
    test4 = AllOf(c, format="format")
    test5 = AllOf(c, metadata={"key": "value"})
    test6 = AllOf(c, unique=True)
    test7 = AllOf(c, min_length=field2)
    test8 = AllOf(c, max_length=field3)


# Generated at 2022-06-12 15:34:04.335203
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    allOf = AllOf([String()])

    assert(isinstance(allOf, Field))
    assert(isinstance(allOf.all_of, list))
    assert(isinstance(allOf.subtypes, list))


# Generated at 2022-06-12 15:34:08.494660
# Unit test for constructor of class OneOf
def test_OneOf():
    bool_field = Boolean()
    str_field = String()
    oneof_field = OneOf([bool_field, str_field])
    assert oneof_field.validate(True)
    assert oneof_field.validate("string")


# Generated at 2022-06-12 15:34:11.870156
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        assert AllOf(None) is not None
    except AssertionError:
        return False
    return True

print('Testing AllOf().__init__()')
print('Test Passed:', test_AllOf())


# Generated at 2022-06-12 15:34:20.778898
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()

    if_then_else_1 = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else_1.if_clause is if_clause
    assert if_then_else_1.then_clause is then_clause
    assert if_then_else_1.else_clause is else_clause

    if_then_else_2 = IfThenElse(if_clause)
    assert if_then_else_2.if_clause is if_clause
    assert isinstance(if_then_else_2.then_clause, Any)
    assert isinstance(if_then_else_2.else_clause, Any)

# Generated at 2022-06-12 15:34:24.449307
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    type = AllOf([String(max_length = 20), String(min_length = 5)])
    for _ in range(20):
        value = generate_random_str(random.randrange(5, 20, 1))
        assert(type.validate(value, strict = False) == value)


# Generated at 2022-06-12 15:34:36.552358
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test if super().__init__ is called in constructor of AllOf
    all_of = AllOf([], description="Description")
    assert all_of.description == "Description"
    # Test if exception is raised if `kwargs` is not empty
    with pytest.raises(AssertionError):
        all_of = AllOf([], allow_null=True)


# Generated at 2022-06-12 15:34:37.918757
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    print("test IfThenElse")
    ite = IfThenElse(Not(NeverMatch(name="if")), None, None)
    ite.validate(True)

# Generated at 2022-06-12 15:34:38.469283
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-12 15:34:40.675714
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    new_IfThenElse = IfThenElse(Any(), Any())
    assert isinstance(new_IfThenElse, IfThenElse)
    assert new_IfThenElse.if_clause == Any()
    assert new_IfThenElse.then_clause == Any()
    assert new_IfThenElse.else_clause == Any()

# Generated at 2022-06-12 15:34:41.669591
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(
        if_clause=Field(),
        then_clause=Field(),
        else_clause=Field(),
    )

# Generated at 2022-06-12 15:34:46.411421
# Unit test for constructor of class OneOf
def test_OneOf():
    from .objects import Schema

    from .fields import String, Object

    test_schema = Schema(OneOf([String(), Object({})], name="Address"))
    assert test_schema.fields.Address.validate("abc") is "abc"
    assert test_schema.fields.Address.validate({}) == {}
    assert test_schema.fields.Address.validate(8) is not None


# Generated at 2022-06-12 15:34:49.880309
# Unit test for constructor of class OneOf
def test_OneOf():
    # Create instance of class OneOf without arguments
    instance = OneOf()

    # Check type of instance
    assert isinstance(instance, OneOf) == True

    # Check value of __init__() arguments of instance
    assert instance.one_of == []


# Generated at 2022-06-12 15:34:51.283310
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    _ifthenelse = IfThenElse(String())

# Generated at 2022-06-12 15:34:54.597751
# Unit test for constructor of class OneOf
def test_OneOf():
    foo=OneOf([], allow_blank=True)
    assert foo.allow_blank
    assert foo.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}


# Generated at 2022-06-12 15:34:56.728705
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__init__
    assert OneOf
    assert OneOf.one_of
    assert OneOf.errors
    assert OneOf.validate


# Generated at 2022-06-12 15:35:19.208930
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Test 0
    class NaiveString(Field):
        def validate(self, value, strict=True):
            return value
        def __init__(self, **kwargs):
            super().__init__(**kwargs)
    if_clause = NaiveString()
    then_clause = NaiveString()
    else_clause = NaiveString()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    # Test 1
    if_clause = NaiveString()
    then_clause = NaiveString()
    if_then_else = IfThenElse(if_clause, then_clause)
    # Test 2
    if_clause = NaiveString()
    if_then_else = IfThenElse(if_clause)
   

# Generated at 2022-06-12 15:35:27.331933
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import Integer, String
    from typesystem.compat import assertRaisesRegex
    if_clause = String()
    then_clause = Integer()
    else_clause = String()
    some_field = IfThenElse(if_clause, then_clause, else_clause)
    assertRaisesRegex(
        TypeError,
        "Assertion failed",
        IfThenElse,
        if_clause,
        then_clause,
        else_clause,
        value_hint="some_hint",
    )

# Generated at 2022-06-12 15:35:34.502586
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class IfTest(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
            self.if_clause = 1  # type: ignore
            self.then_clause = 2  # type: ignore
            self.else_clause = 3  # type: ignore
            self.errors = self.if_clause  # type: ignore
            self.validate  # type: ignore

    ifThen = IfThenElse(
        if_clause=IfTest(),  # type: ignore
        then_clause=IfTest(),  # type: ignore
        else_clause=IfTest(),  # type: ignore
    )
    assert ifThen.if_clause == 1
    assert ifThen.then_clause == 2

# Generated at 2022-06-12 15:35:39.919811
# Unit test for constructor of class OneOf
def test_OneOf():
    '''
    Unit test for OneOf constructor
    '''
    
    try:
        oo = OneOf(one_of="fail")
        assert False, "Constructor of class OneOf failed"
    except AssertionError as e:
        print(e)



# Generated at 2022-06-12 15:35:41.478182
# Unit test for constructor of class OneOf
def test_OneOf():
    assert (OneOf([]) is not None)


# Generated at 2022-06-12 15:35:48.434827
# Unit test for constructor of class AllOf
def test_AllOf():
    class AllOfTest(AllOf):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(all_of, **kwargs)
            self.all_of = all_of
            self.kwargs = kwargs

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            for child in self.all_of:
                child.validate(value, strict=strict)
                return value

    # Test case #1 does not reach the code inside validate()
    # therefore not possible to assert the code inside
    AllOfTest(['hello'])
    # Test case #2 reach the code inside validate(), and then return.
    # therefore not possible to assert the code inside

# Generated at 2022-06-12 15:35:50.508280
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Array, String
    one_of = OneOf(one_of=[Array(items=String()), String()])

# Generated at 2022-06-12 15:35:53.577513
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [String(), Integer()]
    a = AllOf(all_of)
    assert(hasattr(a, "allow_null"))
    assert(a.allow_null == False)
    assert(a.all_of == [String(), Integer()])
    assert(a.errors == {})

# Generated at 2022-06-12 15:35:55.836260
# Unit test for constructor of class AllOf
def test_AllOf(): # real signature unknown; restored from __doc__
    """
    AllOf(all_of: typing.List[Field], **kwargs: typing.Any)
    """
    pass


# Generated at 2022-06-12 15:35:58.339529
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import unittest

    from . import String

    class IfThenElseTests(unittest.TestCase):
        def test_IfThenElse(self):
            field = IfThenElse(String())
            self.assertEqual(field.if_clause, String())

# Generated at 2022-06-12 15:36:23.968787
# Unit test for constructor of class OneOf
def test_OneOf():
    test_OneOf = OneOf([])
    assert test_OneOf.one_of == []

# Generated at 2022-06-12 15:36:24.545617
# Unit test for constructor of class AllOf
def test_AllOf():
    x = AllOf([])

# Generated at 2022-06-12 15:36:28.044646
# Unit test for constructor of class OneOf
def test_OneOf():
    basic_field = OneOf([
        Field(),
        Field(),
        Field(),
    ])
    assert basic_field.one_of == [
        Field(),
        Field(),
        Field(),
    ]


# Generated at 2022-06-12 15:36:29.445942
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        OneOf(one_of=[])
    except:
        assert False
    assert True

# Generated at 2022-06-12 15:36:29.907907
# Unit test for constructor of class OneOf
def test_OneOf():
    pass

# Generated at 2022-06-12 15:36:34.174105
# Unit test for constructor of class AllOf
def test_AllOf():
    """
    Unit test for constructor of class AllOf
    """
    from typesystem import String
    from typesystem.field import AllOf
    all_of = AllOf([String(max_length=10), String(min_length=3)])
    all_of.validate(value='abcdefghijk')
    with pytest.raises(all_of.validation_error):
        all_of.validate(value='ab')
    with pytest.raises(all_of.validation_error):
        all_of.validate(value='abcdefghijkl')

# Generated at 2022-06-12 15:36:35.073134
# Unit test for constructor of class OneOf
def test_OneOf():
    pass


# Generated at 2022-06-12 15:36:35.559404
# Unit test for constructor of class OneOf
def test_OneOf():

    assert 1 == 1

# Generated at 2022-06-12 15:36:43.238428
# Unit test for constructor of class OneOf
def test_OneOf():
    field = Field()
    one_of = [field]
    # Pass
    field_one_of = OneOf(one_of)
    # Fail
    field_one_of = OneOf(one_of, allow_null=True)
    field_one_of = OneOf(one_of, description='')
    field_one_of = OneOf(one_of, title='')
    field_one_of = OneOf(one_of, name='')
    field_one_of = OneOf(one_of, read_only=True)
    field_one_of = OneOf(one_of, write_only=True)


# Generated at 2022-06-12 15:36:50.229733
# Unit test for constructor of class AllOf
def test_AllOf():
    # Should not throw exception
    def_ = """
    allOf:
        - type: object
          properties:
            name:
              type: string
        - type: object
          properties:
            age:
              type: integer
              minimum: 0
              maximum: 150
    """
    schema = Schema(def_)
    schema.validate({"name": "Jill", "age": 20})
    schema.validate({"age": 20, "name": "Jill"})
