

# Generated at 2022-06-12 15:28:44.959866
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([])
    b = OneOf([Any()], name="x", description="y")
    c = OneOf([Any()], allow_null=True)
    assert a.one_of == []
    assert b.one_of == [Any()]
    assert b.name == "x"
    assert b.description == "y"
    assert c.allow_null == True



# Generated at 2022-06-12 15:28:48.852329
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    if_clause = IfThenElse(integers())
    then_clause = IfThenElse(integers())
    else_clause = IfThenElse(strings())

    IfThenElse(if_clause, then_clause, else_clause)



# Generated at 2022-06-12 15:28:49.442437
# Unit test for constructor of class AllOf
def test_AllOf():
    pass

# Generated at 2022-06-12 15:28:52.506076
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert str(OneOf([]).validate_or_error(None)) == '"no_match"'

# Generated at 2022-06-12 15:28:56.940820
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    input = {"state":"draft","date":"2016-02-15"}
    field = IfThenElse(
        if_clause=Field(name="state", type=str),
        then_clause=Field(name="date", format="date"),
        else_clause=Field(name="date", format="date-time"),
    )
    field.validate(**input)

# Generated at 2022-06-12 15:29:01.628435
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test if correct initialisation is possible
    test_field = OneOf([Any()])
    assert test_field.one_of == [Any()]


# Generated at 2022-06-12 15:29:02.232950
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    "a"

# Generated at 2022-06-12 15:29:12.062256
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String
    from typesystem.exceptions import ValidationError

    if_clause = Integer(minimum=1, maximum=2)
    then_clause = String(regex='^a')
    else_clause = String(regex='^b')
    field = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)

    assert field.validate(1) == 'a'
    assert field.validate(2) == 'a'
    assert field.validate(3) == 'b'

    try:
        field.validate('c')
    except ValidationError as e:
        assert e.message == 'Must match one of the following patterns: "^a", "^b".'

# Generated at 2022-06-12 15:29:13.897129
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-12 15:29:16.435922
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field, NeverMatch)


# Generated at 2022-06-12 15:29:23.707802
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_then_else = IfThenElse(String(), String(), String())
    assert if_then_else.if_clause == String()
    assert if_then_else.then_clause == String()
    assert if_then_else.else_clause == String()

# Generated at 2022-06-12 15:29:24.870891
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate('value')

# Generated at 2022-06-12 15:29:29.476780
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String, Typed
    example = String()
    #example = Typed(String)
    field = IfThenElse(example,"OK","NOT OK")
    assert field.validate("Hello") == "OK"
    assert field.validate(1) == "NOT OK"

# Generated at 2022-06-12 15:29:34.677405
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, Schema
 
    class NumberSchema(Schema):
        n = IfThenElse(if_clause=Integer(minimum=10), then_clause=Integer(minimum=1))
 
    serializer = NumberSchema()
    serializer.load({"n": 4})



# Generated at 2022-06-12 15:29:35.333288
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-12 15:29:43.361788
# Unit test for method validate of class Not
def test_Not_validate():
    Not(Any()).validate(None)
    Not(Any()).validate(3)
    Not(Any()).validate(3.14)
    Not(Any()).validate("")
    Not(Any()).validate("not an empty string")
    Not(Any()).validate(False)
    Not(Any()).validate(True)
    Not(Any()).validate([])
    Not(Any()).validate([1, 2, 3])
    Not(Any()).validate({})
    Not(Any()).validate({1: "a"})


# Generated at 2022-06-12 15:29:45.701617
# Unit test for method validate of class Not
def test_Not_validate():
    some_type = type("some_type", (Field,), {})
    not_type = Not(negated=some_type)
    not_type.validate(None)



# Generated at 2022-06-12 15:29:48.757761
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test __init__ call with None as parameter
    test_obj = NeverMatch(None)
    # Check if fields match expected
    assert test_obj.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:29:54.904301
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=None)
    assert not_field.validate(1) == 1, "invalid value"
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1, "invalid value"
    not_field = Not(negated=String())
    assert not_field.validate(1) == 1, "invalid value"
    assert not_field.validate("1") == "1", "invalid value"

# Generated at 2022-06-12 15:29:55.865994
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    t = NeverMatch(name="t")
    assert t.name == "t"

# Generated at 2022-06-12 15:30:05.180089
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    value = "test"
    strict = False
    object = IfThenElse(if_clause, then_clause, else_clause)
    result = object.validate(value, strict)
    # verify the result
    assert True




# Generated at 2022-06-12 15:30:10.146492
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
   # test
   if_clause = Any()
   then_clause = Any()
   else_clause = Any()
   # test
   testTrue = IfThenElse(if_clause, then_clause, else_clause)
   testFalse = IfThenElse(if_clause, then_clause, else_clause)

   # result
   assert testTrue.validate(1) == 1
   assert testFalse.validate(1) == 1

# Generated at 2022-06-12 15:30:11.616126
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_object = IfThenElse(None, None, None)
    assert test_object.validate('test')
    
    

# Generated at 2022-06-12 15:30:15.430069
# Unit test for method validate of class Not
def test_Not_validate():
    with pytest.raises(typesystem.ValidationError) as excinfo:
        Not(Number(maximum = 1)).validate(2)
    assert excinfo.value.code == 'negated'


# Generated at 2022-06-12 15:30:18.781480
# Unit test for method validate of class Not
def test_Not_validate():
    message = "Message"
    negated = Not(message, errors={"negated": "Not match"})
    result, error = negated.validate_or_error("Message")
    assert result == "Message"
    assert error is None


# Generated at 2022-06-12 15:30:27.349694
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Boolean
    from typesystem.fields import Float
    from typesystem.fields import Array
    from typesystem.fields import Dict

    fields = [Integer(), String(), Boolean()]
    assert AllOf(fields)

    fields = [Integer(), String(), Boolean()]
    assert AllOf(fields, min_length=0)

    fields = [Integer(), String(), Boolean()]
    assert AllOf(fields, max_length=0)

    fields = [Integer(), String(), Boolean()]
    assert AllOf(fields, min_length=0, max_length=0)

    fields = [Integer(), String(), Boolean()]
    assert AllOf(fields, min_length=0, max_length=0, min_value=0)

    fields

# Generated at 2022-06-12 15:30:27.967790
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass # FIXME

# Generated at 2022-06-12 15:30:32.395042
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # set input values
    validator = OneOf([],)
    value = "value"
    strict = False

    valid = True
    try:
        validator.validate(value, strict)
    except:
        valid = False
    assert valid



# Generated at 2022-06-12 15:30:33.923775
# Unit test for constructor of class OneOf
def test_OneOf():
    obj = OneOf(one_of=[])
    assert obj


# Generated at 2022-06-12 15:30:34.812630
# Unit test for constructor of class Not
def test_Not():
    assert Not(Any())



# Generated at 2022-06-12 15:30:41.198159
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(field1, field2)
    not_.validate(value, True)
    print("Test passed!")


# Generated at 2022-06-12 15:30:44.015079
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_list = [Any(), Any()]
    one_of_field = OneOf(one_of_list)
    assert one_of_field.one_of == one_of_list


# Generated at 2022-06-12 15:30:45.140747
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()


# Generated at 2022-06-12 15:30:50.747989
# Unit test for method validate of class Not
def test_Not_validate():
    a = Not(Any())
    # MUST work
    a.validate({})
    a.validate({23: 'hello'})
    a.validate([1,2,3])
    a.validate('hello')
    a.validate(23)
    # MUST fail
    try:
        a.validate(None)
    except Exception:
        pass
    except:
        assert False
    else:
        assert False

# Generated at 2022-06-12 15:30:52.493410
# Unit test for constructor of class Not
def test_Not():
    new_Not = Not(5)
    assert new_Not.negated == 5


# Generated at 2022-06-12 15:30:53.059104
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()

# Generated at 2022-06-12 15:30:54.093141
# Unit test for constructor of class OneOf
def test_OneOf():
    OneOf(one_of=[])


# Generated at 2022-06-12 15:30:58.310149
# Unit test for method validate of class Not
def test_Not_validate():
    # define
    field = Not(Any())

    print('--test_Not_validate--')
    try:
        # test valid case
        field.validate('abc')
        assert True
    except:
        assert False

    try:
        # test invalid case
        field.validate(None)
    except:
        assert True


# Generated at 2022-06-12 15:31:04.545800
# Unit test for method validate of class Not
def test_Not_validate():
    example = Not(negated=Any())
    error_msg = {}
    assert example.validate("", error_msg) == ""
    assert not error_msg
    assert example.validate("aa", error_msg) == "aa"
    assert not error_msg
    assert example.validate("abc", error_msg) == "abc"
    assert not error_msg

    example = Not(negated=String(max_length=10))
    error_msg = {}
    assert example.validate("", error_msg) == ""
    assert not error_msg
    assert example.validate("aa", error_msg) == "aa"
    assert not error_msg
    assert example.validate("abc", error_msg) == "abc"
    assert not error_msg

    error_msg = {}

# Generated at 2022-06-12 15:31:07.580318
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    validator = NeverMatch()
    try:
        validator.validate(None)
        assert False, "NeverMatch should always fail"
    except:
        pass


# Generated at 2022-06-12 15:31:25.681249
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    foo = NeverMatch()
    bar = NeverMatch()
    baz = NeverMatch()

    f = OneOf([foo, bar, baz])

    with pytest.raises(f.validation_error) as excinfo:
        f.validate(10, strict=False)

    assert excinfo.value.message == "Did not match any valid type."
    assert excinfo.value.code == "no_match"



# Generated at 2022-06-12 15:31:28.176560
# Unit test for constructor of class AllOf
def test_AllOf():
    class Schema1(Field):
        pass

    class Schema2(Field):
        pass

    all_of = AllOf([Schema1(), Schema2()])
    assert all_of.all_of[0].__class__ == Schema1
    assert all_of.all_of[1].__class__ == Schema2


# Generated at 2022-06-12 15:31:33.067794
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Parameter value of method is not None and input is correct
    # Return type of the method is Any

    # Parameter value of method is not None and input is correct
    # Return type of the method is Any

    # Parameter value of method is None but input is correct
    # Return type of the method is Any

    pass

# Generated at 2022-06-12 15:31:41.839501
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_1 = Integer()
    field_1.errors = {"integer_filed_error_1": "integer field error 1"}

    field_2 = Integer()
    field_2.errors = {"integer_filed_error_2": "integer field error 2"}

    field_3 = Integer()
    field_3.errors = {"integer_filed_error_3": "integer field error 3"}

    field = OneOf([field_1, field_2, field_3])

    try:
        field.validate(0)
    except Exception as e:
        assert str(e) == "integer field error 1"

    try:
        field.validate(2)
    except Exception as e:
        assert str(e) == "integer field error 2"


# Generated at 2022-06-12 15:31:44.886439
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated = Int(max_value = 5))
    assert field.validate(4) == 4
    with pytest.raises(InvalidType):
        field.validate(6)



# Generated at 2022-06-12 15:31:47.576464
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_instance = OneOf(one_of = [])
    try:
        test_instance.validate()
    except:
        return True
    return False


# Generated at 2022-06-12 15:31:55.228131
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # 'one_of' is required in constructor of OneOf
    with pytest.raises(TypeError, match=r".*missing 1 required positional argument.*"):
        one_of = OneOf()
        one_of.validate({})

    # one of the elements of 'one_of' cannot be validated
    one_of_field = OneOf(one_of = [{}])
    with pytest.raises(AssertionError, match=r".*The argument 'field' must be an instance of Field.*"):
        one_of_field.validate({})

    # the first element of 'one_of' can be validated
    one_of_field = OneOf(one_of = [Any()])
    assert one_of_field.validate({}) == {}

    # the second element of 'one_of'

# Generated at 2022-06-12 15:32:01.830156
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([{'type': 'string'}],name="test_field")
    assert field.validate("test") == "test"
    try:
        assert field.validate(1)
    except Field.ValidationError:
        print("no_match")
    try:
        assert field.validate("test")
    except Field.ValidationError:
        print("multiple_matches")


# Generated at 2022-06-12 15:32:07.688131
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    try:
        all_of = AllOf(
            [])
    except:
        pass
    try:
        all_of = AllOf(
            [String()])
    except:
        pass
    try:
        all_of = AllOf(
            [String()],
            format='json')
    except:
        pass
    try:
        all_of = AllOf(
            [String()],
            description='All')
    except:
        pass


# Generated at 2022-06-12 15:32:09.860423
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Field()])
    result = field.validate([1, 2, 3], strict=False)
    assert result == [1, 2, 3]



# Generated at 2022-06-12 15:32:19.435511
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import String

    class O(OneOf):
        def __init__(self, one_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(one_of, **kwargs)

    oo = O([String(max_length=2), String(max_length=3)])
    oo.validate('a')


# Generated at 2022-06-12 15:32:26.100997
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])

    assert field.validate(1) == 1
    assert field.validate("hey") == "hey"

    with pytest.raises(ValidationError) as exc_info:
        field.validate(None)
    assert exc_info.value.code == "no_match"

    with pytest.raises(ValidationError) as exc_info:
        field.validate(3.14)
    assert exc_info.value.code == "multiple_matches"

# Generated at 2022-06-12 15:32:35.717068
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # CASE: Valid
    # EXPECTED: OK (no error)
    one_of = OneOf([Any()])
    value = one_of.validate(42)
    assert value == 42

    # CASE: Not Valid
    # EXPECTED: Error
    with pytest.raises(ValidationError) as e:
        one_of = OneOf([Boolean()])
        value = one_of.validate(42)
    assert e.value.errors == {'code': 'no_match', 'message': 'Did not match any valid type.', 'value': 42}


# Generated at 2022-06-12 15:32:39.941155
# Unit test for constructor of class OneOf
def test_OneOf():
    # test error will be raised for invalid value for one of
    one_of_field = types.OneOf([
        types.String(),
        types.Integer()
    ])

    # Assert that error is raised for invalid value as None is not a valid
    # value for field types.Integer()
    with pytest.raises(types.ValidationError) as e:
        one_of_field.validate(None)

    # Assert that error message is as expected
    assert e.value.message == 'no_match'


# Generated at 2022-06-12 15:32:45.999929
# Unit test for method validate of class Not
def test_Not_validate():
    def negated_validate(value, strict=False):
        if value==8:
            return 'error', 'Must not match.'
        else:
            return 'ok', 'ok'

    negated = Field(validate=negated_validate)
    not_type = Not(negated)
    assert not_type.validate(8)==8
    assert not_type.validate(7)==7



# Generated at 2022-06-12 15:32:51.820403
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        ao = AllOf(all_of=None)
    except Exception:
        assert True
    else:
        assert False

    ao = AllOf(all_of=[])
    try:
        ao = AllOf(all_of=None, a=2)
    except Exception:
        assert True
    else:
        assert False

    ao = AllOf(all_of=[], a=2)
    assert ao.all_of == []
    assert ao.a == 2

# Test if we can define a never match class

# Generated at 2022-06-12 15:32:55.915400
# Unit test for method validate of class Not
def test_Not_validate():
    x = Not(String())
    r = x.validate(d={'io': 'oio'})
    print(r)
    x = Not(String())
    r = x.validate(d='oio')
    print(r)
test_Not_validate()

# Generated at 2022-06-12 15:32:57.413536
# Unit test for constructor of class OneOf
def test_OneOf():
    object = OneOf()
    assert object is not None


# Generated at 2022-06-12 15:33:06.472708
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Number(), String()])
    field.validate(123)
    field.validate("123")
    try:
        field.validate([123])
    except error.ValidationError as e:
        if 'no_match' not in e.messages:
            print("Wrong error message")
        if str(e) != "Did not match any valid type.":
            print("Wrong error message")
    else:
        print("Wrong error message")
    try:
        field.validate(123, 456)
    except error.ValidationError as e:
        if 'multiple_matches' not in e.messages:
            print("Wrong error message")
        if str(e) != "Matched more than one type.":
            print("Wrong error message")

# Generated at 2022-06-12 15:33:14.110249
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """ Test OneOf validate method"""
    f1 = String()
    f2 = String()
    f3 = String()
    f = OneOf([f1, f2])
    assert f.validate("hello") == "hello"
    with pytest.raises(ValidationError):
        f.validate(1)
    f = OneOf([f1, f2, f3])
    with pytest.raises(ValidationError):
        f.validate("hello")


# Generated at 2022-06-12 15:33:29.176524
# Unit test for method validate of class Not
def test_Not_validate():
    class col1(Field):
        def __init__(self):
            super().__init__()
            self.errors = {"1": "Yes"}
        def validate(self, value, strict=False):
            raise self.validation_error("1")
    class col2(Field):
        def __init__(self):
            super().__init__()
            self.errors = {"2": "No"}
        def validate(self, value, strict=False):
            raise self.validation_error("2")
    not_col1 = Not(col1())
    not_col2 = Not(col2())
    print("not_col1.validate_or_error(2):", not_col1.validate_or_error(2))

# Generated at 2022-06-12 15:33:32.613297
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer, String
    from typesystem.types import Schema

    class MySchema(Schema):
        field = AllOf([Integer(),String()])

    schema = MySchema({'field': '123'})
    assert schema.is_valid() is True

# Generated at 2022-06-12 15:33:35.527915
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    assert field.validate("Hello World") == "Hello World"
    with pytest.raises(ValidationError):
        field.validate(123)


# Generated at 2022-06-12 15:33:39.956038
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of = [])
    assert field.all_of == []

    field = AllOf(all_of = [Any()])
    assert field.all_of == [Any()]

    field = AllOf(all_of = [Any(), Any()])
    assert field.all_of == [Any(), Any()]



# Generated at 2022-06-12 15:33:44.405543
# Unit test for method validate of class Not
def test_Not_validate():
    from .base import Number
    from .base import String

    field = Not(String())
    assert field.validate(123) == 123
    assert field.validate(123.456) == 123.456
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(()) == ()


# Generated at 2022-06-12 15:33:50.755336
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer
    notField = Not(Integer())
    # Checks the branch that returns 'value', the value which is not matched
    assert notField.validate(4.5) == 4.5
    # Checks the branch that raises an error
    try:
        notField.validate(4)
    except Exception as e:
        print(str(e))
        assert str(e) == "Must not match."
    

# Generated at 2022-06-12 15:33:51.753365
# Unit test for constructor of class AllOf
def test_AllOf():
    assert all_of is not None


# Generated at 2022-06-12 15:33:58.686931
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    item = OneOf([Boolean(), String(), DateTime()])
    assert item.validate(True) is True
    assert item.validate("foo") == "foo"
    import datetime
    assert item.validate(datetime.datetime.now()) == datetime.datetime.now()

    try:
        item.validate(1)
        assert False
    except ValidationError:
        pass
    try:
        item.validate([])
        assert False
    except ValidationError:
        pass
    try:
        item.validate({"foo": 1})
        assert False
    except ValidationError:
        pass



# Generated at 2022-06-12 15:34:04.633422
# Unit test for method validate of class Not
def test_Not_validate():
    x = Not(negated = StringField(min_length = 2, max_length = 5))
    assert x.validate("") == ""
    assert x.validate("hello") == "hello"
    assert x.validate("helloworld") == "helloworld"
    assert x.validate(1) == 1
    assert x.validate([]) == []
    assert x.validate({}) == {}



# Generated at 2022-06-12 15:34:08.263392
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import QueryParameters
    from typesystem.exceptions import ValidationError
    
    class QueryStringSchema(QueryParameters):
        name = String()
        age = String()
    assert isinstance(QueryStringSchema().fields['age'], String), 'Incorrect type'
    

# Generated at 2022-06-12 15:34:32.495934
# Unit test for method validate of class Not
def test_Not_validate():
    a = Schema([Not(Integer())])
    assert a.validate([1, -1]) == [1, -1]
    assert a.validate([1, -1, 1.1]) == [1, -1, 1.1]
    assert a.validate([]) == []
    assert a.validate(["a", "b"]) == ["a", "b"]
    assert a.validate([1.1, 1.1]) == [1.1, 1.1]

# Generated at 2022-06-12 15:34:38.829957
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not({"type": "string"})
    value, error = n.validate_or_error(8.2)
    assert error == None
    assert value == 8.2
    value, error = n.validate_or_error(8)
    assert error == None
    assert value == 8
    value, error = n.validate_or_error("hey")
    assert error == "negated"
    assert value == None


# Generated at 2022-06-12 15:34:43.351958
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String())

    assert not_field.validate(1) == 1
    assert not_field.validate([1, 2]) == [1, 2]
    with pytest.raises(ValidationError) as excinfo:
        not_field.validate('str')
    assert excinfo.match('Must not match.')



# Generated at 2022-06-12 15:34:44.235787
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Not(Field()))()
    field.validate(1)

# Generated at 2022-06-12 15:34:47.941173
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any(), name="f")
    field.validate(42)
    try:
        field.validate(None)
        assert False, "Should raise"
    except field.ValidationError:
        pass



# Generated at 2022-06-12 15:34:51.317832
# Unit test for method validate of class Not
def test_Not_validate():
    """
    method: validate
    when: called
    with:
    should: succeed
    """
    test_field = Not(negated=Any())
    test_field.validate(value=None, strict=False)



# Generated at 2022-06-12 15:34:55.272319
# Unit test for method validate of class Not
def test_Not_validate():
    field = typesystem.OneOf([typesystem.Integer(), typesystem.String()])
    field.validate("string")

    field = typesystem.Not(typesystem.Integer())
    try:
        field.validate("string")
    except typesystem.ValidationError:
        assert True
    except:
        assert False
        

# Generated at 2022-06-12 15:35:03.031056
# Unit test for method validate of class Not
def test_Not_validate():
    class field(Field):
        def __init__(self):
            self.errors = {"error": "This doesn't work."}
            self.validate_messages = []

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            self.validate_messages.append(value)
            raise self.validation_error("error")

    f = field()
    n = Not(negated=f)
    with pytest.raises(n.validation_error):
        assert n.validate("foo") == "foo"
    with pytest.raises(n.validation_error):
        assert n.validate("bar") == "bar"
    assert f.validate_messages == ["foo", "bar"]

# Generated at 2022-06-12 15:35:14.582728
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate('a') == 'a'
    assert not_field.validate('') == ''
    assert not_field.validate(['1','2','1','1','1']) == ['1','2','1','1','1']
    assert not_field.validate({'name':'dev','age':'20','sex':'male'}) == {'name':'dev','age':'20','sex':'male'}
    assert not_field.validate(False) == False
    assert not_field.validate(True) == True
    # assert not_field.validate('') == 'must not match'


# Generated at 2022-06-12 15:35:19.978502
# Unit test for method validate of class Not
def test_Not_validate():
    # Two test examples
    f1 = Not(Any())
    f2= Not(Integer())
    assert f1.validate(False)
    assert f2.validate(5)
    assert f2.validate(0)
    assert f2.validate(True)
    assert f2.validate(False)
    assert f2.validate("abcde")
    assert f2.validate(["abcde"])
    assert f2.validate(5.5)



# Generated at 2022-06-12 15:35:36.009097
# Unit test for method validate of class Not
def test_Not_validate():
    test_schema = Not(String())

    # when
    result = test_schema.validate(5)

    # then
    assert result == 5

# Generated at 2022-06-12 15:35:42.188058
# Unit test for method validate of class Not
def test_Not_validate():
    class TestNot(Not):
        def __init__(self, negated: Field, **kwargs: typing.Any):
            super().__init__(negated, **kwargs)

    test_not = TestNot(negated=Any())
    answer = test_not.validate("1")
    assert answer == "1"



# Generated at 2022-06-12 15:35:52.171780
# Unit test for method validate of class Not

# Generated at 2022-06-12 15:35:59.938544
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem
    from typesystem.base import Error

    # case 1: negated == None
    negated = None
    not_validate = Not(negated)
    value = 'aa'
    strict = False
    assert not_validate.validate(value, strict) == value

    # case 2: negated is not None and raise typesystem.base.Error
    negated = typesystem.String()
    not_validate = Not(negated)
    value = 1
    strict = False
    with pytest.raises(Error) as excinfo:
        not_validate.validate(value, strict)
    assert 'Must not match.' in str(excinfo.value)

    # case 3: negated is not None and not raise typesystem.base.Error
    negated = typesystem.String()

# Generated at 2022-06-12 15:36:08.746264
# Unit test for method validate of class Not
def test_Not_validate():
    import json
    import typing
    from typesystem.fields import Integer, Not

    class Address(typesystem.Schema):
        street = typesystem.String(max_length=255)
        zip_code = Not(Integer())

    assert Address().validate({"street": "Storgata 5", "zip_code": "0000"}) == {
        "street": "Storgata 5",
        "zip_code": "0000",
    }
    assert Address().validate({"street": "Storgata 5", "zip_code": "0000"}) == {
        "street": "Storgata 5",
        "zip_code": "0000",
    }

# Generated at 2022-06-12 15:36:13.355231
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String

    string_field = String(max_length=5)
    not_string_field = Not(string_field)
    assert not_string_field.validate("12345") == "12345"
    try:
        assert not_string_field.validate("123456")
        assert False
    except Exception as e:
        assert e.args[0]["code"] == "negated"

# Generated at 2022-06-12 15:36:15.470653
# Unit test for method validate of class Not
def test_Not_validate():
    integer_type = Integer()
    not_type = Not(negated=integer_type)
    assert not_type.validate(value='1') == '1'


# Generated at 2022-06-12 15:36:18.812841
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    # Should return value if error is True
    value = True
    error = field.validate(value)
    assert error == value
    # Should raise ValidationError exception if error is None
    value = False
    try:
        field.validate(value)
    except Exception as err:
        assert type(err) == field.validation_error

# Generated at 2022-06-12 15:36:23.078542
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer

    field = Not(Integer())
    assert_raises(ValidationError, field.validate, 5.6)
    assert field.validate(None) is None
    assert field.validate("hello") == "hello"



# Generated at 2022-06-12 15:36:24.433242
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated='i am a string')
    assert field.validate('i am a string') == 'i am a string'



# Generated at 2022-06-12 15:36:56.275891
# Unit test for method validate of class Not
def test_Not_validate():
    class MockField:
        def validate(self, value: typing.Any, strict: bool = False):
            return value, []

    my_field = Not(MockField())
    res = my_field.validate(1, True)
    assert res == 1


# Generated at 2022-06-12 15:36:59.522491
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=Any()).validate(None) == None
    assert Not(negated=String()).validate(None) == None

    try:
        Not(negated=String()).validate(2)
        assert False
    except:
        assert True


# Generated at 2022-06-12 15:37:03.958797
# Unit test for method validate of class Not
def test_Not_validate():
    # Ensure that when the field is valid, no exception is raised.
    not_field = Not(Any())
    not_field.validate("a")

    # Ensure that when the field is invalid, a ValidationError is raised.
    not_field = Not(String())
    try:
        not_field.validate("a")
    except ValidationError:
        pass

# Generated at 2022-06-12 15:37:07.909320
# Unit test for method validate of class Not
def test_Not_validate():
    field_a = Field()
    field_a.errors["custom"] = "Custom error message."
    field_a.validation_error = field_a.make_error("custom")
    not_field = Not(field_a)
    assert not_field.validate(value=1) == 1


# Generated at 2022-06-12 15:37:15.575007
# Unit test for method validate of class Not
def test_Not_validate():
    b = Not(Field())
    f1 = Field(max_length = 10)
    f2 = Field(max_length = 20)
    b.validate_and_raise("Terraform")
    b.validate_and_raise("Terraform Terraform")
    assert(b.validate("Terraform", strict=False) == "Terraform")
    b = Not(f1)
    b.validate_and_raise("Terraform")
    b.validate_and_raise("Terraform Terraform")
    assert(b.validate("Terraform", strict=False) == "Terraform")
    b = Not(f2)
    b.validate_and_raise("Terraform Terraform")
    b.validate_and_raise("Terraform Terraform Terraform")
   

# Generated at 2022-06-12 15:37:17.676665
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(AllOf([String(pattern=r"^[0-9]+$"), Int()]))
    value = "123"
    errors = not_field.validate(value, strict=False)
    assert errors == []

# Generated at 2022-06-12 15:37:20.916902
# Unit test for method validate of class Not
def test_Not_validate():
    class UnitTestNotValidat(unittest.TestCase):
        def setUp(self):
            self.notPositive = Not(Integer(min_value=0))

        def test_valid_value(self):
            self.assertEqual(self.notPositive.validate(-7), -7)

        def test_invalid_value(self):
            self.assertRaises(ValidationError, self.notPositive.validate, 7)



# Generated at 2022-06-12 15:37:25.620747
# Unit test for method validate of class Not
def test_Not_validate():
    number_field = Number()
    not_number_field = Not(number_field)
    not_number_field.validate(None)

    negated_number_field = Not(number_field)
    try:
        negated_number_field.validate(3)
        assert False
    except ValidationError as e:
        assert len(e.detail) == 1
        assert "negated" in e.detail

    not_negated_number_field = Not(negated_number_field)
    not_negated_number_field.validate(3)


# Generated at 2022-06-12 15:37:30.807423
# Unit test for method validate of class Not
def test_Not_validate():
    class TestField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value+1
    not_f1 = Not(TestField(),name="test")
    assert not_f1.validate(1) == 1
    assert not_f1.validate(2) == 2



# Generated at 2022-06-12 15:37:38.425702
# Unit test for method validate of class Not
def test_Not_validate():

    # create a simple Field that checks if the number is positive
    class PositiveField(Field):

        errors = {
            "not_positive": "Number should be positive."
        }

        def validate(self, value: int) -> int:
            if value <= 0:
                raise self.validation_error("not_positive")
            return value

    my_field = Not(PositiveField())
    # check if validation of a negative number works
    try:
        my_field.validate(-10)
    except ValidationError:
        assert True

    # check if validation of a positive number throws an error
    try:
        my_field.validate(10)
        assert True
    except ValidationError:
        assert False


# Generated at 2022-06-12 15:38:35.739198
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(negated=None)
    a = Field()
    assert not_.validate(a) == a