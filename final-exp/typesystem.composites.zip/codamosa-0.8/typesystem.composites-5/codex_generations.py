

# Generated at 2022-06-12 15:28:41.734818
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse(int, int, str)
    assert a.validate(1)==1
    assert a.validate('hello')=='hello'

# Generated at 2022-06-12 15:28:44.273979
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem
    n = Not(typesystem.String())
    assert n.validate("x") == "x"
    try:
        n.validate("")
        assert False
    except typesystem.ValidationError as e:
        assert e.code == "negated"

# Generated at 2022-06-12 15:28:49.239441
# Unit test for method validate of class Not
def test_Not_validate(): 
    not_field = Not(negated=Field(), description='abc')
    try:
        not_field.validate('abc')
    except Exception as e:
        assert type(e) == not_field.validation_error
        assert e.code == 'negated'
        assert e.desc == "Must not match."



# Generated at 2022-06-12 15:28:55.019737
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    field = OneOf([], error = "no_match", strict_error = True)
    with pytest.raises(field.validation_error) as excinfo:
        field.validate("test")
    assert excinfo.value.code == "no_match"

    field = OneOf([types.String("test")], error = "no_match", strict_error = True)
    with pytest.raises(field.validation_error) as excinfo:
        field.validate("test1")
    assert excinfo.value.code == "no_match"

    field = OneOf([types.String("test1"), types.String("test2")], error = "no_match", strict_error = True)

# Generated at 2022-06-12 15:28:58.035109
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Case that value is integer and the value is true
    case_1 = IfThenElse(Field(type="integer", minimum=0), Field(type="integer", minimum=10))
    assert case_1.validate(33) == 33

    # Case that value is integer and the value is false
    case_2 = IfThenElse(Field(type="integer", minimum=10), Field(type="integer", minimum=0), Field(type="integer", minimum=10))
    assert case_2.validate(20) == 20


# Generated at 2022-06-12 15:29:05.506301
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    field = IfThenElse(Integer(minimum=50), Integer(), Integer(minimum=100))
    assert field.validate(None) is None
    assert field.validate(80) == 80
    assert field.validate(50) == 50
    assert field.validate(25) == 25
    try:
        field.validate(25, strict=True)
        assert False
    except Exception as e:
        assert str(e) == "Must be greater than or equal to 50."

# Generated at 2022-06-12 15:29:16.960867
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # test the normal situation
    a_if = Union([String(), Integer()])
    a_then = String()
    a_else = Integer()
    a_ifthenelse = IfThenElse(a_if, a_then, a_else)
    assert a_ifthenelse.validate(1) == 1
    assert a_ifthenelse.validate("1") == "1"
    # test if the input is None
    a_ifthenelse = IfThenElse(a_if, a_then)
    try:
        assert a_ifthenelse.validate(None)
    except Exception:
        return True
    else:
        return False
    # test if the input is neither in then clause nor else clause
    try:
        assert a_ifthenelse.validate(True)
    except Exception:
        return True

# Generated at 2022-06-12 15:29:21.597566
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Int(Field):
        def validate(self,value,strict=False):
            try:
                return int(value)
            except:
                raise self.validation_error("not_int")

    class Even(Field):
        def validate(self,value,strict=False):
            if value % 2 == 0:
                return value
            else:
                raise self.validation_error("not_even")

    class Odd(Field):
        def validate(self,value,strict=False):
            if value % 2 == 1:
                return value
            else:
                raise self.validation_error("not_odd")

    class IfEvenThenOddElseInt(Field):
        def __init__(self,**kwargs):
            if "allow_null" in kwargs:
                super().__init__

# Generated at 2022-06-12 15:29:22.886123
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match


# Generated at 2022-06-12 15:29:25.526491
# Unit test for method validate of class Not
def test_Not_validate():
    # Initialize data for testing
    negated = Boolean()
    negated.validate("true")

    # Create object of class Not
    not_ = Not(negated) 

    # Call method validate
    not_.validate("false")


# Generated at 2022-06-12 15:29:29.058592
# Unit test for constructor of class Not
def test_Not():
    t1 = Not(Any())
    assert t1.negated == Any()

# Generated at 2022-06-12 15:29:33.185523
# Unit test for method validate of class Not
def test_Not_validate():
    class test:
        def __init__(self, value):
            self.value = value
        def validate(self, value, strict : bool = False) -> typing.Any :
            if self.value == value:
                raise self.validation_error("negated")
            return value

    t = test(5)
    t2 = Not(t)
    t2.validate(6)

    try:
        t2.validate(5)
    except Exception as e:
        print(e.validation_error_message)
        assert(True)
    else:
        assert(False)

if __name__ == "__main__":
    test_Not_validate()

# Generated at 2022-06-12 15:29:43.003504
# Unit test for method validate of class Not
def test_Not_validate():
    # valid_value which will pass the test
    valid_value = {
        "oneOf": [{"type": "string"}, {"type": "integer"}],
        "not": {"type": "string"},
    }
    # invalid_value which will fail the test
    invalid_value = {
        "oneOf": [{"type": "string"}, {"type": "integer"}],
        "not": {"type": "integer"},
    }

    nf = Not(valid_value["not"])
    nf.validate(invalid_value)
    print("Test 1 Passed")

    # test for exception
    try:
        nf.validate(valid_value)
    except Exception:
        print("Test 2 Passed")


# Generated at 2022-06-12 15:29:43.864609
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(10, 2)



# Generated at 2022-06-12 15:29:44.998731
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf([Boolean()])
    assert o is not None


# Generated at 2022-06-12 15:29:46.733352
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf is not None


# Generated at 2022-06-12 15:29:49.407773
# Unit test for method validate of class Not
def test_Not_validate():
    negated_field = NeverMatch()
    not_field = Not(negated_field)
    value = 'success'
    assert not_field.validate(value) == 'success'

# Generated at 2022-06-12 15:29:56.350507
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print('Unit test for method validate of class OneOf')

    # field = OneOf(one_of=[Int(), Array(items=String())])
    field = OneOf([Int(), Array(items=String())])
    value = 321
    expected = 321
    assert field.validate(value) == expected
    

    # field = OneOf(one_of=[Int(), Array(items=String())])
    field = OneOf([Int(), Array(items=String())])
    value = ["a", "b"]
    expected = ["a", "b"]
    assert field.validate(value) == expected
    



# Generated at 2022-06-12 15:30:04.932096
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Schema

    class Product(Schema):
        name = String()
        price = Not(Integer())
        errors = {"negated": "Must not match."}

    p = Product({"name": "123", "price": "456"})
    assert p.is_valid()

    p = Product({"name": "123", "price": "a"})
    assert p.is_valid()

    p = Product({"name": "123", "price": 1})
    assert not p.is_valid()
    assert {"price": ["Must not match."]} == p.errors

# Generated at 2022-06-12 15:30:07.583998
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    n.validate(3)
    assert n.validate(3) == 3
    with pytest.raises(Exception):
        n.validate(None)


# Generated at 2022-06-12 15:30:18.220677
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(String(max_length=4), String(max_length=4)).validate("1234") == "1234"
    assert IfThenElse(String(min_length=10), String(max_length=4)).validate("12345678910") == "12345678910"
    assert IfThenElse(String(max_length=4), String(), String(max_length=4)).validate("12345") == "12345"
    assert IfThenElse(String(max_length=4), String(max_length=4), String(max_length=4)).validate("12345") == "12345"

# Generated at 2022-06-12 15:30:22.830544
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(int, then_clause=str)
    assert schema.validate(1) == 1
    assert schema.validate(2) == 2
    assert schema.validate(3) == 3


# Generated at 2022-06-12 15:30:33.274155
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause = String(), then_clause = String(), else_clause = String())
    assert field.validate("1") == "1"
    assert field.validate(1) == "1"
    assert field.validate(1.1) == "1.1"
    assert field.validate({}) == "{}"
    assert field.validate(None) == "null"
    #assert field.validate("") == ""
    #assert field.validate("#") == "#"
    assert field.validate(" ") == " "
    assert field.validate("a") == "a"
    #assert field.validate("false") == "false"
    #assert field.validate("true") == "true"

# Generated at 2022-06-12 15:30:36.917516
# Unit test for constructor of class OneOf
def test_OneOf():
    oneof_schema = OneOf(
        one_of=[
            {
                "type": "integer",
            },
            {
                "type": "string",
            },
        ]
    )
    assert oneof_schema.validate(5) == 5
    assert oneof_schema.validate("5") == "5"
    try:
        oneof_schema.validate(True)
    except Exception:
        assert True
    else:
        assert False



# Generated at 2022-06-12 15:30:38.079922
# Unit test for constructor of class Not
def test_Not():
    not_obj = Not(Any())
    assert (not_obj.negated == Any())
    

# Generated at 2022-06-12 15:30:44.877609
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    myField = IfThenElse(if_clause="1", then_clause="2")
    assert myField.validate("1") == "2"
    assert myField.validate("3") == "3"
    myField = IfThenElse(if_clause="1", then_clause="2", else_clause="4")
    assert myField.validate("1") == "2"
    assert myField.validate("3") == "4"



# Generated at 2022-06-12 15:30:54.650753
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String

    # if_clause must be a string
    if_clause = String(max_length=15)
    # then_clause must be a string
    then_clause=String(max_length=5)
    # else_clause must be a string
    else_clause=String(max_length=3)

    # if_clause is string and its length is less than 15
    then_value="then"

    # if_clause is string and its length is more than 15
    else_value="else"

    if_then_else=IfThenElse(if_clause, then_clause, else_clause)

    # value of if_clause is less than 15
    assert if_then_else.validate(then_value) == then_value

    # value of

# Generated at 2022-06-12 15:30:59.101376
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = "abc"
    # create a dummy field
    test_field = IfThenElse(
        if_clause=Field(title="if"),
        then_clause=Field(title="then"),
        else_clause=Field(title="else"),
    )
    # run method validate
    result = test_field.validate(value)
    # assert the results
    assert result == value

# Generated at 2022-06-12 15:31:04.239742
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    AllOf_instance = AllOf([Integer()])
    assert AllOf_instance.validate(1) == 1
    OneOf_instance = OneOf([String(), Integer()])
    assert OneOf_instance.validate("test") == "test"
    Not_instance = Not(AllOf([Integer()]))
    assert Not_instance.validate("test") == "test"
    IfThenElse_instance = IfThenElse(Integer(), then_clause=String())
    assert IfThenElse_instance.validate(1) == 1
    NeverMatch_instance = NeverMatch()
    try:
        NeverMatch_instance.validate(1)
    except Exception as error:
        print(error)

# Generated at 2022-06-12 15:31:06.762682
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Integer(), String()])

    assert one_of.validate(1) == 1
    assert one_of.validate("a") == "a"

    with pytest.raises(ValidationError):
        one_of.validate(1.1)

    with pytest.raises(ValidationError):
        one_of.validate([1])

# Generated at 2022-06-12 15:31:14.872121
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # type: () -> None
    from datetime import date
    from typesystem.types import Date

    field = OneOf(
        one_of=[
            Date(),
            Date(),
        ]
    )

    assert field.validate(date(2018, 1, 1)) == date(2018, 1, 1)
    assert field.validate(date(2018, 1, 2)) == date(2018, 1, 2)


# Generated at 2022-06-12 15:31:19.571694
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create an instance of Class Any
    any_class = Any()

    # Create an instance of Class Any
    any_class1 = Any()

    # Create an instance of Class OneOf
    one_of_class = OneOf([any_class, any_class1])

    # Call method validate of one_of_class
    # Type warning
    one_of_class.validate(1)


# Generated at 2022-06-12 15:31:25.119834
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Boolean, Integer, String
    from typesystem import ValidationError

    allof_boolean_integer = AllOf([Boolean(), Integer()])
    assert allof_boolean_integer.validate(1) == 1
    assert allof_boolean_integer.validate(True) == True
    try:
        allof_boolean_integer.validate("")
    except ValidationError as e:
        assert e.code == "not_an_integer"


# Generated at 2022-06-12 15:31:29.581855
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    assert(IfThenElse(Integer(), Integer(), Integer()).validate(1).value == 1)
    assert(IfThenElse(Integer(), Integer(), Integer()).validate(True).value == True)


# Generated at 2022-06-12 15:31:33.219138
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    #instance = OneOf(one_of=None)
    #assert_equals(expected, instance.validate(value, strict))
    assert True # TODO: implement your test here


# Generated at 2022-06-12 15:31:37.183758
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # The following statement should not raise an exception
    field = NeverMatch()
    # The following statement should raise an exception
    def test_NeverMatch_exception():
        field = NeverMatch(allow_null=True)
    test_NeverMatch_exception()
    field.validate_or_error(1)

# Generated at 2022-06-12 15:31:38.693323
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    assert f.errors == {'never': 'This never validates.'}


# Generated at 2022-06-12 15:31:44.597490
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.integer import Integer
    from typesystem.string import String
    str_field = String(max_length=3)
    int_field = Integer(maximum=2)
    if_clause = str_field
    then_clause = int_field
    else_clause = int_field
    conditional_field = IfThenElse(if_clause,then_clause,else_clause)

    try:
        result = conditional_field.validate('a')
        assert result == 0
        result = conditional_field.validate(3)
        assert result == 3
    except Exception as err:
        print(err)
        assert False

# Generated at 2022-06-12 15:31:53.526617
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String
    if_clause = String(max_length=3)
    then_clause = String(max_length=4)
    else_clause = String(max_length=5)
    ite = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    assert ite.validate('abc') == 'abc'
    assert ite.validate('abcd') == 'abcd'
    assert ite.validate('abcde') == 'abcde'
    try:
        ite.validate('abdef')
        assert False, 'Expected a validation error'
    except Exception as ex:
        assert ex.message == 'Must be no longer than 4 characters.'

# Generated at 2022-06-12 15:31:58.374992
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(),then_clause=Str(), else_clause=Str()).validate('test', strict=False) == 'test'
    assert IfThenElse(if_clause=Str(),then_clause=Str(), else_clause=Str()).validate('test', strict=False) == 'test'

# Generated at 2022-06-12 15:32:05.568303
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = "String"
    strict = True

    all_of = IfThenElse(if_clause, then_clause, else_clause)
    result = all_of.validate(value, strict)
    assert result == value


# Generated at 2022-06-12 15:32:11.732440
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def validate_and_catch_error(field, value):
        try:
            field.validate(value)
        except ValidationError as e:
            return e
        return None

    # True, True, True
    assert validate_and_catch_error(IfThenElse(Boolean(), Boolean(), Boolean()), True) is None
    # False, False, False
    assert validate_and_catch_error(IfThenElse(Boolean(), Boolean(), Boolean()), False) is None
    # False, True, False
    assert validate_and_catch_error(IfThenElse(Boolean(), Boolean(), Boolean()), 1) is None
    assert validate_and_catch_error(IfThenElse(Boolean(), Boolean(), Boolean()), 1.0) is None

# Generated at 2022-06-12 15:32:21.571948
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    
    assert IfThenElse(typesystem.String(), typesystem.Integer()).validate("test") == "test"
    assert IfThenElse(typesystem.String(), typesystem.Integer()).validate(5) == 5
    assert IfThenElse(typesystem.String(required=False), typesystem.Integer()).validate("test") == "test"
    assert IfThenElse(typesystem.String(required=False), typesystem.Integer()).validate(5) == 5
    assert IfThenElse(typesystem.String(required=False), typesystem.Integer(required=False)).validate("test") == "test"
    assert IfThenElse(typesystem.String(required=False), typesystem.Integer(required=False)).validate(5) == 5

# Generated at 2022-06-12 15:32:25.532238
# Unit test for constructor of class Not
def test_Not():
    try:
        Not(negated="string")
    except AssertionError:
        print("'negated' should be a Field")
    try:
        Not("string", negated="string")
    except AssertionError:
        print("'negated' should be a Field")


# Generated at 2022-06-12 15:32:26.130826
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass



# Generated at 2022-06-12 15:32:26.919124
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    Field()

# Generated at 2022-06-12 15:32:38.495708
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  never_match_schema = NeverMatch()
  assert never_match_schema.name is None
  assert never_match_schema.context is None
  assert never_match_schema.path is None
  assert never_match_schema.allow_null is False
  assert never_match_schema.errors == {"never": "This never validates."}
  assert never_match_schema.extra_properties == False
  assert never_match_schema.pattern is None
  assert never_match_schema.regex is None
  assert never_match_schema.enum is None
  assert never_match_schema.const is None
  assert never_match_schema.multiple_of is None
  assert never_match_schema.minimum is None
  assert never_match_schema.maximum is None

# Generated at 2022-06-12 15:32:39.165523
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-12 15:32:42.172451
# Unit test for constructor of class OneOf
def test_OneOf():
    # Initialize the class with default arguments
    assert OneOf([Any()]).one_of == [Any()]


# Generated at 2022-06-12 15:32:45.409888
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create object of class OneOf
    test_obj = OneOf(one_of = 1)

    # Create input for method validate of class OneOf
    value = 1
    strict = 1

    # Call method validate of class OneOf
    test_obj.validate(value, strict)

# Generated at 2022-06-12 15:32:57.880363
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Student(types.Document):
        major = fields.StringField()
        age = fields.IntField()
        sex = fields.StringField()
        if_clause = IfThenElse(
            if_clause = ((lambda major: major == "CS") if (lambda major: major == "CS") else None),
            then_clause = fields.IntField(),
            else_clause = fields.StringField(),
        )
        s: Student(major = "CS", age = 18, sex = "male", if_clause = 12)
        s: Student(major = "Math", age = 18, sex = "male", if_clause = "12")

# Generated at 2022-06-12 15:33:06.776384
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = Field(default=5, nullable=True)
    y = Field(default=10, nullable=True)
    z = IfThenElse(x, y)
    assert z.validate(None) is None
    assert z.validate(5) == 5   # if-clause default value
    assert z.validate(10) == 10 # then-clause default value
    assert z.validate(6) == 10  # then-clause default value
    #
    x2 = Field(default=5, nullable=False)
    y2 = Field(default=10, nullable=False)
    z2 = IfThenElse(x2, y2)
    assert z2.validate(5) == 5   # if-clause default value
    assert z2.validate(10) == 10 # then-

# Generated at 2022-06-12 15:33:07.379423
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-12 15:33:18.646495
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import ipdb; ipdb.set_trace()
    number_list = [1, 5, 4, 6]

    ### Test of no error ###
    IfThenElse([1,2,3],None,None).validate(number_list)

    ### Test of no error ###
    IfThenElse([1,5,3],None,None).validate(number_list)

    ### Test of no error ###
    IfThenElse([1,7,3],None,None).validate(number_list)

    ### Test of no error ###
    IfThenElse([1,5,7],None,None).validate(number_list)

    ### Test of no error ###
    IfThenElse([1,5,6],None,None).validate(number_list)

    ### Test of no error ###

# Generated at 2022-06-12 15:33:22.443616
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_field = IfThenElse(
        if_clause = BaseField(required=True),
        then_clause = BaseField(required=True),
        else_clause = BaseField(required=False)
    )
    test_field.validate("test")


# Generated at 2022-06-12 15:33:27.658865
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def validate_if_clause_or_error(value, strict = False):
        raise NeverMatch.validation_error('negated')

    def validate_else_clause(value, strict = False):
        return 'else'

    import mock
    with mock.patch('typesystem.schema.NeverMatch.validate_or_error', validate_if_clause_or_error):
        if_then_else = IfThenElse(NeverMatch())
        value = if_then_else.validate(None)
        assert value == 'else'

# Generated at 2022-06-12 15:33:31.015869
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String

    not_name = Not(String())
    assert not_name.negated.type == 'string'

    not_name = Not(String(allow_null=True))
    assert not_name.negated.allow_null

# Generated at 2022-06-12 15:33:32.003019
# Unit test for constructor of class OneOf
def test_OneOf():
    assert (OneOf([], error_messages={}) != None)


# Generated at 2022-06-12 15:33:34.482550
# Unit test for constructor of class Not
def test_Not():
    n = Not(Any())
    assert n.error_messages == {"negated": "Must not match."}
    assert n.negated.error_messages == {}


# Generated at 2022-06-12 15:33:42.710413
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.base import ValidationError
    from typesystem.fields import Boolean, Integer

    if_clause = Boolean()
    then_clause = Integer()
    else_clause = Integer()
    field =  IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(True) == True
    try:
        field.validate(False)
    except ValidationError as exc:
        assert str(exc) == "Value is not true."
    else:
        raise AssertionError()

    then_clause = Boolean()
    else_clause = Boolean()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(True) == True
    assert field.validate(False) == False

# Generated at 2022-06-12 15:33:55.529587
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause = Int(max_value = 0),
        then_clause = Int(max_value = 1),
        else_clause = Int(max_value = 2),
    )
    field.validate(0)
    field.validate(1)
    field.validate(2)
    try:
        field.validate(3)
        assert False
    except:
        assert True
    field = IfThenElse(
        if_clause = Int(max_value = 1),
        then_clause = Int(max_value = 1),
        else_clause = Int(max_value = 2),
    )
    try:
        field.validate(3)
        assert False
    except:
        assert True

# Generated at 2022-06-12 15:33:57.176828
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    const = IfThenElse(Field(), Field())
    assert const.if_clause
    assert const.then_clause
    assert not const.else_clause
    assert const.errors == {}

# Generated at 2022-06-12 15:33:58.766133
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(String(), String())
    field.validate("hello")


# Generated at 2022-06-12 15:34:03.876047
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    testcases = [
        (True, 3, 2, 3),
        (True, 3, 5, 3),
        (False, 3, 2, 2),
        (False, 3, 5, 5),
    ]
    for tc in testcases:
        assert IfThenElse(tc[0], tc[1], tc[2]).validate(tc[3]) == tc[3]

# Generated at 2022-06-12 15:34:11.293471
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import typesystem
    from typesystem.fields import String
    import json
    import pytest
    test_data = {}

# Generated at 2022-06-12 15:34:15.445379
# Unit test for constructor of class Not
def test_Not():
    # Testing constructor
    negated = String()
    n = Not(negated=negated)

    # Testing getters
    assert n.negated == negated
    assert n.errors == {'negated': 'Must not match.'}

if __name__ == "__main__":
    test_Not()

# Generated at 2022-06-12 15:34:16.410774
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()



# Generated at 2022-06-12 15:34:18.985422
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert schema.validate("a string") == "a string"


# Generated at 2022-06-12 15:34:21.340715
# Unit test for constructor of class AllOf
def test_AllOf():
    _ = AllOf([])


# Generated at 2022-06-12 15:34:23.079566
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import String, Integer

    many = OneOf([String(), Integer()])
    print(many)



# Generated at 2022-06-12 15:34:27.880605
# Unit test for constructor of class OneOf
def test_OneOf():
    n = NeverMatch('name 1', 'name 2')
    assert n.name == 'name 1'

# Generated at 2022-06-12 15:34:28.985679
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-12 15:34:29.622503
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf.__init__

# Generated at 2022-06-12 15:34:35.105552
# Unit test for constructor of class OneOf
def test_OneOf():
    f1 = OneOf(one_of=[])
    f2 = OneOf(one_of=[], allow_empty=True)
    f3 = OneOf(one_of=[], allow_null=True)
    f4 = OneOf(one_of=[], allow_empty=True, allow_null=True)


# Generated at 2022-06-12 15:34:44.132525
# Unit test for constructor of class OneOf
def test_OneOf():
    #test 1
    validator = OneOf([String()], name="name")
    assert validator.name == "name"
    assert validator.required == True
    assert validator.allow_null == False
    assert validator.one_of == [String()]
    assert validator.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}
    #test 2
    validator = OneOf([Integer()], name="name", required=False)
    assert validator.name == "name"
    assert validator.required == False
    assert validator.allow_null == False
    assert validator.one_of == [Integer()]

# Generated at 2022-06-12 15:34:47.442333
# Unit test for constructor of class OneOf
def test_OneOf():
    test_object = OneOf(None, None)
    print("Test OneOf")
    print(test_object.errors)
    print(test_object.one_of)
    return True


# Generated at 2022-06-12 15:34:51.172245
# Unit test for constructor of class OneOf
def test_OneOf():
    # Instance creation
    expected_output = 'OneOf(one_of=[Any(), Any()], name="", metadata={})'
    test_instance = OneOf(one_of=[Any(), Any()])
    assert str(test_instance) == expected_output


# Generated at 2022-06-12 15:34:54.832749
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer
    my_field = OneOf([Integer()])
    assert my_field.validate(1) == 1
    assert my_field.validate(1.1) == 1.1
    assert my_field.validate('test') == 'test'


# Generated at 2022-06-12 15:34:55.965196
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.validate(1)

# Generated at 2022-06-12 15:34:57.577888
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with normal parameters
    oof = OneOf([])
    assert oof.one_of == []
    assert oof.description == ""
    assert oof.name == ""
    assert oof.default == NULL_VALUE



# Generated at 2022-06-12 15:35:04.889169
# Unit test for constructor of class OneOf
def test_OneOf():
	pass

# Generated at 2022-06-12 15:35:07.235446
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(help="Some help", error_messages={"never":"This never validates."})


# Generated at 2022-06-12 15:35:09.160247
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Any())
    assert field.negated is not None


# Generated at 2022-06-12 15:35:12.916615
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        new_NeverMatch = NeverMatch(allow_null=False)
        assert 1 == 2
    except:
        assert 1 == 1


# Generated at 2022-06-12 15:35:20.884757
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    def test_NeverMatch_init_01():
        a = NeverMatch()
        assert a.allow_null is False
        assert a.repr_cname() == "NeverMatch"

    def test_NeverMatch_validate_01():
        a = NeverMatch()
        with pytest.raises(a.validation_error) as excinfo:
            a.validate("abc")
        assert str(excinfo.value) == "This never validates."

    def test_NeverMatch_validate_02():
        a = NeverMatch(allow_null=True)
        with pytest.raises(a.validation_error) as excinfo:
            a.validate("abc")
        assert str(excinfo.value) == "This never validates."
        assert a.validate(None) == None


# Generated at 2022-06-12 15:35:24.638030
# Unit test for constructor of class AllOf
def test_AllOf():
    import unittest.mock as mock

    fieldList = [mock.MagicMock()] * 3
    f = AllOf(fieldList)

    assert f.all_of == fieldList
    assert f.is_optional()
    assert f.default == ""



# Generated at 2022-06-12 15:35:29.989723
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer, String
    field = AllOf([Integer(), String()])

    # Test a valid value
    result, error = field.validate_or_error("1")
    assert not error
    assert result == "1"

    # Test an invalid value
    result, error = field.validate_or_error(1.5)
    assert error
    assert error["type"] == "invalid_type"

# Generated at 2022-06-12 15:35:32.448576
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # initialize class object
    field = NeverMatch()
    # check if __init__() method runs correctly
    assert field.label == None
    assert field.description == "A field"
    assert field.allow_null == True


# Generated at 2022-06-12 15:35:37.224056
# Unit test for constructor of class Not
def test_Not():
    assert str(fields.Not(fields.String())) == "~String()"
    assert str(fields.Not(fields.String(required=True))) == "~String(required=True)"
    assert str(fields.Not(fields.String(default="foo"))) == "~String(default='foo')"
    assert str(fields.Not(fields.String(validators=[my_validator]))) == "~String(validators=[<function my_validator at 0x7f1d389b9a60>])"
    assert str(fields.Not(fields.String(error="Badness"))) == "~String(error='Badness')"



# Generated at 2022-06-12 15:35:42.360808
# Unit test for constructor of class AllOf
def test_AllOf():
    class SomeField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    allOf1 = AllOf([SomeField()])
    allOf2 = AllOf([SomeField()]*10)


# Generated at 2022-06-12 15:36:07.572282
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    expected = NeverMatch(name=None, description=None)
    actual = NeverMatch()
    assert expected.name == actual.name
    assert expected.description == actual.description
    assert expected.errors == actual.errors
    assert expected.validation_error == actual.validation_error


# Generated at 2022-06-12 15:36:10.443586
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(if_clause = Field(), then_clause = Field(), else_clause = Field())
    assert ite.if_clause is not None
    assert ite.then_clause is not None
    assert ite.else_clause is not None

# Generated at 2022-06-12 15:36:11.044314
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    pass

# Generated at 2022-06-12 15:36:12.565413
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Unit test for constructor of class IfThenElse
    #TODO
    pass


# Generated at 2022-06-12 15:36:14.729729
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Field('Field')]).__init__([Field('Field')]) == None
    assert OneOf([Field('Field')]).__init__() == None


# Generated at 2022-06-12 15:36:15.779962
# Unit test for constructor of class Not
def test_Not():
    assert Not(String(max_length=1)) is not None



# Generated at 2022-06-12 15:36:24.211873
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field_x = OneOf([Integer])
    assert field_x.validate(7) == 7
    assert field_x.validate(None) == None
    try:
        field_x.validate("foo")
        assert False
    except field_x.validation_error:
        pass

    field_y = OneOf([Integer, String])
    assert field_y.validate(7) == 7
    assert field_y.validate("foo") == "foo"
    try:
        field_y.validate(None)
        assert False
    except field_y.validation_error:
        pass



# Generated at 2022-06-12 15:36:32.241763
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class T(Field):
        def __init__(self):
            super().__init__()
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            assert False

    class T1(T):
        def __init__(self):
            super().__init__()
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            assert value == 1
            return 1

    class T2(T):
        def __init__(self):
            super().__init__()
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            assert value == 2
            return 2


# Generated at 2022-06-12 15:36:33.301166
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field


# Generated at 2022-06-12 15:36:34.861761
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    non_empty_string = NeverMatch()
    assert non_empty_string


# Generated at 2022-06-12 15:37:09.847931
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Check that allow_null cannot be changed
    try:
        test = NeverMatch()
    except:
        assert False
    try:
        test = NeverMatch(allow_null = True)
        assert False
    except:
        assert True


# Generated at 2022-06-12 15:37:12.245295
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = [Integer(),Float()]
    one_of_field = OneOf(one_of)
    assert one_of_field.one_of == one_of


# Generated at 2022-06-12 15:37:14.698492
# Unit test for constructor of class Not
def test_Not():
    error1 = "Must not match."
    # Test that not_type is the same as self.negated
    not_type1 = Not(Any(), message=error1)
    assert not_type1.negated == Any()


# Generated at 2022-06-12 15:37:15.444353
# Unit test for constructor of class Not
def test_Not():
    a = Not(None)


# Generated at 2022-06-12 15:37:16.284400
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()



# Generated at 2022-06-12 15:37:17.648886
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of = []) 

    assert type(field) == OneOf
    assert field.one_of == []

# Generated at 2022-06-12 15:37:18.879321
# Unit test for constructor of class Not
def test_Not():
    try:
        not_instance=Not(None)
    except AssertionError:
        assert True
    return

# Generated at 2022-06-12 15:37:19.891401
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True)


# Generated at 2022-06-12 15:37:20.491764
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-12 15:37:22.042943
# Unit test for constructor of class Not
def test_Not():
    i = Not(negated="string_value")
    assert i.negated == "string_value"