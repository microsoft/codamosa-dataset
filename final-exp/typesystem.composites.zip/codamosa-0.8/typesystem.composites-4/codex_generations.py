

# Generated at 2022-06-12 15:28:41.187507
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf( [Field()] )

    assert one_of.validate("hola") == "hola"

# Generated at 2022-06-12 15:28:46.572988
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class MyClass(): pass
    class MyField(Field):
        def validate(self, value, strict=False):
            if str(value).lower() == "example":
                return "Yay!"
            else:
                return "Nay!"

    f1 = MyField()
    f2 = MyField()
    f3 = MyField()
    ite = IfThenElse(f1, f2, f3)
    ite.validate("example") == "Yay!"
    ite.validate("EXAMPLE") == "Yay!"
    ite.validate("anything_else") == "Nay!"
    ite.validate(MyClass) == "Nay!"  # MyClass is not string

# Generated at 2022-06-12 15:28:49.574248
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(1,2,3,4,5).validate(1) == 2
    assert IfThenElse(1,2,3,4,5).validate(3) == 1


# Generated at 2022-06-12 15:28:52.352270
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x is not None


# Generated at 2022-06-12 15:28:54.666500
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}

# Generated at 2022-06-12 15:29:00.651148
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[Any()]).one_of == [Any()]
    assert OneOf(one_of=[Any()]).allow_null == False
    assert OneOf(one_of=[Any()], allow_null=True).allow_null == True
    assert OneOf(one_of=[Any()]).field_name == None
    assert OneOf(one_of=[Any()], field_name='field_name').field_name == 'field_name'
    assert OneOf(one_of=[Any()]).default == None
    assert OneOf(one_of=[Any()], default='default').default == 'default'


# Generated at 2022-06-12 15:29:03.192448
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    field = IfThenElse(TestField(), TestField(), TestField())
    value = "a"

    assert field.validate(value) == value


# Generated at 2022-06-12 15:29:10.255319
# Unit test for method validate of class Not
def test_Not_validate():
	from typesystem import String

	class A(Field):
		def validate(self, value, strict=False):
			super().validate(value, strict=strict)
			if value == "aa":
				return value
			else:
				raise self.validation_error("bb")

	negated = Not(A(), required=False)
	assert negated.validate("aa") == "aa"
	assert negated.validate("bb") == "bb"
	assert negated.validate("", required=True) is None
	assert negated.validate(None, required=True) is None

# Generated at 2022-06-12 15:29:12.894001
# Unit test for constructor of class AllOf
def test_AllOf():
    mbt = AllOf([AllOf([AllOf([Any()])])])
    assert type(mbt) == AllOf

# Generated at 2022-06-12 15:29:15.225515
# Unit test for constructor of class OneOf
def test_OneOf():
    oo = OneOf([1,2,3])
    assert isinstance(oo, OneOf)

# Generated at 2022-06-12 15:29:24.137879
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(then_clause=Any()).validate(1) == 1
    assert IfThenElse(then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Not(Boolean()), then_clause=Number(), else_clause=Boolean()).validate(1.5) == 1.5

# Generated at 2022-06-12 15:29:35.714051
# Unit test for method validate of class Not
def test_Not_validate():
    stringField = String()
    fileField = File()
    notField_1 = Not(negated = stringField)
    notField_2 = Not(negated = fileField)
    value_1 = 'I am a string.'
    value_2 = 'I am a string, but I am not a file.'
    value_3 = 'I am a string, but I am not a file.'
    value_4 = 'I am a string, but I am not a file.'
    error_1 = None
    error_2 = None
    error_3 = None
    error_4 = None
    result_1 = value_1
    result_2 = value_2
    result_3 = value_3
    result_4 = value_4
    assert(notField_1.validate(value_1) == result_1)
   

# Generated at 2022-06-12 15:29:41.238274
# Unit test for constructor of class AllOf
def test_AllOf():
    def param_AllOf(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
        assert "allow_null" not in kwargs
        super().__init__(**kwargs)
        self.all_of = all_of
    assert param_AllOf(None, None, **None) is None
test_AllOf()


# Generated at 2022-06-12 15:29:47.541240
# Unit test for constructor of class AllOf
def test_AllOf():
    i = [Field,Field,Field]
    k = {'key1': 'value1','key2': 'value2','key3': 'value3','key4': 'value4'}
    try:
        field = AllOf(i)
    except Exception as e:
        assert ('allow_null' not in k)
    assert field.__init__(i,k) == None
    field.all_of = i
    assert 'all_of' in field.__dict__
    assert field.all_of == i


# Generated at 2022-06-12 15:29:56.822884
# Unit test for method validate of class Not
def test_Not_validate():
    assert str(Not(Byte).validate(None)) == "Must not match."
    assert str(Not(Byte).validate(1))  == "Must not match."
    assert str(Not(Byte).validate(2))  == "Must not match."
    assert str(Not(Byte).validate(3))  == "Must not match."
    assert str(Not(Byte).validate(4))  == "Must not match."
    assert str(Not(Byte).validate(5))  == "Must not match."
    assert str(Not(Byte).validate(6))  == "Must not match."
    assert str(Not(Byte).validate(255))  == "Must not match."
    assert str(Not(Byte).validate(257))  == "Must not match."


# Generated at 2022-06-12 15:30:01.188621
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Integer())

    # Fails
    foo = "foo"
    try:
        field.validate(foo)
    except Exception as e:
        assert str(e) == "Must not match."


# Generated at 2022-06-12 15:30:06.191629
# Unit test for constructor of class OneOf
def test_OneOf():
    def test():
        OneOf(one_of=[1])

    from typesystem.exceptions import ValidationError

    try:
        test()
    except ValidationError as err:
        assert err.messages == {'$': ['Must be a list with at least one item.']}
        assert err.code == 'type_error'
    else:
        assert False



# Generated at 2022-06-12 15:30:13.196263
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test cases for method validate of the class IfThenElse
    """
    #then_clause and else_clause are not provided
    test = IfThenElse(if_clause=String())
    assert test.validate("test") == "test"
    test = IfThenElse(if_clause=String(), then_clause=String())
    assert test.validate("test") == "test"
    test = IfThenElse(if_clause=String(), else_clause=String())
    assert test.validate("test") == "test"
    test = IfThenElse(if_clause=String(), then_clause=String(), else_clause=String())
    assert test.validate("test") == "test"

# Generated at 2022-06-12 15:30:17.929375
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem
    from typesystem import fields, types
    class MySchema(typesystem.Schema):
        """A schema for testing."""
        all_of = fields.AllOf([types.Number(), types.String()])

    v = MySchema()
    assert isinstance(v, typesystem.Schema)

# Generated at 2022-06-12 15:30:25.499887
# Unit test for method validate of class Not
def test_Not_validate():
    # CASE1: value is not equal to negated
    # Nothing happens
    negated_field = Field()
    field = Not(negated_field)
    assert field.validate("a") == "a"

    # CASE2: value is equal to negated
    # ValidationError raised
    negated_field = Field(required=True, allow_null=True)
    field = Not(negated_field)
    try:
        field.validate(None)
    except TypeSystemError as e:
        assert getattr(e, "code") == "negated"

# Generated at 2022-06-12 15:30:30.429026
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        NeverMatch(
            allow_null=True
        )

# Generated at 2022-06-12 15:30:32.353554
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([1,2,3])
    assert a.one_of == [1,2,3]


# Generated at 2022-06-12 15:30:36.504100
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """Unit test for method validate of class IfThenElse"""
    required_field = IfThenElse(if_clause=Field())

    assert required_field.validate("") == ""

    try:
        required_field.validate(None)
        assert False
    except ValidationError as e:
        assert str(e) == 'This field is required.'

# Generated at 2022-06-12 15:30:46.415070
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    number = Field(typing.Number)
    string = Field(typing.String)
    if_clause = Field(typing.String)
    then_clause = Field(typing.Number)
    else_clause = Field(typing.String)

    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate('1') == '1'
    assert if_then_else.validate(1).isInteger() == True
    assert if_then_else.validate('1').isString() == True

    if_then_else = IfThenElse(if_clause, else_clause)

# Generated at 2022-06-12 15:30:52.010951
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Int()
    then_clause = Str()
    else_clause = Float()

    newIfThenElse = IfThenElse(if_clause, then_clause, else_clause)

    assert type(newIfThenElse.if_clause) == Int
    assert type(newIfThenElse.then_clause) == Str
    assert type(newIfThenElse.else_clause) == Float


# Generated at 2022-06-12 15:30:53.467195
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    assert n.validate(1) == 1

    error = n.validate_or_error(1)
    assert error
    assert error.code == "negated"

# Generated at 2022-06-12 15:30:56.035881
# Unit test for method validate of class Not
def test_Not_validate():
    value1 = 1
    value2 = 0
    not_field = Not(Any())
    assert not_field.validate(value1) is not None
    assert not_field.validate(value2) is not None

# Generated at 2022-06-12 15:31:01.018445
# Unit test for constructor of class AllOf
def test_AllOf():
    # Simple AllOf test with 2 fields
    f1 = String()
    f2 = String()

    f3 = AllOf([f1, f2])
    assert f3.all_of == [f1, f2]

    # AllOf test with an empty list
    f4 = AllOf([])
    assert f4.all_of == []

    # AllOf test with a single field
    f5 = AllOf([f1])
    assert f5.all_of == [f1]



# Generated at 2022-06-12 15:31:11.664834
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String
    from typesystem.fields import Boolean
    class TestIfThenElse(IfThenElse):
        def __init__(self, if_clause: Field, then_clause: Field = None, else_clause: Field = None, **kwargs: typing.Any) -> None:
            super().__init__(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause, **kwargs)

    string = String()
    boolean = Boolean()
    test = TestIfThenElse(if_clause=boolean, then_clause=string, else_clause=string)
    if_value = True
    then_value = 'then string'
    else_value = 'else string'

# Generated at 2022-06-12 15:31:12.164194
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass

# Generated at 2022-06-12 15:31:17.584201
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse(
        if_clause=String(),
        then_clause=String()
    )
    # 1
    result = a.validate("a")
    assert result == "a"

# Generated at 2022-06-12 15:31:22.812249
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x_test_IfThenElse_validate = IfThenElse(
        if_clause = Int(),
        then_clause = Int(),
        else_clause = Int()
    )
    assert x_test_IfThenElse_validate.validate(1) == 1

    # set strict to True
    assert x_test_IfThenElse_validate.validate(1, strict=True) == 1


# Generated at 2022-06-12 15:31:25.767425
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Schema
    from typesystem.fields import String

    class CustomSchema(Schema):
        not_string = Not(String)

    schema = CustomSchema()
    schema.validate({"not_string": 0})
    schema.validate({"not_string": "0"})

# Generated at 2022-06-12 15:31:30.270550
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_empty(it: Field):
        assert it.validate(None) is None
        assert it.validate(0) == 0
        assert it.validate(3) == 3
        assert it.validate("") == ""
        assert it.validate("Hello") == "Hello"

    test_empty(IfThenElse(Any()))
    test_empty(IfThenElse(Any(), Integer()))
    test_empty(IfThenElse(Integer(), Integer()))
    test_empty(IfThenElse(Integer(), Integer(), Integer()))
    test_empty(IfThenElse(Integer(), Integer(), String()))

    test_empty(IfThenElse(Integer(gte=2), Integer()))
    test_empty(IfThenElse(Integer(gte=2), None, Integer()))


# Generated at 2022-06-12 15:31:33.320267
# Unit test for method validate of class Not
def test_Not_validate():
    result = Not(not_negated=Union(types=[String(), Integer()])).validate(value=0)
    assert result is not None


# Generated at 2022-06-12 15:31:42.024938
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.errors import ValidationError
    from typesystem import Field
    import pytest
    input_value = ["This is a string"];
    if_clause = String();
    then_clause = String();
    else_clause = String();
    my_if_then_else = IfThenElse(if_clause,then_clause,else_clause);
    act_result = my_if_then_else.validate(input_value);
    exp_result = input_value
    assert act_result == exp_result;
    # Case: This is a valid input
    input_value = "This is a string";
    if_clause = String();
    then_clause = String();
    else_clause = String();
    my_if_then_else

# Generated at 2022-06-12 15:31:43.312697
# Unit test for method validate of class Not
def test_Not_validate():
    not_validator = Not(Any())
    not_validator.validate(None)


# Generated at 2022-06-12 15:31:52.457685
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.typing import Number
    from typesystem import fields
    # Method validate of class IfThenElse
    
    # Case 1: IfThenElse(if_clause=Number(), then_clause=Number()).validate(1)
    if_clause = Number()
    then_clause = Number()
    else_clause = None
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    result1 = if_then_else.validate(1)
    assert result1 == 1
    
    # Case 2: IfThenElse(if_clause=Number(), then_clause=Number(), else_clause=Number()).validate("hello")
    if_clause = Number()
    then_clause = Number()
    else_clause = Number

# Generated at 2022-06-12 15:31:58.416392
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IfThenElseTest:
        def test_if(self, value: typing.Any) -> None:
            _, error = self.if_clause.validate_or_error(value, strict=False)
            assert not error

    class IfThenElseTest2:
        def test_if(self, value: typing.Any) -> None:
            _, error = self.if_clause.validate_or_error(value, strict=False)
            assert error

# Generated at 2022-06-12 15:32:06.697940
# Unit test for method validate of class Not
def test_Not_validate():
    def test_body(data, expected):
        result = Not(Any()).validate(data)
        assert result == expected

    test_body(1,1)
    test_body(1.23,1.23)
    test_body(True,True)
    test_body('a', 'a')
    test_body(b'abc', b'abc')
    test_body([1,2,3], [1,2,3])
    #test_body((1,2,3), (1,2,3))
    test_body({'a':1, 'b':2}, {'a':1, 'b':2})
    test_body(None, None)
    

# Generated at 2022-06-12 15:32:09.372328
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf(None)


# Generated at 2022-06-12 15:32:17.477159
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String
    from typesystem.fields import IfThenElse
    from typesystem.exceptions import ValidationError

    field = IfThenElse(if_clause=String(min_length=5), then_clause=String(max_length=2))

    try:
        field.validate("123")
    except ValidationError:
        assert True
    else:
        assert False # pragma: no cover

    try:
        field.validate("12345")
    except ValidationError:
        assert True
    else:
        assert False # pragma: no cover

# Generated at 2022-06-12 15:32:19.813268
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    field.validate(value=None, strict=False)

# Generated at 2022-06-12 15:32:23.853096
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	class A(NeverMatch):
		def __init__(self, **kwargs):
			super().__init__(**kwargs)

	a = A(name="dfs")
	print("class A(NeverMatch): ...")
	print("a = A(name='dfs')")



# Generated at 2022-06-12 15:32:24.754005
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(Field(), Field(), Field())

# Generated at 2022-06-12 15:32:26.488449
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[Any(), Any()])
    assert field.one_of == [Any(), Any()]


# Generated at 2022-06-12 15:32:35.619504
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    try:
        assert IfThenElse(if_clause= Any(),
              then_clause= [1, 2, 30],
              else_clause= [2, 3]).validate([1, 2, 30]) == [1, 2, 30]
        assert IfThenElse(if_clause= Any(),
              then_clause= [1, 2, 30],
              else_clause= [2, 3]).validate([2, 3]) == [2, 3]
    except:
        print("test_IfThenElse_validate::Unit test for method validate of class IfThenElse failed")

# Generated at 2022-06-12 15:32:36.730232
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print(NeverMatch())


# Generated at 2022-06-12 15:32:40.088906
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem
    test_value = 22
    child = typesystem.Integer(max_value=10)
    not_field = Not(negated=child)
    not_validated, not_error = not_field.validate_or_error(test_value)
    assert test_value == not_validated


# Generated at 2022-06-12 15:32:43.208713
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(String())
    assert f.validate('abc') is None
    assert f.errors['negated'] == 'Must not match.'

# Generated at 2022-06-12 15:32:45.773975
# Unit test for constructor of class AllOf
def test_AllOf():
    class Test(Field):
        pass
    test = Test()
    assert isinstance(AllOf([test]), Field)

# Generated at 2022-06-12 15:32:49.944245
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String
    if_clause = String(min_length=2)
    then_clause = String(max_length=3)
    else_clause = String(max_length=1)
    ite = IfThenElse(if_clause, then_clause, else_clause)

    assert ite.validate("ab") == "ab"
    with pytest.raises(ite.validation_error):
        ite.validate("abcd")
    assert ite.validate("a") == "a"
    with pytest.raises(ite.validation_error):
        ite.validate("abc")



# Generated at 2022-06-12 15:32:53.397572
# Unit test for constructor of class OneOf
def test_OneOf():
    from .typing import Number, String

    T = OneOf([Number(), String()])
    assert T.validate(1) == 1
    assert T.validate("1") == "1"

# Generated at 2022-06-12 15:32:57.270253
# Unit test for method validate of class Not
def test_Not_validate():
	field_type=Not(Boolean())
	assert field_type.validate(True)
	try:
		field_type.validate(False)
		assert False
	except FieldError:
		assert True


# Generated at 2022-06-12 15:33:06.405993
# Unit test for constructor of class OneOf
def test_OneOf():
    # OneOf can be called with no arguments
    try:
        OneOf()
    except TypeError:
        # For some reason, we cannot call this without any arguments
        assert (
            False
        ), "FAIL: OneOf cannot be called with no arguments, and it is not clear why"
    except:
        # This is the wrong error
        assert (
            False
        ), "FAIL: OneOf cannot be called with no arguments, but raised the wrong error"
    else:
        # This is the correct case
        assert (
            True
        ), "PASS: OneOf can be called with no arguments, and no error is raised"
    # OneOf can be called with two arguments, one is a list of fields, and the other is a dictionary
    f1 = Field()
    f2 = Field()
    f3 = Field()
    list

# Generated at 2022-06-12 15:33:08.253120
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(
        one_of=[Int(),Str()]
    )
    assert one_of != None

# Generated at 2022-06-12 15:33:15.982251
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = 1
    b = "a"
    c = [1, 2, 3]
    if_clause = IfThenElse(Any())
    then_clause = IfThenElse(Any(), then_clause=List(items=Integer()))
    else_clause = IfThenElse(Any(), else_clause=Integer())
    assert if_clause.validate(a) == a
    assert then_clause.validate(b) == b
    assert else_clause.validate(c) == c

# Generated at 2022-06-12 15:33:17.350870
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field is not None


# Generated at 2022-06-12 15:33:26.328377
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Person:
        name: typing.Optional[str] = None
        age: int = None

    class Argument:
        name: str = None
        age: int = None
        adult: bool = None

    class Adult(IfThenElse):
        def __init__(self, **kwargs):
            if_clause = Field()
            then_clause = Field()
            super().__init__(if_clause=if_clause, then_clause=then_clause, **kwargs)

    a = Argument()
    p = Person()
    a.name = p.name
    a.age = p.age
    a.adult = p.age > 18
    to_from_python = Adult.from_python(a)
    assert to_from_python.validate(a) == a

# Generated at 2022-06-12 15:33:30.688886
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    json = (
        '{"if_clause": {"type": "number"}, "then_clause": {'
        '"type": "string"}, "else_clause": {"type": "integer"}}'
    )
    field = IfThenElse.from_json(json)

    print(field)
    assert field.if_clause.__class__.__name__ == "Number"
    assert field.then_clause.__class__.__name__ == "String"
    assert field.else_clause.__class__.__name__ == "Integer"

# Generated at 2022-06-12 15:33:35.607902
# Unit test for method validate of class Not
def test_Not_validate():
    test_field = Not(negated=Field(max_length=5))
    assert test_field.validate('String') == 'String'
    assert test_field.validate('Too long String') == 'Too long String'


# Generated at 2022-06-12 15:33:41.754256
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate("foo") == "foo"
    with pytest.raises(not_field.validation_error):
        not_field.validate(None)

    # Test validate method on fields without validation error
    not_field = Not(Any())
    assert not_field.validate("foo") == "foo"
    not_field = Not(Any(required=True))
    with pytest.raises(not_field.validation_error):
        not_field.validate("foo")



# Generated at 2022-06-12 15:33:43.672287
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x.errors == {"never": "This never validates."}

# Generated at 2022-06-12 15:33:53.765990
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A:
        def __init__(self, value):
            self.value = value

    def if_clause(value):
        if (value.value == 1):
            return True
        else:
            return False

    def then_clause(value):
        if (value.value == 1):
            return True
        else:
            return False

    def else_clause(value):
        if (value.value == 2):
            return True
        else:
            return False

    def valid_value(value):
        if (value.value == 1):
            return True
        elif (value.value == 2):
            return False
        else:
            return None

    test_field = IfThenElse(
        if_clause,
        then_clause,
        else_clause
    )

   

# Generated at 2022-06-12 15:33:57.138277
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    item = IfThenElse(if_clause=IfThenElse(then_clause=String()))
    item.validate(None)

    with pytest.raises(ValidationError) as exc:
        item.validate(12)
    assert "expected a string" in str(exc.value)

# Generated at 2022-06-12 15:34:03.589757
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n.errors == {"never": "This never validates."}
    n.validate('0123')
    n2 = NeverMatch(required=False)
    assert n2.errors == {"never": "This never validates."}
    n2.validate(None)
    n3 = NeverMatch(formats=["never"])
    assert n3.errors == {"never": "This never validates."}
    n3.validate(None)


# Generated at 2022-06-12 15:34:09.476481
# Unit test for method validate of class Not
def test_Not_validate():
    # Unit test for method validate of class Not

    def assert_no_error(value):
        # function to assert that value doesn't lead to error
        field = Not(Integer())
        field.validate(value)

    def assert_with_error(value):
        # function to assert that value leads to error
        field = Not(Integer())
        with pytest.raises(typesystem.exceptions.ValidationError):
            field.validate(value)

    assert_with_error(123)
    assert_no_error("123")
    assert_no_error(None)

# Generated at 2022-06-12 15:34:14.088854
# Unit test for constructor of class OneOf
def test_OneOf():
    # these 2 subclasses are defined only for testing purposes
    class Boolean(Field):
        pass

    class Text(Field):
        pass

    text = Text()
    boolean = Boolean()

    bool_or_text = OneOf([text, boolean])
    assert bool_or_text.one_of == [text, boolean]

    # validates any text
    bool_or_text.validate("hello world")

    # validates only true
    bool_or_text.validate(True)

    # does not validate anything else
    with pytest.raises(FieldError):
        bool_or_text.validate(False)
        bool_or_text.validate(1)

    # matches exactly one of the types; raises error otherwise
    # so, helps catch bugs

# Generated at 2022-06-12 15:34:18.308424
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any(), error_messages={'negated': "Must not match."})
    with pytest.raises(ValidationError) as e:
        n.validate(1)
    assert e.value.get_code() == 'negated'
    assert e.value.get_message() == 'Must not match.'


# Generated at 2022-06-12 15:34:24.053521
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Unit test for method validate of class Not
    """
    field = Not(negated = Integer(maximum = 4, minimum = 3))
    field.validate(5)
    assert hasattr(field, "allow_null")
    assert hasattr(field, "metadata")
    assert hasattr(field, "validation_error")


# Generated at 2022-06-12 15:34:33.014834
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}
    assert field.error_messages == {"never": "This never validates."}


# Generated at 2022-06-12 15:34:36.441255
# Unit test for method validate of class Not
def test_Not_validate():
    class Foo(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    field = Not(Foo())
    assert field.validate(True)

# Generated at 2022-06-12 15:34:38.297529
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    n.validate(3) # it works; it shouldn't raise any exception

# Generated at 2022-06-12 15:34:39.979811
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = IfThenElse(Any())
    then_clause = IfThenElse(Any(), Any())
    else_clause = IfThenElse(Any(),Any(),Int())
    assert Else_clause.validate(1) == 1

# Generated at 2022-06-12 15:34:41.988205
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse("test_clause").validate("test_clause") == "test_clause"

# Generated at 2022-06-12 15:34:45.195948
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Tests method validate of class Not. It tests if the validator 'Not' is working correctly.
    """
    validator = Not(Number())
    assert validator.validate("1") == "1"
    try:
        validator.validate("not_number")
        assert 0
    except ValueError:
        pass


# Generated at 2022-06-12 15:34:49.801143
# Unit test for method validate of class Not
def test_Not_validate():

    not_field = Not(negated=Field())

    assert not_field.validate("do not raise error") == "do not raise error"

    try:
        not_field.validate("raise error")
        assert False # should not reach this line
    except Field.validation_error:
        pass

# Generated at 2022-06-12 15:34:54.205507
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Schema
    class NotTest(Schema):
        x = Not(String())
    sch = NotTest(strict=True)
    assert sch.is_valid({"x": {"a"}}) == []
    assert sch.is_valid({"x": "a"}) == ["Validation error in x; Must not match."]

# Generated at 2022-06-12 15:34:56.079952
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.__dict__ == {'errors': {'never': 'This never validates.'}}


# Generated at 2022-06-12 15:34:58.008115
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(AllOf([Boolean(), Text()]))
    validate_ThenOrElse(field, "if_clause")


# Generated at 2022-06-12 15:35:07.162027
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Type
    from typesystem.types import NumberType
    from typesystem import ValidationError

    # Test case of if_clause matches
    try:
        t = Type(name='test', type=IfThenElse(
            if_clause=NumberType(),
            then_clause=NumberType(gt=1)
        ))
        t.validate(2)
    except:
        raise AssertionError('IfThenElse.validate raised Exception '
                             'unexpectedly!')

    # Test case of else_clause matches

# Generated at 2022-06-12 15:35:17.308366
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_if(val):
        return type(val) == int and val > 3
    if_clause = IfThenElse(
        Field(validators=[test_if])
    )
    then_clause = Field(validators=[lambda x: type(x) == type("abc")])
    else_clause = Field(validators=[lambda x: type(x) == type(True)])
    field = IfThenElse(if_clause,then_clause, else_clause)
    assert field.validate("abc")
    assert field.validate(5)
    assert not field.validate(2)
    assert field.validate(True)

# Generated at 2022-06-12 15:35:18.152278
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never = NeverMatch()


# Generated at 2022-06-12 15:35:22.980449
# Unit test for method validate of class Not
def test_Not_validate():
    """
    test the method validate of class Not
    :return:
    """
    from typesystem.types import String, Integer
    from typesystem import error_messages
    negated = Integer()
    not_a = Not(negated)
    value = 'a'
    not_a.validate(value)
    assert True


# Generated at 2022-06-12 15:35:24.091267
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field


# Generated at 2022-06-12 15:35:32.120341
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.types import ErrorList
    from typesystem import types
    from typesystem.exceptions import ValidationError
    from typesystem.fields.errors import ValidationError as ValidationErrorField
    from typesystem import fields
    field = Not(String())
    assert field.validate('Hello') == 'Hello'
    assert field.validate('1') == '1'
    e = types.ErrorList()
    try:
        field.validate('', error_list = e)
    except ValidationError:
        pass
    assert e.as_data() == {'type': 'not', 'code': 'negated', 'key': ''}


# Generated at 2022-06-12 15:35:41.741426
# Unit test for method validate of class Not
def test_Not_validate():
    content_type = 'application/json'
    headers = {'content-type': 'application/json'}
    method = 'POST'
    status = '200 OK'
    text = '{"name": "John", "email": "john@example.com", "telephone": "5556667777"}'
    url = 'https://api.petstore.swagger.io/v2/pet'
    data = {"name": "John", "email": "john@example.com", "telephone": "5556667777"}
    # TODO: Create the JSON response

# Generated at 2022-06-12 15:35:43.637765
# Unit test for method validate of class Not
def test_Not_validate():
    val = "1234"
    field = Not(Any(max_length=3))
    assert field.validate(val) == "1234"


# Generated at 2022-06-12 15:35:44.422817
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # TODO
    pass


# Generated at 2022-06-12 15:35:53.515004
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Person:
        def __init__(self):
            self.age = 20
            self.salary = 20000
            self.name = "name"
            self.sex = "male"

    person = Person()

    # case 1: if_clause is true
    ite_field = IfThenElse(
        if_clause=Field.validate_positive, then_clause=Field.validate_int
    )
    ite_field.validate(person.age)

    # case 2: if_clause is false
    try:
        ite_field.validate(person.name)
    except FieldError:
        print("if_clause is false, the exception is raised")
    else:
        print("if_clause is false, the exception is not raised")

    # case 3: if_

# Generated at 2022-06-12 15:35:59.808988
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause=Number()
    then_clause=Number()
    else_clause=String()

    ite = IfThenElse(if_clause, then_clause, else_clause)

    assert ite.validate(1.1) == 1.1
    assert ite.validate("text") == "text"

# Generated at 2022-06-12 15:36:07.648256
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == 1:
                return value
    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == 2:
                return value
    class C(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == 3:
                return value
    x = IfThenElse(if_clause=A(), then_clause=B(), else_clause=C())
    assert x.validate(2) == 2


# Generated at 2022-06-12 15:36:08.850398
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=Field()).validate("") == ""

# Generated at 2022-06-12 15:36:13.176229
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(Boolean(), Number(), String(), optional=True)
    value = ite.validate(5)
    assert value == 5
    value = ite.validate(True)
    assert value == True
    value = ite.validate(False)
    assert value == False
    value = ite.validate(None)
    assert value == None


# Generated at 2022-06-12 15:36:16.107794
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate("irrelevant")

# Generated at 2022-06-12 15:36:18.138562
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(Any(), Any(), None, required=True)
    assert ite.validate(None) == None
    assert ite.validate(1) == 1


# Generated at 2022-06-12 15:36:23.126753
# Unit test for method validate of class Not
def test_Not_validate():
    # creation of input parameters
    args = {}
    kwargs = {
        "negated": Not
    }
    # creation of expected output
    expected_output = None

    # creation of object to test
    obj = Not(**kwargs)

    # act
    actual_output = obj.validate(*args)
    # assert
    assert actual_output == expected_output


# Generated at 2022-06-12 15:36:24.650601
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Field(db_field="name"))
    assert not_field.validate("not name") == "not name"
    

# Generated at 2022-06-12 15:36:27.213140
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Field(name="title"))
    not_field.validate("foobar")


# Generated at 2022-06-12 15:36:28.509270
# Unit test for method validate of class Not
def test_Not_validate():
    MyField = Not(Integer())
    assert isinstance(MyField(value=42), int)

# Generated at 2022-06-12 15:36:31.994218
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch()

# Generated at 2022-06-12 15:36:32.787233
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(label=None).label is None


# Generated at 2022-06-12 15:36:33.754616
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:36:35.034771
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert 1 in [1,2,3]

# Generated at 2022-06-12 15:36:37.539036
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:36:41.294872
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field(format="%Y-%m-%d"))
    field.validate("0001-01-01")
    try:
        field.validate("2018-01-01")
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:36:44.755983
# Unit test for method validate of class Not
def test_Not_validate():
    valid = Not(negated=String())
    assert valid.validate("a") is None
    assert valid.validate({"a":"b"}) is None
    assert valid.validate(5) is None

# Generated at 2022-06-12 15:36:49.427424
# Unit test for method validate of class Not
def test_Not_validate():
    field1 = Field()
    field2 = Not(field1)
    field2.validate("a")
    with pytest.raises(ValueError):
        value_error = ValueError('Must not match.')
        field2.validate("b")


# Generated at 2022-06-12 15:36:54.326494
# Unit test for method validate of class Not
def test_Not_validate():
    nested = {"a": {"b": {"c": "test"}}}
    dict_field = Dict({
        "a": Dict({
            "b": Dict({
                "c": String(max_length=4),
            }),
        }),
    })
    not_field = Not(dict_field)
    try:
        not_field.validate(nested)
    except ValidationError:
        pytest.fail("unexpected ValidationError")
    assert True

# Generated at 2022-06-12 15:36:58.996830
# Unit test for method validate of class Not
def test_Not_validate():
    # test that validate with a value should return the same value
    n = Not(Any())
    assert n.validate(1) == 1
    assert n.validate("hello") == "hello"
    assert n.validate(None) is None
    assert n.validate([]) == []
    assert n.validate(True) is True
    assert n.validate(False) is False


# Generated at 2022-06-12 15:37:05.388385
# Unit test for method validate of class Not
def test_Not_validate():
    pass

# Generated at 2022-06-12 15:37:06.835619
# Unit test for method validate of class Not
def test_Not_validate():
    one = Not(Field())
    with pytest.raises(Field.validation_error):
        one.validate(None)


# Generated at 2022-06-12 15:37:10.165356
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Boolean
    from .typesystem import ValidationError
    integer = Not(Boolean())
    error_msg = "Must not match."
    try:
        integer.validate(1)
    except ValidationError as e:
        assert e.messages["negated"] == error_msg


# Generated at 2022-06-12 15:37:14.137076
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(int)
    assert field.validate(3.14) == 3.14
    assert field.validate(True) == True
    assert field.validate('abc') == 'abc'
    try:
        field.validate(1)
    except Exception as err:
        assert str(err) == 'Must not match.'
    else:
        assert False


# Generated at 2022-06-12 15:37:15.966903
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    try:
        assert n.validate(1)
    except AssertionError:
        return
    raise AssertionError


# Generated at 2022-06-12 15:37:20.468627
# Unit test for method validate of class Not
def test_Not_validate():
    instance = None
    assert instance.validate(value=None, strict=None) == value
    assert instance.validate(value=None, strict=None) == value
    assert instance.validate(value=None, strict=None) == value
    assert instance.validate(value=None, strict=None) == value
    assert instance.validate(value=None, strict=None) == value
    assert instance.validate(value=None, strict=None) == value
    assert instance.validate(value=None, strict=None) == value
    assert instance.validate(value=None, strict=None) == value



# Generated at 2022-06-12 15:37:21.937472
# Unit test for method validate of class Not
def test_Not_validate():
    N = Not(String())
    N.validate("OK")
    try:
        N.validate("ERROR")
    except N.validation_error:
        pass


# Generated at 2022-06-12 15:37:24.208554
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import String, Integer
    not_string = Not(negated = String())
    assert not_string.validate("type") is None
    assert not_string.validate("") == ""
    assert not_string.validate("type").errors == {"negated" : "Must not match."}
    assert not_string.validate("").errors == {"negated" : "Must not match."}


# Generated at 2022-06-12 15:37:26.813005
# Unit test for method validate of class Not
def test_Not_validate():
    # check the not match value
    not_match = Not(String(min_length=1))
    input = "aaa"
    result = not_match.validate(input, strict=False)
    assert result==input


# Generated at 2022-06-12 15:37:30.928672
# Unit test for method validate of class Not
def test_Not_validate():
    value = Not('this is a sample')
    error = value.validate(value.errors['negated'])
    if error == None:
        print("No error: Not match")
    else:
        print(error)


# Generated at 2022-06-12 15:37:44.936449
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_field = NeverMatch()

# Generated at 2022-06-12 15:37:46.226507
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    ne = NeverMatch()
    # test whether ne is a Field
    assert isinstance(ne, Field) == True


# Generated at 2022-06-12 15:37:47.836219
# Unit test for method validate of class Not
def test_Not_validate():
    # Case 1 : negated field is a never match
    field = Not(NeverMatch())
    value = "test"
    assert field.validate(value) == "test"


# Generated at 2022-06-12 15:37:48.607798
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(allow_null=False)


# Generated at 2022-06-12 15:37:49.907342
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(1)
    not_field.validate(None)


# Generated at 2022-06-12 15:37:50.357036
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()

# Generated at 2022-06-12 15:37:51.051382
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
   t= NeverMatch()
   assert t != None


# Generated at 2022-06-12 15:37:52.425636
# Unit test for method validate of class Not
def test_Not_validate():
    num = 42
    type = Not(String())
    try:
        type.validate(num)
        assert False
    except Exception as exp:
        assert str(exp) == "Must not match."

# Generated at 2022-06-12 15:38:02.245306
# Unit test for method validate of class Not
def test_Not_validate():
    # Unit test for method validate of class Not
    menor = Not(Integer(), gte=19)
    assert menor.validate(18) == 18

    # Test if the value is null
    menor_null = Not(Integer(), allow_null=True, gte=19)
    assert menor_null.validate(None) is None

    # Test if the value is null when allow_null is False is Nullable
    with pytest.raises(ValidationError) as exc:
        menor = Not(Integer(), allow_null=False, gte=19)
        menor.validate(None)
    assert exc.value.message == "null"

# Test when the negated field is valid

# Generated at 2022-06-12 15:38:03.478258
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    print(field)


# Generated at 2022-06-12 15:38:16.361074
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print('Executing NeverMatch constructor')
    NeverMatch()

# Generated at 2022-06-12 15:38:17.134890
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-12 15:38:17.885249
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    instance = NeverMatch()


# Generated at 2022-06-12 15:38:19.603804
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(name="test_NeverMatch")
    assert field.name == "test_NeverMatch"


# Generated at 2022-06-12 15:38:21.991529
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem.base import String
    assert NeverMatch(String()).allow_null is True
    assert NeverMatch(String(), allow_null=False).allow_null is False
    assert NeverMatch(String(), allow_null=True).allow_null is True


# Generated at 2022-06-12 15:38:23.454981
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Arrange
    field = NeverMatch()

    # Act
    value = field.validate("None")

    # Assert
    assert value == "None"

# Generated at 2022-06-12 15:38:24.064709
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()


# Generated at 2022-06-12 15:38:26.054222
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    assert f.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:38:28.574292
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n.allow_null == False
    assert n.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:38:31.215308
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a=NeverMatch()
    assert_equals(a.errors, {"never": "This never validates."})
