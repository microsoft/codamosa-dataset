

# Generated at 2022-06-12 15:28:42.601951
# Unit test for method validate of class Not
def test_Not_validate():
    # Given
    field = Not(AllOf([Any(), Any()]))
    value = None
    strict = False
    # When
    result = field.validate(value, strict)
    # Then
    assert isinstance(result, type(value))


# Generated at 2022-06-12 15:28:52.591167
# Unit test for method validate of class Not
def test_Not_validate():
    # A schema targeted for the type Int and allowing null values
    Field = Not(Int(allow_null=True), allow_null=True)
    assert Field.validate(None) is None
    assert Field.validate(1) == 1
    assert Field.validate(1.0) == 1.0
    assert Field.validate("1") == "1"
    assert Field.validate(True) == True
    assert Field.validate(False) == False
    assert Field.validate(3.5) == 3.5
    # The value is not a Int or a null value, so it is not valid
    try:
        Field.validate("abc")
    except AssertionError as e:
        assert "Must not match" in str(e)


# Generated at 2022-06-12 15:28:53.514556
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    return None



# Generated at 2022-06-12 15:28:56.627056
# Unit test for method validate of class Not
def test_Not_validate():
    a = Not(Any(min_length=2))
    with pytest.raises(ValueError) as excinfo:
        b = a.validate('1')
    assert excinfo.value.args[0] == 'Must not match.'

# Generated at 2022-06-12 15:29:03.136530
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Any()).validate(5) == 5
    assert IfThenElse(Any(), then_clause=Integer()).validate(5) == 5
    assert IfThenElse(Any(), then_clause=Integer()).validate(5.0) == 5
    assert IfThenElse(Any(), then_clause=String()).validate(5.0) == '5.0'
    assert IfThenElse(NeverMatch(), else_clause=Integer()).validate(5.0) == 5
    assert IfThenElse(NeverMatch(), else_clause=String()).validate(5.0) == '5.0'
    assert IfThenElse(NeverMatch(), then_clause=Integer(), else_clause=String()).validate(5.0) == '5.0'

# Generated at 2022-06-12 15:29:06.043681
# Unit test for constructor of class OneOf
def test_OneOf():
    # one_of = Field
    # **kwargs = {}
    f1 = Field()
    f2 = Field()
    f3 = Field()
    t = OneOf([f1, f2, f3])
    assert t != None

# Generated at 2022-06-12 15:29:08.636387
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(None, None, None, nullable=True)
    field.nullable = True
    assert field.validate("test") == "test"
    assert field.validate(None) is None

# Generated at 2022-06-12 15:29:11.490630
# Unit test for method validate of class Not
def test_Not_validate():
    not1 = Not(Type(str))
    assert not1.validate("hi") is None
    assert not1.validate(3) == 3

# Generated at 2022-06-12 15:29:18.712806
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    if_clause.validate = lambda x: True
    then_clause.validate = lambda x: True
    else_clause = Field()
    else_clause.validate = lambda x: False
    a = IfThenElse(if_clause, then_clause, else_clause)
    assert a.validate("a") == True

# Generated at 2022-06-12 15:29:23.619253
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Testing method validate of class Not
    """
    negatedField = Field()
    field = Not(negatedField)
    negatedField.validate = lambda value, strict=False : True if value == 42 else False
    assert True == field.validate(42)
    assert False == field.validate(23)

# Unit tests for method validate of class IfThenElse

# Generated at 2022-06-12 15:29:27.862214
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)



# Generated at 2022-06-12 15:29:29.792435
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([]).validate(1, strict=False) == 1


# Generated at 2022-06-12 15:29:41.564476
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Schema, Integer

    class OneOfZeroOrFive(OneOf):
        def __init__(self):
            super().__init__(one_of=[Integer(maximum=5), Integer(maximum=0)])

    assert Schema(OneOfZeroOrFive()).validate(1) == 1
    assert Schema(OneOfZeroOrFive()).validate(2) == 2
    assert Schema(OneOfZeroOrFive()).validate(3) == 3
    assert Schema(OneOfZeroOrFive()).validate(4) == 4
    assert Schema(OneOfZeroOrFive()).validate(5) == 5
    assert Schema(OneOfZeroOrFive()).validate(0) == 0
    assert Schema(OneOfZeroOrFive()).validate(-1) != -1

# Generated at 2022-06-12 15:29:51.136361
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    OneOf([
        Integer(maximum=10),
        String(max_length=10),
    ]).validate(5)
    OneOf([
        Integer(maximum=10),
        String(max_length=10),
    ]).validate("123")
    with pytest.raises(ValidationError) as e:
        OneOf([
            Integer(maximum=10),
            String(max_length=10),
        ]).validate(15)

    assert e.value.code == "no_match"
    with pytest.raises(ValidationError) as e:
        OneOf([
            Integer(maximum=10),
            String(max_length=10),
        ]).validate(5)

    assert e.value.code == "multiple_matches"
   

# Generated at 2022-06-12 15:29:52.869055
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[])
    assert field.one_of == []


# Generated at 2022-06-12 15:30:00.096321
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    then_clause = IfThenElse(
        if_clause=AllOf([Field()]),
        then_clause=Field(),
        else_clause=Field(),
    )

    expected_then = then_clause.then_clause.schema().get('type')
    then_validated = then_clause.validate('test')
    assert(expected_then == then_validated)

    else_clause = IfThenElse(
        if_clause=AllOf([Field()]),
        then_clause=Field(),
        else_clause=Field(),
    )
    
    expected_else = else_clause.else_clause.schema().get('type')
    else_validated = else_clause.validate()
    assert(expected_else == else_validated)

# Generated at 2022-06-12 15:30:00.745198
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-12 15:30:07.826447
# Unit test for method validate of class Not
def test_Not_validate():
    not_object = Not(String(), errors={'negated': 'Must not match.'})
    string_object = String()
    bool_object = Boolean()
    assert not_object.validate("hello") == "hello"
    try:
        not_object.validate(1)
        raise Exception("validate method of Not class didn't raise exception")
    except TypesystemError as e:
        assert e.to_primitive()["errors"] == {'negated': 'Must not match.'}
        assert e.to_primitive()["type"] == "validation"


# Generated at 2022-06-12 15:30:09.637023
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-12 15:30:10.505672
# Unit test for constructor of class Not
def test_Not():
    print(Not(Boolean(),title="condition"))

# Generated at 2022-06-12 15:30:20.034625
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.errors import ValidationError
    from typesystem.fields import Integer
    field = OneOf([Integer(min_value=0), Integer(max_value=10)], description="test field for OneOf")
    try:
        field.validate(0)
        field.validate(10)
        field.validate(5)
    except ValidationError:
        assert False
    try:
        field.validate(-1)
        assert False
    except ValidationError:
        assert True
        print("test_OneOf_validate passed")

# Generated at 2022-06-12 15:30:27.490468
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.tests.base_tests import (
        TestCase,
        all_fields,
        all_schemas,
    )

    class TestIfThenElse(TestCase):
        def test_if_then_else(self) -> None:
            if_clause = all_schemas[0]
            then_clause = all_schemas[3]
            else_clause = all_schemas[1]
            schema = IfThenElse(if_clause, then_clause, else_clause)
            data = all_fields[0]
            self.assertValidated(
                schema.validate_or_error,
                {"type": "string", "max_length": 10},
                data,
            )

        def test_if_then(self) -> None:
            if_cl

# Generated at 2022-06-12 15:30:36.307318
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Failure case
    try:
        NoValidateField = Field()
        NoValidateField.validate = mock.Mock(return_value=None)
        field = OneOf([NoValidateField])
        field.validate(0)
    except ValidationError as e:
        assert field.errors['no_match'] == e.messages['_schema']
    
    # Success case
    class SuccessField(Field):
        errors = {'invalid': 'Invalid'}
        
        def validate(self, value, strict=False):
            return value

    field = OneOf([SuccessField()])
    assert field.validate(None) == None



# Generated at 2022-06-12 15:30:42.132202
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field1 = IntField()
    one_of_field2 = IntField()
    one_of_field3 = FloatField()

    one_of_field_list = [one_of_field1, one_of_field2, one_of_field3]
    test_one_of_field = OneOf(one_of_field_list)

    assert test_one_of_field.validate(1) == 1


# Generated at 2022-06-12 15:30:48.351896
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print('Unit test for method validate of class OneOf')
    field = OneOf([String()])
    out = field.validate('')
    assert out == ''

    field = OneOf([String(), Integer()])
    out = field.validate(1)
    assert out == 1

    field = OneOf([])
    try:
        field.validate(1)
    except Exception:
        print('test_OneOf_validate passed')


# Generated at 2022-06-12 15:30:54.567717
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class mytest(Field):
        def __init__(self,**kwargs: typing.Any) -> None:
            super().__init__(**kwargs)

        def validate(self,value: typing.Any, strict: bool = False) -> typing.Any:
            return True

    assert IfThenElse(mytest()).validate("123") == "123"
    assert IfThenElse(mytest(),then_clause=Integer(),else_clause=String()).validate("123") == "123"


# Generated at 2022-06-12 15:30:59.326644
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema = OneOf([Integer(), String()])
    schema.validate(3)
    schema.validate("3")
    try:
        schema.validate(3.0)
    except ValidationError as e:
        assert e.field == "no_match"
    try:
        schema.validate(None)
    except ValidationError as e:
        assert e.field == "no_match"



# Generated at 2022-06-12 15:31:00.948448
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {'never': 'This never validates.'}


# Generated at 2022-06-12 15:31:04.497697
# Unit test for method validate of class Not
def test_Not_validate():
    test_field = Not(String())
    assert test_field.validate(10) == 10
    assert test_field.validate("10") == "10"


# Generated at 2022-06-12 15:31:06.652025
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        a = AllOf(None)
    except:
        assert False


# Generated at 2022-06-12 15:31:15.686929
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String()])
    value = "test"
    # assert field.validate(value) == value


# Generated at 2022-06-12 15:31:18.013923
# Unit test for constructor of class Not
def test_Not():
    errors = {"negated": "Must not match."}
    field = Not(NeverMatch())
    assert field.errors == errors

# Test for method validate of class Not

# Generated at 2022-06-12 15:31:20.696779
# Unit test for method validate of class Not
def test_Not_validate():
    # Arrange
    field = Not(negated=Any())

    # Act
    actual = field.validate(1)

    # Assert
    assert actual == 1


# Generated at 2022-06-12 15:31:27.730321
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.base import ValidationError

    # Happy path
    try:
        str_type = str()
        not_str = Not(str_type)
        not_str.validate(1)
    except ValidationError:
        assert False

    # Not happy path
    try:
        str_type = str()
        not_str = Not(str_type)
        not_str.validate("abc")
        assert False
    except ValidationError:
        pass

    # Happy path
    try:
        str_type = str()
        not_str = Not(str_type)
        not_str.validate("")
    except ValidationError:
        assert False

    # Not happy path

# Generated at 2022-06-12 15:31:29.231363
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    testNeverMatch = NeverMatch(name="testNeverMatch")
    assert testNeverMatch

# Generated at 2022-06-12 15:31:32.449192
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    value = 'a'
    error = {'error': 'no_match'}
    assert field.validate(value) == error


# Generated at 2022-06-12 15:31:36.537260
# Unit test for constructor of class AllOf
def test_AllOf():
    from . import Boolean, Integer, String
    field = AllOf([Integer(), String()])
    field.validate(0)
    field.validate('a')
    try:
        field.validate(True)
    except:
        pass
    else:
        assert False


# Generated at 2022-06-12 15:31:38.256696
# Unit test for method validate of class Not
def test_Not_validate():
    a_Not = Not(negated = 123)
    assert a_Not.validate(None) is None
    assert a_Not.validate("abc") is "abc"
    assert a_Not.validate(2) is 2


# Generated at 2022-06-12 15:31:42.177228
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Negated)
    assert field.validate('123', True) == '123'
    try:
        field.validate('abc', True)
    except ValueError as ve:
        assert str(ve) == 'negated'


# Generated at 2022-06-12 15:31:49.538536
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer

    if_clause = Integer(min_value=10)
    then_clause = Integer(max_value=20)
    else_clause = Integer(max_value=30)
    field = IfThenElse(if_clause, then_clause=then_clause, else_clause=else_clause)

    # test valid value
    value = 15
    assert field.validate(value) == value

    # test invalid value
    # value = 5
    # assert False == field.validate(value)
    pass

# Generated at 2022-06-12 15:32:05.814818
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # define the fields for if_clause, then_clause and else_clause
    if_clause_field = Field(max_length=10)
    then_clause_field = Field(max_length=20)
    else_clause_field = Field(min_length=20)

    # define a new class of type IfThenElse
    if_else_clause = IfThenElse(if_clause=if_clause_field, then_clause=then_clause_field, else_clause=else_clause_field)

    # test a case where the value meets the condition in if_clause, then return the value which meets the then_clause condition
    value = "helloworld"
    result = if_else_clause.validate(value) 

# Generated at 2022-06-12 15:32:08.237509
# Unit test for method validate of class Not
def test_Not_validate():
    x = Field()
    x.validate=mock.Mock()
    if_schema = Not(x)
    if_schema.validate(1)
    x.validate.assert_called_with(1)



# Generated at 2022-06-12 15:32:08.904212
# Unit test for constructor of class OneOf
def test_OneOf():
    print(OneOf)

# Generated at 2022-06-12 15:32:11.958316
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Field()])
    field.validate(1)
    field.validate('a')
    field.validate([])
    field.validate({})

# Generated at 2022-06-12 15:32:20.718519
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TypeOne(Field):
        pass
    class TypeTwo(Field):
        pass
    class TypeThree(Field):
        pass

    type_one = TypeOne()
    type_two = TypeTwo()
    type_three = TypeThree()

    if_field = IfThenElse(
        if_clause=type_one,
        then_clause=type_two,
        else_clause=type_three
    )

    # Case 1
    value = 1
    assert if_field.validate(value) == value
    # Case 2
    assert if_field.validate(value) == value
    # Case 3
    assert if_field.validate(value) == value



# Generated at 2022-06-12 15:32:22.440223
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors["never"] == "This never validates."


# Generated at 2022-06-12 15:32:23.702944
# Unit test for method validate of class Not
def test_Not_validate():
    # Create instance of class
    field = Not(AllOf([Any(), Any()]))
    # Test validate method
    value = "test"
    result = field.validate(value)
    assert result == "test"

# Generated at 2022-06-12 15:32:24.973747
# Unit test for constructor of class AllOf
def test_AllOf():
    fields = [Field(
        name="a",
        required=False
    )]

    instance = AllOf(fields)
    assert instance is not None


# Generated at 2022-06-12 15:32:31.927485
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import set_options

    set_options(strict_json=True)

    try:
        a = AllOf([String()])
    except AssertionError:
        print("Constructor of class AllOf failed")
    else:
        print("Constructor of class AllOf succeeded")


# Generated at 2022-06-12 15:32:33.362828
# Unit test for method validate of class Not
def test_Not_validate():
    x = Not(Any())
    x.validate({})



# Generated at 2022-06-12 15:32:50.180394
# Unit test for method validate of class Not
def test_Not_validate():
    a = Not(String())

    # validating without error
    try:
        assert a.validate([4]) is not None
    except:
        print("test_Not_validate_without_error Failed")

    # validating with error
    try:
        assert a.validate("abc") is None
    except:
        print("test_Not_validate_with_error Failed")


if __name__ == "__main__":
    test_Not_validate()

# Generated at 2022-06-12 15:32:51.215101
# Unit test for constructor of class OneOf
def test_OneOf():
    oo = OneOf()
    assert oo.__class__.__name__ == 'OneOf'


# Generated at 2022-06-12 15:32:51.993637
# Unit test for constructor of class Not
def test_Not():
    not_1 = Not(1)
    assert not_1


# Generated at 2022-06-12 15:32:55.773118
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [1, 2, 3]
    kwargs = {'all_of': all_of}
    test = AllOf(**kwargs)
    assert test.all_of == [1, 2, 3]


# Generated at 2022-06-12 15:32:58.065530
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    try:
        f.validate(1)
        assert False
    except:
        assert True


# Generated at 2022-06-12 15:32:58.816414
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never = NeverMatch()

# Generated at 2022-06-12 15:33:00.156409
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), Field)


# Generated at 2022-06-12 15:33:08.090202
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf(one_of=[Integer(minimum=5), Integer(maximum=5)]).validate(5) is None
    assert OneOf(one_of=[Integer(minimum=5), Integer(maximum=5)]).validate(4) == {'no_match': "Did not match any valid type."}
    assert OneOf(one_of=[Integer(minimum=5), Integer(maximum=5)]).validate(6) == {'no_match': "Did not match any valid type."}
    assert OneOf(one_of=[Integer(minimum=5), Integer(maximum=5)]).validate(4.5) == {'no_match': "Did not match any valid type."}

# Generated at 2022-06-12 15:33:19.591488
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Field(), Field()])
    assert one_of.validate(None) is None

    try:
        one_of = OneOf([Field()])
        one_of.validate(None)
    except ValueError as e:
        assert str(e) == '\nValidation error at "<root>"\nExpected type "oneOf"\n  - Expected type "any"\n'

    one_of = OneOf([Field(), NeverMatch()])
    assert one_of.validate(None) is None

    one_of = OneOf([NeverMatch(), Field()])
    assert one_of.validate(None) is None


# Generated at 2022-06-12 15:33:20.572959
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass


# Generated at 2022-06-12 15:34:37.645439
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_NeverMatch = NeverMatch()
    assert test_NeverMatch != None


# Generated at 2022-06-12 15:34:41.288014
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    my_field = IfThenElse(if_clause=OneOf([Bool()]))
    assert my_field.validate(True) == True
    my_field = IfThenElse(if_clause=OneOf([Bool()]), then_clause=String())
    assert my_field.validate(True) == "True"
    my_field = IfThenElse(if_clause=OneOf([Bool()]), else_clause=String())
    assert my_field.validate(1) == "1"
    #TODO: add a test for when there is no if or else clause.

# Generated at 2022-06-12 15:34:43.840357
# Unit test for constructor of class OneOf
def test_OneOf():
  one_of = [AllOf([Any()]), AllOf([Any()])]
  x = OneOf(one_of)
  print(x)

# Unit test runner
if __name__ == '__main__':
  test_OneOf()

# Generated at 2022-06-12 15:34:51.580267
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field1 = Field()
    field2 = Field()
    field3 = Field()
    value = 10
    field = OneOf([field1, field2, field3])
    field.validate(value)
    field = OneOf([field1, field2, field3])
    field.validate(value)
    field = OneOf([field1, field2, field3])
    field.validate(value)
    field = OneOf([field1, field2, field3])
    field.validate(value)
    field = OneOf([field1, field2, field3])
    field.validate(value)

# Generated at 2022-06-12 15:35:00.085377
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Strutura do teste:
    #   Entrada: valor, strict
    #   Saída: valor após aplicar(validate)
    #   Restrições: if_clause, then_clause e else_clause existem

    # Teste: 'then_clause' possui valor
    teste = True
    if_clause = Field()
    then_clause = Field(default='a')
    else_clause = Field(default='a')
    valor = 'a'
    strict = False
    if IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause).validate(valor, strict) == valor:
        teste = True

# Generated at 2022-06-12 15:35:04.660100
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Int(), String()])
    field.validate("1") # doesn't raise
    with pytest.raises(ValidationError) as excinfo:
        field.validate(0.1)
    assert excinfo.value.messages == {"__root__": ["Did not match any valid type."]}
    with pytest.raises(ValueError) as excinfo:
        OneOf([Int(), Int()])
    assert "Expected to find" in str(excinfo.value)


# Generated at 2022-06-12 15:35:13.114044
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String(max_length=5))
    value, error = field.validate_or_error('123456')
    assert error is None
    assert value == '123456'

    value, error = field.validate_or_error('12345')
    assert error is not None
    assert len(error['errors']) == 1
    assert error['errors'][0]['code'] == 'negated'
    assert error['errors'][0]['message'] == 'Must not match.'

# Generated at 2022-06-12 15:35:19.332906
# Unit test for method validate of class Not
def test_Not_validate():
    # Tests handling of simple case
    a = Not(Integer(maximum=100))
    expected_value_1 = 46
    returned_value_1 = a.validate(expected_value_1)
    assert returned_value_1 == expected_value_1

    # Tests handling of case that the field is not valid.
    a = Not(Integer())
    expected_value_2 = "test string"
    returned_value_2 = a.validate(expected_value_2)
    assert returned_value_2 == expected_value_2

# Generated at 2022-06-12 15:35:29.398466
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    n.validate(1)
    n.validate(None)
    n.validate(True)
    n.validate(False)
    n.validate(1.0)
    n.validate(1.0)
    n.validate('test')
    n.validate('test')
    n.validate([1,2,3])
    n.validate({'key':'value'})

    n = Not(Boolean())
    with pytest.raises(ValidationError):
        n.validate(True)
    with pytest.raises(ValidationError):
        n.validate(False)
    with pytest.raises(ValidationError):
        n.validate(1)


# Generated at 2022-06-12 15:35:30.491561
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field is not None


# Generated at 2022-06-12 15:37:45.865787
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any(), Int()])
    assert field.validate(123) == 123

# Generated at 2022-06-12 15:37:46.465456
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(Field())

# Generated at 2022-06-12 15:37:49.594756
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_type = OneOf(one_of=[types.String()])
    with pytest.raises(types.ValidationError) as exc_info:
        one_of_type.validate(1)
    assert str(exc_info.value) == '1 is not a valid string.'
    assert one_of_type.validate('a') == 'a'


# Generated at 2022-06-12 15:37:54.882898
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Hobbits(Field):
        errors = {"hobbit": "Must not be a hobbit."}

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if isinstance(value, dict) and value["name"] == "Frodo":
                raise self.validation_error("hobbit")
            return value

    class Hobbits_II(Field):
        errors = {"hobbit": "Must not be a hobbit."}

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if isinstance(value, dict) and value["name"] == "Frodo":
                raise self.validation_error("hobbit")
            return value
    

# Generated at 2022-06-12 15:38:05.128208
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    oneOf = OneOf([IsInt, IsFloat], name='oneOf', description='oneOf')
    assert isinstance(oneOf.validate(1), int)
    assert isinstance(oneOf.validate(1.1), float)
    try:
        oneOf.validate(True)
    except Exception as e:
        assert e.message == 'Did not match any valid type.'
    int_field = IsInt(name='int_field', description='int_field')
    int_field2 = IsInt(name='int_field2', description='int_field2')
    oneOf = OneOf([int_field, int_field2])
    assert isinstance(oneOf.validate(1), int)

# Generated at 2022-06-12 15:38:06.300718
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([]).validate(0) == 0


# Generated at 2022-06-12 15:38:11.643099
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(Integer(),Integer())
    valid_value = 1
    print(ite.validate(valid_value))
    invalid_value = 'a'
    try:
        print(ite.validate(invalid_value))
    except BaseException as err:
        print(err)

if __name__ == '__main__':
    print('Test webhook_python:')
    test_IfThenElse_validate()

# Generated at 2022-06-12 15:38:12.455557
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert True



# Generated at 2022-06-12 15:38:20.512489
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(one_of=[Number(max_value=100), String()])
    assert True == isinstance(one_of, Field)
    assert isinstance(one_of.validate(0), int)
    assert isinstance(one_of.validate("test"), str)
    #assert one_of.validate(200) == None
    try:
        one_of.validate(200)
    except:
        assert True
    else:
        assert False
    #assert one_of.validate(0.0) == None
    try:
        one_of.validate(0.0)
    except:
        assert True
    else:
        assert False
    assert one_of.validate("test") == "test"


# Generated at 2022-06-12 15:38:21.649678
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert field.NeverMatch(
        name="name", label="label", hint="hint", description="description"
    )