

# Generated at 2022-06-12 15:28:44.360377
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    import pytest
    class data(typesystem.Schema):
        if1 = IfThenElse(if_clause=typesystem.Integer,
                then_clause=typesystem.Integer,
                else_clause=typesystem.Float)
    res = data({"if1": 1})
    assert res.is_valid()
    res = data({"if1": 1.0})
    assert res.is_valid()
    res = data({"if1": "1"})
    assert not res.is_valid()

# Generated at 2022-06-12 15:28:47.540189
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    typesys = OneOf([String(), Integer()])
    assert typesys.validate("1") == "1"
    try:
        typesys.validate(1.0)
        assert False
    except ValidationError as e:
        assert e.detail == "Matched more than one type."
    try:
        typesys.validate(1)
        assert False
    except ValidationError as e:
        assert e.detail == "Did not match any valid type."

# Generated at 2022-06-12 15:28:48.330287
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nevermatch = NeverMatch(name="nevermatch")
    assert nevermatch


# Generated at 2022-06-12 15:28:53.871503
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    oof = OneOf([
        Int(),
        Str(),
    ])
    assert oof.validate("hi") == "hi"
    assert oof.validate("100") == "100"
    assert oof.validate("100", strict=True) == "100"
    assert oof.validate(100) == 100


# Generated at 2022-06-12 15:28:59.141356
# Unit test for method validate of class Not
def test_Not_validate():
    int_field = Int()
    not_prime = Not(int_field)
    assert not_prime.validate(1) == 1
    assert not_prime.validate(4) == 4
    # An exception is raised only if value is a prime number
    try:
        not_prime.validate(7)
        raise AssertionError("Did not get an exception. Value 7 is a prime number")
    except ValidationError as e:
        assert e.code == "negated"


# Generated at 2022-06-12 15:29:04.774691
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import String
    from typesystem.schema import Schema, CompoundError

    schema = Schema({"if": String(),"else": String()})

    result = schema.validate({
    "if": "true",
    "else": "false"
    })
    assert {"if": "true", "else": "false"} == result


# Generated at 2022-06-12 15:29:09.751944
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Int()
    then_clause = String()
    else_clause = String()

    x = IfThenElse(if_clause, then_clause, else_clause)

    x.validate(5)
    x.validate("5")
    try:
        x.validate(5.5)
    except:
        print('Unexpected Exception, Float is not in the range of Int')



# Generated at 2022-06-12 15:29:12.405098
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(5) == 5



# Generated at 2022-06-12 15:29:17.749011
# Unit test for constructor of class Not
def test_Not():
    assert(Not(negated=None))
    assert(Not(negated=Any()))
    assert(Not(negated=Any(), allow_null=True))
    assert(Not(negated=Any(), required=True))
    assert(Not(negated=Any(), description='asdf'))



# Generated at 2022-06-12 15:29:20.157141
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate("somethhing")=="somethhing"
    assert not_field.validate(123)==123
    assert not_field.validate(12.6)==12.6
    assert not_field.validate(False)==False
    assert not_field.validate(True)==True

# Generated at 2022-06-12 15:29:29.119545
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([], required=True)
    with pytest.raises(FieldError) as exc:
        field.validate(None)
    assert str(exc.value) == 'Did not match any valid type.'
    field = OneOf([Field()], required=True)
    assert field.validate(None) is None
    field = OneOf([Field(), Field()], required=True)
    with pytest.raises(FieldError) as exc:
        field.validate(None)
    assert str(exc.value) == 'Matched more than one type.'
    field = OneOf([Field(), Field(default=0)], required=True)
    assert field.validate(None) == 0
    field = OneOf([Field(default=0), Field()], required=True)
    assert field.validate(None)

# Generated at 2022-06-12 15:29:41.034464
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    this test case aims to test the validate method of OneOf
    """
    test_object = OneOf([Any()])
    """
    one_of param must contain at least one field
    """
    with pytest.raises(AssertionError):
        test_object.validate(None)
    """
    strict parameter of OneOf.validate method must be boolean type
    """
    with pytest.raises(TypeError):
        test_object.validate(None,[1,2,3])
    """
    'Multiple_matches' error message test case
    """
    with pytest.raises(MultipleInvalid):
        test_object.validate([1,2,3,4],1)
    """
    'No_match' error message test case
    """

# Generated at 2022-06-12 15:29:47.886539
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    my_one_of = OneOf(
    one_of=[
        Any(),
        Any(noneable=True),
        Any(nullable=False)
        ]
    )
    assert my_one_of([1,2,3]) == [1,2,3]
    assert my_one_of({1,2,3}) == {1,2,3}
    assert my_one_of(1) == 1
    assert my_one_of(None) == None
    assert my_one_of(False) == False
    assert my_one_of([]) == []
    assert my_one_of({}) == {}
    assert my_one_of(0) == 0
    assert my_one_of((None, None)) == (None, None)


# Generated at 2022-06-12 15:29:57.122433
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestField01(Field):
        def validate(self, value, strict=False):
            if value == 'test this':
                raise Exception("This should be 'test this'")
            else:
                return value

    class TestField02(Field):
        def validate(self, value, strict=False):
            if value == 'test that':
                raise Exception("This should be 'test that'")
            else:
                return value

    class TestField03(Field):
        def validate(self, value, strict=False):
            if value == 'test the other':
                raise Exception("This should be 'test the other'")
            else:
                return value


# Generated at 2022-06-12 15:30:07.984220
# Unit test for method validate of class Not
def test_Not_validate():
    result = None
    field = Not(Int16(2))
    valid, error = field.validate_or_error(2)
    assert valid == result, "Case 1: 2"

    field = Not(Int16(3))
    valid, error = field.validate_or_error(2)
    assert not valid, "Case 2: 2"

    field = Not(Float())
    valid, error = field.validate_or_error(3.14)
    assert not valid, "Case 3: 3.14"

    field = Not(Float(2.22))
    valid, error = field.validate_or_error(2.22)
    assert valid == result, "Case 4: 2.22"

    field = Not(Boolean())
    valid, error = field.validate_or_error(True)


# Generated at 2022-06-12 15:30:17.054878
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a1 = Field()
    a2 = Field(name='a2')
    b = Field(name='b')
    if_clause = Field(name='if_clause')
    if_then_else = IfThenElse(if_clause, then_clause=a1, else_clause=a2)
    if_then_else.validate(1)
    assert 1 == a1.validate(1)
    assert 1 == a2.validate(1)
    if_then_else.validate(0)
    assert 1 == b.validate(1)

# Generated at 2022-06-12 15:30:23.122984
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    s = IfThenElse(Integer(), then_clause=Integer())
    assert s.validate(2) == 2
    with pytest.raises(ValidationError):
        s.validate("abc")
    s = IfThenElse(Integer(), else_clause=String())
    assert s.validate("abc") == "abc"
    with pytest.raises(ValidationError):
        s.validate(2)

# Generated at 2022-06-12 15:30:34.250699
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import json

    # test case 1
    condition = {'type': 'string', 'pattern': '^[0-9]*$'}
    consequent = {'type': 'integer'}
    alternative = {'type': 'string'}
    value = "1234"

    if_field = IfThenElse(if_clause=condition, then_clause=consequent, else_clause=alternative)
    expected = 1234
    actual = if_field.validate(value)
    assert actual == expected

    # test case 2
    condition = {'type': 'string', 'pattern': '^[0-9]*$'}
    consequent = {'type': 'integer'}
    alternative = {'type': 'string'}
    value = "abc"


# Generated at 2022-06-12 15:30:36.109051
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(), Any())
    result = field.validate(1)
    assert result == 1


# Generated at 2022-06-12 15:30:39.115747
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = IfThenElse(Any())
    y = IfThenElse(Any(), then_clause=Any())
    z = IfThenElse(Any(), else_clause=Any())
    q = IfThenElse(Any(), then_clause=Any(), else_clause=Any())

# Generated at 2022-06-12 15:30:49.123212
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class MyClass():
        def __init__(self, a: int, b: int) -> None:
            self.a = a
            self.b = b

    field = IfThenElse(
        if_clause=lambda x: isinstance(x, MyClass),
        then_clause=lambda x: (x.a > x.b),
        else_clause=lambda x: True,
        required=True,
    )
    assert field.validate(MyClass(2, 3)) is True
    assert field.validate(MyClass(3, 2)) is False
    assert field.validate(1) is True

# Generated at 2022-06-12 15:30:55.241908
# Unit test for constructor of class AllOf
def test_AllOf():
    class x(AllOf):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any):
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.all_of = all_of

        def validate(self, value: typing.Any, strict: bool = False):
            for child in self.all_of:
                child.validate(value, strict=strict)
            return value



# Generated at 2022-06-12 15:30:56.117880
# Unit test for constructor of class OneOf
def test_OneOf():
    T = OneOf([Any()])

# Generated at 2022-06-12 15:30:57.074846
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer
    assert isinstance(OneOf([Integer()]), Field)

# Generated at 2022-06-12 15:30:59.366275
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=String()).validate("abc") == "abc"
    raises(str, lambda: Not(negated=String()).validate(1))


# Generated at 2022-06-12 15:31:00.633156
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([Any()])
    assert field

# Generated at 2022-06-12 15:31:01.574102
# Unit test for constructor of class AllOf
def test_AllOf():
  a = AllOf([])


# Generated at 2022-06-12 15:31:04.401235
# Unit test for constructor of class Not
def test_Not():
    not_=Not(String())
    assert not_.negated.alias == 'String'


# Generated at 2022-06-12 15:31:07.082942
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = [Field()]
    o = OneOf(one_of)

    assert o.one_of == one_of



# Generated at 2022-06-12 15:31:10.975136
# Unit test for method validate of class Not
def test_Not_validate():
    # Test when error is None
    value = "some value"
    strict = False
    result = Not(Any()).validate(value, strict)
    assert value == result

    # Test when error is not None
    with pytest.raises(FieldValidationError):
        Not(String()).validate(value, strict)



# Generated at 2022-06-12 15:31:18.927907
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    int_field = Integer(name="int_field")
    string_field = String(name="string_field")
    if_then_else_field = IfThenElse(
        name="if_then_else_field", if_clause=int_field, then_clause=string_field, else_clause=Any(),
    )
    assert if_then_else_field.validate("") == ""
    assert if_then_else_field.validate(1) == 1

# Generated at 2022-06-12 15:31:23.433346
# Unit test for method validate of class Not
def test_Not_validate():
    # No error raised with an allowed value
    not_field = Not(String())
    not_field.validate('5')
    # Error raised with an unallowed value
    with pytest.raises(ValidationError):
        not_field = Not(String())
        not_field.validate(5)



# Generated at 2022-06-12 15:31:26.854854
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch(description="", title="", name="", required=False, errors={"never": "This never validates."})


# Generated at 2022-06-12 15:31:27.625255
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated = Field())
    assert not_field is not None

# Generated at 2022-06-12 15:31:29.529255
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch(name='x')
    assert x.name == 'x'


# Generated at 2022-06-12 15:31:33.521684
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.fields import String
    i = IfThenElse(Integer(),then_clause = String())
    res = i.validate(5)
    assert res == "5"


# Generated at 2022-06-12 15:31:34.484494
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-12 15:31:38.623827
# Unit test for method validate of class Not
def test_Not_validate():
    x = Not(negated=Any())
    v, error = x.validate_or_error(1)
    assert v == 1
    assert error is None
    v, error = x.validate_or_error(2)
    assert error.detail == "Must not match."
    assert error.code == "negated"

# Generated at 2022-06-12 15:31:40.085372
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=None)
    print(not_field.validate("foo"))

# Generated at 2022-06-12 15:31:45.654952
# Unit test for method validate of class Not
def test_Not_validate():
    # Given
    field_1 = Not(negated=String())
    # When - should return without raising an exception
    field_1.validate(1)
    # Given
    field_2 = Not(negated=String())
    # When - should raise an exception
    with pytest.raises(ValidationError):
        field_2.validate("test")


# Generated at 2022-06-12 15:31:50.103677
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String())
    assert not_field.validate('test')

    not_field = Not(Integer())
    assert not_field.validate('test')



# Generated at 2022-06-12 15:31:56.306210
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String, Integer

    # condition fails, then clause is not evaluated
    if_clause = String(max_length=3)
    then_clause = Integer()
    validator = IfThenElse(if_clause, then_clause)
    assert validator.validate(4) == 4

    # condition passes, then clause is evaluated
    if_clause = String(max_length=3)
    then_clause = Integer()
    validator = IfThenElse(if_clause, then_clause)
    assert validator.validate("abc") == "abc"

    # condition fails, both clauses are evaluated
    if_clause = String(max_length=3)
    then_clause = Integer()
    else_clause = Integer()

# Generated at 2022-06-12 15:32:02.934096
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])

    assert one_of.name is None
    assert one_of.description == 'Must match exactly one of the sub-items.'
    assert one_of.field_type == 'OneOf'
    assert one_of.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}
    assert one_of.params == {}
    assert one_of.one_of == []


# Generated at 2022-06-12 15:32:04.785816
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    an_int = OneOf(one_of=[7])
    assert an_int.validate(7) is 7
    

# Generated at 2022-06-12 15:32:07.055123
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = Field()
    b = Field()
    c = Field()
    IfThenElse(a, b, c).validate(1)
    IfThenElse(a, b, c).validate(0)

# Generated at 2022-06-12 15:32:07.744411
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch() != None


# Generated at 2022-06-12 15:32:16.489495
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_1 = AllOf([])
    assert all_of_1.all_of == []
    assert all_of_1.errors == {}
    all_of_2 = AllOf([1, 2, 3, 4, 5])
    assert all_of_2.all_of == [1, 2, 3, 4, 5]
    assert all_of_2.errors == {}
    # this test fails because the error message is not fixed
    # assert all_of_3.errors["no_match"] == "Did not match any valid type."
    # assert all_of_3.errors["multiple_matches"] == "Matched more than one type."



# Generated at 2022-06-12 15:32:20.027436
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Schema(typesystem.Schema):
        a = typesystem.Integer()

    json = {"a":1}
    input = Schema(json)
    assert input.is_valid()
    output = input.validate()
    assert json == output



# Generated at 2022-06-12 15:32:20.944349
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()


# Generated at 2022-06-12 15:32:27.681620
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Create objects
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    # Check validation error
    with pytest.raises(FieldError) as exc:
        if_then_else.validate(None)
    assert exc.value.code == ''
    assert str(exc.value) == 'This field is required.'

    # Check success validation
    result = if_then_else.validate('string')
    assert result == 'string'
    

# Generated at 2022-06-12 15:32:32.990754
# Unit test for constructor of class Not
def test_Not():
    assert Not(Foo(name="Bob"))


# Generated at 2022-06-12 15:32:37.474457
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    IfThenElse(if_clause)
    IfThenElse(if_clause, then_clause)
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-12 15:32:38.673033
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of is not None


# Generated at 2022-06-12 15:32:43.920597
# Unit test for method validate of class Not
def test_Not_validate():
    Not(String("name", max_length=20)).validate("")
    Not(String("name", max_length=20)).validate("YB")
    Not(String("name", max_length=20)).validate("YangBin")
    try:
        Not(String("name")).validate("")
        assert False
    except Error:
        assert True



# Generated at 2022-06-12 15:32:44.774170
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()



# Generated at 2022-06-12 15:32:48.229305
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.name == "NeverMatch"

# Generated at 2022-06-12 15:32:52.609502
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Schema, String
    schema_str = '{"name": "User","type": "object","properties": {"email": {"$ref": "#/definitions/Email"},"username": {"$ref": "#/definitions/Username"}}}'
    schema_dict = eval(schema_str)
    schema = Schema(**schema_dict)
    not_str = Not(schema, required=True)
    errors = not_str.validate("test")
    assert errors == {'email': "This field may not be blank.", 'username': "This field may not be blank."}


# Generated at 2022-06-12 15:32:54.508094
# Unit test for constructor of class Not
def test_Not():
    field = Not(Field())
    assert isinstance(field, Not)
    assert field.error_messages == field.errors


# Generated at 2022-06-12 15:33:04.943732
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = IfThenElse(
        if_clause = String(min_length = 1), 
        then_clause = String(), 
        else_clause = String(min_length = 1, max_length = 15)
        )
    # Case 1 - Matches if_clause
    value = "Test_if_clause"
    try:
        field.validate(value)
    except ValidationError as err:
        assert False, "If cases - no match"
    # Case 2 - Matches else_clause
    value = "abcde"
    try:
        field.validate(value)
    except ValidationError as err:
        assert False, "Else cases - no match"
    # Case 3 - Matches neither

# Generated at 2022-06-12 15:33:08.012030
# Unit test for method validate of class Not
def test_Not_validate():
    Not(Number()).validate("1")

    try:
        Not(Number()).validate(1)
    except Exception as error:
        assert error.code == 'negated'

# Generated at 2022-06-12 15:33:18.733408
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Create a IfThenElse field
    ite_obj = IfThenElse(if_clause=int)

    # check if the validate method of IfThenElse class works properly
    assert ite_obj.validate(1) == 1
    assert ite_obj.validate("test") == "test"

# Generated at 2022-06-12 15:33:20.301494
# Unit test for method validate of class Not
def test_Not_validate():
    negatedField = Int()
    invalidInput = 'abc'
    expected = None
    result = Not(negatedField, required=True).validate(invalidInput)
    assert result == expected

# Generated at 2022-06-12 15:33:21.980941
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_test = OneOf([])
    one_of_test.validate(None)

# Generated at 2022-06-12 15:33:23.330695
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate("hello world!") is not None
    not_field = Not(None)
    assert not_field.validate(None) is not None

# Generated at 2022-06-12 15:33:24.770551
# Unit test for constructor of class Not
def test_Not():
    from typesystem.base import Number

    field = Not(Number())
    assert field.negated == Number()

# Generated at 2022-06-12 15:33:26.978368
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Create an instance of class IfThenElse
    if_clause = Field()
    ite = IfThenElse(if_clause)

    # Call method validate of class IfThenElse
    ite.validate(100)

# Generated at 2022-06-12 15:33:27.767842
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	assert NeverMatch()


# Generated at 2022-06-12 15:33:28.530277
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(negated=Any())

# Generated at 2022-06-12 15:33:32.135316
# Unit test for constructor of class Not
def test_Not():
    a = Not(negated=5)
    assert a.errors == {'negated': 'Must not match.'}
    assert a.negated == 5
    a = Not(negated=[1, 2])
    assert a.negated == [1, 2]



# Generated at 2022-06-12 15:33:41.061829
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import String

    # Test if-clause validation
    String().validate(1, strict=True)
    String().validate_or_error(1, strict=True)[1].code == "invalid_type"
    IfThenElse(String(), String(), String()).validate(1, strict=True)
    IfThenElse(String(), String(), String()).validate_or_error(1, strict=True)[1].code == "invalid_type"

    # Test then-clause validation
    IfThenElse(String(), String(), String()).validate("x", strict=True)
    IfThenElse(String(), String(), String()).validate_or_error("x", strict=True)[1] == None
    IfThenElse(String(), String("")).validate("x", strict=True)
    IfThen

# Generated at 2022-06-12 15:33:55.029362
# Unit test for method validate of class Not
def test_Not_validate():
    a = Not(String())
    print(a.validate('abc'))



# Generated at 2022-06-12 15:33:58.516901
# Unit test for method validate of class Not
def test_Not_validate():
    #arrange
    from typesystem import Boolean, String
    f1 = Not(String(max_length=2))
    #act
    value, error = f1.validate_or_error("abc")
    #assert
    assert error is None
    assert value == "abc"


# Generated at 2022-06-12 15:34:01.350894
# Unit test for constructor of class AllOf
def test_AllOf():
    base = AllOf([String(), Integer()])
    base.validate("foo")
    base.validate(3)


# Generated at 2022-06-12 15:34:05.101974
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause = Integer(),
        then_clause = String(),
        else_clause = String()
    )

    value = 1
    assert field.validate(value) == value

    value = 3.1
    assert field.validate(value) == '3.1'

# Generated at 2022-06-12 15:34:08.648505
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name='test_NeverMatch', description='None').name == 'test_NeverMatch'
    assert NeverMatch(name='test_NeverMatch', description='None').description == 'None'
    assert NeverMatch(name='test_NeverMatch', description='None').errors == {'never': 'This never validates.'}


# Generated at 2022-06-12 15:34:10.200524
# Unit test for constructor of class Not
def test_Not():
    not_val = Not(negated = Field('int'))
    assert hasattr(not_val, 'negated')


# Generated at 2022-06-12 15:34:13.598994
# Unit test for constructor of class Not
def test_Not():
    assert(Not(Any()))
    assert(Not(Any(), description="Not"))
    assert(Not(Any(), description="Not").description == "Not")


# Generated at 2022-06-12 15:34:16.785621
# Unit test for constructor of class Not
def test_Not():
    a = 1
    b = Field()
    c = Field()
    d = Field()
    e = Not(a)
    f = Not(b)
    g = Not(c, d)
    h = Not(b, d)
    return

# Generated at 2022-06-12 15:34:19.776757
# Unit test for method validate of class Not
def test_Not_validate():
    int_field = Field(typ=int)
    bool_field = Field(typ=bool)

    assert Not(negated=int_field).validate(True)

    with pytest.raises(FieldError):
        Not(negated=bool_field).validate(1)

# Generated at 2022-06-12 15:34:21.820697
# Unit test for constructor of class AllOf
def test_AllOf():
    x = AllOf([])
    assert x is not None



# Generated at 2022-06-12 15:35:00.615504
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Test(Field):
        errors = {"test": "test"}
        def validate(self, value, strict = False):
            raise self.validation_error("test")

    test_False = Test()
    test_True = Test()

    # Test 1
    value = IfThenElse(test_False, test_True)
    out = value.validate_or_error(None)
    assert out == (None, None)
    # Test 2
    value = IfThenElse(test_True, test_False)
    out = value.validate_or_error(None)
    assert out == (None, {'test': 'test'})
    # Test 3
    value = IfThenElse(test_True, None, test_False)
    out = value.validate_or_error(None)

# Generated at 2022-06-12 15:35:01.381516
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__init__

# Generated at 2022-06-12 15:35:04.257094
# Unit test for method validate of class Not
def test_Not_validate():
    test_cases = [
        {"value": (1, 2), "expected": (1, 2)},
        {"value": (1, 2, 3), "expected": (1, 2, 3)},
    ]
    #  "negated": "Did not match any valid type."

    for test_case in test_cases:
        field = Not(List[int](min_length=2))
        result = field.validate(test_case["value"])
        assert result == test_case["expected"]

# Generated at 2022-06-12 15:35:06.609195
# Unit test for method validate of class Not
def test_Not_validate():
    inp = 1
    n = Not(Number())
    n.validate(inp)



# Generated at 2022-06-12 15:35:08.583031
# Unit test for method validate of class Not
def test_Not_validate():
    with pytest.raises(Exception) as e:
        Not(Integer()).validate(-1)



# Generated at 2022-06-12 15:35:09.211077
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()

# Generated at 2022-06-12 15:35:12.196158
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Any(), Any()).validate(5) == 5
    assert IfThenElse(NeverMatch(), Any()).validate(5) == 5

# Generated at 2022-06-12 15:35:15.092533
# Unit test for constructor of class OneOf
def test_OneOf():
    oo = OneOf([])
    assert oo != None
    assert isinstance(oo, OneOf)
    assert isinstance(oo, Field)


# Generated at 2022-06-12 15:35:17.574973
# Unit test for constructor of class AllOf
def test_AllOf():
    print("Testing AllOf constructor:")
    all_of = AllOf()
    print(all_of)


# Generated at 2022-06-12 15:35:27.918829
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    id_dict = {'$id': 'http://some_url.com/person.schema.json'}

    # case compares the given data to the condition and if the result is True then the data is checked agains the second given schema
    # case = valid result from if_clause (if_clause is True)

    # if_clause: given data is compared to if_clause
    valid_if_clause = IfThenElse(Integer(),Object(properties={
        'name': String()
    }, **id_dict))
    invalid_if_clause = IfThenElse(Boolean(),Object(properties={
        'name': String(),
    }, **id_dict))

    # Then_clause: given data is compared to given then clause

# Generated at 2022-06-12 15:36:55.730104
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert not field.allow_null
    assert field.errors == {"never": "This never validates."}
    assert field.name == "NeverMatch"


# Generated at 2022-06-12 15:36:57.792821
# Unit test for constructor of class AllOf
def test_AllOf():
    bool1 = typing.List[Field]()
    bool2 = Field()
    one = AllOf(bool1, bool2)
    assert one != None


# Generated at 2022-06-12 15:36:59.518219
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(field)
    value = 1
    strict = False
    field.validate(value, strict)


# Generated at 2022-06-12 15:37:06.553149
# Unit test for method validate of class Not
def test_Not_validate():
    not_value = Not(Any())
    assert not_value.validate(None) == Not.errors["negated"]
    assert not_value.validate("string") == Not.errors["negated"]
    assert not_value.validate(1) == Not.errors["negated"]
    assert not_value.validate(0.1) == Not.errors["negated"]
    assert not_value.validate(list()) == Not.errors["negated"]
    assert not_value.validate(tuple()) == Not.errors["negated"]
    assert not_value.validate(dict()) == Not.errors["negated"]
    assert not_value.validate(set()) == Not.errors["negated"]

# Generated at 2022-06-12 15:37:07.566105
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(NeverMatch()).validate(1) == 1



# Generated at 2022-06-12 15:37:10.559356
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    neverMatch = NeverMatch()
    assert neverMatch._name == ""
    assert neverMatch._default is None
    assert neverMatch._allow_null is False
    assert neverMatch.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:37:11.580288
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
    except:
        assert False

# Generated at 2022-06-12 15:37:12.927667
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer, String


    field1 = Integer()
    field2 = String()

    a

# Generated at 2022-06-12 15:37:17.319610
# Unit test for method validate of class Not
def test_Not_validate():
    kwargs = { "allow_null": False }
    errors = { "negated": "Must not match." }
    field = Not(Number(), **kwargs)
    field.field_name = "field"
    field.errors = errors
    value = 1000
    strict = False
    try:
        field.validate(value, strict)
    except Exception as ex:
        if str(ex) != "{'field': ['Must not match.']}":
            return False
    return True


# Generated at 2022-06-12 15:37:22.695475
# Unit test for method validate of class Not
def test_Not_validate():
    class TestNot(Not):

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.errors = {"negated": "Must not match."}

    negated = TestNot(None)
    x = TestNot(negated)
    x.validate(0)

    # Error is not raised
    assert True



# Generated at 2022-06-12 15:37:42.112285
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()


# Generated at 2022-06-12 15:37:45.396281
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:37:46.861516
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    def_NeverMatch = NeverMatch()
    assert def_NeverMatch.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:37:48.552148
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field.errors, dict)
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:37:50.985347
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.label == 'Never match'
    assert field.help_text == ''
    assert field.required == False
    assert field.allow_none == True
    assert field.allow_coerce == False
    assert field.allow_empty == True



# Generated at 2022-06-12 15:37:52.027544
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match.errors["never"] == "This never validates."


# Generated at 2022-06-12 15:37:52.824062
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert isinstance(x, NeverMatch)

# Generated at 2022-06-12 15:37:55.778617
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from json import dumps
    from typesystem.errors import ErrorTree
    f = NeverMatch()
    assert f.validate('ab') == ErrorTree()
    assert f.validate('ab').serialize() == f.errors['never']


# Generated at 2022-06-12 15:37:56.312566
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    pass


# Generated at 2022-06-12 15:37:57.714299
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    try:
        assert (a.validate(1) == "default")
    except AssertionError as e:
        print("Assertion error catch NeverMatch")
        return
    assert (False)
