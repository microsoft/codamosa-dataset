

# Generated at 2022-06-12 15:28:47.124396
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf([Any()], 'description')
    assert o

# Generated at 2022-06-12 15:28:49.572662
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String(), nullable=True)
    assert not_field.validate('not') is None
    assert not_field.validate(12) is 12
    assert not_field.validate(None) is None


# Generated at 2022-06-12 15:28:51.911350
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()


# Generated at 2022-06-12 15:29:00.035832
# Unit test for method validate of class Not
def test_Not_validate():

    def test_func_1():
        print("这是一个测试方法")

    content = {
        "a": 1,
        "b": 2,
        "c": 3
    }

    # 这里执行报错
    # not_schema = Not({"type": "dict"})

    # 这里执行ok
    not_schema = Not({"type": "list"})

    try:
        not_schema.validate(content)
        print("ok, 就是我要的结果")
    except Exception as e:
        print("出错了！！！")
        raise e

# Generated at 2022-06-12 15:29:05.961956
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Testing when error is None
    IfThenElse = IfThenElse(if_clause=True, then_clause=True, else_clause=False)
    assert True == IfThenElse.validate(True)

    # Testing when error is not None
    IfThenElse = IfThenElse(if_clause=False, then_clause=False, else_clause=True)
    assert True == IfThenElse.validate(True)

# Generated at 2022-06-12 15:29:06.997400
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(name="field1")
    assert field.name == "field1"


# Generated at 2022-06-12 15:29:11.357889
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestField1(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "TEST"

    class TestField2(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "TEST"

    class TestField3(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "TEST"

    field = IfThenElse(TestField1(), TestField2(), TestField3())
    r1 = field.validate("AA")
    assert r1 == "TEST"
    field = IfThenElse(TestField1(), TestField2())
    r2 = field.validate("BB")
    assert r2 == "TEST"

# Generated at 2022-06-12 15:29:13.600694
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(negated=not_)
    assert not_.validate(value = [1])
    assert not_.validate(value = 'True')

# Generated at 2022-06-12 15:29:18.761775
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    obj = OneOf(one_of=[Int(), String()])
    value = '1'
    strict = False

    # Act
    result = obj.validate(value, strict)

    # Assert
    assert result == '1'


# Generated at 2022-06-12 15:29:30.786685
# Unit test for method validate of class OneOf
def test_OneOf_validate():
     # First test: one_of: [Boolean(), Integer()]
     # Expectation: Boolean(False)
     field = OneOf([Boolean(), Integer()])
     value = False
     expected = value
     validated = field.validate(value)
     assert validated == expected



     # Second test: one_of: [Boolean(), Integer()]
     # Expectation: Integer(42)
     field = OneOf([Boolean(), Integer()])
     value = 42
     expected = value
     validated = field.validate(value)
     assert validated == expected



     # Third test: one_of: [Boolean(), Integer()]
     # Expectation: error
     field = OneOf([Boolean(), Integer()])
     value = "yes"

# Generated at 2022-06-12 15:29:38.146693
# Unit test for method validate of class Not
def test_Not_validate():
    # assert math.isclose(expected, Not.validate(self, value, strict=strict))
    assert True # TODO: implement your test here


# Generated at 2022-06-12 15:29:46.522910
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse(if_clause=str,then_clause=int,else_clause=float)
    a.validate("1")
    a.validate("0")
    a.validate("-5")
    a.validate("1.1")
    a.validate("0.0")
    a.validate("-5.5")
    a.validate("12345678901234567890")
    with pytest.raises(ValueError):
        a.validate("abc")
    with pytest.raises(ValueError):
        a.validate("1,")
    with pytest.raises(ValueError):
        a.validate("1,1")
    with pytest.raises(ValueError):
        a.validate("1.1.")

# Generated at 2022-06-12 15:29:49.540473
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([Any(), Any()])
    assert field.all_of == [Any(), Any()]
    assert field.errors == {}
    assert field.allow_null == False


# Generated at 2022-06-12 15:29:55.828454
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Person:
        first_name = "joe"
        age = 30

    if_clause = Field(type=str)
    then_clause = Field(type=int)
    else_clause = Field(type=str)
    conditional_field = IfThenElse(if_clause, then_clause, else_clause)
    assert conditional_field.validate(Person.first_name) == str(Person.first_name)
    assert conditional_field.validate(Person.age) == int(Person.age)



# Generated at 2022-06-12 15:30:01.388231
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import pytest
    from typesystem.fields import Integer

    if_clause = Integer()
    then_clause = Integer()
    else_clause = Integer()

    field = IfThenElse(if_clause, then_clause, else_clause)
    with pytest.raises(ValueError) as e:
        field.validate(7)
    assert "Validation error for" in str(e)

# Generated at 2022-06-12 15:30:10.349249
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Boolean, Integer

    field = OneOf([Boolean(), Integer()])
    assert field.validate(True) == True
    assert field.validate(1) == 1
    assert field.validate(1.5) == 1
    assert field.validate('1') == 1
    assert field.validate(None) == None

    try:
        field.validate('string')
        assert False
    except:
        assert True

        
    field = OneOf([Boolean(), Integer()], allow_null=True)
    assert field.validate(True) == True
    assert field.validate(1) == 1
    assert field.validate(1.5) == 1
    assert field.validate('1') == 1
    assert field.validate(None) == None
    

# Generated at 2022-06-12 15:30:15.529123
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Unit test for method validate of class Not
    """
    from typesystem import Boolean
    N = Not(Boolean())
    try:
        N.validate(True)
        raise Exception('Unit test Not failed')
    except:
        print('Unit test Not succeeded')


test_Not_validate()

# Generated at 2022-06-12 15:30:16.846832
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	assert False # TODO: implement your test here


# Generated at 2022-06-12 15:30:18.114857
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = OneOf(one_of = [])
    assert a.validate(None) == None


# Generated at 2022-06-12 15:30:24.361414
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    for i in range(10):
        field = NeverMatch(name='name')
        assert field.name == 'name'
        assert field.errors == {'never': 'This never validates.'}
        assert field.allow_null == False
        assert field.is_list == False
        assert field.regex == None
        assert field.label == None
        assert field.description == None


# Generated at 2022-06-12 15:30:34.169982
# Unit test for method validate of class Not
def test_Not_validate():
    # Позитивный тест
    res = Not(Field()).validate(None)
    assert res == None
    # Негативный тест
    err = None
    try:
        Not(Field()).validate(1)
    except ValueError as e:
        err = e
    assert err is not None
    assert str(err) == 'Must not match.'



# Generated at 2022-06-12 15:30:37.755022
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    print("\ntest_IfThenElse_validate")
    myField = IfThenElse(Not(String()),String(),Integer())
    myField.validate("3")
    print("test_IfThenElse_validate")

if __name__ == "__main__":
    test_IfThenElse_validate()

# Generated at 2022-06-12 15:30:43.807767
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field1 = Int(clamp_to_min=10, clamp_to_max=20)
    field2 = String(min_length=3, max_length=15, strip_whitespace=True)
    field3 = List(String(min_length=3, max_length=15, strip_whitespace=True), min_length=1, max_length=None)
    field = OneOf([field1, field2, field3])

    # test 1: ["a", "b", "c"] - correct
    value = ["a", "b", "c"]
    result = field.validate(value)
    assert result == value

    # test 2: 20 - correct
    value = 20
    result = field.validate(value)
    assert result == value

    # test 3: "abc" - correct
    value

# Generated at 2022-06-12 15:30:45.310227
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Number(), String())



# Generated at 2022-06-12 15:30:50.965437
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
  assert IfThenElse(if_clause=True, then_clause=True, else_clause=True).if_clause == True
  assert IfThenElse(if_clause=True, then_clause=True, else_clause=True).then_clause == True
  assert IfThenElse(if_clause=True, then_clause=True, else_clause=True).else_clause == True


# Generated at 2022-06-12 15:30:55.707942
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # ====== test 0 ======
    valid_value = True
    schema = OneOf([Boolean()]).validate(valid_value) # should not raise error
    assert schema == valid_value # type: ignore
    # ====== test 1 ======
    invalid_value = False
    try:
        OneOf([Boolean()]).validate(invalid_value)
    except ValidationError as e:
        assert e.message == "Did not match any valid type." # type: ignore
        assert e.code == "no_match" # type: ignore
        assert e.field == ("$",) # type: ignore
    else:
        assert False # type: ignore
    # ====== test 2 ======
    valid_value = False
    schema = OneOf([Boolean(), Boolean()]).validate(valid_value) # should not raise error

# Generated at 2022-06-12 15:31:02.817699
# Unit test for method validate of class Not
def test_Not_validate():
    """
    this unit test is to test method validate of class Not,
    which is invalid when negated is also valid.
    """
    ex = typesystem.Exception
    instance_string = typesystem.String()
    instance_not = Not(instance_string, description="This should be string")

    val_1 = "valid string"
    val_2 = 1
    val_3 = "invalid null"
    val_4 = []

    error = False
    try:
        instance_not.validate(val_1)
    except ex:
        error = True
    assert error

    error = False
    try:
        instance_not.validate(val_2)
    except ex:
        error = True
    assert error

    error = False

# Generated at 2022-06-12 15:31:09.693315
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    my_if = Not(NeverMatch())
    my_then = Field(required='True', description="Value is 4")
    my_else = Field(required='True', description="Value is not 4")
    my_IfThenElse = IfThenElse(my_if, my_then, my_else)
    assert my_IfThenElse.validate(4)
    assert my_IfThenElse.validate("a")
    assert not my_IfThenElse.validate("4")


# Generated at 2022-06-12 15:31:12.984385
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(None)
    try:
        not_field.validate(1)
    except Not.validation_error as e:
        assert e.code == "negated"

# Generated at 2022-06-12 15:31:21.204882
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Integer())
    assert not_field.validate(1) == 1
    not_field = Not(Integer())
    assert not_field.validate('1') == '1'
    not_field = Not(String())
    assert not_field.validate(2) == 2
    not_field = Not(String())
    assert not_field.validate(1.0) == 1.0
    not_field = Not(String())
    assert not_field.validate('1.0') == '1.0'
    not_field = Not(String())
    assert not_field.validate(True) == True
    not_field = Not(String())
    assert not_field.validate(False) == False
    not_field = Not(String())

# Generated at 2022-06-12 15:31:35.782291
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Case 1.1
    if_clause = String()
    then_clause = String()
    else_clause = String()
    myfield = IfThenElse(if_clause, then_clause, else_clause)
    myvalue = "a"
    myfield.validate(myvalue)

    # Case 1.2
    if_clause = String()
    then_clause = Integer()
    else_clause = String()
    myfield = IfThenElse(if_clause, then_clause, else_clause)
    myvalue = "a"
    myfield.validate(myvalue)

    # Case 2
    if_clause = String()
    then_clause = String()
    else_clause = Integer()

# Generated at 2022-06-12 15:31:36.312935
# Unit test for constructor of class Not
def test_Not():
    assert Not.__init__

# Generated at 2022-06-12 15:31:42.550609
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Boolean(), String()])
    field.validate(True)
    field.validate("hi")
    with pytest.raises(ValidationError) as excinfo:
        field.validate(0)
    assert excinfo.value.error_code == 'no_match'
    with pytest.raises(ValidationError) as excinfo:
        field.validate(0)
    assert excinfo.value.error_code == 'no_match'
    with pytest.raises(ValidationError):
        field.validate(None)


# Generated at 2022-06-12 15:31:47.989518
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Initialization
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    ite = IfThenElse(if_clause, then_clause, else_clause)
    value = 42
    strict = False

    # Run method
    result = ite.validate(value, strict)
    assert result == 42


# Generated at 2022-06-12 15:31:49.705267
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated={"type": "string"})
    print(field.negated)


# Generated at 2022-06-12 15:31:55.339704
# Unit test for constructor of class AllOf
def test_AllOf():
    # Create a AllOf object
    obj1 = AllOf(all_of=[])
    # Accessing its fields
    assert obj1.all_of == []
    assert obj1.nullable is False
    assert obj1.input_schema() == {}
    assert obj1.output_schema() == {}
    # Accessing unreachable fields
    try:
        obj1.unreachable_field
    except AttributeError:
        pass
    else:
        assert False, "unreachable_field should not exist"
    # Calling its methods
    # classmethod from_json
    obj2 = AllOf.from_json({})
    assert obj2.all_of == []
    # set_value
    obj3 = AllOf(all_of=[])
    obj3.set_value([])
    # validate

# Generated at 2022-06-12 15:31:58.036119
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch(allow_null=True)
        return False
    except:
        return True


# Generated at 2022-06-12 15:32:01.784903
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = 1
    strict = True
    i = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    result = i.validate(value=value, strict=strict)
    assert result == value

# Generated at 2022-06-12 15:32:06.843349
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    def validate():    
        schema = OneOf([Dict({'a': Int()}), Dict({'b': Int()})])
        pass_value = {'a': 5}
        fail_value = {'c': 5}
        try:
            schema.validate(pass_value)
        except Exception:
            assert False
        try:
            schema.validate(fail_value)
            assert False
        except JSONSchemaValidationError:
            raise

# Generated at 2022-06-12 15:32:08.000932
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String

    a = OneOf([String()])
    print(a)

# Generated at 2022-06-12 15:32:13.291171
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    fields = NeverMatch()
    assert str(fields) == 'NeverMatch()'
    assert fields.to_primitive() == {"type": "never_match"}


# Generated at 2022-06-12 15:32:13.878756
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-12 15:32:18.156208
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([])

    value = 1
    strict = True
    one_of.validate(value, strict)

    one_of = OneOf([])

    value = 1
    strict = False
    one_of.validate(value, strict)


# Generated at 2022-06-12 15:32:26.985787
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    def test_validate(field: IfThenElse) -> None:
        # Check normal validation
        field.validate(42)

        # Check else_clause is handled
        field.validate(10)

        # Check validation error
        try:
            field.validate(True)
        except field.validation_error:
            pass # expected
        else:
            assert False # fail

    test_validate(IfThenElse(Integer(gte=42), Integer(gte=100), Integer(gte=50)))
    test_validate(IfThenElse(Integer(gte=42), Integer(gte=100)))
    test_validate(IfThenElse(Integer(gte=42), else_clause=Integer(gte=50)))

# Generated at 2022-06-12 15:32:28.046778
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert True

# Generated at 2022-06-12 15:32:39.029656
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Test validate and validate_or_error methods of OneOf class
    """
    import typesystem
    class MyStrField(typesystem.String):
        __type_name__ = 'MyStrField'
        def get_value(self, value):
            return value + ' <get_value>'
        def set_value(self, value):
            return value + ' <set_value>'
    class MyIntField(typesystem.Int):
        __type_name__ = 'MyIntField'
        def get_value(self, value):
            return value + 5
        def set_value(self, value):
            return value + 5
    myStrField = MyStrField()
    myIntField = MyIntField()
    oneOf = OneOf([myStrField, myIntField])
    assert oneOf.validate

# Generated at 2022-06-12 15:32:44.074369
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer, String
    # Test that the constructor is working
    assert OneOf([String(), Integer()]).one_of[0].__class__.__name__ == 'String'
    # Test that the constructor is working
    assert OneOf([String(), Integer()]).one_of[1].__class__.__name__ == 'Integer'

# Generated at 2022-06-12 15:32:46.189285
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test if constructor of class NeverMatch works
    try:
        assert NeverMatch(key="NeverMatch") is not None
    except:
        assert False
        

# Generated at 2022-06-12 15:32:47.827953
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
    except AssertionError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:32:51.140203
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_name = 'NeverMatch'
    # Testing the constructor of class NeverMatch
    print('Testing the constructor of class ' + test_name)
    test = NeverMatch(field_name='never')
    assert test.name == 'never' , 'Expected field_name to be "never"'
    assert test.errors == {'never': 'This never validates.'} , 'Expected a not match error'



# Generated at 2022-06-12 15:33:05.516280
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # test_OneOf_validate_0
    #   Field one_of: type list
    #   test_neither_errors
    #   test_match_only_once
    #   test_matches_more_than_once
    #   test_matches_doesnt_match
    field = OneOf(one_of=[Integer(), Integer()])
    matches = [
        {},
        {"a": 1},
        {"a": "1"},
        {"a": 1.0},
        {"a": -1},
        {"a": "one"},
        {"a": [1]},
        {"a": {"a": 1}},
    ]

# Generated at 2022-06-12 15:33:10.198197
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Number(), Integer()])
    assert field.validate(1) == 1
    try:
        field.validate('test')
        assert False
    except ValidationError:
        assert True
    try:
        field.validate(0.5)
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-12 15:33:17.707508
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class MyClass: 
        def __init__(self,name):
            self.name = name
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    a = "John"
    b = MyClass(a)
    test_obj = IfThenElse(if_clause, then_clause, else_clause)
    assert test_obj.validate(a) == a
    assert test_obj.validate(b) == b

# Generated at 2022-06-12 15:33:26.607432
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import typing
    type_list = [int, str]
    # test string
    str_ = "abcd"
    for field in type_list:
        if field == str:
            assert OneOf(one_of = [field]).validate(str_) == str_
            break
    # test int
    num = 1
    for field in type_list:
        if field == int:
            assert OneOf(one_of = [field]).validate(num) == num
            break
    # test string and int
    try:
        OneOf(one_of = [int, str]).validate(num+str_)
    except Exception as e:
        assert(str(e) == '"multiple_matches"')
    # test string in int

# Generated at 2022-06-12 15:33:28.770345
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import BooleanField
    class F(BooleanField):
        pass
    myfield = F()
    field = Not(myfield)
    assert field.negated == myfield

# Generated at 2022-06-12 15:33:30.654184
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    assert AllOf([String(), String()])

# Generated at 2022-06-12 15:33:31.637663
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print("test_OneOf_validate")
    field = Field()

# Generated at 2022-06-12 15:33:40.611991
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # define the test cases
    t1 = IfThenElse(Integer())
    t2 = IfThenElse(Integer(), then_clause=Integer())
    t3 = IfThenElse(Integer(), else_clause=Integer())
    t4 = IfThenElse(Integer(), then_clause=Integer(), else_clause=Integer())
    t5 = IfThenElse(Integer(), then_clause=Integer(), else_clause=String())


    # test case 1
    actual = t1.validate(None)
    assert actual == None, actual

    # test case 2
    actual = t2.validate(None)
    assert actual == None, actual

    # test case 3
    actual = t3.validate(None)
    assert actual == None, actual

    # test case 4

# Generated at 2022-06-12 15:33:45.781744
# Unit test for constructor of class OneOf
def test_OneOf():
    class Foo:
        pass
    def run_test():
        try:
            field = OneOf([Foo()])
        except AssertionError:
            return False
        if field.one_of[0].__class__.__name__ == "Foo":
            return True
        return False
    assert run_test()


# Generated at 2022-06-12 15:33:50.338546
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import typesystem
    # Create a field with a name and parse as integer
    # If number > 0 then return the number, else return 0

# Generated at 2022-06-12 15:33:56.168618
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match.errors["never"] == "This never validates."


# Generated at 2022-06-12 15:33:57.755748
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        Any(),
            Any(),
    ])
    assert field.validate(1)

# Generated at 2022-06-12 15:33:58.980740
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(None)
    assert not_field != None


# Generated at 2022-06-12 15:34:03.709866
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Testing with success
    IfThenElse(Int(), Int()).validate(1)
    # Testing with failure
    try:
        IfThenElse(Int(), Int()).validate("1")
        raise AssertionError("The previous line should have raised a ValidationError")
    except ValidationError:
        pass


# Generated at 2022-06-12 15:34:11.197124
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    import json
    # if_clause that always match

# Generated at 2022-06-12 15:34:13.100532
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([Integer()])
    assert a.all_of == [Integer()]


# Generated at 2022-06-12 15:34:18.044589
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    data = [{'type': 'oneOf',
             'one_of': [{'type': 'number'}, {'type': 'string'}]},
            {'type': 'oneOf',
             'one_of': [{'type': 'number'}, {'type': 'string'}]},
            {'type': 'oneOf',
             'one_of': [{'type': 'number'}, {'type': 'string'}]}]
    data_value = ['123', 123, None]
    # data_value = ['123', 123, None]
    # data_value = '123'
    # data = [{'type': 'number'}, {'type': 'string'}]
    # data_value = '123'
    for i in range(3):
        print(data_value[i])

# Generated at 2022-06-12 15:34:21.896179
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    neverMatch = NeverMatch()
    assert isinstance(neverMatch, Field)



# Generated at 2022-06-12 15:34:22.693209
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x

# Generated at 2022-06-12 15:34:28.478439
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    r = OneOf([Str(), Bool()]).validate("1")
    assert r == "1"

    r = OneOf([Str(), Bool()]).validate(True)
    assert r == True

    with pytest.raises(ValidationError):
        OneOf([Str(), Bool()]).validate(1)

    with pytest.raises(ValidationError):
        OneOf([Str(), Bool()]).validate(1.1)

    with pytest.raises(ValidationError):
        OneOf([Str(), Bool()]).validate({})

    with pytest.raises(ValidationError):
        OneOf([Str(), Bool()]).validate([])


# Generated at 2022-06-12 15:34:35.837103
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse('abc', 'then', 'else')
    except AssertionError:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:34:40.960027
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f1 = Any()
    f2 = Integer()

    x = IfThenElse(f1,f2)
    assert x.validate("as") == "as"
    assert x.validate(2) == 2

    x = IfThenElse(f2,f1)
    assert x.validate("as") == "as"
    assert x.validate(2) == 2

# Generated at 2022-06-12 15:34:41.793485
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nev = NeverMatch()


# Generated at 2022-06-12 15:34:44.662704
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test AllOf(all_of: typing.List[Field], **kwargs: typing.Any) -> None
    # 1. Call function with None value as input
    all_of = AllOf(all_of=None)
    # Verify
    assert all_of is not None


# Generated at 2022-06-12 15:34:50.948442
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String
    one_of = OneOf([
        String(max_length=1),
        Integer(),
    ])
    assert one_of.validate("X") == "X"
    assert one_of.validate(123) == 123
    try:
        one_of.validate(True)
    except Exception as e:
        assert str(e) == one_of.errors["no_match"]



# Generated at 2022-06-12 15:34:53.453036
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().description is None
    assert NeverMatch().errors == {"never": "This never validates."}
    assert NeverMatch().name == "nevermatch"
    assert NeverMatch().format == None


# Generated at 2022-06-12 15:34:56.662431
# Unit test for constructor of class AllOf
def test_AllOf():
    schema = AllOf([Integer(), String()])
    assert schema.validate("1") == "1"
    with raises(ValidationError):
        schema.validate(1)
    with raises(ValidationError):
        schema.validate("hello")



# Generated at 2022-06-12 15:35:04.338896
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    base_int = Int(name="base_int")
    base_str = Str(name="base_str")
    base_obj = [base_int, base_str]
    base_then = IfThenElse(base_int, base_str)
    base_then2 = IfThenElse(base_int)
    assert base_then.validate("123") == "123"
    assert base_then2.validate("123") == "123"
    base_else = IfThenElse(base_int, base_then, base_then)
    assert base_else.validate("123") == "123"
    try:
        base_then.validate("123a")
    except ValidationError as ve:
        assert ve.value == "123a"

# Generated at 2022-06-12 15:35:07.852916
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse(if_clause=Field(required=True), then_clause=Field(required=True))
    except Exception:
        assert False
        return
    assert True

# Generated at 2022-06-12 15:35:13.776047
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
 
    # Sample test case 2
    expected =  {'validate': 'This never validates.'}
    actual = NeverMatch().errors
    assert (expected == actual)
    # Sample test case 2
    expected = {'validate': 'This never validates.'}
    actual = NeverMatch().errors
    assert (expected == actual)

# Generated at 2022-06-12 15:35:31.398657
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[
        Integer(),
        String()
    ])
    #
    # Positive cases
    #
    #Case1:
    value = json.dumps([2, 3])
    strict = True
    field.validate(value, strict)
    #Case2:
    value = json.dumps([2, 3])
    strict = False
    field.validate(value, strict)
    #
    # Negative cases
    #
    #Case1:
    value = json.dumps([2, "hello"])
    try:
        field.validate(value, strict)
        assert False
    except:
        assert True
    #Case2:
    value = json.dumps([2, "hello"])

# Generated at 2022-06-12 15:35:33.648347
# Unit test for constructor of class AllOf
def test_AllOf():
    class AllOfTest(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    all_of_field = AllOf([AllOfTest(), AllOfTest()])
    assert all_of_field


# Generated at 2022-06-12 15:35:35.655999
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Int(), Float()])
    test_value = 3.3
    field.validate(test_value)


test_OneOf_validate()


# Generated at 2022-06-12 15:35:41.554352
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    #Arrange
    one_of = ['1','2','3']
    test_field = OneOf(one_of)
    value = '1'
    #Act
    actual = test_field.validate(value)
    #Assert 
    assert actual == '1'


# Generated at 2022-06-12 15:35:42.649542
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
    except:
        assert False


# Generated at 2022-06-12 15:35:47.578537
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    integer = Integer()
    if_clause = integer
    then_clause = integer
    else_clause = integer
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(5) == 5
    assert if_then_else.validate("5") == "5"

# Generated at 2022-06-12 15:35:49.953079
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    A = NeverMatch()
    with pytest.raises(SystemExit):
        raise A.validation_error("never")


# Generated at 2022-06-12 15:35:53.097739
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=typesystem.String(),
        then_clause=typesystem.Integer(),
        else_clause=typesystem.Boolean()
    )

    assert field.validate('foo') == 0
    assert field.validate(0.0) == True

# Generated at 2022-06-12 15:35:57.502799
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = lambda value: len(value) > 1
    then_clause = int
    else_clause = str

    validate_object = IfThenElse(if_clause, then_clause, else_clause)
    assert validate_object.validate("2") == "2"
    assert validate_object.validate("data") == "data"
    assert validate_object.validate(12) == 12

# Generated at 2022-06-12 15:35:58.181069
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch


# Generated at 2022-06-12 15:36:16.239821
# Unit test for constructor of class AllOf
def test_AllOf():
    # A fairly simple test of the AllOf constructor
    test_object = AllOf([1,2,3,4,5,6,7,8,9,10])
    assert test_object.all_of == [1,2,3,4,5,6,7,8,9,10]


# Generated at 2022-06-12 15:36:24.922192
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Types.Object({"name": Types.String()})
    then_clause = Types.Object({"age": Types.Integer()})
    else_clause = Types.Object({"sex": Types.String()})
    field = Types.IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    assert field.validate({"name": "John", "age": 28}) == {"name": "John", "age": 28}
    assert field.validate({"name": "John", "sex": "male"}) == {"name": "John", "sex": "male"}

# Generated at 2022-06-12 15:36:31.419275
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class MyField(Field):
        def validate_then(self, value: typing.Any, strict: bool = False) -> typing.Any:
            print("my_field then")
            return value

        def validate_else(self, value: typing.Any, strict: bool = False) -> typing.Any:
            print("my_field else")
            return value

    a = MyField()
    b = IfThenElse(a, else_clause=a)
    c = IfThenElse(a, then_clause=a)
    assert b.validate("a") == "a"
    assert c.validate("a") == "a"

# Generated at 2022-06-12 15:36:35.884293
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    t1 = IfThenElse(if_clause=None, then_clause=None,else_clause=None)
    t2 = IfThenElse(if_clause=None, then_clause=None)
    t3 = IfThenElse(if_clause=None, else_clause=None)
    t4 = IfThenElse(if_clause=None)
    assert t1.validate(None) == None
    assert t2.validate(None) == None
    assert t3.validate(None) == None
    assert t4.validate(None) == None

    assert t1.validate("word") == "word"
    assert t2.validate("word") == "word"
    assert t3.validate("word") == "word"
    assert t4.validate("word")

# Generated at 2022-06-12 15:36:41.797970
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def method_IfThenElse_validate(name):
        assert name == "David"
    class mockClass_IfThenElse():
        def __init__(self, mockVariable):
            self.name = mockVariable
    mock_IfThenElse = mockClass_IfThenElse("David")
    mock_IfThenElse.validate = method_IfThenElse_validate
    mock_IfThenElse.validate()



# Generated at 2022-06-12 15:36:52.375186
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # set up fields
    iffield = String(required = True, min_length = 1)
    thenfield = String(required = True, min_length = 2)
    elsefield = String(required = True, min_length = 3)
    ifthenelsefield = IfThenElse(if_clause = iffield, then_clause = thenfield, else_clause = elsefield)
    # test when clause matches
    value = 'a'
    result, error = ifthenelsefield.validate_or_error(value)
    # result should be value itself
    assert result == value
    # test when clause does not match
    value = 'aaa'
    result, error = ifthenelsefield.validate_or_error(value)
    # result should be value itself
    assert result == value

test_IfThenElse_validate

# Generated at 2022-06-12 15:36:58.996589
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(then_clause=Any()).validate(None) is None
    assert IfThenElse(then_clause=False).validate(None) is None
    assert IfThenElse(if_clause=False, else_clause=Any()).validate(None) is None
    assert IfThenElse(if_clause=False, then_clause=Any()).validate(None) is None
    assert IfThenElse(if_clause=False, then_clause=False).validate(None) is None
    assert IfThenElse(if_clause=True, then_clause=False).validate(None) is False

# Generated at 2022-06-12 15:37:01.514680
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(
        lambda value, strict: (value, None),
        lambda value, strict: (value, None),
        lambda value, strict: (value, None),
        ).validate(1) == 1

# Generated at 2022-06-12 15:37:07.194738
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Schema
    import unittest
    import uuid

    class Person(Schema):
        name = String()

    class PersonAllOf(Schema):
        all_of = AllOf(Person())

    person = PersonAllOf({"name": "Eric Idle"})
    assert person.is_valid()

    person = PersonAllOf({"name": 42})
    with unittest.TestCase().assertRaises(TypeError):
        person.is_valid()

    person = PersonAllOf({"name": "Eric Idle", "age": 42})
    with unittest.TestCase().assertRaises(TypeError):
        person.is_valid()



# Generated at 2022-06-12 15:37:15.007474
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_field = IfThenElse(String())
    assert test_field.validate('a') == 'a'

    test_field = IfThenElse(String())
    assert test_field.validate(1) == 1

    test_field = IfThenElse(String(), then_clause=Integer())
    assert test_field.validate('a') == 'a'

    test_field = IfThenElse(String(), then_clause=Integer())
    assert test_field.validate(1) == 1

    test_field = IfThenElse(String(), then_clause=Integer())
    assert test_field.validate('a') == 'a'

    test_field = IfThenElse(String(), then_clause=Integer())
    assert test_field.validate(1) == 1


# Generated at 2022-06-12 15:37:56.155351
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = Field()
    if_clause = IfThenElse(a, then_clause=a, else_clause=a)
    assert if_clause.validate(1) == 1

# Generated at 2022-06-12 15:37:58.437708
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Any(), Any()).validate(1) == 1



# Generated at 2022-06-12 15:38:02.408857
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    conditional_field = IfThenElse(
        if_clause=None,
        then_clause=None,
        else_clause=None,
    )
    conditional_field.validate(None)
    assert True

# Generated at 2022-06-12 15:38:05.720351
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf(one_of=[Integer(), String()])
    assert (field.validate(123) == 123)

    field = OneOf(one_of=[Integer(), String()])
    assert (field.validate("123") == "123")


# Generated at 2022-06-12 15:38:15.233086
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Vehicle(Field):
        pass
    class Car(Field):
        pass
    class Truck(Field):
        pass
    class Motorcycle(Field):
        pass
    class Person(Field):
        pass

    car = Car(name="vehicles")
    vehicle = Vehicle(name="vehicle", subtypes=[car])

    truck = Truck(name="vehicles")
    vehicle = Vehicle(name="vehicle", subtypes=[truck])

    motorcycle = Motorcycle(name="vehicles")
    vehicle = Vehicle(name="vehicle", subtypes=[motorcycle])

    person = Person(name="person")
    IFE = IfThenElse(if_clause=person, then_clause=vehicle, else_clause=vehicle)

    # person should pass validation

# Generated at 2022-06-12 15:38:16.108002
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n.errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:38:18.135776
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = AllOf([Boolean()])
    then_clause = Boolean()
    else_clause = Boolean()
    value = False
    strict = False
    obj = IfThenElse(if_clause, then_clause, else_clause)
    res = obj.validate(value, strict)
    assert res == False

# Generated at 2022-06-12 15:38:21.186832
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Boolean, Integer, String

    field = IfThenElse(Boolean(), Integer(), String())
    field.validate(True)
    field.validate(False)
    field.validate(None, strict=True)
    field.validate(True, strict=True)
    field.validate(False, strict=True)

# Generated at 2022-06-12 15:38:22.962743
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert 1 == IfThenElse(IfThenElse(
        1,
        then_clause=1,
        else_clause=0
    )).validate(1)


# Generated at 2022-06-12 15:38:24.606959
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    ite = IfThenElse(if_clause, then_clause, else_clause)
    ite.validate(1)