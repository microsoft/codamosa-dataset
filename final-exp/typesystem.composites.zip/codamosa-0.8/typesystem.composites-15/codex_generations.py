

# Generated at 2022-06-12 15:28:38.604703
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String(min_length=1))
    assert field.validate(1) == 1


# Generated at 2022-06-12 15:28:45.577457
# Unit test for constructor of class Not
def test_Not():
    import pytest
    from typesystem.exceptions import ValidationError
    from typesystem.fields import (
        Array,
        Boolean,
        Integer,
        NeverMatch,
        Number,
        Object,
        String,
    )
    not_object = Not(Object())
    with pytest.raises(ValidationError) as exc:
        not_object.validate({"message": "yes"})
    assert "negated" in str(exc.value)
    assert not_object.validate(5) == 5

    not_string = Not(String())
    with pytest.raises(ValidationError) as exc:
        not_string.validate("hello")
    assert "negated" in str(exc.value)
    assert not_string.validate(7) == 7

    not_array = Not

# Generated at 2022-06-12 15:28:49.400092
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated = Field({}))
    assert not_field.errors == {"negated": "Must not match."}
    assert not_field.negated == Field({})
    assert not_field.validate(11) == 11
    pass


# Generated at 2022-06-12 15:28:54.211243
# Unit test for method validate of class Not
def test_Not_validate():
    field_not = Not(Integer())
    assert field_not.validate("5") == 5
    assert field_not.validate("5") != "5"
    with pytest.raises(ValidationError):
        field_not.validate(5)



# Generated at 2022-06-12 15:29:01.567694
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class If(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class Then(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class Else(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    # testing new If of IfThenElse
    b = If()
    b.validate(value=1, strict=True)
    b.validate(value=1, strict=False)

    # testing new Then of IfThenElse
    c = Then()
    c.validate(value=1, strict=True)
    c.validate(value=1, strict=False)

    #

# Generated at 2022-06-12 15:29:02.899795
# Unit test for constructor of class Not
def test_Not():
    assert Not(Any(), **{}) is not None


# Generated at 2022-06-12 15:29:12.757114
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # 1. True
    operator = IfThenElse(Boolean(), Integer(), Integer())
    assert operator.validate(True) == 0
    assert operator.validate(False) == 0

    # 2. False
    operator = IfThenElse(Boolean(), Integer(), Integer())
    assert operator.validate(True) == 0
    assert operator.validate(False) == 0

    # 3. None
    operator = IfThenElse(Boolean(), Integer(), Integer())
    assert operator.validate(True) == 0
    assert operator.validate(False) == 0

    # 4. "0"
    operator = IfThenElse(Boolean(), Integer(), Integer())
    assert operator.validate(True) == 0
    assert operator.validate(False) == 0

    # 5. "1"

# Generated at 2022-06-12 15:29:22.155317
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Then
    then = AllOf([String(), Length(max_length=3)])
    # If
    if_cl = String()
    # Else
    else_cl = Email()
    # IfThenElse
    ifthenelse = IfThenElse(if_clause=if_cl, then_clause=then, else_clause=else_cl)
    # test then_clause
    assert ifthenelse.validate("abc") == "abc"
    # test else_clause
    assert ifthenelse.validate("aaa@bbb.com") == "aaa@bbb.com"

# Generated at 2022-06-12 15:29:24.634074
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Int, then_clause=Int)
    assert field.validate(1) == 1
    # assert field.validate("1") == 1



# Generated at 2022-06-12 15:29:35.379971
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(Integer(), String()).validate(1)
    # IfThenElse(Integer(), String()).validate("xx")
    IfThenElse(Integer(), String()).validate(2)
    # IfThenElse(String(), Integer()).validate(1)
    IfThenElse(String(), Integer()).validate("2")
    if_clause = Integer()
    then_clause = String()
    else_clause = Boolean()
    IfThenElse(if_clause, then_clause).validate(1)
    # IfThenElse(Integer(), String(), Boolean()).validate("1")
    IfThenElse(if_clause, then_clause, else_clause).validate(True)


# Generated at 2022-06-12 15:29:41.238621
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[Int(), Str()])
    assert field.one_of == [Int(), Str()]
    assert field._options == {'formats': [], 'one_of': [Int(), Str()]}


# Generated at 2022-06-12 15:29:43.460370
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(), String(), Null())
    assert field.validate("test") == "test"
    assert field.validate(1) is None

# Generated at 2022-06-12 15:29:44.923977
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    my_field = IfThenElse(if_clause=Field, then_clause=Any(), else_clause=Any())

# Generated at 2022-06-12 15:29:47.492103
# Unit test for constructor of class Not
def test_Not():
    f1 = Field()
    n = Not(f1)
    assert n.negated


# Generated at 2022-06-12 15:29:54.817626
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import typesystem
    schema = typesystem.OneOf(one_of=[typesystem.Integer(), typesystem.String()])
    assert schema.validate(0) == 0
    assert schema.validate("1") == "1"
    try:
        schema.validate({})
        assert False
    except typesystem.ValidationError as e:
        assert e.detail["code"] == "no_match"
    try:
        schema.validate(0.0)
        assert False
    except typesystem.ValidationError as e:
        assert e.detail["code"] == "multiple_matches"


# Generated at 2022-06-12 15:29:55.350090
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print(NeverMatch())


# Generated at 2022-06-12 15:29:56.594767
# Unit test for constructor of class OneOf
def test_OneOf():
    validator = OneOf(one_of=[Any()])
    val = "one"
    assert validator.validate(val) == "one"

# Generated at 2022-06-12 15:30:07.374552
# Unit test for constructor of class Not
def test_Not():
    str_field = String()
    str_field.max_length = 10
    f = Not(String())
    print("Valid? " + str(f.validate("123")))
    print("Valid? " + str(f.validate("123", strict=True)))
    print("Error? " + str(f.convert("123", strict=True)))
    print("Error? " + str(f.convert("", strict=True)))
    print("Error? " + str(f.convert("123", strict=False)))
    print("Error? " + str(f.convert("", strict=False)))
    print("Error: " + str(f.convert("123", strict=True)[1]))
    # print("Error: " + str(f.convert("", strict=True)[1]))

# Generated at 2022-06-12 15:30:18.781849
# Unit test for method validate of class Not
def test_Not_validate():
    """Unit test for method validate of class Not
    """

    from typesystem.base import validator

    class NotField(Field):
        """
        NotField
        """

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            """validate

            Args:
                value:
                strict:

            Returns:

            """
            raise self.validation_error("error")

    class NotString(Field):
        """
        NotString
        """

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            """validate

            Args:
                value:
                strict:

            Returns:

            """
            return value

    f_not = NotField()
    f_not_string = NotString()


# Generated at 2022-06-12 15:30:21.046036
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String

    assert Not(String())

# Generated at 2022-06-12 15:30:26.352952
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from . import Integer, String
    # Arrange
    field = IfThenElse(Integer())

    # Act
    output1 = field.validate(1)
    output2 = field.validate('erro')

    # Assert
    assert output1 == 1
    assert type(output2) is str

# Generated at 2022-06-12 15:30:30.987216
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Case 1:
    # value = 1,
    # then_value = 2,
    # else_value = 3
    # expected result = 2
    assert IfThenElse(Number(),Number(const=2),Number(const=3)).validate(1) == 2


# Generated at 2022-06-12 15:30:35.541505
# Unit test for method validate of class Not
def test_Not_validate():
    # Case 1
    one_of_fields = [Boolean(), Integer()]
    negated_field = OneOf(one_of_fields)
    n = Not(negated_field)
    assert n.validate(None) == None

    # Case 2
    n = Not(negated_field)
    assert n.validate(5)


# Generated at 2022-06-12 15:30:42.060324
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Test function for method validate of class Not in file test_fields.
    """
    # initialize
    field_not = Not(String())
    # test in case value is valid
    value = "string"
    field_not.validate(value)
    # test in case value is invalid
    value = 1
    with pytest.raises(ValidationError):
        field_not.validate(value)
    # test in case value is None
    value = None
    with pytest.raises(ValidationError):
        field_not.validate(value)
    # test in case value is empty
    value = ""
    with pytest.raises(ValidationError):
        field_not.validate(value)



# Generated at 2022-06-12 15:30:46.682593
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestIfThenElse(IfThenElse):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            print(self.if_clause)

    test_case = TestIfThenElse(if_clause="if", then_clause="then")
    test_case.validate(None)

# Generated at 2022-06-12 15:30:51.062048
# Unit test for constructor of class Not
def test_Not():
    # define the class under test
    class_under_test = Not

    # define an instance of the class under test
    field1 = Field(key="Field1")
    instance_under_test = class_under_test(negated=field1)

    # check that the instance has what it should have
    assert instance_under_test.negated == field1

# Generated at 2022-06-12 15:30:59.796730
# Unit test for method validate of class Not
def test_Not_validate():
    a = {
        "type": "object",
        "properties": {
            "x": {
                "not": {
                    "type": "object",
                    "properties": {
                        "y": {
                            "type": "integer"
                        }
                    },
                    "required": ["y"]
                }
            }
        }
    }
    b = {"x": {"p": 12}}
    c = Not.from_json(a['properties']['x']['not'])
    assert c.validate(b['x']) is None
    b = {"x": {"y": 12}}
    with pytest.raises(ValidationError) as e:
        c.validate(b['x'])
    # a strict validate should throw error
    b = {"x": {"p": 12}}

# Generated at 2022-06-12 15:31:02.519084
# Unit test for method validate of class Not
def test_Not_validate():
    value = True
    negated = Field.validate(True)
    if error is None:
        return value
    else:
        raise error

# Generated at 2022-06-12 15:31:03.582798
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    value = None
    strf = NeverMatch()
    assert strf.validate(value) == None


# Generated at 2022-06-12 15:31:12.270289
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Boolean, Integer
    from typing import List

    # Basic
    field = AllOf([Boolean(), Integer()])
    assert field

    # Raise on invalid field
    for invalid_field in [None, 1, "str", {}]:
        try:
            AllOf([invalid_field])
            assert False
        except AssertionError:
            assert True

    # Raise on invalid list
    for invalid_list in [None, 1, "str", {}]:
        try:
            AllOf(invalid_list)
            assert False
        except AssertionError:
            assert True

    # Raise on empty list
    try:
        AllOf([])
        assert False
    except AssertionError:
        assert True



# Generated at 2022-06-12 15:31:18.013399
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(),then_clause=Any(),else_clause=Any()).validate("any")


# Generated at 2022-06-12 15:31:20.225088
# Unit test for constructor of class Not

# Generated at 2022-06-12 15:31:26.243635
# Unit test for method validate of class Not
def test_Not_validate():
    intField = typesystem.Integer()
    stringField = typesystem.String()
    typeField = typesystem.Type(intField)
    notTypeField = typesystem.Not(typeField)
    # Int match
    expected = 0
    actual = notTypeField.validate(expected)
    assert actual == expected
    # String match
    expected = "String"
    actual = notTypeField.validate(expected)
    assert actual == expected
    # Negative match
    with pytest.raises(nope.errors.FieldError):
        notTypeField.validate(123)


# Generated at 2022-06-12 15:31:37.017946
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(name="if")
    then_clause = Field(name="then")
    else_clause = Field(name="else")
    test_inerface = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    
    if_clause.validate = MagicMock()
    then_clause.validate = MagicMock()
    else_clause.validate = MagicMock()
    then_clause.validate.return_value = "then value"
    else_clause.validate.return_value = "else value"
    assert test_inerface.validate("some value") == "then value"

# Generated at 2022-06-12 15:31:46.928330
# Unit test for constructor of class Not

# Generated at 2022-06-12 15:31:50.105312
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Validating an empty instance.
    """

    field = IfThenElse(
        if_clause=None,
        then_clause=None,
        else_clause=None,
    )
    field.validate(value={})

# Generated at 2022-06-12 15:31:53.912408
# Unit test for constructor of class Not
def test_Not():
    field1 = Field()
    good_field2 = Not(field1)
    assert good_field2.negated == field1
    assert good_field2.errors == {'negated': 'Must not match.'}
    bad_field2 = Not(field1, allow_null=False)
    assert bad_field2.allow_null == False
    assert bad_field2.errors == {'negated': 'Must not match.'}



# Generated at 2022-06-12 15:32:02.399341
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_field = Field(type_name = "int")
    then_field = Field(type_name = "float")
    else_field = Field(type_name = "string")
    field = IfThenElse(
        if_clause = if_field,
        then_clause = then_field,
        else_clause = else_field,
    )
    # then branch
    value = 1
    answer = field.validate(value)
    assert answer == value
    # else branch
    value = "hi"
    answer = field.validate(value)
    assert answer == value

# Generated at 2022-06-12 15:32:09.693319
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    from typesystem import validators
    class IFThenElseSchema(typesystem.Schema):
        my_field1 = typesystem.Integer(validators=[
            typesystem.validators.Min(10)
        ])
        my_field2 = typesystem.Integer(validators=[
            typesystem.validators.Max(20)
        ])
        my_field3 = typesystem.Integer(validators=[
            typesystem.validators.Max(30)
        ])

# Generated at 2022-06-12 15:32:13.008672
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
  assert IfThenElse(1, 2, 3) # Instance of IfThenElse created

# Unit test that checks if a IfThenElse.validate() can validate the values in the "Then" clause

# Generated at 2022-06-12 15:32:18.723506
# Unit test for constructor of class AllOf
def test_AllOf():
    # Create an instance of AllOf with no arguments
    AllOf_instance = AllOf()
    # Check the value of its all_of property
    assert AllOf_instance.all_of == []  # type: ignore


# Generated at 2022-06-12 15:32:25.802290
# Unit test for method validate of class Not
def test_Not_validate():
    type_string = types.SimpleNamespace()
    type_string.validate = mock.Mock(return_value = 'hello')
    type_not = types.Not(type_string)

    # Case 1
    value = type_not.validate_or_error('abc')
    assert (value == 'abc')

    # Case 2
    mock_error = types.ValidationError(None, 'This is error')
    type_string.validate_or_error = mock.Mock(return_value = (None, mock_error))
    type_not.validate_or_error('abc')



# Generated at 2022-06-12 15:32:37.729223
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def raise_exception():
        raise Exception()
        
    def no_raise_exception():
        return True
        
    class If_clause_Mock:
        def validate_or_error(self, value, strict=False):
            if raise_exception():
                raise Exception()
            else:
                return True, None

    class Then_clause_Mock:
        def validate(self, value, strict=False):
            if no_raise_exception():
                return "then_clause"
            else:
                raise Exception()
    
    class Else_clause_Mock:
        def validate(self, value, strict=False):
            if no_raise_exception():
                return "else_clause"
            else:
                raise Exception()

    if_clause = If_clause_

# Generated at 2022-06-12 15:32:38.737839
# Unit test for constructor of class OneOf
def test_OneOf():
    # assert
    assert OneOf([None, None, None]) is not None

# Generated at 2022-06-12 15:32:39.756704
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Number())
    assert not_field.negated == Number()

# Generated at 2022-06-12 15:32:42.811368
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Int()]).validate(10) == 10
    assert OneOf([Int()]).validate(9) == 9

# Generated at 2022-06-12 15:32:50.264104
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f1 =IfThenElse(if_clause=Integer(),then_clause=Integer())
    f1.validate(1) == 1
    f2 = IfThenElse(if_clause=Integer(), else_clause=Integer())
    f2.validate(2) == 2
    f3 = IfThenElse(if_clause=Integer(), then_clause=Integer(), else_clause=Integer())
    f3.validate(5) == 5
    f4 = IfThenElse(if_clause=Integer(), then_clause=Integer(max_value=5))
    try:
        f4.validate(5)
    except ValidationError:
        assert True
    else:
        assert False

# Generated at 2022-06-12 15:32:53.442038
# Unit test for constructor of class AllOf
def test_AllOf():
    test = AllOf([
        Integer(min_value=1),
        Integer(max_value=10)
    ])
    
    assert test(2) == 2
    assert test(11) == 11

# Generated at 2022-06-12 15:32:54.313530
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), Field)

# Generated at 2022-06-12 15:32:55.506158
# Unit test for constructor of class AllOf
def test_AllOf():

    AllOf([])

# Generated at 2022-06-12 15:33:02.473944
# Unit test for constructor of class AllOf
def test_AllOf():

    from typesystem.fields import String
    from typesystem.schema import Schema
    from typesystem.types import String as StringType

    class MySchema(Schema):
        foo = AllOf([String(min_length=2), StringType()])
        bar = AllOf([String(), StringType(min_length=2)])

    MySchema({"foo": "100", "bar": "100"})

# Generated at 2022-06-12 15:33:04.610106
# Unit test for method validate of class Not
def test_Not_validate():
    class MyField(Not):
        pass
    myfield = MyField(negated = "test")
    assert myfield.validate(10) == 10

# Generated at 2022-06-12 15:33:07.562685
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        AllOf(['a', 'b'])
    except AssertionError as e:
        assert type(e) == AssertionError


# Generated at 2022-06-12 15:33:16.123525
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    print("test_IfThenElse_validate")
    if_clause = MockField(name="if_clause")
    then_clause = MockField(name="then_clause")
    else_clause = MockField(name="else_clause")
    value = "value"
    result = IfThenElse(if_clause, then_clause, else_clause).validate(
        value, strict=True)
    assert then_clause.validate.called
    assert then_clause.validate.called_with(value, strict=True)



# Generated at 2022-06-12 15:33:18.321742
# Unit test for method validate of class Not
def test_Not_validate():
    data = 5
    a = Any()
    b = Not(a)
    b.validate(data)



# Generated at 2022-06-12 15:33:20.716806
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Field(required=True))

    assert not_field.validate(None) == None


# Generated at 2022-06-12 15:33:21.673672
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-12 15:33:29.030035
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class MyInteger(Integer):
        def __init__(self, error_messages=None):
            super().__init__()
            self.error_messages = {"wrong_type": "Should be type of int."}
        def validate(self, value, strict=False):
            _, error = Integer().validate_or_error(value, strict=strict)
            if error is not None:
                raise self.validation_error("wrong_type")
            if value >= 0:
                return value
            else:
                return value * -1
    class MyFloat(Float):
        def __init__(self, error_messages=None):
            super().__init__()
            self.error_messages = {"wrong_type": "Should be type of float."}

# Generated at 2022-06-12 15:33:33.158668
# Unit test for constructor of class OneOf
def test_OneOf():

    integer = Field(type=int)
    string = Field(type=str)

    oneof = OneOf(one_of=[integer, string])

    assert oneof.validate(1) == 1
    assert oneof.validate('1') == '1'
    with pytest.raises(ValidationError):
        oneof.validate(None)


# Generated at 2022-06-12 15:33:38.753512
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Number
    data = '{"name":"Ricky Bobby", "age": "6"}'
    ite = IfThenElse(if_clause=Number(gt=5), then_clause=Number(max_value=7), else_clause=Number(max_value=10))
    print(ite.validate(data))
    return "test passed for method validate of class IfThenElse"


# Generated at 2022-06-12 15:33:41.514007
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([]) is not None


# Generated at 2022-06-12 15:33:46.041650
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Dynamic, String

    test1 = OneOf([Dynamic()])
    test2 = OneOf([Dynamic(), String()])
    assert test1.one_of == [Dynamic()]
    assert test2.one_of == [Dynamic(), String()]


# Generated at 2022-06-12 15:33:47.341612
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert(NeverMatch().errors == {'never': 'This never validates.'})

# Generated at 2022-06-12 15:33:48.111279
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf([])
    assert o.one_of == []


# Generated at 2022-06-12 15:33:49.971633
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    f = IfThenElse(if_clause, then_clause, else_clause)

    assert f.validate(10) == 10



# Generated at 2022-06-12 15:33:53.874741
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_NeverMatch = NeverMatch(name='nevermatch')
    assert test_NeverMatch.name == 'nevermatch'
    # Validate an value with NeverMatch()
    try:
        test_NeverMatch.validate(1)
    except Exception as error:
        assert error.messages['never'] == 'This never validates.'

# Generated at 2022-06-12 15:33:58.981289
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.errors import ErrorList

    f = IfThenElse(
        if_clause=Field(),
        then_clause=Field(description="One."),
        else_clause=Field(description="Two."),
    )
    expected = "One."
    result, errors = f.validate_or_error(1)
    assert result == 1
    assert isinstance(errors, ErrorList)
    assert len(errors) == 0


# Generated at 2022-06-12 15:34:08.299639
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IfThenElseTest(IfThenElse):
        def __init__(self, if_clause: Field = None, then_clause: Field = None, else_clause: Field = None):
            super().__init__(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)

    class MyStringField(Field):
        def __init__(self):
            super().__init__()

        def validate(self, value: typing.Any = None, strict: bool = False) -> typing.Any:
            return [1, 2, 3]

    myStringField = MyStringField()
    ifThenElseTest = IfThenElseTest(if_clause=myStringField)
    assert ifThenElseTest.validate(myStringField)



# Generated at 2022-06-12 15:34:17.050868
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    #For this test we create a object of type IfThenElse, we define conditions to test with and then we test with these.
    #The test are on the right hand of the query string and we use assert to determine if the test return true or false
    text = IfThenElse(OneOf([Boolean(), Integer(), Float()]),
                      then_clause=Length(min_length=10),
                      else_clause=Length(max_length=5))
    assert text.validate("Hello World") == "Hello World"
    assert text.validate(1) == 1
    assert text.validate(3.14) == 3.14
    assert text.validate(True) == True
    assert text.validate("Hello") == "Hello"

# Generated at 2022-06-12 15:34:18.911634
# Unit test for constructor of class AllOf
def test_AllOf():
    assert hasattr(AllOf, '__init__')
    assert callable(AllOf.__init__)



# Generated at 2022-06-12 15:34:23.634557
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate('') == ''


# Generated at 2022-06-12 15:34:26.364925
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=3, then_clause=4, else_clause=5).validate(3)==4
    assert IfThenElse(if_clause=3, then_clause=4, else_clause=5).validate(5)==5


# Generated at 2022-06-12 15:34:31.640290
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    print("Test IfThenElse.validate:")
    test_values = [0,1,2,3,4,5]
    test_expected = [2,3,3,3,3,5]
    try:
        i = 0
        for test_value in test_values:
            actual = IfThenElse.validate(self = IfThenElse(if_clause=test_value>=2), value = test_value, strict=False)
            assert actual == test_expected[i]
            i += 1
        print("All tests passed!")
    except AssertionError as e:
        print("Test No. " + str(i) + " failed.")
        print("Expected: " + str(test_expected[i]) + "; Actual: " + str(actual))
        raise e



# Generated at 2022-06-12 15:34:32.404822
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert False

# Generated at 2022-06-12 15:34:39.853931
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(AllOf([Any(), AllOf([Any(), Any()])]),
                      AllOf([Any(), AllOf([Any(), Any()])]))
    field.validate(0)
    field.validate(True)
    field.validate(1)
    field.validate("hello")
    field.validate((1,))
    field.validate((1, 2))
    field.validate([0])
    field.validate([0, 1])
    field.validate({})
    field.validate({"x": 1})


# Generated at 2022-06-12 15:34:44.163674
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    condition=String()
    then_clause=String()
    else_clause=String()
    new_clause=IfThenElse(condition,then_clause,else_clause)
    assert new_clause.if_clause==condition
    assert new_clause.then_clause==then_clause
    assert new_clause.else_clause==else_clause

# Generated at 2022-06-12 15:34:54.023845
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field1 = IfThenElse(if_clause=Integer(), then_clause=String(), else_clause=None)
    field2 = IfThenElse(if_clause=Integer(), then_clause=None, else_clause=String())
    field3 = IfThenElse(if_clause=Integer(), then_clause=None, else_clause=None)
    field4 = IfThenElse(if_clause=Integer(), then_clause=String(), else_clause=String())
    # field5 = IfThenElse(if_clause=Integer(), then_clause=None, else_clause=String())
    # field6 = IfThenElse(if_clause=Integer(), then_clause=String(), else_clause=None)
    # field7 = IfThenElse(if_clause=Integer(), then

# Generated at 2022-06-12 15:34:57.341827
# Unit test for method validate of class Not
def test_Not_validate():
    # Should return value if error exists
    assert Not(negated = Any(), label = "Field1").validate(valid_value = "any string value") == "any string value"
    # Should return validation error if not error
    try:
        Not(negated = Any(), label = "Field1").validate(valid_value = "any string value")
    except Field.ValidationError as error:
        assert error.code == "negated"
        assert error.value == "any string value"
        assert error.field == "Field1"


# Generated at 2022-06-12 15:34:59.583697
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([String()])
    assert one_of.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}


# Generated at 2022-06-12 15:35:06.122993
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = "if"
    then_clause = "then"
    else_clause = "else"

    # Testing IfThenElse with correct input
    if_clause_test = IfThenElse(if_clause, then_clause, else_clause)
    result = if_clause_test.validate(if_clause)
    assert result == "then"

    # Testing IfThenElse with incorrect input
    if_clause_test = IfThenElse(if_clause, then_clause, else_clause)
    result = if_clause_test.validate("random_input")
    assert result == "else"

    # Testing IfThenElse with incorrect input
    if_clause_test = IfThenElse(if_clause, None, else_clause)
    result = if_

# Generated at 2022-06-12 15:35:14.061328
# Unit test for method validate of class Not
def test_Not_validate():
    negated = String(min_length=3, max_length=4)
    not_Field = Not(negated)
    #value = ""
    #assert not_Field.validate(value) == value



# Generated at 2022-06-12 15:35:19.891967
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Integer, Object, String
    field = IfThenElse(
        IfThenElse(
            if_clause=Integer(),
            then_clause=String(),
        ),
        then_clause=Object(),
    )
    assert field.if_clause.if_clause == Integer()
    assert field.if_clause.then_clause == String()
    assert field.if_clause.else_clause == Any()
    assert field.then_clause == Object()
    assert field.else_clause == Any()

# Generated at 2022-06-12 15:35:24.676680
# Unit test for constructor of class OneOf
def test_OneOf():
    import typesystem
    bool_field = typesystem.Boolean()
    string_field = typesystem.String()
    integer_field = typesystem.Integer()
    one_of = typesystem.fields.OneOf(one_of=[bool_field, string_field, integer_field])
    assert one_of is not None


# Generated at 2022-06-12 15:35:25.383457
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()

# Generated at 2022-06-12 15:35:27.929658
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Boolean(required=True)])
    assert field.one_of[0].required


# Generated at 2022-06-12 15:35:31.741036
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Integer()
    then_clause = String()
    else_clause = Integer()

    my_ifthenelse = IfThenElse(if_clause,then_clause,else_clause)
    assert my_ifthenelse.validate(3) == '3'
    assert my_ifthenelse.validate('3') == 3

# Generated at 2022-06-12 15:35:36.694493
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer

    if_clause = Integer()
    then_clause = Integer()
    else_clause = Integer()
    ite = IfThenElse(if_clause, else_clause=else_clause)

    value = "wrong value"
    validated = ite.validate(value)
    assert validated == value

    value = 1
    validated = ite.validate(value)
    assert validated == 1

    ite = IfThenElse(if_clause, then_clause = then_clause, else_clause = else_clause)
    value = 1
    validated = ite.validate(value)
    assert validated == 1

# Generated at 2022-06-12 15:35:40.907905
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String

    # First, test that a value passes through as expected when "then" clause is not defined
    if_clause = String(min_length=1)
    then_clause = None
    else_clause = String()

    if_then_else_field = IfThenElse(if_clause, then_clause, else_clause)

    value = "test"
    expected = value
    actual = if_then_else_field.validate(value)
    assert actual == expected

    # Second, test that a value passes through as expected when "else" clause is not defined
    if_clause = String(max_length=1)
    then_clause = String()
    else_clause = None


# Generated at 2022-06-12 15:35:42.397888
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    assert f.validate('test') == False


# Generated at 2022-06-12 15:35:46.048666
# Unit test for method validate of class Not
def test_Not_validate():
    # This unit test is only to cover the method validate of class Not
    # Linting errors may occur since Not is not a stand-alone class.
    field = Not(negated=Any())
    field.validate(1)
    # pass

# Generated at 2022-06-12 15:35:55.850762
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():  
    from typesystem.fields import String
    string = String()
    #Constructors f1, f2, f3, f4
    f1 = IfThenElse(if_clause=string, then_clause=string)
    f2 = IfThenElse(if_clause=string)
    f3 = IfThenElse(then_clause=string)
    f4 = IfThenElse()
    assert f1.validate("This string is not empty") == f2.validate("This string is not empty")
    assert f2.validate("This string is not empty") == f3.validate("This string is not empty")
    assert f3.validate("This string is not empty") == f4.validate("This string is not empty")

# Generated at 2022-06-12 15:35:58.145160
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=String(),
        then_clause=Integer(),
        else_clause=Boolean(),
    )
    assert field.validate('1') == 1
    assert field.validate(1) == True

# Generated at 2022-06-12 15:36:01.633738
# Unit test for constructor of class OneOf
def test_OneOf():
    # "Field" is not callable, so this should fail
    try:
        OneOf(Field())
        assert False
    except AssertionError:
        assert True
    # Multiple fields should be passable
    try:
        OneOf([Field(), Field()])
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-12 15:36:02.537508
# Unit test for constructor of class OneOf
def test_OneOf():
    test = OneOf([Field(),Field()])
    assert test



# Generated at 2022-06-12 15:36:04.992526
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import AllOf
    from typesystem.fields import String
    all_of = AllOf([String()])
    expected = AllOf([String()])
    assert all_of == expected


# Generated at 2022-06-12 15:36:06.480185
# Unit test for constructor of class OneOf
def test_OneOf():
    listFields = Field()
    assert not listFields.errors

# Generated at 2022-06-12 15:36:14.695758
# Unit test for method validate of class Not
def test_Not_validate():
    field_not = Not(Integer())
    assert field_not.validate(1) == 1
    assert field_not.validate(1.0) == 1.0
    assert field_not.validate(1.1) == 1.1
    assert field_not.validate(1.5) == 1.5
    assert field_not.validate(2) == 2
    assert field_not.validate(2.0) == 2.0
    assert field_not.validate(2.1) == 2.1
    assert field_not.validate(2.5) == 2.5
    assert field_not.validate(3) == 3
    assert field_not.validate(3.0) == 3.0
    assert field_not.validate(3.1) == 3.1
    assert field

# Generated at 2022-06-12 15:36:18.317861
# Unit test for constructor of class OneOf
def test_OneOf():
    # It is possible to create an instance with no error
    a = OneOf([Any()], description='this is a test')
    assert(a is not None)
    assert(a.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'})
    assert(a.description == 'this is a test')


# Generated at 2022-06-12 15:36:23.961635
# Unit test for constructor of class OneOf
def test_OneOf():
    # OneOf should get a list of one or more field objects
    from typesystem.fields import Boolean
    f1 = Boolean(required = True, name = "field1")
    f2 = Boolean(required = True, name = "field2")
    t1 = OneOf([f1])
    t2 = OneOf([f1,f2])
    #t3 = OneOf([f1,f2,"f3"]) # AssertionError
    return



# Generated at 2022-06-12 15:36:25.902195
# Unit test for method validate of class Not
def test_Not_validate():
    notField = Not(Field())
    assert notField.validate(1) == 1
    try:
        notField.validate("s")
        assert False
    except AssertionError:
        assert True
    except:
        assert False



# Generated at 2022-06-12 15:36:42.186188
# Unit test for method validate of class Not
def test_Not_validate():
    DEFAULT_LABEL = "test"
    DEFAULT_HELP_TEXT = "test"
    DEFAULT_ERROR_MESSAGES = {"negated": "Must not match."}
    DEFAULT_VALUE = 10

    DEFAULT_NEGATED_VALUE = "test"
    DEFAULT_NEGATED_ERROR_MESSAGES = {"noval": "Negated value not valid."}

    # Initialise the class
    field = Not(Number(DEFAULT_VALUE, DEFAULT_LABEL, DEFAULT_HELP_TEXT, DEFAULT_ERROR_MESSAGES), DEFAULT_LABEL, DEFAULT_HELP_TEXT, DEFAULT_ERROR_MESSAGES)

    # Test that validate returns the correct value, when passing in a valid int
    assert field.validate(DEFAULT_VALUE) == DEFAULT

# Generated at 2022-06-12 15:36:49.127074
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value_1 = 1
    value_0 = 0
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(value_1) == value_1
    assert field.validate(value_0) == value_0

# Generated at 2022-06-12 15:36:50.263589
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(None)
    assert field.validate(None) == None

# Generated at 2022-06-12 15:36:51.124603
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Bool(), String())

# Generated at 2022-06-12 15:36:53.594055
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        if "a"=="a":
            raise Exception("Constructor of class NeverMatch can be invoked")
    except TypeError as e:
        print("Constructor of class NeverMatch can not be invoked")


# Generated at 2022-06-12 15:36:54.072880
# Unit test for constructor of class OneOf
def test_OneOf():
    pass

# Generated at 2022-06-12 15:37:02.329201
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    import json
    
    # Creation of an empty NeverMatch
    my_NeverMatch = NeverMatch()

    # We check that the type of my_NeverMatch is correct
    assert type(my_NeverMatch) == NeverMatch

    # We check that the default value of my_NeverMatch is None
    assert my_NeverMatch.default == None

    # We check that the example of my_NeverMatch is None
    assert my_NeverMatch.example == None

    # TypeError when a non-dict is passed
    try:
        my_NeverMatch = NeverMatch("a", "b", "c")
    except TypeError:
        assert True
    else:
        assert False

    # TypeError when a dict with non-string keys is passed

# Generated at 2022-06-12 15:37:04.372912
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Boolean())
    assert (field.validate(False))
    try:
        field.validate(True)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-12 15:37:10.025752
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(None)
    assert not_field.validate(1) is None
    not_field = Not(Dict())
    assert not_field.validate('1') is None
    not_field = Not(String())
    assert not_field.validate(1) is None
    not_field = Not(Int())
    assert not_field.validate('1') is None
    not_field = Not(Float())
    assert not_field.validate('1') is None
    not_field = Not(List())
    assert not_field.validate(True) is None

# Generated at 2022-06-12 15:37:16.938277
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Number
    from typesystem.exceptions import ValidationError

    if_clause = Number(maximum=5)
    then_clause = Number(maximum=10)
    else_clause = Number(minimum=-5)
    ite = IfThenElse(if_clause, then_clause, else_clause)
    ite.validate(3)
    ite.validate(-7)
    with raises(ValidationError) as exc:
        ite.validate(12)
    assert "value must be less than or equal to 10." in str(exc.value)
    with raises(ValidationError) as exc:
        ite.validate(-20)
    assert "value must be greater than or equal to -5." in str(exc.value)

# Generated at 2022-06-12 15:37:36.312776
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Int(), Int()).validate(0) == Int().validate(0)
    assert IfThenElse(Int(), Int()).validate(0.0) == Int().validate(0.0)
    assert IfThenElse(Int(), Int(), Float()).validate(0) == Int().validate(0)
    assert IfThenElse(Int(), Int(), Float()).validate(0.0) == Float().validate(0.0)

# Generated at 2022-06-12 15:37:37.011974
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf



# Generated at 2022-06-12 15:37:40.612562
# Unit test for constructor of class OneOf
def test_OneOf():
    import json
    import typesystem
    class Test(typesystem.Schema):
        test_field = typesystem.OneOf([typesystem.String()])
    data = {"test_field":"abcde"}
    schema = Test()
    schema.validate(data)
    assert True


# Generated at 2022-06-12 15:37:42.414365
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # assert isinstance({}, dict)
    print(IfThenElse.validate(IfThenElse, {}, False))

# Generated at 2022-06-12 15:37:50.718933
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    try:
        if_clause = Field()
        then_clause = Field()
        else_clause = Field()
        assert (IfThenElse(if_clause, then_clause, else_clause).validate(3) == 3)
        assert (IfThenElse(if_clause, then_clause, else_clause).validate(3) == 3)
        assert (IfThenElse(if_clause, else_clause).validate(3) == 3)
        assert (IfThenElse(if_clause, then_clause).validate(3) == 3)
        assert (IfThenElse(if_clause).validate(3) == 3)
    except AssertionError:
        print('Test Failed')
        exit()
    print('Test Passed')


# Generated at 2022-06-12 15:37:55.829788
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.errors import ValidationError

    if_clause = String()
    then_clause = String(max_length=10)
    else_clause = String(min_length=10)

    field = IfThenElse(if_clause, then_clause, else_clause)

    # Success if condition fulfilled
    field.validate("123")
    try:
        field.validate("12345678901")
    except ValidationError as e:
        assert str(e) == "Must be no more than 10 characters."
    assert field.validate("12345678901") == "12345678901"

    # Success if condition not fulfilled
    assert field.validate("12345678901") == "12345678901"

# Generated at 2022-06-12 15:37:56.800969
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x is not None


# Generated at 2022-06-12 15:38:06.968294
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer
    test_case = AllOf([Integer()])
    print("test AllOf")
    print(">>> array = [1, 2, 3, 4]")
    array = [1, 2, 3, 4]
    print(">>> test_case.validate(array)")
    try:
        test_case.validate(array)
    except Exception as e:
        print(e)
    print(">>> array = [1, 'a', 3, 4]")
    array = [1, 'a', 3, 4]
    print(">>> test_case.validate(array)")
    try:
        test_case.validate(array)
    except Exception as e:
        print(e)
    print(">>> array = [1, 2, 3, 4, 'a']")
    array

# Generated at 2022-06-12 15:38:16.547148
# Unit test for constructor of class AllOf
def test_AllOf():
    test_bool = AllOf([Boolean()])
    assert test_bool.all_of == [Boolean()]
    test_int = AllOf([Integer(), Number()])
    assert test_int.all_of == [Integer(), Number()]
    test_any = AllOf([Any(), Any()])
    assert test_any.all_of == [Any(), Any()]
    test_string = AllOf([String(), String()])
    assert test_string.all_of == [String(), String()]
    test_float = AllOf([Float(), Number()])
    assert test_float.all_of == [Float(), Number()]
    test_array = AllOf([Array(items=AllOf([Array(items=Integer()), Array(items=Boolean())])), Array(items=Number())])
    assert test_array.all

# Generated at 2022-06-12 15:38:17.936881
# Unit test for method validate of class Not
def test_Not_validate():
    field_Not = Not(String())
    assert isinstance(field_Not.validate("test"), str)
    assert isinstance(field_Not.validate("test"), str)
