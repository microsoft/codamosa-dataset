

# Generated at 2022-06-12 15:28:44.893812
# Unit test for method validate of class Not
def test_Not_validate():
    return True

# Generated at 2022-06-12 15:28:46.278454
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(None, None) is not None


# Generated at 2022-06-12 15:28:50.239321
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    t = IfThenElse(
        if_clause=AllOf(all_of=[Any()]),
        then_clause=AllOf(all_of=[Any()]),
        else_clause=AllOf(all_of=[Any()]),
    )
    t.validate(value="a")

# Generated at 2022-06-12 15:28:54.168918
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field(name="test"))
    obj = {"test": 1}
    error, value = field.validate_or_error(obj)
    assert error == field.errors['negated']
    assert value == None

# Generated at 2022-06-12 15:28:56.774169
# Unit test for method validate of class Not
def test_Not_validate():
    schema = Not(Any())
    assert schema.validate(1) == 1
    assert schema.validate("foo") == "foo"
    assert schema.validate(True) == True
    assert schema.validate([1, 2]) == [1, 2]
    try:
        schema.validate(None)
        assert False
    except ValueError as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-12 15:28:59.517739
# Unit test for constructor of class AllOf
def test_AllOf():
    f = AllOf([Any()])
    assert f is not None

# Generated at 2022-06-12 15:29:01.814177
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x is not None


# Generated at 2022-06-12 15:29:03.844721
# Unit test for constructor of class AllOf
def test_AllOf():
    with pytest.raises(AssertionError):
        AllOf(all_of=[], allow_null=True)


# Generated at 2022-06-12 15:29:13.800132
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class TestField(Field):
        pass

    class TestParentField(Field):
        pass

    class TestChildField(TestParentField):
        pass

    class TestChildField2(TestParentField):
        pass

    field = OneOf(
        [
            TestField(),
            TestParentField(),
            TestChildField(),
            TestChildField2(),
        ],
        required=True,
        allow_null=True
    )

    assert field.validate(1) == 1
    assert field.validate(True) == True
    assert field.validate(["a", "b"]) == ["a", "b"]
    assert field.validate({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert field.validate(TestField()) == TestField()
    assert field

# Generated at 2022-06-12 15:29:24.860759
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    This is a unit test function written using unittest module
    """
    import unittest
    from typesystem import Integer

    class TestOneOf(unittest.TestCase):

        def test_valid_sub_item(self):
            class TestOneOf(OneOf):
                one_of = [Integer(), Integer(max_value = 50)]

            input_value = 1
            output_value = TestOneOf().validate(input_value)

            self.assertEqual(output_value, input_value)

        def test_invalid_sub_item(self):
            class TestOneOf(OneOf):
                one_of = [Integer(), Integer(max_value = 50)]

            input_value = 100

            with self.assertRaises(TestOneOf.validation_error) as context:
                TestOne

# Generated at 2022-06-12 15:29:30.645743
# Unit test for method validate of class Not
def test_Not_validate():
    Not(negated = Any()).validate(None)
    try:
        Not(negated = Any()).validate(None, strict=True)
    except ValueError:
        pass



# Generated at 2022-06-12 15:29:33.134837
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=Integer())
    assert n.validate('a') == 'a'


# Generated at 2022-06-12 15:29:35.066773
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch(name='test')
    assert a.name == 'test'


# Generated at 2022-06-12 15:29:45.072916
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def to_int_func(value: typing.Any, strict: bool = False) -> int:
        try:
            value = int(value)
        except (ValueError, TypeError):
            value = 0
        return value

    str_field = Field(to_primitive=str)
    int_field = Field(to_primitive=to_int_func)

    if_field = Field(to_primitive=lambda value: value / 2)
    if_field_int = Field(to_primitive=int)

    if_then_else = IfThenElse(if_clause=if_field, then_clause=str_field)
    if_then_else_else = IfThenElse(if_clause=if_field_int, then_clause=str_field, else_clause=int_field)



# Generated at 2022-06-12 15:29:47.493799
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    i = IfThenElse(Field(), Field())
    i.validate(1, strict=False)

# Generated at 2022-06-12 15:29:53.086193
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    object = IfThenElse(if_clause, then_clause, else_clause)
    value = "abc"
    strict = True
    result1 = object.validate(value, strict)
    result2 = object.validate(value, strict)
    assert result1 == result2
    return


# Generated at 2022-06-12 15:29:57.268623
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    value = 'Dave'
    field1 = StringField(max_length=4)
    field2 = StringField(max_length=8)
    schema = OneOf([field1, field2], min_length=2)

    # Act
    result = schema.validate(value)

    # Assert
    assert result == value


# Generated at 2022-06-12 15:30:00.564338
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = OneOf(one_of=[1,2,3])
    b = a.validate(2)
    assert b == 2


# Generated at 2022-06-12 15:30:08.331026
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from inspect import signature
    sig = signature(OneOf.validate)
    assert len(sig.parameters) == 2
    assert list(sig.parameters)[0] == 'self'
    assert sig.parameters['self'].kind == inspect.Parameter.POSITIONAL_ONLY
    assert sig.parameters['self'].default == inspect.Parameter.empty
    assert list(sig.parameters)[1] == 'value'
    assert sig.parameters['value'].kind == inspect.Parameter.POSITIONAL_ONLY
    assert sig.parameters['value'].default == inspect.Parameter.empty



# Generated at 2022-06-12 15:30:10.817609
# Unit test for constructor of class OneOf
def test_OneOf():
    oo = OneOf([Any()], name="OneOf", required=True)
    print(oo)
    return

# Generated at 2022-06-12 15:30:19.260976
# Unit test for method validate of class Not
def test_Not_validate():
    null_value = None
    empty_dict = {}
    not_instance = Not(negated=None)
    # case 1: negated = None
    assert not_instance.validate(null_value) is None
    # case 2: negated = {}
    not_instance.negated = {}
    assert not_instance.validate(null_value) is None
    not_instance.negated = null_value


# Generated at 2022-06-12 15:30:25.376997
# Unit test for constructor of class AllOf
def test_AllOf():

    import typesystem

    schema = typesystem.AllOf([typesystem.Array(), typesystem.Integer()])

    assert schema.validate([1, 2, 3]) == [1, 2, 3]
    assert schema.validate([1, 2.2, 3]) == [1, 2, 3]
    try:
        schema.validate([1, 2.2, "3"])
        assert False, "Should not have validated"
    except typesystem.ValidationError:
        assert True


# Generated at 2022-06-12 15:30:26.765695
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-12 15:30:34.007537
# Unit test for constructor of class OneOf
def test_OneOf():
    t = OneOf([int, str])
    assert t.validate(1) == 1
    assert t.validate("hello") == "hello"
    assert t.validate(1.0) == 1
    assert t.validate("hello") == "hello"
    assert t.validate(1) == 1
    assert t.validate("hello") == "hello"
    assert t.validate(1.0) == 1
    assert t.validate("hello") == "hello"
    return

# Generated at 2022-06-12 15:30:35.868183
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Field(key="first"), Field(key="second")])
    value = "correct"
    assert field.validate(value) == value

# Generated at 2022-06-12 15:30:42.672918
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    child1 = int
    child2 = float
    child3 = str
    child4 = bytes
    field = OneOf([child1, child2, child3, child4])
    assert field.one_of == [child1, child2, child3, child4]
    assert field.errors == {'multiple_matches': 'Matched more than one type.', 'no_match': 'Did not match any valid type.'}
    assert field.__class__.__name__ == 'OneOf'
    
    strict = False
    value = 10
    
    # Act
    return_value = field.validate(value, strict)
    
    # Assert
    assert return_value == 10
    
    
    
    
    
    
    
    
    
    
    
    
    
    

# Generated at 2022-06-12 15:30:52.620396
# Unit test for constructor of class OneOf
def test_OneOf():
    print("\nTesting OneOf constructor")
    # Create a mock field
    mock_field = Field()
    # Create a list of fields
    field_list: typing.List[Field] = []
    field_list.append(mock_field)
    # Create a mock field constructor
    mock_field_constructor = Field(
        field_type='field_type',
        description='description',
        required=True,
        default=None,
        validators=None,
        error_messages=None,
        strip_whitespace=False
    )
    # Create a list of field constructors
    field_constructor_list: typing.List[Field] = []
    field_constructor_list.append(mock_field_constructor)
    # Create a OneOf instance

# Generated at 2022-06-12 15:30:55.370972
# Unit test for constructor of class AllOf
def test_AllOf():
    field_0 = Field()
    field_1 = Field()
    field_list = [field_0, field_1]
    all_of_instance = AllOf(field_list)
    return

# Generated at 2022-06-12 15:30:57.238663
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[])
    assert field.validate(1) == 1

test_OneOf_validate()

# Generated at 2022-06-12 15:31:08.251367
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Field(int), Field(float)])
    one_of.validate(1)
    one_of.validate(1.0)
    one_of.validate(1.1)
    try:
        one_of.validate("test")
        raise Exception("Test failed")
    except FieldValidationError as err:
        assert err.code == "no_match"
        assert str(err) == "Did not match any valid type."
    try:
        one_of.validate(1, strict=True)
        raise Exception("Test failed")
    except FieldValidationError as err:
        assert err.code == "no_match"
        assert str(err) == "Did not match any valid type."

# Generated at 2022-06-12 15:31:12.902619
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String, Integer
    all_of = AllOf(all_of=[String(), Integer()])
    assert all_of


# Generated at 2022-06-12 15:31:16.196461
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    try:
        field = OneOf([Integer(), String()])
        field.validate(12)
    except BaseException as e:
        assert str(e) == 'Did not match any valid type.'


# Generated at 2022-06-12 15:31:18.729158
# Unit test for method validate of class Not
def test_Not_validate():
        notField = Not(Field())
        notField.validate(None)
        notField.validate(True)
        notField.validate("abc")
        notField.validate([1,2,3])
        notField.validate({"a":1})



# Generated at 2022-06-12 15:31:20.417493
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([]).validate([]) == []

# Generated at 2022-06-12 15:31:22.086135
# Unit test for method validate of class Not
def test_Not_validate():
    test_object = Not(Field())
    value = 5

    # test if valid
    result = test_object.validate(value)
    result2 = value

    assert result == result2


# Generated at 2022-06-12 15:31:22.970274
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf


# Generated at 2022-06-12 15:31:29.177752
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}
    assert str(type(field.label)) == "<class 'str'>"
    assert field.path == []
    assert field.required == False
    assert field.get_default() == None
    assert field.get_placeholder() == None


# Generated at 2022-06-12 15:31:34.388676
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    #Test method __init__ from class NeverMatch
    assert f._name == "never_match"
    assert f.errors == {"never": "This never validates."}
    assert f._default == None
    assert f._allow_null == False
    assert f._validate_always == True


# Generated at 2022-06-12 15:31:42.785683
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite_field = IfThenElse(String(), String())
    print("Testing of IfThenElse.validate: ")
    try:
        print("if clause matches, then clause validates: ", end="")
        ite_field.validate(value="asd")
        print("OK")
    except Exception as e:
        print("Failed: {}".format(e))
    try:
        print("if clause matches, then clause does not validate: ", end="")
        ite_field.validate(value=123)
        print("Failed")
    except Exception as e:
        print("OK: {}".format(e))

# Generated at 2022-06-12 15:31:47.669208
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import Integer
    not_int = Not(Integer(), name="no-integer")
    _, error = not_int.validate_or_error({"hello": "world"})
    assert error is None

    _, error = not_int.validate_or_error(1)
    assert error == {"negated": "Must not match."}

# Generated at 2022-06-12 15:31:52.564665
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    one_of = OneOf([Integer()])
    assert one_of.validate(1234) == 1234


# Generated at 2022-06-12 15:32:02.123249
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated = Bool()) #will pass
    not_error = not_field.validate_or_error(2)
    assert not_error
    assert not_error[0] == "negated"
    assert not_error[1] == "Must not match."
    not_error = not_field.validate_or_error(1)
    assert not_error
    assert not_error[0] == "negated"
    assert not_error[1] == "Must not match."
    not_error = not_field.validate_or_error(0)
    assert not_error
    assert not_error[0] == "negated"
    assert not_error[1] == "Must not match."


# Generated at 2022-06-12 15:32:03.671024
# Unit test for constructor of class Not
def test_Not():
    object_ = Not(negated=Field())
    assert isinstance(object_, Not)
    assert isinstance(object_.negated, Field)
    assert object_.errors == {"negated": "Must not match."}


# Generated at 2022-06-12 15:32:05.173949
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_list = [Int(), Float()]
    field = AllOf(all_of = all_of_list)
    assert field.all_of == all_of_list


# Generated at 2022-06-12 15:32:07.973335
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of=[
        Int(),
        Float(),
    ])

    field.validate(1)
    field.validate(1.0)
    with pytest.raises(ValidationError):
        field.validate(1.1)



# Generated at 2022-06-12 15:32:08.854476
# Unit test for constructor of class OneOf
def test_OneOf():
    oneof = OneOf([])


# Generated at 2022-06-12 15:32:12.922917
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    value = "abc"
    # Case 1
    assert NeverMatch().validate(value) == None
    assert NeverMatch().validate("abc") == None
    # Case 2
    assert False == isinstance(NeverMatch().validate("abc"), typing.Any)


# Generated at 2022-06-12 15:32:17.475959
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.integer import Integer
    from typesystem.string import String
    from typesystem.fields import Field
    from typesystem.types import CompoundField
    ## AllOf
    field = AllOf([Integer(), String()])
    assert isinstance(field, CompoundField)
    assert isinstance(field, Field)

# Generated at 2022-06-12 15:32:26.524353
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not()
    value = ""
    result = field.validate(value)
    assert result == ""

    value = "string"
    result = field.validate(value)
    assert result == "string"

    value = 0
    result = field.validate(value)
    assert result == 0

    value = -1
    result = field.validate(value)
    assert result == -1

    value = 1
    result = field.validate(value)
    assert result == 1

    value = 0.0
    result = field.validate(value)
    assert result == 0.0

    value = -1.0
    result = field.validate(value)
    assert result == -1.0

    value = 1.0
    result = field.validate(value)
    assert result == 1

# Generated at 2022-06-12 15:32:31.726630
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[])
    with pytest.raises(AssertionError):
        field.validate(None, strict=True)
    with pytest.raises(AssertionError):
        field.validate(None, strict=False)


# Generated at 2022-06-12 15:32:43.484556
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    n.validate(1)

# Generated at 2022-06-12 15:32:46.490648
# Unit test for constructor of class Not
def test_Not():
    x = Not(field=Field(name='xxx', primitive_type=str))
    assert x.errors == {"negated": "Must not match."}
    assert x.negated == Field(name='xxx', primitive_type=str)
    assert x.name == None
    assert x.description == None
    assert x.default == None
    assert x.help_text == None
    assert x.title == None
    assert x.validators == []


# Generated at 2022-06-12 15:32:48.436155
# Unit test for method validate of class Not
def test_Not_validate():
    class TestField(Field):
        type=str
        def validate(self, value, strict=False):
            return value
    not_test = Not(TestField())
    assert not_test.validate("test") == "test"

# Generated at 2022-06-12 15:32:51.451827
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of = [])
    assert field != None
    assert field.all_of != None
    assert field.label == None


# Generated at 2022-06-12 15:32:52.304896
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass



# Generated at 2022-06-12 15:32:59.120082
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    fields = [Integer(min_value=0), Integer(max_value=0)]
    field = OneOf(fields)
    assert field.validate(10) == 10

    fields = [Integer(min_value=0, max_value=10), Integer(max_value=1)]
    field = OneOf(fields)
    with pytest.raises(FieldError) as error:
        field.validate(10)
    assert error.match("multiple_matches")


# Generated at 2022-06-12 15:33:01.151768
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(1)
    assert field.validate(1) is 1


# Generated at 2022-06-12 15:33:04.059835
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=AllOf(all_of=[Any()]))
    assert isinstance(not_field, Not)

# Unit tests for constructor of class IfThenElse

# Generated at 2022-06-12 15:33:04.562559
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-12 15:33:06.048892
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())



# Generated at 2022-06-12 15:33:14.648190
# Unit test for constructor of class Not
def test_Not():
    import typesystem
    from typesystem import fields
    from typesystem.fields import Integer

    schema = typesystem.structure(
        {"number": fields.Not(Number(required=True))},
    )
    schema.validate({"number": 4})

# Generated at 2022-06-12 15:33:15.784987
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([Field()])


# Generated at 2022-06-12 15:33:20.851364
# Unit test for constructor of class OneOf
def test_OneOf():
    val = OneOf([1,2,3], optional=True, pk=False, unique=False, field_name="1", description="1", enum=[1,2,3], choices=[1,2,3], min_value=1, max_value=3, min_length=1, max_length=3, regex="1", pattern="1", nullable=True, readonly=True)

# Generated at 2022-06-12 15:33:26.179262
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    oneof = OneOf([
        Int(maximum=10),
        Int(minimum=10),
        Int(maximum=20),
        Int(minimum=20),
        Int(),
    ])

    assert oneof.validate(3) == 3
    assert oneof.validate(10) == 10
    assert oneof.validate(50) == 50
    assert oneof.validate(15) == 15

    with raises(ValidationError):
        oneof.validate(1.5)



# Generated at 2022-06-12 15:33:32.540496
# Unit test for method validate of class Not

# Generated at 2022-06-12 15:33:35.440887
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [AllOf(Field()), AllOf(Field())]
    a = AllOf(all_of = all_of)
    assert isinstance(a, Field)

# Generated at 2022-06-12 15:33:36.664869
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(if_clause=Int(), then_clause=Float())

# Generated at 2022-06-12 15:33:40.945383
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import String, Integer

    f = OneOf([Integer(), String()])
    assert f.validate(3) == 3
    assert f.validate("3") == "3"
    try:
        f.validate(3.3)
    except f.ValidationError:
        pass
    else:
        assert False, "Must raise ValidationError"



# Generated at 2022-06-12 15:33:42.781719
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    value = 1
    obj = OneOf(one_of=[Number])
    obj.validate(value)

# Generated at 2022-06-12 15:33:53.017938
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    int_field = Field()
    str_field = Field()
    my_one_of = OneOf([int_field, str_field])
    my_all_of = AllOf([int_field, str_field])

    # Test of type checking
    try:
        my_one_of.validate(1.0, strict=True)
    except AssertionError as e:
        print(e)

    # Test of value
    assert my_one_of.validate(1, strict=True) == 1
    try:
        my_one_of.validate(1.0, strict=True)
    except AssertionError as e:
        print(e)

    # Test of type checking

# Generated at 2022-06-12 15:34:06.847060
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    values = [None, 1, 2.0]
    for value in values:
        f = OneOf([
            { 'type': 'integer', 'minimum': 10 },
            { 'type': 'integer', 'maximum': 5 },
            { 'type': 'number', 'minimum': 10 },
        ])
        try:
            f.validate(value)
        except AssertionError:
            pass


# Generated at 2022-06-12 15:34:11.058440
# Unit test for method validate of class Not
def test_Not_validate(): 
    from typesystem.types import Integer
    from typesystem.errors import ValidationError
    type_ = Not(Integer(minimum=10))
    value = 5
    try:
        result = type_.validate(value)
    except ValidationError as e:
        error_msg = e.errors
    expected_result = None
    expected_msg = {"negated": "Must not match."}
    assert result == expected_result
    assert error_msg == expected_msg


# Generated at 2022-06-12 15:34:13.311132
# Unit test for constructor of class AllOf
def test_AllOf():
    d1 = {'type': 'string', 'maxLength': 10}
    d2 = {'type': 'string', 'minLength': 10}
    all_of = AllOf([Field.from_json(d1), Field.from_json(d2)]).validate('okokokokokokokokok')
    assert(all_of == "okokokokokokokokok")


# Generated at 2022-06-12 15:34:15.848215
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer
    from typesystem.base import ValidationError

    with pytest.raises(ValidationError):
        Integer(min_value=3).validate(1)

# Generated at 2022-06-12 15:34:19.639226
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([]).validate("a") == "a"
    assert OneOf([Field()]).validate("a") == "a"
    assert OneOf([Field(), Field()]).validate("a") == "a"
    assert OneOf([Field(), Field(), Field()]).validate("a") == "a"



# Generated at 2022-06-12 15:34:22.351698
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = OneOf([])
    with pytest.raises(a.validation_error):
        a.validate('')


# Generated at 2022-06-12 15:34:23.243835
# Unit test for constructor of class Not
def test_Not():
    test = Not(None)
    assert isinstance(test,Not)

# Generated at 2022-06-12 15:34:24.798796
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(None)
    # should pass
    result = f.validate(None)
    assert result == None


# Generated at 2022-06-12 15:34:28.136234
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    clause = IfThenElse(if_clause,then_clause, else_clause)
    assert clause.if_clause == if_clause
    assert clause.then_clause == then_clause
    assert clause.else_clause == else_clause


# Unit test IfThenElse.validate()

# Generated at 2022-06-12 15:34:29.011448
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert[1,2,3]==[1,2,3]

# Generated at 2022-06-12 15:34:49.689474
# Unit test for constructor of class Not
def test_Not():
    field = Not(None, None)
    assert field.negated is None


# Generated at 2022-06-12 15:34:54.023478
# Unit test for method validate of class Not
def test_Not_validate():
    # Setting up
    field = Not(Field(), label="l")

    # Testing
    # Should return value if error present
    assert field.validate("value") == "value"
    # Should raise error if no errors
    try:
        field.validate("value")
    except:
        assert True
    else:
        assert False


# Generated at 2022-06-12 15:34:55.624608
# Unit test for constructor of class Not
def test_Not():
  not1 = Not("string")
  assert not1.negated == "string"


# Generated at 2022-06-12 15:35:03.552213
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    One of the most complicated methods in typesystem, this is a unit test
    for the class OneOf, as well as its subclass AnyOf.
    """
    from typesystem.fields import String, Integer, Number
    StringField = String(max_length=5)
    IntegerField = Integer()
    NumberField = Number()
    OneOfField = OneOf([StringField, IntegerField, NumberField])
    AnyOfField = AnyOf([StringField, IntegerField, NumberField])


# Generated at 2022-06-12 15:35:05.876589
# Unit test for constructor of class AllOf
def test_AllOf():
    my_field = AllOf()
    assert my_field.all_of == []


# Generated at 2022-06-12 15:35:07.233730
# Unit test for constructor of class OneOf
def test_OneOf():
	o = OneOf([])
	assert o.one_of == []

# Generated at 2022-06-12 15:35:11.989665
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema1 = {"type": "integer"}
    schema2 = {"type": "string"}
    schema3 = {"type": "object"}

    input1 = 123
    input2 = "abc"


if __name__ == "__main__":
    test_OneOf_validate()

# Generated at 2022-06-12 15:35:16.236974
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(
        [Integer, String]
    )

    one_of.validate(10)
    one_of.validate("Hello")
    one_of.validate(True, strict=True)

# Generated at 2022-06-12 15:35:19.797384
# Unit test for method validate of class Not
def test_Not_validate():
   negated = Field()
   not_field = Not(negated)
   try:
      not_field.validate(1)
   except Exception as e:
      assert str(e) == "'negated' Must not match."
   else:
      assert False



# Generated at 2022-06-12 15:35:22.791550
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String(max_length=5))
    not_field.validate('abcdefg') == 'abcdefg'

# Generated at 2022-06-12 15:35:51.877832
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    not_valid_1, _ = not_field.validate_or_error(value=10)
    assert not_valid_1 == 10
    not_valid_2, _ = not_field.validate_or_error(value=3.14)
    assert not_valid_2 == 3.14
    not_valid_3, _ = not_field.validate_or_error(value="Hello!")
    assert not_valid_3 == "Hello!"
    not_valid_4, _ = not_field.validate_or_error(value=True)
    assert not_valid_4 == True
    not_valid_5, _ = not_field.validate_or_error(value=False)
    assert not_valid_5 == False

# Unit test

# Generated at 2022-06-12 15:35:57.152588
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Build mock object
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    mock_data = IfThenElse(if_clause, then_clause, else_clause)

    # Run test
    mock_strict = True
    ret_value = mock_data.validate('string', strict=mock_strict)

    assert ret_value is not None


# Generated at 2022-06-12 15:35:58.089160
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([AllOf([1])]).all_of, [1]

# Generated at 2022-06-12 15:35:59.531507
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(one_of=[])
    assert one_of.validate(None) is None


# Generated at 2022-06-12 15:36:00.224594
# Unit test for constructor of class Not
def test_Not():
    assert Not(None) is not None


# Generated at 2022-06-12 15:36:04.386303
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import String

    field = OneOf(one_of = [Integer(),Float()])
    assert field.validate('1') == '1'
    assert field.validate(3.0) == 3.0
    assert field.validate([1]) == [1]


# Generated at 2022-06-12 15:36:07.647166
# Unit test for constructor of class Not
def test_Not():
    test_negated = Field()
    test_not = Not(test_negated)
    assert test_not.negated == test_negated
    assert test_not.errors == {'negated': 'Must not match.'}


# Generated at 2022-06-12 15:36:15.712182
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Test method validate of class OneOf.
    """
    a = Integer(label='a', gt=0, lt=10)
    b = Integer(label='b', gt=10, lt=20)
    c = Integer(label='c', gt=20, lt=30)
    # Test if a value given as argument is not equal to any element of the given list
    val = OneOf(one_of=[a, b, c]).validate(40)
    assert val == 40, "OneOf.validate failed for value 40"
    # Test if a value given as argument is equal to exactly one element of the list
    val = OneOf(one_of=[a, b, c]).validate(5)
    assert val == 5, "OneOf.validate failed for value 5"
    # Test if

# Generated at 2022-06-12 15:36:21.859576
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = CharField()
    b = CharField(max_length=20)
    c = IntField(min_value=0, max_value=20)
    d = OneOf([a,b,c])
    assert d.validate('Hey') == 'Hey'
    assert d.validate('Hey Hey I Am Here') == 'Hey Hey I Am Here'
    assert d.validate(10) == 10
    assert d.validate(30) == 30
    try:
        d.validate(30)
        assert False
    except Exception as e:
        assert str(e) == 'Did not match any valid type.'

    try:
        d.validate(True)
        assert False
    except Exception as e:
        assert str(e) == 'Did not match any valid type.'



# Generated at 2022-06-12 15:36:22.925811
# Unit test for constructor of class Not
def test_Not():
    import typesystem
    not_field = typesystem.Not(
        typesystem.String()
    )

# Generated at 2022-06-12 15:37:03.338707
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(AllOf([Any()]))
    not_field.validate(1)

# Generated at 2022-06-12 15:37:04.594999
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    v = OneOf(one_of=[])
    assert v.validate('hello') == 'hello'

# Generated at 2022-06-12 15:37:14.514628
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String, Integer

    # both valid, one match
    schema = Not(String(max_length=2))
    assert schema("a") == "a"

    # both valid, no match
    schema = Not(String(max_length=2))
    assert schema("aa") == "aa"

    # both invalid, no match
    schema = Not(String(max_length=2))
    assert schema(1) == 1

    # one valid, no match
    schema = Not(String(max_length=2))
    assert schema(1) == 1

    # one invalid, one match
    schema = Not(String(max_length=2))
    assert schema(1) == 1

    # both invalid, one match
    schema = Not(Integer(), String(max_length=2))

# Generated at 2022-06-12 15:37:15.783190
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f = OneOf(one_of=[])
    assert f.validate({}) == ({}, None)

# Generated at 2022-06-12 15:37:19.916826
# Unit test for method validate of class Not
def test_Not_validate():
    field_1 = Not(negated="a")
    field_2 = Not(negated="b")
    field_3 = Not(negated=None)

    assert field_1.validate("a") == "a"
    assert field_1.validate("b") != "b"
    assert field_2.validate("a") != "a"
    assert field_2.validate("b") == "b"
    assert field_3.validate("a") == "a"
    assert field_3.validate(None) != None



# Generated at 2022-06-12 15:37:23.938682
# Unit test for method validate of class Not
def test_Not_validate():
    notfield = Not(Any(), allow_null=True)
    assert notfield.validate(None) == None
    notfield = Not(Any(), allow_null=False)
    with pytest.raises(ValidationError):
        notfield.validate(None)
    notfield = Not(Any())
    assert notfield.validate(None) == None
test_Not_validate()

# Generated at 2022-06-12 15:37:29.640117
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # test should fail, if one element validates
    one_of = OneOf([Any(), NeverMatch()])
    with pytest.raises(ValidationError):
        one_of.validate("x")

    # test should pass, if only one element validates
    one_of = OneOf([NeverMatch(), NeverMatch()])
    with pytest.raises(ValidationError):
        one_of.validate("x")


# Generated at 2022-06-12 15:37:30.442265
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert 1 == 1



# Generated at 2022-06-12 15:37:35.445227
# Unit test for method validate of class OneOf
def test_OneOf_validate():
	# input
	#----------------------------------------------------------------------------------------------------
	one_of= [Integer(),String()]
	value= 1
	strict= True

	# Ground Truth
	GT= None

	# call the function
	result= OneOf(one_of).validate(value, strict)

	# return
	print(result)
	print(GT)
	assert result == GT


# Generated at 2022-06-12 15:37:37.364162
# Unit test for method validate of class Not
def test_Not_validate():
    a_field = Not(Boolean())
    a_field.validate(5)
    try:
        a_field.validate(False)
    except ValueError:
        pass


# Generated at 2022-06-12 15:37:54.412868
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None


# Generated at 2022-06-12 15:37:56.955911
# Unit test for constructor of class OneOf
def test_OneOf():
    assert(issubclass(OneOf, Field))
    typesystem.registry.register_type(OneOf)
    field = OneOf.create('OneOf(Str())')
    assert(field.one_of[0].name == 'Str')


# Generated at 2022-06-12 15:37:59.780621
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of = []) != None 


# Generated at 2022-06-12 15:38:04.403906
# Unit test for method validate of class Not
def test_Not_validate():
	val = 5
	if_clause = 5
	then_clause = 5
	else_clause = 5
	expected = 5

	actual = IfThenElse(if_clause,then_clause,else_clause)
	actual = actual.validate(val,strict=False)

	assert actual == expected


# Generated at 2022-06-12 15:38:06.289183
# Unit test for method validate of class Not
def test_Not_validate():
    try:
        Not(Integer()).validate("ssss")
    except Exception as e:
        print(e)
        pass

# Generated at 2022-06-12 15:38:08.675631
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=String(min_length=1))
    assert field.validate("abc") == "abc"
    try:
        field.validate("")
        assert False
    except FieldValidationError:
        pass



# Generated at 2022-06-12 15:38:09.336754
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-12 15:38:14.001004
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(String())
    assert f.validate("hello") == "hello"
    try:
        f.validate(1)
    except ValidationError as err:
        assert err.messages == {"value": {"negated": "Must not match."}}


# Generated at 2022-06-12 15:38:18.443932
# Unit test for constructor of class OneOf
def test_OneOf():
    nums = [0, 1, 2, 3]
    my_list = [1, 2, 3]
    field = OneOf(my_list)
    assert field.one_of == my_list
    assert field.errors["no_match"] == "Did not match any valid type."
    assert field.errors["multiple_matches"] == "Matched more than one type."
   

# Generated at 2022-06-12 15:38:21.280995
# Unit test for method validate of class Not
def test_Not_validate():
    negated_value = 5
    not_obj = Not(negated=AllOf([Not(negated=Any()), Any()]))

    value, error = not_obj.validate_or_error(negated_value)
    assert error
    assert value == negated_value

    value, error = not_obj.validate_or_error(None)
    assert error is None
    assert value is None
