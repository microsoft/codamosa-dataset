

# Generated at 2022-06-26 10:09:40.422422
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    not_0 = Not()
    value_1 = None
    not_0.validate(value_1)


# Generated at 2022-06-26 10:09:41.413058
# Unit test for constructor of class Not
def test_Not():
    assert Not() is None

# Generated at 2022-06-26 10:09:44.956289
# Unit test for constructor of class Not
def test_Not():
    negated_0 = None
    not_0 = Not(negated_0)


# Generated at 2022-06-26 10:09:55.929200
# Unit test for method validate of class Not
def test_Not_validate():
    def test_Not_validate_0():
        data_0 = "string_1"
        field_0 = String()
        not_0 = Not(field_0)
        assert not_0.validate(data_0) == data_0
    test_Not_validate_0()

    def test_Not_validate_1():
        data_0 = "string_2"
        field_0 = String()
        not_0 = Not(field_0)
        assert not_0.validate(data_0) == data_0
    test_Not_validate_1()

    def test_Not_validate_2():
        data_0 = "string_3"
        field_0 = String()
        not_0 = Not(field_0)

# Generated at 2022-06-26 10:10:02.081114
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_ = None # TODO
    if_clause_ = None # TODO
    then_clause_ = None # TODO
    else_clause_ = None # TODO
    default_0 = None # TODO
    assert IfThenElse(field_, if_clause_, then_clause_, else_clause_, default_0)

# Generated at 2022-06-26 10:10:08.913343
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)

    # Call function validate of class IfThenElse with arguments
    # if_then_else_0, field_0
    # The function returns a result.
    result = if_then_else_0.validate(field_0)

# Generated at 2022-06-26 10:10:15.282745
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    # assert_equal(expected, IfThenElse(field_0, then_clause, else_clause).validate(value, strict))
    assert_equal('expected a value', IfThenElse(field_0, then_clause, else_clause).validate(value, strict))


# Generated at 2022-06-26 10:10:17.520872
# Unit test for method validate of class Not
def test_Not_validate():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:10:24.316627
# Unit test for constructor of class OneOf
def test_OneOf():
    sub_items_0 = list()
    sub_items_1 = list()
    sub_items_2 = list()
    one_of_0 = OneOf(sub_items_0)
    one_of_1 = OneOf(sub_items_1)
    one_of_2 = OneOf(sub_items_2)



# Generated at 2022-06-26 10:10:27.308781
# Unit test for constructor of class AllOf
def test_AllOf():
    field_0 = None
    all_of_0 = AllOf(field_0)


# Generated at 2022-06-26 10:10:36.897501
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field_0 = None
    never_match_0 = NeverMatch(field_0)


# Generated at 2022-06-26 10:10:39.188453
# Unit test for method validate of class Not
def test_Not_validate():
    negated_0 = None
    not_0 = Not(negated_0)
    value_0 = None
    strict_0 = False
    not_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:10:45.262191
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    value_0 = None
    try:
        if_then_else_0.validate(value_0)
    except AssertionError as raised_0:
        if "allow_null" in str(raised_0):
            pass


# Generated at 2022-06-26 10:10:54.581447
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = Field()
    one_of_0 = OneOf([field_0])
    field_1 = Field()
    one_of_1 = OneOf([field_1])
    assert one_of_0 == one_of_1
    field_2 = Field()
    one_of_2 = OneOf([field_2])
    assert one_of_0 != one_of_2


# Generated at 2022-06-26 10:10:56.939777
# Unit test for method validate of class Not
def test_Not_validate():
    text = "hu"
    d1 = Not(text)
    assert d1.validate(text) == text

# Generated at 2022-06-26 10:11:03.580317
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    value_0 = ""
    strict_0 = False
    actual = if_then_else_0.validate(value_0, strict_0)



# Generated at 2022-06-26 10:11:04.820611
# Unit test for constructor of class AllOf
def test_AllOf():
    field_0 = None
    all_of_0 = AllOf(field_0)
    field_1 = None
    not_0 = Not(field_1)



# Generated at 2022-06-26 10:11:06.046745
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = None
    one_of_0 = OneOf(field_0)


# Generated at 2022-06-26 10:11:09.765568
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Implicitly tested by test case 0
    pass

# Generated at 2022-06-26 10:11:17.104687
# Unit test for constructor of class Not
def test_Not():
    # If then_clause is None, then_clause is None
    # Else then_clause is then_clause
    # If else_clause is None, else_clause is None
    # Else else_clause is else_clause
    negated = Field()
    not_0 = Not(negated)



# Generated at 2022-06-26 10:11:22.605702
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(field_0)
    value_0 = 1.01552459585574E-314
    boolean_0 = not_0.validate(value_0, strict=False)
    assert_true(boolean_0)


# Generated at 2022-06-26 10:11:24.837531
# Unit test for constructor of class AllOf
def test_AllOf():
    field_0 = None
    assert AllOf(field_0)


# Generated at 2022-06-26 10:11:29.957819
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Text

    one_of_0 = OneOf([Text()])
    value_0 = None
    try:
        one_of_0.validate(value_0)
    except AssertionError:
        pass


# Generated at 2022-06-26 10:11:41.717464
# Unit test for method validate of class Not
def test_Not_validate():
    fields = {
        'metadata': {'title': 'not', 'type': 'object', 'properties': {}, 'additionalProperties': False},
        'type': 'object',
        'properties': {},
        'additionalProperties': False,
    }
    jsonschema_0 = fields['metadata']
    field_0 = None
    not_0 = Not(field_0, jsonschema=jsonschema_0, name='not')
    value_0 = 'str'
    try:
        actual = not_0.validate(value_0)
    except ValidationError as e:
        assert e.code == "negated"


# Generated at 2022-06-26 10:11:51.489249
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field_0 = None
    then_clause_0 = None
    else_clause_0 = None
    if_then_else_0 = IfThenElse(field_0, then_clause_0, else_clause_0)

    assert if_then_else_0.if_clause is None
    assert if_then_else_0.then_clause is None
    assert if_then_else_0.else_clause is None


# Generated at 2022-06-26 10:11:55.420691
# Unit test for method validate of class Not
def test_Not_validate():
    field_0 = None
    not_0 = Not(field_0)
    value_0 = None
    not_0.validate(value_0)


# Generated at 2022-06-26 10:12:00.632071
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    value_0 = None
    str_0 = if_then_else_0.validate(value_0)
    assert str_0 == None

# Generated at 2022-06-26 10:12:12.418487
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = None
    field_1 = None
    field_2 = None
    field_3 = None
    field_4 = None
    field_5 = None
    field_6 = None
    field_7 = None
    field_8 = None
    field_9 = None
    field_10 = None
    field_11 = None
    field_12 = None
    field_13 = None
    field_14 = None
    field_15 = None
    field_16 = None
    one_of_0 = OneOf([field_0])
    one_of_0.validate(None)


# Generated at 2022-06-26 10:12:23.534349
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    value_0 = None
    assert if_then_else_0.validate(value_0) == None, "failed test"
    assert if_then_else_0.validate(value_0) == None, "failed test"

# Test Fixtures
test_case_0()

# Testing
if __name__ == "__main__":
    test_IfThenElse_validate()

# Generated at 2022-06-26 10:12:35.554327
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = [None]
    kwargs = {}
    all_of_1 = AllOf(all_of_0, **kwargs)
    assert all_of_1 is not None
    # Equality test
    assert all_of_1 == all_of_1
    assert not (all_of_1 != all_of_1)
    # Inequality test
    assert all_of_1 != all_of_0
    assert not (all_of_1 == all_of_0)


# Generated at 2022-06-26 10:12:45.193727
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    int_0 = 0
    # state 0
    assert (int_0 == if_then_else_0.validate(int_0))



# Generated at 2022-06-26 10:12:56.943071
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    value_0 = None
    strict_0 = False
    try:
        if_then_else_0.validate(value_0, strict_0)
    except Exception as exception_0:
        assert type(exception_0) is ValidationError
        assert exception_0.args == ("validator.null", "Object value was null")


# Generated at 2022-06-26 10:13:05.180409
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = String()
    if_then_else_0 = IfThenElse(field_0)
    strict_0 = None
    # value of type Any
    value_0 = None
    # Call method validate of class IfThenElse and assert return type Any
    assert_equal(if_then_else_0.validate(value_0, strict_0), None)

# Generated at 2022-06-26 10:13:08.603180
# Unit test for method validate of class Not
def test_Not_validate():
    negated_0 = None
    not_0 = Not(negated_0)

    # Call validate
    assert not_0.validate(None) is None


# Generated at 2022-06-26 10:13:14.057858
# Unit test for method validate of class Not
def test_Not_validate():
    field_0 = AllOf([])
    not_0 = Not(field_0)
    value_0 = {}
    result = not_0.validate(value_0)

    assert result == value_0


# Generated at 2022-06-26 10:13:20.107076
# Unit test for method validate of class Not
def test_Not_validate():
    # Nothing to test for this method, as it just raises an exception
    pass


# Generated at 2022-06-26 10:13:29.991572
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None # TODO - set to a valid value
    then_clause_0 = None # TODO - set to a valid value
    else_clause_0 = None # TODO - set to a valid value
    if_then_else_0 = IfThenElse(field_0, then_clause_0, else_clause_0)
    value_0 = None # TODO - set to a valid value
    strict_0 = None # TODO - set to a valid value
    if_then_else_0.validate(value_0, strict_0)

# Generated at 2022-06-26 10:13:33.265872
# Unit test for method validate of class Not
def test_Not_validate():
    field_0 = NeverMatch()
    not_0 = Not(field_0)


# Generated at 2022-06-26 10:13:34.706942
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = OneOf([])



# Generated at 2022-06-26 10:13:38.224939
# Unit test for method validate of class Not
def test_Not_validate():
    field_1 = Not(field_0)


if __name__ == '__main__':
    test_case_0()
    test_Not_validate()

# Generated at 2022-06-26 10:13:49.280415
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_then_else_0 = IfThenElse()
    strict_0 = true
    value_0 = true
    try:
        if_then_else_0.validate(value_0, strict_0)
    except ValidationError:
        valu

# Generated at 2022-06-26 10:13:56.013849
# Unit test for constructor of class Not
def test_Not():
    # Tests the following constructor:
    # def __init__(self, negated: Field, **kwargs: typing.Any) -> None:
    # test 1: negated is a field:
    field = Not(String())
    assert isinstance(field, Not)


# Generated at 2022-06-26 10:14:02.526418
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = [ None, None, None ]
    field_0 = OneOf(one_of_0)
    value_0 = None
    strict_0 = None
    field_0.validate(value_0, strict_0)
    strict_1 = False
    field_0.validate(value_0, strict_1)
    strict_2 = True
    field_0.validate(value_0, strict_2)


# Generated at 2022-06-26 10:14:12.039167
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = Min(1)
    field_1 = Max(2)
    one_of_0 = OneOf([field_0, field_1])
    value_0 = 1
    value_0 = one_of_0.validate(value_0)
    value_1 = 1.3
    with raises(ValidationError):
        one_of_0.validate(value_1)
    value_2 = 3.2
    with raises(ValidationError):
        one_of_0.validate(value_2)


# Generated at 2022-06-26 10:14:18.303510
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a_value_0 = None
    never_match_0 = NeverMatch(a_value_0)
    assert never_match_0 is not None
    assert never_match_0.validate() is not None


# Generated at 2022-06-26 10:14:20.686343
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated=None)


# Generated at 2022-06-26 10:14:24.844060
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)

# Generated at 2022-06-26 10:14:33.130068
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value_0 = None
    strict_0 = False
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    try:
        if_then_else_0.validate(value_0, strict_0)
    except:
        raise AssertionError("validate should not raise an exception")


# Generated at 2022-06-26 10:14:36.988743
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)


if __name__ == "__main__":
    import sys
    import doctest

    print(doctest.testmod(sys.modules[__name__]))
    print("DocTest end")

# Generated at 2022-06-26 10:14:40.558332
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = None
    one_of_0 = OneOf(field_0)
    value_0 = None
    strict_0 = None
    result_0 = one_of_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:14:56.066797
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = None
    one_of_0 = OneOf(field_0)
    strict_0 = False
    value_0 = one_of_0.validate(**{'strict': strict_0})


# Generated at 2022-06-26 10:15:06.681324
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    field_1 = None
    field_2 = None
    if_then_else_0 = IfThenElse(field_0, field_1, field_2)
    strict_0 = False
    maybe_value_0 = None
    try:
        if_then_else_0.validate(maybe_value_0, strict_0)
    except ValidationError:
        maybe_value_0 = maybe_value_0
    else:
        maybe_value_0 = maybe_value_0


# Generated at 2022-06-26 10:15:08.970257
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_3 = None
    one_of_0 = OneOf(field_3)
    value_0 = None

    # Call the method
    result = one_of_0.validate(value_0)

# Generated at 2022-06-26 10:15:11.914472
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    integer_0 = Any()
    if_then_else_0 = IfThenElse(integer_0, integer_0)
    assert if_then_else_0.validate(3) == 3



# Generated at 2022-06-26 10:15:14.764069
# Unit test for method validate of class Not
def test_Not_validate():
    field_0 = AllOf([Any()])
    not_0 = Not(field_0)
    value_0 = {}
    strict_0 = True
    not_0.validate(value_0, strict_0)



# Generated at 2022-06-26 10:15:17.298645
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)



# Generated at 2022-06-26 10:15:20.907128
# Unit test for method validate of class Not
def test_Not_validate():
    arg_0 = None
    arg_1 = None
    arg_2 = None
    field_3 = Not(arg_0, arg_1, arg_2)
    arg_3 = None
    arg_0 = field_3.validate(arg_3)



# Generated at 2022-06-26 10:15:24.027066
# Unit test for method validate of class Not
def test_Not_validate():
    def test_Not_validate_test_case():
        input0 = null
        input1 = False
        return_value = Not.validate(input0, input1)
        Not.validate(input0, input1)


# Generated at 2022-06-26 10:15:31.584971
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    field_1 = None
    field_2 = None
    if_then_else_0 = IfThenElse(field_0)
    try:
        if_then_else_0.validate(field_1)
    except ValidationError as raised:
        assert raised.code == "no_match"
    else:
        raise AssertionError

# Generated at 2022-06-26 10:15:38.672575
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field_0 = Integer(max_value=10)
    one_of_field_1 = Integer(min_value=10)
    one_of_0 = OneOf([one_of_field_0, one_of_field_1])
    one_of_validation_error_0 = one_of_0.validate(b'34')
    one_of_validation_error_1 = one_of_0.validate(b'73')
    assert one_of_validation_error_0.code == "no_match"
    assert one_of_validation_error_1.code == "no_match"


# Generated at 2022-06-26 10:15:51.143522
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)


# Generated at 2022-06-26 10:15:53.868392
# Unit test for constructor of class Not
def test_Not():
    negated_0 = None
    not_0 = Not(negated_0)


# Generated at 2022-06-26 10:15:58.725379
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = None
    one_of_0 = OneOf([field_0])
    value_0 = None
    boolean_0 = False
    error_0 = one_of_0.validate(value_0, boolean_0)

# Generated at 2022-06-26 10:16:02.807094
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    assert if_then_else_0 is not None


# Generated at 2022-06-26 10:16:09.863046
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    assert if_then_else_0.if_clause is field_0
    assert if_then_else_0.then_clause is None
    assert if_then_else_0.else_clause is None
    field_0 = []
    if_then_else_0 = IfThenElse(field_0, else_clause=[])
    assert if_then_else_0.if_clause is field_0
    assert if_then_else_0.else_clause == []
    assert if_then_else_0.then_clause is None
    field_0 = {}
    if_then_else_0 = IfThenElse(field_0, then_clause={})
    assert if_then_

# Generated at 2022-06-26 10:16:20.431196
# Unit test for constructor of class AllOf

# Generated at 2022-06-26 10:16:24.639278
# Unit test for constructor of class AllOf
def test_AllOf():
    assert_equal(hasattr(AllOf, "__init__"), True)



# Generated at 2022-06-26 10:16:26.269105
# Unit test for constructor of class AllOf
def test_AllOf():
    field_0 = None
    all_of_0 = AllOf(field_0)


# Generated at 2022-06-26 10:16:27.917380
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # TODO
    pass

# Generated at 2022-06-26 10:16:31.328313
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Setup
    json_doc = None
    field = OneOf(None)
    field.validate(json_doc)
    return None

# Generated at 2022-06-26 10:16:53.284795
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    value_0 = None
    result = if_then_else_0.validate(value_0)
    assert result == None


# Generated at 2022-06-26 10:16:55.873043
# Unit test for method validate of class Not
def test_Not_validate():

    field_0 = None
    field_1 = None
    not_0 = Not(field_0)
    try:
        not_0.validate(field_1)
    except Exception:
        useful_exception = True
    else:
        useful_exception = False
    if not useful_exception:
        assert True
    else:
        assert False


# Generated at 2022-06-26 10:16:59.019107
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:17:09.034413
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    data_0 = None
    try:
        if_then_else_0.validate(data_0)
    except Invalid as e:
        assert e.error == "invalid_type"
        assert e.field == if_then_else_0
        assert e.path == []
        assert e.value is None
    else:
        raise AssertionError("Expected an error.")

# Generated at 2022-06-26 10:17:15.078034
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0, allow_null=True)

    with raises(ValueError):
        if_then_else_0.validate(None)


# Generated at 2022-06-26 10:17:26.725515
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test Invalid Argument Type
    field_0 = None
    one_of_0 = OneOf(field_0)
    with raises(AssertionError):
        one_of_0.validate()

    # Test Invalid Argument Type
    with raises(TypeError):
        OneOf(object(), object())

    # Test Valid Argument Type
    field_0 = Any()
    one_of_0 = OneOf(field_0)
    with raises(AssertionError):
        one_of_0.validate(object())

    # Test Invalid Argument Type
    field_0 = None
    one_of_0 = OneOf(field_0)
    if_then_else_0 = IfThenElse(field_0)

# Generated at 2022-06-26 10:17:31.228588
# Unit test for method validate of class Not
def test_Not_validate():
    # Input arguments for the method.
    item_0 = None
    strict_0 = True

    # Call the method.
    Not_0 = Not(item_0)
    Not_0.validate(strict_0)


# Generated at 2022-06-26 10:17:37.362355
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    items_0 = []
    one_of_0 = OneOf(items_0)
    value_0 = True
    strict_0 = True
    value_1 = one_of_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:17:40.774143
# Unit test for method validate of class Not
def test_Not_validate():
    input = 'amet'
    not_0 = Not(any_0)
    output = not_0.validate(input)


# Generated at 2022-06-26 10:17:55.154965
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    field_0 = OneOf([])
    with pytest.raises(AssertionError, match=r"^.*?no_match$"):
        field_0.validate("<unknown>")

    field_1 = OneOf([])
    with pytest.raises(AssertionError, match=r"^.*?no_match$"):
        field_1.validate("<unknown>")

    field_2 = OneOf([])
    with pytest.raises(AssertionError, match=r"^.*?no_match$"):
        field_2.validate("<unknown>")

    field_3 = OneOf([])
    with pytest.raises(AssertionError, match=r"^.*?no_match$"):
        field_3.validate("<unknown>")

# Generated at 2022-06-26 10:18:14.071006
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf(field_0).validate(value_0) == value_0


# Generated at 2022-06-26 10:18:16.077672
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    neverMatch = NeverMatch()
    assert neverMatch


# Generated at 2022-06-26 10:18:29.119799
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String

    # Test NeverMatch init.
    never_match_0 = NeverMatch()

    # Test NeverMatch.validate.
    try:
        never_match_0.validate("hello")
        assert False
    except ValidationError:
        pass

    # Test NeverMatch.validate.
    try:
        never_match_0.validate("hello", strict=True)
        assert False
    except ValidationError:
        pass

    # Test NeverMatch.validate_or_error.
    expected_0 = ("hello", None)
    actual_0 = never_match_0.validate_or_error("hello")
    assert expected_0 == actual_0

    # Test NeverMatch.validate_or_error.
    expected_

# Generated at 2022-06-26 10:18:37.179145
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    name = "OneOf"
    one_of = None
    description = None
    child = None
    one_of_0 = OneOf(one_of, name=name, description=description)
    number = 0
    strict = True
    value = None
    expected = None
    assert one_of_0.validate(value, strict=strict) == expected


# Generated at 2022-06-26 10:18:42.035784
# Unit test for constructor of class Not
def test_Not():
    assert isinstance(Not(None, label=None, description=None, enum=None,
                          error_messages=None, name=None),
                      Not)

# Generated at 2022-06-26 10:18:45.786071
# Unit test for method validate of class Not
def test_Not_validate():
    # We instantiate a Dummy object for the test
    field_0 = Dummy() # Note that the Dummy class inherits from Field
    # We instantiate a Not object for the test
    not_0 = Not(field_0) # Here we pass the Dummy object as the argument
    # We test the validate() method of the Not object with a null value
    value_0 = None
    # We then test that the validate() method returns null
    assert not_0.validate(value_0) is None


# Generated at 2022-06-26 10:18:49.397895
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = None
    if_then_else_0 = IfThenElse(field_0)
    value_0 = None
    result = if_then_else_0.validate(value_0)


# Generated at 2022-06-26 10:18:51.924027
# Unit test for method validate of class Not
def test_Not_validate():
    negated_0 = None
    not_0 = Not(negated_0)
    value = None

    try:
        result = not_0.validate(value)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 10:18:53.743029
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_1 = None
    one_of_0 = OneOf([field_1])
    field_2 = None
    one_of_1 = OneOf([field_2])
    assert one_of_0.validate(None) is None
    assert one_of_1.validate(None) is None


# Generated at 2022-06-26 10:18:57.586309
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0 is not None

# # Unit test for constructor of class OneOf