

# Generated at 2022-06-26 10:09:52.968571
# Unit test for method validate of class Not
def test_Not_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    dict_1 = {}
    not_0 = Not(negated=never_match_0, **dict_1)
    assert not_0.validate(0)


# Generated at 2022-06-26 10:10:04.145868
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value_0 = "field_0"
    strict_0 = None
    list_0 = []
    any_0 = Any()
    dict_0 = {}
    field_0 = Field(**dict_0)
    if_clause_0 = field_0
    list_1 = []
    any_1 = Any()
    dict_1 = {}
    field_1 = Field(**dict_1)
    then_clause_0 = field_1
    list_2 = []
    any_2 = Any()
    dict_2 = {}
    field_2 = Field(**dict_2)
    else_clause_0 = field_2
    dict_3 = {}

# Generated at 2022-06-26 10:10:14.219713
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(None).validate(None) is None
    assert Not(None).validate(True) is True
    assert Not(None).validate(False) is False
    assert Not(None).validate(0) == 0
    assert Not(None).validate(0.0) == 0.0
    assert Not(None).validate('') == ''
    assert Not(None).validate('a') == 'a'
    assert Not(None).validate([]) == []
    assert Not(None).validate([0]) == [0]
    assert Not(None).validate({}) == {}
    assert Not(None).validate({'a': 0}) == {'a': 0}


# Generated at 2022-06-26 10:10:26.284745
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    dict_1 = {}
    never_match_1 = NeverMatch(**dict_1)
    dict_2 = {}
    if_then_else_0 = IfThenElse(never_match_0, never_match_1, **dict_2)
    dict_3 = {}
    never_match_2 = NeverMatch(**dict_3)
    dict_4 = {}
    if_then_else_1 = IfThenElse(never_match_2, **dict_4)
    dict_5 = {}
    never_match_3 = NeverMatch(**dict_5)
    dict_6 = {}
    if_then_else_2 = IfThenElse(never_match_3, **dict_6)

# Generated at 2022-06-26 10:10:34.984129
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Field()
    then_clause_0 = Field()
    else_clause_0 = Field()
    value_0 = 1
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0, value_0)
    assert if_then_else_0.validate(value_0) == value_0


# Generated at 2022-06-26 10:10:44.584020
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    any_0 = Any(**dict_0)
    dict_1 = {}
    any_1 = Any(**dict_1)
    dict_2 = {}
    if_then_else_0 = IfThenElse(any_0, any_1, **dict_2)
    any_2 = Any()
    str_0 = if_then_else_0.validate(any_2)
    print(str_0)


# Generated at 2022-06-26 10:10:50.654366
# Unit test for method validate of class Not
def test_Not_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    dict_1 = {}
    not_0 = Not(negated=never_match_0, **dict_1)
    dict_2 = {}
    any_0 = Any(**dict_2)
    any_0.validate = lambda x: x
    dict_3 = {}
    one_of_0 = OneOf(one_of=[not_0, any_0, any_0], **dict_3)


# Generated at 2022-06-26 10:10:58.790457
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    dict_1 = {'title': 'never match'}
    dict_2 = {'title': 'never match'}
    any_0 = Any(**dict_0)
    if_clause = NeverMatch(**dict_1)
    then_clause = None
    else_clause = any_0
    if_then_else_0 = IfThenElse(if_clause, then_clause, else_clause, **dict_2)
    boolean_0 = if_then_else_0.validate(True)


# Generated at 2022-06-26 10:11:10.757579
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    field_0 = Field(**dict_0)
    field_1 = Field(**dict_1)
    field_2 = Field(**dict_2)
    dict_3 = {
        "if_clause": field_0,
        "then_clause": field_1,
        "else_clause": field_2,
    }
    if_then_else_0 = IfThenElse(**dict_3)
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    field_3 = Field(**dict_4)
    field_4 = Field(**dict_5)
    field_5 = Field(**dict_6)

# Generated at 2022-06-26 10:11:21.495723
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    if_clause_0 = NeverMatch(**dict_0)
    then_clause_0 = NeverMatch(**dict_1)
    else_clause_0 = NeverMatch(**dict_2)
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    dict_3 = {}
    dict_4 = {}
    not_0 = Not(NeverMatch(**dict_3), **dict_4)
    if_then_else_1 = IfThenElse(not_0, if_then_else_0, if_then_else_0)

# Generated at 2022-06-26 10:11:33.072768
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    field_0 = None # exception thrown
    field_1 = Field(**dict_0)
    field_2 = Any(**dict_1)
    field_3 = Any(**dict_2)
    field_4 = NeverMatch(**dict_3)
    field_5 = IfThenElse(**dict_4)

# Generated at 2022-06-26 10:11:37.514729
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    # TypeError: __init__() missing 1 required keyword-only argument: 'self'
    # never_match_0 = NeverMatch(**dict_0)
    pass


# Generated at 2022-06-26 10:11:38.914099
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True == True


# Generated at 2022-06-26 10:11:44.852551
# Unit test for method validate of class Not
def test_Not_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    dict_1 = {}
    not_0 = Not(negated=never_match_0, **dict_1)

    # Test default
    assert not_0.validate(value=None)

    # Test default, explicit
    assert not_0.validate(value=None, strict=False)

    # Test strict
    assert not_0.validate(value=None, strict=True)


# Generated at 2022-06-26 10:11:51.672193
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {"one_of": [],}
    oneof_0 = OneOf(**dict_0)
    try:
        _ = oneof_0.validate(None)
        assert False, "Should have errored."
    except Exception as e:
        assert "no_match" in str(e)


# Generated at 2022-06-26 10:11:58.146599
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    field_0 = Field(**dict_0)
    list_0 = [field_0]
    oneOf_0 = OneOf(list_0, **dict_0)
    oneOf_0.validate(value=None, strict=False)


# Generated at 2022-06-26 10:12:01.072550
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(one_of=[])
    str_0 = one_of_0.validate('17ddc24d7f')
    print("OneOf")
    print(str_0)


# Generated at 2022-06-26 10:12:07.469698
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_5 = {}
    type_0 = Any()
    all_of_0 = AllOf((type_0, ), **dict_5)
    list_0 = []
    one_of_0 = OneOf(list_0, **dict_5)
    dict_0 = {}
    dict_1 = {}
    dict_0['data_type'] = dict_1
    dict_0['annotations'] = None
    dict_0['default'] = None
    dict_0['format'] = None
    dict_0['title'] = None
    dict_0['description'] = None
    dict_1['args'] = dict_0
    dict_2 = {}
    dict_0['kwargs'] = dict_2
    dict_3 = {}
    dict_4 = {}

# Generated at 2022-06-26 10:12:12.987308
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    list_0 = []
    list_0.insert(0, never_match_0)
    one_of_0 = OneOf(list_0, **dict_0)
    one_of_0.validate(False)

# Generated at 2022-06-26 10:12:24.808168
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = list()
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    list_0.append(never_match_0)
    dict_1 = {}
    never_match_1 = NeverMatch(**dict_1)
    list_0.append(never_match_1)
    non_null_0 = NonNull(list_0)
    one_of_0 = OneOf(list_0)
    try:
        value = one_of_0.validate(None)
    except ValidationError as error:
        assert error.code == "no_match"
    else:
        assert False


# Generated at 2022-06-26 10:12:30.018689
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {
        "name": "OneOf",
        "one_of": Field
    }

    one_of_0 = OneOf(**dict_0)
    str_0 = one_of_0.validate()


# Generated at 2022-06-26 10:12:31.929511
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    assert NeverMatch(**dict_0) is not None


# Generated at 2022-06-26 10:12:39.788526
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    value_0 = {}
    never_match_0 = NeverMatch(**value_0)
    value_0 = True
    never_match_1 = NeverMatch(**value_0)
    value_0 = False
    never_match_2 = NeverMatch(**value_0)
    one_of_0 = OneOf(**dict_0)
    value_0 = {}
    one_of_0.validate(value_0, strict = True)
    one_of_0 = OneOf([never_match_0, never_match_1, never_match_2], **dict_0)
    value_0 = {}
    one_of_0.validate(value_0, strict = True)


# Generated at 2022-06-26 10:12:45.631932
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    assert issubclass(NeverMatch, Field)
    with pytest.raises(AssertionError):
        assert never_match_0.validate(1)


# Generated at 2022-06-26 10:12:54.718574
# Unit test for method validate of class Not
def test_Not_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    dict_1 = {}
    not_0 = Not(**dict_1)
    assert not_0.validate(never_match_0)


# Generated at 2022-06-26 10:12:59.195704
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
   dict_0 = {}
   all_of_0 = AllOf([Any()], **dict_0)
   notify_0 = Not(all_of_0, **dict_0)
   call_0 = IfThenElse(notify_0, **dict_0)
   try:
       call_0.validate(None, True)
   except Exception as e:
       pass


# Generated at 2022-06-26 10:13:08.094870
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Setup object
    if_clause = None
    then_clause = None
    else_clause = None
    dict_0 = {'else_clause': else_clause, 'then_clause': then_clause, 'if_clause': if_clause}
    if_then_else_0 = IfThenElse(**dict_0)
    value = None
    strict = False
    # Test validate
    result = if_then_else_0.validate(value, strict)
    assert result is None


# Generated at 2022-06-26 10:13:14.276484
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0, **dict_0)
    value = None
    strict = True
    assert one_of_0.validate(value, strict=strict)
    assert None


# Generated at 2022-06-26 10:13:22.931179
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    union_0 = Union(bool_0, bool_1)
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    union_1 = Union(bool_3, bool_4)
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    union_2 = Union(bool_6, bool_7)
    if_then_else_0 = IfThenElse(union_0, union_1, union_2)
    if_then_else_0.validate(bool_2)
    if_then_else_0.validate(bool_5)
    if_then_else_0.validate(bool_8)

#

# Generated at 2022-06-26 10:13:30.693454
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    list_0 = [never_match_0]
    dict_1 = {}
    one_of_0 = OneOf(list_0, **dict_1)

    # try:
    one_of_0.validate(None)
    #
    #
    # except ValidationError:
    #     pass
    # else:
    #     assert False, 'Expected ValidationError'



# Generated at 2022-06-26 10:13:39.577515
# Unit test for constructor of class AllOf
def test_AllOf():
    # Creating test values
    array_0 = [NeverMatch()]
    # Creating test parameters
    all_of = array_0
    # Creating test values
    array_1 = [never_match_0]
    # Creating test parameters
    kwargs = {
        "all_of": array_1
    }
    # Creating test object
    all_of_0 = AllOf(all_of, **kwargs)


# Generated at 2022-06-26 10:13:49.893456
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import unittest
    from . import datetime as tm

    class IfThenElseTestCase(unittest.TestCase):
        def test_IfThenElse_validate_0(self):
            datetime_0 = tm.datetime(1981, 5, 28, 23, 54, 51, 0)
            dict_0 = {}
            any_0 = Any(**dict_0)
            list_0 = [any_0]
            all_of_0 = AllOf(list_0, **dict_0)
            dict_1 = {}
            never_match_0 = NeverMatch(**dict_1)
            list_1 = [all_of_0, never_match_0]

# Generated at 2022-06-26 10:14:02.408659
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Create a mock object for the if_clause parameter
    if_clause = mock.Mock()
    # Create a mock object for the then_clause parameter
    then_clause = mock.Mock()
    # Create a mock object for the else_clause parameter
    else_clause = mock.Mock()
    # Create a mock object for the kwargs parameter
    kwargs = {"keyword1": "value1", "keyword2": 2}

    # Test with required parameters
    result = IfThenElse(
        if_clause, 
        then_clause, 
        else_clause,  
    )

    # Test with optional parameters

# Generated at 2022-06-26 10:14:07.348619
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test the following types
    #   Positive
    #   Positive.Positive

    dict_0 = {}
    list_0 = []
    str_0 = "This is a string"

    assert True is True
    assert False is False
    assert None is None


# Generated at 2022-06-26 10:14:10.150454
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)


# Generated at 2022-06-26 10:14:13.288877
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    one_of_1 = OneOf([None])
    one_of_0.validate(**{"value": one_of_1, "strict": one_of_1})


# Generated at 2022-06-26 10:14:18.866672
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    # Test case 0
    dict_0 = {}
    one_of_0 = OneOf(**dict_0)
    # Test case 1
    dict_1 = {}
    one_of_1 = OneOf(**dict_1)


# Generated at 2022-06-26 10:14:27.523686
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    dict_5 = {}
    dict_6 = {}
    dict_7 = {}
    dict_8 = {}
    dict_9 = {}
    dict_10 = {}
    dict_11 = {}
    dict_12 = {}
    dict_13 = {}
    dict_14 = {}
    dict_15 = {}
    dict_16 = {}
    dict_17 = {}
    dict_18 = {}
    dict_19 = {}
    dict_20 = {}
    dict_21 = {}
    dict_22 = {}
    dict_23 = {}
    dict_24 = {}
    dict_25 = {}
    dict_26 = {}
    dict_27 = {}
    dict_

# Generated at 2022-06-26 10:14:37.876627
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    list_0 = []
    one_of_0 = OneOf(list_0)

    dict_1 = {}
    never_match_1 = NeverMatch(**dict_1)
    list_1 = []
    one_of_1 = OneOf(list_1)

    list_2 = []
    one_of_2 = OneOf(list_2)

    dict_3 = {}
    never_match_3 = NeverMatch(**dict_3)
    list_3 = []
    one_of_3 = OneOf(list_3)

# Generated at 2022-06-26 10:14:43.350901
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    assert not hasattr(never_match_0, "allow_null")
    assert never_match_0.errors["never"] == "This never validates."


# Generated at 2022-06-26 10:14:56.025821
# Unit test for constructor of class AllOf
def test_AllOf():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    never_match_0 = NeverMatch(**dict_0)
    never_match_1 = NeverMatch(**dict_1)
    fields_0 = [never_match_0, never_match_1]
    all_of_0 = AllOf(fields_0, **dict_2)


# Generated at 2022-06-26 10:15:03.295292
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    string_0 = "No match."
    string_1 = "Multiple matches."
    list_0 = []
    one_of_0 = OneOf(list_0, )
    # Unit test for function validate of class OneOf
    assert one_of_0.validate(None) == None


# Generated at 2022-06-26 10:15:07.112828
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-26 10:15:12.377482
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    dict_1 = {
        "minimum": 1,
        "maximum": 1,
    }
    any_0 = Any(**dict_0)
    any_1 = Any(**dict_0)
    dict_2 = {
        "if_clause": any_0,
        "then_clause": any_1,
    }
    if_then_else_0 = IfThenElse(**dict_2)

# Generated at 2022-06-26 10:15:16.593860
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf
    dict_0 = {'all_of': [], 'required': True}
    allOf_0 = AllOf(**dict_0)
    dict_1 = {'all_of': [], 'required': False}
    allOf_1 = AllOf(**dict_1)


# Generated at 2022-06-26 10:15:17.551757
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        test_case_0()

# Generated at 2022-06-26 10:15:18.678154
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-26 10:15:25.854614
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    dict_1 = {}
    never_match_0 = NeverMatch(**dict_0)
    never_match_1 = NeverMatch(**dict_1)
    list_0 = [never_match_0, never_match_1]
    dict_2 = {}
    one_of_0 = OneOf(one_of=list_0, **dict_2)
    value_0 = None
    strict_0 = False
    one_of_0.validate(value_0, strict_0)



# Generated at 2022-06-26 10:15:34.967477
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    dict_0 = {}
    if_clause_0 = NeverMatch(**dict_0)
    dict_1 = {}
    then_clause_0 = NeverMatch(**dict_1)
    dict_2 = {}
    else_clause_0 = NeverMatch(**dict_2)
    dict_3 = {}
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0, **dict_3)


# Generated at 2022-06-26 10:15:42.878897
# Unit test for constructor of class AllOf
def test_AllOf():
    # Assign arguments
    all_of_0 = [
        NeverMatch(**{}),
        NeverMatch(**{}),
        NeverMatch(**{}),
    ]

    # Create object
    all_of_0 = AllOf(**{
        'all_of': all_of_0,
    })


# Generated at 2022-06-26 10:15:47.846870
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)


# Generated at 2022-06-26 10:15:52.233007
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    any_0 = Any(**dict_0)
    any_1 = Any(**dict_0)
    if_then_else_0 = IfThenElse(if_clause=any_0, then_clause=any_1, **dict_0)

# Generated at 2022-06-26 10:15:57.892398
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    never_match_1 = NeverMatch(**dict_0)
    dict_1 = {}
    never_match_2 = NeverMatch(**dict_1)
    list_0 = [never_match_1, never_match_2, never_match_1]
    dict_2 = {}
    one_of_0 = OneOf(list_0, **dict_2)


# Generated at 2022-06-26 10:16:03.755819
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {'oneOf': [Number(), 'Number']}
    one_of_0 = OneOf(**dict_0)
    str_0 = "oneOf"
    str_1 = "allOf"
    str_2 = "Not"


# Generated at 2022-06-26 10:16:09.198310
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    one_0 = 1
    all_of_0 = AllOf([one_0])
    if_clause_0 = one_0
    then_clause_0 = all_of_0
    else_clause_0 = all_of_0
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = 1
    strict_0 = True
    # Exception raised
    with pytest.raises(TypeError):
        if_then_else_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:16:12.996995
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    return 0


# Generated at 2022-06-26 10:16:15.279874
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any())
    field.validate(3)


# Generated at 2022-06-26 10:16:27.724198
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_3 = {}
    dict_4 = {}
    never_match_0 = NeverMatch(**dict_0)
    never_match_1 = NeverMatch(**dict_1)
    one_of_0 = OneOf(**dict_2)
    dict_2.update(one_of=[never_match_0, never_match_1])
    one_of_0.__init__(**dict_2)
    dict_3.update(one_of=[never_match_0, never_match_1])
    dict_4.update(one_of_0=one_of_0, value=1)
    all_of_0 = AllOf(**dict_3)
    dict_5 = {}
    dict_5

# Generated at 2022-06-26 10:16:37.380144
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    dict_0 = {}
    any_0 = Any(**dict_0)
    dict_1 = {}
    any_1 = Any(**dict_1)
    dict_2 = {}
    any_2 = Any(**dict_2)
    dict_3 = {}
    any_3 = Any(**dict_3)
    dict_4 = {}
    if_then_else_0 = IfThenElse(any_0, then_clause = any_1, else_clause = any_2, **dict_4)
    assert if_then_else_0.validate(any_3) == any_3


# Generated at 2022-06-26 10:16:50.286465
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    list_0 = []
    dict_0 = {}
    dict_1 = {"type":list_0}
    dict_2 = {"type":"number"}
    dict_3 = {"type":"number"}
    dict_4 = {"properties":dict_3,"type":"object"}
    dict_5 = {"type":"string"}
    dict_6 = {"type":"string"}
    dict_7 = {"properties":dict_6,"type":"object"}
    dict_8 = {"type":list_0}
    dict_9 = {"pattern":"^[0-9]+","type":"string"}
    dict_10 = {"type":list_0}
    dict_11 = {"pattern":"^[0-9]+","type":"string"}
    dict_12 = {"properties":dict_11,"type":"object"}

# Generated at 2022-06-26 10:17:01.963381
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    string_0 = "never"
    dictionary_0 = {"never": "This never validates."}
    field_0 = NeverMatch(errors=dictionary_0)
    list_0.append(field_0)
    field_1 = OneOf(one_of=list_0)
    dictionary_1 = {"multiple_matches": "Matched more than one type."}
    field_2 = OneOf(errors=dictionary_1)
    list_0.append(field_2)
    with pytest.raises(ValidationError) as excinfo:
        field_2.validate(string_0)
    with pytest.raises(ValidationError) as excinfo:
        field_1.validate(string_0)


# Generated at 2022-06-26 10:17:06.028504
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = [NeverMatch()]
    dict_0 = {}
    one_of_0 = OneOf(list_0, **dict_0)



# Generated at 2022-06-26 10:17:13.249203
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    one_of_0 = OneOf(**dict_0)
    never_match_0 = NeverMatch(**dict_0)
    never_match_1 = NeverMatch(**dict_0)
    never_match_2 = NeverMatch(**dict_0)
    one_of_0.one_of = [never_match_0, never_match_1, never_match_2]
    value_0 = one_of_0.validate()



# Generated at 2022-06-26 10:17:17.838136
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    list_0 = []
    oneof_0 = OneOf(list_0)
    assert oneof_0.validate() == None


# Generated at 2022-06-26 10:17:21.380736
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    validate_0_0 = AllOf()
    validate_0_1 = validate_0_0.validate(validate_0_0)


# Generated at 2022-06-26 10:17:33.324604
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    str_0 = "string"
    never_match_0 = NeverMatch(**dict_0)
    never_match_1 = NeverMatch(**dict_0)
    never_match_2 = NeverMatch(**dict_0)
    list_0 = []
    list_0.append(never_match_0)
    list_0.append(never_match_1)
    list_0.append(never_match_2)
    one_of_0 = OneOf(list_0, **dict_0)
    try:
        error_0 = one_of_0.validate(str_0)
    except Exception as error_0:
        print(error_0)



# Generated at 2022-06-26 10:17:44.183369
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    #assert never_match_0.errors == {'never': 'This never validates.'}
    #assert never_match_0.kwargs == {}
    #assert never_match_0.name == 'never_match_0'
    #assert never_match_0.context == {}
    dict_1 = {'errors': {'multiple_matches': 'Matched more than one type.'}}
    one_of_0 = OneOf(**dict_1)
    #assert one_of_0.errors == {'multiple_matches': 'Matched more than one type.'}
    #assert one_of_0.kwargs == {}
    #assert one_of_0.name == 'one_of_0'
    #assert one

# Generated at 2022-06-26 10:17:49.285429
# Unit test for constructor of class AllOf
def test_AllOf():
    dict_0 = {}
    all_of_0 = AllOf(**dict_0)


# Generated at 2022-06-26 10:17:52.475298
# Unit test for constructor of class AllOf
def test_AllOf():
    dict_0 = {}
    list_0 = []
    all_of_0 = AllOf(list_0, **dict_0)


# Generated at 2022-06-26 10:17:53.888287
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    initialize_0 = NeverMatch()


# Generated at 2022-06-26 10:18:10.344037
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    dict_0 = {}
    any_0 = Any(**dict_0)
    dict_1 = {}
    any_1 = Any(**dict_1)
    if_then_else_0 = IfThenElse(if_clause=any_0, then_clause=any_1)
    if_then_else_1 = IfThenElse(any_0, then_clause=any_1)

# Generated at 2022-06-26 10:18:11.923665
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # First test case
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)


# Generated at 2022-06-26 10:18:21.540636
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # dict_0 = {}
    # if_clause_0 = Any()
    # then_clause_0 = never_match_0
    # else_clause_0 = never_match_0
    # if_then_else_1 = IfThenElse(if_clause_0, **dict_0)
    # if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, **dict_0)
    # if_then_else_1 = IfThenElse(if_clause_0, then_clause_0, else_clause_0, **dict_0)
    return


# Generated at 2022-06-26 10:18:26.024552
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    one_of_0 = OneOf(one_of=[never_match_0])


# Generated at 2022-06-26 10:18:28.891462
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)


# Generated at 2022-06-26 10:18:37.044751
# Unit test for constructor of class AllOf
def test_AllOf():
    list_0 = [None for x in range(0, 10)]
    dict_0 = {}
    # Insert call to the constructor of AllOf
    all_of_0 = AllOf(all_of=list_0,**dict_0)
    # Check if the call to the constructor of AllOf is correct
    assert isinstance(all_of_0, AllOf)

# Generated at 2022-06-26 10:18:50.772496
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    dict_0 = {}
    list_1 = []
    dict_1 = {}
    list_2 = []
    dict_2 = {}
    list_3 = []
    dict_3 = {}
    list_4 = []
    dict_4 = {}
    list_5 = []
    dict_5 = {}
    list_6 = []
    dict_6 = {}
    list_7 = []
    dict_7 = {}
    list_8 = []
    dict_8 = {}
    list_9 = []
    dict_9 = {}
    list_10 = []
    dict_10 = {}
    list_11 = []
    dict_11 = {}
    list_12 = []
    dict_12 = {}
    list_13 = []
    dict_13 = {}
    list_

# Generated at 2022-06-26 10:18:53.658525
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)



# Generated at 2022-06-26 10:19:02.764306
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    bool_0 = all_of_0.allow_blank
    assert bool_0
    dict_0 = {}
    all_of_1 = AllOf([], **dict_0)
    bool_1 = all_of_1.allow_blank
    assert bool_1
    list_0 = []
    all_of_2 = AllOf(list_0, allow_blank=bool_1)
    bool_2 = all_of_2.allow_blank
    assert bool_2



# Generated at 2022-06-26 10:19:13.340421
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    list_0 = []
    one_of_0 = OneOf(**dict_0)
    one_of_0.one_of = list_0
    value_0 = None
    boolean_0 = never_match_0.validate(value_0)
    boolean_1 = one_of_0.validate(value_0)
    boolean_2 = never_match_0.validate(value_0)
    boolean_3 = one_of_0.validate(value_0)


# Generated at 2022-06-26 10:19:33.817586
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    dict_0 = {}
    never_match_0 = NeverMatch(**dict_0)
    # AssertionError: Assertion failed


# Generated at 2022-06-26 10:19:47.728903
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    dict_0 = {"allow_null": False, "description": "f2i8N6Z0", "format": "date-time"}
    field_0 = Field(**dict_0)
    dict_1 = {"allow_null": True, "description": "B2Q2e2X9", "format": "date-time"}
    field_1 = Field(**dict_1)
    if_then_else_0 = IfThenElse(if_clause=field_0, then_clause=field_1, else_clause=field_0)
    if_then_else_0.get_error_code()
    if_then_else_0.allow_null
    dict_2 = {"allow_null": False, "description": "ETG6n1S6", "format": "date-time"}
    field