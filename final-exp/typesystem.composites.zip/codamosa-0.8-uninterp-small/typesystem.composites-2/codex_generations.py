

# Generated at 2022-06-26 10:09:48.085919
# Unit test for constructor of class Not
def test_Not():
    negated_0 = Any()
    never_match_0 = Not(negated=negated_0)
    assert never_match_0.validate(1) == 1


# Generated at 2022-06-26 10:09:55.562641
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([Any()])
    assert all_of_0.errors == {}
    assert all_of_0.all_of == [Any()]
    all_of_1 = AllOf([Any(), Any()])
    assert all_of_1.errors == {}
    assert all_of_1.all_of == [Any(), Any()]
    all_of_2 = AllOf([Any(), Any(), Any()])
    assert all_of_2.errors == {}
    assert all_of_2.all_of == [Any(), Any(), Any()]


# Generated at 2022-06-26 10:10:02.267415
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    obj_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value = None
    result = obj_0.validate(value)
    print(result)


# Generated at 2022-06-26 10:10:05.195978
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[])
    assert one_of_0.one_of == []


# Generated at 2022-06-26 10:10:07.531404
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:10:15.547421
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(Negated=None)
    str_0 = str(not_0)
    str_1 = str(not_0)
    str_2 = str(not_0)
    str_3 = str(not_0)
    str_4 = str(not_0)
    str_5 = str(not_0)
    str_6 = str(not_0)
    str_7 = str(not_0)
    str_8 = str(not_0)
    str_9 = str(not_0)
    str_10 = str(not_0)
    str_11 = str(not_0)
    str_12 = str(not_0)
    str_13 = str(not_0)
    str_14 = str(not_0)
    str_15 = str

# Generated at 2022-06-26 10:10:24.519670
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    data_0 = [{"foo": 1}, {"bar": 2}]
    data_1 = {"foo": 1}
    data_2 = {"bar": 2}
    field_0 = OneOf(data_0)
    actual = field_0.validate(data_1)
    expected = {"foo": 1}
    assert actual == expected
    actual = field_0.validate(data_2)
    expected = {"bar": 2}
    assert actual == expected


# Generated at 2022-06-26 10:10:29.680092
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    one_of_0 = OneOf([never_match_0, never_match_1])


# Generated at 2022-06-26 10:10:36.418172
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    value = "aa"
    strict = True
    field = IfThenElse(if_clause, then_clause, else_clause)
    try:
        field.validate(value, strict)
    except Exception as e:
        assert "Matched more than one type." == str(e)

test_IfThenElse_validate()

# Generated at 2022-06-26 10:10:42.464036
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ifthenelse = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    ifthenelse.validate(value=None, strict=True)
    ifthenelse.validate(value=None, strict=False)


# Generated at 2022-06-26 10:10:49.566316
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    result = field.validate("value")


# Generated at 2022-06-26 10:10:51.724264
# Unit test for constructor of class OneOf
def test_OneOf():
    oneOf_0 = OneOf(one_of=[])


# Generated at 2022-06-26 10:10:59.018170
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    foo_0 = IfThenElse(
        if_clause=None,
        then_clause=None,
        else_clause=None,
        allow_null=None,
        description=None,
        name=None,
    )
    # Test with a valid 'value'
    foo_0.validate(value=None)

    # Test with an invalid 'value'
    try:
        foo_0.validate(value=None)
        assert False
    except Exception as e:
        assert True


# Generated at 2022-06-26 10:11:10.840745
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Assert: field_name
    assert test_case_0.never_match_0.field_name == "never_match"
    # Assert: label
    assert test_case_0.never_match_0.label == "never match"
    # Assert: description
    assert test_case_0.never_match_0.description == "Never Match"
    # Assert: help_text
    assert test_case_0.never_match_0.help_text == ""
    # Assert: required
    assert test_case_0.never_match_0.required == False
    # Assert: read_only
    assert test_case_0.never_match_0.read_only == False
    # Assert: write_only

# Generated at 2022-06-26 10:11:13.121150
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert hasattr(NeverMatch, "__init__")



# Generated at 2022-06-26 10:11:15.331194
# Unit test for constructor of class AllOf
def test_AllOf():
    assert isinstance(AllOf([]), Field)


# Generated at 2022-06-26 10:11:20.039368
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch(errors={"never": "This never validates."}, name="NeverMatch")
    assert never_match_0.errors['never'] == "This never validates."
    assert never_match_0.name == "NeverMatch"

# Unit tests for method NeverMatch.validate

# Generated at 2022-06-26 10:11:23.036228
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:11:28.539896
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([never_match_0, never_match_0, never_match_0, never_match_0, never_match_0, never_match_0, never_match_0, never_match_0])


# Generated at 2022-06-26 10:11:32.927938
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, NeverMatch)
    assert never_match_0.name == "NeverMatch"


# Generated at 2022-06-26 10:11:38.708319
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    def test_0():
        assert isinstance(never_match_0, NeverMatch)
        assert never_match_0.errors == {"never": "This never validates."}

# Generated at 2022-06-26 10:11:40.456427
# Unit test for constructor of class AllOf
def test_AllOf():
    children = []
    always_match_0 = AllOf(children)



# Generated at 2022-06-26 10:11:43.280721
# Unit test for constructor of class Not
def test_Not():
    field0 = AllOf([Int(), Float()])
    field1 = Not(field0)



# Generated at 2022-06-26 10:11:50.340143
# Unit test for constructor of class Not
def test_Not():
    negated_0 = NeverMatch()
    assert isinstance(negated_0, NeverMatch)
    not_0 = Not(negated=negated_0)
    assert isinstance(not_0, Not)
    assert not_0.negated == negated_0
    assert isinstance(not_0.negated, NeverMatch)
    negated_1 = NeverMatch()
    assert isinstance(negated_1, NeverMatch)
    not_1 = Not(negated=negated_1)
    assert isinstance(not_1, Not)
    assert not_1.negated == negated_1
    assert isinstance(not_1.negated, NeverMatch)
    negated_2 = NeverMatch()
    assert isinstance(negated_2, NeverMatch)

# Generated at 2022-06-26 10:11:55.585758
# Unit test for constructor of class AllOf
def test_AllOf():
    one_of_0 = OneOf([Any()])
    one_of_1 = OneOf([Any()])
    one_of_2 = OneOf([Any()])
    one_of_3 = OneOf([Any()])

    all_of_0 = AllOf([one_of_0, one_of_1])
    all_of_1 = AllOf([one_of_2, one_of_3])

    one_of_4 = OneOf([all_of_0, all_of_1])


# Generated at 2022-06-26 10:12:05.513054
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Unit tests for OneOf.validate
    # Single match
    one_of_0 = OneOf([
        String(max_length=5),
        String(min_length=5)
    ])
    one_of_0.validate('a')
    # Single match with None
    one_of_1 = OneOf([
        String(max_length=5),
        Number()
    ])
    one_of_1.validate(None)
    # No match
    one_of_2 = OneOf([
        Number(),
        Number(max_value=0),
        Number(min_value=0)
    ])

# Generated at 2022-06-26 10:12:08.326617
# Unit test for method validate of class Not
def test_Not_validate():
    not_1 = Not(never_match_0)
    assert not_1.validate(0) == 0
    not_1 = Not(NeverMatch())
    assert not_1.validate(1) == 1
    try:
        not_1 = Not(NeverMatch())
        assert not_1.validate(2) == 2
        assert False
    except TypeSystemError:
        pass



# Generated at 2022-06-26 10:12:16.776713
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(
        if_clause=Any(), then_clause=True, else_clause=False,
    )
    x = schema.validate(False)
    assert x == False

    schema = IfThenElse(
        if_clause=Any(), then_clause=True, else_clause=False,
    )
    x = schema.validate(True)
    assert x == True

    schema = IfThenElse(
        if_clause=Any(), then_clause=Any(), else_clause=Any(),
    )
    x = schema.validate(True)
    assert x == True

    schema = IfThenElse(
        if_clause=Any(), then_clause=Any(), else_clause=Any(),
    )
    y = schema.validate(None)
   

# Generated at 2022-06-26 10:12:18.145886
# Unit test for constructor of class AllOf
def test_AllOf():
    pass



# Generated at 2022-06-26 10:12:22.904043
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    

# Generated at 2022-06-26 10:12:28.701711
# Unit test for constructor of class Not
def test_Not():
    negated_0 = Any()
    not_0 = Not(negated=negated_0)


# Generated at 2022-06-26 10:12:37.123560
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert never_match_0.label == "NeverMatch field"
    assert never_match_0.label_from == "never_match_0"
    assert never_match_0.sub_fields == {}
    assert never_match_0.child_keys == []
    assert never_match_0.parent is None
    assert never_match_0.root is never_match_0
    assert never_match_0.errors == {"never": "This never validates."}
    assert never_match_0.keywords == {}


# Generated at 2022-06-26 10:12:48.086883
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        negated = None
        negated = "foo"
        negated = 123
        negated = 12.3
        negated = ["foo", "bar"]
        negated = {"foo": "bar"}
        negated = types.SimpleNamespace()
        negated = types.SimpleNamespace(foo="bar")
        negated = types.SimpleNamespace(a=1, b="foo", c=12.3, d=["foo", "bar"], e={"foo": "bar"})
        not_0 = Not(negated)


# Generated at 2022-06-26 10:12:51.495297
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()



# Generated at 2022-06-26 10:13:00.576516
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_1 = NeverMatch()
    assert field_test_data_test_NeverMatch["invalid_values"] == []
    assert never_match_1.validate(field_test_data_test_NeverMatch["valid_values"][0]) == field_test_data_test_NeverMatch["valid_values"][0]
    assert never_match_1.validate(field_test_data_test_NeverMatch["valid_values"][1]) == field_test_data_test_NeverMatch["valid_values"][1]
    assert never_match_1.validate(field_test_data_test_NeverMatch["valid_values"][2]) == field_test_data_test_NeverMatch["valid_values"][2]

# Generated at 2022-06-26 10:13:05.603245
# Unit test for constructor of class Not
def test_Not():
    never_match_1 = NeverMatch()
    not_1 = Not(never_match_1)
    assert not_1.negated == never_match_1
    assert not_1.allow_null == False


# Generated at 2022-06-26 10:13:08.602759
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import AllOf

    all_of_0 = AllOf(all_of=list())


# Generated at 2022-06-26 10:13:10.869301
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=None)


# Generated at 2022-06-26 10:13:12.892815
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([], )


# Generated at 2022-06-26 10:13:19.290472
# Unit test for constructor of class AllOf
def test_AllOf():
    cases = [
        {
            # normal case
            "all_of": [],
        },
        {
            # normal case
            "all_of": [],
        },
        {
            # empty case
            "all_of": [],
        },
    ]
    for case in cases:
        AllOf(**case)


# Generated at 2022-06-26 10:13:26.144233
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        all_0 = AllOf([never_match_0])
    except:
        assert False


# Generated at 2022-06-26 10:13:27.085777
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert type(NeverMatch()) == NeverMatch
    return NeverMatch()


# Generated at 2022-06-26 10:13:31.993127
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_IfThenElse_0 = IfThenElse(if_clause=Field, then_clause=None, else_clause=None, allow_null=None, required=None, description=None, error_messages=None)
    test_IfThenElse_1 = IfThenElse(if_clause=Field(), then_clause=None, else_clause=Field(), allow_null=None, required=True, description="This is a description", error_messages=None)


# Generated at 2022-06-26 10:13:36.545690
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print("test_NeverMatch")
    never_match_0 = NeverMatch()
    try:
        assert never_match_0.validate(0)
        assert False
    except Exception as e:
        assert True


# Generated at 2022-06-26 10:13:38.513305
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:13:45.573286
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create test objects
    one_of_0 = OneOf(one_of=[float, str])
    one_of_1 = OneOf(one_of=[float, str])

    # Test function call
    result = one_of_1.validate(one_of_0, strict=True)



# Generated at 2022-06-26 10:13:48.817224
# Unit test for constructor of class Not
def test_Not():
    negated: Field = None
    not_0 = Not(negated=negated)
    assert not_0 is not None



# Generated at 2022-06-26 10:13:50.218526
# Unit test for constructor of class AllOf
def test_AllOf():
    pass


# Generated at 2022-06-26 10:13:52.327555
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()


# Generated at 2022-06-26 10:13:55.419069
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of=[Any(), Any()])


# Generated at 2022-06-26 10:14:07.872859
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([Any(), Any()])
    res = one_of_0.validate(None)
    assert res is None



# Generated at 2022-06-26 10:14:11.041073
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    num_0 = 1
    field_0 = Field()
    schema_1 = OneOf([field_0])
    schema_1.validate(num_0)



# Generated at 2022-06-26 10:14:13.753365
# Unit test for constructor of class AllOf
def test_AllOf():
    # default constructor
    all_of_0 = AllOf([Any()])



# Generated at 2022-06-26 10:14:16.433559
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = [NeverMatch()]
    one_of_0 = OneOf(one_of)
    value = 1
    strict = True
    assert one_of_0.validate(value, strict)


# Generated at 2022-06-26 10:14:21.955541
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    then_clause = Any()
    if_clause = Any()
    else_clause = Any()
    test = IfThenElse(if_clause, then_clause, else_clause)
    assert test


# Generated at 2022-06-26 10:14:26.608088
# Unit test for constructor of class OneOf
def test_OneOf():
    field_1 = None
    field_2 = None
    array_of_fields = [field_1, field_2]
    OneOf(array_of_fields)


# Generated at 2022-06-26 10:14:27.466224
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert True

# Generated at 2022-06-26 10:14:36.909516
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True
    string_0 = String()
    integer_0 = Integer()
    all_of_0 = AllOf([string_0, integer_0])
    assert all_of_0.validate(1) == 1
    all_of_1 = AllOf([string_0, integer_0])
    assert all_of_1.validate("aa") == "aa"
    all_of_2 = AllOf([string_0, integer_0])
    all_of_2.validate([])


# Generated at 2022-06-26 10:14:47.903094
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test OneOf with one_of = [NeverMatch()]
    never_match_2 = NeverMatch()
    one_of_0 = OneOf([never_match_2])
    try:
        assert one_of_0.validate(1) == None
    except Exception as e:
        pass

    # Test OneOf with one_of = [Str()]
    str_3 = Str()
    one_of_1 = OneOf([str_3])
    try:
        assert one_of_1.validate('a') == 'a'
    except Exception as e:
        pass

    # Test OneOf with one_of = [Str(), Int()]
    str_5 = Str()
    int_5 = Int()
    one_of_2 = OneOf([str_5, int_5])

# Generated at 2022-06-26 10:14:53.475310
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_ = OneOf([Float(), String()])
    value_1 = 1.0
    field_.validate(value_1)
    value_2 = "1.0"
    field_.validate(value_2)


# Generated at 2022-06-26 10:15:04.100920
# Unit test for constructor of class OneOf
def test_OneOf():
    x = OneOf(one_of=[AllOf(all_of=[Any()])]) # x is instance of OneOf

# Generated at 2022-06-26 10:15:16.251248
# Unit test for constructor of class Not
def test_Not():
    number_0 = 1
    not_0 = Not(never_match_0)
    str_0 = "New York"
    not_0 = Not(String(min_length=number_0))
    str_1 = "New York"
    not_0 = Not(String(max_length=number_0))
    str_2 = "New York"
    not_0 = Not(Number(maximum=number_0))
    str_3 = "New York"
    not_0 = Not(Number(exclusive_maximum=number_0))
    str_4 = "New York"
    not_0 = Not(Number(minimum=number_0))
    str_5 = "New York"
    not_0 = Not(Number(exclusive_minimum=number_0))
    str_6 = "New York"
    not_0

# Generated at 2022-06-26 10:15:18.412855
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = [
        NeverMatch(),
        NeverMatch(),
        NeverMatch(),
    ]
    one_of_0 = OneOf(one_of)



# Generated at 2022-06-26 10:15:22.064325
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([
    ])
    all_of_1 = AllOf(all_of=[

    ])
    never_match_0 = NeverMatch()
    all_of_2 = AllOf(all_of=[
        never_match_0,
    ])


# Generated at 2022-06-26 10:15:29.808515
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_fields = []
    one_of_fields.append(NeverMatch())
    one_of_fields.append(NeverMatch())
    one_of_0 = OneOf(one_of_fields)
    assert one_of_0.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}

    # Unit test for constructor of class AllOf

# Generated at 2022-06-26 10:15:36.195357
# Unit test for constructor of class Not
def test_Not():
    negated = None
    x = Not(negated)


if __name__ == "__main__":
    import sys
    import logging

    logging.basicConfig(level=logging.DEBUG)
    # test_NeverMatch()
    # test_Not()
    # test_IfThenElse()
    # test_OneOf()
    # test_AllOf()
    logging.debug(sys.path)

# Generated at 2022-06-26 10:15:41.596117
# Unit test for constructor of class OneOf
def test_OneOf():
    # Tests for OneOf
    with pytest.raises(AssertionError):
        # never_match_0 = NeverMatch()
        _ = OneOf([never_match_0])

# Generated at 2022-06-26 10:15:50.270061
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Assert that NeverMatch object is constructed properly
    # Equivalent to assertRaises(ValueError, NeverMatch, allow_null=True)
    with pytest.raises(ValueError):
        NeverMatch(allow_null=True)

    # Assert different method calls produce the correct output
    # Equivalent to assertRaises(ValueError, NeverMatch().validate, 1)
    with pytest.raises(ValueError):
        NeverMatch().validate(1)

    # Equivalent to assertRaises(ValueError, NeverMatch().validate_or_error, 1)
    with pytest.raises(ValueError):
        NeverMatch().validate_or_error(1)

    # Equivalent to assertRaises(ValueError, NeverMatch().validate_json, 1)

# Generated at 2022-06-26 10:16:00.227499
# Unit test for constructor of class NeverMatch

# Generated at 2022-06-26 10:16:04.113454
# Unit test for constructor of class Not
def test_Not():
    sample_Field = Field()

    not_0 = Not(sample_Field)

    if not isinstance(not_0, Field):
        print("TypeError")


# Generated at 2022-06-26 10:16:22.711573
# Unit test for constructor of class AllOf
def test_AllOf():
    # Arguments to constructor (kwargs)
    all_of = [AllOf(all_of=[Any()])]
    kwargs = {'all_of': all_of}
    # Initializing the object
    AllOf_obj = AllOf(**kwargs)
    if isinstance(AllOf_obj, AllOf):
        test_passed = True
    else:
        test_passed = False
    assert test_passed



# Generated at 2022-06-26 10:16:24.224484
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(object())
    assert isinstance(not_0, Field)


# Generated at 2022-06-26 10:16:24.940929
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])


# Generated at 2022-06-26 10:16:27.993823
# Unit test for constructor of class OneOf
def test_OneOf():
    if (True):
        raise TypeError("must be list, not bool")
    then = OneOf(one_of=[])


# Generated at 2022-06-26 10:16:31.402285
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}



# Generated at 2022-06-26 10:16:33.484375
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    x = OneOf([None])
    x.validate(1)

# Generated at 2022-06-26 10:16:37.403217
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(one_of=[])
    # TypeError: an integer is required (got type str)
    with raises(TypeError):
        one_of_0.validate("")


# Generated at 2022-06-26 10:16:39.659812
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf([Any()]), OneOf)


# Generated at 2022-06-26 10:16:42.389891
# Unit test for constructor of class Not
def test_Not():
    my_not = Not(negated=NeverMatch())


# Generated at 2022-06-26 10:16:47.635273
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        # Construct an instance of the AllOf class
        all_of_0 = AllOf("")
    except Exception as e:
        # Construct an instance of the Exception class
        exception_0 = Exception("Failure description")
        assert exception_0.args == e.args

# Generated at 2022-06-26 10:17:21.932673
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Any()
    assert if_clause is not None

    then_clause = Any()
    assert then_clause is not None

    else_clause = Any()
    assert else_clause is not None

    IfThenElse(if_clause, then_clause, else_clause)
    assert if_clause is not None
    assert then_clause is not None
    assert else_clause is not None


# Generated at 2022-06-26 10:17:26.383840
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        never_match_0 = NeverMatch()
    except Exception as e:
        assert(False)


# Generated at 2022-06-26 10:17:31.037125
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        negated_0 = Field(**{'nullable': True})
        not_0 = Not(
        negated=negated_0,
        **{}
        )


# Generated at 2022-06-26 10:17:33.306958
# Unit test for constructor of class Not
def test_Not():
    negated_0 = Not(Any())


# Generated at 2022-06-26 10:17:34.847022
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass


# Generated at 2022-06-26 10:17:38.383233
# Unit test for constructor of class OneOf
def test_OneOf():
    with pytest.raises(AssertionError):
        test_case_2()
    test_case_3()


# Generated at 2022-06-26 10:17:40.538812
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([], description=None)



# Generated at 2022-06-26 10:17:41.948908
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])


# Generated at 2022-06-26 10:17:46.802029
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(one_of = [])
    one_of_1 = OneOf(one_of = [])


# Generated at 2022-06-26 10:17:52.551525
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0_0 = Field()
    all_of_0_1 = Field()
    all_of_0 = [all_of_0_0, all_of_0_1]
    all_of_1 = AllOf(all_of_0)


# Generated at 2022-06-26 10:19:30.215826
# Unit test for constructor of class Not
def test_Not():
    never_match_1 = NeverMatch()
    field_1 = Not(never_match_1)


# Generated at 2022-06-26 10:19:35.523450
# Unit test for constructor of class Not
def test_Not():
    # Should not raise any error
    Not(Any())
    # Should raise an error
    try:
        Not(NeverMatch())
        assert False, "Should raise an error"
    except NeverMatch.ValidationError:
        assert True
        pass
    # Should raise an error
    try:
        Not(None)
        assert False, "Should raise an error"
    except AssertionError:
        assert True
        pass


# Generated at 2022-06-26 10:19:46.562027
# Unit test for constructor of class Not
def test_Not():
    invalid_negated_0 = NeverMatch()
    valid_negated_0 = Any()

    # Test constructor call with valid value of field "negated"
    try:
        test_case_0 = Not(valid_negated_0)
    except Exception as e:
        print("Exception when testing constructor for Not:", e)

    # Test constructor call with invalid value of field "negated"
    try:
        test_case_0 = Not(invalid_negated_0)
    except Exception as e:
        print("Exception when testing constructor for Not:", e)

