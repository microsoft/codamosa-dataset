

# Generated at 2022-06-26 10:09:45.337789
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(None)
    not_0.validate(None)


# Generated at 2022-06-26 10:09:55.118205
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = module_0.Field()
    field_1 = module_0.Field()
    field_2 = module_0.Field()
    import pprint
    pp = pprint.PrettyPrinter(indent=2)
    pp.pprint(field_0.validate([{'0': 0}]))
    pp.pprint(field_1.validate({'0': 'a', '1': 'b', 'c': 1}))
    pp.pprint(field_2.validate(['a', 'b', 'c', 'd']))
    one_of_0 = OneOf([field_0, field_1, field_2])


# Generated at 2022-06-26 10:10:03.976716
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        # IfThenElse(negated=None, if_clause=None, then_clause=None, else_clause=None, description=None, format=None, title=None, errors=None, required=False, default=None)
        if_then_else_0 = IfThenElse(None, None, None, None, None, None, None, None, False, None)
        assert if_then_else_0 is not None
        assert if_then_else_0.if_clause is not None
    except Exception as e:
        print('Exception is: ', str(e))
        quit(-1)
    else:
        pass
    finally:
        pass


# Generated at 2022-06-26 10:10:10.497375
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_0 = module_0.Field()
    if_then_else_0 = IfThenElse(field_0, field_0)
    # Call tested method
    if_then_else_0.validate(None)
    # Check for consistency of return value
    assert True


# Generated at 2022-06-26 10:10:15.065800
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=never_match_0)
    assert not_0.validate(value=None) is None
    try:
        not_0.validate(value="")
        raise RuntimeError("AssertionError not raised")
    except AssertionError:
        pass


# Generated at 2022-06-26 10:10:21.527218
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = Field()
    one_of_0 = OneOf()
    # TEST CASE: no_match
    value_0 = None
    strict_0 = False
    # TEST CASE: multiple_matches
    value_1 = None
    strict_1 = False


# Generated at 2022-06-26 10:10:24.996771
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(123)
    assert not_0.validate(123) == 123
    assert not_0.validate(456) == 456
    assert not_0.validate(789) == 789


# Generated at 2022-06-26 10:10:37.324961
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = module_0.Field()
    then_clause_0 = module_0.Field()
    else_clause_0 = module_0.Field()
    value_0 = 'x'
    strict_0 = True
    else_clause_0.validate = typesystem.utils.Mock(return_value=None)
    if_clause_0.validate_or_error = typesystem.utils.Mock(return_value=(value_0, None))
    then_clause_0.validate = typesystem.utils.Mock(return_value=None)
    ifThenElse_0 = IfThenElse(if_clause_0,then_clause_0,else_clause_0)
    result_0 = ifThenElse_0.validate('x',True)


# Generated at 2022-06-26 10:10:47.058213
# Unit test for method validate of class Not
def test_Not_validate():
    field_0 = module_0.Field()
    not_0 = Not(negated=field_0)

    for value_0 in [None, float("NaN"), -1.0, 0.0, 1.0, float("inf"), float("-inf")]:
        try:
            not_0.validate(value_0)
            assert False, ('TypeError not raised', value_0)
        except TypeError:
            pass

    value_0 = '\u05e0\x94\u06ab\ufffc\u0720\x9e\ufff3\xbb\u0a23\xa7\x1f'
    not_0.validate(value_0)



# Generated at 2022-06-26 10:10:51.719339
# Unit test for constructor of class Not
def test_Not():
    negated_0: Field = None
    not_0 = Not(negated=negated_0)
    assert not_0.negated == negated_0


# Generated at 2022-06-26 10:10:54.945941
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(never_match_0).validate({}) is not None

# Generated at 2022-06-26 10:10:58.089928
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    never_match_0 = NeverMatch()

    one_of_0 = OneOf(one_of=[never_match_0])

    # Test case 0
    one_of_0.validate(value=22, strict=True)



# Generated at 2022-06-26 10:11:03.652291
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        one_of_0 = OneOf(one_of = [never_match_0])
    except Exception as e:
        print('Test failed: ', str(e))


# Generated at 2022-06-26 10:11:06.494970
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.code == "never"


# Generated at 2022-06-26 10:11:12.044418
# Unit test for method validate of class Not
def test_Not_validate():
    # Verify that Not().validate() works correctly with None
    field = Not(None)
    result = field.validate(None)
    assert True

# Generated at 2022-06-26 10:11:16.574194
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ifThenElse_0 = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    ifThenElse_0.validate(value=None)


# Generated at 2022-06-26 10:11:19.285280
# Unit test for constructor of class Not
def test_Not():
    negated = Not(AllOf([OneOf([Any()])]))
    assert negated.negated is not None



# Generated at 2022-06-26 10:11:27.643555
# Unit test for method validate of class Not
def test_Not_validate():
    def _inner_test_validate(value):
        not_0 = Not(value)
        not_0.validate(value)
    _inner_test_validate(NeverMatch())
    _inner_test_validate(Not(NeverMatch()))
    _inner_test_validate(IfThenElse(NeverMatch()))


# Generated at 2022-06-26 10:11:41.832381
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Pass
    test_object_0 = NeverMatch()
    test_value_0 = "test string"
    assert test_object_0.validate(test_value_0) is None
    # Fail
    test_object_1 = NeverMatch()
    test_value_1 = 123
    try:
        test_object_1.validate(test_value_1)
    except Exception as error:
        test_value_1 = error

    assert type(test_value_1) == NeverMatch.validation_error.__class__
    # Fail
    test_object_2 = NeverMatch()
    test_value_2 = None
    try:
        test_object_2.validate(test_value_2)
    except Exception as error:
        test_value_2 = error


# Generated at 2022-06-26 10:11:43.932108
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(Field())


# Generated at 2022-06-26 10:11:51.016760
# Unit test for constructor of class Not
def test_Not():
    # Init
    negated = NeverMatch()

    # Test
    not_ = Not(negated)

    # Verify
    assert isinstance(not_.negated, NeverMatch)



# Generated at 2022-06-26 10:11:52.713828
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([])


# Generated at 2022-06-26 10:12:00.006213
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0_1_2 = NeverMatch()
    then_clause_0_1_2 = NeverMatch()
    else_clause_0_1_2 = NeverMatch()
    value_0_1_2 = None
    strict_0_1_2 = True

    if_clause_0_1_3 = NeverMatch()
    then_clause_0_1_3 = NeverMatch()
    else_clause_0_1_3 = NeverMatch()
    value_0_1_3 = None
    strict_0_1_3 = True

    if_clause_0_1_4 = NeverMatch()
    then_clause_0_1_4 = NeverMatch()
    else_clause_0_1_4 = NeverMatch()
    value_0_1_4 = None


# Generated at 2022-06-26 10:12:02.246853
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Boolean
    not_bool = Not(Boolean())
    not_bool.validate(None)
    assert not_bool.validate(False) == False


# Generated at 2022-06-26 10:12:05.909732
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_case_0()


if __name__ == "__main__":
    test_IfThenElse()

# Generated at 2022-06-26 10:12:09.933130
# Unit test for method validate of class Not
def test_Not_validate():
    val = "anotheroption"
    validator = Not(Mapping({"one": Any(), "two": Any()}))
    validator.validate(val)


# Generated at 2022-06-26 10:12:14.107820
# Unit test for constructor of class Not
def test_Not():
    field0 = Field(name="test_field", description="test_description")
    instance0 = Not(negated=field0)
    assert isinstance(instance0, Field)
    assert instance0.name == "test_field"
    assert instance0.negated == field0



# Generated at 2022-06-26 10:12:21.258167
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem import Schema

    class TestSchema(Schema):
        foo = Not(String())

    schema = TestSchema()

    assert schema.validate({"foo": 1}) == {"foo": 1}
    assert schema.validate({"foo": "bar"}) == {"foo": "bar"}


# Generated at 2022-06-26 10:12:25.270276
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_IfThenElse = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    value = "test"
    strict = True
    expected_value = "test"
    actual_value = test_IfThenElse.validate(value, strict)
    assert actual_value == expected_value


# Generated at 2022-06-26 10:12:28.313871
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:12:37.284903
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    strict_0 = True
    value_0 = 0
    assert if_then_else_0.validate(value_0, strict_0) == value_0


# Generated at 2022-06-26 10:12:43.566289
# Unit test for method validate of class Not
def test_Not_validate():
    schema = Not(Any())
    # Test not matching case
    value, error = schema.validate_or_error(2)
    assert error is None
    # Test matching case
    value, error = schema.validate_or_error(None)
    assert error != None


# Generated at 2022-06-26 10:12:53.404283
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    boolean_0 = Boolean()
    boolean_1 = Boolean()
    if_then_else_0 = IfThenElse(boolean_0, then_clause=boolean_1)
    boolean_2 = Boolean()
    boolean_3 = Boolean()
    if_then_else_1 = IfThenElse(boolean_2, then_clause=boolean_3)
    boolean_4 = Boolean()
    boolean_5 = Boolean()
    if_then_else_2 = IfThenElse(boolean_4, then_clause=boolean_5)
    boolean_6 = Boolean()
    boolean_7 = Boolean()
    if_then_else_3 = IfThenElse(boolean_6, then_clause=boolean_7)
    boolean_8 = Boolean()
    boolean_9 = Boolean()
    if_

# Generated at 2022-06-26 10:12:55.497732
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of = [])


# Generated at 2022-06-26 10:12:58.001016
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(boolean(), number(), object_())
    result = field.validate(True)
    assert result == 3
    result = field.validate(False)
    assert result == {"hello": "world"}

# Generated at 2022-06-26 10:12:59.164701
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass



# Generated at 2022-06-26 10:13:04.102917
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    d = {1: 'One', 2: 'Two', 3: 'Three'}
    type_a = OneOf(d)
    print(type_a.validate(2))


# Generated at 2022-06-26 10:13:05.880403
# Unit test for constructor of class Not
def test_Not():
    f1 = OneOf([String()])
    f2 = Not(f1)

# Generated at 2022-06-26 10:13:09.778860
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([Any(), Any()])
    all_of_1 = AllOf([Float()])
    all_of_2 = AllOf([Integer()])
    all_of_3 = AllOf(all_of=[Decimal()])

# Generated at 2022-06-26 10:13:21.453560
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert (
        NeverMatch.__init__.__code__.co_varnames
        == ("self", "kwargs", "__kwargs_param_name", "__configured")
    )
    assert NeverMatch.__init__.__defaults__ == (None,)
    assert NeverMatch.__init__.__kwdefaults__ == None
    assert (
        NeverMatch.__init__.__annotations__ == {"self": NeverMatch, "kwargs": dict}
    )
    assert NeverMatch._fields == None
    assert NeverMatch.validate.__code__.co_varnames == (
        "self",
        "value",
        "strict",
        "__kwargs_param_name",
        "__configured",
    )

# Generated at 2022-06-26 10:13:25.591199
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=not_0)


# Generated at 2022-06-26 10:13:26.833627
# Unit test for constructor of class NeverMatch
def test_NeverMatch():

    assert isinstance(NeverMatch(), NeverMatch)

# Generated at 2022-06-26 10:13:30.621600
# Unit test for method validate of class Not
def test_Not_validate():
    errors = {"negated": "Must not match."}

    negated_0 = Any()
    negated_0_expected = Any()
    # Call method validate of class Not
    result_0 = Not(negated_0).validate(None)
    assert result_0 == negated_0_expected


# Generated at 2022-06-26 10:13:33.794046
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, NeverMatch)


# Generated at 2022-06-26 10:13:43.309275
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    then_clause_0 = Any()
    if_clause_0 = Any()
    else_clause_0 = Any()
    value_0 = True
    value_1 = False
    if_clause_1 = OneOf([if_clause_0])
    value_2 = False
    value_3 = False
    if_clause_2 = OneOf([then_clause_0, else_clause_0])
    value_4 = True
    value_5 = False
    if_clause_3 = Not(if_clause_0)
    value_6 = False
    value_7 = False
    if_clause_4 = Not(if_clause_1)
    value_8 = True
    value_9 = False

# Generated at 2022-06-26 10:13:47.618645
# Unit test for method validate of class Not
def test_Not_validate():
    """
    It's possible to have the schema validator validate your schema, it just
    has to be wrapped in a not-matching type.
    """
    # first we need to create the schema validator
    from typesystem import Schema, core

    schema_validator = Schema(core.Object({
        "name": core.String(),
        "children": core.Array(core.Object({
            "name": core.String(),
            "children": core.Array(core.Ref(core.Ref("#"))),
            "age": core.Number(),
        })),
        "age": core.Number(),
    }))

    # now wrap it in a `Not` field.
    schema_validator = Not(schema_validator)

    # now parse the schema and validate it.

# Generated at 2022-06-26 10:13:50.515256
# Unit test for method validate of class Not
def test_Not_validate():
    negated = AllOf([never_match_0])
    not_ = Not(negated)

    # Valid
    value = {}
    result = not_.validate(value, strict=False)
    assert result == value


# Generated at 2022-06-26 10:13:56.656873
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    never_match_ = Not(never_match_0)
    never_match___1 = never_match_.validate("tuple()")
    assert not (never_match___1 is None)


# Generated at 2022-06-26 10:13:59.458535
# Unit test for method validate of class Not
def test_Not_validate():
    assert NeverMatch().validate(5) == 5

# Generated at 2022-06-26 10:14:06.407237
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of = [])
    one_of_1 = OneOf(one_of = [])
    assert one_of_0 is not one_of_1


# Generated at 2022-06-26 10:14:11.192990
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated=never_match_0)

if __name__ == '__main__':
    test_case_0()
    test_Not()

# Generated at 2022-06-26 10:14:15.874599
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([NeverMatch()])
    all_of_1 = AllOf([])
    all_of_2 = AllOf([NeverMatch()])


# Generated at 2022-06-26 10:14:17.998834
# Unit test for constructor of class Not
def test_Not():
    negated = Not(1, 2)



# Generated at 2022-06-26 10:14:21.152924
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    obj = IfThenElse(None, None, None)
    assert obj.validate(None) is None


# Generated at 2022-06-26 10:14:28.058843
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([Any()])
    assert one_of_0.validate(0) == 0
    assert one_of_0.validate(-0) == 0
    assert one_of_0.validate(0.0) == 0.0
    assert one_of_0.validate(()) == ()
    assert one_of_0.validate([]) == []
    assert one_of_0.validate({}) == {}
    assert one_of_0.validate("0") == "0"
    assert one_of_0.validate(True) is True
    assert one_of_0.validate(False) is False
    assert one_of_0.validate(None) is None

# Generated at 2022-06-26 10:14:40.104686
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None #TODO

# Generated at 2022-06-26 10:14:47.607990
# Unit test for constructor of class AllOf
def test_AllOf():
    inputs1 = [{"name": "one", "type": "string"}, {"name": "two", "type": "string"}]
    inputs2 = [{"name": "three", "type": "string"}, {"name": "four", "type": "string"}]
    test1 = AllOf(inputs1)
    test2 = AllOf(inputs1, **{"raw": True})
    test3 = AllOf(inputs2, **{"allow_null": True})
    assert test1.raw is False
    assert test2.raw is True
    assert test3.allow_null is True


# Generated at 2022-06-26 10:14:50.906905
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.validate(None)


# Generated at 2022-06-26 10:14:56.147976
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    then_clause_value = "abc"
    else_clause_value = "123"
    schema_value = True
    expected = then_clause_value
    actual = IfThenElse(Any()).validate(schema_value)
    assert actual == expected


# Generated at 2022-06-26 10:14:58.138997
# Unit test for constructor of class OneOf
def test_OneOf():
    t = OneOf(one_of=[])


# Generated at 2022-06-26 10:15:03.943549
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test class AllOf constructor
    all_of_0 = AllOf(None)
    all_of_1 = AllOf(None)



# Generated at 2022-06-26 10:15:06.040130
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    zero_or_one = OneOf([Field(default=0), Field(default=1)])


# Generated at 2022-06-26 10:15:09.537154
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        never_match_0 = NeverMatch(allow_null=True)


# Generated at 2022-06-26 10:15:10.813799
# Unit test for constructor of class AllOf
def test_AllOf():
    test = AllOf([])


# Generated at 2022-06-26 10:15:13.620246
# Unit test for constructor of class AllOf
def test_AllOf():
    foo_str = String(max_length=20, regex="foo")
    foo_int = Integer(minimum=0, maximum=7)
    test_AllOf = AllOf([foo_str, foo_int, foo_int])

# Generated at 2022-06-26 10:15:24.956011
# Unit test for constructor of class AllOf
def test_AllOf():
    import json
    json_string = '{"items": [{"type": "integer"}], "type": "array", "additionalItems": False}'
    json_object = json.loads(json_string)
    field = AllOf(**json_object)
    assert field.kwargs == json_object
    assert field.items == [Integer()]
    assert field.allow_additional_items == {'additionalItems': False}
    assert field.type == 'array'
    try:
        field.kwargs == {'error': 'error message'}
        field.items == [String()]
        field.allow_additional_items == {'additionalItems': True}
        field.type == 'boolean'
    except:
        pass


# Generated at 2022-06-26 10:15:25.702992
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])


# Generated at 2022-06-26 10:15:30.097054
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True


# Generated at 2022-06-26 10:15:34.006335
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of=(Integer(),), allow_blank=False, max_length=None, min_length=None, pattern=None)


# Generated at 2022-06-26 10:15:41.970602
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field_0 = OneOf([])
    str_0 = "Validating a null value is invalid here."
    with pytest.raises(AssertionError) as exception:
        one_of_field_0.validate(None)
    assert str_0 == str(exception.value)


# Generated at 2022-06-26 10:15:52.024999
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([never_match_0, never_match_0])
    assert isinstance(one_of, OneOf)
    assert one_of._errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}
    assert one_of._name == 'one_of'


# Generated at 2022-06-26 10:15:55.197908
# Unit test for constructor of class AllOf
def test_AllOf():
    if_clause_0 = AllOf(all_of_0)
    assert if_clause_0.all_of == all_of_0


# Generated at 2022-06-26 10:15:59.920518
# Unit test for constructor of class OneOf
def test_OneOf():
    # List of Fields
    one_of_0 = [NeverMatch()]
    one_of_1 = one_of_0
    # Field
    one_of_2 = OneOf(one_of_1)


# Generated at 2022-06-26 10:16:06.135046
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}
    assert not never_match_0.allow_null
    assert never_match_0.default is None
    assert never_match_0.description is None
    assert never_match_0.name is None
    assert never_match_0.title is None


# Generated at 2022-06-26 10:16:08.398408
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:16:14.629100
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0 = NeverMatch()
    then_clause_0 = Any()
    else_clause_0 = never_match_0
    IfThenElse(if_clause_0, then_clause_0, else_clause_0)

# Generated at 2022-06-26 10:16:19.525802
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import pytest
    from typesystem.exceptions import ValidationError
    one_of_0 = OneOf(one_of = [])
    with pytest.raises(ValidationError):
        one_of_0.validate({})


# Generated at 2022-06-26 10:16:23.592494
# Unit test for constructor of class Not
def test_Not():
    with raises(AssertionError):
        Not(
            negated=None,
        )


# Generated at 2022-06-26 10:16:32.329982
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated = "")
    assert_true(not_0 is not None, "constructor returned a value")
    assert_true(isinstance(not_0, Not), "should be an instance of type Not")
    assert_equal(not_0.errors, {"negated": "Must not match."}, "errors should be equal to {\"negated\": \"Must not match.\"}")
    assert_equal(not_0.negated, "", "negated should be equal to \"\"")


# Generated at 2022-06-26 10:16:37.136531
# Unit test for constructor of class OneOf
def test_OneOf():
    arg_0 = [NeverMatch(), NeverMatch()]
    result = OneOf(arg_0)
    assert isinstance(result, OneOf)


# Generated at 2022-06-26 10:16:52.453028
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from unittest import mock
    import typing

    mocked_child_validate = mock.Mock()
    mocked_child_validate.return_value = ("validated", None)
    mocked_child_1 = mock.Mock()
    mocked_child_1.validate_or_error = mocked_child_validate
    mocked_child_2 = mock.Mock()
    mocked_child_2.validate_or_error = mocked_child_validate
    mocked_child_3 = mock.Mock()
    mocked_child_3.validate_or_error = mocked_child_validate

    one_of_field = OneOf([mocked_child_1, mocked_child_2, mocked_child_3])
    actual = one_of_field.validate(1)
    expected = "validated"

# Generated at 2022-06-26 10:16:53.945228
# Unit test for constructor of class AllOf
def test_AllOf():
    test_case_0()

# Generated at 2022-06-26 10:16:59.868406
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError) as excinfo:
        negated = Field()
        not_1 = Not(negated)
    assert 'Did not raise AssertionError' in str(excinfo.value)

# Generated at 2022-06-26 10:17:03.749147
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [Any(), NeverMatch()]
    one_of = OneOf(fields, nullable=True)


# Generated at 2022-06-26 10:17:07.711126
# Unit test for constructor of class OneOf
def test_OneOf():
    never_match_1 = NeverMatch()
    never_match_2 = NeverMatch()
    oneOf = OneOf([never_match_1, never_match_2])


# Generated at 2022-06-26 10:17:11.608690
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = OneOf(one_of=[AlwaysMatch()])
    field_0.validate(value="")
    field_1 = OneOf(one_of=[NeverMatch()])
    field_1.validate(value="")



# Generated at 2022-06-26 10:17:18.371045
# Unit test for constructor of class OneOf
def test_OneOf():
    # Create example object and validate
    list_0 = []
    list_0.append(NeverMatch())
    never_match_0 = NeverMatch()
    field_0 = OneOf(list_0)
    assert isinstance(field_0, Field)


# Generated at 2022-06-26 10:17:20.683070
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated=Field(required=True))


# Generated at 2022-06-26 10:17:33.022189
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    clauses = [
        (
            None,
            None,
            None,
        ),
        (
            NeverMatch(),
            None,
            None,
        ),
        (
            None,
            NeverMatch(),
            None,
        ),
        (
            None,
            None,
            NeverMatch(),
        ),
        (
            NeverMatch(),
            NeverMatch(),
            None,
        ),
        (
            NeverMatch(),
            None,
            NeverMatch(),
        ),
        (
            None,
            NeverMatch(),
            NeverMatch(),
        ),
        (
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
        ),
    ]
    for clause in clauses:
        IfThenElse(*clause)

# Generated at 2022-06-26 10:17:44.083562
# Unit test for constructor of class OneOf
def test_OneOf():

    # TEST CASE: Constructor of class OneOf
    # Instance creation of class OneOf
    one_of_0 = OneOf([Any()])
    one_of_0 = OneOf(one_of=[Any()])
    one_of_0 = OneOf(one_of=[Any(), Any()])
    one_of_0 = OneOf(one_of=[Any(), Any(), Any()])
    one_of_0 = OneOf(one_of=[Any(), Any(), Any(), Any()])
    one_of_0 = OneOf(one_of=[Any(), Any(), Any(), Any(), Any()])
    one_of_0 = OneOf(one_of=[Any(), Any(), Any(), Any(), Any(), Any()])

# Generated at 2022-06-26 10:18:07.832257
# Unit test for constructor of class Not
def test_Not():
    never_match_1 = NeverMatch()

    not_0 = Not(negated=never_match_1)

    # Type check for field negated
    # Should be of class typesystem.fields.Field

    if not isinstance(not_0.negated, Field):
        print("Expected type of negated field to be typesystem.fields.Field")
        return False

    # Test case for non-nullable value types

    try:
        not_1 = Not(negated=None)
    except TypeError:
        pass
    else:
        print("Expected TypeError to be raised for non-nullable value types")
        return False

    return True


# Generated at 2022-06-26 10:18:09.297580
# Unit test for constructor of class Not
def test_Not():
    negated_0 = Any()
    not_0 = Not(negated=negated_0)


# Generated at 2022-06-26 10:18:10.477152
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([NeverMatch()])


# Generated at 2022-06-26 10:18:22.231910
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.null is False
    assert never_match_0.errors == {'never': 'This never validates.'}
    never_match_1 = NeverMatch(description='q3%')
    never_match_2 = NeverMatch(description='ov. ')
    assert never_match_2.description == 'ov. '
    never_match_3 = NeverMatch(description=';n ')
    assert never_match_3.description == ';n '
    never_match_4 = NeverMatch()
    never_match_4.validate('!')
    never_match_5 = NeverMatch(description='mui@')
    never_match_6 = NeverMatch(description='?i]1')

# Generated at 2022-06-26 10:18:23.549642
# Unit test for constructor of class AllOf
def test_AllOf():
    # Constructor Test
    all_of_0 = AllOf([])
    assert (all_of_0.all_of == [])


# Generated at 2022-06-26 10:18:27.067259
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create a OneOf instance
    one_of_0 = OneOf([Any(), Any(), Any()])
    # Run method validate
    ret_val_0 = one_of_0.validate(0)


# Generated at 2022-06-26 10:18:37.328793
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([Class(key=String()), Class(key=Integer())])
    one_of_1 = OneOf([Class(key=String(), value=Boolean())])
    one_of_2 = OneOf([Class(key=String()), Class(key=Integer()), Class(key=Boolean())])
    one_of_3 = OneOf([Class(key=String()), Class(key=Integer()), Class(key=Boolean()), Class(key=Float())])


# Generated at 2022-06-26 10:18:41.564561
# Unit test for constructor of class Not
def test_Not():
    with raises(AssertionError):
        not_instance_0 = Not(Field)
    not_instance_1 = Not(Field, help_text="")

# Generated at 2022-06-26 10:18:44.945296
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
#    assert never_match_0.validate(False) is None


# Generated at 2022-06-26 10:18:50.246634
# Unit test for constructor of class Not
def test_Not():
    negated = NeverMatch()

    # Invalid
    try:
        Not()
    except Exception:
        pass

    # Invalid
    try:
        Not(negated=negated, x="x")
    except Exception:
        pass

    # Valid
    try:
        Not(negated=negated)
    except Exception:
        pass



# Generated at 2022-06-26 10:19:08.136818
# Unit test for constructor of class Not
def test_Not():
    try:
        field = Not(None)
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-26 10:19:09.587270
# Unit test for constructor of class Not
def test_Not():
    pass



# Generated at 2022-06-26 10:19:12.550263
# Unit test for constructor of class OneOf
def test_OneOf():
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, NeverMatch)
    all_of_0 = AllOf(one_of=[NeverMatch()])
    assert isinstance(all_of_0, AllOf)


# Generated at 2022-06-26 10:19:14.845370
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])


# Generated at 2022-06-26 10:19:18.218571
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf()


# Generated at 2022-06-26 10:19:19.649291
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:19:25.124360
# Unit test for constructor of class OneOf
def test_OneOf():
    test_case_OneOf_0()
    test_case_OneOf_1()
    test_case_OneOf_2()
    test_case_OneOf_3()
    test_case_OneOf_4()
    test_case_OneOf_5()
    test_case_OneOf_6()

# Test case for class OneOf

# Generated at 2022-06-26 10:19:27.168273
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[])
    one_of_1 = OneOf(one_of=[], allow_null=False)


# Generated at 2022-06-26 10:19:31.321979
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        never_match_0 = NeverMatch()
    except Exception as inst:
        assert False, "Unexpected exception type in NeverMatch(): {}".format(
            inst
        )
    return



# Generated at 2022-06-26 10:19:32.725265
# Unit test for constructor of class OneOf
def test_OneOf():
    pass
