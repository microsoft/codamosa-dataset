

# Generated at 2022-06-26 10:09:39.407969
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert 1 == 1


# Generated at 2022-06-26 10:09:47.124765
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Testing the first condition
    try:
        one_of_1 = OneOf([NeverMatch(), NeverMatch()])
        one_of_1.validate(None)
    except:
        assert True
    else:
        assert False
    # Testing the second condition
    try:
        one_of_1 = OneOf([NeverMatch(), NeverMatch()])
        one_of_1.validate(None)
    except:
        assert True
    else:
        assert False
    # Testing the third condition
    try:
        one_of_1 = OneOf([NeverMatch(), NeverMatch()])
        one_of_1.validate(None)
    except:
        assert True
    else:
        assert False
    # Testing the fourth condition

# Generated at 2022-06-26 10:09:53.304277
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = True
    i = IfThenElse(if_clause, then_clause, else_clause)
    i.validate(value, strict)

# Generated at 2022-06-26 10:10:01.142933
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    # Test whether an exception is raised for a valid value
    one_of_0.validate(None)
    # Test whether an exception is raised for an invalid value
    try:
        one_of_0.validate(None)
    except Exception as e:
        assert type(e) is AssertionError


# Generated at 2022-06-26 10:10:02.842482
# Unit test for constructor of class AllOf
def test_AllOf():
    field = test_case_0()
    never_match_0 = AllOf(field)


# Generated at 2022-06-26 10:10:14.377127
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    v1 = IfThenElse(Integer(), allow_null=True)
    v2 = IfThenElse(Integer(), allow_null=False)
    v3 = IfThenElse(Integer(), then_clause=Boolean(), allow_null=True)
    v4 = IfThenElse(Integer(), then_clause=Boolean(), allow_null=False)
    v5 = IfThenElse(Integer(), else_clause=Boolean(), allow_null=True)
    v6 = IfThenElse(Integer(), else_clause=Boolean(), allow_null=False)

    validate_primitive(v1, 4, 4)
    validate_primitive(v2, 4, 4)
    validate_primitive(v1, 4.0, 4)
    validate_primitive(v1, True, None)

# Generated at 2022-06-26 10:10:19.129671
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    value_0 = None
    strict_0 = False
    one_of_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:10:25.397547
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    field = IfThenElse(if_clause, then_clause, else_clause)
    # Call method validate of class IfThenElse
    value = field.validate()
    # Return value of method validate of class IfThenElse should be None
    assert value is None


# Generated at 2022-06-26 10:10:33.241518
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause=then_clause_0, else_clause=else_clause_0)

# Generated at 2022-06-26 10:10:46.639971
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = OneOf([NeverMatch(), NeverMatch()])
    field_1 = OneOf([NeverMatch(), NeverMatch()])
    field_2 = OneOf([NeverMatch(), NeverMatch()])
    field_3 = OneOf([NeverMatch(), NeverMatch()])
    field_4 = OneOf([NeverMatch(), NeverMatch()])
    field_5 = OneOf([NeverMatch(), NeverMatch()])
    field_6 = OneOf([NeverMatch(), NeverMatch()])
    field_7 = OneOf([NeverMatch(), NeverMatch()])
    field_8 = OneOf([NeverMatch(), NeverMatch()])
    field_9 = OneOf([NeverMatch(), NeverMatch()])
    field_10 = OneOf([NeverMatch(), NeverMatch()])
    field_11 = OneOf([NeverMatch(), NeverMatch()])
    field_12 = OneOf

# Generated at 2022-06-26 10:10:55.777815
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(NegationType())
    result, error = field.validate_or_error(5, strict=True)
    print(result)
    assert result == 5
    print(error)
    assert error is None
    # TODO: Implement test case for variant #0 of Not.validate


# Generated at 2022-06-26 10:10:57.556935
# Unit test for method validate of class Not
def test_Not_validate():
    negated: Field = NeverMatch()
    validator: Field = Not(negated)
    validator.validate(1)


# Generated at 2022-06-26 10:11:10.233374
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class FirstClass:
        pass
    class SecondClass:
        pass
    class ThirdClass:
        pass
    if_clause = lambda x: x == FirstClass
    def then_clause(value, strict=False) -> typing.Any:
        returns = []
        expected = [FirstClass]
        returns = IfThenElse(if_clause, then_clause, else_clause, name='test_IfThenElse_validate').validate(value, strict=strict)
        assert returns in expected
    else_clause = lambda x: x == ThirdClass
    # Call the function
    test_IfThenElse_validate_instance = IfThenElse(if_clause, then_clause, else_clause, name='test_IfThenElse_validate')
    test_IfThenElse_validate_instance.valid

# Generated at 2022-06-26 10:11:13.713693
# Unit test for method validate of class Not
def test_Not_validate():
    print("Testing validate")
    field = Not(None)
    assert field.validate(None) == None



# Generated at 2022-06-26 10:11:18.077818
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_1 = NeverMatch()
    negated_field = Not(negated=never_match_1)
    value = None
    assert negated_field.validate(value) == None


# Generated at 2022-06-26 10:11:21.469749
# Unit test for method validate of class Not
def test_Not_validate():

    f = Not(None, allow_null=True, name="foo")

    (result, error) = f.validate_or_error(None)
    assert error is None, f"Error is {error}"
    assert result is None, f"Result is {result}"

    (result, error) = f.validate_or_error("bar")
    assert error is None, f"Error is {error}"
    assert result is "bar", f"Result is {result}"

# Generated at 2022-06-26 10:11:23.816352
# Unit test for constructor of class Not
def test_Not():
    negated = Field()
    not1 = Not(negated)



# Generated at 2022-06-26 10:11:29.973352
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(negated=never_match_0)
    value_0 = int()
    try:
        not_0.validate(value_0)
    except ValidationError as e:
        assert e.detail == '{"negated": "Must not match."}'
        assert e.kwargs == {}
        assert e.detail == e.detail

# Generated at 2022-06-26 10:11:35.612057
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_2 = NeverMatch()
    not_0 = Not(negated=never_match_2)
    assert not_0.validate(value="a") == "a"



# Generated at 2022-06-26 10:11:36.976363
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(Field, Field)



# Generated at 2022-06-26 10:11:43.846563
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test for method validate of class IfThenElse
    """
    validating_field = IfThenElse(if_clause=NeverMatch())
    with pytest.raises(ValidationError):
        validating_field.validate(value=None, strict=False)

# Generated at 2022-06-26 10:11:47.050177
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create the object
    one_of = OneOf([])

    # Create the test_value
    test_value = 0

    # Run the test
    assert one_of.validate(test_value) == test_value



# Generated at 2022-06-26 10:11:54.370154
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    choices = [NeverMatch(), NeverMatch()]
    one_of = OneOf(choices)

    # Unit test for case none of the choices matches
    try:
        one_of.validate(None)
    except:
        pass

    # Unit test for case more than one choice matches
    try:
        one_of.validate(None)
    except:
        pass
    # Unit test for case one choice matches
    try:
        one_of.validate(None)
    except:
        pass



# Generated at 2022-06-26 10:11:55.615043
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(NeverMatch())
    value = True
    assert field.validate(value, strict=True) is True

# Generated at 2022-06-26 10:12:05.512006
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test if then clause is None
    if_clause = NeverMatch()
    then_clause = None
    else_clause = NeverMatch()
    test_IfThenElse_validate_then_clause_is_none(if_clause, then_clause, else_clause)

    # Test if else clause is None
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = None
    test_IfThenElse_validate_else_clause_is_None(if_clause, then_clause, else_clause)

    # Test if both then and else clauses are None
    if_clause = NeverMatch()
    then_clause = None
    else_clause = None
    test_IfThenElse_validate_both_then_and_else

# Generated at 2022-06-26 10:12:10.665769
# Unit test for method validate of class Not
def test_Not_validate():
    # Initialize the target object
    not_0 = Not(negated=None)
    # Initialize the parameters
    value = 0
    strict = False
    # Invoke the target method
    not_0.validate(value, strict)

# Generated at 2022-06-26 10:12:13.857519
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer, String
    from typesystem.exceptions import ValidationError
    field = OneOf([Integer(), String()])
    field.validate(1)
    field.validate('foo')


# Generated at 2022-06-26 10:12:24.169454
# Unit test for constructor of class Not
def test_Not():
    NeverMatch = NeverMatch()
    not_0 = Not(None)
    not_1 = Not(None, name="not_1")
    not_2 = Not(None, none_message="not_2")
    not_3 = Not(NeverMatch, name="not_3")
    not_4 = Not(NeverMatch, none_message="not_4")
    not_5 = Not(None, name="not_5", none_message="not_5")
    not_6 = Not(NeverMatch, name="not_6", none_message="not_6")


# Generated at 2022-06-26 10:12:27.252418
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert never_match_0


# Generated at 2022-06-26 10:12:30.743434
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(
        if_clause=NeverMatch(),
        then_clause=NeverMatch(),
    ).validate({"foo": "bar"})

# Generated at 2022-06-26 10:12:41.089308
# Unit test for constructor of class Not
def test_Not():
    try:
        not_0 = Not(negated=Type[int]())
    except TypeError as e:
        assert '"negated" argument must be instance of "Field"' in str(e)

    try:
        not_0 = Not(negated=int())
    except TypeError as e:
        assert '"negated" argument must be instance of "Field"' in str(e)

    try:
        not_0 = Not(negated=NeverMatch(a=1, b=2))
    except TypeError as e:
        assert '"negated" argument must not have additional arguments' in str(e)

    not_0 = Not(negated=NeverMatch())


# Generated at 2022-06-26 10:12:45.461506
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    _source_code = '''
f = Field()
c = IfThenElse(Bool, Int)
'''
    _test_code = '''
f = Field()
c = IfThenElse(Bool, Int, Str)
'''
    exec(_test_code)
    assert type(f) == Field


# Generated at 2022-06-26 10:12:58.150460
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Basic case 0
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    obj_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = "foo"
    try:
        obj_0.validate(value_0, strict=True)
    except ValidationError as err:
        print("Expected to raise ValidationError: ", err)
    else:
        raise Exception("Expected exception")


# Generated at 2022-06-26 10:12:59.775714
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated = Field())


# Generated at 2022-06-26 10:13:06.358670
# Unit test for method validate of class Not
def test_Not_validate():
    test_object = Not(negated=NeverMatch())
    # testing for not negated
    assert test_object.validate(value=1) == 1
    # testing for negated
    with pytest.raises(ValidationError):
        test_object.validate(value=None)


# Generated at 2022-06-26 10:13:10.877222
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    if_clause=None
    then_clause=None
    else_clause=None
    field_object = IfThenElse(if_clause,then_clause,else_clause)
    assert field_object.validate(None) == None
    assert field_object.validate(1) == None



# Generated at 2022-06-26 10:13:19.482073
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Field, Integer

    class OneOf(Field):

        def validate(self, value, strict=False):
            if value == 'foo':
                return True

            return value.startswith('bar')

    field = OneOf()
    field.validate('foo')
    field.validate('bar')
    field.validate('baz')

    # Ensure that the superclass method is called correctly
    field = OneOf(name='example')
    field.validate('baz')


# Generated at 2022-06-26 10:13:21.259712
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[])


# Generated at 2022-06-26 10:13:30.472585
# Unit test for method validate of class Not
def test_Not_validate():
    # From example in https://json-schema.org/latest/json-schema-validation.html#anchor12
    not_0 = Not(None)
    not_0_validated = not_0.validate(True)

    not_1 = Not(NeverMatch())
    not_1_validated = not_1.validate(True)

    not_2 = Not(NeverMatch())
    not_2.validate(False)

    not_3 = Not(NeverMatch())
    not_3.validate((-10))



# Generated at 2022-06-26 10:13:36.148261
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(if_clause=never_match_0)

    result = not_0.validate_or_error(value=0)
    assert result == (0, None)  # type: ignore

# Generated at 2022-06-26 10:13:49.146598
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Field()
    then_clause_0 = Field()
    else_clause_0 = Field()
    ifthenelse_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    strict_0 = False
    value_0 = IsNull()
    typeError = None
    try:
        ifthenelse_0.validate(value_0, strict_0)
    except TypeError as e:
        typeError = e
    assert typeError is None

# Generated at 2022-06-26 10:13:57.014422
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    
    ite0 = IfThenElse(
        if_clause=Integer(),
        then_clause=Integer(),
        else_clause=Integer(),
    )
    
    if ite0.validate(True) is True:
        pass
    else:
        assert False


# Generated at 2022-06-26 10:13:59.775609
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_test_0 = NeverMatch()


# Generated at 2022-06-26 10:14:09.271074
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f1 = Field()
    f2 = None
    f3 = None
    one_of = OneOf([f1, f2, f3])
    one_of.validate(None)
    one_of.validate(None)
    one_of.validate(None)
    one_of.validate(None)
    one_of.validate(None)
    one_of.validate(None)



# Generated at 2022-06-26 10:14:13.729107
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field_0: OneOf = OneOf([Any()])
    OneOf(one_of_field_0.field, one_of_field_0.field, one_of_field_0.field, one_of_field_0.field, one_of_field_0.field, one_of_field_0.field)


# Generated at 2022-06-26 10:14:14.566264
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()



# Generated at 2022-06-26 10:14:26.159225
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """ Unit tests for method validate of class IfThenElse. """

    myInt = 1
    myFloat = 1.0
    myString = "hej"
    myList = [1,2]
    myDict = {"myInt" : myInt, "myFloat": myFloat, "myString": myString, "myList": myList}

    # Validations passed
    myIf = IfThenElse(if_clause=Integer.validate, then_clause=Integer.validate, else_clause=Integer.validate)
    myIf.validate(myInt)

    myIf = IfThenElse(if_clause=Float.validate, then_clause=Float.validate, else_clause=Float.validate)
    myIf.validate(myFloat)


# Generated at 2022-06-26 10:14:39.608272
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # OneOf
    one_of_0 = OneOf(one_of=[])
    x_0 = one_of_0.validate(True)
    assert type(x_0) is bool
    # TypeError raised, as expected
    with pytest.raises(TypeError):
        one_of_0 = OneOf([NeverMatch()])
    # TypeError raised, as expected
    with pytest.raises(TypeError):
        x_0 = one_of_0.validate(None)
    # ValueError raised, as expected
    with pytest.raises(ValueError):
        one_of_0 = OneOf(one_of=[])
    # TypeError raised, as expected
    with pytest.raises(TypeError):
        x_0 = one_of_0.validate(None)
   

# Generated at 2022-06-26 10:14:41.025881
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=NeverMatch())

# Generated at 2022-06-26 10:14:47.524380
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    never_match_0 = NeverMatch()
    if_then_else_0 = IfThenElse(never_match_0, never_match_0, never_match_0)
    if_then_else_1 = IfThenElse(never_match_0, never_match_0)
    if_then_else_2 = IfThenElse(never_match_0)
    assert if_then_else_0 is not None
    assert if_then_else_1 is not None
    assert if_then_else_2 is not None


# Generated at 2022-06-26 10:14:54.837345
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_1 = NeverMatch()
    not_0 = Not(
        negated=never_match_1
    )
    not_0.validate(
        value="testing string"
    )


# Generated at 2022-06-26 10:14:56.608518
# Unit test for constructor of class Not
def test_Not():
    # Not
    not_not = typesystem.Not(IfThenElse(never_match_0))


# Generated at 2022-06-26 10:15:06.943840
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    never_match_0 = NeverMatch()
    if_clause_1 = IfThenElse(never_match_0, then_clause=None, else_clause=None)
    strict_2 = True
    value_3 = None
    try:
        if_clause_1.validate(value_3, strict_2)
    except AssertionError as raised_exception_0:
        assert type(raised_exception_0) == AssertionError
    else:
        raise AssertionError


# Generated at 2022-06-26 10:15:10.167358
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([Boolean, String])
    one_of_0.validate(1)
    one_of_0.validate(2)
    one_of_0.validate(3)


# Generated at 2022-06-26 10:15:11.470307
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(None, None, None, default=None)

# Generated at 2022-06-26 10:15:15.893748
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # This will always match OneOf, it is basically Any
    one_of_0 = OneOf([Any()])
    one_of_1 = OneOf([Any()])
    one_of_2 = OneOf([Any()])
    one_of_3 = OneOf([Any()])


# Generated at 2022-06-26 10:15:25.199906
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0: Field
    then_clause_0: Field
    else_clause_0: Field

    # Class constructor: IfThenElse(if_clause, then_clause, else_clause)
    if_clause_0 = NeverMatch(description="")
    then_clause_0 = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    else_clause_0 = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0, description="")


# Generated at 2022-06-26 10:15:31.986803
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    _0 = NeverMatch()
    _1 = NeverMatch()
    _2 = NeverMatch()
    _0._name = "if_clause"
    _1._name = "then_clause"
    _2._name = "else_clause"
    _ = IfThenElse(_0, _1, _2)



# Generated at 2022-06-26 10:15:36.309559
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    IfThenElse(if_clause=if_clause_0, then_clause=then_clause_0, else_clause=else_clause_0)


# Generated at 2022-06-26 10:15:41.152107
# Unit test for constructor of class OneOf
def test_OneOf():
    # Undefined arguments will have default values of None
    one_of_0 = OneOf([])
    assert one_of_0.one_of == []


# Generated at 2022-06-26 10:15:54.323475
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = None
    then_clause = None
    else_clause = None
    if_clause = None
    then_clause = None
    else_clause = None
    if_clause = None
    then_clause = None
    else_clause = None
    if_clause = None
    then_clause = None
    else_clause = None
    if_clause = None
    then_clause = None
    else_clause = None

# Generated at 2022-06-26 10:15:57.116871
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    with raises(FieldError) as err:
        result = one_of_0.validate("b")
        assert err.value.code == "no_match"


# Generated at 2022-06-26 10:16:01.707092
# Unit test for method validate of class Not
def test_Not_validate():
    # Tests the validate method of class Not with default parameters
    negated = NeverMatch()
    field = Not(negated)
    value = object()
    field.validate(value)



# Generated at 2022-06-26 10:16:09.515724
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    #For this unit test we need to use the function "validate_or_error" from the class Field in order to verify the result of the validation
    one_of_0 = OneOf([Any(), Any()])

# Generated at 2022-06-26 10:16:19.107972
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([], **{})
    # No value provided, default value returned
    assert one_of_0.validate() == one_of_0.default == None
    # A single value is provided
    one_of_0 = OneOf([], **{})
    # No value provided, default value returned
    assert one_of_0.validate(10) == 10
    # A list of values is provided
    one_of_0 = OneOf([], **{})
    # No value provided, default value returned
    assert one_of_0.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-26 10:16:20.181556
# Unit test for constructor of class OneOf
def test_OneOf():
    assert hasattr(OneOf, '__init__')


# Generated at 2022-06-26 10:16:24.295234
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(None, None)
    field.validate(None)


# Generated at 2022-06-26 10:16:28.220526
# Unit test for method validate of class Not
def test_Not_validate():
    instance = Not(field=None, default=None, description=None, required=True)
    value = None
    strict = True
    actual_return = instance.validate(value, strict)
    assert actual_return is None


# Generated at 2022-06-26 10:16:37.323203
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    options = {
        "if_clause": if_clause,
        "then_clause": then_clause,
        "else_clause": else_clause,
    }
    x = IfThenElse(**options)

    value_0 = "an arbitrary string"
    strict_0 = True
    expected_0 = value_0
    actual_0 = x.validate(value_0, strict=strict_0)
    assert expected_0 == actual_0

# Generated at 2022-06-26 10:16:50.032528
# Unit test for constructor of class Not
def test_Not():
    # You should create your own error message
    try:
        not_0 = Not(None)
    except TypeError as te:
        assert te.args[0] == "Field cannot be null."
    else:
        raise AssertionError(
            "Expected TypeError exception but didn't raise. "
            "Did you change the error message?"
        )

    # You should create your own error message
    try:
        not_0 = Not(None, error_messages={"negated": "Never match."})
    except TypeError as te:
        assert te.args[0] == "Field cannot be null."
    else:
        raise AssertionError(
            "Expected TypeError exception but didn't raise. "
            "Did you change the error message?"
        )

# Generated at 2022-06-26 10:17:01.740394
# Unit test for constructor of class OneOf
def test_OneOf():
    data = [
        {
            "message": "example",
            "name": "John Doe",
            "id": 1,
        }
    ]
    field = OneOf(
        [
            Dict(
                {
                    "message": String(),
                    "name": String(),
                    "id": Integer(),
                }
            ),
            Dict(
                {
                    "message": String(),
                    "name": String(),
                    "id": String(),
                }
            ),
        ]
    )
    field.validate(data[0])


# Generated at 2022-06-26 10:17:03.901707
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([NeverMatch()])


# Generated at 2022-06-26 10:17:13.312068
# Unit test for constructor of class OneOf
def test_OneOf():
    AllOf_0 = AllOf([], description = "A very useful type.")
    AllOf_1 = AllOf([AllOf_0], description = "A very useful type.")
    OneOf_0 = OneOf([], description = "A very useful type.")
    OneOf_1 = OneOf([AllOf_0], description = "A very useful type.")
    OneOf_2 = OneOf([AllOf_1], description = "A very useful type.")
    OneOf_3 = OneOf([OneOf_1], description = "A very useful type.")
    OneOf_4 = OneOf([OneOf_2], description = "A very useful type.")
    OneOf_5 = OneOf([AllOf_0, AllOf_1], description = "A very useful type.")

# Generated at 2022-06-26 10:17:17.568287
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    value_0 = None
    strict_0 = None

    try:
        if_then_else_0 = IfThenElse(if_clause=if_clause_0, then_clause=then_clause_0, else_clause=else_clause_0)
        if_then_else_0.validate(value=value_0, strict=strict_0)
        assert False
    except:
        assert True



# Generated at 2022-06-26 10:17:19.577594
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([NeverMatch(), NeverMatch()])


# Generated at 2022-06-26 10:17:26.707584
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([
        Any(min_length=1), 
        Boolean(), 
        Integer(), 
        String(), 
        String(min_length=1), 
        String(min_length=1, max_length=10), 
    ])



# Generated at 2022-06-26 10:17:34.625935
# Unit test for constructor of class OneOf
def test_OneOf():
    # Fixture for OneOf tests
    # Assume
    def test_OneOf_0():
        all_of = [Any()]
        # Assume
        def test_OneOf_0_0():
            never_match_0 = NeverMatch()
            subtype_1 = never_match_0
            all_of[0] = subtype_1
        test_OneOf_0_0()
        # Assume
        def test_OneOf_0_1():
            never_match_0 = NeverMatch()
            subtype_1 = never_match_0
            all_of[0] = subtype_1
        test_OneOf_0_1()

        one_of = OneOf(all_of)
    test_OneOf_0()

# Generated at 2022-06-26 10:17:40.156375
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    one_of_0 = OneOf([NeverMatch(), NeverMatch(), NeverMatch()])
    try:
        one_of_0.validate(None)
    except Exception:
        pass
    else:
        assert False



# Generated at 2022-06-26 10:17:51.885146
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Check that name defaults to None
    assert NeverMatch().name == None

    # Check that value defaults to None
    assert NeverMatch().value == None

    # Check that required defaults to False
    assert NeverMatch().required == False

    # Check that allow_null defaults to False
    assert NeverMatch().allow_null == False

    # Check that errors defaults to {'never': 'This never validates.'}
    assert NeverMatch().errors == {'never': 'This never validates.'}

    # Check that validators defaults to []
    assert NeverMatch().validators == []

    # Check that metadata defaults to {}
    assert NeverMatch().metadata == {}

    # Check that label defaults to None
    assert NeverMatch().label == None

    # Check that help_text defaults to None
    assert NeverMatch().help_text == None

    # Check that default_error

# Generated at 2022-06-26 10:17:53.961269
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    global IfThenElse
    IfThenElse = IfThenElse(None, None, None)
    # No Exceptions raised

# Generated at 2022-06-26 10:18:15.130364
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_3 = NeverMatch()
    then_clause_4 = NeverMatch()
    else_clause_5 = NeverMatch()
    item_0 = IfThenElse(if_clause_3, then_clause_4, else_clause_5)
    str_1 = "abc"

    # Call method validate of class IfThenElse on item_0
    # This should throw an exception
    try:
        item_0.validate(str_1)
    except TypeError as raised_exception:
        assert str(raised_exception) == "This never validates."

# Generated at 2022-06-26 10:18:26.409239
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = IfThenElse(
        else_clause=None, if_clause=None, then_clause=None
    )
    str_val_0 =  "Lorem ipsum dolor sit amet, consectetur adipiscing elit."
    str_val_0 = if_clause_0.validate(str_val_0)
    assert (str_val_0 == str_val_0)



# Generated at 2022-06-26 10:18:38.221974
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Try when only one of the field matches
    field1 = NeverMatch()
    field2 = NeverMatch()
    field3 = NeverMatch()
    field4 = NeverMatch()
    field5 = NeverMatch()
    field6 = NeverMatch()
    field7 = NeverMatch()
    field8 = NeverMatch()
    field9 = NeverMatch()
    field10 = NeverMatch()
    one_of = OneOf([field1, field2, field3, field4, field5, field6, field7, field8, field9, field10])
    one_of.validate({'field': 'f1'})


# Generated at 2022-06-26 10:18:51.216664
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = ""
    strict = False
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_clause.name = Field.name
    then_clause.name = Field.name
    else_clause.name = Field.name
    then_clause.errors = Field.errors
    if_clause.errors = Field.errors
    else_clause.errors = Field.errors
    if_clause.null_value = Field.null_value
    then_clause.null_value = Field.null_value
    else_clause.null_value = Field.null_value
    if_clause.validate = Field.validate
    then_clause.validate = Field.validate
    else_clause.validate = Field.validate


# Generated at 2022-06-26 10:18:53.433877
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:19:00.855245
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    item1 = None()
    item2 = Str()
    items = [item1,item2]
    oneof = OneOf(items)
    test_string = 'abc'
    actual = oneof.validate(test_string)
    expected = pack(test_string, 'abc')
    assert actual == expected


# Generated at 2022-06-26 10:19:06.403345
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch())
    assert field.validate(None) is None
    assert field.validate(42) == 42


# Generated at 2022-06-26 10:19:09.586108
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    all_0 = [
        "Something",
        "SomethingElse",
        "AnotherThing",
    ]

    assert True


# Generated at 2022-06-26 10:19:12.631776
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer

    integer_0 = Integer()
    test_field_0 = OneOf([integer_0])
    _ = test_field_0.validate('hello')


# Generated at 2022-06-26 10:19:21.026855
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert type(never_match_0.error_messages) == dict
    assert never_match_0.error_messages.get('never') == "This never validates."
    assert type(never_match_0.errors) == dict
    assert never_match_0.errors.get('never') == "This never validates."

