

# Generated at 2022-06-26 10:09:48.967886
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    else_clause = None
    then_clause = None
    element = IfThenElse(if_clause, then_clause, else_clause)
    string = "test"
    assert element.validate(string) is None


# Generated at 2022-06-26 10:09:57.369410
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    #    """Tests the validate method of the OneOf class"""
    #    """Tests the validation of empty fields"""

    one_of_0 = OneOf(one_of = [])
    try:
        one_of_0.validate(None)
    except ValidationError as ve:
        assert ve.code == "no_match"
    else:
        assert False, 'Should have raised a ValidationError'

    one_of_1 = OneOf(one_of = [String()])
    try:
        one_of_1.validate(None)
    except ValidationError as ve:
        assert ve.code == "no_match"
    else:
        assert False, 'Should have raised a ValidationError'

    one_of_2 = OneOf(one_of = [String(), String()])
   

# Generated at 2022-06-26 10:10:02.792317
# Unit test for method validate of class Not
def test_Not_validate():
    if_clause = None
    then_clause = None
    else_clause = None
    field = IfThenElse(if_clause,then_clause,else_clause)
    value = None
    strict = False
    field.validate(value, strict)
    # Unit test for method validate of class AllOf

# Generated at 2022-06-26 10:10:06.345826
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=NeverMatch())
    # Test for positive case
    assert field.validate(field)


# Generated at 2022-06-26 10:10:13.541752
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    '''
    Method validate of class OneOf has a condition that is not met:
    if not any(item.validates(value) for item in self.one_of):
    '''
    field = OneOf([])
    value = {'a':1}
    strict = False

    try:
        field.validate(value, strict)
    except Exception as e:
        assert e.args[0] == "Did not match any valid type."


# Generated at 2022-06-26 10:10:20.172297
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    field = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)


# Generated at 2022-06-26 10:10:23.696596
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])

    assert one_of_0.validate(None) == None


# Generated at 2022-06-26 10:10:32.240327
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    field_1 = NeverMatch()
    field_2 = NeverMatch()
    field_3 = NeverMatch()
    val_1 = {}
    val_2 = {}
    f = IfThenElse(field_1, field_2, field_3)
    res = f.validate(val_1)
    #assert res == val_2



# Generated at 2022-06-26 10:10:33.647353
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()

# Generated at 2022-06-26 10:10:36.965532
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch(), else_clause=NeverMatch())
    new_value = 3
    try:
        result = field.validate(new_value)
    except field.validation_error:
        result = "failed"

    assert(result == "failed")


# Generated at 2022-06-26 10:10:44.519381
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        negated_0 = NeverMatch(allow_null=True)
        never_match_0 = Not(negated_0)


# Generated at 2022-06-26 10:10:48.084319
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(None, None)
    result = field.validate("val")
    assert result == "val"

# Generated at 2022-06-26 10:10:49.003793
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch.errors["never"] == "This never validates."
    assert callable(NeverMatch)


# Generated at 2022-06-26 10:10:50.491876
# Unit test for method validate of class Not
def test_Not_validate():
    if_clause = Not(NeverMatch())



# Generated at 2022-06-26 10:10:55.897871
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    val = OneOf(one_of=[Any()])
    result = val.validate(None)
    assert result == None

    val = OneOf(one_of=[String()])
    result = val.validate(None)
    assert result == None


# Generated at 2022-06-26 10:10:59.586703
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([{'type': 'string'}, {'type': 'integer'}])


# Generated at 2022-06-26 10:11:02.283667
# Unit test for constructor of class Not
def test_Not():
    _ = Not()



# Generated at 2022-06-26 10:11:06.165346
# Unit test for constructor of class AllOf
def test_AllOf():
    # AllOf is never initialized without arguments
    # This can be done in the following way
    try:
        assert False
    except:
        assert True


# Generated at 2022-06-26 10:11:13.784246
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(None)
    try:
        not_0.validate(None)
    except ValidationError as e:
        assert e.code == "negated"
        assert e.context == {"value": None}


# Generated at 2022-06-26 10:11:16.022566
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(None) is not None


# Generated at 2022-06-26 10:11:23.627834
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_field = AllOf([])
    assert isinstance(all_of_field, AllOf)


# Generated at 2022-06-26 10:11:33.004926
# Unit test for constructor of class OneOf
def test_OneOf():
    sub_field_0 = Any(sub_field_0_0)
    sub_field_1 = Not(sub_field_1_0, sub_field_1_1)
    sub_field_2 = AllOf(sub_field_2_0, sub_field_2_1, sub_field_2_2)
    sub_field_3 = IfThenElse(sub_field_3_0, sub_field_3_1, sub_field_3_2)
    sub_field_4 = OneOf(sub_field_4_0)
    one_of_0 = OneOf(sub_field_0, sub_field_1, sub_field_2, sub_field_3, sub_field_4)

# Generated at 2022-06-26 10:11:35.260125
# Unit test for constructor of class Not
def test_Not():
    negated = Not(negated=None)


# Generated at 2022-06-26 10:11:37.714047
# Unit test for method validate of class Not
def test_Not_validate():
    negated = NeverMatch()
    not_ = Not(negated=negated)
    not_.validate(10)

# Generated at 2022-06-26 10:11:40.870674
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors=={'never': 'This never validates.'}
    assert never_match_0.allow_null==False
    assert never_match_0.validate('a')!=None


# Generated at 2022-06-26 10:11:42.465525
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {'never': 'This never validates.'}

# Generated at 2022-06-26 10:11:46.065276
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # The following fields are required for complete JSON schema support,
    # but are undocumented as we don't recommend using them directly.

    assert True

# Generated at 2022-06-26 10:11:51.336231
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(never_match_0.errors, dict)
    assert never_match_0.errors['never'] == "This never validates."
    

one_of_0 = OneOf([never_match_0])


# Generated at 2022-06-26 10:11:55.291862
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    instance = Not(never_match_0)
    assert isinstance(instance.negated, NeverMatch)


# Generated at 2022-06-26 10:12:05.396418
# Unit test for constructor of class OneOf
def test_OneOf():
    # Example use of OneOf where we define some valid types
    # (e.g. Int, Float and String)
    int_field = Int()
    float_field = Float()
    string_field = String()
    # We then instantiate the OneOf class and pass it the Int, Float and String validators
    one_of_field = OneOf(
        fields=[
            int_field,
            float_field,
            string_field
        ]
    )

    # Unit test for validate of class OneOf
    # Here we show that a OneOf field will validate an
    # integer value
    value = 12
    one_of_field.validate(value=value)

    # Here we show that a OneOf field will raise a validation
    # error if we pass it an empty object
    from typesystem import Object

    object_field

# Generated at 2022-06-26 10:12:14.461175
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test validate method of IfThenElse
    """
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)


# Generated at 2022-06-26 10:12:18.005751
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}


# Generated at 2022-06-26 10:12:19.317335
# Unit test for constructor of class Not
def test_Not():
    # initializes Not class
    not_0 = Not(negated = None)


# Generated at 2022-06-26 10:12:21.867853
# Unit test for constructor of class Not
def test_Not():
    always_match = LaterField()
    negated = Not(always_match)


# Generated at 2022-06-26 10:12:26.142980
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem.fields import NeverMatch

    arg_0 = None

    ret_0 = NeverMatch(arg_0)

    assert isinstance(ret_0, NeverMatch)
    arg_0 = None
    arg_1 = {}

    ret_1 = NeverMatch(arg_0, **arg_1)

    assert isinstance(ret_1, NeverMatch)


# Generated at 2022-06-26 10:12:27.436728
# Unit test for constructor of class Not
def test_Not():
    not0 = Not(NeverMatch())

# Generated at 2022-06-26 10:12:33.347918
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = "if_clause"
    then_clause = "then_clause"
    else_clause = "else_clause"
    name = "name"
    description = "description"
    required = True
    error_messages = "error_messages"
    IfThenElse(if_clause, then_clause, else_clause, name = "name", description = "description", required = True, error_messages = "error_messages")


# Generated at 2022-06-26 10:12:36.701387
# Unit test for constructor of class OneOf
def test_OneOf():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    cases_0 = [ never_match_0, never_match_1 ]
    one_of_0 = OneOf(cases_0)



# Generated at 2022-06-26 10:12:39.075280
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([NeverMatch()])



# Generated at 2022-06-26 10:12:40.880106
# Unit test for constructor of class Not
def test_Not():
    negated_0 = Int()
    not_0 = Not(negated=negated_0)


# Generated at 2022-06-26 10:12:51.568936
# Unit test for constructor of class AllOf
def test_AllOf():
    # TEST: Constructor with no arguments
    assert AllOf()


# Generated at 2022-06-26 10:12:56.113843
# Unit test for constructor of class Not
def test_Not():
    # Initialize struct variable
    not_0 = Not(negated=None)
    assert not_0.negated == None
    # Initialize struct variable
    not_1 = Not(negated=None)
    assert not_1.negated == None


# Generated at 2022-06-26 10:12:57.696851
# Unit test for constructor of class Not
def test_Not():
    negated_0 = NeverMatch()
    not_field_0 = Not(negated_0)


# Generated at 2022-06-26 10:12:59.708073
# Unit test for constructor of class OneOf
def test_OneOf():
    pass


# Generated at 2022-06-26 10:13:07.426378
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([Any()])
    all_of_1 = AllOf([Any()], description="A valid description.")
    all_of_2 = AllOf([Any()], description="A valid description.", error_messages={})
    all_of_3 = AllOf([Any()], description="A valid description.", error_messages={}, name="all_of")


# Generated at 2022-06-26 10:13:20.676154
# Unit test for method validate of class Not
def test_Not_validate():
    # setup
    valid_value_0 = Not(negated=NeverMatch())
    valid_value_0.validate(None, strict=True)
    # setup
    valid_value_1 = Not(negated=NeverMatch())
    valid_value_1.validate(None, strict=True)
    # setup
    valid_value_2 = Not(negated=NeverMatch())
    valid_value_2.validate(None, strict=True)
    # setup
    valid_value_3 = Not(negated=NeverMatch())
    valid_value_3.validate(None, strict=True)
    # setup
    valid_value_4 = Not(negated=NeverMatch())
    valid_value_4.validate(None, strict=True)
    # setup

# Generated at 2022-06-26 10:13:25.205445
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_1 = NeverMatch()
    try:
        never_match_1.validate(None)
        assert False, "Expected exception"
    except ValueError:
        pass
    # The following fields are required for complete JSON schema support,
    # but are undocumented as we don't recommend using them directly.



# Generated at 2022-06-26 10:13:26.568194
# Unit test for constructor of class OneOf
def test_OneOf():
    test_case_0()


# Generated at 2022-06-26 10:13:34.128872
# Unit test for method validate of class Not
def test_Not_validate():
    # Valid cases
    try:
        never_match_0 = NeverMatch()
        not_0 = Not(negated=never_match_0)
        assert not_0.validate("Test")
    except:
        assert False

    # Invalid cases (tests else clause)
    try:
        not_0 = Not(negated=None)
        not_0.validate(None)
        assert False
    except:
        assert True

    try:
        not_0 = Not(negated=None)
        not_0.validate("")
        assert False
    except:
        assert True

    # Edge cases

# Generated at 2022-06-26 10:13:35.935087
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([NeverMatch()])


# Generated at 2022-06-26 10:13:47.622224
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # A test case
    assert True == True

# Generated at 2022-06-26 10:13:48.621984
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=None)

# Generated at 2022-06-26 10:13:51.382439
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of=[])
    assert all_of_0


# Generated at 2022-06-26 10:13:59.228413
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Initialize arguments
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    # Call method
    result = IfThenElse(if_clause, then_clause, else_clause).validate(None)
    assert isinstance(result, Field)


# Generated at 2022-06-26 10:14:03.439025
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()



# Generated at 2022-06-26 10:14:09.201584
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf()
    s = one_of.validate("hello")
    assert one_of.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}

# Generated at 2022-06-26 10:14:11.009811
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    assert all_of_0 != None


# Generated at 2022-06-26 10:14:16.264026
# Unit test for constructor of class OneOf
def test_OneOf():
    """
    No parameters test case
    """
    field_name = "test"
    one_of = []
    value = None
    one_of_0 = OneOf(one_of)


# Generated at 2022-06-26 10:14:19.199695
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(NeverMatch()).validate({"foo": "bar"}) == {"foo": "bar"}


# Generated at 2022-06-26 10:14:22.997569
# Unit test for method validate of class Not
def test_Not_validate():
    s = Not(negated = NeverMatch())
    try: 
        t = s.validate(None)
    except AssertionError:
        return True
    return False    


# Generated at 2022-06-26 10:14:46.445775
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import errors
    from typesystem import fields
    # Create two fields.
    text_field = fields.String()
    int_field = fields.Integer()

    # Create a OneOf field with the two fields as items.
    one_of_field = OneOf([text_field, int_field])

    # The field should allow a string, but not an integer.
    assert one_of_field.validate("foo") == "foo"

    # This will fail, we don't have the correct field, so it should error.
    with pytest.raises(errors.ValidationError):
        one_of_field.validate(123)



# Generated at 2022-06-26 10:14:51.876373
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    all_of_1 = AllOf([], description="description_0")
    all_of_2 = AllOf([], allow_null=True)


# Generated at 2022-06-26 10:14:54.096376
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[])


# Generated at 2022-06-26 10:15:01.473629
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass # known bug - no code coverage for nested function
    # Field.validate = mock.Mock()
    # if_clause = mock.Mock()
    # then_clause = mock.Mock()
    # else_clause = mock.Mock()
    # value = mock.Mock()
    # strict = mock.Mock()
    # if_clause.validate_or_error.return_value = (then_clause, None)
    # x = IfThenElse(if_clause, then_clause, else_clause)
    # x.validate(value, strict)
    # if_clause.validate_or_error.assert_called_with(value, strict)
    # then_clause.validate.assert_called_with(value, strict)
    # if_cl

# Generated at 2022-06-26 10:15:07.210523
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    test_val = "something"
    field = Field()
    if_clause = Field()
    then_clause = IfThenElse(if_clause, field)
    # Act
    result = then_clause.validate(test_val)
    # Assert
    assert result == "something"

# Generated at 2022-06-26 10:15:09.431325
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_1 = NeverMatch()
    schema = Not(negated=never_match_1)
    assert schema.validate("hello") == "hello"


# Generated at 2022-06-26 10:15:18.972254
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    valid_data = "Valid";
    invalid_data = "InValid";
    data_list = [valid_data, invalid_data]

    for data in data_list:
        if (data == valid_data):
            clause = True
        else:
            clause = False

        ite = IfThenElse(clause, valid_data)
        ret = ite.validate(data)

        if (data == valid_data and ret.value == valid_data):
            print ("Valid data: " + data + " is returned as " + ret.value)
            print ("Test passed")
        else:
            print ("Test failed")


test_case_0()
test_IfThenElse_validate()

# Generated at 2022-06-26 10:15:31.105039
# Unit test for constructor of class OneOf
def test_OneOf():
    import typesystem
    # Declare some types of fields

    String = typesystem.String()
    Array = typesystem.Array(
        items=typesystem.String()
    )
    Boolean = typesystem.Boolean()

    one_of_0 = OneOf(one_of=[String, Array, Boolean])
    print(one_of_0.one_of)
    print(one_of_0.validate('123'))
    print(one_of_0.validate(['123']))
    print(one_of_0.validate(True))
    print(one_of_0.errors)
    try:
        print(one_of_0.validate(None))
    except Exception as err:
        print(err)

# Generated at 2022-06-26 10:15:31.990924
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert True


# Generated at 2022-06-26 10:15:38.428965
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import pytest
    from typesystem import exceptions
    if_clause = lambda x: x % 2 == 0
    then_clause = lambda x: x % 4 == 0
    else_clause = lambda x: x % 3 == 0
    type_schema = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    class Test:
        value = 2
    test_value = Test()
    with pytest.raises(exceptions.ValidationError):
        type_schema.validate(test_value)

# Generated at 2022-06-26 10:16:00.817553
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(NeverMatch())
    not_0.validate(None)


# Generated at 2022-06-26 10:16:03.708265
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f = IfThenElse(OneOf([]))
    f.validate(1)



# Generated at 2022-06-26 10:16:04.934375
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])


# Generated at 2022-06-26 10:16:07.084617
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:16:10.216330
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=Any())
    actual = n.validate(10)
    assert actual == 10

# Generated at 2022-06-26 10:16:10.896936
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf()


# Generated at 2022-06-26 10:16:15.322773
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=NeverMatch())
    try:
        not_0.validate(value=0)
    except ValidationError:
        pass


test_Not_validate()

# Generated at 2022-06-26 10:16:24.015847
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(required=True)
    then_clause = Field(required=True)
    else_clause = Field(required=False)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(None) == None


# Generated at 2022-06-26 10:16:25.855169
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert never_match_0.errors == {"never": "This never validates."}



# Generated at 2022-06-26 10:16:28.888042
# Unit test for constructor of class Not
def test_Not():
    negated_0 = NeverMatch()
    not_0 = Not(negated=negated_0)


# Generated at 2022-06-26 10:16:46.734214
# Unit test for constructor of class Not
def test_Not():
    # Base case.
    not_0 = Not(NeverMatch())
    # Edge case.
    not_1 = Not(NeverMatch())


# Generated at 2022-06-26 10:16:57.145962
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Create an instance of the IfThenElse class.
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else_instance_0 = IfThenElse(if_clause, then_clause, else_clause)

    # Assign value to variable 'value'
    value = 0

    # Call method validate from class IfThenElse with args
    # value
    if_then_else_instance_0.validate(value)

# Generated at 2022-06-26 10:17:10.923824
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0 is not None

# Unit tests for constructor of class OneOf
# TODO:
# def test_OneOf():
#     one_of_0 = OneOf([])
#     assert one_of_0 is not None

# Unit tests for constructor of class AllOf
# TODO:
# def test_AllOf():
#     all_of_0 = AllOf([])
#     assert all_of_0 is not None

# Unit tests for constructor of class Not
# TODO:
# def test_Not():
#     not_0 = Not(NeverMatch())
#     assert not_0 is not None

# Unit tests for constructor of class IfThenElse
# TODO:
# def test_IfThenElse():
#     if_then_else_0

# Generated at 2022-06-26 10:17:20.590178
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])
    one_of_1 = OneOf(
        [
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
            NeverMatch(),
        ]
    )


# Generated at 2022-06-26 10:17:24.734086
# Unit test for constructor of class Not
def test_Not():
    field = Not(
        negated=NeverMatch(),
        errors = {
            "negated": "Must not match."
        }
    )


# Generated at 2022-06-26 10:17:26.943763
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)



# Generated at 2022-06-26 10:17:29.743512
# Unit test for constructor of class Not
def test_Not():
    for i in range(100):
        not_0 = Not(negated=i)


# Generated at 2022-06-26 10:17:32.970868
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-26 10:17:35.820959
# Unit test for constructor of class Not
def test_Not():
    negated_0 = Field()
    not_0 = Not(negated=negated_0)


# Generated at 2022-06-26 10:17:42.124849
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    then_clause_0 = Any()
    if_clause_0 = NeverMatch()
    else_clause_0 = Any()
    if_then_else_0 = IfThenElse(if_clause=if_clause_0, then_clause=then_clause_0, else_clause=else_clause_0)


# Generated at 2022-06-26 10:18:19.556787
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = Field()
    my_IfThenElse = IfThenElse(if_clause, then_clause, else_clause)
    my_IfThenElse.validate(False)
    my_IfThenElse.validate(False)
    my_IfThenElse.validate(True)
    my_IfThenElse.validate(True)


# Generated at 2022-06-26 10:18:25.665115
# Unit test for constructor of class OneOf
def test_OneOf():
    _TestField = Any()
    _TestField = Any()
    _TestField = Any()
    _TestField = Any()
    _TestField = Any()
    _TestField = Any()
    _TestField = Any()
    _TestField = Any()

# Generated at 2022-06-26 10:18:30.808814
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    try:
        never_match_0 = NeverMatch(another_argument='temp_0')
    except TypeError:
        pass


# Generated at 2022-06-26 10:18:40.036055
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def validate_ThenClause(value, strict=False):
        return "then", None
    def validate_ElseClause(value, strict=False):
        return "else", None
    def validate_IfClause(value, strict=False):
        return "if", None

    # Case 1: if clause matches
    x = IfThenElse(lambda x: True, validate_ThenClause, validate_ElseClause)
    x.validate('x')
    # Case 2: if clause matches
    y = IfThenElse(lambda x: False, validate_ThenClause, validate_ElseClause)
    y.validate('x')

# Generated at 2022-06-26 10:18:51.798390
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from json import loads
    from .utils import IncorrectSchemaException
    from uuid import uuid4
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.json.fields import IfThenElse
    from typesystem.json.types import Schema
    # Test with string, integer, float and boolean values (unwrapped and wrapped).
    # Only string should be allowed
    schema_dict_0 = {"if": {"type": "string"}, "then": {"type": "string"}}
    schema_0 = Schema(schema_dict_0)
    value_0 = "string"
    assert schema_0.validate(value_0) == value_0
    value_1 = 10

# Generated at 2022-06-26 10:19:02.016165
# Unit test for constructor of class NeverMatch
def test_NeverMatch():

    # Pass

    # Check that we can construct a NeverMatch
    never_match_0 = NeverMatch()
    assert never_match_0

    # Fail

    # Check that we cannot construct a NeverMatch
    try:
        never_match_0 = NeverMatch(a=1)
        assert False
    except Exception as e:
        pass
    # Check that we cannot construct a NeverMatch
    try:
        never_match_0 = NeverMatch(a=1)
        assert False
    except Exception as e:
        pass


# Generated at 2022-06-26 10:19:14.623839
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    true_field = lambda: True
    false_field = lambda: False

    # Run
    if_field = IfThenElse(if_clause=true_field, then_clause=true_field)
    result = if_field.validate(value={})
    # Verify
    assert result == {}

    result = if_field.validate(value=False)
    assert result == False

    # Run
    if_field = IfThenElse(if_clause=false_field, then_clause=true_field)
    result = if_field.validate(value={})
    # Verify
    assert result == {}

    result = if_field.validate(value=False)
    assert result == False

    # Run

# Generated at 2022-06-26 10:19:20.322902
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Scenario 1
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    if_clause.validate(None)


# Generated at 2022-06-26 10:19:29.063685
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    cls = IfThenElse
    fn = cls.validate
    assert(fn.__doc__.split('\n')[0] == '    Conditional sub-item matching.')
    assert(fn.__doc__.split('\n')[1] == '    ')
    assert(fn.__doc__.split('\n')[2] == '    You should use custom validation instead.')
    assert(fn.__doc__.split('\n')[3] == '    ')

    # test case 0
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    never_match_2 = NeverMatch()

    result = fn(never_match_0, never_match_1, never_match_2)
    assert(result == None)
    # test case 1
   

# Generated at 2022-06-26 10:19:30.932893
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
