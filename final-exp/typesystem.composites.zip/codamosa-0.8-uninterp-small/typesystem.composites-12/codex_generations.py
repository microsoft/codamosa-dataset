

# Generated at 2022-06-26 10:09:41.235055
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = None
    one_of_0 = OneOf(list_0)
    # Type failure
    with pytest.raises(TypeFailure):
        value_0 = 1
        one_of_0.validate(value_0)



# Generated at 2022-06-26 10:09:47.183986
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = None
    one_of_0 = OneOf(list_0)
    value = None
    try:
        one_of_0.validate(value)
        assert False
    except Exception as e:
        assert True



# Generated at 2022-06-26 10:09:50.388865
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = None
    one_of_0 = OneOf(list_0)
    assert one_of_0 is not None


# Generated at 2022-06-26 10:09:54.830305
# Unit test for method validate of class Not
def test_Not_validate():
    list_0 = None
    one_of_0 = OneOf(list_0)
    not_0 = Not(one_of_0)
    value_0 = None
    boolean_0 = not_0.validate(value_0)


# Generated at 2022-06-26 10:10:02.267460
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    value_0 = NeverMatch()
    ifthenelse_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    ifthenelse_0.validate(value_0)



# Generated at 2022-06-26 10:10:13.566142
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    if_clause_0 = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    value_0 = None
    strict_0 = None
    strict_1 = None
    value_1 = None
    strict_2 = None
    value_2 = None
    strict_3 = None
    value_3 = None

    if_clause_0.validate(value_0, strict_0)
    if_clause_0.validate(value_1, strict_1)
    if_clause_0.validate(value_2, strict_2)
    if_clause_0.validate(value_3, strict_3)



# Generated at 2022-06-26 10:10:17.521279
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = None
    one_of_0 = OneOf(list_0)
    assert one_of_0.validate() == None


# Generated at 2022-06-26 10:10:23.480842
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # test with no value given for required field
    mandatory_field = True
    test_obj = NeverMatch(mandatory_field=mandatory_field)
    assert test_obj.mandatory_field == mandatory_field


# Generated at 2022-06-26 10:10:36.592062
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test types that don't match Field
    list_0 = [None]
    with raises(AssertionError):
        OneOf(list_0)

    list_0 = [None, None]
    with raises(AssertionError):
        OneOf(list_0)

    list_0 = [None, None, None]
    with raises(AssertionError):
        OneOf(list_0)

    list_0 = [None, None, None, None]
    with raises(AssertionError):
        OneOf(list_0)

    list_0 = [None, None, None, None, None]
    with raises(AssertionError):
        OneOf(list_0)

    # Test types that don't match Field
    list_0 = [None, None, None, None, None, None]


# Generated at 2022-06-26 10:10:44.071572
# Unit test for constructor of class Not
def test_Not():
  field = Field()
  negated = Field()
  def_kwargs: Dict[str, Any]
  def_kwargs = {'allow_null': True, 'description': 'description', 'name': 'name', 'title': 'title'}
  not_0 = Not(negated, **def_kwargs)
  assert not_0.name == 'name'

# Generated at 2022-06-26 10:10:50.852144
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = None
    one_of_0 = OneOf(list_0)


# Generated at 2022-06-26 10:10:56.704645
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    str_0 = None
    list_0 = None
    one_of_0 = OneOf(list_0, description=str_0)
    one_of_1 = OneOf(list_0, description=str_0)
    str_1 = ""
    one_of_1.validate(str_1)


# Generated at 2022-06-26 10:11:07.861634
# Unit test for method validate of class Not
def test_Not_validate():
    # Fails with assert.
    # list_0 = None
    # one_of_0 = OneOf(list_0)
    # assert one_of_0.validate(1) is None
    pass  # except AssertionError: pass
    # Fails with assert.
    # list_0 = [Any(), Any()]
    # one_of_0 = OneOf(list_0)
    # assert one_of_0.validate(1) is None
    pass  # except AssertionError: pass



# Generated at 2022-06-26 10:11:15.885461
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Local variable
    list_0 = None
    one_of_0 = OneOf(list_0)
    # Local variable
    list_0 = None
    one_of_0 = OneOf(list_0)
    # Local variable
    list_0 = None
    one_of_0 = OneOf(list_0)


# Generated at 2022-06-26 10:11:19.209506
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    value_0 = None
    OneOf_0 = OneOf([Any(), Any()])
    result = OneOf_0.validate(value_0)


# Generated at 2022-06-26 10:11:29.291151
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = None
    one_of_0 = OneOf(list_0)
    any_0 = Any()
    any__0 = Any()
    field_set_0 = AllOf( [any_0, any__0])
    not_0 = Not(field_set_0)
    _, error_0 = one_of_0.validate_or_error(not_0, strict=True)



# Generated at 2022-06-26 10:11:36.185492
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(list_0)
    value_0 = None
    strict_0 = False
    try:
        not_0.validate(value_0, strict=strict_0)
    except Exception as e:
        assert str(e) == "Must not match."


# Generated at 2022-06-26 10:11:41.097333
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = list()
    one_of_0 = OneOf(list_0)
    strict_0 = bool()
    value_0 = one_of_0.validate(strict_0)
    list_1 = None
    one_of_1 = OneOf(list_1)
    strict_1 = bool()
    value_1 = one_of_1.validate(strict_1)


# Generated at 2022-06-26 10:11:47.837235
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None
    else_clause_0 = None
    then_clause_0 = None
    IIfThenElse = IfThenElse(if_clause_0, else_clause_0, then_clause_0)
    IIfThenElse.validate(None)



# Generated at 2022-06-26 10:11:59.469780
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch(allow_null=False)
    never_match_2 = NeverMatch(description="Description of NeverMatch")
    never_match_3 = NeverMatch(title="Title of NeverMatch")
    never_match_4 = NeverMatch(name="Name of NeverMatch")
    never_match_5 = NeverMatch(allow_null=False, description="Description of NeverMatch")
    never_match_6 = NeverMatch(allow_null=False, title="Title of NeverMatch")
    never_match_7 = NeverMatch(allow_null=False, name="Name of NeverMatch")
    never_match_8 = NeverMatch(allow_null=False, description="Description of NeverMatch", title="Title of NeverMatch")

# Generated at 2022-06-26 10:12:06.857554
# Unit test for method validate of class Not
def test_Not_validate():
    int_0 = 0
    not_0 = Not(negated=Any())
    try:
        not_0.validate(value=int_0)
    except ValidationError:
        pass


# Generated at 2022-06-26 10:12:15.785699
# Unit test for constructor of class AllOf
def test_AllOf():
    bool_0 = True
    list_field_all_of_0 = [object()]
    # Constructor test
    all_of_0 = AllOf(list_field_all_of_0)
    # Access system property is_optional
    assert all_of_0.is_optional
    # Access system property is_collection
    assert all_of_0.is_collection
    # Access system property is_abstract
    assert all_of_0.is_abstract
    # Access system property is_basic
    assert not all_of_0.is_basic
    # Access system property is_type_field
    assert not all_of_0.is_type_field


# Generated at 2022-06-26 10:12:20.499112
# Unit test for method validate of class Not
def test_Not_validate():
    bool_0 = True
    never_match_0 = NeverMatch()
    not_0 = Not(negated=never_match_0)
    not_0.validate(bool_0)


# Generated at 2022-06-26 10:12:28.996395
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = Field(
        error_messages={'invalid': 'No matches'}
    )
    one_of_0 = OneOf(
        one_of=[one_of_0],
        error_messages={'no_match': 'No match', 'multiple_matches': 'Multiple matches'},
    )
    one_of_1 = OneOf(
        one_of=[one_of_0],
        error_messages={'no_match': 'No match', 'multiple_matches': 'Multiple matches'},
    )
    one_of_1 = OneOf(
        one_of=[one_of_1],
        error_messages={'no_match': 'No match', 'multiple_matches': 'Multiple matches'},
    )

# Generated at 2022-06-26 10:12:39.386872
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(one_of=[bool])
    str_0 = "hello"
    bool_0 = True
    one_of_1 = OneOf(one_of=[bool, int])
    all_of_0 = AllOf(all_of=[bool, int])
    all_of_1 = AllOf(all_of=[one_of_1, all_of_0])
    one_of_2 = OneOf(one_of=[bool, int, all_of_1])

    try:
        one_of_0.validate(str_0)
    except ValidationError:
        pass
    try:
        one_of_0.validate(bool_0)
    except ValidationError:
        pass

# Generated at 2022-06-26 10:12:45.120999
# Unit test for method validate of class Not
def test_Not_validate():
    field_0 = Not(negated = None)
    try:
        field_0.validate(value = None, strict = False)
        assert False
    except Not.ValidationError as error_0:
        assert error_0.error == 'negated'



# Generated at 2022-06-26 10:12:47.460519
# Unit test for method validate of class Not
def test_Not_validate():
    boolean_0 = True
    not_0 = Not(None)
    not_0.validate(boolean_0)


# Generated at 2022-06-26 10:12:55.413823
# Unit test for constructor of class AllOf
def test_AllOf():
    list_of_int_0 = [1, 0]
    list_of_int_1 = [0, 1]
    all_of_0 = AllOf(list_of_int_0, name="all_of_0")
    all_of_0.validate(list_of_int_1)



# Generated at 2022-06-26 10:12:59.621724
# Unit test for method validate of class Not
def test_Not_validate():
    bool_0 = True
    never_match_0 = NeverMatch()
    not_0 = Not(never_match_0)
    values = [
        (False, "Must validate False", bool_0),
        (None, "Must validate None", None),
    ]
    for expected, message, value in values:
        actual = not_0.validate(value)
        assert actual == value, message

# Generated at 2022-06-26 10:13:02.250483
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [bool(0)]  # Should raise a TypeError



# Generated at 2022-06-26 10:13:08.602036
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    try:
        x_0 = IfThenElse(Field())
        x_0.validate(None, True)
        # The line below fails, passing the test.
        assert False
    except:
        pass


# Generated at 2022-06-26 10:13:10.869202
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    bool_0 = True
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:13:19.782373
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = True
    never_match_0 = NeverMatch()
    if_clause_0 = never_match_0
    then_clause_0 = never_match_0
    else_clause_0 = never_match_0
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    try:
        if_then_else_0.validate(bool_0)
        assert False
    except:
        assert True


# Generated at 2022-06-26 10:13:26.386093
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    bool_0 = False
    str_0 = "x"
    if_clause = bool_0
    then_clause = str_0
    else_clause = bool_0
    all_of_0 = AllOf(if_clause, then_clause, else_clause)


# Generated at 2022-06-26 10:13:28.086995
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    bool_0 = True
    never_match_0 = NeverMatch()



# Generated at 2022-06-26 10:13:37.796158
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    if_then_else_0 = IfThenElse(if_clause=if_clause_0, then_clause=then_clause_0, else_clause=else_clause_0)
    with pytest.raises(ValidationError):
        value_0 = None
        strict_0 = None
        if_then_else_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:13:40.895162
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    global bool_0
    never_match = NeverMatch()


# Generated at 2022-06-26 10:13:51.715499
# Unit test for constructor of class AllOf
def test_AllOf():
    """
    AllOf is a class of type Field
    

    """

# Generated at 2022-06-26 10:13:55.495729
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[])
    NeverMatch()
test_OneOf()


# Generated at 2022-06-26 10:14:01.575854
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = ""
    then_clause = ""
    else_clause = ""
    instance = IfThenElse(
        if_clause,
        then_clause,
        else_clause
    )
    result = instance.validate(value)
    assert result is None

# Generated at 2022-06-26 10:14:09.115206
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = True
    str_0 = "this is a valid string"
    never_match_0 = NeverMatch()
    if_clause_0 = IfThenElse.validate(never_match_0,bool_0)
    assert if_clause_0 == bool_0
    assert if_clause_0 == True

# Generated at 2022-06-26 10:14:11.693382
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    bool_0 = False
    try:
        never_match_0 = NeverMatch()
    except Exception:
        bool_0 = True
    assert not bool_0


# Generated at 2022-06-26 10:14:15.238866
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([never_match_0])
    test_case_0()


# Generated at 2022-06-26 10:14:19.506276
# Unit test for constructor of class OneOf
def test_OneOf():
    boolean_0 = Boolean()
    boolean_1 = Boolean()
    value = [boolean_0, boolean_1]
    one_of = OneOf(value)


# Generated at 2022-06-26 10:14:21.841062
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    json_schema_0 = {"oneOf":[{ "type":"integer" }, {"type":"string"}]}
    if_then_else_0 = IfThenElse(if_clause=json_schema_0, then_clause="apple", else_clause="orange"  )


# Generated at 2022-06-26 10:14:24.508742
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    bool_0 = True
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:14:26.836527
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(negated=bool_0)



# Generated at 2022-06-26 10:14:34.886451
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # test_case_0
    bool_0 = True
    never_match_0 = NeverMatch()
    try:
        never_match_0.validate(bool_0, strict=True)
    except ValidationError as validation_error_0:  # type: ignore
        code_0 = validation_error_0.code
        assert code_0 == "never"


# Generated at 2022-06-26 10:14:40.498198
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = [Any()]
    all_of_1 = AllOf(all_of_0)
    all_of_0 = all_of_1.all_of


# Generated at 2022-06-26 10:14:43.047259
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        assert True
    except:
        raise AssertionError()


# Generated at 2022-06-26 10:14:55.943660
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf()
    one_of_0.validate(value=None, strict=False)
    one_of_0.validate(value=None, strict=False)
    one_of_0.validate(value=None, strict=False)
    one_of_0.validate(value=None, strict=False)
    one_of_0.validate(value=None, strict=False)


# Generated at 2022-06-26 10:14:57.938934
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(list_0)


# Generated at 2022-06-26 10:15:02.925457
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_object_0 = IfThenElse(
        False,
        True,
        False,
    )
    test_object_0.validate(True)


# Generated at 2022-06-26 10:15:05.747791
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([NeverMatch()])


# Generated at 2022-06-26 10:15:10.652741
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value_0 = True
    IfThenElse_0 = IfThenElse(None, None, None)
    # Type error test
    # IfThenElse_0.validate(value_0, strict=bool_0)


# Generated at 2022-06-26 10:15:15.685727
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = None
    strict_0 = None
    if_then_else_0.validate(value_0, strict_0)



# Generated at 2022-06-26 10:15:19.863041
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    bool_0 = False
    never_match_0 = NeverMatch()
    # :: error: (argument.type.incompatible)
    bool_1 = never_match_0.validate("True")


# Generated at 2022-06-26 10:15:24.165199
# Unit test for constructor of class AllOf
def test_AllOf():
    bool_10 = True
    bool_11 = True
    array_of_bools_0 = [ bool_10, bool_11 ]
    all_of_0 = AllOf( array_of_bools_0 )


# Generated at 2022-06-26 10:15:36.916054
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test case 1
    bool_0 = True
    never_match_0 = NeverMatch()
    one_of_0 = OneOf(
        one_of=[bool_0, never_match_0]
    )
    value_0 = True
    result_0 = one_of_0.validate(value_0)
    assert result_0 == value_0

    # Test case 2
    bool_0 = True
    never_match_0 = NeverMatch()
    one_of_0 = OneOf(
        one_of=[bool_0, never_match_0]
    )
    value_0 = True
    result_0 = one_of_0.validate(value_0)
    assert result_0 == value_0

    # Test case 3
    bool_0 = True
    never_match_0

# Generated at 2022-06-26 10:15:48.997484
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    bool_0 = True
    never_match_0 = NeverMatch()
    if_clause_0 = never_match_0
    never_match_1 = NeverMatch()
    then_clause_0 = never_match_1
    never_match_2 = NeverMatch()
    else_clause_0 = never_match_2
    if_then_else_0 = IfThenElse(if_clause=if_clause_0, then_clause=then_clause_0, else_clause=else_clause_0)
    if_that_else_0 = IfThenElse(if_clause=if_clause_0, else_clause=else_clause_0)

# Generated at 2022-06-26 10:16:00.102188
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = True
    all_of_0 = AllOf([])
    not_0 = Not(all_of_0)
    all_of_1 = AllOf([not_0])
    not_1 = Not(all_of_1)
    if_then_else_0 = IfThenElse(bool_0, not_1)
    if_then_else_0.validate(False)

# Generated at 2022-06-26 10:16:06.733674
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([never_match_0, never_match_0])
    all_of_0 = AllOf([never_match_0, never_match_0], description="covfefe")
    all_of_0 = AllOf([never_match_0, never_match_0], title="covfefe")
    all_of_0 = AllOf([never_match_0, never_match_0], widget="covfefe")


# Generated at 2022-06-26 10:16:09.681901
# Unit test for constructor of class AllOf
def test_AllOf():
    bool_0 = True
    AllOf(all_of=[bool_0])


# Generated at 2022-06-26 10:16:12.551202
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Make sure that instances can be constructed with any valid number of arguments
    NeverMatch( )


# Generated at 2022-06-26 10:16:13.484950
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([""])


# Generated at 2022-06-26 10:16:15.574790
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = False
    if_then_else_0 = IfThenElse(bool_0, None, None)

# Generated at 2022-06-26 10:16:18.198516
# Unit test for constructor of class OneOf
def test_OneOf():
    sub_item_0 = NeverMatch()
    test_0 = OneOf(one_of=[sub_item_0])
    str_0 = str(test_0)
    str_1 = test_0.__repr__()


# Generated at 2022-06-26 10:16:23.687586
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    bool_0 = True

    # Test with a simple parameter
    never_match_0 = NeverMatch()
    # Test with an empty parameter
    never_match_1 = NeverMatch(error_code="no_value")
    # Test with two parameters
    never_match_2 = NeverMatch(error_code="no_value", name="x")
    # Test with two same parameters
    never_match_3 = NeverMatch(error_code="no_value", error_code="no_value")



# Generated at 2022-06-26 10:16:29.247869
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    one_of_0 = OneOf([None, ])
    string_0 = "Must not match."
    not_0 = Not(never_match_0)
    bool_0 = True
    if_then_else_0 = IfThenElse(not_0, one_of_0, one_of_0)
    if_then_else_0.validate(bool_0)

# Generated at 2022-06-26 10:16:31.482389
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
  assert False # TODO: implement your test here


# Generated at 2022-06-26 10:16:49.154292
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    bool_0 = True
    never_match_0 = NeverMatch()
    # test constructor


# Generated at 2022-06-26 10:16:58.754711
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = True
    never_match_0 = NeverMatch()
    all_of_0 = AllOf([never_match_0], label="match all")
    if_then_else_0 = IfThenElse(all_of_0, then_clause=never_match_0)
    with raises(ValidationError) as validation_error_0:
        if_then_else_0.validate(bool_0)
    assert str(validation_error_0.value) == 'For "match all": Did not match any valid type.'


# Generated at 2022-06-26 10:17:03.197128
# Unit test for constructor of class AllOf
def test_AllOf():
    one_of_0 = [bool_0, never_match_0]
    all_of_0 = AllOf(one_of_0)


# Generated at 2022-06-26 10:17:06.559679
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}


# Generated at 2022-06-26 10:17:10.414141
# Unit test for constructor of class OneOf
def test_OneOf():
    oneof_0 = OneOf(one_of=[NeverMatch()])

# Generated at 2022-06-26 10:17:12.790684
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    bool_0 = True
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:17:20.851537
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Any()
    then_clause_0 = Any()
    else_clause_0 = Any()
    if_then_else_0 = IfThenElse(if_clause_0,then_clause_0,else_clause_0)
    value_0 = None
    strict_0 = True
    if_then_else_0.validate(value_0,strict_0)


# Generated at 2022-06-26 10:17:33.529200
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = True
        # Type: bool
    else_clause_0 = Any()
        # Type: Field
    if_clause_0 = Any()
        # Type: Field
    bool_1 = True
    if_clause_1 = Any()
    then_clause_0 = Any()
        # Type: Field
    else_clause_1 = Any()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
        # Type: IfThenElse
    if_then_else_1 = IfThenElse(if_clause_1, then_clause_0, else_clause_1)
    if_then_else_0.validate(bool_0, True)

# Generated at 2022-06-26 10:17:44.230263
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    then_bool_0 = True
    then_bool_1 = True
    then_bool_2 = True
    then_bool_3 = True
    then_bool_4 = True
    then_bool_5 = True
    then_bool_6 = True
    then_bool_7 = True
    then_bool_8 = True
    then_bool_9 = True
    then_bool_10 = True
    then_bool_11 = True
    then_bool_12 = True
    then_bool_13 = True
    then_bool_14 = True
    then_bool_15 = True
    then_bool_16 = True
    then_bool_17 = True
    then_bool_18 = True
    then_bool_19 = True
    then_bool_20 = True
    then_bool_21 = True
   

# Generated at 2022-06-26 10:17:47.842622
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True

# Generated at 2022-06-26 10:18:48.006289
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([NeverMatch()])
    one_of_0.validate(None)


# patternProperties: {
#     ".*": {
#         "$ref": "basic.json#/definitions/NonNegativeInteger"
#     }
# }


# Generated at 2022-06-26 10:18:56.372534
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    bool_0 = True
    never_match_0 = NeverMatch()
    one_of_0 = OneOf([never_match_0])
    try:
        one_of_0.validate(bool_0)
        assert False
    except Exception:
        assert True


# Generated at 2022-06-26 10:19:02.158299
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([bool_0, never_match_0])
    one_of_0.validate(True)
    one_of_0.validate(False)
    try:
        one_of_0.validate(None)
        return False
    except:
        return True
    return True


# Generated at 2022-06-26 10:19:10.162250
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([NeverMatch()])
    one_of_0 = OneOf([NeverMatch(),NeverMatch()])
    one_of_0 = OneOf([NeverMatch(),NeverMatch(),NeverMatch()])
    one_of_0 = OneOf([NeverMatch(),NeverMatch(),NeverMatch(),NeverMatch()])


# Generated at 2022-06-26 10:19:13.548707
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    bool_0 = True

    field_0 = OneOf( [ bool_0 ] )
    exception_0 = None
    try:
        field_0.validate(bool_0)
    except BaseException as exception_0:
        pass
    except:
        pass


# Generated at 2022-06-26 10:19:19.336659
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    bool_0 = True
    one_of_0 = OneOf([bool_0])
    int_0 = 1
    enum_0 = one_of_0.validate(int_0)


# Generated at 2022-06-26 10:19:28.657549
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    bool_0 = True
    bool_1 = False
    bool_2 = False
    bool_3 = False
    bool_4 = False
    bool_5 = False
    bool_6 = False
    bool_7 = False
    bool_8 = False
    bool_9 = False
    bool_10 = False
    bool_11 = False
    bool_12 = False
    bool_13 = False
    bool_14 = False
    bool_15 = False
    bool_16 = False
    bool_17 = False
    bool_18 = False
    bool_19 = False
    bool_20 = False
    bool_21 = False
    bool_22 = False
    bool_23 = False
    bool_24 = False
    bool_25 = False
    bool_26 = False
    bool_27 = False
    bool_

# Generated at 2022-06-26 10:19:35.585540
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    strict_0 = True
    value_0 = None
    exception_0 = None
    try:
        one_of_0.validate(value_0, strict_0)
    except Exception as e_0:
        exception_0 = e_0
    assert type(exception_0) == one_of_0.validation_error
    assert exception_0.code == "no_match"
    assert str(exception_0) == "Did not match any valid type."
