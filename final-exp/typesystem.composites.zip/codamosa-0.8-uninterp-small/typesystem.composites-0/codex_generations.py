

# Generated at 2022-06-26 10:09:46.278023
# Unit test for constructor of class AllOf
def test_AllOf():
    child_0 = Text()
    child_1 = UUID()
    all_of_0 = AllOf(all_of=[child_0, child_1])



# Generated at 2022-06-26 10:09:54.872492
# Unit test for method validate of class Not
def test_Not_validate():
    # test_case_0
    never_match_0 = NeverMatch()
    not_0 = Not(never_match_0)
    try:
        not_0.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."

    # test_case_1
    never_match_0 = NeverMatch()
    not_0 = Not(never_match_0)
    try:
        not_0.validate(1)
    except Exception as e:
        assert str(e) == "Must not match."

# Generated at 2022-06-26 10:10:00.270809
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        never_match_0 = NeverMatch(allow_null=False)
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch(label="x", description="x", enum=[0])


# Generated at 2022-06-26 10:10:02.938098
# Unit test for method validate of class Not
def test_Not_validate():
    t = 0
    t += 1
    f = Not(negated=NeverMatch())
    assert t == 1
    return

test_Not_validate()

# Generated at 2022-06-26 10:10:11.861923
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for validating a Not field
    def test_validation():
        # Create a Not field, with a Str field from typesystem as the negated field,
        # and a string as the value.     
        not_field = Not(negated=Str(), value="5")
        # Assert that the negated field, Str(), cannot validate the value, "5".
        assert not_field.validate(value="5") is not None

# Generated at 2022-06-26 10:10:18.221990
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=never_match_0)
    with pytest.raises(ValidationError) as excinfo:
        not_0.validate(value = None, strict = False)
    assert excinfo.value.error_key == "negated"
    assert excinfo.value.value == None
    assert excinfo.value.context == {
        "field": not_0,
        "in_error": 'Not(negated=NeverMatch(required=True))',
        'original_error': 'NeverMatch(required=True)',
        'type_error': 'Must not match.',
    }
    # Test with a value that *does* validate.
    not_0.validate(value = 1, strict = False)



# Generated at 2022-06-26 10:10:20.663746
# Unit test for constructor of class Not
def test_Not():
    test = Not(True, nullable=False)

# Generated at 2022-06-26 10:10:24.722277
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)



# Generated at 2022-06-26 10:10:30.425547
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = IfThenElse()
    value_0 = None
    strict_0 = False
    actual = if_clause_0.validate(value_0, strict_0)
    actual == "null"


# Generated at 2022-06-26 10:10:36.479897
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    strict_0 = True
    value_0 = True
    if_then_else_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:10:42.540459
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    test_0 = Not(negated=never_match_0,)
    assert isinstance(test_0, Not)



# Generated at 2022-06-26 10:10:48.003219
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema = [
        {
            "oneOf": [
                {
                    "type": "string",
                    "minLength": 1,
                    "maxLength": 256,
                },
                {
                    "type": "array",
                    "minItems": 1,
                    "maxItems": 256,
                    "items": {
                        "type": "string",
                        "minLength": 1,
                        "maxLength": 256,
                    }
                }
            ],
        },
    ]
    data = ["a", "b"]
    print("data=", data)
    # OneOf.validate(data)


# Generated at 2022-06-26 10:10:49.499994
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-26 10:10:52.758088
# Unit test for method validate of class Not
def test_Not_validate():
    never = NeverMatch()
    not_never = Not(never)
    not_never.validate("whatever")


# Generated at 2022-06-26 10:10:54.720289
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # TODO: Define test for method validate of class OneOf
    pass

# Generated at 2022-06-26 10:10:58.861325
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    value_0 = None
    strict_0 = None
    IfThenElse.validate(if_clause_0, then_clause_0, else_clause_0, value_0, strict_0)


# Generated at 2022-06-26 10:11:06.422383
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([test_case_0]).validate() == None
    assert OneOf([test_case_0]).validate(test_case_0) == None
    assert OneOf([test_case_0]).validate(test_case_0, test_case_0) == None


# Generated at 2022-06-26 10:11:12.627754
# Unit test for method validate of class Not
def test_Not_validate():
    # Setup
    field = Not(negated=None)

    # Exercise
    result = field.validate("value")

    # Verify
    assert result == "value"



# Generated at 2022-06-26 10:11:20.726826
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # create an instance of IfThenElse
    if_clause = Field(primitive="any")
    then_clause = Field(primitive="any")
    else_clause = Field(primitive="any")
    if_then_else_instance_0 = IfThenElse(if_clause, then_clause, else_clause) 
    # execute the method validate
    if_then_else_instance_0.validate(0, False)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 10:11:28.266248
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([], allow_null=True)
    assert one_of.validate(None) == None
    assert one_of.validate(None, strict=False) == None

    one_of = OneOf([], allow_null=True)
    assert one_of.validate(None) == None
    assert one_of.validate(None, strict=False) == None



# Generated at 2022-06-26 10:11:32.283864
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(negated=never_match_0)
    assert not_0.validate(5) == 5


# Generated at 2022-06-26 10:11:44.384805
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Default constructor of a field
    never_match_0 = NeverMatch(name='field_name', description='field_description')
    assert never_match_0.name == 'field_name'
    assert never_match_0.description == 'field_description'
    assert never_match_0.errors == {'never': 'This never validates.'}
    # Setter constructor of a field
    never_match_0.name = 'field_name'
    never_match_0.description = 'field_description'
    never_match_0.errors = {'never': 'This never validates.'}
    assert never_match_0.name == 'field_name'
    assert never_match_0.description == 'field_description'
    assert never_match_0.errors == {'never': 'This never validates.'}


# Generated at 2022-06-26 10:11:46.520459
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of=[])

# Generated at 2022-06-26 10:11:56.271013
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema_0 = IfThenElse(then_clause=Boolean(), if_clause=Boolean())
    assert schema_0.validate(None) is None
    assert schema_0.validate("foo") is False
    assert schema_0.validate(0) is False
    assert schema_0.validate("") is False
    assert schema_0.validate("true") is True
    assert schema_0.validate("TrUe") is True
    assert schema_0.validate("TRUE") is True
    assert schema_0.validate("1") is True
    assert schema_0.validate("0") is False
    assert schema_0.validate("False") is False
    assert schema_0.validate("t") is False
    assert schema_0.validate("f") is False
    assert schema

# Generated at 2022-06-26 10:11:57.181659
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])


# Generated at 2022-06-26 10:12:01.334792
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(negated=never_match_0)
    assert not_0.validate(value="T") == "T"


# Generated at 2022-06-26 10:12:07.225440
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=Field())
    not_0.validate(value=None)
    not_1 = Not(negated=Field(name="abc"))
    not_1.validate(value=None)

# Generated at 2022-06-26 10:12:10.665112
# Unit test for constructor of class OneOf
def test_OneOf():
    sub_items = [Field()]
    one_of = OneOf(one_of=sub_items)


# Generated at 2022-06-26 10:12:17.443099
# Unit test for method validate of class Not
def test_Not_validate():
    # Example use of Not
    not_0 = Not(negated = Any())
    
    # Test 0: Try to validate a value of type Any.
    #         This should raise an error.
    try:
        not_0.validate("This is a string.")
    except ValidationError:
        pass
    else:
        raise Exception("Test 0 failed: This should raise an error.")
        
    # Test 1: Try to validate a value of type Any.
    #         This should raise an error.
    try:
        not_0.validate(5)
    except ValidationError:
        pass
    else:
        raise Exception("Test 1 failed: This should raise an error.")
        
    # Test 2: Try to validate a value of type Any.
    #         This should raise an error.

# Generated at 2022-06-26 10:12:28.083785
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = [Any()]
    one_of_0 = OneOf(list_0)
    one_of_0.validate(1)
    list_1 = None
    one_of_1 = OneOf(list_1)
    one_of_1.validate(1)
    list_2 = [String(), Int()]
    one_of_2 = OneOf(list_2)
    one_of_2.validate(0)
    list_3 = [String(), Int()]
    one_of_3 = OneOf(list_3)
    one_of_3.validate(0)
    list_4 = [String(), Int()]
    one_of_4 = OneOf(list_4)
    one_of_4.validate(0)

# Generated at 2022-06-26 10:12:35.195717
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    xtype = IfThenElse(if_clause,then_clause,else_clause)
    # Check if the fields are not none
    if xtype is None:
        assert False


# Generated at 2022-06-26 10:12:44.209349
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # help: IfThenElse.validate()
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    if_then_else = IfThenElse(never_match_0, never_match_1)
    # help: IfThenElse.validate(value=...)
    if_then_else.validate(value=None)

# Generated at 2022-06-26 10:12:53.191692
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Case 0
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    test_0 = IfThenElse(if_clause_0,then_clause_0,else_clause_0)
    assert test_0 is not None
    # Case 1
    if_clause_1 = None
    then_clause_1 = None
    else_clause_1 = None
    test_1 = IfThenElse(if_clause_1,then_clause_1,else_clause_1)
    assert test_1 is not None
    # Case 2
    if_clause_2 = None
    then_clause_2 = None
    else_clause_2 = None

# Generated at 2022-06-26 10:12:54.870058
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert issubclass(NeverMatch, Field)



# Generated at 2022-06-26 10:12:55.892978
# Unit test for constructor of class AllOf
def test_AllOf():
    allOf_1 = AllOf()


# Generated at 2022-06-26 10:12:59.066451
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = False
    then_clause = True
    else_clause = False
    obj = IfThenElse(if_clause, then_clause, else_clause)
    assert obj

# Generated at 2022-06-26 10:13:04.532131
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    testIfThenElse = IfThenElse({'if_clause': 'default', 'then_clause': 'default', 'else_clause': 'default'}, name='testIfThenElse')
    testIfThenElse.validate('value')



# Generated at 2022-06-26 10:13:08.200027
# Unit test for constructor of class OneOf
def test_OneOf():
    t = OneOf([])

if __name__ == "__main__":
    import sys

    sys.exit(pytest.main(["-s", __file__]))

# Generated at 2022-06-26 10:13:20.963194
# Unit test for constructor of class OneOf
def test_OneOf():
    field_0 = String(max_length=0, min_length=0, pattern="")
    field_1 = String(max_length=0, min_length=0, pattern="")
    field_2 = String(max_length=0, min_length=0, pattern="")
    field_3 = OneOf([field_0, field_1, field_2])
    field_4 = String(max_length=0, min_length=0, pattern="")
    field_5 = OneOf([field_4, field_0, field_1, field_2])
    field_6 = OneOf([field_4, field_0, field_3, field_1, field_2])
    field_7 = OneOf([field_4, field_0, field_1, field_2, field_3])
    field_

# Generated at 2022-06-26 10:13:22.726320
# Unit test for constructor of class OneOf
def test_OneOf():
    value_0 =  [Any(),]
    oneOf_0 = OneOf(value_0)


# Generated at 2022-06-26 10:13:28.206646
# Unit test for constructor of class AllOf
def test_AllOf():
    allOf = AllOf([Field,Field,Field])
    assert not hasattr(allOf, "allow_null")
    assert allOf.all_of == [Field,Field,Field]


# Generated at 2022-06-26 10:13:33.664858
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    obj_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    obj_0.validate(None)
    if_clause_1 = Union()
    then_clause_1 = None
    else_clause_1 = None
    obj_1 = IfThenElse(if_clause_1, then_clause_1, else_clause_1)
    obj_1.validate(None)


# Generated at 2022-06-26 10:13:36.936563
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])
    one_of_0 = OneOf([Any(), Any(), Any(), Any(), Any(), Any(), Any(), Any(), Any()])


# Generated at 2022-06-26 10:13:40.529810
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    never_match_0 = NeverMatch()
    assert OneOf(one_of=[never_match_0]).validate(value=5) == 5
    assert OneOf(one_of=[never_match_0]).validate(value=5) == 5


# Generated at 2022-06-26 10:13:44.360917
# Unit test for constructor of class Not
def test_Not():
    # Create an instance of class Field
    field = Field()

    # Create an instance of class Not
    not_0 = Not(negated=field)


# Generated at 2022-06-26 10:13:52.674361
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # The then-clause must match for the entire type to validate.
    if_clause = Field(validators=[lambda value: value == 'a'])
    then_clause = Field(validators=[lambda value: value == 'b'])
    else_clause = Field(validators=[lambda value: value == 'c'])
    type_ = IfThenElse(if_clause, then_clause, else_clause)

    assert type_.validate('b') == 'b'
    assert type_.validate('c') == 'c'

    with pytest.raises(ValidationError) as exc:
        type_.validate('a')
    assert exc.value.field_name == 'field'
    assert exc.value.value == 'a'


# Generated at 2022-06-26 10:13:55.118396
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:14:02.829434
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Field(), then_clause=Field())
    # Check that the function return an error if the value doesn't correspond to the if clause
    assert field.validate(value=1, strict=False) is None
    # Check that the function doesn't return an error if the value correspond to the if clause
    field = IfThenElse(if_clause=Field(min_length=1), then_clause=Field())
    assert field.validate(value="a", strict=False) is None


# Generated at 2022-06-26 10:14:08.251305
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = IfThenElse(String())
    value_0 = '''d'''
    strict_0 = True
    try:
        if_clause_0.validate(value_0, strict_0)
    except Exception as exc:
        pass
    else:
        assert False, 'Unreachable'


# Generated at 2022-06-26 10:14:16.940576
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    # Check if the 'errors' attribute is the one expected
    assert never_match_0.errors == {"never":"This never validates."}
    # Check if the 'none' attribute is the one expected
    assert never_match_0.none == None
    # Check if the 'allow_null' attribute is the one expected
    assert never_match_0.allow_null == False

    # Test the __init__ method
    try:
        never_match_1 = NeverMatch(allow_null=True)
        assert never_match_1.allow_null == False
    except RuntimeError as e:
        assert "allow_null" in str(e)

    # Test the validate method

# Generated at 2022-06-26 10:14:20.275222
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert never_match_0


# Generated at 2022-06-26 10:14:21.934379
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    all_of_1 = AllOf([])
    assert all_of_0 == all_of_1


# Generated at 2022-06-26 10:14:27.852065
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    IfThenElse(if_clause, then_clause, else_clause)


# Generated at 2022-06-26 10:14:40.249481
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    arg_0 = Field()
    arg_1 = None
    arg_2 = None
    arg_3 = None
    arg_4 = Field()
    arg_5 = None
    arg_6 = None
    arg_7 = None
    arg_8 = Field()
    arg_9 = None
    arg_10 = None
    arg_11 = None
    arg_12 = Field()
    arg_13 = None
    arg_14 = None
    arg_15 = None
    arg_16 = Field()
    arg_17 = None
    arg_18 = None
    arg_19 = None
    arg_20 = Field()
    arg_21 = None
    arg_22 = None
    arg_23 = None
    arg_24 = Field()
    arg_25 = None
    arg_26 = None
    arg_

# Generated at 2022-06-26 10:14:42.844084
# Unit test for constructor of class Not
def test_Not():
    field = Not("test", error="test")
    assert field.error == "test"



# Generated at 2022-06-26 10:14:45.400329
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    actual = IfThenElse(Any()).validate(1)
    expected = 1
    assert actual == expected


# Generated at 2022-06-26 10:14:50.905598
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {'never': 'This never validates.'}
    assert never_match_0.help_text == None


# Generated at 2022-06-26 10:15:00.460654
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Boolean

    # Assert: IfThenElse(if_clause, then_clause, else_clause).validate(value, strict=strict)
    # Method Variant: Variant #1: Value of if_clause is True
    if_clause_1 = Boolean()
    then_clause_1 = Any()
    else_clause_1 = Any()
    value_1 = True
    strict_1 = True
    expectedOutput_1 = value_1 # Type: typing.Any
    if_then_else_1 = IfThenElse(if_clause_1, then_clause_1, else_clause_1)
    actualOutput_1 = if_then_else_1.validate(value_1, strict_1)
   

# Generated at 2022-06-26 10:15:03.221669
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:15:09.677281
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse("abc", then_clause=1, else_clause=2)
        print("test_IfThenElse: ", "test_case_0")
    except:
        print("test_IfThenElse: ", "test_case_0", "Failed")
        raise



# Generated at 2022-06-26 10:15:16.991567
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(
        all_of=[NeverMatch()]
    )
    assert isinstance(all_of_0, AllOf)
    assert isinstance(all_of_0, Field)
    assert len(all_of_0.all_of) == 1
    assert isinstance(all_of_0.all_of[0], NeverMatch)
    assert not hasattr(all_of_0, "nullable")


# Generated at 2022-06-26 10:15:27.764468
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert type(IfThenElse(if_clause = Field(), then_clause = Field(), else_clause = Field()).if_clause) is Field
    assert type(IfThenElse(if_clause = Field(), then_clause = Field(), else_clause = Field()).then_clause) is Field
    assert type(IfThenElse(if_clause = Field(), then_clause = Field(), else_clause = Field()).else_clause) is Field
    assert IfThenElse(if_clause = Field(), then_clause = Field(), else_clause = Field()).default_error_messages == {'invalid': 'Must be valid.'}
    assert IfThenElse(if_clause = Field(), then_clause = Field(), else_clause = Field()).allow_null == False
    assert IfThen

# Generated at 2022-06-26 10:15:32.989732
# Unit test for constructor of class Not
def test_Not():
    field = Field()
    other_field = Field(default=1)
    not_field = Not(negated=Field())
    not_field_null = Not(negated=field)
    not_field_default = Not(negated=Field(), default=True)
    not_field_default_null = Not(negated=other_field, default=True)
    not_field_no_default = Not(negated=Field(default=True))


# Generated at 2022-06-26 10:15:36.779484
# Unit test for constructor of class AllOf
def test_AllOf():
    allOf_type = AllOf([
        AllOf([
            AllOf([type, type]),
            AllOf([type, type]),
        ]),
        AllOf([
            AllOf([type, type]),
            AllOf([type, type]),
        ]),
    ])


# Generated at 2022-06-26 10:15:39.790569
# Unit test for constructor of class Not
def test_Not():
    n = Not(negated=NeverMatch())
    assert n.negated is not None

# Generated at 2022-06-26 10:15:40.600282
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()


# Generated at 2022-06-26 10:15:46.282122
# Unit test for constructor of class OneOf
def test_OneOf():
    never_match_0 = NeverMatch()
    assert never_match_0 is not None # Type check
    one_of_0 = OneOf([never_match_0])
    assert one_of_0 is not None # Type check
    assert one_of_0.one_of == [never_match_0] # Type check



# Generated at 2022-06-26 10:15:47.942022
# Unit test for constructor of class Not
def test_Not():
    never_match_1 = NeverMatch()
    # Constructor of field Not
    not_0 = Not(never_match_1)


# Generated at 2022-06-26 10:15:50.761193
# Unit test for constructor of class Not
def test_Not():
    not0 = Not(negated=None)


# Generated at 2022-06-26 10:15:52.666186
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # TODO
    never_match_0 = NeverMatch()

# Generated at 2022-06-26 10:16:02.277079
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([
        Number(max_value=10),
        Number(min_value=20)
    ])
    one_of_1 = OneOf([
        Number(max_value=10),
        Number(min_value=20)],
        default=[1,2,3]
    )
    one_of_2 = OneOf([
        Number(max_value=10),
        Number(min_value=20)],
        description='Example',
        error_messages={'message': 'Example'}
    )
    one_of_3 = OneOf([
        Number(max_value=10),
        Number(min_value=20)],
        name='Example',
        required=True
    )

# Generated at 2022-06-26 10:16:07.542957
# Unit test for constructor of class AllOf
def test_AllOf():
    i = 0
    for elements in [['a','b','c'],[1,2,3],[never_match_0]]:
        try:
            AllOf(elements,name='AllOf_name_{}'.format(i))
            raise ValueError('Expected an exception')
        except:
            pass
        i += 1
    assert AllOf(['a','b','c'],name='AllOf_name_{}'.format(i))


# Generated at 2022-06-26 10:16:09.834401
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:16:12.091444
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = IfThenElse(if_clause=True)


# Generated at 2022-06-26 10:16:16.548743
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0 = Any()
    then_clause_0 = Any()
    else_clause_0 = Any()
    obj = IfThenElse(if_clause_0, then_clause_0, else_clause_0)


# Generated at 2022-06-26 10:16:22.802745
# Unit test for constructor of class OneOf
def test_OneOf():
    fields_0 = []
    fields_1 = []
    fields_2 = []
    fields_3 = [NeverMatch()]

# Generated at 2022-06-26 10:16:23.748607
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([Field])



# Generated at 2022-06-26 10:16:25.422914
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:16:28.968198
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {'never': 'This never validates.'}
    assert never_match_0.validation_error('never') == {'code': 'never', 'message': 'This never validates.'}
    assert never_match_0.validate(None, True) == {'code': 'never', 'message': 'This never validates.'}


# Generated at 2022-06-26 10:16:31.252149
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [None]
    field = OneOf(fields)


# Generated at 2022-06-26 10:16:37.951148
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])


# Generated at 2022-06-26 10:16:50.495642
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0 = "if_clause_0"
    then_clause_0 = "then_clause_0"
    else_clause_0 = "else_clause_0"

    # Testing if a ValueError is raised in case of null value
    caught_exception = None
    try:
        IfThenElse(None, None, None)
    except ValueError as caught_exception:
        pass
    assert type(caught_exception).__name__ == "ValueError"

    # Testing if a ValueError is raised in case of empty value
    caught_exception = None
    try:
        IfThenElse("", "", "")
    except ValueError as caught_exception:
        pass
    assert type(caught_exception).__name__ == "ValueError"

    # Testing if a

# Generated at 2022-06-26 10:16:52.595531
# Unit test for constructor of class OneOf
def test_OneOf():
    oneOf_0 = OneOf( [Any(), Any()] )


# Generated at 2022-06-26 10:16:58.325261
# Unit test for constructor of class AllOf

# Generated at 2022-06-26 10:17:02.159833
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of=['String','Int']
    assert set(all_of) == set(AllOf(all_of).all_of)

# Generated at 2022-06-26 10:17:12.697586
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    never_match_2 = NeverMatch()
    never_match_3 = NeverMatch()
    never_match_4 = NeverMatch()
    never_match_5 = NeverMatch()
    never_match_6 = NeverMatch()
    never_match_7 = NeverMatch()
    never_match_8 = NeverMatch()
    never_match_9 = NeverMatch()
    never_match_10 = NeverMatch()
    never_match_11 = NeverMatch()
    never_match_12 = NeverMatch()
    never_match_13 = NeverMatch()
    never_match_14 = NeverMatch()
    never_match_15 = NeverMatch()
    never_match_16 = NeverMatch()
    never_match_17 = NeverMatch()
   

# Generated at 2022-06-26 10:17:15.449019
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:17:18.878972
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([])
    assert a is None


# Generated at 2022-06-26 10:17:21.733549
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert not bool(never_match_0.validate(1))


# Generated at 2022-06-26 10:17:24.175976
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert getattr(NeverMatch, "errors", None) is not None


# Generated at 2022-06-26 10:17:35.899032
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()


# Generated at 2022-06-26 10:17:38.686032
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print("Testing constructor of class NeverMatch")
    assert (str(NeverMatch()) == "NeverMatch()")


# Generated at 2022-06-26 10:17:40.310291
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)


# Generated at 2022-06-26 10:17:42.179551
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    assert isinstance(all_of_0, Field)


# Generated at 2022-06-26 10:17:49.596920
# Unit test for constructor of class OneOf
def test_OneOf():
    # Constructor with parameters
    all_of_0 = AllOf(all_of=[])
    one_of_0 = OneOf(one_of=[], label="oneOf_0", description="", required=True, allow_null=False)


# Generated at 2022-06-26 10:17:52.667181
# Unit test for constructor of class OneOf
def test_OneOf():
    never_match_2 = NeverMatch()
    one_of_0 = OneOf([never_match_2])

# Generated at 2022-06-26 10:17:59.049374
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError) as excinfo:
        never_match_0 = NeverMatch(allow_null=True)
    the_exception = excinfo.value
    assert str(the_exception) == 'assert not "allow_null" in kwargs'



# Generated at 2022-06-26 10:18:01.489075
# Unit test for constructor of class AllOf
def test_AllOf():
    test_case_0()

test_AllOf()
test_case_0()

# Generated at 2022-06-26 10:18:06.310246
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """
    Check that constructor raises error on undefined argument
    """
    with pytest.raises(TypeError) as ex:
        NeverMatch()
    assert "missing 1 required positional argument: 'kwargs'" in str(ex.value)



# Generated at 2022-06-26 10:18:10.212631
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    all_of_1 = AllOf([Any()])
    all_of_2 = AllOf([Any(), Any()])


# Generated at 2022-06-26 10:18:34.341929
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:18:37.250668
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])  # type: AllOf
    assert isinstance(one_of_0, Field)

# Generated at 2022-06-26 10:18:44.594740
# Unit test for constructor of class Not
def test_Not():
    no_null_value = not Field().allow_null
    NeverMatch_0 = NeverMatch()
    Not_0 = Not(NeverMatch_0)
    no_null_value_0 = not Not_0.allow_null
    assert(no_null_value == no_null_value_0)


# Generated at 2022-06-26 10:18:50.400612
# Unit test for constructor of class AllOf
def test_AllOf():
    # Create an instance of the AllOf class
    all_of_instance = AllOf(all_of=[
        None,
    ])
    one_of_0 = OneOf(one_of=[
        None,
    ])
    all_of_instance.validate(all_of_instance)
    one_of_0.validate(one_of_0)
    return


# Generated at 2022-06-26 10:18:52.578538
# Unit test for constructor of class OneOf
def test_OneOf():
    field_0 = NeverMatch()
    field_1 = AlwaysMatch()
    one_of_0 = OneOf([field_0, field_1])


# Generated at 2022-06-26 10:18:54.188308
# Unit test for constructor of class OneOf
def test_OneOf():
    _ = OneOf([""])


# Generated at 2022-06-26 10:18:56.744220
# Unit test for constructor of class NeverMatch
def test_NeverMatch():

    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:18:58.207156
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()


# Generated at 2022-06-26 10:19:00.854457
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0 is not None


# Generated at 2022-06-26 10:19:02.699353
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
