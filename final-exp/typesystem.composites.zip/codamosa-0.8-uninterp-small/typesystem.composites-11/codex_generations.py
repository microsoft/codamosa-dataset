

# Generated at 2022-06-26 10:09:50.313929
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Setup
    if_clause = None
    then_clause = None
    else_clause = None
    boolean = True
    strict = False
    ifThenElse = IfThenElse(if_clause, then_clause, else_clause)

    # Test
    result = ifThenElse.validate(boolean, strict)
    assert result is True



# Generated at 2022-06-26 10:09:54.672185
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(NeverMatch())
    # no_match
    try:
        not_0.validate(False)
    except Exception as e:
        assert e.args[0]["code"] == "negated"


# Generated at 2022-06-26 10:10:00.207905
# Unit test for constructor of class AllOf
def test_AllOf():
    if_clause_1 = None
    then_clause_1 = None
    else_clause_1 = None
    all_of_0 = AllOf(if_clause_1, then_clause_1, else_clause_1)


# Generated at 2022-06-26 10:10:06.197735
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = True
    bool_1 = True
    all_of_0 = AllOf([])
    all_of_1 = AllOf([])
    not_0 = Not(all_of_1)
    if_then_else_0 = IfThenElse(bool_1, else_clause=all_of_0)


# Generated at 2022-06-26 10:10:16.082338
# Unit test for method validate of class Not
def test_Not_validate():
    value_0 = True
    if_clause_0 = True
    then_clause_0 = True
    else_clause_0 = True
    negated_0 = Not( negated=never_match_0)
    negated_0.validate(value_0)
    if_clause_1 = True
    then_clause_1 = True
    else_clause_1 = True
    negated_1 = Not( negated=never_match_0)
    negated_1.validate(value_0)
    if_clause_2 = True
    then_clause_2 = True
    else_clause_2 = True
    negated_2 = Not( negated=never_match_0)
    negated_2.validate(value_0)


# Generated at 2022-06-26 10:10:18.269769
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=NeverMatch())


# Generated at 2022-06-26 10:10:26.525793
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    bool_0 = True
    never_match_0 = NeverMatch()
    if_then_else_0 = IfThenElse(never_match_0, then_clause=never_match_0, else_clause=never_match_0)
    assert if_then_else_0.validate(None) is None
    assert if_then_else_0.validate("") is ""
    assert if_then_else_0.validate(0) == 0
    assert if_then_else_0.validate(0.0) == 0.0
    assert if_then_else_0.validate(bool_0)


# Generated at 2022-06-26 10:10:33.018336
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_1 = [
        Any(),
    ]
    value_1 = "foo"
    one_of_2 = OneOf(one_of_1)
    assert one_of_2.validate(value_1) == "foo"


# Generated at 2022-06-26 10:10:34.257437
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([]) is not None


# Generated at 2022-06-26 10:10:45.485920
# Unit test for method validate of class Not
def test_Not_validate():
    bool_0 = True
    str_0 = "abc"
    negated_0 = Not(negated=BaseString())
    try:
        negated_0.validate(value=bool_0, strict=True)
        assert False
    except Exception as error_0:
        pass
    try:
        negated_0.validate(value=str_0, strict=True)
        assert False
    except Exception as error_0:
        pass
    try:
        negated_0.validate(value=str_0, strict=False)
        assert False
    except Exception as error_0:
        pass

# Generated at 2022-06-26 10:10:51.345291
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(None)
    assert not_field.validate('value') == 'value'

# Generated at 2022-06-26 10:11:01.221606
# Unit test for method validate of class Not
def test_Not_validate():
    then_clause = IfThenElse(
        if_clause=NeverMatch(),
        then_clause=OneOf(
            one_of=[
                Integer(minimum=1000, maximum=9999),
                Integer(minimum=1000, maximum=9999),
                Integer(minimum=1000, maximum=9999),
                Integer(minimum=1000, maximum=9999),
            ]
        ),
        else_clause=OneOf(
            one_of=[
                Integer(minimum=10000, maximum=99999),
                Integer(minimum=10000, maximum=99999),
                Integer(minimum=10000, maximum=99999),
                Integer(minimum=10000, maximum=99999),
            ]
        ),
    )
    assert then_clause.validate("A111") == "A111"

# Generated at 2022-06-26 10:11:08.333519
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(never_match_0)
    with pytest.raises(TypeSystemError):
        not_0.validate("")
    not_1 = Not(never_match_0)
    with pytest.raises(TypeSystemError):
        not_1.validate("")


# Generated at 2022-06-26 10:11:16.336091
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # If-then-else with default condition
    if_then_else_0 = IfThenElse(
        if_clause = Any(),
        then_clause = Any(),
        else_clause = Any(),
    )

    # If-then-else with custom else_clause
    if_then_else_1 = IfThenElse(
        if_clause = Any(),
        then_clause = Any(),
        else_clause = Any(),
    )

    # If-then-else with custom then_clause
    if_then_else_0 = IfThenElse(
        if_clause = Any(),
        then_clause = Any(),
        else_clause = Any(),
    )

    # If-then-else with custom if_clause

# Generated at 2022-06-26 10:11:17.694587
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert_0



# Generated at 2022-06-26 10:11:22.409599
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # TODO: uncomment the code below
    # then_clause = None
    # else_clause = None
    # if_clause = Field()
    # validate = IfThenElse(if_clause, then_clause, else_clause)
    # assert validate == ...  # TODO: choose a value for validate

    # TODO: implement other tests
    raise NotImplementedError("Tests are not implemented yet.")


# Project TODOs
# TODO: add tests for all functions and classes

# Generated at 2022-06-26 10:11:27.036758
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_args = None
    else_args = None
    ifthenelse = IfThenElse(if_clause,then_args,else_args)
    pass

# Generated at 2022-06-26 10:11:30.037467
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(never_match_0)
    never_match_1 = NeverMatch()
    not_1 = Not(never_match_1)

# Generated at 2022-06-26 10:11:37.241814
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """Test for method validate of class IfThenElse"""

    ifthenelse_0 = IfThenElse(value=None)
    ifthenelse_0.validate(value=None, strict=True)
    ifthenelse_0.validate(value=None, strict=False)


# Generated at 2022-06-26 10:11:44.087747
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Setup
    one_of_0 = OneOf([Int()])

    # Assertion: verify that validate raises no exception with valid input.
    one_of_0.validate(0)
    assert True, ""

    # Assertion: verify that validate raises an exception with invalid input.
    raised = False
    try:
        one_of_0.validate(1.2)
    except ValidationError:
        raised = True
    assert raised


# Generated at 2022-06-26 10:11:50.109807
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test 1
    one_of_0 = OneOf([
        Field(max_length=5),
        Field(max_length=5),
    ])

# Generated at 2022-06-26 10:11:51.040391
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated=never_match_0)

# Generated at 2022-06-26 10:12:03.585067
# Unit test for constructor of class AllOf
def test_AllOf():
    one_of_0 = OneOf([1, 2, 3])
    all_of_0 = AllOf([one_of_0, one_of_0])
    one_of_1 = OneOf([1, 2, 3], description='description_0')
    all_of_1 = AllOf([one_of_0, one_of_0], description='description_1')
    one_of_2 = OneOf([1, 2, 3], description='description_2')
    all_of_2 = AllOf([one_of_1, one_of_1], description='description_3')
    one_of_3 = OneOf([1, 2, 3], description='description_4')
    all_of_3 = AllOf([one_of_2, one_of_2], description='description_5')
    one_

# Generated at 2022-06-26 10:12:12.776816
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch(allow_null=True)
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = True
    strict_0 = False
    if_then_else_0.validate(value_0, strict_0)

# Generated at 2022-06-26 10:12:18.215849
# Unit test for method validate of class Not
def test_Not_validate():
    negated = Any()
    obj = Not(negated=negated)
    x = obj.validate(1)
    assert x == 1


# Generated at 2022-06-26 10:12:21.258955
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}



# Generated at 2022-06-26 10:12:25.011186
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test that constructor raises TypeError when passed args
    with pytest.raises(TypeError):
        assert NeverMatch("bar")

    # Test that constructor raises TypeError when passed unknown kwargs
    with pytest.raises(TypeError):
        assert NeverMatch(bar="bar")


# Generated at 2022-06-26 10:12:36.451228
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch()).validate(
        "value-0"
    )
    IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch()).validate(
        "value-1"
    )
    IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch()).validate(
        116646845
    )
    IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch()).validate(
        -352499316
    )


# Generated at 2022-06-26 10:12:38.983622
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()



# Generated at 2022-06-26 10:12:45.272378
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case for 'Negated' error
    not_0 = Not(NeverMatch())
    with pytest.raises(ValidationError):
        assert not_0.validate(1) is None
    # Test case for 'not negated'
    assert not_0.validate(None) is None


# Generated at 2022-06-26 10:12:59.899919
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    from typesystem import SchemaError
    assert isinstance(never_match_0, NeverMatch)
    assert never_match_0.errors == {"never": "This never validates."}
    assert never_match_0.name is None
    assert never_match_0.description is None
    assert never_match_0.required is False
    try:
        assert never_match_0.validate(None)
    except SchemaError as exc:
        assert exc.code == "never"
        assert exc.field == None
        assert exc.path == []
        assert exc.context == {}

    assert never_match_0.validate(None, strict=False) == None


# Generated at 2022-06-26 10:13:07.244360
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([never_match_0])


if __name__ == "__main__":
    import sys

    try:
        import testcase  # type: ignore

        sys.exit(not testcase.run("-vv"))
    except ImportError:
        from unittest import main

        main(argv=[sys.argv[0]])

# Generated at 2022-06-26 10:13:20.676019
# Unit test for constructor of class AllOf
def test_AllOf():
    error_factory_mock = mock.MagicMock()
    field_mock = mock.MagicMock()
    name = "test"
    error_factory = error_factory_mock
    description = "description"
    help_text = "help"
    all_of = [field_mock]

    allof = AllOf(
        all_of,
        error_factory=error_factory,
        name=name,
        description=description,
        help_text=help_text
    )

    assert allof.error_factory == error_factory_mock
    assert allof.all_of == all_of
    assert allof.description == description
    assert allof.help_text == help_text
    assert allof.name == name


# Generated at 2022-06-26 10:13:28.127581
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Create an instance of IfThenElse
    if_then_else_0 = IfThenElse(
        Field(),
        Field(),
        Field()
    )

    # Call method validate of if_then_else_0 on some data
    try:
        if_then_else_0.validate(None)
    except:
        assert False
    assert True


# Generated at 2022-06-26 10:13:34.883778
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        if_clause = IfThenElse(1, 2, 3)
    except AssertionError:
        pass
    try:
        if_clause = IfThenElse(1, 2, 3, allow_null=1)
    except AssertionError:
        pass


# Generated at 2022-06-26 10:13:40.855985
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test 1
    field_0 = AllOf([])

    # Test 2
    all_of_0 = [
        Field(default='a'),
        Field(default=2),
        Field(default=3.14)
    ]
    field_1 = AllOf(all_of_0)

    # Test 3
    all_of_0.append(Field(default=True))
    field_0 = AllOf(all_of_0)


# Generated at 2022-06-26 10:13:45.300829
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.get_field_name() == None
    assert never_match_0.get_default() == None


# Generated at 2022-06-26 10:13:48.964680
# Unit test for constructor of class OneOf
def test_OneOf():
    sub_items_1 = []
    sub_items_1.extend([Field()])
    type_0 = OneOf(sub_items_1)


# Generated at 2022-06-26 10:14:02.082326
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(
        [
            String(
                min_length=0,
                max_length=2147483647,
                allow_blank=False,
                allow_null=True,
            ),
            Integer(
                min_value=0,
                max_value=2147483647,
                allow_null=True,
            ),
            String(
                min_length=0,
                max_length=2147483647,
                allow_blank=False,
                allow_null=True,
            ),
        ]
    )
    # Test 0
    value_0 = "3"
    result_0 = one_of_0.validate(value_0, strict=False)
    assert result_0 == "3"
    # Test 1
    value_1 = 3

# Generated at 2022-06-26 10:14:05.166551
# Unit test for constructor of class Not
def test_Not():
    negated = Field()
    assert negated is not None
    not_field = Not(negated)
    assert not_field is not None



# Generated at 2022-06-26 10:14:11.804845
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])
    one_of_1 = OneOf([never_match_0])


# Generated at 2022-06-26 10:14:15.318534
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)
    assert Not(negated=NeverMatch())


# Generated at 2022-06-26 10:14:16.783725
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of=[never_match_0], description=None)


# Generated at 2022-06-26 10:14:24.101545
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Any()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    if_then_else_0 = IfThenElse(if_clause=if_clause_0, then_clause=then_clause_0, else_clause=else_clause_0)
    assert if_then_else_0.validate("string") == "string"


# Generated at 2022-06-26 10:14:37.937547
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Hack to get around current string support limitations
    object_string = object()
    object_dict = object()
    object_list = object()
    # Hack end
    one_of_0 = OneOf([
        object_string,
        object_dict,
        object_list])

    if_clause_0 = one_of_0
    then_clause_0 = object_string
    else_clause_0 = object_dict

    if_then_else_0 = IfThenElse(if_clause=if_clause_0, then_clause=then_clause_0,
        else_clause=else_clause_0)
    if_then_else_0.validate(value=object_string)
    if_then_else_0.validate(value=object_dict)

#

# Generated at 2022-06-26 10:14:44.449120
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    internals = never_match_0.get_internal_state()
    assert len(internals) == 2
    assert internals["key_name"] is None
    assert internals["errors"] == {"never": {
        "type": "never",
        "message": "This never validates."
    }}



# Generated at 2022-06-26 10:14:48.948344
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Generate data for test of method validate of class OneOf
    def _gen_data_validate():
        one_of = []
        one_of.append(NeverMatch())
        one_of.append(NeverMatch())
        one_of.append(NeverMatch())
        return one_of
    one_of_0 = OneOf(_gen_data_validate())
    try:
        one_of_0.validate(12)
    except AssertionError:
        return
    raise AssertionError('OneOf.validate failed.')


# Generated at 2022-06-26 10:14:50.798015
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    i = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    assert not i.validate(None)

# Generated at 2022-06-26 10:14:55.347995
# Unit test for constructor of class OneOf
def test_OneOf():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    one_of_0 = OneOf([never_match_0, never_match_1])


# Generated at 2022-06-26 10:15:01.495707
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test that all branches are validated.
    field = IfThenElse(
        if_clause=AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[NeverMatch()])])])]),
        then_clause=AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[NeverMatch()])])])]),
        else_clause=AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[NeverMatch()])])])])
    )
    with pytest.raises(field.validation_error("negated")):
        field.validate("some value")


# Generated at 2022-06-26 10:15:06.029788
# Unit test for constructor of class Not
def test_Not():
    negated = Any()
    not0 = Not(negated)



# Generated at 2022-06-26 10:15:08.422729
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([NeverMatch()])


# Generated at 2022-06-26 10:15:12.548764
# Unit test for constructor of class AllOf
def test_AllOf():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    all_of_0 = AllOf([never_match_0, never_match_1])


# Generated at 2022-06-26 10:15:24.453515
# Unit test for constructor of class Not
def test_Not():
    # Calling the constructor of class Field with the following arguments:
    # if_clause = Not(negated=not(true))
    if_clause = Not(negated=not(True))
    # then_clause = None
    then_clause = None
    # else_clause = None
    else_clause = None
    # Calling the constructor of class IfThenElse with the following arguments:
    # if_clause = not(true)
    if_clause = not(True)
    # then_clause = None
    then_clause = None
    # else_clause = None
    else_clause = None
    # Calling the constructor of class Not with the following arguments:
    # negated = not(true)
    negated = not(True)
    # Calling the constructor of class Not with the following arguments

# Generated at 2022-06-26 10:15:25.863382
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of = [])
    one_of_1 = OneOf(one_of = [])


# Generated at 2022-06-26 10:15:31.305524
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of = [])
    assert all_of_0.all_of == []
    assert all_of_0.error_messages == {}


# Generated at 2022-06-26 10:15:34.381076
# Unit test for constructor of class Not
def test_Not():
    negated = types.Dict({'type': 'string'})
    not_0 = Not(negated)


# Generated at 2022-06-26 10:15:47.911433
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(
        [never_match_0]
    )  # TypeError: __init__() got multiple values for argument 'one_of'
    one_of_1 = OneOf(
        one_of=[never_match_0]
    )  # TypeError: __init__() got multiple values for argument 'one_of'
    one_of_2 = OneOf(
        one_of=[never_match_0]
    )  # TypeError: __init__() got multiple values for argument 'one_of'
    one_of_3 = OneOf(
        one_of=[never_match_0]
    )  # TypeError: __init__() got multiple values for argument 'one_of'

# Generated at 2022-06-26 10:15:50.455340
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert True == True



# Generated at 2022-06-26 10:15:52.976650
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, NeverMatch)


# Generated at 2022-06-26 10:16:03.396022
# Unit test for constructor of class AllOf
def test_AllOf():
    one_of_0 = OneOf([1, 2])
    all_of_0 = AllOf([one_of_0, 1])


# Generated at 2022-06-26 10:16:04.371561
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(None)


# Generated at 2022-06-26 10:16:14.792268
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(
        all_of=[
            Integer(
                maximum=100,
                description="An integer that cannot be more than 100.",
            ),
            String(
                pattern="^[0-9]{3}-[0-9]{3}-(.*)$",
                description="A string that looks like a phone number",
            ),
        ],
        description="An integer that cannot be more than 100, unless it is a phone number.",
    )



# Generated at 2022-06-26 10:16:16.256695
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(None)


# Generated at 2022-06-26 10:16:26.795684
# Unit test for constructor of class OneOf
def test_OneOf():
    # example value for constructor:
    # `one_of` can be used to construct instances of this enum, or can be compared to such instances.
    one_of = OneOf(['one_of_var'], "kwargs_var")
    # noinspection PyTypeChecker
    assert one_of.one_of == ['one_of_var']
    assert one_of.kwargs == "kwargs_var"
    assert one_of.errors == {'multiple_matches': 'Matched more than one type.', 'no_match': 'Did not match any valid type.'}


# Generated at 2022-06-26 10:16:29.549004
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        never_match_0 = NeverMatch()
    except:
        assert False



# Generated at 2022-06-26 10:16:33.624054
# Unit test for constructor of class Not
def test_Not():
    o = Not(None)
    assert o.negated is None
    assert o.errors == {'negated': 'Must not match.'}


# Generated at 2022-06-26 10:16:36.923831
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[Any()])
    one_of_0.validate(value=1)


# Generated at 2022-06-26 10:16:42.966554
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(
        all_of = [],
        description = "",
        error_messages = {},
        name = "",
        title = "",
    )
    # No exceptions should be raised by this constructor


# Generated at 2022-06-26 10:16:48.209679
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    ite_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)


# Generated at 2022-06-26 10:17:11.602719
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0 is not None


# Generated at 2022-06-26 10:17:15.669863
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0 != None
    never_match_0.validate(0)


# Generated at 2022-06-26 10:17:19.260229
# Unit test for constructor of class OneOf
def test_OneOf():
    test_one_of = [NeverMatch(), NeverMatch()]
    test_case = OneOf(test_one_of)


# Generated at 2022-06-26 10:17:20.917816
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    all_of_1 = AllOf(["foo"], **{"allow_null": True})


# Generated at 2022-06-26 10:17:28.481582
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    try:
        assert never_match_0.validate('never') == 'never', 'AssertionError:  Constructor NeverMatch failed'
    except AssertionError as err:
        print('AssertionError:  Constructor NeverMatch failed')


# Generated at 2022-06-26 10:17:33.380706
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), NeverMatch)


# Generated at 2022-06-26 10:17:37.440558
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import Integer

    never_match_0 = NeverMatch()
    not_0 = Not(negated=never_match_0)


# Generated at 2022-06-26 10:17:40.309425
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0 is not None


# Generated at 2022-06-26 10:17:42.462674
# Unit test for constructor of class Not
def test_Not():
    negated = None  # type: Field

    # Call the constructor
    never_match_0 = Not(negated=negated)



# Generated at 2022-06-26 10:17:46.727407
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Any()]
    AllOf(all_of)



# Generated at 2022-06-26 10:18:02.554882
# Unit test for constructor of class Not
def test_Not():
    negated_0 = Any()
    not_0 = Not(negated=negated_0)


# Generated at 2022-06-26 10:18:05.805617
# Unit test for constructor of class Not
def test_Not():
    # No error should be thrown
    a = Not(None)


# Generated at 2022-06-26 10:18:07.321831
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(None)


# Generated at 2022-06-26 10:18:08.835569
# Unit test for constructor of class Not
def test_Not():
    a = Not(NeverMatch())


# Generated at 2022-06-26 10:18:13.082075
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])

    one_of_1 = OneOf([never_match_0])
    assert one_of_1.one_of == [never_match_0]


# Generated at 2022-06-26 10:18:19.394854
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, Field)
    assert never_match_0.errors == {'never': 'This never validates.'}


# Generated at 2022-06-26 10:18:20.913304
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
	assert IfThenElse


# Generated at 2022-06-26 10:18:26.630783
# Unit test for constructor of class Not
def test_Not():
    # Test that constructor of class Not raises an error when given a "negated" parameter of the wrong type
    try:
        test_case_0()
    except TypeError as err:
        # Check that the message is equal to the expected message
        assert err.args[0] == "field must be Field"

# Generated at 2022-06-26 10:18:28.174394
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-26 10:18:32.406370
# Unit test for constructor of class Not
def test_Not():
    x = Field(key="y")
    try:
        not_0 = Not(x)
    except Exception as e:
        print(e)



# Generated at 2022-06-26 10:18:55.957750
# Unit test for constructor of class OneOf
def test_OneOf():
    pass


# Generated at 2022-06-26 10:19:02.969800
# Unit test for constructor of class OneOf
def test_OneOf():
    # The following fields are required for complete JSON schema support,
    # but are undocumented as we don't recommend using them directly.
    # import typing
    #
    # from typesystem.fields import Any, Field
    one_of_0 = OneOf([Any()])
    one_of_0_0 = one_of_0
    one_of_1 = OneOf([Any()], _creation_counter=0)
    one_of_1_0 = one_of_1


# Generated at 2022-06-26 10:19:10.663288
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = Field()
    y = Field()
    z = Field()
    if_clause = x
    then_clause = y
    else_clause = z
    if_then_else_0 = IfThenElse(if_clause, then_clause, else_clause)
    return if_then_else_0


# Generated at 2022-06-26 10:19:12.490823
# Unit test for constructor of class OneOf
def test_OneOf():
   one_of_0 = OneOf([NeverMatch()])


# Generated at 2022-06-26 10:19:16.047585
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}


# Generated at 2022-06-26 10:19:21.267118
# Unit test for constructor of class Not
def test_Not():
    negated_0 = NeverMatch()
    test = Not(negated=negated_0)
    assert test.negated == negated_0


# Generated at 2022-06-26 10:19:23.503012
# Unit test for constructor of class OneOf
def test_OneOf():
    test_one_of_0 = OneOf(one_of = [])


# Generated at 2022-06-26 10:19:35.645571
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch.__bases__ == (Field,)
    assert NeverMatch.errors == {'never': 'This never validates.'}
    assert isinstance(NeverMatch._creation_counter, int)
    assert NeverMatch.errors_on_separate_lines == True
    assert NeverMatch.name == 'NeverMatch'
    assert NeverMatch.__doc__ == None
    assert NeverMatch.all_errors == {'never': 'This never validates.'}
    assert isinstance(NeverMatch.allow_null, bool)
    assert NeverMatch.default == None
    assert NeverMatch.description == None
    assert isinstance(NeverMatch.empty, bool)
    assert NeverMatch.error_messages == {'null': 'This field may not be null.'}
    assert NeverMatch.format == None
    assert NeverMatch.null == False
    assert Never

# Generated at 2022-06-26 10:19:46.599591
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    q = OneOf  # type: typing.Union[typing.Type[Any], typing.Type[NeverMatch]]
    x = AllOf  # type: typing.Union[typing.Type[Any], typing.Type[NeverMatch]]
    y = OneOf  # type: typing.Union[typing.Type[Any], typing.Type[NeverMatch]]
    z = IfThenElse(never_match_0, y, z)
    assert z.if_clause is never_match_0
    assert z.then_clause is y
    assert z.else_clause is z