

# Generated at 2022-06-26 10:09:47.033365
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True)


# Generated at 2022-06-26 10:09:48.436967
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert 1 == 1, "one equals one"

# Generated at 2022-06-26 10:09:56.826073
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Setup
    one_of = list()
    one_of.append(None)
    one_of.append(None)
    one_of.append(None)
    one_of.append(None)
    one_of.append(None)
    one_of.append(None)
    one_of.append(None)
    one_of.append(None)
    one_of.append(None)
    one_of.append(None)
    value = None
    strict = False
    
    # Exercise
    one_of1 = OneOf(one_of)
    ret = one_of1.validate(value, strict)
    
    # Verify
    pass


# Generated at 2022-06-26 10:10:02.205361
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)


# Generated at 2022-06-26 10:10:08.571868
# Unit test for method validate of class Not
def test_Not_validate():
    negated = NeverMatch.make(description="Negated field")
    not_ = Not.make(negated=negated, description="Negated field")
    err = Not.validate(
        not_,
        value=None,
        strict=True,
    )
    assert err == None


# Generated at 2022-06-26 10:10:14.026452
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(one_of=[Any(), Any()])
    assert one_of_0.validate(None) == None


# Generated at 2022-06-26 10:10:18.713245
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None
    then_clause = None
    else_clause = None
    IfThenElse(if_clause, then_clause, else_clause)


# Generated at 2022-06-26 10:10:20.519294
# Unit test for method validate of class OneOf
def test_OneOf_validate():
	test_OneOf_validate_0()


# Generated at 2022-06-26 10:10:23.047998
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])


# Generated at 2022-06-26 10:10:24.722881
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(String(max_length=20),title='Not')
    n.validate('hello') # It should raise ValidationError


# Generated at 2022-06-26 10:10:34.143100
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=NeverMatch())
    assert not_0.validate(value=5) == 5

# Generated at 2022-06-26 10:10:36.418144
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([
        Integer(description="First field"),
        Integer(description="Second field"),
        Integer(description="Third field"),
    ],
        description="A list of integers"
    )


# Generated at 2022-06-26 10:10:41.390530
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    validate_IfThenElse_0 = IfThenElse(
        if_clause=NeverMatch(), then_clause=NeverMatch(), else_clause=NeverMatch()
    ).validate(None)


# Generated at 2022-06-26 10:10:46.691456
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    param = {
        "if_clause": IfThenElse,
        "then_clause": Field,
        "else_clause": Field,
        "required": bool,
        "description": str,
        "name": str,
        "allow_null": bool,
        "format": str
    }
    obj = IfThenElse.__init__(param)
    obj.validate()
    return



# Generated at 2022-06-26 10:10:53.313762
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    true_type = Field()
    false_type = Field()

    if_then_else = IfThenElse(true_type, then_clause=true_type, else_clause=false_type)
    # assert False to make sure code runs
    assert False

# Generated at 2022-06-26 10:11:01.968269
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    then_clause_1 = NeverMatch()
    else_clause_1 = NeverMatch()
    test_object = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    try:
        test_object.validate(True)
        assert False
    except Exception:
        pass
    test_object = IfThenElse(if_clause_0, then_clause_1, else_clause_1)
    try:
        test_object.validate(False)
        assert False
    except Exception:
        pass
    if_clause_2 = NeverMatch()
    then_clause_2 = NeverMatch()

# Generated at 2022-06-26 10:11:11.486740
# Unit test for method validate of class Not
def test_Not_validate():
    not_0_0 = Not(negated=Any())
    not_0_1 = Not(negated=Any())

    # Test with both if_clause and then_clause
    if_then_else_0 = IfThenElse(if_clause=Any(), then_clause=Any())
    if_then_else_1 = IfThenElse(if_clause=Any(), then_clause=Any())

    # Test with if_clause and no then_clause
    if_then_else_2 = IfThenElse(if_clause=Any())
    if_then_else_3 = IfThenElse(if_clause=Any())

    # Test with if_clause, else_clause and no then_clause

# Generated at 2022-06-26 10:11:20.201111
# Unit test for method validate of class Not
def test_Not_validate():
    all_0 = [
        True,
        False,
        1,
        0,
        -1,
        0.0,
        42.5,
        -4.2,
        "hello",
        "world!",
        (),
        [],
        {},
        "",
        0j,
        1j,
        {},
        [],
        None,
        True,
    ]
    for v_0 in all_0:
        for v_1 in all_0:
            n_0 = Not(v_0)
            n_0.validate(value=v_1)

            n_1 = Not(v_1)
            n_1.validate(value=v_0)


# Generated at 2022-06-26 10:11:23.128322
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__doc__ == "Must match exactly one of the sub-items."

# Generated at 2022-06-26 10:11:28.059448
# Unit test for constructor of class AllOf
def test_AllOf():
    int_0 = typesystem.Integer()
    all_of_0 = AllOf([int_0])
    assert isinstance(all_of_0, Field)
    assert all_of_0.all_of == [int_0]


# Generated at 2022-06-26 10:11:40.387355
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
  never_match_0 = NeverMatch()
  if_clause_0 = never_match_0
  then_clause_0 = never_match_0
  else_clause_0 = never_match_0
  if_then_else_0 = IfThenElse(if_clause=if_clause_0,then_clause=then_clause_0,else_clause=else_clause_0)
  #example: if_then_else_0.validate(value=1)

# Generated at 2022-06-26 10:11:41.812542
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:11:46.039265
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    value = 1

    # Action
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    ex = None
    try:
        if_then_else.validate(value)
    except ValidationError as e:
        ex = e

    # Assert
    assert ex is not None
    assert ex.errors.get("negated")

# Generated at 2022-06-26 10:11:47.499814
# Unit test for constructor of class OneOf
def test_OneOf():
    # no_match =
    OneOf([NeverMatch()])
    # multiple_matches =
    OneOf([Any(), Any()])


# Generated at 2022-06-26 10:11:51.143832
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    OneOf_validate_0 = OneOf([Any()])

    OneOf_validate_0.validate(None)


# Generated at 2022-06-26 10:11:58.902601
# Unit test for method validate of class Not
def test_Not_validate():
    negated_0 = None
    Not_instance_0 = Not(negated=negated_0)
    try:
        Not_instance_0.validate(value=None)
    except Exception as error:
        print(type(error))
        # ==> <class 'typesystem.exceptions.ValidationError'>
        print(error)
        # ==> 'Must not match.'

# Generated at 2022-06-26 10:12:06.269271
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Any()
    then_clause_0 = Any()
    else_clause_0 = Any()
    IfThenElse_obj_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = "value"
    str_0 = IfThenElse_obj_0.validate(value_0)
    assert str_0 == "value"

# Generated at 2022-06-26 10:12:14.144517
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Variables that are defined in this method
    if_clause: Field = None
    then_clause: Field = None
    else_clause: Field = None
    if_then_else: IfThenElse = None

    # Assign values to the variables defined above
    if_clause = None
    then_clause = None
    else_clause = None
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)



# Generated at 2022-06-26 10:12:15.082436
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[NeverMatch()])


# Generated at 2022-06-26 10:12:19.178563
# Unit test for method validate of class Not
def test_Not_validate():
    # Arrange
    negated = Field()

    # Act
    not_0 = Not(negated)
    not_0.validate("0")


# Generated at 2022-06-26 10:12:25.507677
# Unit test for method validate of class Not
def test_Not_validate():
    never = NeverMatch()
    clone = Not(never)
    # Method validate of class Not should return value
    assert clone.validate(None) is None
    # Method validate of class Not should raise ValidationError with key `negated`
    try:
        clone.validate(0)
        assert False
    except ValidationError as e:
        assert e.key == 'negated'


# Generated at 2022-06-26 10:12:29.123944
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    never_match_0.validate(1, False)


# Generated at 2022-06-26 10:12:32.405462
# Unit test for constructor of class Not
def test_Not():
    # Test for default constructor
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, NeverMatch)
    negated_Field_0 = Not(never_match_0)
    assert isinstance(negated_Field_0, Field)


# Generated at 2022-06-26 10:12:34.112521
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=never_match_0)



# Generated at 2022-06-26 10:12:38.719384
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    import unittest

    try:
        test_case_0()
    except Exception as e:
        suite = unittest.TestSuite()
        suite.addTest(unittest.makeSuite(test_NeverMatch))
        runner = unittest.TextTestRunner()
        res = runner.run(suite)
        print(res)
    if __name__ == "__main__":
        unittest.main()

# Generated at 2022-06-26 10:12:43.852214
# Unit test for constructor of class AllOf
def test_AllOf():
    # this is just a stubbed out test case until we can generate it from the
    # JSON schema syntax.
    field_0 = Any()
    field_1 = AllOf([field_0])
    case_0 = field_1


# Generated at 2022-06-26 10:12:48.496877
# Unit test for constructor of class OneOf
def test_OneOf():
    # Input data for testing
    one_of = None
    kwargs = {}

    # Constructor call and assertion
    one_of = OneOf(**kwargs)
    assert one_of.one_of == None


# Generated at 2022-06-26 10:12:50.358413
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(
        [
            NeverMatch(),
            NeverMatch()
        ]
    )
    all_of_0.validate(
        None
    )


# Generated at 2022-06-26 10:12:56.604787
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}
    assert never_match_0.validate(None) == ValueError()
    assert never_match_0.validate(None, True) == ValueError()

if __name__ == "__main__":
    test_NeverMatch()

# Generated at 2022-06-26 10:12:57.919931
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        test_case_0()



# Generated at 2022-06-26 10:13:07.041219
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = None
    # State 0
    # Instantiation test
    never_match_0 = NeverMatch()
    assert never_match_0 is not None


# Generated at 2022-06-26 10:13:15.487833
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None
    then_clause = None
    else_clause = None
    IfThenElse(if_clause, then_clause, else_clause)
    if_clause = None
    then_clause = None
    else_clause = None
    IfThenElse(if_clause, then_clause, else_clause)


# Generated at 2022-06-26 10:13:27.372560
# Unit test for method validate of class Not
def test_Not_validate():
    # Arrange
    negated = Field(required=True)
    if_clause = Field(required=True)
    then_clause = Field(required=False)
    else_clause = Field(required=False)
    not_field = Not(Field(required=False))
    if_then_else_field = IfThenElse(if_clause, then_clause, else_clause)
    all_of_field = AllOf([Field(required=True), Field(required=True)])
    one_of_field = OneOf([Field(required=False), Field(required=False)])

    # Act
    not_field.validate(None, strict=False)
    if_then_else_field.validate(None, strict=False)

# Generated at 2022-06-26 10:13:31.136538
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(one_of = [], allow_null = True, name = 'anyOf', description = 'Must match exactly one of the sub-items.', error_messages = {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'})


# Generated at 2022-06-26 10:13:32.735020
# Unit test for constructor of class Not
def test_Not():
    not0 = Not()


# Generated at 2022-06-26 10:13:34.706353
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()



# Generated at 2022-06-26 10:13:36.503412
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[])


# Generated at 2022-06-26 10:13:38.751740
# Unit test for constructor of class Not
def test_Not():
  NeverMatch_0 = NeverMatch()
  Not_0 = Not(negated = NeverMatch_0)


# Generated at 2022-06-26 10:13:45.786815
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert hasattr(test_case_0, "assertEqual")
    assert isinstance(test_case_0.never_match_0, typing.Any)
    test_case_0.assertEqual(test_case_0.never_match_0.errors, {'never': 'This never validates.'})


# Generated at 2022-06-26 10:13:48.113822
# Unit test for constructor of class Not
def test_Not():
    negated = NeverMatch()
    not_0 = Not(negated=negated)


# Generated at 2022-06-26 10:14:06.336363
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(None)
    try:
        not_0.validate(None)
    except Exception as x:
        assert isinstance(x, Not.validation_error)


# Generated at 2022-06-26 10:14:09.797146
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        never_match_0 = NeverMatch()
    except Exception as err:
        assert False, err.args


# Generated at 2022-06-26 10:14:11.344663
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])


# Generated at 2022-06-26 10:14:14.134525
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([])
    assert a.all_of == []


# Generated at 2022-06-26 10:14:19.108878
# Unit test for constructor of class AllOf
def test_AllOf():
    items = [
        Field(),
        Field(),
        Field(),
    ]
    all_of = AllOf(items)
    assert isinstance(all_of, Field)



# Generated at 2022-06-26 10:14:21.513166
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Case 0
    never_match_0 = NeverMatch()



# Generated at 2022-06-26 10:14:23.572020
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()


# Generated at 2022-06-26 10:14:26.292186
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=None)
    assert field.negated is None

# Generated at 2022-06-26 10:14:29.094949
# Unit test for method validate of class Not
def test_Not_validate():
    (a) = (1)
    assert (a >= 0)


# Generated at 2022-06-26 10:14:30.601963
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()

# Generated at 2022-06-26 10:15:01.050145
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    # from pytest import raises
    from .test_fields import get_test_field_value
    
    # Case 1: Invalid type
    field_0 = OneOf([get_test_field_value(True)], name="test1")
    test_value_0 = get_test_field_value(False)
    # with raises(ValidationError) as ex:
    #     _ = field_0.validate(test_value_0)
    # assert ex.value.message == "test1: test1_0"
    # assert ex.value.path == "test1"

    # Case 2: Invalid value
    field_1 = OneOf([get_test_field_value(True)], name="test1")
    test_value_1 = get_test_field_value(False)
    # with raises(Validation

# Generated at 2022-06-26 10:15:05.991590
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(1)
    not_field.validate(None)
    not_field.validate("hello")



# Generated at 2022-06-26 10:15:10.814294
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=None)
    try:
        not_0.validate(None)
    except Exception as e:
        print(e)
    try:
        not_0.validate(None)
    except Exception as e:
        print(e)
    try:
        not_0.validate(None)
    except Exception as e:
        print(e)


# Generated at 2022-06-26 10:15:15.392974
# Unit test for method validate of class Not
def test_Not_validate():
    # Construct NeverMatch instance for testing
    never_match_0 = NeverMatch()
    # Construct an instance of Not using never_match_0
    not_0 = Not(negated=never_match_0)
    # Call not_0.validate using a random value
    random.seed()
    rand_0 = random.randint(0, 100000000)
    not_0.validate(value=rand_0)

# Generated at 2022-06-26 10:15:17.296501
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(Negated=None)
    pass


# Generated at 2022-06-26 10:15:20.347982
# Unit test for constructor of class Not
def test_Not():
    my_field = typesystem.String()
    negated = Not(my_field)
    assert negated is not None


# Generated at 2022-06-26 10:15:24.389207
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_instance = Not(never_match_0)
    result = not_instance.validate(
        "test", strict=False)
    assert result == "test"



# Generated at 2022-06-26 10:15:25.380659
# Unit test for constructor of class Not
def test_Not():
    a=Not(negated=NeverMatch())


# Generated at 2022-06-26 10:15:30.159564
# Unit test for constructor of class Not
def test_Not():
    negated = NeverMatch()
    test_Not = Not(negated=negated)


# Generated at 2022-06-26 10:15:37.167119
# Unit test for constructor of class Not
def test_Not():
    all_of = [
        Field(name="foo"),
        Field(name="bar"),
        Field(name="baz"),
    ]
    field = Not(negated=AllOf(all_of=all_of))
    assert field.negated == AllOf(all_of=all_of)
    assert field.errors == Not.errors
    assert field.name == ""
    assert field.default is None
    assert field.required is False
    assert field.allow_null is False


# Generated at 2022-06-26 10:16:04.817571
# Unit test for constructor of class Not
def test_Not():
  test_Not = Not(negated=None)
  assert test_Not.negated is None


# Generated at 2022-06-26 10:16:11.782492
# Unit test for constructor of class Not
def test_Not():
  # Assert default values for boolean parameters
  
  not_test = Not(Field())
  # Assert expected type for `negated`
  assert type(not_test.negated) == Field
  
  assert not_test.errors == {"negated": "Must not match."}


# Generated at 2022-06-26 10:16:14.162086
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:16:15.575481
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated=Any())


# Generated at 2022-06-26 10:16:17.355632
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated=None)


# Generated at 2022-06-26 10:16:19.471247
# Unit test for constructor of class Not
def test_Not():
    errors = {"negated": "Must not match."}
    negated = NeverMatch()
    not_0 = Not(errors=errors, negated=negated)


# Generated at 2022-06-26 10:16:23.528417
# Unit test for constructor of class Not
def test_Not():
    negated = NeverMatch()
    test_Not = Not(negated)
    # should be Not()


# Generated at 2022-06-26 10:16:25.890631
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Instance of class NeverMatch
    never_match_0 = NeverMatch()
    assert type(never_match_0) == NeverMatch


# Generated at 2022-06-26 10:16:37.718753
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem import Schema

    schema = Schema(
        {
            "title": str,
            "one_of": OneOf([int, str]),
            "all_of": AllOf([int]),
            "not": Not(int),
            "ifthenelse": IfThenElse(float, 1, 2),
            "never": NeverMatch(),
        }
    )
    schema.validate({"one_of": "test"})
    schema.validate({"all_of": 1})
    schema.validate({"not": "test"})
    schema.validate({"ifthenelse": 1.0})
    with pytest.raises(schema.ValidationError):
        schema.validate({"never": "test"})


# Generated at 2022-06-26 10:16:39.365911
# Unit test for constructor of class Not
def test_Not():
    x = Not(None)


# Generated at 2022-06-26 10:17:00.258375
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test for no parameters passed
    assert (str(NeverMatch()) == "None")


# Generated at 2022-06-26 10:17:11.786383
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    class EmployeeExt(OneOf):
        def __init__(self, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(
                one_of=[String, String],
                **kwargs,
            )
            self.name = 'EmployeeExt'

    class Employee:
        def __init__(self, name:str, age:str) -> None:
            self.name = name
            self.age = age

    employee = Employee('shubham', 34)
    schema = EmployeeExt(required=False)
    print(schema.validate(employee))
    print(schema.validate('Shubham'))


# Generated at 2022-06-26 10:17:15.834081
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([String(), Number()])
    one_of_0.validate(1)


# Generated at 2022-06-26 10:17:18.223557
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:17:22.546161
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([Field(description="...")])
    one_of_1 = OneOf([Field(description="...")])
    one_of_2 = OneOf([Field(description="...")])
    one_of_3 = OneOf([Field(description="...")])


# Generated at 2022-06-26 10:17:31.473934
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert never_match_0.errors == {'never': 'This never validates.'}
    assert never_match_0.error_messages == {'never': 'This never validates.'}
    assert never_match_0.label == 'NeverMatch'
    assert never_match_0.empty_html_input == ''
    assert never_match_0.prototype == ''
    assert never_match_0.display_name == 'NeverMatch'



# Generated at 2022-06-26 10:17:33.049173
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()



# Generated at 2022-06-26 10:17:36.511489
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Any()]).validate(True)
    assert OneOf([Any(), Any()]).validate(True)



# Generated at 2022-06-26 10:17:38.685802
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:17:40.231929
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch() is not None


# Generated at 2022-06-26 10:18:06.522597
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()



# Generated at 2022-06-26 10:18:08.605185
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass # TODO: implement your test here


# Generated at 2022-06-26 10:18:10.369066
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = [Any()]
    field = OneOf(one_of)
    field.validate(3)


# Generated at 2022-06-26 10:18:11.478223
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	never_match_0 = NeverMatch()
	assert never_match_0.required == False
	assert never_match_0.nullable == False
	assert never_match_0.strict == False


# Generated at 2022-06-26 10:18:13.158225
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    pass

# Generated at 2022-06-26 10:18:15.661488
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert issubclass(NeverMatch, Field)
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:18:19.225801
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert never_match_0


# Generated at 2022-06-26 10:18:25.151564
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        never_match_0 = NeverMatch()
    except Exception as e:
        if type(e) == TypeError:
            print('NeverMatch: constructor: no exception expected')
        else:
            raise


# Generated at 2022-06-26 10:18:28.601689
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_1 = NeverMatch()
    assert never_match_1


# Generated at 2022-06-26 10:18:31.042271
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:19:21.571731
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Creating an OneOf object
    one_of_0 = OneOf([Any()])
    # Calling method validate of one_of_0
    one_of_0.validate(None, strict=True)

# Generated at 2022-06-26 10:19:25.123632
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    always_true = AlwaysTrue()
    never_match_1 = NeverMatch()
    assert OneOf([always_true, never_match_1]).validate(True) is True
    assert OneOf([never_match_1, always_true]).validate(True) is True


# Generated at 2022-06-26 10:19:29.385674
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = None
    value = None
    strict = None

    one_of_0 = OneOf(field)
    one_of_0.validate(value, strict=strict)



# Generated at 2022-06-26 10:19:33.223288
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    oneOf_00 = OneOf([NeverMatch()])
    oneOf_01 = OneOf([NeverMatch(), NeverMatch()])
    oneOf_02 = OneOf([NeverMatch(), NeverMatch(), NeverMatch()])


# Generated at 2022-06-26 10:19:42.818075
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(one_of=[Any(),Boolean()])
    assert "one_of_0" in one_of.as_json_schema()["oneOf"][0]
    assert "one_of_1" in one_of.as_json_schema()["oneOf"][1]
    one_of.validate(True)
