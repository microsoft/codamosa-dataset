

# Generated at 2022-06-26 10:09:52.896971
# Unit test for constructor of class Not
def test_Not():

    # ---
    # Creates a new instance of Not with correct arguments
    # ---
    Field_instance_0 = Field()
    Not_instance_0 = Not(
        negated=Field_instance_0
    )

    # ---
    # Check class attribute errors
    # ---
    errors_expected_0 = {
        "negated": "Must not match."
    }
    errors_actual_0 = Not_instance_0.errors
    assert errors_expected_0 == errors_actual_0


# Generated at 2022-06-26 10:09:57.980747
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    oneOf_field = OneOf([])
    assert oneOf_field.validate(5)
    assert oneOf_field.validate(6)


# Generated at 2022-06-26 10:10:08.704968
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    any_ = Any()
    integer = Integer()
    if_clause = any_
    then_clause = any_
    else_clause = integer
    field = IfThenElse(if_clause, then_clause, else_clause)

    # Action
    value = 0
    strict = False
    actual = field.validate(value, strict=strict)

    # Assert
    expected = 0
    assert expected == actual



# Generated at 2022-06-26 10:10:13.711558
# Unit test for constructor of class Not
def test_Not():
    # default values for optional parameters
    try:
        not_0 = Not(Field())
    except TypeError:
        pass


# Generated at 2022-06-26 10:10:26.097410
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = {
        'additionalProperties': {'type': 'number'},
        'properties': {
            'age': {'maximum': 150, 'minimum': 0.0, 'type': 'number'},
            'name': {'type': 'string'}
        },
        'required': ['age', 'name'],
        'type': 'object'}
    errors_0 = {
        'additionalProperties': {'type': 'number'},
        'properties': {
            'age': {'maximum': 150, 'minimum': 0.0, 'type': 'number'},
            'name': {'type': 'string'}
        },
        'required': ['age', 'name'],
        'type': 'object'}

# Generated at 2022-06-26 10:10:28.423461
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert hasattr(NeverMatch, "__init__")



# Generated at 2022-06-26 10:10:32.877533
# Unit test for constructor of class Not
def test_Not():
    try:
        never_match_1 = NeverMatch()
        not_0 = Not(never_match_1)
    except Exception as e:
        assert(False)


# Generated at 2022-06-26 10:10:37.694573
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    ite = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    value = 1
    strict = False
    with pytest.raises(AssertionError):
        ite.validate(value=value, strict=strict)


# Generated at 2022-06-26 10:10:45.799632
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=NeverMatch())
    not_1 = Not(negated=NeverMatch())
    not_2 = Not(negated=not_0)
    not_3 = Not(negated=not_1)
    assert not_0.validate(value=None) == None
    assert not_1.validate(value=None) == None
    assert not_2.validate(value=None) == None
    assert not_3.validate(value=None) == None


# Generated at 2022-06-26 10:10:49.903027
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = test_case_0()
    assert not isinstance(if_clause, Field)

# Generated at 2022-06-26 10:10:55.625577
# Unit test for constructor of class Not
def test_Not():
    negated_0: Field = AlwaysMatch()
    result = Not(negated=negated_0)
    result


# Generated at 2022-06-26 10:10:57.121143
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.validate('1') == 1

# Generated at 2022-06-26 10:11:06.916336
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    value = tests.json_dummy_0
    strict = False
    if_then_else_1 = IfThenElse(if_clause, then_clause, else_clause)
    with pytest.raises(ValidationError):
        if_then_else_1.validate(value, strict)


# Generated at 2022-06-26 10:11:21.116577
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = None
    then_clause = None
    else_clause = None
    ite = IfThenElse(if_clause, then_clause, else_clause)
    value = None
    strict = None
    ite.validate(value, strict) # Should raise the error "then_clause should not be None"
    if_clause = None
    then_clause = None
    else_clause = None
    ite = IfThenElse(if_clause, then_clause, else_clause)
    value = None
    strict = None
    ite.validate(value, strict) # Should raise the error "else_clause should not be None"
    if_clause = None
    then_clause = None
    else_clause = NeverMatch()
    ite

# Generated at 2022-06-26 10:11:31.171143
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([String()])
    one_of_1 = OneOf([RegexPattern(regex='[a-zA-Z]+')])
    one_of_2 = OneOf([String(), RegexPattern(regex='[a-zA-Z]+')])
    one_of_3 = OneOf([Object(properties={}), Array(items=String())])
    one_of_4 = OneOf([Object(properties={}), String()])
    one_of_5 = OneOf([Object(properties={}), String(), RegexPattern(regex='[a-zA-Z]+')])


# Generated at 2022-06-26 10:11:33.391200
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([NeverMatch()])
    actual = one_of_0.validate(1)
    assert actual


# Generated at 2022-06-26 10:11:35.611531
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(all_of=[])


# Generated at 2022-06-26 10:11:39.302898
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
  if_clause_0 = NeverMatch()
  then_clause_0 = NeverMatch()
  else_clause_0 = NeverMatch()
  sut_0 = IfThenElse(if_clause_0,then_clause_0,else_clause_0)
  try:
    sut_0.validate('a')
    assert False
  except:
    assert True



# Generated at 2022-06-26 10:11:41.775783
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    try:
        NeverMatch(allow_null=True)
    except AssertionError:
        raise AssertionError(str(AssertionError()))


# Generated at 2022-06-26 10:11:54.369544
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Integer number with multiple valid types
    one_of_0 = OneOf([Integer(), Number()])
    
    # Integer number with a single valid type
    one_of_1 = OneOf([Integer()])
    
    # String with multiple valid types
    one_of_2 = OneOf([String(), Email()])
    
    # String with a single valid type
    one_of_3 = OneOf([String()])
    
    # Decimal number with multiple valid types
    one_of_4 = OneOf([Decimal(), Number()])
    
    # Decimal number with a single valid type
    one_of_5 = OneOf([Decimal()])
    
    # Integer number with no valid type
    one_of_6 = OneOf([Email()])
    
    # String with no valid types
    one_of_

# Generated at 2022-06-26 10:11:58.709640
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    #
    # One of the sub items validates
    #
    def test_a(value):
        return value
    field = OneOf([
        test_a,
        NeverMatch(),
    ])
    result = field.validate(1)
    assert result == 1


# Generated at 2022-06-26 10:12:04.967114
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    case_0_in_0 = None
    case_0_out_0 = None
    if_clause_0 = 'ii1f;'
    then_clause_0 = 'YcX,5.fzE'
    else_clause_0 = True
    case_0_obj_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    case_0_obj_0.validate(case_0_in_0)
    assert case_0_out_0 == None


# Generated at 2022-06-26 10:12:12.650397
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    integer_0 = Integer()
    boolean_0 = Boolean()
    one_of_0 = OneOf(one_of=[integer_0, boolean_0])
    try:
        one_of_0.validate(value=1.0, strict=True)
    except ValueError as e:
        assert "'no_match' {{ 'value': 1.0 }}" == str(e)


# Generated at 2022-06-26 10:12:22.701607
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.validators import MinLength, Required
    field = IfThenElse(
        if_clause=MinLength(4),
        then_clause=Required()
    )
    try:
        field.validate("asd")
    except Exception:
        assert True
    else:
        assert False
    try:
        field.validate("asda")
    except Exception:
        assert False
    else:
        assert True

# Generated at 2022-06-26 10:12:24.275505
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    one_of_0.validate({})



# Generated at 2022-06-26 10:12:38.066121
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.error_messages == {'never': 'This never validates.'}
    # See https://github.com/python/mypy/issues/5374
    assert never_match_0.default == typing.Any
    assert never_match_0.nullable == False
    assert never_match_0.title == ''
    assert never_match_0.description == ''
    assert never_match_0.format == ''
    assert never_match_0.const == None
    assert never_match_0.enum == []
    assert never_match_0.exclusive_maximum == False
    assert never_match_0.exclusive_minimum == False
    assert never_match_0.maximum == None
    assert never_match_0.minimum == None
    assert never_match

# Generated at 2022-06-26 10:12:46.298428
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Defining var never_match_0

    class never_match_0(Field):
        errors = {"never": "This never validates."}

        def __init__(self, **kwargs):
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)

        def validate(self, value, strict=False):
            raise self.validation_error("never")



# Generated at 2022-06-26 10:12:59.843331
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    # unit tests for OneOf.validate
    field = OneOf([])
    assert field.validate('abc') == 'abc'

    field = OneOf([Any(max_length=10)])
    assert field.validate('abcdefghij') == 'abcdefghij'
    assert field.validate('abcdefghijk') != 'abcdefghijk'

    field = OneOf([Any(max_length=10), Any(max_value=99)])
    assert field.validate('abcdefghij') == 'abcdefghij'
    assert field.validate('abcdefghijk') != 'abcdefghijk'
    assert field.validate(50) == 50
    assert field.validate(100) != 100


# Generated at 2022-06-26 10:13:03.038229
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    OneOf_instance = OneOf([Any()])
    OneOf_instance.validate(None)


# Generated at 2022-06-26 10:13:10.392816
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = IfThenElse("if_clause_0")
    then_clause_0 = IfThenElse("then_clause_0")
    else_clause_0 = IfThenElse("else_clause_0")
    testcase_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    testcase_0.validate()


# Generated at 2022-06-26 10:13:15.873883
# Unit test for constructor of class AllOf
def test_AllOf():
    with pytest.raises(AssertionError):
        AllOf(all_of=[AllOf(all_of=[])])

# Generated at 2022-06-26 10:13:18.190449
# Unit test for constructor of class Not
def test_Not():
    negated = None
    test_Not = Not(negated)

    return


# Generated at 2022-06-26 10:13:25.393266
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Variables
    if_clause = None
    then_clause = None
    else_clause = None
    value = None
    strict = False
    # Setup mocks
    test_case_IfThenElse_validate_target = IfThenElse(if_clause, then_clause, else_clause)
    # Execute
    result = test_case_IfThenElse_validate_target.validate(value, strict)
    # Verify
    assert False


# Generated at 2022-06-26 10:13:27.421165
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test 1:
    never_match_0 = NeverMatch()



# Generated at 2022-06-26 10:13:29.790421
# Unit test for constructor of class OneOf
def test_OneOf():
    number_enum_0 = OneOf(2, 5)


# Generated at 2022-06-26 10:13:41.217375
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    foo_field = String(name="foo")
    bar_field = String(name="bar")
    if_clause = foo_field
    then_clause = bar_field
    else_clause = bar_field
    validator = IfThenElse(
        if_clause=if_clause,
        then_clause=then_clause,
        else_clause=else_clause
    )
    # case 0
    result = validator.validate({"foo": "val"})
    assert result == {"foo": "val"}
    # case 1
    result = validator.validate({"foo": "val", "bar": "val"})
    assert result == {"foo": "val", "bar": "val"}



# Generated at 2022-06-26 10:13:51.826634
# Unit test for constructor of class AllOf
def test_AllOf():
    fields_0: typing.List[Field] = [Any()]
    fields_1: typing.List[Field] = [Any()]
    fields_2: typing.List[Field] = [Any()]
    all_of_0 = AllOf(all_of=fields_0)
    all_of_1 = AllOf(all_of=fields_2)
    all_of_2 = AllOf(all_of=fields_2)
    all_of_3 = AllOf(fields_1)
    all_of_4 = AllOf(fields_1)
    all_of_5 = AllOf(fields_2)
    all_of_6 = AllOf(fields_1)
    all_of_7 = AllOf(fields_0)
    all_of_8 = AllOf(fields_1)
   

# Generated at 2022-06-26 10:13:57.370097
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = String()
    then_clause = String()
    else_clause = String()

    if_clause = String()
    then_clause = String()
    else_clause = String()


# Generated at 2022-06-26 10:14:01.835569
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = OneOf([])
    field_1 = OneOf([NeverMatch()])
    field_2 = OneOf([NeverMatch(), NeverMatch()])
    assert field_0.validate(None)
    assert field_1.validate(None)
    assert field_2.validate(None)


# Generated at 2022-06-26 10:14:03.562368
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([])


# Generated at 2022-06-26 10:14:09.725338
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Case 1:
    never_match_0 = NeverMatch()

# Generated at 2022-06-26 10:14:13.567997
# Unit test for constructor of class OneOf
def test_OneOf():
    test_list = []
    oneof = OneOf(test_list)
    assert oneof.one_of == []
    assert oneof.errors == {'multiple_matches': 'Matched more than one type.', 'no_match': 'Did not match any valid type.'}

# Generated at 2022-06-26 10:14:17.673816
# Unit test for constructor of class OneOf
def test_OneOf():
    m_one_0 = OneOf(one_of = [])
    m_one_1 = OneOf(one_of = [NeverMatch()])


# Generated at 2022-06-26 10:14:19.349433
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()



# Generated at 2022-06-26 10:14:20.914688
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    ifThenElse = IfThenElse("")

    # Act
    def f():
        return ifThenElse.validate("")
    # Assert
    #self.assertEqual(f(), )

# Generated at 2022-06-26 10:14:28.000673
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String
    from typesystem.typing import Literal

    if_clause = String()
    then_clause = String(max_length=5)
    else_clause = String(min_length=3, max_length=3)

    ite = IfThenElse(if_clause, then_clause, else_clause)

    error = ite.validate("123")
    assert error is None

    error = ite.validate("1234")
    assert error is None

    error = ite.validate("12345")
    assert error is not None

    error = ite.validate("2")
    assert error is None

    error = ite.validate("23")
    assert error is None

    error = ite.validate("234")

# Generated at 2022-06-26 10:14:40.329195
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()
    else_clause = NeverMatch()

    then_clause = NeverMatch()

# Generated at 2022-06-26 10:14:41.864127
# Unit test for constructor of class Not
def test_Not():
    field = NeverMatch()
    not_field = Not(negated=field)

# Generated at 2022-06-26 10:14:46.988548
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Any()
    then_clause_0 = Any()
    else_clause_0 = Any()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = None
    
    # Test of passing an object of the wrong type into field validation.
    # If a field doesn't type check, then it should throw an error on any value.
    strict_0 = False
    if_then_else_0.validate(value_0, strict_0)

# Generated at 2022-06-26 10:14:59.257923
# Unit test for constructor of class OneOf
def test_OneOf():
    with pytest.raises(TypeError):
        OneOf(one_of = None)
    with pytest.raises(TypeError):
        OneOf(one_of = "one_of")
    with pytest.raises(TypeError):
        OneOf(one_of = 1.0)
    with pytest.raises(TypeError):
        OneOf(one_of = 1)
    with pytest.raises(TypeError):
        OneOf(one_of = {'one_of': 'one_of'})
    with pytest.raises(TypeError):
        OneOf(one_of = {1: 'one_of'})
    with pytest.raises(TypeError):
        OneOf(one_of = {'one_of': 1})

# Generated at 2022-06-26 10:15:05.778177
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[Any()])


# Generated at 2022-06-26 10:15:17.164831
# Unit test for constructor of class Not
def test_Not():
    # For class Not, the first argument is negated, and there are no other arguments.
    # The type of negated can be any fields.
    from typesystem import Integer
    from typesystem import String
    from typesystem import Boolean
    from typesystem import Float
    from typesystem import Any
    from typesystem import Array
    from typesystem import Object
    from typesystem import Union

    field1 = Integer()
    field2 = String()
    field3 = Boolean()
    field4 = Float()
    field5 = Any()
    field6 = Array(field1)
    field7 = Object({"field":field2})
    field8 = Union(field3,field4)

    # Field1 is one of the valid fields

# Generated at 2022-06-26 10:15:18.608469
# Unit test for constructor of class AllOf
def test_AllOf():
    assert issubclass(AllOf, Field)

# Generated at 2022-06-26 10:15:20.197562
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0 != None


# Generated at 2022-06-26 10:15:21.039229
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    type(NeverMatch)

# Generated at 2022-06-26 10:15:22.444341
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(Field())


# Generated at 2022-06-26 10:15:29.038489
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import unittest
    import typesystem
    import json
    import sys
    class NewTestClass(unittest.TestCase):

        def test_OneOf_validate_0(self):
            # Test 0
            # No error
            one_of_0 = typesystem.OneOf([typesystem.String()])
            try:
                typesystem.validate(one_of_0, "1")
            except:
                self.fail("Unexpected Failure in one_of_0")

        def test_OneOf_validate_1(self):
            # Test 1
            # No error
            one_of_1 = typesystem.OneOf([typesystem.String(), typesystem.Integer()])

# Generated at 2022-06-26 10:15:36.078137
# Unit test for constructor of class AllOf
def test_AllOf():
    # TYPES: (List[Field], Dict[str, Any]) -> AllOf
    one_of_0 = AllOf()
    one_of_1 = AllOf(None)
    one_of_2 = AllOf(None, None)
    assert one_of_0 is not None # type: ignore
    assert one_of_1 is not None # type: ignore
    assert one_of_2 is not None # type: ignore


# Generated at 2022-06-26 10:15:39.030180
# Unit test for constructor of class OneOf
def test_OneOf():
    assert issubclass(OneOf, Field)


# Generated at 2022-06-26 10:15:42.269387
# Unit test for constructor of class Not
def test_Not():
    test_req = "test string"
    negated = String()
    not_0 = Not(negated = negated)



# Generated at 2022-06-26 10:15:48.438114
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated = None)


# Generated at 2022-06-26 10:15:49.781944
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    case_0 = NeverMatch()


# Generated at 2022-06-26 10:15:51.123599
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()

# Generated at 2022-06-26 10:15:56.958175
# Unit test for constructor of class Not
def test_Not():
    schema = {
        "name": "Not",
        "type": "object",
        "properties": {"negated": {"oneOf": [{"type": "null"}, {"type": "boolean"}]}},
    }
    negated = Field.from_json(schema["properties"]["negated"])
    not_0 = Not(negated)


# Generated at 2022-06-26 10:15:59.109403
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf is not None and issubclass(AllOf, Field)


# Generated at 2022-06-26 10:16:01.278452
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of=[])


# Generated at 2022-06-26 10:16:04.934288
# Unit test for constructor of class AllOf
def test_AllOf():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    all_of_0 = AllOf([never_match_0, never_match_1])


# Generated at 2022-06-26 10:16:07.096035
# Unit test for constructor of class OneOf
def test_OneOf():
    assert not "allow_null" in OneOf.options

# Generated at 2022-06-26 10:16:10.222764
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print("\n\nTesting NeverMatch class constructor")

    assert NeverMatch() is not None


# Generated at 2022-06-26 10:16:14.978890
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.validate("testing") == "testing"
    assert never_match_0.validate("testing", True) == "testing"


# Generated at 2022-06-26 10:16:22.800426
# Unit test for constructor of class Not
def test_Not():
    field1 = {"type": "string"}
    field2 = {"type": "string"}
    notfield = Not(negated=field1, compare=field2)
    assert isinstance(notfield.negated, Field)
    assert isinstance(notfield.compare, Field)

# Generated at 2022-06-26 10:16:25.201865
# Unit test for constructor of class Not
def test_Not():
    # Create an object of class Not with the following parameters
    test_object = Not(negated=None)


# Generated at 2022-06-26 10:16:37.540921
# Unit test for constructor of class OneOf
def test_OneOf():
    # Assertions in constructor may be skipped
    one_of_0 = OneOf([])
    one_of_2 = OneOf([], min_length=0, max_length=0, pattern='', format='',
        allow_null=False, description='', title='', name='', item=None, 
        min_items=0, max_items=0, min_value=None, max_value=None, 
        multiple_of=None, exclusive_minimum=None, exclusive_maximum=None, 
        default=None)
    # Test with failure
    try:
        one_of_1 = OneOf(None)
        one_of_1.errors
        # Test passed
    except Exception:
        assert False
    # Test with failure

# Generated at 2022-06-26 10:16:41.114523
# Unit test for constructor of class OneOf
def test_OneOf():
    sub_items = OneOf(one_of = [])
    assert sub_items is not None


# Generated at 2022-06-26 10:16:43.282115
# Unit test for constructor of class OneOf
def test_OneOf():
    OneOf([])
    OneOf([NeverMatch()])


# Generated at 2022-06-26 10:16:48.397053
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test with optional arguments
    all_of_0 = AllOf(all_of = [])

    # Test with positional arguments
    all_of_1 = AllOf([])

    # Test with named arguments
    all_of_2 = AllOf(all_of = [])


# Generated at 2022-06-26 10:16:50.251314
# Unit test for constructor of class AllOf
def test_AllOf():
    test0 = AllOf([])


# Generated at 2022-06-26 10:16:54.761599
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String

    all_of = AllOf([String()])
    assert all_of.all_of[0].__class__.__name__ == "String"


# Generated at 2022-06-26 10:17:03.508422
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([], **{  })
    one_of_1 = OneOf([], **{  })
    one_of_2 = OneOf([], **{  })
    one_of_3 = OneOf([], **{  })
    one_of_4 = OneOf([], **{  })
    one_of_5 = OneOf([], **{  })
    one_of_6 = OneOf([], **{  })
    one_of_7 = OneOf([], **{  })
    one_of_8 = OneOf([], **{  })
    one_of_9 = OneOf([], **{  })
    one_of_10 = OneOf([], **{  })
    one_of_11 = OneOf([], **{  })

# Generated at 2022-06-26 10:17:08.090882
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        # Arrange
        all_of_0 = AllOf([])
        # Act & Assert
        assert True
    except:
        # Act & Assert
        assert False


# Generated at 2022-06-26 10:17:16.459686
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(Negated=None)

# Generated at 2022-06-26 10:17:19.682633
# Unit test for constructor of class AllOf
def test_AllOf():
    a: typing.List[Field] = []
    all_of_0 = AllOf(a)
    assert all_of_0


# Generated at 2022-06-26 10:17:33.053266
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert (
        str(never_match_0) == "<NeverMatch()>"
    ), f"expected: <NeverMatch()>, actual: {str(never_match_0)}"
    assert never_match_0.errors == {
        "never": "This never validates.",
    }, f"expected: {{'never': 'This never validates.'}}, actual: {never_match_0.errors}"
    never_match_0.name = "abc"
    assert never_match_0.name == "abc", f"expected: abc, actual: {never_match_0.name}"
    never_match_0.description = "abc"
    assert never_match_0.description == "abc", f"expected: abc, actual: {never_match_0.description}"
   

# Generated at 2022-06-26 10:17:40.388980
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_1: Field = Any()
    then_clause_2: Field = Any()
    else_clause_3: Field = Any()
    if_then_else_4 = IfThenElse(
        if_clause_1,
        then_clause_2,
        else_clause_3
    )



# Generated at 2022-06-26 10:17:51.941141
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Case 0
    # Test with zero argument
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, NeverMatch)
    # Case 1
    # Test with one argument
    try:
        never_match_1 = NeverMatch(None)
        assert False
    except TypeError as e:
        assert True
    try:
        never_match_2 = NeverMatch(1)
        assert False
    except TypeError as e:
        assert True
    never_match_3 = NeverMatch('a')
    assert isinstance(never_match_3, NeverMatch)
    try:
        never_match_4 = NeverMatch(1.0)
        assert False
    except TypeError as e:
        assert True

# Generated at 2022-06-26 10:17:56.523562
# Unit test for constructor of class Not
def test_Not():
    # Arrange
    not_0 = Not(Any())
    # Act

    # Assert
    assert isinstance(not_0, Not) is True
    assert isinstance(not_0, Field) is True


# Generated at 2022-06-26 10:18:01.906589
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(
        one_of=[Integer(), Boolean(), String()], options={}
    )
    try:
        one_of_0.validate({"test_input": 1})
    except Exception as error:
        assert error is not None

# Generated at 2022-06-26 10:18:05.415983
# Unit test for constructor of class Not
def test_Not():
    field_0 = NeverMatch()
    not_0 = Not(field_0)
    pass

# Generated at 2022-06-26 10:18:09.290826
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(
        all_of=[],
        description="All of the conditions must be met.",
        title="AllOf",
    )

# Generated at 2022-06-26 10:18:10.827057
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)


# Generated at 2022-06-26 10:18:59.224573
# Unit test for constructor of class AllOf
def test_AllOf():
    def test() -> None:
        all_of = AllOf([Field(required=True), Field(required=True)])
    test()


# Generated at 2022-06-26 10:19:01.645585
# Unit test for constructor of class AllOf
def test_AllOf():
    never_match_0 = NeverMatch()
    all_of_field_0 = AllOf(one_of=[NeverMatch()])


# Generated at 2022-06-26 10:19:08.426350
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field(allow_null=True)
    then_clause = Field(allow_null=True)
    else_clause = Field(allow_null=True)
    IfThenElse(if_clause, then_clause, else_clause)


# Generated at 2022-06-26 10:19:13.269627
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class_object = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    try:
        assert isinstance(class_object, IfThenElse)
    except AssertionError:
        raise AssertionError("AssertionError: Expected type IfThenElse")


# Generated at 2022-06-26 10:19:15.345704
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
  field = IfThenElse(field1, field2, field3)

# Generated at 2022-06-26 10:19:22.641347
# Unit test for constructor of class AllOf
def test_AllOf():
    """
    Tests that attributes of ``AllOf`` are properly set.
    """
    field = AllOf([])
    field1 = AllOf([field])
    assert field.all_of == []
    assert field1.all_of == [field]


# Generated at 2022-06-26 10:19:27.168465
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(
        all_of=[],
        default="",
        description="",
        formats="",
        title="",
    )
    assert all_of_0.all_of == []
    assert all_of_0.default == ""
    assert all_of_0.description == ""
    assert all_of_0.formats == ""
    assert all_of_0.title == ""


# Generated at 2022-06-26 10:19:29.580102
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = "if clause"
    then_clause = "then clause"
    else_clause = "else clause"
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)



# Generated at 2022-06-26 10:19:31.470358
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of =[])


# Generated at 2022-06-26 10:19:34.646673
# Unit test for constructor of class AllOf
def test_AllOf():
    print('Start to test constructor of class AllOf!')
    all_of_0 = AllOf(all_of=[NeverMatch()])=={}
    print('Test class AllOf finished!')
    print('-'*40)
