

# Generated at 2022-06-26 10:09:45.239170
# Unit test for constructor of class Not
def test_Not():
    field_0 = None
    not_0 = Not(field_0)

# Generated at 2022-06-26 10:09:53.543389
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_i_0 = None
    field_t_0 = None
    field_e_0 = None
    if_then_else_0 = IfThenElse(field_i_0, field_t_0, field_e_0)
    value_0 = None
    strict_0 = None
    result = if_then_else_0.validate(value_0, strict_0)
    assert result == None


# Generated at 2022-06-26 10:09:56.300276
# Unit test for constructor of class Not
def test_Not():
    field_0 = None
    not_0 = Not(field_0)



# Generated at 2022-06-26 10:09:56.781376
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-26 10:10:02.557879
# Unit test for method validate of class Not
def test_Not_validate():
    field_0 = None
    not_0 = Not(field_0)
    other_0 = typing.Any()
    expected_result_0 = None
    result_0 = not_0.validate(other_0)
    assert (
        result_0 is expected_result_0
    ), "Field value does not match expected result"

# Generated at 2022-06-26 10:10:05.118133
# Unit test for constructor of class Not
def test_Not():
    field_0 = NeverMatch()
    not_0 = Not(field_0)


# Generated at 2022-06-26 10:10:08.215693
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(None)
    assert not_0.errors == {"negated": "Must not match."}

# Generated at 2022-06-26 10:10:11.240851
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.errors['never'] == "This never validates."
    assert a.allow_null == False


# Generated at 2022-06-26 10:10:17.274177
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = False
    field_0 = None
    field_1 = None
    field_2 = None
    if_then_else_0 = IfThenElse(field_0, field_1, field_2)
    a = True if if_then_else_0.validate(False) else False
    assert a
    field_4 = None
    field_5 = None
    field_6 = None
    if_then_else_1 = IfThenElse(field_4, field_5, field_6)
    a = True if if_then_else_1.validate(True) else False
    assert a

# Generated at 2022-06-26 10:10:20.246815
# Unit test for constructor of class AllOf
def test_AllOf():
    field_0 = None
    all_of = AllOf(field_0)


# Generated at 2022-06-26 10:10:36.565511
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    string_0 = str()
    string_1 = str()
    string_2 = str()
    list_0 = []
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    if_then_else_1 = IfThenElse(if_clause_0)
    assert if_then_else_1.validate(string_0) is string_0
    assert if_then_else_1.validate(string_1) is string_1
    assert if_then_else_1.validate(string_2) is string_2
    if_then_else_2 = If

# Generated at 2022-06-26 10:10:46.836902
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Any()
    then_clause_0 = String()
    else_clause_0 = Boolean()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = "amet"
    strict_0 = True
    with pytest.raises(ValidationError) as excinfo:
        if_then_else_0.validate(value_0, strict_0)
    assert excinfo.value.code == "invalid"
    assert excinfo.value.fields == ["$"]
    assert excinfo.value.message == "Not a valid boolean."


# Generated at 2022-06-26 10:10:55.080693
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)

    # Test: normal case 1
    # Call the method
    # Expected result: Error
    try:
        one_of_0.validate(None)
    except BaseException as e:
        assert str(e) == "Did not match any valid type."



# Generated at 2022-06-26 10:11:02.541884
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = OneOf([])
    then_clause_0 = OneOf([])
    else_clause_0 = OneOf([])
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = True
    strict_0 = False
    try:
        if_then_else_0.validate(value_0, strict_0)
    except ValidationError as exc_0:
        message_0 = exc_0.messages
    try:
        if_then_else_0.validate(value_0, strict_0)
    except ValidationError as exc_0:
        message_0 = exc_0.messages

# Generated at 2022-06-26 10:11:07.544517
# Unit test for method validate of class Not
def test_Not_validate():
    negated = Not()
    value = None
    strict = False
    # TypeError is raised if arguments are of wrong type
    # SUT
    with pytest.raises(TypeError):
        negated.validate(value, strict)


# Generated at 2022-06-26 10:11:13.923187
# Unit test for constructor of class Not
def test_Not():
    value = None
    strict = False
    negated_ = None
    # Type code here.
    target = Not(negated_)
    # Call method on class
    result = target.validate(value, strict)


# Generated at 2022-06-26 10:11:20.003016
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    statement = "one_of_0.validate(value = value_0, strict = True)"
    try:
        assert False
        one_of_0.validate(value = value_0, strict = True)
    except:
        print("Failed: " + repr(statement))
    else:
        print("Passed: " + repr(statement))



# Generated at 2022-06-26 10:11:28.334006
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Any()
    then_clause_0 = Any()
    else_clause_0 = Any()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    # value, strict
    if_then_else_0.validate(None, True)

# Generated at 2022-06-26 10:11:31.692069
# Unit test for constructor of class AllOf
def test_AllOf():
    list_0 = []
    all_of_0 = AllOf(list_0)


# Generated at 2022-06-26 10:11:35.681055
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    with raises(ValidationError): one_of_0.validate(1)


# Generated at 2022-06-26 10:11:45.259544
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    value_0 = 1
    # ValueError raised, with message "one_of_0.validate() missing 1 required positional argument: 'strict'"
    # TypeError raised, with message "one_of_0.validate() missing 1 required positional argument: 'strict'"
    # TypeError raised, with message "one_of_0.validate() argument after * must be a sequence, not int"
    # TypeError raised, with message "one_of_0.validate() argument after * must be a sequence, not int"
    # AssertionError raised, with message "one_of_0.validate() missing 1 required positional argument: 'strict'"
    with pytest.raises(AssertionError) as exception_context:
        one

# Generated at 2022-06-26 10:11:50.109910
# Unit test for method validate of class Not
def test_Not_validate():
    value_0 = "A"
    field_1 = Not(Field())
    result_0 = field_1.validate(value_0)
    assert result_0 is None


# Generated at 2022-06-26 10:11:50.797952
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(None)

# Generated at 2022-06-26 10:11:55.497728
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    assert one_of_0.validate(1) == 1  # 1
    assert one_of_0.validate("") == ""  # ""
    assert one_of_0.validate(False) == False  # False
    assert one_of_0.validate(None) == None  # None
    assert one_of_0.validate([]) == []  # []


# Generated at 2022-06-26 10:11:56.269824
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-26 10:11:58.243232
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    expected_value = None
    obj = NeverMatch()

    actual_value = obj.errors

    assert expected_value == actual_value, "Expected {}, but got {}".format(expected_value, actual_value)
# Tests end here


# Generated at 2022-06-26 10:12:01.139488
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(Any())
    with pytest.raises(not_0.validation_error):
        not_0.validate(0)

# Generated at 2022-06-26 10:12:02.836574
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(negated = AlwaysValid())


# Generated at 2022-06-26 10:12:05.911111
# Unit test for method validate of class Not
def test_Not_validate():
    _0 = Not(negated=None)
    return str(_0)


# Generated at 2022-06-26 10:12:07.853825
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    type_0 = one_of_0.validate(None)
    assert type_0 is None, "Expected None, but got " + repr(type_0)



# Generated at 2022-06-26 10:12:13.135542
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    assert one_of_0.validate(0) == 0

# Generated at 2022-06-26 10:12:14.373583
# Unit test for method validate of class Not
def test_Not_validate():
    list_0 = []
    not_0 = Not(None, list_0)


# Generated at 2022-06-26 10:12:18.610104
# Unit test for method validate of class Not
def test_Not_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    not_0 = Not(one_of_0)
    string_0 = ""
    try:
        not_0.validate(string_0)
        assert False
    except FieldValidationError as ex:
        assert ex.code == "negated"


# Generated at 2022-06-26 10:12:21.051572
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(None)

    assert not_0.validate(None, True) is None

# Generated at 2022-06-26 10:12:24.232061
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    value_0 = one_of_0.validate(None)
    assert value_0 is None


# Generated at 2022-06-26 10:12:31.110610
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    with pytest.raises(one_of_0.validation_error):
        one_of_0.validate(None)


# Generated at 2022-06-26 10:12:33.099768
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    # FIXME; This test is pending.


# Generated at 2022-06-26 10:12:35.402115
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    one_of_0 = OneOf(list_0)


# Generated at 2022-06-26 10:12:40.074806
# Unit test for constructor of class AllOf
def test_AllOf():
    def test_case_0():
        list_0 = []
        all_of_0 = AllOf(list_0)


# Generated at 2022-06-26 10:12:41.827758
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    list_0 = []
    nev_0 = NeverMatch(one_of=list_0)



# Generated at 2022-06-26 10:12:47.569070
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    assert isinstance(one_of_0.validate_or_error(1.0)[0], float) == True


# Generated at 2022-06-26 10:12:52.009687
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test if a constructor of AllOf works properly.
    all_of_0 = AllOf([])



# Generated at 2022-06-26 10:13:00.794941
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    dict_0 = {"type": "array"}
    dict_1_list = []
    dict_1 = {"type": "array", "items": dict_1_list}
    dict_2_list = [dict_1]
    dict_2 = {"type": "array", "items": dict_2_list}
    dict_3_list = [dict_2]
    dict_3 = {"type": "array", "items": dict_3_list}
    dict_4_list = [dict_3]
    dict_4 = {"type": "array", "items": dict_4_list}
    dict_5_list = [dict_0]
    dict_5 = {"type": "array", "items": dict_5_list}
    dict_6_list = [dict_5]

# Generated at 2022-06-26 10:13:05.369520
# Unit test for constructor of class Not
def test_Not():
    try:
        negated_0 = Any()
        not_0 = Not(negated_0)
    except Exception:
        assert False



# Generated at 2022-06-26 10:13:15.525728
# Unit test for constructor of class AllOf
def test_AllOf():
    # Tests for class AllOf.
    # TODO: Test that it respects `required`.
    # TODO: Test that it respects `default`.
    # TODO: Test that it respects `allow_null`.
    # TODO: Test that it respects `description`.
    # TODO: Test that it respects `extras`.
    # TODO: Test that it respects `format`.
    # TODO: Test that it respects `title`.
    # Test that it has errors with no match.
    field_0 = AllOf([Integer()])
    data_0 = 1
    try:
        field_0.validate(data_0)
    except ValidationError as e:
        assert e.error_code == "no_match"
    
    # Test that it has errors with multiple matches.

# Generated at 2022-06-26 10:13:20.824349
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Any()]
    all_of_0 = AllOf(all_of)
    assert all_of_0.all_of == all_of


# Generated at 2022-06-26 10:13:22.706242
# Unit test for constructor of class AllOf
def test_AllOf():
    # test constructor
    all_of_0 = AllOf()


# Generated at 2022-06-26 10:13:26.134116
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)


# Generated at 2022-06-26 10:13:38.044182
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])
    assert one_of_0.superclass is None
    assert one_of_0._attribute is None
    assert one_of_0._value is None
    assert one_of_0.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert one_of_0._required is False
    assert one_of_0._readable is True
    assert one_of_0._writable is True
    assert one_of_0.one_of == []
    assert one_of_0.context is None
    assert one_of_0._default_error_messages == {"required": "This field is required."}
    assert one_of_0.name == "OneOf"
    assert one_of_0

# Generated at 2022-06-26 10:13:44.151530
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    value_0 = None
    value_1 = one_of_0.validate(value_0)
    assert value_1 is None



# Generated at 2022-06-26 10:13:50.387368
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    one_of_0 = OneOf(list_0)
    assert one_of_0.one_of is list_0


# Generated at 2022-06-26 10:14:00.486113
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    boolean_0 = True
    with pytest.raises(Exception) as ex:
        one_of_0.validate(boolean_0)
    with pytest.raises(Exception) as ex:
        one_of_0.validate(boolean_0)
    with pytest.raises(Exception) as ex:
        one_of_0.validate(boolean_0)


# Generated at 2022-06-26 10:14:06.864350
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    value_0 = one_of_0.validate(None, strict=False)
    assert value_0 == None



# Generated at 2022-06-26 10:14:12.067430
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    error = one_of_0.validate("", True)
    assert error == False
    error = one_of_0.validate("", True)
    assert error == False
    error = one_of_0.validate("", True)
    assert error == False


# Generated at 2022-06-26 10:14:18.947485
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = [Integer(minimum=3)]
    one_of_0 = OneOf(list_0)
    try:
        one_of_0.validate(3)
    except SchemaError as se:
        print(se)



# Generated at 2022-06-26 10:14:23.538104
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    assert all_of_0.validate("") is ""
    assert all_of_0.validate("", strict=True) is ""
    assert all_of_0.validate("", strict=True) is ""
    assert all_of_0.validate("", strict=False) is ""
    assert all_of_0.validate("", strict=True) is ""
    assert all_of_0.validate("", strict=False) is ""
    assert all_of_0.validate("", strict=True) is ""
    assert all_of_0.validate("", strict=False) is ""
    assert all_of_0.validate("", strict=True) is ""
    assert all_of_0.validate("", strict=False) is ""
   

# Generated at 2022-06-26 10:14:25.580013
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(None)


# Generated at 2022-06-26 10:14:36.560168
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Unit test for __init__ method of class NeverMatch
    list_0 = []
    never_match_0 = NeverMatch(list_0)
    assert(len(never_match_0.errors) == 1)
    assert(never_match_0.errors['never'] == "This never validates.")

    # Unit test for validate method of class NeverMatch
    try:
        never_match_0.validate(list_0)
    except Exception as e:
        assert(e.get_code() == 'never')
        assert(str(e) == 'This never validates.')


# Generated at 2022-06-26 10:14:41.532040
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    assert one_of_0.validate(one_of_0) == one_of_0


# Generated at 2022-06-26 10:14:46.127125
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Dummy input data for type Any
    data_0: typing.Any = None

    # Testing constructor of class NeverMatch
    never_match_0 = NeverMatch()
    # Testing method 'validate' of class NeverMatch
    assert never_match_0.validate(data_0) is None


# Generated at 2022-06-26 10:15:19.965441
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    value = 1
    strict = False
    assert one_of_0.validate(value, strict) == 1


# Generated at 2022-06-26 10:15:23.542924
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    # assert one_of_0.validate(None, True) == None


# Generated at 2022-06-26 10:15:26.431720
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(None)
    assert not_0.negated is None

# Generated at 2022-06-26 10:15:31.305954
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    value_0 = one_of_0.validate()
    assert value_0 is None


# Generated at 2022-06-26 10:15:36.599365
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    try:
        one_of_0.validate(123)
        assert False
    except ValueError as e:
        assert str(e) == '''ValidationError at /
    no_match: Did not match any valid type.
    value: 123'''


# Generated at 2022-06-26 10:15:48.885754
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    strict_1 = False
    try:
        one_of_0.validate(None, strict=strict_1)
        assert False
    except FieldValidationError as e:
        assert e.code == "no_match"
        assert e.field == one_of_0
        assert e.value is None
    strict_2 = True
    try:
        one_of_0.validate(None, strict=strict_2)
        assert False
    except FieldValidationError as e:
        assert e.code == "no_match"
        assert e.field == one_of_0
        assert e.value is None
    strict_2 = True

# Generated at 2022-06-26 10:15:51.634329
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    FieldTests.validation_test(one_of_0, "")


# Generated at 2022-06-26 10:15:58.453806
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field(name = "if_clause")
    then_clause = Field(name = "then_clause")
    else_clause = Field(name = "else_clause")
    IfThenElse(if_clause,then_clause,else_clause)
    # assert IfThenElse(if_clause,then_clause,else_clause) == IfThenElse(if_clause,then_clause,else_clause)


# Generated at 2022-06-26 10:16:08.421734
# Unit test for constructor of class Not
def test_Not():
    negated_0 = None
    not_0 = Not(negated_0)
    negated_1 = OneOf(list())
    field_id_0 = "ifThenElse"
    if_clause_0 = Constant(True, field_id=field_id_0)
    field_id_1 = "ifThenElse"
    then_clause_0 = Constant(True, field_id=field_id_1)
    field_id_2 = "ifThenElse"
    else_clause_0 = Constant(True, field_id=field_id_2)
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    not_1 = Not(if_then_else_0)
    negated_2 = One

# Generated at 2022-06-26 10:16:13.462076
# Unit test for constructor of class Not
def test_Not():
    negated_0 = Field()
    not_0 = Not(negated_0)
    negated_1 = Field()
    not_1 = Not(negated_1)


# Generated at 2022-06-26 10:16:32.757886
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    val_0 = OneOf(object())
    val_1 = AllOf(object())
    val_2 = Not(object())

# Generated at 2022-06-26 10:16:38.879722
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)

    # Call
    with pytest.raises(ValidationError) as exception_info:
        one_of_0.validate(True)

    assert exception_info.value.message == 'Expected type {}, got {} for value `{}`.'.format(one_of_0.__class__.__name__, 'bool', True)


# Generated at 2022-06-26 10:16:48.973018
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
  if_clause = Field()
  then_clause = Field()
  else_clause = Field()
  obj = IfThenElse(if_clause, then_clause, else_clause)
  obj = IfThenElse(if_clause=if_clause)
  obj = IfThenElse(if_clause=if_clause, then_clause=then_clause)
  obj = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)


# Generated at 2022-06-26 10:16:51.844385
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    one_of_0 = OneOf(list_0)


# Generated at 2022-06-26 10:16:53.946964
# Unit test for constructor of class OneOf
def test_OneOf():
    obj = OneOf([])
    assert obj.one_of == []



# Generated at 2022-06-26 10:17:00.223403
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create the instance
    value = {'index': 'int', 'type': 'string'}
    one_of_0 = OneOf(value)

    # Method to test
    assert one_of_0.validate(value) == {'index': 'int', 'type': 'string'}



# Generated at 2022-06-26 10:17:07.787980
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    value_0 = one_of_0.validate(None, True)
    value_1 = one_of_0.validate(None, False)
    value_2 = one_of_0.validate(123, False)
    value_3 = one_of_0.validate("", False)



# Generated at 2022-06-26 10:17:12.944359
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    value_0 = None
    strict_0 = True
    with pytest.raises(ValidationError) as error:
        one_of_0.validate(value_0, strict_0)
    assert error.value.error_type == 'no_match'
    assert error.value.value is None
    assert error.value.field == one_of_0
    assert error.value.context == {}
    assert error.value.data == {}


# Generated at 2022-06-26 10:17:15.526834
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(list())
    boolean_0 = False
    try:
        one_of_0.validate(boolean_0)
        raise Exception("Expected assertion error")
    except AssertionError as e:
        assert str(e) == "No match"


# Generated at 2022-06-26 10:17:18.521659
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    one_of_0 = OneOf(list_0)


# Generated at 2022-06-26 10:18:00.308847
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    field_0 = OneOf(list_0)
    value_0 = field_0.validate(None)  # expected to fail
    value_1 = field_0.validate([])  # expected to fail
    value_2 = field_0.validate({})  # expected to fail
    value_3 = field_0.validate("")  # expected to fail
    value_4 = field_0.validate(0)  # expected to fail
    value_5 = field_0.validate(0.0)  # expected to fail
    value_6 = field_0.validate(Float(None))  # expected to fail
    value_7 = field_0.validate(AllOf(list_0))  # expected to fail

# Generated at 2022-06-26 10:18:05.777189
# Unit test for constructor of class Not
def test_Not():
    list_0 = []
    one_of_0 = OneOf(list_0)
    negated_0 = one_of_0
    not_0 = Not(negated_0)
    assert not_0 is not None


# Generated at 2022-06-26 10:18:18.514156
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_0 = OneOf([string_0])
    field_0.validate(0.7200254343623889, False)
    field_0.validate(0.7200254343623889, False)
    field_0.validate(0.7200254343623889, False)
    field_0.validate(0.7200254343623889, False)
    field_0.validate(0.7200254343623889, False)
    field_0.validate(0.7200254343623889, False)
    field_0.validate(0.7200254343623889, False)
    field_0.validate(0.7200254343623889, False)


# Generated at 2022-06-26 10:18:20.295624
# Unit test for constructor of class Not
def test_Not():
    one_of_0 = OneOf(list_0)
    not_0 = Not(one_of_0)

# Generated at 2022-06-26 10:18:27.679151
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_1 = OneOf([], description=None, name=None)
    value_1 = False
    strict_1 = True
    with pytest.raises(ValidationError):
        one_of_1.validate(value_1, strict_1)
    value_2 = None
    strict_2 = True
    with pytest.raises(ValidationError):
        one_of_1.validate(value_2, strict_2)



# Generated at 2022-06-26 10:18:31.868357
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    one_of_0.validate("Fq;")


# Generated at 2022-06-26 10:18:35.618805
# Unit test for constructor of class OneOf
def test_OneOf():
    data = [1, 2, 3, 4, 5]
    testCase = OneOf(data)
    assert testCase.one_of == data


# Generated at 2022-06-26 10:18:38.150213
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    value_0 = one_of_0.validate(value_0)


# Generated at 2022-06-26 10:18:51.182992
# Unit test for constructor of class OneOf

# Generated at 2022-06-26 10:18:59.535046
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    str_0: str = "The quick brown fox jumps over the lazy dog."
    str_1: str = "The quick brown fox jumps over the lazy dog."
    one_of_0.validate(str_1)


if __name__ == "__main__":
    test_case_0()