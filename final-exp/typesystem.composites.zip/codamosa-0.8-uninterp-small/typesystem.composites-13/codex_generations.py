

# Generated at 2022-06-26 10:09:40.195801
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(never_match_0)



# Generated at 2022-06-26 10:09:44.483319
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(
        one_of = [
            Boolean,
            Integer,
        ],
    )

    one_of_0.validate(True)
    one_of_0.validate(False)
    one_of_0.validate(0)
    try:
        one_of_0.validate("True")
    except ValidationError:
        pass
    try:
        one_of_0.validate(2)
    except ValidationError:
        pass


# Generated at 2022-06-26 10:09:47.844183
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()

    not_0 = Not(negated=never_match_0)




# Generated at 2022-06-26 10:09:51.406270
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # We can't write tests for this as it doesn't actually validate *anything*
    pass


# Generated at 2022-06-26 10:09:53.226220
# Unit test for constructor of class Not
def test_Not():
    assert Not()


# Generated at 2022-06-26 10:09:56.300776
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Field()).validate(0)


# Generated at 2022-06-26 10:09:58.877084
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(None)
    assert not_0.validate(True, True) == True


# Generated at 2022-06-26 10:10:02.892858
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    objects = [Field, String.Field, String.Field]
    data = "test"
    expectations = []
    output = Field.validate(objects, data, strict=True)


# Generated at 2022-06-26 10:10:11.240974
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_list = [Any()]
    one_of_0 = OneOf(field_list)
    value = None
    strict = False
    try:
        one_of_0.validate(value, strict)
    except Exception as e:
        print(e)
        return False
    return True

test_case_1 = test_OneOf_validate()


# Generated at 2022-06-26 10:10:13.752341
# Unit test for constructor of class OneOf
def test_OneOf():
    AllOfField1 = AllOf([int, float])
    OneOfField0 = OneOf([AllOfField1])


# Generated at 2022-06-26 10:10:27.394657
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    obj = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    if_clause_1 = NeverMatch()
    then_clause_1 = NeverMatch()
    else_clause_1 = NeverMatch()
    obj = IfThenElse(if_clause_1, then_clause_1, else_clause_1)
    strict_0 = False
    value_0 = 42
    try:
        obj.validate(value_0, strict_0)
        assert False
    except FieldValidationError as e:
        assert e.code == "never"
    assert False


# Generated at 2022-06-26 10:10:35.117092
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case where value is not None
    arg = Not(negated=Any())
    value = typing.Any()
    expected = value
    result = arg.validate(value)
    assert expected == result

    # Test case where value is None
    arg = Not(negated=Any())
    value = None
    expected = None
    result = arg.validate(value)
    assert expected == result


# Generated at 2022-06-26 10:10:36.897469
# Unit test for method validate of class Not
def test_Not_validate():
    # TODO
    pass

# Generated at 2022-06-26 10:10:37.794625
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-26 10:10:39.240030
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    I = IfThenElse(if_clause=None, then_clause=None, else_clause=None)


# Generated at 2022-06-26 10:10:43.573420
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=NeverMatch(),
        then_clause=NeverMatch(),
        else_clause=NeverMatch()
    )
    field.validate(None)

# Generated at 2022-06-26 10:10:48.064902
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()

    negated_0 = Not(negated=never_match_0)

# Generated at 2022-06-26 10:10:51.936807
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(negated=never_match_0)
    not_0.validate(True)



# Generated at 2022-06-26 10:10:59.564452
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(never_match_0)
    try:
        assert never_match_0.validate(1) is None
    except Not.validation_error :
        pass
    # TypeError: int() argument must be a string, a bytes-like object or a number, not 'NoneType'
    try:
        assert not_0.validate(1) is None
    except Not.validation_error :
        pass
    # TypeError: int() argument must be a string, a bytes-like object or a number, not 'NoneType'

# Generated at 2022-06-26 10:11:11.051886
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Array, Boolean, Integer, Number, Object, String
    from typesystem import Format, Length, Maximum, Minimum, Pattern, Range
    from typesystem import ValidationError

    array = Array(items=Integer())
    one_of = OneOf([Integer(), String(format="email")])
    all_of = AllOf([Number(), Maximum(value=8)])

    # Test for field items
    integer_0 = Integer()
    array_0_0 = Array(items=integer_0)
    array_0_1 = Array(items=integer_0)
    array_0_2 = Array(items=integer_0)
    array_0_3 = Array(items=integer_0)
    array_0_4 = Array(items=integer_0)
    array_0_5 = Array(items=integer_0)

# Generated at 2022-06-26 10:11:18.634087
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Create a mock object
    mock = MagicMock()

    # Create a IfThenElse object
    if_then_else_object = IfThenElse(mock)

    # Call method
    if_then_else_object.validate("value")


# Generated at 2022-06-26 10:11:19.423001
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert True
    # TODO implement your test here

# Generated at 2022-06-26 10:11:22.029131
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    obj = IfThenElse(if_clause, then_clause, else_clause)

    with pytest.raises(ValidationError) as info:
        obj.validate(10)

# Generated at 2022-06-26 10:11:28.528795
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_1 = NeverMatch(name="always_error_no_default")
    assert never_match_1.name == "always_error_no_default"
    assert never_match_1._errors == {"never": "This never validates."}
    assert never_match_1._default is None
    assert never_match_1._required is False


# Generated at 2022-06-26 10:11:34.068622
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([None])
    all_of_1 = AllOf([None, None])
    assert not (all_of_0 is not None)
    assert not (all_of_1 is not None)


# Generated at 2022-06-26 10:11:39.090656
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None
    then_clause = None
    else_clause = None

    try:
        IfThenElse(if_clause, then_clause, else_clause)
    except AssertionError:
        pass


# Generated at 2022-06-26 10:11:40.833817
# Unit test for constructor of class AllOf
def test_AllOf():
    # In the following line, the exception should be ignored
    all_of = AllOf(all_of=[])


# Generated at 2022-06-26 10:11:41.879600
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), NeverMatch)


# Generated at 2022-06-26 10:11:54.404154
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    all_of_0 = AllOf(
        [
            Nested(
                {
                    "status": String(),
                    "celebs": Array(of=Nested({"name": String(), "age": Integer()})),
                }
            ),
            Nested({"status": String()}),
        ]
    )


# Generated at 2022-06-26 10:11:56.241823
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Case 0
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}



# Generated at 2022-06-26 10:12:02.580409
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    if_then_else_instance = IfThenElse(if_clause=if_clause_0, else_clause=else_clause_0)
    value = 0
    if_then_else_instance.validate(value=value)


# Generated at 2022-06-26 10:12:05.692884
# Unit test for constructor of class Not
def test_Not():
    negated = NeverMatch()
    Not(negated)


# Generated at 2022-06-26 10:12:12.380148
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = Field()
    instance = IfThenElse(if_clause, then_clause, else_clause)
    value = None
    strict = True

    with pytest.raises(ValidationError):
        instance.validate(value, strict)

# Generated at 2022-06-26 10:12:20.915016
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Assemble
    if_clause_0 = IfThenElse(String(max_length=10), String(max_length=10))
    value_0 = "123"

    # Act
    ret = if_clause_0.validate(value_0)

    # Assert
    assert ret == "123"



# Generated at 2022-06-26 10:12:31.207865
# Unit test for constructor of class NeverMatch
def test_NeverMatch(): 
    never_match_0 = NeverMatch()
    # check if the field name is correct
    assert never_match_0.field_name == "NeverMatch"
    # check if the field type is correct
    assert never_match_0.field_type == "NeverMatch"
    # check if the error message is correct
    assert never_match_0.errors["never"] == 'This never validates.'
    # check if the default is correct
    assert never_match_0.default == undefined
    # check if the error is correct
    try:
        never_match_0.validate(None)
    except ValidationError as err:
        assert err.message == 'This never validates.'
        assert err.code == 'never'
        assert err.field_name == 'NeverMatch'

# Generated at 2022-06-26 10:12:39.890885
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = NeverMatch()
    then_clause = NeverMatch()

    result_0 = IfThenElse(None, None, None)
    result_1 = IfThenElse(None, None, None)
    result_2 = IfThenElse(None, None, None)
    result_3 = IfThenElse(None, then_clause, None)
    result_4 = IfThenElse(None, None, None)
    result_5 = IfThenElse(if_clause, then_clause, None)
    result_6 = IfThenElse(if_clause, then_clause, None)
    result_7 = IfThenElse(if_clause, then_clause, None)
    result_8 = IfThenElse(if_clause, then_clause, then_clause)

# Generated at 2022-06-26 10:12:41.057274
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])


# Generated at 2022-06-26 10:12:43.710449
# Unit test for constructor of class Not
def test_Not():
    field = Field()
    negated = Field()
    not_ = Not(negated)


# Generated at 2022-06-26 10:12:48.958399
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])


# Generated at 2022-06-26 10:12:53.582145
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Boolean, String

    if_then_else_0 = IfThenElse(
        if_clause=Boolean(), else_clause=Boolean(), then_clause=Boolean()
    )

    # Pass
    if_then_else_0.validate(value=True)

    # Fail
    try:
        if_then_else_0.validate(value=0)
    except Exception as e:
        assert e.message == "{'__all__': ['Must be valid boolean.']}"


# Generated at 2022-06-26 10:12:58.044913
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    allof_0 = AllOf([])
    ifthenelse_0 = IfThenElse(allof_0)
    ifthenelse_0.validate(2)



# Generated at 2022-06-26 10:13:08.414535
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])

    # Test valid values
    try:
        all_of_0.validate(0)
        print("Test 1 of class AllOf passed.")
    except:
        print("Test 1 of class AllOf failed.")

    try:
        all_of_0.validate(True)
        print("Test 2 of class AllOf passed.")
    except:
        print("Test 2 of class AllOf failed.")

    try:
        all_of_0.validate("")
        print("Test 3 of class AllOf passed.")
    except:
        print("Test 3 of class AllOf failed.")


# Generated at 2022-06-26 10:13:14.643716
# Unit test for constructor of class OneOf
def test_OneOf():
    child_list = []
    child_list.append(NeverMatch())
    child_list.append(NeverMatch())
    child_list.append(NeverMatch())
    OneOf(child_list)
    one_of_0 = OneOf(child_list)


# Generated at 2022-06-26 10:13:15.972282
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])


# Generated at 2022-06-26 10:13:17.402761
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([])


# Generated at 2022-06-26 10:13:24.228009
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    obj = IfThenElse(if_clause, then_clause, else_clause)
    result = obj.validate(None)
    assert result is None
    assert obj.errors == {}
    assert obj.histogram == 1
    assert obj.valid_values == {None}
    assert obj.invalid_values == set()


# Generated at 2022-06-26 10:13:25.809225
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert False


# Generated at 2022-06-26 10:13:27.687127
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test without parameters
    test_case_0()



# Generated at 2022-06-26 10:13:30.121400
# Unit test for constructor of class OneOf
def test_OneOf():
    # TODO - Write a unit test
    pass


# Generated at 2022-06-26 10:13:32.736669
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:13:36.714790
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Invalid: Test if scalar constructor is never called with any missing parameter
    never_match_0 = NeverMatch()



# Generated at 2022-06-26 10:13:38.947682
# Unit test for constructor of class OneOf
def test_OneOf():
    list_field_0 = [Any()]
    one_of_0 = OneOf(list_field_0)

# Generated at 2022-06-26 10:13:49.111121
# Unit test for constructor of class Not
def test_Not():
    int_field = Integer(min_value=1000, max_value=15000)
    simple_string_field = Char(max_length=2)
    not_int_string_field = Not(negated=int_field)

    # false
    assert not_int_string_field.validate(10)

    # false
    assert not_int_string_field.validate("aa")

    # true
    assert not not_int_string_field.validate("aaa")


# Generated at 2022-06-26 10:13:51.718399
# Unit test for constructor of class OneOf

# Generated at 2022-06-26 10:13:56.656866
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None
    then_clause = None
    else_clause = None
    ifthenelse = IfThenElse(if_clause, then_clause, else_clause)


# Generated at 2022-06-26 10:14:04.059474
# Unit test for constructor of class AllOf
def test_AllOf():
    # Case 1
    all_of_1 = AllOf(all_of=[])

    # Case 2
    all_of_2 = AllOf(all_of=[], description="description")

    # Case 3
    all_of_3 = AllOf(all_of=[], **{"description": "description"})

    # Case 4
    all_of_4 = AllOf(all_of=[], description="description", **{"description": "description"})

    # Case 5
    all_of_5 = AllOf(all_of=[], **{"description": "description"}, **{"description": "description"})

    # Case 6
    exception_6 = False
    try:
        AllOf(all_of=None)
    except Exception:
        exception_6 = True
    assert exception_6

    # Case 7

# Generated at 2022-06-26 10:14:06.193161
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([Any(), Any()])


# Generated at 2022-06-26 10:14:07.666147
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch.__init__


# Generated at 2022-06-26 10:14:10.729334
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {'never': 'This never validates.'}

# Generated at 2022-06-26 10:14:13.980884
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(
        all_of=[NeverMatch()]
    )


# Generated at 2022-06-26 10:14:19.506648
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()

# Unit tests for class OneOf

# Generated at 2022-06-26 10:14:22.828417
# Unit test for constructor of class OneOf
def test_OneOf():
    with pytest.raises(AssertionError):
        one_of_0 = OneOf(one_of=[never_match_0])


# Generated at 2022-06-26 10:14:25.429384
# Unit test for constructor of class Not
def test_Not():
    assert isinstance(Not(subfield=int), Not)


# Generated at 2022-06-26 10:14:28.166801
# Unit test for constructor of class Not
def test_Not():
    test_negated = Not()
    assert test_negated.negated == None



# Generated at 2022-06-26 10:14:29.930408
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem import Schema

    schema = Schema(NeverMatch())
    assert schema.validate({}) == {"__errors__": {"__root__": ["This never validates."]}}



# Generated at 2022-06-26 10:14:40.699024
# Unit test for constructor of class AllOf
def test_AllOf():
    one_of_0 = OneOf([Integer(cast_on_load=True)], required=False)
    all_of_0 = AllOf([one_of_0], required=False)
    never_match_1 = NeverMatch()

# Generated at 2022-06-26 10:14:48.882873
# Unit test for constructor of class AllOf
def test_AllOf():
    # test 1: check if the output is an object of type AllOf and the schema 
    # matches the schema of the description
    field = AllOf([Any()])
    assert isinstance(field, Field)
    assert field.schema() == {"allOf": [{"type": "any"}]}
    # test 2: check if the output is an object of type AllOf and the schema 
    # matches the schema of the description
    field = AllOf([Any(), Any()])
    assert isinstance(field, Field)
    assert field.schema() == {"allOf": [{"type": "any"}, {"type": "any"}]}
    # test 3: check the error if the input argument is an empty list 
    # and the schema matches the schema of the description
    field = AllOf([])
    assert isinstance(field, Field)
   

# Generated at 2022-06-26 10:14:54.774989
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem.fields import NeverMatch
    never_match_0 = NeverMatch()
    # NeverMatch should be NeverMatch
    assert isinstance(never_match_0, NeverMatch)
    # NeverMatch should be a subclass of Field
    assert issubclass(NeverMatch, Field)



# Generated at 2022-06-26 10:14:55.636730
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print('Construction of class NeverMatch')
    test_case_0()


# Generated at 2022-06-26 10:14:57.013833
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True



# Generated at 2022-06-26 10:15:16.874433
# Unit test for constructor of class OneOf
def test_OneOf():
    d = [NeverMatch()]
    a = OneOf(d)


# Generated at 2022-06-26 10:15:21.050532
# Unit test for constructor of class AllOf
def test_AllOf():
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, NeverMatch)
    # Return type annotation

# Generated at 2022-06-26 10:15:22.540690
# Unit test for constructor of class OneOf
def test_OneOf():
    value = [Any(), Any()]
    one_of = OneOf(value)


# Generated at 2022-06-26 10:15:25.998295
# Unit test for constructor of class Not
def test_Not():
    # Case 0
    negated_0 = AllOf([Any()])
    never_match_0 = Not(negated=negated_0)


# Generated at 2022-06-26 10:15:30.374445
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Integer
    field = Not(Integer())


# Generated at 2022-06-26 10:15:33.815855
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[])
    field_0 = one_of_0.one_of


# Generated at 2022-06-26 10:15:36.579538
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([Integer(), Number()])
    assert one_of.validate(1) == 1



# Generated at 2022-06-26 10:15:41.445157
# Unit test for constructor of class OneOf
def test_OneOf():
    # Input: (one_of: List[Field])
    one_of_0 = OneOf(one_of=[NeverMatch(), NeverMatch()])

# Generated at 2022-06-26 10:15:46.395636
# Unit test for constructor of class Not
def test_Not():
    assert True
    class Dummy:
        pass
    dummy = Dummy()
    dummy.negated = Dummy()
    test_field = Not(dummy)
    assert (test_field.negated == dummy)
    assert (test_field.allow_null == False)

# Generated at 2022-06-26 10:15:47.698258
# Unit test for constructor of class OneOf
def test_OneOf():
    m = AllOf(all_of=[])


# Generated at 2022-06-26 10:16:01.706932
# Unit test for constructor of class OneOf
def test_OneOf():
  one_of_0 = OneOf(one_of=[])


# Generated at 2022-06-26 10:16:03.806669
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of=[])


# Generated at 2022-06-26 10:16:05.462461
# Unit test for constructor of class OneOf
def test_OneOf():
    print('test_OneOf')


# Generated at 2022-06-26 10:16:09.464137
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([Any(), Any()])
    one_of_1 = OneOf([Any(), Any()], description="foo")


# Generated at 2022-06-26 10:16:12.398018
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = [NeverMatch(), NeverMatch()]
    field = OneOf(one_of)



# Generated at 2022-06-26 10:16:15.778621
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_field_0 = OneOf([never_match_0])
    assert one_of_field_0.one_of == [never_match_0]


# Generated at 2022-06-26 10:16:20.109232
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_list_0: typing.List[typesystem.Field] = [Field(format="date-time")]
    all_of_0 = AllOf(all_of=all_of_list_0)


# Generated at 2022-06-26 10:16:23.666930
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of = [])


# Generated at 2022-06-26 10:16:25.676417
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])
    assert one_of_0.one_of == []


# Generated at 2022-06-26 10:16:29.400528
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test initialization of an object of class OneOf
    one_of_0 = OneOf([None, None, None])


# Generated at 2022-06-26 10:16:56.777783
# Unit test for constructor of class Not
def test_Not():
  field = NeverMatch()
  negated = Not(field)

# Generated at 2022-06-26 10:16:58.288812
# Unit test for constructor of class Not
def test_Not():
    assert issubclass(Not, Field)
    assert isinstance(Not, type)


# Generated at 2022-06-26 10:17:04.064684
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    # Try to construct an instance of Not by passing a valid value to
    # the first argument.
    try:
        Not(never_match_0)
    except Exception:
        assert False


# Generated at 2022-06-26 10:17:07.405839
# Unit test for constructor of class Not
def test_Not():
    field = Field()
    never_match_0 = NeverMatch()
    not_0 = Not(negated=never_match_0)


# Generated at 2022-06-26 10:17:19.166381
# Unit test for constructor of class Not
def test_Not():
    # Try to create an object of type Not with a bad type for field negated
    with pytest.raises(TypeError) as excinfo:
        never_match_0 = Not(negated=None)
    # Verify that the type of the raised error is TypeError
    assert isinstance(excinfo.value, TypeError)

    # Try to create an object of type Not with a bad type for field allow_null
    with pytest.raises(TypeError) as excinfo:
        never_match_1 = Not(negated=NeverMatch(), allow_null=None)
    # Verify that the type of the raised error is TypeError
    assert isinstance(excinfo.value, TypeError)

    # Try to create an object of type Not with a bad type for field label

# Generated at 2022-06-26 10:17:20.896434
# Unit test for constructor of class Not
def test_Not():
    Not(Any())


# Generated at 2022-06-26 10:17:23.188094
# Unit test for constructor of class Not
def test_Not():
    field = Field()
    case = Not(field)


# Generated at 2022-06-26 10:17:27.326513
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError) as e:
        not_0 = Not(NeverMatch())


# Generated at 2022-06-26 10:17:29.521028
# Unit test for constructor of class Not
def test_Not():
    assert Not(Field, name="test", description="test") != None


# Generated at 2022-06-26 10:17:35.359746
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    # verified
    not_0=Not(negated=never_match_0)
    #verified

# Generated at 2022-06-26 10:18:24.632241
# Unit test for constructor of class Not
def test_Not():
  field = Not(negated=Any())
  assert field


# Generated at 2022-06-26 10:18:27.546330
# Unit test for constructor of class Not
def test_Not():
    not_0 = Not(Anything())


# Generated at 2022-06-26 10:18:40.054706
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    never_match_2 = NeverMatch()
    never_match_3 = NeverMatch()
    never_match_4 = NeverMatch()
    never_match_5 = NeverMatch()
    never_match_6 = NeverMatch()
    never_match_7 = NeverMatch()
    never_match_8 = NeverMatch()
    never_match_9 = NeverMatch()
    not1 = Not(negated=never_match_0)
    not2 = Not(negated=never_match_1, metadata=None)
    not3 = Not(negated=never_match_2, name="")
    not4 = Not(negated=never_match_3, description="")

# Generated at 2022-06-26 10:18:42.072144
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    test_0 = Not(negated=never_match_0)


# Generated at 2022-06-26 10:18:47.375957
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    test_not_0 = Not(negated=never_match_1)
    test_not_0.validate("value")


# Generated at 2022-06-26 10:18:50.229520
# Unit test for constructor of class Not
def test_Not():
    assert Not.__doc__ is not None
    assert Not.__init__.__doc__ is not None


# Generated at 2022-06-26 10:18:52.718467
# Unit test for constructor of class Not
def test_Not():
    negated_0 = AllOf()
    # Type hinting is not yet supported.
    # not_0 = Not(negated=negated_0)
    not_0 = Not(negated=negated_0)

# Generated at 2022-06-26 10:18:56.044436
# Unit test for constructor of class Not
def test_Not():
    with raises(AssertionError):
        not_0 = Not(None)


# Generated at 2022-06-26 10:18:59.613774
# Unit test for constructor of class Not
def test_Not():
    assert issubclass(Not, Field)
    negated: Field = NeverMatch()
    Not(negated)


# Generated at 2022-06-26 10:19:02.612367
# Unit test for constructor of class Not
def test_Not():
    # Test parameters
    negated = None

    # Test exceptions
    try:
        Not(negated)
    except Exception as e:
        assert type(e) == AssertionError

    # Test fields

