

# Generated at 2022-06-26 10:09:42.092847
# Unit test for method validate of class Not
def test_Not_validate():
    try:
        never_match_0 = NeverMatch()
        empty_validate_1 = never_match_0.validate(3)
        assert False, "Expected exception"
    except:
        pass


# Generated at 2022-06-26 10:09:49.606089
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=NeverMatch())
    x = not_0.validate("test")
    assert x == 'test'
    try:
        x = not_0.validate(None)
    except ValidationError as e:
        assert str(e) == "{'errors': ['Must not match.']}"


# Generated at 2022-06-26 10:09:53.083819
# Unit test for constructor of class AllOf
def test_AllOf():
    never_match_0 = NeverMatch()
    all_of_0 = AllOf([never_match_0])


# Generated at 2022-06-26 10:10:02.144463
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Case 0
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    field = IfThenElse(if_clause, then_clause, else_clause)
    # TODO: Make sure this is truly the expected behavior, then remove these lines.
    # field.errors = ()
    value = None
    strict = False
    assert field.validate(value, strict) is None

# Generated at 2022-06-26 10:10:03.851170
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([Bool()])


# Generated at 2022-06-26 10:10:06.727795
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-26 10:10:15.360179
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Validating an instance of class NeverMatch against the constraints of
    # an instance of class OneOf should produce a validation error
    # if the instance of class NeverMatch is a valid value for the constraints
    # of an instance of class OneOf.
    never_match_0 = NeverMatch()
    clause_0 = never_match_0
    one_of_0 = OneOf(clause_0)
    try:
        one_of_0.validate(never_match_0)
        assert False, 'Exception not raised'
    except Exception as e:
        assert str(e) == 'Validation error: {\'never\': \'This never validates.\'}'
    # Validating an instance of class NeverMatch against the constraints of
    # an instance of class AllOf should produce a validation error
    # if the instance of class NeverMatch is

# Generated at 2022-06-26 10:10:25.425270
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    if_clause_0 = never_match_0
    then_clause_0 = never_match_1
    else_clause_0 = never_match_1
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = __random__()
    try:
        if_then_else_0.validate__(value_0)
    except RuntimeError as e:
        pass


# Generated at 2022-06-26 10:10:27.747884
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:10:34.742340
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=NeverMatch())
    assert not_0.validate("hi") == "hi"
    with pytest.raises(Exception):
        not_0.validate("hi", strict=False)
    with pytest.raises(Exception):
        not_0.validate("hi", strict=True)



# Generated at 2022-06-26 10:10:42.891771
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    x = IfThenElse(if_clause, then_clause, else_clause)
    x.validate(None)

# Generated at 2022-06-26 10:10:48.754695
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    never_match_0 = NeverMatch()
    test_field_any_0 = Any()
    one_of_0 = OneOf(subfields=[never_match_0, test_field_any_0])
    with pytest.raises(ValidationError) as exc_info:
        one_of_0.validate(value={})
    error = exc_info.value
    assert error.code == "no_match"
    assert error.path == ""
    assert not error.context
    with pytest.raises(ValidationError) as exc_info:
        one_of_0.validate(value={"id": "test_str"})
    error = exc_info.value
    assert error.code == "multiple_matches"
    assert error.path == ""
    assert not error.context


# Unit

# Generated at 2022-06-26 10:10:59.485706
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert hasattr(never_match_0, 'errors')
    # Unit test for instance variable errors of class NeverMatch
    assert never_match_0.errors == {'never': 'This never validates.'}
    # Unit test for instance variable description of class NeverMatch
    assert never_match_0.description == ''
    # Unit test for instance variable name of class NeverMatch
    assert never_match_0.name == ''
    assert never_match_0.type_name == 'never_match'
    assert never_match_0.required == True
    assert never_match_0.allow_coerce == False
    assert never_match_0.allow_null == False
    assert never_match_0.allow_empty == False


# Generated at 2022-06-26 10:11:08.072009
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    field = IfThenElse(if_clause, then_clause, else_clause)
    value = None
    assert field.validate(value) is None
    value = None
    strict = None
    assert field.validate(value, strict) is None


# Generated at 2022-06-26 10:11:13.427430
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_1 = NeverMatch()
    not_field_0 = Not(never_match_1)
    assert not_field_0.validate(1) == 1


# Generated at 2022-06-26 10:11:19.247257
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_parameters = [
        IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    ]
    for tester in test_parameters:
        result = tester.validate(0)
        assert result == None


# Generated at 2022-06-26 10:11:22.692528
# Unit test for constructor of class Not
def test_Not():
    negated = Field()
    unit = Not(negated)


# Generated at 2022-06-26 10:11:31.306833
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = IfThenElse()
    value_0 = None
    strict_0 = True
    strict_1 = True
    try:
        if_clause_0.validate(value_0, strict_0)
    except Exception as e:
        assert type(e) == if_clause_0.validation_error
        assert str(e) == "This field is required."
    else:
        assert False, "Expected exception of type %s" % str(if_clause_0.validation_error)


# Generated at 2022-06-26 10:11:34.994643
# Unit test for method validate of class Not
def test_Not_validate():
    negated = None
    not_ = Not(negated)
    value = None
    strict = None
    test_value = not_.validate(value, strict)
    assert test_value is None


# Generated at 2022-06-26 10:11:40.790114
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None # type: Field
    then_clause = None # type: Field
    else_clause = None # type: Field
    kwargs = {} # type: typing.Any
    test_case = IfThenElse(if_clause, then_clause, else_clause, **kwargs)


test_case_0()

# Generated at 2022-06-26 10:11:48.666277
# Unit test for method validate of class Not
def test_Not_validate():
    field_0 = Not(
        negated=Any()
    )
    print(field_0.validate(value="", strict=True))


# Generated at 2022-06-26 10:11:51.297994
# Unit test for method validate of class Not
def test_Not_validate():
    not_instance = Not(AllOf([never_match_0]))
    assert not_instance.validate(1)

# Generated at 2022-06-26 10:11:54.161145
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=NeverMatch())
    not_0.validate(value=None)

# Generated at 2022-06-26 10:11:58.216463
# Unit test for method validate of class Not
def test_Not_validate():
    _0 = NeverMatch()
    _1 = Not(_0)

    # Testing error case: negated
    with raises(ValidationError) as error:
        _1.validate(
            123,
            strict=False
        )
    exc = error.value
    assert isinstance(exc, ValidationError)
    assert exc.detail == ({'negated': 'Must not match.'},)
    assert exc.field_name == None
    assert exc.field_index == None



# Generated at 2022-06-26 10:12:01.411224
# Unit test for constructor of class OneOf
def test_OneOf():
    test_OneOf_0 = OneOf([NeverMatch()])
    test_OneOf_1 = OneOf([NeverMatch()], meta={"key": "value"})


# Generated at 2022-06-26 10:12:11.696390
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    oneOf_0 = OneOf([NeverMatch(), NeverMatch(), NeverMatch()])
    # ValueError if more than 1 validation test is successful
    try:
        oneOf_0.validate(1)
    except ValueError:
        pass
    oneOf_1 = OneOf([NeverMatch(), NeverMatch(), NeverMatch()])
    # ValueError if no validation test is successful
    try:
        oneOf_1.validate(2)
    except ValueError:
        pass


# Generated at 2022-06-26 10:12:13.360736
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    valid_0 = None
    test_0 = OneOf([Field(type=str)])
    test_0.validate(valid_0)



# Generated at 2022-06-26 10:12:18.636676
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    input0 = {
        'if':  {'type': 'integer'},
        'then':  {'type': 'string'},
        'else':  {'type': 'string'},
    }
    expect0 = 'foo'
    actual0 = IfThenElse(**input0).validate(expect0)
    print(f'''
input0: {input0}
expect0: {expect0}
actual0: {actual0}
''')


# Generated at 2022-06-26 10:12:23.956396
# Unit test for constructor of class AllOf
def test_AllOf():
    # default argument for items of class Field
    item1 = Any()
    # default argument for items of class Field
    item2 = AllOf([item1])
    assert item2.all_of[0] == item1
    # default argument for items of class Field
    item3 = Not(AllOf([item1]))
    assert item3.negated.all_of[0] == item1
    # default argument for items of class Field
    item4 = IfThenElse(item1)
    assert item4.if_clause == item1


# Generated at 2022-06-26 10:12:27.778139
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:12:34.605040
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([], required=False)
    val_0 = False  # type: typing.Optional[typing.Any]
    with pytest.raises(ValidationError):
        val_0 = one_of_0.validate(False)
    assert val_0 is None


# Generated at 2022-06-26 10:12:36.124843
# Unit test for constructor of class AllOf
def test_AllOf():
    field_obj = Field()
    all_of_ins = AllOf([field_obj])


# Generated at 2022-06-26 10:12:46.369633
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(label="if_clause")
    then_clause = Field()
    else_clause = Field()
    test_obj = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    value = "value"
    strict = True
    expected_value = "value"
    assert test_obj.validate(value, strict) == expected_value



# Generated at 2022-06-26 10:12:55.176264
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.validators import MinLength

    field = IfThenElse(
        if_clause=MinLength(1),
        then_clause=MinLength(2),
        else_clause=MinLength(10),
    )
    field.validate("123")


# Generated at 2022-06-26 10:13:05.079402
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    try:
        test_1_0 = OneOf(one_of=[Integer(min_value=1, max_value=2),String(pattern=r"^x*$")])
        test_1_0.validate("x")
        assert False
    except ValidationError as e:
        assert e.errors == {"no_match": "Did not match any valid type."}
    try:
        test_1_1 = OneOf(one_of=[Integer(min_value=1, max_value=2),String(pattern=r"^x*$")])
        test_1_1.validate("xxx")
        assert False
    except ValidationError as e:
        assert e.errors == {"multiple_matches": "Matched more than one type."}

# Generated at 2022-06-26 10:13:14.230861
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError) as exception_info:
        NeverMatch(allow_null=False)
    with pytest.raises(AssertionError) as exception_info:
        NeverMatch(required=False)
    with pytest.raises(AssertionError) as exception_info:
        NeverMatch(allow_null=[True])
    with pytest.raises(AssertionError) as exception_info:
        NeverMatch(required=[False])
    with pytest.raises(TypeError) as exception_info:
        NeverMatch(allow_null='')
    with pytest.raises(TypeError) as exception_info:
        NeverMatch(required='')


# Generated at 2022-06-26 10:13:20.492775
# Unit test for constructor of class AllOf
def test_AllOf():
    with pytest.raises(AssertionError):
        assert AllOf(all_of=[], allow_null=False) is None

# Generated at 2022-06-26 10:13:21.795240
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert None


# Generated at 2022-06-26 10:13:26.757314
# Unit test for method validate of class OneOf
def test_OneOf_validate():


    class A:
        def __eq__(self, other):
            return isinstance(other, A)
            
    class B:
        def __eq__(self, other):
            return isinstance(other, B)
    
    b = B()

    one_of_0 = OneOf([A(), B()])
    print(one_of_0.validate(b))



# Generated at 2022-06-26 10:13:27.967982
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([NeverMatch()])

# Generated at 2022-06-26 10:13:35.870077
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        test_case_1()
        test_case_2()
        test_case_3()
        test_case_4()
    except NameError:
        pass

# Generated at 2022-06-26 10:13:39.469703
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([never_match_0])
    try:
        one_of_0.validate(None)
    except Exception as raised:
        assert str(raised) == "Must not be null."


# Generated at 2022-06-26 10:13:46.660674
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    obj = IfThenElse(if_clause, then_clause, else_clause)
    with pytest.raises(AttributeError):
        obj.validate(None, strict=False)



# Generated at 2022-06-26 10:13:48.404068
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    if_clause = None
    then_clause = None
    else_clause = None
    field = IfThenElse(if_clause, then_clause, else_clause)

    value = None
    strict = False
    field.validate(value, strict)

# Generated at 2022-06-26 10:13:50.982478
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(one_of=[])
    # Implicitly validates self, so this is not a static method.
    one_of_0.validate(1, strict=False)


# Generated at 2022-06-26 10:13:54.032818
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf is not None and issubclass(OneOf, Field)


# Generated at 2022-06-26 10:14:00.558082
# Unit test for constructor of class OneOf
def test_OneOf():
    field0 = Any()
    field1 = Any()
    field2 = Any()
    field3 = Any()
    field4 = Any()
    field5 = Any()
    field6 = Any()
    field7 = Any()
    one_of0 = OneOf([field0, field1, field2, field3, field4, field5, field6, field7])


# Generated at 2022-06-26 10:14:04.397249
# Unit test for constructor of class OneOf
def test_OneOf():
    a = Field()
    b = Field()
    c = OneOf([a, b])


# Generated at 2022-06-26 10:14:11.384698
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    then_clause = "header"
    else_clause = "document"
    value = "document"
    if_clause = value
    obj = IfThenElse(if_clause, then_clause, else_clause)
    result = obj.validate(value)
    # AssertionError: "header" != "document"
    assert result == "document"



# Generated at 2022-06-26 10:14:25.137255
# Unit test for constructor of class IfThenElse

# Generated at 2022-06-26 10:14:32.271995
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Constructor test case 0
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:14:34.320432
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert get_validate_OneOf_return_value() == 1


# Generated at 2022-06-26 10:14:38.560961
# Unit test for constructor of class AllOf
def test_AllOf():
    fields = []
    all_of = AllOf(fields)
    assert all_of is not None


# Generated at 2022-06-26 10:14:43.497538
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.errors == {"never": "This never validates."}
    assert never_match_0.validate("") == "never"
    assert never_match_0.validate("") == "never"


# Generated at 2022-06-26 10:14:45.732137
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
   test = IfThenElse(if_clause="test")
   assert test.validate() == "test"


# Generated at 2022-06-26 10:14:56.417294
# Unit test for constructor of class OneOf
def test_OneOf():
    # Create a list of Field objects
    one_of_list_0 = [Field(), Field(), Field(), Field(), Field(), Field(), Field()]
    # Create a OneOf object by calling constructor of OneOf
    # with the list as parameter
    one_of_obj_0 = OneOf(one_of_list_0)
    # test for type
    assert isinstance(one_of_obj_0, OneOf)
    # test for constructor arguments
    assert one_of_obj_0.one_of == one_of_list_0


# Generated at 2022-06-26 10:15:07.082999
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        # Method 1:
        # Sub-item types
        fields = [
            NeverMatch(),
            NeverMatch(),
        ]

        all_of_0 = AllOf(
            all_of=fields
        )

        # Method 2:
        # Default values
        fields_0 = []
        all_of_1 = AllOf(
            all_of=fields_0,
        )

    except Exception as err:
        print("Unexpected error:", type(err), err)
        assert False
    else:
        assert True


# Generated at 2022-06-26 10:15:16.047676
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = list()
    field_0 = NeverMatch()
    list_0.append(field_0)
    int_0 = 0
    field_if_then_else_0 = IfThenElse(field_0, then_clause=Any(), else_clause=Any())
    list_0.append(field_if_then_else_0)
    assert int_0 == len(list_0)
    one_of_0 = OneOf(list_0)
    assert one_of_0.one_of == list_0


# Generated at 2022-06-26 10:15:25.556362
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test cases with valid if-then-else clauses
    if_clause_1 = lambda x: x == 1
    then_clause_1 = lambda x: x == 1
    else_clause_1 = lambda x: x == 2
    if_then_else_1 = IfThenElse(if_clause=if_clause_1, then_clause=then_clause_1,
        else_clause=else_clause_1)
    assert if_then_else_1.validate(1)
    assert not if_then_else_1.validate(2)

    if_clause_2 = lambda x: x == 1
    then_clause_2 = lambda x: x == 1
    else_clause_2 = lambda x: x == 2
    if_then_else_2 = IfThen

# Generated at 2022-06-26 10:15:34.792916
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Unit test for optional field names
    field_names = ["String", "Integer"]

    # Unit test for optional field oneOf (validate but dont set)
    one_of = [String(max_length=10), Integer(max_value=15)]

    # Unit test for optional field oneOf with Error
    one_of_err = [String(), Integer()]

    # Unit test for optional field allowNull
    allow_null = True

    # Unit test for parameter strict
    strict = False

    # Unit test for parameter value
    value = 20
    value_err = "test"

    # Unit test for optional parameter strict
    strict = False

    # Unit test for optional parameter value
    value = "test"

    # Validate the oneOf with value

# Generated at 2022-06-26 10:15:46.167073
# Unit test for constructor of class Not
def test_Not():
    def test_None():
        with pytest.raises(AssertionError) as excinfo:
            x = Not(None)
        assert str(excinfo.value) == "'Not' takes one positional argument but 2 were given"
    def test_correct():
        x = Not(Any())
        assert x.negated == Any()
    test_None()
    test_correct()
    print('Test of Not constructor successful')


# Generated at 2022-06-26 10:15:55.512775
# Unit test for constructor of class OneOf
def test_OneOf():
    a = 123
    b = "123"
    c = None
    v_0 = OneOf([Int32(), String()])
    v_0.validate(a)
    v_0.validate(b)
    try:
        v_0.validate(c)
    except:
        pass
    v_1 = OneOf([Int32(), String()], options=[])
    v_1.validate(a)
    v_1.validate(b)
    try:
        v_1.validate(c)
    except:
        pass


# Generated at 2022-06-26 10:15:56.714999
# Unit test for constructor of class AllOf
def test_AllOf():
  test_case_0()


# Generated at 2022-06-26 10:15:58.726203
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:16:02.808383
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    assert (Not(negated=never_match_0).errors["negated"] == "Must not match.")


# Generated at 2022-06-26 10:16:04.071982
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:16:05.967602
# Unit test for constructor of class Not
def test_Not():
    negated0 = Not(None)


# Generated at 2022-06-26 10:16:07.435109
# Unit test for constructor of class AllOf
def test_AllOf():
    pass


# Generated at 2022-06-26 10:16:09.066908
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert False, "Test not implemented"


# Generated at 2022-06-26 10:16:15.738125
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Setup test data
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 'test value'
    strict = False

    # Invoke method
    IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)

# Generated at 2022-06-26 10:16:30.059112
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    one_of_1 = OneOf([])
    one_of_2 = OneOf([])
    one_of_3 = OneOf([])
    one_of_4 = OneOf([])
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch()
    all_of_0 = AllOf([never_match_0, never_match_1])
    one_of_5 = OneOf([all_of_0])
    not_0 = Not(never_match_0)
    one_of_6 = OneOf([not_0])
    one_of_7 = OneOf([not_0])
    if_then_else_0 = IfThenElse(not_0)

# Generated at 2022-06-26 10:16:32.168357
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:16:36.368681
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[Any()])


# Generated at 2022-06-26 10:16:38.687543
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([NeverMatch(), NeverMatch()])


# Generated at 2022-06-26 10:16:42.825606
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = IfThenElse(field1 = None, field2 = None, field3 = None)
    assert x is not None

# Generated at 2022-06-26 10:16:50.159898
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Define constants and initialise object
    one_of_0 = [
        NeverMatch(),
        NeverMatch(),
        NeverMatch(),
        NeverMatch(),
        NeverMatch(),
        NeverMatch(),
    ]
    one_of_1 = OneOf(one_of_0)
    # Call the method validate
    try:
        one_of_1.validate(0)
        raise ValueError("Expected InvalidType exception")
    except ValueError as e:
        assert str(e) == "Expected InvalidType exception"


# Generated at 2022-06-26 10:16:54.614337
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Integer()
    then_clause = String()
    else_clause = Integer()
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-26 10:16:59.457040
# Unit test for constructor of class OneOf
def test_OneOf():
    x = None # type: typing.Type[typing.Any]
    y = None # type: typing.Type[typing.Any]
    z = None # type: typing.Type[typing.Any]
    try:
        x = NeverMatch()
    except:
        x = typing.cast(typing.Type[typing.Any], x)
    try:
        y = NeverMatch()
    except:
        y = typing.cast(typing.Type[typing.Any], y)
    try:
        z = NeverMatch()
    except:
        z = typing.cast(typing.Type[typing.Any], z)
    one_of = [x, y]
    try:
        OneOf(one_of)
    except:
        assert False


# Generated at 2022-06-26 10:17:01.369327
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # No test yet.
    assert True

# Generated at 2022-06-26 10:17:02.957312
# Unit test for constructor of class OneOf
def test_OneOf():
    h = OneOf([])


# Generated at 2022-06-26 10:17:32.773663
# Unit test for constructor of class OneOf
def test_OneOf():
    match_all_0 = {"type": "object"}  # Should never match a non-object type
    match_all_1 = {"type": "object"}  # Should never match a non-object type
    one_of_0 = None


# Generated at 2022-06-26 10:17:34.309421
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(None)

# Generated at 2022-06-26 10:17:39.158745
# Unit test for constructor of class Not
def test_Not():
    a_schema = {'type': 'array', 'items': {'type': 'integer'}}
    negated = a_schema
    not_0 = Not(negated=a_schema)


# Generated at 2022-06-26 10:17:51.484943
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    some_field = Field()
    some_if_clause = Field()
    some_else_clause = Field()
    some_then_clause = Field()
    some_if_clause.validate = lambda self, value: raise_error("some error")
    some_else_clause.validate = lambda self, value: raise_error("some error")
    some_then_clause.validate = lambda self, value: raise_error("some error")
    ite = IfThenElse(some_if_clause, some_then_clause, some_else_clause, name="some name")
    assert "some name" == ite.name
    assert some_if_clause == ite.if_clause
    assert some_then_clause == ite.then_clause
    assert some_else

# Generated at 2022-06-26 10:17:56.301051
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert isinstance(never_match_0, NeverMatch)
    with open("jsonschema_tests/test_case_0.json") as jsonschema_test_file:
        expected_json = json.load(jsonschema_test_file)
    actual_json = never_match_0.to_json()
    assert actual_json == expected_json

# Test for serialization of class NeverMatch

# Generated at 2022-06-26 10:18:00.240819
# Unit test for constructor of class Not
def test_Not():
    pass
    # Constructor test case
    negated_0 = NeverMatch()
    not_0 = Not(negated=negated_0)


# Generated at 2022-06-26 10:18:01.548370
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    ever_match_0 = NeverMatch()

# Generated at 2022-06-26 10:18:09.810486
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Positive cases
    # Positive case:1: if clause matches
    one_of_0 = OneOf([ IfThenElse(AllOf([Integer(), Minimum(1)]), None, AllOf([Integer(), Maximum(1)])) ])
    result_0 = one_of_0.validate(False, False)
    assert result_0 == False
    # Positive case:2: else clause matches
    one_of_1 = OneOf([ IfThenElse(AllOf([Integer(), Minimum(1)]), None, AllOf([Integer(), Maximum(1)])) ])
    result_1 = one_of_1.validate(False, False)
    assert result_1 == False
    # Negative cases
    # Negative case:1: both clauses fail

# Generated at 2022-06-26 10:18:12.503864
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    i_t_e_0 = IfThenElse(None, None, None)
    value_0 = None
    strict_0 = None
    result_0 = i_t_e_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:18:13.743161
# Unit test for constructor of class Not
def test_Not():
    never_match_0 = NeverMatch()
    not_0 = Not(negated=never_match_0)


# Generated at 2022-06-26 10:19:12.904670
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([]).validate(1)
    one_of_1 = OneOf([Any(), Any()]).validate(None)


# Generated at 2022-06-26 10:19:19.337356
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = None
    then_clause = None
    else_clause = None
    expression = IfThenElse(if_clause, then_clause, else_clause)
    expression.validate("test_value_0")

# Generated at 2022-06-26 10:19:24.088587
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # set up context
    obj = OneOf(one_of=[Any(), Any()])
    value = 1
    strict = False

    # invoke the target
    result = obj.validate(value, strict)

    # check the result
    assert result is value



# Generated at 2022-06-26 10:19:35.005339
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_field = OneOf(
        one_of=[
            test_field_0,
            test_field_1,
            test_field_2,
        ]
    )
    # Test validations of each type:
    # The following test should succeed.
    test_field.validate(test_value_0)
    # The following test should succeed.
    test_field.validate(test_value_1)
    # The following test should succeed.
    test_field.validate(test_value_2)
    # The following test should fail.
    with pytest.raises(ValidationError):
        test_field.validate(test_value_3)
