

# Generated at 2022-06-26 10:09:45.972366
# Unit test for method validate of class Not
def test_Not_validate():
    bool_0 = False
    not_0 = Not(bool_0)
    not_0.validate(False)


# Generated at 2022-06-26 10:09:53.046689
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    if_then_else_0 = IfThenElse(one_of_0, bool_0)
    str_0 = "ABCD"
    if_then_else_0.validate(str_0)


# Generated at 2022-06-26 10:10:00.143668
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = 'f'
    then_clause_0 = True
    else_clause_0 = True
    value_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0).validate(0.6)


# Generated at 2022-06-26 10:10:13.195742
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema_type = IfThenElse
    schema_args = {"if_clause": "IfClause", "then_clause": "ThenClause"}
    schema_kwargs = {}
    schema_kwargs_with_default = {"else_clause": Any()}
    nullable = False
    error_message = "Valid object"
    invalid_tests = [
        [[], False],
        [0, False],
        [{}, False],
        [0.1, False],
        ["", False],
        [{0}, False],
        [[[]], False],
        [None, False],
    ]
    tests_with_error_message = [
        ["IfClause", True],
        ["ThenClause", True],
        ["IfClauseThenClause", False],
    ]
    valid_tests = []


# Generated at 2022-06-26 10:10:20.446764
# Unit test for method validate of class Not
def test_Not_validate():
    dict_0 = dict()
    list_0 = []
    bool_0 = False
    list_1 = list()
    not_0 = Not(list_1, dict_0)
    value_0 = not_0.validate(list_0, bool_0)
    assert value_0 is None


# Generated at 2022-06-26 10:10:22.087936
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field_0 = NeverMatch()


# Generated at 2022-06-26 10:10:23.905719
# Unit test for method validate of class Not
def test_Not_validate():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:10:31.969647
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_default = None
    then_default = None
    else_default = None
    class_0 = IfThenElse(if_default, then_default, else_default)
    data = {}
    expected = None
    actual = class_0.validate("")
    assert actual == expected, "Return value mismatch"


# Generated at 2022-06-26 10:10:34.632397
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)


# Generated at 2022-06-26 10:10:47.016267
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    int_0 = 0
    null_0 = None
    list_0 = []
    bool_0 = False
    float_0 = 0.0
    str_0 = 'qT/D4B6[4UY>#@.!=2jEa0\"m'
    then_clause_0 = Reference()
    str_1 = 'Y57HV7o0\)8Wn!VJ!Cz'
    int_1 = 0
    else_clause_0 = Reference()
    if_clause_0 = Reference()
    reference_0 = null_0
    reference_1 = null_0
    reference_2 = null_0

    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    one_

# Generated at 2022-06-26 10:11:00.857185
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Union({})
    then_clause = IfThenElse(Union({}))
    else_clause = Union({})
    result = IfThenElse(if_clause, then_clause, else_clause)
    # Check the generated object.
    assert isinstance(result, IfThenElse)
    # Check the generated object fields.
    assert result.field_name == None
    assert result.if_clause == if_clause
    assert result.then_clause == then_clause
    assert result.else_clause == else_clause
    # Check the generated object metadata.
    assert result.required == True
    assert result.allow_null == False
    assert result.default == None
    assert result.read_only == False
    assert result.write_only == False
    assert result.re

# Generated at 2022-06-26 10:11:08.333548
# Unit test for method validate of class Not
def test_Not_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    list_1 = []
    bool_0 = False
    list_1.append(bool_0)
    not_0 = Not(one_of_0)
    val = not_0.validate(list_1)
    assert val == list_1


# Generated at 2022-06-26 10:11:11.455881
# Unit test for method validate of class Not
def test_Not_validate():
    test_field = Not(Boolean())
    assert test_field.validate(None) == None

# Generated at 2022-06-26 10:11:14.408017
# Unit test for constructor of class Not
def test_Not():
    one_of_0 = NeverMatch()
    not_0 = Not(one_of_0)


# Generated at 2022-06-26 10:11:19.389869
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    obj_0 = bool_0
    list_0.append(obj_0)
    one_of_0 = OneOf(list_0)
    one_of_0.validate(obj_0)


# Generated at 2022-06-26 10:11:21.351242
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    assert one_of_0.validate(bool_0) is bool_0



# Generated at 2022-06-26 10:11:32.321553
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = None
    then_clause = None
    else_clause = None
    if_clause_0 = Field()
    then_clause_0 = Field()
    else_clause_0 = Field()
    strict_0 = True
    strict_1 = False
    value_0 = None
    value_1 = None
    value_2 = None
    value_3 = None
    value_4 = None
    value_5 = None
    value_6 = None
    value_7 = None
    value_8 = None
    value_9 = None
    value_10 = None
    value_11 = None
    value_12 = None
    value_13 = None
    value_14 = None
    value_15 = None
    value_16 = None
    value_17 = None
    value

# Generated at 2022-06-26 10:11:35.692823
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=True if False else False, then_clause='ifthenelse', else_clause=None)


# Generated at 2022-06-26 10:11:37.041460
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert True


# Generated at 2022-06-26 10:11:40.726183
# Unit test for method validate of class Not
def test_Not_validate():
    list_0 = []
    bool_0 = False
    not_0 = Not(list_0)
    string_0 = "b=y"
    not_0.validate(string_0)


# Generated at 2022-06-26 10:11:45.914170
# Unit test for constructor of class AllOf
def test_AllOf():
    list_0 = []
    all_of_0 = AllOf(list_0)


# Generated at 2022-06-26 10:11:50.109745
# Unit test for constructor of class AllOf
def test_AllOf():
    list_0 = []
    field_0 = AllOf(list_0)
    test_case_0(list_0, field_0)



# Generated at 2022-06-26 10:11:51.374773
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert callable(NeverMatch)


# Generated at 2022-06-26 10:12:03.780234
# Unit test for method validate of class Not
def test_Not_validate():
    # Create a Not object
    if_clause_0 = Not(None)
    # Create a Not object
    then_clause_0 = Not(None)
    # Create a Not object
    else_clause_0 = Not(None)
    all_of_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0, None)
    one_of_0 = AllOf([all_of_0])
    all_of_1 = OneOf([one_of_0])
    all_of_2 = AllOf([all_of_1])
    one_of_1 = OneOf([all_of_0, all_of_2, all_of_1])
    list_0 = [all_of_0, all_of_2, all_of_1]

# Generated at 2022-06-26 10:12:15.428620
# Unit test for constructor of class AllOf
def test_AllOf():
    list_1 = []
    all_of_0 = AllOf(list_1)
    str_0 = "any"
    dict_0 = {}
    list_0 = []
    dict_1 = {"type": str_0, "properties": dict_0, "required": list_0}
    if_then_else_0 = IfThenElse(all_of_0)
    str_1 = "any"
    dict_2 = {}
    list_1 = []
    dict_3 = {"type": str_1, "properties": dict_2, "required": list_1}
    if_then_else_1 = IfThenElse(all_of_0, dict_3)
    str_2 = "any"
    dict_4 = {}
    list_2 = []

# Generated at 2022-06-26 10:12:20.959552
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0: Field = Field()
    then_clause_0: Field = Field()
    else_clause_0: Field = Field()
    if_then_else_0: IfThenElse = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0: typing.Any = TypingError()
    strict_0: bool = False
    assert isinstance(if_then_else_0.validate(value_0, strict_0), TypingError)



# Generated at 2022-06-26 10:12:31.206872
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    value_0 = None
    strict_0 = None
    one_of_0.validate(value_0, strict_0)
    strict_1 = False
    value_1 = None
    one_of_0.validate(value_1, strict_1)
    strict_2 = True
    value_2 = None
    one_of_0.validate(value_2, strict_2)
    strict_3 = True
    one_of_0.validate(strict_3)
    strict_4 = True
    value_4 = None
    one_of_0.validate(value_4, strict_4)
    strict_5 = True
    one_of_0.valid

# Generated at 2022-06-26 10:12:34.395859
# Unit test for method validate of class Not
def test_Not_validate():
    bool_0 = False
    bool_1 = True
    str_0 = 'a'
    list_0 = []
    not_0 = Not(Any())
    assert not_0.validate(str_0) == 'a'

# Generated at 2022-06-26 10:12:38.318460
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    value_0 = [2, 3]
    try:
        one_of_0.validate(value_0)
        assert False
    except ValidationError as ex:
        assert ex.code == "no_match"


# Generated at 2022-06-26 10:12:45.296593
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    if_clause_0 = IfThenElse(one_of_0)
    bool_1 = if_clause_0.validate(bool_0)
    assert bool_1 == bool_0


# Generated at 2022-06-26 10:12:57.966924
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    assert (one_of_0.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'})
    bool_0 = bool(one_of_0.one_of == [])
    assert bool_0
    list_0.append(one_of_0)
    bool_0 = bool(list_0)
    assert bool_0
    list_0.append(one_of_0)
    bool_0 = bool(list_0)
    assert bool_0


# Generated at 2022-06-26 10:13:08.426475
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    str_0 = "multiple_matches"
    dict_0 = one_of_0.errors
    error_0 = dict_0[str_0]
    with pytest.raises(ValidationError) as error_0:
        one_of_0.validate(bool_0)
    str_1 = "multiple_matches"
    dict_1 = one_of_0.errors
    error_1 = dict_1[str_1]
    assert str(error_0.value) == error_1


# Generated at 2022-06-26 10:13:14.636080
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    param0 = IfThenElse()
    param1 = Union()
    param2 = typesystem.fields.String()
    param3 = False
    result = param0.validate(param1, param2, param3)
    assert isinstance(result, Any) == True


# Generated at 2022-06-26 10:13:26.698136
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    str_0 = 'src/test/python/typesystem/union_test/cases/case_0.py'
    str_1 = 'src/test/python/typesystem/union_test/cases/case_1.py'
    str_2 = 'src/test/python/typesystem/union_test/cases/case_2.py'
    str_3 = 'src/test/python/typesystem/union_test/cases/case_3.py'
    str_4 = 'src/test/python/typesystem/union_test/cases/case_4.py'
    str_5 = 'src/test/python/typesystem/union_test/cases/case_5.py'
    str

# Generated at 2022-06-26 10:13:29.638798
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    assert one_of_0.one_of == list_0



# Generated at 2022-06-26 10:13:36.101451
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = 0
    strict = bool_0
    ifThenElse = IfThenElse(one_of_0, then_clause=one_of_0, else_clause=one_of_0)
    ifThenElse.validate(value, strict)


# Generated at 2022-06-26 10:13:44.118511
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    one_of_0 = OneOf(list_0)
    object_0 = object()
    str_0 = ""
    bool_0 = False
    strict_0 = False
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_1 = float()
    float_0 = float()
    float_1 = float()
    float_0

# Generated at 2022-06-26 10:13:48.065446
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)

# Generated at 2022-06-26 10:13:55.972037
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0 = None
    then_clause_0 = None
    else_clause_0 = None
    try:
        if_clause_0 = Not(NeverMatch())
    except:
        import sys
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_tb(exc_traceback)
    try:
        then_clause_0 = Not(NeverMatch())
    except:
        import sys
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()
        traceback.print_tb(exc_traceback)
    try:
        else_clause_0 = Not(NeverMatch())
    except:
        import sys
        import traceback
        exc_type

# Generated at 2022-06-26 10:14:00.762082
# Unit test for constructor of class AllOf
def test_AllOf():
    one_of_0 = AllOf([])
    one_of_1 = AllOf([], description="description_0")
    one_of_2 = AllOf([], description="description_0")


# Generated at 2022-06-26 10:14:12.886288
# Unit test for constructor of class Not
def test_Not():
    # Create object Not with argument 'negated'
    negated = Any()
    not_0 = Not(negated)

    assert isinstance(not_0, Not)
    assert not_0.name is None
    assert not_0.description is None
    assert not_0.required is True
    assert not_0.allow_null is False
    assert not_0.allow_empty is False
    assert not_0.hidden is False
    assert not_0.negated == negated
    assert not_0.errors == {"negated": "Must not match."}


# Generated at 2022-06-26 10:14:25.701320
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    obj_0 = OneOf(list_0)
    list_1 = []
    obj_1 = OneOf(list_1)
    list_2 = []
    obj_2 = OneOf(list_2)
    list_3 = []
    obj_3 = OneOf(list_3)
    list_4 = []
    obj_4 = OneOf(list_4)
    list_5 = []
    obj_5 = OneOf(list_5)
    list_6 = []
    obj_6 = OneOf(list_6)
    list_7 = []
    obj_7 = OneOf(list_7)
    list_8 = []
    obj_8 = OneOf(list_8)
    list_9 = []
    obj_9 = OneOf(list_9)

# Generated at 2022-06-26 10:14:31.093486
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    value_0 = one_of_0.validate("")


# Generated at 2022-06-26 10:14:36.146801
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    bool_1 = False
    value, error = one_of_0.validate_or_error(bool_0) # exception raise
    assert value == bool_0
    assert error is None


# Generated at 2022-06-26 10:14:45.817841
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    str_0 = ''
    dict_0 = {}
    list_0 = []
    bool_0 = True
    if_clause_0 = Any()
    then_clause_0 = Any()
    else_clause_0 = Any()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = if_then_else_0.validate((str_0, dict_0, list_0, bool_0))


# Generated at 2022-06-26 10:14:54.763680
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    i = 0
    then_clause_0 = Any()
    if_clause_0 = IfThenElse(then_clause_0, then_clause_0)
    strict_0 = False
    value_0 = 123
    assert if_clause_0.validate(value_0, strict_0) == then_clause_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:14:58.046230
# Unit test for constructor of class OneOf
def test_OneOf():
    field = list
    one_of_0 = OneOf([field])
    bool_0 = False
    bool_1 = True
    if (one_of_0.validate(bool_0)):
        bool_1 = False
    assert bool_1


# Generated at 2022-06-26 10:15:03.581943
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    assert one_of_0.one_of == list_0


# Generated at 2022-06-26 10:15:05.992868
# Unit test for constructor of class AllOf
def test_AllOf():
    list_0 = []
    field_0 = AllOf(list_0)


# Generated at 2022-06-26 10:15:14.692605
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = None
    else_clause_0 = None
    then_clause_0 = None
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    if_then_else_0.validate(1)
    if_clause_1 = None
    else_clause_1 = None
    then_clause_1 = None
    if_then_else_1 = IfThenElse(if_clause_1, then_clause_1, else_clause_1)
    if_then_else_1.validate(1)
    if_clause_2 = None
    else_clause_2 = None
    then_clause_2 = None

# Generated at 2022-06-26 10:15:21.947550
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([NeverMatch()])
    assert isinstance(all_of_0, Field)
    assert isinstance(all_of_0, AllOf)


# Generated at 2022-06-26 10:15:35.270452
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    list_1 = []
    bool_1 = False
    not_0 = Not(one_of_0)
    # If-then-else
    if True:
        assert (
            one_of_0.validate(Any().validate(list_1))
            == Any().validate(list_1)
        )
    else:
        assert (
            one_of_0.validate(Any().validate(list_1))
            == Any().validate(list_1)
        )
    assert not_0.errors["negated"] == "Must not match."
    # If-then-else

# Generated at 2022-06-26 10:15:47.388418
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_1 = []
    bool_2 = False
    one_of_0 = OneOf(list_1)
    assert one_of_0.validate(bool_2) == False
    list_2 = []
    all_of_1 = AllOf(list_2)
    assert all_of_1.validate(bool_2) == False
    list_3 = []
    not_0 = Not(list_3)
    assert not_0.validate(bool_2) == False
    list_4 = []
    if_then_else_0 = IfThenElse(list_4)
    assert if_then_else_0.validate(bool_2) == False


# Generated at 2022-06-26 10:15:52.403063
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    str_0 = ""
    try:
        one_of_0.validate(str_0, bool_0)
        assert True
    except ValidationError as e:
        assert False



# Generated at 2022-06-26 10:15:59.427910
# Unit test for constructor of class Not
def test_Not():
    list_0 = []
    any_0 = Any()
    str_0 = ""
    one_of_0 = OneOf(list_0)
    not_0 = Not(one_of_0)
    dict_0 = {}
    all_of_0 = AllOf(list_0)
    union_0 = Union(list_0)
    never_match_0 = NeverMatch()
    if_then_else_0 = IfThenElse(one_of_0, union_0, all_of_0)
    bool_0 = False


# Generated at 2022-06-26 10:16:04.371584
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    value_0 = one_of_0.validate(bool_0)
    assert value_0 == bool_0

# Generated at 2022-06-26 10:16:15.492151
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    obj = one_of_0.validate(obj)
    num = one_of_0.validate(num)
    str = one_of_0.validate(str)
    bool_1 = one_of_0.validate(bool_0)
    one_of_0.validate(bool_0)
    one_of_0.validate(bool_0)


# Generated at 2022-06-26 10:16:24.777007
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    one_of_0.validate(bool_0)
    one_of_0.validate(bool_0)
    one_of_0.validate(bool_0)
    one_of_0.validate(bool_0)
    one_of_0.validate(bool_0)



# Generated at 2022-06-26 10:16:27.062323
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    if_then_else_0 = IfThenElse(one_of_0)



# Generated at 2022-06-26 10:16:34.672212
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    Field_0 = TypedField(int, name="int_0")
    one_of_0 = OneOf(list_0)
    value_0 = one_of_0.validate(Field_0)
    # Tested
    value_1 = one_of_0.validate(Field_0)


# Generated at 2022-06-26 10:16:48.092300
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    # Check type of var 'one_of_0' (line 9)
    assert isinstance(one_of_0, OneOf)
    # Call method 'validate' (line 30)
    # Call method 'validate' (line 30)
    # Call method 'validate' (line 30)
    # Call method 'validate' (line 30)


# Generated at 2022-06-26 10:16:52.363571
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    assert one_of_0 is not None



# Generated at 2022-06-26 10:16:55.810859
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Create an instance of the NeverMatch class
    test_NeverMatch = NeverMatch()
    assert test_NeverMatch is not None



# Generated at 2022-06-26 10:17:00.418144
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Parameterize the test case
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    value_0 = None
    strict_0 = False
    
    # Call the method under test
    if_then_else_0 = one_of_0.validate(value_0, strict_0)
    
    # Assert the expected results
    assert if_then_else_0 is None


# Generated at 2022-06-26 10:17:04.845806
# Unit test for constructor of class Not
def test_Not():
    assert (Not(negated=None))
    assert (Not(negated=NeverMatch()))
    assert (Not(negated=Any()))



# Generated at 2022-06-26 10:17:10.965605
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    # AssertionError: Did not match any valid type.
    one_of_0.validate(bool_0)


# Generated at 2022-06-26 10:17:12.382647
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    schema = NeverMatch()


# Generated at 2022-06-26 10:17:19.186891
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Initialize test arguments
    list_0 = []
    strict_0 = False
    any_0 = Any()
    # Execute the method under test
    result_0 = OneOf(list_0).validate(any_0, strict_0)


# Generated at 2022-06-26 10:17:22.091227
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    one_of_0.validate(bool_0)


# Generated at 2022-06-26 10:17:23.284457
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True

# Generated at 2022-06-26 10:17:33.692520
# Unit test for constructor of class AllOf
def test_AllOf():
    assert (AllOf([]) != None) # Type assertion error


# Generated at 2022-06-26 10:17:38.084228
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # default constructor
    NeverMatchObj_0 = NeverMatch()

    # initializer constructor
    NeverMatchObj_1 = NeverMatch(errors=dict)

    # initializer constructor
    NeverMatchObj_2 = NeverMatch(error_types=dict)

    # initializer constructor
    NeverMatchObj_3 = NeverMatch(metadata=dict)


# Generated at 2022-06-26 10:17:42.311113
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    value = bool_0
    strict = bool_0
    str_1 = one_of_0.validate(value, strict)


# Generated at 2022-06-26 10:17:48.938909
# Unit test for constructor of class Not
def test_Not():
    """Test the __init__ method of class Not"""
    negated = "negated"
    obj = Not(negated)
    assert isinstance(obj, Not)
    assert obj.negated == "negated"


# Generated at 2022-06-26 10:17:54.362438
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_1 = [bool_0]
    literal_1 = False
    literal_0 = "test"
    one_of_1 = OneOf(list_1)
    value_0 = one_of_1.validate(literal_1)
    value_1 = one_of_1.validate(literal_0)


# Generated at 2022-06-26 10:17:59.288442
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = "b'new_value'"
    then_clause = "b'then_value'"
    else_clause = "b'else_value'"
    test_case_name = "test_case_123"

    # Test for constructor of class IfThenElse
    ifthenelse = IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-26 10:18:05.200461
# Unit test for constructor of class AllOf
def test_AllOf():
    """
    Initializes a AllOf field.

    first param - allof[list['a', 'b', 'c']]

    """
    # all_of_0 is a AllOf
    all_of_0 = AllOf([])


# Generated at 2022-06-26 10:18:09.140975
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    one_of_0.validate(bool_0)


# Generated at 2022-06-26 10:18:14.772397
# Unit test for constructor of class Not
def test_Not():
    assert Not.__init__
    # TODO: Create a Not object to pass to test
    # Hint: This class requires a parameter, which you must pass a field object to.
    #       We recommend using a bool, int, or string field for testing.
    try:
        test_Not = Not()
    except TypeError:
        assert True
    else:
        assert False



# Generated at 2022-06-26 10:18:20.193683
# Unit test for constructor of class Not
def test_Not():
    # The initializer has 2 parameters.
    negated = "ab"
    assert isinstance(Not(negated), Not)


# Generated at 2022-06-26 10:18:40.026339
# Unit test for constructor of class AllOf
def test_AllOf():
    list_1 = []
    all_of_0 = AllOf(list_1)


# Generated at 2022-06-26 10:18:47.502002
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Init
    list_0 = ["abc"]
    # bool_0 = False
    one_of_0 = OneOf(list_0)
    int_0 = 0
    # Invoke method
    result = one_of_0.validate(int_0)
    # Check for error
    assert not result



# Generated at 2022-06-26 10:18:54.069441
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test fields
    list_0 = []
    bool_0 = False
    map_0 = {}
    set_0 = {}

    one_of_0 = OneOf(list_0)
    list_1 = [one_of_0]
    one_of_1 = OneOf(list_1)
    list_2 = [one_of_1]
    one_of_2 = OneOf(list_2)
    not_0 = Not(one_of_2)
    list_3 = [not_0]
    all_of_0 = AllOf(list_3)
    list_4 = [all_of_0]
    if_then_else_0 = IfThenElse(all_of_0, then_clause=all_of_0)

# Generated at 2022-06-26 10:18:59.303267
# Unit test for constructor of class OneOf
def test_OneOf():
    list_0 = []
    bool_0 = False
    one_of_0 = OneOf(list_0)
    assert one_of_0.one_of == list_0


# Generated at 2022-06-26 10:19:02.520122
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    any_3 = Any()
    try:
        nevermatch_0 = NeverMatch(name="nevermatch_0", value=any_3)
    except :
        nevermatch_0 = NeverMatch(name="nevermatch_0")


# Generated at 2022-06-26 10:19:11.074331
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Empty constructor
    never_match0 = NeverMatch()
    assert never_match0.errors == {"never": "This never validates."}

    # Constructor with arguments
    never_match1 = NeverMatch(key_str='', key_str_2='')
    assert never_match1.errors == {"never": "This never validates."}



# Generated at 2022-06-26 10:19:12.904982
# Unit test for constructor of class Not
def test_Not():
    list_0 = []
    not_0 = Not(list_0)
    assert not_0.negated == list_0



# Generated at 2022-06-26 10:19:21.266807
# Unit test for constructor of class Not
def test_Not():
    value_0 = True
    all_of_0 = AllOf(value_0)
    if_clause_0 = value_0
    negated_0 = value_0
    negated_1 = value_0
    not_0 = Not(negated_0)
    not_1 = Not(negated_1)


# Generated at 2022-06-26 10:19:24.424936
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_OneOf_validate_0()
    test_OneOf_validate_1()
    test_OneOf_validate_2()
    test_OneOf_validate_3()


# Generated at 2022-06-26 10:19:27.190070
# Unit test for constructor of class Not
def test_Not():
    type_0 = Not
    assert issubclass(type_0, Field) is True
