

# Generated at 2022-06-26 10:09:49.109039
# Unit test for constructor of class Not
def test_Not():
    # Create a Not object
    arg_0 = Union([Str(),Str()])
    obj_0 = Not(arg_0)

    # Test if the new object is equal to a string
    assert obj_0 != 'Not(Union([Str(),Str()]))'


# Generated at 2022-06-26 10:09:52.810254
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    str_0 = ''
    one_of_0 = OneOf([])
    one_of_0.validate(str_0)


# Generated at 2022-06-26 10:09:59.513651
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    str_0 = ''
    field_0 = module_0.Field(description=str_0)
    one_of_0 = OneOf([field_0])
    str_1 = ''
    one_of_0.validate(str_1)


# Generated at 2022-06-26 10:10:06.124326
# Unit test for method validate of class Not
def test_Not_validate():
    str_0 = ''
    field_0 = Field(description=str_0)
    not_0 = Not(field_0)
    str_1 = ''
    thrown = None
    try:
        not_0.validate(str_1)
    except ValidationError as e:
        thrown = e
    assert thrown


# Generated at 2022-06-26 10:10:10.629568
# Unit test for method validate of class Not
def test_Not_validate():
    str_0 = ''
    field_0 = module_0.Field(description=str_0)
    not_0 = Not(field_0)
    not_0.validate()


# Generated at 2022-06-26 10:10:12.994512
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(None)


# Generated at 2022-06-26 10:10:25.781342
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    str_0 = ''
    field_0 = module_0.Field(description=str_0)
    one_of_0 = OneOf([field_0])
    str_1 = ''
    dict_0 = {str_1: str_0}
    field_1 = module_0.Field(description=str_0)
    one_of_1 = OneOf([field_1, field_0])
    tuple_0 = (field_1, dict_0)
    field_2 = module_0.Field(description=str_0)
    one_of_2 = OneOf([one_of_0, one_of_1])
    # Test the case where candidate is None and match_count is 1
    one_of_0.validate(tuple_0)
    # Test the case where candidate is dict_0 and

# Generated at 2022-06-26 10:10:32.452221
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    str_0 = 'kIx'
    str_1 = '`aV'
    one_of_1 = one_of_0.validate(str_1)
    assert str_0 != str_1


# Generated at 2022-06-26 10:10:35.404274
# Unit test for method validate of class Not
def test_Not_validate():
    str_0 = ''
    field_0 = module_0.Field(description=str_0)
    not_0 = Not(field_0)
    assert not_0.validate() == None

# Generated at 2022-06-26 10:10:47.057942
# Unit test for method validate of class Not
def test_Not_validate():
    str_0 = ''
    field_0 = module_0.Field(description=str_0)
    not_0 = Not(field_0)
    str_1 = ''
    bool_0 = bool()
    bool_1 = bool(str_1)
    bool_2 = bool(str_0)
    bool_3 = bool(not not bool_2)
    not_1 = Not(field_0)
    not_2 = Not(field_0)
    not_3 = Not(field_0)
    not_4 = Not(field_0)
    not_5 = Not(field_0)
    not_6 = Not(field_0)
    not_7 = Not(field_0)
    not_8 = Not(field_0)
    not_9 = Not(field_0)
   

# Generated at 2022-06-26 10:10:57.770286
# Unit test for method validate of class Not
def test_Not_validate():
    value_0 = Not()

    with pytest.raises(NotImplementedError):
        value_0.validate(value_0.validate())

    with pytest.raises(NotImplementedError):
        value_0.validate(value_0.validate())

    with pytest.raises(NotImplementedError):
        value_0.validate(value_0.validate())



# Generated at 2022-06-26 10:11:10.326907
# Unit test for constructor of class Not
def test_Not():

    var_0 = None
    _ = Not(var_0)
    var_1 = Not({})
    var_1 = Not([])
    var_1 = Not("string")
    var_1 = Not(0)
    var_1 = Not(0.1)
    var_1 = Not(None)
    var_1 = Not(Not({}))
    var_1 = Not(AllOf({}))
    var_1 = Not(OneOf({}))
    var_1 = Not(IfThenElse({}))
    var_1 = Not(Not(None))
    var_1 = Not(AllOf(None))
    var_1 = Not(OneOf(None))
    var_1 = Not(IfThenElse(None))
    var_1 = Not(Not({}))
    var_1 = Not

# Generated at 2022-06-26 10:11:13.286318
# Unit test for constructor of class AllOf
def test_AllOf():
    var_0 = None
    all_of_0 = AllOf(var_0)


# Generated at 2022-06-26 10:11:18.204741
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print('Testing constructor of NeverMatch class')
    var_0 = NeverMatch()
    assert var_0 is not None
    try:
        var_0 = NeverMatch('test')
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-26 10:11:23.805104
# Unit test for method validate of class Not
def test_Not_validate():
    var_0 = Not(None)
    var_1 = Not(None)
    var_2 = Not(None)
    var_3 = Not(None)
    var_4 = Not(None)
    var_5 = Not(None)
    var_6 = Not(None)
    var_7 = Not(None)
    var_8 = Not(None)
    var_9 = Not(None)
    var_10 = Not(None)
    var_11 = Not(None)
    var_12 = Not(None)
    var_13 = Not(None)
    var_14 = Not(None)
    var_15 = Not(None)
    var_16 = Not(None)
    var_17 = Not(None)
    var_18 = Not(None)
    var_19 = Not(None)

# Generated at 2022-06-26 10:11:25.198160
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True == True


# Generated at 2022-06-26 10:11:31.058159
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    implicitly_not = Not(IfThenElse(String(), True))
    assert implicitly_not.validates("abc")
    assert not implicitly_not.validates("false")

    # This is going to be a big problem:
    # if = IfThenElse(Number(), True)
    # not_if = Not(if)
    # assert if.validates("42")
    # assert not_if.validates("false")

# Generated at 2022-06-26 10:11:37.829053
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Unit test for the validate() method of the OneOf class.
    """
    var_0 = None
    one_of_0 = OneOf(var_0)

    # Test parameter: strict
    value = None
    one_of_0.validate(value=value)
    value = None
    one_of_0.validate(value=value, strict=True)


# Generated at 2022-06-26 10:11:40.979162
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    var_0 = None
    var_1 = IfThenElse(var_0)
    var_2 = var_0
    var_3 = None
    var_4 = None
    var_5 = IfThenElse(var_2, var_3, var_4)

# Generated at 2022-06-26 10:11:45.198515
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    var_0 = Any()
    var_1 = None
    obj = OneOf(var_0,var_1)
    obj.validate(None, True)


# Generated at 2022-06-26 10:11:53.042690
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(
        negated=Field()
    )
    any_0 = Field()
    boolean_0 = not_0.validate(any_0)
    boolean_1 = not_0.validate(any_0)
    boolean_2 = Not(
        negated=Field()
    ).validate(any_0)

# Generated at 2022-06-26 10:11:58.083321
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class First(Field):
        def validate(self, value, strict=False):
            pass
    class Second(Field):
        def validate(self, value, strict=False):
            pass
    class Third(Field):
        def validate(self, value, strict=False):
            pass
    first_0 = First()
    second_0 = Second()
    third_0 = Third()
    if_then_else_0 = IfThenElse(first_0, then_clause=second_0, else_clause=third_0)
    any_0 = if_then_else_0.validate(if_then_else_0)


# Generated at 2022-06-26 10:12:01.968122
# Unit test for method validate of class Not
def test_Not_validate():
    # Given
    not_0 = Not(NeverMatch())
    # When
    with TestRun.step("When we validate against never match type."):
        any_0 = not_0.validate(not_0)


# Generated at 2022-06-26 10:12:06.785410
# Unit test for method validate of class Not
def test_Not_validate():
    # Setup
    not_0 = Not(negated=NeverMatch())
    # Exercise and Verify
    not_0.validate(not_0)


# Generated at 2022-06-26 10:12:08.378136
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()


# Generated at 2022-06-26 10:12:15.303853
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([Boolean(),])
    one_of_0 = OneOf([Boolean(),])
    one_of_1 = OneOf([Boolean(),], description="foo")
    one_of_2 = OneOf([Boolean(),], name="foo")
    one_of_3 = OneOf([Boolean(),], context={"foo"},)
    one_of_4 = OneOf([Boolean(),], default=True,)
    one_of_5 = OneOf([Boolean(),], required=True)
    assert one_of_5.validate(True) == True
    with pytest.raises(Error):
        one_of_5.validate(None)
    one_of_6 = OneOf([Boolean(),], required=False)
    assert one_of_6.validate(None)

# Generated at 2022-06-26 10:12:23.718853
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    any_0 = Any()
    if_clause_0 = any_0.validate(any_0)
    if_clause_1 = any_0.validate(if_clause_0)
    if_then_else_0 = IfThenElse(if_clause=if_clause_1)
    if_then_else_1 = IfThenElse(if_clause=if_then_else_0)
    if_then_else_2 = IfThenElse(if_clause=if_then_else_1)
    _condition_0 = "if"
    if_then_else_3 = IfThenElse(if_clause=if_then_else_2, **{_condition_0: if_then_else_2})

# Generated at 2022-06-26 10:12:30.220367
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(Negated=None)
    value_0 = None
    strict_0 = False
    result_0 = not_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:12:37.777037
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = Any()
    then_clause_0 = IfThenElse(if_clause_0, if_clause_0)
    else_clause_0 = None
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = if_then_else_0
    strict_0 = False
    if_then_else_0.validate(value_0, strict_0)


# Generated at 2022-06-26 10:12:42.925498
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = [
        IntegerField(),
        StringField(),
        ]
    oneof0 = OneOf(one_of)
    value0 = 1.0
    any0 = oneof0.validate(value0)


# Generated at 2022-06-26 10:12:49.315379
# Unit test for constructor of class AllOf
def test_AllOf():
    items = []
    parameters = {
        "all_of": items,
    }
    all_of = AllOf(**parameters)
    assert hasattr(all_of, "all_of")
    assert hasattr(all_of, "validate")


# Generated at 2022-06-26 10:12:54.575017
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    never_match_0 = NeverMatch()
    if_clause_0 = Any()
    then_clause_0 = never_match_0
    else_clause_0 = never_match_0
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = if_then_else_0.validate(if_then_else_0)
    with raises(ValidationError):
        never_match_0.validate(never_match_0)
    assert value_0 == if_then_else_0


# Generated at 2022-06-26 10:13:02.432568
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    some_string = "A string"
    some_int = 42
    my_string = typesystem.String()
    my_int = typesystem.Integer()
    my_union = OneOf([my_string, my_int])
    my_union.validate(some_string)
    my_union.validate(some_int)

# if __name__ == "__main__":
#     import sys
#     import os

#     if "--debug" in sys.argv:
#         from typesystem.tests.debug import *

#         debug_typesystem_module(os.path.dirname(__file__))

#     else:
#         test_case_0()
#         test_AllOf_validate()
#         test_OneOf_validate()

# Generated at 2022-06-26 10:13:06.754519
# Unit test for constructor of class AllOf
def test_AllOf():
    # Initializes a list of types
    all_of = [AllOf(allof=None)]

    assert all_of is not None


# Generated at 2022-06-26 10:13:08.827593
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not()
    not_0.validate(not_0)


# Generated at 2022-06-26 10:13:13.335896
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Any(), Any()]
    all_of_0 = AllOf(all_of)
    assert all_of_0.all_of == [Any(), Any()]


# Generated at 2022-06-26 10:13:22.949702
# Unit test for constructor of class AllOf
def test_AllOf():
    maybe_int = Any()
    list_of_int = List(maybe_int)
    min_items = MinItems(1)
    max_items = MaxItems(2)
    all_of = AllOf([min_items, max_items], description="All of")
    any_0 = all_of.validate(list_of_int)


# Generated at 2022-06-26 10:13:25.042494
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()



# Generated at 2022-06-26 10:13:30.547923
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test a scenario where the validation succeeds
    oneOf_0 = OneOf(one_of=[Any()])
    any_0 = oneOf_0.validate(any_0)
    # Test a scenario where the validation fails
    oneOf_1 = OneOf(one_of=[NeverMatch()])
    any_1 = oneOf_1.validate(any_1)


# Generated at 2022-06-26 10:13:40.560257
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class Constant(Field):
        def __init__(self, constant: Any, **kwargs: Any) -> None:
            self.constant = constant
            super().__init__(**kwargs)
        def validate(self, value: Any, strict: bool = False) -> Any:
            if value == self.constant:
                return self.constant
            raise self.validation_error("invalid")

    constant_0 = Constant(None)
    constant_1 = Constant("test_value")
    oneof_0 = OneOf([constant_0, constant_1])
    any_0 = oneof_0.validate(oneof_0)


# Generated at 2022-06-26 10:13:50.811957
# Unit test for constructor of class AllOf
def test_AllOf():
  # all_of
  all_of = [Any()]
  # name
  name = ""
  # description
  description = ""
  # label
  label = ""
  # nullable
  nullable = True
  # strict
  strict = True
  # error
  expected_error = None
  try:
    # call case0
    AllOf(all_of, name, description, label, nullable, strict)
  except Exception as e:
    actual_error = str(e)
  # check exception
  assert actual_error == expected_error


# Generated at 2022-06-26 10:13:55.787973
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not()
    value_0 = ""
    not_0_validate_0 = not_0.validate(value_0)


# Generated at 2022-06-26 10:14:00.532907
# Unit test for method validate of class Not
def test_Not_validate():
    not_0 = Not(negated=NeverMatch())
    not_0.validate(not_0)

# Test for method validate of class IfThenElse

# Generated at 2022-06-26 10:14:06.864315
# Unit test for method validate of class Not
def test_Not_validate():
    # unit test for validate
    negated = AllOf([Any(), Any()])
    not_0 = Not(negated)
    any_0 = not_0.validate(not_0)
    not_0.validate(None)


# Generated at 2022-06-26 10:14:09.725301
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(list())
    assert all_of_0.kwargs == {}


# Generated at 2022-06-26 10:14:12.356636
# Unit test for method validate of class Not
def test_Not_validate():
    never_match_0 = NeverMatch()
    not_0 = Not(never_match_0)
    any_0 = not_0.validate(never_match_0)


# Generated at 2022-06-26 10:14:17.273383
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    # Assert field name was set correctly.
    assert never_match_0.field_name == "NeverMatch"


# Generated at 2022-06-26 10:14:22.042786
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([Any()], name='AllOf')
    assert(all_of_0 != None)
    assert(all_of_0.name == 'AllOf')


# Generated at 2022-06-26 10:14:23.632696
# Unit test for method validate of class Not
def test_Not_validate():
  assert False


# Generated at 2022-06-26 10:14:30.226246
# Unit test for constructor of class Not
def test_Not():
    # type: () -> None
    """
    We should be able to construct a Not object without error
    """
    not_0 = Not(negated=NeverMatch())
    assert not_0.negated == NeverMatch


# Generated at 2022-06-26 10:14:36.766332
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    # Test __init__()
    assert never_match_0.validate(never_match_0)==never_match_0

    # Test assert()
    assert never_match_0.validate(never_match_0)==never_match_0


# Generated at 2022-06-26 10:14:47.904168
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    item = typesystem.OneOf(typesystem.OneOf(typesystem.String()))
    with pytest.raises(typesystem.Error):
        item.validate(item)
    with pytest.raises(typesystem.Error):
        item.validate(typesystem.OneOf(typesystem.String()))
    with pytest.raises(typesystem.Error):
        item.validate(typesystem.Any())
    with pytest.raises(typesystem.Error):
        item.validate(typesystem.Dict())
    with pytest.raises(typesystem.Error):
        item.validate(typesystem.Array())
    with pytest.raises(typesystem.Error):
        item.validate(typesystem.Boolean())

# Generated at 2022-06-26 10:14:51.656822
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([Field])
    bool_0 = one_of_0.validate(one_of_0)


# Generated at 2022-06-26 10:14:53.874973
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])


# Generated at 2022-06-26 10:15:01.384456
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
  # initialize instance
  if_clause = NeverMatch()
  then_clause = NeverMatch()
  else_clause = NeverMatch()

  # call method
  x = IfThenElse(if_clause, then_clause, else_clause)
  y0 = x.validate(x)
  y1 = x.validate(x)
  y2 = x.validate(x)
  y3 = x.validate(x)
  y4 = x.validate(x)
  y5 = x.validate(x)
  y6 = x.validate(x)
  y7 = x.validate(x)

  assert(y1 == y0)
  assert(y2 == y0)
  assert(y3 == y0)
  assert(y4 == y0)


# Generated at 2022-06-26 10:15:04.522513
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    string_0 = OneOf([String()])
    any_0 = string_0.validate("")


# Generated at 2022-06-26 10:15:16.276979
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Case 0:
    if_clause_0 = Any()
    then_clause_0 = Any()
    else_clause_0 = Any()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    any_0 = if_then_else_0.validate(if_then_else_0)
    
    # Case 1:
    if_clause_1 = Any()
    then_clause_1 = Any()
    else_clause_1 = Any()
    if_then_else_1 = IfThenElse(if_clause_1, then_clause_1, else_clause_1)
    any_1 = if_then_else_1.validate(if_then_else_1)

# Generated at 2022-06-26 10:15:17.291306
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([float])
    all_of_1 = AllOf([float, float])
    all_of_2 = AllOf(float)

# Generated at 2022-06-26 10:15:25.555944
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_0 = lambda: None
    then_clause_0 = lambda: None
    else_clause_0 = lambda: None
    if_clause_0.validate_or_error = lambda: (lambda: None, None)
    if_then_else = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    value_0 = lambda: None
    if_then_else.validate(value_0)
    if_then_else.validate(value_0, strict=False)
    if_then_else.validate(value_0, strict=True)

# Generated at 2022-06-26 10:15:30.837219
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        test_case_0()
    except AssertionError as error:
        print("Failed to create object")


# Generated at 2022-06-26 10:15:36.195367
# Unit test for constructor of class Not
def test_Not():
    def verify(negated: Field, expected: typing.Any):
        actual = Not(negated)
        assert actual.negated == expected

    negated = NeverMatch()
    expected = negated
    verify(negated, expected)


# Generated at 2022-06-26 10:15:44.737883
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([Any()])
    all_of_0 = AllOf([one_of_0])
    not_0 = Not(one_of_0)
    if_then_else_0 = IfThenElse(one_of_0, one_of_0)
    all_of_1 = AllOf([if_then_else_0])



# Generated at 2022-06-26 10:15:46.666141
# Unit test for constructor of class Not
def test_Not():
    all_items_0 = Not()

# Generated at 2022-06-26 10:15:47.460935
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # case 0
    test_case_0()

# Generated at 2022-06-26 10:15:50.374400
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf(all_of=[])


# Generated at 2022-06-26 10:15:53.485443
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = [NeverMatch(), NeverMatch()]
    one_of_0 = OneOf(one_of)


# Generated at 2022-06-26 10:15:56.302107
# Unit test for constructor of class Not
def test_Not():
    # Default arguments
    not_0 = Not(negated=None)

    # Non-default arguments
    not_1 = Not(negated=None)

# Generated at 2022-06-26 10:16:07.574072
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        never_match_0 = NeverMatch(allow_null=True)
    with pytest.raises(AssertionError):
        never_match_1 = NeverMatch(label='')
    with pytest.raises(AssertionError):
        never_match_2 = NeverMatch(name='')
    with pytest.raises(AssertionError):
        never_match_3 = NeverMatch(description='')
    with pytest.raises(AssertionError):
        never_match_4 = NeverMatch(error_messages={})
    never_match_5 = NeverMatch()
    with pytest.raises(AssertionError):
        never_match_6 = NeverMatch(name='')

# Generated at 2022-06-26 10:16:12.475243
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([Any()])
    one_of_1 = OneOf([Any()])
    any_0 = one_of_0.validate(one_of_1)


# Generated at 2022-06-26 10:16:18.235570
# Unit test for constructor of class OneOf
def test_OneOf():
    all_of_0 = [NeverMatch()]
    all_of_1 = [NeverMatch(), NeverMatch()]
    all_of_2 = [NeverMatch(), NeverMatch(), NeverMatch()]
    one_of_0 = OneOf(all_of_0)
    one_of_1 = OneOf(all_of_1)
    one_of_2 = OneOf(all_of_2)


# Generated at 2022-06-26 10:16:25.531170
# Unit test for constructor of class OneOf
def test_OneOf():
    # OneOf(one_of=)
    # Create an instance of OneOf
    one_of_0 = OneOf(one_of=[OneOf(one_of=[])])


# Generated at 2022-06-26 10:16:31.177321
# Unit test for constructor of class OneOf
def test_OneOf():
    field_0 = OneOf([Any()])
    str_0 = OneOf([Any()]).validate(field_0)
    field_1 = Field()
    dict_0 = OneOf([Any()]).validate(field_0)


# Generated at 2022-06-26 10:16:33.848098
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    obj = OneOf([NeverMatch(), Field()])
    obj._validated("foobar", strict=True)


# Generated at 2022-06-26 10:16:40.852866
# Unit test for constructor of class AllOf
def test_AllOf():
    one_of_0 = OneOf([])
    one_of_1 = OneOf([True])
    one_of_2 = OneOf([one_of_0, one_of_1])
    one_of_3 = OneOf([one_of_1, False])
    all_of_0 = AllOf(one_of_3)
    all_of_1 = AllOf([all_of_0])
    all_of_2 = AllOf([all_of_1, one_of_2])
    all_of_3 = AllOf([all_of_0, all_of_1, all_of_2, one_of_3])

# Generated at 2022-06-26 10:16:42.315599
# Unit test for constructor of class Not
def test_Not():
    pass


# Generated at 2022-06-26 10:16:45.855490
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    any_0 = never_match_0.validate(never_match_0)


# Generated at 2022-06-26 10:16:48.090704
# Unit test for constructor of class OneOf
def test_OneOf():
    some_field_0 = OneOf(one_of=[])
    some_field_0.validate(some_field_0)


# Generated at 2022-06-26 10:16:51.694448
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    any_0 = never_match_0.validate(never_match_0)


# Generated at 2022-06-26 10:16:54.911301
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    any_0 = never_match_0.validate(never_match_0)


# Generated at 2022-06-26 10:16:59.261918
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Allocate and initialize an empty NeverMatch instance
    never_match_0 = NeverMatch()
    # Allocate and initialize an empty Any instance
    any_0 = never_match_0.validate(never_match_0)
    # Add in our checks
    assert(any_0 == None)
    assert(True)


# Generated at 2022-06-26 10:17:07.711219
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf(
        [
            NeverMatch(),
            NeverMatch(),
        ],
    )
    with pytest.raises(ValidationError, match="Must not match."):
        any_0 = one_of_0.validate(one_of_0)


# Generated at 2022-06-26 10:17:11.389244
# Unit test for constructor of class Not
def test_Not():
    one_of_0 = OneOf([])
    not_0 = Not(one_of_0)
    val = not_0.validate(one_of_0)
    assert val is None


# Generated at 2022-06-26 10:17:18.740764
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    assert never_match_0.label == ""
    assert never_match_0.description == ""
    assert never_match_0.errors == {'never': 'This never validates.'}
    assert never_match_0.name == "NeverMatch"



# Generated at 2022-06-26 10:17:20.980475
# Unit test for constructor of class Not
def test_Not():
  not_0 = Not(
        negated=None,
        )


# Generated at 2022-06-26 10:17:33.575077
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause_0 = NeverMatch()
    then_clause_0 = NeverMatch()
    else_clause_0 = NeverMatch()
    if_then_else_0 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    if_then_else_1 = IfThenElse(if_clause_0)
    if_then_else_2 = IfThenElse(else_clause_0)
    if_then_else_3 = IfThenElse(if_clause_0, then_clause_0, else_clause_0)
    if_then_else_4 = IfThenElse(if_clause_0)
    if_then_else_5 = IfThenElse(else_clause_0)

# Generated at 2022-06-26 10:17:35.938009
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([None])
    assert one_of_0 is not None


# Generated at 2022-06-26 10:17:42.668781
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_0 = OneOf(one_of=[None])
    one_1 = one_0.validate(one_0)
    two_0 = OneOf(one_of=[None, None, None])
    two_1 = two_0.validate(two_0)
    three_0 = OneOf(one_of=[None, None, None, None, None])
    three_1 = three_0.validate(three_0)


# Generated at 2022-06-26 10:17:47.573125
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test empty first parameter
    fields = []
    clause = OneOf(fields)
    assert clause is not None


# Generated at 2022-06-26 10:17:50.561416
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(all_of=[any_0])
    one_of_1 = OneOf(one_of=[any_0])
    one_of_2 = OneOf(all_of=[])

# Generated at 2022-06-26 10:18:00.645348
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf(one_of=[])
    one_of_1 = OneOf(
        one_of=[
            NeverMatch(),
            AllOf(all_of=[NeverMatch(), NeverMatch()]),
            AllOf(all_of=[NeverMatch()]),
            AllOf(all_of=[Not(negated=NeverMatch()), NeverMatch()]),
            AllOf(all_of=[Not(negated=NeverMatch())]),
            Not(negated=NeverMatch()),
            OneOf(one_of=[NeverMatch()]),
            OneOf(one_of=[AllOf(all_of=[NeverMatch()])]),
            OneOf(one_of=[Not(negated=NeverMatch())]),
        ]
    )

# Generated at 2022-06-26 10:18:10.676486
# Unit test for constructor of class Not

# Generated at 2022-06-26 10:18:11.163697
# Unit test for constructor of class OneOf
def test_OneOf():
    pass

# Generated at 2022-06-26 10:18:14.304969
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([Any()])
    one_of_1 = OneOf(None)
    one_of_2 = OneOf([Any(), Any()])



# Generated at 2022-06-26 10:18:19.718224
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_0 = OneOf([])
    any_0 = one_of_0.validate(one_of_0)


# Generated at 2022-06-26 10:18:23.463347
# Unit test for constructor of class AllOf
def test_AllOf():
    # Create a new instance of the class to test
    all_of_0 = AllOf(all_of=3,)


# Generated at 2022-06-26 10:18:26.772640
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    never_match_1 = NeverMatch(error="never")
    assert never_match_0 is not None
    assert never_match_1 is not None


# Generated at 2022-06-26 10:18:30.096694
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    case_0 = OneOf(one_of=[test_case_0()])
    case_0.validate(case_0)


# Generated at 2022-06-26 10:18:38.786280
# Unit test for constructor of class Not
def test_Not():
    database_string_0 = "0"
    database_string_1 = database_string_0
    negated_0 = Not(database_string_1)
    any_0 = negated_0.validate(None)
    # Test method validate()
    negated_1 = Not(None)
    negated_0.validate(negated_1)
    negated_0.validate(negated_1)
    negated_0.validate(negated_1)


# Generated at 2022-06-26 10:18:42.195934
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_0 = AllOf([])
    assert all_of_0


# Generated at 2022-06-26 10:18:44.945960
# Unit test for constructor of class Not
def test_Not():
    not_1 = Not(negated=Field())
    not_1.validate(Not(negated=Field()))

# Generated at 2022-06-26 10:18:53.880269
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()


# Generated at 2022-06-26 10:18:59.066415
# Unit test for constructor of class Not
def test_Not():
  # Arrange
  negated = Field()

  # Act

# Generated at 2022-06-26 10:19:01.872203
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # type: () -> None
    one_of_1 = OneOf([])
    any_1 = one_of_1.validate(one_of_1)

# Generated at 2022-06-26 10:19:14.564436
# Unit test for constructor of class Not
def test_Not():
    # Return a new type that forces the value to be exactly the opposite of the given type.
    #
    #
    # --------
    #
    # Like the built-in `typesystem.Not` field, but with a slightly nicer error message
    # by default.
    #
    # Args:
    #     negated (type): The type that the returned type must not match.
    #     error (str): (Optional) A custom error message for the field.
    #
    # Returns:
    #     type: a type that is the opposite of ``negated``

    negated_0 = None
    error_0 = None
    not_0 = Not(negated=negated_0, error=error_0)
    # not_0 = Not(negated=negated_0, error=error_0)

# Unit test

# Generated at 2022-06-26 10:19:16.127150
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_case_0()


# Generated at 2022-06-26 10:19:18.752960
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated = "")



# Generated at 2022-06-26 10:19:22.823865
# Unit test for constructor of class Not
def test_Not():
    test_case_0()


if __name__ == "__main__":
    import sys

    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-26 10:19:26.897718
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match_0 = NeverMatch()
    str_0 = never_match_0.to_representation(never_match_0)


# Generated at 2022-06-26 10:19:33.913097
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_0 = OneOf([])
    # Testing for value errors
    with pytest.raises(ValueError):
        OneOf([], allow_null=False)
    with pytest.raises(ValueError):
        OneOf([], allow_null=True)
    all_of_0 = AllOf([])
    # Testing for value errors
    with pytest.raises(ValueError):
        AllOf([], allow_null=False)
    with pytest.raises(ValueError):
        AllOf([], allow_null=True)
    not_0 = Not(None)
    # Testing for value errors
    with pytest.raises(ValueError):
        Not(None, allow_null=False)
    with pytest.raises(ValueError):
        Not(None, allow_null=True)


# Generated at 2022-06-26 10:19:47.772788
# Unit test for constructor of class Not
def test_Not():
    # Cannot directly instantiate abstract class Not with abstract methods validate
    with pytest.raises(TypeError):
        Not()
        # test if member type is correct
        assert isinstance(Not().negated, Field)
    # test object
    negated = Field()
    negated.errors = {'error': 'This never validates.'}
    never_match = Not(negated)
    # test error message
    assert never_match.errors['negated'] == 'Must not match.'
    # test type of member fields
    assert isinstance(never_match.negated, Field)
    assert never_match.negated.errors == {'error': 'This never validates.'}
    # test for None value in negated
    with pytest.raises(TypeError):
        never_match = Not(None)

# Unit test