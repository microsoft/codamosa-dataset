

# Generated at 2022-06-24 10:38:35.451896
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
    if_clause = Integer(),
    then_clause = String(),
    else_clause = Float()
    )
    field.validate(1)


# Generated at 2022-06-24 10:38:42.102862
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import String, Integer

    field = AllOf([String(), Integer()])
    s = "s"
    field.validate(s)
    assert field.validate(s) == "s"
    i = 2
    field.validate(i)
    assert field.validate(i) == 2
    field.validate(1.0)
    assert field.validate(1.0) == 1.0


# Generated at 2022-06-24 10:38:43.912096
# Unit test for constructor of class OneOf
def test_OneOf():
    assert 1 == 1
    iden = OneOf(None, 
        one_of = [
        Field(a=2),
        ])

test_OneOf()

# Generated at 2022-06-24 10:38:44.829803
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert None == None


# Generated at 2022-06-24 10:38:51.612708
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any()).validate(123) == 123
    assert IfThenElse(if_clause=NeverMatch()).validate(123) == 123
    assert IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch(), else_clause=Any()).validate(123) == 123
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any(), else_clause=NeverMatch()).validate(123) == 123
    assert IfThenElse(if_clause=Any(), then_clause=NeverMatch(), else_clause=Any()).validate(123) == 123
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=NeverMatch()).validate(123) == 123
    assert IfThen

# Generated at 2022-06-24 10:38:56.270210
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class MyField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value+1
    f1 = AllOf(all_of=[MyField(), MyField()])
    assert f1.validate(1) == 3

# Generated at 2022-06-24 10:39:04.780122
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Initializes object with IfThenElse fields
    if_clause = Field(validators=None)
    then_clause = Field(validators=None)
    else_clause = Field(validators=None)
    condition = IfThenElse(if_clause, then_clause, else_clause)

    # Asserts if_clause is initialized
    assert condition.if_clause == if_clause

    # Asserts then_clause is initialized
    assert condition.then_clause == then_clause

    # Asserts else_clause is initialized
    assert condition.else_clause == else_clause

# Generated at 2022-06-24 10:39:05.689804
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # function_body
    pass

# Generated at 2022-06-24 10:39:08.546985
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    class TestFields(Field):
        pass
    field = NeverMatch()
    with pytest.raises(ValidationError) as excinfo:
        field.validate(1)
    assert excinfo.value.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:39:10.414911
# Unit test for constructor of class AllOf
def test_AllOf():
    list_ = Field()
    str_ = Field()
    a = AllOf(all_of = [list_, str_])
    # Not a JSON schema compatible field
    assert (a.allow_null != True)


# Generated at 2022-06-24 10:39:13.328343
# Unit test for method validate of class Not
def test_Not_validate():
    not_p = Not(negated=int)
    assert not_p.validate("hello") == "hello"
    try:
        not_p.validate(1)
    except AssertionError as e:
        assert e.args[0] == "Must not match."
    else:
        assert False

# Generated at 2022-06-24 10:39:16.059133
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = 5
    result = IfThenElse(Field()).validate(5)
    assert result == value
    assert result == value

# Generated at 2022-06-24 10:39:19.344449
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    instance = NeverMatch(description='test_NeverMatch_validate')
    with pytest.raises(Exception) as excinfo:
        instance.validate("test_NeverMatch_validate")
    assert "This never validates." in str(excinfo.value)


# Generated at 2022-06-24 10:39:23.144666
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[Any()])
    field.validate(None)
    field.validate(1)
    field.validate(1.2)
    field.validate("hello")
    field.validate(["hello"])

# Generated at 2022-06-24 10:39:31.131035
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    res = OneOf({
        "oneOf": [
            {"type": "string"},
            {"type": "number"},
            {"type": "boolean"},
        ]
    }).validate(1)
    assert res == 1

    try:
        OneOf({
            "oneOf": [
                {"type": "string"},
                {"type": "number"},
                {"type": "boolean"},
            ]
        }).validate(1.1)
        assert False
    except ValidationError:
        pass

    try:
        OneOf({
            "oneOf": [
                {"type": "string"},
                {"type": "number"},
                {"type": "boolean"},
            ]
        }).validate(1, strict=True)
        assert False
    except ValidationError:
        pass


#

# Generated at 2022-06-24 10:39:34.356717
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Any())
    assert isinstance(not_field, Not)
    assert isinstance(not_field.negated, Any)

# Generated at 2022-06-24 10:39:36.950090
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    instance = NeverMatch()
    with raises(AssertionError, match="This never validates."):
        instance.validate(None, strict=False)

# Generated at 2022-06-24 10:39:38.238238
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert str(NeverMatch()) == "<NeverMatch>"


# Generated at 2022-06-24 10:39:39.750663
# Unit test for constructor of class Not
def test_Not():
    not_test = Not(negated="1")
    assert not_test.negated  == "1"

# Generated at 2022-06-24 10:39:40.893294
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(1) == 1

# Generated at 2022-06-24 10:39:43.937013
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import Integer

    v = Not(negated=Integer())
    assert v.validate("a") == "a"
    try:
        v.validate(1)
        assert False
    except ValueError:
        pass


# Generated at 2022-06-24 10:39:50.475796
# Unit test for constructor of class OneOf
def test_OneOf():
    import pytest
    from typesystem.fields import Boolean
    myfield = OneOf([Boolean()])
    with pytest.raises(AssertionError):
        myfield = OneOf([Boolean()], allow_null=True)
    with pytest.raises(AssertionError):
        myfield = OneOf([Boolean()], strict=True)



# Generated at 2022-06-24 10:39:56.893999
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test passing validation
    field = OneOf([
        types.Integer()
    ])

    assert field.validate(1) == 1

    # Test validation error when no sub-fields match
    field = OneOf([
        types.Integer(),
        types.String()
    ])

    with pytest.raises(types.ValidationError):
        field.validate("hi")

    # Test validation error when more than one sub-field matches
    field = OneOf([
        types.Integer(),
        types.String()
    ])

    with pytest.raises(types.ValidationError):
        field.validate("")


# Generated at 2022-06-24 10:39:58.521041
# Unit test for constructor of class Not
def test_Not():
    s = Not(negated=Field())
    assert s.negated
    def fails_to_create_Without_negated_specified():
        s = Not()
    fails_to_create_Without_negated_specified()

# Generated at 2022-06-24 10:39:59.806258
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # TODO: should we test this?
    pass

# Generated at 2022-06-24 10:40:04.377489
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value = 1
    strict = True
    if_clause = Integer()
    then_clause = Integer()
    else_clause = Integer()
    f = IfThenElse(if_clause, then_clause, else_clause)
    result = f.validate(value, strict)

    assert result == value



# Generated at 2022-06-24 10:40:09.501453
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    # Check attributes
    assert never_match.errors == {"never": "This never validates."}
    assert never_match.name is None
    assert never_match.description is None
    assert never_match.allow_null is None
    assert never_match.default is None
    assert never_match.serialized_name is None


# Generated at 2022-06-24 10:40:11.252598
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Any()])
    assert field.one_of == [Any()]

# Generated at 2022-06-24 10:40:13.825792
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():

    field = NeverMatch()

    with pytest.raises(ValidationError) as excinfo:
        field.validate(None)
    assert excinfo.match("This never validates.")


# Generated at 2022-06-24 10:40:15.598810
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    def test_NeverMatch_1() -> None:
        field = NeverMatch()
        assert field.allow_null is False



# Generated at 2022-06-24 10:40:22.286808
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    class A(Field):
        def validate(self, value, **kwargs):
            return value

    class B(Field):
        def validate(self, value, **kwargs):
            return value
    
    test_case = [
        # test 0
        IfThenElse(A(), B()).validate(1),

        # test 1
        IfThenElse(B(), A()).validate(1),

        # test 2
        IfThenElse(A(), B(), B()).validate(1),

        # test 3
        IfThenElse(B(), A(), A()).validate(1),
    ]




# Generated at 2022-06-24 10:40:23.605634
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any()])
    field.validate(10)

# Generated at 2022-06-24 10:40:29.660634
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    from typesystem.fields import OneOf
    a = Integer()
    b = Integer(maximum=100)
    c = Integer()

    if_then_else = IfThenElse(if_clause=OneOf([a,b]),then_clause=c)

    assert if_then_else.validate(5) == 5
    assert if_then_else.validate(105) == 105
    with raises(ValidationError) as e:
        if_then_else.validate('a')

# Generated at 2022-06-24 10:40:38.493149
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    new_if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert new_if_then_else.if_clause == if_clause
    assert new_if_then_else.then_clause == then_clause
    assert new_if_then_else.else_clause == else_clause

# Generated at 2022-06-24 10:40:39.409188
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-24 10:40:41.225258
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())

    assert not_field.negated

# Generated at 2022-06-24 10:40:46.034524
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class T(AllOf):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__([Any() for _ in range(4)], **kwargs)
    t = T()
    assert t.validate([1, 2, 3, 4, 5])
    assert t.validate('')
    assert t.validate('hello')


# Generated at 2022-06-24 10:40:49.949540
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:40:54.563377
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    test = IfThenElse(if_clause, then_clause, else_clause)
    value = 'string'
    strict = False
    assert test.validate(value, strict=strict) == value


# Generated at 2022-06-24 10:40:56.850385
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any()])
    field.validate(value=None)



# Generated at 2022-06-24 10:40:57.867605
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any(max_length=10), Any(min_length=5)])
    field.validate("123456")


# Generated at 2022-06-24 10:40:59.263051
# Unit test for constructor of class Not
def test_Not():
    result = Not(negated=None)
    assert result



# Generated at 2022-06-24 10:41:02.332537
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of=OneOf(one_of=["one","two","three"])
    assert one_of.validate("one")=="one"
    assert one_of.validate("four")=="no_match"

# Generated at 2022-06-24 10:41:05.719174
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    obj = OneOf([Any()])
    expected_value = []
    expected_error = None
    value, error = obj.validate_or_error(expected_value)
    assert value == expected_value
    assert error == expected_error



# Generated at 2022-06-24 10:41:08.809783
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Invalid
    from typesystem import Boolean

    all_of = AllOf([Boolean(minimum=True), Boolean(maximum=True)])
    assert all_of.validate(True)
    assert all_of.validate(False) is Invalid

# Generated at 2022-06-24 10:41:11.060802
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ite = IfThenElse(Any(), Any())
    assert ite.validate(1) == 1

# Generated at 2022-06-24 10:41:16.999057
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # inputs
    one_of = [Int(), Str()]
    value = 1
    strict = False

    # expected outputs
    expected_match_count = 1
    expected_validated = 1

    # test
    f = OneOf(one_of)
    validated, error = f.validate_or_error(value, strict=strict)
    assert expected_match_count == 1
    assert expected_validated == validated

# Generated at 2022-06-24 10:41:24.509857
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    print("testing AllOf.validate()")
    # test to validate integer
    all_of = AllOf([Field(int),Field(type="int"),Field(int,required=True)])
    assert all_of.validate(1) == 1
    assert all_of.validate(True) == True
    # test to validate string
    all_of = AllOf([Field(str),Field(str,min_length=3)])
    assert all_of.validate("abc") == "abc"
    assert all_of.validate("ab") == "ab"


# Generated at 2022-06-24 10:41:26.231951
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    validator = NeverMatch()
    assert validator.validate(None) == {}


# Generated at 2022-06-24 10:41:30.887170
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=Required()). validate(0) == 0
    assert Not(negated=Required()). validate(None) == None
    assert Not(negated=Required()). validate('') == ''
    assert Not(negated=Required()). validate(1) == 1
    assert Not(negated=Required()). validate(True) == True
    assert Not(negated=Required()). validate(False) == False

# Generated at 2022-06-24 10:41:34.226583
# Unit test for constructor of class OneOf
def test_OneOf():
    schema=OneOf([Str(),Int()])
    assert schema.validate("test")=="test"
    assert schema.validate(1)==1


# Generated at 2022-06-24 10:41:36.573400
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[])
    assert field.one_of == []


# Generated at 2022-06-24 10:41:40.257126
# Unit test for constructor of class OneOf
def test_OneOf():
    # For coverage of __init__
    test_type = OneOf([types.Integer()])
    assert test_type.one_of == [types.Integer()]
    assert 'validate' in dir(test_type)



# Generated at 2022-06-24 10:41:41.409914
# Unit test for constructor of class AllOf
def test_AllOf():
    Field = AllOf([])

# Generated at 2022-06-24 10:41:44.285244
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = []
    assert(OneOf(one_of))
    # assert(OneOf(one_of) is not None)



# Generated at 2022-06-24 10:41:46.950851
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    t = IfThenElse(if_clause=True, then_clause=True, else_clause=False)
    assert t.if_clause == True
    assert t.then_clause == True
    assert t.else_clause == False

# Generated at 2022-06-24 10:41:49.746233
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate(None, strict=True) == None
    assert field.validate(None) == None
    assert field.validate(1, strict=True) == 1
    assert field.validate(1) == 1


# Generated at 2022-06-24 10:41:52.294924
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field())
    try:
        field.validate(2)
    except:
        print("error in Not_validate method")


# Generated at 2022-06-24 10:41:53.397244
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()



# Generated at 2022-06-24 10:41:58.443597
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        Int(),
        String(),
        Array(items=String()),
    )
    value = field.validate(1, True)
    assert value == '1'
    value = field.validate('1', True)
    assert value == '1'
    value = field.validate([1], True)
    assert value == ['1']



# Generated at 2022-06-24 10:42:02.116439
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(Number(), Number())
    assert schema.validate(15) == 15
    assert schema.validate("15") == 15
    assert schema.validate(-15) == -15
    assert schema.validate("-15") == -15

# Generated at 2022-06-24 10:42:04.783699
# Unit test for constructor of class Not
def test_Not():
    not_one_of2 = Not(OneOf([Int(), Str()]), name="test")
    assert not_one_of2.name == "test"

    not_one_of = Not(OneOf([Int(), Str()]))
    assert not_one_of.name == "field"


# Generated at 2022-06-24 10:42:09.591189
# Unit test for method validate of class Not
def test_Not_validate():
    # Test: `validate` method
    # Case: No error
    # Expected: return value
    assert Not(Any()).validate(1) == 1

    # Test: `validate` method
    # Case: Error
    # Expected: raise ValidationError
    with pytest.raises(ValidationError):
        Not(Any(max_length=0)).validate("Hello")

# Generated at 2022-06-24 10:42:15.266229
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def _get_IfThenElse(if_clause, then_clause, else_clause):
        return IfThenElse(
            if_clause=if_clause, then_clause=then_clause, else_clause=else_clause
        )
    if_clause = NeverMatch()
    then_clause = String()
    else_clause = String()
    obj = _get_IfThenElse(if_clause, then_clause, else_clause)
    res = obj.validate('1')
    expected = '1'
    assert res == expected

# Generated at 2022-06-24 10:42:18.995573
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    value = 10
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    assert IfThenElse(if_clause,then_clause,else_clause).validate(value) == value

# Generated at 2022-06-24 10:42:22.589072
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # pylint: disable=no-value-for-parameter,unexpected-keyword-arg
    assert NeverMatch(name="test_field").name == "test_field"



# Generated at 2022-06-24 10:42:25.057878
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	field = NeverMatch(description="description")
	assert field.description == "description"
	assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:42:26.985596
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(Field.ValidationError):
        field.validate(1)



# Generated at 2022-06-24 10:42:28.987675
# Unit test for constructor of class OneOf
def test_OneOf():
  # test_OneOf_init_properties
  i = OneOf(one_of = [Any()])
  assert i.one_of == [Any()]

# Generated at 2022-06-24 10:42:31.253723
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(field.validation_error) as exc_info:
        field.validate("abc")
    assert "never" in str(exc_info.value)


# Generated at 2022-06-24 10:42:32.404528
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of = [])
    assert field.one_of is not None


# Generated at 2022-06-24 10:42:39.606531
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test for method validate of class IfThenElse
    """
    from typesystem.fields import Boolean, Integer, String

    if_clause = Integer().min(1)
    then_clause = String()
    else_clause = Boolean()
    a = IfThenElse(if_clause, then_clause, else_clause)
    assert a.validate(1) == "1"
    assert a.validate(0) == False



# Generated at 2022-06-24 10:42:40.226740
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True

# Generated at 2022-06-24 10:42:46.973394
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValueError):
        field.validate([1,2,3])
    with pytest.raises(ValueError):
        field.validate({"array":[1,2,3]})
    with pytest.raises(ValueError):
        field.validate(1)
    with pytest.raises(ValueError):
        field.validate(None)


# Generated at 2022-06-24 10:42:47.882863
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Field())

# Generated at 2022-06-24 10:42:49.136230
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(2)

# Generated at 2022-06-24 10:42:56.680455
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, Number, String

    field_oneof = OneOf([String(), Integer()], name="field_oneof")
    assert field_oneof.validate("value") == "value"

# Generated at 2022-06-24 10:43:00.917955
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=NeverMatch()).if_clause.errors == {"never": "This never validates."}
    assert IfThenElse(if_clause=NeverMatch()).then_clause.errors == None
    assert IfThenElse(if_clause=NeverMatch()).else_clause.errors == None

# Generated at 2022-06-24 10:43:03.448098
# Unit test for constructor of class Not
def test_Not():
    test = Not(None)
    assert test.negated == None
    assert test.errors ==  {"negated": "Must not match."}


# Generated at 2022-06-24 10:43:09.941892
# Unit test for constructor of class AllOf
def test_AllOf():
    class Field1(Field):
        pass
    class Field2(Field):
        pass
    class Field3(Field):
        pass
    f1 = Field1()
    f2 = Field2()
    f3 = Field3()
    myAllOf = AllOf([f1, f2, f3])
    assert myAllOf.all_of == [f1, f2, f3]


# Generated at 2022-06-24 10:43:18.467703
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    schema = IfThenElse(if_clause=typesystem.String(), then_clause=typesystem.Integer())
    # Check Type of an Exception
    my_val = "3"
    with pytest.raises(typesystem.ValidationError) as excinfo:
        schema.validate(my_val)
    assert excinfo.type == typesystem.ValidationError


# Generated at 2022-06-24 10:43:23.163115
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_field = fields.String()
    two_fields = fields.OneOf([one_field, fields.Boolean()])
    assert two_fields.validate("hello") == "hello"
    assert two_fields.validate(True) == True
    with pytest.raises(ValidationError):
        two_fields.validate(False)



# Generated at 2022-06-24 10:43:26.975949
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    print(field)
    with pytest.raises(AssertionError) as e_info:
        field = NeverMatch(name='test')


# Generated at 2022-06-24 10:43:30.005019
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[])
    value = None
    strict = False
    assert field.validate(value=value, strict=strict) == None


# Generated at 2022-06-24 10:43:33.053824
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert True


# Generated at 2022-06-24 10:43:35.692702
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch(
        name="test_NeverMatch_validate", description="Unit Test").validate(
        "") == "notvalid"


# Generated at 2022-06-24 10:43:38.007050
# Unit test for method validate of class Not
def test_Not_validate():
        not_field = Not(Any())
        assert not_field.validate(True) is True
        assert not_field.validate(False) is False
        assert not_field.validate(None) is None
        assert not_field.validate(1) == 1

# Test Case

# Generated at 2022-06-24 10:43:38.832762
# Unit test for constructor of class Not
def test_Not():
    a = Not(None)
    assert a

# Generated at 2022-06-24 10:43:41.314364
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer, Float, Union
    field = AllOf([Integer(), Float()])
    assert field.all_of == [Integer(), Float()]
    assert field.errors == {}
    assert field.metadata == {}


# Generated at 2022-06-24 10:43:44.478148
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch() is not None

# Unit tests for field constructor

# Generated at 2022-06-24 10:43:45.297237
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(None)
    assert field.validate(None) is None

# Generated at 2022-06-24 10:43:48.482657
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_object = OneOf([])
    assert one_of_object.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}


# Generated at 2022-06-24 10:43:51.511373
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(FieldValidationError):
        field.validate(1)


# Generated at 2022-06-24 10:43:54.003141
# Unit test for constructor of class Not
def test_Not():
    t = Not(Any())
    assert t.negated == Any()
    assert t.errors == {'negated': 'Must not match.'}



# Generated at 2022-06-24 10:43:55.317696
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated


# Generated at 2022-06-24 10:43:56.398985
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf

# Generated at 2022-06-24 10:43:59.695742
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(if_clause=True)
    IfThenElse(if_clause=True, then_clause=False)
    IfThenElse(if_clause=True, then_clause=False, else_clause=True)

# Generated at 2022-06-24 10:44:01.518810
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(AllOf([Any()]))

# Generated at 2022-06-24 10:44:03.425587
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer, String
    field1 = OneOf(one_of=[Integer(), String()])
    assert field1.validate(1) == 1


# Generated at 2022-06-24 10:44:05.177979
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert "never" in field.errors
    assert "this never validates" in field.errors["never"]


# Generated at 2022-06-24 10:44:07.676105
# Unit test for constructor of class Not
def test_Not():
    assert(Not(Any())).negated == Any()

# Generated at 2022-06-24 10:44:11.924779
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().name == 'NeverMatch'
    assert NeverMatch().description == ''
    assert NeverMatch().errors == {'never': 'This never validates.'}
    assert NeverMatch(required=True).required == True


# Generated at 2022-06-24 10:44:21.929816
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class Person:
        def __init__(self) -> None:
            pass
    class Student(Person):
        def __init__(self) -> None:
            super().__init__()
    class Employee(Person):
        def __init__(self) -> None:
            super().__init__()
    class PublicEmployee(Employee):
        def __init__(self) -> None:
            super().__init__()
    p = Person()
    s = Student()
    e = Employee()
    pe = PublicEmployee()
    scheme = AllOf([Employee, Person])
    scheme.validate(p)
    scheme.validate(s)
    scheme.validate(pe)
    scheme.validate(e)



# Generated at 2022-06-24 10:44:25.015088
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Field(constraints = [lambda x: x == 1])]
    all_of_field = AllOf(all_of = all_of)
    assert all_of_field.all_of == all_of


# Generated at 2022-06-24 10:44:28.732602
# Unit test for constructor of class AllOf
def test_AllOf():
    field_list = [ 
        Field(),
        Field(),
        Field(),
    ]
    field = AllOf(field_list)
    assert field.all_of == field_list


# Generated at 2022-06-24 10:44:30.890614
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = []
    item = {}
    field = AllOf(all_of)
    field.validate(item)



# Generated at 2022-06-24 10:44:34.078896
# Unit test for method validate of class Not
def test_Not_validate():
    # Declare parameters
    negated = Field()
    # Declare variables
    value = 1
    strict = False
    # Define function input
    not_instance = Not(negated)
    # Evaluate function output
    validate_output = not_instance.validate(value, strict)
    # Check for function output
    assert validate_output == 1

# Generated at 2022-06-24 10:44:35.144378
# Unit test for constructor of class Not
def test_Not():
    type = Not
    assert type is not None


# Generated at 2022-06-24 10:44:43.942857
# Unit test for constructor of class Not
def test_Not():
    # Given
    _list = ["abc"]
    _list.append(1)
    _dict = {
      "monday": "1",
      "tuesday": "2",
      "wednesday": "3",
      "thursday": "4",
      "friday": "5",
      "saturday": "6",
      "sunday": "7"
  }
    list_field = List(_list)
    dict_field = Dict(_dict)
    # When
    not_list = Not(list_field)
    not_dict = Not(dict_field)
    # Then
    assert not_list.negated is list_field
    assert not_dict.negated is dict_field

# Generated at 2022-06-24 10:44:48.335868
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf([]), OneOf)


# Generated at 2022-06-24 10:44:54.969197
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem
    import unittest
    import unittest.mock
    field = typesystem.fields.AllOf([])
    value = None
    strict = False
    with unittest.mock.patch.object(field, 'validate', return_value=None) as mock_validate:
        field.validate(value, strict)
        assert mock_validate.call_count == 0


# Generated at 2022-06-24 10:44:56.410864
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert(NeverMatch(__type__='a') is not None)


# Generated at 2022-06-24 10:44:58.704113
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([String()]).validate("value") == "value"
    try:
        AllOf([String(), Boolean()]).validate("value")
    except:
        return
    assert False


# Generated at 2022-06-24 10:45:01.686781
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Try to validate
    try:
        NeverMatch().validate(1)
    # Catch assertion error and return false
    except AssertionError:
        return False
    # If not caught return True
    else:
        return True


# Generated at 2022-06-24 10:45:03.984721
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    AllOf([Any()]).validate(1)


# Generated at 2022-06-24 10:45:05.756659
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([Any(), Any(), Any()])
    assert f.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-24 10:45:08.937362
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # create instance of class NeverMatch with arguments
    args = {}
    nevermatch = NeverMatch(**args)


# Generated at 2022-06-24 10:45:13.056675
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    print("Inside test_AllOf_validate function")
    a = AllOf([1, 2, 3])
    print(a.validate(0))
    print(a.validate(1))
    print(a.validate(2))
    print(a.validate(3))
    print(a.validate(4))


# Generated at 2022-06-24 10:45:15.222549
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    t = NeverMatch()
    with pytest.raises(AssertionError):
        t.validate("Hi")


# Generated at 2022-06-24 10:45:18.480653
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():

    # Creation of a test object
    obj = NeverMatch()

    # Try to validate a field
    with pytest.raises(AssertionError):
        obj.validate(value = 123)


# Generated at 2022-06-24 10:45:24.769328
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    case_1 = IfThenElse(if_clause=Field(), then_clause=Field())
    assert isinstance(case_1.then_clause, Field)
    assert isinstance(case_1.else_clause, Any)
    case_2 = IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    assert isinstance(case_2.then_clause, Field)
    assert isinstance(case_2.else_clause, Field)

# Generated at 2022-06-24 10:45:33.389301
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    # Test the constructor for class AllOf
    # Default arguments for AllOf
    all_of0 = AllOf([String()])
    assert all_of0.all_of == [String()]
    assert all_of0.metadata == {}
    # Non-default arguments for AllOf
    all_of1 = AllOf([String()], description="some description")
    assert all_of1.all_of == [String()]
    assert all_of1.metadata == {"description": "some description"}


# Generated at 2022-06-24 10:45:34.586641
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(None) is None

# Generated at 2022-06-24 10:45:36.645877
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError):
        field.validate(None)



# Generated at 2022-06-24 10:45:42.714049
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = lambda x: True
    then_clause = lambda x: x + 1
    else_clause = lambda x: x + 2
    field = IfThenElse(if_clause,then_clause,else_clause)
    value = field.validate(3)
    assert value == 4

# Generated at 2022-06-24 10:45:44.546089
# Unit test for constructor of class Not
def test_Not():
    assert Not


# Generated at 2022-06-24 10:45:54.613119
# Unit test for method validate of class Not
def test_Not_validate():
    # Test: First case where the negated field is not matched by value
    not_field = Not(Any())
    assert not_field.validate(1) == 1

    # Test: Second case where the negated field is matched by value
    not_field = Not(Int())
    try:
        not_field.validate(1)
    except Exception as e:
        assert str(e) == 'Validation error: Must not match'

    # Test: Third case where the negated field is not matched by value with strict mode
    not_field = Not(String())
    try:
        not_field.validate(1, strict=True)
    except Exception as e:
        assert str(e) == 'Validation error: Must not match'

    # Test: Fourth case where the negated field is not matched by value
    not_

# Generated at 2022-06-24 10:45:56.481033
# Unit test for constructor of class OneOf
def test_OneOf():
    sub_field = OneOf([NeverMatch(), AlwaysMatch()])
    assert sub_field.one_of[0] == NeverMatch()

# Generated at 2022-06-24 10:46:07.713725
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Schema, Integer
    from gaia_sdk.graphql.request.enumeration.RitualState import RitualState
    from gaia_sdk.graphql.request.enumeration.RuntimeState import RuntimeState

    one_of = OneOf([Integer(), RitualState()])
    schema = Schema(one_of)
    assert schema.validate(1) == 1
    assert schema.validate(2) == 2
    assert schema.validate("START") == "START"
    assert schema.validate("STOP") == "STOP"
    assert schema.validate("STOPPED") == "STOPPED"
    assert schema.validate("STARTING") == "STARTING"
    assert schema.validate("STOPPING") == "STOPPING"

# Generated at 2022-06-24 10:46:11.062503
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    F = NeverMatch
    assert F.errors['never'] == "This never validates."
    f = F()


# Generated at 2022-06-24 10:46:18.904838
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # case 1: validation successful
    if_clause = Field(primitive_type=str)
    then_clause = Field(primitive_type=str)
    else_clause = Field(primitive_type=int)
    field = IfThenElse(if_clause, then_clause, else_clause)
    value = "test_str"
    ret = field.validate(value)
    assert ret == value

    # case 2: validation error
    value = 1
    with pytest.raises(exceptions.ValidationError) as e:
        field.validate(value)

# Generated at 2022-06-24 10:46:21.840021
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class T(OneOf):

        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
            self.one_of = [String()]

    t = T()
    t.validate("123")


# Generated at 2022-06-24 10:46:33.606901
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class Obj(Field):
        def __init__(self, name, **kwargs):
            super().__init__(name, **kwargs)
            self.name = name

        def validate(self, value, strict=False):
            if value == self.name:
                return self.name
            else:
                return None

    one_of_list = [Obj('1'), Obj('2'), Obj('3')]
    sut = OneOf(one_of_list)
    for obj in one_of_list:
        assert sut.validate(obj.name) == obj.name

    assert sut.validate('4') is None
    assert sut.validate(None) is None

    one_of_list.append(Obj('1'))
    assert sut.validate('1') is None

# Generated at 2022-06-24 10:46:36.256052
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(negated=Any())
    assert not_.validate('v') == 'v'
    

# Generated at 2022-06-24 10:46:38.632690
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(TypeError):
        NeverMatch(allow_null=True)


# Generated at 2022-06-24 10:46:45.979211
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.types import String

    class XField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "x"

    class YField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "y"

    field = OneOf([XField(), YField()])

    # validates correctly
    try:
        field.validate("x")
        field.validate("y")
    except:
        assert False

    # matches x, y and raises error
    try:
        field.validate("xyz")
        assert False
    except:
        pass

# Generated at 2022-06-24 10:46:47.661555
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate(None) is None


# Generated at 2022-06-24 10:46:57.723400
# Unit test for constructor of class AllOf
def test_AllOf():
    import json
    import typesystem
    assert repr(AllOf([Integer(min_value=1)])) == "AllOf([Integer(min_value=1)])"
    assert repr(AllOf([Integer(min_value=1)])) == "AllOf([Integer(min_value=1)])"
    test = AllOf([String(), Integer()])
    assert test.validate(1) == 1
    assert test.validate("1") == "1"
    try:
        test.validate(None)
        assert False, "should not allow null"
    except typesystem.ValidationError:
        pass

# Generated at 2022-06-24 10:46:58.465735
# Unit test for method validate of class Not
def test_Not_validate():
    pass

# Generated at 2022-06-24 10:46:58.862215
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-24 10:47:08.321355
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test(i, t, e):
        if_clause = Field()
        then_clause = Field()
        else_clause = Field()
        if_clause = Field()
        ite = IfThenElse(if_clause, then_clause, else_clause)
        try:
            ite.validate(i)
            assert if_clause.validate(i) == i
            assert then_clause.validate(t) == t
        except ValidationError:
            assert else_clause.validate(e) == e
    for n in range(10):
        i = random.randint(0,10)
        t = random.randint(0,100)
        e = random.randint(0,1000)
        test(i, t, e)



# Generated at 2022-06-24 10:47:12.156866
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test1 = IfThenElse(Boolean(), Integer(), **{'name': 'test field'})
    test2 = IfThenElse(Boolean(), **{'name': 'test field'})
    assert test1 is not None
    assert test2 is not None

# Generated at 2022-06-24 10:47:15.583631
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    allof = AllOf(all_of=None)
    value = 1
    strict = False
    result = allof.validate(value, strict)
    assert result == value


# Generated at 2022-06-24 10:47:17.538522
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        OneOf([])
    except Exception as e:
        assert False, "Exception raised during construction of OneOf"


# Generated at 2022-06-24 10:47:21.056219
# Unit test for constructor of class Not
def test_Not():
    field_1 = Object({'field_1': String()})
    field = Not(field_1)
    assert field.negated is field_1


# Generated at 2022-06-24 10:47:30.764511
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    import json
    import csv
    from typesystem import schema as s
    from typesystem import exceptions as e
    filename = "./test_data/test_schema_types/test_NeverMatch.json"
    with open(filename, "r") as f:
        json_text = json.load(f)
    s.Schema.validate_schema(json_text)
    f_csv = open("./test_data/test_schema_types/test_NeverMatch.csv", "r")
    csv_reader = csv.reader(f_csv, delimiter=',', quotechar='|')
    for row in csv_reader:
        try:
            s(json_text).validate(row)
        except e.ValidationError:
            continue
        else:
            assert False

#

# Generated at 2022-06-24 10:47:42.125094
# Unit test for method validate of class OneOf

# Generated at 2022-06-24 10:47:44.287995
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(AssertionError):
        field.validate(value=None, strict=False)


# Generated at 2022-06-24 10:47:49.347129
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate("helo") == "helo"



# Generated at 2022-06-24 10:47:50.890334
# Unit test for method validate of class Not
def test_Not_validate():
    nested_not_field = Not(negated=Any())
    nested_not_field.validate(value=None)



# Generated at 2022-06-24 10:48:01.153299
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """
    This can't be run as a unit test at the moment.
    """
#   x = IfThenElse(Int32(), Int32())
#   y = IfThenElse(Int32(), Int32(), Int32())
    pass
#   assert x is not None
#   assert y is not None
#   assert x.if_clause is not None
#   assert x.then_clause is not None
#   assert x.else_clause is not None
#   assert x.if_clause.__class__.__name__ == 'Int32'
#   assert x.then_clause.__class__.__name__ == 'Int32'
#   assert x.else_clause.__class__.__name__ == 'Any'
#   assert y.if_clause is not None
#   assert y.then

# Generated at 2022-06-24 10:48:12.468687
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import String
    from cawdrey.json_schema_fields import IfThenElse
    
    # Create two test fields
    field_1 = String(min_length=1)
    field_2 = String(min_length=2)
    field_3 = String(min_length=3)

    # field 1 and 2 are used
    if_clause_1 = IfThenElse(if_clause=field_1, then_clause=field_2)
    if_clause_1.validate('abc')

    # field 1 and 3 are used
    if_clause_2 = IfThenElse(if_clause=field_1, else_clause=field_3)
    if_clause_2.validate('abc')

    # raises error because field 1 is used and then clause is not defined

# Generated at 2022-06-24 10:48:13.375844
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String

# Generated at 2022-06-24 10:48:22.843824
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Integer, String

    # AllOf的子项必须都满足，故此处的例子不满足
    field = AllOf(all_of=[String(min_length=1), Integer()])
    try:
        field.validate('abc')
    except Exception as e:
        assert e.args == {'code': 'invalid', 'message': "Can't convert 'abc' to int"}
    try:
        field.validate(123)
    except Exception as e:
        assert e.args == {'code': 'invalid', 'message': "Value must have at least 1 character."}

# Generated at 2022-06-24 10:48:25.662431
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test for AllOf constructor
    all_of = AllOf([Any()])
    assert all_of.all_of == [Any()]

# Generated at 2022-06-24 10:48:31.364949
# Unit test for constructor of class Not
def test_Not():
    t = Not(negated=str)   
    assert t.negated == str
    assert t.errors == {'negated': 'Must not match.'}


# Generated at 2022-06-24 10:48:37.662920
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test typical use
    field = OneOf([
        Any()
    ])
    data = "a string"
    field.validate(data, strict=False)
    assert field.validate(validate_data, strict=False) == "a string"

    # Test failure
    field.validate(data, strict=False)
    assert field.validate(validate_data, strict=False) == "a string"
    assert field.validate(validate_data, strict=False) == "a string"

