

# Generated at 2022-06-24 10:38:31.166854
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])


# Generated at 2022-06-24 10:38:35.918740
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = String()
    then_clause = String()
    else_clause = String()
    x = IfThenElse(if_clause, then_clause, else_clause)
    assert x.if_clause == if_clause
    assert x.then_clause == then_clause
    assert x.else_clause == else_clause

# Generated at 2022-06-24 10:38:40.210449
# Unit test for constructor of class AllOf
def test_AllOf():
    assert [type(obj).__name__ for obj in AllOf.__init__.__closure__] == ['Field', 'typing', 'int', 'typing', 'int', 'typing']
    assert AllOf.__init__.__code__.co_varnames == ('self', 'all_of', '**kwargs')
    assert AllOf.__init__.__code__.co_argcount == 3


# Generated at 2022-06-24 10:38:42.145966
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(one_of=3)
    print(one_of)


# Generated at 2022-06-24 10:38:44.001713
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """Unit test for constructor of class IfThenElse"""
    new_ifthenelse = IfThenElse(String())
    if new_ifthenelse:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:38:46.939047
# Unit test for method validate of class Not
def test_Not_validate():
    class Person:
        def __init__(self, name):
            self.name = name
    p = Person('Homer')
    notField = Not(Field(label='first_name'))
    notField.validate(p)

# Generated at 2022-06-24 10:38:48.498861
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(None) == {"never": "This never validates."}


# Generated at 2022-06-24 10:38:53.056259
# Unit test for method validate of class Not
def test_Not_validate():
    if_clause = AllOf([Any()])
    then_clause = AllOf([Any()])
    else_clause = AllOf([Any()])
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    if_then_else.validate([1, 2, 3])
    with pytest.raises(IfThenElse.validation_error):
        if_then_else.validate(1)


# Generated at 2022-06-24 10:39:04.823109
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer, String
    from typesystem.fields import Object, Union, Boolean
    from typesystem.schema import Schema
    from typesystem.exceptions import ValidationError
    one_of = OneOf([Boolean(), Integer()])
    assert one_of.validate("foo") == 0
    assert one_of.validate(10) == 10
    assert one_of.validate("10") == 10
    assert one_of.validate(10.5) == 10
    assert one_of.validate(True) is True
    assert one_of.validate(False) is False
    class User(Schema):
        username = String(max_length=8)
        name = String()
        age = Integer(minimum=18, maximum=65)

# Generated at 2022-06-24 10:39:09.488584
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Constructor for class NeverMatch
    errors_1 = {'never': 'This never validates.'}
    assert NeverMatch(errors = errors_1).errors == errors_1
    # Constructor for class Field
    errors_2 = {'required': 'This field is required.'}
    assert NeverMatch(errors = errors_1).errors == errors_1
    # Check type of field errors
    assert isinstance(NeverMatch(errors = errors_1).errors, dict)


# Generated at 2022-06-24 10:39:16.263108
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Array, Boolean
    my_object = AllOf([Array(items=Boolean()), Array(min_length=2)])
    # <AllOf: AllOf(all_of=[<Array: Array(items=<Boolean: Boolean()>)>, <Array: Array(min_length=2)>])>
    assert str(my_object) == '<AllOf: AllOf(all_of=[<Array: Array(items=<Boolean: Boolean()>)>, <Array: Array(min_length=2)>])>'
    my_object = AllOf([Array(items=Boolean()), Array(min_length=2)])
    # <AllOf: AllOf(all_of=[<Array: Array(items=<Boolean: Boolean()>)>, <Array: Array(min_length=2)>])>


# Generated at 2022-06-24 10:39:21.806128
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    is_integer = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any()
    )

    assert type(is_integer).__name__ == 'IfThenElse'


# Generated at 2022-06-24 10:39:26.788268
# Unit test for constructor of class AllOf
def test_AllOf():
    intField = Integer()
    floatField = Float()
    allOf = AllOf([intField, floatField])

    # Test the validation of field allOf
    assert allOf.validate(1) == 1
    assert allOf.validate(1.1) == 1.1
    try:
        allOf.validate('a')
    except ValidationError:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:39:32.081446
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # setup
    field = NeverMatch()

    # exercise
    try:
        field.validate(None)
        assert False
    except FieldValidationError as err:
        # verify
        assert str(err) == '{"never": "This never validates."}'



# Generated at 2022-06-24 10:39:34.118180
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    ne = NeverMatch()
    assert(ne.errors == NeverMatch.errors)


# Generated at 2022-06-24 10:39:35.274947
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # TODO: 
    pass

# Generated at 2022-06-24 10:39:40.697632
# Unit test for method validate of class Not
def test_Not_validate():
    class TestField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise ValidationError("expected this error")

    field = Not(negated=TestField())

    result, error = field.validate_or_error(None)
    assert error == None
    assert result == None
    result, error = field.validate_or_error(1)
    assert error == None
    assert result == 1

# Generated at 2022-06-24 10:39:42.283710
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test = NeverMatch()
    assert test.errors == {"never":"This never validates."}


# Generated at 2022-06-24 10:39:46.514994
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    with pytest.raises(SystemExit):
        field = AllOf([Any()])
        field.validate(1)



# Generated at 2022-06-24 10:39:50.958147
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field_to_test = NeverMatch()
    expected_error = "This never validates."

    value_expected_to_match = None
    actual_error = field_to_test.validate(value_expected_to_match, strict=True)
    assert actual_error == expected_error


# Generated at 2022-06-24 10:39:55.547391
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.base import TypeSystem
    ts = TypeSystem()
    all_of = AllOf([ts.String(), ts.Integer()])
    try:
        all_of.validate({"foo": "bar"})
    except ValueError as e:
        assert "Validation error" in str(e)

    all_of.validate({"foo": "bar", "bar": 42})



# Generated at 2022-06-24 10:40:05.232591
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Int(), Str()]).validate(123) is None
    assert OneOf([Int(), Str()]).validate('123') is None
    try:
        OneOf([Int(), Str()]).validate(123.0)
    except Exception as exc:
        assert str(exc) == "Did not match any valid type."
    try:
        OneOf([Int()]).validate(123.0)
    except Exception as exc:
        assert str(exc) == "Must be an integer."
    try:
        OneOf([Int(), Str()]).validate(123.0, strict=True)
    except Exception as exc:
        assert str(exc) == "Must be an integer."

# Generated at 2022-06-24 10:40:05.754780
# Unit test for constructor of class Not
def test_Not():
    Not(None)

# Generated at 2022-06-24 10:40:11.199011
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = IfThenElse(String(), String(), String(), description='Test')
    if x.if_clause is None:
        raise Exception('Test failed.')
    if x.then_clause is None:
        raise Exception('Test failed.')
    if x.else_clause is None:
        raise Exception('Test failed.')
    if x.description != 'Test':
        raise Exception('Test failed.')


# Generated at 2022-06-24 10:40:13.136955
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    try:
        n.validate(1)
        assert False
    except:
        assert True
#

# Generated at 2022-06-24 10:40:16.095265
# Unit test for constructor of class Not
def test_Not():
    # Test Not with default parameters
    f_not = Not(Any())
    assert isinstance(f_not.negated, Any)

    # Test Not with valid parameters
    f_not = Not(Any(), allow_null=True)
    assert f_not.allow_null == True

# Generated at 2022-06-24 10:40:17.816558
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([1,2]).one_of == [1, 2]


# Generated at 2022-06-24 10:40:20.189565
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of = [])



# Generated at 2022-06-24 10:40:23.696665
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():

    # Arrange
    field = NeverMatch()

    # Act
    try:
        field.validate(None)
    except ValidationError as error:

        # Assert
        assert error.code == 'never'


# Generated at 2022-06-24 10:40:30.354417
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema = OneOf([
        Integer(minimum=5, maximum=10),
        Integer(minimum=50, maximum=100)
    ])
    assert schema.validate(7) == 7
    assert schema.validate(55) == 55
    try:
        schema.validate(3)
        assert False
    except:
        assert True
    try:
        schema.validate(200)
        assert False
    except:
        assert True
    try:
        schema.validate(55.5)
        assert False
    except:
        assert True


# Generated at 2022-06-24 10:40:35.017559
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field, NeverMatch)
    assert field.name == 'NeverMatch'
    assert field.errors == {'never': 'This never validates.'}

# Generated at 2022-06-24 10:40:40.986976
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause: Field = Field()
    then_clause: Field = Field()
    else_clause: Field = Field()
    ite: IfThenElse = IfThenElse(if_clause, then_clause, else_clause)
    value: typing.Any = None
    assert ite.validate(value) is None
    assert ite.validate("test") is None
    assert ite.validate(1) is None



# Generated at 2022-06-24 10:40:42.300618
# Unit test for constructor of class OneOf
def test_OneOf():
    input_object = OneOf([])
    assert input_object

# Generated at 2022-06-24 10:40:43.202076
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    NeverMatch()


# Generated at 2022-06-24 10:40:46.519530
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[String(max_length=10)])
    assert field.validate('test') == 'test'
    try:
        field.validate(True)
    except Exception:
        print('expectation exception thrown')


# Generated at 2022-06-24 10:40:51.880090
# Unit test for method validate of class Not
def test_Not_validate():
    item = Not(Any())
    res, err = item.validate_or_error("qwerty")
    assert err is None
    assert res == "qwerty"


# Generated at 2022-06-24 10:40:55.105011
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(if_clause=NeverMatch())
    assert isinstance(ite.if_clause, NeverMatch)
    assert isinstance(ite.then_clause, Any)
    assert isinstance(ite.else_clause, Any)

# Generated at 2022-06-24 10:41:03.254651
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    ite = IfThenElse(if_clause, then_clause, else_clause, description="test")
    print(ite.errors)
    print(ite.if_clause)
    print(ite.then_clause)
    print(ite.else_clause)
    assert ite.if_clause == if_clause
    assert ite.then_clause == then_clause
    assert ite.else_clause == else_clause

#
# test_IfThenElse()

# Generated at 2022-06-24 10:41:09.229643
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch(optional=True)
    result1, error1 = n.validate_or_error(None)
    result2, error2 = n.validate_or_error('none')
    result3, error3 = n.validate_or_error('', strict=False)

    assert result1 == None
    assert result2 == 'none'
    assert result3 == ''
    assert error1 == None
    assert error2 != None
    assert error3 != None


# Generated at 2022-06-24 10:41:11.061233
# Unit test for constructor of class AllOf
def test_AllOf():
    assert isinstance(AllOf([Any()]), AllOf)


# Generated at 2022-06-24 10:41:11.737026
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated = Any()) is not None

# Generated at 2022-06-24 10:41:15.137064
# Unit test for constructor of class Not
def test_Not():
    import typesystem
    actual = typesystem.Not(negated=typesystem.Integer(minimum=2))
    expected = typesystem.Not(negated=typesystem.Integer(minimum=2))
    assert actual == expected

# Generated at 2022-06-24 10:41:22.201498
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class ParentField(Field):
        def validate(self, value: typing.Any, strict: typing.Any = False) -> typing.Any:
            return value + 1

    class ChildField(Field):
        def validate(self, value: typing.Any, strict: typing.Any = False) -> typing.Any:
            return value + 2

    field = OneOf([ParentField(), ChildField()])

    assert field.validate(1) == 3
    assert field.validate(2) == 4

# Generated at 2022-06-24 10:41:30.435538
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise Exception("A")

    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise Exception("B")

    class C(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise Exception("C")

    allOf = AllOf(all_of=[A(), B(), C()])

    try:
        allOf.validate("")
    except Exception as e:
        err = e
    else:
        err = ""
    assert err == "A"



# Generated at 2022-06-24 10:41:39.662636
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([Any()]).validate("a") == "a"
    assert AllOf([String()]).validate("a") == "a"
    assert AllOf([String(), Integer()]).validate("a") == "a"
    assert AllOf([String(), Integer()]).validate(1) == 1
    with pytest.raises(ValidationError):
        AllOf([String(), Integer()]).validate(1.23)
    assert AllOf([Any()]).validate(None) is None
    with pytest.raises(ValidationError):
        AllOf([String(), Integer()]).validate(None)

# Generated at 2022-06-24 10:41:48.012361
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    test the method validate of class IfThenElse
    """
    if_clause = Int()
    then_clause = Int()
    else_clause = Str()
    if_then = IfThenElse(if_clause, then_clause)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then.validate(1) == 1
    assert if_then.validate("1") == 1
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate("1") == "1"
    if_clause = Int()
    then_clause = Int()
    else_clause = BaseType()

# Generated at 2022-06-24 10:41:54.519002
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test = OneOf(one_of=[Int(), Float()])
    res1, res2, res3 = test.validate(value=1), test.validate(value=1.2), test.validate(value='a')
    assert res1 == 1 and res2 == 1.2 and isinstance(res3, Exception)


# Generated at 2022-06-24 10:41:58.674710
# Unit test for constructor of class Not
def test_Not():
    import typesystem
    field = typesystem.Not(typesystem.Integer())
    assert isinstance(field, typesystem.Field), "Should be an instance of class Field"
    assert field.errors == {"negated": "Must not match."}
    try:
        field.validate(1.1)
    except:
        pass


# Generated at 2022-06-24 10:42:00.001753
# Unit test for constructor of class Not
def test_Not():
    field = Not("field")
    assert field.negated == "field"


# Generated at 2022-06-24 10:42:01.664667
# Unit test for constructor of class AllOf
def test_AllOf():
    obj = AllOf((Field(),),)
    assert obj.all_of == (Field(),)


# Generated at 2022-06-24 10:42:05.075008
# Unit test for constructor of class OneOf
def test_OneOf():
    """Test OneOf"""
    one_of = OneOf(one_of=["a", "b"])
    assert one_of.one_of[0] == "a"
    assert one_of.one_of[1] == "b"


# Generated at 2022-06-24 10:42:08.278623
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    field2 = NeverMatch(description="test")
    expected = "This never validates."
    assert field.errors["never"] == expected
    assert field2.errors["never"] == expected


# Generated at 2022-06-24 10:42:15.686338
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.json_schema_fields import IfThenElse

    assert IfThenElse(if_clause=String()).validate(1) == 1
    assert IfThenElse(if_clause=String(), then_clause=String()).validate(1) == 1
    assert IfThenElse(if_clause=String(), else_clause=strict_string(max_length=1)).validate(1) == 1
    assert IfThenElse(if_clause=String(), then_clause=String(), else_clause=strict_string(max_length=1)).validate(1) == 1
    assert IfThenElse(if_clause=String(max_length=1)).validate('a') == 'a'

# Generated at 2022-06-24 10:42:20.613055
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class Foo(IfThenElse):
        def __init__(self):
            super().__init__(
                if_clause=None,
                then_clause=None,
                else_clause=None,
                allow_null=False,
                description="I'm a Foo"
            )

# Generated at 2022-06-24 10:42:23.243517
# Unit test for constructor of class OneOf
def test_OneOf():
    a = 3
    b = 4
    sh = String()
    print(OneOf([sh, a, b]))


# Generated at 2022-06-24 10:42:26.515526
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[String, Any])

    with pytest.raises(SchemaError) as excinfo:
        field.validate([1,2])

    value = ["1", "2", "3"]
    field.validate(value, strict=True)
    assert value == ["1", "2", "3"]


# Generated at 2022-06-24 10:42:30.728416
# Unit test for constructor of class Not
def test_Not():
	negated = 1
	assert(Not(negated).negated == 1)
	negated = 10
	assert(Not(negated).negated == 10)
	negated = None
	assert(Not(negated).negated == None)
	negated = "Python"
	assert(Not(negated).negated == "Python")


# Generated at 2022-06-24 10:42:31.571443
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(1) == 1


# Generated at 2022-06-24 10:42:33.776503
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    subitem_1 = typesystem.String()
    subitem_2 = typesystem.String(max_length=2)
    all_of = typesystem.AllOf([subitem_1, subitem_2])
    assert all_of.validate("a") == "a"


# Generated at 2022-06-24 10:42:45.899588
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Okay, the instance is initialized 
    class _T(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    f1 = _T()
    f2 = _T()
    f3 = _T()
    f4 = _T()
    f5 = _T()
    a = AllOf([f1,f2,f3,f4,f5])

    # Sub-items are valid
    assert f1.validate(1) == 1
    assert f2.validate(2) == 2
    assert f3.validate(3) == 3
    assert f4.validate(4) == 4
    assert f5.validate(5) == 5

    # Sub-items are all valid
    assert a.validate(0)

# Generated at 2022-06-24 10:42:51.611900
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Test method validate of class AllOf
    """
    from typesystem import Integer
    from typesystem.fields import AllOf, String
    all_of_instance = AllOf([Integer(), String()])
    with raises(ValidationError):
        all_of_instance.validate('')
    with raises(ValidationError):
        all_of_instance.validate(0)


# Generated at 2022-06-24 10:43:01.137372
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import json
    import typing
    from typesystem import Schema

    a = AllOf([Integer(), String()])

    try:
        a.validate(123)
        a.validate("ABC")
        b = typing.cast(
            typing.List[typing.Any], json.loads('[{"name": "Alice", "age": 12}, {"name": "Bob", "age": 13}]')
        )
        s = Schema({"name": String(), "age": Integer()})
        a = AllOf([s, ArrayOf(s)])
        a.validate(b)
    except:
        assert False



# Generated at 2022-06-24 10:43:02.549633
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    e = NeverMatch()
    assert e.validate(10) is None

# Generated at 2022-06-24 10:43:07.046517
# Unit test for constructor of class AllOf
def test_AllOf():
	try:
		AllOf()
		OneOf()
		NeverMatch()
		IfThenElse()
		Not()
		assert False
	except TypeError:
		assert True

test_AllOf()

# Generated at 2022-06-24 10:43:10.767985
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(AllOf(subfields))
    field.validate(Not_validate_test_cases[0][0])
    with pytest.raises(ValidationError):
        field.validate(Not_validate_test_cases[1][0])


# Generated at 2022-06-24 10:43:16.442046
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    validate = IfThenElse(if_clause=String(),then_clause=String(max_length=10),else_clause=String(min_length=10)).validate
    validate("a")
    expect(lambda: validate("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaa")).to.throw(ValidationError)
    expect(lambda: validate(1)).to.throw(ValidationError)
    



# Generated at 2022-06-24 10:43:21.258937
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    def validate(value):
        if_clause = Integer()
        then_clause = Integer()
        else_clause = String()
        field = IfThenElse(if_clause, then_clause, else_clause)
        field.validate(value)

    validate("Hello")
    validate(123)
    try:
        validate("Hello123")
    except ValueError:
        pass

# Generated at 2022-06-24 10:43:23.378102
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(Field.validation_error):
        field.validate(None)

# Generated at 2022-06-24 10:43:28.284930
# Unit test for method validate of class Not
def test_Not_validate():
    not_obj = Not(negated=True)
    with pytest.raises(FieldValidationError, match='Must not match.'):
        not_obj.validate(0)


# Generated at 2022-06-24 10:43:28.839386
# Unit test for constructor of class AllOf
def test_AllOf():
    pass

# Generated at 2022-06-24 10:43:40.428879
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    OneOf([Any()]).validate(1)
    OneOf([Any()]).validate(2)
    try:
        OneOf([NeverMatch()]).validate(1)
        assert False
    except:
        assert True

    OneOf([NeverMatch(), Any()]).validate(1)
    OneOf([NeverMatch(), Any()]).validate(2)
    try:
        OneOf([NeverMatch(), NeverMatch()]).validate(1)
        assert False
    except:
        assert True

    try:
        OneOf([Any(), Any()]).validate(1)
        assert False
    except:
        assert True

    OneOf([Any(), NeverMatch()]).validate(1)
    OneOf([Any(), NeverMatch()]).validate(2)

# Generated at 2022-06-24 10:43:50.555043
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test string
    allof_str = "allof"
    # Test list of fields
    list_fields = []
    # Test keyword arguments
    kwargs = {
        "all_of": allof_str,
        "description": "Test AllOf"
    }
    # Create new AllOf object
    allof = AllOf(**kwargs)
    # Test if object is AllOf object
    assert isinstance(allof, AllOf)
    # Test if object contains correct all_of field
    assert allof.all_of == allof_str
    # Test if object contains correct description field
    assert allof.description == kwargs["description"]




# Generated at 2022-06-24 10:43:53.551559
# Unit test for method validate of class Not
def test_Not_validate():
    data = {"a1" : 5}
    data1 = {"a2" : 6}
    n = Not(Number())
    n.validate(data)
    n.validate(data1)


# Generated at 2022-06-24 10:43:54.597120
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test = NeverMatch()
    assert test.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:43:59.086898
# Unit test for method validate of class Not
def test_Not_validate():
    def check_negated_IfThenElse():
        field = Not(IfThenElse(True, then_clause=1))

    # The exception might raise by IfThenElse
    # but the exception raised by Not should be negated
    with pytest.raises(ValidationError) as excinfo:
        check_negated_IfThenElse()
    assert excinfo.value.code == "negated"


# Generated at 2022-06-24 10:43:59.955530
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf is not None


# Generated at 2022-06-24 10:44:06.284527
# Unit test for constructor of class Not
def test_Not():
    from typesystem.base import Field
    from typesystem.fields import String
    not_obj = Not(negated=String())
    assert(not_obj.negated == String())
    try:
        assert(not_obj.validate('abc'))
        assert(0)
    except:
        pass
    try:
        assert(not_obj.validate(None))
        assert(1)
    except:
        pass
    try:
        assert(not_obj.validate(''))
        assert(1)
    except:
        pass
    try:
        assert(not_obj.validate(5))
        assert(0)
    except:
        pass

# Generated at 2022-06-24 10:44:10.640940
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause =String(max_length = 2),
        then_clause =Integer(),
        else_clause =Float()
    )
    assert field.validate('ab') == "ab"
    assert field.validate(3) == 3
    assert field.validate(3.4) == 3.4
    assert field.validate('abc') == "abc"

# Generated at 2022-06-24 10:44:21.717370
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    child1 = DummyField(name="child1")
    child2 = DummyField(name="child2")
    f = OneOf([child1, child2])

    # Test 1
    child1.validated = "my_validated"
    child1.error = None
    child2.validated = "my_validated"
    child2.error = None
    actual = f.validate("my_value")
    assert actual == "my_validated"

    # Test 2
    child1.validated = "my_validated"
    child1.error = "my_error"
    child2.validated = "my_validated"
    child2.error = None
    actual = f.validate("my_value")
    assert actual == "my_validated"

    # Test 3
    child1

# Generated at 2022-06-24 10:44:25.940431
# Unit test for method validate of class Not
def test_Not_validate():
    try:
        not_field = Not(Any(), source="test")
        not_field.validate(123, False)
    except Not.validation_error as e:
        assert e.code == "negated"
        assert e.source == "test"
        assert e.value == 123


# Generated at 2022-06-24 10:44:29.455867
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(NeverMatch()).validate(1) == 1
    try:
        Not(NeverMatch()).validate('')
    except Exception as exc:
        assert str(exc) == "Must not match."


# Generated at 2022-06-24 10:44:33.441957
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import pytest
    from typesystem.exceptions import ValidationError

    # test_never
    # keyword arguments:
    # name=None
    with pytest.raises(ValidationError) as errinfo:
        NeverMatch().validate(1)
    assert errinfo.value.code == "never"
    assert errinfo.value.message == "This never validates."
    assert errinfo.value.value == 1
    assert errinfo.value.field == "field"
    assert errinfo.value.field_path == ["field"]


# Generated at 2022-06-24 10:44:36.330997
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([AllOf([])])

if __name__ == '__main__':
    test_AllOf()

# Generated at 2022-06-24 10:44:38.040514
# Unit test for method validate of class Not
def test_Not_validate():
    x = Not(Any()).validate(any)
    assert x == any

# Generated at 2022-06-24 10:44:38.934650
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    neverMatch = NeverMatch()


# Generated at 2022-06-24 10:44:43.511933
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    field.validate("this should pass")

# Generated at 2022-06-24 10:44:47.260096
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer
    from typesystem.fields import Number
    from typesystem.fields import String
    from typesystem.fields import Text

    field = AllOf([Integer(), Number(), String(), Text()])


# Generated at 2022-06-24 10:44:53.319334
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String

    errors = {
        "no_match": "Did not match any valid type.",
        "multiple_matches": "Matched more than one type.",
    }

    one_of = [String()]

    o = OneOf(one_of=one_of)
    print(o.errors)


# Generated at 2022-06-24 10:44:54.828419
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(field1, field2, field3)
    return

# Generated at 2022-06-24 10:44:57.868611
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([String()])
    assert isinstance(a,AllOf)
    assert isinstance(a,Field)
    assert hasattr(a, 'validate')
    assert hasattr(a,'all_of')


# Generated at 2022-06-24 10:45:04.272375
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(type=int)
    then_clause = Field(type=int, description="then_clause description")
    else_clause = Field(type=str, description="else_clause description")
    field = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)

    result = field.validate(4)
    assert result == 4

    result = field.validate("4")
    assert result == "4"

    assert field.then_clause.description == "then_clause description"
    assert field.else_clause.description == "else_clause description"



# Generated at 2022-06-24 10:45:09.615596
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Integer(max_value=2), Integer(max_value=4), Integer(max_value=6))
    assert field.validate(1) == 1
    assert field.validate(3) == 3
    assert field.validate(5) == 5
    assert IfThenElse(Integer(max_value=2), Integer(max_value=4)).validate(3) == 3

# Generated at 2022-06-24 10:45:11.958778
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String
    t = IfThenElse(String())
    assert t.validate('aiueo') == 'aiueo'
    #assert t.validate(123) == '123'

# Generated at 2022-06-24 10:45:16.021039
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    errorMessage = "Error message"
    schema = AllOf([AllOf([AllOf([Any()])]),Any()])
    value = {}
    with pytest.raises(ValidationError, match=errorMessage):
        schema.validate(value)
test_AllOf_validate()


# Generated at 2022-06-24 10:45:17.038104
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf

# Generated at 2022-06-24 10:45:25.316990
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Int()
    then_clause = Int()
    else_clause = Str()
    test_field = IfThenElse(if_clause, then_clause, else_clause)
    if then_clause == test_field.then_clause:
        assert True
    else:
        assert False
    if else_clause == test_field.else_clause:
        assert True
    else:
        assert False
    try:
        test_field.validate(3)
        assert True
    except:
        assert False
    try:
        test_field.validate("Three")
        assert True
    except:
        assert False

# Generated at 2022-06-24 10:45:27.703254
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String

    not_test = Not(String(max_length=3))
    if not_test.negated.max_length != 3:
        assert False



# Generated at 2022-06-24 10:45:30.322973
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[Any()])
    assert OneOf(one_of=[Any()], allow_null=False)


# Generated at 2022-06-24 10:45:34.779454
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Any()).validate(None) == None
    error = None
    try:
        Not(Any()).validate(10)
    except Exception as e:
        error = e
    assert error != None
    assert str(error) == "Must not match."

# Generated at 2022-06-24 10:45:39.154637
# Unit test for constructor of class AllOf
def test_AllOf():
    test_data = AllOf([])
    assert test_data



# Generated at 2022-06-24 10:45:48.054886
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    # IfThenElse(Integer(), String()).validate(4) =>  "4"
    assert IfThenElse(Integer(), String()).validate(4) == "4"

    # IfThenElse(Integer(), String(), String()).validate(4) =>  "4"
    assert IfThenElse(Integer(), String(), String()).validate(4) == "4"

    # IfThenElse(Integer(), String(), String()).validate(4) =>  "4"
    assert IfThenElse(Integer(), String(), String()).validate(4) == "4"

    # IfThenElse(Integer(), String(), String()).validate("4") =>  "4"
    assert IfThenElse(Integer(), String(), String()).validate("4") == "4"

    # IfThenElse(

# Generated at 2022-06-24 10:45:53.551208
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class Int(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if isinstance(value, int):
                return value
            raise self.validation_error("invalid")
    field = AllOf([Int(), Int()])
    assert field.validate(1) == 1
    assert field.validate(2) == 2



# Generated at 2022-06-24 10:45:57.004342
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    n.validate("")
    try:
        n.validate(None)
    except ValidationError:
        pass

    n = Not(Any(required=True))
    try:
        n.validate("")
    except ValidationError:
        pass



# Generated at 2022-06-24 10:46:01.526600
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([
        Int(),
        String()
    ])

    assert field.validate(1) == 1
    assert field.validate('1') == '1'


# Generated at 2022-06-24 10:46:06.951071
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    assert isinstance(if_clause, Field)
    assert isinstance(then_clause, Field)
    assert isinstance(else_clause, Field)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("test") == "test"

# Generated at 2022-06-24 10:46:18.517774
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    err = 'assertion error'


# Generated at 2022-06-24 10:46:26.282782
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Test validate method of class AllOf
    """
    # Initialization
    input_value = "testing"
    input_strict = False

    all_of_field_1 = Field()
    all_of_field_2 = Field()
    test_input = AllOf([all_of_field_1,all_of_field_2])

    # Expected output
    expected_output = input_value

    # Apply test
    test_output = test_input.validate(input_value, strict=input_strict)

    # Verify test
    assert expected_output == test_output


# Generated at 2022-06-24 10:46:31.860073
# Unit test for method validate of class AllOf
def test_AllOf_validate():

    import json
    
    from typesystem.fields import AllOf, Any, Array, Boolean, Integer, String

    field = AllOf([Any(), Boolean(), Boolean()])

    field.validate(False)
    field.validate(True)
    field.validate(None)
    #field.validate(3.14)  # -> error



# Generated at 2022-06-24 10:46:36.508504
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-24 10:46:40.840824
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import json
    obj = json.loads('{"one_of": [{"type": "integer"}, {"type": "string"}]}')
    v = OneOf.from_json_schema(obj)
    v.validate(3)
    v.validate("3")



# Generated at 2022-06-24 10:46:42.117814
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated='a').validate(None) == None

# Generated at 2022-06-24 10:46:45.545128
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String())
    assert not_field.validate(1) == 1
    try:
        not_field.validate("")
    except typesystem.Error as exc:
        assert exc.code == "negated"
    else:
        raise RuntimeError("The code should not reach here")


# Generated at 2022-06-24 10:46:50.765418
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Setup
    data = {
        "type": "integer"
    }
    errormsg = "This never validates."
    # Exercise
    result = NeverMatch(**data)
    # Verify
    assert result.errors['never'] == errormsg


# Generated at 2022-06-24 10:46:54.636036
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer

    class SimpleTest(AllOf):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__([Integer()], **kwargs)


# Generated at 2022-06-24 10:47:02.983692
# Unit test for constructor of class AllOf
def test_AllOf():
    int_field = fields.Integer(minimum=6, description='Some description', title='Some title', multiple_of=5)
    str_field = fields.String(enum=['8ball'], min_length=1, max_length=10, pattern=r'.*')
    lst_field = fields.List()
    all_of_field = fields.AllOf([int_field, str_field, lst_field], required=True, title='Some title', description='Some description', format='email', nullable=True, additional_properties=False)
    print(all_of_field)


# Generated at 2022-06-24 10:47:05.052528
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  never_match = NeverMatch()
  assert never_match.errors == { 'never': 'This never validates.' }


# Generated at 2022-06-24 10:47:06.341655
# Unit test for constructor of class Not
def test_Not():
    invalid_object = Not(Any())
    assert invalid_object != None

# Generated at 2022-06-24 10:47:08.759499
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a=AllOf([Integer(),Integer()])
    a.validate('1')
    #assert a.validate('a') == "error"


# Generated at 2022-06-24 10:47:18.837430
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert (IfThenElse(1, 2).validate(1) == 2)
    assert (IfThenElse(1, 2).validate(2) == None)
    assert (IfThenElse(1, 2, 3).validate(1) == 2)
    assert (IfThenElse(1, 2, 3).validate(2) == 3)
    assert (IfThenElse(1, 2, 3).validate(3) == None)
    assert (IfThenElse(1, then_clause=2).validate(1) == 2)
    assert (IfThenElse(1, then_clause=2).validate(2) == None)
    assert (IfThenElse(1, else_clause=2).validate(1) == None)

# Generated at 2022-06-24 10:47:29.205544
# Unit test for method validate of class OneOf

# Generated at 2022-06-24 10:47:35.662513
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a1 = String()
    a2 = String()
    a3 = String()

    allOf = AllOf([a1, a2, a3])
    assert allOf.validate('test') == 'test'


# Generated at 2022-06-24 10:47:41.195416
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # with pytest.raises(AssertionError):
    #     NeverMatch(allow_null=True)
    assert NeverMatch(description='abc').description=='abc'

# Generated at 2022-06-24 10:47:48.441977
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class SubType(Field):
        def __init__(self):
            super().__init__()
    
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            self.validation_error("Must be a string")
    
    with pytest.raises(ValidationError) as error:
        subType = SubType()
        x = IfThenElse(subType);
        x.validate(1)
    assert str(error.value) == "Must be a string"

    subType = SubType()
    x = IfThenElse(subType)
    value = x.validate(True)
    assert value is True



# Generated at 2022-06-24 10:47:54.859145
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    assert f.validate(None) is None
    with pytest.raises(Field.ValidationError):
        f.validate("foo")


# Generated at 2022-06-24 10:47:58.605603
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.types import String
    field = AllOf([String(max_length=3), String(min_length=2)])
    assert field.validate("12") is not None


# Generated at 2022-06-24 10:48:05.055622
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Boolean, Integer, String

    f = OneOf(one_of=[Integer(), Boolean(), String()])
    f.validate("foo")  # should pass
    f.validate("123")  # should pass
    f.validate(0)  # should pass
    f.validate(False)  # should pass
    f.validate("fasle")  # should not pass
    f.validate("True")  # should not pass
    f.validate("1")  # should not pass
    f.validate("0")  # should not pass

# Generated at 2022-06-24 10:48:07.620038
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    import typesystem
    t = typesystem.NeverMatch()
    assert t.validate(1) == None


# Generated at 2022-06-24 10:48:19.122396
# Unit test for method validate of class Not
def test_Not_validate():
    # Test data
    value = "test"
    strict = False
    negated = "negated"
    negated1 = "negated1"

    # Expected data
    expected_result = "test"
    expected_error = {'negated': 'Must not match.'}

    # Case 1
    # Test accuracy
    not_field = Not(negated)
    result = not_field.validate(value, strict)
    assert result == expected_result

    # Case 2
    # Test accuracy
    not_field1 = Not(negated1)
    result = not_field1.validate(value, strict)
    assert result == expected_error

# Generated at 2022-06-24 10:48:25.972508
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema = OneOf([String(), Integer()])
    assert schema.validate(10) == 10
    assert schema.validate("hello") == "hello"
    try:
        schema.validate(None)
        assert False
    except Exception as e:
        assert True
    try:
        schema.validate({"K1": "V1"})
        assert False
    except Exception as e:
        assert True


# Generated at 2022-06-24 10:48:34.231669
# Unit test for method validate of class Not
def test_Not_validate():
    # verifie si le format de la variable est bien un string ou pas
    not_field = Not(String())
    assert str(not_field.validate('pas un string')).replace("'", "") == 'None'
    assert not_field.validate('1') == '1'
    # verifie si la valeur de la variable est bien complétée ou pas
    assert not_field.validate(1) == 1
    assert str(not_field.validate(None)).replace("'", "") == "None"