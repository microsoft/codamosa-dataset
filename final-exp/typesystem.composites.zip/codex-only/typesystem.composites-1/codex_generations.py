

# Generated at 2022-06-24 10:38:39.684825
# Unit test for constructor of class AllOf
def test_AllOf():
    import typing
    from typesystem.fields import AllOf, Any
    # test__init__
    a = AllOf([Any()])
    assert a.all_of == [Any()]
    assert a.errors == {}
    assert a.metadata == {}
    # test__init__

    # test__init__
    a = AllOf([Any()], name="foo")
    assert a.all_of == [Any()]
    assert a.errors == {}
    assert a.metadata == {"name":"foo"}
    # test__init__


# Generated at 2022-06-24 10:38:41.949045
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
    except TypeError as err:
        assert(str(err))


# Generated at 2022-06-24 10:38:43.302525
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf([Field])
    assert o.type == "oneOf"


# Generated at 2022-06-24 10:38:46.792372
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(True) == True
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(False) == False
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-24 10:38:50.416967
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with a single item in the list
    field = OneOf(one_of=[Any()])
    field.validate("hello")
    field.validate(1)

    # Test with two items in the list
    field = OneOf(one_of=[Any(), Any()])
    field.validate("hello")
    field.validate(1)


# Generated at 2022-06-24 10:38:52.191100
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    x = AllOf([Int(), Str()])
    assert x.validate(1) == 1
    assert x.validate("1") == "1"


# Generated at 2022-06-24 10:38:52.734884
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-24 10:38:54.092099
# Unit test for constructor of class OneOf
def test_OneOf():
    with pytest.raises(AssertionError):
        OneOf(one_of=[Any()], allow_null=False)

# Generated at 2022-06-24 10:38:57.248333
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Init code

    testField = AllOf([])
    value = []
    strict = True
    # Test code
    testField.validate(value, strict)



# Generated at 2022-06-24 10:39:04.062363
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    before_clause = IfThenElse(
        if_clause=String(max_length=10),
        then_clause=String(max_length=16),
        else_clause=String(max_length=1),
    )
    assert before_clause.if_clause.max_length == 10
    assert before_clause.then_clause.max_length == 16
    assert before_clause.else_clause.max_length == 1


# Test for custom validation in class Not

# Generated at 2022-06-24 10:39:07.163290
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    f = IfThenElse(field1, field2)
    if_clause = f.if_clause
    then_clause = f.then_clause
    else_clause = f.else_clause


# Generated at 2022-06-24 10:39:08.484101
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert False # TODO: implement your test here


# Generated at 2022-06-24 10:39:09.680737
# Unit test for constructor of class Not
def test_Not():
    f1 = Integer()
    f2 = Not(f1)
    assert f2.negated == f1

# Generated at 2022-06-24 10:39:11.091346
# Unit test for constructor of class OneOf
def test_OneOf():
    print(OneOf(one_of=[{'test': 'first one'}]))


# Generated at 2022-06-24 10:39:17.499704
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    
    # Test:
    # value=10
    # strict=True
    # expected=raise TypeError
    
    with pytest.raises(TypeError):
        type_instance = NeverMatch()
        value = 10
        strict = True
        type_instance.validate(value, strict)
    
    

# Generated at 2022-06-24 10:39:25.367009
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import unittest
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    from . import AllOf

    class AllOfField(unittest.TestCase):
        valid_data = {"a": 1, "b": "text", "c": "some text"}
        invalid_data = {"a": 1, "b": "text", "c": [1, 2, 3]}

        def test_valid_data(self):
            self.assertEqual(
                AllOf(
                    [
                        Field(required=True),
                        String(min_length=1),
                        String(max_length=10),
                    ]
                ).validate(self.valid_data),
                self.valid_data,
            )


# Generated at 2022-06-24 10:39:36.586543
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf([Field(type="string"), Field(type="integer")])
    
    # Test for an undefined value
    with pytest.raises(ValidationError) as excinfo:
        one_of_field.validate()
    assert str(excinfo.value) == "No match"
    
    # Test for a string value
    one_of_field.validate("coucou")

    # Test for an integer value
    one_of_field.validate(2)

    # Test for a boolean value
    with pytest.raises(ValidationError) as excinfo:
        one_of_field.validate(True)
    assert str(excinfo.value) == "No match"

    # Test for a dictionary value

# Generated at 2022-06-24 10:39:37.517988
# Unit test for constructor of class Not
def test_Not():
    s = Not(Field())

# Generated at 2022-06-24 10:39:40.977424
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test for TypeError when one_of has wrong type
    with pytest.raises(TypeError):
        OneOf(one_of=1)

    # Test for TypeError when one_of is empty
    with pytest.raises(TypeError):
        OneOf(one_of=[])


# Generated at 2022-06-24 10:39:51.748832
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Boolean()
    then_clause = Float()
    else_clause = Integer()
    a = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    # Test with condition True
    assert a.validate(True) == True
    # Test with condition False
    import typesystem
    try:
        a.validate(False)
    except typesystem.ValidationError:
        assert typesystem.ValidationError
    try:
        a.validate("False")
    except typesystem.ValidationError:
        assert typesystem.ValidationError

# Generated at 2022-06-24 10:39:53.495496
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated = Any()).negated == Any()


# Generated at 2022-06-24 10:40:04.492444
# Unit test for constructor of class IfThenElse
def test_IfThenElse():

    from typesystem.types import String, Integer
    class TestType(IfThenElse):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(if_clause=String(max_length=5), then_clause=String(max_length=10), else_clause=Integer(), **kwargs)

    # Test for invalid length
    f = TestType()
    try:
        f.validate('abcdefghijklmnopqrstuvwxyz')
        assert(False)
    except Exception as e:
        assert(e.code == 'max_length')

    # Test for valid length
    f.validate('abc')

    # Test for valid int
    f.validate(1)

# Generated at 2022-06-24 10:40:13.261207
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String

    field = Not(String())
    # valid case:
    field.validate(None)

    # invalid case:
    from typesystem.exceptions import ValidationError

    error = None
    try:
        field.validate("not_None")
    except ValidationError as err:
        error = err
    assert error.as_dict() == {'code': u'negated', 'loc': [], 'message': u'Must not match.'}

    # we cannot do the following assertion since field.error_messages is not a dictionary,
    # and still not checkable by pytest:
    # assert error.as_dict() == field.error_messages

# Generated at 2022-06-24 10:40:14.803827
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([OneOf([Any()]), Any()]).validate(1) == 1


# Generated at 2022-06-24 10:40:19.399156
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer

    field1 = Integer()
    field2 = Integer()
    field3 = AllOf([field1, field2])
    try:
        field3.validate(1)
    except RuntimeError as inst:
        assert inst.args == ('AllOf.validate: must be one of [<Integer: Integer>] and <Integer: Integer>',)



# Generated at 2022-06-24 10:40:24.350302
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    error = 0
    validator = AllOf([types.Integer(),types.Integer()])
    try:
        validator.validate(1)
    except ValidationError:
        error += 1
    if (error == 0):
        print("method validate of class AllOf works")
    else:
        print("method validate of class AllOf doesn't work")


# Generated at 2022-06-24 10:40:26.054411
# Unit test for constructor of class AllOf
def test_AllOf():
    list_ = []
    assert (AllOf(list_).all_of == list_)


# Generated at 2022-06-24 10:40:34.087175
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.types import String, Integer

    field = OneOf([String(), Integer()], name="name")
    field.validate("5")
    field.validate(5)
    try:
        field.validate(5.5)
        assert False
    except Exception as e:
        assert e.full_messages() == ['name: Did not match any valid type.']

    try:
        field.validate("5.5")
        assert False
    except Exception as e:
        assert e.full_messages() == ['name: Did not match any valid type.']

    try:
        field.validate("5")
        assert False
    except Exception as e:
        assert e.full_messages() == ['name: Did not match any valid type.']


# Generated at 2022-06-24 10:40:35.822361
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate('123')

# Generated at 2022-06-24 10:40:37.266572
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([])

    assert a is not None


# Generated at 2022-06-24 10:40:39.702823
# Unit test for constructor of class Not
def test_Not():
    not_type = Not(negated=int)
    assert not_type is not None


# Generated at 2022-06-24 10:40:42.960180
# Unit test for constructor of class Not
def test_Not():
    Test = Field()
    not_field = Not(negated=Test)
    assert not_field.negated is Test
    assert not_field.errors["negated"] == "Must not match."

# Generated at 2022-06-24 10:40:44.976242
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError):
        field.validate(None)


# Generated at 2022-06-24 10:40:46.826138
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(num_int)
    assert not_field.validate(12.5) == 12.5
    

# Generated at 2022-06-24 10:40:49.426873
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf.__init__

# Generated at 2022-06-24 10:40:58.798392
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Any()).validate("somestring") == "somestring"
    assert IfThenElse(Any(), then_clause = String()).validate("somestring") == "somestring"
    assert IfThenElse(Any(), else_clause = String()).validate("somestring") == "somestring"
    assert IfThenElse(Any(), then_clause = String(), else_clause = String()).validate("somestring") == "somestring"

    assert IfThenElse(Any(), then_clause = String(), else_clause = String()).validate(123) == String().validate(123)
    assert IfThenElse(NeverMatch(), then_clause = String(), else_clause = String()).validate(123) == String().validate

# Generated at 2022-06-24 10:41:01.388383
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String, Integer

    field = Not(Integer())
    assert field.negated is Integer()
    assert field.errors == {"negated": "Must not match."}
    assert field.validate(None) == None
    assert field.validate("yo") == "yo"
    try:
        field.validate(1)
    except:
        assert True
    else:
        assert False



# Generated at 2022-06-24 10:41:05.630146
# Unit test for constructor of class Not
def test_Not():
    dummy_field = Field()
    try:
        Not(dummy_field)
    except AssertionError:
        assert False
    try:
        Not(dummy_field, allow_null=None)
        assert False
    except AssertionError:
        assert True



# Generated at 2022-06-24 10:41:10.101650
# Unit test for method validate of class Not
def test_Not_validate():
    # Case 1: Error
    not_field_error = Not(negated=NeverMatch())
    with pytest.raises(ValidationError):
        not_field_error.validate(1)
    # Case 2: No error
    not_field_no_error = Not(negated=NeverMatch())
    assert not_field_no_error.validate(1) == 1


# Generated at 2022-06-24 10:41:11.282517
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    bool_ = IfThenElse(None, None, None)
    assert bool_ is not None

if __name__ == "__main__":
    test_IfThenElse()

# Generated at 2022-06-24 10:41:13.729920
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    field.validate('abc', strict=False)


# Generated at 2022-06-24 10:41:18.195085
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    with pytest.raises(ValueError) as err:
        nm.validate(3)
    assert err.value.args[0] == "This never validates."


# Generated at 2022-06-24 10:41:21.519562
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=String(), then_clause=Integer(), else_clause=Boolean())
    assert field.__class__.__name__ == "IfThenElse"

# Generated at 2022-06-24 10:41:22.945630
# Unit test for constructor of class Not
def test_Not():
    field = Not(Field())
    assert isinstance(field, Not)


# Generated at 2022-06-24 10:41:29.811310
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.validators import NotEmpty
    from typesystem.fields import Field, String
    from typesystem.base import SimpleValidator

    class MySimpleValidator(SimpleValidator):
        def validate(self, value):
            return super().validate(value)

    validation = MySimpleValidator()

    if_clause = Field(validators=[validation])
    then_clause = String()
    else_clause = Field(validators=[NotEmpty()])
    field = IfThenElse(if_clause, then_clause, else_clause)
    field.validate("test")

# Generated at 2022-06-24 10:41:37.512836
# Unit test for method validate of class Not
def test_Not_validate():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    a = A()
    b = Not(a)
    b.validate_or_error(1)
    try:
        b.validate_or_error("string")
    except Exception:
        print("Not.validate returns correctly")
    else:
        print("Not.validate doesn't return correctly")


test_Not_validate()

# Generated at 2022-06-24 10:41:46.491254
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    p1 = OneOf([Integer(), String(), Integer()])  # OneOf
    p2 = OneOf([Integer(), String(), Boolean()])  # OneOf
    p3 = OneOf([Integer(), String()])  # OneOf
    p4 = OneOf([Integer(), OneOf([Boolean(), String(), String()])])  # OneOf
    p5 = OneOf([String(), Integer()])  # OneOf

    # INPUT 1

    x = 'abc'  # str
    xin = x
    expected1 = xin
    actual1 = p1.validate(xin)
    assert expected1 == actual1

    # INPUT 2

    x = [123, True, 'abc']  # bool
    xin = x
    expected2 = xin
    actual2 = p1.validate(xin)

# Generated at 2022-06-24 10:41:49.406993
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Create an instance of the NeverMatch class
    myNeverMatch = NeverMatch(
        name="name",
        description="description",
        default="default",
        required=True,
    )
    assert myNeverMatch
    assert isinstance(myNeverMatch, Field)


# Generated at 2022-06-24 10:41:53.134735
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    OneOf([Field()],'optional')
    one_of = OneOf([Field(required=True)], 'optional')
    assert one_of.validate('foo') == 'foo'
    with pytest.raises(ValidationError) as error_info:
        one_of.validate(None)
    assert error_info.value.errors == {"no_match": "Did not match any valid type."}

# Generated at 2022-06-24 10:41:54.137019
# Unit test for constructor of class AllOf
def test_AllOf():
  field = AllOf()


# Generated at 2022-06-24 10:41:55.886361
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:41:57.842772
# Unit test for constructor of class NeverMatch
def test_NeverMatch(): 
    never_match = NeverMatch()
    assert never_match.errors['never'] == "This never validates."



# Generated at 2022-06-24 10:42:03.283979
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()

    field = IfThenElse(if_clause, then_clause, else_clause)

    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert field.else_clause == else_clause

# Generated at 2022-06-24 10:42:04.221428
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Field()])
    assert isinstance(field, OneOf)

# Generated at 2022-06-24 10:42:09.082886
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(None,None,None).if_clause == None
    assert IfThenElse(None,None,None).then_clause != None
    assert IfThenElse(None,None,None).else_clause != None

    assert IfThenElse(None,None,Any()).else_clause != None
    assert IfThenElse(None,None,Any()).else_clause.type == Any
    assert IfThenElse(None,None,Any(required=False)).else_clause != Any()
    assert IfThenElse(None,None,Any(required=False)).else_clause.type == Any


# Generated at 2022-06-24 10:42:17.697085
# Unit test for constructor of class OneOf
def test_OneOf():
    from pprint import pprint
    from typing import List
    from typesystem.fields import Boolean

    class TestOneOf(OneOf):
        one_of: List[Boolean] = []

    test_one_of = TestOneOf()
    pprint(test_one_of.__dict__)
    assert str(test_one_of.__dict__) == "{'errors': {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}, 'one_of': []}"
    assert str(test_one_of.errors) == "{'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}"
    assert test_one_of.errors['multiple_matches'] == 'Matched more than one type.'


# Generated at 2022-06-24 10:42:26.219017
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_list = [
        Field(key = "123", key_error = 'cannot be 123', regex_match=r'^\d+?$'), 
        Field(key = "abc", key_error = 'cannot be abc', regex_match=r'^[a-z]+?$')
    ]
    one_of = OneOf(one_of_list)
    one_of.validate(123)             # want `key_error` raised here
    one_of.validate('abc')           # want `key_error` raised here

test_OneOf_validate()

# Generated at 2022-06-24 10:42:30.165892
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Integer

    class Positive(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value <= 0:
                raise self.validation_error("Must be positive")
            return value

    field = AllOf(fields=[Integer(), Positive()])
    field.validate(1)

# Generated at 2022-06-24 10:42:33.812947
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    
    try:
        from typesystem import fields
        from typesystem.exceptions import ValidationError
    
        class MyNeverMatch(fields.NeverMatch):
            pass
        
        a = MyNeverMatch()

        try:
            a.validate({"myVar": 1337})
        except ValidationError as ve:
            assert ve.error == "never"
    except ImportError:
        pass


# Generated at 2022-06-24 10:42:36.314029
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer

    field = OneOf([Integer()])
    value = 123
    field.validate(value=value)


# Generated at 2022-06-24 10:42:39.022761
# Unit test for constructor of class Not
def test_Not():
    # Given
    a = Not(Any())

    # When
    b = a.validate(None)

    # Then
    assert b == None

# Generated at 2022-06-24 10:42:43.681350
# Unit test for method validate of class Not
def test_Not_validate():
    negated = Not(Any())
    negated.validate("value")
    try:
        negated.validate("value")
        assert False
    except AssertionError as e:
        assert "Must not match." in str(e)


# Generated at 2022-06-24 10:42:46.973232
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    new_if = IfThenElse(if_clause=Field(), then_clause=Field())
    assert new_if.if_clause is not None
    assert new_if.then_clause is not None

# Generated at 2022-06-24 10:42:55.476725
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([])
    b = OneOf(["1"])
    c = OneOf(["1", "2"])
    d = OneOf([])

    assert a.one_of == b.one_of
    assert a.one_of == c.one_of
    assert a.one_of != d.one_of

    assert a.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert b.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert c.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}

# Generated at 2022-06-24 10:43:02.549411
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import Boolean, Integer, String

    assert isinstance(IfThenElse(if_clause=Boolean()).if_clause, Boolean)
    assert isinstance(IfThenElse(if_clause=Boolean()).then_clause, Any)
    assert isinstance(IfThenElse(if_clause=Boolean()).else_clause, Any)
    assert isinstance(IfThenElse(if_clause=Boolean(), then_clause=Integer(), else_clause=String()).then_clause, Integer)


# Generated at 2022-06-24 10:43:06.668968
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Initialize
    nm = NeverMatch()

    # Test
    assert nm.schema() == {"allOf": [{}, {"not": {"type": "null"}}], "type": "object"}

# Generated at 2022-06-24 10:43:13.849690
# Unit test for constructor of class OneOf
def test_OneOf():

    test_schema = {
                    "type": "object",
                    "properties": {
                        "hourly_rate": {
                            "type": "number",
                            "minimum": 0
                        }
                    },
    }

    hourly_rate = test_schema["properties"]["hourly_rate"]
    hourly_rate_new = OneOf([hourly_rate])
    assert hourly_rate_new.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}

test_OneOf()

# Generated at 2022-06-24 10:43:14.539986
# Unit test for constructor of class OneOf
def test_OneOf():
    OneOf([])

# Generated at 2022-06-24 10:43:24.108370
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # If a value pass the if clause, it must pass the then clause
    # Create an if then else object
    if_then_else = IfThenElse(Field(), Field())

    # Test with a value that must pass the if clause
    if_then_else.validate(None)

    # If a value pass the if clause, it must pass the then clause
    # Create an if then else object with no else clause (by default, the then clause is an Any field)
    if_then_else = IfThenElse(Field())

    # Test with a value that must pass the if clause
    if_then_else.validate(None)

    # If a value does not pass the if clause, it must pass the else clause
    # Create an if then else object
    if_then_else = IfThenElse(Field(), else_clause=Field())



# Generated at 2022-06-24 10:43:30.569021
# Unit test for constructor of class OneOf
def test_OneOf():
    # These fields should never be called, but they need to be instantiated so
    # that the constructor doesn't fail.
    dummy = NeverMatch(label="dummy", description="dummy")
    one_of = OneOf([dummy], label="one_of", description="one_of")
    assert one_of.one_of == [dummy]


# Generated at 2022-06-24 10:43:34.855095
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[String()])
    valid, error = field.validate_or_error("test",strict=False)
    assert valid == "test"



# Generated at 2022-06-24 10:43:39.152006
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f1 = OneOf([Any(),Any()])
    f1.validate(1)
    f2 = OneOf([Str(),Any()])
    f2.validate("1")
    f3 = OneOf([[Str()],Any()])
    print(f3.validate("1"))

test_OneOf_validate()

# Generated at 2022-06-24 10:43:41.236968
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Field(name="str"), then_clause=String(name="str"))
    assert field.validate({"str": "str"}, strict=True) == {"str": "str"}

# Generated at 2022-06-24 10:43:44.479485
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(1)


# Generated at 2022-06-24 10:43:47.018231
# Unit test for constructor of class Not
def test_Not():
    f = Not("default", "any", "null", "boolean", "number", "string", "array", "object")
    assert isinstance(f, Not)


# Generated at 2022-06-24 10:43:50.384930
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([str, int])
    assert field.one_of == [str, int]

# Generated at 2022-06-24 10:43:52.218702
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    instance = NeverMatch()
    # No exception raised
    instance.validate("-1")


# Generated at 2022-06-24 10:43:55.937413
# Unit test for constructor of class Not
def test_Not():
    # Test 2: A working negative
    try:
        test2 = Not(String(max_length=10))
        assert test2.validate("this is a long string")
    except Exception as e:
        print("Test 2 failed: {}".format(e))
        assert 0



# Generated at 2022-06-24 10:43:57.227510
# Unit test for constructor of class AllOf
def test_AllOf():
    of = AllOf([])
    assert isinstance(of, AllOf)

# Generated at 2022-06-24 10:44:03.589170
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Data
    if_clause = Int()
    then_clause = String()
    else_clause = Bool()

    value = 1
    value2 = 'test'
    value3 = True

    strict = False

    # Object to test
    obj = IfThenElse(if_clause, then_clause, else_clause)

    # Tests
    assert obj.validate(value, strict) == then_clause.validate(value, strict)
    assert obj.validate(value2, strict) == else_clause.validate(value3, strict)

# Generated at 2022-06-24 10:44:09.349403
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    ite = IfThenElse(if_clause, then_clause, else_clause)
    assert ite.validate(0) == 0
    assert ite.validate(1) == 1
    assert ite.validate(2) == 2

    if_clause = String()
    then_clause = String()
    else_clause = String()
    ite = IfThenElse(if_clause, then_clause, else_clause)
    assert ite.validate(0) == '0'
    assert ite.validate(1) == '1'
    assert ite.validate(2) == '2'



# Generated at 2022-06-24 10:44:12.545587
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test with complete input
    a = NeverMatch(None, None, None)
    print(a.errors)


# Generated at 2022-06-24 10:44:14.317710
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    testField = NeverMatch()
    testField.name = 'name'


# Generated at 2022-06-24 10:44:16.258874
# Unit test for constructor of class Not
def test_Not():
    # Does not crash on initialization
    n = Not(negated=Int(minimum=1))


# Generated at 2022-06-24 10:44:20.310306
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem
    field0 = typesystem.String(min_length=10)
    field1 = typesystem.String(max_length=20)
    field2 = typesystem.String()
    field = AllOf([field0, field1, field2])
    assert field is not None

# Generated at 2022-06-24 10:44:27.101309
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(AssertionError):
        nm = NeverMatch()
        nm.validate(1)
    # test error case
    with pytest.raises(AssertionError):
        nm = NeverMatch()
        nm.validate(1)
    # test error case
    with pytest.raises(AssertionError):
        nm = NeverMatch()
        nm.validate(1)


# Generated at 2022-06-24 10:44:31.983785
# Unit test for constructor of class AllOf
def test_AllOf():

    import json
    
    data = {
        'allOf': [],
        'title': 'AllOf',
    }


    try:
        a = AllOf(**data)
    except Exception as e:
        assert True
    else:
        assert False

    assert a.errors == {}
    assert a.all_of == []
    assert a.title == 'AllOf'



# Generated at 2022-06-24 10:44:34.712282
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem.base import Schema, TypeError
    import pytest
    n = NeverMatch()
    with pytest.raises(TypeError):
        n.validate(1)


# Generated at 2022-06-24 10:44:37.803477
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Negated=Boolean()).validate(True) == True
    assert Not(Negated=Boolean()).validate(False) == False


# Generated at 2022-06-24 10:44:43.823128
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Ensures that the method validate of class OneOf raises Exception when it should 
    data = {"movies": "Adventure"}
    one_of = OneOf([Field()], allow_null=False)
    with pytest.raises(Exception) as excinfo:
        one_of.validate(data, strict=False)
    assert '"oneOf": ["Did not match any valid type."]' in str(excinfo.value)



# Generated at 2022-06-24 10:44:53.046759
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    ite = IfThenElse(condition=String(max_length=5), then_clause=String(max_length=7))
    assert ite.validate("aaaaaa") == "aaaaaa"
    assert ite.validate("aaa") == "aaa"
    assert ite.validate("aaaaaaaa") == "aaaaaaaa"

# Generated at 2022-06-24 10:44:54.634803
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x.__init__ == None

# Generated at 2022-06-24 10:44:56.785109
# Unit test for method validate of class Not
def test_Not_validate():
    expected = ["not"]
    result = Not(None, None)
    assert result.validate(expected) == expected


# Generated at 2022-06-24 10:44:57.597166
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-24 10:44:58.126054
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:45:02.778485
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Testing the method validate of class OneOf
    # Declare the parameter of the method validate of class OneOf
    # Declare the parameter of the method validate of class OneOf
    # Validate the result of the method validate of class OneOf
    assert True == True
    """ 
    # Validate the result of the method validate of class OneOf
    assert True == True
    """

# Generated at 2022-06-24 10:45:05.193414
# Unit test for constructor of class Not
def test_Not():
    field1 = Not(negated='d')
    assert field1.negated == 'd'

# Generated at 2022-06-24 10:45:09.446050
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field_class = IfThenElse(Any(), Any(), Any())
    assert field_class.if_clause.__class__==Any
    assert field_class.then_clause.__class__==Any
    assert field_class.else_clause.__class__==Any


# Generated at 2022-06-24 10:45:12.113850
# Unit test for method validate of class Not
def test_Not_validate():
    s = Not(negated=AllOf([Any(), Any()]))
    assert s.validate(1) == 1
    with pytest.raises(s.validation_error):
        assert s.validate([1, 2])


# Generated at 2022-06-24 10:45:12.734893
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass

# Generated at 2022-06-24 10:45:16.021664
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(ValueError) as excinfo:
        NeverMatch().validate(5)
    assert str(excinfo.value) == "This never validates."
test_NeverMatch_validate()


# Generated at 2022-06-24 10:45:25.420731
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from .objects import Object, Member

    class Foo(Object):
        auth = AllOf([
            Member("password", String()),
            Member("client_id", String()),
        ])
        a = Member("a", String(), required=False)
        b = Member("b", String())

    f = Foo({"auth": {"password": "foo", "client_id": "bar"}})
    f.validate()
    f = Foo({"auth": {"password": "foo", "client_id": "bar"}, "b": "baz", "a": "qux"})
    f.validate()
    f = Foo({"auth": {"password": "foo", "client_id": "bar"}, "b": "baz"})
    f.validate()


# Generated at 2022-06-24 10:45:27.221837
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [String()]
    field = AllOf(all_of)
    assert field.all_of == all_of



# Generated at 2022-06-24 10:45:30.931865
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class A(AllOf):
        def __init__(self, all_of, **kwargs):
            super().__init__(all_of, **kwargs)
    # valid value, no error returned
    a = A(all_of=['A', 'B'])
    assert a.validate('A') == 'A'
    # invalid value, error returned
    a = A(all_of=['A', 'B'])
    assert a.validate('A', strict=True) == 'A'


# Generated at 2022-06-24 10:45:36.212124
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    test = Not(
        negated=String(min_length=1, max_length=5, pattern=r'a{3}', enum=['aaa'])
    )
    assert test.negated.pattern == r'a{3}'
    assert test.negated.max_length == 5
    assert test.er

# Generated at 2022-06-24 10:45:36.938033
# Unit test for method validate of class Not
def test_Not_validate():
    Not(None).validate(None)

# Generated at 2022-06-24 10:45:39.897635
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[])
    assert one_of.one_of == []



# Generated at 2022-06-24 10:45:41.557682
# Unit test for constructor of class AllOf
def test_AllOf():
	allof = AllOf([Any(), Any()])
	assert allof


# Generated at 2022-06-24 10:45:47.490010
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf([Any()], name='one')
    assert o.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert o.one_of[0] == Any()
    assert o.name == 'one'


# Generated at 2022-06-24 10:45:51.409580
# Unit test for method validate of class Not
def test_Not_validate():
    not_example1 = Not(1)
    assert not_example1.validate(2) == 2
    with pytest.raises(ValidationError) as excinfo:
        not_example1.validate(1)
    assert excinfo.match('negated')

# Generated at 2022-06-24 10:45:53.551045
# Unit test for constructor of class Not
def test_Not():
    negated = int()
    test = Not(negated)
    assert (test.negated == negated)


# Generated at 2022-06-24 10:45:54.772038
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import String, Integer
    assert OneOf([String(), Integer()])

# Generated at 2022-06-24 10:45:55.979337
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[])


# Generated at 2022-06-24 10:46:03.045292
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    aField = Field(name="aField")
    bField = Field(name="bField")
    cField = Field(name="cField")
    iteField = IfThenElse(if_clause=aField,then_clause=bField,else_clause=cField)
    value = 10
    validated_value = iteField.validate(value, True)
    assert validated_value == value

# Generated at 2022-06-24 10:46:04.326537
# Unit test for constructor of class AllOf
def test_AllOf():
    assert isinstance(AllOf, object)



# Generated at 2022-06-24 10:46:05.769788
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  # Test `__init__` of `NeverMatch` class
  pass

# Generated at 2022-06-24 10:46:11.365962
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert True == IfThenElse(if_clause=Field(), then_clause=Field()).validate(True)
    assert False == IfThenElse(if_clause=Field(), else_clause=Field()).validate(False)
    assert None == IfThenElse(if_clause=Field()).validate(True)

# Generated at 2022-06-24 10:46:23.045702
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Test the method validate of class AllOf
    field_1 = Integer.to_python(5)
    field_2 = Integer.to_python(-5)
    field_3 = Float.to_python(5.5)
    field_4 = String.to_python("A string")
    field = AllOf([field_1, field_2, field_3, field_4])
    assert field.validate(5) == 5
    assert field.validate("A string") == "A string"
    assert field.validate(5.5) == 5.5
    try:
        assert field.validate(1) == 1
    except ValueError:
        pass
    try:
        assert field.validate("Another string") == "Another string"
    except ValueError:
        pass

# Generated at 2022-06-24 10:46:30.698802
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def validate(val):
        if_clause = IfThenElse(
            Number(),
            then_clause=Integer(minimum=0),
            else_clause=Integer(minimum=1),
        )
        _, error = if_clause.validate_or_error(val)
        assert error is not None, "IfThenElse.validate() raises error"

    validate("")
    validate(" ")
    validate(1)
    validate(2)
    validate(3)


# Generated at 2022-06-24 10:46:33.976255
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=Any()).validate(value=1) == 1
    with pytest.raises(ValidationError):
        Not(negated=Any()).validate(value=None)
    
    

# Generated at 2022-06-24 10:46:40.397827
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    catch_all_schema = {"properties": {"*": {"type": "string"}}}
    field = IfThenElse(
        if_clause=catch_all_schema,
        then_clause=catch_all_schema,
        else_clause=catch_all_schema,
    )
    field.validate({"key": "value"})

# Generated at 2022-06-24 10:46:42.370521
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([
        Any(description="field 1"),
        Any(description="field 2"),
    ])
    field.validate(1)

# Generated at 2022-06-24 10:46:43.648031
# Unit test for constructor of class Not
def test_Not():
    field = Not(Integer())
    assert field.negated == Integer()

# Generated at 2022-06-24 10:46:47.459165
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        Not(String)

    x = Not(String, allow_null=False)
    assert x.negated.__class__ == String
    assert x.negated.allow_null == False


# Generated at 2022-06-24 10:46:56.714518
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Schema
    from typesystem.fields import String
    from typesystem.validators import min_length, regex

    class PersonSchema(Schema):
        name = String(validators=[min_length(5)])

    person = PersonSchema()
    person.validate({"name": "Mike"})
    assert person.errors == {'name': ["Must be at least 5 characters."]}

    schema = Not(
        person
    )

    schema.validate({"name": "Mike"})
    assert schema.errors == {}

    schema.validate({"name": "Stephen"})
    assert schema.errors == {'negated': 'Must not match.'}



# Generated at 2022-06-24 10:46:57.348205
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True is True

# Generated at 2022-06-24 10:47:04.668952
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    defined_type_1 = Any()
    defined_type_2 = Any()
    instance = OneOf(one_of = [defined_type_1, defined_type_2])
    # check initial state
    assert instance.one_of == [defined_type_1, defined_type_2]
    # run method under test
    result = instance.validate(value = {'test_key': 'test_value'})
    # assert result
    # check final state
    assert instance.one_of == [defined_type_1, defined_type_2]


# Generated at 2022-06-24 10:47:05.943369
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(), Field)


# Generated at 2022-06-24 10:47:09.694560
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print('Unit test for constructor of class NeverMatch')
    never_match = NeverMatch()
    assert never_match.name == ''
    assert never_match.description == ''
    assert never_match.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:47:12.468308
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Array
    allof = AllOf([Array(min_length=2), Array(max_length=5)])
    allof.validate([1, 2, 3, 4, 5])
    allof.validate([1, 2])
    allof.validate([1])

# Generated at 2022-06-24 10:47:15.887268
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    '''
    Test function validate of class AllOf
    '''
        
    all_of = [String(), Integer()]
    all_of = AllOf(all_of)
    all_of.validate(1)

# Generated at 2022-06-24 10:47:17.173491
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated == Field()

# Generated at 2022-06-24 10:47:28.586428
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(
        one_of=[
            Int(minimum=10, maximum=20),
            Int(minimum=1000, maximum=1200),
            Int(minimum=10000, maximum=20000),
        ]
    )
    assert field.validate(10) == 10
    assert field.validate(15) == 15
    assert field.validate(20) == 20
    assert field.validate(1000) == 1000
    assert field.validate(1050) == 1050
    assert field.validate(1200) == 1200
    assert field.validate(10000) == 10000
    assert field.validate(15000) == 15000
    assert field.validate(20000) == 20000

# Generated at 2022-06-24 10:47:32.025752
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:47:34.828612
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match = NeverMatch()
    with pytest.raises(FieldError):
        never_match.validate('random_value')



# Generated at 2022-06-24 10:47:36.492241
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True


# Generated at 2022-06-24 10:47:43.068390
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    valid_value = 1
    invalid_value = "invalid_value"
    field = OneOf([Integer(), String()])
    field.validate(valid_value)
    try:
        field.validate(invalid_value)
        assert False
    except ValidationError:
        assert True



# Generated at 2022-06-24 10:47:46.213517
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(FieldError) as excinfo:
        NeverMatch().validate("some value")
    assert excinfo.value.code == "never"
    assert excinfo.value.message == "This never validates."


# Generated at 2022-06-24 10:47:54.745983
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem import Structure

    class Person(Structure):
        first_name = NeverMatch()

    # test
    person = Person({"first_name": "John"})
    assert person.validate_or_error()

# Generated at 2022-06-24 10:47:56.884317
# Unit test for method validate of class Not
def test_Not_validate():
    not1 = Not(Field(label="Field 1"))
    not1.validate("a string that must not be included", strict=False)



# Generated at 2022-06-24 10:48:01.110387
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        if_c = IfThenElse(None, None, None)

        if if_c is not None:
            print("Test 1 passed")
    except AssertionError:
        print("Test 1 failed")

if __name__ == "__main__":
    test_IfThenElse()

# Generated at 2022-06-24 10:48:06.701461
# Unit test for constructor of class Not
def test_Not():
    if_clause = Field(required=True)
    then_clause = Field(required=False)
    else_clause = Field(required=False)
    test_case = IfThenElse(if_clause,then_clause,else_clause)
    assert isinstance(test_case, IfThenElse) is True

# Generated at 2022-06-24 10:48:13.523928
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=AllOf(all_of=[Field()]), then_clause=Field(), else_clause=Field()).validate(value=True, strict=False) == True
    assert IfThenElse(if_clause=AllOf(all_of=[Field()]), then_clause=Field(), else_clause=Field()).validate(value=False, strict=False) == False
    assert IfThenElse(if_clause=AllOf(all_of=[Field()])).validate(value=False, strict=False) == None

# Generated at 2022-06-24 10:48:20.209073
# Unit test for constructor of class OneOf
def test_OneOf():
	try:
		a = "empty"
		b = [Field(),Field()]
		c = OneOf(a)
		assert False, "Expected assertion error not thrown!"
	except Exception:
		pass
	
	a = "list of objects"
	b = [Field(),Field()]
	c = OneOf(b)
	assert c.one_of == b
	

# Generated at 2022-06-24 10:48:30.113746
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.base import Error
    from typesystem.primitives import Boolean, String
    from typesystem.testing import assert_error_message_equal
    from typesystem.validators import MaxLengthValidator

    field = IfThenElse(
        if_clause=Boolean(),
        then_clause=String(validators=[MaxLengthValidator(max_length=10)]),
    )

    # if_clause = false, String: valid
    assert field.validate(False) == False
    # if_clause = true, String: valid
    assert field.validate(True) == True

    # if_clause = true, wrong type
    assert_error_message_equal(field.validate_or_error(10), "value_error.any")

# Generated at 2022-06-24 10:48:32.076138
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        test_field = IfThenElse()
        assert False, "Allowed IfThenElse constructor without arguments"
    except TypeError:
        assert True