

# Generated at 2022-06-24 10:38:38.643279
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    test_input_valid_input = [
        ([1, 2, 3], 1),
        ([1, 2, 3], 2),
        ([1, 2, 3], 3),
        (["1", "2", "3"], "1"),
        (["1", "2", "3"], "2"),
        (["1", "2", "3"], "3"),
        ([1, "2", 3], 1),
        ([1, "2", 3], "2"),
        ([1, "2", 3], 3),
    ]

    test_input_zero_match = [
        ([1, 2, 3], "4"),
        (["1", "2", "3"], "4"),
        ([1, "2", 3], "4"),
    ]


# Generated at 2022-06-24 10:38:42.294075
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = String() # test input
    then_clause = String() # test input
    else_clause = String() # test input
    kwargs = {}
    obj = IfThenElse(if_clause,then_clause,else_clause,**kwargs)
    value = "" # test input
    strict = False # test input
    # Run the test (validate)
    assert obj.validate(value,strict) == value


# Generated at 2022-06-24 10:38:43.985028
# Unit test for constructor of class Not
def test_Not():
	not_test = Not(Any())
	assert not_test.negated


# Generated at 2022-06-24 10:38:45.974340
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=String())
    assert not_field.negated.name is None


# Generated at 2022-06-24 10:38:49.316342
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(field.validation_error) as e:
        field.validate("42")
    
    assert e.value.code == "never"
    assert e.value.message == "This never validates."

# Generated at 2022-06-24 10:38:59.695493
# Unit test for constructor of class OneOf
def test_OneOf():
    # C1
    # Test for correct inputs
    one_of_c1 = OneOf([Any(), Any()])
    assert not hasattr(one_of_c1, "allow_null")
    assert one_of_c1.one_of == [Any(), Any()]

    # C2
    # Test for incorrect inputs
    try:
        one_of_c2 = OneOf([Any(), 1])
        assert False
    except AssertionError:
        assert True

    # C3
    # Test for incorrect inputs
    try:
        one_of_c3 = OneOf([Any(), Any(), 1])
        assert False
    except AssertionError:
        assert True

    # C4
    # Test for incorrect inputs

# Generated at 2022-06-24 10:39:03.104467
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(Field.ValidationError, match=r"Did not match any valid type."):
        field = OneOf(one_of=[NeverMatch()])
        field.validate(1)


# Generated at 2022-06-24 10:39:04.019510
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([]) is not None



# Generated at 2022-06-24 10:39:08.262147
# Unit test for constructor of class OneOf
def test_OneOf():
    number_field = Field(type_name='number')
    string_field = Field(type_name='string')
    field_list = [number_field, string_field]
    oneOf = OneOf(field_list)
    assert oneOf.one_of[0] == number_field
    assert oneOf.one_of[1] == string_field


# Generated at 2022-06-24 10:39:09.787304
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n.validate(0) == "This never validates."


# Generated at 2022-06-24 10:39:11.960044
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer
    from typesystem.fields.complex import OneOf
    a = Integer()
    b = Integer(maximum=10)
    c = OneOf([a, b])
    assert c.validate(5) == 5
    assert c.validate(11) == 11

# Generated at 2022-06-24 10:39:22.388659
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Test with all optional clauses
    test = IfThenElse(Any(), None, None)
    assert test.if_clause == Any()
    assert test.then_clause == Any()
    assert test.else_clause == Any()

    # Test with only else clause
    test = IfThenElse(Any(), else_clause=None)
    assert test.if_clause == Any()
    assert test.then_clause == Any()
    assert test.else_clause == Any()

    # Test with only then clause
    test = IfThenElse(Any(), then_clause=None)
    assert test.if_clause == Any()
    assert test.then_clause == Any()
    assert test.else_clause == Any()

    # Test with completely filled out constructor

# Generated at 2022-06-24 10:39:28.358135
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_then():
        if_clause = Integer(minimum=1)
        then_clause = Integer(maximum=100)
        else_clause = Integer(maximum=200)
        value = 100
        value_validate = IfThenElse(if_clause, then_clause, else_clause).validate(value)
        assert value == value_validate

    def test_else():
        if_clause = Integer(minimum=1)
        then_clause = Integer(maximum=100)
        else_clause = Integer(maximum=200)
        value = 1000
        value_validate = IfThenElse(if_clause, then_clause, else_clause).validate(value)
        assert value == value_validate

    test_then()
    test_else()

# Generated at 2022-06-24 10:39:29.858884
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    
    assert IfThenElse(if_clause, then_clause).validate(None) == None


# Generated at 2022-06-24 10:39:40.669860
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.types import TextType
    from typesystem.exceptions import ValidationError

    str_type = TextType()
    test_object = Not(negated=str_type)

    assert test_object.key == 'Not'
    assert test_object.errors == {'negated': 'Must not match.'}
    assert test_object.negated == str_type
    assert test_object.description == 'Must not match.'

    try:
        test_object.validate('Hello')
        assert False
    except ValidationError:
        pass

    assert test_object.validate(3) == 3

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 10:39:42.282867
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate("not a null") != None


# Generated at 2022-06-24 10:39:49.060615
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of=[])
    assert field.key_is_optional()
    assert field.get_default() is None
    assert field.get_empty() is None
    assert isinstance(field.validate_for_swagger(), dict)
    field.validate(None)


# Generated at 2022-06-24 10:39:56.724614
# Unit test for constructor of class IfThenElse
def test_IfThenElse():

    expected = (
        Field,
        Field(name="if_clause"),
        Field(name="if_clause", description=""),
        Field(name="if_clause", description="", required=True),
        Field(name="if_clause", description="", required=False),
        Field(name="if_clause", description="", required=False, allow_null=True)
    )


# Generated at 2022-06-24 10:39:58.654192
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-24 10:39:59.244122
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass

# Generated at 2022-06-24 10:40:00.078541
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(1,2,3) is not None

# Generated at 2022-06-24 10:40:07.975938
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    from typesystem import Form
    # both then and else match
    assert IfThenElse(String(), String(), String())
    form = Form({
        'name': IfThenElse(String(), String(), String())
    })
    assert form.validate({
        'name': 'A String'
    })
    # neither then nor else match
    assert IfThenElse(String(), String(), String())
    form = Form({
        'name': IfThenElse(String(), String(), String())
    })
    assert form.validate({
        'name': 123
    }) == {
        'name': ['Did not match any valid type.']
    }
    # only else matches
    assert IfThenElse(String(), String(), String())

# Generated at 2022-06-24 10:40:15.098299
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    input1 = [1, 2, 3]
    input2 = 4
    input3 = "abcd"
    output1 = 4
    output2 = "abcd"

    field = OneOf([
        Field(type = int),
        Field(type = str)
    ])

    result1 = field.validate(input1)
    result2 = field.validate(input2)
    result3 = field.validate(input3)
    
    assert result1 == output1
    assert result2 == output2
    assert result3 == output3


# Generated at 2022-06-24 10:40:15.643144
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True

# Generated at 2022-06-24 10:40:18.722753
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test .__init__()
    # Default Arguments
    field = AllOf([], **{})
    assert field.all_of == [], f".__init__() != {field.all_of}"


# Generated at 2022-06-24 10:40:20.901847
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f = IfThenElse(String(), String(), String())
    assert f.validate(u'abc') == u'abc'

# Generated at 2022-06-24 10:40:23.883580
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated='1')
    assert field.negated=='1'
    assert field.errors=={'negated': 'Must not match.'}
    assert not field.allow_null


# Generated at 2022-06-24 10:40:25.965608
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String

    field = AllOf([String(max_length=10)])
    field.validate('test')



# Generated at 2022-06-24 10:40:27.736159
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    obj = IfThenElse(Any)
    obj.validate(0)


# Generated at 2022-06-24 10:40:29.665467
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_field = NeverMatch()
    assert test_field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:40:42.071635
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Test case for method validate of class Not.
    """
    from typesystem.fields import String
    from typesystem.errors import ValidationError
    from typesystem.errors import ErrorMessage
    import pytest # type: ignore
    class TestClass():
        """
        Test class for method validate of class Not.
        """
        def test_method_validate_of_class_Not(self):
            """
            Test method validate of class Not.
            """
            str_field = String()
            not_field = Not(str_field)
            try:
                not_field.validate(1)
            except Exception as caught_exception:
                assert type(caught_exception) is ValidationError

# Generated at 2022-06-24 10:40:44.339608
# Unit test for constructor of class Not
def test_Not():
    test_negated = None
    test_kwargs = dict()
    test_not = Not(test_negated, **test_kwargs)
    assert test_not


# Generated at 2022-06-24 10:40:48.728851
# Unit test for constructor of class OneOf
def test_OneOf():
    import typesystem
    # EncodableField
    class String(typesystem.String):
        ...
    # Field
    class Integer(typesystem.Integer):
        ...
    field = typesystem.OneOf([
        String(),
        Integer(),
    ])
    assert field.one_of == [
        String(),
        Integer(),
    ]

# Generated at 2022-06-24 10:40:54.517806
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=String(),
        then_clause=Integer(),
        else_clause=Dict(properties={"x":String()}),
        label="if then else"
    )
    value = field.validate({"x":"x"})
    assert value == {"x":"x"}

    value = field.validate(10)
    assert value == 10

# Generated at 2022-06-24 10:40:55.792471
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert True

# Generated at 2022-06-24 10:40:57.498646
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass # TODO: implement your test here


# Generated at 2022-06-24 10:41:07.628583
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # This test assumes that the class Any and the method validate_or_error of class Field are tested.

    # Test OneOf.validate when a match has been found (one_of = [Any(), Float()])
    f = OneOf(one_of=[Any(), Float()])
    assert f.validate(1) == 1
    assert f.validate(1.0) == 1.0

    # Test OneOf.validate when multiple matches are found (one_of = [Integer(), Integer()])
    f = OneOf(one_of=[Integer(), Integer()])
    try:
        f.validate(1.0)
    except Exception as exc:
        assert f"{exc}" == "Matched more than one type."

    # Test OneOf.validate when no match is found (one_of = [String(), Integer(), Float()

# Generated at 2022-06-24 10:41:18.811671
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f1 = AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[AllOf(all_of=[Any()])])])])])])])])])])])])])])])])])])

# Generated at 2022-06-24 10:41:24.649494
# Unit test for constructor of class OneOf
def test_OneOf():
    test_type = OneOf(
        [
            Field(name="test", description="test"),
        ],
        name="test",
        description="test",
    )
    assert test_type.one_of[0].name == "test"
    assert test_type.one_of[0].description == "test"
    assert test_type.name == "test"
    assert test_type.description == "test"



# Generated at 2022-06-24 10:41:32.617116
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    def __init__(self, one_of: typing.List[Field], **kwargs: typing.Any) -> None:
        assert "allow_null" not in kwargs
        super().__init__(**kwargs)
        self.one_of = one_of

    def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
        candidate = None
        match_count = 0
        for child in self.one_of:
            validated, error = child.validate_or_error(value, strict=strict)
            if error is None:
                match_count += 1
                candidate = validated

        if match_count == 1:
            return candidate
        elif match_count > 1:
            raise self.validation_error("multiple_matches")
        raise self.validation_

# Generated at 2022-06-24 10:41:35.330946
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of_instance = AllOf([Any()])
    all_of_instance.validate(1)


# Generated at 2022-06-24 10:41:37.723348
# Unit test for constructor of class Not
def test_Not():
    a = Not(IfThenElse(Any(), Any(), Any()))
    print(a.errors)

# Generated at 2022-06-24 10:41:39.663597
# Unit test for constructor of class Not
def test_Not():
    f = Not(negated=Any())
    g = Any()
    assert f.negated is g

# Generated at 2022-06-24 10:41:44.081875
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem import Any, Field, Validator

    # test setUp and tearDown
    validator = Validator([NeverMatch()])
    assert validator.dump([]) == [{"type": "never"}]
    assert validator.dump(True) == [{"type": "never"}]


# Generated at 2022-06-24 10:41:47.846825
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any(format="uri"), Any(format="email")])
    field.validate("foo@gmail.com")
    field.validate("https://foo.com")
    with pytest.raises(ValidationError):
        field.validate("someone")


# Generated at 2022-06-24 10:41:51.996436
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    try:
        not_field.validate(1)
        assert True
    except:
        assert False


# Generated at 2022-06-24 10:41:52.742205
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    pass

# Generated at 2022-06-24 10:42:00.950298
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, Schema
    from typesystem.validators import Min, Max
    schema = Schema({'a': IfThenElse(if_clause=Integer(min_value=100), then_clause=Integer(max_value=100)),'b': IfThenElse(if_clause=Integer(min_value=100), then_clause=Integer(max_value=100))})
    data = {'a': 200, 'b': 300}
    actual = schema.validate(data, raise_exceptions=False)
    assert actual['a'] is None and 'errors' in actual
    assert actual['b'] is None and 'errors' in actual
test_IfThenElse_validate()

# Generated at 2022-06-24 10:42:02.611704
# Unit test for constructor of class Not
def test_Not():
  not_inst = Not(5)
  assert not_inst.validate(5) == None

# Generated at 2022-06-24 10:42:11.480272
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    string_length = AllOf(all_of = [String(max_length=4), String(min_length=2)])
    assert string_length.validate('aa', strict = True) == 'aa'
    assert string_length.validate('a', strict = True) == 'a'
    assert string_length.validate('aaaa', strict = True) == 'aaaa'
    try:
        string_length.validate(None, strict = True)
    except Exception as e:
        assert str(e) == 'This field is required.'
    try:
        string_length.validate('', strict = True)
    except Exception as e:
        assert str(e) == 'Must have a length greater than or equal to 2.'

# Generated at 2022-06-24 10:42:13.766821
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.errors == {"negated": "Must not match."}
    assert 'negated' in field.errors
    

# Generated at 2022-06-24 10:42:18.527800
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    """Unit test for constructor of class IfThenElse"""
    ite = IfThenElse("if_clause", "then_clause", "else_clause")
    assert ite.if_clause == "if_clause"
    assert ite.then_clause == "then_clause"
    assert ite.else_clause == "else_clause"

# Generated at 2022-06-24 10:42:27.880846
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(required=True, description="if clause")
    then_clause = Field(required=True, description="then clause")
    value = 123
    strict = False
    if_else = IfThenElse(if_clause,then_clause)
    assert if_else.validate(value,strict) == value

# Test above
# Some data that is not required by the IfThenElse class
value = 123
strict = False
if_clause = Field(required=True, description="if clause")
then_clause = Field(required=True, description="then clause")
# The actual test
if_else = IfThenElse(if_clause,then_clause)
if_else.validate(value,strict)

# Generated at 2022-06-24 10:42:29.671926
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-24 10:42:30.665005
# Unit test for constructor of class AllOf
def test_AllOf():
    x = AllOf([], required=True, name="")


# Generated at 2022-06-24 10:42:31.810816
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    t = NeverMatch()
    assert t.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:42:35.374306
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    string_field = String()
    all_of_field = AllOf([string_field])
    assert all_of_field.all_of == [string_field]


# Generated at 2022-06-24 10:42:38.717699
# Unit test for constructor of class Not
def test_Not():
    from typesystem.types import String

    type = Not(negated=String())
    assert type.__class__.__name__ == 'Not'


# Generated at 2022-06-24 10:42:45.625299
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = typesystem.Integer()
    b = typesystem.String()
    c = OneOf([a, b])
    assert c.validate(1) == 1
    assert c.validate("hello") == "hello"
    with pytest.raises(typesystem.ValidationError):
        c.validate(1.1)
    with pytest.raises(typesystem.ValidationError):
        c.validate([1])

# Generated at 2022-06-24 10:42:50.655776
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[
        String(),
        Number(),
        ])

    assert one_of.name is None
    assert one_of.description == ''
    assert one_of.required == False
    assert one_of.read_only == False
    assert one_of.write_only == False
    assert one_of.default is None
    assert one_of.one_of == [String(), Number()]


# Generated at 2022-06-24 10:42:53.700783
# Unit test for constructor of class OneOf
def test_OneOf():
    test_one_of = OneOf((int, float))
    assert test_one_of.errors['no_match'] == "Did not match any valid type."
    assert test_one_of.errors['multiple_matches'] == "Matched more than one type."


# Generated at 2022-06-24 10:42:54.437865
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass


# Generated at 2022-06-24 10:42:56.598511
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String

    String(min_length=1)
    String(max_length=1)
    String()
    String()

# Generated at 2022-06-24 10:42:58.661059
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test = IfThenElse(if_clause=Any(), then_clause=Any())
    test.validate("")
    test = IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch())
    test.validate("")

# Generated at 2022-06-24 10:43:01.510132
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Arrange
    t=NeverMatch       
    # Act
    # Assert
    assert t.validate(None,False)==None
    assert t.validate(True,False)


# Generated at 2022-06-24 10:43:04.461402
# Unit test for method validate of class Not
def test_Not_validate():
  not_object = Not(negated='hello')
  assert not_object.validate('hello') == 'hello'


# Generated at 2022-06-24 10:43:08.339853
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()

# Generated at 2022-06-24 10:43:18.217946
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([IntegerField()]).validate(1) == 1
    assert OneOf([IntegerField()]).validate(1.0) == 1
    assert OneOf([IntegerField()]).validate(1.1) == 1
    assert OneOf([NumberField()]).validate(1) == 1
    assert OneOf([NumberField()]).validate(1.0) == 1.0
    assert OneOf([NumberField()]).validate(1.1) == 1.1
    assert OneOf([StringField()]).validate(1) == '1'
    assert OneOf([StringField()]).validate(1.0) == '1.0'
    assert OneOf([StringField()]).validate(1.1) == '1.1'

# Generated at 2022-06-24 10:43:20.633410
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(Boolean())
    assert f.validate(1) == 1
    try:
        f.validate(True)
        assert False, "Not match validation error not raised"
    except FieldValidationError:
        pass

# Generated at 2022-06-24 10:43:21.097307
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-24 10:43:26.719195
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    print("test_NeverMatch_validate")
    never = NeverMatch()
    try:
        never.validate(1,strict=True)
        assert False
    except NeverMatch.ValidationError as e:
        assert e.code == "never"
    print("passed test_NeverMatch_validate")


# Generated at 2022-06-24 10:43:30.082119
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Any(), Any())
    assert field.if_clause is not None
    assert field.then_clause is not None
    assert field.else_clause is not None

# Generated at 2022-06-24 10:43:33.353656
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    myIfThenElse = IfThenElse(AllOf([String()]))
    

# Generated at 2022-06-24 10:43:35.208826
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:43:38.235302
# Unit test for constructor of class AllOf
def test_AllOf():
    with pytest.raises(AssertionError):
        AllOf(field_name='test_all_of', all_of=[], allow_null=['test_null'])



# Generated at 2022-06-24 10:43:39.957775
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    a = String(max_length=10)
    b = String(min_length=2)
    c = String(max_length=30)
    d = AllOf([a,b,c])


# Generated at 2022-06-24 10:43:42.542020
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True # TODO: implement your test here


# Generated at 2022-06-24 10:43:44.083209
# Unit test for constructor of class AllOf
def test_AllOf():
    a1 = AllOf([Field(name=None, required=True),Field(name=None, required=False)])
    assert a1.required == True

# Generated at 2022-06-24 10:43:46.974552
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    method = NeverMatch().validate
    # Call
    result = method("foo")
    # AssertionError: Validation failed for <NeverMatch: foo>
    assert False


# Generated at 2022-06-24 10:43:48.918497
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=["test"])
    assert field.one_of == ["test"]



# Generated at 2022-06-24 10:43:50.605859
# Unit test for constructor of class Not
def test_Not():
    f = Not(None)
    assert f.negated == None


# Generated at 2022-06-24 10:43:52.436278
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    f = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())

# Generated at 2022-06-24 10:43:53.501033
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(Any(), None, None)

# Generated at 2022-06-24 10:44:00.495504
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer
    field = OneOf([Integer(min_value=1), Integer(max_value=10)])
    field.validate(5)
    field.validate(1)
    try:
        field.validate(20)
    except Exception as e:
        assert e.messages == {'no_match': 'Did not match any valid type.'}

    try:
        field.validate(6)
    except Exception as e:
        assert e.messages == {'multiple_matches': 'Matched more than one type.'}


# Generated at 2022-06-24 10:44:08.081622
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any()])
    valid, error = field.validate_or_error(1)
    assert valid == 1
    assert error is None


# Generated at 2022-06-24 10:44:13.859045
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    unit_under_test = IfThenElse(if_clause, then_clause, else_clause)

    # Test for if_clause is None
    if_clause = None
    then_clause = Field()
    else_clause = Field()
    unit_under_test = IfThenElse(if_clause, then_clause, else_clause)
    expected = None
    actual = unit_under_test.validate(None)
    assert expected == actual

    # Test for else_clause is None
    if_clause = Field()
    then_clause = Field()
    else_clause = None

# Generated at 2022-06-24 10:44:15.820228
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # type: () -> None
    field = NeverMatch()
    assert not field.validate(None)


# Generated at 2022-06-24 10:44:18.184274
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    j = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())

# Generated at 2022-06-24 10:44:23.530117
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_field = Integer(minimum=10)
    then_field = Integer(minimum=20)
    else_field = Integer(minimum=30)
    test_field = IfThenElse(if_field, then_field, else_field)
    test_value = 21
    validated_value = test_field.validate(test_value)
    assert validated_value == test_value

# Generated at 2022-06-24 10:44:29.730629
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    """Test method validate of class NeverMatch."""

    # Setup
    nm = NeverMatch()

    # Exercise
    with pytest.raises(ValidationError) as exc_info:
        nm.validate(5)

    # Verify
    assert exc_info.match(r"This never validates\.") is not None
    assert exc_info.value.code == "never"
    assert exc_info.value.params == {}


# Generated at 2022-06-24 10:44:39.982127
# Unit test for constructor of class AllOf
def test_AllOf():
    # initialize an object reffering to Class AllOf
    from typesystem.fields import Boolean, Number
    a = AllOf([Number(),Boolean()])
    # check if a is an object of Class AllOf
    assert isinstance(a,AllOf) == True
    # check if a has the right number of fields
    assert hasattr(a,'all_of') == True
    # check if a has the right number of fields
    # (excluding the fields in the constructor)
    assert len(a.__dict__.keys()) == 1


# Generated at 2022-06-24 10:44:43.411833
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    one_of = OneOf([String()])
    assert one_of.one_of[0] == String()
    assert "no_match" in one_of.errors


# Generated at 2022-06-24 10:44:44.072676
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([])

# Generated at 2022-06-24 10:44:50.373062
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass
    # one_of = OneOf(one_of=[], allow_null=True)
    # value = ""
    # strict = True
    # one_of.validate(value, strict)


# Generated at 2022-06-24 10:44:55.701759
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    try:
        not1 = Not(String())
        assert not1.error_messages == Not.errors
        assert not1.negated is not None
    except TypeError:
        print("Error in the test for constructor of class Not.")


# Generated at 2022-06-24 10:44:57.453966
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Any())



# Generated at 2022-06-24 10:44:58.004270
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert False

# Generated at 2022-06-24 10:45:00.412293
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import fields
    from typesystem_json_schema import JSONSchemaField

    fields.OneOf([fields.String()])
    fields.OneOf([JSONSchemaField({})])


# Generated at 2022-06-24 10:45:03.872148
# Unit test for constructor of class AllOf
def test_AllOf():
    try:
        temp = AllOf(all_of=5, description='', name='', type_='')
        assert False
    except:
        pass


# Generated at 2022-06-24 10:45:06.321798
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_field = IfThenElse(if_clause=Any(), then_clause=Any())
    assert test_field.then_clause.__class__.__name__ == "Any"

# Generated at 2022-06-24 10:45:09.744257
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.errors == {
        'no_match': 'Did not match any valid type.',
        'multiple_matches': 'Matched more than one type.'
    }


# Generated at 2022-06-24 10:45:12.067688
# Unit test for constructor of class OneOf
def test_OneOf():
    one = Field()
    another = Field()
    o = OneOf([one, another])
    assert o.one_of == [one, another], f"expected [one, another] but got {o.one_of}"

# Generated at 2022-06-24 10:45:15.738969
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        class TestOneOf(OneOf):
            def __init__(self):
                super().__init__(
                    [Int(), Int()]
                )
    except TypeError as e:
        assert "one_of must be" in str(e)


# Generated at 2022-06-24 10:45:21.675405
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ite = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert ite.if_clause is not None
    assert ite.then_clause is not None
    assert ite.else_clause is not None
    # default argument test
    ite = IfThenElse(if_clause=Any())
    assert ite.if_clause is not None
    assert ite.then_clause is not None
    assert ite.else_clause is not None



# Generated at 2022-06-24 10:45:25.786706
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Raiserror if attribute allow_null is given
    try:
        NeverMatch(allow_null=True)
    except:
        assert True
    else:
        assert True == False
    # No error if attribute allow_null is not given
    try:
        NeverMatch()
    except:
        assert True == False
    else:
        assert True


# Generated at 2022-06-24 10:45:37.221103
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.typing import JSONDict, JSONList, Integer as T_Integer
    from typesystem.schema.common import add_type_metadata
    from typesystem.typing import TypedJSONDict, TypedJSONList
    from typing import Type

    def unbox(node):
        if isinstance(node, (TypedJSONDict, TypedJSONList)):
            return node.value
        else:
            return node

    class Document(TypedJSONDict):
        d: TypedJSONDict
        e: TypedJSONList

    def _test(schema, value, then_value, else_value):
        if_clause = schema
        then_clause = Document.of(d=then_value)

# Generated at 2022-06-24 10:45:42.507781
# Unit test for constructor of class AllOf
def test_AllOf():
    # assert 1
    all_of = AllOf(
        [
            Field.build(
                type="string",
                description="Django field description for the ``value`` field.",
                max_length=255
            )
        ]
    )
    assert all_of.validate("Some random string")


# Generated at 2022-06-24 10:45:46.265319
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print("Unit test for class NeverMatch")
    never_match = NeverMatch()

    try:
        never_match.validate(1)
    except Exception as e:
        print(e.args)


# Generated at 2022-06-24 10:45:47.395018
# Unit test for constructor of class AllOf
def test_AllOf():
    assert all_of is not None


# Generated at 2022-06-24 10:45:49.498987
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    assert field.validate(1) is None

# Generated at 2022-06-24 10:45:50.485151
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert Field().__class__ == Field

# Generated at 2022-06-24 10:45:53.779497
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String

    not_field = Not(String())
    val =  not_field.validate(10, strict=True)
    assert val == 10



# Generated at 2022-06-24 10:46:03.943527
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # First test field
    field_one_of_1 = String(required=True, description="A description")
    field_one_of_2 = String(required=True, description="A description")
    field_one_of_3 = Array(String(required=True, description="A description"))
    field_one_of_4 = OneOf([field_one_of_1, field_one_of_2, field_one_of_3], required=True, description="A description")

    assert field_one_of_4.validate([1, 2, 3]) == [1, 2, 3]
    assert field_one_of_4.validate(["hey", "man"]) == ["hey", "man"]
    assert field_one_of_4.validate("hey") == "hey"

    # Second test field


# Generated at 2022-06-24 10:46:05.201202
# Unit test for method validate of class Not
def test_Not_validate():
    field=Not("")
    assert field.validate("")==""

# Generated at 2022-06-24 10:46:07.974583
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # tests validate method of IfThenElse
    assert IfThenElse(Int(), String()).validate(1)=="1"
    assert IfThenElse(Int(), String()).validate("1") == "1"

# Generated at 2022-06-24 10:46:14.254907
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class Example(AllOf):
        def __init__(self, all_of, **kwargs):
            self.all_of = all_of
    all_of = [FakeField()]
    example = Example(all_of, required=True)
    value = FakeValue()
    assert example.validate(value) == value


# Generated at 2022-06-24 10:46:24.603280
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_if_then_else(if_clause, then_clause, else_clause, value, expected):
        field = IfThenElse(if_clause, then_clause, else_clause)
        actual = field.validate(value)
        assert actual == expected

    test_if_then_else(Any(), Any(), Any(), 1, 1)
    test_if_then_else(Any(), Any(), Any(), 0, 0)
    test_if_then_else(None, Any(), Any(), 1, 1)
    test_if_then_else(None, Any(), Any(), 0, 0)
    test_if_then_else(False, Any(), Any(), 1, 1)
    test_if_then_else(False, Any(), Any(), 0, 0)

# Generated at 2022-06-24 10:46:28.228392
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Test validate method of class AllOf
    """
    field = AllOf(all_of = [])
    try:
        field.validate(123)
    except Exception:
        assert False
    else:
        assert True



# Generated at 2022-06-24 10:46:29.326052
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Any()).validate(None) == None
    # TODO: test other cases


# Generated at 2022-06-24 10:46:33.817815
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([
        Field(validators=['is_odd'], label="First number"),
        Field(validators=['is_even'], label="Second number")
    ])
    validated_value, error = field.validate_or_error(1)
    assert validated_value == 1
    assert error is None
    

# Generated at 2022-06-24 10:46:39.258034
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    '''
    Testing for constructor of class IfThenElse
    '''
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    obj = IfThenElse(if_clause, then_clause, else_clause)
    assert obj

# Generated at 2022-06-24 10:46:42.200922
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated = SomeInt()).validate(3) == 3
    try:
        Not(negated = SomeInt()).validate("3")
    except ValidationError:
        pass

# Generated at 2022-06-24 10:46:43.802994
# Unit test for constructor of class Not
def test_Not():
    # type: () -> None
    assert isinstance(Not(negated=Field()), Not)


# Generated at 2022-06-24 10:46:49.591584
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Create AllOf object and sub_items
    sub_items = [Boolean(), String(), Hash()]
    all_of = AllOf(all_of=sub_items)

    # Test
    value = True
    actual = all_of.validate(value=value)

    # Verify
    assert actual == value

# Generated at 2022-06-24 10:46:51.449278
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    type = "NeverMatch"
    field = NeverMatch()
    assert field.type == type


# Generated at 2022-06-24 10:46:54.223072
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import json
    import numpy as np
    import pandas as pd

    from typesystem.exceptions import ValidationError

    with pytest.raises(ValidationError) as excinfo:
        NeverMatch().validate(None)
    assert excinfo.value.error == "never"



# Generated at 2022-06-24 10:47:01.057152
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Case when value is a valid string
    foo = AllOf(all_of=[Field.construct("string")])
    bar = "foo"
    foo.validate(bar)
    
    # Case when value is an invalid string
    foo = AllOf(all_of=[Field.construct("string")])
    bar = 1
    with pytest.raises(TypeError):
        foo.validate(bar)


# Generated at 2022-06-24 10:47:04.041066
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_field = IfThenElse(if_clause=Int())
    assert test_field.if_clause is not None
    assert test_field.then_clause is not None
    assert test_field.else_clause is not None

# Generated at 2022-06-24 10:47:09.266250
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    Test for method validate of class OneOf
    """
    class DummyField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    field = OneOf([DummyField(name="a"), DummyField(name="b")])
    field.validate("test_value")
    assert True

test_OneOf_validate()


# Generated at 2022-06-24 10:47:10.466008
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    pass #TODO: test for method validate of class NeverMatch



# Generated at 2022-06-24 10:47:12.861919
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.type == "never_match"


# Generated at 2022-06-24 10:47:15.182586
# Unit test for constructor of class Not
def test_Not():
    this = Not(negated=None)
    assert this.negated == None


# Generated at 2022-06-24 10:47:17.173486
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String
    x = AllOf([String()]).validate('asdf')
    assert x == 'asdf'

# Generated at 2022-06-24 10:47:26.489688
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class TestClause(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == "5":
                return value
            else:
                raise self.validation_error("negated")

    ite = IfThenElse(TestClause(), TestClause(), TestClause())
    assert ite.validate("5") == "5"
    try:
        ite.validate("6")
    except Exception as e:
        assert str(e) == "negated"
    else:
        assert False

test_IfThenElse()

# Generated at 2022-06-24 10:47:29.972975
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any(), default="default")
    val_1 = field.validate("hello")
    assert val_1 == "hello"
    try:
        field.validate(3)
    except Exception as e:
        assert e.detail["error"] == "negated"
        pass


# Generated at 2022-06-24 10:47:35.195983
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem

    class A(typesystem.Schema):
        a = typesystem.Integer(0)
        b = typesystem.Integer(1)


    a = A()
    assert a.validate({"a": 0, "b": 1}) == {"a": 0, "b": 1}
    assert a.validate({"a": 1, "b": 1}) == {"a": 1, "b": 1}
    assert a.validate({"a": 1, "b": 0}) == {"a": 1, "b": 0}
    assert a.validate({"a": 0, "b": 0}) == {"a": 0, "b": 0}
    assert a.validate({"a": 0}) == {"a": 0, "b": 1}

# Generated at 2022-06-24 10:47:42.401750
# Unit test for method validate of class Not
def test_Not_validate():
    negated = Field()
    not_field = Not(negated)
    assert not_field.validate(10) == 10
    with pytest.raises(FieldValidationError):
        not_field.validate(None)


# Generated at 2022-06-24 10:47:46.550570
# Unit test for constructor of class Not
def test_Not():
    # Shouldn't be able to create without schema
    try:
        Not()
    except(TypeError):
        assert True
    except:
        assert False
    # Should be able to create with schema
    try:
        Not(Any())
    except(TypeError):
        assert False
    except:
        assert False


# Generated at 2022-06-24 10:47:51.374998
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Any()) is not None

# Generated at 2022-06-24 10:48:00.626329
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class TestClass:
        def test_validate(self):
            field = AllOf([])
            assert field.validate(42) == 42

            field = AllOf([Int()])
            assert field.validate(42) == 42
            with pytest.raises(ValidationError):
                field.validate("nope")

            field = AllOf([Int(), Int()])
            assert field.validate(42) == 42
            with pytest.raises(ValidationError):
                field.validate("nope")

    instance = TestClass()
    instance.test_validate()


# Generated at 2022-06-24 10:48:05.125271
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from pprint import pprint
    from jsonschema import validate
    schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "title": "Product",
        "description": "A product from Acme's catalog",
        "type": "object",
        "properties": {
            "productId": {
                "description": "The unique identifier for a product",
                "type": "integer"
            }
        },
        "required": ["productId"]
    }

    validate({"productId": 42}, schema)
    validate({"productId": "42"}, schema)


# Generated at 2022-06-24 10:48:07.670513
# Unit test for constructor of class OneOf
def test_OneOf():
    oneOf1: OneOf = OneOf([])
    assert isinstance(oneOf1.one_of, list)
    

# Generated at 2022-06-24 10:48:12.810239
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    NeverMatch(required=True)

# Generated at 2022-06-24 10:48:15.230829
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Field())
    result = not_field.validate(1)
    assert result is None

# Generated at 2022-06-24 10:48:19.662031
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema = OneOf([Field(),Field()],name="a")
    try:
        schema.validate("test")
    except Exception as e:
        print("test exception: " + str(e))
    print("test_OneOf_validate passed")


# Generated at 2022-06-24 10:48:24.945660
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    n.validate(None)
    n.validate(42)
    n.validate(3.14)
    n.validate("Hello World!")
    n.validate(object())
    with pytest.raises(AssertionError):
        n.validate(None, True)



# Generated at 2022-06-24 10:48:35.413553
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    assert(OneOf([Any()]).validate(None) is None)
    assert(OneOf([Any('hello')]).validate('hello') == 'hello')

    try:
        OneOf([Any(None)]).validate('hello')
    except Exception as e:
        assert(str(e) == 'Did not match any valid type.')
    else:
        assert(False) # Should not arrive here

    try:
        OneOf([Any(None),Any(1)]).validate('hello')
    except Exception as e:
        assert(str(e) == 'Matched more than one type.')
    else:
        assert(False) # Should not arrive here

