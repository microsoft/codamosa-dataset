

# Generated at 2022-06-24 10:38:38.731510
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Point(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value['x'] == 0 and value['y'] == 0:
                return value
            raise Exception("This is not a valid point")

    class Line(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value['p1'] == value['p2']:
                return value
            raise Exception("This is not a valid line")

    point1 = {'x': 0, 'y': 0}
    point2 = {'x': 0, 'y': 1}
    line1 = {'p1': point1, 'p2': point2}
    line2 = {'p1': point1, 'p2': point1}
   

# Generated at 2022-06-24 10:38:42.604844
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([Any()]).validate(None) is None
    assert AllOf([Any()]).validate(5) == 5

    assert AllOf([Any(), Any()]).validate(5) == 5
    assert AllOf([Any(), Field(required=False)]).validate(5) == 5
    assert AllOf([Any(), String(min_length=1)]).validate(5) == 5
    assert AllOf([Any(), String(min_length=1)]).validate(5) == 5


# Generated at 2022-06-24 10:38:46.849645
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Field()])
    assert field.one_of is not None

# Generated at 2022-06-24 10:38:51.375273
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    result = field.validate(0)
    assert result == '{"never": "This never validates."}'

    field = NeverMatch()
    result = field.validate(None)
    assert result == '{"never": "This never validates."}'

    field = NeverMatch()
    result = field.validate("")
    assert result == '{"never": "This never validates."}'


# Generated at 2022-06-24 10:38:58.130559
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Foo(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    foo = Foo()
    if_clause = IfThenElse(foo, foo)
    if_clause.validate(0) # 0 is a valid value of IfThenElse
    if_clause = IfThenElse(foo, foo, foo)
    if_clause.validate(0) # 0 is a valid value of IfThenElse

# Generated at 2022-06-24 10:38:59.948380
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="nevermatch", description="never match")

# Generated at 2022-06-24 10:39:02.972472
# Unit test for method validate of class Not
def test_Not_validate():
    # Declares a instance of Not
    n = Not(String())
    n.validate(None)
    # n.validate("")
    # n.validate("test") # Fails

# Generated at 2022-06-24 10:39:05.869281
# Unit test for constructor of class Not
def test_Not():
    # Given
    field = object

    # When
    not_field = Not(field)

    # Then
    assert isinstance(not_field, Field)
    assert not_field.negated == field


# Generated at 2022-06-24 10:39:08.115424
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse(None, None)
    except Exception as e:
        assert False, "IfThenElse() raised Exception unexpectedly"

# Generated at 2022-06-24 10:39:12.040511
# Unit test for method validate of class Not
def test_Not_validate():
    negated = String(max_length = 1)
    not_field = Not(negated)
    _, error = not_field.validate_or_error(2, strict=True)
    assert error == None
    _, error = not_field.validate_or_error("abc", strict=True)
    assert error == "negated"


# Generated at 2022-06-24 10:39:22.389527
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    ifThenElse1 = IfThenElse(Field(),Field(),Field())
    allOf1 = AllOf([Field(),Field()])
    not1 = Not(Field())
    oneOf1 = OneOf([Field(),Field()])
    ifThenElse2 = IfThenElse(Field(),Field(),Field())
    allOf2 = AllOf([Field(),Field()])
    not2 = Not(Field())
    oneOf2 = OneOf([Field(),Field()])
    ifThenElse3 = IfThenElse(Field(),Field(),Field())
    allOf3 = AllOf([Field(),Field()])
    not3 = Not(Field())
    oneOf3 = OneOf([Field(),Field()])
    ifThenElse4 = IfThenElse(Field(),Field(),Field())
    allOf4 = AllOf([Field(),Field()])

# Generated at 2022-06-24 10:39:26.413177
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import String

    field = OneOf([String(), String()])
    field.validate('hello')

    field = OneOf([String(), String()])
    with raises(ValidationError) as error:
        field.validate(12345)
    assert error.json_message == 'Did not match any valid type.'


# Generated at 2022-06-24 10:39:33.375383
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Schema

    schema = Schema(all_of=[
        AllOf(all_of=[int]),
        AllOf(all_of=[Schema(min_length=1)]),
        AllOf(all_of=[Schema(max_length=5)]),
    ])
    schema.validate([1])
    schema.validate([1, 2])


# Generated at 2022-06-24 10:39:35.832525
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_test = IfThenElse('test', 'test', 'test')
    expected = IfThenElse(if_test, 'test', 'test')
    assert if_test == expected

# Generated at 2022-06-24 10:39:37.602742
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any(), Any()])
    field.validate(123)
    field.validate(None)

# Generated at 2022-06-24 10:39:43.135879
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # unit-test for method validate of class OneOf
    from typesystem.number import Number

    one_of = OneOf([Number(multiple_of=2), Number(multiple_of=3)])
    one_of.validate(2)
    one_of.validate(3)
    one_of.validate_or_error(4)
    one_of.validate_or_error(5)


# Generated at 2022-06-24 10:39:51.453256
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    options = {
        "allow_null": True,
        "description": "hello",
        "name": "Foo",
        "enum": [1, 2, 3],
        "minimum": 4,
        "maximum": 5,
        "error_messages": {},
        "validators": []
    }
    n = NeverMatch(**options)
    assert n.errors == {"never": "This never validates."}
    assert n.name == "Foo"
    assert n.allow_null == True


# Generated at 2022-06-24 10:39:55.019387
# Unit test for method validate of class Not
def test_Not_validate():
    # 1. Arrange
    negated = Field()
    notField = Not(negated)
    value = 1

    # 2. Act
    retorno = notField.validate(value)

    # 3. Assert
    expected = 1
    assert retorno == expected

# Generated at 2022-06-24 10:39:56.451108
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.validate(1)

# Generated at 2022-06-24 10:39:59.194110
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch()
    # This should pass assert
    assert True


# Generated at 2022-06-24 10:40:07.497176
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    check = typesystem.OneOf([typesystem.String(), typesystem.Number()])

    with pytest.raises(typesystem.ValidationError) as excinfo:
        check.validate(True)
    assert excinfo.value.code == "no_match"
    assert check.validate('string') == 'string'
    assert check.validate(1) == 1

    check = typesystem.OneOf([typesystem.String(), typesystem.Number()])
    with pytest.raises(typesystem.ValidationError) as excinfo:
        check.validate(1.0)
    assert excinfo.value.code == "multiple_matches"

    check = typesystem.OneOf([typesystem.String(), typesystem.Number()])

# Generated at 2022-06-24 10:40:08.616656
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf()


# Generated at 2022-06-24 10:40:11.946242
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    i = NeverMatch()
    assert i.label is None
    assert i.description is None
    assert i.default is None
    assert i.name is None
    assert i.allow_null is False


# Generated at 2022-06-24 10:40:13.505293
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True)



# Generated at 2022-06-24 10:40:17.542279
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    s = IfThenElse(
        if_clause = types.String(),
        then_clause = {types.String(), types.Int()},
        else_clause = types.Int()
    )
    s.validate("1" or 1 or 2)
    s.validate(1)
    s.validate(2)


# Generated at 2022-06-24 10:40:25.278546
# Unit test for constructor of class AllOf
def test_AllOf():
    import json
    field = Field()
    field_1 = Field()
    all_of = AllOf([field, field_1])
    assert all_of.name is None
    assert all_of.required == False
    assert all_of.description == ""
    assert json.dumps(all_of.errors) == '{"invalid": "Invalid value."}'
    assert all_of.allow_null == False
    assert all_of.all_of == [field, field_1]


# Generated at 2022-06-24 10:40:29.498786
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(if_clause=Float(lt=-10), then_clause=Float(gt=-100))
    IfThenElse(if_clause=Float(lt=-10))
    IfThenElse(lt=-10, then_clause=Float(gt=-100))
    IfThenElse(lt=-10, else_clause=Float(gt=-100))

# Generated at 2022-06-24 10:40:34.153855
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(AssertionError):
        field.validate(None)


# Generated at 2022-06-24 10:40:36.574135
# Unit test for constructor of class AllOf
def test_AllOf():
  all_of = [AllOf]
  kwargs = {}
  x = AllOf(all_of, **kwargs)
  return x


# Generated at 2022-06-24 10:40:40.312335
# Unit test for constructor of class OneOf
def test_OneOf():
    d={"a":1, "b":2}
    assert OneOf([])._validate_parameters() == d, 'OneOf constructor test failed'


# Generated at 2022-06-24 10:40:46.034647
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([Int()]).validate(3) == 3
    assert AllOf([Int(), Max(4), Min(4), Enum(4)]).validate(4) == 4
    assert AllOf([Int(), Max(4), Min(4), Enum(4)]).validate(2) == 2
    assert AllOf([Int(), Max(4), Min(4), Enum(4)]).validate(6) == 6


# Generated at 2022-06-24 10:40:49.948686
# Unit test for constructor of class AllOf
def test_AllOf():
    assert str(AllOf([])) == "AllOf([])"



# Generated at 2022-06-24 10:40:53.466642
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    field = AllOf([Field()])
    assert type(field.all_of) == list
    field = AllOf([AllOf([Field()])])
    assert type(field.all_of) == list


# Generated at 2022-06-24 10:40:55.699017
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("")


# Generated at 2022-06-24 10:41:00.592485
# Unit test for method validate of class Not
def test_Not_validate():
    error_msg='Must not match.'
    type_ = Not(dict(), error_messages={'negated':error_msg})
    data = 1
    error = None

    try:
        type_.validate(data)
    except Exception as e:
        error = e
    assert error and error.args[0] == error_msg

# Generated at 2022-06-24 10:41:01.632618
# Unit test for constructor of class Not
def test_Not():
    n = Not(Any())



# Generated at 2022-06-24 10:41:02.236607
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:41:05.630096
# Unit test for constructor of class Not
def test_Not():
    not_instance = Not(Any())
    assert isinstance(not_instance, Field)
    assert not_instance.errors == {"negated": "Must not match."}
    assert not_instance.negated == Any()



# Generated at 2022-06-24 10:41:09.044286
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    value = {'name':'Barry', 'age':18}
    obj1 = IfThenElse(if_clause=Any())
    message1 = obj1.validate(value)
    
    assert message1 == value
    # obj1.validate(value) != value
    # AssertionError: assert {'name': 'Barry', 'age': 18} == None



# Generated at 2022-06-24 10:41:13.237001
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=None)
    assert not_field.negated == None
    assert not_field.errors == {"negated": "Must not match."}


# Generated at 2022-06-24 10:41:21.025036
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create a list of field objects
    test_list = [
        Field(),
        Field(serialized_name="name"),
        Field(serialized_name="name", description="description", required=True),
    ]
    # Create a OneOf object
    one_of = OneOf(test_list)
    # Test cases
    assert one_of.validate(0.5) == 0.5
    assert one_of.validate("string") == "string"
    assert one_of.validate(1) == 1
    assert one_of.validate(None) == None
    assert one_of.validate([1, 2]) == [1, 2]
    assert one_of.validate({'a' : 1, 'b' : 2}) == {'a' : 1, 'b' : 2}
# Unit

# Generated at 2022-06-24 10:41:29.514510
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([String(min_length=10),Json(schema={"type": "object"})]).validate({}) == None
    assert OneOf([String(min_length=10)]).validate({}) == None
    assert OneOf([String(max_length=10),Json(schema={"type": "object"})]).validate({}) == None
    assert OneOf([String(max_length=10)]).validate({}) == None
    assert OneOf([Json(schema={"type": "object"}),Json(schema={"type": "object"})]).validate({}) == None
    assert OneOf([Json(schema={"type": "object"})]).validate({}) == None

# Generated at 2022-06-24 10:41:31.046274
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:41:40.655733
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import String, Integer

    string_field = String()
    integer_field = Integer()

    oneof = OneOf(one_of=[string_field, integer_field])
    assert oneof.validate(1) == 1
    try:
        oneof.validate("1")
        assert False
    except:
        assert True

    oneof_string = OneOf(one_of=[String()])
    assert oneof_string.validate("1") == "1"
    try:
        oneof_string.validate(1)
        assert False
    except:
        assert True



# Generated at 2022-06-24 10:41:43.343296
# Unit test for constructor of class Not
def test_Not():
    n = Not(Field())
    assert n != None


# Generated at 2022-06-24 10:41:44.999728
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[Field()])
    print(one_of)


# Generated at 2022-06-24 10:41:48.788722
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    field1 = Str()
    field2 = Number()
    one_of_field = OneOf([field1, field2])
    
    # Action
    value = "some text"
    result = one_of_field.validate(value)
    
    # Assert
    assert result == "some text"
    

# Generated at 2022-06-24 10:41:50.498879
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field())
    result = field.validate(None, strict=None)
    assert result == None


# Generated at 2022-06-24 10:41:57.379138
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    with pytest.raises(ValidationError):
        f.validate(None)
    with pytest.raises(ValidationError):
        f.validate(True)
    with pytest.raises(ValidationError):
        f.validate(1)
    with pytest.raises(ValidationError):
        f.validate([])
    with pytest.raises(ValidationError):
        f.validate({})


# Generated at 2022-06-24 10:42:00.672022
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(String()).validate("abc") == "abc"
    # assert Not(String()).validate(123) == "abc"



# Generated at 2022-06-24 10:42:05.510359
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class MyField(Field):
        def validate(self, value: typing.Any, strict: bool = False):
            raise ValueError()

    myField = MyField()

    field = IfThenElse(
        myField,
        then_clause=Any()
    )

    value = 'yes'
    try:
        field.validate(value)
    except ValueError:
        assert False
    assert True

# Generated at 2022-06-24 10:42:09.309186
# Unit test for method validate of class Not
def test_Not_validate():
    is_odd = Not(Integer(multiple_of=2))
    odd = is_odd.validate(3)
    assert odd == 3
    with pytest.raises(is_odd.validation_error("negated")):
        is_odd.validate(4)


# Generated at 2022-06-24 10:42:10.449407
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(label="x").label == "x"


# Generated at 2022-06-24 10:42:13.393260
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Initialization
    field = AllOf([Integer()])

    # Validating
    try:
        field.validate(5)
    except:
        test_condition = False
    else:
        test_condition = True
    assert test_condition


# Generated at 2022-06-24 10:42:15.208817
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([],name = 'one_of')
    assert one_of is not None, "OneOf constructor not executed"

# Generated at 2022-06-24 10:42:16.718091
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        NeverMatch().validate("value")
        assert False
    except Exception:
        assert True


# Generated at 2022-06-24 10:42:21.937566
# Unit test for method validate of class Not
def test_Not_validate():
    t = Not(negated=Object({'nested': 'test'}))
    assert t.validate(value={'nested': 'test'}) is None
    assert t.validate(value={'nested': 'bla'}) is not None

# Generated at 2022-06-24 10:42:23.748028
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(then_clause=None, else_clause=None)


# Generated at 2022-06-24 10:42:32.219608
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class TestField(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    t = TestField()
    ift = IfThenElse(t)
    assert t == ift.if_clause
    assert Any() == ift.then_clause
    assert Any() == ift.else_clause
    
    iftt = IfThenElse(t, t)
    assert t == iftt.if_clause
    assert t == iftt.then_clause
    assert Any() == iftt.else_clause
    

# Generated at 2022-06-24 10:42:44.274356
# Unit test for method validate of class Not
def test_Not_validate():
    import sys
    import os
    import unittest
    import json

    if not os.path.exists('./results'):
        os.mkdir('./results')

    data = {"id": "A001", "details": {"sector": "A", "no": "1"}, "name": "Bob"}

# Generated at 2022-06-24 10:42:49.081915
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import String, Integer
    from typesystem.exceptions import ValidationError
    all_of_obj = AllOf([Integer(), String()])
    try:
        all_of_obj.validate(23)
    except ValidationError:
        assert True
        return
    assert False


# Generated at 2022-06-24 10:42:50.223116
# Unit test for constructor of class Not
def test_Not():
    a_type = Not(String())
    assert a_type.negated == String()

# Generated at 2022-06-24 10:42:55.828489
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    @Field.validator_for("test_field")
    def test_func(value, view):
        pass

    class FieldTest(Field):
        test_field = "test"

    if_clause = FieldTest()
    then_clause = FieldTest()
    else_clause = FieldTest()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert field.else_clause == else_clause


# Generated at 2022-06-24 10:42:59.953344
# Unit test for method validate of class Not
def test_Not_validate():
    print("-------------------test_Not_validate-----------------------")
    test_field = Not(Int())
    print(test_field.validate(1).__class__)
    print(test_field.validate(True).__class__)
    print(test_field.validate(1.1).__class__)
    print(test_field.validate([]).__class__)
    print(test_field.validate({}).__class__)
    print(test_field.validate(None).__class__)


# Generated at 2022-06-24 10:43:00.917712
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf.__init__

# Generated at 2022-06-24 10:43:02.673144
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Int(), Int()])
    field.validate(2)



# Generated at 2022-06-24 10:43:13.778000
# Unit test for constructor of class OneOf
def test_OneOf():
    # one_of is a typing.List[Field]
    # kwargs is a dict
    # return None

    # Case 1: one_of has invalid value. assert raises
    try:
        OneOf(one_of=5)
        assert False
    except AssertionError:
        assert True

    # Case 2: kwargs has invalid key. assert raises
    try:
        OneOf(one_of=[], hello="world")
        assert False
    except AssertionError:
        assert True

    # Case 3: valid one_of and kwargs.
    OneOf(one_of=[])

    # Case 4: one_of is empty. assert raises
    try:
        OneOf(one_of=[])
        assert False
    except AssertionError:
        assert True

    # Case 5: one_

# Generated at 2022-06-24 10:43:20.994426
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Unit test for method validate of class AllOf
    # boolean
    try:
        result = AllOf(one_of=[Boolean(allow_null=False),
            Null()]).validate(True, strict=False)
        assert result is None
    except ValidationError as e:
        assert e.code == 'null'
    try:
        result = AllOf(one_of=[Boolean(allow_null=False),
            Null()]).validate(False, strict=False)
        assert result is None
    except ValidationError as e:
        assert e.code == 'null'

# Generated at 2022-06-24 10:43:21.796336
# Unit test for constructor of class Not
def test_Not():
	assert True


# Generated at 2022-06-24 10:43:26.819871
# Unit test for constructor of class Not
def test_Not():
    pass
    #assert Not.errors == {"negated": "Must not match."}
    '''
    negated = Field()
    notField = Not(negated)
    assert notField.negated == negated
    '''


# Unit tests for constructor of class IfThenElse

# Generated at 2022-06-24 10:43:30.752055
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import Integer
    from typesystem.schemas.json_schema import Not
    field = Not(Integer)
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1


# Generated at 2022-06-24 10:43:41.020650
# Unit test for method validate of class Not
def test_Not_validate():
    value = {"foo": "bar"}

    def check_error(field):
        assert field.validate(value) is None
        assert field.validate({"foo": 123}) == {"foo": 123}

    check_error(Not(Any()))
    check_error(Not(dict(foo=Any())))
    check_error(Not(dict(foo=String())))
    check_error(Not(dict(foo=Number())))
    check_error(Not(dict(foo=Boolean())))
    check_error(Not(dict(foo=Integer())))
    check_error(Not(dict(foo=List(of=Any()))))
    check_error(Not(dict(foo=List(of=String()))))
    check_error(Not(dict(foo=List(of=Number()))))

# Generated at 2022-06-24 10:43:51.815417
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_cl = int
    then_cl = str
    else_cl = list
    try:
        # First, test the case value is int, then_clause and else_clause are both str
        in_1 = 1
        ite = IfThenElse(if_clause = if_cl, then_clause = then_cl, else_clause = else_cl)
        ite.validate(in_1)
    except Exception:
        assert False
    # Second, test the case value is str, then_clause is int, else_clause is list

# Generated at 2022-06-24 10:43:52.394473
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True

# Generated at 2022-06-24 10:43:54.546208
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=None, then_clause=None, else_clause=None) is not None


# Generated at 2022-06-24 10:44:02.937190
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Check if the value is in the list of valid fields
    # Boolean true
    one_of_field = OneOf([Boolean()])
    assert True == one_of_field.validate(True)
    # Boolean false
    assert False == one_of_field.validate(False)
    # String with 10 characters
    assert '1234567890' == one_of_field.validate('1234567890')

    # Check if the value is not in the list of valid fields
    # String with 11 characters
    try:
        assert '12345678901' == one_of_field.validate('12345678901')
    except FieldError as e:
        assert 'Must be less than 10 characters' == str(e)



# Generated at 2022-06-24 10:44:03.740442
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert True


# Generated at 2022-06-24 10:44:10.470608
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    field.validate(1)
    try:
        field.validate(None)
    except TypeError as e:
        assert type(e) == TypeError
    else:
        raise AssertionError

# Generated at 2022-06-24 10:44:14.803444
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    
    # Constructor test with undefined arguments
    try:
        new = NeverMatch()
    except AssertionError:
        new = None
    assert new is None, "Constructor of class NeverMatch has not been tested"



# Generated at 2022-06-24 10:44:17.013607
# Unit test for constructor of class Not
def test_Not():
    f = Not(Field, default=None)
    assert f.errors == { "negated": "Must not match." }

# Generated at 2022-06-24 10:44:21.767106
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    e1 = OneOf([SchemaField(Integer)], name="test1")
    e2 = OneOf([SchemaField(Integer)], name="test2")
    e3 = OneOf([e1, e2], name="test3")

    assert e1.validate(1) == 1
    assert e2.validate(1) == 1
    assert e3.validate(1) == 1


# Generated at 2022-06-24 10:44:23.789736
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Field()]

    tmp = AllOf(all_of)
    assert tmp.all_of == all_of

# Generated at 2022-06-24 10:44:27.828022
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field.if_clause
    assert field.then_clause
    assert field.else_clause

# Generated at 2022-06-24 10:44:30.377236
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
        f = NeverMatch()

        assert f.validate("foo") == "foo"
        assert f.validate("foo") == "foo"


# Generated at 2022-06-24 10:44:31.255409
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([]) is not None


# Generated at 2022-06-24 10:44:34.022135
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String

    schema = OneOf([String(max_length=2), String(min_length=4)])

# Generated at 2022-06-24 10:44:35.073521
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    AllOf([])
    AllOf([Field()])



# Generated at 2022-06-24 10:44:42.230598
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.types import String
    if_ = String(min_length=1)
    then_ = String(min_length=2)
    else_ = String(min_length=3)
    if_then_else = IfThenElse(if_, then_, else_)
    # call constructor with minimal parameters
    if_then_else = IfThenElse(if_)
    # call constructor with all parameters
    if_then_else = IfThenElse(if_, then_, else_)


# Generated at 2022-06-24 10:44:44.738449
# Unit test for constructor of class Not
def test_Not():
    s = Field()
    n = Not(s)
    assert s==n.negated


# Generated at 2022-06-24 10:44:46.684002
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(foo='bar')
    assert isinstance(field, NeverMatch)



# Generated at 2022-06-24 10:44:50.106221
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    myfield = NeverMatch()
    with pytest.raises(myfield.validation_error):
        myfield.validate(12345)


# Generated at 2022-06-24 10:44:51.682961
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    return True

# Generated at 2022-06-24 10:44:55.751544
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch(name="NeverMatch", description="Don't ever match")
    with pytest.raises(AssertionError) as m:
        field.validate(None, strict=False)
    assert str(m.value) == "This never validates."


# Generated at 2022-06-24 10:44:58.810932
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import validate
    from typesystem.primitives import String

    primitive_value = "primitive value"
    expected_result = primitive_value
    test_field = Not(negated=String())
    assert validate(test_field, primitive_value) == expected_result

# Generated at 2022-06-24 10:44:59.669812
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass


# Generated at 2022-06-24 10:45:03.018495
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_field = OneOf(one_of=[])
    assert one_of_field.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}
    assert one_of_field.one_of == []
    return one_of_field


# Generated at 2022-06-24 10:45:12.600898
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Tests the method validate of class Not
    """
    from typesystem import Integer
    from typesystem.utils import JsonSchema
    not_field = Not(Integer(), name="Test Not")
    json_schema = not_field.to_json_schema()

# Generated at 2022-06-24 10:45:15.221950
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field_never_match = NeverMatch()
    with pytest.raises(assertionerror):
        field_never_match.validate(value=10)


# Generated at 2022-06-24 10:45:22.591518
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = Any()
    b = Any()
    obj = OneOf([a])
    obj.validate(1)

    obj = OneOf([a])
    obj.validate(1, strict=True)

    obj = OneOf([a, b])
    obj.validate(1)

    obj = OneOf([a, b])
    obj.validate(1, strict=True)

    obj = OneOf([a, b])
    obj.validate(1)

    obj = OneOf([a, b])
    obj.validate(1, strict=True)

# Generated at 2022-06-24 10:45:25.183049
# Unit test for method validate of class Not
def test_Not_validate():
    negated = Field()
    field = Not(negated=negated)
    assert hasattr(negated, "errors")
    assert hasattr(negated, "validate")



# Generated at 2022-06-24 10:45:26.950745
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate(1)



# Generated at 2022-06-24 10:45:29.039136
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()

    with pytest.raises(Exception) as e:
        nm.validate(1)

    assert e.value.message == 'This never validates.'


# Generated at 2022-06-24 10:45:30.277540
# Unit test for constructor of class OneOf
def test_OneOf():
  one_of = OneOf([])

# Generated at 2022-06-24 10:45:36.216211
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    x = Field()
    y = Field(default=1)
    z = Field(default=2)
    field = OneOf([x, y, z])
    field.validate(1)
    field.validate(2)
    try:
        field.validate(1, strict=True)
    except:
        pass
    print("test OneOf_validate ok")


# Generated at 2022-06-24 10:45:46.950496
# Unit test for method validate of class Not
def test_Not_validate():
    # =======================
    # Test case 1
    # =======================
    field = Not(NeverMatch())
    value = field.validate(1)
    assert value == 1
    # =======================
    # Test case 2
    # =======================
    field = Not(NeverMatch())
    with pytest.raises(field.validation_error) as excinfo:
        field.validate(None)
    assert excinfo
    # =======================
    # Test case 3
    # =======================
    field = Not(NeverMatch())
    with pytest.raises(field.validation_error) as excinfo:
        field.validate(100)
    assert excinfo
    # =======================
    # Test case 4
    # =======================
    field = Not(NeverMatch())

# Generated at 2022-06-24 10:45:50.177342
# Unit test for constructor of class OneOf
def test_OneOf():
    On = OneOf([Integer(), String()])
    On.validate(2)
    On.validate("3")
    try:
        On.validate(True)
        assert False
    except:
        pass



# Generated at 2022-06-24 10:45:51.954032
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    AllOf([String()])


# Generated at 2022-06-24 10:45:57.212414
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_if_clause(value: typing.Any) -> bool:
        return value == 1

    def test_else_clause(value: typing.Any) -> bool:
        return value == 2

    ite = IfThenElse(if_clause=test_if_clause, else_clause=test_else_clause)

    assert ite.validate(value=1) == 1
    assert ite.validate(value=2) == 2



# Generated at 2022-06-24 10:45:59.189824
# Unit test for constructor of class AllOf
def test_AllOf():
    field1 = AllOf(all_of='field1')

    assert(isinstance(field1, AllOf))
    assert(field1.all_of == 'field1')


# Generated at 2022-06-24 10:46:04.554546
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    tp0 = NeverMatch()
    # test_repr_return_type
    assert isinstance(tp0.__repr__(), str)
    # test_validate_return_type
    with pytest.raises(Exception) as exception_info:
        tp0.validate(x=None)
    assert isinstance(exception_info.value, Exception)


# Generated at 2022-06-24 10:46:05.690359
# Unit test for constructor of class Not
def test_Not():
    assert Not(Field())


# Generated at 2022-06-24 10:46:11.267262
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    t1 = types.String()
    t2 = types.Number()
    t3 = types.Boolean()
    t = types.OneOf(t1, t2, t3)
    assert t.validate(1) == 1
    with pytest.raises(ValidationError):
        t.validate("")


# Generated at 2022-06-24 10:46:13.429671
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse("if_clause", "then_clause", "else_clause")


# Generated at 2022-06-24 10:46:14.309432
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()

# Generated at 2022-06-24 10:46:16.076549
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # TEST CASE: It should raise a validation_error
    field = NeverMatch()
    with pytest.raises(field.validation_error):
        field.validate("value")


# Generated at 2022-06-24 10:46:25.576438
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch(required=True)
    assert n.validate(1) == None
    assert n.validate(1) == None
    assert n.validate(1) == None
    assert n.validate(1) == None
    assert n.validate(1) == None
    assert n.validate(2) == None
    assert n.validate(3) == None
    assert n.validate(4) == None
    assert n.validate(5) == None
    assert n.validate(6) == None
    assert n.validate(1) == None
    assert n.validate(1) == None
    assert n.validate(1) == None
    assert n.validate(1) == None
    assert n.validate(1) == None

# Generated at 2022-06-24 10:46:28.551931
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated = None)
    assert field.negated is None
    assert field.errors is {"negated": "Must not match."}


# Generated at 2022-06-24 10:46:33.383843
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(String(), Number())
    field.validate("42")
    with pytest.raises(ValidationError):
        field.validate(42)
    field = IfThenElse(None, Number())
    with pytest.raises(ValidationError):
        field.validate("42")



# Generated at 2022-06-24 10:46:44.141055
# Unit test for constructor of class OneOf
def test_OneOf():
    assert hasattr(OneOf, 'errors')
    assert isinstance(OneOf.errors, dict)
    assert 'no_match' in OneOf.errors
    assert OneOf.errors['no_match'] == 'Did not match any valid type.'
    assert 'multiple_matches' in OneOf.errors
    assert OneOf.errors['multiple_matches'] == 'Matched more than one type.'
    assert hasattr(OneOf, '__init__')
    assert hasattr(OneOf.__init__, '__call__')
    assert hasattr(OneOf.__init__, '__annotations__')
    assert 'self' in OneOf.__init__.__annotations__
    assert OneOf.__init__.__annotations__['self'] == OneOf

# Generated at 2022-06-24 10:46:50.864401
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class testField(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    f = testField()
    oneof = OneOf([f, f], required=False)

    oneof.validate([1, 2, 3])
    oneof.validate("string")

# Generated at 2022-06-24 10:46:59.153909
# Unit test for constructor of class OneOf
def test_OneOf():
    # Try creating instance of OneOf
    # with no arguments
    try:
        OneOf()
    except TypeError:
        pass
    else:
        raise AssertionError

    # Try creating instance of OneOf
    # with some arguments
    try:
        OneOf(one_of=[])
    except TypeError:
        pass
    else:
        raise AssertionError

    # Try creating instance of OneOf
    # with some arguments
    try:
        OneOf(one_of=[], errors={"never": "This never validates."})
    except TypeError:
        pass
    else:
        raise AssertionError

    # Try creating instance of OneOf
    # with all arguments
    OneOf(one_of=[], errors={"never": "This never validates."})

# Generated at 2022-06-24 10:47:04.917167
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(1, then_clause=2, else_clause=3).if_clause == 1
    assert IfThenElse(1, then_clause=2, else_clause=3).then_clause == 2
    assert IfThenElse(1, then_clause=2, else_clause=3).else_clause == 3
    assert IfThenElse(1, then_clause=2, else_clause=3).kwargs == {}


# Generated at 2022-06-24 10:47:06.548743
# Unit test for constructor of class Not
def test_Not():
    a = Field(name='test_field')
    b = Not(a)
    assert b.negated == a

# Generated at 2022-06-24 10:47:07.675364
# Unit test for constructor of class OneOf
def test_OneOf():
    # Empty **kwargs
    assert OneOf


# Generated at 2022-06-24 10:47:09.360412
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1

# Generated at 2022-06-24 10:47:11.121205
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = typesystem.fields.NeverMatch()
    with pytest.raises(typesystem.fields.ValidationError):
        field.validate(None)


# Generated at 2022-06-24 10:47:20.681110
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Str(),Int()])
    result = field.validate(1)
    assert result == 1

    field = OneOf([Str(),Int()])
    result = field.validate("1")
    assert result == "1"

    field = OneOf([Str(),Int()])
    with pytest.raises(ValidationError):
        field.validate([1,2])

    field = OneOf([Str(),Int()])
    with pytest.raises(ValidationError):
        field.validate(1.2)

    field = OneOf([Str(),Int()])
    with pytest.raises(ValidationError):
        field.validate(1,strict=True)

    field = OneOf([Str(),Int()])

# Generated at 2022-06-24 10:47:22.677469
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field, NeverMatch) == True


# Generated at 2022-06-24 10:47:24.544269
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Field('string')).validate('anystring') is not None


# Generated at 2022-06-24 10:47:32.779999
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Double(Field):
        """
        Double the value.
        """

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value * 2
    class IsLessThan(Field):
        """
        Test if the value is less than the given value.
        """

        def __init__(self, value: typing.Any, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.value = value
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value < self.value:
                return value
            raise self.validation_error("not_less_than")


# Generated at 2022-06-24 10:47:42.440851
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(if_clause=1, then_clause=2).validate(0)
    IfThenElse(if_clause=1, then_clause=2).validate(1)
    IfThenElse(if_clause=1, then_clause=2, else_clause=3).validate(0)
    IfThenElse(if_clause=1, then_clause=2, else_clause=3).validate(1)
    IfThenElse(if_clause=1, then_clause=2, else_clause=3).validate("a")
    IfThenElse(if_clause="a", then_clause=2, else_clause=3).validate("a")

# Generated at 2022-06-24 10:47:45.185542
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        field = NeverMatch()
    except:
        assert False
    assert field.errors == {"never": "This never validates."}

# Integration test for function validate
# of class NeverMatch

# Generated at 2022-06-24 10:47:51.153231
# Unit test for constructor of class AllOf
def test_AllOf():
    # Constructor test
    field = AllOf()
    # NOTE: We can't assert on the specific error message of the raised exception, because the message is part of the implementation (not the interface)
    with pytest.raises(AssertionError):
        field = AllOf(allow_null=True)


# Generated at 2022-06-24 10:47:53.845847
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    name = field.name
    errors = field.errors
    assert name == "NeverMatch" and errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:47:57.232576
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError) as excinfo:
        field.validate(None)
    assert excinfo.match("This never validates.")


# Generated at 2022-06-24 10:47:58.182457
# Unit test for constructor of class Not
def test_Not():
    f = Not(Any())
    print(f.negated)


# Generated at 2022-06-24 10:48:02.053530
# Unit test for constructor of class OneOf
def test_OneOf():
    new_field = OneOf([])
    assert new_field.description == ""
    assert new_field.name == ""
    assert new_field.required == False
    assert new_field.editable == True
    assert new_field.default == None
    assert new_field.one_of == []


# Generated at 2022-06-24 10:48:05.655093
# Unit test for constructor of class Not
def test_Not():
    # Ensure that constructor for class Not does not throw an error
    try:
        Not(None)
    except:
        assert False



# Generated at 2022-06-24 10:48:08.475066
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of_field = AllOf(all_of = [{'type': 'string'}])
    assert isinstance(all_of_field, AllOf)


# Generated at 2022-06-24 10:48:09.933679
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[])
    assert field.one_of == []



# Generated at 2022-06-24 10:48:10.412007
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()

# Generated at 2022-06-24 10:48:11.976200
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(format='yaml')
    assert NeverMatch()
    assert NeverMatch(format='yaml', errors=None)


# Generated at 2022-06-24 10:48:13.192456
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[]) is not None

# Generated at 2022-06-24 10:48:16.479298
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [Field()]
    one_of = OneOf(fields)
    assert one_of.one_of == fields


# Generated at 2022-06-24 10:48:23.825631
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type, Message

    class Example(Type):
        name = AllOf([String()])
        name = String()

    assert Example().get_field("name").all_of == [String()]
    assert Example().get_field("name").error_messages == {"required": "This field is required."}
    assert Example().get_field("name").error_messages == {"required": "This field is required."}
    """
    Example().validate({"name": "lala"})
    with pytest.raises(ValidationError):
        Example().validate({})
    """

# Generated at 2022-06-24 10:48:26.881738
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated = Field(required=True, description="This is not field"))
    assert not_field.validate(value=None, strict=False) == None

# Generated at 2022-06-24 10:48:36.316761
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = String()
    then_clause = String()
    else_clause = String()
    f = IfThenElse(if_clause, then_clause, else_clause)
    assert f.field_name == 'IfThenElse'
    assert f.if_clause == if_clause
    assert f.then_clause == then_clause
    assert f.else_clause == else_clause
    f = IfThenElse(if_clause, then_clause, else_clause, name="test name")
    assert f.field_name == 'test name'
    assert f.if_clause == if_clause
    assert f.then_clause == then_clause
    assert f.else_clause == else_clause