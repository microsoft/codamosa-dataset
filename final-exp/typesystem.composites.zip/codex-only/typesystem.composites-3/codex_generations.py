

# Generated at 2022-06-24 10:38:31.212693
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=["test_one_of", "test_one_of2"])


# Generated at 2022-06-24 10:38:32.310426
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([])

# Generated at 2022-06-24 10:38:37.073443
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse.validate(True,1) == 1
    assert IfthenElse.validate(False,1) == None
    assert IfThenElse.validate(False,1,1,0) == 0

# Generated at 2022-06-24 10:38:41.581003
# Unit test for constructor of class Not
def test_Not():
    # Create a Field
    typed_not = Not(field_type=str)
    # Create expected result
    expected_result = {"type": "string", "errors": {"negated": "Must not match."}}
    # Call method / attribute to test
    result = typed_not.to_primitive()
    # Compare with expected result
    assert result == expected_result



# Generated at 2022-06-24 10:38:46.665762
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nvm_0 = NeverMatch()
    nvm_1 = NeverMatch(name='nvm')
    assert nvm_0.name == 'NeverMatch'
    assert nvm_0.errors['never'] == 'This never validates.'
    assert nvm_1.name == 'nvm'
    assert nvm_1.errors['never'] == 'This never validates.'


# Generated at 2022-06-24 10:38:47.673661
# Unit test for constructor of class Not
def test_Not():
    a = Not(None)


# Generated at 2022-06-24 10:38:54.312358
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer, Number
    class IfThenElseTest(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if_clause = Number()
            then_clause = Integer()
            else_clause = String()
            if_clause = IfThenElse(if_clause,else_clause=else_clause, then_clause=then_clause)
            return if_clause.validate(value, strict=strict)
    ifThenElse_test = IfThenElseTest()
    value = 10
   

# Generated at 2022-06-24 10:38:59.845879
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = [String(), Number()]
    field = AllOf(all_of)
    field.validate(1)
    field.validate('string')

    all_of = [Number(), String()]
    field = AllOf(all_of)
    field.validate(1)
    field.validate('string')


# Generated at 2022-06-24 10:39:08.515167
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Any()).validate(10) == 10
    assert Not(None).validate(10) == 10
    assert Not(Number()).validate(10) == 10
    assert Not(String()).validate(10) == 10
    assert Not(Boolean()).validate(10) == 10
    assert Not(Dict()).validate(10) == 10
    assert Not(Boolean()).validate(False) == False
    assert Not(Dict()).validate(False) == False
    #assert Not(Boolean()).validate(True) == True
    #assert Not(Dict()).validate(True) == True
    #assert not Not(String()).validate("Hello")
    assert Not(String()).validate("Hello") == "Hello"

# Generated at 2022-06-24 10:39:09.355695
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(None) == None



# Generated at 2022-06-24 10:39:09.952263
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass



# Generated at 2022-06-24 10:39:11.930447
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Define variables and initialize values
    field = NeverMatch()
    value = None

    with pytest.raises(Exception):
        field.validate(value)



# Generated at 2022-06-24 10:39:20.948829
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return 100
    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return 200
    class C(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return 300
    field = OneOf([A(), B(), C()])
    assert field.validate(None) == 100
    assert field.validate(None) == 200
    assert field.validate(None) == 300
# unit test end



# Generated at 2022-06-24 10:39:22.686379
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:39:30.870279
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem.base

    class FloatSchema(typesystem.base.Schema):
        value = typesystem.Float()

    class IntSchema(typesystem.base.Schema):
        value = typesystem.Integer()

    # Test case 1
    # test for the case when type of input is different from the negated type
    schema = IntSchema()
    schema.fields["value"] = Not(typesystem.Float())
    assert schema.validate({"value": 10}) == {"value": 10}

    # Test case 2
    # test for the case when type of input is same as negated type
    schema = FloatSchema()
    schema.fields["value"] = Not(typesystem.Integer())
    assert schema.validate({"value": 10.0}) == {"value": 10.0}


# Generated at 2022-06-24 10:39:41.430705
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
  import unittest
  import unittest.mock
  import typesystem


  class TestField(typesystem.Field):
    errors = {"test": "Internal test error."}

    def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
      raise self.validation_error("test")


  class TestIfThenElse(unittest.TestCase):
    def test_validate_if_clause_failure(self):
      field = typesystem.IfThenElse(TestField(), typesystem.Any(), typesystem.Any())
      with self.assertRaises(typesystem.ValidationError) as error:
        field.validate("value")
      self.assertEqual(error.exception.errors, {"test": "Internal test error."})


# Generated at 2022-06-24 10:39:42.323241
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Field())



# Generated at 2022-06-24 10:39:51.677081
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(
        [
            typesystem.fields.String(),
            typesystem.fields.Integer(),
        ]
    )

    value = 47

    # AssertionError: Expected error of type 'multiple_matches'
    with pytest.raises(AssertionError):
        field.validate(value, strict=False)

    # AssertionError: Expected error of type 'multiple_matches'
    with pytest.raises(AssertionError):
        field.validate(value, strict=False)



# Generated at 2022-06-24 10:39:55.423467
# Unit test for method validate of class Not
def test_Not_validate():
    print("Unit test for method validate of class Not")
    value = 5
    strict = True
    field = Not(AllOf([Number(), Number(gt=100)]))
    assert field.validate(value, strict) == value
    value = "test"
    assert field.validate(value, strict) == value

# Generated at 2022-06-24 10:40:06.042854
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class Person(types.Object):

        name = types.String()
        age = types.Integer()

    class Pet(types.Object):

        name = types.String()
        pet_type = types.String()

    class Band(types.Object):

        name = types.String()
        members = types.Array(OneOf([Person, Pet]))

    fields = Band.get_fields()
    body = {
        "name" : "KISS",
        "members" : [
            {
                "name": "Gene Simmons",
                "age": 73
            },
            {
                "name": "Paul Stanley"
            }
        ]
    }
    try:
        fields.validate(body)
        assert True
    except types.ValidationError as error:
        assert False, error



# Generated at 2022-06-24 10:40:10.612189
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of: Field = AllOf([])
    value = 1
    res = all_of.validate(value)
    print("test_AllOf_validate: ", res)
    print("test_AllOf_validate: ", all_of.validate(value, True))


# Generated at 2022-06-24 10:40:12.756364
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    field = OneOf([String()])
    assert field.one_of == [String()]


# Generated at 2022-06-24 10:40:13.628759
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([Any()], description="")

# Generated at 2022-06-24 10:40:15.169757
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    value = 5
    field = Field()
    assert field.validate(value) == 5


# Generated at 2022-06-24 10:40:17.662188
# Unit test for constructor of class OneOf
def test_OneOf():
  fields = [Field(title='a'), Field(title='b')]
  oneof = OneOf(fields)
  assert oneof.one_of == fields


# Generated at 2022-06-24 10:40:28.670646
# Unit test for method validate of class Not

# Generated at 2022-06-24 10:40:30.165924
# Unit test for constructor of class Not
def test_Not():
    field = Not(field = None)
    assert field.negated == None


# Generated at 2022-06-24 10:40:32.727858
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-24 10:40:35.239055
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:40:41.502537
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(
        [
            {"type": "string", "pattern": "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"},
            {"type": "string", "format": "date-time"},
        ]
    )
    value = '123@123.com'
    field.validate(value)
    print('test successful')


# Generated at 2022-06-24 10:40:46.281473
# Unit test for method validate of class Not
def test_Not_validate():
    # create a field
    str_field = fields.String()
    # create a Not instance
    not_field = fields.Not(negated=str_field)
    # assert that an integer is valid by not raising ValidationError
    assert not_field.validate(1) == 1
    with pytest.raises(exceptions.ValidationError):
        assert not_field.validate("1")

# Generated at 2022-06-24 10:40:49.249212
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-24 10:40:53.084252
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    ite = IfThenElse(if_clause, then_clause, else_clause)
    ite.validate(None)

# Generated at 2022-06-24 10:40:57.745836
# Unit test for method validate of class Not
def test_Not_validate():
    f2 = Not(String())
    assert f2.validate({}) == {}
    f2 = Not(String())
    with pytest.raises(ValidationError):
        f2.validate("abc")

# Generated at 2022-06-24 10:41:06.669758
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer

    # Test that if we give a list of fields to validate and at least one
    # of them doesn't validate, it throws an exception
    integer_field = Integer()
    field = AllOf([integer_field, NeverMatch()])
    try:
        field.validate("test")
        raise Exception("An error should have been thrown")
    except Exception as e:
        assert str(e) == "Did not match all types."

    # Test that if we give a list of fields to validate and all of them
    # validate, it doesn't throw an exception
    field = AllOf([integer_field, integer_field])
    field.validate("2")
    assert True



# Generated at 2022-06-24 10:41:08.979012
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(Field()).all_of == Field()


# Generated at 2022-06-24 10:41:14.316264
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Given
    expected_error_message = "This never validates."
    field = NeverMatch()
    # When
    error = field.validation_error("never")
    # Then
    assert error.code == "never"
    assert error.message == expected_error_message



# Generated at 2022-06-24 10:41:21.904586
# Unit test for method validate of class Not
def test_Not_validate():
    # testing in case input is not given
    not_field = Not(None)
    expected_result = TypeError
    with pytest.raises(expected_result):
        result = not_field.validate(None, False)
    # testing in case if negated is not None
    not_field = Not(Any())
    expected_result = None
    result = not_field.validate('abcd', False)
    assert result == expected_result



# Generated at 2022-06-24 10:41:24.836593
# Unit test for constructor of class OneOf
def test_OneOf():
    data1 = {"name": "test"}
    field = OneOf([Any()], description="test")
    field.validate(data1, strict=False)
    assert field.description == "test"


# Generated at 2022-06-24 10:41:27.929901
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_ifthenelse = IfThenElse(1,2,3)
    assert test_ifthenelse.if_clause == 1
    assert test_ifthenelse.then_clause == 2
    assert test_ifthenelse.else_clause == 3

# Generated at 2022-06-24 10:41:29.754495
# Unit test for constructor of class AllOf
def test_AllOf():
    sut = AllOf([])


# Generated at 2022-06-24 10:41:30.566456
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-24 10:41:39.369130
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
        _, error = self.if_clause.validate_or_error(value, strict=strict)
        if error is None:
            return self.then_clause.validate(value, strict=strict)
        else:
            return self.else_clause.validate(value, strict=strict)

    assert test_IfThenElse_validate(5,10) == 5 and test_IfThenElse_validate(5,10) == 10

# Generated at 2022-06-24 10:41:46.597077
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem import Schema
    from typesystem.exceptions import ValidationError

    class UserDetails(Schema):
        class Meta:
            allow_null = True

        name = NeverMatch()

    user_details = UserDetails({"name": "franco"})

    try:
        user_details.validate()
    except ValidationError as e:
        assert e.message == {'name': {'never': 'This never validates.'}}
        assert e.field_error is None
        # test type
        assert isinstance(e, ValidationError)
        assert isinstance(e.field_error, NeverMatch)



# Generated at 2022-06-24 10:41:51.810218
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = None
    then_clause = None
    else_clause = None
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == None, "if_clause should be None"
    assert if_then_else.then_clause == Any(), "then_clause should be None"
    assert if_then_else.else_clause == Any(), "else_clause should be None"

# Generated at 2022-06-24 10:41:54.517696
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nevermatch = NeverMatch()
    with pytest.raises(nevermatch.validation_error):
        nevermatch.validate(1)

# Generated at 2022-06-24 10:42:00.128375
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from unittest import mock
    mockField = mock.MagicMock()
    val = mock.MagicMock()
    strict = mock.MagicMock()
    AllOf([mockField], name='name').validate(val, strict)
    mockField.validate.assert_called_with(val, strict=strict)

# Generated at 2022-06-24 10:42:08.317536
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    test_field = IfThenElse(Any())
    assert test_field.if_clause == Any()
    assert test_field.then_clause == Any()
    assert test_field.else_clause == Any()

    test_field = IfThenElse(Any(), Any(), Any())
    assert test_field.if_clause == Any()
    assert test_field.then_clause == Any()
    assert test_field.else_clause == Any()

    test_field = IfThenElse(Any(), Any())
    assert test_field.if_clause == Any()
    assert test_field.then_clause == Any()
    assert test_field.else_clause == Any()

# Generated at 2022-06-24 10:42:11.438477
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f1 = Field(type="string")
    s = IfThenElse(if_clause=f1, then_clause=f1, else_clause=f1)
    s.validate(value=1) # expected to fail with assert error

# Generated at 2022-06-24 10:42:17.095773
# Unit test for method validate of class Not
def test_Not_validate():
    stub_dict = {}
    stub_field = Field()
    stub_kwargs = {}
    stub_strict = True
    dummy_value = None
    dummy_error = None
    # Replace following line with mock (dummy) values
    dummy_validated, dummy_error = stub_field.validate_or_error(dummy_value,strict=stub_strict)
    if not dummy_error:
        return dummy_value
    else:
        raise stub_field.validation_error("negated")



# Generated at 2022-06-24 10:42:23.878000
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # create instance
    expected = 'This never validates.'
    try:
        # run method
        NeverMatch().validate('v', strict=False)
        # check for error (something went wrong)
        assert False
    except:
        # read result
        result = exc_info()[1]
        # check for expected
        result.args[0]['messages'][0] == expected

# Generated at 2022-06-24 10:42:26.561636
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse(if_clause=2)
    except AssertionError as e:
        assert str(e) == "if_clause=2 is not an instance of Field"

# Generated at 2022-06-24 10:42:31.649448
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # The method validate of class IfThenElse is called with right parameters
    # The method validate of class IfThenElse return None
    if_ = "ab"
    then_ = "ab"
    else_ = "ab"

    if_then_else = IfThenElse(if_, then_, else_)
    assert if_then_else.validate("ab") == "ab"
    assert if_then_else.validate("a") == "ab"



# Generated at 2022-06-24 10:42:33.650586
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        import typesystem

        field = typesystem.NeverMatch(name="field")
        field.validate("value")
    except Exception as exc:
        assert str(exc) == "This never validates."


# Generated at 2022-06-24 10:42:42.429274
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    _, error = IfThenElse(Boolean(), then_clause=Number(), else_clause=String()).validate_or_error(None, strict=False)
    assert error is not None

    _, error = IfThenElse(Boolean(), then_clause=Boolean(), else_clause=Boolean()).validate_or_error(True, strict=False)
    assert error is None

    _, error = IfThenElse(Boolean(), then_clause=Boolean(), else_clause=Boolean()).validate_or_error(False, strict=False)
    assert error is None



# Generated at 2022-06-24 10:42:48.172019
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Build stub objects
    all_of = Field()

    # Build stub class
    class stub_class:
        def validate(self, value, strict = False):
            return None

    # Build test object
    test = AllOf(all_of)

    # Perform test call
    assert test.validate(stub_class()) == None


# Generated at 2022-06-24 10:42:50.321155
# Unit test for constructor of class Not
def test_Not():
    print("Unit test for constructor of class Not")
    not_value = Not(negated=Any())


# Generated at 2022-06-24 10:42:53.614840
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(None, None)
    assert a is not None

# Generated at 2022-06-24 10:43:03.632100
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    ifThenElse = IfThenElse(if_clause, then_clause, else_clause)
    assert ifThenElse.validate(1) == "1"
    assert ifThenElse.validate("abc") == "abc"

    if_clause = String()
    then_clause = Integer()
    else_clause = String()

    ifThenElse = IfThenElse(if_clause, then_clause, else_clause)
    assert ifThenElse.validate("1") == 1
    assert ifThenElse.validate("abc") == "abc"

# Generated at 2022-06-24 10:43:04.338934
# Unit test for constructor of class OneOf
def test_OneOf():
    assert 1==1


# Generated at 2022-06-24 10:43:13.240535
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    r'''
    def test_OneOf_validate():
        a = OneOf([[{"type": "integer"}, {"type": "string"}]])
        b = validate(a, 1)
        c = validate(a, "string")
        d = a.validate(1)
        e = a.validate("string")
        f = validate(a, 1.0)
        g = validate(a, '1.0')

        assert b == 1
        assert c == 'string'
        assert d == 1
        assert e == 'string'
        assert f == 1.0
        assert g == '1.0'
    '''
    pass


# Generated at 2022-06-24 10:43:14.429293
# Unit test for constructor of class AllOf
def test_AllOf():
  pass


# Generated at 2022-06-24 10:43:17.616993
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Field(),Field())
    assert (field.if_clause, field.then_clause, field.else_clause) != (None, None, None)

# Generated at 2022-06-24 10:43:24.290936
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == 'test':
                return True
            else:
                raise self.validation_error("error")

    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == 'testing':
                return True
            else:
                raise self.validation_error("error")

    a = A()
    b = B()
    c = IfThenElse(a, then_clause=b)

    c.validate('test')
    c.validate('testing')
    try:
        c.validate('fail')
        assert (False)
    except:
         assert(True)


# Generated at 2022-06-24 10:43:32.691922
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class myField(Field):
        errors = {"error": "This always returns an error."}
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return self.validation_error("error")
    class myOtherField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    myObject = IfThenElse(myField(), myOtherField())
    value, error = myObject.validate_or_error(5, strict=False)
    assert error is None
    assert value == 5

# Generated at 2022-06-24 10:43:39.157138
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field1 = OneOf(one_of=[Dict(properties={"name": String()}), String()])
    assert field1.validate({"name": "value"}) == {"name": "value"}
    assert field1.validate("value") == "value"
    with pytest.raises(ValidationError) as exc:
        field1.validate({"age": 1})
    assert exc.value.messages == {"age": [{"type": ["Does not match any valid type"]}]}



# Generated at 2022-06-24 10:43:40.282826
# Unit test for constructor of class Not
def test_Not():
    # Test with no parameters
    assert isinstance(Not(negated="bool"), Not)


# Generated at 2022-06-24 10:43:48.276996
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # unit test for 'IfThenElse' constructor
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    ite = IfThenElse(if_clause, then_clause, else_clause)
    assert ite.if_clause == if_clause
    assert ite.then_clause == then_clause
    assert ite.else_clause == else_clause


# Generated at 2022-06-24 10:43:51.676897
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    allOf = AllOf([IntField(), FloatField()])
    assert allOf.validate(1)
    assert not allOf.validate(1.5)


# Generated at 2022-06-24 10:43:52.616160
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()



# Generated at 2022-06-24 10:43:54.358770
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[Any()]).all_of == [Any()]



# Generated at 2022-06-24 10:44:01.265768
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    from typesystem.fields.number import Number
    from typesystem.fields.object import Object
    from typesystem.fields.string import String
    obj = Object(properties={'a': IfThenElse(
        if_clause=Number(),
        then_clause=String(),
        else_clause=Integer())})
    x = obj.validate({'a': 1})
    assert x['a'] == '1'
    y = obj.validate({'a': 'a'})
    assert y['a'] == 'a'



# Generated at 2022-06-24 10:44:07.346246
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(None)
    assert not_field.negated == None


# Generated at 2022-06-24 10:44:11.679093
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Number
    from typing import List

    # arrange
    one_of: List[Number] = [Number(multiple_of=1), Number(multiple_of=10)]

    # act
    one_of_instance = OneOf(one_of)

    # assert
    assert one_of_instance.one_of == one_of
    assert one_of_instance.errors["no_match"] == "Did not match any valid type."
    assert one_of_instance.errors["multiple_matches"] == "Matched more than one type."



# Generated at 2022-06-24 10:44:16.891942
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    typesystem_AllOf = AllOf([String()])
    typesystem_AllOf.validate('123')
    typesystem_AllOf.validate('1')
    typesystem_AllOf.validate('123')
    typesystem_AllOf.validate('1')


# Generated at 2022-06-24 10:44:20.009841
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    code = 'NeverMatch()'
    result = eval(code)
    assert(isinstance(result, NeverMatch))
    assert(result.errors == {'never': 'This never validates.'})


# Generated at 2022-06-24 10:44:26.814971
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    IFT = IfThenElse(if_clause,then_clause,else_clause)
    assert IFT.if_clause == if_clause
    assert IFT.then_clause == then_clause
    assert IFT.else_clause == else_clause
    return


# Generated at 2022-06-24 10:44:34.840589
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    t1 = Field()
    t2 = Type()
    t3 = NeverMatch()
    t4 = NeverMatch()

    f = OneOf([t1, t2, t3, t4])

    # validates t1
    validated_value, error = f.validate_or_error(1)
    assert error is None
    assert validated_value == 1

    # validates t2
    validated_value, error = f.validate_or_error('foo')
    assert error is None
    assert validated_value == 'foo'

    # raises error on multiple matches
    with pytest.raises(ValidationError) as excinfo:
        f.validate(2.1)
    assert excinfo.value.messages == {'general': ['multiple_matches']}

    # raises error on no matches

# Generated at 2022-06-24 10:44:42.863413
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from unittest import TestCase
    from typesystem.fields import Integer

    assert IfThenElse(Integer(), Integer(minimum=0), Integer(maximum=0)).validate(5) == 5
    assert IfThenElse(Integer(minimum=10), Integer(minimum=0), Integer(maximum=0)).validate(5) == 0
    assert IfThenElse(Integer(maximum=0), Integer(minimum=0), Integer(maximum=0)).validate(5) == 0
    assert IfThenElse(
        Integer(minimum=0), Integer(minimum=0), Integer(maximum=0)
    ).validate(5) == 5

# Generated at 2022-06-24 10:44:49.359893
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    types = "abc"
    field = OneOf(types)
    assert isinstance(field, OneOf)
    assert field.one_of == types
    try:
        field.validate("a")
        assert False
    except Exception as e:
        assert str(e) == 'Did not match any valid type.'
    try:
        field.validate("e")
        assert False
    except Exception as e:
        assert str(e) == 'Did not match any valid type.'


# Generated at 2022-06-24 10:44:52.334043
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(Field.ValidationError):
        NeverMatch().validate(value=1)


# Generated at 2022-06-24 10:44:56.324727
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem import String, Integer
    from typesystem.fields import NeverMatch
    
    assert NeverMatch().__init__() == None
    assert NeverMatch()(String().__init__()) == None
    assert NeverMatch()(Integer().__init__()) == None




# Generated at 2022-06-24 10:44:58.163762
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from .fields import String

    field = IfThenElse(String(), String())



# Generated at 2022-06-24 10:45:02.824213
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Field())
    try:
        validated = field.validate(value="test")
    except Exception as e:
        assert isinstance(e, field.validation_error)
        assert e.code == 'negated'
        assert e.params == {'value': 'test'}
    else:
        assert validated == "test"

# Generated at 2022-06-24 10:45:04.146412
# Unit test for constructor of class OneOf
def test_OneOf():
    assert 1 == 1

# Generated at 2022-06-24 10:45:12.237164
# Unit test for constructor of class OneOf
def test_OneOf():
    # Create a OneOf instance
    one_of = OneOf(one_of=[])
    assert one_of.one_of == []
    # test if not a list
    assert one_of.one_of != 2
    assert one_of.one_of != 'TypeSystem'
    assert one_of.one_of != {'a':1, 'b':2}
    assert one_of.one_of != None
    assert one_of.one_of != True
    assert one_of.one_of != False
    # test here
    assert type(one_of.one_of) == list
    # test if not just an empty list
    assert one_of.one_of != []


# Generated at 2022-06-24 10:45:20.472437
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(Schema({"x": Integer()}), Integer())
    assert schema.validate({"x": 1})
    assert schema.validate({"x": 1}, strict=True) == {"x": 1}
    assert schema.validate({"x": 1, "y": "s"}) == {"x": 1, "y": "s"}
    assert schema.validate({"x": 1, "y": "s"}, strict=True) == {"x": 1, "y": "s"}
    assert schema.validate({"y": 4}) == {"y": 4}
    assert schema.validate({"y": 4}, strict=True) == {"y": 4}
    assert schema.validate(4) == 4
    assert schema.validate(4, strict=True) == 4
    assert schema.validate

# Generated at 2022-06-24 10:45:24.281072
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:45:26.781894
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        field = NeverMatch()
        field.validate(1)
        assert False
    except Exception as e:
        assert str(e) == "This never validates."


# Generated at 2022-06-24 10:45:28.956146
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nevermatch = NeverMatch()
    assert nevermatch.validate(1) is None


# Generated at 2022-06-24 10:45:29.594438
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:45:33.337120
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=None)
    assert not_field.negated is None
    assert not_field.errors == {"negated": "Must not match."}



# Generated at 2022-06-24 10:45:40.835054
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem
    class PositiveInteger(typesystem.Integer):
        errors = {"not_positive": "Must be a positive integer."}
        def validate(self, value):
            if not value > 0:
                raise self.validation_error("not_positive")
            return value

    class LessThan5(typesystem.Integer):
        errors = {"not_less_than_5": "Must less than 5."}
        def validate(self, value):
            if value >= 5:
                raise self.validation_error("not_less_than_5")
            return value

    class PositiveAndSmall(typesystem.AllOf):
        def __init__(self, **kwargs):
            super().__init__([PositiveInteger(), LessThan5()], **kwargs)

    schema = PositiveAndSmall()


# Generated at 2022-06-24 10:45:52.678052
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    value_list = [
        {}, {"a": 1},
        {"b": 1, "a": 1},
        {"c": 1, "a": 1}
    ]
    key_list = ["a", "b", "c"]
    for value in value_list:
        all_of_list = [
            Field(required=True, allow_null=True) for key in key_list
        ]
        for index, key in enumerate(key_list):
            if key in value:
                all_of_list[index].validate(value[key])
        # test valid value
        my_all_of = AllOf(all_of=all_of_list)
        my_all_of.validate(value)



# Generated at 2022-06-24 10:45:53.957104
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf(None)
    AllOf(None, default=None)
    AllOf(None, description="")


# Generated at 2022-06-24 10:45:55.493591
# Unit test for constructor of class AllOf
def test_AllOf():
    objects = [{'name': 'one'}, {'name': 'two'}]
    assert objects[0]['name'] is not objects[1]['name']


# Generated at 2022-06-24 10:45:57.026226
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test = OneOf([Field(name="test")])
    assert test.validate(1) == 1


# Generated at 2022-06-24 10:46:03.360257
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    nField1 = Field()
    nField2 = Field()
    nField3 = Field()
    nIfThenElse = IfThenElse(nField1, nField2, nField3)
    assert nIfThenElse.if_clause == nField1
    assert nIfThenElse.then_clause == nField2
    assert nIfThenElse.else_clause == nField3

# Generated at 2022-06-24 10:46:04.286350
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-24 10:46:06.459557
# Unit test for constructor of class OneOf
def test_OneOf():
    exampleOneOf = OneOf('one', 'two', 'three')

# Generated at 2022-06-24 10:46:16.966550
# Unit test for constructor of class OneOf
def test_OneOf():
    assert issubclass(OneOf, Field)
    assert OneOf.__name__ == 'OneOf'
    assert OneOf.__module__ == __name__
    assert OneOf.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}
    assert OneOf.__init__ != Field.__init__
    assert OneOf.validate != Field.validate
    assert OneOf.__doc__ == '\n    Must match exactly one of the sub-items.\n    \n    You\'ll almost always want to just use `Union` instead of this, which is an\n    "anyOf" test.\n    '



# Generated at 2022-06-24 10:46:23.878328
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(Field.ValidationError, match=r"This never validates.") as exception_info:
        NeverMatch().validate("anything")
    assert exception_info.value.field == "never"


# Generated at 2022-06-24 10:46:25.694062
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([1,2,3])


# Generated at 2022-06-24 10:46:28.184613
# Unit test for constructor of class OneOf
def test_OneOf():
    oneOf_field = OneOf(one_of = [])
    assert oneOf_field.one_of == []


# Generated at 2022-06-24 10:46:28.544780
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True

# Generated at 2022-06-24 10:46:37.256267
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def testcase(if_clause, then_clause, else_clause):
        if_clause = eval(if_clause)
        then_clause = eval(then_clause)
        else_clause = eval(else_clause)
        field = IfThenElse(if_clause, then_clause, else_clause)
        return field.validate({"name": "peter"})
    assert testcase('{"type": "object", "properties": {"name": {"type": "string"}}}', '{"type": "object", "properties": {}}', '{"type": "object", "properties": {}}') == {"name": "peter"}

# Generated at 2022-06-24 10:46:42.325932
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ifThenElse = IfThenElse(Field(key='key'), Field(min_length=10), Field(max_length=20))
    assert ifThenElse.if_clause.key == 'key'
    assert ifThenElse.then_clause.min_length == 10
    assert ifThenElse.else_clause.max_length == 20


# Generated at 2022-06-24 10:46:43.275800
# Unit test for constructor of class OneOf
def test_OneOf():
    ...


# Generated at 2022-06-24 10:46:48.642331
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    
    field = IfThenElse(OneOf([]), then_clause=AllOf([]))
    assert field.validate_or_error(None)

    field = IfThenElse(OneOf([]), else_clause=AllOf([]))
    assert field.validate_or_error(None)

    field = IfThenElse(OneOf([NeverMatch()]))
    assert field.validate_or_error(None) is None

    field = IfThenElse(OneOf([NeverMatch()]), then_clause=AllOf([]))
    assert field.validate_or_error(None) is None

    field = IfThenElse(OneOf([NeverMatch()]), else_clause=AllOf([]))
    assert field.validate_or_error(None) == None


# Generated at 2022-06-24 10:46:50.092551
# Unit test for constructor of class OneOf
def test_OneOf():
	assert(isinstance(OneOf(one_of=[1,2]), OneOf))

# Generated at 2022-06-24 10:46:51.978514
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = [Field(),Field()]
    self = AllOf(all_of)
    expected = "hello"
    actual = self.validate(expected)
    assert actual == expected

# Generated at 2022-06-24 10:46:56.838494
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Schema
    from typesystem.fields import Not
    from typesystem.types import EmailType
    from typesystem.types import String
    
    class InvalidEmail(Schema):

        email = Not(EmailType())

    invalid_email = InvalidEmail()

    # test for matching
    case1 = invalid_email.validate({"email":"shuyan@"}, strict=False)
    assert case1 == {"email":"shuyan@"}

    # test for not matching
    case2 = invalid_email.validate({"email":"shuyan.li@nyu.edu.au"}, strict=False)
    assert case2 == None



# Generated at 2022-06-24 10:46:59.280890
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    t = AllOf([])
    assert t.validate(1) == 1
    assert t.validate([]) == []


# Generated at 2022-06-24 10:47:03.818680
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    field = IfThenElse(if_clause,then_clause,else_clause)
    data = ""
    expected = ""
    actual = field.validate(data,strict=False)
    assert actual == expected


# Generated at 2022-06-24 10:47:05.175234
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any()])
    field.validate(value=1)


# Generated at 2022-06-24 10:47:09.669232
# Unit test for constructor of class Not
def test_Not():
    class Address(TypesystemObject):
        city = String()
    address = Address()
    address.city = "London"
    result = Not(city, **kwargs)
    assert result.validate(value, strict=strict) == True
    assert result.negated == "city"
    assert result.validate(value, strict=strict) == True


# Generated at 2022-06-24 10:47:10.904181
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f=NeverMatch()
    assert f.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:47:13.046211
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    AllOf([String(), String()]).validate("Hello")


# Generated at 2022-06-24 10:47:15.003143
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test cases will be implemented soon
    assert IfThenElse


# Generated at 2022-06-24 10:47:17.891197
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String, Integer
    Field_Set = AllOf([String(), Integer()])
    assert Field_Set.validate(10) == 10
    assert Field_Set.validate(10, strict=True) == 10
    assert Field_Set.validate('a') == 'a'
    assert Field_Set.validate('a', strict=True) == 'a'


# Generated at 2022-06-24 10:47:27.249558
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    list_of_types = [Any(), AllOf([Any()]), AllOf([Any()])]
    a = AllOf(all_of = list_of_types) #Instantiate object of class AllOf
    for i in range(3):
        assert a.validate(1) == 1
        assert a.validate("Hello") == "Hello"
        assert a.validate(1.0) == 1.0
        assert a.validate([1, 2, 3]) == [1, 2, 3]
        assert a.validate({"name": "John", "age": 20}) == {"name": "John", "age": 20}
        assert a.validate(True) == True

# Generated at 2022-06-24 10:47:35.367411
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    value = None
    strict = False
    with pytest.raises(TypeError) as error:
        OneOf(one_of = [ 1 ]).validate(value, strict)
    with pytest.raises(TypeError) as error:
        OneOf(one_of = [ 1 ]).validate(value, strict)
    with pytest.raises(TypeError) as error:
        OneOf(one_of = [ 1 ]).validate(value, strict)


# Generated at 2022-06-24 10:47:37.192811
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[Any(), Any()]) is not None


# Generated at 2022-06-24 10:47:40.208158
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    allof = AllOf([Field(),Field()])
    value = 3
    assert allof.validate(value) == value

# Generated at 2022-06-24 10:47:44.524424
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Initializing NeverMatch object
    _NeverMatch_obj = NeverMatch()
    # Calling method on NeverMatch object
    exception_raised = False
    try:
        _NeverMatch_obj.validate(0)
    except:
        exception_raised = True
    assert exception_raised


# Generated at 2022-06-24 10:47:54.652806
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class test_object(object):
        def __init__(self, a=None, b=None, c=None, d=None):
            self.a = a
            self.b = b
            self.c = c
            self.d = d

    object1 = test_object(3,4,5,6)
    object2 = test_object(7,8,9,10)

    if_clause = Field.create(type="integer")
    then_clause = Field.create(type="integer")
    else_clause = Field.create(type="array", items=object1)

    test_field = IfThenElse(if_clause, then_clause, else_clause)

    assert test_field.validate(9) == 9

# Generated at 2022-06-24 10:48:04.528331
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    json_str = """{
      "type": "object",
      "properties": {
        "name": {
          "type": "string"
        },
        "age": {
          "type": "integer"
        },
        "salary": {
          "type": "number"
        }
      },
      "required": [
        "name",
        "age"
      ]
    }"""
    json_schema = json.loads(json_str)
    test_schema = Schema(json_schema)
    # Act
    employee = test_schema.validate({'name': 'John', 'age': 26, 'salary': 10000})
    # Assert
    assert employee.is_valid()
    assert employee.get('name') == "John"

# Generated at 2022-06-24 10:48:06.365440
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[Any()])


# Generated at 2022-06-24 10:48:08.344194
# Unit test for constructor of class Not
def test_Not():
    negated = Not(AllOf([Any()]))
    assert negated.name == 'Not'

# Generated at 2022-06-24 10:48:15.387040
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Boolean, String

    number = IfThenElse(Boolean(), String())

    assert number.validate(True) == "True"
    assert number.validate(False) == "False"

# Generated at 2022-06-24 10:48:24.212174
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse(if_clause=None, then_clause=None, else_clause=None, error_messages={"test_error": "Custom error message"})
        assert False
    except AssertionError:
        pass

    try:
        IfThenElse(if_clause=None, then_clause=None, else_clause=None, error_messages={"test_error": "Custom error message"}, allow_null=False)
        assert False
    except AssertionError:
        pass
    try:
        IfThenElse(if_clause=None, then_clause=None, else_clause=None, error_messages={"test_error": "Custom error message"}, allow_blank=False)
        assert False
    except AssertionError:
        pass

# Generated at 2022-06-24 10:48:26.565139
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf([])
    b = AllOf([])
    a.validate(b) # validating that two objects are equal


# Generated at 2022-06-24 10:48:30.799110
# Unit test for constructor of class OneOf
def test_OneOf():
    obj_oneOf = OneOf([1, 2, 3])
    assert obj_oneOf is not None