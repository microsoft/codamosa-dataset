

# Generated at 2022-06-24 10:38:41.647889
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Initializing typesystem and field
    import typesystem
    from pydantic import BaseConfig
    from typesystem.fields import NeverMatch
    from typing import Any

    schema = typesystem.Schema(
        {
            "name": NeverMatch(),
        },
        strict=False,
    )

    # Test for `validate` method of class `NeverMatch`
    try:
        schema.validate({"name": "test"})
    except Exception as error:
        assert (
            str(error)
            == "validation error of NeverMatch in 'name' at 'name': This never validates."
        )

    # Test for `errors` property of field `NeverMatch`
    assert schema.fields[0].errors["never"] == "This never validates."

    # Test for `validate` method with strict False

# Generated at 2022-06-24 10:38:42.757955
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
    except:
        assert False

# Generated at 2022-06-24 10:38:47.259318
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field=AllOf()
    assert field.validate(4) == 4


# Generated at 2022-06-24 10:38:52.254083
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
    OneOf() should validate if exactly one of the sub-items passes.
    """
    # Should validate
    field = OneOf([
        String(),
        String(max_length=7),
    ])
    assert field.validate("testing") == "testing"
    assert field.validate("testing")._errors == {}
    assert field.validate("testing").to_native() == "testing"

    # Should not validate
    field = OneOf([
        String(max_length=7),
        String(max_length=8),
    ])
    assert field.validate("testing") == "testing"
    assert field.validate("testing")._errors == {}
    assert field.validate("testing").to_native() == "testing"


# Generated at 2022-06-24 10:38:54.797880
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(Field.ValidationError):
        f = NeverMatch()
        f.validate(0)


# Generated at 2022-06-24 10:39:05.857714
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Valid
    one_of = OneOf([Int(max_value=10), Int(min_value=20)], name="one_of")
    assert one_of.validate(5) == 5
    assert one_of.validate(25) == 25

    # Invalid
    with pytest.raises(ValidationError) as exc_info:
        one_of.validate(15)
    assert exc_info.value.code == "multiple_matches"

    # Invalid
    with pytest.raises(ValidationError) as exc_info:
        one_of.validate(15, strict=True)
    assert exc_info.value.code == "multiple_matches"

    # Invalid

# Generated at 2022-06-24 10:39:07.870444
# Unit test for constructor of class AllOf
def test_AllOf():
    fields = [Any(), Any()]
    allof = AllOf(all_of = fields)
    assert allof.all_of == fields



# Generated at 2022-06-24 10:39:15.121488
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Create a simple test class
    class A:
        pass

    a = A()

    # Create the child fields, if_clause and then_clause
    allowed_types = (A,)

    if_field = OneOf([Instance(allowed_types)])
    then_field = Instance(allowed_types)

    # Create an IfThenElse instance and try an allowed value
    if_then_else_field = IfThenElse(if_field, then_field)
    allowed_value = a
    assert if_then_else_field.validate(allowed_value) == allowed_value

    # Create an IfThenElse instance and try a disallowed value
    class B:
        pass

    b = B()

    if_then_else_field = IfThenElse(if_field, then_field)

# Generated at 2022-06-24 10:39:21.090602
# Unit test for method validate of class Not
def test_Not_validate():
    # Method Not validate
    # Arrange
    # Act
    # Assert
    from typesystem.fields import Choice

    choices = ["a", "b", "c"]
    not_field = Not(Choice(choices))
    not_field.validate("d")
    assert True
    with pytest.raises(ValueError) as excinfo:
        not_field.validate("a")
    assert excinfo.typename == "ValidationError"
    assert str(excinfo.value) == "Must not match."



# Generated at 2022-06-24 10:39:22.433425
# Unit test for constructor of class Not
def test_Not():
    field = Not(String())
    assert field.negated == String()


# Generated at 2022-06-24 10:39:23.827903
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch()
    assert obj

# Generated at 2022-06-24 10:39:30.023258
# Unit test for method validate of class Not
def test_Not_validate():
    my_not = Not(String())
    my_valid_data = [
        "",
        "a"
    ]
    my_invalid_data = [None, 1.0, True, dict()]
    for string in my_valid_data:
        assert my_not.validate(string) == string
    for data in my_invalid_data:
        try:
            my_not.validate(data)
        except Exception as e:
            pass
        else:
            raise AssertionError("Exception should be raised")
    

# Generated at 2022-06-24 10:39:41.353306
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    assert IfThenElse(if_clause).if_clause == if_clause
    assert IfThenElse(if_clause).then_clause == Field(allow_null=True)
    assert IfThenElse(if_clause).else_clause == Field(allow_null=True)
    assert IfThenElse(if_clause, then_clause).then_clause == then_clause
    assert IfThenElse(if_clause, else_clause).else_clause == else_clause
    assert IfThenElse(if_clause, then_clause).else_clause == Field(allow_null=True)
    assert IfThenElse(if_clause, else_clause).then_cl

# Generated at 2022-06-24 10:39:43.179419
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.name is None
    assert field.description is None
    assert field.nullable is False


# Generated at 2022-06-24 10:39:44.616150
# Unit test for constructor of class OneOf
def test_OneOf():
	assert isinstance(OneOf([Any()]), OneOf)


# Generated at 2022-06-24 10:39:47.158984
# Unit test for constructor of class Not
def test_Not():

    type_definition = Not(Any())
    assert type_definition is not None

# Generated at 2022-06-24 10:39:49.195605
# Unit test for constructor of class Not
def test_Not():
    negate = Not(Any())
    assert negate.negated == Any()

# Generated at 2022-06-24 10:39:49.709065
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:39:56.782876
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print('Testing method validate of class OneOf')

    from typesystem import Schema

    my_schema = Schema({"a": OneOf([Schema({"b": int})])})

    # test that it returns a valid
    res = my_schema.validate({"a": {"b": 1}})
    assert res["a"] == {"b": 1} == res["a"]

    # test that it returns "no_match" if type doesn't match
    try:
        my_schema.validate({"a": {"b": "abc"}})
        assert False
    except Schema.ValidationError as e:
        assert str(e) == "Did not match any valid type."

# Generated at 2022-06-24 10:39:57.412571
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-24 10:40:06.916791
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    def validate_method_mock_if_clause(value, strict=False):
        pass
    def validate_method_mock_then_clause(value, strict=False):
        pass
    def validate_method_mock_else_clause(value, strict=False):
        pass
    if_clause = typesystem.object.Object(properties = {"validate": validate_method_mock_if_clause})
    then_clause = typesystem.object.Object(properties = {"validate": validate_method_mock_then_clause})
    else_clause = typesystem.object.Object(properties = {"validate": validate_method_mock_else_clause})

# Generated at 2022-06-24 10:40:08.364970
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    assert nm.validate(None) 


# Generated at 2022-06-24 10:40:11.732359
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch(description="This never validates.")
    assert nm.description == "This never validates."
    assert nm.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:40:14.002356
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.validate("abc") == "abc"


# Generated at 2022-06-24 10:40:18.353961
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=Int(), then_clause=Int(), else_clause=Str())
    assert field.if_clause.__class__.__name__ == "Int"
    assert field.then_clause.__class__.__name__ == "Int"
    assert field.else_clause.__class__.__name__ == "Str"

# Generated at 2022-06-24 10:40:20.693623
# Unit test for constructor of class Not
def test_Not():
    #import io, sys
    #from contextlib import redirect_stdout
    #f = io.StringIO()
    #with redirect_stdout(f):
    assert Not(negated=None)

# Generated at 2022-06-24 10:40:30.126995
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Boolean, Integer
    from typesystem.exceptions import ValidationError
    data = [
        (Integer(), [{'value': 5, 'error': None}]),
        (Boolean(), [{'value': False, 'error': None}]),
        (Integer(), [{'value': 'a', 'error': "'a' is not a valid integer."},
                     {'value': None, 'error': "Value was None, not a valid integer."}]),
        (Boolean(), [{'value': 'a', 'error': "Value was not a valid boolean."},
                     {'value': None, 'error': "Value was None, not a valid boolean."}]),
    ]
    for case in data:
        # print(case)
        one_of = OneOf(one_of=[case[0]])
       

# Generated at 2022-06-24 10:40:42.291227
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(), Any())
    assert field.validate(1)
    assert field.validate('a')

    field = IfThenElse(Any(min_length=3), Any())
    assert field.validate(1) == 1
    assert field.validate('a') == 'a'

    field = IfThenElse(Any(min_length=3), Any(max_length=2))
    assert field.validate(1) == 1
    assert field.validate('a') == 'a'

    field = IfThenElse(Any(min_length=3), Any(max_length=2), Any())
    assert field.validate(1) == 1
    assert field.validate('a') == 'a'


# Generated at 2022-06-24 10:40:44.229204
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch(name="NeverMatch")
    assert n.name == "NeverMatch"


# Generated at 2022-06-24 10:40:45.911179
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([Int(), Greater(32)])
    assert f.validate(42) == 42



# Generated at 2022-06-24 10:40:53.064515
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Boolean

    class MyObject(Object):
        afield = Integer()
        bfield = String()
        cfield = Array(String())
        dfield = Boolean()

    class MyIfThenElse(IfThenElse):
        if_clause = Integer()
        then_clause = MyObject(required=['afield'])
        else_clause = MyObject(required=['cfield'])

    # test AllOf Fields
    foo = AllOf([String(), Integer()])
    foo.validate('a string')
    foo.validate(10)

    # test IfThenElse Fields
    foo2 = MyIfThenElse()
    foo2.valid

# Generated at 2022-06-24 10:40:58.133785
# Unit test for constructor of class OneOf
def test_OneOf():
    # Check the created object is of type Field
    assert isinstance(OneOf([], type="OneOf"), Field)
    # Check the created object is of type OneOf
    assert isinstance(OneOf([], type="OneOf"), OneOf)


# Generated at 2022-06-24 10:40:59.540813
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # TODO : define test set and result
    assert 1 == 1


# Generated at 2022-06-24 10:41:00.642206
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse


# Generated at 2022-06-24 10:41:01.540823
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()

# Generated at 2022-06-24 10:41:04.666328
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    try:
        nm.validate("foo")
    except Exception as inst:
        assert inst.args[0] == {"errors": ["This never validates."]}


# Generated at 2022-06-24 10:41:07.481045
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f = OneOf([Any(), Any()])
    f.validate(1)

# Unit test to verify that the method validate of class FillInTheBlanks
# raises a validation error if the number of tokens is less than the number
# of blanks

# Generated at 2022-06-24 10:41:11.116109
# Unit test for constructor of class OneOf
def test_OneOf():
    assert len(OneOf([]).one_of) == 0
    assert len(OneOf([Any()]).one_of) == 1

# Generated at 2022-06-24 10:41:15.427432
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        if_clause = Integer()
        then_clause = String()
        else_clause = Integer()
        IfThenElse(if_clause, then_clause, else_clause)
    except:
        assert False


# Generated at 2022-06-24 10:41:17.164888
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([])


# Generated at 2022-06-24 10:41:19.883623
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch(name="a")
    b = NeverMatch(name="b")
    assert a.name == "a"
    assert b.name == "b"


# Generated at 2022-06-24 10:41:20.679728
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-24 10:41:21.659032
# Unit test for constructor of class Not
def test_Not():
    notField = Not(Field("not"))

# Generated at 2022-06-24 10:41:24.183036
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    value = "abc"
    with pytest.raises(ValidationError):
        assert field.validate(value)


# Generated at 2022-06-24 10:41:26.277809
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("test", strict=False) is None

test_NeverMatch_validate()


# Generated at 2022-06-24 10:41:26.962750
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field=NeverMatch()
    assert 1==1

# Generated at 2022-06-24 10:41:27.832107
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert isinstance(NeverMatch(name="field"), NeverMatch)


# Generated at 2022-06-24 10:41:29.942318
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    ite = IfThenElse(if_clause, then_clause, else_clause, name="test")
    assert ite.validate("test") == "test"

# Generated at 2022-06-24 10:41:41.740685
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([]) == OneOf([])
    assert OneOf([]) != []
    assert OneOf([]) == 'OneOf'
    assert OneOf([1]) == OneOf([1])
    assert OneOf([1]) != 1
    assert OneOf([1]) == 'OneOf'
    assert OneOf([1]) == 'OneOf'
    assert OneOf([0]) != 'OneOf'
    assert OneOf([1.0]) == 'OneOf'
    assert OneOf(['one']) == 'OneOf'
    assert OneOf([{'a':1}]) == 'OneOf'
    assert OneOf([[1]]) == 'OneOf'
    assert OneOf([True]) == 'OneOf'
    assert OneOf([False]) == 'OneOf'
    assert OneOf([None]) == 'OneOf'



# Generated at 2022-06-24 10:41:47.448837
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    F1 = Any()
    F2 = Any()
    F3 = NeverMatch()
    F4 = NeverMatch()
    F = OneOf([F1, F2, F3, F4])
    res = F.validate(1)
    assert res == 1
    try:
        F.validate(None)
        assert False
    except:
        assert True



# Generated at 2022-06-24 10:41:51.569665
# Unit test for constructor of class OneOf
def test_OneOf():
    assert 2==2
    assert type(OneOf([]))==OneOf
    assert type(OneOf([Field()]))==OneOf


# Generated at 2022-06-24 10:41:54.051063
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    type = OneOf([
        Any(),
        Any(),
    ])
    value = 'blabla'
    strict = False
    with pytest.raises(Exception) as error:
        type.validate(value, strict)
    assert error.value.args[0] == 'Matched more than one type.'

# Generated at 2022-06-24 10:41:57.676260
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(ValidationError) as exc_info:
        NeverMatch().validate(2)
    assert exc_info.value.messages == {"": {"never": "This never validates."}}


# Generated at 2022-06-24 10:41:58.641685
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)

# Generated at 2022-06-24 10:42:01.159786
# Unit test for constructor of class Not
def test_Not():
    field = Not(Integer())
    assert field.negated == Integer()
    assert field.validate(False) == False


# Generated at 2022-06-24 10:42:04.945477
# Unit test for constructor of class Not
def test_Not():
    import typesystem
    print("\n\nUnit test for constructor of class Not\n")
    basic_typesystem = typesystem.Typesystem()
    notNullField = basic_typesystem.Not(basic_typesystem.Null())
    assert notNullField.negated == basic_typesystem.Null()


# Generated at 2022-06-24 10:42:05.513724
# Unit test for method validate of class Not
def test_Not_validate():
    assert True

# Generated at 2022-06-24 10:42:16.380142
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    obj = OneOf([Any()])
    assert obj.validate(None) == None
    assert obj.validate(True) == True
    assert obj.validate(False) == False
    assert obj.validate(0) == 0
    assert obj.validate(1) == 1
    assert obj.validate(-1) == -1
    assert obj.validate(2.3) == 2.3
    assert obj.validate(object) == object
    assert obj.validate(object()) == object()
    assert obj.validate(b"hello") == b"hello"
    assert obj.validate(u"hello") == u"hello"
    assert obj.validate("hello") == "hello"
    test_dict = {"a": 1}
    assert obj.validate(test_dict) == test_dict



# Generated at 2022-06-24 10:42:23.686049
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer

    # Create object
    obj = Not(Integer(minimum=300))

    # Test case 1
    expected = 100
    actual = obj.validate(expected)
    assert expected == actual

    # Test case 2
    expected = 400
    actual = obj.validate(expected)
    assert expected == actual

    # Test case 3
    expected = 400
    actual = obj.validate(expected)
    assert expected == actual



# Generated at 2022-06-24 10:42:26.727938
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer, String
    AllOf([Integer(), String()])
    try:
        AllOf([Integer()], allow_null=True)
        raise AssertionError
    except AssertionError:
        pass


# Generated at 2022-06-24 10:42:32.349813
# Unit test for method validate of class OneOf
def test_OneOf_validate():
	obj = OneOf(one_of=[])
	# obj must be an instance of OneOf
	assert isinstance(obj, OneOf)
	# obj must be an instance of Field
	assert isinstance(obj, Field)
	# obj must be an instance of MetaField
	assert isinstance(obj, type)
	# Call method validate of obj:
	# obj.validate(self, value, strict)
	# type(value) must be <class 'int'>
	assert type(1) == int
	# value must be equal 1
	assert 1 == 1

# Generated at 2022-06-24 10:42:35.422990
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    error_message = "This never validates."
    try:
        NeverMatch().validate(10)
    except ValidationError as e:
        assert e.messages[0] == error_message



# Generated at 2022-06-24 10:42:44.480238
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())

    # Test for case 'Must not match.'
    try:
        not_field.validate(value=None, strict=False)
    except FieldError as err:
        assert err.code == 'negated'
        assert str(err) == 'Must not match.'

    # Test for case 'Must not match.'
    try:
        not_field.validate(value=None, strict=True)
    except FieldError as err:
        assert err.code == 'negated'
        assert str(err) == 'Must not match.'

# Generated at 2022-06-24 10:42:46.921843
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        field = NeverMatch(allow_null=True)



# Generated at 2022-06-24 10:42:55.447430
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import String
    from typesystem.errors import ValidationError
    all_of_field = AllOf([String(), String()])
    # Test when there are no validation errors
    try:
        all_of_field.validate('abc')
    except ValidationError:
        assert False
    # Test when the field does not have a value
    try:
        all_of_field.validate('')
    except ValidationError:
        assert False
    # Test when the value is not a string
    try:
        all_of_field.validate(123)
    except ValidationError:
        assert False

# Generated at 2022-06-24 10:43:06.363616
# Unit test for constructor of class Not
def test_Not():
    import json
    import typesystem
    def test_of_Not(self):
        """Test the constructor of class Not."""
        field_name = "name"
        field_error = "error"
        field_name_error = field_name + "_error"
        field_name_error_msg = "field_name_error"
        field_name_error_msg_code = 100
        field_name_error_msg_params = "field_name_error_params"
        field_name_error_msg_params_code = 200

# Generated at 2022-06-24 10:43:08.614505
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated = "I am negated")
    assert not_field.negated == "I am negated"

# Generated at 2022-06-24 10:43:14.806581
# Unit test for constructor of class Not
def test_Not():
    v = Not(2, description="description")
    assert v.description == "description" and v.negated == 2


# Generated at 2022-06-24 10:43:19.600643
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import String
    import pytest
    with pytest.raises(AssertionError):
        OneOf(
            one_of=[String()],
            allow_null=True
        )
    with pytest.raises(AssertionError):
        OneOf(
            one_of=[String()]
        )

# Generated at 2022-06-24 10:43:20.675406
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([
        Field(),
        Field(),
        Field(),
    ])

# Generated at 2022-06-24 10:43:22.169634
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    value = 1
    assert field.validate(value) == 1



# Generated at 2022-06-24 10:43:25.229257
# Unit test for method validate of class Not
def test_Not_validate():
    def example(x):
        return x + 1

    def negative_example(x):
        return x - 1

    not_example = Not(example(x))



# Generated at 2022-06-24 10:43:34.116455
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # test with no then or else clause
    if_clause = Field()
    ite = IfThenElse(if_clause)
    assert ite.if_clause is if_clause
    assert isinstance(ite.then_clause, Any)
    assert isinstance(ite.else_clause, Any)

    # test with only then clause
    ite = IfThenElse(if_clause, then_clause=if_clause)
    assert ite.if_clause is if_clause
    assert ite.then_clause is if_clause
    assert isinstance(ite.else_clause, Any)

    # test with only else clause
    ite = IfThenElse(if_clause, else_clause=if_clause)
    assert ite.if_clause is if_

# Generated at 2022-06-24 10:43:36.772131
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Bool(),Number())
    value = 5
    state = field.validate(value)
    assert state == 5


# Generated at 2022-06-24 10:43:38.223393
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert type(NeverMatch()) == type(NeverMatch)


# Generated at 2022-06-24 10:43:44.625220
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from .exceptions import ValidationError
    from .fields import Integer
    from .compound_types import Array
    from .typing import Str

    try:
        IfThenElse(Str(), Integer())
        assert False
    except AssertionError:
        assert True

    try:
        IfThenElse(Str(), Array(Integer()))
        assert False
    except AssertionError:
        assert True

    try:
        IfThenElse(Str(), None, Integer())
        assert False
    except AssertionError:
        assert True

    try:
        IfThenElse(Str(), None, Array(Integer()))
        assert False
    except AssertionError:
        assert True

    assert '"a" is not a valid integer' in str(
        IfThenElse(Str(), Integer(), Integer()).validate('a'))

# Generated at 2022-06-24 10:43:51.372330
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field1 = IfThenElse(String(), Number())
    field2 = IfThenElse(String(), Number(), Number())
    field3 = IfThenElse(String(), Number(), Any()) 
    field4 = IfThenElse(String(), Any(), Number())
    field5 = IfThenElse(String(), Any(), Any())

    assert field1.validate("2") == "2"
    assert field2.validate("2") == "2"
    assert field3.validate("2") == "2"
    assert field4.validate("2") == "2"
    assert field5.validate("2") == "2"

# Generated at 2022-06-24 10:43:54.270213
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import String, Number
    allOf = AllOf([String(), Number()])
    allOf.validate(1)
    allOf.validate("a")
    allOf.validate("1")

# Generated at 2022-06-24 10:43:58.080642
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    assert IfThenElse(if_clause, then_clause, else_clause).validate(value = 1) == 1


# Generated at 2022-06-24 10:44:00.081361
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(Field.ValidationError):
        field.validate(field)


# Generated at 2022-06-24 10:44:03.089291
# Unit test for method validate of class Not
def test_Not_validate():
    not_value = Not("not_field")
    assert not_value.validate("not_field") == Field.error("negated")
    assert not_value.validate("not_field", strict=True) == Field.error("negated")


# Generated at 2022-06-24 10:44:04.219246
# Unit test for constructor of class Not
def test_Not():
    field = Not(Any())
    assert field.negated == Any()


# Generated at 2022-06-24 10:44:07.189606
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse(Field(),Field(),Field())
    b = IfThenElse(Field(),Field())
    c = IfThenElse(Field())
    assert a.validate(None) == None
    assert b.validate(None) == None
    assert c.validate(None) == None



# Generated at 2022-06-24 10:44:17.823158
# Unit test for constructor of class AllOf
def test_AllOf():

    from typesystem import String, Number

    class AllOf(Field):

        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.all_of = all_of

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            for child in self.all_of:
                child.validate(value, strict=strict)
            return value

    type_all_of = AllOf(all_of=[String, Number])
    assert type_all_of.validate("1") == "1"


# Generated at 2022-06-24 10:44:20.449641
# Unit test for constructor of class Not
def test_Not():
    f = Not(negated = AllOf([Integer(),Integer()]))
    assert f.negated.all_of[0].__class__.__name__ == 'Integer'

# Generated at 2022-06-24 10:44:23.444819
# Unit test for constructor of class AllOf
def test_AllOf():
    x = AllOf([Any()], description="descr")
    assert x.all_of == [Any()]
    assert x.description == "descr"


# Generated at 2022-06-24 10:44:29.641325
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    f = IfThenElse(String())
    assert f.if_clause == String()
    assert f.then_clause == Any()
    assert f.else_clause == Any()
    f = IfThenElse(String(), then_clause=String(), else_clause=String())
    assert f.if_clause == String()
    assert f.then_clause == String()
    assert f.else_clause == String()



# Generated at 2022-06-24 10:44:30.717795
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-24 10:44:36.806341
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # test for type 'int'
    test_field = OneOf([Integer(minimum=5, maximum=10)])
    assert test_field.validate(6) == 6
    # test for type 'str'
    test_field = OneOf([String(max_length=80), Integer(minimum=5, maximum=10)])
    assert test_field.validate("test") == "test"
    # test for type 'float'
    test_field = OneOf([Float(minimum=5.5, maximum=10.5)])
    assert test_field.validate(6.6) == 6.6
    # test for type 'bool'
    test_field = OneOf([Boolean()])
    assert test_field.validate(True) == True


# Generated at 2022-06-24 10:44:40.561844
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Setup
    field = NeverMatch()

    # Exercise
    with pytest.raises(field.validation_error) as exinfo:
        field.validate(None)

    assert exinfo.value.code == "never"



# Generated at 2022-06-24 10:44:43.126627
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf


# Generated at 2022-06-24 10:44:57.894108
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    def fonction(x,y):
        ifThenElse = IfThenElse(x, then_clause=y)
        return ifThenElse
        
    assert (fonction(schema.Number, schema.Integer) == IfThenElse(schema.Number, then_clause=schema.Integer))
    assert (fonction(schema.Any, schema.Any) == IfThenElse(schema.Any, then_clause=schema.Any))
    assert (fonction(schema.Bool, schema.Bool) == IfThenElse(schema.Bool, then_clause=schema.Bool))
    assert (fonction(schema.String, schema.String) == IfThenElse(schema.String, then_clause=schema.String))


# Generated at 2022-06-24 10:45:01.233783
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class TestOneOf(OneOf):
        def __init__(self, one_of, **kwargs):
            OneOf.__init__(self,one_of,**kwargs)

        def validate(self,value,strict=False):
            return 'true'

    TestOneOf([String()],format='test')

# Generated at 2022-06-24 10:45:01.720305
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-24 10:45:04.745241
# Unit test for constructor of class OneOf
def test_OneOf():
    """
    Test that constructor of class OneOf is working correctly
    """
    assert OneOf([Field()]) is not None


# Generated at 2022-06-24 10:45:13.320921
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import jsonschema
    import json

    # Given
    field = AllOf([Field(coerce=int)], name="AllOf_test")
    val1 = json.dumps('10') # Correct
    val2 = json.dumps('20') # Correct
    val3 = json.dumps('30') # Correct

    # When
    result1 = field.validate(val1, strict=True)
    result2 = field.validate(val2, strict=True)
    result3 = field.validate(val3, strict=True)

    # Then
    assert result1 == '10'
    assert result2 == '20'
    assert result3 == '30'


# Generated at 2022-06-24 10:45:17.676189
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(
                String(max_length=10),
                String(max_length=12),
                String(max_length=14)
            )

# Generated at 2022-06-24 10:45:18.628135
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer, String
    field = OneOf([Integer(), String()])

# Generated at 2022-06-24 10:45:22.202035
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(Field(type='text'))
    not_.validate('something')
    not_.validate(None)
    try:
        not_.validate(1)
    except Exception as e:
        print(e)



# Generated at 2022-06-24 10:45:25.609532
# Unit test for method validate of class Not
def test_Not_validate():

    test_not = Not(negated=Any())

    # Test that, if input is matched by negated type, Not.validate raises an exception
    try:
        test_not.validate(value="a_string")
    except test_not.ValidationError as e:
        assert e.code == "negated"

    # Test that, if input is not matched by negated type, Not.validate returns the input
    assert test_not.validate(value=1) == 1



# Generated at 2022-06-24 10:45:28.324775
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    data = "hello"
    field = NeverMatch()
    with pytest.raises(ValidationError) as e_info:
        field.validate(data)
    assert e_info.value.code == "never"


# Generated at 2022-06-24 10:45:29.412098
# Unit test for constructor of class OneOf
def test_OneOf():
    assert isinstance(OneOf([]), object)

# Generated at 2022-06-24 10:45:31.334760
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(None) == None


# Generated at 2022-06-24 10:45:33.440165
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field
    assert field.all_of == []


# Generated at 2022-06-24 10:45:36.824503
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    my_IfThenElse = IfThenElse(0,0,0)
    assert my_IfThenElse.if_clause == 0
    assert my_IfThenElse.then_clause == 0
    assert my_IfThenElse.else_clause == 0

# Generated at 2022-06-24 10:45:47.015870
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer, PrimitiveType

    # Test when match_count is equal to 1
    one_of = [Integer(), PrimitiveType()]
    one_of_field = OneOf(one_of)
    assert one_of_field.validate(5, False) == 5

    # Test when match_count is greater than 1
    with pytest.raises(one_of_field.validation_error) as error:
        one_of_field.validate(5.0, False)

    # Test when match_count is equal to 0
    with pytest.raises(one_of_field.validation_error) as error:
        one_of_field.validate("hello", False)



# Generated at 2022-06-24 10:45:48.888010
# Unit test for method validate of class Not
def test_Not_validate():
    test = Not(Any())
    with pytest.raises(test.validation_errors["negated"]):
        assert test.validate(1)

# Generated at 2022-06-24 10:45:55.980430
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate('F') == 'F'
    assert NeverMatch().validate(object()) == object()
    assert NeverMatch().validate('F',strict=True) == 'F'
    assert NeverMatch().validate(object(),strict=True) == object()
    assert NeverMatch().serialize('F') == 'F'
    assert NeverMatch().serialize(object()) == object()
    assert NeverMatch().serialize('F',strict=True) == 'F'
    assert NeverMatch().serialize(object(),strict=True) == object()


# Generated at 2022-06-24 10:45:59.885490
# Unit test for constructor of class OneOf
def test_OneOf():

    assert OneOf(one_of = [Any()]).one_of == [Any()]

# Unit tests for function __init__ of class OneOf

# Generated at 2022-06-24 10:46:02.132889
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(all_of=[Any()])
    assert all_of.all_of == [Any()]


# Generated at 2022-06-24 10:46:02.874601
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-24 10:46:03.803762
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()


# Generated at 2022-06-24 10:46:04.725490
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__init__

# Generated at 2022-06-24 10:46:05.937186
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # TODO: implement
    assert False # implement your test here


# Generated at 2022-06-24 10:46:11.989141
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([String(), Number()])
    assert field.validate("hello")
    assert field.validate(1)
    with pytest.raises(TypeSystemError):
        field.validate(1, True)
    # test null
    assert field.validate(None)
    assert field.validate(None, True)


# Generated at 2022-06-24 10:46:14.752405
# Unit test for constructor of class Not
def test_Not():
    try:
        Not(negated='yolo')
    except:
        print("Not did not work")


# Generated at 2022-06-24 10:46:21.638429
# Unit test for constructor of class OneOf
def test_OneOf():
    """
    Test for valid data
    """
    try:
        value = OneOf([1,2,3])
        assert value.one_of == [1,2,3]
        assert value.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
        assert value.allow_casts == False
    except Exception as error:
        print(error)
        assert False


# Generated at 2022-06-24 10:46:33.562466
# Unit test for constructor of class Not
def test_Not():
    a = 'Not'
    b = 'Field'
    c = False
    negated = 'negated'
    negated_ = 'negated'
    errors = {negated: 'Must not match.'}
    errors_ = {negated: 'Must not match.'}
    f_schema = "test"
    f_schema_ = "test"
    f_full_clean = "test"
    f_full_clean_ = "test"
    f_description = "test"
    f_description_ = "test"
    f_allow_null = "test"
    f_allow_null_ = "test"
    f_allow_blank = "test"
    f_allow_blank_ = "test"
    f_default = "test"
    f_default_ = "test"
    f_extra

# Generated at 2022-06-24 10:46:42.032355
# Unit test for constructor of class AllOf
def test_AllOf():
    import json
    import sys
    import os

    sys.path.append(os.path.dirname(
        os.path.dirname(os.path.abspath(__file__))))

    from typesystem.fields import Integer, String

    field = AllOf([Integer(), String()])

    # unit test 1
    input_value = "hello"
    assert field.validate(input_value) == input_value

    # unit test 2
    input_value = 102
    assert field.validate(input_value) == input_value


# Generated at 2022-06-24 10:46:48.126627
# Unit test for method validate of class AllOf
def test_AllOf_validate():

    class Mock(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    a = Mock()
    b = Mock()
    c = Mock()
    all1 = AllOf([a, b, c])
    all2 = AllOf([a])
    all1.validate(1)
    all2.validate(1)

# Generated at 2022-06-24 10:46:51.226477
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([Bool(), Str()]).validate(True)
    assert AllOf([Bool(), Str()]).validate("True")
    try:
        assert AllOf([Bool(), Str()]).validate(1)
    except Exception as e:
        assert str(e) == 'Must be str.'


# Generated at 2022-06-24 10:46:51.810863
# Unit test for constructor of class OneOf
def test_OneOf():
    pas

# Generated at 2022-06-24 10:46:55.529624
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field=IfThenElse(IfThenElse(None, None, None, name='if'), IfThenElse(None, None, None, name='then'), IfThenElse(None, None, None, name='else'), name='if-then-else')
    assert field.if_clause.name == 'if'
    assert field.then_clause.name == 'then'
    assert field.else_clause.name == 'else'
    assert field.name == 'if-then-else'

# Generated at 2022-06-24 10:46:56.123216
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-24 10:46:57.716659
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=IfThenElse(if_clause=Any()))

# Generated at 2022-06-24 10:46:58.937382
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    value = None
    field = NeverMatch()
    strict = True
    assert field.validate(value, strict) is None


# Generated at 2022-06-24 10:47:01.102230
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()]).one_of[0].__class__ is Any


# Generated at 2022-06-24 10:47:03.797481
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test OneOf instance creation with wrong parameters
    with pytest.raises(AssertionError) as error:
        OneOf('wrong_param')


# Generated at 2022-06-24 10:47:05.459745
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all = AllOf([String(), String()])
    all.validate("test")


# Generated at 2022-06-24 10:47:08.913449
# Unit test for method validate of class Not
def test_Not_validate():
    class Integer(typesystem.Integer):
        pass
    
    integer = Integer()
    negated = Not(negated=integer)
    value = "1"
    strict = False
    assert negated.validate(value, strict) == value
    

# Generated at 2022-06-24 10:47:13.027392
# Unit test for method validate of class Not
def test_Not_validate():
    print(Not)

    field = Not(negated=Boolean())

    try:
        field.validate(value=2)
    except ValidationError:
        assert True
    else:
        assert False




# Generated at 2022-06-24 10:47:20.473127
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # public method validate(self, value: typing.Any, strict: bool = False) -> typing.Any
    # Mock object for testing
    class MockAllOf(AllOf):
        def __init__(self, *args, **kwargs):
            super().__init__(self, *args, **kwargs)
            self.all_of = []

    # Basic test
    all_of_test = MockAllOf()
    value_test = 10
    bool_value_test = True
    # Run
    res_test = all_of_test.validate(value_test, bool_value_test)
    # Assertion
    assert res_test is value_test


# Generated at 2022-06-24 10:47:22.834512
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f1 = NeverMatch()
    assert f1.validate(1) == f1.errors['never']


# Generated at 2022-06-24 10:47:32.060172
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IntegerField(Field):
        def __init__(self) -> None:
            super().__init__()
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return 5
        def serialize(self, value: typing.Any) -> typing.Any:
            return 5

    class StringField(Field):
        def __init__(self) -> None:
            super().__init__()
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return "5"
        def serialize(self, value: typing.Any) -> typing.Any:
            return "5"

    if_clause = IntegerField()
    then_clause = IntegerField()
    else_clause = StringField()


# Generated at 2022-06-24 10:47:36.761392
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Field())

    value = "any"

    assert not_field.validate(value) == value
    with pytest.raises(Field.ValidationError):
        not_field.validate("")

# Generated at 2022-06-24 10:47:39.724823
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    my_field = OneOf([])
    my_field.validate(1)

# Generated at 2022-06-24 10:47:45.553828
# Unit test for method validate of class Not
def test_Not_validate():
    dummy_field = Field()
    dummy_field.errors = {"some_error": "error"}
    test_field = Not(dummy_field)
    assert test_field.validate(10) == 10
    try:
        test_field.validate(10.1)
        assert False, "Should not get here"
    except Field.ValidationError as e:
        assert e.code == "negated"
        assert e.value == 10.1


# Generated at 2022-06-24 10:47:52.348774
# Unit test for method validate of class OneOf
def test_OneOf_validate():
  oneOf = OneOf(None)
  oneOf.validate(None)

test_OneOf_validate()

# Generated at 2022-06-24 10:48:02.577912
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class A(Field):
        errors = {"validation_error_name": "validation_error_message"}
        def validate(self, value, strict=False): return value
    a = A()
    a1 = A()
    a2 = A()

    # Case 1
    x = AllOf([a1, a2], required=True)
    assert x.validate([1, 2]) == [1, 2]
    assert x.validate("") == ""
    assert x.validate(1) == 1

    # Case 2
    x = AllOf([a1, a2])
    assert x.validate("") == ""
    assert x.validate("test") == "test"
    #assert x.validate(None) == None
    
    # Case 3
    x = AllOf([a1])
   

# Generated at 2022-06-24 10:48:07.767757
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field1 = Field(name="field1", required=False)
    field2 = Field(name="field2", required=False)
    field3 = Field(name="field3", required=False)
    assert IfThenElse(field1, field2, field3)

# Generated at 2022-06-24 10:48:13.709615
# Unit test for constructor of class OneOf
def test_OneOf():
    test=Field()
    assert test.validate(None, strict=False) == None



# Generated at 2022-06-24 10:48:18.997258
# Unit test for constructor of class Not
def test_Not():
    not_=Not(None, default=None, choices=None, description="", name="", required=False)
    print(not_)
    try:
            not_.validate(1)  # because Not(Integer())
    except:
            print('Exception')

# Generated at 2022-06-24 10:48:21.592495
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(None)
    value = field.validate(3)

    assert value == 3

# Generated at 2022-06-24 10:48:25.440262
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    if_clause = String()
    then_clause = String()
    else_clause = String()
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-24 10:48:30.691385
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:48:32.911976
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    test_field = NeverMatch()
    with pytest.raises(test_field.validation_error):
        test_field.validate('anything')