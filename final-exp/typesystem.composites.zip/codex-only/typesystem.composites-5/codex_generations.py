

# Generated at 2022-06-24 10:38:38.673518
# Unit test for constructor of class AllOf
def test_AllOf():
    list = [1, 2, 3, 4]
    all_of = AllOf(all_of=list)
    assert type(all_of) == AllOf


# Generated at 2022-06-24 10:38:39.585721
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  a = NeverMatch()
  assert a


# Generated at 2022-06-24 10:38:42.253633
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    error = field.validate(1)
    assert field.validation_error("never") == error



# Generated at 2022-06-24 10:38:46.257986
# Unit test for method validate of class Not
def test_Not_validate():
    err = "Must not match."
    obj = Not(String())
    
    assert obj.validate(None) == None
    assert obj.validate('hello') == 'hello'
    try:
        obj.validate(1)
    except ValidationError as ve:
        assert ve.messages == err

# Generated at 2022-06-24 10:38:47.555155
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field


# Generated at 2022-06-24 10:38:49.319961
# Unit test for constructor of class AllOf
def test_AllOf():
    with pytest.raises(AssertionError):
        af = AllOf([], allow_null=True)


# Generated at 2022-06-24 10:38:54.976368
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import json
    import typesystem
    schema = typesystem.Schema(
        properties={
            "foo": typesystem.OneOf(
                one_of=[
                    typesystem.Boolean(),
                    typesystem.Integer(),
                    typesystem.Floating(),
                ]
            ),
            "bar": typesystem.OneOf(
                one_of=[
                    typesystem.Boolean(),
                    typesystem.String(),
                    typesystem.Array(),
                ]
            ),
        }
    )
    data = json.dumps({"foo": 1, "bar": "foo"})
    result = schema.validate(data)
    assert result["foo"] == 1 and result["bar"] == "foo"

# Generated at 2022-06-24 10:38:57.019808
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:39:03.848255
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(
        all_of=[
            String(min_length=5, max_length=5),
            String(min_length=6, max_length=6),
            String(min_length=7, max_length=7),
        ]
    )
    with pytest.raises(ValueError) as e:
        field.validate("foobar")
    assert e.value.args[0] == "String is too short (minimum is 5 characters)."
    
    

# Generated at 2022-06-24 10:39:06.972746
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(field2)
    field.validate(1)
    field.validate('a')
    try:
        field.validate(0)
    except ValidationError:
        pass
    else:
        assert False


# Generated at 2022-06-24 10:39:07.728393
# Unit test for constructor of class OneOf
def test_OneOf():
	assert OneOf([Any()])


# Generated at 2022-06-24 10:39:13.452115
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Type, Array, Integer, String
    schema = Type(
        properties = {
            'foo': AllOf([Integer(), String()])
        }
    )
    # Test case 1: TypeError expection should be thrown
    try:
        schema.validate({'foo': True})
    except TypeError as err:
        assert str(err) == 'Property "foo" has error: "Must be type integer or string"'
    # Test case 2: TypeError expection should be thrown
    try:
        schema.validate({'foo': 'bar'})
    except TypeError as err:
        assert str(err) == 'Property "foo" has error: "Must be type integer or string"'
    # Test case 3: no exception
    schema.validate({'foo': 1})

# Generated at 2022-06-24 10:39:19.261855
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem.validators as validators
    from typesystem.fields import Integer
    from typesystem.types import String
    
    class IfThenElseTest(IfThenElse):
        def __init__(self):
            super().__init__(
                if_clause=String(
                    min_length=10, 
                    validators=[
                        validators.EqualsValidator(value="Terminator")
                    ]
                ),
                then_clause=Integer(
                    min_value=5,
                    max_value=25
                ),
                else_clause=Integer(
                    min_value=-10,
                    max_value=10
                )
            )

    if_then_else = IfThenElseTest()
    assert if_then_else.validate("Terminator", strict=True) == 5
    assert if_

# Generated at 2022-06-24 10:39:20.406796
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated


# Generated at 2022-06-24 10:39:22.014171
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("Juan") == "Juan"

# Generated at 2022-06-24 10:39:25.116233
# Unit test for method validate of class OneOf
def test_OneOf_validate():
  field = typesystem.fields.OneOf([typesystem.fields.Integer, typesystem.fields.Any])
  assert field.validate(10) == 10, f"{field.validate(10)} should be 10"



# Generated at 2022-06-24 10:39:29.531273
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=None, then_clause=None, else_clause=None)
    assert field.if_clause is None
    assert field.then_clause is None
    assert field.else_clause is None


# Generated at 2022-06-24 10:39:31.784921
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:39:33.201510
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:39:36.091347
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    obj = Field()
    obj2 = Field()
    if_then_else_obj = IfThenElse(obj, else_clause=obj2)
    assert isinstance(if_then_else_obj, Field)

# Generated at 2022-06-24 10:39:41.349859
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field1 = Field()
    field2 = Field()
    field3 = Field()
    test_field = IfThenElse(field1, field2, field3)
    assert test_field.if_clause == field1
    assert test_field.then_clause == field2
    assert test_field.else_clause == field3
    assert test_field.allow_null == False
    assert test_field.context == None
    assert test_field.error_messages == None

# Generated at 2022-06-24 10:39:43.466736
# Unit test for method validate of class Not
def test_Not_validate():
    not_number = Not(Integer(minimum=5))
    value = 1
    try:
        not_number.validate(value)
        assert True
    except:
        assert False

# Generated at 2022-06-24 10:39:50.061657
# Unit test for constructor of class OneOf
def test_OneOf():
    # Invalid type of value
    field = OneOf([Any()], description="Some description")
    assert field.one_of[0] is not None

    # List is empty
    field = OneOf([])
    assert field.one_of is None

    # Success
    field = OneOf([Any(), Any()])
    assert field.one_of is not None



# Generated at 2022-06-24 10:39:53.820760
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = [True,123,False]
    field = AllOf(all_of)
    value = 1234
    assert field.validate(value) == value
    assert field.validate(value) != all_of
    
###


# Generated at 2022-06-24 10:40:05.201204
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    with pytest.raises(TypeSystemError):
        AllOf([Any(), Any()]).validate(1)

    a = Field()
    b = Field()
    c = AllOf([a, b])
    assert c.validate(c) == c
    a.errors = {"a": "fail"}
    with pytest.raises(TypeSystemError):
        c.validate(c)

    with pytest.raises(TypeSystemError):
        Not(Any()).validate(1)

    a = Field(primitive_type=int)
    b = Field(primitive_type=str)

    c = IfThenElse(
        a,
        then_clause=AllOf([a, b]),
    )
    assert c.validate(1) == 1

# Generated at 2022-06-24 10:40:15.061781
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.types import String
    from typesystem.errors import ValidationError
    from typesystem.fields import Array
    
    class AllOfTest(Array): 
        def __init__(self):
            self.all_of = [String(), String()]
            super().__init__(items=self.all_of[0])
    
    all_of = AllOfTest()
    
    assert all_of.validate(["Foo", "Bar"]) == ["Foo", "Bar"]
    assert all_of.validate(["Foo", "Bar", "Baz"]) == ["Foo", "Bar", "Baz"]
    with pytest.raises(ValidationError) as excinfo:
        all_of.validate(["Foo", None])

# Generated at 2022-06-24 10:40:20.490889
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create a new instance of OneOf
    field = OneOf([String()])

    # Set up a variable to hold the class type. This is used
    # in the unit test to validate the type of the variable
    # being returned by the method validate of class OneOf
    field_type = field.__class__

    # Call method validate of class OneOf
    result = field.validate("string")

    # Check that the method returns data of expected type
    assert (type(result) == str)



# Generated at 2022-06-24 10:40:21.851987
# Unit test for constructor of class Not
def test_Not():
    field = Not(1)
    assert field.negated == 1

# Generated at 2022-06-24 10:40:31.079038
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field(default_factory=int, nullable=False)
    then_clause = Field(default_factory=str, nullable=False)
    else_clause = Field(default_factory=str, nullable=False)
    ifelse = IfThenElse(if_clause, then_clause, else_clause)
    assert ifelse.validate(1) == '1'
    assert ifelse.validate(2) == '2'
    assert ifelse.validate(1, strict=True) == '1'
    assert ifelse.validate(2, strict=True) == '2'
    default = Field(default_factory=int, nullable=False)

# Generated at 2022-06-24 10:40:32.833474
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass


# Generated at 2022-06-24 10:40:39.885556
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Array, Integer, Integer

    integer_list = Array(items = Integer())

    assert integer_list.validate([1, 2, 3]) == [1, 2, 3]
    assert AllOf(all_of = [Array(), Integer()]).validate([1, 2, 2, 4]) == [1, 2, 2, 4]
    assert AllOf(all_of = [Array(), Integer()]).validate([1, 2, 2, 4]) == [1, 2, 2, 4]

# Generated at 2022-06-24 10:40:42.469250
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with pytest.raises(AssertionError):
        field = NeverMatch(allow_null=True)



# Generated at 2022-06-24 10:40:50.700377
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import pytest
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])

    assert field.validate(123) == 123
    assert field.validate("abc") == "abc"

    with pytest.raises(NotImplementedError):
        field.validate(None)
    with pytest.raises(NotImplementedError):
        field.validate(True)
    with pytest.raises(NotImplementedError):
        field.validate(1.234)
    with pytest.raises(NotImplementedError):
        field.validate({})
    with pytest.raises(NotImplementedError):
        field.validate([])



# Generated at 2022-06-24 10:40:54.385194
# Unit test for method validate of class Not
def test_Not_validate():
    integer = Integer(10)

    try:
        integer.validate(5)
        assert False
    except ValidationError:
        assert True

    try:
        Not(integer).validate(5)
        assert True
    except ValidationError:
        assert False


# Generated at 2022-06-24 10:40:59.216951
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from json import loads
    from unittest.mock import MagicMock
    from typesystem import Integer

    item = MagicMock(spec=OneOf)
    item.one_of = [Integer()]
    converted = item.validate(loads('"foo"'))
    assert converted == 'foo'

# Generated at 2022-06-24 10:41:03.995171
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Test if the error message of method validate of class NeverMatch is correct
    try:
        NeverMatch().validate(1)
    except Exception as exc:
        assert str(exc) == "Did not match type 'never'"
    # Test if the value of method validate of class NeverMatch is correct
    assert NeverMatch().validate(1) is None

# Generated at 2022-06-24 10:41:06.454247
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    myList = []
    myList.append(None)
    myField = OneOf(one_of=myList)
    myField.validate(None, False)

# Generated at 2022-06-24 10:41:08.516579
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = OneOf([])
    value = "test"
    assert a.validate(value) == value


# Generated at 2022-06-24 10:41:14.882476
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf(one_of=[String()]).__name__ == 'OneOf'
    assert OneOf(one_of=[Object(), String()]).__name__ == 'OneOf object, string'
    assert OneOf(one_of=[Object(), String()]).validate('abc') == 'abc'
    assert OneOf(one_of=[Object(), String()]).validate(123) == 123
    assert OneOf(one_of=[Object(), String()]).validate(False) == False
    assert OneOf(one_of=[Object(), String()]).validate(None) == None
    assert OneOf(one_of=[Object(), String()]).validate([]) == []
    assert OneOf(one_of=[Object(), String()]).validate({}) == {}

# Generated at 2022-06-24 10:41:17.117923
# Unit test for constructor of class Not
def test_Not():
  item = Not(AllOf([]))


# Generated at 2022-06-24 10:41:18.074139
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])



# Generated at 2022-06-24 10:41:20.035943
# Unit test for constructor of class Not
def test_Not():
    a = Not(' ')
    assert a.negated == ' '
    return None


# Generated at 2022-06-24 10:41:21.820322
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = String()
    then_clause = String()
    else_clause = String()
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-24 10:41:29.249133
# Unit test for method validate of class Not
def test_Not_validate():
    # Test Not field with matching validation
    f = Not(Field(validators=[lambda v: True]))
    v, e = f.validate_or_error(value="x")
    if e:
        print("test_Not_validate failed")
        sys.exit(1)
    # Test Not field with non-matching validation
    f = Not(Field(validators=[lambda v: False]))
    v, e = f.validate_or_error(value="x")
    if not e:
        print("test_Not_validate failed")
        sys.exit(1)
    sys.exit(0)



# Generated at 2022-06-24 10:41:31.046517
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([1, 2])
    assert all_of.all_of == [1, 2]


# Generated at 2022-06-24 10:41:35.278603
# Unit test for constructor of class AllOf
def test_AllOf():
    import typing
    field = Field()
    all_of = []
    all_of.append(field)
    all_of.append(field)
    all_of.append(field)
    field = AllOf(all_of)



# Generated at 2022-06-24 10:41:38.485065
# Unit test for method validate of class Not
def test_Not_validate():
    x = Not(negated=String())
    try:
        x.validate("")
    except ValueError:
        y = 1
    assert y == 1


# Generated at 2022-06-24 10:41:41.117010
# Unit test for constructor of class AllOf
def test_AllOf():
        # field_allof = AllOf([])
        # field_allof = AllOf(all_of=['1'])
        assert True

# Generated at 2022-06-24 10:41:45.204012
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    val = ['a',1]
    all_of = [Field(type="string"),Field(type="integer")]
    field_object=AllOf(all_of)
    field_object.validate(val)
    

# Generated at 2022-06-24 10:41:51.841204
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    clause1 = IntegerField()
    clause2 = StringField()
    clause3 = IntegerField()
    ifThenElse1 = IfThenElse(clause1,clause2)
    ifThenElse2 = IfThenElse(clause1,clause2,clause3)
    assert(ifThenElse1.if_clause==clause1)
    assert(ifThenElse1.then_clause==clause2)
    assert(ifThenElse2.else_clause==clause3)
    assert(isinstance(ifThenElse1.else_clause, Any))
    assert(isinstance(ifThenElse2.then_clause, StringField))


# Generated at 2022-06-24 10:41:54.612797
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.throwaway import int_
    from typesystem.throwaway import str_
    foo = AllOf([
        int_,
        str_
    ])
    foo.validate("hello")
    foo.validate(1)


# Generated at 2022-06-24 10:41:55.546574
# Unit test for constructor of class OneOf
def test_OneOf():
    oneOf = OneOf([])


# Generated at 2022-06-24 10:41:58.165985
# Unit test for constructor of class Not
def test_Not():
    any = Any()
    n = Not(any)
    assert isinstance(n, Not)
    assert n.negated == any
    assert n.errors == {"negated": "Must not match."}


# Generated at 2022-06-24 10:41:59.771244
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf.__init__

# Generated at 2022-06-24 10:42:01.440657
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:42:02.030988
# Unit test for constructor of class Not
def test_Not():
    Not(1)

# Generated at 2022-06-24 10:42:06.754484
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf(one_of=[String()]).validate("abc") == "abc"
    with pytest.raises(Invalid):
        OneOf(one_of=[String()]).validate(1)

    with pytest.raises(Invalid):
        OneOf(one_of=[String(), Integer()]).validate("abc", strict=True)
        

# Generated at 2022-06-24 10:42:13.322128
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=None)
    assert isinstance(field, Field)
    assert field.negated is None
    assert field.errors == {"negated": "Must not match."}
    assert field.additional_properties is False
    assert field.format is None
    assert field.regex is None
    assert field.types == {}


# Generated at 2022-06-24 10:42:16.054103
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=Any(), then_clause=Any())
    assert field.if_clause is not None
    assert field.then_clause is not None
    assert field.else_clause is not None

# Generated at 2022-06-24 10:42:21.987756
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import pytest
    from typesystem import Schema
    data={}
    data['Nevermatch']='never'
    field = NeverMatch(name='NeverMatch')
    schema = Schema(field=field)
    with pytest.raises(schema.ValidationError):
        schema.validate(data)

# Generated at 2022-06-24 10:42:27.623811
# Unit test for constructor of class Not
def test_Not():
    # ignore unused import warning
    import typesystem
    # test a successful run
    my_not = Not(negated=typesystem.String(max_length=10))
    assert my_not.validate("This is a string") == "This is a string"
    try:
        my_not.validate("This is a very long string")
        assert False
    except BaseException as e:
        assert str(e) == "Must not match."


# Generated at 2022-06-24 10:42:28.153725
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-24 10:42:29.370095
# Unit test for constructor of class Not
def test_Not():
    notField = Not(Field())
    assert notField.negated == Field()


# Generated at 2022-06-24 10:42:31.393784
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf(all_of=[Int(minimum=0,maximum=10)])
    assert(all_of.validate(2) == 2)


# Generated at 2022-06-24 10:42:32.284905
# Unit test for constructor of class Not
def test_Not():
    s = Not(None)
    assert s.negated == None

# Generated at 2022-06-24 10:42:40.410424
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import typesystem
    a = typesystem.Any()
    b = typesystem.Any()
    c = typesystem.IfThenElse(a, b)
    d = typesystem.IfThenElse(a, then_clause=b)
    assert c.if_clause is a
    assert c.then_clause is b
    assert c.else_clause is Any()
    assert d.if_clause is a
    assert d.then_clause is b
    assert d.else_clause is Any()



# Generated at 2022-06-24 10:42:41.408196
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)


# Generated at 2022-06-24 10:42:50.218833
# Unit test for constructor of class OneOf
def test_OneOf():
    f1 = Field(description="The first field.")
    f2 = Field(description="The second field.")
    oneOf = OneOf([f1, f2], description="The OneOf field.")
    assert isinstance(oneOf, Field)
    assert oneOf.description == "The OneOf field."
    assert oneOf.one_of == [f1, f2]
    assert oneOf.errors == {
        "no_match": "Did not match any valid type.",
        "multiple_matches": "Matched more than one type.",
    }


# Generated at 2022-06-24 10:42:52.789660
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_value = "test"
    t = OneOf(one_of=[Any(), Any()])
    with pytest.raises(Exception):
        if t.validate(test_value):
            pass

# Generated at 2022-06-24 10:43:03.120518
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import String

    class AllOf(Field):
        """
        Must match all of the sub-items.

        You should instead consolidate into a single type, or use
        schema inheritence instead of this.
        """

        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.all_of = all_of

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            for child in self.all_of:
                child.validate(value, strict=strict)
            return value
    input1 = "hello"
    input2 = 10
    input3 = [1,2,3]


# Generated at 2022-06-24 10:43:07.335483
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Field()], label="OneOf")
    assert field.validate(1) == 1
    assert field.validate(1.5) == 1.5



# Generated at 2022-06-24 10:43:11.996347
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Schema

    schema = Schema(fields={"field": Not(negated=int)})
    assert schema.load({"field": 1}) == {"field": 1}
    assert schema.load({"field": "1"}) == {"field": "1"}



# Generated at 2022-06-24 10:43:15.342726
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x.errors["never"] == "This never validates."
    assert x.allow_null == False
    assert x.description == ""
    assert x.title == ""


# Generated at 2022-06-24 10:43:17.984949
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[])
    value = []
    field.validate(value, strict=False)



# Generated at 2022-06-24 10:43:20.930337
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        Not(Any(), allow_null=False)

    not_any = Not(Any())
    assert not_any.negated == Any()

    not_any = Not(Any(required=True))
    assert not_any.negated == Any(required=True)

# Generated at 2022-06-24 10:43:22.449250
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([None])
    assert one_of.one_of == [None]

# Generated at 2022-06-24 10:43:33.041270
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Test case 1
    #   test_value = 1 
    #   strict = False
    #   expect_output = {'type_': 'integer', 'extended_properties': {'minimum': 1, 'maximum': 100}, 'required': True}
    #   expected_output = {'type_': 'integer', 'extended_properties': {'minimum': 1, 'maximum': 100}, 'required': True}
    test_value = 1
    strict = False
    expect_output = {'type_': 'integer', 'extended_properties': {'minimum': 1, 'maximum': 100}, 'required': True}

# Generated at 2022-06-24 10:43:35.338240
# Unit test for constructor of class OneOf
def test_OneOf():
    with pytest.raises(AssertionError):
        OneOf(one_of=[], allow_null=False)


# Generated at 2022-06-24 10:43:38.410397
# Unit test for constructor of class NeverMatch
def test_NeverMatch():

    # calling the constructor
    expected = NeverMatch(label="NeverMatch_test")

    # asserting the error messages
    assert expected.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:43:39.589561
# Unit test for constructor of class Not
def test_Not():
    f = Not()
    assert f.negated == ()


# Generated at 2022-06-24 10:43:40.395353
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-24 10:43:44.673308
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    with pytest.raises(ValidationError):
        nm.validate(1)


# Generated at 2022-06-24 10:43:49.521507
# Unit test for method validate of class Not
def test_Not_validate():
    my_Not = Not(
        negated = {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
            },
        }
)
    assert my_Not.validate({'name': 'test'}) == {'name': 'test'}
    raise ValueError("Not raise expected ValueError")



# Generated at 2022-06-24 10:43:50.562588
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(True) == False

# Generated at 2022-06-24 10:44:00.371432
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import AllOf
    from typesystem.fields import Any
    from typesystem.fields import Boolean
    from typesystem.fields import Integer
    from typesystem.fields import String

    # test_AllOf_OneOf_validate_success
    field = AllOf([Any(), Any()])
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None

    # test_AllOf_OneOf_validate_failure
    field = AllOf([Any(), Integer()])
    with raises(Exception):
        assert field.validate(True) == True
    with raises(Exception):
        assert field.validate(False) == False
    with raises(Exception):
        assert field.validate(None) == None

# Generated at 2022-06-24 10:44:08.082447
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import IntegerField
    field = AllOf([IntegerField(minimum=1), IntegerField(maximum=100)])
    field.validate(50)


# Generated at 2022-06-24 10:44:11.924872
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert(OneOf([Field(int),Field(str)]).validate(2) == 2)
    assert(OneOf([Field(int),Field(str)]).validate("abc") == "abc")
    try:
        OneOf([Field(int),Field(str)]).validate(2.5)
    except:
        pass
    try:
        OneOf([Field(int),Field(str)]).validate(['a','b'])
    except:
        pass
        

# Generated at 2022-06-24 10:44:14.708898
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=AllOf(all_of=[Any()]))
    assert field.validate("Hello") == "Hello"


# Generated at 2022-06-24 10:44:20.476727
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
  n_match = NeverMatch()

  # Check the expected behavior when the input value is None
  with pytest.raises(ValidationError) as exc:
    n_match.validate(None)
  assert "never" == exc.value.code

  # Check the expected behavior when the input value is not None
  with pytest.raises(ValidationError) as exc:
    n_match.validate(1)
  assert "never" == exc.value.code


# Generated at 2022-06-24 10:44:23.034327
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_OneOf = OneOf(["field1", "field2"])
    test_OneOf.validate("*")


# Generated at 2022-06-24 10:44:28.505178
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_else = IfThenElse(Any())
    assert if_else.validate("abc") == "abc"
    if_then = IfThenElse(Any(), Any())
    assert if_then.validate("abc") == "abc"
    if_then_else = IfThenElse(Any(), Any(), Any())
    assert if_then_else.validate("abc") == "abc"

# Generated at 2022-06-24 10:44:29.453718
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of = [Any])
    assert field.validate(123) == 123


# Generated at 2022-06-24 10:44:34.175172
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String

    class IfThenElse_test_inst(IfThenElse):
        pass

    test_obj = IfThenElse_test_inst(
        String(), String(max_length=10), String(max_length=20)
    )
    assert len(test_obj.if_clause.errors) == 2
    assert len(test_obj.then_clause.errors) == 4
    assert len(test_obj.else_clause.errors) == 4

# Generated at 2022-06-24 10:44:35.979039
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=None)
    assert field.negated is not None

# Generated at 2022-06-24 10:44:39.412733
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # arrange
    field = OneOf(one_of=[OneOf(one_of=[Field()]), Field()])

    # act
    res = field.validate("string")
    
    # assert
    assert res == "string"

# Generated at 2022-06-24 10:44:44.738313
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch(allow_null=True)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-24 10:44:49.855180
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause=Field()
    else_clause=Field()
    a=IfThenElse(if_clause, then_clause, else_clause, description='test')
    assert(a.if_clause==if_clause)
    assert(a.then_clause==then_clause)
    assert(a.else_clause==else_clause)
    assert(a.description=='test')

# Generated at 2022-06-24 10:44:55.751435
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
   field1 = Field(int)
   field2 = Field(str)
   field3 = Field(list)
   ifthenelse = IfThenElse(field1,field2,field3)
   assert ifthenelse.if_clause is field1
   assert ifthenelse.then_clause is field2
   assert ifthenelse.else_clause is field3


# Generated at 2022-06-24 10:44:59.191052
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.types import String
    a = Not(String())
    assert a.validate('x')

    b = Not(String())
    assert not b.validate(1)



# Generated at 2022-06-24 10:45:04.709059
# Unit test for constructor of class AllOf
def test_AllOf():
    # Set up the state before running the test
    all_of = 1
    kwargs = 1 # Default value

    # Run the test
    result = AllOf(all_of, **kwargs)
    # Anything that throws an error, fails the test

    # Compare the expected result to the actual result
    assert result is not None # Placeholder, remove when code is added



# Generated at 2022-06-24 10:45:12.102591
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # test with two fields
    if_then_else = IfThenElse(
        if_clause = None,
        then_clause = Field(["a", "b"], description="List of a and b"),
        else_clause = Field([0, 1], description="List of a and b")
    )

    # test with one field
    if_then_else = IfThenElse(
        if_clause = None,
        then_clause = Field(["a", "b"], description="List of a and b")
    )

    # test with no field
    if_then_else = IfThenElse(
        if_clause = None
    )

# Generated at 2022-06-24 10:45:13.637832
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-24 10:45:19.550067
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    #AllOf([Integer(minimum=1), Integer(maximum=10)])
    a = AllOf([Integer(minimum=1), Integer(maximum=10)])
    assert a.validate(5) == 5
    assert a.validate(5.5) == 5
    assert a.validate(0) == 0
    assert a.validate(11) == 11
    try:
        a.validate("not an integer")
        assert False
    except ValidationError as ex:
        assert False
    try:
        a.validate("not an integer")
        assert True

    except ValidationError as ex:
        assert True


# Generated at 2022-06-24 10:45:25.795927
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    '''
    Test method validate of class NeverMatch
    '''
    field = NeverMatch()
    assert field.validate(1) == None

# Generated at 2022-06-24 10:45:34.729034
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_one_of = OneOf([Boolean()])
    assert field_one_of.validate(True) == True
    assert field_one_of.validate("Foo") == "Foo"
    assert field_one_of.validate("Foo") == "Foo"
    assert field_one_of.validate("Foo") == "Foo"
    assert field_one_of.validate("Foo") == "Foo"
    assert field_one_of.validate("Foo") == "Foo"



# Generated at 2022-06-24 10:45:40.401462
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    with pytest.raises(AssertionError):
        f.validate(1)
        

# Generated at 2022-06-24 10:45:46.138574
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer
    from typesystem.types import ContactName

    try:
        AllOf(all_of=ContactName().all_of)
    except Exception as ex:
        return ex



# Generated at 2022-06-24 10:45:55.979037
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    test method IfThenElse.validate
    """
    # Cases
    print("Cases:")
    # Case if_clause = None, then_clause = None, else_clause = None
    if_clause = None
    then_clause = None
    else_clause = None
    field = IfThenElse(if_clause, then_clause, else_clause)
    value = []
    print("- if_clause = {0}, then_clause = {1}, else_clause = {2}"
            .format(if_clause, then_clause, else_clause))
    assert field.validate(value) == []
    # Case if_clause = None, then_clause = None, else_clause = None
    if_clause = None
    then

# Generated at 2022-06-24 10:46:07.468538
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import pytest
    from typesystem.exceptions import ValidationError

    field = NeverMatch()
    with pytest.raises(ValidationError) as excinfo:
        field.validate(None)
    assert str(excinfo.value) == '{"field": ["This never validates."]}'

    with pytest.raises(ValidationError) as excinfo:
        field.validate("")
    assert str(excinfo.value) == '{"field": ["This never validates."]}'

    with pytest.raises(ValidationError) as excinfo:
        field.validate(1)
    assert str(excinfo.value) == '{"field": ["This never validates."]}'

    with pytest.raises(ValidationError) as excinfo:
        field.validate(True)
    assert str

# Generated at 2022-06-24 10:46:18.981834
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import pytest
    
    class FieldMock():
        def __init__(self, boolVal):
            self.boolVal = boolVal
        def validate(self, value, strict = False):
            if (self.boolVal):
                return 42
            else:
                raise ValueError
    
    class FieldMock2():
        def __init__(self, boolVal):
            self.boolVal = boolVal
        def validate(self, value, strict = False):
            if (not self.boolVal):
                return 42
            else:
                raise ValueError

    ite = IfThenElse(FieldMock(True), FieldMock2(False))
    assert ite.validate(7) == 42

# Generated at 2022-06-24 10:46:19.518529
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
        pass

# Generated at 2022-06-24 10:46:26.493291
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([
        Field(type=float),
        Field(minimum=5)
    ])
    f.validate(10.5)
    with pytest.raises(ValidationError):
        f.validate(3.5)


# Generated at 2022-06-24 10:46:30.973691
# Unit test for constructor of class AllOf
def test_AllOf():
    def test():
        a = Field('a')
        b = Field('b')
        c = Field('c')
        allOf = AllOf([a, b, c])
        return allOf.all_of
    assert test() == [a, b, c]



# Generated at 2022-06-24 10:46:32.826725
# Unit test for constructor of class AllOf
def test_AllOf():
    test_object = AllOf([Field()])
    assert test_object.all_of == [Field()]

# Generated at 2022-06-24 10:46:33.600635
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()


# Generated at 2022-06-24 10:46:38.479139
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    f1 = Field("field1")
    f2 = Field("field2")
    test_case = OneOf([f1,f2])
    expected = "hello"
    actual = test_case.validate("hello")
    assert actual == expected 


# Generated at 2022-06-24 10:46:39.635978
# Unit test for constructor of class Not
def test_Not():
    field = Not(Field())
    assert field is not None

# Generated at 2022-06-24 10:46:43.186827
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """ Unit test for method validate of class OneOf """

    # Arrange
    field = OneOf([Field()])
    value = 0
    strict = True

    # Act
    result = field.validate(value, strict)

    # Assert
    assert result == value


# Generated at 2022-06-24 10:46:46.440500
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never = NeverMatch()
    assert never.errors['never'] == "This never validates."
    assert never.allow_null



# Generated at 2022-06-24 10:46:53.806278
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Case 1:
    #    if_clause: value == 1
    #    then_clause: value == 1
    #    else_clause: value == 2
    if_clause = Equals(1)
    then_clause = Equals(1)
    else_clause = Equals(2)
    value = 1
    assert IfThenElse(if_clause, then_clause, else_clause).validate(value) == value

    # Case 2:
    #   if_clause: value == 0
    #   then_clause: value == 1
    #   else_clause: value == 2
    if_clause = Equals(0)
    then_clause = Equals(1)
    else_clause = Equals(2)
    value = 0
    assert IfThen

# Generated at 2022-06-24 10:46:54.844317
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()


# Generated at 2022-06-24 10:47:04.851913
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    oneOfType = OneOf([])
    strict = False
    # assert that a validation error is raised
    try:
        assert oneOfType.validate(None, strict) is None
    except oneOfType.validation_error as e:
        assert str(e) == 'no_match'
    # assert that a validation error is raised
    try:
        assert oneOfType.validate([''], strict) is None
    except oneOfType.validation_error as e:
        assert str(e) == 'no_match'
    # assert that a validation error is raised
    try:
        assert oneOfType.validate([['']], strict) is None
    except oneOfType.validation_error as e:
        assert str(e) == 'no_match'
    # assert that a validation error is raised
   

# Generated at 2022-06-24 10:47:05.768923
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=4)

# Generated at 2022-06-24 10:47:07.905994
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match.name == 'NeverMatch'
    assert never_match.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:47:09.828546
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    expected = {'never': 'This never validates.'}
    actual = field.validate('hello')
    assert actual == expected



# Generated at 2022-06-24 10:47:10.394338
# Unit test for constructor of class Not
def test_Not():
    assert Not(AllOf)



# Generated at 2022-06-24 10:47:14.495194
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([String(max_length=10), Integer(min_value=0, max_value=10)]).validate(String(max_length=10)).validate(1) == 1


# Generated at 2022-06-24 10:47:20.320394
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(String(), String(), String())
    if field.if_clause is String():
        print("If clause has been created successfully")
    else:
        print("If clause has not been created yet")
    if field.then_clause is String():
        print("Then clause has been created successfully")
    else:
        print("Then clause has not been created yet")
    if field.else_clause is String():
        print("Else clause has been created successfully")
    else:
        print("Else clause has not been created yet")

test_IfThenElse()

# Generated at 2022-06-24 10:47:22.190717
# Unit test for constructor of class Not
def test_Not():
    test = Not(negated = Not(negated = Any()))
    assert test

# Generated at 2022-06-24 10:47:26.201877
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem.error import ValidationError
    error = ValidationError("never")
    field = NeverMatch
    try:
        field.validate("text")
    except Exception as e:
        assert type(e) == type(error)



# Generated at 2022-06-24 10:47:28.221361
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(String(), Integer())
    # for want of a better test.
    assert schema.validate("12", strict=True) == 12

# Generated at 2022-06-24 10:47:35.288430
# Unit test for constructor of class Not
def test_Not():
    not1 = Not(negated=Any())
    assert isinstance(not1, Not)
    assert isinstance(not1.negated, Any)
    assert not1.errors["negated"] == "Must not match."


# Generated at 2022-06-24 10:47:47.115146
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    from typesystem.definitions import IfThenElse as Ite
    from typesystem.exceptions import ValidationError

    ite = Ite(
        if_clause=Integer(),
        then_clause=Integer(),
        else_clause=Integer(),
    )

    value = 1
    ite.validate(value)

    value = 0
    with pytest.raises(ValidationError):
        ite.validate(value)

    ite = Ite(
        if_clause=Integer(),
        then_clause=None,
        else_clause=Integer(),
    )

    try:
        value = 0
        ite.validate(value)
    except ValidationError:
        pytest.fail("Should not raise")

# Generated at 2022-06-24 10:47:55.436610
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = String(max_length=10)
    then_clause = String(min_length=10)
    else_clause = String(max_length=10)
    conditional = IfThenElse(if_clause, then_clause, else_clause)

    assert conditional.validate("12345678910") == "12345678910"
    assert conditional.validate("123") == "123"

    with pytest.raises(ValidationError):
        conditional.validate("1234567891011")
    with pytest.raises(ValidationError):
        conditional.validate(None)

# Generated at 2022-06-24 10:47:57.665553
# Unit test for constructor of class AllOf
def test_AllOf():
    # test initializer
    a = AllOf(all_of=[1,2,3])
    assert(a.all_of == [1,2,3])



# Generated at 2022-06-24 10:47:58.315390
# Unit test for constructor of class Not
def test_Not():
    pass

# Generated at 2022-06-24 10:48:05.118057
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(), Integer())
    field.validate(1)
    try:
        field.validate("test")
    except ValueError:
        pass
    field2 = IfThenElse(Any(), Integer(), Float())
    field2.validate(1.0)
    try:
        field2.validate("test")
    except ValueError:
        pass
    field3 = IfThenElse(Any(), Integer(), None)
    field3.validate(1)
    try:
        field3.validate("test")
    except ValueError:
        assert False, "Validation should have passed when else_clause == None"

# Generated at 2022-06-24 10:48:14.250009
# Unit test for method validate of class Not
def test_Not_validate():
    testcase = [
        {
            "name": "validate should return error if validated field is valid",
            "input": ("number", 6, None),
            "assert": {"error": "Must not match."}
        },
        {
            "name": "validate should return value if validated field isn't valid",
            "input": ("number", "ten", None),
            "assert": {"error": ""}
        }
    ]

    for test in testcase:
        # Arrange
        notField = Not(Field()(test.get("input")[0]))
        value = test.get("input")[1]
        # Act
        _, error = notField.validate_or_error(value)
        if error:
            error = error.messages.get("negated")
        # Assert

# Generated at 2022-06-24 10:48:20.781164
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    class IntOrString(Field):
        def validate(self, value, strict=False):
            if isinstance(value, int) or isinstance(value, str):
                return value
            else:
                raise Exception
    class String(Field):
        def validate(self, value, strict=False):
            if isinstance(value, str):
                return value
            else:
                raise Exception
    class Int(Field):
        def validate(self, value, strict=False):
            if isinstance(value, int):
                return value
            else:
                raise Exception
    then_clause = String()
    else_clause = Int()
    # Act
    test = IfThenElse(if_clause=IntOrString(), then_clause=then_clause, else_clause=else_clause)

# Generated at 2022-06-24 10:48:30.237284
# Unit test for method validate of class Not
def test_Not_validate():
	def __init__(self, negated: Field, **kwargs: typing.Any) -> None:
		assert "allow_null" not in kwargs
		super().__init__(**kwargs)
		self.negated = negated
	
	def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
		_, error = self.negated.validate_or_error(value, strict=strict)
		if error:
			return value
		raise self.validation_error("negated")

	errors = {"negated": "Must not match."}

	def test_validate_success():
		field = Not(Field())
		field.validate('Test')

	def test_validate_failure():
		field = Not

# Generated at 2022-06-24 10:48:35.173129
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.validators import MinValidator
    ite = IfThenElse(
        Integer(min_value=2),
        Integer(min_value=4),
        Integer(min_value=6)
    )
    assert(ite.validate(10) == 10)
    assert(ite.validate(5) == 6)