

# Generated at 2022-06-24 10:38:35.881962
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[
        types.Integer(minimum=0),
        types.Integer(minimum=2),
        types.Integer(minimum=3),
    ])
    assert field.validate(1) == 1
    assert field.validate(2) == 2
    assert field.validate(3) == 3
    assert_validation_error(field, None, "no_match")
    assert_validation_error(field, [], "no_match")
    assert_validation_error(field, "3", "no_match")



# Generated at 2022-06-24 10:38:40.657721
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # class NeverMatch(Field):
    # """
    # Doesn't ever match.
    # """
    #     errors = {"never": "This never validates."}
    #     def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
    #         raise self.validation_error("never")
    never_match = NeverMatch()
    with pytest.raises(AssertionError):
        never_match.validate(True)



# Generated at 2022-06-24 10:38:42.680429
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    my_one_of = OneOf([])
    assert my_one_of.validate(value=1) == None


# Generated at 2022-06-24 10:38:47.951049
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Create and validate with the AllOf class
    field = AllOf([])
    result = field.validate(None)

    # Assert the result
    assert result is None


# Generated at 2022-06-24 10:38:49.091101
# Unit test for constructor of class AllOf
def test_AllOf():
    class Test:
        t = AllOf([Any()])
    assert Test().t

# Generated at 2022-06-24 10:38:50.415851
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    example = AllOf(all_of=[Any])
    assert example.validate({}) == {}



# Generated at 2022-06-24 10:38:51.478743
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    AllOf([Int()]).validate(42)


# Generated at 2022-06-24 10:38:56.406239
# Unit test for constructor of class AllOf
def test_AllOf():
    import pytest
    assert AllOf(all_of=[Field(), Field()])
    assert AllOf(all_of=[Field()])
    with pytest.raises(AssertionError):
        assert AllOf(all_of=[Field(), Field()], allow_null=True)

# Generated at 2022-06-24 10:38:59.282429
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    conditional = IfThenElse(String())
    assert conditional.validate("") == "", "Should return the input value after validation."
    

# Generated at 2022-06-24 10:39:00.394632
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-24 10:39:05.304683
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    f = IfThenElse(if_clause, then_clause, else_clause)
    assert f.if_clause == if_clause
    assert f.then_clause == then_clause
    assert f.else_clause == else_clause

# Generated at 2022-06-24 10:39:09.054872
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String 

    field = IfThenElse(String(max_length=5), String(max_length=4))

    # this should work
    field.validate_or_error("123")

    # this should fail
    try:
        field.validate_or_error("123456")
        assert False
    except:
        assert True

# Generated at 2022-06-24 10:39:10.213859
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # TODO: write code here
    return


# Generated at 2022-06-24 10:39:13.423810
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test data
    one_of = [
        Field(validators=[Rule(min_length=6)]),
        Field(validators=[Rule(max_length=6)]),
    ]
    
    # Test execution
    result = OneOf(one_of).validate('123456')
    assert result == '123456'


# Generated at 2022-06-24 10:39:14.638706
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([])
    assert field.validate("a") == "a"


# Generated at 2022-06-24 10:39:15.933491
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem.fields import NeverMatch
    NeverMatch()


# Generated at 2022-06-24 10:39:17.540478
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    Field = NeverMatch()
    assert Field.error == {"never": "This never validates."}


# Generated at 2022-06-24 10:39:18.087387
# Unit test for constructor of class Not
def test_Not():
    a = Not()

# Generated at 2022-06-24 10:39:21.582222
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(label="field")
    assert field.label == "field"
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:39:22.842360
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([Field(name="test_field")], name="test_field")

# Generated at 2022-06-24 10:39:24.595708
# Unit test for constructor of class OneOf
def test_OneOf():
  one_of_fields = [Any()]
  one_of = OneOf(one_of_fields)
  assert(one_of != None)


# Generated at 2022-06-24 10:39:26.839035
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(typesystem.ValidationError):
        NeverMatch().validate(None)

# Unit tests for method validate of class OneOf

# Generated at 2022-06-24 10:39:29.782715
# Unit test for constructor of class Not
def test_Not():
    not_item = Not(negated=3)
    assert not_item.negated == 3

# Generated at 2022-06-24 10:39:31.994234
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert isinstance(never_match, NeverMatch)


# Generated at 2022-06-24 10:39:33.523907
# Unit test for method validate of class Not
def test_Not_validate():
    # TODO
    pass

# Generated at 2022-06-24 10:39:40.151576
# Unit test for method validate of class Not
def test_Not_validate():
	error = {'negated': "Must not match."}

	json_input = '{"Key1":"Key1Value"}'
	json_input = json.loads(json_input)

	not1 = Not(Dict({
        "Key1": String(required=True),
        "Key2": String(required=True),
    }, required=True))

	try:
		not1.validate(json_input)
		assert(False)
	except ValidationError as error_raised:
		assert(error_raised.error_dict == error)


# Generated at 2022-06-24 10:39:41.349205
# Unit test for constructor of class Not
def test_Not():
    not_field = Not("field")
    assert not_field.negated == "field"

# Generated at 2022-06-24 10:39:45.638703
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import String, Integer

    field = OneOf([String(), Integer()])

    assert field.validate("a") == "a"
    assert field.validate(1) == 1

    with pytest.raises(ValidationError, match="no_match"):
        field.validate(True)

    with pytest.raises(ValidationError, match="multiple_matches"):
        field.validate(1.0)



# Generated at 2022-06-24 10:39:49.807346
# Unit test for method validate of class Not
def test_Not_validate():
    check_field = Not(negated=Any())
    assert check_field.validate(1) == 1
    assert check_field.validate(None) == None
    assert check_field.validate("One") == "One"



# Generated at 2022-06-24 10:39:50.700921
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert 1==1


# Generated at 2022-06-24 10:39:55.823300
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Define a list of items
    items = [String(), String(), String()]
    # Define an object of class OneOf
    oneof = OneOf(one_of=items)
    # Define a list of strings
    strings = ['This ','is ','a ','string']
    # Define a string
    string = 'This is a string'
    assert oneof.validate(string) == string
    assert oneof.validate(strings) == string

# Generated at 2022-06-24 10:39:56.684023
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf is not None

# Generated at 2022-06-24 10:40:06.831308
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer, String
    from typesystem.fields import Array
    from typesystem.fields import Boolean
    from typesystem.fields import Object
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf

    def test_validate(t):
        print(t)
        assert t.validate({"a": 1, "b": 2}) == t.validate({"a": 2, "b": 2})
        assert t.validate({"b": 2}) == t.validate({"a": 2, "b": 2})
        assert t.validate({"b": 2, "c": 1}) == t.validate({"a": 2, "b": 2})
        print(t.error_messages({"a": 1, "b": 2}))
        assert t.validate

# Generated at 2022-06-24 10:40:14.096673
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print("Unit test for constructor of class NeverMatch")
    nm = NeverMatch()
    # nm = NeverMatch(allow_null=True)
    print(nm.label)
    print(nm.name)
    print(nm.errors)
    print(nm.meta)
    print(nm.allow_null)
    print(nm.default)
    print(nm.description)
    print(nm.required)
    print(nm.strict)
    print(nm.validate)
    print(nm.get_json_schema())


# Generated at 2022-06-24 10:40:18.036301
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = IfThenElse(None, None, None)
    then_clause = IfThenElse(None, None, None)
    else_clause = IfThenElse(None, None, None)

    test_obj = IfThenElse(if_clause, then_clause, else_clause)
    test_obj.validate(1)

test_IfThenElse_validate()

# Generated at 2022-06-24 10:40:23.145142
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any(min_length=4), required=True)
    n.validate("lista")
    #print(n.validate("lista"))
    try:
        n.validate("lis")
    except Exception as e:
        print(repr(e))


# Generated at 2022-06-24 10:40:24.118398
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()])



# Generated at 2022-06-24 10:40:30.698344
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf([List(Int()), Array(), Any()], allow_null=True)
    one_of_field.validate([1,2,3])
    one_of_field.validate([1,2])
    one_of_field.validate([])
    assert one_of_field.validate(1) == 1
    one_of_field.validate(None)
    assert str(one_of_field.validate([1,2,3,4])) == "Matched more than one type."


# Generated at 2022-06-24 10:40:42.332518
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()

    # Case 1: if_clause is None
    if_clause = None
    then_clause = None
    else_clause = None

    result = IfThenElse(if_clause, then_clause, else_clause).validate("fake value")
    assert result == "fake value"

    # Case 2: else_clause is None
    if_clause = Field()
    then_clause = Field()
    else_clause = None

    result = IfThenElse(if_clause, then_clause, else_clause).validate("fake value")
    assert result == "fake value"

    # Case 3: then_clause is None
    if_clause = Field()
   

# Generated at 2022-06-24 10:40:51.072670
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class MyIf(typesystem.Field):
        def validate(self, value, strict=False):
            if value:
                raise self.validation_error("MyIf")

    my_if = MyIf()
    class MyThen(typesystem.Field):
        def validate(self, value, strict=False):
            if value:
                raise self.validation_error("MyThen")

    my_then = MyThen()
    class MyElse(typesystem.Field):
        def validate(self, value, strict=False):
            if value:
                raise self.validation_error("MyElse")

    my_else = MyElse()
    my = IfThenElse(my_if, my_then, my_else)
    my.validate(False)

# Generated at 2022-06-24 10:40:56.775258
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from random import randint
    from typesystem.utils import get_random_string

    from typesystem.fields import Field

    x = (
        AllOf([Field(max_length=5), Field(min_length=5), Field(type=str)])
        .validate(get_random_string(randint(5, 10)))
        .__str__()
    )
    assert x == get_random_string(randint(5, 10))



# Generated at 2022-06-24 10:41:06.973116
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_field = Boolean(true_values=['t'], false_values=['f'])
    if_field.validate('t')
    then_field = Integer(min=0, max=10)
    else_field = Integer(min=0, max=10)
    field = IfThenElse(if_clause=if_field, then_clause=then_field, else_clause=else_field)
    assert field.validate('t') == None
    assert field.validate('f') == None
    with pytest.raises(ValidationError):
        field.validate('t', strict=True)
    with pytest.raises(ValidationError):
        field.validate('f', strict=True)
    assert field.validate('t', strict=False) == None
    assert field.valid

# Generated at 2022-06-24 10:41:11.942994
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    try:
        OneOf([Any()]).validate(1)
    except Exception as e:
        assert str(e) == "Did not match any valid type."
        return
    assert False, "Failed to raise exception"


# Generated at 2022-06-24 10:41:15.636887
# Unit test for constructor of class OneOf
def test_OneOf():
    result = OneOf([], **{"description": "", "title": "", "format": "", "name": ""})
    assert result.title == ""  # type: ignore
    assert result.name == ""  # type: ignore


# Generated at 2022-06-24 10:41:26.601983
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String, Boolean, List
    from typesystem.error_messages import ErrorMessage

    schema_a = Boolean()
    schema_q = String(enum=["abc"])
    schema_r = List(items=Integer())
    schema_e = Integer(gt=0)
    schema_c = IfThenElse(schema_a, else_clause=schema_r, then_clause=schema_e)

    # should pass validation
    data1 = 0
    data2 = True
    data3 = [1, 2, 3]

    assert schema_c.validate(data1) == data1
    assert schema_c.validate(data2) == data2
    assert schema_c.validate(data3) == data3

    # should throw error
    data4 = "abc"


# Generated at 2022-06-24 10:41:28.144240
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = typing.List([Any()])
    field = OneOf(one_of)
    assert isinstance(field, OneOf)



# Generated at 2022-06-24 10:41:32.533813
# Unit test for constructor of class OneOf
def test_OneOf():
    print('Unit test for constructor of class OneOf')
    print('~~~')
    one_of = [Any(), Any()]
    assert OneOf(one_of) is not None
    print('~~~')
    print('Passed!')


# Generated at 2022-06-24 10:41:32.914089
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert True

# Generated at 2022-06-24 10:41:35.020494
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    schema = OneOf([])
    assert schema.validate(5) == 5


# Generated at 2022-06-24 10:41:42.466346
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # type: () -> None
    from typesystem import Integer

    class TestOneOfValidateInteger(OneOf):
        one_of = [Integer(), String()]

    obj = TestOneOfValidateInteger()
    assert obj.validate(1) == 1
    assert obj.validate('1') == '1'
    try:
        obj.validate(True)
        assert False
    except Exception as e:
        assert e.message == 'Did not match any valid type.'


# Generated at 2022-06-24 10:41:45.041505
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ifthenelse = IfThenElse(Any(), then_clause = Any(), else_clause = Any())
    assert ifthenelse

# Generated at 2022-06-24 10:41:51.744379
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class AllOfField(Field):
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
            self.all_of = all_of
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            for child in self.all_of:
                child.validate(value, strict = strict)
            return value

    # AllOfField extends Field and implements method validate
    assert issubclass(AllOfField, Field)
    assert hasattr(AllOfField, 'validate')
    assert callable(getattr(AllOfField, 'validate'))
    # AllOfField extends Field and implements method validate
    assert iss

# Generated at 2022-06-24 10:41:55.045556
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated = None)
    with pytest.raises(NotImplementedError):
        field.validate(value = None)


# Generated at 2022-06-24 10:41:58.404401
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():

    data = []
    error = {}
    f = NeverMatch()

    try:
        f.validate(data)
    except Exception as e:
        error = e.errors

    assert error == {"never": "This never validates."}



# Generated at 2022-06-24 10:42:03.152357
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f1 = IntegerField(description="f1")
    f2 = IntegerField(description="f2")
    f3 = IntegerField(description="f3")
    field = IfThenElse(f1, f2, f3, description="field")
    assert field.validate(1) == 1
    assert field.validate(-1) == -1

# Generated at 2022-06-24 10:42:11.923983
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    The method AllOf.validate, when called with a value
    x and strict=True, raises a ValidationError if x does not
    validate against all of the fields of self.all_of
    """
    class AllOfTest(AllOf):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
        
    class A:
        def validate(self, value, strict=False):
            if strict and value!=1:
                raise Field.ValidationError("Invalid value for A")
    
    class B:
        def validate(self, value, strict=False):
            if strict and value!=2:
                raise Field.ValidationError("Invalid value for B")
    

# Generated at 2022-06-24 10:42:12.817435
# Unit test for constructor of class AllOf
def test_AllOf():
   a = AllOf([Any()])

# Generated at 2022-06-24 10:42:13.686873
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()


# Generated at 2022-06-24 10:42:20.212670
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.typing import *
    from typesystem.meta import MetaSchema

    # Test without a child_type
    my_not = Not(negated=String())
    assert isinstance(my_not.negated, String)
    assert my_not.to_json_schema() == {
        '$schema': MetaSchema.url,
        'title': 'Not',
        'type': 'not',
        'negated': {
            '$schema': MetaSchema.url,
            'title': 'String',
            'type': 'string',
        }
    }

    # Test with a child_type that is not a Field
    with pytest.raises(AssertionError):
        Not(String())


# Generated at 2022-06-24 10:42:25.143174
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    value = 1
    strict = True
    kwargs = {}
    fieldname = 'test'
    error = 'This never validates.'
    a = NeverMatch(**kwargs)
    assert a.field_name == fieldname
    assert a.validate(value, strict=strict) == error

# Constructor

# Generated at 2022-06-24 10:42:28.866597
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([
        Type(int),
        Min(2),
        Max(10)
    ])
    result = field.validate(3)
    assert result == 3, "The function 'validate' of class 'AllOf' does not return the correct value or does not work properly"


# Generated at 2022-06-24 10:42:29.828775
# Unit test for constructor of class Not
def test_Not():
    assert isinstance(Not(negated=Any()), Not)

# Generated at 2022-06-24 10:42:30.691418
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    item = AllOf([Any()])
    val = item.validate(1)

# Generated at 2022-06-24 10:42:37.750820
# Unit test for constructor of class Not
def test_Not():
    # tests that the constructor works
    # create an instance of Not
    my_not = Not(Any())
    # assert that my_not is an instance of Not
    assert(isinstance(my_not, Not))
    # assert that my_not is an instance of Field
    assert(isinstance(my_not, Field))
    # assert that my_not.negated is an instance of Any
    assert(isinstance(my_not.negated, Any))
    return True


# Generated at 2022-06-24 10:42:42.382776
# Unit test for constructor of class OneOf
def test_OneOf():
    # Setup
    one_of = [Field()]
    # Exercise
    obj = OneOf(one_of)
    # Verify
    assert obj.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}


# Generated at 2022-06-24 10:42:52.750489
# Unit test for method validate of class Not
def test_Not_validate():
    # create instance of class Not
    my_not = Not(String())

    # test value '5' with input string
    result = my_not.validate("5")
    assert result == "5"

    # test value '5.6' with input string
    result = my_not.validate("5.6")
    assert result == "5.6"

    # test value True with input bool
    result = my_not.validate(True)
    assert result is True

    # test value 5.6 with input float
    result = my_not.validate(5.6)
    assert result == 5.6

    # test value None with input None
    result = my_not.validate(None)
    assert result is None

# Generated at 2022-06-24 10:42:54.554097
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(['a'])

# Generated at 2022-06-24 10:42:58.011355
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf(one_of=[Int()]).validate(1) == 1
    assert OneOf(one_of=[Int()]).validate("1") == "1"
    assert OneOf(one_of=[Int()]).validate(1.1) == 1.1


# Generated at 2022-06-24 10:43:00.962777
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String

    not_field = Not(negated=String())
    assert isinstance(not_field, Not)
    assert isinstance(not_field.negated, String)



# Generated at 2022-06-24 10:43:05.795558
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Initialize a instance of the class
    all_of = AllOf([])

    # Must match all of the sub-items. You should instead consolidate into a single type, or use schema inheritence instead of this.
    assert all_of.validate(1) == 1

# Generated at 2022-06-24 10:43:14.151587
# Unit test for method validate of class AllOf
def test_AllOf_validate():

    from typesystem import Integer, String

    class MyTest(AllOf):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(all_of=[Integer(), String()], **kwargs)

    my_test = MyTest()

    try:
        my_test.validate("str")
        my_test.validate("5")
        my_test.validate(5)
    except:
        assert False

    try:
        my_test.validate("5.5")
        assert False
    except:
        pass


# Generated at 2022-06-24 10:43:15.903638
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(NeverMatch()).validate(1) == 1

# Generated at 2022-06-24 10:43:17.195881
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass



# Generated at 2022-06-24 10:43:23.924409
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.json_schema.fields import OneOf, AllOf
    a = "a"
    b = "b"
    c = "c"
    d = "d"
    # all(a,b)
    all_of_obj = AllOf(all_of = [a, b])
    assert all_of_obj.all_of == [a, b]
    # all(all(a),b,c)
    all_of_obj = AllOf(all_of = [AllOf(all_of = [a]),b,c])
    assert all_of_obj.all_of == [AllOf(all_of = [a]),b,c]
    # all(one(a))

# Generated at 2022-06-24 10:43:31.267250
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer
    field = OneOf([Integer(minimum=1), Integer(maximum=10)])
    expected_errors = {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}
    assert field.errors == expected_errors
    assert field.one_of[0].options == {'minimum': 1}
    assert field.one_of[1].options == {'maximum': 10}



# Generated at 2022-06-24 10:43:33.617603
# Unit test for method validate of class Not
def test_Not_validate():
    field_not = Not(Any())
    assert field_not.validate(1) == 1


# Generated at 2022-06-24 10:43:37.813759
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer, String
    not_integer = Not(Integer())
    _, error = not_integer.validate_or_error(1)
    assert error == {"negated": "Must not match."}
    _, error = not_integer.validate_or_error("text")
    assert error == None

# Generated at 2022-06-24 10:43:39.667871
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    x = NeverMatch()
    assert x.validate("test") == "test"

test_NeverMatch_validate()



# Generated at 2022-06-24 10:43:48.277151
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = String(max_length=10)
    then_clause = String(min_length=5)
    else_clause = String(max_length=5)
    ifthenelse = IfThenElse(if_clause, then_clause, else_clause)
    assert ifthenelse.validate('hello') == 'hello'
    assert ifthenelse.validate('hellohellohello') == 'hellohellohello'
    assert ifthenelse.validate('hellohellohellohello') == 'hellohellohellohello'

# Generated at 2022-06-24 10:43:52.759957
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field_1 = Field(type='integer')
    field_2 = Field(type='string')
    assert IfThenElse(if_clause=field_1, then_clause=field_2, else_clause=field_2) is not None



# Generated at 2022-06-24 10:44:02.113039
# Unit test for constructor of class AllOf
def test_AllOf():
    import pytest
    from typesystem import Any, Integer, String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Schema

    field = AllOf([Integer(), Integer(maximum=10)])
    assert field.validate(1) == 1
    # ValueError: Cannot use 'allow_null' with this field.
    with pytest.raises(ValueError) as excinfo:
        AllOf([String()], allow_null=True)
    assert "Cannot use 'allow_null' with this field" in str(excinfo.value)

    class MySubSchema(Schema):
        a = Integer()
        b = Integer()

    class MySchema(Schema):
        x = AllOf([MySubSchema, Any()])
        y = AllOf([MySubSchema, Any()])

# Generated at 2022-06-24 10:44:12.058130
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_field = Field()
    if_field.errors = {"if": "if clause fails"}
    then_field = Field()
    then_field.errors = {"then": "then clause fails"}
    else_field = Field()
    else_field.errors = {"else": "else clause fails"}

    if_clause = IfThenElse(if_field)
    assert if_clause.if_clause is if_field
    assert if_clause.then_clause is not None
    assert isinstance(if_clause.then_clause, Any)
    assert if_clause.else_clause is not None
    assert isinstance(if_clause.else_clause, Any)

# Generated at 2022-06-24 10:44:17.052729
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    value1 = 3
    value2 = 9
    value3 = "9"
    field1 = IfThenElse(value1, value2)
    field2 = IfThenElse(value3, value2)
    assert(field1.validate(value1) == value2)
    assert(field2.validate(value3) == value2)

# Generated at 2022-06-24 10:44:22.740526
# Unit test for method validate of class Not
def test_Not_validate():
    name = "Negated"
    allow_null = "False"
    description = "Must not match."
    errors = {"negated": "Must not match."}
    field = Field()

    # test instance of class AllOf
    negated_test_instance = Not(negated=field)
    assert negated_test_instance.name == name
    assert negated_test_instance.allow_null == allow_null
    assert negated_test_instance.description == description
    assert negated_test_instance.errors == errors


# Generated at 2022-06-24 10:44:29.013355
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(2) == 2
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("s") == "s"


# Generated at 2022-06-24 10:44:32.056590
# Unit test for constructor of class Not
def test_Not():
    f1 = Not('c', error_messages={'negated': 'Must not match.'})
    assert f1.negated == 'c'
    assert f1.error_messages == {'negated': 'Must not match.'}


# Generated at 2022-06-24 10:44:36.725900
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause = String(max_length = 2, allow_blank = False),
        then_clause = String(max_length = 10, allow_blank = False),
        else_clause = String(allow_blank = False)
    )

    field.validate("Hello")

# Generated at 2022-06-24 10:44:37.807108
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    pass

# Generated at 2022-06-24 10:44:44.590418
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=['a','b','c','d','e','f','g','h'])
    assert AllOf(all_of=[1,2,3,4,5,6,7,8,9,10])
    assert AllOf(all_of=['a','b','c','d','e','f','g','h'], error_messages={})
    assert AllOf(all_of=[1,2,3,4,5,6,7,8,9,10], error_messages={})



# Generated at 2022-06-24 10:44:49.456184
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    
    field = AllOf([])
    strict = True
    value = {}
    field.validate(value, strict)
    

# Generated at 2022-06-24 10:44:51.411829
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(field)
    field = AllOf()

# Generated at 2022-06-24 10:44:55.934838
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_json1 = {
        "name": "James"
    }
    test_OnOf_field = OneOf([String()],name="name")
    print(test_OnOf_field.validate(test_json1))


if __name__ == "__main__":
    test_OneOf_validate()

# Generated at 2022-06-24 10:44:59.117862
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():

    field = typesystem.field.NeverMatch('description')

    with pytest.raises(typesystem.exceptions.ValidationError):
        field.validate()



# Generated at 2022-06-24 10:45:02.012032
# Unit test for constructor of class OneOf
def test_OneOf():
    test_OneOf_oneof = [typesystem.String()]
    test_OneOf_kwargs = {}
    value = OneOf(test_OneOf_oneof, **test_OneOf_kwargs)
    assert value is not None


# Generated at 2022-06-24 10:45:03.798642
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert False == True


# Generated at 2022-06-24 10:45:08.868913
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IField(Field):
        def validate(self, value, strict=False):
            return True
    if_clause = IField()
    then_clause = IField()
    else_clause = IField()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(1) is True

# Generated at 2022-06-24 10:45:10.961228
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse("if").validate("if")


# Generated at 2022-06-24 10:45:17.038317
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test_validate_else():
        assert IfThenElse(if_clause=Number(maximum=2), else_clause=Number(minimum=0)).validate(3) == 3
    test_validate_else()
    def test_validate_then():
        assert IfThenElse(if_clause=Number(maximum=2), then_clause=Number(maximum=0)).validate(3) == 3
    test_validate_then()

# Generated at 2022-06-24 10:45:26.098613
# Unit test for method validate of class Not
def test_Not_validate():
    children1 = CharField()
    children1.errors = {"char": "Must be a char."}
    negated1 = Not(children1)
    # True case

# Generated at 2022-06-24 10:45:30.186621
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    try:
        f.validate(1)
        assert False
    except Exception as exc:
        msg = str(exc)
        assert msg == "Validation error: This never validates."


# Generated at 2022-06-24 10:45:31.899620
# Unit test for constructor of class NeverMatch

# Generated at 2022-06-24 10:45:34.052710
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test = NeverMatch()
    assert test.errors == {"never" : "This never validates."}


# Generated at 2022-06-24 10:45:34.638225
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-24 10:45:37.019224
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    test_field=NeverMatch()
    with pytest.raises(test_field.validation_error):
        test_field.validate(1)


# Generated at 2022-06-24 10:45:42.560071
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    from typesystem.types import JSONSchemaType

    class TestField(Field):
        def validate(self, value: str, strict: bool = False) -> str:
            return value + "!"

    # Test validating the sub-field.
    field = NeverMatch(one_of=[TestField()])
    assert field.validate("hello") == "hello!"

    # Test erroring when no sub-field matches.
    field = NeverMatch(one_of=[NeverMatch()])
    try:
        field.validate("hello")
        assert False, "Did not raise ValidationError"
    except ValidationError as error:
        assert error.code == "no_match"

    # Test erroring when multiple sub-fields match.

# Generated at 2022-06-24 10:45:45.608059
# Unit test for method validate of class Not
def test_Not_validate():
    fields = Not(negated=str)
    result = fields.validate(value=1)
    assert result == 1


# Generated at 2022-06-24 10:45:49.105793
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # initialize field data
    data = 1
    strict = False

    # initialize class
    instance = AllOf(all_of=[])

    # run test
    instance.validate(data, strict)

    # assert
    assert True

# Generated at 2022-06-24 10:45:51.560153
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    validate(field, "a_string")
    validate(field, 11)
    validate(field, 1.0)

# Generated at 2022-06-24 10:45:59.497309
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.types import String

    # case: if_clause matches, then_clause matches
    I = String()
    T = String()
    E = String()
    F = IfThenElse(if_clause=I, then_clause=T)
    assert F.validate("yes") == "yes"

    # case: if_clause doesn't match, else_clause matches
    I = String(pattern="^[a-z]$")
    T = String()
    E = String()
    F = IfThenElse(if_clause=I, then_clause=T, else_clause=E)
    assert F.validate("yes") == "yes"

    # case: if_clause matches, then_clause doesn't match
    I = String()

# Generated at 2022-06-24 10:46:00.840966
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([])
    assert field.validate(1) == 1


# Generated at 2022-06-24 10:46:05.631875
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.types import String, Integer, Number

    print("Unit test for method validate of class AllOf")

    numbers_is_string = AllOf([String(), Number()])
    assert numbers_is_string.validate("test") is None
    
    numbers_is_string_number = AllOf([String(), Integer()])
    assert numbers_is_string_number.validate("test") is None
    assert numbers_is_string_number.validate(10) is None



# Generated at 2022-06-24 10:46:08.110041
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String(max_length=1), String(max_length=4)])
    print(field)



# Generated at 2022-06-24 10:46:10.076984
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert not NeverMatch()



# Generated at 2022-06-24 10:46:13.197358
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import Integer

    integer = Integer()
    not_integer = Not(integer)
    assert not_integer.negated == integer



# Generated at 2022-06-24 10:46:16.782499
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # init
    one_of_test = OneOf([])
    # execute
    with pytest.raises(one_of_test.validation_error):
        one_of_test.validate()
    # verify



# Generated at 2022-06-24 10:46:21.388888
# Unit test for constructor of class OneOf
def test_OneOf():
    pass


# Generated at 2022-06-24 10:46:23.466651
# Unit test for constructor of class Not
def test_Not():
    Not(negated=True)

# Generated at 2022-06-24 10:46:26.040574
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert(not_field.validate(1) == 1)



# Generated at 2022-06-24 10:46:28.184191
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    assert f.validate(None, strict=False) == None


# Generated at 2022-06-24 10:46:28.604456
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])

# Generated at 2022-06-24 10:46:31.538235
# Unit test for constructor of class OneOf
def test_OneOf():
    A = OneOf([1,2,3], description="The description")
    assert A.one_of == [1, 2, 3]
    assert A.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert A.description == "The description"
    assert A.required == False
    assert A.default == None
 

# Generated at 2022-06-24 10:46:33.733035
# Unit test for method validate of class Not
def test_Not_validate():
    assert(Not(Any()).validate(2) == 2)
    #assert(Not(Int()).validate(2) == 2)


# Generated at 2022-06-24 10:46:37.797679
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    import pytest
    from typesystem.fields import NeverMatch
    with pytest.raises(AssertionError):
        nevermatch_field = NeverMatch(allow_null=True)


# Generated at 2022-06-24 10:46:39.309725
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([Field(), Field()])



# Generated at 2022-06-24 10:46:45.474402
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any(), Any()])
    assert field.validate("any") == "any"
    assert field.validate(True) == True
    assert field.validate([]) == []


# Generated at 2022-06-24 10:46:46.864150
# Unit test for constructor of class Not
def test_Not():
    field = Not(BaseNumber())
    assert field.negated == BaseNumber()



# Generated at 2022-06-24 10:46:53.875954
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field1 = Text()
    field2 = Integer()
    all_of = AllOf(all_of=[field1, field2])
    with pytest.raises(ValidationError):
        all_of.validate(value=12.3)
    with pytest.raises(ValidationError):
        all_of.validate(value='hello')
    with pytest.raises(ValidationError):
        all_of.validate(value='12')


# Generated at 2022-06-24 10:47:01.377216
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import Integer
    if_clause = Integer(nullable=True)
    class abc:
        x = 1
    then_clause = Integer()
    else_clause = abc()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert isinstance(if_then_else, Field)
    assert if_then_else.nullable == False


# Generated at 2022-06-24 10:47:03.565854
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Initialize
    field = NeverMatch()

    # Test
    assert field.errors == ("never", "This never validates.")


# Generated at 2022-06-24 10:47:04.499668
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(IfThenElse, IfThenElse)

# Generated at 2022-06-24 10:47:07.406365
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        NeverMatch().validate('123')
        # print("Fail: NeverMatch().validate('123')")
    except:
        # print("Pass: NeverMatch().validate('123')")
        pass
    return


# Generated at 2022-06-24 10:47:10.903840
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = IfThenElse(lambda x: (x > 0) - (x < 0), PrimitiveField(int, allow_null=False))
    assert if_clause.validate(4) == 4
    assert if_clause.validate(0) == 0
    assert if_clause.validate(-8) == -8



# Generated at 2022-06-24 10:47:15.404263
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.validators import Length
    target = Not(String(validators=[Length(0, 1)]))
    assert target.negated == String(validators=[Length(0, 1)])


# Generated at 2022-06-24 10:47:21.255236
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match = NeverMatch()
    test_value = "test_value"
    with pytest.raises(Field.validation_error) as exception_info:
        never_match.validate(test_value)
    assert exception_info.value.args[0] == never_match.errors["never"]


# Generated at 2022-06-24 10:47:22.350325
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf


# Generated at 2022-06-24 10:47:28.136946
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer

    # OneOf with parameters
    one_of_field = OneOf(one_of=[Integer(), Integer()])
    assert one_of_field.errors == {
        'multiple_matches': 'Matched more than one type.', 'no_match': 'Did not match any valid type.'
    }
    assert one_of_field.one_of == [Integer(), Integer()]



# Generated at 2022-06-24 10:47:41.107498
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(one_of= [Int(), Float()])

    assert one_of.validate(3) == 3
    assert one_of.validate(3.0) == 3.0
    assert one_of.validate(3.1) == 3.1
    assert one_of.validate(3.1) == 3.1

    # e = one_of.validate('3.1')
    # print(e)
    assert one_of.validate('3.1') == '3.1'
    assert one_of.validate('3.1') == '3.1'
    assert one_of.validate('3.1') == '3.1'


# Generated at 2022-06-24 10:47:45.226279
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Given
    typesystem.fields.Any.errors = {'invalid': 'Must be of any type.'}
    all_of = [Any(), Any(), Any()]
    one_of = OneOf(all_of)
    # When
    validated = one_of.validate(2)
    # Then
    assert validated == 2


# Generated at 2022-06-24 10:47:47.186141
# Unit test for constructor of class OneOf
def test_OneOf():
	field = OneOf([Dict({}), Array([])])
	assert field.errors["no_match"] == "Did not match any valid type."

# Generated at 2022-06-24 10:47:49.405715
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-24 10:47:50.736647
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Boolean())
    print(field.validate(True))


# Generated at 2022-06-24 10:47:51.538178
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:47:53.728739
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert True == True
    assert False == False
    assert False == True
    assert False == False
    assert True == False
    assert False == True

# Generated at 2022-06-24 10:47:57.696144
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(AssertionError):
        NeverMatch(allow_null=True).validate(None, strict=False)
    with pytest.raises(Field.validation_error):
        NeverMatch().validate(1, strict=False)


# Generated at 2022-06-24 10:47:58.860606
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch(validate=False)
    assert nm


# Generated at 2022-06-24 10:48:02.018146
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(None, None, None)
    IfThenElse(None, None)
    IfThenElse(None)
    IfThenElse(1, None, None)
    IfThenElse(1)
    IfThenElse(1, None)

# Generated at 2022-06-24 10:48:07.908149
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    print("x = NeverMatch() => ", x)
    print("x.__dict__ => ", x.__dict__)
    assert x is not None
    assert x.errors['never'] == "This never validates."
    print("\n--- test Not NeverMatch success ---\n")



# Generated at 2022-06-24 10:48:13.709834
# Unit test for constructor of class Not
def test_Not():
    negated = None
    not_ = Not(negated)
    assert not_.negated is negated



# Generated at 2022-06-24 10:48:18.996576
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any(), default="default_value")
    assert field.validate("value") == "value"
    assert field.validate(None) == "default_value"
    with pytest.raises(AssertionError):
        field.validate(None, strict=True)

# Generated at 2022-06-24 10:48:20.254831
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match



# Generated at 2022-06-24 10:48:30.179293
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    
    user_schema = {
      "title": "user schema",
      "type": "object",
      "required": ["username"],
      "properties": {
        "username": {"type": "string", "minLength": 3},
        "age": {"type": "string", "minLength": 2},
      },
    }
    schema_json = typesystem.load_schema(user_schema)
    print(schema_json)
    schema_json.validate({'username': 'david', 'age': '25'})
    print(schema_json)