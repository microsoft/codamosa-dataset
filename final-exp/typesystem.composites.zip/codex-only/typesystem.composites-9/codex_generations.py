

# Generated at 2022-06-24 10:38:33.510384
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        field = NeverMatch()
        result = field.validate(1)
        assert False
    except ValueError as e:
        assert str(e) == "never"


# Generated at 2022-06-24 10:38:37.350107
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(5) == 5

# Generated at 2022-06-24 10:38:38.863983
# Unit test for constructor of class AllOf
def test_AllOf():
    obj = AllOf(all_of=[True])
    assert obj.all_of == [True]


# Generated at 2022-06-24 10:38:40.301451
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    with pytest.raises(ValueError):
        field.validate(123)


# Generated at 2022-06-24 10:38:41.718104
# Unit test for constructor of class AllOf
def test_AllOf():
    assert isinstance(AllOf, object)


# Generated at 2022-06-24 10:38:43.243729
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test Constructor
    assert(True)


# Generated at 2022-06-24 10:38:52.972272
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    """
    Test validate method of class IfThenElse
    """
    if_clause = mock.Mock()
    then_clause = mock.Mock()
    else_clause = mock.Mock()
    value = mock.Mock()
    strict = mock.Mock()
    field = IfThenElse(if_clause, then_clause, else_clause)
    field.validate(value, strict)
    if_clause.validate_or_error.assert_called_once_with(value, strict=strict)
    then_clause.validate.assert_called_once_with(value, strict=strict)
    else_clause.validate.assert_called_once_with(value, strict=strict)

# Generated at 2022-06-24 10:38:54.968639
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(1) == "This never validates."

# Generated at 2022-06-24 10:39:01.814008
# Unit test for constructor of class OneOf
def test_OneOf():
    # False Cases
    with pytest.raises(AssertionError):
        a = OneOf(one_of=[], allow_null=False)
    # True Cases
    a = OneOf(one_of=[])
    assert a.one_of == []
    assert a.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}


# Generated at 2022-06-24 10:39:07.381807
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Try to create the object
    try:
        objNeverMatch = NeverMatch()
    except Exception as e:
        print(e)
    else:
        print('NeverMatch is working properly')
    # Check if the function "validate" is working properly
    try:
        objNeverMatch.validate('foo', strict=False)
    except Exception as e:
        print(e)
    else:
        print('NeverMatch validate is working properly')


# Generated at 2022-06-24 10:39:13.548363
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Arrange
    # Act
    test1 = NeverMatch()
    test2 = NeverMatch(title="Test")
    # Assert
    assert test1.title == "Never Match"
    assert test1.description == None
    assert test1.allow_null == False
    assert test1.default == None
    assert test1.errors == {"never":"This never validates."}

    assert test2.title == "Test"
    assert test2.description == None
    assert test2.allow_null == False
    assert test2.default == None
    assert test2.errors == {"never":"This never validates."}



# Generated at 2022-06-24 10:39:18.492605
# Unit test for method validate of class Not
def test_Not_validate():
    negated = Field()
    negated.validate = lambda value, strict=False: value
    field = Not(negated)
    assert field.validate("test") == "test"
    try:
        field.validate(3)
    except Field.ValidationError:
        pass
    else:
        raise ValueError("Error not raised when validating invalid value")


# Generated at 2022-06-24 10:39:19.435859
# Unit test for constructor of class AllOf
def test_AllOf():
  assert AllOf([])

# Generated at 2022-06-24 10:39:21.340938
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[bool])


# Generated at 2022-06-24 10:39:22.657910
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf(all_of = [])


# Generated at 2022-06-24 10:39:25.675924
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    value = 6
    strict = True
    test_instance = NeverMatch()
    try:
        test_instance.validate(value, strict)
    except:
        return
    raise Exception("The NeverMatch.validate_method failed")


# Generated at 2022-06-24 10:39:33.941950
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse((lambda x: x==1 ),(lambda x: x==1 ),(lambda x: x==1 )).validate(1) == 1
    assert IfThenElse((lambda x: x!=1 ),(lambda x: x==1 ),(lambda x: x==1 )).validate(1) == 1
    assert IfThenElse((lambda x: x==0 ),(lambda x: x==1 ),(lambda x: x==1 )).validate(2) == 1

# Test method validate
test_IfThenElse_validate()

# Generated at 2022-06-24 10:39:40.969377
# Unit test for constructor of class OneOf
def test_OneOf():
    o1 = OneOf([])
    o2 = OneOf([Field()])
    o3 = OneOf([Field(), Field()])
    o4 = OneOf([Field(), Field(), Field()])

    assert o1.one_of == []
    assert o2.one_of == [Field()]
    assert o3.one_of == [Field(), Field()]
    assert o4.one_of == [Field(), Field(), Field()]


# Generated at 2022-06-24 10:39:43.434490
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    f = IfThenElse(if_clause=String(), then_clause=String(), else_clause=String())
    f.validate(1)
    f.validate('')



# Generated at 2022-06-24 10:39:46.842069
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Any())
    assert field._schema == {"not": {"type": "any"}}



# Generated at 2022-06-24 10:39:55.864521
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    all_of_field = AllOf([
        Text(pattern="\\d+", min_length=1, max_length=3),
        Number(minimum=0, maximum=10)
    ])

    field = OneOf([
        Integer(),
        Boolean(),
        all_of_field
    ])
    field.validate(True)
    field.validate(1)
    field.validate(2)
    field.validate(3)

    with pytest.raises(ValidationError) as e:
        field.validate("a")

# Generated at 2022-06-24 10:40:06.289725
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer, String
    field = OneOf(one_of=[Integer(), String()])
    
    # Test 1
    value = 1
    result = field.validate(value, strict=True)
    assert result == 1
    assert type(result) == int
    
    
    # Test 2
    value = "1"
    result = field.validate(value, strict=True)
    assert result == "1"
    assert type(result) == str
    
    
    # Test 3
    value = 1.1
    try:
        result = field.validate(value, strict=True)
        assert False
    except ValidationError as err:
        assert err.messages == ['No match.']
        assert err.value == 1.1

# Generated at 2022-06-24 10:40:14.986581
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field_allOf = AllOf([], base_type=str)
    field_allOf_1 = AllOf([], base_type=str)
    field_oneOf = OneOf([], base_type=str)
    field_oneOf_1 = OneOf([], base_type=str)
    field_oneOf_3 = OneOf([field_allOf, field_allOf_1], base_type=str)
    oneOf = OneOf([field_oneOf_3, field_oneOf], base_type=str)
    oneOf_validate = oneOf.validate
    value = "string"
    result = oneOf_validate(value)
    assert result == "string"

# Generated at 2022-06-24 10:40:17.501287
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    with pytest.raises(NeverMatch.validation_error):
        nm.validate("hello", True)


# Generated at 2022-06-24 10:40:19.792173
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf({}) == None


# Generated at 2022-06-24 10:40:25.143385
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any(required=False))
    assert field.validate(False) is False
    assert field.validate(None) is None
    assert field.validate([0]) == [0]
    assert field.validate("decoy") == "decoy"
    try:
        field.validate("")
    except Exception as e:
        assert str(e) == "Must not match."



# Generated at 2022-06-24 10:40:26.917255
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf([Any()])
    assert o.one_of[0] == Any()



# Generated at 2022-06-24 10:40:30.506057
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = Field()
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then = IfThenElse(if_clause)
    if_then_else = IfThenElse(if_clause,then_clause,else_clause)

# Generated at 2022-06-24 10:40:38.268880
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    field = IfThenElse(Integer(), then_clause=Integer())
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    field = IfThenElse(Integer(), then_clause=Integer(), else_clause=String())
    assert field.validate(1) == 1
    assert field.validate("a") == "a"



# Generated at 2022-06-24 10:40:41.482128
# Unit test for constructor of class AllOf
def test_AllOf():
    f = AllOf([Field()])
    assert f.allow_null is False
    assert f.required is False
    assert f.default is Field.empty



# Generated at 2022-06-24 10:40:45.954175
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    list_test = [
        {"value": True, "result": True},
        {"value": False, "result": False}
    ]
    for item in list_test:
        res, err = OneOf([Boolean(),Integer()]).validate_or_error(item["value"])
        assert res == item["result"]
        assert err == None
      


# Generated at 2022-06-24 10:40:50.882624
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(AllOf((Integer(),Integer())))
    assert not_field.validate([1]) == [1]



# Generated at 2022-06-24 10:41:00.671249
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Create a mock for class Field
    class MockField:
        def __init__(self):
            self.errors = {
                "if_clause": "This is if clause.",
                "then_clause": "This is then clause.",
                "else_clause": "This is else clause."
            }

        def validate_or_error(self, value, strict=False):
            if strict:
                print('validate_or_error of MockField has been called')
            else:
                print('validate_or_error of MockField has not been called')
            return (value, None)

        def validation_error(self, key):
            print(self.errors[key])

    # Create a mock for class Any

# Generated at 2022-06-24 10:41:03.802414
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Given
    input = {"allow_null": False}
    # When
    output = NeverMatch(**input)
    # Then
    assert output.allow_null == False


# Generated at 2022-06-24 10:41:06.670026
# Unit test for method validate of class OneOf
def test_OneOf_validate():
  o1 = String()
  o2 = String()
  o3 = String()

  oo = OneOf([o1, o2, o3])
  oo.validate("one")



# Generated at 2022-06-24 10:41:11.060795
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()], max_length=100, min_length=0)
    assert field.validate("hello world") == "hello world"
    assert field.validate(5) == 5

# Generated at 2022-06-24 10:41:20.188049
# Unit test for method validate of class Not
def test_Not_validate():
    print(Not(negated=None).validate(value=None, strict=False))
    print(Not(negated=None).validate(value=True, strict=False))
    print(Not(negated=None).validate(value=False, strict=False))
    print(Not(negated=None).validate(value="string", strict=False))
    print(Not(negated=None).validate(value=[1, 2, 3], strict=False))
    print(Not(negated=None).validate(value=[], strict=False))
    print(Not(negated=None).validate(value={"a": 1, "b": 2}, strict=False))
    print(Not(negated=None).validate(value={}, strict=False))

# Generated at 2022-06-24 10:41:23.894486
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(all_of=[])
    assert field.validate("Pustekuchen") == "Pustekuchen"
    with raises(AssertionError):
        field = AllOf(all_of=[], allow_null=True)


# Generated at 2022-06-24 10:41:30.821329
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        Field(type="string"),
        Field(type="integer")
    ])
    assert field.validate("test") == "test"
    assert field.validate(3) == 3
    try:
        field.validate({})
        assert False
    except Field.ValidationError as e:
        assert e.messages == {"__all__": "Did not match any valid type."}
    try:
        field.validate([])
        assert False
    except Field.ValidationError as e:
        assert e.messages == {"__all__": "Did not match any valid type."}



# Generated at 2022-06-24 10:41:32.157504
# Unit test for constructor of class Not
def test_Not():
    assert Not(None).negated == None

# Generated at 2022-06-24 10:41:33.350092
# Unit test for constructor of class OneOf
def test_OneOf():
    OneOf()


# Generated at 2022-06-24 10:41:44.490190
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import random
    import math
    import time
    random.seed(time.time())
    error_list = []
    match_count = 0
    candidate = None
    value_list = []
    for i in range(1000000):
        value_list.append(random.randint(-2147483648,2147483647))
    for i in value_list:
        for child in value:
            validated, error = child.validate_or_error(i, strict=strict)
            if error is None:
                match_count += 1
                candidate = validated
        if match_count == 1:
            break
        elif match_count > 1:
            error_list.append(self.validation_error("multiple_matches"))

# Generated at 2022-06-24 10:41:47.884523
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Negative(),)
    assert not_field.validate(1) == 1
    try:
        not_field.validate(-1)
    except typesystem.Error as e:
        assert e.code == "negated"

# Generated at 2022-06-24 10:41:59.449367
# Unit test for method validate of class Not
def test_Not_validate():
    Not_object = Not(negated=Any())
    assert Not_object.validate(value=(), strict=True) == ()
    assert Not_object.validate(value=(1,), strict=False) == (1,)
    assert Not_object.validate(value={}, strict=False) == {}
    assert Not_object.validate(value="", strict=True) == ""
    assert Not_object.validate(value="test", strict=False) == "test"
    assert Not_object.validate(value=True, strict=True) == True
    assert Not_object.validate(value=1, strict=True) == 1
    assert Not_object.validate(value=1.0, strict=True) == 1.0
    assert Not_object.validate(value=None, strict=False) == None


# Generated at 2022-06-24 10:42:02.927017
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        Field(required=True)
    ])
    value = {}
    with pytest.raises(RuntimeError) as excinfo:
        field.validate(value)
    assert str(excinfo.value) == 'RuntimeError: Did not match any valid type.'

# Generated at 2022-06-24 10:42:04.032494
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    pass # TODO: implement your test here


# Generated at 2022-06-24 10:42:05.457558
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Calling constructor of class NeverMatch
    # NeverMatch()
    assert True # TODO: implement your test here


# Generated at 2022-06-24 10:42:08.634113
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test_IfThenElse_validate.__doc__ = IfThenElse.validate.__doc__
    actual_out = IfThenElse(None, None, 1)
    actual = actual_out.validate(1)
    assert actual == 1

# Generated at 2022-06-24 10:42:12.598524
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    root = IfThenElse(
        if_clause=Boolean(),
        then_clause=Boolean(),
        else_clause=String(),
    )
    # Should not raise any exception
    root.validate(False)
    root.validate(True)
    root.validate("TRUE")
    root.validate("FALSE")


# Generated at 2022-06-24 10:42:15.404300
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String, Integer

    field = AllOf([String(), Integer()])

    field.validate("123")  # will succeed
    # field.validate("asdf")  # will fail


# Generated at 2022-06-24 10:42:20.162096
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    a = NeverMatch()
    with raises(ValidationError) as exc_info:
        a.validate(1)
    assert exc_info.value.args[0] == "This never validates."
    assert exc_info.value.args[1] == "never"


# Generated at 2022-06-24 10:42:22.385939
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(Any(), Any(), Any())
    x.validate(1)
    assert True



# Generated at 2022-06-24 10:42:23.393513
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-24 10:42:30.160447
# Unit test for method validate of class Not
def test_Not_validate():
    test_errors = {"negated": "Must not match."}
    test_negated = Field()
    class TestClass:
        def __init__(self, value=None):
            self.errors = {"negated": "Must not match."}
            self.negated = test_negated
        def validation_error(self, error_key, **context):
            return "What"
    test_value = 1
    test_strict = False
    test_instance = TestClass()
    assert test_instance.validate(test_value, test_strict) == test_value


# Generated at 2022-06-24 10:42:34.039491
# Unit test for method validate of class AllOf
def test_AllOf_validate():

    def validate_AllOf(my_field, value):
        try:
            my_field.validate(value)
            return True
        except:
            return False

    schema = AllOf([Int8, Int16])
    value1 = 5
    value2 = 500
    value3 = -5

    assert validate_AllOf(schema, value2)
    assert validate_AllOf(schema, value3)
    assert not validate_AllOf(schema, value1)


# Generated at 2022-06-24 10:42:46.159552
# Unit test for method validate of class Not
def test_Not_validate():
    # Test assertion 'error'
    with pytest.raises(AssertionError):
        Not(negated=String()).validate(1)
    # Test assertion 'error'
    try:
        Not(negated=String()).validate(1)
    except AssertionError as error:
        assert error.args[0] == 'Expected to error.'

    # Expected to error
    try:
        Not(negated=String()).validate(1)
    except ValidationError as error:
        assert error.code == 'negated'
    else:
        raise AssertionError('Expected to error.')

    # Expected to be valid

# Generated at 2022-06-24 10:42:54.179409
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    none = None
    schema = {"oneOf": [{"type": "string"}, {"type": "boolean"}]}
    instance = "a"
    expected_result = ("a", False)
    test_result = None
    field = OneOf([None, None])
    field.errors = {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    test_result = field.validate(instance, True)
    if test_result == expected_result:
        print("Unit test for method validate of class OneOf passed!")
    else:
        print("Unit test for method validate of class OneOf failed!")



# Generated at 2022-06-24 10:42:54.621939
# Unit test for method validate of class AllOf
def test_AllOf_validate():
	pass

# Generated at 2022-06-24 10:42:56.471477
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Any()])
    field.validate(value=None, strict=False)

# Generated at 2022-06-24 10:43:07.238369
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Any(accepts_all=True, allow_null=True), Int(max_value=5), Map(value_type=Int())])
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate({}) == {}
    assert field.validate({1:1}) == {1:1}
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({1:1,2:2}) == {1:1,2:2}
    assert field.validate([1,2,3]) == [1,2,3]
    assert field.validate([1,2,3.0]) == [1,2,3.0]

# Generated at 2022-06-24 10:43:09.953116
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """
    Unit test for constructor of class NeverMatch
    """
    x = NeverMatch()
    assert x.validate({"bob":"jones"}) == "Error"

# Generated at 2022-06-24 10:43:14.956185
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    try:
        field.validate(None)
        assert(False)
    except:
        assert(True)


# Generated at 2022-06-24 10:43:17.704882
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    msg = NeverMatch()
    with pytest.raises(TypeError):
        msg.validate("10")


# Generated at 2022-06-24 10:43:20.390548
# Unit test for constructor of class AllOf
def test_AllOf():
    def setUp(self):
        self.all_of = []
        self.kwargs={}
    config = {
        'setup': setUp,
        'kwargs': {}
    }
    check_type_factory('AllOf', config)



# Generated at 2022-06-24 10:43:27.429928
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    result_positive_testcase_1 = None
    result_negative_testcase_1 = None

    result_positive_testcase_2 = None
    result_negative_testcase_2 = None

    # positive test case!
    try:
        num = [1,2,3,4]
        new = OneOf(num)
        result_positive_testcase_1 = new.validate(3)
    except Exception:
        pass
    # negative test case!
    try:
        num = [1,2,3,4]
        new = OneOf(num)
        result_negative_testcase_1 = new.validate(5)
    except Exception:
        pass
    
    # positive test case!

# Generated at 2022-06-24 10:43:29.732515
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Any())
    assert not_field.__dict__.get("negated") is not None


# Generated at 2022-06-24 10:43:38.223009
# Unit test for constructor of class AllOf
def test_AllOf():
    #This Field will fail if all child validators fail, but if any child validator succeeds, then it will succeed
    types = [
        typesystem.String(max_length=10),
        typesystem.Boolean(),
    ]
    field = typesystem.AllOf(types)
    field.validate('a string')
    field.validate(True)
    with pytest.raises(typesystem.ValidationError): # Failing AllOf
        field.validate(11)


# Generated at 2022-06-24 10:43:39.015101
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch


# Generated at 2022-06-24 10:43:43.945635
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    '''
    Test code for testing constructor function of class IfThenElse
    '''
    test_input1 = Field()
    test_input2 = Field()
    test_input3 = Field()
    test_output = IfThenElse(test_input1, test_input2, test_input3)
    assert test_output.if_clause is test_input1
    assert test_output.then_clause is test_input2
    assert test_output.else_clause is test_input3
    assert test_output.allow_null is False
    assert test_output.name is None


# Generated at 2022-06-24 10:43:49.549255
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import typesystem
    one_of_in_place = typesystem.OneOf([Any(), Any(), Any()])
    value = {"str": "str", "num": 123, "list": [1, 2, 3]}
    one_of_in_place.validate(value)
    one_of_raw = typesystem.OneOf([Any(), Any(), Any()])
    one_of_raw.validate(value)


# Generated at 2022-06-24 10:43:50.561239
# Unit test for constructor of class NeverMatch
def test_NeverMatch():

    assert isinstance(NeverMatch(), Field)

# Generated at 2022-06-24 10:43:53.231675
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    result, error = not_field.validate_or_error(2)
    assert error
    assert result is None


# Generated at 2022-06-24 10:43:55.273261
# Unit test for constructor of class Not
def test_Not():
	n = Not(Dict(properties={"hoge": Any()}, required=["hoge"]))
	return n


# Generated at 2022-06-24 10:44:04.152296
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # mock the field with error
    class IFClause(Field):
        def validate(self):
            raise Exception("IF clause error")

    # mock the field with error
    class ThenClause(Field):
        def validate(self):
            raise Exception("THEN clause error")

    # mock the field without error
    class ELSEClause(Field):
        def validate(self):
            pass

    # a test case where the IF clause is valid
    try:
        IfThenElse(IFClause(), ThenClause()).validate()
    except Exception as e:
        if str(e) == "IF clause error":
            pass

    # a test case where the IF clause is valid

# Generated at 2022-06-24 10:44:07.354672
# Unit test for constructor of class Not
def test_Not():
    pass

# Generated at 2022-06-24 10:44:10.073570
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = [NeverMatch(), NeverMatch()]
    field = OneOf(one_of)
    try:
        field.validate({}, strict=True)
    except Exception as e:
        return e.code == 'no_match'
    return False


# Generated at 2022-06-24 10:44:14.710335
# Unit test for constructor of class OneOf
def test_OneOf():
    class OneOf():
        def __init__(self, one_of: list) -> None:
            self.one_of = one_of
    assert OneOf([1,2,3]).one_of == [1,2,3]


# Generated at 2022-06-24 10:44:24.666046
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f1 = Field(label="f1")
    f2 = Field(label="f2")
    f3 = Field(label="f3")
    f4 = IfThenElse(if_clause=f1, then_clause=f2, else_clause=f3)
    f5 = IfThenElse(if_clause=f1, then_clause=f2, else_clause=f3)
    f6 = IfThenElse(if_clause=f1, then_clause=f2, else_clause=f3)
    f7 = IfThenElse(if_clause=f1, then_clause=f2, else_clause=f3)

# Generated at 2022-06-24 10:44:26.527566
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf == OneOf



# Generated at 2022-06-24 10:44:30.503250
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    test_types = [
        'alpha',
        1,
        1.1,
        False,
        None,
    ]

    field = NeverMatch()
    for value in test_types:
        error = field.validate(value)
        assert error == "This never validates."


# Generated at 2022-06-24 10:44:34.749118
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    schema = {
        "type": "object",
        "properties": {"x": {"type": "integer"}},
    }
    ns = NeverMatch()
    assert ns.validate(1) is not None



# Generated at 2022-06-24 10:44:37.291821
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    print("test_NeverMatch")
    field = NeverMatch()
    print(field.errors)


# Generated at 2022-06-24 10:44:39.300444
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    a = NeverMatch()
    with pytest.raises(a.validation_error):
        a.validate('a')


# Generated at 2022-06-24 10:44:44.744721
# Unit test for constructor of class AllOf
def test_AllOf():
    assert hasattr(AllOf, '__init__')
    assert callable(AllOf.__init__)


# Generated at 2022-06-24 10:44:46.723285
# Unit test for method validate of class Not
def test_Not_validate():
    myField = Not(String())
    myField.validate("TEST NOT")


# Generated at 2022-06-24 10:44:53.739360
# Unit test for method validate of class Not
def test_Not_validate():
    # 1. Arrange

    name = "name"
    msg = "Must not match."
    negated_field = Dict.of({"id": Integer().non_null()})
    not_field = Not(negated_field)

    # 2. Act
    result, error = not_field.validate_or_error({}, strict=False)

    # 3. Assert
    assert not error



# Generated at 2022-06-24 10:44:55.613758
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=None)
    assert field.negated is not None


# Generated at 2022-06-24 10:44:58.121255
# Unit test for constructor of class OneOf
def test_OneOf():
    x = [1,2,3]
    assert OneOf(x).one_of == x


# Generated at 2022-06-24 10:44:59.001700
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(String())


# Generated at 2022-06-24 10:45:00.073650
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate(1) is None


# Generated at 2022-06-24 10:45:01.473170
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    nm.validate()
    assert True

# Generated at 2022-06-24 10:45:10.320937
# Unit test for constructor of class OneOf
def test_OneOf():
    test_field = "test_field"
    test_nullable = False
    test_errorMessage = "There is an error in this field"
    test_defaultValue = 0
    test_required = True
    test_description = "This is a test"
    test_one_of = "test_one_of"
    x = OneOf(one_of = test_one_of, required = test_required, description = test_description, default = test_defaultValue, nullable = test_nullable, error_messages = test_errorMessage, name = test_field)
    assert x.one_of == test_one_of


# Generated at 2022-06-24 10:45:18.395908
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = String(max_length=10)
    then_clause = String(min_length=10)
    else_clause = String(min_length=0)
    str_test = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    assert str_test.validate("a"*10) == "a"*10
    assert str_test.validate("a"*9) == "a"*9
    assert str_test.validate("a"*5) == "a"*5
    assert str_test.validate("a"*11) is None
    assert str_test.validate("") == ""

# Generated at 2022-06-24 10:45:27.564618
# Unit test for constructor of class AllOf

# Generated at 2022-06-24 10:45:38.198696
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import String, Integer, Boolean
    from typesystem.fields import Any
    from typesystem import ValidationError
    a = AllOf(all_of=[String(max_length=10), Integer(maximum=20)])
    b = AllOf(all_of=[String(max_length=10), Integer(maximum=20), Boolean()])
    
    a.validate("Hello world")
    a.validate(15)
    
    with pytest.raises(ValidationError):
        a.validate(25)
    
    with pytest.raises(ValidationError):
        a.validate("lorem ipsum")
    
    b.validate("Hello world")
    b.validate(15)
    b.validate(True)
    b.validate(False)
    

# Generated at 2022-06-24 10:45:42.549347
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Create an instance of NeverMatch
    nv = NeverMatch()

    # Test the validate() method
    with pytest.raises(ValidationError) as excinfo:
        nv.validate('abc')
    assert 'never' in str(excinfo.value)


# Generated at 2022-06-24 10:45:49.525063
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    S1 = String()
    S2 = String(max_length=10)
    S3 = String(min_length=20)
    # Def: all_of: [field1, field2, ...]
    # When field1, field2, ... are all True
    # Expect: True
    result = AllOf([S1,S2,S3]).validate('Hello World!')
    assert result == 'Hello World!'
    # When field1 ,field2 or ... is False
    # Expect: "ValidationError"
    with pytest.raises(ValidationError):
        AllOf([S1, S2, S3]).validate('1')


# Generated at 2022-06-24 10:45:50.548653
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-24 10:45:52.339499
# Unit test for constructor of class OneOf
def test_OneOf():
    '''
    Test OneOf constructor
    '''
    assert OneOf.__init__

# Generated at 2022-06-24 10:45:53.999861
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of_field = [Any()]
    assert one_of_field is not None


# Generated at 2022-06-24 10:46:00.236818
# Unit test for constructor of class Not
def test_Not():
    # Test with no additional fields.
    not_field = Not(AllOf([Any()]))
    assert not_field.negated == AllOf([Any()])

    # Test with additional key words
    not_field = Not(AllOf([Any()]), error_messages={'a': 'b'})
    assert not_field.negated == AllOf([Any()])
    assert not_field.error_messages['a'] == 'b'



# Generated at 2022-06-24 10:46:03.583935
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import pytest
    with pytest.raises(AssertionError) as excinfo:
        NeverMatch().validate(None)
    assert 'Did not match any valid type.' in str(excinfo.value)


# Generated at 2022-06-24 10:46:05.201202
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(None)
    assert not_field.negated == None


# Generated at 2022-06-24 10:46:07.713685
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import Integer
    check_value = Not(Integer(-10,10)).validate(-20)
    assert(check_value == -20)


# Generated at 2022-06-24 10:46:11.468619
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ifThenElse = IfThenElse(AllOf([]), Any())
    ifThenElse = IfThenElse(AllOf([]), Any(), Any())


# Generated at 2022-06-24 10:46:14.201794
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf(all_of=[Any(), Any()])
    assert all_of.validate(0) == 0

# Generated at 2022-06-24 10:46:18.799379
# Unit test for constructor of class AllOf
def test_AllOf():
    definition = {
        "allOf": [
            {"type": "string"},
            {"type": "string"},
            {"type": "number"},
        ],
    }
    field = AllOf.from_json(definition)

    assert field.validate("Hi")
    assert field.validate(3)
    assert not field.validate(True)


# Generated at 2022-06-24 10:46:21.244649
# Unit test for constructor of class OneOf
def test_OneOf():
    class A:
        def __init__(self, x, y, z):
            self.x = x
            self.y = y
            self.z = z
    a = A("1", "2", "3")
    one_of = OneOf([a])

# Generated at 2022-06-24 10:46:26.169209
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=NeverMatch(),
    )
    assert field.validate("value") == "value"


# Generated at 2022-06-24 10:46:27.952632
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field, NeverMatch)



# Generated at 2022-06-24 10:46:30.882564
# Unit test for constructor of class AllOf
def test_AllOf():
    from .date import Date
    from .datetime import DateTime
    from .string import String
    from .uuid import UUID
    AllOf([Date(), DateTime()])

# Generated at 2022-06-24 10:46:32.724929
# Unit test for constructor of class Not
def test_Not():
    assert Not.__name__ == "Not"
    assert Not.__doc__ == None


# Generated at 2022-06-24 10:46:34.297099
# Unit test for constructor of class OneOf
def test_OneOf():
    d = [1, 2, 3]
    x = OneOf(d)

    # assert x.one_of is d


# Generated at 2022-06-24 10:46:37.745872
# Unit test for constructor of class AllOf
def test_AllOf():
    all_ofs = []
    field = AllOf(all_ofs)
    field.validate("test")


# Generated at 2022-06-24 10:46:40.970107
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    assert IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-24 10:46:45.903862
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.base import TypeSystem
    from typesystem.enum import Enum
    from typesystem.fields import String
    from typesystem.json_schema import JsonSchemaTypeSystem

    class TestSchema(TypeSystem):
        field = AllOf([
            String(max_length=3),
            Enum(["a", "b", "c"])
        ])

    schema = TestSchema()
    schema.field.validate("a")
    schema.field.validate("ab")



# Generated at 2022-06-24 10:46:47.697758
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    fld = NeverMatch()
    with pytest.raises(ValidationError) as ex:
        fld.validate(1)
    with pytest.raises(ValidationError) as ex:
        fld.validate("name")


# Generated at 2022-06-24 10:46:48.942090
# Unit test for constructor of class Not
def test_Not():
    example = Not(String(), name = 'test')

# Generated at 2022-06-24 10:46:51.174819
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Integer(minimum=1, maximum=5), String()])
    field.validate(3)
    field.validate("Hello")

# Generated at 2022-06-24 10:46:54.678387
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Field(name="1"),Field(name="2")])
    assert one_of.validate(1) == 1

test_OneOf_validate()


# Generated at 2022-06-24 10:46:58.831387
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field
    assert field.negated
    assert isinstance(field.negated, Field)

    def create_with_type_error():
        field2 = Not()

    assert create_with_type_error



# Generated at 2022-06-24 10:47:02.160804
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    f = IfThenElse(1, 2, 3)
    assert f.if_clause == 1
    assert f.then_clause == 2
    assert f.else_clause == 3


# Generated at 2022-06-24 10:47:06.083066
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    else_clause = NeverMatch()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert isinstance(if_then_else, IfThenElse)

# Generated at 2022-06-24 10:47:08.837961
# Unit test for method validate of class AllOf
def test_AllOf_validate():
  from typesystem import Integer
  from typesystem import String, Boolean
  a = AllOf(all_of=[String(), Integer()], default='test')
  assert a.validate('test') == 'test'


# Generated at 2022-06-24 10:47:14.638279
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Init a test object
    test_object = NeverMatch()

    # Test a value that should not be valid.
    with pytest.raises(test_object.validation_error) as error:
        test_object.validate("test value")

    # Check that the error contains the given message
    assert error.value.code == "never"


# Generated at 2022-06-24 10:47:15.917762
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}

# Generated at 2022-06-24 10:47:20.795664
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String
    a = String()
    t = AllOf([String()], default="test")
    assert t.validate("test") == "test"
    assert t.validate("test1") == "test1"
    assert t.validate(False) == False
    assert t.validate(None) == None
    assert t.validate(1) == 1
    assert t.validate(1.1) == 1.1
    assert t.validate("") == ""


# Generated at 2022-06-24 10:47:24.626283
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Test validating when types do match
    def the_test(test_case):
        # Create a Field containing a Boolean field containing a List field containing an Integer field containing a String field containing a given string
        field = AllOf([Boolean(), List([Integer(), String(test_case)])])
        result = field.validate(["1", "2"])
        # Check that the result is as expected
        assert(result == ["1", "2"])
    the_test("1")
    the_test("2")

    # Test validating when type doesn't match
    def the_test(test_case):
        # Create a Field containing a Boolean field containing a List field containing an Integer field containing a String field containing a given string
        field = AllOf([Boolean(), List([Integer(), String(test_case)])])
        # Check that an

# Generated at 2022-06-24 10:47:25.782632
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    error = "Error message"
    nm = NeverMatch(error)
    assert nm.errors == {"never": "Error message"}


# Generated at 2022-06-24 10:47:30.084223
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    #Is the assert of test_IfThenElse_validate() correct?
    from typesystem.fields import BaseField
    from typesystem.fields import String
    from typesystem.fields import Integer
    import pytest
    with pytest.raises(AssertionError):
        tt = IfThenElse(if_clause=Integer(), then_clause=String())

# Generated at 2022-06-24 10:47:34.659461
# Unit test for constructor of class AllOf
def test_AllOf():
    print('Test: AllOf')
    # Testcase 1
    # all_of = []
    # kwargs = {}
    # test = AllOf(all_of, **kwargs)
    # print('Testcase 1: ', test)

    # Testcase 2
    # all_of = []
    # kwargs = {}
    # test = AllOf(all_of, **kwargs)
    # print('Testcase 2: ', test)

    # Testcase 3
    # all_of = []
    # kwargs = {}
    # test = AllOf(all_of, **kwargs)
    # print('Testcase 3: ', test)


# Generated at 2022-06-24 10:47:35.665669
# Unit test for constructor of class Not
def test_Not():
    pass


# Generated at 2022-06-24 10:47:47.402278
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class one_of(Field):
        def __init__(self, one_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
            self.one_of = one_of

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            candidate = None
            match_count = 0
            for child in self.one_of:
                validated, error = child.validate_or_error(value, strict=strict)
                if error is None:
                    match_count += 1
                    candidate = validated

            if match_count == 1:
                return candidate
            elif match_count > 1:
                raise self.validation_error("multiple_matches")

# Generated at 2022-06-24 10:47:51.879948
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm is not None


# Generated at 2022-06-24 10:48:01.331470
# Unit test for method validate of class Not
def test_Not_validate():
    class MyField(Field):
        def validate(self, value, strict=False):
            return value

    my_field = MyField()

    # value matches negated_field
    negated = Not(my_field)
    _, error = negated.validate_or_error(2, strict=True)
    print(error)
    assert error.code == "negated"

    # value doesn't match negated_field
    negated = Not(my_field)
    _, error = negated.validate_or_error(None, strict=True)
    assert error is None

test_Not_validate()

# Generated at 2022-06-24 10:48:05.758257
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    x = NeverMatch()
    with pytest.raises(x.validation_error) as excinfo:
        x.validate('test')
    assert excinfo.value.code == 'never'


# Generated at 2022-06-24 10:48:14.527539
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class ValidateTest(unittest.TestCase):
        def setUp(self):
            self.one_of = OneOf([Int(), String()])

        def test_no_match(self):
            with self.assertRaises(ValidationError) as cm:
                self.one_of.validate(True)
            self.assertEqual([str(cm.exception)], self.one_of.errors['no_match'])

        def test_match_first(self):
            self.one_of.validate(5)

        def test_match_second(self):
            self.one_of.validate("five")

        def test_multiple_matches(self):
            with self.assertRaises(ValidationError) as cm:
                self.one_of.validate(6)

# Generated at 2022-06-24 10:48:15.276163
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:48:18.996770
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Field(required=False, allow_null=False), Field(required=False, allow_null=False)])
    assert field.validate('hello') == 'hello'


# Generated at 2022-06-24 10:48:22.358356
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test = IfThenElse(
        if_clause=Any(),
        then_clause=Not(negated=Number(minimum=5)),
        else_clause=Number(minimum=10),
    )
    expected = 10

    actual = test.validate(0)
    assert expected == actual



# Generated at 2022-06-24 10:48:23.253438
# Unit test for constructor of class AllOf
def test_AllOf():
    AllOf([])


# Generated at 2022-06-24 10:48:27.785301
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer

    class Meta:
        title = "AllOfTest"

    field = AllOf([Integer()], meta=Meta, description="Title")
    assert field.meta.title == Meta.title
    assert field.description == "Title"
    assert field.all_of == [Integer()]


# Generated at 2022-06-24 10:48:28.705000
# Unit test for constructor of class AllOf
def test_AllOf():
    pass

# Generated at 2022-06-24 10:48:31.935797
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="Never match") != NeverMatch(name="Match never")
    assert NeverMatch(name="Match never") != NeverMatch(name="Match mainly")