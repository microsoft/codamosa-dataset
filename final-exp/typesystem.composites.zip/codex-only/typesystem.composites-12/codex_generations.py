

# Generated at 2022-06-24 10:38:37.109659
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Any(), Any(), Any(), default=None, description='') is not None
    assert IfThenElse(Any(), Any(), Any(), default=None, description='').validate({}) is not None

# Generated at 2022-06-24 10:38:39.118408
# Unit test for constructor of class Not
def test_Not():
    simple_type = Not(Field(str))
    assert simple_type.validate(5) == 5 and simple_type.validate('something') == 'something'


# Generated at 2022-06-24 10:38:40.771766
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import String
    from typesystem import Integer
    string = String()
    field = AllOf([string])
    assert field.all_of == [string]


# Generated at 2022-06-24 10:38:44.058819
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Boolean(strict=True)
    then_clause = Integer()
    else_clause = List(of=String(), allow_empty=False, strict=True)
    assert IfThenElse(if_clause, then_clause, else_clause, strict=True)

# Generated at 2022-06-24 10:38:45.586686
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nv_field = NeverMatch()
    assert nv_field.validate("abc") == "abc"
    

# Generated at 2022-06-24 10:38:47.755771
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert 'b' == IfThenElse(String('a'), String('b')).validate('a')
    assert 'a' == IfThenElse(String('a'), String('b')).validate('b')

# Test the subclasses of Field.

# Generated at 2022-06-24 10:38:49.269490
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = [{"OneOf": "string"}, 1]
    assert (OneOf(one_of).one_of == one_of)


# Generated at 2022-06-24 10:38:52.518029
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([IntField(max_value=0), IntField(min_value=10)])
    try:
        one_of.validate(5)
    except Exception as e:
        if not isinstance(e, FieldValidationError):
            raise
        assert e.error_code == "no_match"
    else:
        raise AssertionError("Expected exception.")



# Generated at 2022-06-24 10:38:54.769871
# Unit test for constructor of class OneOf
def test_OneOf():
    with pytest.raises(AssertionError):
        field = OneOf(one_of=[Any()], allow_null=False)
    
    field = OneOf(one_of=[Any()])
    assert field.validate({})



# Generated at 2022-06-24 10:38:58.674176
# Unit test for constructor of class Not
def test_Not():
    test = Not(AllOf([Any(),Any()]))
    assert test.negated == [Any(),Any()]
    assert test.errors == {'negated': 'Must not match.'}


# Generated at 2022-06-24 10:39:06.934394
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create OneOf class object
    field = OneOf(one_of=[String(), Number()])
    value = 1
    field.validate(value)
    assert field.validate(value) == value
    # Testing multiple matches
    field = OneOf(one_of=[String(), Number()])
    value = "string"
    assert field.validate(value) == value
    field = OneOf(one_of=[String(), Number()])
    value = [1, 2, 3]
    with pytest.raises(ValueError) as exinfo:
        field.validate(value)
    assert "multiple_matches" in str(exinfo.value)



# Generated at 2022-06-24 10:39:08.691171
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors["never"] == "This never validates."


# Generated at 2022-06-24 10:39:11.352086
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    myIfThenElse = IfThenElse(Field())
    assert myIfThenElse.if_clause is not None
    assert myIfThenElse.then_clause is not None
    assert myIfThenElse.else_clause is not None

# Generated at 2022-06-24 10:39:14.690583
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert type(NeverMatch()) is NeverMatch


# Generated at 2022-06-24 10:39:22.988358
# Unit test for constructor of class Not
def test_Not():
    try:
        not_field = Not(Field(nullable=False))
        assert(False)
    except AssertionError:
        assert(True)
    not_field = Not(Any(), nullable=False)
    assert(not_field.validate(None) == None)
    assert(not_field.validate("") == None)
    assert(not_field.validate(0) == None)
    assert(not_field.validate(0.0) == None)
    assert(not_field.validate(False) == None)
    assert(not_field.validate(False) == None)
    assert(not_field.validate([]) == None)
    assert(not_field.validate({}) == None)

# Generated at 2022-06-24 10:39:25.359534
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class Item(Field):
        pass
    allof_field = AllOf([Item(), Item()])
    assert allof_field.validate("hello") == "hello"



# Generated at 2022-06-24 10:39:35.280217
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # setup
    class ExampleType(Any):
        pass

    class ExampleElseType(Any):
        pass
    class ExampleType2(Any):
        pass
    class ExampleElseType2(Any):
        pass
    value = ExampleType()
    value2 = ExampleType2()
    else_type = ExampleElseType()
    else_type2 = ExampleElseType2()
    example = IfThenElse(if_clause=value,then_clause=else_type,else_clause=else_type2)

    # info
    assert example.validate(value) == else_type
    assert example.validate(value2) == else_type2



# Generated at 2022-06-24 10:39:41.042289
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(Any(), Int())
    field.validate(2)
    field.validate(1.1)
    field.validate("abc")
    try:
        field.validate("abc")
    except ValueError:
        pass
    field = IfThenElse(String(), String(), Int())
    field.validate("abc")
    field.validate(2)
    try:
        field.validate(1.1)
    except ValueError:
        pass



# Generated at 2022-06-24 10:39:43.770705
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field_instance = NeverMatch()
    with pytest.raises(FieldValidationError) as excinfo:
        field_instance.validate(None)
    assert excinfo.value.messages == {'never': ['This never validates.']}

# Generated at 2022-06-24 10:39:46.369040
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Field())
    n.validate(None)

# Generated at 2022-06-24 10:39:48.779350
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test1 = NeverMatch()
    test2 = NeverMatch()
    assert test1 is not test2



# Generated at 2022-06-24 10:39:50.394439
# Unit test for constructor of class Not
def test_Not():
    # fails: can't have null in Not
    assert Not(String(allow_null=False))


# Generated at 2022-06-24 10:39:51.280774
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("123") == "123"

# Generated at 2022-06-24 10:39:53.781956
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.integer import Integer
    my_all_of: AllOf = AllOf([Integer()])
    assert my_all_of is not None

# Generated at 2022-06-24 10:40:00.562266
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Test correct validation.
    all_of = AllOf([Any(min_length=1), Any()])
    all_of.validate("s")

    # Test incorrect validation.
    try:
        all_of.validate("")
    except Exception as e:
        print(str(e))
        # "Field is too short."
        assert("Field is too short." == str(e))


# Generated at 2022-06-24 10:40:02.835756
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([Any()])
    assert field.all_of == [Any()]


# Generated at 2022-06-24 10:40:05.458189
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(children)
    assert all_of is not None


# Generated at 2022-06-24 10:40:06.047980
# Unit test for method validate of class Not
def test_Not_validate():
  pass

# Generated at 2022-06-24 10:40:11.519506
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse.validate(IfThenElse, 1, 2)==1
    assert IfThenElse.validate(IfThenElse, 1, 2, 3)==2
    assert IfThenElse.validate(IfThenElse, 1, None, 3)==3
    assert IfThenElse.validate(IfThenElse, 1, None, None)==1



# Generated at 2022-06-24 10:40:18.098614
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String, Integer
    all_numbers = OneOf([Integer(), String()])
    assert all_numbers.validate(3) == 3
    all_numbers.validate_or_error("a")
    from typesystem import ValidationError
    try:
        all_numbers.validate(False)
        assert False
    except ValidationError as e:
        assert e.messages == {"no_match": "Did not match any valid type."}
    all_bytes = OneOf([b"\x04", b"\x06", b"\t"])
    assert all_bytes.validate(b"\t") == b"\t"

# Generated at 2022-06-24 10:40:20.237917
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    unit = OneOf([])
    assert unit.validate(10) == 10

# Generated at 2022-06-24 10:40:23.002420
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(Any(), attribute='a')
    assert not_.negated.attribute == 'a'
    assert not_.attribute == 'a'


# Generated at 2022-06-24 10:40:23.979907
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    type_ = NeverMatch()


# Generated at 2022-06-24 10:40:27.598445
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(None)
    if a.if_clause or a.then_clause or a.else_clause:
        raise AssertionError("The constructor of IfThenElse class is broken")

# Unit test case for validating the input

# Generated at 2022-06-24 10:40:34.087063
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # testing the constructor with different inputs.
    A = IfThenElse(1, 2, 3)
    assert(A.if_clause == 1)
    assert(A.then_clause == 2)
    assert(A.else_clause == 3)
    B = IfThenElse(1, 2)
    assert(B.if_clause == 1)
    assert(B.then_clause == 2)
    assert(B.else_clause == Any())
    C = IfThenElse(1)
    assert(C.if_clause == 1)
    assert(C.then_clause == Any())
    assert(C.else_clause == Any())

# Generated at 2022-06-24 10:40:35.530483
# Unit test for constructor of class Not
def test_Not():
    field = Field()
    n_field = Not(field)
    assert n_field.negated == field


# Generated at 2022-06-24 10:40:39.662286
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
	# Arrange
	field = NeverMatch()
	# Act and assert
	with pytest.raises(Exception):
		field.validate(10, True)



# Generated at 2022-06-24 10:40:47.308759
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Schema, String
    from typesystem.fields import Integer


# Generated at 2022-06-24 10:40:49.717673
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-24 10:40:52.582664
# Unit test for method validate of class Not
def test_Not_validate():
    test_case = {"foo": 1}
    field = Not(Not(Any(), description="foo"), description="bar")
    assert field.validate(test_case) is test_case

# Generated at 2022-06-24 10:40:55.378868
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert 1 == 1


# Generated at 2022-06-24 10:41:01.084526
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=Any())
    assert n.validate(0) == 0
    try:
        n.validate(None)
    except:
        assert True
    else:
        assert False
    try:
        n.validate("")
    except:
        assert True
    else:
        assert False
    assert n.validate([]) == []


# Generated at 2022-06-24 10:41:03.446785
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([])
    with pytest.raises(AssertionError):
        field.validate(object())


# Generated at 2022-06-24 10:41:06.626210
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(OneOf([Any()]))
    val = field.validate("a")
    assert val == "a"

# Generated at 2022-06-24 10:41:07.573024
# Unit test for constructor of class Not
def test_Not():
    assert Not(NeverMatch())

# Generated at 2022-06-24 10:41:10.732827
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=String())
    assert not_field.negated==String()


# Generated at 2022-06-24 10:41:20.004037
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    list = [
        {"field1": AllOf([
            {"field1": String()},
            {"field1": Field()}, 
            ], **{}),
         "field2": String(),
        },
        {"field2": Field()}, 
        ]
    schema = AllOf(list, **{})
    schema.validate(value={
        "field1": "hello",
        "field2": "world",
    })
    # test error
    list = [{"field1": AllOf([{"field1": Field()}, {"field1": Field()}, ], **{}), "field2": Field(), }, {"field2": Field(), }, ]
    schema = AllOf(list, **{})

# Generated at 2022-06-24 10:41:21.093189
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert 0


# Generated at 2022-06-24 10:41:21.715576
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-24 10:41:26.458712
# Unit test for method validate of class Not
def test_Not_validate():
    # Create instance of class Not
    not_schema = Not(negated = Integer(min_value = 2))

    # Test object returns correct output when function is called 
    assert not_schema.validate(3) == 3

    # Test object raises correct error message
    raises(Not.validation_error('negated'), not_schema.validate, 2)


# Generated at 2022-06-24 10:41:27.038006
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)

# Generated at 2022-06-24 10:41:32.178572
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # try the if clause
    f = IfThenElse(if_clause=Float())
    assert(f.if_clause == Float())
    assert(f.then_clause is None)
    assert(f.else_clause is None)

    # try the then clause
    f = IfThenElse(then_clause=Float())
    assert(f.if_clause is None)
    assert(f.then_clause == Float())
    assert(f.else_clause is None)
    
    # try the else clause
    f = IfThenElse(else_clause=Float())
    assert(f.if_clause is None)
    assert(f.then_clause is None)
    assert(f.else_clause == Float())

    # now try if/then/else
    f = If

# Generated at 2022-06-24 10:41:34.400485
# Unit test for method validate of class Not
def test_Not_validate():
    with pytest.raises(typesystem.errors.ValidationError):
        Not(String()).validate("foo")

# Generated at 2022-06-24 10:41:37.617836
# Unit test for constructor of class OneOf
def test_OneOf():
    one_Of = OneOf([0, 1])
    expected = type(one_Of)
    actual = OneOf
    assert expected == actual


# Generated at 2022-06-24 10:41:41.830572
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a1 = Int(required=True)
    a2 = Int(required=True)
    allOf_field = AllOf([a1, a2])
    assert allOf_field.validate(5) == 5
    assert allOf_field.validate('a')


# Generated at 2022-06-24 10:41:46.976242
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import typesystem
    from typesystem.fields import String, Boolean, Any

    a = String()
    b = Boolean()
    c = Any()
    assert IfThenElse(if_clause=a,then_clause=b,else_clause=c,nullable=True).validate(True)==True
    assert IfThenElse(if_clause=a,then_clause=b,else_clause=c,nullable=True).validate('a')=='a'



# Generated at 2022-06-24 10:41:52.738026
# Unit test for method validate of class Not
def test_Not_validate():
    obj = Not(List(String()))

    res = obj.validate([])    
    assert res == []

    res = obj.validate(["a", "b"])
    assert res == ["a", "b"]
    

# Generated at 2022-06-24 10:41:58.638375
# Unit test for constructor of class OneOf
def test_OneOf():
    f = OneOf([Any(), Any()])
    assert f.errors["no_match"] == "Did not match any valid type."
    assert f.errors["multiple_matches"] == "Matched more than one type."
    assert f.one_of[0].errors["invalid"] == "Not a valid value."
    assert f.one_of[1].errors["invalid"] == "Not a valid value."


# Generated at 2022-06-24 10:42:03.680806
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf([String(), Number()])
    all_of.validate('123')
    with pytest.raises(ValidationError) as excinfo:
        all_of.validate('123.4')
    with pytest.raises(ValidationError) as excinfo:
        all_of.validate(123)



# Generated at 2022-06-24 10:42:04.381109
# Unit test for method validate of class Not
def test_Not_validate():
    # TBD
    pass


# Generated at 2022-06-24 10:42:10.277423
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()

    def validate(value, if_clause = if_clause,then_clause = then_clause, else_clause = else_clause,
    strict = False):
        error = if_clause.validate_or_error(value, strict=strict)

        if error is None:
            return then_clause.validate_or_error(value, strict=strict)
        else:
            return else_clause.validate_or_error(value, strict=strict)
    x = validate('abc')
    assert x == None
    x = validate('abc',if_clause = Any(), else_clause = Any())
    assert x == None

# Generated at 2022-06-24 10:42:17.096305
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.types import Type

    class Alarm(Type):
        alarm_timestamp = IfThenElse(Integer, then_clause=Integer())
        alarm_type = Integer()

    alarm = Alarm({"alarm_timestamp": 12345, "alarm_type":23})
    # Only the then clause is validate since if clause is satisfied
    assert(alarm.is_valid())

    alarm = Alarm({"alarm_timestamp": 12.34, "alarm_type":23})
    # Both clauses are validated since the if clause is not satisfied
    assert(alarm.is_valid())

# Generated at 2022-06-24 10:42:20.664364
# Unit test for constructor of class AllOf
def test_AllOf():
    test_field = AllOf([Field, AllOf])
    assert test_field.all_of == [Field, AllOf]

#Unit test for constructor of class Not

# Generated at 2022-06-24 10:42:30.278600
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = String()
    then_clause = String()
    else_clause = String()
    x = IfThenElse(if_clause, then_clause, else_clause)
    assert x.if_clause is if_clause
    assert x.then_clause is then_clause
    assert x.else_clause is else_clause
    x = IfThenElse(if_clause, then_clause)
    assert x.if_clause is if_clause
    assert x.then_clause is then_clause
    assert x.else_clause is Any()
    x = IfThenElse(if_clause)
    assert x.if_clause is if_clause
    assert x.then_clause is Any()
    assert x.else_clause is Any

# Generated at 2022-06-24 10:42:35.588957
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import ArrayValidationError, ValidationError
    from typesystem.fields import Array, Integer
    from typesystem.json_schema import AllOf, Object
    from typesystem.types import ObjectValidationError, StringValidationError

    class SubClass(AllOf):
        def __init__(self, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)

    field = SubClass(all_of=[Integer(), Integer()])
    assert field.validate(1) == 1
    assert field.validate(2) == 2
    with pytest.raises(ValidationError):
        field.validate(3)


# Generated at 2022-06-24 10:42:37.254767
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(1, 2, 3)



# Generated at 2022-06-24 10:42:47.367189
# Unit test for method validate of class Not
def test_Not_validate():
    # Case 1: negated value is valid
    # Expected output: validation error of class Not
    test_value = True
    test_error = True
    negated = Field(required=True)
    with pytest.raises(Field.validation_error):
        Not(negated=negated).validate(test_value, test_error)
    
    # Case 2: negated value is valid
    # Expected output: negated value
    test_value = False
    test_error = True
    negated = Field(required=True)
    assert Not(negated=negated).validate(test_value, test_error)==None



# Generated at 2022-06-24 10:42:51.777697
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    # unit test for method NeverMatch.validate
    value = None
    error = field.validate_or_error(value)
    # unit test for method NeverMatch.validate
    value = "foo"
    error = field.validate_or_error(value)


# Generated at 2022-06-24 10:42:57.107825
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem
    strict = False
    all_of = [typesystem.Integer(), typesystem.String()]
    field = AllOf(all_of)
    value = "1"
    assert field.validate(value, strict) == value



# Generated at 2022-06-24 10:43:03.493221
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(NeverMatch())
    value = None
    strict = False
    assert field.validate(value, strict) == value
    try:
        object = Not(Any())
        object.validate(value, strict)
        assert False
    except Exception as e:
        assert str(e) == 'Must not match.'
    try:
        object = Not(NeverMatch())
        value = 1
        object.validate(value)
        assert False
    except Exception as e:
        assert str(e) == 'Must not match.'


# Generated at 2022-06-24 10:43:05.845327
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([Strings, Numbers], allow_null=True)

# Generated at 2022-06-24 10:43:08.998931
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=Any())
    n.validate(5)

# Generated at 2022-06-24 10:43:18.770597
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ifthenelse1 = IfThenElse(AllOf([Any()]), then_clause = Any(), else_clause = Any())
    assert ifthenelse1 is not None
    ifthenelse2 = IfThenElse(AllOf([Any()]), then_clause = Any())
    assert ifthenelse2 is not None
    ifthenelse3 = IfThenElse(AllOf([Any()]))
    assert ifthenelse3 is not None


# Generated at 2022-06-24 10:43:19.414714
# Unit test for method validate of class Not
def test_Not_validate():
    Not()

# Generated at 2022-06-24 10:43:24.086719
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # JSON schema example
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    ite = IfThenElse(
        if_clause, then_clause, else_clause
    )
    assert ite.if_clause == if_clause
    assert ite.then_clause == then_clause
    assert ite.else_clause == else_clause

# Generated at 2022-06-24 10:43:28.239235
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    myfield = NeverMatch()
    with pytest.raises(myfield.validation_error):
        myfield.validate(None)

# Generated at 2022-06-24 10:43:29.810817
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        OneOf()
    except TypeError as error:
        print("Error:", error)


# Generated at 2022-06-24 10:43:32.907811
# Unit test for method validate of class Not
def test_Not_validate():
    Not(validators.Boolean()).validate(False)

# Generated at 2022-06-24 10:43:34.513591
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n


# Generated at 2022-06-24 10:43:35.629275
# Unit test for constructor of class OneOf
def test_OneOf():
    test_one_of = OneOf(one_of=[])
    assert test_one_of.one_of == []

# Generated at 2022-06-24 10:43:36.747815
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    neverMatch = NeverMatch()



# Generated at 2022-06-24 10:43:37.978553
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf(one_of=[])


# Generated at 2022-06-24 10:43:40.971383
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = IfThenElse(if_clause='', then_clause='', else_clause=None)
    assert if_clause.then_clause == Any()
    assert if_clause.else_clause == Any()

    another_if_clause = IfThenElse()
    assert another_if_clause.then_clause == Any()
    assert another_if_clause.else_clause == Any()

# Generated at 2022-06-24 10:43:44.812274
# Unit test for constructor of class Not
def test_Not():
    n = Not(None)
    assert n.errors == {"negated": "Must not match."}


# Generated at 2022-06-24 10:43:47.286758
# Unit test for constructor of class AllOf
def test_AllOf():
    # Create the object
    allOf = AllOf([Field(),Field()])

    # Check the attributes
    assert allOf.all_of == [Field(),Field()]


# Generated at 2022-06-24 10:43:54.269697
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    load_string = String()
    load_integer = String()
    load_number = String()
    load_boolean = String()
    load_null = String()
    load_array = String()
    load_object = String()
    AllOf([load_string, load_integer, load_number, load_boolean, load_null, load_array, load_object])


# Generated at 2022-06-24 10:43:58.080203
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # Initializes the test object
    test_obj = NeverMatch(name="test_obj", description="test")

    # Make sure the test program fails if calling validate
    with pytest.raises(ValueError):
        test_obj.validate("Hello")


# Generated at 2022-06-24 10:44:01.469604
# Unit test for constructor of class OneOf
def test_OneOf():
    class StringField(Field):
        def validate(self, value, strict=False):
            return value

    assert OneOf([StringField()], label='some_label').label == 'some_label'


# Generated at 2022-06-24 10:44:08.048771
# Unit test for constructor of class AllOf
def test_AllOf():
    fields = [
        {
            "type": "number",
            "minimum": 5,
            "exclusiveMinimum": True,
            "title": "Current value",
            "description": "Current value",
            "readOnly": False,
            "multipleOf": 1.0,
            "maximum": 25,
            "exclusiveMaximum": True
        },
        {
            "type": "number",
            "minimum": 4,
            "exclusiveMinimum": True,
            "title": "Current value",
            "description": "Current value",
            "readOnly": False,
            "multipleOf": 1.0,
            "maximum": 26,
            "exclusiveMaximum": True
        }
    ]
    field_objs = [
        Field.from_dict(field) for field in fields
    ]
    all_of_field = All

# Generated at 2022-06-24 10:44:11.026580
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    A = NeverMatch()
    B = A.validate(4)
    # AssertionError: This never validates.
    print(B)

# Generated at 2022-06-24 10:44:17.019455
# Unit test for constructor of class OneOf
def test_OneOf():
    type_list = [Int(min_value=4), Int(min_value=40), Int(min_value=400)]
    a = OneOf(one_of = type_list)
    assert a.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}
    assert a.one_of == type_list


# Generated at 2022-06-24 10:44:18.644429
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert(field)


# Generated at 2022-06-24 10:44:22.369766
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    field = IfThenElse(
        if_clause = Integer(),
        then_clause = Integer(),
        else_clause = String()
    )
    field.validate(3)
    field.validate("not a number")

    import pytest
    with pytest.raises(ValueError):
        field.validate(None)

# Generated at 2022-06-24 10:44:24.440937
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # type: () -> None
    """
    Unit test for method validate of class OneOf
    """
    pass

# Generated at 2022-06-24 10:44:28.865306
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field_options = dict()
    name = 'f'
    required = False
    _NeverMatch = NeverMatch(name)
    assert _NeverMatch.get_name() == 'f'
    assert _NeverMatch.get_required() == False


# Generated at 2022-06-24 10:44:29.462847
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass

# Generated at 2022-06-24 10:44:30.051620
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert 1 == 1, "Fail"

# Generated at 2022-06-24 10:44:31.368497
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()


# Generated at 2022-06-24 10:44:33.796809
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Number(),String()]
    assert AllOf(all_of).validate("test") == "test"

# Generated at 2022-06-24 10:44:39.849699
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import AllOf, Boolean, Integer, String
    field = AllOf([Boolean(), Integer(), String()])
    value = field.validate(False, strict=True)
    assert value == False
    value = field.validate(1, strict=True)
    assert value == 1
    value = field.validate('text', strict=True)
    assert value == 'text'


# Generated at 2022-06-24 10:44:48.201102
# Unit test for method validate of class Not
def test_Not_validate():
    # Initialize field
    field = Not(negated=Any())
    field.error_messages = {}
    # Check validation
    if field.validate(None) is not None or field.validate(True) is not True:
        raise Exception('Value not valid')
    try:
        field.validate(None)
    except Exception as e:
        raise Exception('Value not valid:' + str(e))



# Generated at 2022-06-24 10:44:50.650308
# Unit test for method validate of class Not
def test_Not_validate():
     not_field = Not(negated=Field())
     assert not_field.validate(True)

# Generated at 2022-06-24 10:44:52.936582
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test for class constructor
    assert issubclass(NeverMatch, Field)


# Generated at 2022-06-24 10:45:00.297874
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test case data
    oneof_data = {
        "one_of": [
            Field("1"),
            Field("2"),
            Field("3")
        ]
    }

    # Perform the test
    oneof_field = OneOf(**oneof_data)

    # Perform tests
    assert oneof_field.name == "OneOf"
    assert oneof_field.required == True
    assert oneof_field.one_of == [Field("1"), Field("2"), Field("3")]
    assert oneof_field.errors == {
        "no_match": "Did not match any valid type.",
        "multiple_matches": "Matched more than one type."
    }



# Generated at 2022-06-24 10:45:02.676307
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    input = ['abc', 'abc']
    f = AllOf([Any()])
    f.validate(input)
    assert True


# Generated at 2022-06-24 10:45:04.370229
# Unit test for constructor of class Not
def test_Not():
    assert Not(None).negated == None

# Generated at 2022-06-24 10:45:13.097986
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    from typesystem.base import ValidationError

    field = IfThenElse(Integer(), Integer())

    assert field.validate(1) == 1
    try:
        field.validate(1.5)
        assert False
    except ValidationError:
        pass

    field.if_clause = Integer()
    field.then_clause = Integer(maximum=5)
    field.else_clause = Integer(minimum=6)

    assert field.validate(5) == 5
    assert field.validate(6) == 6

    try:
        field.validate(1.5)
        assert False
    except ValidationError:
        pass

    try:
        field.validate(-5)
        assert False
    except ValidationError:
        pass



# Generated at 2022-06-24 10:45:16.902889
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    b = NeverMatch()
    assert b.name is None
    assert b.get_schema() == {'type': 'never'}


# Generated at 2022-06-24 10:45:21.194517
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.base import ValidationError
    from typesystem.fields import Integer

    field = Not(Integer())
    assert field.validate(1) == 1
    try:
        field.validate(2)
        assert False
    except ValidationError as e:
        assert e.code == "negated"

# Generated at 2022-06-24 10:45:27.183186
# Unit test for method validate of class Not
def test_Not_validate():
    not_test = Not(negated=Any())
    assert not_test.validate(value=None) == None
    assert not_test.validate(value='0') == '0'
    assert not_test.validate(value=0) == 0
    assert not_test.validate(value={}) == {}
    assert not_test.validate(value=[]) == []
    assert not_test.validate(value=()) == ()
    assert not_test.validate(value=False) == False
    assert not_test.validate(value=True) == True

# Generated at 2022-06-24 10:45:29.208604
# Unit test for method validate of class AllOf
def test_AllOf_validate():
  test = AllOf([Int(), Float()])
  assert test.validate(1) == 1

# Generated at 2022-06-24 10:45:31.483665
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import Integer

    field = Not(Integer())
    print(field.negated)

# Generated at 2022-06-24 10:45:33.582873
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match = NeverMatch()
    assert never_match.validate(value=0) == 0


# Generated at 2022-06-24 10:45:35.117409
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
	s = IfThenElse(Integer(),Integer())


# Generated at 2022-06-24 10:45:37.417290
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf(children=[
        Any(),
        Any(),
        Any(),
    ])

    assert all_of.validate(10) == 10



# Generated at 2022-06-24 10:45:41.889586
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch()
    with pytest.raises(FieldError) as info:
        nm.validate_or_error(123)
    assert info.match("never")
    assert info.match("This never validates.")


# Generated at 2022-06-24 10:45:48.252757
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A(Field):
        def validate(self, value):
            if value == "a":
                return "correct"
            else:
                return self.validation_error()

    class B(Field):
        def validate(self, value):
            if value == "b":
                return "correct"
            else:
                return self.validation_error()

    clause = IfThenElse(A(), then_clause=B())
    assert clause.validate("a") == "correct"

# Generated at 2022-06-24 10:45:57.510188
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    field = IfThenElse(IfThenElse(Integer()), Integer())
    field.validate(3)
    field.validate(2.1)
    
    field = IfThenElse(Integer(), Integer())
    field.validate(3)
    with pytest.raises(ValidationError):
        field.validate(2.1)

    field = IfThenElse(Integer(), None, Integer())
    with pytest.raises(ValidationError):
        field.validate(3)
    field.validate(2.1)

    field = IfThenElse(Integer(), None, None)
    with pytest.raises(ValidationError):
        field.validate(3)
    with pytest.raises(ValidationError):
        field.validate(2.1)


# Generated at 2022-06-24 10:45:59.935963
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Any())
    assert field.negated == Any()

# Generated at 2022-06-24 10:46:05.365137
# Unit test for method validate of class Not
def test_Not_validate():
    class CustomField(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise self.validation_error("This is a custom field.")

    not_custom_field = Not(CustomField())
    not_custom_field.validate(1)

# Generated at 2022-06-24 10:46:06.197623
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-24 10:46:11.287210
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String
    field = AllOf([String()])
    error_msg_1 = field.validate(['a', 'b'])
    error_msg_2 = field.validate(None)
    error_msg_3 = field.validate('a')
    assert (error_msg_1 == {'__all__': ['Item [0]: Must be a string.', 'Item [1]: Must be a string.']})
    assert (error_msg_2 == {'__all__': ['Must be a string.']})
    assert (error_msg_3 == None)


# Generated at 2022-06-24 10:46:15.244966
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with raises(ValidationError) as excinfo:
        field.validate(1)
    assert excinfo.value.code == "never"
    assert excinfo.value.field == field


# Generated at 2022-06-24 10:46:16.242758
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([Any()])

# Generated at 2022-06-24 10:46:25.648696
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate("") == ""
    assert field.validate("text") == "text"
    assert field.validate(b"") == b""
    assert field.validate(b"text") == b"text"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({"a": 1}) == {"a": 1}

# Generated at 2022-06-24 10:46:30.838147
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String

    class TestString(Not):
        def __init__(self, negated: String):
            super().__init__(negated)

    test_string1=TestString(String('hello'))
    assert test_string1.validate('hello') != 'hello', 'Negation failed'


# Generated at 2022-06-24 10:46:37.314113
# Unit test for method validate of class Not
def test_Not_validate():
    class Address(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise self.validation_error("negated")
    # Test case 1:
    test = Not(Address(), allow_null=True)
    # Test case 2:
    test_2 = Not(Address(), allow_null=True)
if __name__ == '__main__':
    test_Not_validate()

# Generated at 2022-06-24 10:46:45.978936
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class ErrorClass(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            raise self.validation_error("error")
    class ValidClass(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    valid = AllOf([ValidClass()])
    valid.validate(1)
    try:
        invalid = AllOf([ErrorClass(), ErrorClass()])
        invalid.validate(2)
    except ValidationError:
        assert True
    else:
        assert False
    try:
        invalid = AllOf([ErrorClass(), ValidClass()])
        invalid.validate(2)
    except ValidationError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 10:46:49.372426
# Unit test for constructor of class Not
def test_Not():
    """
    Test that constructor of class "Not" is working
    """
    field = Not(negated=AllOf([Int(), String()]))
    assert field.negated is not None



# Generated at 2022-06-24 10:46:52.187679
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_ = True
    then_ = "test_true"
    else_ = "test_false"
    IfThenElse(if_, then_, else_)

# Generated at 2022-06-24 10:46:59.806878
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import (
        Array,
        Boolean,
        Integer,
    )
    from typesystem.exceptions import ValidationError
    from typesystem.types import Null
    from typesystem.validators import Pattern
    from typesystem.core.utils import contains_any

    # positive test case
    if_clause = Integer(
        maximum=100,
        required=True,
    )
    then_clause = Array(
        items=Boolean(
            required=True,
        ),
        max_items=10,
    )

    conditional_type = IfThenElse(
        if_clause=if_clause,
        then_clause=then_clause,
    )

    # negative test case

# Generated at 2022-06-24 10:47:09.089737
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def _validate_field_correct(field):
        return isinstance(field, Field) and field.validate_correct is None
    def _validate_field_incorrect(field):
        return isinstance(field, Field) and field.validate_incorrect is None


# Generated at 2022-06-24 10:47:15.979344
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class SubClass(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
            # self.negated = negated

    negated = SubClass()
    if_clause = SubClass()
    then_clause = SubClass()
    else_clause = SubClass()

    a = IfThenElse(negated, if_clause, then_clause, else_clause)
    return a

# Generated at 2022-06-24 10:47:19.619784
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    try:
        n.validate('a')
    except Exception as exc:
        assert exc.args[0] == 'This never validates.'

# Generated at 2022-06-24 10:47:21.104421
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-24 10:47:22.987763
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Number())
    assert not_field.negated.errors == {}


# Generated at 2022-06-24 10:47:27.296017
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [Any()]
    field = OneOf(fields)
    # Verify all required attributes are present
    assert field.one_of == fields
    assert field.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}



# Generated at 2022-06-24 10:47:29.166672
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        field = OneOf()
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-24 10:47:34.884442
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(one_of=[Field()])
    assert one_of.validate(1) == 1

if __name__ == "__main__":
    test_OneOf_validate()

# Generated at 2022-06-24 10:47:46.457464
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = True
    then_clause = 2
    else_clause = 3
    if_clause_object = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    value = 5
    assert if_clause_object.validate(value) == 2

    if_clause = False
    then_clause = 2
    else_clause = 3
    if_clause_object = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    value = 5
    assert if_clause_object.validate(value) == 3

# Generated at 2022-06-24 10:47:47.340165
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-24 10:47:47.863358
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-24 10:47:50.419944
# Unit test for constructor of class Not
def test_Not():
    class MyField(Field):
        pass

    assert isinstance(Not(MyField()), Not)

# Generated at 2022-06-24 10:48:00.674180
# Unit test for constructor of class AllOf
def test_AllOf():
    # Testing for acceptable input
    class a(AllOf):
        def __init__(self, all_of: [Field], **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
            self.all_of = all_of
    class b(AllOf):
        def __init__(self, all_of: [Field], **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
            self.all_of = all_of
    a([Field("Field", int)])
    b([Field("Field", int), Field("Field1", int)])
    # Testing for null values in field list
    try:
        AllOf([None])
    except AssertionError:
        assert True

# Generated at 2022-06-24 10:48:04.457702
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class X(Field):
        def validate(self, value, strict=False):
            return value
    class Y(Field):
        def validate(self, value, strict=False):
            return Y
    class Z(Field):
        def validate(self, value, strict=False):
            return Z
    test_field = IfThenElse(Y(), X())
    assert test_field.then_clause == Any()
    assert test_field.else_clause == Any()
    test_field = IfThenElse(Z(), X(), Y())
    assert test_field.then_clause == X()
    assert test_field.else_clause == Y()

# Generated at 2022-06-24 10:48:09.801279
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    # valid
    string_value = "abc"
    value = field.validate(string_value)
    # invalid
    field = Not(Number())
    number_value = 123
    try:
        field.validate(number_value)
    except Exception:
        pass

# Generated at 2022-06-24 10:48:19.408278
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    test_data = [
        [
            "check if the validation matches all of the sub-items",
            {
                "all_of": [
                    Any(),
                    Any(description="description for any"),
                    Any(description="description for any"),
                ]
            },
            True,
        ],
        [
            "check that validation is raised if one of the sub-items fails",
            {"all_of": [Any(), NeverMatch()]},
            False,
        ],
    ]
    for description, kwargs, raises in test_data:
        with pytest.raises(Exception) == raises:
            # when
            AllOf(**kwargs).validate(1.2)



# Generated at 2022-06-24 10:48:22.369692
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert type(x) is NeverMatch
    assert type(x.name) is str
    assert type(x.description) is str


# Generated at 2022-06-24 10:48:23.587424
# Unit test for constructor of class AllOf
def test_AllOf():
    data = 'test'
    assert AllOf([Any()]).validate(data) is data

# Generated at 2022-06-24 10:48:29.716488
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem

    class A(typesystem.Schema):
        a = typesystem.String()

    allOf_field = AllOf([A, typesystem.Boolean()])

    # Case 1: value is valid
    assert (True, True) == allOf_field.validate_or_error(True)
    # Case 2: value is not valid
    assert isinstance(allOf_field.validate_or_error(None)[1], typesystem.ValidationError)

# Generated at 2022-06-24 10:48:32.003764
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        NeverMatch().validate(None)
        assert False
    except NotImplementedError:
        pass


# Generated at 2022-06-24 10:48:34.154756
# Unit test for constructor of class Not
def test_Not():
    import pytest
    a = Not(1)
    # The object must be an instance of Class Field not int
    with pytest.raises(AssertionError):
        Not(1)