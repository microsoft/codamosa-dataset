

# Generated at 2022-06-24 10:38:30.856652
# Unit test for constructor of class Not
def test_Not():
    Not(None)


# Generated at 2022-06-24 10:38:36.033238
# Unit test for constructor of class Not
def test_Not():
    class MyField(Not):
        def __init__(self, negated):
            super().__init__()

    assert issubclass(Not, Field)
    assert issubclass(MyField, Not)
    assert isinstance(Not(), Field)
    assert isinstance(MyField(""), Not)
    assert issubclass(MyField, Field)
    assert issubclass(MyField, Not)


# Generated at 2022-06-24 10:38:38.360885
# Unit test for constructor of class AllOf
def test_AllOf():
    Field1 = Field()
    Field2 = Field()

    AllOf([Field1,Field2])


# Generated at 2022-06-24 10:38:40.772543
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([Boolean()]).validate(True) == True
    assert AllOf([Boolean()]).validate(False) == False

    assert AllOf([String()]).validate("foo") == "foo"
    assert AllOf([String()]).validate("bar") == "bar"

# Generated at 2022-06-24 10:38:43.244839
# Unit test for method validate of class OneOf
def test_OneOf_validate():
  field = OneOf([])
  assert field.validate(None) == None
test_OneOf_validate()

# Generated at 2022-06-24 10:38:48.931592
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    n = 2
    field = AllOf([
        Field(name="must_be_int", validators=[InstanceOf(int)]),
        Field(name="must_be_even", validators=[InstanceOf(int)]),
    ])
    field.validate(n)



# Generated at 2022-06-24 10:38:50.876044
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with raises(AssertionError):
        NeverMatch(allow_null=True)
    assert NeverMatch(allow_null=False)
    assert NeverMatch()


# Generated at 2022-06-24 10:38:52.131077
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    assert n.validate(None) == None


# Generated at 2022-06-24 10:38:57.716636
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Float()])
    assert field.validate('a') == 'a'
    _, error = field.validate_or_error(7)
    assert error['code'] == 'no_match'
    _, error = field.validate_or_error(7.0)
    assert error is None


# Generated at 2022-06-24 10:39:02.006787
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(negated=object())
    assert n.validate(42) == 42
    try:
        n.validate(object())
    except Exception:
        pass
    else:
        raise AssertionError("Expected exception")



# Generated at 2022-06-24 10:39:02.972809
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-24 10:39:07.975999
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(min_length=2)])
    # test_OneOf_validate_valid
    value = "aabb"
    validation_result = field.validate(value)
    assert (validation_result == "aabb")

    # test_OneOf_validate_invalid
    value = "aa"
    with pytest.raises(ValidationError):
        field.validate(value)


# Generated at 2022-06-24 10:39:12.210821
# Unit test for constructor of class OneOf
def test_OneOf():
    Field1 = Integer()
    Field2 = String()
    list = []
    list.append(Field1)
    list.append(Field2)
    test = OneOf(one_of=list)
    assert test.name == "one_of"
    assert test.one_of == list
    assert test.errors == test.one_of[0].errors
    assert test.allow_null



# Generated at 2022-06-24 10:39:15.254477
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([Int()], format="int32")
    f.validate("123")


# Generated at 2022-06-24 10:39:26.997793
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer, String
    from .test_field import test_field
    field = OneOf([Integer(), String()]).bind(name="foo")
    test_field(field, "foo")

    # value 1 must match only integer
    assert field.validate(1) == 1

    # value '1' must match only string
    assert field.validate("1") == "1"

    # value 1.0 must match no one
    try:
        field.validate(1.0)
    except:
        pass
    else:
        assert False

    # value '1.0' must match no one
    try:
        field.validate("1.0")
    except:
        pass
    else:
        assert False

    # value [1, 2] must match no one

# Generated at 2022-06-24 10:39:30.733992
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError):
        field.validate(1)


# Generated at 2022-06-24 10:39:37.474406
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    oneOf = OneOf([
        Any(pattern=None),
        Any(pattern="text"),
        Any(pattern='http.//'),
    ])
    ifThenElse = IfThenElse(oneOf, then_clause=Any(pattern='http.//'), else_clause=Any(pattern=None))
    value = 'http.//'

    ifThenElse.validate(value)
    return



# Generated at 2022-06-24 10:39:45.246947
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ''' Test for method validate of class IfThenElse'''
    # Define parameters
    ix1 = Number(gt=0)
    tx1 = Number(gt=5)
    ex1 = Number(eq=0)
    ix2 = Number(ge=7)
    tx2 = Number(le=12)
    ex2 = Number(eq=5)

    # Define tests

# Generated at 2022-06-24 10:39:53.206698
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import io
    import typesystem
    import sys
    import pytest
    f = io.StringIO()
    with pytest.raises(typesystem.Error) as excinfo:
        schema = typesystem.Schema(
            fields=(
                typesystem.String(
                    description="test"
                ),
            ),
        )
        schema.validate(
            data={
                "test": NeverMatch()
            }
        )
    assert str(
        excinfo.value
    ) == "test: This never validates."


# Generated at 2022-06-24 10:39:54.448929
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf([Any(), Any(), Any()])
    a.validate(1)

# Generated at 2022-06-24 10:40:01.954689
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import Integer
    field = AllOf([Integer(minimum=1, maximum=100), Integer(minimum=-100, maximum=-1)])
    assert field.validate(50) == 50
    assert field.validate(-50) == -50
    assert field.validate(0) == 0
    assert field.validate(101) == 101
    assert field.validate(-101) == -101


# Generated at 2022-06-24 10:40:13.708666
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case when to validate if_clause
    field = IfThenElse(Boolean(), Integer())
    field.validate(True)

    # Test case when not to validate if_clause
    field = IfThenElse(Boolean(), Integer())
    field.validate(1)

    # Test case when both then and else are empty
    field = IfThenElse(Boolean())
    field.validate(True)

    # Test case when both then and else are defined
    field = IfThenElse(Boolean(), String(), Integer())
    field.validate(False)

    # Test case when only then is defined
    field = IfThenElse(Boolean(), String())
    field.validate(True)
    field.validate(False)
    field.validate(1)
    
    # Test case when only else is defined


# Generated at 2022-06-24 10:40:14.539060
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([]) is not None


# Generated at 2022-06-24 10:40:20.704025
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    schema = AllOf(
        [
            Integer(description="this integer"),
            String(description="this string"),
        ]
    )
    assert schema.validate(2) == 2
    assert schema.validate("ha") == 'ha'
    with pytest.raises(TypeSystemError) as e:
        schema.validate(1.0)
    assert e.value.error_code == "multiple_errors"
    assert "this integer" in e.value.error_message
    assert "this string" in e.value.error_message


# Generated at 2022-06-24 10:40:23.202963
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    f = NeverMatch()
    assert f.name is None
    assert f.default is None
    assert "allow_null" not in f.metadata
    assert f.errors["never"] == "This never validates."


# Generated at 2022-06-24 10:40:26.376949
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError) as excinfo:
        field.validate('foo')
    assert str(excinfo.exconly()) == 'ValidationError: This never validates.'


# Generated at 2022-06-24 10:40:27.418475
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(Any(), Any()) is not None

# Generated at 2022-06-24 10:40:29.376556
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test init
    field = OneOf(one_of=[])
    assert field.one_of == []


# Generated at 2022-06-24 10:40:39.114134
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    from typesystem.types import Integer

    field = IfThenElse(
        if_clause = Integer(),
        then_clause = String(),
        else_clause = String(),
    )
    field_2 = IfThenElse(Integer())
    field_3 = IfThenElse(Integer(), else_clause = String())
    field_4 = IfThenElse(Integer(), then_clause = String())
    field_5 = IfThenElse(Integer(), then_clause = String(), else_clause = String())

# Generated at 2022-06-24 10:40:44.893173
# Unit test for constructor of class OneOf
def test_OneOf():
    class Alpha(Field):
        pass
    class Bravo(Field):
        pass
    field = OneOf(one_of=[Alpha(), Bravo()])
    assert field.one_of == [Alpha(), Bravo()]
    assert field.errors == {
    "no_match": "Did not match any valid type.",
    "multiple_matches": "Matched more than one type."
    }
    assert field.label == None


# Generated at 2022-06-24 10:40:49.071139
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # class NeverMatch(Field):
    # def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
    # raise self.validation_error("never")

    nm = NeverMatch()
    try:
        nm.validate("string value")
    except:
        pass
    assert True


# Generated at 2022-06-24 10:40:52.235091
# Unit test for constructor of class AllOf
def test_AllOf():
    l = Field()
    all_of_ = AllOf(all_of=[l])
    assert all_of_.all_of == [l]


# Generated at 2022-06-24 10:40:53.833414
# Unit test for constructor of class Not
def test_Not():
    error = Not(Field())
    assert error.__init__(None) is None


# Generated at 2022-06-24 10:40:57.195314
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        field = NeverMatch()
        text = "This never validates."
        field.validate(text)
        assert(False) # The code did not raise an exception
    except:
        assert(True) # The code raised an exception as expected


# Generated at 2022-06-24 10:41:02.581654
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(integer())
    assert field.validate(1.0) == 1.0, "Error in test 1"

    try:
        field.validate(1)
        err = "Error in test 2"
    except ValidationError as e:
        assert str(e) == "Must not match.", "Error in test 2"
    else:
        raise AssertionError(err)


# Generated at 2022-06-24 10:41:05.630088
# Unit test for constructor of class Not
def test_Not():
    simple_field = Field(name='test')
    not_simple_field = Not(negated=simple_field, name='test')
    assert not_simple_field.negated == simple_field

# Generated at 2022-06-24 10:41:12.171302
# Unit test for constructor of class AllOf
def test_AllOf():
    # Init a non-null version of AllOf
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    test_field=IfThenElse(if_clause, then_clause, else_clause)
    # Comparing the fields of test_field and their expected values
    assert test_field.if_clause == if_clause
    assert test_field.then_clause == then_clause
    assert test_field.else_clause == else_clause
    assert test_field.validate("a") == "a"
    # Testing for null being passed in
    test_field=IfThenElse(None, None, None)
    assert test_field.if_clause == None
    assert test_field.then_clause == None
    assert test_field

# Generated at 2022-06-24 10:41:14.839207
# Unit test for constructor of class Not
def test_Not():
    n = Not(negated=Field())
    assert n.negated.__class__.__name__ == "Field"


# Generated at 2022-06-24 10:41:17.447905
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()
    assert n != None
    assert n.validate(None) != None


# Generated at 2022-06-24 10:41:27.513155
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    _int = Int()
    _str = String()
    _all = AllOf([_int,_str])
    _any = Any()
    a = IfThenElse(_int,_all)
    assert a.validate(12345) == 12345
    assert isinstance(a.validate(12345), int)
    assert a.validate("12345") == "12345"
    assert isinstance(a.validate("12345"), str)
    a = IfThenElse(_str,_int,_all)
    assert a.validate(12345) == 12345
    assert isinstance(a.validate(12345), int)
    assert a.validate("12345") == "12345"
    assert isinstance(a.validate("12345"), str)

# Generated at 2022-06-24 10:41:35.074840
# Unit test for constructor of class AllOf
def test_AllOf():
  from typing import Type

  class FieldA(Field):
    pass

  class FieldB(Field):
    pass

  type_test = AllOf([FieldA, FieldB])
  assert type(type_test.all_of) == list
  assert issubclass(type_test.all_of[0], Field) and issubclass(type_test.all_of[1], Field)
  assert type(type_test.all_of) is not Type



# Generated at 2022-06-24 10:41:45.520054
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    def test(field_self, value, strict, returned_value):
        field_self.if_clause.validate = lambda x, y: True

        if returned_value == None:
            field_self.then_clause.validate = lambda x, y: x
        else:
            field_self.then_clause.validate = lambda x, y: returned_value

        field_self.else_clause.validate = lambda x, y: returned_value

        assert field_self.validate(value, strict) == returned_value

    test(IfThenElse(Any()), None, None, 1)
    test(IfThenElse(Any()), None, None, None)
    test(IfThenElse(Any(), then_clause=Any(), else_clause=Any()), None, None, 1)
    test

# Generated at 2022-06-24 10:41:47.535465
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(NeverMatch.validation_error):
        NeverMatch().validate(5)


# Generated at 2022-06-24 10:41:51.569929
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field(name="must_match"))
    assert not_field.negated.name == "must_match"

# Generated at 2022-06-24 10:42:01.012714
# Unit test for constructor of class AllOf
def test_AllOf():
    #Test constructor with only required parameters
    test_AllOf = AllOf([Any()])
    assert isinstance(test_AllOf.all_of, list)

    #Test constructor with all possible parameters
    test_AllOf_full = AllOf([Any()], description="A field", title="A field", format="A field", default=5, enum=[5], const=5, multiple_of=5, minimum=5, maximum=5, exclusive_minimum=5, exclusive_maximum=5, min_length=5, max_length=5, pattern="A field", error_messages={"a": "a"}, required=True)
    assert test_AllOf_full.description == "A field"
    assert test_AllOf_full.title == "A field"
    assert test_AllOf_full.format == "A field"
    assert test

# Generated at 2022-06-24 10:42:01.622958
# Unit test for constructor of class Not
def test_Not():
    pass

# Generated at 2022-06-24 10:42:04.032433
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String())
    try:
        not_field.validate(1)
    except Exception as e:
        assert str(e)=="Must not match."

# Generated at 2022-06-24 10:42:06.019233
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    new_NeverMatch = NeverMatch()
    assert new_NeverMatch.errors == {"never": "This never validates."}
    assert new_NeverMatch.validation_error == {"never": ["This never validates."]}


# Generated at 2022-06-24 10:42:08.852505
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
  assert 1==1


# Generated at 2022-06-24 10:42:10.338733
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x=NeverMatch()
    assert x.validate(42)==None


# Generated at 2022-06-24 10:42:10.961186
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert 1==1

# Generated at 2022-06-24 10:42:14.927171
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    schema = NeverMatch()
    input_data = '1'
    try:
        schema.validate(input_data)
    except Exception as e:
        assert e.args[0]['number'] == 'never'
        assert e.args[0]['errors'][0]['number'] == 'never'


# Generated at 2022-06-24 10:42:16.059198
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert x.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:42:23.193223
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String
    field = OneOf([Integer(), String()])
    assert field.validate(None) == None
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    # Test case for TypeError
    try:
        assert field.validate(1.0) == 1.0
    except TypeError:
        return
    assert False



# Generated at 2022-06-24 10:42:31.830263
# Unit test for constructor of class Not
def test_Not():
    from typesystem import Integer, String

    not_string = Not(String())

    assert not_string.validate(123) == 123
    assert not_string.validate([1, 2, 3]) == [1, 2, 3]

    with pytest.raises(not_string.validation_error):
        not_string.validate("foo")

    not_string = Not(String(max_length=5))

    with pytest.raises(not_string.validation_error):
        not_string.validate("foo")

    assert not_string.validate("foob") == "foob"
    assert not_string.validate("fooba") == "fooba"
    assert not_string.validate("foobar") == "foobar"

# Generated at 2022-06-24 10:42:34.149828
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(AllOf([]))
    assert not_field.negated == AllOf([])

# Generated at 2022-06-24 10:42:36.686692
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # initialized a class NeverMatch
    a = NeverMatch(name = "name")
    assert a.name == "name"


# Generated at 2022-06-24 10:42:38.919928
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    foo = NeverMatch()
    bar = foo.validate("hello")
    assert bar is None


# Generated at 2022-06-24 10:42:47.073376
# Unit test for method validate of class Not
def test_Not_validate():
    if __name__ == '__main__' or 'typesystem_jsonschema.jsonschema_types' in __name__:
        # value = 'a'
        # assert Not(String(min_length=1)).validate(value) == value
        # assert Not(String(max_length=1)).validate(value) == value
        # assert Not(String(min_length=0, max_length=0)).validate(value) == value
        # assert Not(String(min_length=2)).validate(value) == value
        pass

# Generated at 2022-06-24 10:42:48.221606
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf


# Generated at 2022-06-24 10:42:50.739536
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	field = NeverMatch(name="Name")
	assert field.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:42:55.531063
# Unit test for constructor of class OneOf
def test_OneOf():
    listOfField = []
    listOfField.append(Any())
    t = OneOf(listOfField)
    assert(t.one_of == listOfField)


# Generated at 2022-06-24 10:42:58.425891
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Setup
    all_of: typing.List[Field] = [typesystem.String()]
    field = typesystem.AllOf(all_of)
    
    # Exercise
    result = field.validate("")
    
    # Verify
    assert result == ""
    assert result == field.instance

    # Cleanup - none necessary



# Generated at 2022-06-24 10:43:02.852771
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # unit test for the validate method of class IfThenElse
    test_field = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any(),
        description="test field",
    )

    assert test_field.validate(1) == 1


# Generated at 2022-06-24 10:43:06.617718
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(one_of=[], allow_null=True)
    assert field.one_of == []
    assert field.allow_null == True

# Generated at 2022-06-24 10:43:10.422131
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    try:
        n.validate("25")
    except ValueError as e:
        assert e.args[0] == "This never validates."

# Generated at 2022-06-24 10:43:14.913287
# Unit test for constructor of class OneOf
def test_OneOf():
    oo = OneOf()
    assert oo._description == "Must match exactly one of the sub-items."
    assert oo._nullable == False

# Generated at 2022-06-24 10:43:20.268495
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Any(), then_clause=None, else_clause=None)


json_schema_fields = {
    "anyOf": Union,
    "oneOf": OneOf,
    "allOf": AllOf,
    "not": Not,
    "if": IfThenElse,
}  # type: typing.Dict[str, typing.Any]

# Generated at 2022-06-24 10:43:21.800394
# Unit test for method validate of class Not
def test_Not_validate():
    input = {"a": "b"}
    output = Not(Field(type="number")).validate(input)
    expected = input
    assert output == expected

# Generated at 2022-06-24 10:43:23.481128
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nm = NeverMatch(description="asdf")
    assert nm.validate("asdf") == None
    assert nm.validate(None) == None

# Generated at 2022-06-24 10:43:28.748169
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    instance = NeverMatch()
    with pytest.raises(Field.validation_error):
        instance.validate(object)
    with pytest.raises(Field.validation_error):
        instance.validate(4)

# Generated at 2022-06-24 10:43:34.029408
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import pytest
    with pytest.raises(NeverMatch.validation_error) as excinfo:
        NeverMatch().validate('some string')



# Generated at 2022-06-24 10:43:36.729525
# Unit test for constructor of class OneOf

# Generated at 2022-06-24 10:43:43.762729
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    assert AllOf([]).validate(1) == 1
    assert AllOf([Integer()]).validate(1) == 1
    assert AllOf([Integer(), Any()]).validate(1) == 1
    assert AllOf([Integer(), Integer()]).validate(1) == 1
    assert AllOf([Integer(), Integer(), Integer()]).validate(1) == 1
    assert AllOf([Integer(), Integer(), Integer(), Integer()]).validate(1) == 1
    assert AllOf([Integer(), Integer(), Integer(), Integer(), Integer()]).validate(1) == 1
    assert AllOf([Integer(), Integer(), Integer(), Integer(), Integer(), Integer()]).validate(1) == 1
    assert AllOf([Integer(), Integer(), Integer(), Integer(), Integer(), Integer(), Integer()]).validate(1) == 1

# Generated at 2022-06-24 10:43:45.177390
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(1) == None


# Generated at 2022-06-24 10:43:46.974761
# Unit test for constructor of class Not
def test_Not():
    field1 = Not(String())
    field2 = Not(a=5)


# Generated at 2022-06-24 10:43:51.576707
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = NeverMatch()
    then_clause = NeverMatch()
    field = IfThenElse(if_clause, then_clause)
    assert field.validate(42) == 42

# Generated at 2022-06-24 10:43:52.527763
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True


# Generated at 2022-06-24 10:44:00.693770
# Unit test for constructor of class OneOf
def test_OneOf():
    for i in range(1, 5):
        for j in range(1, 5):
            for k in range(1, 5):
                if i+j+k < 3: break
                if i > 6: continue
                if (j == 2) or (k == 2): continue
                if i == 2: break
                if i == j: break
                if i+j == 7: break
                # print(i, j, k)

    fields = [
        Field(title="field1", required=True),
        Field(title="field2", required=True),
        Field(title="field3", required=True)
    ]
    f = OneOf(fields)
    print(f)

# Generated at 2022-06-24 10:44:07.943267
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(
        all_of=[
            Field(
                name="name1",
                description="description1",
                serialized_name="serialized_name1",
                required=True,
                allow_null=True,
                write_only=True,
                default=1,
                example="example1"
            ),
            Field(
                name="name2",
                description="description2",
                serialized_name="serialized_name2",
                required=True,
                allow_null=True,
                write_only=True,
                default=1,
                example="example2"
            )
        ]
    )
    assert field.name == None
    assert field.description == None
    assert field.serialized_name == None
    assert field.required == False
    assert field.allow_null

# Generated at 2022-06-24 10:44:19.169690
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(
        [
            String(min_length=2, max_length=5),
            String(min_length=6, max_length=10),
        ]
    )

    try:
        v = field.validate("1")
    except errors.ValidationError:
        pass
    else:
        raise Exception(
            "Should have failed - didn't match any of the sub clauses"
        )

    v = field.validate("123456")
    if v != "123456":
        raise Exception("Output should be same as input")

    try:
        v = field.validate("12345678910")
    except errors.ValidationError:
        pass
    else:
        raise Exception(
            "Should have failed - matched more than one of the sub clauses"
        )


# Generated at 2022-06-24 10:44:24.666292
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Schema  # noqa: F401

    class AllOfSchema(Schema):
        name = AllOf([String(), Email(format_check=False)])

    AllOfSchema().validate({"name": "foo"})

    with raises(FieldError, match="starts with") as exc_info:
        AllOfSchema().validate({"name": "123"})

# Generated at 2022-06-24 10:44:27.291170
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(Any(), Any())
    assert x.validate(1) == 1

# Generated at 2022-06-24 10:44:28.515092
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch(
        )
    except TypeError:
        pass
    else:
        assert False


# Generated at 2022-06-24 10:44:29.454441
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    IfThenElse(int, int, str)
    IfThenElse(int, str)
    IfThenElse(int)

# Generated at 2022-06-24 10:44:31.215164
# Unit test for constructor of class OneOf
def test_OneOf():
    f = OneOf([])
    assert hasattr(f, "one_of")


# Generated at 2022-06-24 10:44:32.584022
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match = NeverMatch()
    assert never_match.validate(None, True) == None


# Generated at 2022-06-24 10:44:35.979424
# Unit test for method validate of class Not
def test_Not_validate():
    not_ = Not(negated=Any())
    assert not_.validate("test") == "test"
    try:
        not_.validate(1)
        assert False
    except Exception as e:
        assert "Must not match" in str(e)

# Generated at 2022-06-24 10:44:42.408468
# Unit test for constructor of class Not
def test_Not():
    from typesystem import String, Integer

    not_string = Not(String())
    not_integer = Not(Integer())

    for value in ("hello", "world"):
        assert not_string.validate(value) == value
        assert not_integer.validate(value) == value

    for value in (42, 3.14):
        assert not_string.validate(value) == value
        assert not_integer.validate(value) == value



# Generated at 2022-06-24 10:44:48.601392
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # all of
    print("all of")
    class Integer(Field):
        def validate(self, value, strict=False):
            return str(value)
    all_of1 = AllOf([Integer()])
    all_of1.validate(10)
    # one of
    print("one of")
    class Integer(Field):
        def validate(self, value, strict=False):
            return str(value)
    one_of1 = OneOf([Integer()])
    one_of1.validate(10)
    # ifThenElse
    print("ifThenElse")
    class Integer(Field):
        def validate(self, value, strict=False):
            return str(value)
    if_clause = Integer()
    then_clause = Integer()
    else_clause = Integer()
    ifThen

# Generated at 2022-06-24 10:44:49.577819
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [Field(), Field(), Field()]
    tester = OneOf(fields)
    assert tester.one_of == fields


# Generated at 2022-06-24 10:44:59.513964
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test1 = {"a": 2, "b": 5, "c": 7}
    test2 = {"a": 2, "b": 3}
    test3 = {"a": 2, "b": 5, "c": 3}
    test4 = {"a": 2, "b": 5, "c": 5}

    if_clause = typesystem.Object(
        properties={"a": typesystem.Integer(), "b": typesystem.Integer()}
    )
    then_clause = typesystem.Object(
        properties={"a": typesystem.Integer(), "b": typesystem.Integer(), "c": typesystem.Integer()}
    )
    else_clause = typesystem.Object(
        properties={"a": typesystem.Integer(), "b": typesystem.Integer()}
    )

# Generated at 2022-06-24 10:45:01.964878
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    p = NeverMatch(name = "NeverMatch")
    assert p.name == "NeverMatch"
    assert p.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:45:06.008996
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    field = OneOf([], name="UnitTest")

    # Act
    try:
        field.validate("")
        # Assert
        assert False
    except Exception as e:
        # Assert
        assert True

# Generated at 2022-06-24 10:45:08.824010
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(negated=AllOf([Any()]))
    try:
        f.validate("test")
    except Exception as e:
        assert "negated" in e.detail

# Generated at 2022-06-24 10:45:09.921714
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=1).negated == 1

# Generated at 2022-06-24 10:45:18.598823
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # The following example of a test is the same used in dcc_qc
    # https://github.com/UMCUGenetics/dcc_qc/blob/master/test/test_model_transaction.py
    if_clause = Field(name='if_clause', pattern="\d{1,2}/\d{1,2}/\d{4}")
    then_clause = Field(name='then_clause', pattern="\d{1,2}/\d{1,2}/\d{4}")
    else_clause = Field(name='else_clause', pattern="\d{1,2}/\d{1,2}/\d{4}")


# Generated at 2022-06-24 10:45:20.596469
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    x = AllOf([Any()])
    x.validate(1)

# Generated at 2022-06-24 10:45:25.796150
# Unit test for constructor of class Not
def test_Not():
    f = Not(Any())
    assert(isinstance(f, Not))
    f.validate(1)


# Generated at 2022-06-24 10:45:28.611922
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer

    f = AllOf([Integer()])
    # Unit test for constructor of class IfThenElse

# Generated at 2022-06-24 10:45:33.584328
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_test = IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    assert if_test.if_clause == Field()
    assert if_test.then_clause == Field()
    assert if_test.else_clause == Field()

# Generated at 2022-06-24 10:45:35.027024
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import typing
    from typesystem.exceptions import ValidationError
    from typesystem.fields import NeverMatch
    field = NeverMatch()
    try:
        field.validate(None)
    except ValidationError:
        pass


# Generated at 2022-06-24 10:45:38.769627
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not("test")
    with pytest.raises(Exception) as e:
        field.validate("test")
    
    assert e.type == IncompleteImplementationError
    assert e.value.args[0] == "The Not class is not implemented."
    assert not e.value.args[1]


# Generated at 2022-06-24 10:45:43.508123
# Unit test for method validate of class Not
def test_Not_validate():
    # Mock a Field as a parameter of  validate
    strict = False
    mock = mock.MagicMock()
    mock.validate_or_error.return_value = "True",None
    # Call validate of class Not
    result = Not(mock).validate(strict)
    assert result == "True"



# Generated at 2022-06-24 10:45:48.418386
# Unit test for constructor of class Not
def test_Not():
    import typesystem
    def_type = typesystem.String(max_length=4)
    not_type = typesystem.Not(def_type)
    test_str = "abc"
    assert not_type.validate(test_str) == test_str
    test_str2 = "abcd"
    try:
        not_type.validate(test_str2)
    except:
        pass
    else:
        raise Exception("Not is not working")

# Generated at 2022-06-24 10:45:49.751530
# Unit test for constructor of class AllOf
def test_AllOf():
    d=AllOf([])
    assert d!=None


# Generated at 2022-06-24 10:45:53.779685
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf([Any()], name='a')
    assert a.validate(10) == 10
    assert a.validate({'x': 10}) == {'x': 10}
    assert a.validate('foo') == 'foo'



# Generated at 2022-06-24 10:45:55.021914
# Unit test for constructor of class AllOf
def test_AllOf():
    # This is used for code coverage of the __init__ method
    assert AllOf([], nullable=False)

# Generated at 2022-06-24 10:46:00.802824
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.objs import _Str
    a = _Str()
    b = _Str()
    c = _Str()
    value = 1
    strict = False
    if_clause, error1 = a.validate_or_error(value, strict=strict)
    then_clause, error2 = b.validate_or_error(value, strict=strict)
    else_clause, error3 = c.validate_or_error(value, strict=strict)
    if error1 is None:
        d = then_clause
    else:
        d = else_clause
    return d

# Generated at 2022-06-24 10:46:03.063822
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    x = IfThenElse(if_clause=Int(required=True),
                   then_clause=Int(required=True),
                   else_clause=Int(required=True))
    x.validate(1)
    x.validate(2)

# Generated at 2022-06-24 10:46:04.781385
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Test method validate of class AllOf
    value = "value"
    field = AllOf([Any(), Any()])
    assert field.validate(value) == value

# Generated at 2022-06-24 10:46:08.684779
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    one = 1
    three = 3
    test = IfThenElse(if_clause=AllOf([one]), then_clause=AllOf([three]))
    test.validate(1)
    # TODO: Add assertion for case in which one of the clauses does not match
    # TODO: Add assertion for case in which both clauses match

# Generated at 2022-06-24 10:46:13.010916
# Unit test for constructor of class Not
def test_Not():
    class Test:
        def __init__(self, a: str = "123", b: int = 123):
            raise ValueError("wtf")
    assert Not(Test()).validate("123") == "123"

# Generated at 2022-06-24 10:46:14.254990
# Unit test for constructor of class AllOf
def test_AllOf():
    pass


# Generated at 2022-06-24 10:46:18.787895
# Unit test for constructor of class Not
def test_Not():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.if_clause == if_clause
    assert field.then_clause == then_clause
    assert field.else_clause == else_clause

# Generated at 2022-06-24 10:46:24.944248
# Unit test for constructor of class AllOf
def test_AllOf():
    class SomeClass:
        def __init__(self, all_of: typing.List[Field], **kwargs: typing.Any) -> None:
            self.all_of = all_of
    all_of = AllOf('something',title='Some Title')
    some_class = SomeClass(all_of)
    assert some_class.all_of == all_of


# Generated at 2022-06-24 10:46:28.095350
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    for x in range(10000):
        # Arrange
        x = random.randint(0, 1000)
        y = random.randint(0, 1000)
        z = random.randint(0, 1000)

        # Act
        all_of = AllOf([Integer(min_value=x), Integer(min_value=y), Integer(min_value=z)])
        all_of.validate(random.randint(0, 1000))



# Generated at 2022-06-24 10:46:34.665022
# Unit test for method validate of class Not
def test_Not_validate():
    class N(Not):
        # Explicit arguments:
        negated=None
        # Implicit arguments:
        allow_null=False,
        children=None
        # Implicit keyword arguments:
        def __init__(self, **kwargs):
            super(N, self).__init__(**kwargs)
            
    l = N(negated=int)
    b = l.validate("s")
    assert b == "s"
    b = l.validate(7)
    assert b == 7

# Generated at 2022-06-24 10:46:45.278893
# Unit test for method validate of class OneOf
def test_OneOf_validate():
  # creation of object test1
  test1 = OneOf(one_of = [])
  # creation of object test2
  test2 = OneOf(one_of = [], validate = lambda value: value + 1)
  # creation of object test3
  test3 = OneOf(one_of = [], allow_null = True)
  # creation of object test4
  test4 = OneOf(one_of = [], allow_null = True, required = True)
  # creation of object test5
  test5 = OneOf(one_of = [], allow_null = True, required = True, default = 3)
  # creation of object test6
  test6 = OneOf(one_of = [], allow_null = True, required = True, default = 3, validate = lambda value: value + 1)
  # creation of object

# Generated at 2022-06-24 10:46:47.907404
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    error = {"This is just for test."}
    nm = NeverMatch(errors=error)
    assert nm.errors == error


# Generated at 2022-06-24 10:46:51.220626
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=None)
    if (field.negated is None):
        print('Not factory test passed')
    else:
        print('Not factory test failed')

test_Not()

# Generated at 2022-06-24 10:46:55.046024
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import AllOf, Integer, String
    class A(AllOf):
        all_of = [Integer(), String()]
    all_of = A()
    all_of.validate(2)


# Generated at 2022-06-24 10:46:58.042671
# Unit test for constructor of class OneOf
def test_OneOf():
    string = "string"
    int = 3
    float = 3.2
    one_of = [string, int, float]

    field = OneOf(one_of)
    assert field



# Generated at 2022-06-24 10:46:59.274014
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    try:
        f = NeverMatch()
        f.validate('x')
        assert False
    except Exception:
        assert True

# Generated at 2022-06-24 10:47:01.012622
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()]).__doc__ == 'Any'


# Generated at 2022-06-24 10:47:01.659222
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    pass

# Generated at 2022-06-24 10:47:05.591966
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Int(), Str()]).validate(4) == 4
    assert OneOf([Int(), Str()]).validate("4") == "4"
    try:
        assert OneOf([Int(), Str()]).validate(4.0)
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-24 10:47:09.823623
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    try:
        field.validate('42')
    except TypeSystemError as field_error:
        assert field_error.code == 'never'
        assert str(field_error) == 'This never validates.'
    else:
        raise AssertionError('Expected TypeSystemError but got no error')


# Generated at 2022-06-24 10:47:11.545218
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem import parse
    field = parse({"type": "never-match"})
    assert field.deserialize(5) == 5


# Generated at 2022-06-24 10:47:14.958581
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse.__init__.__doc__ == \
        "Conditional sub-item matching.\n\n    You should use custom validation instead.\n    "

# Generated at 2022-06-24 10:47:18.232825
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([])
    with pytest.raises(AssertionError) as excinfo:
        one_of.validate(None)
    the_exception = excinfo.value
    assert str(the_exception) == "no_match"


# Generated at 2022-06-24 10:47:21.057123
# Unit test for constructor of class OneOf
def test_OneOf():
    values = ['one', 'two', 'three']
    one_of = OneOf(values)
    assert one_of.one_of == values


# Generated at 2022-06-24 10:47:21.841453
# Unit test for constructor of class IfThenElse

# Generated at 2022-06-24 10:47:23.752464
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Array(items=String()))
    field.validate([])


# Generated at 2022-06-24 10:47:27.918900
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f1 = Field(convert=lambda v: v + 1)
    f2 = Field(convert=lambda v: v + "b")
    all_of = AllOf([f1, f2])
    assert all_of.validate("a", strict=True) == "ab"

# Generated at 2022-06-24 10:47:37.747128
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(None, None, None).validate(1) == 1
    assert IfThenElse(None, None, None).validate(0) == 0
    assert IfThenElse(None, None, None).validate("1") == "1"
    assert IfThenElse(None, None, None).validate("0") == "0"
    assert IfThenElse(None, None, None).validate(1.0) == 1.0
    assert IfThenElse(None, None, None).validate(0.0) == 0.0
    assert IfThenElse(None, None, None).validate([1,2,3]) == [1,2,3]
    assert IfThenElse(None, None, None).validate({"a":1, "b":2}) == {"a":1, "b":2}


# Generated at 2022-06-24 10:47:42.021765
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    '''
    Unit test for method validate of class AllOf
    '''
    allof = AllOf([Any() for i in range(2)])
    # Test case 1
    res = allof.validate(1)
    assert res == 1
    # Test case 2
    res = allof.validate('1')
    assert res == '1'


# Generated at 2022-06-24 10:47:43.948217
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    test_field = NeverMatch()
    with pytest.raises(ValueError):
        test_field.validate(True)


# Generated at 2022-06-24 10:47:51.375268
# Unit test for constructor of class OneOf
def test_OneOf():
    field = AllOf([NeverMatch(), NeverMatch(), NeverMatch()])
    assert field.allow_null is False
    assert field.errors == {
        "no_match": "Did not match any valid type.",
        "multiple_matches": "Matched more than one type.",
    }
    assert field.one_of == [NeverMatch(), NeverMatch(), NeverMatch()]


# Generated at 2022-06-24 10:47:52.688008
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of_object = AllOf([String()])
    assert all_of_object.validate('a') == 'a'


# Generated at 2022-06-24 10:47:55.243038
# Unit test for constructor of class AllOf
def test_AllOf():
    pass


# Generated at 2022-06-24 10:47:56.203122
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # TODO: Add unit tests
    pass

# Generated at 2022-06-24 10:47:59.410045
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.name == 'NeverMatch'
    assert a.label == 'NeverMatch'
    assert a.required is False


# Generated at 2022-06-24 10:48:06.969773
# Unit test for constructor of class AllOf
def test_AllOf():
    class Person:
        def __init__(self, age: int, name: str) -> None:
            self.age = age
            self.name = name

    class PersonField(Field):
        default_error_messages = {"invalid": "Could not parse person."}

        def to_python(self, value: typing.Any) -> Person:
            return Person(**value)

        def to_representation(self, value: Person) -> typing.Dict[str, typing.Any]:
            return {"age": value.age, "name": value.name}

    age = Range(min_value=0)
    name = Length(min_length=2)
    p = PersonField(all_of=[age, name])
    assert p.validate({"age": 2, "name": "joe"}) is not None



# Generated at 2022-06-24 10:48:07.992647
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass


# Generated at 2022-06-24 10:48:19.973272
# Unit test for constructor of class OneOf
def test_OneOf():
    Field()
    Field('Title', 'Hello World')
    Field('boolean', True)
    Field('number', 1234)
    Field('string', "string")
    Field('list', ['a', 'b', 'c'])
    Field('tuple', ('a', 'b', 'c'))
    Field('dict', {'a': 1, 'b': 2, 'c': 3})
    OneOf(Field())
    OneOf(Field('Title', 'Hello World'))
    OneOf(Field('boolean', True))
    OneOf(Field('number', 1234))
    OneOf(Field('string', "string"))
    OneOf(Field('list', ['a', 'b', 'c']))
    OneOf(Field('tuple', ('a', 'b', 'c')))

# Generated at 2022-06-24 10:48:25.510238
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Typesystem.Integer()
    then_clause = Typesystem.String()
    else_clause = Typesystem.Float()
    create_ifthenelse = IfThenElse(if_clause, then_clause, else_clause)
    assert create_ifthenelse.validate(1) == "1"
    assert create_ifthenelse.validate(5) == "5"
    assert create_ifthenelse.validate(10) == "10"
    assert (create_ifthenelse.validate(-1) == -1.0)


# Generated at 2022-06-24 10:48:32.714184
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=String(), 
        then_clause=Integer(), else_clause=Float()).validate("1") == 1
    assert IfThenElse(if_clause=String(), 
        then_clause=Integer(), else_clause=Float()).validate("1.0") == 1.0