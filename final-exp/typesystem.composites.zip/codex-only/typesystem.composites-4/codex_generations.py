

# Generated at 2022-06-24 10:38:33.390424
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    Int = Field()
    String = Field()
    allof_field = AllOf([Int, String])
    allof_field.validate(1)


# Generated at 2022-06-24 10:38:38.393244
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typing import Any
    from typesystem import String
    from typesystem.fields import AllOf
    from typesystem.exceptions import ValidationError

    field = AllOf(all_of=[String(), String()])
    field.validate('data')

    field.all_of.append(String(min_length=5))
    try:
        field.validate('data')
        assert False
    except ValidationError as e:
        assert len(e.messages) == 1 and 'minLength' in e.messages[0]


# Generated at 2022-06-24 10:38:47.333135
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    def check_it(expected, got):
        # add more checks as needed
        assert expected.if_clause == got.if_clause
        assert expected.then_clause == got.then_clause
        assert expected.else_clause == got.else_clause

    test_name = 'test_IfThenElse'
    print_test_subject(test_name)
    from typesystem.fields import String
    f1 = String()
    f2 = String()
    f3 = String()
    ite1 = IfThenElse(if_clause=f1)
    expected1 = IfThenElse(if_clause=f1, then_clause=Any(), else_clause=Any())
    check_it(expected1, ite1)

# Generated at 2022-06-24 10:38:53.676651
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Boolean
    from typesystem.fields import Float
    from typesystem.fields import DateTime
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Enum
    from typesystem.fields import UUID
    from typesystem.fields import Pattern
    from typesystem.fields import Email
    from typesystem.fields import URL
    from typesystem.fields import Choice
    from typesystem.fields import JSON
    all_of = AllOf([String(required=True, min_length=1, max_length=1,
        pattern=r'\d')])
    assert __name__ == '__main__'


# Generated at 2022-06-24 10:39:04.998958
# Unit test for constructor of class AllOf
def test_AllOf():
    def test_AllOf_1(self):
        input_list = "[Field({'meta': {'name': 'string'}, 'type': 'string'})]"
        assert self.all_of == eval(input_list)
        assert self.kwargs == dict()

    def test_AllOf_2(self):
        input_list = "[Field({'meta': {'name': 'string'}, 'type': 'string'})]"
        assert self.all_of == eval(input_list)
        assert self.kwargs == dict()

    all_of_1 = AllOf(all_of="[Field({'meta': {'name': 'string'}, 'type': 'string'})]")

# Generated at 2022-06-24 10:39:06.858475
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf(all_of=[Any()])
    all_of.validate("test")



# Generated at 2022-06-24 10:39:09.515484
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field(validators=[True]))
    assert field.errors == {"negated": "Must not match."}
    assert field.validate(False) == False



# Generated at 2022-06-24 10:39:14.058178
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.utils import Undefined

    class Integer(Field):

        # Unit test for method validate of class Integer
        def _validate(self, value: typing.Any) -> typing.Any:
            if not self.nullable and value is None:
                raise self.validation_error("null")

            if not isinstance(value, int):
                raise self.validation_error("invalid")

            if value < self.min_value:
                raise self.validation_error("min_value")

            if value > self.max_value:
                raise self.validation_error("max_value")

            return value


# Generated at 2022-06-24 10:39:19.540271
# Unit test for method validate of class Not
def test_Not_validate():
    from unittest import TestCase
    from typesystem import String, Structure

    subtype = String(max_length=5)
    validator = Not(subtype)

    test_string = "a"
    self = TestCase()
    self.assertEqual(validator.validate(test_string), test_string)
    test_string = "abcde"
    try:
        validator.validate(test_string)
        self.assertTrue(False)
    except:
        self.assertTrue(True)

    test_structure = Structure({'field_a': 'a', 'field_b': 5})
    try:
        validator.validate(test_structure)
        self.assertTrue(False)
    except:
        self.assertTrue(True)

# Generated at 2022-06-24 10:39:29.360123
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import sys
    import typesystem
    AllOf_fields = {}
    AllOf_fields['all_of'] = ['test_AllOf_validate_all_of']
    AllOf_fields['_validators'] = []
    def call_AllOf_validate(self, value, strict):
        return AllOf.validate(self, value, strict)
    AllOf_fields['validate'] = types.MethodType(call_AllOf_validate, AllOf)
    AllOf_fields['validate'].__dict__ = {}
    type_store['AllOf'] = types.ClassType('AllOf', (Field,), AllOf_fields)
    AllOf.__dict__ = {}

# Generated at 2022-06-24 10:39:32.475710
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([int, str],max_length=10)
    assert field.all_of == [int, str]
    assert field.max_length == 10

# Generated at 2022-06-24 10:39:36.623084
# Unit test for constructor of class Not
def test_Not():
    field = Not(NeverMatch())
    assert field.errors is None
    assert field.negated.errors == {"never": "This never validates."}
    try:
        field.validate('')
        assert False
    except Exception as error:
        assert error == "Must not match."


# Generated at 2022-06-24 10:39:38.898489
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(Any())
    assert f.validate('this') == 'this'
    with pytest.raises(f.validation_error):
        f.validate(None)

# Generated at 2022-06-24 10:39:40.387265
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}

test_NeverMatch()


# Generated at 2022-06-24 10:39:42.283555
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # arrange
    nm = NeverMatch()
    # act
    nm.validate("")
    # assert


# Generated at 2022-06-24 10:39:51.076204
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    number = 123
    number_field = Int(name='number_field')
    string_field = String(name='string_field')
    if_clause = number_field
    then_clause = number_field
    else_clause = string_field
    ite = IfThenElse(
        if_clause = if_clause,
        then_clause = then_clause,
        else_clause = else_clause
    )
    ite.validate(value=number)

# Generated at 2022-06-24 10:39:51.883880
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-24 10:39:52.658070
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([str])


# Generated at 2022-06-24 10:40:00.605003
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse('1', '2').if_clause == '1'
    assert IfThenElse('1', '2').then_clause == '2'
    assert IfThenElse('1', '2').else_clause == {}
    assert IfThenElse('1', '2', '3').if_clause == '1'
    assert IfThenElse('1', '2', '3').then_clause == '2'
    assert IfThenElse('1', '2', '3').else_clause == '3'


# Generated at 2022-06-24 10:40:02.546038
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-24 10:40:13.759510
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # GIVEN
    import typesystem
    from typesystem.fields import String, Integer

    # WHEN
    class Foo(typesystem.Schema):
        field = AllOf(
            [
                Integer(minimum=1, maximum=10),
                String(format="ipv4"),
            ],
            description="Some description",
            required=True
        )

    # THEN
    foo = Foo({"field": "1"})
    assert foo.is_valid() is False
    assert foo.validate() is False
    assert foo.errors

    # WHEN
    class Foo(typesystem.Schema):
        field = AllOf(
            [
                Integer(minimum=1, maximum=10),
                String(format="ipv4"),
            ],
            description="Some description",
            required=True
        )

    # THEN

# Generated at 2022-06-24 10:40:17.501346
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    from typesystem.types import Integer
    field = IfThenElse(String(), Integer())
    assert (field.if_clause.name == "String")
    assert (field.then_clause.name == "Integer")
    assert (field.else_clause.name == "Any")

# Generated at 2022-06-24 10:40:27.918375
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        Boolean(required=True),
        Integer(required=True),
        String(required=True)
    ])
    
    # Test cases and expected results
    valid_data_list = [True, "", "42", 42]
    invalid_data_list = [{}, [], None, list]

    for expected_result in valid_data_list:
        assert field.validate(expected_result) == expected_result
    for data in invalid_data_list:
        try:
            field.validate(data)
        except ValidationError:
            assert True
        else:
            assert False, "ValidationError should be raised for data: {}".format(data)

test_OneOf_validate()



# Generated at 2022-06-24 10:40:31.812726
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    Test method validate of class AllOf
    """
    test_AllOf_field = AllOf([])
    test_AllOf_value = True
    test_AllOf_strict = False
    assert test_AllOf_field.validate(test_AllOf_value, test_AllOf_strict) == test_AllOf_value


# Generated at 2022-06-24 10:40:32.781325
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert None is not None

# Generated at 2022-06-24 10:40:35.349545
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())

# Generated at 2022-06-24 10:40:40.100843
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """
    Test constructor of class NeverMatch
    """
    
    try:
        nm = NeverMatch(name="NeverMatch")
    except Exception as e:
        nm = None
        print("Failed when create a NeverMatch")
        print("The error message is: {0}".format(e.message))
    assert nm
    assert isinstance(nm, NeverMatch)



# Generated at 2022-06-24 10:40:45.147327
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String, Integer

    field = OneOf([String(), Integer()])
    assert field.validate(1) == 1
    assert field.validate("foo") == "foo"
    try:
        field.validate(False)
    except Exception as e:
        assert str(e) == "Did not match any valid type."



# Generated at 2022-06-24 10:40:51.258871
# Unit test for method validate of class AllOf
def test_AllOf_validate():

    f = AllOf(all_of=[BaseInteger(), BaseString()])
    try:
        f.validate(2)
    except ValidationError:
        pass
    else:
        assert False

    try:
        f.validate("abc")
    except ValidationError:
        pass
    else:
        assert False

    try:
        f.validate(4)
    except ValidationError:
        assert False
    else:
        assert True

    try:
        f.validate("")
    except ValidationError:
        assert False
    else:
        assert True

# Generated at 2022-06-24 10:41:01.323557
# Unit test for method validate of class Not
def test_Not_validate():
    
    not1 = Not(childField) #childField is Field type, not a field
    #validate will raise error because negated is a field
    # It should be a field object but created from default value of Field,
    # not a Field type
    #not2 = Not(Field) #childField is Field type, not a field
    #validate will raise error because negated is a field
    # It should be a field object but created from default value of Field,
    # not a Field type
    #not3 = Not(Field()) #childField is Field type, not a field
    #validate will raise error because negated is a field
    # It should be a field object but created from default value of Field,
    # not a Field type
    #not4 = Not(Boolean()) #childField is Field type, not a field
    #

# Generated at 2022-06-24 10:41:02.721033
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate("foobar") == "foobar"

# Generated at 2022-06-24 10:41:11.454593
# Unit test for method validate of class OneOf

# Generated at 2022-06-24 10:41:15.636660
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    clause = IfThenElse(
            if_clause = Field(),
            then_clause = Field(),
            else_clause = Field(),
            name = "testIfThenElse"
    )
    assert clause.validate(10) == 10


# Generated at 2022-06-24 10:41:19.154700
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(FieldError, match=".*did not match.*"):
        field.validate("anything")



# Generated at 2022-06-24 10:41:21.904373
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(name='', description='', error='')
    assert field.name == ''
    assert field.description == ''
    assert field.error == ''


# Generated at 2022-06-24 10:41:27.033888
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Int(), else_clause=Int(max=10))
    field.validate(12)
    field.validate(8)
    field.validate(5)
    try:
        field.validate(15)
    except:
        return True
    return False
print("test case 1 for IfThenElse.validate: ", test_IfThenElse_validate())

# Generated at 2022-06-24 10:41:27.814415
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)
    assert field.negated is None


# Generated at 2022-06-24 10:41:28.345588
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-24 10:41:35.008112
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    one = Field(key = 'one')
    two = Field(key = 'two')
    three = Field(key = 'three')

    value = Field(key = 'value')
    value.validate = MagicMock(return_value = {'one' : 1, 'two' : 2, 'three' : 3})

    if_clause = Field()
    if_clause.validate_or_error = MagicMock(return_value = (True, "bla"))

    then_clause = Field()
    then_clause.validate_or_error = MagicMock(return_value = (True, "bla"))

    else_clause = Field()
    else_clause.validate_or_error = MagicMock(return_value = (True, "bla"))


# Generated at 2022-06-24 10:41:36.295133
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert isinstance(field, Field)
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:41:41.081754
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class myField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    myIfThenElse = IfThenElse(myField(), myField(), myField())
    assert myIfThenElse.validate("abc") == "abc"

# Generated at 2022-06-24 10:41:43.428371
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert(True)


# Generated at 2022-06-24 10:41:48.141044
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # Arrange
    ifThenElse = IfThenElse("if_clause", "then_clause", "else_clause")
    # Act
    # Assert
    assert ifThenElse.if_clause == "if_clause"
    assert ifThenElse.then_clause == "then_clause"
    assert ifThenElse.else_clause == "else_clause"
    

# Generated at 2022-06-24 10:41:50.254977
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert True == True

# Generated at 2022-06-24 10:41:54.998253
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    with pytest.raises(ValidationError) as exc_info:
        not_field.validate(None)
    assert exc_info.value.messages == {"negated": "Must not match."}


# Generated at 2022-06-24 10:41:56.325561
# Unit test for constructor of class AllOf
def test_AllOf():
    test_field = AllOf(all_of=[Integer(), String()])


# Generated at 2022-06-24 10:42:00.262358
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A: pass
    class B: pass

    f = IfThenElse(
        if_clause=Instance(A),
        then_clause=Instance(B),
        else_clause=Instance(A),
    )

    assert isinstance(f.validate(A()), A)
    assert isinstance(f.validate(B()), B)

# Generated at 2022-06-24 10:42:07.801140
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert (IfThenElse(if_clause="10", then_clause="9", else_clause="8").validate("10") == "10")
    assert (IfThenElse(if_clause="10", then_clause="9", else_clause="8").validate("9") == "8")
    assert (IfThenElse(if_clause="10", then_clause="9", else_clause="8").validate("8") == "8")
    assert (IfThenElse(if_clause="10", then_clause="9", else_clause="8").validate("7") == "8")



# Generated at 2022-06-24 10:42:10.074009
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass
    # TODO


# Generated at 2022-06-24 10:42:17.696691
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem import StringType
    from typesystem import Array

    # Test that constructor for OneOf throws an exception for null 'one_of'
    try:
        OneOf(None)
        assert False
    except AssertionError:
        assert True

    # Test that constructor for OneOf throws an exception for empty 'one_of'
    try:
        OneOf([])
        assert False
    except AssertionError:
        assert True

    # Test that constructor for OneOf throws an exception for 'one_of' with
    # element that is not a Field
    try:
        OneOf(StringType())
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-24 10:42:28.385192
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import pytest
    from typesystem.exceptions import ValidationError
    from typesystem.types import String, Number
    from typesystem import fields
    
    class MyString(fields.IfThenElse):
        def __init__(self):
            super().__init__(
                if_clause = String(),
                then_clause = String(),
                else_clause = Number(),
                description = "String or number",
                )
                
    my_string = MyString()
    
    def test_IfThenElse_validate():
        assert my_string.validate("foo") == "foo"
        assert my_string.validate(123) == 123
        
        with pytest.raises(ValidationError):
            my_string.validate(True)

# Generated at 2022-06-24 10:42:30.776886
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    condition1 = {"type": "string", "enum": ["a", "b"]}
    schema1 = {"if": condition1, "then": {"type": "string"}}
    if_clause1 = IfThenElse(**schema1)
    if_clause1.validate("a")
    if_clause1.validate("b")


# Generated at 2022-06-24 10:42:42.383450
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    import pytest
    
    field = String()
    field1 = String()
    field.key = "name"
    field1.key = "surname"
    manyfiel = [field, field1]
    oneof = OneOf(manyfiel)
    value =  "John"
    strict = False
    oneof.validate(value,strict)
    assert value == oneof.validate(value,strict)
    value = "Michael"
    oneof.validate(value,strict)
    assert value == oneof.validate(value,strict)
    value = "Doe"
    strict = False

# Generated at 2022-06-24 10:42:43.744959
# Unit test for constructor of class AllOf
def test_AllOf():
    assert True

# Generated at 2022-06-24 10:42:46.617647
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field_list = [Any(), Any()]
    obj = AllOf(all_of=field_list)
    obj.validate("123")


# Generated at 2022-06-24 10:42:48.127515
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(1)


# Generated at 2022-06-24 10:42:56.203247
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    names = []
    for name in dir(IfThenElse):
        if not name.startswith("_"):
            names.append(name)

# Generated at 2022-06-24 10:42:58.048895
# Unit test for constructor of class Not
def test_Not():
    a = Not(negated = "")
    assert a.negated == ""
    assert a.errors["negated"] == "Must not match."

# Generated at 2022-06-24 10:43:09.159835
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    field_one = String()
    field_two = Integer()
    field_three = String()
    field_four = Integer()
    field_five = String()
    field_six = Integer()
    field_seven = String()
    field_eight = Integer()
    field_nine = String()
    field_ten = Integer()
    field_eleven = String()
    field_twelve = Integer()

    # Act
    field_one_of = OneOf([field_one, field_two, field_three, field_four,
                          field_five, field_six, field_seven, field_eight,
                          field_nine, field_ten, field_eleven, field_twelve])
    field_one_of.validate(1)

# Generated at 2022-06-24 10:43:10.532108
# Unit test for constructor of class AllOf
def test_AllOf():
  assert AllOf([Any()]).__init__([Any(), Any()], None)

# Generated at 2022-06-24 10:43:15.688967
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(1, 2, 3, allow_null=True).allow_null == False
    # the then and else clauses will be instantiated as Any
    assert IfThenElse(1).then_clause == Any()
    assert IfThenElse(1).else_clause == Any()

# Generated at 2022-06-24 10:43:18.428525
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    try:
        field.validate("test")
    except Exception as exc:
        assert str(exc) == "This never validates."


# Generated at 2022-06-24 10:43:23.135182
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Preconditions
    assert all([]) is True, 'Precondition failed'

    all_of: typing.List[Field] = []
    all_of.append(Field())
    all_of.append(Field())

    # There is no behaviour to test for AllOf's validate method
    # The method is called in the built-in test of class Field



# Generated at 2022-06-24 10:43:26.970797
# Unit test for constructor of class OneOf
def test_OneOf():

    one_of = [Any()]
    field = OneOf(one_of=one_of)
    assert field.one_of == one_of


# Generated at 2022-06-24 10:43:27.837883
# Unit test for constructor of class AllOf
def test_AllOf():
    assert isinstance(AllOf([Field()]), Field)
    

# Generated at 2022-06-24 10:43:34.986247
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from . import String, Integer
    text = "test"
    integer = 3
    test_allof = AllOf([String(), Integer(), String()])
    assert test_allof.validate(text) == text
    assert test_allof.validate(integer) == integer


# Generated at 2022-06-24 10:43:37.875032
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    checker = allof([String(max_length=6), String(min_length=3)])
    # returns None
    assert checker.validate(value_='foobarbaz') is None

# Generated at 2022-06-24 10:43:39.432924
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    with raises(AssertionError):
        test = NeverMatch(allow_null = True)


# Generated at 2022-06-24 10:43:41.281792
# Unit test for constructor of class AllOf
def test_AllOf():
    fields = [Field(), Field()]
    obj = AllOf(fields)
    assert obj.name == 'AllOf'
    assert obj.all_of == fields

# Generated at 2022-06-24 10:43:47.148889
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Integer, String
    int_or_str = AllOf([Integer(), String()])
    assert int_or_str.validate(1) == 1
    assert int_or_str.validate("x") == "x"
    assert int_or_str.validate([1, 2])

# Generated at 2022-06-24 10:43:49.031216
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(required=True)
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:43:50.412399
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field()).negated == Field()

# Generated at 2022-06-24 10:43:54.545616
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Arrange
    test_value = 10
    test_strict = True
    field = AllOf([Any()])

    # Act
    test_result = field.validate(test_value, test_strict)
    
    # Assert
    assert test_result == test_value



# Generated at 2022-06-24 10:43:56.354463
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    myField = NeverMatch()
    myField.validate("123", strict = True)


# Generated at 2022-06-24 10:44:04.872547
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    
    field = typesystem.IfThenElse(
        then_clause = typesystem.String(min_length=2, max_length=4),
        else_clause = typesystem.String(min_length=5, max_length=8),
        if_clause = typesystem.Boolean(),
    )
    field.validate(True)
    field.validate(False)
    
    field_true = typesystem.IfThenElse(
        then_clause = typesystem.String(min_length=3, max_length=4),
        else_clause = typesystem.String(min_length=5, max_length=8),
        if_clause = typesystem.Boolean(),
    )
    field_true.validate(True)

# Generated at 2022-06-24 10:44:16.086565
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String

    expected_type = String(max_length=2)
    negated_type = String(max_length=4)
    actual_type = Not(negated_type)

    data = 'ab'
    expected_result = data
    actual_result = actual_type.validate(data)
    assert expected_result == actual_result

    data = 'abcd'
    try:
        actual_result = actual_type.validate(data)
    except Exception as e:
        expected_result = e.args[0]
        assert expected_result == actual_result



# Generated at 2022-06-24 10:44:18.190256
# Unit test for method validate of class Not
def test_Not_validate():
    import typesystem
    schema = typesystem.Schema(type="not")
    assert schema._Field__field.validate(-1, strict=False) == -1


# Generated at 2022-06-24 10:44:20.041827
# Unit test for constructor of class AllOf
def test_AllOf():
    allof = AllOf([Any()])
    assert allof.all_of == [Any()]


# Generated at 2022-06-24 10:44:21.974642
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()]).one_of == [Any()]

# Generated at 2022-06-24 10:44:24.353758
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause=None,
        then_clause=None,
        else_clause=None,
    )


# Generated at 2022-06-24 10:44:29.140612
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    field = OneOf([String(), String(max_length=10)])
    assert field.validate("hello") == "hello"
    with raises(ValidationError):
        field.validate("The quick brown fox jumps over the lazy dog")


# Generated at 2022-06-24 10:44:32.441581
# Unit test for method validate of class AllOf
def test_AllOf_validate():

    class InnerField(Field):
        def validate(self, value, strict=False):
            return value
    innerField = InnerField()

    allField = AllOf([innerField, innerField, innerField])

    assert allField.validate("Hello") == "Hello"



# Generated at 2022-06-24 10:44:37.632588
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    try:
        field.validate(42)
    except field.validation_error:
        pass
    else:
        assert False, "validation_error not raised"

# Generated at 2022-06-24 10:44:50.755010
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field_one = Field(name='one')
    field_two = Field(name='two')
    field_three = Field(name='three')

    if_then_else_field = IfThenElse(if_clause=field_one, then_clause=field_two)
    assert if_then_else_field.validate(value='one') == 'one'

    if_then_else_field = IfThenElse(if_clause=field_one, then_clause=field_two, else_clause=field_three)
    assert if_then_else_field.validate(value='one') == 'one'
    assert if_then_else_field.validate(value='three') == 'three'


# Generated at 2022-06-24 10:44:55.935943
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a = AllOf([str])
    assert a.validate('fdfd') == 'fdfd'
    try:
        a.validate('fdfd')
    except ValueError:
        assert True
    else:
        assert False
    # TODO: Add more tests, this only checks that the method runs without error


# Generated at 2022-06-24 10:45:00.337240
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(String(), else_clause=Dict[String, String]())
    assert field.__dict__ == {'child': None, 'if_clause': String(), 'then_clause': Any(), 'else_clause': Dict[String, String]()}



# Generated at 2022-06-24 10:45:01.128776
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    N = NeverMatch()


# Generated at 2022-06-24 10:45:11.525987
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IfThenClass(Field):
        def __init__(self, if_clause: Field, then_clause: Field = None, else_clause: Field = None, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
            self.if_clause = if_clause
            self.then_clause = Any() if then_clause is None else then_clause
            self.else_clause = Any() if else_clause is None else else_clause

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            _, error = self.if_clause.validate_or_error(value, strict=strict)

# Generated at 2022-06-24 10:45:12.602915
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([]) is not None


# Generated at 2022-06-24 10:45:14.873779
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf(["name", "age"])
    assert field.one_of == ["name", "age"]
    
test_OneOf()

# Generated at 2022-06-24 10:45:16.704496
# Unit test for constructor of class AllOf
def test_AllOf():
    fields = [Field(), Field()]
    a = AllOf(fields)
    assert a.all_of == fields


# Generated at 2022-06-24 10:45:18.453851
# Unit test for constructor of class AllOf
def test_AllOf():
    '''
    Unit test for constructor of class AllOf
    '''
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-24 10:45:22.746302
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    def test_if_true():
        return 1
    
    def test_if_false():
        return 2

    result = test_if_true()

    test_case = Field()
    assert(result == 1)
    assert(test_case.allow_null == False)



# Generated at 2022-06-24 10:45:23.807423
# Unit test for constructor of class AllOf
def test_AllOf():
    instance = AllOf(all_of=[])


# Generated at 2022-06-24 10:45:27.408208
# Unit test for constructor of class AllOf
def test_AllOf():
    # Constructor
    # all_of: List[Field]

    # int_field = Field(serializer=serializers.IntegerField(), required=True)
    # all_int_field = AllOf(all_of=[int_field, int_field])
    pass # TODO


# Generated at 2022-06-24 10:45:30.449161
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause=String(),
        then_clause=String(),
        else_clause=String()
    )



# Generated at 2022-06-24 10:45:35.246424
# Unit test for constructor of class AllOf
def test_AllOf():
    field1 = Field()
    field2 = Field()
    field3 = Field()
    list1 = [field1, field2, field3]
    all_of_test = AllOf(all_of=list1)
    assert all_of_test.all_of == list1


# Generated at 2022-06-24 10:45:38.211926
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:45:41.767939
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem
    import json
    allOf = AllOf([typesystem.Integer(), typesystem.Integer()])
    print(json.dumps(allOf.schema(), indent=2))


# Generated at 2022-06-24 10:45:47.142836
# Unit test for constructor of class Not
def test_Not():
    not_int_obj=Not(Integer(), name="invalid_int")
    assert len(not_int_obj.errors) == 1
    assert "negated" in not_int_obj.errors
    assert not_int_obj.negated.name == "integer"
    assert not_int_obj.name == "invalid_int"


# Generated at 2022-06-24 10:45:49.578586
# Unit test for method validate of class OneOf
def test_OneOf_validate():
  a = OneOf(one_of=[String(), Number()])
  assert a.validate("string") == "string"
  assert a.validate(1) == 1


# Generated at 2022-06-24 10:45:54.614986
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String, Integer

    # Valid
    field_1 = AllOf([String(), Integer()])
    field_1.validate(5)

    # Invalid
    field_2 = AllOf([String(), Integer()])
    try:
        field_2.validate('test')
        assert False
    except TypeError:
        pass



# Generated at 2022-06-24 10:46:01.753336
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = IfThenElse(Int())
    assert(x.if_clause.__class__.__name__ == "Int")
    assert(x.then_clause.__class__.__name__ == "Any")
    assert(x.else_clause.__class__.__name__ == "Any")
    x = IfThenElse(Str(), then_clause=Boolean())
    assert(x.if_clause.__class__.__name__ == "Str")
    assert(x.then_clause.__class__.__name__ == "Boolean")
    assert(x.else_clause.__class__.__name__ == "Any")
    x = IfThenElse(Str(), else_clause=Boolean())

# Generated at 2022-06-24 10:46:05.537229
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String

    assert IfThenElse(
        String(), String(), String()
    ).then_clause.__class__.__name__ == 'String'
    assert IfThenElse(
        String(), String(), String()
    ).else_clause.__class__.__name__ == 'String'

# Generated at 2022-06-24 10:46:10.131462
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    a = NeverMatch()
    assert a.validate("a", strict=False) == "a"
    # Test error
    try:
        a.validate("a", strict=True)
        assert False
    except Exception as e:
        assert e.code == "never"

# Generated at 2022-06-24 10:46:21.731318
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause_is_valid = True
    value = "1"

    def validate_if(value: typing.Any, strict: bool = False) -> typing.Any:
        if if_clause_is_valid:
            return value
        else:
            raise Exception("Invalid")

    then_clause = Field(validate=validate_if)

    def validate_else(value: typing.Any, strict: bool = False) -> typing.Any:
        if not if_clause_is_valid:
            return value
        else:
            raise Exception("Invalid")

    else_clause = Field(validate=validate_else)


# Generated at 2022-06-24 10:46:33.563701
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from .types import String

    string_field = String()
    if_clause = string_field
    then_clause = string_field
    else_clause = string_field

    IfThenElse(if_clause, then_clause, else_clause)
    IfThenElse(if_clause, then_clause)
    IfThenElse(if_clause, else_clause=else_clause)
    # then_clause and else_clause are the same; the else clause
    # is dropped, but this is OK
    IfThenElse(if_clause, then_clause, then_clause)


# Generated at 2022-06-24 10:46:34.058199
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])

# Generated at 2022-06-24 10:46:44.797821
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import Boolean, Boolean, Integer
    a = True
    b = False
    x = 0
    y = 1
    if_clause = Boolean( True)
    then_clause = Boolean(a)
    else_clause = Boolean(b)
    c = IfThenElse(if_clause=if_clause,then_clause=then_clause,else_clause=else_clause, format='default')
    assert c.if_clause==Boolean(True)
    assert c.then_clause==Boolean(True)
    assert c.else_clause==Boolean(False)
    assert c.validate(x)==Boolean(True)
    assert c.validate(y)==Boolean(False)
    if_clause = Boolean( False)
    then_

# Generated at 2022-06-24 10:46:51.449632
# Unit test for constructor of class Not
def test_Not():
    class test_field(Field):
        pass

    try:
        _ = Not('string')
        assert False
    except AssertionError:
        pass

    assert isinstance(Not(test_field()), Not)
    assert isinstance(Not(test_field(), errors={'negated': 'Must not match'}), Not)

# Generated at 2022-06-24 10:46:54.224914
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.name is None
    assert field.label is None
    assert field.description is None
    assert field.required is False
    assert field.validate(1, strict=True) == 1
    assert field.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:47:03.551299
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import pytest
    from typesystem import Integer

    class A(AllOf):
        name = "AllOf_test"
        all_of = [Integer(default=10),
                  Integer(default=20),
                  Integer()]

    a = A()

    assert a.validate(20) == 20

    with pytest.raises(a.validation_error) as e:
        assert a.validate(20.5)

    assert e.value.code == "invalid"
    assert e.value.message == "Not a valid integer."
    assert e.value.detail == 20.5

    assert a.validate(30) == 30


# Generated at 2022-06-24 10:47:06.248819
# Unit test for method validate of class Not
def test_Not_validate():
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    n = Not(if_clause, then_clause, else_clause)


# Generated at 2022-06-24 10:47:12.068566
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)

    assert isinstance(field.validate(1), str)
    assert isinstance(field.validate("not an integer"), str)
    assert isinstance(field.validate(1.1), str)

test_IfThenElse_validate()

# Generated at 2022-06-24 10:47:13.781894
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    result = NeverMatch().validate('test')
    assert result is None


# Generated at 2022-06-24 10:47:15.194696
# Unit test for constructor of class AllOf
def test_AllOf():
    print("test_AllOf")
    class MyClass(Field):
        pass
    a = MyClass(name="a")
    b = AllOf([a])


test_AllOf()

# Generated at 2022-06-24 10:47:16.208775
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=1, then_clause=2, else_clause=3, **{})

# Generated at 2022-06-24 10:47:22.620877
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Any()
    then_clause = Any()
    else_clause = None

    f = IfThenElse(if_clause, then_clause, else_clause)
    assert f.if_clause == if_clause
    assert f.then_clause == then_clause
    assert f.else_clause == else_clause

# Generated at 2022-06-24 10:47:32.051635
# Unit test for method validate of class AllOf

# Generated at 2022-06-24 10:47:33.975727
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([1])
    assert a


# Generated at 2022-06-24 10:47:44.118151
# Unit test for method validate of class Not
def test_Not_validate():
    import json

    # Success
    schema = Not(negated={'type': 'string'})
    data = 'hello'
    try:
        schema.validate(data)
    except Exception as e:
        output = {'valid': False, 'message': 'Expected no error but got one'}
    else:
        output = {'valid': True}

    print(json.dumps(output, sort_keys=True, indent=4, separators=(',', ': ')))

    # Failure: validation error
    schema = Not(negated={'type': 'string'})
    data = 5
    try:
        schema.validate(data)
    except Exception as e:
        output = {'valid': False, 'message': e.message}
    else:
        output = {'valid': True}

    print

# Generated at 2022-06-24 10:47:47.301268
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=Any()).validate(1) == 1
    try:
        Not(negated=Any()).validate(None)
    except Exception as e:
        assert str(e) == "Must not match."

# Generated at 2022-06-24 10:47:52.658144
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test if an error is raised when the value cannot be found in one of the defined fields.
    schema = OneOf(one_of = [Int(), Str()])
    with pytest.raises(ValidationError) as excinfo:
        schema.validate(True)
    assert excinfo.value.code == "no_match"

    # Test if an error is raised when the value can be found in multiple defined fields.
    schema = OneOf(one_of = [Int(), Str(), Int()])
    with pytest.raises(ValidationError) as excinfo:
        schema.validate(1)
    assert excinfo.value.code == "multiple_matches"

    # Test if value is valid in one of the defined fields.
    schema = OneOf(one_of=[Int(), Str()])

# Generated at 2022-06-24 10:47:56.562173
# Unit test for constructor of class Not
def test_Not():
    Not(AllOf).__class__.__name__
    Not(AllOf())
    Not(AllOf(one_of=[AllOf(one_of=[Any()])]))

# Generated at 2022-06-24 10:47:58.414954
# Unit test for constructor of class Not
def test_Not():
    field = Field(name="field")
    assert field.name == "field"

# Generated at 2022-06-24 10:48:03.237314
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class A(Field):
        pass
    a = A()
    
    class B(Field):
        pass
    b = B()
    
    class C(Field):
        pass
    c = C()

    assert OneOf([a,b,c]).validate({}) == {}
    assert OneOf([a,b,c]).validate({}, strict=True) == {}
    
    

# Generated at 2022-06-24 10:48:11.830484
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of_fields = [Field(), Field()]
    all_of_field = AllOf(all_of_fields)
    all_of_field.validate('String')
    all_of_field.validate('String', strict='String')
    all_of_field.validate(1)
    all_of_field.validate(1, strict=1)
    all_of_field.validate(1.0)
    all_of_field.validate(1.0, strict=1.0)


# Generated at 2022-06-24 10:48:14.332926
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
        assert False
    except:
        assert True


# Generated at 2022-06-24 10:48:19.490645
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.exceptions import ValidationError
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    rule = IfThenElse(if_clause, then_clause, else_clause)
    try:
        rule.validate("value")
    except ValidationError as e:
        e.args[0] == 'value'
        e.args[1] == 'value'
        e.args[2] == 'value'
        e.args[3] == 'value'

# Generated at 2022-06-24 10:48:22.058327
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    with pytest.raises(n.validation_error):
        n.validate(None)


# Generated at 2022-06-24 10:48:24.693079
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    value = "some_value"
    assert not_field.validate(value) == value


# Generated at 2022-06-24 10:48:33.173626
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # Test with if_clause and then_clause and else_clause
    ifthenelse = IfThenElse(if_clause=Integer(min_value=1),then_clause=String(min_length=2))
    ifthenelse.validate(-2)
    ifthenelse.validate(2)
    ifthenelse.validate(-1.5)


    # Test with if_clause and then_clause
    ifthenelse = IfThenElse(if_clause=Integer(min_value=1),then_clause=String(min_length=2))
    ifthenelse.validate(-2)
    ifthenelse.validate(2)
    ifthenelse.validate(-1.5)


    # Test with if_clause and else_clause
    ifthenelse = IfThenElse