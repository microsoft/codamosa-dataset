

# Generated at 2022-06-24 10:38:35.309174
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # check IfThenElse class can't be called
    FG = IfThenElse()
    with pytest.raises(TypeError):
        fg = FG()

# Generated at 2022-06-24 10:38:39.241848
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ITE = IfThenElse(String(),Integer(),String())
    assert ITE.validate('good') == 'good'
    assert ITE.validate(1) == 1


# Generated at 2022-06-24 10:38:42.529318
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    from typesystem.types import DateTime
    ite = IfThenElse(String(), DateTime())
    assert ite is not None

# Generated at 2022-06-24 10:38:46.804359
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import String

    assert AllOf(all_of=[])

# Generated at 2022-06-24 10:38:56.318511
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = ClassName(min_length=5)
    then_clause = ClassName(max_length=10)
    else_clause = ClassName()
    obj = IfThenElse(if_clause=if_clause, then_clause=then_clause, else_clause=else_clause)
    # Valid values
    assert obj.validate("12345") == "12345"
    assert obj.validate("123456") == "123456"
    assert obj.validate("12345678910") == "12345678910"
    # Invalid values
    try:
        obj.validate("1234")
        assert False
    except ValidationError as e:
        assert e.detail["code"] == "if_clause"

# Generated at 2022-06-24 10:38:59.178601
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(name="never_match")
    assert field.name == "never_match"
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:39:08.385385
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Tests AllOf.validate()
    # Valid cases
    assert AllOf([Any()]).validate(None) is None
    assert AllOf([Any()]).validate(1) == 1
    assert AllOf([Any(), Any()]).validate(1) == 1
    assert AllOf([Any(), Any()]).validate(2) == 2
    assert AllOf([Any(), Any()]).validate(3) == 3
    assert AllOf([Any(), Any(), Any()]).validate(1) == 1
    assert AllOf([Any(), Any(), Any()]).validate(2) == 2
    assert AllOf([Any(), Any(), Any()]).validate(3) == 3

    # Invalid cases
    try: AllOf([Any()]).validate(1.1)
    except Exception as e: assert str(e) == 'invalid'

# Generated at 2022-06-24 10:39:10.940227
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Test case for method validate of class Not
    """
    test_field = Not(
        negated=Integer(),
    )
    test_value = 1
    test_result = test_field.validate(
        test_value,
        strict=True,
    )
    assert test_result == test_value

# Generated at 2022-06-24 10:39:16.393232
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    N = NeverMatch()
    assert N.validate(None) is None
    try:
        N.validate(1)
    except Exception as e:
        print(e)
        assert str(e) == "This never validates."

# Generated at 2022-06-24 10:39:20.556380
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(None)
    # positive test with not matching sub-field
    assert field.validate(1) == 1
    # negative test with matching sub-field
    try:
        field.validate(None)
        assert False
    except ValidationError as ex:
        assert ex.as_dict() == {'negated': 'Must not match.'}

# Generated at 2022-06-24 10:39:22.292341
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Field())
    assert not_field.negated is not None

# Generated at 2022-06-24 10:39:24.739997
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
    except AssertionError as e:
        assert False, "Never Match constructor failed"
    except:
        assert True


# Generated at 2022-06-24 10:39:26.838170
# Unit test for method validate of class Not
def test_Not_validate():
    not_clause = Not(Any())
    _, error = not_clause.validate_or_error(None)
    assert error is None


# Generated at 2022-06-24 10:39:28.535258
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch() is not None


# Generated at 2022-06-24 10:39:38.838277
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    a = OneOf([])
    with pytest.raises(TypeSystemError):
        a.validate(1)

    a = OneOf([Int()])
    assert a.validate(1) == 1

    a = OneOf([Int(), String()])
    with pytest.raises(TypeSystemError):
        a.validate(1.0)

    a = OneOf([Float(), String()])
    with pytest.raises(TypeSystemError):
        a.validate(1)
    assert a.validate(1.0) == 1.0
    assert a.validate('1.0') == '1.0'



# Generated at 2022-06-24 10:39:43.572512
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    t = AllOf([Integer(), String()], description="all_of")
    t.validate(1)
    t.validate("test")
    t.validate("1")
    t.validate(1.0)
    t.validate(False)
    t.validate(True)
    try:
        t.validate({"key": "value"})
    except Exception:
        return True
    return False


# Generated at 2022-06-24 10:39:52.988689
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(
        one_of=[
            Integer(minimum=0, maximum=10),
            String(max_length=10),
        ],
    )

    assert field.validate(5) == 5
    assert field.validate("hello") == "hello"
    with pytest.raises(
        ValidationError, match="Did not match any valid type."
    ):
        field.validate("hello world")  # type: ignore
    with pytest.raises(
        ValidationError, match="Matched more than one type."
    ):
        field.validate(17)  # type: ignore

# Generated at 2022-06-24 10:39:58.679389
# Unit test for method validate of class Not
def test_Not_validate():
    """ test_Not_validate """
    obj = Not(Int())
    assert obj.validate(None) == None

    obj = Not(Int(), allow_null=True)
    assert obj.validate(None) == None

    obj = Not(Int(), allow_null=False)
    assert obj.validate(None) == None

    obj = Not(Int(), allow_null=False)
    try:
        obj.validate(1)
    except Exception as e:
        print(e.args)
    # String.validate_or_error(1, strict=True)

    obj = Not(Int(), allow_null=False)
    try:
        obj.validate('')
    except Exception as e:
        print(e.args)
    # String.validate_or_error('', strict=True

# Generated at 2022-06-24 10:40:02.084020
# Unit test for constructor of class Not
def test_Not():
    assert "allow_null" not in Not.__init__.__code__.co_varnames
    assert "kwargs" in Not.__init__.__code__.co_varnames

# Generated at 2022-06-24 10:40:05.158255
# Unit test for constructor of class Not
def test_Not():
    n = Not(negated=None)



# Generated at 2022-06-24 10:40:08.710729
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of_field = AllOf([Any()])
    all_of_field.validate(1)
    all_of_field.validate("test")

# Generated at 2022-06-24 10:40:10.040097
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=NeverMatch())

# Generated at 2022-06-24 10:40:14.689138
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    test = IfThenElse(if_clause=Integer(), then_clause=String(), else_clause=Float())
    test.validate(1)
    test.validate('1')
    test.validate(1.0)
    try:
        test.validate('a')
    except Exception as e:
        assert True
    try:
        test.validate(True)
    except Exception as e:
        assert True


# Generated at 2022-06-24 10:40:15.900088
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf(one_of=[])


# Generated at 2022-06-24 10:40:16.680315
# Unit test for constructor of class Not
def test_Not():
    assert Not

# Generated at 2022-06-24 10:40:21.632515
# Unit test for method validate of class Not
def test_Not_validate():
    import pytest

    def test_method():
        from typesystem.fields import String

        field = Not(String())
        with pytest.raises(ValueError):
            field.validate()

    test_method()

# Generated at 2022-06-24 10:40:25.010094
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f = IfThenElse(
        {"type": "string"},
        {"type": "integer"},
        {"type": "boolean"}
    )
    v = f.validate("string")
    assert v == "string"




# Generated at 2022-06-24 10:40:33.173719
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause={"type": "number"}, then_clause={"type": "string"})
    assert field.validate(0) == "0"
    assert field.validate(5) == "5"
    field.else_clause = {"type": "integer"}
    assert field.validate(0) == 0
    assert field.validate(5) == 5
    field = IfThenElse(if_clause={"type": "string"}, then_clause={"type": "string"})
    assert field.validate("0") == "0"
    assert field.validate("5") == "5"
    field.else_clause = {"type": "integer"}
    assert field.validate("0") == "0"
    assert field.validate("5") == "5"

# Generated at 2022-06-24 10:40:34.970782
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause = None,
        then_clause = None,
        else_clause = None,
        description = '',
        enum = None,
        example = None,
        format = None,
        title = None,
    )
    assert field

# Generated at 2022-06-24 10:40:40.943785
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import AllOf, Array
    from typesystem.fields import Integer

    integer_array = AllOf([Array(), Array(items=Integer())])

    # Valid case
    integer_array.validate([1, 2, 3])

    # Invalid case
    try:
        integer_array.validate([1, 2.5, 3])
    except Exception as e:
        # Expect to be here
        assert str(e) == "Field did not validate: ['2.5']"

# Generated at 2022-06-24 10:40:42.958803
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Integer, String
    out = AllOf([Integer(), String()]).validate(1)
    assert out == 1



# Generated at 2022-06-24 10:40:44.397252
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem.exceptions import ValidationError
    field = NeverMatch()
    with pytest.raises(ValidationError):
        field.validate(None)


# Generated at 2022-06-24 10:40:46.401839
# Unit test for constructor of class AllOf
def test_AllOf():
    # noinspection PyTypeChecker
    obj = AllOf([])
    assert obj != 134
    assert obj is not None


# Generated at 2022-06-24 10:40:49.948651
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1

# Generated at 2022-06-24 10:40:55.088539
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of_field = AllOf([
        Field(allow_null=True),
        String(max_length=10)
    ])

    try:
        all_of_field.validate(None)
    except Exception as e:
        print('AllOf.validate: null')
        assert(False)

    try:
        all_of_field.validate('')
    except Exception as e:
        print('AllOf.validate: empty')
        assert(False)

    try:
        all_of_field.validate('test')
    except Exception as e:
        print('AllOf.validate: normal')
        assert(False)

    try:
        all_of_field.validate(123)
    except Exception as e:
        print('AllOf.validate: scalar')

# Generated at 2022-06-24 10:41:05.630164
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # test for no clauses
    assert str(IfThenElse(IfThenElse())) == "ifThenElse([ifThenElse([any()])])"
    # test for only if clause
    assert str(IfThenElse(IfThenElse(), IfThenElse())) == "ifThenElse([ifThenElse([any()])], [ifThenElse([any()])])"
    # test for only else clause
    assert str(IfThenElse(IfThenElse(), None, IfThenElse())) == "ifThenElse([ifThenElse([any()])], else=[ifThenElse([any()])])"
    # test for then and else clause

# Generated at 2022-06-24 10:41:07.509913
# Unit test for constructor of class AllOf
def test_AllOf():
    a_field = Integer()
    test_AllOf = AllOf([a_field])
    assert test_AllOf.all_of[0] == a_field



# Generated at 2022-06-24 10:41:11.722455
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String
    a = AllOf(all_of=[String()]).validate("hello")
    assert a == "hello"



# Generated at 2022-06-24 10:41:13.336113
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-24 10:41:14.272659
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch()



# Generated at 2022-06-24 10:41:18.641876
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    a = IfThenElse(if_clause, then_clause, else_clause)


# Generated at 2022-06-24 10:41:28.388310
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = IfThenElse(if_clause=Field)
    assert if_clause.if_clause == Field
    assert if_clause.then_clause == Any()
    assert if_clause.else_clause == Any()

    if_clause = IfThenElse(if_clause=Field, then_clause=Field)
    assert if_clause.if_clause == Field
    assert if_clause.then_clause == Field
    assert if_clause.else_clause == Any()

    if_clause = IfThenElse(if_clause=Field, then_clause=Field, else_clause=Field)
    assert if_clause.if_clause == Field
    assert if_clause.then_clause == Field
    assert if_clause.else_

# Generated at 2022-06-24 10:41:34.075892
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    input_value = 'a'
    field = IfThenElse(if_clause=input_value, then_clause=5, else_clause=9)
    o = None
    try:
        o = field.validate(input_value)
    except:
        pass
    if (o != 5):
        raise AssertionError()


# Generated at 2022-06-24 10:41:44.925919
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Integer
    from typesystem import String
    if_clause = Integer(description="if clause")
    then_clause = String(description="then clause")
    else_clause = String(description="else clause")

    if_then_else = IfThenElse(
        if_clause=if_clause,
        then_clause=then_clause,
        else_clause=else_clause,
        description="if-then-else clause"
    )
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause
    assert if_then_else.description == "if-then-else clause"

# Generated at 2022-06-24 10:41:48.176824
# Unit test for constructor of class AllOf
def test_AllOf():
    Field.register(Field)
    test = AllOf([Field(), Field()])
    print(type(test))
    print(repr(test))
    assert repr(test) == "AllOf(all_of=[Field(), Field()], description=None, title=None)"



# Generated at 2022-06-24 10:41:53.397245
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    one_of = OneOf([])
    if_then_else = IfThenElse(OneOf([]))
    assert if_then_else.then_clause == one_of
    assert if_then_else.else_clause == one_of


# Generated at 2022-06-24 10:41:55.693291
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-24 10:42:01.951222
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # create OneOf object
    oneOf = OneOf(one_of = [])

    # testing error when no match
    with pytest.raises(AssertionError) as info:
        oneOf.validate("text")
    assert str(info.value) == oneOf.errors["no_match"]
    
    # testing error when multiple matches
    with pytest.raises(AssertionError) as info:
        oneOf.validate(1)
    assert str(info.value) == oneOf.errors["multiple_matches"]

    # testing correct output
    assert oneOf.validate(1) is not None


# Generated at 2022-06-24 10:42:03.593340
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(default="a")
    assert field.default == "a"


# Generated at 2022-06-24 10:42:07.885437
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem import Integer, String

    #json_schema_fields.OneOf(one_of=["integer", "string"])
    #json_schema_fields.OneOf(one_of=[Integer, String])
    assert json_schema_fields.OneOf(one_of=[Integer, String])


# Generated at 2022-06-24 10:42:10.415528
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of_field = OneOf(
        one_of=[
            Integer(minimum=1, maximum=4).with_title("OneOf Integer"), 
            String(max_length=4).with_title("OneOf String"), 
            ]
        )

    assert one_of_field.validate(3) == 3
    assert one_of_field.validate("abc") == "abc"
    with raises(ValidationError):
        one_of_field.validate(5)
    with raises(ValidationError):
        one_of_field.validate("hello")

# Generated at 2022-06-24 10:42:12.194378
# Unit test for constructor of class Not
def test_Not():
    negated = Field()
    not_ = Not(negated)
    assert not_.negated == negated

# Generated at 2022-06-24 10:42:18.227703
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem import Schema
    from typesystem.typing import JSONSchema

    class Never(Schema):
        test = NeverMatch()

    schema: JSONSchema = Never().schema(use_refs=False)

# Generated at 2022-06-24 10:42:19.229698
# Unit test for constructor of class AllOf
def test_AllOf():
    assert 1



# Generated at 2022-06-24 10:42:24.749297
# Unit test for method validate of class Not
def test_Not_validate():
    # field_object used for testing
    field_object = Not(
        negated=Any()
    )

    # Test for validate: return value of validate is expected value
    assert field_object.validate(value=2) == 2
    assert field_object.validate(value=True) == True
    assert field_object.validate(value=False) == False



# Generated at 2022-06-24 10:42:26.688082
# Unit test for constructor of class Not
def test_Not():
    "Test instantiation of the Not class."
    not_field = Not(Field("Field"))
    assert not_field.negated.name == "Field"

# Generated at 2022-06-24 10:42:27.920873
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[Field()])


# Generated at 2022-06-24 10:42:28.858238
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    i = IfThenElse(if_clause=Field(), then_clause=Field)

# Generated at 2022-06-24 10:42:33.301648
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Test for method validate of class Not

    Ensure:
        1. if error is not none, it must return value
        2. if error is none, it must raise exception
    """
    negated = Field()
    negated.error = {"error": "error"}
    negated.validate_or_error = lambda value, strict=False: (value, None)
    not_failed = Not(negated)
    assert not_failed.validate(10) == 10
    negated.validate_or_error = lambda value, strict=False: (value, "error")
    assert not_failed.validate(10) == 10

# Generated at 2022-06-24 10:42:34.353566
# Unit test for constructor of class Not
def test_Not():
    p = Not(negated=int)

# Generated at 2022-06-24 10:42:35.373539
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("")


# Generated at 2022-06-24 10:42:36.155916
# Unit test for constructor of class Not
def test_Not():
    def test():
        schema = Not(Integer())

    test()

# Generated at 2022-06-24 10:42:38.867617
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.typing import String
    assert IfThenElse(if_clause=String()).validate(1) == 1

# Generated at 2022-06-24 10:42:41.271191
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)
    assert field.__dict__ == {'errors': {'negated': 'Must not match.'}, 'negated': None}

# Generated at 2022-06-24 10:42:45.624390
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    never_match = NeverMatch()
    try:
        never_match.validate(1)
    except AssertionError:
        print("AssertionError caught. Test passed.")
    else:
        print("Test failed.")


# Generated at 2022-06-24 10:42:54.813223
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.errors import ValidationError

    clause = IfThenElse(
        if_clause=String(min_length=3),
        then_clause=String(max_length=5),
        else_clause=String(max_length=10)
    )

    assert clause.validate("long") == "long"
    assert clause.validate("longer") == "longer"
    assert clause.validate("longest") == "longest"

    exception = None
    try:
        clause.validate("longes")
    except ValidationError as e:
        exception = e
    assert str(exception) == "String must be at most 5 characters long."

    assert clause.validate("short") == "short"

# Generated at 2022-06-24 10:43:05.599555
# Unit test for method validate of class Not
def test_Not_validate():
    msg = {'type': 'object', 'properties': {'name': {'type': 'string'}}, 'required': ['name']}
    f = Not(Any())
    f.validate(msg) #no raise exception expected

    msg = {'type': 'object', 'properties': {'name': {'type': 'string'}}, 'required': ['name']}
    f = Not(Any())
    f.validate(msg) #no raise exception expected

    msg = {'type': 'object', 'properties': {'name': {'type': 'string'}}, 'required': ['name']}
    f = Not(Any())
    f.validate(msg) #no raise exception expected


# Generated at 2022-06-24 10:43:15.207330
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = IfThenElse(NeverMatch(), NeverMatch(), NeverMatch())

    with pytest.raises(IfThenElse.validation_error) as excinfo:
        if_clause.validate(True)
    assert str(excinfo.value) == "Must not match."

    else_clause = IfThenElse(NeverMatch(), else_clause=NeverMatch())

    with pytest.raises(IfThenElse.validation_error) as excinfo:
        else_clause.validate(True)
    assert str(excinfo.value) == "Must not match."

    then_clause = IfThenElse(NeverMatch(), then_clause=NeverMatch())

    with pytest.raises(NeverMatch.validation_error) as excinfo:
        then_clause.validate(True)

# Generated at 2022-06-24 10:43:18.752533
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem import Integer
    from typesystem import String
    from typesystem.types.schema import AllOf

    inner_type = Integer(minimum=10, maximum=20)
    all_of = AllOf([String(), inner_type])

    assert all_of.validate(10) == "10"
    assert all_of.validate(30) == 30


# Generated at 2022-06-24 10:43:22.020676
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    a = IfThenElse(
        if_clause=NeverMatch(),
        then_clause=Any(),
        else_clause=Any(),
    )
    a.validate(value="test")


# Generated at 2022-06-24 10:43:22.578866
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert True

# Generated at 2022-06-24 10:43:25.698200
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class Object:
        pass
    with pytest.raises(AssertionError):
        Object = AllOf([])


# Generated at 2022-06-24 10:43:28.835862
# Unit test for constructor of class Not
def test_Not():
    import typesystem
    field = typesystem.Field()
    field2 = typesystem.Field()
    Not(field, field2)


# Generated at 2022-06-24 10:43:31.543826
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch()
    assert obj is not None


# Generated at 2022-06-24 10:43:34.512831
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
	my_object = NeverMatch('test', never='test')
	assert my_object.name == 'test'


# Generated at 2022-06-24 10:43:37.362903
# Unit test for constructor of class OneOf
def test_OneOf():
    a=OneOf([])
    assert a.one_of==[]
    b=OneOf([1,2,3])
    assert b.one_of==[1,2,3]


# Generated at 2022-06-24 10:43:39.073351
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([], name="name")
    assert a.name == "name"



# Generated at 2022-06-24 10:43:40.683233
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    instance = NeverMatch()
    try:
        instance.validate("value")
        assert False
    except:
        assert True


# Generated at 2022-06-24 10:43:43.820602
# Unit test for constructor of class AllOf
def test_AllOf():
	assert AllOf([])
	

# Generated at 2022-06-24 10:43:44.645156
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    pass # TODO


# Generated at 2022-06-24 10:43:52.679544
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Any())
    assert n.validate(None) is None
    assert n.validate(True) is True
    assert n.validate(False) is False
    assert n.validate(1) == 1
    assert n.validate(1.1) == 1.1
    assert n.validate(1+2j) == 1+2j
    assert n.validate('') == ''
    assert n.validate('abc') == 'abc'
    assert n.validate([]) == []
    assert n.validate([1, 2, 3]) == [1, 2, 3]
    assert n.validate({}) == {}
    assert n.validate({1:'a', 2:'b', 3:'c'}) == {1:'a', 2:'b', 3:'c'}
    assert n

# Generated at 2022-06-24 10:43:57.443585
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch(name="name")
    try:
        field.validate(1)
        assert False, "Expected exception"
    except Exception as e:
        assert str(e) == "ValidationError: " \
                        "name is not valid under any of the given schemas: " \
                        "name never", \
            "Expected different error message"

# Generated at 2022-06-24 10:43:59.695955
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    test_field = AllOf([DummyField("test_field")])
    test_field.validate("object")
    assert True

# Generated at 2022-06-24 10:44:02.747690
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Int(), String(min_length=2)])
    assert field.validate(1) is None
    assert field.validate("a") is None
    assert field.validate("ab") is None
    assert field.validate("abc") is None


# Generated at 2022-06-24 10:44:07.582088
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    t = IfThenElse()
    assert t.if_clause == Any()
    assert t.then_clause == Any()
    assert t.else_clause == Any()
    t = IfThenElse(if_clause=Field(), then_clause=Field(nullable=True), else_clause=Field(description="A"))
    assert t.if_clause == Field()
    assert t.then_clause == Field(nullable=True)
    assert t.else_clause == Field(description="A")

# Generated at 2022-06-24 10:44:08.124371
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    pass

# Generated at 2022-06-24 10:44:09.895295
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(NeverMatch())

    # Check that Not returns value and not error object
    result, error = field.validate_or_error(1)
    assert error is None
    assert result == 1


# Generated at 2022-06-24 10:44:14.611226
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # In order to test the constructor of class NeverMatch, N2 must be defined as an object
    # of class NeverMatch
    N2 = NeverMatch()
    assert N2.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:44:15.819437
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert [0] == NeverMatch().validate(0)

# Generated at 2022-06-24 10:44:24.084447
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Number(minimum=3)).validate(3) == 3
    assert IfThenElse(Number(maximum=3), Number(minimum=3)).validate(3) == 3
    assert IfThenElse(Number(maximum=3), Number(minimum=3), Number(maximum=3)).validate(3) == 3

    with pytest.raises(ValidationError) as exc_info:
        IfThenElse(Number(maximum=3)).validate(3)
    assert exc_info.value.code == "type"

    with pytest.raises(ValidationError) as exc_info:
        IfThenElse(Number(maximum=3), Number(maximum=3)).validate(3)
    assert exc_info.value.code == "type"


# Generated at 2022-06-24 10:44:25.373731
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate('abc') == None


# Generated at 2022-06-24 10:44:30.248380
# Unit test for method validate of class Not
def test_Not_validate():
    _, error = Not(negated=True).validate_or_error(value=False)
    assert error.code == "negated"

    value, error = Not(negated=True).validate_or_error(value=True)
    assert value == True
    assert error is None



# Generated at 2022-06-24 10:44:31.136690
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert True


# Generated at 2022-06-24 10:44:41.537742
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Integer(minimum=10)
    then_clause = Integer(maximum=100)
    else_clause = Integer(maximum=1)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-24 10:44:42.904259
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:44:46.028423
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """
    Creating a NeverMatch field
    """
    test_NeverMatch = NeverMatch()
    assert test_NeverMatch.__repr__() == 'NeverMatch()'
    assert test_NeverMatch.__str__() == 'NeverMatch()'
    assert test_NeverMatch.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:44:49.993351
# Unit test for constructor of class Not
def test_Not():
    num = types.Integer()
    notnum = Not(negated=num)
    nonumber = notnum.validate(value="hello")
    assert nonumber == "hello"

# Generated at 2022-06-24 10:44:53.788105
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(Boolean(), Number(), Integer(), name='number').validate(1) == 1
    assert IfThenElse(Boolean(), Number(), Integer(), name='number').validate(1.1) == 1.1

# Generated at 2022-06-24 10:45:01.331435
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Type1(Field):
        def validate(self, value, strict=False):
            return value
    class Type2(Field):
        def validate(self, value, strict=False):
            return value
    class Type3(Field):
        def validate(self, value, strict=False):
            return value
    test_value = 5
    field = IfThenElse(if_clause=Type1(), then_clause=Type2(), else_clause=Type3())
    result = field.validate(test_value)
    assert result == test_value

    field = IfThenElse(if_clause=Type1(), then_clause=Type2(), else_clause=Type3())
    result = field.validate(test_value)
    assert result == test_value


# Generated at 2022-06-24 10:45:05.493855
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    json = {'if_clause': 'if_clause_sample', 'then_clause': 'then_clause_sample', 'else_clause': 'else_clause_sample'}
    IfThenElse(**json)

# Generated at 2022-06-24 10:45:06.526053
# Unit test for constructor of class AllOf
def test_AllOf():
  a = AllOf()
  return

# Generated at 2022-06-24 10:45:14.216072
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    #1.
    class MockIf():
        def __init__(self):
            pass

        def validate_or_error(self, value, *args):
            return (1, None)

    mock_if = MockIf()

    class MockThen():
        def __init__(self):
            pass

        def validate(self, value, strict=False):
            return (value)

    mock_then = MockThen()

    class MockElse():
        def __init__(self):
            pass

        def validate(self, value, strict=False):
            return (value)

    mock_else = MockElse()

    obj = IfThenElse(mock_if, mock_then, mock_else)
    assert obj.validate(1) == 1


# Generated at 2022-06-24 10:45:24.215324
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    name = "OneOf"
    field_name = "oneOf_validate"

# Generated at 2022-06-24 10:45:27.736549
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([
        Field(label="foo"),
        Field(label="bar")
    ])

    assert field.validate({
        "foo": 1,
        "bar": 2
    }) == {
        "foo": 1,
        "bar": 2
    }



# Generated at 2022-06-24 10:45:29.723575
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        IfThenElse(None, None, None)
    except:
        assert False, "Unexpected error when test constructor of class IfThenElse"
    assert True, "No unexpected error when test constructor of class IfThenElse"

# Generated at 2022-06-24 10:45:39.403220
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(
        [
            types.Integer(),
            types.Boolean(),
            types.String(format="uuid"),
            types.Array(
                items=types.String(enum=["match", "not match"]),
                sequence_type=types.Sequence(min_length=1),
            ),
        ]
    )

    field.validate(3)
    field.validate(True)
    field.validate("32d5ce5e-1b9a-4944-be5b-df79f99bdf45")
    field.validate(["match"])

    with pytest.raises(errors.ValidationError) as exc_info:
        field.validate("This is not a valid UUID.")

# Generated at 2022-06-24 10:45:44.298764
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    a_list = AllOf(all_of=[
        Int(),
        MinLength(min_length=3),
        MaxLength(max_length=10),
    ])
    try:
        a_list.validate([1,2,3])
    except Exception:
        pass
    else:
        raise Exception("ValidationError not raised.")

# Generated at 2022-06-24 10:45:46.139407
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:45:55.978991
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    type1 = NeverMatch()
    assert type1.validate(5) == 5
    type1 = NeverMatch()
    assert type1.validate(6) == 6
    type1 = NeverMatch()
    assert type1.validate(7) == 7
    type1 = NeverMatch()
    assert type1.validate(8) == 8
    type1 = NeverMatch()
    assert type1.validate(9) == 9
    type1 = NeverMatch()
    assert type1.validate(10) == 10
    type1 = NeverMatch()
    assert type1.validate(11) == 11
    type1 = NeverMatch()
    assert type1.validate(12) == 12
    type1 = NeverMatch()
    assert type1.validate(13) == 13
    type1 = NeverMatch()

# Generated at 2022-06-24 10:46:07.469577
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class Foo(IfThenElse):
        def __init__(self, if_clause, then_clause = None, else_clause = None, **kwargs):
            super(Foo, self).__init__(if_clause, then_clause, else_clause, **kwargs)
    f=Foo(if_clause=None)
    assert f.if_clause == None
    assert f.then_clause != None
    assert f.else_clause != None
    c=Foo(if_clause=None, then_clause="hello")
    assert c.if_clause == None
    assert c.then_clause == "hello"
    assert c.else_clause != None
    d=Foo(if_clause=None, else_clause="world")

# Generated at 2022-06-24 10:46:12.171896
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Any(), Any()])
    value = {'test': 'test'}
    field.validate(value)
    assert 1 == 1
test_OneOf_validate()


# Generated at 2022-06-24 10:46:20.371482
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = {
        "type": "string",
        "minLength": 8
    }
    then_clause = {
        "type": "string",
        "minLength": 10
    }
    else_clause = {
        "type": "string",
        "minLength": 6
    }
    schema = {
        "type": "object",
        "properties": {
            "name": {
                "if": if_clause,
                "then": then_clause,
                "else": else_clause,
            }
        }
    }
    schema = Schema(schema)
    
    # Test of then_clause
    obj = {
        "name": "abcdefghi"
    }
    schema.validate(obj)
    
    # Test of else_

# Generated at 2022-06-24 10:46:33.518615
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # for the validation of the if_clause
    class Field_1(Field):
        def validate(self, value, strict):
            return value
    # for the validation of the then_clause
    class Field_2(Field):
        def validate(self, value, strict):
            return value + 1
    # for the validation of the else_clause
    class Field_3(Field):
        def validate(self, value, strict):
            return value + 2

    # create instances for the classes Field_1, Field_2 and Field_3
    field_1 = Field_1()
    field_2 = Field_2()
    field_3 = Field_3()
    # create an instance for IfThenElse
    if_then_else = IfThenElse(field_1, field_2, field_3)

    # test the

# Generated at 2022-06-24 10:46:40.569234
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    # arrange
    from typesystem.types import String
    name = String()
    from typesystem.schema import Schema
    s = Schema(fields={"name": name})
    # act
    try:
        s.validate(value={"name":"test"})
    except s.Error as e:
        error = e
    # assert
    assert error.as_dict() == {"name": ["This never validates."]}


# Generated at 2022-06-24 10:46:43.918463
# Unit test for constructor of class OneOf
def test_OneOf():
    # Check that required fields are present
    expected = {
        'error': 'Must match exactly one of the sub-items.',
        'label': 'one_of'
    }
    actual = OneOf(one_of=[Field()]).serialize()
    assert actual == expected

# Generated at 2022-06-24 10:46:48.844141
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    test_field = AllOf([Boolean()])
    test_field.validate(True)
    test_field.validate(False)
    test_field.validate(1)


# Generated at 2022-06-24 10:46:49.844354
# Unit test for constructor of class Not
def test_Not():
  schema = Not(field = 1)


# Generated at 2022-06-24 10:46:57.088637
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class Person:
        name: str
        age: int

    if_clause = Field()

    person = Person()
    person.name = "John"
    person.age = 40

    if_clause.validate(person)

    then_clause = Field()
    then_clause.validate(person)

    else_clause = Field()
    else_clause.validate(person)

    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(person)

# Generated at 2022-06-24 10:47:04.491927
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf([Int(), Bool()])
    # Must match all field
    assert all_of.validate(value=1) == 1
    assert all_of.validate(value=True) == True
    # Fail if not match any field
    try:
        all_of.validate(value=1.2)
        assert False
    except ValidationError:
        assert True
    # Fail if not match one field
    try:
        all_of.validate(value=False)
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-24 10:47:12.366151
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(
        all_of=[
            Int(1),
            String("Hello"),
            Datetime("2020-07-09T13:06:11.845Z")
        ]
    )
    assert field.validate(1) == 1
    assert field.validate("Hello") == "Hello"
    assert field.validate("2020-07-09T13:06:11.845Z") == "2020-07-09T13:06:11.845Z"
    assert field.validate("2020-07-09T13:06:11.845Z", strict=True) == "2020-07-09T13:06:11.845Z"


if __name__ == "__main__":
    import doctest


# Generated at 2022-06-24 10:47:21.284351
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(None).validate(None, strict=True) == None
    assert Not(None).validate(None, strict=False) == None
    assert Not(None).validate(10, strict=True) == 10
    assert Not(None).validate(10, strict=False) == 10
    assert Not(None).validate(True, strict=True) == True
    assert Not(None).validate(True, strict=False) == True
    assert Not(None).validate("", strict=True) == ""
    assert Not(None).validate("", strict=False) == ""
    assert Not(None).validate([], strict=True) == []
    assert Not(None).validate([], strict=False) == []
    assert Not(None).validate({}, strict=True) == {}

# Generated at 2022-06-24 10:47:21.686293
# Unit test for constructor of class AllOf
def test_AllOf():
    assert 1

# Generated at 2022-06-24 10:47:24.008253
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Any()).validate(True) == True
    assert Not(Any()).validate(None)== None


# Generated at 2022-06-24 10:47:26.393884
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError):
        field.validate('test')



# Generated at 2022-06-24 10:47:31.469415
# Unit test for constructor of class AllOf
def test_AllOf():
    print("Unit test for constructor of class AllOf")
    field = AllOf([String()])
    print("AllOf([String()]) =", field)



# Generated at 2022-06-24 10:47:37.982877
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    test_cases = [(1.2, 1.2), ('hello', 'hello'), (True, True)]
    for case in test_cases:
        test_case, expect = case
        print("Test: {}".format(test_case))
        field = OneOf([Any()])
        actual = field.validate(test_case)
        assert actual == expect


# Generated at 2022-06-24 10:47:38.970420
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    x

# Generated at 2022-06-24 10:47:42.821289
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Int())
    assert field.validate(1) is None
    assert field.validate(2) is None
    assert field.validate(3) is None
    assert field.validate(3.5) == 3.5
    assert field.validate('a') == 'a'
    assert field.validate(None) is None


# Generated at 2022-06-24 10:47:45.589642
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    n = NeverMatch(name="never_match", help_text="Never match")
    assert n.name == "never_match"
    assert n.help_text == "Never match"


# Generated at 2022-06-24 10:47:47.540282
# Unit test for constructor of class OneOf
def test_OneOf():
    """is OneOf.all_of the same list sent to the constructor? """
    a_list = [1, 2, 3]
    x = OneOf(a_list)
    assert a_list == x.one_of



# Generated at 2022-06-24 10:47:57.894854
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test with value of condition is true
    if_clause = Int()
    then_clause = Int()
    else_clause = Int()
    value = 1
    field_ifthenelse = IfThenElse(if_clause, then_clause, else_clause)
    result = field_ifthenelse.validate(value)
    assert result == value
    # Test with value of condition is false
    if_clause = Int()
    then_clause = Int()
    else_clause = Int()
    value = 1.5
    field_ifthenelse = IfThenElse(if_clause, then_clause, else_clause)
    result = field_ifthenelse.validate(value)
    assert result == value

# Generated at 2022-06-24 10:47:59.542772
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Field()]
    AllOf(all_of)


# Generated at 2022-06-24 10:48:03.201931
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    expected = None
    actual = NeverMatch(**{'__validators__': {}, 'error': {'never': 'This never validates.'}})
    assert expected is None
    assert actual is not None
    assert repr(actual) == '<NeverMatch allow_reuse=True required=False>'


# Generated at 2022-06-24 10:48:05.855868
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()
    assert isinstance(x, Field)

# Generated at 2022-06-24 10:48:08.305423
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    with pytest.raises(ValidationError):
        field.validate("string")


# Generated at 2022-06-24 10:48:15.654963
# Unit test for constructor of class OneOf
def test_OneOf():
    a = 1
    b = []
    c = "a"
    d = {}
    t1 = OneOf([a,b,c,d])
    assert t1.one_of == [1, [], "a", {}]


# Generated at 2022-06-24 10:48:20.297518
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    test_NeverMatch = NeverMatch(description="This should never match.")
    assert test_NeverMatch.description == "This should never match."
    assert test_NeverMatch.errors == {'never': 'This never validates.'}

# Unit test to ensure that the NeverMatch class does not validate any value.

# Generated at 2022-06-24 10:48:27.997490
# Unit test for method validate of class Not
def test_Not_validate():

    # Initialize an object of class Not
    not_object = Not(
        negated=Union(
            set_of=Set[Integer()],
            list_of=List[
                "1_list"
            ]
        )
    )

    # Test that the condition is correct
    assert not_object.validate(1) == 1
    assert not_object.validate('a') == 'a'
    assert not_object.validate({1, 2}) == {1, 2}
    assert not_object.validate([1, 2]) == [1, 2]

# Generated at 2022-06-24 10:48:29.788796
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String, Integer
    foo = AllOf([String(), Integer()])
    assert foo.all_of == [String(), Integer()]

# Generated at 2022-06-24 10:48:35.199776
# Unit test for method validate of class Not
def test_Not_validate():
    class TestNot(Not):
        errors = {"negated": "Must not match."}
        def __init__(self):
            super(TestNot, self).__init__(negated=Integer(gte=0), title=None)
    test_not = TestNot()
    try:
        test_not.validate(-1)
        assert True
    except KeyError:
        assert False
    try:
        test_not.validate(1)
        assert False
    except KeyError:
        assert True
