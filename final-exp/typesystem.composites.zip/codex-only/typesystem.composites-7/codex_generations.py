

# Generated at 2022-06-24 10:38:28.960553
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated == Field()

# Generated at 2022-06-24 10:38:32.425899
# Unit test for constructor of class OneOf
def test_OneOf():
    a = OneOf([Any(), Any()])
    assert a is not None


# Generated at 2022-06-24 10:38:33.729965
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse({}) == (None, None)

# Generated at 2022-06-24 10:38:38.399073
# Unit test for method validate of class Not
def test_Not_validate():
    a = Not(String(min_length=3))
    res=a.validate("a")
    assert res== "a"

# Generated at 2022-06-24 10:38:43.855678
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass
    """
    Verify that the method validate succeed in validating the correct value
    """
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate("Test") == "Test"
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate("Test") == "Test"
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate("Test") == "Test"
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate("Test") == "Test"
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate("Test") == "Test"


# Generated at 2022-06-24 10:38:49.006546
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    schema_dict = {'all_of': [{'type': 'string'}, {'min_length': 1}]}
    field = AllOf.from_dict(schema_dict)
    assert field.validate('')
    assert field.validate('x')

# Generated at 2022-06-24 10:38:51.239455
# Unit test for constructor of class Not
def test_Not():
    field = Not(field = {}, allow_null = True, description = "Hello")
    assert isinstance(field, Field)
    assert field.errors == {'negated': 'Must not match.'}


# Generated at 2022-06-24 10:38:51.972846
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert(IfThenElse.__init__)

# Generated at 2022-06-24 10:38:56.427369
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer
    field = AllOf([Integer(min_value=1), Integer(max_value=10)])
    for value in [1, 2, None]:
        field.validate(value)
    field.errors = {
        "all_of": "Must match all types."
    }
    try:
        field.validate(0)
        assert False
    except:
        assert True
    try:
        field.validate(11)
        assert False
    except:
        assert True
    try:
        field.validate("ABC")
        assert False
    except:
        assert True


# Generated at 2022-06-24 10:39:06.590484
# Unit test for method validate of class Not
def test_Not_validate():
    # Check if 'Not' class passes validation and return the value
    msj = Not(Any())
    assert msj.validate(12) == 12
    assert msj.validate('asdj') == 'asdj'

    # Check if 'Not' class fails validation when negated type is included
    # in the value
    msj = Not(String())
    with pytest.raises(ValidationError):
        msj.validate('this is a string')

    # Check if 'Not' class fails validation when negated type is included
    # in the value
    msj = Not(Integer())
    with pytest.raises(ValidationError):
        msj.validate(32)
    with pytest.raises(ValidationError):
        msj.validate(32.0)

    # Check if 'Not'

# Generated at 2022-06-24 10:39:07.903723
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of is not None

# Generated at 2022-06-24 10:39:14.167196
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    try:
        Not(String(min_length=4, max_length=200)).validate("not")
        assert False, "should throw ValidationError"
    except ValidationError as e:
        assert e.code == "negated"
        assert e.message == "Must not match."
    try:
        Not(String(min_length=4, max_length=200)).validate("not not")
        assert False, "should throw ValidationError"
    except ValidationError as e:
        assert e.code == "negated"
        assert e.message == "Must not match."

# Generated at 2022-06-24 10:39:14.613197
# Unit test for constructor of class Not
def test_Not():
    assert(Not)

# Generated at 2022-06-24 10:39:22.390461
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.exceptions import ValidationError
    
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value + 1
    
    a = A()
    b = B()
    c = IfThenElse(a, b)

    try:
        c.validate(1)
    except ValidationError as e:
        assert str(e) == 'Invalid value: [1], Expected: [2]'
    else:
        assert False
    

# Generated at 2022-06-24 10:39:24.783564
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    errors = {"never": "This never validates."}
    test = NeverMatch()
    # TODO: should this be a deepcopy?
    assert test.errors == errors


# Generated at 2022-06-24 10:39:36.016234
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    """
        Test for method validate of class OneOf.
        It checks if the method is working correctly.
    """
    # Create test instances
    string_field = String()
    integer_field = Integer()
    boolean_field = Boolean()
    datetime_field = DateTime()

    data_string = "Hello World!"
    data_int = 123
    data_bool = True
    data_datetime = datetime.datetime.now()

    fields = [string_field, integer_field, datetime_field]
    test_data = [data_string, data_int, data_datetime]

    # Test behaviour
    one_of = OneOf(fields)


# Generated at 2022-06-24 10:39:44.319516
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typing import List

    from typesystem.types import String

    class MyField(Field):
        pass

    def assert_value_error(expected_message: str, func, *args, **kwargs):
        try:
            func(*args, **kwargs)
            assert False, "Did not raise."
        except ValueError as e:
            assert e.args == (expected_message,)

    one_of = OneOf(one_of=[String()])
    assert one_of.validate("foo") == "foo"
    assert_value_error(
        "Did not match any valid type.",
        one_of.validate,
        42,
    )

# Generated at 2022-06-24 10:39:51.076497
# Unit test for constructor of class OneOf
def test_OneOf():
    # given
    one_of_field1 = Field()
    one_of_field2 = Field()
    one_of_field_list = [one_of_field1, one_of_field2]
    one_of_field = OneOf(one_of_field_list)

    # when
    assert one_of_field.one_of == one_of_field_list



# Generated at 2022-06-24 10:39:52.185034
# Unit test for constructor of class Not
def test_Not():
    field = Not(None)
    assert field.negated is None


# Generated at 2022-06-24 10:39:54.313559
# Unit test for constructor of class OneOf
def test_OneOf():
    def test_object(object):
        assert object
    test_object(OneOf(one_of=[test_object]))

# Generated at 2022-06-24 10:39:55.050059
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()

# Generated at 2022-06-24 10:39:55.858066
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    pass

# Generated at 2022-06-24 10:39:59.239690
# Unit test for constructor of class Not
def test_Not():
    try:
        f = Not()
        assert False
    except NotImplementedError:
        assert True



# Generated at 2022-06-24 10:40:00.517769
# Unit test for constructor of class Not
def test_Not():
    n = Not(negated=Any())
    assert n.negated == Any()

# Generated at 2022-06-24 10:40:03.755024
# Unit test for constructor of class Not
def test_Not():
  from typesystem.fields import String
  from json import loads
  json = loads("{}")
  assert Not(negated = String(min_length = 1, max_length = 100)).validate(json) == json

# Generated at 2022-06-24 10:40:09.707455
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Even
    assert IfThenElse(Int(min_value=0), String(), String(max_length=1)).validate(2) == '2'
    # Odd
    assert IfThenElse(Int(max_value=-1), String(), String(max_length=1)).validate(2) == '2'

# Generated at 2022-06-24 10:40:12.835048
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = [Any(), Any()]
    all_of_field = AllOf(all_of=all_of)
    passed = False
    try:
        all_of_field.validate(10)
        passed = True
    except AssertionError:
        passed = False
    finally:
        assert passed


# Generated at 2022-06-24 10:40:15.608613
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    thenField = String()
    elseField = String()
    ifField = String()
    ifThenElse = IfThenElse(ifField, thenField, elseField)
    assert ifThenElse is not None

# Generated at 2022-06-24 10:40:23.593695
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class X(object):
        x = int
        y = int
    a = IfThenElse(X.x > 3, then_clause=X.x * X.y)
    assert a.validate(object()) == object()
    assert a.errors() == {'ALL': ['Value must be an int.']}
    assert a.validate(5) == 5
    assert a.errors() == {'ALL': ['Value must be an int.']}
    assert a.validate(4) == 4
    assert a.errors() == {'ALL': ['Value must be an int.']}
    assert a.validate(3) == 3
    assert a.errors() == {'ALL': ['Value must be an int.']}
    assert a.validate(2) == 2

# Generated at 2022-06-24 10:40:24.595398
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    from typesystem.fields import NeverMatch
    NeverMatch()

# Generated at 2022-06-24 10:40:25.188786
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-24 10:40:28.754668
# Unit test for constructor of class OneOf
def test_OneOf():
    s = OneOf(["1", "2"])
    assert s.__dict__ == {'one_of': ["1", "2"], 'allow_null': False, 'description': '', 'name': None, 'default': NOT_PROVIDED, 'required': True}

# Generated at 2022-06-24 10:40:32.036966
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([])
    assert a is not None

# Generated at 2022-06-24 10:40:35.183525
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    test_field = NeverMatch()
    with pytest.raises(AssertionError):
        test_field.validate()


# Generated at 2022-06-24 10:40:42.564324
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IfThenElseTest(IfThenElse):
        def __init__(self, if_clause, then_clause, else_clause, **kwargs):
            super().__init__(if_clause, then_clause, else_clause, **kwargs)
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    ifthenelse_field = IfThenElseTest(if_clause, then_clause, else_clause)
    assert ifthenelse_field.validate(value) == value


# Generated at 2022-06-24 10:40:43.476500
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-24 10:40:51.757749
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.types import Integer
    field = AllOf([Integer(minimum=10), Integer(maximum=20)])
    assert field.validate(10) == 10
    assert field.validate(20) == 20
    assert field.validate(11) == 11

    from typesystem.exceptions import ValidationError
    try:
        field.validate(9)
    except ValidationError as exc:
        assert exc is not None and len(exc.messages) == 1 and exc.messages["__all__"] == ["Value must be at least 10."]
    
    try:
        field.validate(21)
    except ValidationError as exc:
        assert exc is not None and len(exc.messages) == 1 and exc.messages["__all__"] == ["Value must be at most 20."]

#

# Generated at 2022-06-24 10:40:55.005782
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    OneOf_field = OneOf(one_of=[Any(), Any()])
    validated_value, errors = OneOf_field.validate_or_error(1)
    assert validated_value == 1
    assert not errors


# Generated at 2022-06-24 10:41:05.635757
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_test = IfThenElse(Int())
    assert isinstance(
        if_test, IfThenElse
    ), "Constructor of class IfThenElse not working: if_clause not Int"
    if_test = IfThenElse(Int(), Int())
    assert isinstance(
        if_test, IfThenElse
    ), "Constructor of class IfThenElse not working: if_clause and then_clause not Int"
    if_test = IfThenElse(Int(), Int(), Int())
    assert isinstance(
        if_test, IfThenElse
    ), "Constructor of class IfThenElse not working: if_clause, then_clause and else_clause not Int"
    if_test = IfThenElse(Int(), Int(), None)

# Generated at 2022-06-24 10:41:09.593600
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    with pytest.raises(AssertionError) as excinfo:
        IfThenElse(None, allow_null=True)
    assert str(excinfo.value) == "assert 'allow_null' not in kwargs"
    assert excinfo.type == AssertionError
    assert excinfo.value is not None



# Generated at 2022-06-24 10:41:12.994755
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with raises(field.validation_error):
        assert field.validate(None, strict=True)


# Generated at 2022-06-24 10:41:16.004701
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem import Boolean, Integer
    i = IfThenElse(Boolean, Integer)
    i.validate(False)
    i.validate(True)
    i.validate(1)
    # TODO: test to raise error

# Generated at 2022-06-24 10:41:25.217130
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import typesystem
    import typesystem_random
    all_of = typesystem.AllOf(
        [
            typesystem.String(),
            typesystem.Integer(),
            typesystem.Number(),
            typesystem.Boolean(),
        ]
    )
    all_of.validate("abc")
    with pytest.raises(typesystem.exceptions.ValidationError):
        typesystem_random.Random(
            all_of,
            max_size=3,
            seed=1441438821891,
            allow_null=False,
            max_null=False,
            str_len=6,
        ).get()



# Generated at 2022-06-24 10:41:25.823806
# Unit test for constructor of class OneOf
def test_OneOf():
    assert True

# Generated at 2022-06-24 10:41:29.701137
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Integer(maximum=100))
    assert field.validate(90) == 90
    with pytest.raises(ValidationError) as excinfo:
        field.validate(110)
    with pytest.raises(ValidationError) as excinfo:
        field.validate(50)


# Generated at 2022-06-24 10:41:31.200948
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import Integer
    not_int = Not(Integer())


# Generated at 2022-06-24 10:41:34.075834
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    obj = NeverMatch()
    with pytest.raises(AssertionError):
        obj.validate(1)


# Generated at 2022-06-24 10:41:43.352596
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import json
    from typesystem.fields import Integer

    class TestAllOf(AllOf):
        all_of = [Integer(minimum=1), Integer(maximum=2)]
    
    valid_value = 1
    result = TestAllOf.validate(valid_value, strict=False)
    assert result == valid_value
    valid_value = 2
    result = TestAllOf.validate(valid_value, strict=False)
    assert result == valid_value
    invalid_value = 0
    try:
        TestAllOf.validate(invalid_value, strict=False)
        assert False
    except:
        assert True



# Generated at 2022-06-24 10:41:46.144654
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch()
    assert obj.__dict__ == {"default": None, "required": True, "name": "NeverMatch", "error_messages": {"never": "This never validates."}}

# Generated at 2022-06-24 10:41:46.679814
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    x = NeverMatch()

# Generated at 2022-06-24 10:41:53.497621
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # check the match_count = 1
    test_field = OneOf([Integer(), Float()], name="a")
    result = test_field.validate(10)
    assert isinstance(result, int)
    assert result == 10

    # check the match_count = 0
    test_field = OneOf([Integer(), Float()], name="a")
    try:
        test_field.validate("abc")
    except Exception as e:
        assert True
    else:
        assert False

    # check the match_count = 2
    test_field = OneOf([Integer(), Float()], name="a")
    try:
        test_field.validate("10")
    except Exception as e:
        assert True
    else:
        assert False


# Generated at 2022-06-24 10:41:59.738337
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch(short_name='field')
    # case 1
    try:
        field.validate(5)
        assert False
    except field.validation_error:
        assert True
    # case 2
    try:
        field.validate(None)
        assert False
    except field.validation_error:
        assert True
    # case 3
    try:
        field.validate('5')
        assert False
    except field.validation_error:
        assert True


# Generated at 2022-06-24 10:42:06.263534
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer, String

    str_type = Not(Integer())

    # test when value matches the negated type
    value = "ss"
    result_value, error = str_type.validate_or_error(value)

    assert error is None
    assert result_value == value

    # test when value matches the negated type
    value = 5
    with pytest.raises(str_type.validation_error) as excinfo:
        str_type.validate(value)

    assert excinfo.value.code == "negated"

# Generated at 2022-06-24 10:42:17.199913
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typing
    from typesystem.fields import Boolean
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.schemas import Object
    from typesystem.schemas import Schema
    from typesystem.schemas import TypedList

    class Product(Schema):
        code = String(max_length=4)
        discounted = Boolean()
        price = IfThenElse(
            if_clause=Boolean(default=False),
            then_clause=Integer(maximum=999),
            else_clause=Integer(minimum=1000),
        )
        shipping = IfThenElse(
            if_clause=Boolean(default=False),
            then_clause=Integer(maximum=999),
            else_clause=Integer(minimum=1000),
        )


# Generated at 2022-06-24 10:42:23.093150
# Unit test for constructor of class AllOf
def test_AllOf():
	d1 = AllOf([])
	assert d1.all_of == []
	d2 = AllOf([String()])
	assert d2.all_of == [String()]
	d3 = AllOf([String(), Integer()])
	assert d3.all_of == [String(), Integer()]
#

# Generated at 2022-06-24 10:42:25.540396
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=List(items=String()))
    assert not_field.negated.__class__.__name__ == "List"


# Generated at 2022-06-24 10:42:26.427136
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    x = IfThenElse(Any(), None, None)

# Generated at 2022-06-24 10:42:27.337391
# Unit test for constructor of class Not
def test_Not():
    field = Not(Any())
    assert field.negated == Any()


# Generated at 2022-06-24 10:42:32.582922
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    class MyClass:
        pass
    value = MyClass()
    #IfThenElse(if_clause, then_clause, else_clause)
    field = IfThenElse(Any())
    assert field is not None
    assert field.get_value(value) == value

    #IfThenElse(if_clause, then_clause, else_clause)
    field = IfThenElse(Any(), Any())
    assert field is not None
    assert field.get_value(value) == value

    #IfThenElse(if_clause, then_clause, else_clause)
    field = IfThenElse(Any(), Any(), Any())
    assert field is not None
    assert field.get_value(value) == value


# Generated at 2022-06-24 10:42:36.259878
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    neverMatch = NeverMatch()
    assert neverMatch.name is None
    assert neverMatch.description is None
    assert neverMatch.default is None
    assert neverMatch.errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:42:38.557673
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(ValidationError):
        NeverMatch().validate('anything')


# Generated at 2022-06-24 10:42:40.270086
# Unit test for method validate of class Not
def test_Not_validate():
    obj = Not(negated=String(""))
    obj.validate("")

# Generated at 2022-06-24 10:42:41.271230
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()


# Generated at 2022-06-24 10:42:43.798649
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    d1 = NeverMatch()
    assert d1.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:42:45.401218
# Unit test for constructor of class Not
def test_Not():
    a=Not(negated='True')



# Generated at 2022-06-24 10:42:46.871971
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors['never'] == 'This never validates.'


# Generated at 2022-06-24 10:42:48.050757
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    F = NeverMatch()

    try:
        F.validate(5)
    except:
        pass


# Generated at 2022-06-24 10:42:49.768577
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of

# Generated at 2022-06-24 10:42:52.710260
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # set up:
    val = AllOf([])
    # assertion:
    try:
        val.validate(None)
        assert False
    except:
        pass

test_AllOf_validate()


# Generated at 2022-06-24 10:43:00.138571
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import pytest
    from typesystem import ValidationError

    obj = NeverMatch()
    with pytest.raises(ValidationError, match="This never validates.") as excinfo:
        obj.validate("any_value")

    exception_message = str(excinfo.value)
    assert exception_message == "{'never': 'This never validates.'}"



# Generated at 2022-06-24 10:43:11.078455
# Unit test for method validate of class OneOf
def test_OneOf_validate():
	try:
		OneOf(None,one_of=[Any()]).validate('')
	except ValidationError:
		pass

	try:
		OneOf(None,one_of=['A']).validate('')
	except ValidationError:
		pass


	try:
		OneOf(None,one_of=['A']).validate(1)
	except ValidationError:
		pass


	try:
		OneOf(None,one_of=[1]).validate('')
	except ValidationError:
		pass


	try:
		OneOf(None,one_of=['A','B']).validate('')
	except ValidationError:
		pass



# Generated at 2022-06-24 10:43:15.029247
# Unit test for constructor of class OneOf
def test_OneOf():
    '''test for constructor of class OneOf'''
    aof = OneOf(one_of=[])
    assert aof.one_of == []


# Generated at 2022-06-24 10:43:18.108301
# Unit test for method validate of class Not
def test_Not_validate():
    n = Not(Integer(max_value=0))
    n.validate(1)
    raises(n.validation_error, n.validate, 0)


# Generated at 2022-06-24 10:43:21.326418
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    a = String()
    b = String()
    c = OneOf([a, b])
    # no error
    c.validate('a')
    c.validate('b')
    # two errors
    with pytest.raises(ValueError):
        c.validate(1)


# Generated at 2022-06-24 10:43:32.294015
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class innerClass(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == True or value == 'True' or value == 'true':
                return True
            else:
                return False

    assert OneOf([innerClass()], required = True).validate(False) == False
    assert OneOf([innerClass()], required = True).validate(True) == True
    assert OneOf([innerClass()], required = True).validate('True') == True
    assert OneOf([innerClass()], required = True).validate('true') == True
    assert OneOf([innerClass()], required = True).validate('False') != True
    assert OneOf([innerClass()], required = True).validate('false') != True


# Generated at 2022-06-24 10:43:34.930788
# Unit test for constructor of class Not
def test_Not():
    test_field = Not(negated = Integer())
    assert test_field.negated == Integer()
    assert test_field.errors == {'negated': 'Must not match.'}


# Generated at 2022-06-24 10:43:38.540711
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field1 = IfThenElse(if_clause=Int(), then_clause=Int())
    assert field1.if_clause == Int()
    assert field1.then_clause == Int()
    assert field1.else_clause == Any()

# Generated at 2022-06-24 10:43:41.207675
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field1 = AllOf(all_of=['int', 'bool'])
    assert field1.validate(value='10') == '10'
    assert field1.validate(value=10) == 10
    assert field1.validate(value=True) == True


# Generated at 2022-06-24 10:43:45.420250
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Integer()).validate(5) is None
    assert Not(Integer()).validate(5.0) is None
    assert Not(Integer()).validate({}) is None
    assert Not(Integer()).validate(False) is None
    assert Not(Integer()).validate(None) is None
    assert Not(Integer()).validate("Hello") is None
    try:
        Not(Integer()).validate(5)
    except Exception as e:
        assert str(e) == "Must not match."

# Generated at 2022-06-24 10:43:46.435324
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    all_of = AllOf([])
    assert not all_of.validate("hello")

# Generated at 2022-06-24 10:43:49.031526
# Unit test for constructor of class Not
def test_Not():
    # Not should have an attribute negated
    not_obj = Not(Any())
    assert hasattr(not_obj, "negated")
    assert not_obj.negated is not None



# Generated at 2022-06-24 10:43:53.292115
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class DummySchema(object):
        def __init__(self) -> None:
            self.errors = {}

    def create_dummy_field():
        dummy_schema = DummySchema()
        dummy_field = Field(schema=dummy_schema)
        return dummy_field

    # Testcase1: Validates IfThenElse with valid values
    then_validate_flag = False
    else_validate_flag = False
    if_validate_flag = False
    def then_validate(value, strict):
        nonlocal then_validate_flag
        then_validate_flag = True
        return value
    def else_validate(value, strict):
        nonlocal else_validate_flag
        else_validate_flag = True
        return value

# Generated at 2022-06-24 10:43:54.590230
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([Field()])
    assert AllOf([Field()], title='Field')

# Generated at 2022-06-24 10:43:55.188762
# Unit test for constructor of class Not
def test_Not():
    assert Not is not None

# Generated at 2022-06-24 10:43:56.962481
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # set
    f1 = OneOf(one_of=[Any(), Any()])
    f1.validate(1)

# Generated at 2022-06-24 10:44:05.336666
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(
        if_clause = 1,
        then_clause = 2,
        else_clause = 3,
        ).validate(4) == 2
    assert IfThenElse(
        if_clause = 1,
        then_clause = 2,
        else_clause = 3,
        ).validate(1) == 2
    assert IfThenElse(
        if_clause = 2,
        then_clause = 2,
        else_clause = 3,
        ).validate(1) == 3
    assert IfThenElse(
        if_clause = 2,
        then_clause = 2,
        else_clause = 3,
        ).validate(4) == 3

# Generated at 2022-06-24 10:44:07.591706
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print("Unit test for method validate of class OneOf")

    assert True



# Generated at 2022-06-24 10:44:10.193057
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        Not(None, allow_null=False)
    with pytest.raises(AssertionError):
        Not(None, allow_null=True)
    with pytest.raises(TypeError):
        Not(None)

# Generated at 2022-06-24 10:44:14.708212
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    errors = []
    try:
        NeverMatch().validate(None)
    except ValidationError as err:
        errors.append(err)

    assert len(errors) == 1
    assert errors[0].code == "never"


# Generated at 2022-06-24 10:44:19.950207
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    number_field = IfThenElse(Number(),then_clause = String(),else_clause=Field())
    assert isinstance(number_field,Field)
    assert number_field.if_clause is Number()
    assert number_field.then_clause is String()
    assert number_field.else_clause is Field()
    
    with pytest.raises(AssertionError):
        IfThenElse(Number(),allow_null=True)
    with pytest.raises(AssertionError):
        IfThenElse(Number(),then_clause = String(),allow_null=True)
    with pytest.raises(AssertionError):
        IfThenElse(Number(),then_clause = String(),else_clause=Field(),allow_null=True)
        

# Generated at 2022-06-24 10:44:24.048942
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    ifThenElse = IfThenElse(lambda: 1, lambda: 2, lambda: 3, description='Test')
    assert ifThenElse.validate(None) == 1
    assert ifThenElse.validate(True) == 2
    assert ifThenElse.validate(False) == 3

# Generated at 2022-06-24 10:44:25.328520
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-24 10:44:27.147047
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-24 10:44:30.766018
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    string = '999'
    string2 = '100'
    status = 'never'
    nm = NeverMatch()
    res = nm.validate(string)
    assert res == status
    res = nm.validate(string2)
    assert res == status


# Generated at 2022-06-24 10:44:32.736841
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    assert n.validate(1, False) is None
    assert n.validate(1, True) is None



# Generated at 2022-06-24 10:44:36.768466
# Unit test for constructor of class OneOf
def test_OneOf():
    o = OneOf(one_of = [1])
    assert o.one_of == [1]
    assert o.errors == {'no_match': 'Did not match any valid type.', 'multiple_matches': 'Matched more than one type.'}


# Generated at 2022-06-24 10:44:44.961626
# Unit test for constructor of class AllOf
def test_AllOf():
    Field0 = AllOf([])
    Field1 = AllOf([Field0])
    Field2 = AllOf([Field1])
    Field3 = AllOf([Field2])
    Field4 = AllOf([Field3])
    Field5 = AllOf([Field4])
    Field6 = AllOf([Field5])
    Field7 = AllOf([Field6])
    Field8 = AllOf([Field7])
    Field9 = AllOf([Field8])
    Field10 = AllOf([Field9])
    Field11 = AllOf([Field10])
    Field12 = AllOf([Field11])
    Field13 = AllOf([Field12])
    Field14 = AllOf([Field13])
    Field15 = AllOf([Field14])
    Field16 = AllOf([Field15])
    Field17 = AllOf([Field16])
    Field18

# Generated at 2022-06-24 10:44:46.841738
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-24 10:44:48.216860
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch


# Generated at 2022-06-24 10:44:51.206163
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    obj = NeverMatch()
    with pytest.raises(Field.validation_error):
        obj.validate(2)


# Generated at 2022-06-24 10:44:53.318173
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([1,2,3])
    assert a == [1,2,3]


# Generated at 2022-06-24 10:44:55.252936
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([Field()], name='TestOneOf')
    assert field.one_of == [Field()]

# Generated at 2022-06-24 10:44:56.325172
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])

# Generated at 2022-06-24 10:44:58.163281
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(IntegerField()).validate(12) == "12"

# Generated at 2022-06-24 10:44:59.040550
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    NeverMatch().validate('yolo')

# Generated at 2022-06-24 10:45:00.783307
# Unit test for constructor of class OneOf
def test_OneOf():
    # init attributes
    one_of = [Field()]
    field = OneOf(one_of)
    # test attributes
    assert field.one_of

# Generated at 2022-06-24 10:45:05.101715
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        a = IfThenElse(None, None, None)
        assert False, "IfThenElse should not allow invalid parameters"
    except AssertionError as e:
        raise e
    except:
        pass  # Expected exception

# Generated at 2022-06-24 10:45:10.994329
# Unit test for constructor of class OneOf
def test_OneOf():
    schema = OneOf([str, int])
    assert schema.validate("hello") == "hello"
    assert schema.validate(1) == 1
    with pytest.raises(schema.validation_error):
        schema.validate(None)
    with pytest.raises(schema.validation_error):
        schema.validate(["hello", 1])


# Generated at 2022-06-24 10:45:14.830199
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nvm = NeverMatch()
    try:
        nvm.validate("test")
    except Exception as exception:
        assert type(exception) == nvm.validation_error
    else:
        raise AssertionError("No exception was raised")


# Generated at 2022-06-24 10:45:17.753592
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    schema = IfThenElse(
        Integer(),
        then_clause=String(),
        else_clause=String()
    )
    print(schema.validate("This is a String"))
    print(schema.validate(1))

test_IfThenElse_validate()

# Generated at 2022-06-24 10:45:24.328482
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Test different types
    allof_field = AllOf([IntegerField(), StringField()])
    bool_value = True
    assert bool_value == allof_field.validate(bool_value, strict=True)
    # Test true
    test_value = 123
    assert test_value == allof_field.validate(test_value, strict=True)
    # Test false
    test_value = {"wrong": "type"}
    with pytest.raises(FieldError):
        allof_field.validate(test_value, strict=True)



# Generated at 2022-06-24 10:45:26.005328
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate(True) == ValueError


# Generated at 2022-06-24 10:45:32.134942
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_field = Field(required=False)
    then_field = Field(required=False)
    else_field = Field(required=False)
    test = IfThenElse(if_field, then_field, else_field)
    assert test.if_clause == if_field
    assert test.then_clause == then_field
    assert test.else_clause == else_field

# Generated at 2022-06-24 10:45:38.859823
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    # The Field object that the method validate will be called on.
    field = IfThenElse(Field(), Field(), Field())

    # The 'value' argument of the validate method, which can be any type.
    value = Field()

    # The 'strict' argument of the validate method, it is optional.
    strict = Field()

    # The expected return value of the validate method.
    expected = Field()

    # Invoke the validate method
    actual = field.validate(value, strict)

    # Compare the expected return value with the value actually returned by the validate method.
    assert expected == actual

# Generated at 2022-06-24 10:45:42.340334
# Unit test for method validate of class Not
def test_Not_validate():
   # bad
   x = Not(False)
   print("x=", x)
   print("validate(x)=", x.validate(False))
   print("")


# Generated at 2022-06-24 10:45:47.889973
# Unit test for constructor of class OneOf
def test_OneOf():
    fields = [Boolean(), Integer()]
    field = OneOf(fields)
    assert field.validate(1) == 1
    with pytest.raises(ValidationError):
        field.validate("a", strict=True)
    with pytest.raises(ValidationError):
        field.validate(None)


# Generated at 2022-06-24 10:45:51.463909
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(TypeSystemError) as excinfo:
        field.validate(1)
    assert excinfo.value.args[0] == "This never validates."


# Generated at 2022-06-24 10:45:59.442255
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError):
        field.validate(None)
    with pytest.raises(ValidationError):
        field.validate(0)
    with pytest.raises(ValidationError):
        field.validate(1)
    with pytest.raises(ValidationError):
        field.validate(False)
    with pytest.raises(ValidationError):
        field.validate(True)
    with pytest.raises(ValidationError):
        field.validate("0")
    with pytest.raises(ValidationError):
        field.validate("1")
    with pytest.raises(ValidationError):
        field.validate("F")

# Generated at 2022-06-24 10:46:06.312631
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # create a dummy "value" to pass to the AllOf class
    value = ""
    # create a dummy "strict" to pass to the AllOf class
    strict = True
    # instantiate the class with two dummy fields
    # to test the AllOf class with
    allOf = AllOf([AllOf([]), AllOf([])])
    # call the validate method of the AllOf class
    r = allOf.validate(value, strict)
    # the returned should be the same as the value
    # passed into the method
    assert r == value


# Generated at 2022-06-24 10:46:17.912736
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    """
    This function tests method validate of class AllOf
    """
    # First, test if parameters are correctly parsed
    a = AllOf(all_of=[Int(), String()])
    assert a.all_of == [Int(), String()]
    assert a.error_messages == {"required": "This field is required.", "null": "This field may not be null."}
    assert a.default == None
    assert a.required == True

    # Now, test if an item that matches all child fields
    # is correctly parsed
    b = a.validate(value=1, strict=False)
    assert b == 1

    # Test if an exception is correctly thrown for n item
    # that does not match all child fields

# Generated at 2022-06-24 10:46:21.910397
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert isinstance(IfThenElse(if_clause=False), IfThenElse)

# Generated at 2022-06-24 10:46:26.633493
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # instances of class NeverMatch
    error = {}
    error["never"] = "This never validates."
    never_match = NeverMatch(errors = error)

    # access the constructor of class NeverMatch
    assert never_match.errors == error


# Generated at 2022-06-24 10:46:29.546154
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([Any(max_length=5), Any(min_length=5)])
    field.validate("abcde")


# Generated at 2022-06-24 10:46:36.221922
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    """Test constructor of class NeverMatch"""
    # pylint: disable=unused-argument, redefined-outer-name
    # our example arguments
    # some possible field arguments:
    target = "some target"
    alias = "some alias"
    required = False
    default = None

    # exercise
    result = NeverMatch(target, alias, default, required)

    # verify
    assert None is not result
    assert isinstance(result, NeverMatch)
    assert None is result.target
    assert "some target" == result.alias
    assert False == result.required
    assert None is result.default



# Generated at 2022-06-24 10:46:41.862484
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.label == "NeverMatch"
    assert field.description == ""
    assert field.errors == {'never': 'This never validates.'}
    assert field.default == NotImplemented
    assert field.required is False
    assert field.allow_null is False
    assert field.validate('tester') == 'never'


# Generated at 2022-06-24 10:46:45.744113
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])



# Generated at 2022-06-24 10:46:47.559877
# Unit test for constructor of class Not
def test_Not():
    return Not(None)


# Generated at 2022-06-24 10:46:50.045984
# Unit test for method validate of class Not
def test_Not_validate():
    negated1 = Not(Boolean())
    value1 = negated1.validate(True)
    assert value1 == True

# Generated at 2022-06-24 10:46:51.977686
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf([AllOf([Any()])])
    value = None
    strict = None
    result = field.validate(value, strict)
    assert result == value

# Generated at 2022-06-24 10:46:56.214087
# Unit test for method validate of class Not
def test_Not_validate():
    class MyField(Field):
        def __init__(self):
            super().__init__()

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if value == "banana":
                return value
            raise self.validation_error("error_msg")

    f = Not(MyField())
    assert f.validate("banana") == "banana"
    try:
        f.validate("orange")
        assert False
    except ValidationError as error:
        assert error.code == "negated"


# Generated at 2022-06-24 10:47:05.785589
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class Simple():
        pass

    simple = Simple()
    simple.int_attr = 1
    simple.class_attr = Simple()

    simple_if = IfThenElse( 
        if_clause=Field(), 
        then_clause=Field(),
        else_clause=Field(),
        required=True
    )
    simple_if.validate(simple)

    simple_if_with_error = IfThenElse( 
        if_clause=Field(), 
        then_clause=Field(required=True),
        else_clause=Field(required=True),
        required=True
    )
    try:
        simple_if_with_error.validate(simple)
    except FieldError as e:
        assert str(e) == "This field is required."


# Generated at 2022-06-24 10:47:08.058416
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    x = OneOf([int, float])
    assert x.validate(1.0) == 1.0

# Generated at 2022-06-24 10:47:12.307817
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(TypeSystemError) as exc_info:
        NeverMatch().validate('')
    assert str(exc_info.value) == '{"never": "This never validates."}'
    with pytest.raises(TypeSystemError) as exc_info:
        NeverMatch().validate('', strict=True)
    assert str(exc_info.value) == '{"never": "This never validates."}'


# Generated at 2022-06-24 10:47:15.715312
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem import types

    new_AllOf = AllOf(all_of=[])
    assert isinstance(new_AllOf, Field) == True


# Generated at 2022-06-24 10:47:23.089012
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import mypy_extensions
    import typesystem
    import typing

    class Car(mypy_extensions.TypedDict):
        brand: str
        model: str

    class Person(mypy_extensions.TypedDict):
        name: str
        age: int
        car: typing.Optional[Car]

    person_type = Person
    person_type['car?'] = IfThenElse(
    if_clause=person_type['age'] > 18,
    then_clause=Car({
    "brand": typesystem.String(max_length=20),
    "model": typesystem.String(max_length=10),
    }),
    else_clause=None,
    )


# Generated at 2022-06-24 10:47:28.049313
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    field = AllOf(
        [
            Integer(min_value=1, max_value=6),
            Integer(min_value=10, max_value=15)
        ]
    )
    # Fail
    with pytest.raises(ValidationError):
        field.validate(2)
    # Success
    field.validate(11)


# Generated at 2022-06-24 10:47:33.859973
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch(name = 'no match')
    assert field.name == 'no match'
    assert field.required == False


# Generated at 2022-06-24 10:47:39.284986
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(
        Field(),
        name="test_field",
        error_messages={
            "negated": "error_message"
        }
    )
    
    try:
        field.validate(None)
    except ValueError as err:
        assert str(err) == "error_message"
    else:
        assert False

# Generated at 2022-06-24 10:47:41.145276
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("abc") == "abc"
    assert NeverMatch().validate("abc", strict=True) == "abc"


# Generated at 2022-06-24 10:47:49.062663
# Unit test for method validate of class Not
def test_Not_validate():
    # object lookup
    object_lookup = {"field_1": 1, "field_2": 2, "field_3": 3}  # type: typing.Dict[str, typing.Any]
    base_test1 = Not({"field_1": OneOf([1, 2]), "field_2": 3}, name="Test", description="Description test")
    negated_test = True
    assert base_test1.validate(object_lookup, strict=False) == object_lookup
    try:
        base_test1.validate({"field_1": 2, "field_2": 3}, strict=False)
        negated_test = False
    except ValueError:
        negated_test = True
    assert negated_test

    # object lookup - duplicate

# Generated at 2022-06-24 10:47:50.362548
# Unit test for constructor of class Not
def test_Not():
    field = Not(Field())
    assert field.negated is not None


# Generated at 2022-06-24 10:47:52.216378
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    f = NeverMatch()
    assert f.validate(None) == None


# Generated at 2022-06-24 10:47:53.257326
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    pass

# Generated at 2022-06-24 10:48:02.758793
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem

    class TestClass(typesystem.Schema):
        name = typesystem.String(max_length=32)
        age = typesystem.Integer(minimum=0, maximum=100)
        has_pet = typesystem.Boolean()
        pet = IfThenElse(
            if_clause=has_pet, then_clause=typesystem.String(), else_clause=typesystem.String()
        )
        has_pet_and_is_adult = IfThenElse(
            if_clause=has_pet,
            then_clause=typesystem.Boolean(),
            else_clause=None,
        )

# Generated at 2022-06-24 10:48:06.653688
# Unit test for constructor of class Not
def test_Not():
    SomeField = Field()
    SomeOtherField = Not(negated=SomeField)
    assert SomeOtherField.negated == SomeField
test_Not()


# Generated at 2022-06-24 10:48:10.944819
# Unit test for constructor of class OneOf
def test_OneOf():
	# oneof_field = OneOf(one_of: typing.List[Field], **kwargs: typing.Any)
	oneof_field = OneOf(one_of = [Boolean()])
	print(oneof_field.__dict__)


# Generated at 2022-06-24 10:48:11.830090
# Unit test for constructor of class Not
def test_Not():
    x = Not(String())
    assert x is not None

# Generated at 2022-06-24 10:48:22.050426
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Int(max_value=1)
    then_clause = Int(min_value=0)
    else_clause = Int(min_value=0)
    IfThenElse(if_clause, then_clause, else_clause, name='1').validate(2)
    IfThenElse(if_clause, then_clause, else_clause, name='1').validate(4)
    IfThenElse(if_clause, then_clause, else_clause, name='1').validate(0)
    IfThenElse(if_clause, then_clause, else_clause, name='1').validate(1)


# Generated at 2022-06-24 10:48:24.692979
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    integer = IfThenElse(Field.of(5),Field.of(6))
    assert integer.if_clause.allow_null



# Generated at 2022-06-24 10:48:30.637898
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    value = ""
    assert field.validate(value) != value