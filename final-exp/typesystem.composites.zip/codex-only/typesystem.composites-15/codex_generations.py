

# Generated at 2022-06-24 10:38:39.820152
# Unit test for constructor of class AllOf
def test_AllOf():
    """
    Checks AllOf's constructor
    """
    import typesystem

    class Email(typesystem.String):
        pattern = r"[^@]+@[^@]+\.[^@]+"

    class Password(typesystem.String):
        min_length = 6
        max_length = 100

    class UserName(typesystem.String):
        min_length = 4
        max_length = 50

    class DogName(typesystem.String):
        min_length = 3
        max_length = 50

    class User(typesystem.Schema):
        email = Email()
        password = Password()
        username = UserName()

    class Dog(typesystem.Schema):
        name = DogName()
        username = UserName()
        password = Password()

    class Both(typesystem.Schema):
        dog = Dog()

# Generated at 2022-06-24 10:38:42.605006
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    for value in (1, 2, 3):
        with pytest.raises(AssertionError):
            field.validate(value)


# Generated at 2022-06-24 10:38:47.182713
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    f = IfThenElse(Any())
    assert(f.validate("Hello world") == "Hello world")

# Generated at 2022-06-24 10:38:48.820087
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = typesystem.field("foo", typesystem.OneOf([typesystem.String()]))

    result = field.validate("wahaha")
    assert result == "wahaha"

# Generated at 2022-06-24 10:38:50.448794
# Unit test for constructor of class AllOf
def test_AllOf():
    result = AllOf([])
    assert result is not None



# Generated at 2022-06-24 10:38:53.439909
# Unit test for constructor of class OneOf
def test_OneOf():
    # Arrange
    expected_errors = {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}

    # Act
    actual = OneOf(
        one_of = [
        ]
    )

    # Assert
    assert actual.errors == expected_errors

    return


# Generated at 2022-06-24 10:38:56.216709
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(negated=Integer(), name='test').validate(4.0)



# Generated at 2022-06-24 10:38:57.903222
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch()
    ans = NeverMatch()
    assert obj == ans


# Generated at 2022-06-24 10:39:05.262167
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    test_field_value = "test_value"
    test_dict = {"error": "This never validates.", "code": "never"}
    field = NeverMatch()
    with pytest.raises(ValidationError) as excinfo:
        field.validate(test_field_value)
    try:
        assert excinfo.value.args[0] == test_dict["error"]
        assert excinfo.value.args[1]["code"] == test_dict["code"]
    except KeyError:
        assert excinfo.value



# Generated at 2022-06-24 10:39:06.471620
# Unit test for constructor of class Not
def test_Not():
    negated = NeverMatch()
    assert Not(negated).negated == negated

# Generated at 2022-06-24 10:39:07.770895
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf.__init__(AllOf([Any()])) == None

# Generated at 2022-06-24 10:39:09.054512
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    field.validate(value=None)



# Generated at 2022-06-24 10:39:10.066273
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch.__name__ == "NeverMatch"
    assert isinstance(NeverMatch, Field)



# Generated at 2022-06-24 10:39:13.086391
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.types import Integer

    t = IfThenElse(Integer(max_value=3), Integer(min_value=5), Integer(min_value=10))
    assert t.validate(2) == 2
    assert t.validate(5) == 5
    assert t.validate(12) == 12
    assert t.validate(4) == 4
    assert t.validate(1) == 1

test_IfThenElse()



# Generated at 2022-06-24 10:39:14.066682
# Unit test for constructor of class AllOf
def test_AllOf():
    typesystem.fields.AllOf([])


# Generated at 2022-06-24 10:39:17.878224
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    obj = NeverMatch()
    with raises(FieldValidationError):
        obj.validate(1)
    with raises(FieldValidationError):
        obj.validate('string')
    with raises(FieldValidationError):
        obj.validate('with!symbols')


# Generated at 2022-06-24 10:39:25.034022
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    a = String()
    b = String(max_length=10)
    c = AllOf([b,a])
    assert c.validate("hello") == "hello"
    assert c.validate("hellohellohello") != "hellohellohello"
    try:
        c.validate("hellohellohello")
    except ValidationError as e:
        assert e.code == "max_length"
    return True


# Generated at 2022-06-24 10:39:31.186366
# Unit test for method validate of class Not
def test_Not_validate():
    """Unit test for method Not.validate"""
    # 1. Create an instance of class Not
    not_field = Not(negated=Any())
    # 2. Call method validate with argument value = 1
    not_field.validate(1)
    # 3. Assert method validate returns 1
    assert not_field.validate(1) == 1


# Generated at 2022-06-24 10:39:33.729789
# Unit test for constructor of class Not
def test_Not():
    assert_that(Not(negated="hello"), Not(negated="hello"))

# Generated at 2022-06-24 10:39:35.898597
# Unit test for method validate of class Not
def test_Not_validate():
    # set up context
    notinstance = Not(None)

    # exercise
    # exercise

    # verify
    assert False
    pass


# Generated at 2022-06-24 10:39:44.253794
# Unit test for constructor of class Not
def test_Not():
    from unittest.mock import Mock
    from unittest import TestCase
    from typesystem import Integer
    from typesystem.base import ValidationError

    integer = Integer()
    mock_negated = Mock()
    mock_negated.validate_or_error = Mock()
    mock_negated.validate_or_error.return_value = (5, None)
    mock_negated.validation_error = Mock()
    mock_negated.validation_error.return_value = ValidationError("Test Error Message")

    not_integer = Not(negated=mock_negated)
    not_integer.validate(5)

    # Test that the negated field is validated
    mock_negated.validate_or_error.assert_called_with(5, strict=False)


# Generated at 2022-06-24 10:39:50.720805
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch(format='json')
    assert field.validate(111) == 111
    assert field.validate('111') == '111'
    assert field.validate({'111': '22'}) == {'111': '22'}
    assert field.validate(['111']) == ['111']
    assert field.validate(None) == None

# Generated at 2022-06-24 10:39:52.404451
# Unit test for constructor of class Not
def test_Not():
    my_not = Not(String())
    assert my_not.__dict__["negated"] == String()


# Generated at 2022-06-24 10:39:54.001824
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=1)


# Generated at 2022-06-24 10:39:56.492620
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    string = field.test(string='test')
    assert string == 'test'


# Generated at 2022-06-24 10:40:04.299562
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Unit test for method validate of class AllOf
    class TypeA(Field):
        pass

    class TypeB(Field):
        pass

    a = 'a'
    b = 'b'

    field_a = TypeA()
    field_b = TypeB()

    all_of = AllOf([field_a, field_b])

    # Real test starts here
    assert all_of.validate(a) == a
    assert all_of.validate(b) == b


# Generated at 2022-06-24 10:40:14.652521
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():

    def test_IfThenElse_validate_success():

        def assert_values_match_strict_mode(
            assert_statement: typing.Any, expected_value: typing.Any, test_value: typing.Any
        ):
            assert_statement(expected_value, test_value)

        expected_value = "1"
        test_value = "1"
        assert_values_match_strict_mode(Assert.equals, expected_value, test_value)

        def assert_values_do_not_match_strict_mode(
            assert_statement: typing.Any, expected_value: typing.Any, test_value: typing.Any
        ):
            assert_statement(expected_value, test_value)

        expected_value = "1"
        test_value = 1
        assert_values_do_not

# Generated at 2022-06-24 10:40:22.846106
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    import typesystem
    schema = typesystem.Schema(fields = {"a": IfThenElse(
        if_clause = typesystem.String(max_length = 20),
        then_clause = typesystem.String(max_length = 10),
        else_clause = typesystem.String(max_length = 5),
    )})
    #test if valid if_clause
    data = {"a": "1"*15}
    assert schema.is_valid(data)
    assert schema.validate(data) == data
    #test if invalid if_clause, valid else_clause
    data = {"a": "1"}
    assert schema.is_valid(data)
    assert schema.validate(data) == data
    #test if invalid if_clause, valid then_clause

# Generated at 2022-06-24 10:40:31.647621
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class Model(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value
    class Model2(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    obj1 = Model()
    obj2 = Model2()
    with pytest.raises(TypeError):
            OneOf([], error_messages={'no_match': 'test'})
    with pytest.raises(TypeError):
            OneOf([obj1])
    with pytest.raises(TypeError):
        OneOf([obj1, obj2], error_messages={'no_match': 'test', 'multiple_matches': 'test'})

# Generated at 2022-06-24 10:40:35.823330
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[Union(types=[str])], label='Union')
    assert one_of.label == 'Union'
    assert one_of.one_of[0].types[0] == str

# Generated at 2022-06-24 10:40:46.977928
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    ''' Tests the constructor of the class IfThenElse '''
    from typesystem.fields import Integer, String

    newIfThenElse = IfThenElse(if_clause=Integer())

    assert newIfThenElse.if_clause == Integer()
    assert newIfThenElse.then_clause == Any()
    assert newIfThenElse.else_clause == Any()

    newIfThenElse2 = IfThenElse(if_clause=Integer(), then_clause=String())

    assert newIfThenElse2.if_clause == Integer()
    assert newIfThenElse2.then_clause == String()
    assert newIfThenElse2.else_clause == Any()

    newIfThenElse3 = IfThenElse(if_clause=Integer(), then_clause=String(), else_clause=Integer())

    assert new

# Generated at 2022-06-24 10:40:51.929593
# Unit test for constructor of class AllOf
def test_AllOf():
    """Test constructor of class AllOf"""
    all_of = [Field()]
    allof = AllOf(all_of)
    assert allof.all_of is all_of


# Generated at 2022-06-24 10:40:56.813303
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = (3 == 3)
    then_clause = 4 == 5
    else_clause = 4 == 4
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(3) == False
    assert if_then_else.validate(4) == True


# Generated at 2022-06-24 10:41:04.709257
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import json
    import typesystem
    # Given:
    class TestOneOf(typesystem.Schema):
        name = typesystem.OneOf(
            [typesystem.String(), typesystem.Integer()],
            description="Name of the test schema.",
            examples=["name"],
        )
    schema = TestOneOf()
    # When:
    data = {"name": "name"}
    data_json = json.dumps(data)
    # Then:
    assert schema.validate(data) == data
    assert schema.validate_json(data_json) == data


# Generated at 2022-06-24 10:41:05.674694
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    assert NeverMatch().validate("value") is None

# Generated at 2022-06-24 10:41:11.544744
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # TODO: can we make this work?
    field = IfThenElse(String(), then_clause=Integer())
    try:
        field.validate("hello")
        assert False, "unreachable"
    except FieldValidationError as e:
        # TODO: fix error message
        assert e.message == "hello is not a valid Integer."


# Generated at 2022-06-24 10:41:13.948214
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf.__init__(self=OneOf, one_of=[]) is None


# Generated at 2022-06-24 10:41:21.470197
# Unit test for method validate of class Not
def test_Not_validate():
    # Test method validate of class Not
    int_validator = Int()
    # Test case 1
    field_1 = Not(negated=int_validator)
    value_1 = 5.0
    print("Validating '{}' against the field {}".format(
        value_1, field_1))
    try:
        field_1.validate(value_1)
    except Exception as err:
        print("Failed with error: {}".format(err))

    # Test case 2
    field_2 = Not(negated=int_validator)
    value_2 = 5
    print("Validating '{}' against the field {}".format(
        value_2, field_2))

# Generated at 2022-06-24 10:41:24.789557
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(AllOf([Any(), Any()]))
    f.validate([1, 2, 3, 4])
    try:
        f.validate([])
        assert False
    except:
        assert True


# Generated at 2022-06-24 10:41:28.542715
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Define a list of fields
    list_of_fields = [Any()]
    # Define a field
    field = OneOf(list_of_fields)
    # Assert that method validate return the value
    assert field.validate("hello") == "hello"

# Test if method validate raise the validation error

# Generated at 2022-06-24 10:41:32.116537
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    import pytest
    from typesystem import String

    class TestAllOf(AllOf):
        def __init__(self):
            super(AllOf, self).__init__(all_of=[String()])

    _all_of = TestAllOf()

    actual = _all_of.validate("test")
    expected = "test"
    assert actual == expected

# Generated at 2022-06-24 10:41:42.129523
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate({"a": "b"}) == {"a": "b"}
    assert field.validate({"a": "b"}) == {"a": "b"}
    assert field.validate({"a": "b"}) == {"a": "b"}
    assert field.validate({"a": "b"}) == {"a": "b"}
    assert field.validate({"a": "b"}) == {"a": "b"}
    assert field.validate({"a": "b"}) == {"a": "b"}
    assert field.validate({"a": "b"}) == {"a": "b"}



# Generated at 2022-06-24 10:41:44.441449
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    assert n.validate(1) == 1


# Generated at 2022-06-24 10:41:48.139839
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Field(validate=lambda x: x % 3 == 0))
    assert not_field.validate(1) == 1
    try:
        not_field.validate(9)
        raise Exception("Test failed")
    except Exception:
        pass
    return

# Generated at 2022-06-24 10:41:51.697077
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(
        if_clause = Any(),
        then_clause = Any(),
        else_clause = Any()
    )

# Generated at 2022-06-24 10:42:00.196761
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert (IfThenElse(Field()).if_clause == Field())
    assert (IfThenElse(Field()).then_clause == Any())
    assert (IfThenElse(Field()).else_clause == Any())
    assert (IfThenElse(Field(), Field()).then_clause == Field())
    assert (IfThenElse(Field(), Field()).else_clause == Any())
    assert (IfThenElse(Field(), else_clause=Field()).else_clause == Field())
    assert (IfThenElse(Field(), Field(), Field()).then_clause == Field())
    assert (IfThenElse(Field(), Field(), Field()).else_clause == Field())


# Generated at 2022-06-24 10:42:05.998264
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    field = OneOf([String(max_length=5), String(max_length=10)], min_length=1)
    value = field.validate('123')
    assert value == '123'

    field = OneOf([String(max_length=5), String(max_length=10)], min_length=1)
    error = field.validate('1234567')
    assert error.code == 'multiple_matches'



# Generated at 2022-06-24 10:42:09.229938
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    import typesystem
    class abc(typesystem.Schema):
        a = typesystem.Field()
        b = typesystem.Field()
        c = typesystem.Field()

    a = OneOf(abc.fields)
test_OneOf_validate()

# Generated at 2022-06-24 10:42:10.373075
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    never_match = NeverMatch()
    assert never_match is not None


# Generated at 2022-06-24 10:42:17.391120
# Unit test for constructor of class OneOf
def test_OneOf():
    import pytest
    from typesystem.fields import String

    with pytest.raises(AssertionError) as excinfo:
        OneOf(one_of=[String()], allow_null=True)
    assert '"allow_null" not in kwargs' in str(excinfo.value)
    with pytest.raises(AssertionError) as excinfo:
        OneOf(one_of=[String()], allow_null=False)
    assert '"allow_null" not in kwargs' in str(excinfo.value)
    OneOf(one_of=[String()])
    OneOf(one_of=[String()], description='test description')


# Generated at 2022-06-24 10:42:19.762969
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(String())
    assert not_field.negated == String()


# Generated at 2022-06-24 10:42:25.186020
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    A = IfThenElse(Any(), None, None)
    assert not A.if_clause
    assert not A.then_clause
    assert not A.else_clause
    B = IfThenElse(Any(), Any(), Any())
    assert B.if_clause
    assert B.then_clause
    assert B.else_clause



# Generated at 2022-06-24 10:42:32.973304
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    from typesystem import ValidationError
    from typesystem.fields import Literal

    personfield = NeverMatch()
    personfield._validate_one_of_or_type(Literal("hello"))
    try:
        personfield.validate("helloxxx")
    except ValidationError as e:
        assert e.messages == {"never": "This never validates."}
        assert e.data == {"field": "helloxxx"}
        assert str(e) == "{'never': 'This never validates.'}"
        assert repr(e) == "ValidationError(messages={'never': 'This never validates.'}, data={'field': 'helloxxx'}, fields=None)"
    else:
        assert False, "must raise ValidationError"



# Generated at 2022-06-24 10:42:41.854810
# Unit test for constructor of class OneOf
def test_OneOf():
    from dataclasses import dataclass
    from . import Array, Boolean, Integer
    from .validators import MinLength

    # For testing
    @dataclass
    class TestSchema:
        choose_one: OneOf

    # Constructor
    schema = TestSchema(choose_one=OneOf([Boolean(), Integer()]))
    assert isinstance(schema.choose_one, OneOf)
    assert isinstance(schema.choose_one.one_of[0], Boolean)
    assert isinstance(schema.choose_one.one_of[1], Integer)



# Generated at 2022-06-24 10:42:44.981501
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    f = AllOf([Any(min_length=5)])
    assert f.validate("12345") == "12345"

# Generated at 2022-06-24 10:42:46.871874
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    IfThenElse(Any(), Any(), Any())
    IfThenElse(Any())
    IfThenElse(Any(), Any())

# Generated at 2022-06-24 10:42:49.081963
# Unit test for constructor of class AllOf
def test_AllOf():
    TestAllOf = AllOf([])
    assert isinstance(TestAllOf, Field)

# Generated at 2022-06-24 10:42:54.730277
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    with pytest.raises(ValidationError, match="Validation error for field 'field_name': never"):
        field.validate(None, False)
    with pytest.raises(ValidationError, match="Validation error for field 'field_name': never"):
        field.validate(0, False)
    with pytest.raises(ValidationError, match="Validation error for field 'field_name': never"):
        field.validate('', False)


# Generated at 2022-06-24 10:42:56.598581
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-24 10:42:59.698762
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    class TestField(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            return value
    field = AllOf(all_of=[TestField()])
    field.validate(value=1)

# Generated at 2022-06-24 10:43:03.293217
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    ite = IfThenElse(Integer(), then_clause=Integer(min_value=0), else_clause=Integer(max_value=0))
    assert ite.validate(5) == 5
    assert ite.validate(-5) == -5

# Generated at 2022-06-24 10:43:06.211448
# Unit test for constructor of class Not
def test_Not():
    try:
        Not(None)
    except Exception as e:
        assert False


# Generated at 2022-06-24 10:43:15.643567
# Unit test for method validate of class OneOf
def test_OneOf_validate():

    from typesystem.fields import String, Integer

    class Test(OneOf):
        one_of = [String, Integer]

    field = Test()

    # validation of a string value
    value = "a string"
    v, e = field.validate_or_error(value, 'data')
    assert v == value
    assert e is None

    # validation of an integer value
    value = 42
    v, e = field.validate_or_error(value, 'data')
    assert v == value
    assert e is None

    # validation of a list
    value = [1, 2, 3]
    v, e = field.validate_or_error(value, 'data')
    assert e == {'type': 'no_match', 'path': 'data'}
    assert v is None

# Generated at 2022-06-24 10:43:16.943726
# Unit test for constructor of class AllOf
def test_AllOf():
    pass # TODO: construct object for testing

# Generated at 2022-06-24 10:43:18.543613
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    field = NeverMatch()
    assert field.validate(4) == None


# Generated at 2022-06-24 10:43:22.510897
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Composite
    field = Composite(type="allOf", items=[{'type': 'string'}, {'type': 'number'}])
    assert field.all_of[0].type == 'string'
    assert field.all_of[1].type == 'number'

# Generated at 2022-06-24 10:43:25.229340
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    errors = field.errors
    assert errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:43:28.793905
# Unit test for constructor of class OneOf
def test_OneOf():
    assert "errors" in OneOf.errors
    assert "one_of" in OneOf.__init__.__code__.co_varnames

# Generated at 2022-06-24 10:43:36.367828
# Unit test for method validate of class Not
def test_Not_validate():
    t = Not(Any())
    assert t.validate(1) == 1
    assert t._validate_or_error(1) == (1, None)

    with pytest.raises(ValidationError):
        t.validate(1, strict=True)
    assert t._validate_or_error(1, strict=True) == (1, ["negated"])



# Generated at 2022-06-24 10:43:40.482487
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Given
    if_clause = Any()
    then_clause = Any()
    else_clause = Any()
    strict = False
    # When
    try:
        IfThenElse(if_clause, then_clause, else_clause).validate(1, strict)
    except:
        assert False


# Generated at 2022-06-24 10:43:43.625454
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    obj = NeverMatch()


# Generated at 2022-06-24 10:43:45.855450
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    n = NeverMatch()
    assert n.validate(1) == None
    #n.validate(1)



# Generated at 2022-06-24 10:43:47.853319
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    NM = NeverMatch()
    assert NM.validate(2) == 2
    print("Test nevermatch validate is OK")


# Generated at 2022-06-24 10:43:51.333356
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([AllOf([Any()]), Any()])
    value = field.validate([1, 2])
    assert value == [1, 2]


# Generated at 2022-06-24 10:43:59.263123
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String

    schema = IfThenElse(if_clause=Integer(minimum=5),then_clause=String())

    assert schema.validate(5) == "5"
    assert schema.validate("test") is None
    assert schema.validate("test").__class__.__name__ == "NoneType"
    assert schema.validate("test") == None
    assert schema.validate("test") == None

    assert schema.validate("test") is None
    assert schema.validate("test").__class__.__name__ == "NoneType"
    assert schema.validate("test") == None

# Generated at 2022-06-24 10:44:02.633565
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class X(IfThenElse):
        pass
    a = X(if_clause=1)
    assert a.validate(1) == 1
# \Unit test for method validate of class IfThenElse

# Generated at 2022-06-24 10:44:07.841093
# Unit test for constructor of class AllOf
def test_AllOf():
    t=AllOf([1, 2, 3])
    assert t.all_of == [1, 2, 3]


# Generated at 2022-06-24 10:44:09.393964
# Unit test for constructor of class AllOf
def test_AllOf():
    import typesystem
    field = AllOf(typesystem.Boolean())

# Generated at 2022-06-24 10:44:13.769737
# Unit test for method validate of class Not
def test_Not_validate():
    x = Not(Int())
    # assert x.validate("a") == "a"
    assert x.validate(1) == 1
    assert x.validate("a") == "a"


# Generated at 2022-06-24 10:44:14.414022
# Unit test for constructor of class OneOf
def test_OneOf():
    Any()
    None

# Generated at 2022-06-24 10:44:15.954796
# Unit test for constructor of class OneOf
def test_OneOf():
    typed = OneOf(one_of=[])
    assert typed.one_of == []

# Generated at 2022-06-24 10:44:22.599945
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.primitives.numbers import Integer
    from typesystem.primitives.numbers import Number
    from typesystem.primitives.strings import String
    from typesystem.fields import Field

    field = Field.from_whatever(
        {
            "type": "object",
            "allOf": [
                {"type": "number"},
                {"type": "string"},
            ]
        }
    )

    assert isinstance(field.all_of[0], Number)
    assert isinstance(field.all_of[1], String)



# Generated at 2022-06-24 10:44:24.971595
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = [[1,2,3],[4,5,6]]
    field = OneOf(one_of)
    assert field.one_of == one_of


# Generated at 2022-06-24 10:44:27.604453
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert type(IfThenElse("test_if", "test_then", "test_else").validate("test")) == str

# Generated at 2022-06-24 10:44:29.278048
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    with pytest.raises(FieldError):
        NeverMatch().validate("abuse")


# Generated at 2022-06-24 10:44:30.026839
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Field(label="A"))



# Generated at 2022-06-24 10:44:31.255928
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    newField = NeverMatch()
    assert newField is not None


# Generated at 2022-06-24 10:44:42.457899
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    #Base case
    o1 = AllOf(None)
    o1.validate(3)

    #Base case
    o2 = AllOf(None)
    o2.validate(None)

    #Base case
    o3 = AllOf(None)
    o3.validate(None)

    #Base case
    o4 = AllOf(None)
    o4.validate(None)

    #Base case
    o5 = AllOf(None)
    o5.validate(None)
    
    # Input is an integer
    o6 = AllOf([Field()])
    o6.validate(3)
    
    # Base case
    o7 = AllOf(None)
    o7.validate(None)

    # Input is an integer
    o8 = AllOf([Field()])

# Generated at 2022-06-24 10:44:45.149195
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    m = NeverMatch(name="m")
    assert m.validate("thing") == "thing"
    assert m.validate(1) == 1
    assert m.validate(3.141) == 3.141


# Generated at 2022-06-24 10:44:48.239570
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []
    assert field.errors == {"no_match": "Did not match any valid type.", "multiple_matches": "Matched more than one type."}


# Generated at 2022-06-24 10:44:56.785829
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import String
    from typesystem import Integer
    data = {"name": "paul", "age": 100}
    test = Not(String(max_length=20))
    try:
        test.validate(data["name"])
        assert False, "Validating name with a string less than 20 character is a success"
    except:
        assert True
    try:
        test.validate(data["age"])
        assert True
    except:
        assert False, "Validating age with an integer not a string is a failure"



# Generated at 2022-06-24 10:44:58.885195
# Unit test for constructor of class Not
def test_Not():
    name = "test"
    negated = NeverMatch()
    n = Not(negated)
    assert n.negated == negated


# Generated at 2022-06-24 10:45:02.088532
# Unit test for constructor of class Not
def test_Not():
    field = Not(Any())
    assert field.negated
    field = Not(Any(), allow_null=True)
    assert field.allow_null
    assert field.negated
    try:
        Not(Any(), allow_null=False)
        assert False
    except:
        assert True


# Generated at 2022-06-24 10:45:12.174532
# Unit test for method validate of class Not
def test_Not_validate():
    test_Field = Not(negated=None)
    test_value = 1
    # print('test_value = '+str(test_value))
    test_strict = False
    test_result = test_Field.validate(test_value, test_strict)
    # print('test_result = '+str(test_result))
    assert(test_value == test_result)

    test_Field = Not(negated=None)
    test_value = None
    # print('test_value = '+str(test_value))
    test_strict = False
    test_result = test_Field.validate(test_value, test_strict)
    # print('test_result = '+str(test_result))
    assert(test_value == test_result)


# Generated at 2022-06-24 10:45:13.726527
# Unit test for constructor of class OneOf
def test_OneOf():
    foo = OneOf([Field()])
    assert foo is not None


# Generated at 2022-06-24 10:45:18.239137
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer

    assert OneOf([Integer(), Integer()]).one_of[0] == Integer()
    assert OneOf([Integer(), Integer()]).one_of[1] == Integer()


# Generated at 2022-06-24 10:45:27.373605
# Unit test for constructor of class OneOf
def test_OneOf():
    try:
        OneOf([]).validate(42)
        assert False, "expected exception"
    except ValueError as e:
        assert str(e) == "Did not match any valid type."

    try:
        OneOf([Any(), Any()]).validate(42)
        assert False, "expected exception"
    except ValueError as e:
        assert str(e) == "Matched more than one type."

    assert OneOf([Int(max_value = 10), Int(min_value = 0)]).validate(42) == 42
    assert OneOf([Int(max_value = 10), Int(min_value = 0)]).validate(0) == 0

# Generated at 2022-06-24 10:45:28.511146
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-24 10:45:38.737090
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[
        Any(),
        Any(),
        Any()
    ])

    # case 1
    value = "mocked-value"
    result = field.validate(value)
    assert result == value

    # case 2
    field = OneOf(one_of=[
        Any(),
        AlwaysFailField(),
        AlwaysFailField()
    ])
    with pytest.raises(ValidationError):
        field.validate(value)

    # case 3
    field = OneOf(one_of=[
        AlwaysFailField(),
        Any(),
        Any()
    ])
    with pytest.raises(ValidationError):
        field.validate(value)

    # case 4

# Generated at 2022-06-24 10:45:42.375378
# Unit test for method validate of class Not
def test_Not_validate():
    # Must not match
    # Given
    not_field = Not(Any())
    value = 'asd'
    strict = True
    # When
    not_field.validate(value, strict)



# Generated at 2022-06-24 10:45:51.319004
# Unit test for method validate of class Not
def test_Not_validate():
    from .typing_utils import TypeUtils
    from .types import String, Object

    class NestedType1(Object):
        class Meta:
            properties = {"a": Boolean()}

    assert_equal(Not(String()).validate("a"), "a")
    assert_raises(String.validation_error("string"), Not(String()).validate, 123)
    assert_equal(Not(NestedType1()).validate({"a": True}), {"a": True})
    assert_raises(NestedType1.validation_error("object"), Not(NestedType1()).validate, {"a": False})

    # Test with optional fields
    class NestedType2(Object):
        class Meta:
            properties = {"a": String(optional=True)}


# Generated at 2022-06-24 10:45:52.725594
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    a = NeverMatch()
    assert a


# Generated at 2022-06-24 10:45:55.945900
# Unit test for constructor of class Not
def test_Not():
    # First, test the case where NOT negates something
    negated = Not(String())
    _, error = negated.validate_or_error(123)
    assert error is None

    # With that tested, we need to test the case where NOT does not negate something
    negated = Not(String())
    _, error = negated.validate_or_error("Hello")
    assert error is not None


# Generated at 2022-06-24 10:46:00.236770
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import numpy as np
    ite = IfThenElse(Integer(),Integer())
    ite.validate(1)
    ite.validate(2)


# Generated at 2022-06-24 10:46:02.133289
# Unit test for constructor of class AllOf
def test_AllOf():
    assert OneOf._options_class == FieldOptions


# test for constructor of class AllOf

# Generated at 2022-06-24 10:46:04.853437
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.fields import Number
    from typesystem.fields import Array

    arr = Array(String())
    num = Number()

    allf = AllOf([arr, num])

# Generated at 2022-06-24 10:46:07.046039
# Unit test for constructor of class Not
def test_Not():
    a = Not(negated = Field())
    assert a.negated.__class__.__name__ == "Field"



# Generated at 2022-06-24 10:46:09.918691
# Unit test for constructor of class AllOf
def test_AllOf():
	all_of = []
	all_of.append(AllOf(all_of))


# Generated at 2022-06-24 10:46:15.632847
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import AllOf, Any
    from typesystem import Schema

    class MySchema(Schema):
        int_or_bool = AllOf([Any(int), Any(bool)])

    m = MySchema(strict=False)
    assert m.validate({"int_or_bool": 123}) == {"int_or_bool": 123}


# Generated at 2022-06-24 10:46:25.350339
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class FieldStub(Field):
        def __init__(self, is_vald, vald_res):
            self.is_vald = is_vald
            self.vald_res = vald_res
        errors = {"negated": "Must not match."}
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            if self.is_vald:
                return self.vald_res
            raise self.validation_error("negated")

    if_field = FieldStub(True, "")
    then_field = FieldStub(False, "")
    else_field = FieldStub(True, "")
    ifThenElseField = IfThenElse(if_field, then_field, else_field)

# Generated at 2022-06-24 10:46:26.980830
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(int)
    assert not_field.negated == int



# Generated at 2022-06-24 10:46:33.478884
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from custom_fields_test_utils import ModelWithAllOfField

    sut = ModelWithAllOfField()

    x = {'name': 'Sumo'}

    actual = sut.validate(x)
    expected = x
    assert actual == expected

    x = {'name': 'Sumo', 'age': '10'}

    actual = sut.validate(x)
    expected = x
    assert actual == expected



# Generated at 2022-06-24 10:46:38.285984
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    try:
        if_clause = Field()
        then_clause = Field()
        else_clause = Field()

        IfThenElse(if_clause, then_clause, else_clause)
    except:
        assert False



# Generated at 2022-06-24 10:46:41.404305
# Unit test for constructor of class Not
def test_Not():
    field = Any()
    not_field = Not(field)
    assert not_field.negated == field
    assert not_field.errors == {"negated": "Must not match."}



# Generated at 2022-06-24 10:46:44.320379
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    import pytest
    with pytest.raises(AssertionError) as pytest_wrapped_e:
        f = NeverMatch(allow_null=True)
    assert pytest_wrapped_e.type == AssertionError


# Generated at 2022-06-24 10:46:47.849598
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NM = NeverMatch()
    print(NM)


# Generated at 2022-06-24 10:46:49.154349
# Unit test for constructor of class OneOf
def test_OneOf():

    assert 1 == 1



# Generated at 2022-06-24 10:46:58.443752
# Unit test for method validate of class Not
def test_Not_validate():
    import string
    from typesystem.fields import String
    from typesystem.types import Any

    # Success case test - pass in invalid value
    testInput = "TestInput"
    string_validator = String(max_length=4)
    not_field = Not(negated=string_validator)
    fields = {"test1": not_field}
    allowed_types = {"test1": Any()}
    expected_result = testInput
    real_result = not_field.validate(testInput)
    assert real_result == expected_result

    # Error case test - pass in invalid value
    testInput = ["t1", "t2", "t3"]
    string_validator = String(max_length=4)
    not_field = Not(negated=string_validator)

# Generated at 2022-06-24 10:47:02.942719
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Arrange
    a = Field(name="a")
    b = Field(name="b")
    one_of = OneOf(one_of=[a, b])

    # Act
    value = one_of.validate("hello")

    # Assert
    assert value == "hello"


# Generated at 2022-06-24 10:47:11.651825
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    # Testing AllOf.validate

    # 1.
    test = AllOf([Integer()])
    validated, _ = test.validate_or_error(1)
    assert validated == 1
    # 2.
    test = AllOf([Integer(), String()])
    validated, _ = test.validate_or_error(1)
    assert validated == 1
    # 3.
    test = AllOf([Integer()], min_length=1)
    validated, _ = test.validate_or_error([1])
    assert validated == [1]
    # 4.
    test = AllOf([Integer(), String()], min_length=1)
    validated, _ = test.validate_or_error([1])
    assert validated == [1]

# Generated at 2022-06-24 10:47:18.045003
# Unit test for method validate of class Not
def test_Not_validate():
    assertNot = Not(negated=Any())
    # case 1
    assert(assertNot.validate(1))
    # case 2
    assert(assertNot.validate(1.0))
    # case 3
    assert(assertNot.validate("text"))
    # case 4
    assert(assertNot.validate([]))
    # case 5
    assert(assertNot.validate(None))
    # case 6
    assert(assertNot.validate({}))

# Generated at 2022-06-24 10:47:21.254429
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    nev = NeverMatch()
    with pytest.raises(nev.validation_error):
        nev.validate(None)


# Generated at 2022-06-24 10:47:23.601287
# Unit test for method validate of class AllOf
def test_AllOf_validate():
    from typesystem.fields import String

    field = AllOf([String(), String()])
    field.validate("test string")



# Generated at 2022-06-24 10:47:26.348884
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    ne = NeverMatch()
    error = ne.validate(1)
    assert error.messages["never"] == "This never validates."


# Generated at 2022-06-24 10:47:29.278645
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    t = NeverMatch()
    with pytest.raises(ValidationError):
        t.validate(42)
    with pytest.raises(ValidationError):
        t.validate(None)


# Generated at 2022-06-24 10:47:32.834394
# Unit test for constructor of class AllOf
def test_AllOf():
  assert AllOf([Field()]).all_of == [Field()]

# Generated at 2022-06-24 10:47:35.885210
# Unit test for constructor of class AllOf
def test_AllOf():
    # No test for AllOf constructor
    # Argument number 1: 'self'
    # Argument number 2: 'all_of'
    pass


# Generated at 2022-06-24 10:47:38.833438
# Unit test for constructor of class Not
def test_Not():
    with pytest.raises(AssertionError):
        Not(
            Integer(description='number of times the vehicle has been insured'), allow_null=True
        )

# Generated at 2022-06-24 10:47:47.881474
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    # both conditions are None
    if_clause  = None
    then_clause = None
    else_clause = None
    # call the constructor
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    # test the values of if_clause, then_clause and else_clause
    assert if_clause == if_then_else.if_clause
    assert then_clause == if_then_else.then_clause
    assert else_clause == if_then_else.else_clause
    # if_clause is not None
    if_clause = "if_clause"
    # call the constructor
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    # test

# Generated at 2022-06-24 10:47:52.007611
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestClass(IfThenElse):
        pass

    if_clause = True
    then_clause = False
    else_clause = False
    x = TestClass(if_clause, then_clause, else_clause)

# Generated at 2022-06-24 10:47:58.203051
# Unit test for method validate of class NeverMatch
def test_NeverMatch_validate():
    #
    # GIVEN
    args = {'description': 'This never validates.'}
    test_instance = NeverMatch(**args)
    #
    # WHEN
    with pytest.raises(test_instance.validation_error):
        test_instance.validate(**args)
    #
    # THEN
    assert False

# Generated at 2022-06-24 10:48:02.722945
# Unit test for constructor of class Not
def test_Not():
    string = Not(String())
    boolean = Not(Boolean())
    integer = Not(Integer())
    number = Not(Number())
    date = Not(Date())
    time = Not(Time())
    datetime = Not(DateTime())
    schema = [string, boolean, integer, number, date, time, datetime]

    print(schema)


# Generated at 2022-06-24 10:48:10.602044
# Unit test for method validate of class Not
def test_Not_validate():
    class AnIntegerField(Field):
        def validate(self, value:int, strict: bool = False) -> typing.Any:
            if not isinstance(value, int):
                raise self.validation_error("not_an_int")
            else:
                return value

    not_a_field = Not(AnIntegerField())
    try:
        not_a_field.validate(5)
        return False
    except Field.ValidationError:
        return True


# Generated at 2022-06-24 10:48:13.667472
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import String, Integer
    from typesystem.fields import OneOf

    oneof = OneOf([String(max_length=10), Integer()])
    result = oneof.validate('test')
    assert result == 'test'

    result = oneof.validate(None)
    assert not result

# Generated at 2022-06-24 10:48:18.558534
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause = String,
        then_clause = Int,
        else_clause = String)
    assert field.validate("") is ""
    assert field.validate(42) == 42



# Generated at 2022-06-24 10:48:20.510378
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse([1,2,3]) == IfThenElse([1,2,3],then_clause=Any(),else_clause=Any())

# Generated at 2022-06-24 10:48:23.421254
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Boolean()])

    assert field.validate("a") == "a"
    with pytest.raises(ValidationError):
        assert field.validate(4)
        

# Generated at 2022-06-24 10:48:25.885794
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {'never': 'This never validates.'}


# Generated at 2022-06-24 10:48:30.691876
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(value=10) == 10


# Generated at 2022-06-24 10:48:31.696372
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    NeverMatch(required=True)


# Generated at 2022-06-24 10:48:35.971748
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # 1. Should assert the simple case
    assert True

    # 2. Should assert the simple case
    assert True

    # 3. Should assert the simple case
    assert True

    # 4. Should assert the simple case
    assert True

    # 5. Should assert the simple case
    assert True
