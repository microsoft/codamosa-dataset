

# Generated at 2022-06-18 12:02:44.457223
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1:
    # IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    # Expected result:
    # No exception
    try:
        IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())
    except Exception as e:
        print("Test case 1 failed: " + str(e))
    else:
        print("Test case 1 passed")

    # Test case 2:
    # IfThenElse(if_clause=Field(), then_clause=Field())
    # Expected result:
    # No exception
    try:
        IfThenElse(if_clause=Field(), then_clause=Field())
    except Exception as e:
        print("Test case 2 failed: " + str(e))


# Generated at 2022-06-18 12:02:45.207626
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:02:53.736528
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:03:02.905587
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
    strict = False
    expected = 1
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
    strict = True
    expected = 1
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected

    # Test case 3
    if_clause = Field()
    then_clause = Field()
    else_clause = Field

# Generated at 2022-06-18 12:03:12.038722
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MinLength
    from typesystem.exceptions import ValidationError

    class MyType(Type):
        field = AllOf([String(validators=[MinLength(5)]), String(max_length=10)])

    type = MyType()
    type.validate({"field": "hello"})
    try:
        type.validate({"field": "hi"})
    except ValidationError as e:
        assert e.error_code == "min_length"
    try:
        type.validate({"field": "hello world"})
    except ValidationError as e:
        assert e.error_code == "max_length"


# Generated at 2022-06-18 12:03:21.013782
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Union
    from typesystem.fields import Enum
    from typesystem.fields import Reference
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse
    from typesystem.fields import Field
    from typesystem.fields import FieldError
    from typesystem.fields import ValidationError
    from typesystem.fields import ValidationError
    from typesystem.fields import ValidationError
    from typesystem.fields import ValidationError

# Generated at 2022-06-18 12:03:26.613556
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:03:36.701589
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0+2.0j) == 1.0+2.0j
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2]) == [1, 2]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:03:46.114996
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:03:57.123418
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    import pytest
    import json

    class TestSchema(typesystem.Schema):
        if_clause = typesystem.Integer(minimum=0)
        then_clause = typesystem.String()
        else_clause = typesystem.String()

    schema = TestSchema()
    assert schema.validate({"if_clause": 1, "then_clause": "a", "else_clause": "b"}) == {
        "if_clause": 1,
        "then_clause": "a",
        "else_clause": "b",
    }

# Generated at 2022-06-18 12:04:04.511078
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:04:14.159030
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1.1) == 1.1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate("1") == "1"
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(True) == True
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(None) == None

# Generated at 2022-06-18 12:04:24.857897
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case 1
    field = OneOf([])
    value = None
    strict = False
    expected = None
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 2
    field = OneOf([])
    value = None
    strict = True
    expected = None
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 3
    field = OneOf([])
    value = ""
    strict = False
    expected = ""
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 4
    field = OneOf([])
    value = ""
    strict = True
    expected = ""
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 5
   

# Generated at 2022-06-18 12:04:33.201715
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field.validate({"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-18 12:04:35.812327
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any()
    )
    field.validate(None)

# Generated at 2022-06-18 12:04:37.402262
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:43.132642
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:04:48.993898
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:04:50.594823
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:51.130190
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)

# Generated at 2022-06-18 12:04:57.708989
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with valid input
    field = OneOf([Any()])
    assert field.one_of == [Any()]

    # Test with invalid input
    try:
        field = OneOf([Any()], allow_null=True)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-18 12:04:59.423596
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(all_of=[])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:05:01.203945
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated == Field()

# Generated at 2022-06-18 12:05:02.951079
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:05.744105
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    a = AllOf([String()])
    assert a.all_of[0].__class__.__name__ == 'String'


# Generated at 2022-06-18 12:05:07.681438
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=None)
    assert not_field.negated == None


# Generated at 2022-06-18 12:05:08.702614
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())

# Generated at 2022-06-18 12:05:10.112699
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:05:15.117937
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(None) == None
    assert if_then_else.validate(None, strict=True) == None

# Generated at 2022-06-18 12:05:16.863513
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    assert field.validate(None) == None


# Generated at 2022-06-18 12:05:23.201966
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(1)
    not_field.validate(None)
    try:
        not_field.validate("")
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:05:33.428577
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
   

# Generated at 2022-06-18 12:05:43.981107
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import Schema
    from typesystem.types import SchemaType
    from typesystem.types import Object
    from typesystem.types import Array
    from typesystem.types import Boolean
    from typesystem.types import Integer
    from typesystem.types import Number
    from typesystem.types import String
    from typesystem.types import DateTime
    from typesystem.types import Enum
    from typesystem.types import Any
    from typesystem.types import Union
    from typesystem.types import Reference
    from typesystem.types import Link
    from typesystem.types import ValidationError
    from typesystem.types import ValidationErrors
    from typesystem.types import ValidationError

# Generated at 2022-06-18 12:05:45.735431
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:05:47.445665
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:52.372570
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:05:54.221763
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:04.866559
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(()) == ()
    assert not_field.validate(object()) == object()

# Generated at 2022-06-18 12:06:09.279075
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:06:18.619286
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = "value"
    strict = False
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(value, strict) == value

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = "value"
    strict = True
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(value, strict) == value

    # Test case 3
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value

# Generated at 2022-06-18 12:06:30.429106
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("") == ""
    assert not_field.validate("test") == "test"
    assert not_field.validate([]) == []
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({}) == {}
    assert not_field.validate({"key": "value"}) == {"key": "value"}

# Generated at 2022-06-18 12:06:39.675386
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:06:43.137513
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
        assert False
    except Exception as e:
        assert e.args[0] == 'Must not match.'


# Generated at 2022-06-18 12:06:44.771268
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:45.771730
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:47.135252
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    assert field.validate(None) == None


# Generated at 2022-06-18 12:06:56.277892
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.types import IntegerType
    from typesystem.types import FloatType
    from typesystem.types import BooleanType
    from typesystem.types import ArrayType
    from typesystem.types import ObjectType
    from typesystem.types import DateTimeType
    from typesystem.types import DateType
    from typesystem.types import TimeType
    from typesystem.types import UUIDType
    from typesystem.types import ChoiceType
    from typesystem.types import AnyType
    from typesystem.types import EnumType
    from typesystem.types import NumberType
    from typesystem.types import IntegerType
    from typesystem.types import FloatType
    from typesystem.types import BooleanType

# Generated at 2022-06-18 12:07:05.709121
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    negated = String()
    not_field = Not(negated)
    value = "string"
    strict = False
    assert not_field.validate(value, strict) == value

    # Test case 2
    negated = String()
    not_field = Not(negated)
    value = "string"
    strict = True
    assert not_field.validate(value, strict) == value

    # Test case 3
    negated = String()
    not_field = Not(negated)
    value = 1
    strict = False
    assert not_field.validate(value, strict) == value

    # Test case 4
    negated = String()
    not_field = Not(negated)
    value = 1
    strict = True

# Generated at 2022-06-18 12:07:16.818600
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:07:22.680730
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:07:26.971694
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:38.113904
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:07:42.357996
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer, String
    field = AllOf([Integer(), String()])
    assert field.all_of == [Integer(), String()]


# Generated at 2022-06-18 12:07:51.247311
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Union
    from typesystem.types import Object
    from typesystem.types import Array
    from typesystem.types import Boolean
    from typesystem.types import Number
    from typesystem.types import Any
    from typesystem.types import Null
    from typesystem.types import Enum
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Email
    from typesystem.types import URL
    from typesystem.types import UUID
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import IPvAny
    from typesystem.types import MAC
   

# Generated at 2022-06-18 12:07:59.794891
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String
    from typesystem.exceptions import ValidationError
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("1") == "1"
    assert if_then_else.validate(1.0) == "1.0"
    assert if_then_else.validate(True) == "True"
    assert if_then_else.validate(False) == "False"
    assert if_then_else.validate(None) == "None"
    assert if_then_else.validate

# Generated at 2022-06-18 12:08:02.205053
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:12.060086
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = IfThenElse(if_clause=String(), then_clause=String(), else_clause=String())
    field.validate("a")
    field.validate("a", strict=True)
    field.validate("a", strict=False)
    field.validate("a", strict=True)
    field.validate("a", strict=False)
    field.validate("a", strict=True)
    field.validate("a", strict=False)
    field.validate("a", strict=True)
    field.validate("a", strict=False)
    field.validate("a", strict=True)
    field.validate("a", strict=False)

# Generated at 2022-06-18 12:08:22.078739
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate (line 545)
    class TestOneOf(OneOf):
        def __init__(self, one_of: typing.List[Field]) -> None:
            super().__init__(one_of)

    class TestField(Field):
        def __init__(self, name: str) -> None:
            super().__init__()
            self.name = name

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return self.name

    field = TestOneOf([TestField("a"), TestField("b")])
    assert field.validate("a") == "a"
    assert field.validate("b") == "b"

# Generated at 2022-06-18 12:08:27.114400
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = Not(String())
    assert field.validate("foo") == "foo"
    try:
        field.validate(123)
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False, "Expected ValidationError"


# Generated at 2022-06-18 12:08:28.069964
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:08:36.183488
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(1)
    try:
        not_field.validate(None)
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:08:43.952615
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:08:53.749273
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1) == 1.1

# Generated at 2022-06-18 12:08:55.049476
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:56.044332
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(None, None, None)

# Generated at 2022-06-18 12:08:59.248600
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:09:00.169116
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:09:01.613191
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:02.398025
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:09:03.049662
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:08.981884
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:09.954702
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:20.127977
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    assert OneOf([Any()]).validate(1) == 1
    assert OneOf([Any()]).validate(None) == None
    assert OneOf([Any()]).validate("hello") == "hello"
    assert OneOf([Any()]).validate(True) == True
    assert OneOf([Any()]).validate(False) == False
    assert OneOf([Any()]).validate(1.0) == 1.0
    assert OneOf([Any()]).validate([1, 2, 3]) == [1, 2, 3]
    assert OneOf([Any()]).validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert OneOf([Any()]).validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:09:27.524740
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause
    if_then_else = IfThenElse(if_clause, then_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == Any()
    if_then_else = IfThenElse(if_clause)


# Generated at 2022-06-18 12:09:29.042704
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:35.409600
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    try:
        field.validate(True)
        assert False
    except FieldValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(None)
        assert False
    except FieldValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(1.2)
        assert False
    except FieldValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:09:40.808799
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:09:42.252664
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[])
    assert field.validate(1) == 1


# Generated at 2022-06-18 12:09:49.993209
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field.validate({"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-18 12:09:50.790552
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:59.885335
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:10:07.314724
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}


# Generated at 2022-06-18 12:10:08.803418
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:10:10.494510
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:10:11.964093
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:10:15.226344
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."

# Generated at 2022-06-18 12:10:16.664919
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated == Any()


# Generated at 2022-06-18 12:10:25.640409
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate({"a":1, "b":2}) == {"a":1, "b":2}
    assert not_field.validate({"a":1, "b":2, "c":3}) == {"a":1, "b":2, "c":3}


# Generated at 2022-06-18 12:10:26.874267
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:10:35.961743
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.exceptions import ValidationError

    class MyType(Type):
        field = IfThenElse(
            if_clause=String(validators=[MaxLength(10)]),
            then_clause=String(validators=[MaxLength(5)]),
            else_clause=String(validators=[MaxLength(15)]),
        )

    try:
        MyType({"field": "12345678901"})
    except ValidationError as e:
        assert e.as_dict() == {'field': ['Ensure this field has no more than 5 characters.']}
    else:
        assert False


# Generated at 2022-06-18 12:10:53.691763
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    try:
        field.validate(123.456)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(True)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(["hello", 123])
        assert False
    except ValidationError as e:
        assert e.code == "multiple_matches"

# Generated at 2022-06-18 12:11:01.137649
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    if_clause = TestField()
    then_clause = TestField()
    else_clause = TestField()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(2) == 2
    assert if_then_else.validate(3) == 3

# Generated at 2022-06-18 12:11:04.315710
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(1)

# Generated at 2022-06-18 12:11:05.818724
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:11:13.535596
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLengthValidator
    from typesystem.validators import MinLengthValidator
    from typesystem.validators import PatternValidator

    # Test case 1
    # Test if the value is not validated by the negated field
    field = Not(String(max_length=10, min_length=1, pattern="^[a-zA-Z0-9_]*$"))
    value = "test"
    try:
        field.validate(value)
    except ValidationError:
        assert False

    # Test case 2
    # Test if the value is validated by the negated field

# Generated at 2022-06-18 12:11:23.277317
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.types import IntegerType
    from typesystem.types import BooleanType
    from typesystem.types import FloatType
    from typesystem.types import ArrayType
    from typesystem.types import ObjectType

    # Test 1
    try:
        Not(String(max_length=10)).validate("hello")
    except ValidationError as e:
        assert e.code == "negated"
        assert e.message == "Must not match."
        assert e.path == []
        assert e.value == "hello"
        assert e.type == StringType
        assert e.field == Not(String(max_length=10))

    # Test 2

# Generated at 2022-06-18 12:11:24.062455
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:11:24.955153
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:11:28.367418
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:11:29.141168
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:11:53.327214
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse
    from typesystem.fields import Any
    from typesystem.fields import Boolean
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Union
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse
    from typesystem.fields import Any
    from typesystem.fields import Boolean
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Array


# Generated at 2022-06-18 12:11:57.041686
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}

# Generated at 2022-06-18 12:11:57.864807
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:12:01.496448
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with valid input
    field = OneOf([Field()])
    assert field.one_of == [Field()]
    # Test with invalid input
    try:
        field = OneOf([Field()], allow_null=True)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-18 12:12:02.379845
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:12:08.720278
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:12:14.290826
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:12:15.124142
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:12:21.224035
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:12:26.019780
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause
