

# Generated at 2022-06-18 12:02:32.617287
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    assert field.validate(None) == None


# Generated at 2022-06-18 12:02:41.689226
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse
    from typesystem.types import Type
    from typesystem.validators import MaxLength

    class MyType(Type):
        field = IfThenElse(
            Integer(),
            then_clause=String(validators=[MaxLength(10)]),
            else_clause=String(validators=[MaxLength(20)]),
        )

    type = MyType()
    type.validate({"field": "hello"})
    type.validate({"field": "hello world"})
    with pytest.raises(ValidationError) as excinfo:
        type.validate({"field": "hello world!"})

# Generated at 2022-06-18 12:02:46.865031
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2]) == [1, 2]


# Generated at 2022-06-18 12:02:56.082989
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(range(1)) == range(1)
    assert not_field.validate(range(2)) == range(2)

# Generated at 2022-06-18 12:03:05.200834
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:03:14.728296
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:03:23.836034
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=NeverMatch()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:03:33.749630
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = False
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(value, strict) == value

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = True
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(value, strict) == value

    # Test case 3
    if_clause = Field()

# Generated at 2022-06-18 12:03:43.142296
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with empty list of fields
    one_of = OneOf([])
    assert one_of.validate(1) == 1

    # Test with one field
    one_of = OneOf([Field()])
    assert one_of.validate(1) == 1

    # Test with multiple fields
    one_of = OneOf([Field(), Field()])
    assert one_of.validate(1) == 1

    # Test with multiple fields and one of them is not valid
    one_of = OneOf([Field(), NeverMatch()])
    assert one_of.validate(1) == 1

    # Test with multiple fields and none of them is valid
    one_of = OneOf([NeverMatch(), NeverMatch()])

# Generated at 2022-06-18 12:03:49.326865
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()


# Generated at 2022-06-18 12:04:04.163413
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:04:05.170530
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:07.045692
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:12.996824
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:04:24.184093
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:04:29.924174
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = OneOf([String(), String()])
    field.validate("foo")
    try:
        field.validate(1)
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate("foo")
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:04:30.754645
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:39.686723
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:04:41.845732
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    field.validate(1)


# Generated at 2022-06-18 12:04:42.830302
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:04:53.860326
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate("abc") == "abc"
    assert not_field.validate([]) == []
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field

# Generated at 2022-06-18 12:04:55.935210
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:04:57.229362
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-18 12:04:59.020785
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:09.329691
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.fields import Not
    from typesystem.types import StringType
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Not
    from typesystem.types import StringType
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Not
    from typesystem.types import StringType
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Not
    from typesystem.types import StringType
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Not

# Generated at 2022-06-18 12:05:11.281229
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:05:21.446474
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": [1, 2]}) == {"a": [1, 2]}
    assert field.validate({"a": [1, 2], "b": [3, 4]}) == {"a": [1, 2], "b": [3, 4]}


# Generated at 2022-06-18 12:05:22.733166
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate(None) == None


# Generated at 2022-06-18 12:05:24.082088
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:05:29.909046
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:05:33.976335
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:05:34.894934
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:45.543335
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()], name="one_of")
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate(1.1) == 1.1
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2]) == [1, 2]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}


# Generated at 2022-06-18 12:05:47.269915
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:05:49.342478
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:50.810216
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:05:51.829307
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:05:55.681388
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    a = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert a.if_clause is not None
    assert a.then_clause is not None
    assert a.else_clause is not None

# Generated at 2022-06-18 12:06:05.989345
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    not_string = Not(String())
    assert not_string.validate(1) == 1
    assert not_string.validate(None) == None
    assert not_string.validate(True) == True
    assert not_string.validate(False) == False
    assert not_string.validate(1.1) == 1.1
    assert not_string.validate(1.0) == 1.0
    assert not_string.validate(1j) == 1j
    assert not_string.validate(1+1j) == 1+1j
    assert not_string.validate(1-1j) == 1-1j
    assert not_string.validate(1+1) == 1+1

# Generated at 2022-06-18 12:06:14.442223
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:06:18.527476
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:06:27.888058
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate("abc") == "abc"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate([1.0]) == [1.0]
    assert not_field.validate([""]) == [""]
    assert not_field.validate(["abc"]) == ["abc"]

# Generated at 2022-06-18 12:06:28.863898
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:30.429021
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-18 12:06:31.334541
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:32.175403
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:33.522152
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:42.214783
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
   

# Generated at 2022-06-18 12:06:43.942451
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    field = OneOf([String()])
    assert field.one_of == [String()]


# Generated at 2022-06-18 12:06:45.009213
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:06:48.672887
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:06:50.435575
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated == Field()


# Generated at 2022-06-18 12:07:00.255299
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(value=1) == 1
    assert field.validate(value=None) == None
    assert field.validate(value=True) == True
    assert field.validate(value=False) == False
    assert field.validate(value="") == ""
    assert field.validate(value="abc") == "abc"
    assert field.validate(value=[]) == []
    assert field.validate(value=[1, 2, 3]) == [1, 2, 3]
    assert field.validate(value={}) == {}
    assert field.validate(value={"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:07:01.092875
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:07:04.146653
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(1)
    try:
        not_field.validate(None)
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:07:05.694896
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:07:16.807232
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Regex

    # Test with valid value
    field = Not(String(max_length=3))
    value = "abcd"
    try:
        field.validate(value)
    except ValidationError:
        assert False
    else:
        assert True

    # Test with invalid value
    field = Not(String(max_length=3))
    value = "abc"
    try:
        field.validate(value)
    except ValidationError:
        assert True
    else:
        assert False

    # Test with valid value

# Generated at 2022-06-18 12:07:26.972447
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    field.validate(None)
    field.validate(1)
    field.validate("a")
    field.validate([])
    field.validate({})
    field.validate(True)
    field.validate(False)
    field.validate(1.0)
    field.validate(1.0+1.0j)
    field.validate(b"a")
    field.validate(bytearray(b"a"))
    field.validate(memoryview(b"a"))
    field.validate(range(0))
    field.validate(frozenset())
    field.validate(set())
    field.validate(dict())
    field.validate(list())
    field.validate(tuple())
    field

# Generated at 2022-06-18 12:07:29.241115
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated == Field()


# Generated at 2022-06-18 12:07:31.481867
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:07:34.479270
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:37.620149
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(value=1) == 1
    try:
        not_field.validate(value=None)
        assert False
    except:
        assert True


# Generated at 2022-06-18 12:07:39.149700
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:40.037020
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:42.205295
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-18 12:07:43.171728
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:07:44.652196
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[])


# Generated at 2022-06-18 12:07:52.893239
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength

    class MyString(String):
        validators = [MaxLength(5), MinLength(3)]

    not_string = Not(MyString())
    assert not_string.validate(1) == 1
    try:
        not_string.validate("123456")
    except ValidationError as e:
        assert e.code == "negated"
        assert e.message == "Must not match."
    try:
        not_string.validate("12")
    except ValidationError as e:
        assert e.code == "negated"
        assert e.message == "Must not match."


#

# Generated at 2022-06-18 12:07:58.454621
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any(), Any()])
    field.validate(1)
    field.validate(2)
    field.validate(3)
    field.validate(4)
    field.validate(5)
    field.validate(6)
    field.validate(7)
    field.validate(8)
    field.validate(9)
    field.validate(10)
    field.validate(11)
    field.validate(12)
    field.validate(13)
    field.validate(14)
    field.validate(15)
    field.validate(16)
    field.validate(17)
    field.validate(18)
    field.validate(19)
    field.validate(20)

# Generated at 2022-06-18 12:07:59.312188
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:07.515303
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
        assert False
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:08:08.526883
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:08:17.725412
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(range(1)) == range(1)
    assert not_field

# Generated at 2022-06-18 12:08:18.641635
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])



# Generated at 2022-06-18 12:08:25.597556
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    try:
        field.validate(1.1)
        assert False
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(True)
        assert False
    except Exception as e:
        assert str(e) == "Did not match any valid type."


# Generated at 2022-06-18 12:08:26.643374
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:35.534066
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(bytearray()) == bytearray()

# Generated at 2022-06-18 12:08:36.429400
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:37.421173
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:42.483756
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:08:59.398160
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2]) == [1, 2]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:09:00.959378
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated == Field()

# Generated at 2022-06-18 12:09:06.008798
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:09:06.886402
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:09.965961
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (line 543)
    field = Not(String())
    assert field.validate("foo") == "foo"
    with pytest.raises(ValidationError):
        field.validate(1)


# Generated at 2022-06-18 12:09:10.768173
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:21.033130
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2]) == [1, 2]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    assert not_

# Generated at 2022-06-18 12:09:21.951703
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:22.824346
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())

# Generated at 2022-06-18 12:09:23.423490
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:39.616162
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:47.412021
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:09:48.219267
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:54.282595
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({"a":1}) == {"a":1}


# Generated at 2022-06-18 12:09:55.133573
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:10:02.787387
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate([1, "a", True]) == [1, "a", True]
    assert not_field.validate([1, "a", True, [], {}])

# Generated at 2022-06-18 12:10:04.251882
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:10:06.090931
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:10:08.936618
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    not_ = Not(negated=None)
    value = None
    strict = None

    # Perform the test
    result = not_.validate(value, strict)

    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:10:13.331159
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (line 541)
    field = Not(String())
    assert field.validate("foo") == "foo"
    try:
        field.validate(1)
    except ValidationError:
        pass
    else:
        assert False, "Expected ValidationError"


# Generated at 2022-06-18 12:11:43.095074
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("hello") == "hello"

    field = OneOf([String(), Integer()])
    assert field.validate("hello") == "hello"
    assert field.validate(1) == 1
    with pytest.raises(ValidationError):
        field.validate(None)

    field = OneOf([String(), Integer()])
    with pytest.raises(ValidationError):
        field.validate(None)
    with pytest.raises(ValidationError):
        field.validate(1.1)
    with pytest.raises(ValidationError):
        field.validate("hello", strict=True)


# Generated at 2022-06-18 12:11:50.404102
# Unit test for method validate of class Not

# Generated at 2022-06-18 12:11:57.244091
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0+1.0j) == 1.0+1.0j
    assert field.validate({"a":1}) == {"a":1}
    assert field.validate([1,2,3]) == [1,2,3]
    assert field.validate({"a":1, "b":2}) == {"a":1, "b":2}

# Generated at 2022-06-18 12:12:05.986735
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("abc") == "abc"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(range(1)) == range(1)
    assert not_field

# Generated at 2022-06-18 12:12:16.019728
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0 + 1j) == 1.0 + 1j
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}

# Generated at 2022-06-18 12:12:24.128361
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(0) == 0
    assert not_field.validate(1) == 1
    assert not_field.validate(0.0) == 0.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}

# Generated at 2022-06-18 12:12:29.482092
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
