

# Generated at 2022-06-18 12:02:38.313750
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate("test") == "test"
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({"test": "test"}) == {"test": "test"}
    assert field.validate(["test"]) == ["test"]
    assert field.validate({"test": "test"}, strict=True) == {"test": "test"}
    assert field.validate(["test"], strict=True) == ["test"]

# Generated at 2022-06-18 12:02:41.998302
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    field.validate(None)
    field.validate(True)
    field.validate(1)
    field.validate("1")
    field.validate(1.0)
    field.validate([])
    field.validate({})
    field.validate({"a": 1})


# Generated at 2022-06-18 12:02:43.289986
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated == Any()

# Generated at 2022-06-18 12:02:47.393662
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    not_field = Not(String())
    assert not_field.validate(1) == 1
    try:
        not_field.validate('a')
    except ValidationError as e:
        assert e.code == 'negated'
    else:
        assert False


# Generated at 2022-06-18 12:02:48.258620
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:02:53.736377
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("a") == "a"

# Generated at 2022-06-18 12:03:02.906209
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:03:09.565668
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.types import String
    from typesystem.exceptions import ValidationError

    field = IfThenElse(
        if_clause=Integer(),
        then_clause=String(),
        else_clause=String(),
    )

    assert field.validate(1) == "1"
    assert field.validate("1") == "1"
    assert field.validate(1.0) == "1.0"

    with pytest.raises(ValidationError):
        field.validate(None)

# Generated at 2022-06-18 12:03:10.778193
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:03:20.230525
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class TestField2(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class TestField3(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    if_clause = TestField()
    then_clause = TestField2()
    else_clause = TestField3()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:03:39.611950
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:03:40.583505
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:03:50.076768
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:03:59.072444
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with a valid value
    field = OneOf([Any()])
    value = "test"
    assert field.validate(value) == value

    # Test with an invalid value
    field = OneOf([NeverMatch()])
    value = "test"
    with pytest.raises(ValidationError):
        field.validate(value)

    # Test with a value that matches multiple types
    field = OneOf([Any(), Any()])
    value = "test"
    with pytest.raises(ValidationError):
        field.validate(value)


# Generated at 2022-06-18 12:04:10.065708
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:04:13.433018
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:04:19.992846
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = IfThenElse(String(max_length=5), String(max_length=10))
    field.validate("12345")
    field.validate("123456")
    try:
        field.validate("1234567")
    except ValidationError as e:
        assert e.code == "max_length"
    else:
        assert False, "ValidationError not raised"

# Generated at 2022-06-18 12:04:21.178338
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:04:30.856610
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    field = OneOf([String(), String()])
    assert field.validate("foo") == "foo"

    field = OneOf([String(), String(max_length=3)])
    assert field.validate("foo") == "foo"

    field = OneOf([String(max_length=3), String()])
    assert field.validate("foo") == "foo"

    field = OneOf([String(max_length=3), String(max_length=5)])
    assert field.validate("foo") == "foo"

    field = OneOf([String(max_length=3), String(max_length=5)])
    assert field.validate("foobar") == "foobar"


# Generated at 2022-06-18 12:04:31.712435
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:04:41.683828
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError

    field = IfThenElse(Integer(), String())
    field.validate(1)
    field.validate("1")
    try:
        field.validate(1.1)
    except ValidationError as e:
        assert e.code == "invalid_type"
    try:
        field.validate(1.1)
    except ValidationError as e:
        assert e.code == "invalid_type"

# Generated at 2022-06-18 12:04:42.751223
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:04:52.011510
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength

    class TestType(Type):
        field = IfThenElse(String(max_length=3), String(max_length=3), String(max_length=3))

    test_type = TestType()
    assert test_type.validate({"field": "123"}) == {"field": "123"}
    assert test_type.validate({"field": "1234"}) == {"field": "1234"}
    assert test_type.validate({"field": "12345"}) == {"field": "12345"}
    try:
        test_type.validate({"field": "123456"})
    except ValidationError as e:
        assert e

# Generated at 2022-06-18 12:05:01.564207
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import Number
    from typesystem.types import Boolean
    from typesystem.types import String
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Enum
    from typesystem.types import UUID
    from typesystem.types import Any
    from typesystem.types import Union
    from typesystem.types import OneOf
    from typesystem.types import AllOf
    from typesystem.types import Not
    from typesystem.types import IfThenElse
    from typesystem.fields import Field
    from typesystem.fields import Integer


# Generated at 2022-06-18 12:05:02.492729
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([Any()])


# Generated at 2022-06-18 12:05:13.147012
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:05:14.920681
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:05:15.911708
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:05:16.907462
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:05:26.916141
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.1) == 1.1
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:05:30.436399
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:40.245147
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:05:41.754697
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:05:43.641047
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:54.840595
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Pattern
    from typesystem.validators import Required
    from typesystem.validators import Validator

    # Test 1:
    # Test that the constructor of class AllOf works as expected
    # when the parameter all_of is a list of Field objects.
    # The expected result is that the constructor of class AllOf
    # returns an object of class AllOf.
    all_of = [String(max_length=10), String(min_length=5)]
    all_of_field = AllOf(all_of)
    assert isinstance(all_of_field, AllOf)

# Generated at 2022-06-18 12:05:57.138903
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:06:06.801537
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse
    from typesystem.fields import Not
    from typesystem.fields import AllOf
    from typesystem.fields import OneOf
    from typesystem.fields import NeverMatch
    from typesystem.fields import Any

    # Test case 1
    # IfThenElse(if_clause=Not(String()), then_clause=Integer(), else_clause=Integer())
    # value = "test"
    # expected = ValidationError(errors={"if_clause": "Must not match."})
    # actual = IfThenElse(if_clause=Not(String()), then_clause=Integer(), else_clause=Integer()).validate(value)
    # assert

# Generated at 2022-06-18 12:06:07.590997
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:08.712477
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="NeverMatch")


# Generated at 2022-06-18 12:06:12.808526
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = IfThenElse(String(max_length=5), String(max_length=10))
    field.validate("12345")
    try:
        field.validate("123456")
    except ValidationError:
        pass
    else:
        assert False



# Generated at 2022-06-18 12:06:17.783034
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:06:27.123199
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1]) == [1]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate([1, 2]) == [1, 2]
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.valid

# Generated at 2022-06-18 12:06:28.005739
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:06:37.129934
# Unit test for method validate of class Not

# Generated at 2022-06-18 12:06:46.036835
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:06:46.851499
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:06:51.068313
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(1, strict=True) == 1

# Generated at 2022-06-18 12:06:51.926575
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:01.871763
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=NeverMatch(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:07:02.749894
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:07:09.918848
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type

    class TestType(Type):
        field = AllOf([String(), String()])

    assert TestType.field.all_of == [String(), String()]


# Generated at 2022-06-18 12:07:10.897090
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:07:21.975794
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field.validate({"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-18 12:07:22.963914
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:07:24.762761
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:25.779707
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:07:26.728400
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:07:33.254501
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:07:40.914340
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.1) == 1.1
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:07:43.409161
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:54.173939
# Unit test for method validate of class Not
def test_Not_validate():
    # Test with valid value
    field = Not(Any())
    assert field.validate(1) == 1
    # Test with invalid value
    field = Not(Any())
    try:
        field.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."


# Generated at 2022-06-18 12:07:55.125046
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:07:56.157914
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())


# Generated at 2022-06-18 12:07:57.011410
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:07:59.716918
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    with pytest.raises(ValidationError):
        not_field.validate(None)


# Generated at 2022-06-18 12:08:02.126198
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:08:03.465486
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:08:10.280933
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("string") == "string"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:08:11.109375
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:08:12.678615
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    nm = NeverMatch()
    assert nm.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:28.110984
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="NeverMatch")


# Generated at 2022-06-18 12:08:29.167681
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:08:37.996859
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1]) == [1]
    assert field.validate([1, 2]) == [1, 2]
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate([1, 2, 3, 4])

# Generated at 2022-06-18 12:08:39.923972
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:08:42.072564
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(None)
    try:
        not_field.validate(1)
        assert False
    except:
        assert True


# Generated at 2022-06-18 12:08:51.922211
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("") == ""
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1}, strict=True) == {"a": 1}
    assert field.validate([1, 2, 3], strict=True) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:08:52.929438
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:08:58.781592
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()


# Generated at 2022-06-18 12:09:04.337731
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:09:07.929310
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object

    field = AllOf([String(), Integer(), Float(), Boolean(), Array(), Object()])
    assert field.all_of == [String(), Integer(), Float(), Boolean(), Array(), Object()]


# Generated at 2022-06-18 12:10:29.057152
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:10:32.448378
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    value = "test"
    strict = False
    negated = Field()

    # Perform the test
    test_obj = Not(negated)
    result = test_obj.validate(value, strict)

    # Return the result.
    return result


# Generated at 2022-06-18 12:10:41.263425
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({}) == {}
    assert field.validate([]) == []
    assert field.validate("") == ""
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0)

# Generated at 2022-06-18 12:10:49.649562
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0 + 1.0j) == 1.0 + 1.0j
    assert field.validate(()) == ()
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(set()) == set()
    assert field.validate(frozenset()) == frozenset()
    assert field.validate(range(0)) == range(0)
    assert field.validate

# Generated at 2022-06-18 12:10:59.943778
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    field = Not(negated=Field())
    value = "test"
    strict = False
    assert field.validate(value, strict) == value

    # Test case 2
    field = Not(negated=Field())
    value = "test"
    strict = True
    assert field.validate(value, strict) == value

    # Test case 3
    field = Not(negated=Field())
    value = None
    strict = False
    assert field.validate(value, strict) == value

    # Test case 4
    field = Not(negated=Field())
    value = None
    strict = True
    assert field.validate(value, strict) == value

    # Test case 5
    field = Not(negated=Field())
    value = ""
    strict = False

# Generated at 2022-06-18 12:11:08.917168
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:11:17.611096
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}


# Generated at 2022-06-18 12:11:26.455376
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1}, strict=True) == {"a": 1}
    assert field.validate([1, 2, 3], strict=True) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}, strict=True) == {"a": 1, "b": 2}
    assert field

# Generated at 2022-06-18 12:11:29.323050
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate("test") == "test"
    try:
        not_field.validate(None)
        assert False
    except:
        assert True


# Generated at 2022-06-18 12:11:36.748979
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("") == ""
    assert not_field.validate("abc") == "abc"
    assert not_field.validate([]) == []
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({}) == {}
    assert not_field.validate({'a':1, 'b':2}) == {'a':1, 'b':2}