

# Generated at 2022-06-18 12:02:36.779006
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == 'Must not match.'


# Generated at 2022-06-18 12:02:45.440233
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Enum
    from typesystem.fields import UUID
    from typesystem.fields import URL
    from typesystem.fields import Email
    from typesystem.fields import IPAddress
    from typesystem.fields import IPv4Address
    from typesystem.fields import IPv6Address
    from typesystem.fields import Slug
    from typesystem.fields import Choice
    from typesystem.fields import Dict
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch

# Generated at 2022-06-18 12:02:54.687403
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = False
    field = IfThenElse(if_clause, then_clause, else_clause)
    field.validate(value, strict)
    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = True
    field = IfThenElse(if_clause, then_clause, else_clause)
    field.validate(value, strict)
    # Test case 3
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = False

# Generated at 2022-06-18 12:02:56.289168
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated == Field()


# Generated at 2022-06-18 12:03:03.696432
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Object

    class MyObject(Object):
        field = IfThenElse(
            if_clause=Integer(),
            then_clause=Integer(),
            else_clause=String(),
        )

    obj = MyObject()
    obj.validate({"field": 1})
    obj.validate({"field": "1"})
    try:
        obj.validate({"field": 1.0})
    except ValidationError:
        pass
    else:
        assert False, "ValidationError not raised"

# Generated at 2022-06-18 12:03:04.239577
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-18 12:03:05.146286
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:03:06.034383
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())


# Generated at 2022-06-18 12:03:15.540015
# Unit test for constructor of class AllOf
def test_AllOf():
    a = AllOf([])
    assert a.all_of == []
    assert a.errors == {}
    assert a.description == ""
    assert a.name == ""
    assert a.allow_null == False
    assert a.default == None
    assert a.validators == []
    assert a.error_messages == {}
    assert a.metadata == {}
    assert a.allow_coerce == False
    assert a.allow_empty == True
    assert a.allow_blank == True
    assert a.allow_extra == False
    assert a.allow_reuse == False
    assert a.allow_set == False
    assert a.allow_tuple == False
    assert a.allow_list == False
    assert a.allow_dict == False
    assert a.allow_string == False
    assert a.allow_bytes

# Generated at 2022-06-18 12:03:17.235721
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:03:28.914877
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystemError
    from typesystem.types import ValidationError
    from typesystem.types import ValidationErrors
    from typesystem.types import ValidationResult
    from typesystem.types import ValidationResults
    from typesystem.types import Validator
    from typesystem.types import ValidatorError
    from typesystem.types import ValidatorErrors
    from typesystem.types import ValidatorResult
    from typesystem.types import ValidatorResults
    from typesystem.types import ValidatorType
    from typesystem.types import ValidatorTypes
    from typesystem.types import ValidatorValue
    from typesystem.types import ValidatorValues
    from typesystem.types import ValidatorValueType

# Generated at 2022-06-18 12:03:32.951672
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:03:42.378829
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
    strict = False
    expected = 1
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
    strict = True
    expected = 1
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected

    # Test case 3
    if_clause = Field()
    then_clause = Field()
    else_clause = Field

# Generated at 2022-06-18 12:03:46.786540
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False
    field = OneOf(one_of)
    # Perform the test
    result = field.validate(value, strict)
    # Validate the results
    assert True # TODO: implement your test here


# Generated at 2022-06-18 12:03:47.751025
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:03:50.586382
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer
    all_of = AllOf([Integer()])
    assert all_of.all_of[0].__class__.__name__ == 'Integer'


# Generated at 2022-06-18 12:03:58.406550
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:03:59.481711
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:04:06.676701
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import String, Integer
    field = OneOf([String(), Integer()])
    assert field.validate("foo") == "foo"
    assert field.validate(1) == 1
    try:
        field.validate(1.0)
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(True)
    except Exception as e:
        assert str(e) == "Did not match any valid type."


# Generated at 2022-06-18 12:04:13.393950
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:04:26.726371
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystemError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError

# Generated at 2022-06-18 12:04:34.257444
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Pattern
    from typesystem.validators import Regex
    from typesystem.validators import Validator

    # Test 1
    all_of = AllOf([String(max_length=10), String(min_length=5)])
    assert isinstance(all_of, Field)
    assert all_of.all_of == [String(max_length=10), String(min_length=5)]
    assert all_of.allow_null is False
    assert all_of.default is None
    assert all_of.description is None
    assert all_of.enum is None
    assert all_of.error_messages == {}
   

# Generated at 2022-06-18 12:04:44.114331
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.types import Type
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse
    from typesystem.fields import Enum
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Duration


# Generated at 2022-06-18 12:04:45.173319
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:51.085944
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        String(),
        Integer(),
    ])
    field.validate("1")
    field.validate(1)
    try:
        field.validate(1.0)
    except ValidationError:
        pass
    else:
        assert False, "Should have raised ValidationError"
    try:
        field.validate(None)
    except ValidationError:
        pass
    else:
        assert False, "Should have raised ValidationError"


# Generated at 2022-06-18 12:04:51.970233
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:52.994989
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:02.449209
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any(), Any()])
    field.validate(1)
    field.validate(2)
    field.validate(3)
    field.validate(4)
    field.validate(5)
    field.validate(6)
    field.validate(7)
    field.validate(8)
    field.validate(9)
    field.validate(10)
    field.validate(11)
    field.validate(12)
    field.validate(13)
    field.validate(14)
    field.validate(15)
    field.validate(16)
    field.validate(17)
    field.validate(18)
    field.validate(19)
    field.validate(20)

# Generated at 2022-06-18 12:05:13.060411
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse
    from typesystem.fields import Integer
    from typesystem.fields import Boolean

    class MyType(Type):
        field = IfThenElse(
            if_clause=Boolean(),
            then_clause=Integer(),
            else_clause=String(),
        )

    type = MyType()
    type.validate({"field": True})
    type.validate({"field": False})
    try:
        type.validate({"field": "abc"})
    except ValidationError as e:
        assert e.error_code == "invalid_type"

# Generated at 2022-06-18 12:05:19.354711
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:05:27.245641
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:37.510180
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer, String

    class MyField(AllOf):
        def __init__(self):
            super().__init__([Integer(), String()])

    field = MyField()
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    assert field.validate(1.0) == 1.0
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:05:38.460329
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:43.833825
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)

    assert field.validate(1) == "1"
    assert field.validate("a") == "a"

# Generated at 2022-06-18 12:05:45.253682
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:56.907791
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Number

    # Test 1
    if_clause = Boolean()
    then_clause = String()
    else_clause = Integer()
    field = IfThenElse(if_clause, then_clause, else_clause)
    value = True
    strict = False
    try:
        field.validate(value, strict)
    except ValidationError as exc:
        assert exc.code == "invalid_type"
        assert exc.message == "Must be a string."
        assert exc.field_name

# Generated at 2022-06-18 12:05:57.984756
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:06:07.365715
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(None) == None
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(True) == True
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(False) == False
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1.0) == 1.0

# Generated at 2022-06-18 12:06:08.196464
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:06:09.005001
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:14.481218
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."


# Generated at 2022-06-18 12:06:20.540617
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:06:29.756719
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse
    from typesystem.fields import Any
    from typesystem.fields import Integer
    from typesystem.fields import Boolean
    from typesystem.fields import String
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Union
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Duration
    from typesystem.fields import Decimal
    from typesystem.fields import Email
    from typesystem.fields import Regex
    from typesystem.fields import URL
    from typesystem.fields import UUID
    from typesystem.fields import Choice
   

# Generated at 2022-06-18 12:06:38.719473
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:06:39.554157
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:45.883601
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String, Integer
    from typesystem.exceptions import ValidationError

    field = IfThenElse(
        if_clause=Integer(),
        then_clause=String(),
        else_clause=Integer(),
    )

    assert field.validate(1) == "1"
    assert field.validate("1") == 1

    try:
        field.validate(1.1)
    except ValidationError as e:
        assert e.code == "invalid_type"
    else:
        assert False, "Should have raised ValidationError"

# Generated at 2022-06-18 12:06:54.710295
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.1) == 1.1
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:07:04.320309
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    field.validate(None)
    field.validate(1)
    field.validate(True)
    field.validate("")
    field.validate([])
    field.validate({})
    field.validate(set())
    field.validate(frozenset())
    field.validate(object())
    field.validate(object)
    field.validate(type)
    field.validate(Exception)
    field.validate(Exception())
    field.validate(Exception(""))
    field.validate(Exception(Exception))
    field.validate(Exception(Exception()))
    field.validate(Exception(Exception("")))
    field.validate(Exception(Exception(Exception)))
    field.validate(Exception(Exception(Exception())))
   

# Generated at 2022-06-18 12:07:09.748247
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:07:13.325321
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:07:26.542266
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(bytearray()) == bytearray

# Generated at 2022-06-18 12:07:28.400686
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-18 12:07:30.037005
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:07:39.711694
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    field = IfThenElse(Integer(min_value=0), Integer(min_value=1), Integer(min_value=2))
    assert field.validate(1) == 1
    assert field.validate(2) == 2
    try:
        field.validate(-1)
    except ValidationError as e:
        assert e.code == "min_value"
    else:
        assert False, "Should have raised ValidationError"
    try:
        field.validate(0)
    except ValidationError as e:
        assert e.code == "min_value"
    else:
        assert False, "Should have raised ValidationError"


# Generated at 2022-06-18 12:07:42.200264
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:07:47.842340
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:07:49.359375
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated == Field()


# Generated at 2022-06-18 12:07:53.603613
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:08:04.439601
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    field = Not(negated=Any())
    value = None
    strict = False
    expected = None
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 2
    field = Not(negated=Any())
    value = None
    strict = True
    expected = None
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 3
    field = Not(negated=Any())
    value = ""
    strict = False
    expected = ""
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 4
    field = Not(negated=Any())
    value = ""
    strict = True
    expected = ""
    actual = field.validate(value, strict)
   

# Generated at 2022-06-18 12:08:13.753396
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate('') == ''
    assert field.validate('a') == 'a'
    assert field.validate(b'a') == b'a'
    assert field.validate(b'') == b''
    assert field.validate(()) == ()
    assert field.validate((1,)) == (1,)
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({'a': 1}) == {'a': 1}
   

# Generated at 2022-06-18 12:08:21.574265
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated = Field())

# Generated at 2022-06-18 12:08:22.609898
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:08:31.804449
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystemError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError

# Generated at 2022-06-18 12:08:40.963801
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Boolean

    if_clause = Integer()
    then_clause = String()
    else_clause = Boolean()

    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate(True) == True
    assert if_then_else.validate(False) == False

    try:
        if_then_else.validate("a")
    except ValidationError as e:
        assert e.error_code == "invalid_type"
        assert e

# Generated at 2022-06-18 12:08:42.319196
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-18 12:08:52.222109
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = None
    strict = False
    expected = None
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected
    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = None
    strict = True
    expected = None
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected
    # Test case 3
    if_clause = Field()
    then_clause = Field()
    else_clause = Field

# Generated at 2022-06-18 12:08:59.479055
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = IfThenElse(String(max_length=3), String(max_length=4))
    assert field.validate("abc") == "abc"
    assert field.validate("abcd") == "abcd"
    try:
        field.validate("abcde")
        assert False
    except ValidationError:
        pass
    try:
        field.validate("ab")
        assert False
    except ValidationError:
        pass
    try:
        field.validate(1)
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-18 12:09:00.381297
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:09:00.999363
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate(1) == 1


# Generated at 2022-06-18 12:09:05.952256
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("test") == "test"
    assert field.validate([]) == []
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({}) == {}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:09:32.829846
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:09:36.899079
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}



# Generated at 2022-06-18 12:09:38.501969
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:09:44.609701
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    not_field = Not(String())
    try:
        not_field.validate(1)
    except ValidationError as e:
        assert e.code == "negated"
        assert e.message == "Must not match."
        assert e.value == 1
        assert e.field == not_field
        assert e.path == []
        assert e.context == {}
        assert e.valid_value is None
    else:
        assert False, "Should raise ValidationError"


# Generated at 2022-06-18 12:09:46.748920
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-18 12:09:53.303611
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("hello") == "hello"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:09:58.746021
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = IfThenElse(String(), String())
    field.validate("test")
    try:
        field.validate(1)
    except ValidationError as e:
        assert e.code == "invalid_type"
    field = IfThenElse(String(), String(), String())
    field.validate(1)
    field = IfThenElse(String(), String(), String(), default="test")
    assert field.validate(None) == "test"

# Generated at 2022-06-18 12:10:06.256777
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Boolean
    from typesystem.fields import Float
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse
    from typesystem.fields import Enum
    from typesystem.fields import UUID
    from typesystem.fields import URL
    from typesystem.fields import Email
    from typesystem.fields import Slug
    from typesystem.fields import Choice

# Generated at 2022-06-18 12:10:07.016410
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:10:10.616461
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    field = IfThenElse(String(max_length=5), String(min_length=5))
    assert field.validate("hello") == "hello"
    assert field.validate("hello world") == "hello world"

# Generated at 2022-06-18 12:11:08.063228
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:11:16.077193
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Boolean
    from typesystem.types import Array
    from typesystem.types import Object

    # Case 1: if_clause is String, then_clause is Integer, else_clause is String
    if_clause = String()
    then_clause = Integer()
    else_clause = StringType()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("1") == 1
    assert if_then_else.validate("a") == "a"

# Generated at 2022-06-18 12:11:22.681885
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:11:27.695437
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    field = IfThenElse(Integer(min_value=0), Integer(max_value=10))
    assert field.validate(5) == 5
    assert field.validate(11) == 11
    try:
        field.validate(-1)
    except ValidationError:
        pass
    else:
        assert False, "Should raise ValidationError"

# Generated at 2022-06-18 12:11:35.044581
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:11:43.385330
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:11:47.031582
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:11:51.354046
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:11:55.494718
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:12:03.541737
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestIfThenElse(IfThenElse):
        def __init__(self, if_clause: Field, then_clause: Field = None, else_clause: Field = None, **kwargs: typing.Any) -> None:
            super().__init__(if_clause, then_clause, else_clause, **kwargs)
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Regex
    from typesystem.validators import Validator
    from typesystem.validators import ValidatorList
    from typesystem.validators import ValidatorList
    from typesystem.validators import ValidatorList