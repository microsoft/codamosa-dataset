

# Generated at 2022-06-18 12:02:35.375973
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:02:42.728125
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Schema
    from typesystem.exceptions import ValidationError

    class AllOfSchema(Schema):
        field = AllOf([String(min_length=2), String(max_length=3)])

    schema = AllOfSchema()
    assert schema.validate({"field": "ab"}) == {"field": "ab"}
    with pytest.raises(ValidationError):
        schema.validate({"field": "a"})
    with pytest.raises(ValidationError):
        schema.validate({"field": "abcd"})


# Generated at 2022-06-18 12:02:49.273876
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength

    class MyType(Type):
        field = IfThenElse(String(validators=[MaxLength(3)]), String(validators=[MaxLength(4)]), String(validators=[MaxLength(5)]))

    type = MyType()
    type.validate({"field": "abc"})
    try:
        type.validate({"field": "abcd"})
        assert False
    except ValidationError:
        pass
    try:
        type.validate({"field": "abcde"})
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-18 12:02:55.822378
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(1) == "1"
    assert field.validate("1") == "1"
    with pytest.raises(ValidationError):
        field.validate(1.1)

# Generated at 2022-06-18 12:02:57.700440
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:02:59.584992
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    a = AllOf([String()])
    assert a.all_of == [String()]


# Generated at 2022-06-18 12:03:08.754474
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Boolean
    from typesystem.types import Float
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import Enum
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Email
    from typesystem.types import URL
    from typesystem.types import UUID
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import IPvAny
    from typesystem.types import MACAddress
    from typesystem.types import Slug

# Generated at 2022-06-18 12:03:10.317600
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:03:16.873239
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String
    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    try:
        field.validate(None)
        assert False
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(1.1)
        assert False
    except Exception as e:
        assert str(e) == "Matched more than one type."


# Generated at 2022-06-18 12:03:17.885431
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:03:29.469013
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.2) == 1.2
    assert not_field.validate(1.2) == 1.2
    assert not_field.validate(1.2) == 1.2
    assert not_field.validate(1.2) == 1.2
    assert not_field.validate(1.2) == 1.2
    assert not_field.validate(1.2) == 1.2

# Generated at 2022-06-18 12:03:36.510270
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    try:
        field.validate(1.1)
        assert False
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(1)
        assert False
    except Exception as e:
        assert str(e) == "Matched more than one type."


# Generated at 2022-06-18 12:03:45.934117
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem

    class AllOfTest(Type):
        name = String(max_length=10)
        age = String(max_length=10)

    class AllOfTest2(Type):
        name = String(max_length=10)
        age = String(max_length=10)

    class AllOfTest3(Type):
        name = String(max_length=10)
        age = String(max_length=10)

    class AllOfTest4(Type):
        name = String(max_length=10)
        age = String(max_length=10)


# Generated at 2022-06-18 12:03:49.454140
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:03:57.444910
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:04:08.196406
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}
    assert not_field.validate({1:1}) == {1:1}


# Generated at 2022-06-18 12:04:16.223338
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate(0) == 0
    assert not_field.validate(1) == 1
    assert not_field.validate(0.0) == 0.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}

# Generated at 2022-06-18 12:04:27.118619
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    if_clause = String(max_length=3)
    then_clause = String(min_length=3)
    else_clause = String(min_length=4)
    field = IfThenElse(if_clause, then_clause, else_clause)
    try:
        field.validate("abcd")
    except ValidationError as e:
        assert e.code == "min_length"
    try:
        field.validate("abc")
    except ValidationError as e:
        assert e.code == "max_length"
    try:
        field.validate("ab")
    except ValidationError as e:
        assert e.code == "min_length"

# Generated at 2022-06-18 12:04:31.847326
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([Int(), Float()])
    assert one_of.validate(1) == 1
    assert one_of.validate(1.0) == 1.0
    try:
        one_of.validate("1")
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        one_of.validate(1.0, 2.0)
    except Exception as e:
        assert str(e) == "Matched more than one type."


# Generated at 2022-06-18 12:04:37.396310
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[Any()])
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.

# Generated at 2022-06-18 12:04:50.329838
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem

# Generated at 2022-06-18 12:04:54.420300
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    from typesystem.fields import IfThenElse

    field = IfThenElse(
        if_clause=Integer(),
        then_clause=String(),
        else_clause=Integer(),
    )

    assert field.validate(1) == "1"
    assert field.validate("1") == 1

# Generated at 2022-06-18 12:05:04.172581
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=NeverMatch()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=NeverMatch(), else_clause=Any()).validate(1) == 1


# Generated at 2022-06-18 12:05:08.324982
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:05:15.996606
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = IfThenElse(String(max_length=3), String(max_length=5))
    assert field.validate("abc") == "abc"
    assert field.validate("abcde") == "abcde"
    try:
        field.validate("abcdef")
        assert False
    except ValidationError as e:
        assert e.code == "max_length"
    try:
        field.validate(123)
        assert False
    except ValidationError as e:
        assert e.code == "type"

# Generated at 2022-06-18 12:05:16.989593
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:26.920889
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
    strict = False
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(value, strict) == 1

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
    strict = True
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(value, strict) == 1

    # Test case 3
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
   

# Generated at 2022-06-18 12:05:28.235683
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:05:38.501530
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Boolean
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import Any
    from typesystem.types import Union
    from typesystem.types import Reference
    from typesystem.types import Enum
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Duration
    from typesystem.types import Email
    from typesystem.types import UUID
    from typesystem.types import URI
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import MAC

# Generated at 2022-06-18 12:05:44.645186
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with valid value
    field = OneOf([Any()])
    value = "test"
    assert field.validate(value) == value

    # Test with invalid value
    field = OneOf([NeverMatch()])
    value = "test"
    try:
        field.validate(value)
    except Exception as e:
        assert str(e) == "Did not match any valid type."


# Generated at 2022-06-18 12:05:49.094811
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:50.247653
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:52.080075
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:59.902627
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:06:03.621911
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test with valid input
    field = AllOf([Any()])
    assert field.all_of == [Any()]

    # Test with invalid input
    with pytest.raises(AssertionError):
        AllOf([Any()], allow_null=True)


# Generated at 2022-06-18 12:06:10.237754
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Any()).validate(None) == None
    assert Not(Any()).validate(1) == 1
    assert Not(Any()).validate("a") == "a"
    assert Not(Any()).validate(True) == True
    assert Not(Any()).validate(False) == False
    assert Not(Any()).validate([1,2,3]) == [1,2,3]
    assert Not(Any()).validate({1:2,3:4}) == {1:2,3:4}
    assert Not(Any()).validate({"a":1,"b":2}) == {"a":1,"b":2}
    assert Not(Any()).validate({"a":1,"b":2}) == {"a":1,"b":2}
    assert Not(Any()).valid

# Generated at 2022-06-18 12:06:11.780593
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:06:12.808187
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:16.602650
# Unit test for method validate of class Not
def test_Not_validate():
    # Test with valid value
    not_field = Not(Any())
    assert not_field.validate(1) == 1

    # Test with invalid value
    with pytest.raises(ValidationError):
        not_field.validate(None)


# Generated at 2022-06-18 12:06:17.564849
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:20.880864
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)


# Generated at 2022-06-18 12:06:30.086835
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:06:31.023612
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:32.776611
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated == Any()


# Generated at 2022-06-18 12:06:34.258992
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:39.913424
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({"a":1}) == {"a":1}


# Generated at 2022-06-18 12:06:48.298853
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate(1.1) == 1.1
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2]) == [1, 2]
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1}) == {"a": 1}

# Generated at 2022-06-18 12:06:50.083529
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated == Any()


# Generated at 2022-06-18 12:06:50.898477
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:51.728198
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:55.222315
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:55.777604
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()

# Generated at 2022-06-18 12:06:56.643057
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:06:57.839227
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:06.230981
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}

# Generated at 2022-06-18 12:07:10.612321
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = Not(String())
    assert field.validate("hello") == "hello"
    try:
        field.validate(1)
    except ValidationError:
        pass
    else:
        assert False

# Generated at 2022-06-18 12:07:15.769887
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with a valid list of fields
    field = OneOf([Any()])
    assert field.one_of == [Any()]
    # Test with an invalid list of fields
    try:
        field = OneOf([])
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-18 12:07:16.717675
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:17.663524
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:27.869595
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (line 532)
    class TestNot(Not):
        def __init__(self, negated: Field, **kwargs: typing.Any) -> None:
            super().__init__(negated, **kwargs)

    test_not = TestNot(negated=Any())
    assert test_not.validate(value=None) == None
    assert test_not.validate(value=1) == 1
    assert test_not.validate(value=1.0) == 1.0
    assert test_not.validate(value="") == ""
    assert test_not.validate(value="1") == "1"
    assert test_not.validate(value=True) == True
    assert test_not.validate(value=False) == False
    assert test_not.validate

# Generated at 2022-06-18 12:07:38.715953
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:07:41.795844
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-18 12:07:50.858222
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Pattern

    class TestType(Type):
        field = AllOf([
            String(validators=[MinLength(2), MaxLength(5)]),
            String(validators=[Pattern(r"^[a-z]+$")])
        ])

    t = TestType()
    assert t.validate({"field": "abc"}) == {"field": "abc"}
    assert t.validate({"field": "abcdef"}) == {"field": "abcdef"}
    assert t.validate({"field": "abcdefg"}) == {"field": "abcdefg"}

# Generated at 2022-06-18 12:07:51.773099
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:53.290940
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    value = "test"
    assert field.validate(value) == value


# Generated at 2022-06-18 12:07:59.240441
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:08:00.949343
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:08:03.387259
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = Not(String())
    assert field.validate("test") == "test"
    try:
        field.validate(123)
    except ValidationError as e:
        assert e.code == "negated"
        assert e.message == "Must not match."
        assert e.path == []
        assert e.value == 123
    else:
        assert False, "Expected ValidationError"


# Generated at 2022-06-18 12:08:06.790374
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Field())
    assert field.validate(1) == 1
    try:
        field.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."


# Generated at 2022-06-18 12:08:07.959527
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:21.356862
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:08:27.573830
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()


# Generated at 2022-06-18 12:08:30.022449
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf(all_of=[String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:08:31.841255
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:08:33.020816
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:33.877462
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:08:34.914511
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:36.429778
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:38.169802
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:40.090498
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated == Any()


# Generated at 2022-06-18 12:09:05.194002
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:09:13.336886
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(0.0) == 0.0
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:09:23.278932
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:09:31.432688
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:09:34.274780
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field.if_clause is not None
    assert field.then_clause is not None
    assert field.else_clause is not None

# Generated at 2022-06-18 12:09:35.174727
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated = Field())

# Generated at 2022-06-18 12:09:35.902788
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:37.672387
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    field = Not(String())
    assert field.negated.__class__.__name__ == "String"

# Generated at 2022-06-18 12:09:42.467251
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Field())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(True) == True
    assert field.validate(False) == False


# Generated at 2022-06-18 12:09:49.919803
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(0.0) == 0.0
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:10:17.315417
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:10:18.481179
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:10:24.273466
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:10:29.294273
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:10:32.933132
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (line 582)
    # The following call to validate should return True
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    # The following call to validate should return False
    assert not_field.validate(None) == None


# Generated at 2022-06-18 12:10:36.647606
# Unit test for method validate of class Not
def test_Not_validate():
    test_field = Not(negated=Any())
    assert test_field.validate(1) == 1
    try:
        test_field.validate(None)
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:10:37.311452
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:10:38.012858
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:10:42.595794
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:10:43.861950
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Any())
    assert field.negated == Any()


# Generated at 2022-06-18 12:11:38.183512
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType

    not_string = Not(String())
    assert not_string.validate(1) == 1
    assert not_string.validate(None) == None
    assert not_string.validate(True) == True
    assert not_string.validate(False) == False
    assert not_string.validate(1.0) == 1.0
    assert not_string.validate(1.0) == 1.0
    assert not_string.validate(1.0) == 1.0
    assert not_string.validate(1.0) == 1.0
    assert not_string.validate(1.0) == 1.0

# Generated at 2022-06-18 12:11:38.945952
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:11:39.688720
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:11:41.761879
# Unit test for method validate of class Not
def test_Not_validate():
    # Arrange
    field = Not(Any())

    # Act
    result = field.validate(None)

    # Assert
    assert result is None

# Generated at 2022-06-18 12:11:42.552620
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:11:50.127810
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLengthValidator
    from typesystem.validators import MinLengthValidator
    from typesystem.validators import PatternValidator
    from typesystem.validators import RequiredValidator
    from typesystem.validators import UniqueValidator
    from typesystem.validators import Validator

    # Test case 1
    # Test with a valid value
    field = Not(String(max_length=5))
    value = "123456"
    try:
        field.validate(value)
    except ValidationError as e:
        assert False

    # Test case 2
    # Test with an invalid value
    field = Not(String(max_length=5))

# Generated at 2022-06-18 12:11:57.041727
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:12:01.260021
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    value = 1
    strict = False
    negated = Field()
    negated.errors = {"negated": "Must not match."}

    # Perform the test
    test_obj = Not(negated)
    result = test_obj.validate(value, strict)

    # assert the result
    assert result == value


# Generated at 2022-06-18 12:12:09.301552
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.1) == 1.1
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2]) == [1, 2]


# Generated at 2022-06-18 12:12:12.643379
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    not_ = Not(negated=Field())
    value = "value"
    strict = False
    # Perform the test
    result = not_.validate(value, strict)
    # Verify the results
    assert result is value