

# Generated at 2022-06-18 12:02:36.335515
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-18 12:02:37.450671
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:02:45.846818
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class IfThenElseTest(IfThenElse):
        def __init__(self, if_clause, then_clause, else_clause):
            super().__init__(if_clause, then_clause, else_clause)

    class IfClause(Field):
        def __init__(self, value):
            super().__init__()
            self.value = value

        def validate(self, value, strict=False):
            if value == self.value:
                return value
            raise self.validation_error("if_clause")

    class ThenClause(Field):
        def __init__(self, value):
            super().__init__()
            self.value = value

        def validate(self, value, strict=False):
            if value == self.value:
                return value
            raise self

# Generated at 2022-06-18 12:02:51.278854
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate("test") == "test"
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:02:56.842427
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:03:05.911881
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:03:06.862211
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:03:16.288509
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse
    from typesystem.fields import Any

    # Case 1: if_clause is valid
    if_clause = String(max_length=10)
    then_clause = Integer()
    else_clause = Any()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate("abc") == "abc"

    # Case 2: if_clause is not valid
    if_clause = String(max_length=10)
    then_clause = Integer()
    else_clause = Any()

# Generated at 2022-06-18 12:03:17.350510
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:03:26.315811
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case 1
    field = OneOf([Any()])
    value = "test"
    strict = False
    result = field.validate(value, strict)
    assert result == value

    # Test case 2
    field = OneOf([Any()])
    value = "test"
    strict = True
    result = field.validate(value, strict)
    assert result == value

    # Test case 3
    field = OneOf([Any()])
    value = "test"
    strict = False
    result = field.validate(value, strict)
    assert result == value

    # Test case 4
    field = OneOf([Any()])
    value = "test"
    strict = True
    result = field.validate(value, strict)
    assert result == value

    # Test case 5
    field = OneOf

# Generated at 2022-06-18 12:03:33.308376
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:03:34.356358
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:03:39.807699
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:03:41.418340
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated == Field()


# Generated at 2022-06-18 12:03:47.609632
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError

    field = IfThenElse(if_clause=Integer(), then_clause=String())

    assert field.validate(1) == "1"
    assert field.validate(2) == "2"

    try:
        field.validate(3.5)
    except ValidationError as e:
        assert e.code == "invalid_type"
    else:
        assert False

# Generated at 2022-06-18 12:03:48.586308
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:04:00.262202
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.types import Object
    from typesystem.types import String as StringType
    from typesystem.types import Union

    class Person(Object):
        name = String()
        age = Integer()

    class PersonWithAge(Person):
        age = Integer(minimum=18)

    class PersonWithName(Person):
        name = String(min_length=3)

    class PersonWithAgeOrName(Person):
        age = Integer(minimum=18)
        name = String(min_length=3)

    class PersonWithNameOrAge(Person):
        name = String(min_length=3)
        age = Integer(minimum=18)

    class PersonWithNameAndAge(Person):
        name = String(min_length=3)

# Generated at 2022-06-18 12:04:01.333251
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([Any()])


# Generated at 2022-06-18 12:04:07.446974
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(1)
    if_then_else.validate(1, True)
    if_then_else.validate(1, False)

# Generated at 2022-06-18 12:04:10.065590
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer, String

    field = AllOf([Integer(), String()])
    assert field.all_of == [Integer(), String()]


# Generated at 2022-06-18 12:04:24.797590
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
   

# Generated at 2022-06-18 12:04:29.340359
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with valid input
    field = OneOf([Any()])
    assert field.validate(1) == 1

    # Test with invalid input
    field = OneOf([NeverMatch()])
    try:
        field.validate(1)
    except Exception as e:
        assert str(e) == "Did not match any valid type."


# Generated at 2022-06-18 12:04:30.021576
# Unit test for constructor of class OneOf
def test_OneOf():
    pass


# Generated at 2022-06-18 12:04:36.276089
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("abc") == "abc"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({}) == {}
    assert not_field.validate([]) == []
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({"a":1, "b":2}) == {"a":1, "b":2}

# Generated at 2022-06-18 12:04:37.186228
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="test")


# Generated at 2022-06-18 12:04:47.056007
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength
    from typesystem.fields import IfThenElse
    from typesystem.types import Boolean
    from typesystem.types import String
    from typesystem.types import Integer
    from typesystem.types import Float
    from typesystem.types import Number
    from typesystem.types import Object
    from typesystem.types import Array
    from typesystem.types import Any
    from typesystem.types import Null
    from typesystem.fields import Field
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Number
    from typesystem.fields import Object
    from typesystem.fields import Array

# Generated at 2022-06-18 12:04:56.291270
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2]) == [1, 2]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}
    assert field.valid

# Generated at 2022-06-18 12:04:57.187441
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:07.429097
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    field = IfThenElse(Integer(minimum=0), Integer(maximum=10))
    assert field.validate(5) == 5
    assert field.validate(0) == 0
    assert field.validate(10) == 10
    try:
        field.validate(-1)
        assert False
    except ValidationError:
        pass
    try:
        field.validate(11)
        assert False
    except ValidationError:
        pass
    try:
        field.validate(5.5)
        assert False
    except ValidationError:
        pass
    try:
        field.validate('5')
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-18 12:05:09.237783
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:23.118053
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import Number
    from typesystem.types import String
    from typesystem.types import Boolean
    from typesystem.types import Object
    from typesystem.types import Array
    from typesystem.types import Any
    from typesystem.types import Null
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Enum
    from typesystem.types import Union
    from typesystem.types import Reference
    from typesystem.types import OneOf
    from typesystem.types import AllOf
    from typesystem.types import Not
    from typesystem.types import IfThenElse
    from typesystem.types import Tuple


# Generated at 2022-06-18 12:05:24.129857
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:05:28.317669
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with no arguments
    try:
        OneOf()
    except TypeError:
        assert True
    else:
        assert False

    # Test with valid arguments
    try:
        OneOf(one_of=[Any()])
    except TypeError:
        assert False
    else:
        assert True


# Generated at 2022-06-18 12:05:38.601603
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Type
    from typesystem.types.compound import Object

    class TestType(Type):
        field1 = Integer()
        field2 = String()

    class TestType2(Type):
        field1 = Integer()
        field2 = String()

    class TestType3(Type):
        field1 = Integer()
        field2 = String()

    class TestType4(Type):
        field1 = Integer()
        field2 = String()

    class TestType5(Type):
        field1 = Integer()
        field2 = String()

    class TestType6(Type):
        field1 = Integer()
        field2 = String()

    class TestType7(Type):
        field1 = Integer()
        field

# Generated at 2022-06-18 12:05:50.502683
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse

    field = IfThenElse(
        if_clause=Integer(),
        then_clause=String(),
        else_clause=Integer(),
    )

    assert field.validate(1) == "1"
    assert field.validate("1") == "1"
    assert field.validate("a") == "a"
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1

    try:
        field.validate("a", strict=True)
    except ValidationError as e:
        assert e.code == "invalid_type"
    else:
        assert False


# Generated at 2022-06-18 12:05:56.671750
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:05:58.664011
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Field(), then_clause=Field(), else_clause=Field())

# Generated at 2022-06-18 12:05:59.836973
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:01.684894
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    not_field.validate(None)

# Generated at 2022-06-18 12:06:05.402817
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test with valid input
    field = AllOf([Any()])
    assert field.all_of == [Any()]
    # Test with invalid input
    try:
        field = AllOf([Any()], allow_null=True)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-18 12:06:09.648506
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:10.435182
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:11.915560
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:21.541655
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:06:29.464486
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:06:31.364690
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    field = OneOf([String()])
    assert field.one_of == [String()]


# Generated at 2022-06-18 12:06:38.017323
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = IfThenElse(String(max_length=5), String(max_length=10))
    assert field.validate("12345") == "12345"
    assert field.validate("123456") == "123456"
    assert field.validate("12345678910") == "12345678910"
    try:
        field.validate("1234567891011")
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-18 12:06:46.523240
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    field = IfThenElse(Integer(), String())
    assert field.validate(1) == "1"
    assert field.validate("1") == "1"
    assert field.validate(1.0) == "1.0"
    assert field.validate(1.0) == "1.0"
    assert field.validate(None) == None
    assert field.validate(True) == "True"
    assert field.validate(False) == "False"
    assert field.validate(True) == "True"
    assert field.validate(False) == "False"
    assert field.validate(True) == "True"
    assert field.validate(False) == "False"
    assert field.validate(True) == "True"

# Generated at 2022-06-18 12:06:50.704378
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(1, strict=True) == 1

# Generated at 2022-06-18 12:07:00.540805
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength

    class TestType(Type):
        field = IfThenElse(
            if_clause=String(max_length=3),
            then_clause=String(min_length=3),
            else_clause=String(min_length=5),
        )

    type = TestType()
    type.validate({"field": "abc"})
    type.validate({"field": "abcdef"})
    try:
        type.validate({"field": "ab"})
    except ValidationError as e:
        assert e.error_code == "min_length"

# Generated at 2022-06-18 12:07:08.479698
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-18 12:07:09.455049
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:20.217975
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.validators import MaxLength

    if_clause = Integer(max_value=10)
    then_clause = String(validators=[MaxLength(10)])
    else_clause = String(validators=[MaxLength(20)])
    field = IfThenElse(if_clause, then_clause, else_clause)

    assert field.validate(5) == "5"
    assert field.validate(15) == "15"

    try:
        field.validate(15, strict=True)
    except ValidationError as e:
        assert e.code == "max_length"
    else:
        assert False, "ValidationError not raised"


# Generated at 2022-06-18 12:07:31.359179
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestIfThenElse(IfThenElse):
        def __init__(self, if_clause: Field, then_clause: Field = None, else_clause: Field = None, **kwargs: typing.Any) -> None:
            super().__init__(if_clause, then_clause, else_clause, **kwargs)
    class TestField(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
    class TestField2(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init__(**kwargs)
    class TestField3(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            super().__init

# Generated at 2022-06-18 12:07:40.880815
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import Number
    from typesystem.types import Boolean
    from typesystem.types import String
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Enum
    from typesystem.types import UUID
    from typesystem.types import Any
    from typesystem.types import Union
    from typesystem.types import OneOf
    from typesystem.types import AllOf
    from typesystem.types import Not
    from typesystem.types import IfThenElse
    from typesystem.types import NeverMatch
    from typesystem.fields import Field

# Generated at 2022-06-18 12:07:50.745598
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.types import String as String_type
    from typesystem.types import Union
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import Boolean
    from typesystem.types import DateTime
    from typesystem.types import Enum
    from typesystem.types import Float
    from typesystem.types import Integer as Integer_type
    from typesystem.types import Number
    from typesystem.types import Time
    from typesystem.types import Date
    from typesystem.types import UUID
    from typesystem.types import URL
    from typesystem.types import Any
    from typesystem.types import NeverMatch
    from typesystem.types import OneOf
    from typesystem.types import AllOf

# Generated at 2022-06-18 12:07:51.446610
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())

# Generated at 2022-06-18 12:07:56.566449
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    if_clause = Integer(minimum=0)
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == '1'
    assert if_then_else.validate(-1) == '-1'

# Generated at 2022-06-18 12:08:07.515216
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import Number
    from typesystem.types import String as StringType
    from typesystem.types import Union
    from typesystem.types import Boolean
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import Enum
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Email
    from typesystem.types import UUID
    from typesystem.types import URL
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import IPvAny
    from typesystem.types import MACAddress

# Generated at 2022-06-18 12:08:16.936771
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test with if_clause, then_clause and else_clause
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(None)
    # Test with if_clause and then_clause
    if_clause = Field()
    then_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause)
    if_then_else.validate(None)
    # Test with if_clause and else_clause
    if_clause = Field()
    else_clause = Field()

# Generated at 2022-06-18 12:08:40.856617
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.types import String
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("1") == "1"
    assert if_then_else.validate(None) == "None"

# Generated at 2022-06-18 12:08:44.136247
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    not_ = Not(negated=Field())
    value = None
    strict = False

    # Perform the test
    result = not_.validate(value, strict)

    # Check the result
    assert result is None


# Generated at 2022-06-18 12:08:45.011985
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:54.789658
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({'a': 1}) == {'a': 1}
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.2) == 1.2
    assert field.validate(1.3) == 1.

# Generated at 2022-06-18 12:09:03.880365
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:09:07.514808
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(1, strict=True) == 1

# Generated at 2022-06-18 12:09:08.785170
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:18.821678
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.2) == 1.2
    assert field.validate(1.3) == 1.3
    assert field.validate(1.4) == 1.4
    assert field.validate(1.5) == 1.5
    assert field.validate(1.6) == 1.6
    assert field.validate(1.7) == 1.

# Generated at 2022-06-18 12:09:26.698954
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    if_clause = String(validators=[MaxLength(5)])
    then_clause = String(validators=[MaxLength(10)])
    else_clause = String(validators=[MaxLength(15)])
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("12345") == "12345"
    assert if_then_else.validate("123456") == "123456"
    assert if_then_else.validate("123456789012345") == "123456789012345"

# Generated at 2022-06-18 12:09:32.483874
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String
    from typesystem.exceptions import ValidationError

    field = IfThenElse(
        if_clause=Integer(),
        then_clause=String(),
        else_clause=Integer(),
    )

    assert field.validate(1) == "1"
    assert field.validate("1") == 1

    try:
        field.validate(1.1)
    except ValidationError as e:
        assert e.messages == {"else_clause": ["Must be an integer."]}
    else:
        assert False, "Should have raised ValidationError"

# Generated at 2022-06-18 12:10:10.617115
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import String
    from typesystem.types import Number
    from typesystem.types import Boolean
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Enum
    from typesystem.types import UUID
    from typesystem.types import Any
    from typesystem.types import Union
    from typesystem.types import OneOf
    from typesystem.types import AllOf
    from typesystem.types import Not
    from typesystem.types import IfThenElse
    from typesystem.types import Literal
    from typesystem.types import Reference
    from typesystem.types import T

# Generated at 2022-06-18 12:10:20.004485
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    if_clause = String(max_length=2)
    then_clause = String(min_length=3)
    else_clause = String(min_length=1)
    field = IfThenElse(if_clause, then_clause, else_clause)
    try:
        field.validate("a")
    except ValidationError as e:
        assert e.code == "min_length"
    else:
        assert False
    try:
        field.validate("ab")
    except ValidationError as e:
        assert e.code == "min_length"
    else:
        assert False

# Generated at 2022-06-18 12:10:21.941675
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:10:23.338036
# Unit test for constructor of class Not
def test_Not():
    not_ = Not(negated=None)
    assert not_.negated is None


# Generated at 2022-06-18 12:10:24.206051
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:10:25.573925
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated == Field()

# Generated at 2022-06-18 12:10:34.910210
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = "test"
    strict = False
    expected = "test"
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected
    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = "test"
    strict = True
    expected = "test"
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected
    # Test case 3
    if_clause = Field()
    then_clause = Field()

# Generated at 2022-06-18 12:10:40.344445
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:10:41.061734
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:10:49.411427
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength
    from typesystem.fields import IfThenElse
    from typesystem.fields import AllOf
    from typesystem.fields import OneOf
    from typesystem.fields import Not
    from typesystem.fields import NeverMatch
    from typesystem.fields import Any

    # Test for method validate of class IfThenElse
    # Input:
    #     if_clause = AllOf(
    #         [
    #             OneOf(
    #                 [
    #                     Not(NeverMatch()),
    #                     String(validators=[MaxLength(10)]),
    #                 ]
    #             ),
    #             Integer(),
    #         ]
    #     )
    #