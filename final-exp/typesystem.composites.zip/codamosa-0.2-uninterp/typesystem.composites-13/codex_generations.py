

# Generated at 2022-06-18 12:02:38.656617
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    if_clause = String()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("a") == "a"
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:02:46.650669
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = OneOf([String(), String()])
    try:
        field.validate("a")
    except ValidationError as e:
        assert e.code == "multiple_matches"
    field = OneOf([String(), String(max_length=1)])
    try:
        field.validate("ab")
    except ValidationError as e:
        assert e.code == "no_match"
    field = OneOf([String(), String(max_length=1)])
    try:
        field.validate("a")
    except ValidationError as e:
        assert e.code == "multiple_matches"
    field = OneOf([String(), String(max_length=1)])

# Generated at 2022-06-18 12:02:53.408209
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({'a':1}) == {'a':1}


# Generated at 2022-06-18 12:02:55.019713
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:03:04.154570
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.validators import MaxLength
    from typesystem.exceptions import ValidationError
    import pytest

    # Test for constructor of class Not

# Generated at 2022-06-18 12:03:05.063998
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:03:06.321287
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="NeverMatch")


# Generated at 2022-06-18 12:03:07.939287
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:03:17.502328
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:03:26.581190
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.types import ErrorList
    from typesystem.exceptions import ValidationError
    from typesystem.fields import OneOf
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Duration
    from typesystem.fields import Email
    from typesystem.fields import Regex
    from typesystem.fields import URL
    from typesystem.fields import UUID
    from typesystem.fields import Choice
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf


# Generated at 2022-06-18 12:03:34.182515
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String

    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)

    assert field.validate(1) == "1"
    assert field.validate("1") == "1"

# Generated at 2022-06-18 12:03:42.800025
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.types import String
    from typesystem.exceptions import ValidationError

    field = IfThenElse(if_clause=Integer(), then_clause=String())

    assert field.validate(1) == "1"
    assert field.validate(1.0) == "1.0"
    assert field.validate("1") == "1"
    assert field.validate(True) == "True"

    with pytest.raises(ValidationError):
        field.validate(None)

    with pytest.raises(ValidationError):
        field.validate("abc")

    with pytest.raises(ValidationError):
        field.validate(False)



# Generated at 2022-06-18 12:03:52.624223
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MinLength
    from typesystem.fields import IfThenElse

    class TestType(Type):
        field = IfThenElse(
            if_clause=String(validators=[MinLength(5)]),
            then_clause=String(validators=[MinLength(10)]),
            else_clause=String(validators=[MinLength(20)]),
        )

    tt = TestType()
    tt.validate({"field": "12345"})
    tt.validate({"field": "12345678901"})
    tt.validate({"field": "12345678901234567890"})

# Generated at 2022-06-18 12:04:04.924391
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLengthValidator
    from typesystem.validators import MinLengthValidator
    from typesystem.validators import PatternValidator

    # Test with valid value
    field = Not(String(max_length=5, min_length=3, pattern="^[a-z]+$"))
    assert field.validate("abc") == "abc"

    # Test with invalid value
    try:
        field.validate("abcde")
    except ValidationError as e:
        assert e.code == "negated"
        assert e.message == "Must not match."
        assert e.field == field
        assert e.value == "abcde"
        assert e.context == {}

# Generated at 2022-06-18 12:04:10.478584
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("1") == "1"

# Generated at 2022-06-18 12:04:16.990552
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_data = [
        {
            "name": "one_of_1",
            "kwargs": {"one_of": [Field()]},
            "expected_results": {"value_validated": True},
        },
        {
            "name": "one_of_2",
            "kwargs": {"one_of": [Field()]},
            "expected_results": {"value_validated": True},
        },
    ]

    for test_case in one_of_data:
        one_of = OneOf(**test_case["kwargs"])
        # Perform the test
        result = one_of.validate(None)
        # Verify the result
        assert result is None



# Generated at 2022-06-18 12:04:17.925014
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:04:27.338393
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class A(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class B(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    class C(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    a = A()
    b = B()
    c = C()
    if_then_else = IfThenElse(a, b, c)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(0) == 0

# Generated at 2022-06-18 12:04:34.920680
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(), then_clause=Any())
    assert field.validate(1) == 1
    field = IfThenElse(if_clause=NeverMatch(), then_clause=Any())
    assert field.validate(1) == 1
    field = IfThenElse(if_clause=Any(), then_clause=NeverMatch())
    assert field.validate(1) == 1
    field = IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch())
    assert field.validate(1) == 1
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field.validate(1) == 1

# Generated at 2022-06-18 12:04:44.981816
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.json_schema import IfThenElse
    # Test case 1:
    # If the value is an integer, then it must be greater than 10
    # Else, it must be a string
    if_clause = Integer(minimum=10)
    then_clause = Integer(minimum=10)
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(11) == 11
    assert field.validate("hello") == "hello"
    try:
        field.validate(9)
    except ValidationError as e:
        assert e.code == "minimum"

# Generated at 2022-06-18 12:04:56.773411
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystemError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import ValidationError

    class MyType(Type):
        field = AllOf(
            [
                String(max_length=10),
                String(min_length=5),
            ]
        )

    type_system = TypeSystem()
    type_system.register_type(MyType)

    # Test valid value
    type_system.validate(MyType, {"field": "12345"})

    # Test invalid value
    with pytest.raises(TypeSystemValidationError) as exc_info:
        type_system.validate(MyType, {"field": "123"})

# Generated at 2022-06-18 12:05:06.915305
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:05:07.991291
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:05:10.904636
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    try:
        field.validate(None)
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-18 12:05:20.841789
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(0.0) == 0.0
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}



# Generated at 2022-06-18 12:05:30.490696
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:05:31.704396
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:41.901639
# Unit test for method validate of class Not

# Generated at 2022-06-18 12:05:43.347546
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:44.738469
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:59.151534
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:06:07.992293
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Any()).validate(None) == None
    assert Not(Any()).validate(0) == 0
    assert Not(Any()).validate(1) == 1
    assert Not(Any()).validate(True) == True
    assert Not(Any()).validate(False) == False
    assert Not(Any()).validate("") == ""
    assert Not(Any()).validate("a") == "a"
    assert Not(Any()).validate([]) == []
    assert Not(Any()).validate([0]) == [0]
    assert Not(Any()).validate({}) == {}
    assert Not(Any()).validate({'a': 0}) == {'a': 0}
    assert Not(Any()).validate(()) == ()

# Generated at 2022-06-18 12:06:10.361002
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(value=None)
    try:
        field.validate(value=1)
        assert False
    except:
        assert True


# Generated at 2022-06-18 12:06:11.186187
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)


# Generated at 2022-06-18 12:06:12.843301
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:22.413444
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:06:31.741841
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("abc") == "abc"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:06:40.872421
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:06:41.912618
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:46.196262
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_instance = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_instance.validate(value, strict)

    # Return the result
    return result


# Generated at 2022-06-18 12:06:59.239114
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with valid value
    field = OneOf([Any()])
    assert field.validate(1) == 1

    # Test with invalid value
    field = OneOf([NeverMatch()])
    with pytest.raises(ValidationError) as excinfo:
        field.validate(1)
    assert excinfo.value.code == "no_match"

    # Test with multiple matches
    field = OneOf([Any(), Any()])
    with pytest.raises(ValidationError) as excinfo:
        field.validate(1)
    assert excinfo.value.code == "multiple_matches"



# Generated at 2022-06-18 12:07:00.774327
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:10.419885
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Enum
    from typesystem.fields import Union
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse
    from typesystem.fields import Field
    from typesystem.fields import FieldError
    from typesystem.fields import ValidationError
    from typesystem.fields import Validation

# Generated at 2022-06-18 12:07:11.323373
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:22.440190
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate(True) == True
    assert field.validate("") == ""
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:07:33.778283
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(value=None) is None
    assert field.validate(value=1) == 1
    assert field.validate(value="a") == "a"
    assert field.validate(value=True) is True
    assert field.validate(value=False) is False
    assert field.validate(value=[]) == []
    assert field.validate(value={}) == {}
    assert field.validate(value=()) == ()
    assert field.validate(value=set()) == set()
    assert field.validate(value=frozenset()) == frozenset()
    assert field.validate(value=range(1)) == range(1)
    assert field.validate(value=bytearray()) == bytearray()

# Generated at 2022-06-18 12:07:42.362175
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0+1.0j) == 1.0+1.0j
    assert not_field.validate(()) == ()
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()


# Generated at 2022-06-18 12:07:46.059580
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:07:50.773421
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
   

# Generated at 2022-06-18 12:07:54.802889
# Unit test for constructor of class Not
def test_Not():
    # Test with valid input
    not_field = Not(Any())
    assert not_field.negated == Any()
    assert not_field.errors == {"negated": "Must not match."}
    # Test with invalid input
    try:
        Not(None)
    except AssertionError:
        assert True
    else:
        assert False


# Generated at 2022-06-18 12:08:10.916722
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:08:11.786629
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:12.821474
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:08:13.714504
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:23.565948
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:08:25.364755
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:26.177904
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:08:27.987185
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-18 12:08:30.097190
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:08:35.079910
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:08:48.033625
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:48.935051
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:55.879792
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate([1,2,3]) == [1,2,3]


# Generated at 2022-06-18 12:09:02.300755
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.1) == 1.1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:09:03.507266
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:09:10.339032
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
   

# Generated at 2022-06-18 12:09:11.141844
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:21.528195
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.1) == 1.1
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:09:22.002637
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:09:23.243704
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:10:13.451722
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer, String

    not_int = Not(Integer())
    assert not_int.validate("hello") == "hello"
    assert not_int.validate(1) == "Must not match."

    not_str = Not(String())
    assert not_str.validate(1) == 1
    assert not_str.validate("hello") == "Must not match."

# Generated at 2022-06-18 12:10:23.094599
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(value=None) == None
    assert field.validate(value=1) == 1
    assert field.validate(value=1.0) == 1.0
    assert field.validate(value="1") == "1"
    assert field.validate(value=True) == True
    assert field.validate(value=False) == False
    assert field.validate(value=[]) == []
    assert field.validate(value={}) == {}
    assert field.validate(value=()) == ()
    assert field.validate(value=set()) == set()
    assert field.validate(value=frozenset()) == frozenset()
    assert field.validate(value=range(0)) == range(0)
    assert field.valid

# Generated at 2022-06-18 12:10:24.513643
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated == Field()


# Generated at 2022-06-18 12:10:25.013537
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)

# Generated at 2022-06-18 12:10:27.425878
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    not_field = Not(String())
    assert not_field.negated.__class__.__name__ == 'String'


# Generated at 2022-06-18 12:10:30.892539
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(None)
    field.validate(1)
    field.validate(1.0)
    field.validate("")
    field.validate([])
    field.validate({})
    field.validate(True)
    field.validate(False)


# Generated at 2022-06-18 12:10:40.050924
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(1)
    field.validate(None)
    field.validate("")
    field.validate(True)
    field.validate(False)
    field.validate([])
    field.validate({})
    field.validate(())
    field.validate(set())
    field.validate(frozenset())
    field.validate(range(0))
    field.validate(b"")
    field.validate(bytearray())
    field.validate(memoryview(b""))
    field.validate(NotImplemented)
    field.validate(Ellipsis)
    field.validate(NotImplemented)
    field.validate(NotImplemented)

# Generated at 2022-06-18 12:10:41.331567
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:10:46.191393
# Unit test for method validate of class Not
def test_Not_validate():
    # Test with valid input
    negated = Field()
    not_field = Not(negated)
    assert not_field.validate(1) == 1
    # Test with invalid input
    negated = Field()
    not_field = Not(negated)
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == 'Must not match.'


# Generated at 2022-06-18 12:10:47.100001
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:11:44.260078
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    field = Not(negated=Any())
    value = None
    strict = False
    assert field.validate(value, strict) == value

    # Test case 2
    field = Not(negated=Any())
    value = None
    strict = True
    assert field.validate(value, strict) == value

    # Test case 3
    field = Not(negated=Any())
    value = 1
    strict = False
    assert field.validate(value, strict) == value

    # Test case 4
    field = Not(negated=Any())
    value = 1
    strict = True
    assert field.validate(value, strict) == value

    # Test case 5
    field = Not(negated=Any())
    value = "1"
    strict = False
    assert field.validate

# Generated at 2022-06-18 12:11:51.302016
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    negated = Field()
    field = Not(negated)
    value = 'test'
    strict = False
    expected = value
    actual = field.validate(value, strict)
    assert expected == actual

    # Test case 2
    negated = Field()
    field = Not(negated)
    value = 'test'
    strict = True
    expected = value
    actual = field.validate(value, strict)
    assert expected == actual

    # Test case 3
    negated = Field()
    field = Not(negated)
    value = 'test'
    strict = False
    expected = value
    actual = field.validate(value, strict)
    assert expected == actual

    # Test case 4
    negated = Field()
    field = Not(negated)

# Generated at 2022-06-18 12:11:58.005555
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:12:01.014167
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."

# Generated at 2022-06-18 12:12:06.401552
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:12:13.655618
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()


# Generated at 2022-06-18 12:12:21.521984
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:12:30.185694
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(range(1)) == range(1)
    assert not_field