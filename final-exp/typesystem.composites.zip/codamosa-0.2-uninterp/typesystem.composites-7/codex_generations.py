

# Generated at 2022-06-18 12:02:45.779046
# Unit test for method validate of class Not

# Generated at 2022-06-18 12:02:49.117469
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:02:58.708131
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer
    from typesystem import String
    from typesystem import Union
    from typesystem import Array
    from typesystem import Object

    # Test with Integer
    field = AllOf([Integer()])
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate("1") == "1"

    # Test with String
    field = AllOf([String()])
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate("1") == "1"

    # Test with Union
    field = AllOf([Union([Integer(), String()])])
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1

# Generated at 2022-06-18 12:03:07.593343
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:03:14.297196
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:03:20.556955
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    try:
        field.validate(1.0)
        assert False
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(1)
        assert False
    except Exception as e:
        assert str(e) == "Matched more than one type."


# Generated at 2022-06-18 12:03:23.953138
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:03:33.966995
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:03:38.579786
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    field = OneOf([String(), String()])
    assert field.validate("hello") == "hello"

    field = OneOf([String(), String()])
    assert field.validate(1) == 1

    field = OneOf([String(), String()])
    assert field.validate(None) == None



# Generated at 2022-06-18 12:03:39.611365
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:03:56.779371
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:04:08.342650
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(None)
    field.validate(1)
    field.validate("")
    field.validate(True)
    field.validate(False)
    field.validate([])
    field.validate({})
    field.validate([1, 2, 3])
    field.validate({"a": 1, "b": 2, "c": 3})
    field.validate({"a": 1, "b": 2, "c": 3})
    field.validate({"a": 1, "b": 2, "c": 3})
    field.validate({"a": 1, "b": 2, "c": 3})
    field.validate({"a": 1, "b": 2, "c": 3})
    field.validate

# Generated at 2022-06-18 12:04:15.455407
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:04:18.381414
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String

    field = AllOf([String(), String()])
    assert field.all_of == [String(), String()]


# Generated at 2022-06-18 12:04:20.051396
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    assert field.validate(None) == None


# Generated at 2022-06-18 12:04:27.300397
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    try:
        field.validate(1.0)
        assert False
    except FieldError as e:
        assert e.code == "no_match"
    try:
        field.validate(1, strict=True)
        assert False
    except FieldError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:04:28.169179
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:04:33.131666
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        String(),
        Integer(),
        Float(),
    ])
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("1") == "1"
    try:
        field.validate(True)
        assert False
    except ValidationError:
        pass
    try:
        field.validate([1, 2, 3])
        assert False
    except ValidationError:
        pass


# Generated at 2022-06-18 12:04:34.127555
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:04:35.003702
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:04:41.159831
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test for constructor of class NeverMatch
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:50.705260
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Duration
    from typesystem.fields import Decimal
    from typesystem.fields import Email
    from typesystem.fields import URL
    from typesystem.fields import UUID
    from typesystem.fields import IPv4
    from typesystem.fields import IPv6
    from typesystem.fields import MACAddress
    from typesystem.fields import Slug
    from typesystem.fields import Choice
    from typesystem.fields import Regex
    from typesystem.fields import File

# Generated at 2022-06-18 12:04:51.584366
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:04:52.952935
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:04:57.561574
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_instance = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_instance.validate(value, strict)

    # Return the result
    return result


# Generated at 2022-06-18 12:05:07.735829
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError

    field = IfThenElse(if_clause=Integer(), then_clause=String())
    assert field.validate(1) == "1"
    assert field.validate(2) == "2"
    assert field.validate(3) == "3"
    assert field.validate(4) == "4"
    assert field.validate(5) == "5"
    assert field.validate(6) == "6"
    assert field.validate(7) == "7"
    assert field.validate(8) == "8"
    assert field.validate(9) == "9"
    assert field.validate(10) == "10"

# Generated at 2022-06-18 12:05:15.498486
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = IfThenElse(String(max_length=3), String(min_length=3))
    assert field.validate("abc") == "abc"
    assert field.validate("ab") == "ab"
    assert field.validate("abcd") == "abcd"
    try:
        field.validate("a")
        assert False
    except ValidationError:
        pass
    try:
        field.validate("abcd")
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-18 12:05:16.423106
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch() is not None


# Generated at 2022-06-18 12:05:21.352241
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String

    field = IfThenElse(String(max_length=5), String(max_length=10))
    assert field.validate("12345") == "12345"
    assert field.validate("123456") == "123456"
    assert field.validate("1234567") == "1234567"

# Generated at 2022-06-18 12:05:22.294475
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:05:36.002387
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:05:42.687174
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:05:53.820296
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test for method validate(self, value, strict=False)
    # of class IfThenElse
    from typesystem.fields import Integer, String
    from typesystem.types import Object
    from typesystem.validators import MaxLength

    class Person(Object):
        name = String(validators=[MaxLength(10)])
        age = Integer()

    class PersonSchema(Object):
        name = String(validators=[MaxLength(10)])
        age = IfThenElse(
            if_clause=Integer(),
            then_clause=Integer(validators=[MaxLength(10)]),
            else_clause=Integer(validators=[MaxLength(5)]),
        )

    person = Person(name="John Doe", age=20)
    person_schema = PersonSchema(name="John Doe", age=20)
   

# Generated at 2022-06-18 12:05:54.943792
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:05.442708
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import Number
    from typesystem.types import String
    from typesystem.types import Union

    class IfThenElseTest(IfThenElse):
        def __init__(self, if_clause: Field, then_clause: Field = None, else_clause: Field = None, **kwargs: typing.Any) -> None:
            super().__init__(if_clause, then_clause, else_clause, **kwargs)

    # Test case 1
    if_clause = Integer()
    then_clause = String()
    else_clause = Number()

# Generated at 2022-06-18 12:06:13.753890
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:06:18.897005
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestField(Field):
        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value

    field = IfThenElse(
        if_clause=TestField(),
        then_clause=TestField(),
        else_clause=TestField(),
    )
    assert field.validate(1) == 1
    assert field.validate(None) == None

# Generated at 2022-06-18 12:06:19.804567
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:29.209862
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError

    class TestType(Type):
        field = IfThenElse(
            String(max_length=3),
            String(max_length=5),
            String(max_length=7)
        )

    type = TestType()
    type.validate({"field": "abc"})
    type.validate({"field": "abcde"})
    type.validate({"field": "abcdefg"})

    with pytest.raises(ValidationError):
        type.validate({"field": "abcdefgh"})
    with pytest.raises(ValidationError):
        type.validate({"field": "abcd"})

# Generated at 2022-06-18 12:06:30.771938
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:46.223481
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1}) == {"a": 1}

# Generated at 2022-06-18 12:06:51.017447
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("a") == "a"

# Generated at 2022-06-18 12:07:00.854354
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test 1
    field = OneOf([Any()])
    value = "test"
    strict = False
    expected = "test"
    actual = field.validate(value, strict)
    assert actual == expected

    # Test 2
    field = OneOf([Any()])
    value = "test"
    strict = True
    expected = "test"
    actual = field.validate(value, strict)
    assert actual == expected

    # Test 3
    field = OneOf([Any()])
    value = None
    strict = False
    expected = None
    actual = field.validate(value, strict)
    assert actual == expected

    # Test 4
    field = OneOf([Any()])
    value = None
    strict = True
    expected = None
    actual = field.validate(value, strict)
   

# Generated at 2022-06-18 12:07:01.788125
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    pass


# Generated at 2022-06-18 12:07:02.681145
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:12.532716
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate (line 7)
    field = OneOf([Any(), Any()])
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(1.0) == 1.0
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    field = OneOf([Any(), String()])
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(1.0) == 1.0
    assert field.valid

# Generated at 2022-06-18 12:07:15.401523
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([])
    assert one_of.validate(None) == None


# Generated at 2022-06-18 12:07:22.314994
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:07:33.626776
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        String(),
        Integer(),
    ])
    assert field.validate("foo") == "foo"
    assert field.validate(1) == 1
    try:
        field.validate(1.1)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(1, strict=True)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate("foo", strict=True)
        assert False
    except ValidationError as e:
        assert e.code

# Generated at 2022-06-18 12:07:39.325548
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [
        Field(name="one"),
        Field(name="two"),
        Field(name="three"),
    ]
    kwargs = {}
    one_of_field = OneOf(one_of, **kwargs)
    value = "one"
    strict = False

    # Perform the test
    result = one_of_field.validate(value, strict)

    # Check the result
    assert result is value



# Generated at 2022-06-18 12:07:44.738491
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:51.861364
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        Field(type="string"),
        Field(type="number"),
    ])
    field.validate("hello")
    field.validate(42)
    try:
        field.validate(True)
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(None)
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate({"a": "b"})
    except Exception as e:
        assert str(e) == "Did not match any valid type."


# Generated at 2022-06-18 12:07:52.643175
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:54.094620
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:04.956586
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:08:14.269920
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import String

    field = IfThenElse(String(), Integer())
    assert field.validate("1") == 1
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate(["a", 1]) == ["a", 1]
    assert field.validate({"a": "b"}) == {"a": "b"}

# Generated at 2022-06-18 12:08:15.566535
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:08:17.537438
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:08:19.125739
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:08:21.202378
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated == Any()

# Generated at 2022-06-18 12:08:29.426318
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:08:38.215205
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String, Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType, IntegerType
    from typesystem.validators import MinLength, MaxLength, MinValue, MaxValue
    from typesystem.fields import IfThenElse

    if_clause = String(validators=[MinLength(5), MaxLength(10)])
    then_clause = Integer(validators=[MinValue(5), MaxValue(10)])
    else_clause = String(validators=[MinLength(5), MaxLength(10)])
    field = IfThenElse(if_clause, then_clause, else_clause)

    # test if_clause

# Generated at 2022-06-18 12:08:44.874444
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    if_clause = String(max_length=3)
    then_clause = String(max_length=5)
    else_clause = String(max_length=7)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("abc") == "abc"
    assert if_then_else.validate("abcd") == "abcd"
    assert if_then_else.validate("abcde") == "abcde"
    assert if_then_else.validate("abcdef") == "abcdef"
    assert if_then_else.validate("abcdefg") == "abcdefg"

# Generated at 2022-06-18 12:08:46.499232
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(all_of=[])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:08:56.441911
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:08:59.286890
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (line 572)
    field = Not(String())
    assert field.validate("foo") == "foo"
    with pytest.raises(ValidationError):
        field.validate(1)


# Generated at 2022-06-18 12:09:01.413210
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:08.880550
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError

    field = IfThenElse(Integer(minimum=0), Integer(maximum=10))
    assert field.validate(5) == 5
    assert field.validate(0) == 0
    assert field.validate(10) == 10
    with pytest.raises(ValidationError):
        field.validate(-1)
    with pytest.raises(ValidationError):
        field.validate(11)

    field = IfThenElse(Integer(minimum=0), Integer(maximum=10), Integer(minimum=0))
    assert field.validate(5) == 5
    assert field.validate(0) == 0
    assert field.validate(10) == 10
    assert field.validate(-1) == -1
    assert field

# Generated at 2022-06-18 12:09:09.954003
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:09:20.084439
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Boolean
    from typesystem.types import Array
    from typesystem.types import Object

    # Test case 1
    if_clause = String(max_length=10)
    then_clause = Integer()
    else_clause = StringType()
    value = "hello"
    strict = False
    expected_result = "hello"
    actual_result = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual_result == expected_result

    # Test case 2
    if_clause = String(max_length=10)
    then_clause = Integer()
    else_clause = StringType()

# Generated at 2022-06-18 12:09:36.323290
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:39.992929
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import Integer
    integer = Integer()
    not_integer = Not(integer)
    assert not_integer.validate("a") == "a"
    try:
        not_integer.validate(1)
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:09:40.766733
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:48.535571
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:09:49.329789
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:09:57.900274
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import Float
    from typesystem.types import Boolean
    from typesystem.types import String
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Enum
    from typesystem.types import UUID
    from typesystem.types import URL
    from typesystem.types import Email
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import IPvAny
    from typesystem.types import MAC
    from typesystem.types import JSON
    from typesystem.types import Binary
   

# Generated at 2022-06-18 12:10:03.099909
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:10:11.634669
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Enum
    from typesystem.fields import UUID
    from typesystem.fields import URL
    from typesystem.fields import Email
    from typesystem.fields import Number
    from typesystem.fields import Any
    from typesystem.fields import Union
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
   

# Generated at 2022-06-18 12:10:17.136573
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:10:17.966856
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:11:25.238727
# Unit test for method validate of class Not
def test_Not_validate():
    test_field = Not(negated=Any())
    assert test_field.validate(value=None) == None
    assert test_field.validate(value=1) == 1
    assert test_field.validate(value=1.0) == 1.0
    assert test_field.validate(value="1") == "1"
    assert test_field.validate(value=True) == True
    assert test_field.validate(value=False) == False
    assert test_field.validate(value={"a": 1}) == {"a": 1}
    assert test_field.validate(value=[1, 2, 3]) == [1, 2, 3]
    assert test_field.validate(value={"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:11:27.193745
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:11:34.580837
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0+1.0j) == 1.0+1.0j
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(set()) == set()
    assert field.validate(frozenset()) == frozenset()
    assert field.validate(range(0)) == range(0)
    assert field.validate(bytearray()) == bytearray()
   

# Generated at 2022-06-18 12:11:39.284304
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:11:47.493833
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(()) == ()
    assert field.validate(set()) == set()
    assert field.validate(frozenset()) == frozenset()
    assert field.validate(bytearray()) == bytearray()
    assert field.validate(memoryview()) == memoryview()

# Generated at 2022-06-18 12:11:54.592435
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:11:57.318450
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test with no arguments
    try:
        NeverMatch()
    except AssertionError:
        pass
    # Test with invalid arguments
    try:
        NeverMatch(allow_null=True)
    except AssertionError:
        pass


# Generated at 2022-06-18 12:12:06.068131
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:12:08.541213
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="NeverMatch").name == "NeverMatch"


# Generated at 2022-06-18 12:12:15.947169
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
