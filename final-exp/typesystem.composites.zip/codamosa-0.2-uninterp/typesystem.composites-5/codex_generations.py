

# Generated at 2022-06-18 12:02:35.114700
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Boolean
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import Union
    from typesystem.types import Enum
    from typesystem.types import Any
    from typesystem.types import NeverMatch
    from typesystem.types import OneOf
    from typesystem.types import AllOf
    from typesystem.types import Not
    from typesystem.types import IfThenElse
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import UUID
    from typesystem.types import URL

# Generated at 2022-06-18 12:02:44.035330
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.types import Float
    from typesystem.types import Boolean
    from typesystem.types import String
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Enum
    from typesystem.types import UUID
    from typesystem.types import Any
    from typesystem.types import Union
    from typesystem.types import OneOf
    from typesystem.types import AllOf
    from typesystem.types import Not
    from typesystem.types import IfThenElse
    from typesystem.types import NeverMatch
    from typesystem.types import AnyOf
    from typesystem.types import AllOf


# Generated at 2022-06-18 12:02:49.677226
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate([1,2,3]) == [1,2,3]


# Generated at 2022-06-18 12:02:50.884574
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:02:51.913843
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:02:53.116836
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:02:58.790245
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:03:07.679233
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer

    # Test for if_clause is None
    if_clause = None
    then_clause = String()
    else_clause = Integer()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    with pytest.raises(ValidationError):
        if_then_else.validate(1)

    # Test for then_clause is None
    if_clause = String()
    then_clause = None
    else_clause = Integer()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

# Generated at 2022-06-18 12:03:12.681106
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate (1 of 2)
    # Tests simple case.
    field = OneOf([String(), Integer()])
    assert field.validate(1) == 1
    # Test for method validate (2 of 2)
    # Tests simple case.
    field = OneOf([String(), Integer()])
    assert field.validate("1") == "1"


# Generated at 2022-06-18 12:03:21.702882
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(()) == ()
    assert field.validate(set()) == set()
    assert field.validate(frozenset()) == frozenset()
    assert field.validate(bytearray()) == bytearray()
    assert field.validate(memoryview(b"")) == memoryview(b"")
    assert field.validate(range(0)) == range(0)

# Generated at 2022-06-18 12:03:26.193374
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-18 12:03:27.174127
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([Any()])


# Generated at 2022-06-18 12:03:28.074418
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:03:38.198171
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(()) == ()
    assert field.validate(object()) == object()
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0+1.0j) == 1.0+1.0j
    assert field.validate(1.0+1.0j) == 1.0+1.0j

# Generated at 2022-06-18 12:03:40.043477
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:03:41.593214
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:03:43.337418
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated == Any()


# Generated at 2022-06-18 12:03:49.649201
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer

    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("1") == "1"
    assert if_then_else.validate(None) == ""

# Generated at 2022-06-18 12:03:58.071616
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    field = IfThenElse(Integer(minimum=0), Integer(maximum=10))
    assert field.validate(5) == 5
    assert field.validate(-1) == -1
    assert field.validate(11) == 11
    try:
        field.validate(0)
        assert False
    except ValidationError:
        assert True
    try:
        field.validate(10)
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-18 12:04:01.582584
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=Field(type="string"),
        then_clause=Field(type="string"),
        else_clause=Field(type="string"),
    )
    field.validate("test")

# Generated at 2022-06-18 12:04:13.810000
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Union

    if_clause = String(pattern="^[0-9]*$")
    then_clause = Integer()
    else_clause = StringType()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("123") == 123
    assert if_then_else.validate("abc") == "abc"

    if_clause = String(pattern="^[0-9]*$")
    then_clause = Integer()
    else_clause = Union([StringType(), Integer()])

# Generated at 2022-06-18 12:04:15.045598
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:04:25.975426
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate(True) is True
    assert field.validate("") == ""
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:04:33.843866
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}
    assert not_field.validate({'a': 1}) == {'a': 1}
    assert not_field.validate(set()) == set()
    assert not_field.validate({1}) == {1}
    assert not_

# Generated at 2022-06-18 12:04:35.730334
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())

# Generated at 2022-06-18 12:04:39.005588
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False

    # Perform the test
    result = OneOf(one_of).validate(value, strict)

    # Verify the results
    assert result is None


# Generated at 2022-06-18 12:04:39.951047
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:04:49.935779
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0+1.0j) == 1.0+1.0j
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate((1,2,3)) == (1,2,3)
    assert not_field.validate({1,2,3}) == {1,2,3}

# Generated at 2022-06-18 12:04:54.378486
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with a valid value
    field = OneOf([Any()])
    assert field.validate(1) == 1
    # Test with an invalid value
    field = OneOf([Any()])
    try:
        field.validate(None)
    except Exception as e:
        assert str(e) == 'Did not match any valid type.'


# Generated at 2022-06-18 12:05:00.997757
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        Int(),
        String(),
    ])
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    with pytest.raises(ValidationError) as excinfo:
        field.validate(None)
    assert excinfo.value.code == "no_match"
    with pytest.raises(ValidationError) as excinfo:
        field.validate(1.0)
    assert excinfo.value.code == "multiple_matches"


# Generated at 2022-06-18 12:05:05.146078
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:05:15.402886
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=NeverMatch(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=NeverMatch()).validate(1) == 1

# Generated at 2022-06-18 12:05:17.257033
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:05:27.069964
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse

    field = IfThenElse(
        if_clause=Integer(),
        then_clause=String(),
        else_clause=Integer()
    )

    assert field.validate(1) == '1'
    assert field.validate(2) == '2'
    assert field.validate(3) == '3'
    assert field.validate(4) == '4'
    assert field.validate(5) == '5'

    try:
        field.validate('a')
    except ValidationError:
        pass
    else:
        raise AssertionError('ValidationError not raised')


# Generated at 2022-06-18 12:05:32.401210
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(value=None)
    field.validate(value=1)
    field.validate(value="a")
    field.validate(value=True)
    field.validate(value=[])
    field.validate(value={})
    field.validate(value=())


# Generated at 2022-06-18 12:05:37.563535
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("a") == "a"
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:05:41.436675
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:05:53.078144
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:06:03.975424
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import ErrorList
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength
    from typesystem.fields import IfThenElse
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Boolean

    field = IfThenElse(
        if_clause=Boolean(),
        then_clause=String(validators=[MaxLength(5)]),
        else_clause=Integer(),
    )
    assert field.validate(True, strict=True) == True
    assert field.validate(False, strict=True) == False
    assert field.validate(True, strict=True) == True
    assert field.validate(False, strict=True) == False

# Generated at 2022-06-18 12:06:05.341013
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:06:09.127886
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None

# Generated at 2022-06-18 12:06:09.950280
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())


# Generated at 2022-06-18 12:06:15.406041
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:06:21.461596
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:06:22.289401
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:06:23.501406
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:33.291091
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Schema
    from typesystem.types import Object
    from typesystem.types import Array

    class AllOfTest(Schema):
        all_of = AllOf([String(), Array()])

    assert AllOfTest().validate(["hello"]) == ["hello"]
    assert AllOfTest().validate("hello") == "hello"
    assert AllOfTest().validate({"hello": "world"}) == {"hello": "world"}
    assert AllOfTest().validate({"hello": ["world"]}) == {"hello": ["world"]}
    assert AllOfTest().validate({"hello": "world", "foo": "bar"}) == {"hello": "world", "foo": "bar"}

# Generated at 2022-06-18 12:06:34.210990
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:35.092660
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:43.633049
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import Schema

    class MyType(Type):
        field = AllOf([String(max_length=10), String(min_length=5)])

    class MyTypeSystem(TypeSystem):
        type_defs = [MyType]

    class MySchema(Schema):
        types = MyTypeSystem

    schema = MySchema()
    assert schema.validate({"field": "12345"}) == {"field": "12345"}
    assert schema.validate({"field": "12345678901"}) == {"field": "12345678901"}
    assert schema.validate({"field": "1234"}) == {"field": "1234"}
    assert schema.valid

# Generated at 2022-06-18 12:06:48.940392
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:50.128196
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:51.614744
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:06:52.386843
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:54.504266
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:01.216544
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    value = 1
    strict = False
    negated = Field()
    negated.errors = {"negated": "Must not match."}
    negated.validate_or_error = MagicMock(return_value=(1, None))
    # Perform the test
    not_field = Not(negated)
    not_field.validate(value, strict)
    # Assert the result
    negated.validate_or_error.assert_called_with(value, strict)


# Generated at 2022-06-18 12:07:02.787382
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:07:04.480470
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:05.018119
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()

# Generated at 2022-06-18 12:07:09.064514
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."


# Generated at 2022-06-18 12:07:13.485957
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)


# Generated at 2022-06-18 12:07:15.531064
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:07:25.595872
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:07:32.880559
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:07:33.936202
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:35.346152
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:07:42.607383
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

    if_then_else = IfThenElse(if_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == Any()
    assert if_then_else.else_clause == Any()

# Generated at 2022-06-18 12:07:46.545782
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = AllOf([String(), String()])
    field.validate("hello")
    try:
        field.validate(1)
    except ValidationError:
        assert True
    else:
        assert False


# Generated at 2022-06-18 12:07:49.731039
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_field = OneOf([])
    value = None
    strict = False
    # Perform the test
    result = one_of_field.validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:07:50.588174
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:02.512478
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:12.208302
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:08:17.797490
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}

# Generated at 2022-06-18 12:08:27.702435
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import String

    not_string = Not(String())
    try:
        not_string.validate(1)
    except ValidationError:
        pass
    else:
        assert False, "Should raise ValidationError"

    not_string = Not(String())
    try:
        not_string.validate("1")
    except ValidationError:
        assert False, "Should not raise ValidationError"
    else:
        pass

    not_integer = Not(Integer())
    try:
        not_integer.validate("1")
    except ValidationError:
        assert False, "Should not raise ValidationError"
    else:
        pass

    not_integer = Not(Integer())

# Generated at 2022-06-18 12:08:29.082120
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[])


# Generated at 2022-06-18 12:08:37.897514
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MinLength

    field = Not(String(min_length=3))
    assert field.negated.type == StringType
    assert field.negated.validators[0].min_length == 3

    try:
        field.validate("ab")
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False

    try:
        field.validate("abc")
    except ValidationError as e:
        assert False
    else:
        assert True

    field = Not(String(min_length=3, validators=[MinLength(4)]))
    assert field.negated.type == StringType
    assert field

# Generated at 2022-06-18 12:08:39.844120
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:08:41.266056
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:42.079279
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:43.976963
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:09:08.396074
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import Schema
    from typesystem.types import SchemaMeta
    from typesystem.types import SchemaOptions
    from typesystem.types import SchemaType
    from typesystem.types import SchemaTypeMeta
    from typesystem.types import SchemaTypeOptions
    from typesystem.types import SchemaTypeType
    from typesystem.types import SchemaTypeTypeMeta
    from typesystem.types import SchemaTypeTypeOptions
    from typesystem.types import SchemaTypeTypeType
    from typesystem.types import SchemaTypeTypeTypeMeta
    from typesystem.types import SchemaTypeTypeTypeOptions
    from typesystem.types import SchemaTypeTypeTypeType
    from typesystem.types import SchemaTypeType

# Generated at 2022-06-18 12:09:09.442132
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:19.513882
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import Schema
    from typesystem.types import Object
    from typesystem.types import Array
    from typesystem.types import Integer
    from typesystem.types import Boolean
    from typesystem.types import Number
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Enum
    from typesystem.types import Any
    from typesystem.types import Union
    from typesystem.types import Reference
    from typesystem.types import Link
    from typesystem.types import Email
    from typesystem.types import UUID
    from typesystem.types import URL
    from typesystem.types import IPv4
    from typesystem.types import IPv6

# Generated at 2022-06-18 12:09:23.765736
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_instance = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_instance.validate(value, strict)

    # Return the result
    return result


# Generated at 2022-06-18 12:09:25.107883
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:09:30.558920
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    try:
        field.validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(1.0)
        assert False
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:09:31.853923
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:32.545861
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:09:32.982923
# Unit test for constructor of class Not
def test_Not():
    assert Not(Any())

# Generated at 2022-06-18 12:09:34.510384
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:11:01.327682
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate("a") == "a"
    assert field.validate(1) == 1
    assert field.validate(True) == True
    assert field.validate(None) == None
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": [1, 2, 3]}) == {"a": [1, 2, 3]}
    assert field.validate({"a": {"b": [1, 2, 3]}}) == {"a": {"b": [1, 2, 3]}}

# Generated at 2022-06-18 12:11:10.027973
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(None)
    not_field.validate(1)
    not_field.validate(1.0)
    not_field.validate("1")
    not_field.validate(True)
    not_field.validate(False)
    not_field.validate([])
    not_field.validate({})
    not_field.validate(())
    not_field.validate(set())
    not_field.validate(frozenset())
    not_field.validate(bytearray())
    not_field.validate(memoryview(b""))
    not_field.validate(range(0))
    not_field.validate(iter([]))
    not_field.validate(object())


# Generated at 2022-06-18 12:11:17.644744
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()


# Generated at 2022-06-18 12:11:21.109669
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    not_field = Not(negated=Any())
    value = None
    strict = False
    # Perform the test
    result = not_field.validate(value, strict)
    # Verify the results
    assert result is None


# Generated at 2022-06-18 12:11:25.240164
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = Not(String())
    field.validate("abc")
    try:
        field.validate(123)
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False, "Should have raised ValidationError"



# Generated at 2022-06-18 12:11:30.403938
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:11:33.202989
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == 'Must not match.'


# Generated at 2022-06-18 12:11:40.840318
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(value=None)
    field.validate(value=True)
    field.validate(value=False)
    field.validate(value=0)
    field.validate(value=1)
    field.validate(value=0.0)
    field.validate(value=1.0)
    field.validate(value="")
    field.validate(value="a")
    field.validate(value=[])
    field.validate(value=[1])
    field.validate(value={})
    field.validate(value={"a": 1})
    field.validate(value={"a": 1, "b": 2})

# Generated at 2022-06-18 12:11:48.844908
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(0.0) == 0.0
    assert field.validate(0) == 0
    assert field.validate(0.0) == 0.0
    assert field.validate(0.0) == 0.0
    assert field.validate(0.0) == 0.0
    assert field.validate(0.0) == 0.0
    assert field.validate(0.0) == 0.0
    assert field.validate(0.0) == 0.0
    assert field.valid

# Generated at 2022-06-18 12:11:51.574317
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate("test") == "test"
    try:
        field.validate(None)
        assert False
    except:
        assert True
