

# Generated at 2022-06-18 12:02:33.405901
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate([1]) == [1]


# Generated at 2022-06-18 12:02:39.509025
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import String
    try:
        IfThenElse(Integer(), String()).validate(1)
    except ValidationError:
        pass
    else:
        assert False, "Should raise ValidationError"
    try:
        IfThenElse(Integer(), String()).validate("a")
    except ValidationError:
        assert False, "Should not raise ValidationError"
    else:
        pass

# Generated at 2022-06-18 12:02:47.203172
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:02:51.525532
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    assert field.validate("test") == "test"
    assert field.validate(1) == 1
    try:
        field.validate(1.1)
        assert False
    except:
        assert True
    try:
        field.validate(None)
        assert False
    except:
        assert True


# Generated at 2022-06-18 12:02:55.298336
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_field = OneOf([])
    value = None
    strict = False

    # Perform the test
    result = one_of_field.validate(value, strict)

    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:03:01.721751
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:03:10.734513
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    field.validate(value=None, strict=False)
    field.validate(value=None, strict=True)
    field.validate(value=1, strict=False)
    field.validate(value=1, strict=True)
    field.validate(value="1", strict=False)
    field.validate(value="1", strict=True)
    field.validate(value=True, strict=False)
    field.validate(value=True, strict=True)
    field.validate(value=False, strict=False)
    field.validate(value=False, strict=True)
    field.validate(value=[], strict=False)

# Generated at 2022-06-18 12:03:14.519120
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    not_ = Not(negated=None)
    value = None
    strict = None
    # Perform the test
    result = not_.validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:03:17.235629
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=Field(),
        then_clause=Field(),
        else_clause=Field(),
    )
    field.validate(value=None)

# Generated at 2022-06-18 12:03:22.734702
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:03:35.658926
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate(1.1) == 1.1
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0 + 1.0j) == 1.0 + 1.0j
    assert field.validate(1.0 + 1.0j) == 1.0 + 1.0j
    assert field.validate(1.0 + 1.0j) == 1.0 + 1.

# Generated at 2022-06-18 12:03:37.050019
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[])


# Generated at 2022-06-18 12:03:42.674169
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:03:43.664909
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:03:45.025754
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:03:48.936901
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1


# Generated at 2022-06-18 12:04:00.779287
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestIfThenElse(IfThenElse):
        def __init__(self, if_clause: Field, then_clause: Field = None, else_clause: Field = None, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(if_clause, then_clause, else_clause, **kwargs)

    class TestField(Field):
        def __init__(self, **kwargs: typing.Any) -> None:
            assert "allow_null" not in kwargs
            super().__init__(**kwargs)

        def validate(self, value: typing.Any, strict: bool = False) -> typing.Any:
            return value


# Generated at 2022-06-18 12:04:11.587417
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    negated = Field()
    negated.errors = {"negated": "Must not match."}
    negated.validate_or_error = lambda value, strict: (value, None)
    field = Not(negated)
    value = "test"
    strict = False
    expected = value
    actual = field.validate(value, strict)
    assert actual == expected
    # Test case 2
    negated = Field()
    negated.errors = {"negated": "Must not match."}
    negated.validate_or_error = lambda value, strict: (value, None)
    field = Not(negated)
    value = "test"
    strict = False
    expected = value
    actual = field.validate(value, strict)
    assert actual == expected


# Generated at 2022-06-18 12:04:12.601504
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:04:18.247488
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:04:30.117331
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:04:31.020459
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())

# Generated at 2022-06-18 12:04:39.993890
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.exceptions import ValidationError

    class MyType(Type):
        field = IfThenElse(
            String(max_length=3),
            String(max_length=5),
            String(max_length=10),
        )

    type = MyType()
    type.validate({"field": "abc"})
    type.validate({"field": "abcde"})
    type.validate({"field": "abcdefghij"})
    try:
        type.validate({"field": "abcdefghijk"})
    except ValidationError as e:
        assert e.error_code == "max_length"

# Generated at 2022-06-18 12:04:41.332968
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:04:50.835396
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:05:00.168446
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(False) == False
    assert not_field.validate(True) == True
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate({"a":1, "b":2}) == {"a":1, "b":2}

# Generated at 2022-06-18 12:05:03.870468
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:05:05.094915
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:05:15.356315
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Pattern
    from typesystem.validators import Validator

    # Test 1:
    # Test AllOf constructor with valid parameters
    # Expected:
    #   AllOf object is created
    #   AllOf object has correct fields
    def test_AllOf_1():
        all_of = AllOf([String(max_length=10), String(min_length=5)])
        assert isinstance(all_of, AllOf)
        assert isinstance(all_of.all_of, list)
        assert len(all_of.all_of) == 2
        assert isinstance(all_of.all_of[0], String)

# Generated at 2022-06-18 12:05:16.300598
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:19.354559
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:20.393101
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:29.139433
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}
    assert not_field.validate({'a': 1}) == {'a': 1}
    assert not_field.validate(1.0) == 1.0


# Generated at 2022-06-18 12:05:34.895212
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestClass(IfThenElse):
        def __init__(self, if_clause, then_clause, else_clause):
            super().__init__(if_clause, then_clause, else_clause)
    test_class = TestClass(1, 2, 3)
    assert test_class.validate(1) == 2
    assert test_class.validate(2) == 3

# Generated at 2022-06-18 12:05:35.916167
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:05:36.909455
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())

# Generated at 2022-06-18 12:05:37.812379
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:05:38.422402
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-18 12:05:50.300992
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(range(1)) == range(1)
    assert not_field

# Generated at 2022-06-18 12:05:52.193470
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:05:57.023156
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:06.736671
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import String

    # Test that if_clause is not None
    if_clause = String()
    then_clause = Integer()
    else_clause = Integer()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("test") == "test"

    # Test that then_clause is not None
    if_clause = String()
    then_clause = None
    else_clause = Integer()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("test") == "test"

    #

# Generated at 2022-06-18 12:06:08.161754
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:17.347823
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Pattern
    from typesystem.validators import Regex
    from typesystem.validators import Required
    from typesystem.validators import Unique
    from typesystem.validators import Validator
    from typesystem.validators import ValidatorList
    from typesystem.validators import ValidatorListType
    from typesystem.validators import ValidatorType
    from typesystem.validators import ValidatorTypeList
    from typesystem.validators import ValidatorTypeListType
    from typesystem.validators import ValidatorTypeType
    from typesystem.validators import ValidatorTypeTypeList

# Generated at 2022-06-18 12:06:22.825989
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:06:32.097199
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    if_clause = String(max_length=3)
    then_clause = String(max_length=5)
    else_clause = String(max_length=7)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("123") == "123"
    assert if_then_else.validate("1234") == "1234"
    assert if_then_else.validate("12345") == "12345"
    assert if_then_else.validate("123456") == "123456"
    assert if_then_else.validate("1234567") == "1234567"

# Generated at 2022-06-18 12:06:33.522410
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:42.215948
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1)

# Generated at 2022-06-18 12:06:50.785548
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

    if_then_else = IfThenElse(if_clause, then_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == Any()


# Generated at 2022-06-18 12:06:51.615057
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:07:00.373418
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:01.216893
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:02.126834
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:02.994197
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:07:12.871183
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test 1
    all_of = [Field()]
    assert AllOf(all_of).all_of == all_of

    # Test 2
    all_of = [Field()]
    assert AllOf(all_of, name="name").name == "name"

    # Test 3
    all_of = [Field()]
    assert AllOf(all_of, description="description").description == "description"

    # Test 4
    all_of = [Field()]
    assert AllOf(all_of, required=True).required == True

    # Test 5
    all_of = [Field()]
    assert AllOf(all_of, default="default").default == "default"

    # Test 6
    all_of = [Field()]
    assert AllOf(all_of, allow_null=True).allow_null

# Generated at 2022-06-18 12:07:23.959680
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystemError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError

# Generated at 2022-06-18 12:07:30.928011
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:07:32.490633
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:33.724393
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())

# Generated at 2022-06-18 12:07:34.777887
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:07:51.413723
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:59.093374
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
    strict = False
    expected = 1
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = 1
    strict = True
    expected = 1
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected

# Generated at 2022-06-18 12:08:10.513976
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Boolean
    from typesystem.types import Object
    from typesystem.types import Array
    from typesystem.types import Union
    from typesystem.types import Enum
    from typesystem.types import Any
    from typesystem.types import Null
    from typesystem.types import Number
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Duration
    from typesystem.types import Email
    from typesystem.types import UUID
    from typesystem.types import URI
    from typesystem.types import IPv4Address
    from typesystem.types import IPv

# Generated at 2022-06-18 12:08:11.418268
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:21.157477
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate({"a":1}) == {"a":1}
    assert not_field.validate({"a":1}) == {"a":1}

# Generated at 2022-06-18 12:08:22.172000
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:08:31.441254
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field

# Generated at 2022-06-18 12:08:32.327998
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:40.856272
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:08:41.686905
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:09:17.543343
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(1)
    try:
        not_field.validate(None)
        assert False
    except:
        assert True


# Generated at 2022-06-18 12:09:21.528288
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    # Test for constructor of class NeverMatch
    try:
        NeverMatch(allow_null=True)
    except AssertionError:
        pass
    else:
        raise Exception("Expected AssertionError")


# Generated at 2022-06-18 12:09:22.412535
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:29.942252
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) is None
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(0.0) == 0.0
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:09:30.749406
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:09:31.496919
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:32.072226
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:09:39.819076
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystemError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError

# Generated at 2022-06-18 12:09:40.972037
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:47.856176
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError

    class MyType(Type):
        field = IfThenElse(String(max_length=3), String(max_length=5))

    t = MyType()
    assert t.validate({"field": "abc"}) == {"field": "abc"}
    assert t.validate({"field": "abcde"}) == {"field": "abcde"}
    with pytest.raises(ValidationError):
        t.validate({"field": "abcdef"})
    with pytest.raises(ValidationError):
        t.validate({"field": "ab"})