

# Generated at 2022-06-18 12:02:38.499780
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any()
    )
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("a") == "a"

# Generated at 2022-06-18 12:02:46.528173
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    if_clause = String(max_length=10)
    then_clause = String(min_length=10)
    else_clause = String(min_length=20)
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate("1234567890") == "1234567890"
    assert field.validate("12345678901") == "12345678901"
    assert field.validate("12345678901234567890") == "12345678901234567890"
    assert field.validate("123456789012345678901") == "123456789012345678901"

# Generated at 2022-06-18 12:02:52.013142
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.types import String
    if_clause = String(max_length=10)
    then_clause = Integer()
    else_clause = String(max_length=20)
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate("12345") == 12345
    assert field.validate("1234567890") == "1234567890"

# Generated at 2022-06-18 12:03:01.560236
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test if_clause is True
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_clause.validate = MagicMock(return_value=True)
    then_clause.validate = MagicMock(return_value=True)
    else_clause.validate = MagicMock(return_value=True)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(True)
    if_clause.validate.assert_called_once_with(True, False)
    then_clause.validate.assert_called_once_with(True, False)
    else_clause.validate.assert_not_called()

    #

# Generated at 2022-06-18 12:03:10.572078
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystemError
    from typesystem.types import ValidationError
    from typesystem.types import ValidationErrorList

    class MyType(Type):
        field = Not(String())

    type_system = TypeSystem()
    type_system.register_type(MyType)

    # Test valid value
    try:
        type_system.validate(MyType, {"field": "hello"})
    except TypeSystemError as e:
        assert False, "Unexpected TypeSystemError: {}".format(e)

    # Test invalid value

# Generated at 2022-06-18 12:03:20.023172
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Float
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Enum
    from typesystem.fields import UUID
    from typesystem.fields import Email
    from typesystem.fields import URL
    from typesystem.fields import File
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse

# Generated at 2022-06-18 12:03:22.323503
# Unit test for method validate of class Not
def test_Not_validate():
    # Arrange
    field = Not(Any())
    # Act
    result = field.validate(None)
    # Assert
    assert result is None


# Generated at 2022-06-18 12:03:32.185181
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:03:37.668368
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(value=None) == None
    assert field.validate(value=1) == 1
    assert field.validate(value="string") == "string"
    assert field.validate(value=True) == True
    assert field.validate(value=False) == False
    assert field.validate(value=[]) == []
    assert field.validate(value={}) == {}

# Generated at 2022-06-18 12:03:47.150421
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(0.0) == 0.0
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({'a': 1}) == {'a': 1}
    assert field.validate(set()) == set()

# Generated at 2022-06-18 12:03:57.322638
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:03:58.873720
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:03:59.926874
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:04:01.861222
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([])
    assert one_of.validate(1) == 1


# Generated at 2022-06-18 12:04:09.922055
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate (1 of 2)
    # Tests simple case.
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    # Test for method validate (2 of 2)
    # Tests error case.
    field = OneOf([Integer(), String()])
    try:
        field.validate(1.1)
    except Exception as e:
        assert str(e) == "Did not match any valid type."


# Generated at 2022-06-18 12:04:17.106448
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer
    from typesystem import String
    from typesystem import Boolean
    from typesystem import Array
    from typesystem import Object
    from typesystem import Union
    from typesystem import Enum
    from typesystem import DateTime
    from typesystem import Date
    from typesystem import Time
    from typesystem import Duration
    from typesystem import Email
    from typesystem import Regex
    from typesystem import URL
    from typesystem import UUID
    from typesystem import IPv4
    from typesystem import IPv6
    from typesystem import IPvAny
    from typesystem import MAC
    from typesystem import Port
    from typesystem import JSON
    from typesystem import File
    from typesystem import Image
    from typesystem import Any
    from typesystem import NeverMatch
    from typesystem import OneOf
    from typesystem import AllOf


# Generated at 2022-06-18 12:04:22.144462
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_field = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_field.validate(value, strict)

    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:04:24.183225
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:04:29.924255
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:04:38.750830
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import Union
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import Boolean
    from typesystem.types import Number
    from typesystem.types import Integer
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Duration
    from typesystem.types import Email
    from typesystem.types import Regex
    from typesystem.types import URL
    from typesystem.types import UUID
    from typesystem.types import Choice
    from typesystem.types import Const
    from typesystem.types import Enum
    from typesystem.types import FormattedString
    from typesystem.types import String

# Generated at 2022-06-18 12:04:43.776780
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    field = OneOf([String()])
    assert field.one_of == [String()]


# Generated at 2022-06-18 12:04:44.980645
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:54.122114
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:04:55.014118
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:55.981484
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:04:59.512859
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""

# Generated at 2022-06-18 12:05:09.864243
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("") == ""
    assert not_field.validate("hello") == "hello"
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:05:20.252743
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test that OneOf.validate raises an error if no sub-items match
    field = OneOf([NeverMatch()])
    with pytest.raises(field.validation_error) as excinfo:
        field.validate(None)
    assert excinfo.value.code == "no_match"

    # Test that OneOf.validate raises an error if multiple sub-items match
    field = OneOf([Any(), Any()])
    with pytest.raises(field.validation_error) as excinfo:
        field.validate(None)
    assert excinfo.value.code == "multiple_matches"

    # Test that OneOf.validate returns the value if exactly one sub-item matches
    field = OneOf([NeverMatch(), Any()])
    assert field.validate(None) is None


# Unit test

# Generated at 2022-06-18 12:05:21.988910
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:22.904955
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:05:28.317083
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:38.590172
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer

    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)

    # Test for if_clause is true
    value = 1
    expected = "1"
    actual = field.validate(value)
    assert actual == expected

    # Test for if_clause is false
    value = "1"
    expected = "1"
    actual = field.validate(value)
    assert actual == expected

    # Test for if_clause is true and then_clause is false
    value = 1

# Generated at 2022-06-18 12:05:40.161418
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf([])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:05:52.372520
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:05:53.385086
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:05:57.777342
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:06:02.989703
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(1, strict=True) == 1


# Generated at 2022-06-18 12:06:09.903847
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Duration
    from typesystem.fields import Email
    from typesystem.fields import URL
    from typesystem.fields import IPv4
    from typesystem.fields import IPv6
    from typesystem.fields import UUID
    from typesystem.fields import HexColor
    from typesystem.fields import Slug
    from typesystem.fields import Choice
    from typesystem.fields import Regex
    from typesystem.fields import Const
    from typesystem.fields import Enum

# Generated at 2022-06-18 12:06:19.354572
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Regex
    from typesystem.validators import Required
    from typesystem.validators import Unique
    from typesystem.validators import Email
    from typesystem.validators import URL
    from typesystem.validators import UUID
    from typesystem.validators import IPv4
    from typesystem.validators import IPv6
    from typesystem.validators import MACAddress
    from typesystem.validators import Slug
    from typesystem.validators import Choice
    from typesystem.validators import Length
    from typesystem.validators import Contains
    from typesystem.validators import Equal

# Generated at 2022-06-18 12:06:20.403544
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:30.771497
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:06:31.979803
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Any())
    assert field.negated == Any()

# Generated at 2022-06-18 12:06:33.383561
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:42.113510
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:06:49.097199
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    from typesystem.exceptions import ValidationError
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    try:
        if_then_else.validate(1)
    except ValidationError:
        assert False
    try:
        if_then_else.validate("1")
    except ValidationError:
        assert False
    try:
        if_then_else.validate(1.0)
        assert False
    except ValidationError:
        assert True

# Generated at 2022-06-18 12:06:54.639165
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:07:04.185468
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate(0.0) == 0.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(0.0) == 0.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(0.0) == 0.0

# Generated at 2022-06-18 12:07:12.929512
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:07:24.004978
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:07:30.610247
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:07:43.157496
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:45.018879
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:07:53.142009
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import Object
    from typesystem.fields import Field
    from typesystem.fields import Any
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Number
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Enum
    from typesystem.fields import UUID
    from typesystem.fields import URL
    from typesystem.fields import Email
    from typesystem.fields import Regex
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Decimal

# Generated at 2022-06-18 12:07:58.710271
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    field = IfThenElse(Integer(), Integer())
    field.validate(1)
    field.validate(1.0)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.validate(1.1)
    field.valid

# Generated at 2022-06-18 12:07:59.533364
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:08:07.266611
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:08:08.811627
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:08:17.977367
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(String())
    assert field.validate("test") == "test"
    assert field.validate(1) == 1
    assert field.validate(True) == True
    assert field.validate(None) == None
    assert field.validate({"test": "test"}) == {"test": "test"}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"test": "test"}) == {"test": "test"}
    assert field.validate({"test": "test"}) == {"test": "test"}
    assert field.validate({"test": "test"}) == {"test": "test"}
    assert field.validate({"test": "test"}) == {"test": "test"}

# Generated at 2022-06-18 12:08:27.864293
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
   

# Generated at 2022-06-18 12:08:29.706310
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:58.340146
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(value=1) == 1
    assert not_field.validate(value=None) == None
    assert not_field.validate(value=True) == True
    assert not_field.validate(value=False) == False
    assert not_field.validate(value=1.0) == 1.0
    assert not_field.validate(value="1") == "1"
    assert not_field.validate(value=[1]) == [1]
    assert not_field.validate(value={1:1}) == {1:1}


# Generated at 2022-06-18 12:08:59.172741
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:09:07.547407
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:09:09.515973
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:10.320715
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:09:11.818039
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None

# Generated at 2022-06-18 12:09:14.538977
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    all_of = AllOf([String()])
    assert all_of.all_of == [String()]


# Generated at 2022-06-18 12:09:15.462971
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:09:17.074655
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())

# Generated at 2022-06-18 12:09:26.062162
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Not
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Not
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Not
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Not
    from typesystem.types import Type
    from typesystem.validators import MaxLength

# Generated at 2022-06-18 12:10:09.229358
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:10:10.861198
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:10:20.301868
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

    if_then_else = IfThenElse(if_clause, then_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == Any()

    if_then_else = IfThenElse(if_clause)


# Generated at 2022-06-18 12:10:27.686393
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(value=1) == 1
    assert field.validate(value=None) == None
    assert field.validate(value='a') == 'a'
    assert field.validate(value=True) == True
    assert field.validate(value=False) == False
    assert field.validate(value=1.0) == 1.0
    assert field.validate(value=[1, 2, 3]) == [1, 2, 3]
    assert field.validate(value={'a': 1, 'b': 2}) == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:10:29.057358
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:10:37.494661
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(0.0) == 0.0
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:10:39.415920
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:10:40.653481
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:10:42.422853
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem import Integer, String
    all_of = AllOf([Integer(), String()])
    assert all_of.all_of == [Integer(), String()]


# Generated at 2022-06-18 12:10:43.151922
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()
