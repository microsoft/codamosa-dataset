

# Generated at 2022-06-18 12:02:25.333668
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    if_clause = String(max_length=5)
    then_clause = String(min_length=6)
    else_clause = String(min_length=2)
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    value = "123456"
    assert if_then_else.validate(value) == value

# Generated at 2022-06-18 12:02:33.446198
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    field = Not(negated=Any())
    value = "test"
    strict = False
    expected = "test"
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 2
    field = Not(negated=Any())
    value = None
    strict = False
    expected = None
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 3
    field = Not(negated=Any())
    value = "test"
    strict = False
    expected = "test"
    actual = field.validate(value, strict)
    assert actual == expected

    # Test case 4
    field = Not(negated=Any())
    value = None
    strict = False
    expected = None
    actual = field.valid

# Generated at 2022-06-18 12:02:35.068906
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:02:36.376816
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:02:40.079342
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    not_ = Not(negated=Any())
    value = None
    strict = False

    # Perform the test
    result = not_.validate(value, strict)

    # Check the result
    assert result is None



# Generated at 2022-06-18 12:02:44.110741
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("hello") == "hello"
    assert field.validate([1,2,3]) == [1,2,3]
    assert field.validate({"a":1}) == {"a":1}


# Generated at 2022-06-18 12:02:52.972756
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.1) == 1.1
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:02:57.698116
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_instance = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_instance.validate(value, strict)

    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:03:04.113132
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    try:
        field.validate(1.1)
        assert False
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(1)
        field.validate("1")
        assert False
    except Exception as e:
        assert str(e) == "Matched more than one type."


# Generated at 2022-06-18 12:03:13.625247
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError

    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    # Test case 1: if_clause is valid, then_clause is valid
    value = 1
    assert if_then_else.validate(value) == value

    # Test case 2: if_clause is valid, then_clause is invalid
    value = 1
    with pytest.raises(ValidationError):
        if_then_else.validate(value)

    # Test case 3: if_clause is invalid, else_clause is valid

# Generated at 2022-06-18 12:03:18.722429
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    try:
        NeverMatch()
    except AssertionError:
        assert True
    else:
        assert False


# Generated at 2022-06-18 12:03:27.716947
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:03:31.857836
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:03:36.604350
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(1, strict=True) == 1

# Generated at 2022-06-18 12:03:43.755396
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [
        {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
        },
        {
            "type": "integer",
            "minimum": 1,
            "maximum": 10,
        },
    ]
    kwargs = {}
    one_of_instance = OneOf(one_of, **kwargs)
    value = 1
    strict = False

    # Perform the test
    result = one_of_instance.validate(value, strict)

    # assert the result
    assert result == 1



# Generated at 2022-06-18 12:03:54.008507
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [1, 2, 3]
    one_of_2 = [4, 5, 6]
    one_of_3 = [7, 8, 9]
    one_of_4 = [10, 11, 12]
    one_of_5 = [13, 14, 15]
    one_of_6 = [16, 17, 18]
    one_of_7 = [19, 20, 21]
    one_of_8 = [22, 23, 24]
    one_of_9 = [25, 26, 27]
    one_of_10 = [28, 29, 30]
    one_of_11 = [31, 32, 33]
    one_of_12 = [34, 35, 36]

# Generated at 2022-06-18 12:03:55.411100
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:03:58.233010
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String

    field = OneOf([String(), String()])
    field.validate("hello")



# Generated at 2022-06-18 12:04:09.257702
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=NeverMatch(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=NeverMatch()).validate(1) == 1

# Generated at 2022-06-18 12:04:12.789600
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1

# Generated at 2022-06-18 12:04:21.908006
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:04:23.718388
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:25.057006
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:26.946497
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-18 12:04:34.387068
# Unit test for method validate of class Not
def test_Not_validate():
    assert Not(Any()).validate(None) == None
    assert Not(Any()).validate(1) == 1
    assert Not(Any()).validate(1.0) == 1.0
    assert Not(Any()).validate(True) == True
    assert Not(Any()).validate("") == ""
    assert Not(Any()).validate([]) == []
    assert Not(Any()).validate({}) == {}
    assert Not(Any()).validate({"a": 1}) == {"a": 1}
    assert Not(Any()).validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:04:37.991411
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    not_field.validate(1)
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == "Must not match."


# Generated at 2022-06-18 12:04:44.643227
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Int(), Str()])
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    try:
        field.validate(True)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(1.0)
        assert False
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:04:51.625674
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()


# Generated at 2022-06-18 12:05:01.145706
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(bytearray()) == bytearray()

# Generated at 2022-06-18 12:05:02.791021
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Field())
    assert field.negated is not None


# Generated at 2022-06-18 12:05:13.653769
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test with valid value
    field = OneOf([String(), Integer()])
    assert field.validate("hello") == "hello"
    assert field.validate(1) == 1

    # Test with invalid value
    with pytest.raises(ValidationError) as excinfo:
        field.validate(1.1)
    assert excinfo.value.code == "no_match"

    # Test with multiple valid values
    with pytest.raises(ValidationError) as excinfo:
        field.validate(1)
    assert excinfo.value.code == "multiple_matches"


# Generated at 2022-06-18 12:05:18.754310
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_instance = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_instance.validate(value, strict)

    # Return the result
    return result


# Generated at 2022-06-18 12:05:24.653785
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:05:26.387530
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:05:27.685786
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:05:37.895370
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    assert field.validate("test") == "test"
    assert field.validate(1) == 1
    try:
        field.validate(1.1)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(1, strict=True)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate("test", strict=True)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"

# Generated at 2022-06-18 12:05:38.803314
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:50.761807
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:06:01.842563
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    assert field.validate("foo") == "foo"
    assert field.validate(1) == 1
    try:
        field.validate(1.0)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(True)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate({"foo": "bar"})
        assert False
    except ValidationError as e:
        assert e.code == "no_match"

# Generated at 2022-06-18 12:06:02.614630
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:06.232728
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:06:07.583868
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:16.182853
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse
    from typesystem.fields import Field
    from typesystem.fields import AnyOf
    from typesystem.fields import NoneOf
    from typesystem.fields import AllOf
    from typesystem.fields import OneOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse
    from typesystem.fields import Field
    from typesystem.fields import AnyOf

# Generated at 2022-06-18 12:06:25.856126
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:06:27.888963
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf(one_of=[])
    assert one_of.validate(value=None) == None


# Generated at 2022-06-18 12:06:28.865818
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:06:38.216567
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:06:42.064537
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False
    one_of_instance = OneOf(one_of)
    # Perform the test
    result = one_of_instance.validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:06:48.710620
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate (1 of 2)
    # Tests simple case.
    field = OneOf([Int(), String()])
    field.validate(1)
    field.validate("1")
    # Test for method validate (2 of 2)
    # Tests error cases.
    field = OneOf([Int(), String()])
    try:
        field.validate(1.1)
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(1, 2)
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:06:55.391389
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("string") == "string"
    assert not_field.validate(["list"]) == ["list"]
    assert not_field.validate({"dict": "dict"}) == {"dict": "dict"}


# Generated at 2022-06-18 12:07:01.178149
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(1)
    try:
        not_field.validate(None)
    except Exception as e:
        assert str(e) == 'Must not match.'


# Generated at 2022-06-18 12:07:02.422204
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field()).negated == Field()


# Generated at 2022-06-18 12:07:08.936279
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError

    class TestType(Type):
        field = IfThenElse(String(), String())

    type = TestType()
    type.validate({"field": "test"})
    try:
        type.validate({"field": 1})
    except ValidationError as e:
        assert e.error_code == "invalid_type"
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:07:16.589560
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    try:
        field.validate(None)
    except Exception as e:
        assert str(e) == 'ValidationError: Did not match any valid type.'
    try:
        field.validate(1.1)
    except Exception as e:
        assert str(e) == 'ValidationError: Matched more than one type.'


# Generated at 2022-06-18 12:07:17.532780
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:23.777853
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:07:27.564625
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False

    # Perform the test
    result = OneOf(one_of).validate(value, strict)

    # Check the result
    assert result is None


# Generated at 2022-06-18 12:07:28.883998
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:30.769821
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:40.509805
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:07:44.826711
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="NeverMatch").name == "NeverMatch"


# Generated at 2022-06-18 12:07:53.020386
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import String

    not_string = Not(String())
    assert not_string.validate(1) == 1
    assert not_string.validate(None) == None
    assert not_string.validate(True) == True
    assert not_string.validate(False) == False
    assert not_string.validate(1.0) == 1.0
    assert not_string.validate(1.0) == 1.0
    assert not_string.validate([1, 2, 3]) == [1, 2, 3]
    assert not_string.validate({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}
    assert not_string.validate(b'abc') == b'abc'

# Generated at 2022-06-18 12:07:54.523593
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(all_of=[])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:08:05.488294
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    field.validate("hello")
    field.validate(123)
    try:
        field.validate(None)
        assert False
    except ValidationError:
        pass
    try:
        field.validate(True)
        assert False
    except ValidationError:
        pass
    try:
        field.validate(False)
        assert False
    except ValidationError:
        pass
    try:
        field.validate(123.45)
        assert False
    except ValidationError:
        pass
    try:
        field.validate(["hello"])
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-18 12:08:14.689591
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({'a': 1}) == {'a': 1}
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1+1.1j) == 1.1+1.1j
   

# Generated at 2022-06-18 12:08:16.491398
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=Any())
    assert field.negated == Any()

# Generated at 2022-06-18 12:08:19.326509
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    try:
        not_field.validate(None)
        assert False
    except:
        assert True


# Generated at 2022-06-18 12:08:29.382875
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate("a") == "a"
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2]) == [1, 2]
    assert field.validate({"a": 1}, strict=True) == {"a": 1}
    assert field.validate([1, 2], strict=True) == [1, 2]

# Generated at 2022-06-18 12:08:31.921849
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create a OneOf object
    one_of = OneOf([])
    # Test the method validate
    value = one_of.validate(None)
    assert value == None


# Generated at 2022-06-18 12:08:36.226113
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_field = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_field.validate(value, strict)

    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:08:43.533520
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:08:44.396887
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:52.314412
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:08:53.340941
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:08:59.752108
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("abc") == "abc"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({"a":1,"b":2}) == {"a":1,"b":2}


# Generated at 2022-06-18 12:09:00.960068
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:03.773229
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_field = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_field.validate(value, strict)

    # Check the result
    assert result is None


# Generated at 2022-06-18 12:09:04.838057
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Field()])
    assert field.validate(1) == 1


# Generated at 2022-06-18 12:09:12.968512
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:09:23.028074
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    field = Not(negated=Field())
    value = "test"
    strict = False
    expected = "test"
    actual = field.validate(value, strict)
    assert actual == expected
    # Test case 2
    field = Not(negated=Field())
    value = "test"
    strict = False
    expected = "test"
    actual = field.validate(value, strict)
    assert actual == expected
    # Test case 3
    field = Not(negated=Field())
    value = "test"
    strict = False
    expected = "test"
    actual = field.validate(value, strict)
    assert actual == expected
    # Test case 4
    field = Not(negated=Field())
    value = "test"
    strict = False

# Generated at 2022-06-18 12:09:35.837523
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:44.052042
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:09:44.816213
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:09:47.449786
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False
    # Perform the test
    result = OneOf(one_of).validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:09:55.861434
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (line 514)
    field = Not(Any())
    field.validate(None)
    field.validate(1)
    field.validate("a")
    field.validate({"a": 1})
    field.validate([1, 2, 3])
    field.validate(True)
    field.validate(False)
    field.validate(1.1)
    field.validate(1.0)
    field.validate(1j)
    field.validate(1+1j)
    field.validate(1-1j)
    field.validate(1e1)
    field.validate(1e-1)
    field.validate(1e+1)
    field.validate(1.1e1)
    field.validate

# Generated at 2022-06-18 12:09:56.739694
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:09:57.619483
# Unit test for constructor of class Not
def test_Not():
    assert Not(None) is not None


# Generated at 2022-06-18 12:09:58.433301
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:10:04.282004
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        Field(name="name1", type="string"),
        Field(name="name2", type="string"),
        Field(name="name3", type="string")
    ])
    assert field.validate("test") == "test"
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:10:05.844342
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated == Field()


# Generated at 2022-06-18 12:10:55.013439
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:10:56.057352
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:10:57.422989
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:10:59.697210
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:11:01.368166
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf(one_of=[])
    assert one_of is not None


# Generated at 2022-06-18 12:11:10.057167
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:11:15.877949
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False


# Generated at 2022-06-18 12:11:24.395366
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    kwargs['name'] = 'test'
    kwargs['required'] = True
    kwargs['description'] = 'test'
    kwargs['allow_null'] = True
    kwargs['default'] = 'test'
    kwargs['validators'] = [Field()]
    kwargs['error_messages'] = {'test': 'test'}
    value = 'test'
    strict = True
    # Perform the test
    oneof = OneOf(one_of, **kwargs)
    result = oneof.validate(value, strict)
    # Validate the results
    assert(result == value)


# Generated at 2022-06-18 12:11:25.237166
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:11:26.214213
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:12:23.552328
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.types import IntegerType
    from typesystem.types import FloatType
    from typesystem.types import BooleanType
    from typesystem.types import ArrayType
    from typesystem.types import ObjectType
    from typesystem.types import DateTimeType
    from typesystem.types import DateType
    from typesystem.types import TimeType
    from typesystem.types import UUIDType
    from typesystem.types import EnumType
    from typesystem.types import AnyType
    from typesystem.types import UnionType
    from typesystem.types import OneOfType
    from typesystem.types import AllOfType
    from typesystem.types import NotType
    from typesystem.types import IfThenElseType
   