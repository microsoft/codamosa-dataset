

# Generated at 2022-06-18 12:02:36.499156
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:02:40.499635
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with valid input
    field = OneOf([Any()])
    assert field.one_of == [Any()]
    # Test with invalid input
    try:
        field = OneOf([Any()], allow_null=True)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-18 12:02:41.364163
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:02:48.395105
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:02:55.950631
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("abc") == "abc"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate([1,2,3]) == [1,2,3]
    assert not_field.validate({}) == {}
    assert not_field.validate({"a":1}) == {"a":1}


# Generated at 2022-06-18 12:02:56.885188
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:03:05.952931
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    print("test_OneOf_validate")
    # Test case 1
    print("Test case 1")
    one_of = [Field(name="name", type="string"), Field(name="age", type="integer")]
    field = OneOf(one_of=one_of)
    value = "name"
    strict = False
    result = field.validate(value=value, strict=strict)
    assert result == "name"
    # Test case 2
    print("Test case 2")
    one_of = [Field(name="name", type="string"), Field(name="age", type="integer")]
    field = OneOf(one_of=one_of)
    value = "age"
    strict = False
    result = field.validate(value=value, strict=strict)

# Generated at 2022-06-18 12:03:06.893858
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:03:16.326734
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError

    field = IfThenElse(
        if_clause=Integer(),
        then_clause=String(),
        else_clause=String(),
    )

    # Test if_clause
    assert field.validate(1) == "1"
    assert field.validate(1.0) == "1.0"
    assert field.validate(1.0, strict=True) == "1.0"
    assert field.validate(1.0, strict=False) == "1.0"
    assert field.validate(1.0, strict=True) == "1.0"
    assert field.validate(1.0, strict=False) == "1.0"
    assert field

# Generated at 2022-06-18 12:03:17.361610
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:03:25.363120
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = OneOf([String(), String()])
    assert field.validate("hello") == "hello"
    try:
        field.validate(1)
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate("hello", strict=True)
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:03:27.000609
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:03:34.485182
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = OneOf([String(max_length=3), String(max_length=4)])
    field.validate("123")
    field.validate("1234")
    try:
        field.validate("12345")
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate("12")
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:03:36.223680
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    assert field.validate(None) == None


# Generated at 2022-06-18 12:03:45.667628
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:03:56.533506
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-18 12:03:57.594966
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:02.509610
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with valid input
    field = OneOf([Any()])
    assert field.one_of == [Any()]
    # Test with invalid input
    try:
        field = OneOf([Any()], allow_null=True)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-18 12:04:12.830612
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate(()) == ()
    assert field.validate((1,)) == (1,)
    assert field.validate(set()) == set()
    assert field.validate({1}) == {1}

# Generated at 2022-06-18 12:04:15.088008
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:28.212443
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength

    if_clause = Integer(max_value=10)
    then_clause = String(min_length=2, max_length=3)
    else_clause = String(min_length=3, max_length=4)
    field = IfThenElse(if_clause, then_clause, else_clause)

    # test if_clause
    assert field.validate(5) == "5"
    assert field.validate(11) == "11"
    assert field.validate(5, strict=True) == 5
    assert field.validate(11, strict=True) == 11

# Generated at 2022-06-18 12:04:31.312032
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate of class Not
    # Tests if the value is not valid
    not_field = Not(Any())
    assert not_field.validate(None) is None
    # Tests if the value is valid
    with pytest.raises(ValidationError):
        not_field.validate(1)


# Generated at 2022-06-18 12:04:35.972167
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate(None) == None
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({1: 2, 3: 4}) == {1: 2, 3: 4}


# Generated at 2022-06-18 12:04:38.921198
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field.validate(1) == 1
    assert field.validate(1, strict=True) == 1


# Generated at 2022-06-18 12:04:40.795213
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:42.394690
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:43.299799
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:49.503530
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=NeverMatch()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=NeverMatch()).validate(1) == 1

# Generated at 2022-06-18 12:04:56.896843
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:04:57.903980
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:05:01.236248
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:07.267053
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:05:17.456456
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}

# Generated at 2022-06-18 12:05:18.478040
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:19.564355
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:05:20.638004
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:05:21.576214
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:22.469635
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:05:23.370290
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)


# Generated at 2022-06-18 12:05:25.127530
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated == Any()

# Generated at 2022-06-18 12:05:43.689238
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:05:51.677188
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String

    field = Not(String())
    assert field.validate("foo") == "foo"
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({"foo": "bar"}) == {"foo": "bar"}
    assert field.validate(["foo", "bar"]) == ["foo", "bar"]


# Generated at 2022-06-18 12:05:52.701346
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:54.169665
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:06:03.799282
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}
    assert not_field.validate({1: 2}) == {1: 2}

# Generated at 2022-06-18 12:06:04.700430
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:06:12.561499
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer

    field = OneOf([Integer(), Integer()])
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1
    assert field.validate(1.1) == 1
    assert field.validate(1.2) == 1
    assert field.validate(1.3) == 1
    assert field.validate(1.4) == 1
    assert field.validate(1.5) == 1
    assert field.validate(1.6) == 1
    assert field.validate(1.7) == 1
    assert field.validate(1.8) == 1
    assert field.validate(1.9) == 1
    assert field.validate(2) == 2
    assert field.validate(2.0) == 2

# Generated at 2022-06-18 12:06:16.055473
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(None)
    try:
        not_field.validate(1)
        assert False
    except Exception as e:
        assert e.args[0] == "Must not match."


# Generated at 2022-06-18 12:06:25.822618
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.fields import AllOf
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Any
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Any
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean

# Generated at 2022-06-18 12:06:27.514402
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:40.687662
# Unit test for method validate of class Not
def test_Not_validate():
    """
    Test method validate of class Not
    """
    # Test case 1
    field = Not(String())
    value = "test"
    assert field.validate(value) == value

    # Test case 2
    field = Not(String())
    value = 1
    assert field.validate(value) == value

    # Test case 3
    field = Not(String())
    value = None
    assert field.validate(value) == value

    # Test case 4
    field = Not(String())
    value = True
    assert field.validate(value) == value

    # Test case 5
    field = Not(String())
    value = False
    assert field.validate(value) == value

    # Test case 6
    field = Not(String())
    value = 1.0

# Generated at 2022-06-18 12:06:43.556481
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    not_field.validate(1)
    try:
        not_field.validate(None)
        assert False
    except ValueError:
        pass


# Generated at 2022-06-18 12:06:48.372200
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(()) == ()


# Generated at 2022-06-18 12:06:58.361426
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Regex
    from typesystem.validators import Required
    from typesystem.validators import Unique
    from typesystem.validators import URL
    from typesystem.validators import Email
    from typesystem.validators import UUID
    from typesystem.validators import Integer
    from typesystem.validators import Float
    from typesystem.validators import Boolean
    from typesystem.validators import Date
    from typesystem.validators import DateTime
    from typesystem.validators import Time
    from typesystem.validators import Choice
    from typesystem.validators import Length
    from typesystem.validators import Contains

# Generated at 2022-06-18 12:06:59.969258
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:01.136978
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:02.044525
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:03.724542
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:04.932369
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-18 12:07:10.753136
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(()) == ()


# Generated at 2022-06-18 12:07:29.182730
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLengthValidator

    class MyString(String):
        max_length = MaxLengthValidator(10)

    not_string = Not(StringType())
    not_mystring = Not(MyString())

    assert not_string.validate("abc") == "abc"
    assert not_mystring.validate("abc") == "abc"

    try:
        not_string.validate("abcdefghijklmnopqrstuvwxyz")
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False, "Should have raised ValidationError"


# Generated at 2022-06-18 12:07:34.964280
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:07:36.255100
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:07:37.210857
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:07:38.844486
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[])
    assert field.validate(1) == 1

# Generated at 2022-06-18 12:07:41.841848
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:42.641207
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:07:43.555055
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:45.052354
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:50.700609
# Unit test for method validate of class Not
def test_Not_validate():
    f = Not(negated=Any())
    assert f.validate(1) == 1
    assert f.validate(None) == None
    assert f.validate("") == ""
    assert f.validate([]) == []
    assert f.validate({}) == {}
    assert f.validate(True) == True
    assert f.validate(False) == False
    assert f.validate(1.0) == 1.0
    assert f.validate(1.0+2.0j) == 1.0+2.0j
    assert f.validate(1.0+2.0j) == 1.0+2.0j
    assert f.validate(1.0+2.0j) == 1.0+2.0j

# Generated at 2022-06-18 12:08:14.726931
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("") == ""
    assert not_field.validate("string") == "string"
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.1) == 1.1
    assert not_field.validate(1.2) == 1.2
    assert not_field.validate(1.3) == 1.3
    assert not_field.validate(1.4) == 1.4

# Generated at 2022-06-18 12:08:23.295884
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(value=None)
    field.validate(value=True)
    field.validate(value=False)
    field.validate(value=0)
    field.validate(value=1)
    field.validate(value=0.0)
    field.validate(value=1.0)
    field.validate(value="")
    field.validate(value="a")
    field.validate(value=[])
    field.validate(value=[1])
    field.validate(value={})
    field.validate(value={"a": 1})



# Generated at 2022-06-18 12:08:28.304357
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError

    class AllOfType(Type):
        field = AllOf([String(), String()])

    AllOfType().validate({"field": "foo"})

    with pytest.raises(ValidationError):
        AllOfType().validate({"field": 1})



# Generated at 2022-06-18 12:08:36.144465
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:08:43.951770
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystem
   

# Generated at 2022-06-18 12:08:53.747943
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Schema
    from typesystem.validators import MaxLength
    from typesystem.fields import AllOf
    from typesystem.fields import Field
    from typesystem.fields import Any
    from typesystem.fields import Boolean
    from typesystem.fields import Date
    from typesystem.fields import DateTime
    from typesystem.fields import Decimal
    from typesystem.fields import Dict
    from typesystem.fields import Email
    from typesystem.fields import Float
    from typesystem.fields import Integer
    from typesystem.fields import List
    from typesystem.fields import String
    from typesystem.fields import Time
    from typesystem.fields import URL
    from typesystem.fields import UUID
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf


# Generated at 2022-06-18 12:08:55.353342
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:09:01.575250
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test 1:
    all_of = [Field()]
    all_of_field = AllOf(all_of)
    assert all_of_field.all_of == all_of
    assert all_of_field.allow_null == False
    assert all_of_field.default == None
    assert all_of_field.description == None
    assert all_of_field.name == None
    assert all_of_field.required == False
    assert all_of_field.title == None


# Generated at 2022-06-18 12:09:08.973684
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [
        {
            "type": "string",
            "minLength": 1,
            "maxLength": 10,
        },
        {
            "type": "integer",
            "minimum": 1,
            "maximum": 10,
        },
    ]
    kwargs = {}
    oneOf1 = OneOf(one_of, **kwargs)
    # Test execution
    assert oneOf1.validate("12345") == "12345"
    assert oneOf1.validate(12345) == 12345
    try:
        oneOf1.validate(123456)
    except ValidationError as e:
        assert e.messages == {'no_match': 'Did not match any valid type.'}

# Generated at 2022-06-18 12:09:10.544427
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:10:51.521634
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Pattern

    # Test with valid value
    field = Not(String(max_length=5))
    assert field.validate("123456") == "123456"

    # Test with invalid value
    field = Not(String(max_length=5))
    try:
        field.validate("12345")
    except ValidationError as e:
        assert e.messages == {"negated": "Must not match."}
    else:
        assert False

    # Test with valid value
    field = Not(String(min_length=5))

# Generated at 2022-06-18 12:11:01.854685
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLengthValidator, MinLengthValidator
    from typesystem.validators import PatternValidator
    from typesystem.validators import RegexValidator
    from typesystem.validators import URLValidator

    # Test case 1
    field = Not(String(max_length=5))
    try:
        field.validate("123456")
    except ValidationError:
        pass
    else:
        assert False

    # Test case 2
    field = Not(String(max_length=5))
    try:
        field.validate("12345")
    except ValidationError:
        assert False
    else:
        pass

    # Test case 3

# Generated at 2022-06-18 12:11:09.386136
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:11:13.175350
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}


# Generated at 2022-06-18 12:11:22.949203
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate("") == ""
    assert not_field.validate("a") == "a"
    assert not_field.validate([]) == []
    assert not_field.validate([1]) == [1]
    assert not_field.validate({}) == {}
    assert not_field.validate({'a': 1}) == {'a': 1}
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0+1j) == 1.

# Generated at 2022-06-18 12:11:31.183872
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(1)
    field.validate(None)
    field.validate("")
    field.validate(True)
    field.validate(False)
    field.validate([])
    field.validate({})
    field.validate(())
    field.validate(set())
    field.validate(frozenset())
    field.validate(range(0))
    field.validate(bytearray())
    field.validate(memoryview(b""))
    field.validate(object())
    field.validate(object)
    field.validate(type)
    field.validate(Exception())
    field.validate(Exception)
    field.validate(StopIteration())

# Generated at 2022-06-18 12:11:38.734651
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    field = Not(negated=Any())
    value = 1
    strict = False
    expected = 1
    actual = field.validate(value, strict)
    assert expected == actual

    # Test case 2
    field = Not(negated=Any())
    value = None
    strict = False
    expected = None
    actual = field.validate(value, strict)
    assert expected == actual

    # Test case 3
    field = Not(negated=Any())
    value = 1
    strict = True
    expected = 1
    actual = field.validate(value, strict)
    assert expected == actual

    # Test case 4
    field = Not(negated=Any())
    value = None
    strict = True
    expected = None
    actual = field.validate(value, strict)
   

# Generated at 2022-06-18 12:11:46.942057
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength

    class MyString(String):
        validators = [MinLength(3), MaxLength(5)]

    field = Not(MyString())

    try:
        field.validate("ab")
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False

    try:
        field.validate("abc")
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False


# Generated at 2022-06-18 12:11:48.655413
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate(None)
    try:
        not_field.validate(1)
        assert False
    except:
        assert True


# Generated at 2022-06-18 12:11:50.670287
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    not_field.validate("test")
    try:
        not_field.validate(None)
        assert False
    except:
        assert True
