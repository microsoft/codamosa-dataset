

# Generated at 2022-06-18 12:02:36.949746
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:02:42.207548
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {'name': 'name', 'description': 'description'}
    one_of_field = OneOf(one_of, **kwargs)
    value = 'value'
    strict = False

    # Perform the test
    result = one_of_field.validate(value, strict)

    # Check the result
    assert result is None


# Generated at 2022-06-18 12:02:50.430091
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a":1}) == {"a":1}
    assert field.validate({"a":1, "b":2}) == {"a":1, "b":2}
    assert field.validate({"a":1, "b":2, "c":3}) == {"a":1, "b":2, "c":3}

# Generated at 2022-06-18 12:02:54.261790
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    not_field = Not(negated=Any())
    value = None
    strict = False
    # Perform the test
    result = not_field.validate(value, strict)
    # Verify the results
    assert result is None


# Generated at 2022-06-18 12:02:55.145119
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:03:01.559009
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        String(),
        Integer(),
    ])
    assert field.validate("foo") == "foo"
    assert field.validate(123) == 123
    with pytest.raises(ValidationError) as excinfo:
        field.validate(None)
    assert excinfo.value.code == "no_match"
    with pytest.raises(ValidationError) as excinfo:
        field.validate(True)
    assert excinfo.value.code == "multiple_matches"


# Generated at 2022-06-18 12:03:04.507009
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    try:
        field.validate(None)
    except Exception as e:
        assert str(e) == 'Must not match.'


# Generated at 2022-06-18 12:03:05.419212
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:03:14.905464
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength

    class MyType(Type):
        field = IfThenElse(
            if_clause=MaxLength(10),
            then_clause=String(max_length=10),
            else_clause=String(max_length=20),
        )

    # Test if_clause is true
    my_type = MyType()
    my_type.validate({"field": "1234567890"})

    # Test if_clause is false
    my_type = MyType()
    my_type.validate({"field": "12345678901"})

    # Test if_clause is true and then_clause is false
    my_

# Generated at 2022-06-18 12:03:20.473435
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:03:32.598819
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:03:42.018527
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate of class OneOf
    # Tests for the method validate of class OneOf
    # Case 1:
    #     Tests if the method validate returns the correct value
    #     when the value matches one of the sub-items.
    #     Expected result:
    #         The method validate returns the value.
    # Case 2:
    #     Tests if the method validate raises an error
    #     when the value matches more than one of the sub-items.
    #     Expected result:
    #         The method validate raises an error.
    # Case 3:
    #     Tests if the method validate raises an error
    #     when the value doesn't match any of the sub-items.
    #     Expected result:
    #         The method validate raises an error.
    from typesystem.fields import Integer, String

    field = One

# Generated at 2022-06-18 12:03:42.587577
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-18 12:03:52.380943
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(None) == None
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(True) == True
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(False) == False
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate("") == ""

# Generated at 2022-06-18 12:03:53.759919
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:05.691047
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    import typesystem
    import json

    class Person(typesystem.Schema):
        name = typesystem.String(max_length=100)
        age = typesystem.Integer(minimum=0, maximum=150)
        gender = typesystem.String(enum=["male", "female"])
        address = typesystem.String(max_length=100)
        phone = typesystem.String(max_length=100)
        email = typesystem.String(max_length=100)

    class PersonSchema(typesystem.Schema):
        person = Person()
        if_clause = typesystem.String(enum=["male", "female"])
        then_clause = Person()
        else_clause = Person()

    schema = PersonSchema()

# Generated at 2022-06-18 12:04:11.894506
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:04:12.985565
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:04:14.651576
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:04:25.346951
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:04:30.607683
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Create a OneOf object
    one_of_field = OneOf(one_of=[])
    # Call method validate of one_of_field
    # TypeError should be raised.
    with pytest.raises(TypeError):
        one_of_field.validate(value=1)


# Generated at 2022-06-18 12:04:39.519766
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:04:45.944896
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:04:46.844222
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:48.190157
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().validate(None) == None


# Generated at 2022-06-18 12:04:57.314035
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = IfThenElse(String(min_length=1), String(min_length=2))
    assert field.validate("a") == "a"
    assert field.validate("aa") == "aa"
    try:
        field.validate("")
        assert False
    except ValidationError:
        pass
    try:
        field.validate(None)
        assert False
    except ValidationError:
        pass

    field = IfThenElse(String(min_length=1), String(min_length=2), String(min_length=3))
    assert field.validate("a") == "a"
    assert field.validate("aa") == "aa"
    assert field.validate("aaa") == "aaa"

# Generated at 2022-06-18 12:05:07.529367
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Duration
    from typesystem.fields import Email
    from typesystem.fields import Regex
    from typesystem.fields import URL
    from typesystem.fields import UUID
    from typesystem.fields import Choice
    from typesystem.fields import Enum
    from typesystem.fields import Union
    from typesystem.fields import Intersection
    from typesystem.fields import Constant
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch

# Generated at 2022-06-18 12:05:17.256880
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.types import String

    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("1") == "1"
    assert if_then_else.validate(1.0) == "1.0"
    assert if_then_else.validate(True) == "True"
    assert if_then_else.validate(False) == "False"
    assert if_then_else.validate(None) == "None"

# Generated at 2022-06-18 12:05:27.070280
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = False
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(value, strict) == value

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = True
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(value, strict) == value

    # Test case 3
    if_clause = Field()

# Generated at 2022-06-18 12:05:36.649194
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String, Integer
    field = OneOf([String(), Integer()])
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    try:
        field.validate(True)
        assert False
    except ValueError as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(None)
        assert False
    except ValueError as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(["hello", 123])
        assert False
    except ValueError as e:
        assert str(e) == "Matched more than one type."


# Generated at 2022-06-18 12:05:40.286864
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Any())
    assert not_field.negated is not None

# Generated at 2022-06-18 12:05:41.814698
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:45.592634
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field.validate(1) == 1
    assert field.validate(1, strict=True) == 1


# Generated at 2022-06-18 12:05:47.311479
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:55.945331
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.types import String as StringType
    from typesystem.types import Type

    class IfThenElseTest(Type):
        if_clause = String(max_length=5)
        then_clause = Integer()
        else_clause = StringType()

    assert IfThenElseTest().validate("123456") == "123456"
    assert IfThenElseTest().validate("12345") == 12345
    assert IfThenElseTest().validate("1234") == "1234"

# Generated at 2022-06-18 12:06:06.104562
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
    from typesystem.types import Type
   

# Generated at 2022-06-18 12:06:07.552362
# Unit test for constructor of class OneOf
def test_OneOf():
    one_of = OneOf([])
    assert one_of.one_of == []


# Generated at 2022-06-18 12:06:10.798479
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(
        if_clause=Field(),
        then_clause=Field(),
        else_clause=Field(),
    )
    assert field.if_clause is not None
    assert field.then_clause is not None
    assert field.else_clause is not None

# Generated at 2022-06-18 12:06:12.129130
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:06:21.752981
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength

    class TestType(Type):
        field = IfThenElse(
            if_clause=String(validators=[MaxLength(10)]),
            then_clause=String(validators=[MaxLength(5)]),
            else_clause=String(validators=[MaxLength(15)]),
        )

    test_type = TestType()
    test_type.validate({"field": "12345"})
    test_type.validate({"field": "12345678901"})

# Generated at 2022-06-18 12:06:30.175027
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = OneOf([String(), String()])
    assert field.validate("test") == "test"
    try:
        field.validate(5)
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate("test", strict=True)
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:06:39.439489
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    field = OneOf([String(), String()])
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")
    field.validate("test")

# Generated at 2022-06-18 12:06:40.910238
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:46.037388
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Field(), Field()])
    field.validate(1)
    field.validate(2)
    try:
        field.validate(3)
    except Exception as e:
        assert str(e) == 'Did not match any valid type.'
    try:
        field.validate(4)
    except Exception as e:
        assert str(e) == 'Matched more than one type.'


# Generated at 2022-06-18 12:06:46.852676
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:06:51.987722
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for validating a value that does not match the negated field
    field = Not(String())
    assert field.validate("foo") == "foo"
    # Test for validating a value that matches the negated field
    field = Not(String())
    try:
        field.validate(1)
    except ValidationError as error:
        assert error.code == "negated"
    else:
        assert False, "Expected ValidationError"


# Generated at 2022-06-18 12:07:01.911728
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import Object
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Any
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse

    class MyObject(Object):
        field1 = String()
        field2 = Integer()
        field3 = Boolean()
        field4 = Array(String())
        field5 = Any()
        field6 = OneOf([String(), Integer()])
        field7 = AllOf([String(), Integer()])
        field8 = Not(String())

# Generated at 2022-06-18 12:07:03.933024
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    with pytest.raises(field.validation_error):
        field.validate(1)


# Generated at 2022-06-18 12:07:11.452206
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    if_clause = Integer(minimum=0)
    then_clause = Integer(maximum=10)
    else_clause = Integer(maximum=20)
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(5) == 5
    assert field.validate(15) == 15
    with pytest.raises(ValidationError):
        field.validate(-5)
    with pytest.raises(ValidationError):
        field.validate(25)

# Generated at 2022-06-18 12:07:18.427148
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer, String
    from typesystem.exceptions import ValidationError
    field = IfThenElse(Integer(), String())
    assert field.validate(1) == "1"
    assert field.validate("1") == "1"
    try:
        field.validate(1.0)
        assert False
    except ValidationError:
        pass
    try:
        field.validate(None)
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-18 12:07:24.147855
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    one_of = OneOf([])
    assert one_of.validate(None) == None


# Generated at 2022-06-18 12:07:25.259547
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:07:36.478099
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.types import IntegerType
    from typesystem.types import FloatType
    from typesystem.types import BooleanType
    from typesystem.types import ArrayType
    from typesystem.types import ObjectType
    from typesystem.types import DateType
    from typesystem.types import DateTimeType
    from typesystem.types import TimeType
    from typesystem.types import UUIDType
    from typesystem.types import EnumType
    from typesystem.types import AnyType
    from typesystem.types import UnionType
    from typesystem.types import AllOfType
    from typesystem.types import OneOfType
    from typesystem.types import NotType
    from typesystem.types import IfThenElseType
    from typesystem.types import NeverMatchType

# Generated at 2022-06-18 12:07:37.755777
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf(one_of=[])


# Generated at 2022-06-18 12:07:39.520650
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    assert field.validate(None) == None

# Generated at 2022-06-18 12:07:42.768214
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:07:51.589023
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError

    field = IfThenElse(Integer(minimum=0), Integer(maximum=10))
    assert field.validate(5) == 5

    field = IfThenElse(Integer(minimum=0), Integer(maximum=10), Integer(minimum=20))
    assert field.validate(5) == 5
    assert field.validate(25) == 25

    field = IfThenElse(Integer(minimum=0), Integer(maximum=10), Integer(minimum=20))
    try:
        field.validate(15)
        assert False
    except ValidationError:
        pass

    field = IfThenElse(Integer(minimum=0), Integer(maximum=10), Integer(minimum=20))

# Generated at 2022-06-18 12:07:52.968422
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    assert field.validate(None) == None


# Generated at 2022-06-18 12:08:03.413989
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer
    from typesystem.types import String
    from typesystem.fields import AllOf
    from typesystem.fields import Field
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import AllOf
    from typesystem.fields import Field
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import AllOf
    from typesystem.fields import Field
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import AllOf
    from typesystem.fields import Field
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import AllOf
    from typesystem.fields import Field
    from typesystem.fields import Integer

# Generated at 2022-06-18 12:08:05.322024
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:25.717177
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(1) == "1"
    assert field.validate("a") == "a"
    assert field.validate(1.0) == "1.0"
    assert field.validate(True) == "True"
    assert field.validate(False) == "False"
    assert field.validate(None) == "None"
    assert field.validate({"a": 1}) == "{'a': 1}"
    assert field.validate([1, 2, 3]) == "[1, 2, 3]"

# Generated at 2022-06-18 12:08:27.492172
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:30.911687
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(1)

# Generated at 2022-06-18 12:08:37.667084
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"1":1}) == {"1":1}
    assert not_field.validate([1]) == [1]


# Generated at 2022-06-18 12:08:38.596264
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:42.145080
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field(), Field()]
    value = None
    strict = False

    # Perform the test
    field = OneOf(one_of)
    result = field.validate(value, strict)

    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:08:44.015928
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:45.542898
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:08:55.452727
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate (line 572)
    class TestOneOf(OneOf):
        def __init__(self, one_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(one_of, **kwargs)
    # Declaration of local variable 'field'
    field = TestOneOf([Integer(), String()])
    # Call to validate(...): (line 574)
    # Processing the call arguments (line 574)
    int_1 = 1
    # Processing the call keyword arguments (line 574)
    kwargs_2 = {}
    # Getting the type of 'field' (line 574)

# Generated at 2022-06-18 12:08:56.788031
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:09:15.812759
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:25.134594
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = False
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(value, strict) == value

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = True
    field = IfThenElse(if_clause, then_clause, else_clause)
    assert field.validate(value, strict) == value

    # Test case 3
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field

# Generated at 2022-06-18 12:09:26.894336
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:09:30.558929
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False
    one_of_instance = OneOf(one_of)
    # Perform the test
    result = one_of_instance.validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:09:33.069500
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_field = OneOf([])
    value = None
    strict = False
    # Perform the test
    result = one_of_field.validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:09:40.928425
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate (line 50)
    # Unit test for method validate of class OneOf
    class TestOneOf(unittest.TestCase):
        def test_validate(self):
            field = OneOf([Integer(), String()])
            self.assertEqual(field.validate(1), 1)
            self.assertEqual(field.validate("1"), "1")
            with self.assertRaises(ValidationError) as cm:
                field.validate(None)
            self.assertEqual(cm.exception.code, "no_match")
            with self.assertRaises(ValidationError) as cm:
                field.validate(1.0)
            self.assertEqual(cm.exception.code, "multiple_matches")

# Generated at 2022-06-18 12:09:48.702808
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import Schema
    from typesystem.types import Object
    from typesystem.types import Array
    from typesystem.types import Integer
    from typesystem.types import Boolean
    from typesystem.types import Number
    from typesystem.types import String
    from typesystem.types import Enum
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import UUID
    from typesystem.types import URL
    from typesystem.types import Email
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import IPvAny
    from typesystem.types import MACAddress
   

# Generated at 2022-06-18 12:09:57.161556
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert not_field.validate({"a": 1, "b": 2, "c": 3})

# Generated at 2022-06-18 12:10:04.606838
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.exceptions import ValidationError
    from typesystem.fields import IfThenElse
    from typesystem.fields import Boolean
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import String
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Object
    from typesystem.fields import Array
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse

# Generated at 2022-06-18 12:10:12.678836
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate(0) == 0
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate([]) == []
    assert field.validate([1]) == [1]
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}


# Generated at 2022-06-18 12:10:57.102179
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:11:07.069646
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestIfThenElse(IfThenElse):
        def __init__(self, if_clause, then_clause, else_clause):
            super().__init__(if_clause, then_clause, else_clause)

    class TestIfClause(Field):
        def __init__(self):
            super().__init__()

        def validate(self, value, strict=False):
            return value

    class TestThenClause(Field):
        def __init__(self):
            super().__init__()

        def validate(self, value, strict=False):
            return value

    class TestElseClause(Field):
        def __init__(self):
            super().__init__()

        def validate(self, value, strict=False):
            return value

    if_clause = TestIf

# Generated at 2022-06-18 12:11:14.386185
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0 + 1.0j) == 1.0 + 1.0j
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0))

# Generated at 2022-06-18 12:11:24.130973
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0+1j) == 1.0+1j
    assert not_field.validate(()) == ()
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
   

# Generated at 2022-06-18 12:11:32.301957
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:11:33.943579
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:11:41.874462
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    assert field.validate(1) == 1
    assert field.validate(1.0) == 1.0
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate({}) == {}
    assert field.validate([]) == []
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1]) == [1]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate([1, 2]) == [1, 2]

# Generated at 2022-06-18 12:11:45.411615
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (1 of 2)
    # Tests if the method validate works correctly
    field = Not(String())
    assert field.validate("hello") == "hello"
    try:
        field.validate(1)
        assert False
    except ValidationError:
        assert True


# Generated at 2022-06-18 12:11:46.768313
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:11:53.313065
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("hello") == "hello"
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}
    assert field.validate({"a": 1, "b": 2, "c": 3}) == {"a": 1, "b": 2, "c": 3}