

# Generated at 2022-06-18 12:02:42.645368
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:02:43.406728
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:02:52.059006
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.validators import MaxLength

    field = IfThenElse(
        if_clause=Integer(),
        then_clause=String(validators=[MaxLength(10)]),
        else_clause=String(validators=[MaxLength(5)]),
    )

    assert field.validate(1) == "1"
    assert field.validate("abc") == "abc"

    with pytest.raises(ValidationError) as exc:
        field.validate("abcdefghijklmnopqrstuvwxyz")
    assert exc.value.code == "max_length"


# Generated at 2022-06-18 12:02:54.302278
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    a = AllOf([String()])
    assert a.all_of == [String()]


# Generated at 2022-06-18 12:03:03.451159
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:03:12.937467
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import StringType
    from typesystem.fields import Not
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.fields import Not
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.fields import Not
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.fields import Not
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.fields import Not
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.fields import Not
    from typesystem.fields import String
    from typesystem.types import StringType


# Generated at 2022-06-18 12:03:17.792180
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with no arguments
    try:
        OneOf()
        assert False
    except TypeError:
        pass

    # Test with invalid arguments
    try:
        OneOf(one_of=None)
        assert False
    except TypeError:
        pass

    # Test with valid arguments
    OneOf(one_of=[])
    OneOf(one_of=[Any()])


# Generated at 2022-06-18 12:03:26.828640
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Field())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate("") == ""
    assert field.validate("a") == "a"
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.2) == 1.2
    assert field.validate(1.3) == 1.3
    assert field.validate(1.4) == 1.4
    assert field.validate(1.5) == 1.5
    assert field.validate(1.6) == 1.6
    assert field.validate

# Generated at 2022-06-18 12:03:36.946699
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of_1 = [Field()]
    one_of_2 = [Field()]
    one_of_3 = [Field()]
    one_of_4 = [Field()]
    one_of_5 = [Field()]
    one_of_6 = [Field()]
    one_of_7 = [Field()]
    one_of_8 = [Field()]
    one_of_9 = [Field()]
    one_of_10 = [Field()]
    one_of_11 = [Field()]
    one_of_12 = [Field()]
    one_of_13 = [Field()]
    one_of_14 = [Field()]
    one_of_15 = [Field()]
    one_of_16 = [Field()]
   

# Generated at 2022-06-18 12:03:46.357084
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:03:49.457773
# Unit test for constructor of class Not
def test_Not():
    assert Not(None)

# Generated at 2022-06-18 12:03:58.706541
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any()])
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(None) == None
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:04:04.324546
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = Not(String())
    try:
        field.validate("hello")
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False, "Should have raised ValidationError"

    field.validate(1)

# Generated at 2022-06-18 12:04:06.189077
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:10.156028
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False
    # Perform the test
    result = OneOf(one_of).validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:04:14.894657
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:04:15.901015
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:17.749524
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:18.828646
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())

# Generated at 2022-06-18 12:04:23.056332
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String, Integer

    field = IfThenElse(
        if_clause=String(),
        then_clause=Integer(),
        else_clause=Integer(),
    )

    assert field.validate("1") == 1
    assert field.validate(1) == 1

# Generated at 2022-06-18 12:04:32.537680
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(None) == None
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate("1") == "1"
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(True) == True
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(False) == False

# Generated at 2022-06-18 12:04:42.394690
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:04:43.980932
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None

# Generated at 2022-06-18 12:04:45.851453
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause = 1, then_clause = 2, else_clause = 3)

# Generated at 2022-06-18 12:04:52.822413
# Unit test for method validate of class Not
def test_Not_validate():
    # Create a Not object
    not_field = Not(negated=Any())
    # Test the validate method
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:05:02.278397
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import Number
    from typesystem.types import Float
    from typesystem.types import Boolean
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import Enum
    from typesystem.types import UUID
    from typesystem.types import Email
    from typesystem.types import URL
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import IPv46
    from typesystem.types import MACAddress
    from typesystem.types import Slug
    from typesystem.types import Choice


# Generated at 2022-06-18 12:05:12.883028
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import Number
    from typesystem.types import String
    from typesystem.types import Boolean
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import Enum
    from typesystem.types import DateTime
    from typesystem.types import Date
    from typesystem.types import Time
    from typesystem.types import UUID
    from typesystem.types import URL
    from typesystem.types import Email
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import IPvAny
    from typesystem.types import MACAddress
    from typesystem.types import Hostname
    from typesystem.types import Re

# Generated at 2022-06-18 12:05:13.820545
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:05:21.027351
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]


# Generated at 2022-06-18 12:05:21.989864
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:05:36.823998
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate({}) == {}
    assert field.validate([]) == []
    assert field.validate(()) == ()
    assert field.validate(set()) == set()
    assert field.validate(frozenset()) == frozenset()
    assert field.validate(range(0)) == range(0)
    assert field.validate(range(1)) == range(1)
    assert field.validate(range(2)) == range

# Generated at 2022-06-18 12:05:38.460671
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None

# Generated at 2022-06-18 12:05:39.368991
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:42.102311
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    field = AllOf([String()])
    assert field.all_of == [String()]


# Generated at 2022-06-18 12:05:43.438169
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:49.095028
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    kwargs = {}
    one_of_instance = OneOf(one_of, **kwargs)
    value = None
    strict = False

    # Perform the test
    result = one_of_instance.validate(value, strict)

    # assert the result
    assert result is None


# Generated at 2022-06-18 12:05:52.801034
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Duration
    from typesystem.fields import Email
    from typesystem.fields import UUID
    from typesystem.fields import URL
    from typesystem.fields import Choice
    from typesystem.fields import Regex
    from typesystem.fields import Const
    from typesystem.fields import Enum
    from typesystem.fields import Number
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import String

# Generated at 2022-06-18 12:06:01.094867
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = Not(String())
    try:
        field.validate("foo")
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False, "Expected ValidationError"

    try:
        field.validate(1)
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False, "Expected ValidationError"

    field.validate(None)


# Generated at 2022-06-18 12:06:07.667166
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem
    from typesystem.types import TypeSystemError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError
    from typesystem.types import TypeSystemValidationError

# Generated at 2022-06-18 12:06:12.355726
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer

    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)

    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("1") == "1"

# Generated at 2022-06-18 12:06:25.633192
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:06:30.135110
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = Not(String())
    field.validate("foo")
    try:
        field.validate(1)
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False, "Expected ValidationError"



# Generated at 2022-06-18 12:06:31.022767
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:31.899185
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:33.699772
# Unit test for constructor of class OneOf
def test_OneOf():
    field = OneOf([])
    assert field.one_of == []


# Generated at 2022-06-18 12:06:36.525091
# Unit test for constructor of class AllOf
def test_AllOf():
    # Test with valid input
    assert AllOf([Any()])
    # Test with invalid input
    try:
        AllOf([])
    except AssertionError:
        assert True
    else:
        assert False


# Generated at 2022-06-18 12:06:37.314505
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:46.223923
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(range(0)) == range(0)
    assert not_field.validate(bytearray()) == bytearray()

# Generated at 2022-06-18 12:06:46.744669
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-18 12:06:54.667743
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError

    class TestType(Type):
        field = IfThenElse(String(), String())

    try:
        TestType().validate({"field": 1})
    except ValidationError as e:
        assert e.detail == {"field": "Must be a string."}
    else:
        assert False, "ValidationError not raised"

    try:
        TestType().validate({"field": "1"})
    except ValidationError as e:
        assert e.detail == {"field": "Must be a string."}
    else:
        assert False, "ValidationError not raised"

# Generated at 2022-06-18 12:07:04.491144
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None


# Generated at 2022-06-18 12:07:05.345309
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:06.664827
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:07:15.486479
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate([1]) == [1]


# Generated at 2022-06-18 12:07:25.596401
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MaxLength
    from typesystem.validators import MinLength
    from typesystem.validators import Pattern

    class MyType(Type):
        field = AllOf([
            String(max_length=10),
            String(min_length=5),
            String(pattern=r"^[a-z]+$"),
        ])

    assert MyType().validate({"field": "hello"}) == {"field": "hello"}
    assert MyType().validate({"field": "hello world"}) == {"field": "hello world"}
    assert MyType().validate({"field": "hello world!"}) == {"field": "hello world!"}

# Generated at 2022-06-18 12:07:36.804321
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.validators import MinLength, MaxLength
    from typesystem.exceptions import ValidationError

    class MyType(Type):
        field = AllOf([String(min_length=1), String(max_length=10)])

    type = MyType()
    type.validate({"field": "abc"})
    try:
        type.validate({"field": "abcdefghijklmnopqrstuvwxyz"})
    except ValidationError as e:
        assert e.detail["field"]["max_length"] == "Must have no more than 10 characters."

# Generated at 2022-06-18 12:07:37.754987
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:45.279041
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("1") == "1"

# Generated at 2022-06-18 12:07:49.850343
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError

    field = Not(String())
    assert field.validate("foo") == "foo"
    try:
        field.validate(1)
    except ValidationError as e:
        assert e.code == "negated"
    else:
        assert False, "Should have raised ValidationError"


# Generated at 2022-06-18 12:07:53.413605
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field(type="string")
    then_clause = Field(type="string")
    else_clause = Field(type="string")
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:08:16.693907
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), then_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=NeverMatch(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:08:19.812427
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(None)

# Generated at 2022-06-18 12:08:29.945731
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test for method validate (1 of 2)
    # Tests if the then_clause is returned if the if_clause is valid
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == then_clause.validate(1)

    # Test for method validate (2 of 2)
    # Tests if the else_clause is returned if the if_clause is not valid
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
   

# Generated at 2022-06-18 12:08:30.830877
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:40.006595
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate("a") == "a"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate({"a": 1}) == {"a": 1}
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:08:41.395984
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = AllOf(all_of=[])
    assert all_of.all_of == []


# Generated at 2022-06-18 12:08:42.435933
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch(name="NeverMatch").name == "NeverMatch"


# Generated at 2022-06-18 12:08:43.653552
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:44.517482
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:08:49.924865
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:09:12.634652
# Unit test for constructor of class Not
def test_Not():
    from typesystem.fields import String
    field = Not(String())
    assert field.negated == String()


# Generated at 2022-06-18 12:09:13.771918
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:23.615086
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    field.validate(value=None)
    field.validate(value=1)
    field.validate(value="a")
    field.validate(value=True)
    field.validate(value=False)
    field.validate(value=[])
    field.validate(value={})
    field.validate(value=())
    field.validate(value=set())
    field.validate(value=frozenset())
    field.validate(value=range(0))
    field.validate(value=range(1))
    field.validate(value=range(2))
    field.validate(value=range(3))
    field.validate(value=range(4))
    field.validate(value=range(5))


# Generated at 2022-06-18 12:09:27.076229
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False
    # Perform the test
    result = OneOf(one_of).validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:09:34.626388
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate("1") == "1"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate({"a": 1}) == {"a": 1}
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:09:38.657807
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem

    class MyType(Type):
        field = AllOf([String(), String()])

    ts = TypeSystem()
    ts.add_type(MyType)
    assert ts.validate(MyType, {"field": "test"}) == {"field": "test"}


# Generated at 2022-06-18 12:09:40.472153
# Unit test for constructor of class AllOf
def test_AllOf():
    all_of = [Field()]
    assert AllOf(all_of).all_of == all_of


# Generated at 2022-06-18 12:09:41.346387
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:09:42.142290
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:09:49.893035
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:10:57.382876
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Any())

# Generated at 2022-06-18 12:11:03.322259
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:11:08.651170
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause

# Generated at 2022-06-18 12:11:13.068282
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:11:17.539768
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    field = IfThenElse(Any(), Any(), Any())
    assert field.if_clause.__class__.__name__ == 'Any'
    assert field.then_clause.__class__.__name__ == 'Any'
    assert field.else_clause.__class__.__name__ == 'Any'

# Generated at 2022-06-18 12:11:19.025212
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:11:24.444122
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.1) == 1.1
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:11:26.024960
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None

# Generated at 2022-06-18 12:11:31.834623
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:11:33.203736
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}
