

# Generated at 2022-06-18 12:02:25.544071
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == 1
    assert if_then_else.validate(1, strict=True) == 1

# Generated at 2022-06-18 12:02:31.364859
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem import Integer, String

    field = OneOf([Integer(), String()])
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    try:
        field.validate(None)
        assert False
    except Exception as e:
        assert str(e) == "Did not match any valid type."
    try:
        field.validate(1.0)
        assert False
    except Exception as e:
        assert str(e) == "Matched more than one type."


# Generated at 2022-06-18 12:02:40.248659
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Float
    from typesystem.fields import Boolean
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Any
    from typesystem.fields import NeverMatch
    from typesystem.fields import OneOf
    from typesystem.fields import AllOf
    from typesystem.fields import Not
    from typesystem.fields import IfThenElse
    from typesystem.fields import Enum
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Duration
    from typesystem.fields import Email
    from typesystem.fields import UUID
    from typesystem.fields import URL
    from typesystem.fields import Choice

# Generated at 2022-06-18 12:02:47.768547
# Unit test for method validate of class Not
def test_Not_validate():
    from typesystem import Integer

    field = Not(Integer())
    assert field.validate(1) == 1
    assert field.validate("1") == "1"
    assert field.validate(None) == None
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.1) == 1.1
    assert field.validate(1.1 + 1.1j) == 1.1 + 1.1j
    assert field.validate([1, 2, 3]) == [1, 2, 3]
    assert field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}

# Generated at 2022-06-18 12:02:49.286292
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:02:58.872348
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MinLength

    class MyType(Type):
        field = IfThenElse(
            if_clause=String(validators=[MinLength(3)]),
            then_clause=String(validators=[MinLength(5)]),
            else_clause=String(validators=[MinLength(1)]),
        )

    try:
        MyType({"field": "ab"})
    except ValidationError as e:
        assert e.error_code == "min_length"
        assert e.error_message == "Must be at least 5 characters."
    else:
        assert False, "Should have raised ValidationError"


# Generated at 2022-06-18 12:03:02.284127
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case data
    not_ = Not(negated=Field())
    value = 'value'
    strict = False
    # Perform the test
    result = not_.validate(value, strict)
    # Verify the results
    assert result is value



# Generated at 2022-06-18 12:03:04.500428
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Field())
    value = None
    strict = False
    assert field.validate(value, strict) == value


# Generated at 2022-06-18 12:03:14.005684
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:03:23.109064
# Unit test for method validate of class Not

# Generated at 2022-06-18 12:03:26.958424
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:03:29.468615
# Unit test for constructor of class Not
def test_Not():
    field = Not(negated=None)
    assert field.negated == None
    assert field.errors == {"negated": "Must not match."}


# Generated at 2022-06-18 12:03:39.456509
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test for method validate of class OneOf
    # Tests for the case when the value matches one of the sub-items
    field = OneOf([String(), Integer()])
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    # Tests for the case when the value matches multiple sub-items
    field = OneOf([String(), Integer()])
    with pytest.raises(ValidationError) as excinfo:
        field.validate(123.0)
    assert excinfo.value.code == "multiple_matches"
    # Tests for the case when the value matches none of the sub-items
    field = OneOf([String(), Integer()])
    with pytest.raises(ValidationError) as excinfo:
        field.validate(True)

# Generated at 2022-06-18 12:03:45.941077
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = OneOf([String(), String()])
    assert field.validate("hello") == "hello"
    try:
        field.validate(1)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate("hello", strict=True)
        assert False
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:03:49.454610
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    field = IfThenElse(
        if_clause=Any(),
        then_clause=Any(),
        else_clause=Any()
    )
    assert field.validate(1) == 1
    assert field.validate(1, strict=True) == 1


# Generated at 2022-06-18 12:04:01.190840
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.types import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.validators import MaxLength

    class TestIfThenElse(IfThenElse):
        def __init__(self, **kwargs):
            super().__init__(if_clause=Integer(), then_clause=String(max_length=10), else_clause=String(max_length=20), **kwargs)

    test_if_then_else = TestIfThenElse()
    assert test_if_then_else.validate(1) == "1"
    assert test_if_then_else.validate("1234567890") == "1234567890"

# Generated at 2022-06-18 12:04:02.508929
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:04:12.832173
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test with if_clause
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(None)

    # Test with then_clause
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(None)

    # Test with else_clause
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()

# Generated at 2022-06-18 12:04:15.047876
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([])
    assert field.validate(None) is None


# Generated at 2022-06-18 12:04:16.746950
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:23.974962
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with valid input
    field = OneOf([Any()])
    assert field.one_of == [Any()]
    # Test with invalid input
    try:
        field = OneOf([Any()], allow_null=True)
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-18 12:04:29.808136
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:04:30.597756
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:04:31.357112
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:04:35.238140
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    if_clause = String()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("test") == "test"

# Generated at 2022-06-18 12:04:38.754686
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    from typesystem.types import Type
    from typesystem.types import TypeSystem

    class MyType(Type):
        field = AllOf([String(), String()])

    ts = TypeSystem()
    ts.add_type(MyType)


# Generated at 2022-06-18 12:04:43.477372
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case data
    one_of = [Field()]
    value = None
    strict = False
    one_of_instance = OneOf(one_of)
    # Perform the test
    result = one_of_instance.validate(value, strict)
    # Validate the results
    assert result is None


# Generated at 2022-06-18 12:04:45.365688
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:04:46.291308
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:04:47.180284
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:05:01.827881
# Unit test for method validate of class Not
def test_Not_validate():
    # Test for method validate (line 527)
    field = Not(String())
    field.validate("hello")
    field.validate(None)
    field.validate(False)
    field.validate(True)
    field.validate(1)
    field.validate(1.0)
    field.validate([])
    field.validate({})
    field.validate(b"hello")
    with pytest.raises(ValidationError) as excinfo:
        field.validate("hello")
    assert excinfo.value.code == "negated"
    assert excinfo.value.field == field
    assert excinfo.value.value == "hello"
    with pytest.raises(ValidationError) as excinfo:
        field.validate(None)
    assert excinfo.value

# Generated at 2022-06-18 12:05:12.415805
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test with if_clause, then_clause and else_clause
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    if_then_else.validate(None)

    # Test with if_clause, then_clause and no else_clause
    if_clause = Field()
    then_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause)
    if_then_else.validate(None)

    # Test with if_clause and no then_clause and no else_clause
    if_clause = Field()
    if_then_else = IfThenElse

# Generated at 2022-06-18 12:05:22.511277
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:05:27.894375
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    class TestOneOf(OneOf):
        def __init__(self, one_of: typing.List[Field], **kwargs: typing.Any) -> None:
            super().__init__(one_of, **kwargs)

    one_of = [Field(), Field()]
    test_one_of = TestOneOf(one_of)
    assert test_one_of.validate(1) == 1


# Generated at 2022-06-18 12:05:33.689681
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Arrange
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    value = "value"
    strict = False

    # Act
    if_then_else.validate(value, strict)

    # Assert
    assert True

# Generated at 2022-06-18 12:05:35.455506
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:05:39.240007
# Unit test for constructor of class OneOf
def test_OneOf():
    # Test with a valid list of fields
    field = OneOf([Any()])
    assert field.one_of == [Any()]

    # Test with an invalid list of fields
    try:
        field = OneOf([])
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-18 12:05:41.892404
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    a = AllOf([String()])
    assert a.all_of == [String()]


# Generated at 2022-06-18 12:05:53.430312
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Integer
    from typesystem.types import Number
    from typesystem.types import String as StringType
    from typesystem.types import Boolean
    from typesystem.types import Array
    from typesystem.types import Object
    from typesystem.types import DateTime
    from typesystem.types import Any
    from typesystem.types import Enum
    from typesystem.types import Union
    from typesystem.types import Reference
    from typesystem.types import Link
    from typesystem.types import UUID
    from typesystem.types import Email
    from typesystem.types import URL
    from typesystem.types import IPv4
    from typesystem.types import IPv6
    from typesystem.types import IPvAny

# Generated at 2022-06-18 12:06:03.532129
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestIfThenElse(IfThenElse):
        def __init__(self, if_clause: Field, then_clause: Field = None, else_clause: Field = None, **kwargs: typing.Any) -> None:
            super().__init__(if_clause, then_clause, else_clause, **kwargs)
    from typesystem.fields import String
    if_clause = String()
    then_clause = String()
    else_clause = String()
    test_ifthenelse = TestIfThenElse(if_clause, then_clause, else_clause)
    assert test_ifthenelse.validate("") == ""
    assert test_ifthenelse.validate("") == ""

# Generated at 2022-06-18 12:06:17.393891
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import Integer
    from typesystem.exceptions import ValidationError
    from typesystem.types import String

    # Test for if_clause is True
    if_clause = String(max_length=5)
    then_clause = Integer()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate("hello") == 0
    assert if_then_else.validate("hello world") == "hello world"

    # Test for if_clause is False
    if_clause = String(max_length=5)
    then_clause = Integer()
    else_clause = String()

# Generated at 2022-06-18 12:06:18.280347
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:06:23.057242
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([
        String(),
        Integer(),
        Boolean()
    ])
    assert field.validate('hello') == 'hello'
    assert field.validate(1) == 1
    assert field.validate(True) == True
    try:
        field.validate(1.1)
    except Exception as e:
        assert str(e) == 'Did not match any valid type.'


# Generated at 2022-06-18 12:06:24.924216
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:06:25.855603
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:06:35.249664
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    class TestIfThenElse(IfThenElse):
        def __init__(self, if_clause, then_clause, else_clause):
            super().__init__(if_clause, then_clause, else_clause)

    class TestIfClause(Field):
        def __init__(self, if_clause):
            super().__init__()
            self.if_clause = if_clause

        def validate(self, value, strict=False):
            if value == self.if_clause:
                return value
            else:
                raise self.validation_error("if_clause")

    class TestThenClause(Field):
        def __init__(self, then_clause):
            super().__init__()
            self.then_clause = then_clause


# Generated at 2022-06-18 12:06:43.785038
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}
    assert not_field.validate(()) == ()
    assert not_field.validate(set()) == set()
    assert not_field.validate(frozenset()) == frozenset()
    assert not_field.validate(bytearray()) == bytearray()
    assert not_field.validate(memoryview(b"")) == memoryview(b"")

# Generated at 2022-06-18 12:06:48.635071
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    field = OneOf([String(), String()])
    try:
        field.validate("test")
    except ValidationError as e:
        assert e.code == "multiple_matches"
        assert e.message == "Matched more than one type."
    else:
        assert False, "Expected ValidationError"


# Generated at 2022-06-18 12:06:50.396097
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(negated=Field())
    assert not_field.negated is not None

# Generated at 2022-06-18 12:06:57.135919
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate([1, 2, 3]) == [1, 2, 3]
    assert not_field.validate({"a": 1, "b": 2}) == {"a": 1, "b": 2}


# Generated at 2022-06-18 12:07:07.776886
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.if_clause == if_clause
    assert if_then_else.then_clause == then_clause
    assert if_then_else.else_clause == else_clause


# Generated at 2022-06-18 12:07:09.496749
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf(all_of=[])
    assert field.all_of == []


# Generated at 2022-06-18 12:07:10.800121
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch().errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:07:11.698358
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    assert NeverMatch()


# Generated at 2022-06-18 12:07:12.652932
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:07:14.333177
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:15.624338
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=None)

# Generated at 2022-06-18 12:07:21.470529
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) is None
    assert not_field.validate(1) == 1
    assert not_field.validate("a") == "a"
    assert not_field.validate(True) is True
    assert not_field.validate(False) is False
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:07:32.892288
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(String())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate("1") == "1"
    assert not_field.validate("a") == "a"
    assert not_field.validate("a1") == "a1"
    assert not_field.validate("1a") == "1a"
    assert not_field.validate("a1b2c3") == "a1b2c3"
    assert not_field.validate("123") == "123"
    assert not_field.validate("abc") == "abc"
    assert not_field.validate("abc123") == "abc123"
    assert not_

# Generated at 2022-06-18 12:07:34.821995
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf(one_of=[])
    assert field.validate(1) == 1


# Generated at 2022-06-18 12:07:44.445820
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:07:48.087553
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    from typesystem.fields import String
    from typesystem.types import Error
    field = OneOf([String()])
    assert field.validate("test") == "test"
    assert isinstance(field.validate(1), Error)
    assert isinstance(field.validate(None), Error)


# Generated at 2022-06-18 12:07:49.606605
# Unit test for constructor of class IfThenElse
def test_IfThenElse():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any())

# Generated at 2022-06-18 12:07:51.692442
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import String
    all_of = AllOf([String()])
    assert all_of.all_of == [String()]


# Generated at 2022-06-18 12:07:52.247070
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])

# Generated at 2022-06-18 12:08:02.048202
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([Any(), Any()])
    field.validate(1)
    field.validate(1.1)
    field.validate("1")
    field.validate(True)
    field.validate(None)
    field.validate([1, 2, 3])
    field.validate({'a': 1, 'b': 2})
    field.validate(set([1, 2, 3]))
    field.validate(frozenset([1, 2, 3]))
    field.validate(range(1, 10))
    field.validate(b'1')
    field.validate(bytearray(b'1'))
    field.validate(memoryview(b'1'))
    field.validate(1 + 1j)

# Generated at 2022-06-18 12:08:11.985962
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    # Test case 1
    field = OneOf([Any()])
    value = "test"
    strict = False
    result = field.validate(value, strict)
    assert result == value

    # Test case 2
    field = OneOf([Any()])
    value = "test"
    strict = True
    result = field.validate(value, strict)
    assert result == value

    # Test case 3
    field = OneOf([Any()])
    value = None
    strict = False
    result = field.validate(value, strict)
    assert result == value

    # Test case 4
    field = OneOf([Any()])
    value = None
    strict = True
    result = field.validate(value, strict)
    assert result == value

    # Test case 5
    field = OneOf([Any()])

# Generated at 2022-06-18 12:08:22.043247
# Unit test for method validate of class OneOf

# Generated at 2022-06-18 12:08:23.039991
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:08:30.914419
# Unit test for method validate of class OneOf
def test_OneOf_validate():
    field = OneOf([String(), Integer()])
    assert field.validate("hello") == "hello"
    assert field.validate(123) == 123
    try:
        field.validate(123.4)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(None)
        assert False
    except ValidationError as e:
        assert e.code == "no_match"
    try:
        field.validate(["hello", "world"])
        assert False
    except ValidationError as e:
        assert e.code == "multiple_matches"


# Generated at 2022-06-18 12:08:43.307225
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:08:52.930037
# Unit test for constructor of class AllOf
def test_AllOf():
    from typesystem.fields import Integer
    from typesystem.fields import String
    from typesystem.fields import Array
    from typesystem.fields import Object
    from typesystem.fields import Boolean
    from typesystem.fields import Number
    from typesystem.fields import DateTime
    from typesystem.fields import Date
    from typesystem.fields import Time
    from typesystem.fields import Enum
    from typesystem.fields import UUID
    from typesystem.fields import URL
    from typesystem.fields import Email
    from typesystem.fields import IPv4
    from typesystem.fields import IPv6
    from typesystem.fields import IPv46
    from typesystem.fields import CIDR
    from typesystem.fields import MACAddress
    from typesystem.fields import Slug
    from typesystem.fields import Choice
    from typesystem.fields import File
   

# Generated at 2022-06-18 12:09:02.300332
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:09:09.502613
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test that if_clause is validated
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    if_clause.validate = MagicMock()
    if_clause.validate_or_error = MagicMock(return_value=(None, None))
    then_clause.validate = MagicMock()
    else_clause.validate = MagicMock()
    IfThenElse(if_clause, then_clause, else_clause).validate(None)
    if_clause.validate_or_error.assert_called_once()
    then_clause.validate.assert_called_once()
    else_clause.validate.assert_not_called()

    # Test that else_clause is validated
    if_cl

# Generated at 2022-06-18 12:09:19.643686
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(1) == 1
    assert field.validate(None) == None
    assert field.validate("") == ""
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:09:20.602363
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:09:22.204264
# Unit test for constructor of class Not
def test_Not():
    not_field = Not(Any())
    assert not_field.negated == Any()


# Generated at 2022-06-18 12:09:29.982075
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:09:37.364732
# Unit test for method validate of class Not
def test_Not_validate():
    # Test case 1
    negated = Field(name="negated")
    field = Not(negated)
    value = "value"
    strict = False
    expected = "value"
    actual = field.validate(value, strict)
    assert actual == expected
    # Test case 2
    negated = Field(name="negated")
    field = Not(negated)
    value = "value"
    strict = False
    expected = "value"
    actual = field.validate(value, strict)
    assert actual == expected
    # Test case 3
    negated = Field(name="negated")
    field = Not(negated)
    value = "value"
    strict = False
    expected = "value"
    actual = field.validate(value, strict)
    assert actual == expected
    # Test case

# Generated at 2022-06-18 12:09:38.848802
# Unit test for constructor of class NeverMatch
def test_NeverMatch():
    field = NeverMatch()
    assert field.errors == {"never": "This never validates."}


# Generated at 2022-06-18 12:10:02.858140
# Unit test for method validate of class Not
def test_Not_validate():
    # Create a Not object
    not_object = Not(negated=Any())
    # Test the validate method
    assert not_object.validate(1) == 1
    assert not_object.validate(None) == None
    assert not_object.validate('a') == 'a'
    assert not_object.validate(True) == True
    assert not_object.validate(False) == False
    assert not_object.validate(1.0) == 1.0
    assert not_object.validate([1, 2, 3]) == [1, 2, 3]
    assert not_object.validate({'a': 1, 'b': 2}) == {'a': 1, 'b': 2}


# Generated at 2022-06-18 12:10:03.585166
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:10:12.457827
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = False
    expected = Field()
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = True
    expected = Field()
    actual = IfThenElse(if_clause, then_clause, else_clause).validate(value, strict)
    assert actual == expected

    # Test case 3
    if_clause = Field()
    then_clause = Field()
    else_

# Generated at 2022-06-18 12:10:13.330502
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:10:22.982210
# Unit test for constructor of class OneOf
def test_OneOf():
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.types import IntegerType
    from typesystem.types import FloatType
    from typesystem.types import BooleanType
    from typesystem.types import ArrayType
    from typesystem.types import ObjectType
    from typesystem.types import DateTimeType
    from typesystem.types import DateType
    from typesystem.types import TimeType
    from typesystem.types import UUIDType
    from typesystem.types import EnumType
    from typesystem.types import AnyType
    from typesystem.types import UnionType
    from typesystem.types import AllOfType
    from typesystem.types import OneOfType
    from typesystem.types import NotType
    from typesystem.types import IfThenElseType
    from typesystem.types import NeverMatchType

# Generated at 2022-06-18 12:10:31.053329
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(Any())
    assert not_field.validate(1) == 1
    assert not_field.validate(None) == None
    assert not_field.validate("") == ""
    assert not_field.validate(True) == True
    assert not_field.validate(False) == False
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(1.0) == 1.0

# Generated at 2022-06-18 12:10:32.041515
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf([])


# Generated at 2022-06-18 12:10:37.090975
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem import Integer, String
    if_clause = Integer()
    then_clause = String()
    else_clause = String()
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(1) == "1"
    assert if_then_else.validate("1") == "1"

# Generated at 2022-06-18 12:10:44.552427
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(Any())
    assert field.validate(None) is None
    assert field.validate(1) == 1
    assert field.validate("") == ""
    assert field.validate(True) is True
    assert field.validate(False) is False
    assert field.validate(1.0) == 1.0
    assert field.validate(1.0j) == 1.0j
    assert field.validate(1+1j) == 1+1j
    assert field.validate(1+1j) == 1+1j
    assert field.validate(1+1j) == 1+1j
    assert field.validate(1+1j) == 1+1j
    assert field.validate(1+1j) == 1+1j

# Generated at 2022-06-18 12:10:46.482490
# Unit test for constructor of class AllOf
def test_AllOf():
    field = AllOf([])
    assert field.all_of == []


# Generated at 2022-06-18 12:11:27.867179
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.types import Boolean
    from typesystem.types import Integer

    if_clause = Boolean()
    then_clause = String()
    else_clause = Integer()
    field = IfThenElse(if_clause, then_clause, else_clause)

    # Test case 1: if_clause is True
    value = True
    result = field.validate(value)
    assert result == value

    # Test case 2: if_clause is False
    value = False
    result = field.validate(value)
    assert result == value

    # Test case 3: if_clause is not a boolean
    value = 'abc'

# Generated at 2022-06-18 12:11:28.651463
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:11:36.146861
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1
    assert IfThenElse(if_clause=Any(), then_clause=Any(), else_clause=Any()).validate(1) == 1

# Generated at 2022-06-18 12:11:37.335891
# Unit test for constructor of class AllOf
def test_AllOf():
    assert AllOf(all_of=[])


# Generated at 2022-06-18 12:11:44.977821
# Unit test for method validate of class IfThenElse
def test_IfThenElse_validate():
    # Test case 1
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = False
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(value, strict) == value

    # Test case 2
    if_clause = Field()
    then_clause = Field()
    else_clause = Field()
    value = Field()
    strict = True
    if_then_else = IfThenElse(if_clause, then_clause, else_clause)
    assert if_then_else.validate(value, strict) == value

# Generated at 2022-06-18 12:11:52.350952
# Unit test for method validate of class Not
def test_Not_validate():
    field = Not(negated=Any())
    assert field.validate(None) == None
    assert field.validate(1) == 1
    assert field.validate(1.1) == 1.1
    assert field.validate("1") == "1"
    assert field.validate(True) == True
    assert field.validate(False) == False
    assert field.validate([]) == []
    assert field.validate({}) == {}
    assert field.validate(set()) == set()
    assert field.validate(()) == ()
    assert field.validate(range(0)) == range(0)
    assert field.validate(bytearray()) == bytearray()
    assert field.validate(memoryview(b"")) == memoryview(b"")

# Generated at 2022-06-18 12:11:53.052062
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())

# Generated at 2022-06-18 12:11:57.011996
# Unit test for method validate of class Not
def test_Not_validate():
    not_field = Not(negated=Any())
    assert not_field.validate(None) == None
    assert not_field.validate(1) == 1
    assert not_field.validate(1.0) == 1.0
    assert not_field.validate(True) == True
    assert not_field.validate("") == ""
    assert not_field.validate([]) == []
    assert not_field.validate({}) == {}


# Generated at 2022-06-18 12:11:57.864839
# Unit test for constructor of class OneOf
def test_OneOf():
    assert OneOf([])


# Generated at 2022-06-18 12:11:58.656449
# Unit test for constructor of class Not
def test_Not():
    assert Not(negated=Field())