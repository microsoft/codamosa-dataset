

# Generated at 2022-06-11 12:57:47.968758
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import os
    import pytest
    import time

    display = Display()

    fake_ansible_module = FakeAnsibleModule('WaitForConnection', display)
    fake_ansible_module._options = {
        # "connection": None,
        # "remote_user": None,
        # "remote_pass": None,
        # "private_key_file": None,
        # "timeout": 10,
        # "ssh_common_args": None,
        # "sftp_extra_args": None,
        # "scp_extra_args": None,
        # "ssh_extra_args": None,
    }

    fake_ansible_module._remote_pass = None
    fake_ansible_module._remote_user = None


# Generated at 2022-06-11 12:57:56.946618
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager

    play_context = Play().load({}, variable_manager={}, loader=None)
    play_context.connection = "local"

    tqm = TaskQueueManager(
        inventory=None,
        variable_manager=None,
        loader=None,
        options=None,
        passwords=None,
        stdout_callback=None,
    )

    # required args

# Generated at 2022-06-11 12:58:04.940647
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.wait_for_connection import ActionModule
    from ansible.utils.display import Display
    Display().verbosity = 4
    module_result = dict(
        ping='pong',
        msg='',
        skipped=False
    )
    class MockTask():
        args = dict()
        def __init__(self):
            self.args = dict()
        def get_vars(self):
            return dict()

    class MockPlayContext():
        check_mode = False

    class MockConnection():
        def reset(self):
            pass
        def transport_test(self, connect_timeout):
            pass

    class MockExecuteModule():
        def execute_module(params, tmp, task_vars):
            return module_result


# Generated at 2022-06-11 12:58:12.540110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import json

    module = ActionModule()

    # Test default timeout
    module.run()

    display.vvv("wait_for_connection: skipping for check_mode")
    assert module.run() == dict(skipped=True)

    # Test success
    def ping_module_test(connect_timeout):
        ''' Test ping module, if available '''
        print("attempting ping module test")
        # re-run interpreter discovery if we ran it in the first iteration
        if module._discovered_interpreter_key:
            print("poping key")
            task_vars['ansible_facts'].pop(module._discovered_interpreter_key, None)
        # call connection reset between runs if it's there
        try:
            module._connection.reset()
        except AttributeError:
            pass
       

# Generated at 2022-06-11 12:58:20.267085
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Create an instance of class ActionModule
    am = ActionModule()
    start_time = datetime.now()

    # Set current time
    am.datetime = start_time

    # Create a function that returns true after 2 calls
    def boolean_function(timeout):
        boolean_function.counter += 1
        if boolean_function.counter > 1:
            return True
        else:
            raise Exception("Test exception")

    # Reset counter
    boolean_function.counter = 0

    # Call do_until_success_or_timeout
    try:
        am.do_until_success_or_timeout(boolean_function, 1, 1, 'boolean_function', 1)
    except TimedOutException as e:
        end_time = datetime.now()
        # The execution should not timeout
        assert(False)

   

# Generated at 2022-06-11 12:58:30.013512
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action.wait_for import ActionModule
    import pprint
    import time

    mock_play_context = None
    task_vars = dict()
    tmp = None

    # Required in order to process time.sleep() during tests
    time.sleep = lambda x: None

    task_vars['ansible_facts'] = dict()
    a = ActionModule(mock_play_context, dict(timeout=1))
    a._discovered_interpreter_key = "EXECUTABLE_KEY"

    # PY3 compatibility: ensure that the exception string is a text object
    class CustomException(Exception):
        def __str__(self):
            return "CustomException string"

    class MockConnection():
        def __init__(self):
            self.connected = False


# Generated at 2022-06-11 12:58:38.503366
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from unittest.mock import Mock
    from unittest.mock import patch

    task_vars={}
    module_args={}
    display_mock = Mock(return_value=None)
    with patch.object(ActionModule, 'run', return_value=dict(failed=False)), \
            patch.object(display, 'debug', display_mock):
        instance = ActionModule()

        def no_error():
            print('no error')

        def timeout_exception():
            raise TimedOutException('test-timeout')

        timeout = 10
        # 1st, only delay

# Generated at 2022-06-11 12:58:40.841834
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    c = {}
    args = {'connect_timeout': None, 'delay': None, 'sleep': None, 'timeout': None}
    m = ActionModule(c, args)
    print(m.run(c))

# Generated at 2022-06-11 12:58:45.137250
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule(None, None, None, None)
    a.DEFAULT_CONNECT_TIMEOUT = 5
    a.DEFAULT_DELAY = 0
    a.DEFAULT_SLEEP = 1
    a.DEFAULT_TIMEOUT = 600
    assert a.TRANSFERS_FILES == False
    assert a._VALID_ARGS == frozenset('connect_timeout', 'delay', 'sleep', 'timeout')

# Generated at 2022-06-11 12:58:53.804430
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Replace the module class and test the method directly
    # Earlier, this was implemented by mocking the module class and then testing the method
    # mock wasn't compatible with python3 and hence the switch.
    # Below are the inputs and expected outputs in this test

    # nargs is the number of inputs
    nargs = 2
    if nargs <1:
        print("Invalid number of arguments")
        sys.exit(1)

    # Read connection, task_vars and timeout from command line
    connection = None
    task_vars = {}
    timeout = 0
    delay = 0
    sleep = 1
    connect_timeout = 5