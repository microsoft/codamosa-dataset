

# Generated at 2022-06-11 12:56:43.693158
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # Test passing all valid args.
    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)


# Generated at 2022-06-11 12:56:48.152744
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=object(), connection=object(), play_context=object(), loader=object(), templar=object(), shared_loader_obj=object())

    expected_fields = ['elapsed', 'failed', 'invocation', 'stdout_lines', 'warnings']
    for k in expected_fields:
        assert k in module.run()


# Generated at 2022-06-11 12:56:56.375257
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from unittest import mock

    am = ActionModule()
    am.DEFAULT_SLEEP = 0

    then = time.time()
    with mock.patch('ansible.plugins.action.ActionModule.Datetime') as mockclass:
        mockclass.utcnow.return_value = then
        mockclass.side_effect = lambda *args, **kw: datetime(*args, **kw)
        with mock.patch('ansible.plugins.action.ActionBase._execute_module') as mockmethod:
            mockmethod.return_value = dict(ping='pong')
            am.do_until_success_or_timeout(mock.MagicMock(), timeout=0, connect_timeout=0, what_desc='ping module test')
            # we allow 0.1 secs tolerance to account for possible time skew

# Generated at 2022-06-11 12:56:58.919954
# Unit test for constructor of class ActionModule
def test_ActionModule():

    # Unit test for constructor of class ActionModule
    assert ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-11 12:57:06.912110
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import os
    import sys
    import json
    from ansible.plugins.action import ActionBase
    from ansible.executor.task_result import TaskResult
    x = ActionModule()
    play_context = x.get_play_context(None)
    dest = '/root/.ansible/tmp/ansible-tmp-1536946585.132731-108317835773285/'
    try:
        os.makedirs(dest)
    except: pass
    file = 'test_ActionModule_run-stdout.log'
    filepath = os.path.join(dest, file)

# Generated at 2022-06-11 12:57:07.965972
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = ActionModule()
    assert a


# Generated at 2022-06-11 12:57:08.881892
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule()

# Generated at 2022-06-11 12:57:09.664704
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-11 12:57:18.453218
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    _ActionModule = ActionModule()

    def mock_run(tmp, task_vars):
        return {'result': 1}

    _ActionModule.run = mock_run

    def mock_can_defer(self):
        return False

    _ActionModule._can_defer_connect = mock_can_defer

    # _connection is a RemoteMachine, defined in parent class ActionBase
    class _RemoteMachine:
        pass

    _ActionModule._connection = _RemoteMachine()

    # _remove_tmp_path is defined in parent class ActionBase
    def mock_remove_tmp_path(self, path):
        return

    _ActionModule._remove_tmp_path = mock_remove_tmp_path
    assert _ActionModule.run(None, None) == {'result': 1}

# Generated at 2022-06-11 12:57:18.978441
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert True