

# Generated at 2022-06-25 08:11:43.915415
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    list_0 = []
    dict_0 = {}
    timed_out_exception_0 = TimedOutException(*list_0)
    timed_out_exception_1 = TimedOutException(*list_0)
    timed_out_exception_2 = TimedOutException(*list_0)
    timed_out_exception_3 = TimedOutException(*list_0)
    timed_out_exception_4 = TimedOutException(*list_0)
    timed_out_exception_5 = TimedOutException(*list_0)
    timed_out_exception_6 = TimedOutException(*list_0)
    timed_out_exception_7 = TimedOutException(*list_0)
    # Test method with various argument combination
    # Test case with what of int type and other argument as default argument


# Generated at 2022-06-25 08:11:49.557919
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # mock of argument tmp
    tmp = None
    task_vars = dict()

    ActionModule_0 = ActionModule()

    # test_case_0
    list_0 = []
    timed_out_exception_0 = TimedOutException(*list_0)
    task_vars['ansible_facts'] = dict()
    result = ActionModule_0.run(tmp=tmp, task_vars=task_vars)
    assert result['skipped']
    assert result['msg'] == "skipping for check_mode"
    # test_case_1
    task_vars['ansible_facts'] = dict()
    result = ActionModule_0.run(tmp=tmp, task_vars=task_vars)
    assert result['skipped']

# Generated at 2022-06-25 08:11:56.864867
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Setup
    tmp = None
    task_vars = None
    # The method run should return either a dictionary or None
    assert isinstance(ActionModule.run(None, tmp, task_vars), (dict, type(None)))


# Generated at 2022-06-25 08:12:01.960501
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    ping_module_test_0 = ActionModule()
    connect_timeout_0 = 5
    timeout_0 = 600
    what_desc_0 = 'connection port up'
    sleep_0 = 1
    ping_module_test_0.do_until_success_or_timeout(timeout_0, connect_timeout_0, what_desc_0, sleep_0)


# Generated at 2022-06-25 08:12:07.553748
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.connection import Connection
    action_module_0 = ActionModule(task=None, connection=Connection(play_context=None, new_stdin=None), ansible_version_info=None, ansible_facts=Facts())
    try:
        action_module_0.do_until_success_or_timeout(test_case_0, 5, 2, 'test_case_0_0', 3)
    except TimedOutException as e:
        pass
    except Exception as e:
        raise
    try:
        action_module_0.run()
    except Exception as e:
        raise

if __name__ == "__main__":
    test_ActionModule()

# Generated at 2022-06-25 08:12:17.940873
# Unit test for constructor of class ActionModule
def test_ActionModule():
    host_0 = {}
    task_0 = {}
    connection_0 = {}
    play_context_0 = {}
    loader_0 = {}
    templar_0 = {}
    shared_loader_obj_0 = ActionModule(host_0, task_0, connection_0, play_context_0, loader_0, templar_0, shared_loader_obj_0)
    tmp_0 = {}
    task_vars_0 = {}
    result_0 = ActionModule.run(shared_loader_obj_0, tmp_0, task_vars_0)
    assert result_0['skipped']
    tmp_1 = {}
    task_vars_1 = {}
    result_1 = ActionBase.run(shared_loader_obj_0, tmp_1, task_vars_1)
