

# Generated at 2022-06-25 08:11:12.223449
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    a = ActionModule()
    a.do_until_success_or_timeout()
    a.do_until_success_or_timeout(what=None)

# Generated at 2022-06-25 08:11:18.715764
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    time.sleep_0 = time.sleep
    time.sleep = test_case_0
    datetime_utcnow_0 = datetime.utcnow
    datetime.utcnow = test_case_0
    timedelta_seconds_0 = timedelta.seconds
    timedelta.seconds = test_case_0
    datetime_now_0 = datetime.now
    datetime.now = test_case_0
    timedelta_0 = timedelta
    timedelta = test_case_0
    datetime_0 = datetime
    datetime = test_case_0
    to_text_0 = to_text
    to_text = test_case_0
    module = ActionModule()

    # Test function run() with required arguments
    module.run(tmp=None, task_vars=None)

    time

# Generated at 2022-06-25 08:11:26.864539
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_obj = ActionModule()

    e = Exception()
    action_module_obj.do_until_success_or_timeout(test_case_0, 10, 3, "test", 1)
    action_module_obj.do_until_success_or_timeout(test_case_0, 10, 3, "test", 1)

    action_module_obj.do_until_success_or_timeout(test_case_0, 0, 3, "test", 1)
    action_module_obj.do_until_success_or_timeout(test_case_0, 0, 3, "test", 1)

# Generated at 2022-06-25 08:11:31.107022
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_case_0()

# Generated at 2022-06-25 08:11:35.552684
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    params = {'connect_timeout': 5, 'delay': 0, 'sleep': 1, 'timeout': 600}

    # Test exception raised in do_until_success_or_timeout
    m.do_until_success_or_timeout = Mock(side_effect=TypeError())
    m._play_context = Mock()
    m._play_context.check_mode = True
    result = m.run(params)
    assert result == {'skipped': True}

# Generated at 2022-06-25 08:11:43.187119
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    try:
        raise TimedOutException()
    except TimedOutException as e:
        timed_out_exception_0 = e
    assert(timed_out_exception_0 is not None)
    assert(isinstance(timed_out_exception_0, Exception))
    assert(str(timed_out_exception_0) == "timed out waiting for : ")
    action_module_0 = ActionModule()
    try:
        action_module_0.do_until_success_or_timeout(lambda: None, 1, 1, "", 1)
        raise Exception("unreachable")
    except TimedOutException as e:
        assert(str(e) == "timed out waiting for  : ")

# Generated at 2022-06-25 08:11:44.495243
# Unit test for constructor of class ActionModule
def test_ActionModule():
    a = test_case_0()
    assert(a.TimedOutException() == TimedOutException)

# Generated at 2022-06-25 08:11:51.749491
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    timed_out_exception_0 = TimedOutException()

    task_vars_0 = make_dict()
    tmp_0 = make_temp_path()
    result_0 = ActionModule.run(timed_out_exception_0, tmp_0, task_vars_0)
    assert make_dict() == result_0

    result_0 = ActionModule.run(timed_out_exception_0, tmp_0, task_vars_0)
    assert make_dict() == result_0

    result_0 = ActionModule.run(timed_out_exception_0, tmp_0, task_vars_0)
    assert make_dict() == result_0


# Testing of private method _validate_args

# Generated at 2022-06-25 08:11:54.129859
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule()
    result = action_module.run()

# Generated at 2022-06-25 08:12:00.590317
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module_0 = ActionModule()

    # Execution
    # Execution is expected to fail

    # Execution is expected to fail
    with pytest.raises(TimedOutException) as excinfo:
        action_module_0.do_until_success_or_timeout(test_case_0, 0, 0, '')
    assert excinfo.type == TimedOutException
    assert hasattr(excinfo.value, '_VALID_ARGS')

    # Execution is expected to fail
    with pytest.raises(TimedOutException) as excinfo:
        action_module_0.run()
    assert excinfo.type == TimedOutException
    assert hasattr(excinfo.value, '_VALID_ARGS')