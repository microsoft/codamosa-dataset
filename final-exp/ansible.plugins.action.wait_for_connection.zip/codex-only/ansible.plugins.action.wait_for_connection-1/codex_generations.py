

# Generated at 2022-06-23 09:00:17.187868
# Unit test for constructor of class ActionModule
def test_ActionModule():
    x = ActionModule()
    assert type(x) is ActionModule


# Generated at 2022-06-23 09:00:22.121916
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = ActionModule(None, None, None)
    mock_execute_module_patch = ActionModule_run_ActionModule_execute_module_patch()
    mock_execute_module_patch.start()
    result = action_module.run()
    # patch.stop()

    assert result['failed'] is True


# Generated at 2022-06-23 09:00:28.340207
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import contextlib

    module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    success_counter = [0, 0]
    fail_counter = [0, 0]
    error_counter = [0, 0]

    class ExpectingException(Exception):
        pass

    class MockConnection(object):
        def transport_test(self, connect_timeout=None):
            success_counter[0] = success_counter[0] + 1
            return "success"

        def reset(self):  # noqa: E800
            success_counter[1] = success_counter[1] + 1

    @contextlib.contextmanager
    def fake_ping():
        yield

    def failing_test(connect_timeout=None):
        fail

# Generated at 2022-06-23 09:00:29.999323
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule('setup', {}, {}, None) is not None

# Generated at 2022-06-23 09:00:39.166356
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    module = ActionModule(task=dict())
    display.verbosity = 4

    module.DEFAULT_CONNECT_TIMEOUT = 0
    module.DEFAULT_DELAY = 0
    module.DEFAULT_SLEEP = 0
    module.DEFAULT_TIMEOUT = 2

    class FakeConnection:
        def __init__(self):
            self._shell = FakeShell()

        def reset(self):
            pass

        def close(self):
            pass

        def transport_test(self, connect_timeout):
            time.sleep(0.01)
            raise TimedOutException('transport up test')

    class FakeShell:
        def __init__(self):
            self.tmpdir = None

        def close(self):
            pass

    class FakeModule:
        def __init__(self):
            self._

# Generated at 2022-06-23 09:00:50.477479
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.plugins.action
    class ActionModule_run_TestCase(unittest.TestCase):
        def test_success(self):
            module = ansible.plugins.action.ActionModule(
                task=dict(action=dict(name='wait_for_connection', args=dict())),
                connection=dict(module_implementation_preferences=['ansible.legacy.ping']),
                play_context=dict(check_mode=False)
            )
            module._execute_module = lambda *args, **kwargs: dict(ping='pong')

            result = module.run(task_vars=dict())

            self.assertEqual(result, dict(failed=False, skipped=False, elapsed=0))

        def test_success_delay(self):
            import time
           

# Generated at 2022-06-23 09:00:52.880384
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException("timed out waiting for foo: bar")
    assert exception.args[0] == "timed out waiting for foo: bar"
    return exception

# Generated at 2022-06-23 09:00:54.995399
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("test")
    except TimedOutException as e:
        assert "test" in str(e)

# Generated at 2022-06-23 09:00:56.680856
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('exception message')
    except TimedOutException as e:
        assert str(e) == 'exception message'

# Generated at 2022-06-23 09:00:58.413850
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert str(TimedOutException('test')) == 'test'


# Generated at 2022-06-23 09:01:03.279850
# Unit test for constructor of class ActionModule
def test_ActionModule():
    am = ActionModule(None, None)
    assert am.name == 'wait_for_connection'
    assert am.short_description == 'waits until remote system is reachable/usable'
    assert am.deprecated == True
    assert am.version_added == None

# Generated at 2022-06-23 09:01:03.801302
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert True

# Generated at 2022-06-23 09:01:06.237634
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("this is a timeout exception")
    except TimedOutException as e:
        assert str(e) == "this is a timeout exception"

# Generated at 2022-06-23 09:01:15.038184
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import unittest
    import os

    class TestState:
        def __init__(self, test_count, success_count):
            self._test_count = test_count
            self._success_count = success_count
            self._last_result = ''

        def do_test(self, connect_timeout):
            self._test_count = self._test_count - 1
            if self._test_count >= 0:
                self._last_result = 'test failed'
                raise Exception('test failed')

            self._last_result = 'test succeeded'

        def last_result(self):
            return self._last_result

    class ActionModuleTests(unittest.TestCase):
        def test_do_until_success_or_timeout_success(self):
            mock_display = Display(verbosity=2)


# Generated at 2022-06-23 09:01:22.279626
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''
    Unit test for constructor of class ActionModule

    To run the unit test for this class, go to the directory
    where this file is located and run python3 -m unittest
    '''

    import unittest
    import sys
    import copy

    class TestActionModule(unittest.TestCase):
        '''
        Unit test class for constructor of class ActionModule
        '''

        def setUp(self):
            '''
            Creates an instance of class ActionModule
            '''
            self.action_module = ActionModule()

        def tearDown(self):
            '''
            Destroys the instance of class ActionModule
            '''
            self.action_module = None


# Generated at 2022-06-23 09:01:23.424682
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    TimedOutException(message = "test message")

# Generated at 2022-06-23 09:01:34.375393
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import sys
    import os
    import mongomock
    import mock

    class MockDisplay(object):
        def __init__(self):
            self.debug_messages = []

        def debug(self, message):
            self.debug_messages.append(message)

    class MockConnection(object):
        def __init__(self):
            self.module = mock.MagicMock()
            self._shell = mongomock.MockObject()
            self._shell.tmpdir = '/tmp'

        def reset(self):
            self.reset_called = True

        def transport_test(self):
            self.transport_test_called = True

    sys.modules['ansible'] = mongomock.MockObject()
    sys.modules['ansible'].plugins = mongomock.MockObject

# Generated at 2022-06-23 09:01:41.896093
# Unit test for constructor of class ActionModule
def test_ActionModule():
    test_action_module = ActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=dict())
    assert test_action_module.DEFAULT_CONNECT_TIMEOUT == 5
    assert test_action_module.DEFAULT_DELAY == 0
    assert test_action_module.DEFAULT_SLEEP == 1
    assert test_action_module.DEFAULT_TIMEOUT == 600


# Generated at 2022-06-23 09:01:43.669711
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("message")
    assert "message" in str(e)


# Generated at 2022-06-23 09:01:46.316385
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("some text")
    except TimedOutException as e:
        assert str(e) == "timed out: some text"

# Generated at 2022-06-23 09:01:55.162694
# Unit test for method run of class ActionModule
def test_ActionModule_run():

    # Create class instances for testing
    actionm = ActionModule()
    actionm.args = {}
    from ansible.playbook.play_context import PlayContext
    actionm._play_context = PlayContext()
    actionm._play_context.check_mode = False
    actionm._task_vars = None
    actionm.aliases = {}
    actionm.transfers_files = False

    # Test with a positive result
    expected_result_1 = {'failed': False, 'elapsed': 0, 'skipped': False}
    result_1 = actionm.run()
    assert expected_result_1 == result_1

    # Test with a negative result
    expected_result_2 = {'failed': False, 'elapsed': 0, 'skipped': False}
    result_2 = actionm.run()


# Generated at 2022-06-23 09:01:57.366409
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    # Test constructor of class TimedOutException
    exception = TimedOutException('message')
    assert str(exception) == 'message'

# Generated at 2022-06-23 09:02:01.919440
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """ Unit tests for ActionModule(). """
    module = ActionModule()
    result = module.run(tmp="Some Temp", task_vars={"Some Var": "Some Value"})
    assert "skipped" in result
    assert result["skipped"]

# Generated at 2022-06-23 09:02:11.422067
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Arrange
    class FakeConnection:
        def transport_test(self, timeout):
            pass
        def reset(self):
            pass

    # Set up ActionModule instance
    action_module = ActionModule(task=None, connection=FakeConnection())

    # Set up test values
    fake_timeout = 3
    fake_connect_timeout = 2
    fake_what_desc = "test"
    fake_error = Exception('test')
    fake_sleep = 1

    # Set up mock time.sleep function
    original_time_sleep = time.sleep
    def fake_time_sleep(x):
        if x != fake_sleep:
            raise Exception()
    time.sleep = fake_time_sleep

    # At first what will raise Exception
    def fake_what(ct):
        raise fake_error
    # Assert
   

# Generated at 2022-06-23 09:02:19.459995
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import os
    import sys
    import unittest

    from ansible.plugins.action import ActionBase

    # Mock up an object that can be used by ActionModule
    class TestActionBase(ActionBase):
        def _execute_module(self, module_name, module_args, task_vars):
            return result

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            pass

    # Create the test case class
    class TestActionModuleUnit(unittest.TestCase):

        # This is the method that is called before each unit test
        def setUp(self):
            self.am = TestActionModule(task=dict(), connection=dict(), play_context=dict(), loader=dict(), templar=dict(), shared_loader_obj=None)

        # This is

# Generated at 2022-06-23 09:02:20.862151
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    am = ActionModule()
    am.run()

# Generated at 2022-06-23 09:02:23.597566
# Unit test for constructor of class ActionModule
def test_ActionModule():
   # Test no argument constructor
   a = ActionModule()

   # Test arugment constructor
   a = ActionModule(connection=Connection())


# Generated at 2022-06-23 09:02:33.806343
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import pytest

    class MockConnection:
        def __init__(self, ping_succeeds, transport_test_succeeds, transport_test_should_raise=False):
            self.ping_succeeds = ping_succeeds
            self.transport_test_succeeds = transport_test_succeeds
            self.transport_test_should_raise = transport_test_should_raise
            self.transport_test_was_called = False
            self.reset_was_called = False

        def reset(self):
            self.reset_was_called = True

        def transport_test(self):
            self.transport_test_was_called = True
            if self.transport_test_should_raise:
                raise Exception("test exception" )
            return self.trans

# Generated at 2022-06-23 09:02:38.156247
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # The tests require json and text, which may not exist in Python 3.
    # The tests are run in Python 2.
    #
    # Test with assert_equals
    # Test with echo_welcome_to_ansible_run
    # Test with action run_command

    # Run the tests
    return True

if __name__ == '__main__':
    test_ActionModule_run()

# Generated at 2022-06-23 09:02:42.417941
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception_msg = 'Exception Message'
    exception = TimedOutException(exception_msg)
    assert exception.args[0] == exception_msg


# Generated at 2022-06-23 09:02:50.480122
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    class module_mock:
        class connection_mock:
            class _shell_mock:
                tmpdir = "/tmp/tmp.XXXXX"

            _shell = _shell_mock()
            transport = "local"

            def transport_test(self):
                pass

            def reset(self):
                raise AttributeError()

        connection = connection_mock()

    class task_mock:
        def __init__(self):
            self.args = dict(connect_timeout="5", delay="0", sleep="1", timeout="600")

    class play_context_mock:
        check_mode = False

    class display_mock:
        class Display:
            def debug(self, var):
                pass

            def vvv(self, var):
                pass

        display = Display()


# Generated at 2022-06-23 09:03:02.591213
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from ansible.plugins.action import ActionModule
    from ansible.inventory.host import Host
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.playbook.play import Play
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor.playbook_executor import PlaybookExecutor
    from ansible.utils.loader import ModuleLoader

    mock_play_context = Mock()
    mock_play_context.check_mode = False

    mock_connection = Mock()


# Generated at 2022-06-23 09:03:05.886433
# Unit test for constructor of class ActionModule
def test_ActionModule():
    '''Test the constructor of class ActionModule.'''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    action_module = ActionModule(
        connection=None,
        _config=None,
        loader=DataLoader(),
        variable_manager=VariableManager)

    assert action_module
    assert action_module._VALID_ARGS == frozenset(['connect_timeout', 'delay', 'sleep', 'timeout'])
    assert action_module.DEFAULT_CONNECT_TIMEOUT == 5
    assert action_module.DEFAULT_DELAY == 0
    assert action_module.DEFAULT_SLEEP == 1
    assert action_module.DEFAULT_TIMEOUT == 600

# Generated at 2022-06-23 09:03:14.801657
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """
    Unit test of do_until_success_or_timeout method of class ActionModule
    This test only covers the code path when the test passes.
    The code path when the test fails is not covered by this test.
    """
    my_timer_count = 0
    my_sleep_count = 0
    my_sleep_value = 0

    class MyTimer(object):
        def __init__(self, count):
            self.count = count

        def utcnow(self):
            my_timer_count += 1
            if self.count > 0:
                self.count -= 1
                return datetime.utcnow() + timedelta(seconds=99)
            else:
                return datetime.utcnow()

    class MySleep(object):
        def __init__(self, count):
            self.count = count

# Generated at 2022-06-23 09:03:24.790584
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Test the case where what succeeds
    class TestActionModule(ActionModule):
        def __init__(self):
            self.test_count = 0
        def what(self, timeout):
            self.test_count = self.test_count + 1
            if self.test_count == 1:
                raise Exception('fail')
            return
    a = TestActionModule()
    a.do_until_success_or_timeout(a.what, 2, 5, "description")
    assert a.test_count == 2

    # Test the case where what never succeeds
    class TestActionModule(ActionModule):
        def __init__(self):
            self.test_count = 0
        def what(self, timeout):
            self.test_count = self.test_count + 1
            raise Exception('fail')
    a = TestAction

# Generated at 2022-06-23 09:03:30.243604
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    action_module_instance = ActionModule()

    class TestException(Exception):
        pass

    # We test with 2 values here since it is barely possible the call will succeed
    # (the sleep hasn't been long enough) before we reach the maximum number of calls in case
    # the sleep is long.  As long as the sleep is < 1, we can be sure the call won't succeed
    # before the maximum number of calls.
    for sleep in [2, 3]:
        # We expect to call this 4 times in this test
        calls = 0

        def what(connect_timeout):
            nonlocal calls, sleep
            calls += 1
            raise TestException()

        started = datetime.utcnow()

# Generated at 2022-06-23 09:03:33.904878
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('test message')
    except TimedOutException as e:
        assert 'test message' in str(e)

# Generated at 2022-06-23 09:03:35.401270
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert str(TimedOutException('foo')) == 'foo'

# Generated at 2022-06-23 09:03:37.235659
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    '''
    Unit test for method run of class ActionModule
    '''
    print ('to do')


# Generated at 2022-06-23 09:03:37.809459
# Unit test for constructor of class ActionModule
def test_ActionModule():
    pass

# Generated at 2022-06-23 09:03:45.925826
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_taken = None
    class MyActionBase:
        def run(self):
            return action_taken
    action = ActionModule(MyActionBase())
    class MyConnection:
        def __init__(self, args, *kwargs):
            pass
        class Connection:
            def reset(self):
                pass
    class PlayContext:
        def __init__(self):
            self.check_mode = False
    class Task:
        def __init__(self):
            self.name = 'TASK'
        def get_name(self):
            return self.name
    class Play:
        def __init__(self):
            self.connection = MyConnection(args=None)
            self.play_context = PlayContext()
            self.name = 'PLAY'

# Generated at 2022-06-23 09:03:49.014014
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('Error')
    assert e.message == 'Error'
    assert str(e) == 'Error'

# Generated at 2022-06-23 09:03:51.529188
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException("test Message")
    assert str(exception) == "test Message"

# Generated at 2022-06-23 09:03:59.844677
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.action import ActionModule
    from ansible.utils.display import Display
    display = Display()
    # Create instance of ActionModule
    test_class = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # Create instance of ActionBase
    test_ActionBase_class = ActionBase()
    # Call run method of ActionBase class
    results = test_ActionBase_class.run(tmp=None, task_vars=None)
    # Call run method of ActionModule class
    results = test_class.run(tmp=None, task_vars=None)
    # Check the results
    assert(isinstance(results, dict))
    # Check type if results with key 'failed'

# Generated at 2022-06-23 09:04:10.328019
# Unit test for constructor of class ActionModule
def test_ActionModule():
    from ansible.modules.name_and_type_of_module import NameAndTypeOfModule
    a_m = ActionModule(task=NameAndTypeOfModule.task, connection=NameAndTypeOfModule.connection, play_context=NameAndTypeOfModule.play_context, loader=NameAndTypeOfModule.loader, templar=NameAndTypeOfModule.templar, shared_loader_obj=NameAndTypeOfModule.shared_loader_obj)

    assert a_m.TRANSFERS_FILES == False
    assert a_m._VALID_ARGS == frozenset({'connect_timeout', 'delay', 'sleep', 'timeout'})
    assert a_m.DEFAULT_CONNECT_TIMEOUT == 5
    assert a_m.DEFAULT_DELAY == 0
    assert a_m.DEFAULT_SLE

# Generated at 2022-06-23 09:04:11.418049
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert str(TimedOutException('foo')) == 'foo'

# Generated at 2022-06-23 09:04:18.322632
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    timedoutexception = TimedOutException()
    assert not isinstance(timedoutexception, Exception)

    # Test instance string
    if hasattr(TimedOutException, "__unicode__"):
        assert isinstance(timedoutexception.__unicode__(), unicode)
    else:
        assert isinstance(timedoutexception.__str__(), str)

# Generated at 2022-06-23 09:04:20.988520
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    test_instance = TimedOutException("test message")
    assert test_instance.message == "test message"

# Generated at 2022-06-23 09:04:30.974979
# Unit test for constructor of class ActionModule
def test_ActionModule():
    ''' Unit test for constructor of class ActionModule
    '''
    am = ActionModule(None, None)
    assert am._task.args.get('connect_timeout', am.DEFAULT_CONNECT_TIMEOUT) == am.DEFAULT_CONNECT_TIMEOUT
    assert am._task.args.get('delay', am.DEFAULT_DELAY) == am.DEFAULT_DELAY
    assert am._task.args.get('sleep', am.DEFAULT_SLEEP) == am.DEFAULT_SLEEP
    assert am._task.args.get('timeout', am.DEFAULT_TIMEOUT) == am.DEFAULT_TIMEOUT

# Generated at 2022-06-23 09:04:32.677013
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()
    m.run()
    assert True

# Generated at 2022-06-23 09:04:35.538917
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('An exception!')
    except TimedOutException as e:
        assert 'An exception!' in to_text(e)
        return True


# Generated at 2022-06-23 09:04:37.305997
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('foo')
    assert e.args[0] == 'foo'

# Generated at 2022-06-23 09:04:48.796754
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import mock

    # Mock up the _execute_module function so we can test without the actual ping module
    @mock.patch('ansible.plugins.action.wait_for.ActionModule._execute_module')
    def test_wrapper(m):
        m.return_value = {'ping': 'pong'}
        # Mock _connection because we do not have one
        mock_connection = mock.MagicMock()
        # Mock _task because we do not have one
        mock_task = mock.MagicMock()
        mock_task.args = dict()
        # Mock _play_context because we do not have one
        mock_play_context = mock.MagicMock()
        mock_play_context.check_mode = False

        # Create mocked instance

# Generated at 2022-06-23 09:04:55.181057
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule(task={
        'async': 0,
        'async_poll_interval': 10,
        'args': {'connect_timeout': 5, 'delay': 0, 'sleep': 1, 'timeout': 600},
        'delegate_to': 'localhost',
        'run_once': False,
        'module_vars': {},
        'module_name': 'action',
        'module_args': {'connect_timeout': 5, 'delay': 0, 'sleep': 1, 'timeout': 600},
        'name': 'wait_for_connection',
    }, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

# Generated at 2022-06-23 09:04:57.079373
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    timed_out_exception = TimedOutException("test")
    assert(str(timed_out_exception) == "timed out waiting for test")

# Generated at 2022-06-23 09:05:00.993783
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('test')
    assert to_text(e) == 'test', 'TimedOutException.__str__ returns message'


# Generated at 2022-06-23 09:05:10.698074
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    from action_plugins.wait_for_connection import ActionModule
    import unittest
    import sys

    class ActionModuleTest(unittest.TestCase):

        def setUp(self):
            self.actionModule = ActionModule()
            self.results = { 'failed': False }

        def do_until_success_or_timeout(self, what, timeout, connect_timeout, what_desc, sleep=1):
            # Test with success
            try:
                self.actionModule.do_until_success_or_timeout(what, timeout, connect_timeout, what_desc, sleep)
            except Exception as e:
                assert False, "do_until_success_or_timeout failed: %s" % e
            # Test with exception

# Generated at 2022-06-23 09:05:14.866232
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 09:05:15.423908
# Unit test for constructor of class ActionModule
def test_ActionModule():
    # TODO: implement.
    assert True

# Generated at 2022-06-23 09:05:23.540742
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Options(object):
        pass
    class Task(object):
        def __init__(self, args):
            self.args = args

    ansible_options = Options()
    ansible_options.connection = 'local'
    ansible_options.fork = 1
    ansible_options.module_name = 'wait_for_connection'
    ansible_options.module_path = '/path/to/mod_path'

    args = {
        'connect_timeout': 5,
        'delay': 0,
        'sleep': 1,
        'timeout': 60,
    }
    task = Task(args)
    task_vars = dict()

    action_mod = ActionModule(task, ansible_options, task_vars)
    assert action_mod.do_until_success_or_timeout
    assert action

# Generated at 2022-06-23 09:05:25.995355
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    # Create a new TimedOutException object
    exception = TimedOutException("test")
    # Verify exception
    assert(str(exception) == "test")

# Generated at 2022-06-23 09:05:37.528203
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    display = Display() # Mock object
    display.debug = lambda msg: print("debug: " + msg)
    actionmodule = ActionModule()
    actionmodule.boom = None
    # Test timeout
    def raise_exception(): actionmodule.boom = True
    actionmodule.do_until_success_or_timeout(raise_exception, 0, 0, "raise_exception", sleep=0)
    assert(actionmodule.boom)
    # Test success
    actionmodule.boom = False
    def set_boom(): actionmodule.boom = True
    actionmodule.do_until_success_or_timeout(set_boom, 0, 0, "set_boom", sleep=0)
    assert(actionmodule.boom)

# Generated at 2022-06-23 09:05:38.608152
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    for v in version_info:
        print(v)

# Generated at 2022-06-23 09:05:41.255376
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action_module = ActionModule()
    assert isinstance(action_module, ActionModule)

# Generated at 2022-06-23 09:05:52.387463
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import unittest
    import mock
    from ansible.module_utils._text import to_native
    from ansible.plugins.action.wait_for_connection import ActionModule
    from ansible.plugins.action.wait_for_connection import TimedOutException

    # py3 compat
    from ansible.utils.display import Display

    display = Display()

    class MockConnection(object):
        def __init__(self):
            self.tmpdir = None

        def _remove_tmp_path(self, tmpdir):
            print("Removed temporary path: %s" % to_native(tmpdir))

        def reset(self):
            print("Reset connection")

        def transport_test(self, connect_timeout):
            ''' Test connection method, if available '''
            print("transport_test: connection port up")
           

# Generated at 2022-06-23 09:05:58.544811
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import time
    import datetime

    now = datetime.datetime.now()

    # 1. Success case
    action_module = ActionModule()
    start = datetime.datetime.now()
    action_module.do_until_success_or_timeout(what=lambda x: x + 1,
                                              timeout=2,
                                              connect_timeout=1,
                                              what_desc='',
                                              sleep=1)
    end = datetime.datetime.now()
    assert end - start < datetime.timedelta(seconds=2)

    # 2. Failure case
    action_module = ActionModule()
    start = datetime.datetime.now()

# Generated at 2022-06-23 09:06:03.034529
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    """Unit test of class ActionModule method do_until_success_or_timeout. It is not called by the regular test suite.
    To be implemented."""
    # TODO
    #actionmodule = ActionModule()
    assert True

# Generated at 2022-06-23 09:06:06.307159
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    # Instantiate class TimedOutException with message
    t = TimedOutException("message")
    # Assert that message is in the string representation of TimedOutException
    assert "message" in str(t)

# Generated at 2022-06-23 09:06:14.122395
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.connection import Connection
    from ansible.plugins.connections import local

    mock_Connection = Connection(local.Connection())

    mock_Facts = Facts({'ansible_python_interpreter': '/usr/bin/python3'})

    mock_ansible_play_context = dict(
        check_mode=False,
    )

    mock_ActionModule = ActionModule(
        dict(
            _ansible_play_context=mock_ansible_play_context,
            _connection=mock_Connection,
        )
    )

    assert mock_ActionModule.run(mock_Facts)

# Generated at 2022-06-23 09:06:22.240201
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import pytest

    def good_f():
        return

    def f():
        raise Exception("Expected exception")

    am = ActionModule(None, None)

    # First test making sure the good_f case doesn't raise an exception
    am.do_until_success_or_timeout(good_f, 1, 1, what_desc="")

    # Next, we test the case where the exception is raised
    with pytest.raises(TimedOutException):
        am.do_until_success_or_timeout(f, 1, 1, what_desc="")

# Generated at 2022-06-23 09:06:26.038404
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    # Test with a parameter
    e = TimedOutException('Message')
    assert e.args == ('Message',)

    # Test without a parameter
    e = TimedOutException()
    assert e.args == (None,)

# Generated at 2022-06-23 09:06:34.899686
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # test defaults
    timeout = 600
    connect_timeout = 5

    # mock module handler
    class ActionModuleMock(ActionModule):
        def __init__(self):
            super(ActionModuleMock, self).__init__()
            self.times_called = 0

        def get_connection(self):
            return None

    # mock method 'what' which is executed by method do_until_success_or_timeout
    def connect_test(connect_timeout):
        # first call should fail, second call should succeed
        if action.times_called == 0:
            action.times_called += 1
            raise Exception("fail")
        elif action.times_called == 1:
            action.times_called += 1

    action = ActionModuleMock()

# Generated at 2022-06-23 09:06:35.550036
# Unit test for constructor of class ActionModule
def test_ActionModule():
  return ActionModule()

# Generated at 2022-06-23 09:06:35.930813
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    m = ActionModule()

# Generated at 2022-06-23 09:06:38.695074
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    fake_msg = "fake msg"
    exc = TimedOutException(fake_msg)
    assert exc.args[0] == fake_msg

# Generated at 2022-06-23 09:06:39.911318
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    assert False,  "Not implemented"

# Generated at 2022-06-23 09:06:41.663364
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException('test exception')
    assert str(e) == 'test exception'


# Generated at 2022-06-23 09:06:51.563878
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class ActionBaseStub(object):
        def __init__(self):
            self.display = Display()

    class ActionModuleStub(ActionModule):
        def __init__(self, action_base_stub):
            self._task = TaskStub()
            self._play_context = PlayContext()

            # Simulate threading.local() behaviour
            self.__dict__ = self
            self._thread_local = self

            self._connection = ConnectionStub()
            self._task = TaskStub()
            self._loader = None
            self._shared_loader_obj = None
            self._final_loader = None
            self._play_context = PlayContext()
            self._loader = DataLoader()
            self._display = Display()

    class TaskStub(object):
        def __init__(self):
            self

# Generated at 2022-06-23 09:06:54.846911
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    # Check if the constructor is working, here I can add logic for checking the
    # properties.
    assert TimedOutException("timed out waiting for 1") is not None


# Generated at 2022-06-23 09:07:10.327393
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import time

    import pytest
    from functools import partial

    class FakeConnection():
        def __init__(self):
            self.tmpdir = '/tmp'
            self._shell = self

        def reset(self):
            pass

    class FakeActionModule():
        def __init__(self, module_name):
            self.module_name = module_name

        def _execute_module(self, module_name, module_args, task_vars):
            assert module_name == self.module_name
            return dict(ping='pong')

    connection = FakeConnection()
    action_module = FakeActionModule('ansible.legacy.ping')
    action_module._connection = connection
    action_module._play_context = FakePlayContext()

    # Test success
    action_module.do_until_success_

# Generated at 2022-06-23 09:07:20.105345
# Unit test for constructor of class ActionModule
def test_ActionModule():
    import collections
    import __builtin__

    # Create a dummy class to instantiate
    class MyOptionParser(object):
        pass

    class MyDisplay(object):
        error = collections.namedtuple("error", "message")

    class MyActionBase(object):
        def __init__(self):
            self._task = collections.namedtuple("_task", "args")
            self._play_context = collections.namedtuple("_play_context", "check_mode")
            self._remote_tmp = "/path/to/remote/tmp/"

        def run(self):
            pass

    class MyConnection(object):
        def __init__(self):
            self._shell = collections.namedtuple("_shell", "tmpdir")
            self.reset = lambda: True

        def reset(self):
            pass

   

# Generated at 2022-06-23 09:07:30.153581
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class MockActionModule(ActionModule):
        def __init__(self):
            self.call_count = 0
            self.timed_out = True
        def do_until_success_or_timeout(self, what, timeout, connect_timeout, what_desc, sleep=1):
            self.call_count += 1
            if self.call_count >= 3:
                self.timed_out = False
                return
            raise Exception('testing')

    action_module = MockActionModule()

    try:
        action_module.do_until_success_or_timeout(None, 1, 1, None)
    except:
        pass

    assert action_module.call_count == 3
    assert action_module.timed_out == False

# Generated at 2022-06-23 09:07:31.025891
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert isinstance(TimedOutException(), Exception)

# Generated at 2022-06-23 09:07:42.713877
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    class MockConnection:
        def __init__(self):
            self.test_result = False

        def transport_test(self):
            if self.test_result:
                return True
            else:
                raise Exception("test failed")

    class FakeActionModule(ActionModule):
        def __init__(self):
            self._connection = MockConnection()

    am = FakeActionModule()
    with pytest.raises(TimedOutException):
        am.do_until_success_or_timeout(lambda: am._connection.transport_test(), 2, 5, "test_desc")
    am._connection.test_result = True
    am.do_until_success_or_timeout(lambda: am._connection.transport_test(), 2, 5, "test_desc")

# Generated at 2022-06-23 09:07:52.358581
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    def test_func(connect_timeout):
        nonlocal i
        i += 1
        if i <= 2:
            raise Exception('boom')
        if i >= 3:
            return

    i = 0
    am = ActionModule(None, None, None, None, None)
    am.do_until_success_or_timeout(test_func, timeout=2, connect_timeout=None, what_desc='test_func')
    assert i == 3

    def test_func_with_args(connect_timeout):
        nonlocal i, ct
        ct = connect_timeout
        i += 1
        if i <= 2:
            raise Exception('boom')
        if i >= 3:
            return

    i = 0
    ct = None
    am = ActionModule(None, None, None, None, None)


# Generated at 2022-06-23 09:08:02.256956
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # Initialize
    display = Display()
    display.verbosity = 4  # Verbosity level
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Method to test
    timeout = 10
    connect_timeout = 1
    what_desc = "test"
    sleep = 1

    # Define a test function that fails
    def test_function(connect_timeout):
        raise Exception('Test function exception')

    # Call method
    try:
        am.do_until_success_or_timeout(test_function, timeout, connect_timeout, what_desc, sleep=sleep)
        assert False
    except TimedOutException:
        assert True


# Generated at 2022-06-23 09:08:14.024493
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    #pylint: disable=unused-argument
    class MockActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            return dict()

    # MockActionModule doesn't do anything but inherits from ActionModule so we can call it's superclass methods
    mock_action_module = MockActionModule(
        task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    success_times = 0
    fail_times = 0

    def success():
        nonlocal success_times
        success_times += 1
        display.debug("mock_function: success")

    def fail():
        nonlocal fail_times
        fail_times += 1
        display.debug("mock_function: fail")

# Generated at 2022-06-23 09:08:16.219032
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exc = TimedOutException("test exception message")

    assert str(exc) == "test exception message"
    assert repr(exc) == "test exception message"

# Generated at 2022-06-23 09:08:17.368326
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    with pytest.raises(SystemExit):
        ActionModule.run(None, None)

# Generated at 2022-06-23 09:08:24.451759
# Unit test for constructor of class ActionModule
def test_ActionModule():
    actionModule = ActionModule()
    assert actionModule.TRANSFERS_FILES is False
    assert actionModule._VALID_ARGS == frozenset(('connect_timeout', 'delay', 'sleep', 'timeout'))

    # DEFAULT_CONNECT_TIMEOUT
    assert actionModule.DEFAULT_CONNECT_TIMEOUT == 5

    # DEFAULT_DELAY
    assert actionModule.DEFAULT_DELAY == 0

    # DEFAULT_SLEEP
    assert actionModule.DEFAULT_SLEEP == 1

    # DEFAULT_TIMEOUT
    assert actionModule.DEFAULT_TIMEOUT == 600


# Generated at 2022-06-23 09:08:27.238841
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("message")

    # check for class and message
    assert isinstance(e, TimedOutException)
    assert e.args[0] == "message"


# Generated at 2022-06-23 09:08:29.558802
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:08:33.737637
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    res = ActionModule.run(ActionModule(), task_vars='task_vars')
    assert res['skipped'] is True
    res = ActionModule.run(ActionModule(), task_vars='task_vars')
    assert res['skipped'] is True

# Generated at 2022-06-23 09:08:37.049029
# Unit test for constructor of class ActionModule
def test_ActionModule():
    result = ActionModule(None, None)
    assert isinstance(result, ActionModule)




# Generated at 2022-06-23 09:08:37.746541
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-23 09:08:46.450928
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Prepare test data
    my_connection = test_connection()
    my_play_context = test_play_context()

    my_action_module = ActionModule(task=None, connection=my_connection, play_context=my_play_context, loader=None, templar=None, shared_loader_obj=None)

    deadline = datetime.now() + timedelta(seconds=1)
    while True:
        if datetime.now() > deadline:
            assert False, "Did not receive the 'transport_test' method call"
        elif my_connection.transport_test_called:
            break
        else:
            time.sleep(0.05)

    while True:
        if datetime.now() > deadline:
            assert False, "Did not receive the 'reset' method call"

# Generated at 2022-06-23 09:08:50.875862
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Arrange
    action_module = ActionModule()
    # Act
    result = action_module.run('tmp', None)
    # Assert
    assert result == {}

# Generated at 2022-06-23 09:08:55.581120
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("message")
    assert e.args[0] == "message"
    assert e.__str__()  == "message"
    assert e.__repr__() == "TimedOutException('message',)"

# Generated at 2022-06-23 09:08:57.311242
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # A test case, to be programatically run by the test suite
    am = ActionModule()
    assert True

# Generated at 2022-06-23 09:08:58.552227
# Unit test for constructor of class ActionModule
def test_ActionModule():
    action = ActionModule()
    assert action.run() == None

test_ActionModule()

# Generated at 2022-06-23 09:09:10.035434
# Unit test for constructor of class ActionModule
def test_ActionModule():
    class Options(object):
        def __init__(self, args):
            self.args = args

    class Task(object):
        def __init__(self, args):
            self.args = args

    class PlayContext(object):
        def __init__(self, check_mode):
            self.check_mode = check_mode

    class Connection(object):
        def __init__(self, tmpdir):
            self.tmpdir = tmpdir

    class AnsibleHostFromOptions(object):
        def get_option(self, option):
            if option == 'ansible_connection':
                return 'network_cli'
            elif option == 'name':
                return 'localhost'
            else:
                return ''

    class Display(object):
        def __init__(self):
            self.debug_msg = []



# Generated at 2022-06-23 09:09:21.080506
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    # To be mocked
    class connection():
        def transport_test(self, connect_timeout):
            raise Exception('transport test failed')

    class task():
        def __init__(self):
            self.args = {
                'connect_timeout': 1,
                'delay': 0,
                'sleep': 0,
                'timeout': 0.1
            }

    from datetime import datetime

    # Mock dependencies
    class display():
        @staticmethod
        def debug(msg):
            print('*DEBUG %s' % msg)

    class task_vars():
        def __init__(self):
            self.ansible_facts = {}

    # Create test object
    a = ActionModule(task(), connection(), task_vars())

    # Test do_until_success_or_timeout with a timeout

# Generated at 2022-06-23 09:09:25.195392
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    # Test case - Valid arguments
    # Test 1 - Default values
    task_args = {}
    action = ActionModule(task=MagicMock(), connection=MagicMock())
    result = action.run(task_args=task_args)
    assert result == {'elapsed': 0, 'failed': False}
    # Test 2 - Passing specific arguments
    task_args = {'connect_timeout': 10, 'delay': 5, 'sleep': 2, 'timeout': 120}
    action = ActionModule(task=MagicMock(), connection=MagicMock())
    result = action.run(task_args=task_args)
    assert result == {'elapsed': 5, 'failed': False}

    # Test case - Invalid arguments
    # Test 1 - Invalid connect_timeout
    task_args = {'connect_timeout': 'a'}


# Generated at 2022-06-23 09:09:27.776583
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("test_TimedOutException")
    assert str(e) == "test_TimedOutException"

# Generated at 2022-06-23 09:09:30.528300
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException("message")
    except TimedOutException:
        pass
    except Exception as e:
        raise e

# Generated at 2022-06-23 09:09:41.445350
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    display = Display()
    display.verbosity = 4

    # Inputs
    task_vars = {}
    timeout = 15
    connect_timeout = 10
    sleep = 1

    def testfunc(timeout):
        import random
        i = random.random()
        if i < 0.5:
            raise Exception("Test Exception")

    actionmodule = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)

    # Start timer
    start = datetime.utcnow()
    actionmodule.do_until_success_or_timeout(testfunc, timeout, connect_timeout, what_desc="testing", sleep=sleep)

    # End timer
    end = datetime.utcnow()
    elapsed = end - start

    assert elapsed.seconds

# Generated at 2022-06-23 09:09:45.283200
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    exception = TimedOutException("Timed Out Exception")
    # We need to convert this into a string to check the exception
    exception_str = str(exception)
    assert "Timed Out Exception" in exception_str

# Generated at 2022-06-23 09:09:51.822752
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    display = Display()

    class TestActionModule(ActionModule):
        def run(self, tmp=None, task_vars=None):
            double_self = TestActionModule()
            res = double_self.do_until_success_or_timeout(
                self.get_expected, timeout=5, connect_timeout=5, what_desc="Test what_desc"
            )
            return res

        # method for testing purpose
        def get_expected(self, connect_timeout):
            raise TimedOutException("timed out waiting for %s: %s" % ("expected", "expected exception"))

    try:
        test_action_module = TestActionModule()
        test_action_module.run()
    except TimedOutException as e:
        display.debug(e)

# Generated at 2022-06-23 09:09:56.534724
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    te1 = TimedOutException()
    te2 = TimedOutException("A Test error")
    assert str(te1) == "timed out waiting for: "
    assert str(te2) == "timed out waiting for: A Test error"

# Generated at 2022-06-23 09:10:00.527119
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("test_missing_attribute")
    assert e.args[0] == "test_missing_attribute"

# Generated at 2022-06-23 09:10:03.698852
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    e = TimedOutException("Test message")
    assert repr(e).split(" ", 1)[0] == "TimedOutException"

# Generated at 2022-06-23 09:10:05.341364
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        raise TimedOutException('Test TimedOutException')
    except TimedOutException as e:
        assert e.args == ('Test TimedOutException',)


# Generated at 2022-06-23 09:10:07.207899
# Unit test for constructor of class ActionModule
def test_ActionModule():
    module = ActionModule('localhost', 'testuser', 'testpass')
    assert module is not None

# Generated at 2022-06-23 09:10:14.791278
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    from ansible.plugins.connection.winrm import Connection

    # Configuration parameters and return values
    config = dict()
    config['shell'] = "powershell"
    config['transport'] = "plaintext"
    config['remote_addr'] = "192.168.0.1"
    config['remote_port'] = 5986
    config['port'] = 5985
    config['connection'] = "smart"
    config['url_username'] = ""
    config['url_password'] = ""
    config['no_host_key_check'] = "False"
    config['host_key_auto_add'] = "True"
    config['encrypt'] = "False"
    config['ansible_winrm_server_cert_validation'] = "ignore"
    config['ansible_winrm_send_credssp']

# Generated at 2022-06-23 09:10:28.620937
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    display = Display()
    am = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    # test success
    what_desc = "test_what_desc"
    def what(timeout):
        return True
    try:
        am.do_until_success_or_timeout(what, 1, 1, what_desc, sleep=0)
    except TimedOutException:
        raise AssertionError("do_until_success_or_timeout should not have timed out")
    # test timeout
    what_desc = "test_what_desc_timeout"
    def what_timeout(timeout):
        raise Exception("test_what_desc_timeout should not have succeeded")