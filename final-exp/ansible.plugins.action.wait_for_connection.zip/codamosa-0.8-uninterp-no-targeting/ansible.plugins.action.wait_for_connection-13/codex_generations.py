

# Generated at 2022-06-21 03:26:08.724225
# Unit test for constructor of class ActionModule
def test_ActionModule():
  pass

# Generated at 2022-06-21 03:26:13.126910
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():

    from ansible.plugins.action.wait_for_connection import ActionModule
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.six import iterkeys

    am = ActionModule()

    # For the mock objects below, we need to make sure that the properties return the same values as the keys.
    class DataSource(object):
        def __getitem__(self, key):
            return key

    # Provide a fake _execute_module.
    # 1. If called with module_name='ansible.legacy.ping', return the ping module output.
    # 2. If called with module_name='ansible.legacy.shell', raise an exception.
    class PingResult(DataSource):
        def __setitem__(self, key, value):
            pass


# Generated at 2022-06-21 03:26:13.604672
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    pass

# Generated at 2022-06-21 03:26:19.919329
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    def fail():
        raise Exception('Fail!')

    class MyActionModule(ActionModule):
        def do_until_success_or_timeout(self, what, timeout, connect_timeout, what_desc, sleep=1):
            self.executed = []

            max_end_time = datetime.now() + timedelta(seconds=timeout)
            while datetime.now() < max_end_time:
                try:
                    what(connect_timeout)
                    self.executed.append(what)
                    return
                except Exception:
                    pass
            raise TimedOutException("timed out waiting for %s" % what_desc)

    action_module = MyActionModule()
    action_module.run(timeout=5, connect_timeout=5)


# Generated at 2022-06-21 03:26:23.499975
# Unit test for constructor of class ActionModule
def test_ActionModule():
    assert ActionModule.TRANSFERS_FILES == False
    assert ActionModule._VALID_ARGS == frozenset(('connect_timeout', 'delay', 'sleep', 'timeout'))



# Generated at 2022-06-21 03:26:32.051137
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import datetime
    import sys
    import unittest

    if sys.version_info >= (3, 0):
        from io import StringIO
    else:
        from StringIO import StringIO

    from ansible.module_utils.six import binary_type

    class MyActionModule(ActionModule):
        pass

    class MyDisplay(Display):
        def debug(self, msg, *args, **kwargs):
            self.messages.append(msg)

    class MyTestCase(unittest.TestCase):
        def setUp(self):
            self.action_module = MyActionModule()
            self.display = MyDisplay()
            self.display.messages = []

        def test_success(self):
            start_datetime = datetime.datetime(2017,1,1,16,17)
            end_

# Generated at 2022-06-21 03:26:40.504763
# Unit test for method do_until_success_or_timeout of class ActionModule
def test_ActionModule_do_until_success_or_timeout():
    import copy
    import unittest

    class Dest(object):
        def __init__(self):
            self.recv_calls = 0
        def recv(self, buffer_size):
            self.recv_calls += 1
            if self.recv_calls == 1:
                return b'\x00\x00\x01\x00\x00\x00'  # Return an exception
            return b'\x00\x00\x00\x00\x00\x00'  # Return ok

    class TestClass:
        class TestPlayContext:
            def __init__(self):
                self.check_mode = False

        class TestTask:
            def __init__(self):
                self.args = dict(timeout=4, sleep=1)


# Generated at 2022-06-21 03:26:42.544324
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    try:
        class InnerException(Exception):
            pass
        raise InnerException("inner exception")
    except InnerException as e:
        try:
            raise TimedOutException(e)
        except TimedOutException as x:
            assert x.message == e

# Generated at 2022-06-21 03:26:43.392206
# Unit test for constructor of class TimedOutException
def test_TimedOutException():
    assert str(TimedOutException('hello', 'world')) == "timed out waiting for hello: world"

# Generated at 2022-06-21 03:26:47.001565
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    action_module = AnsibleActionModule()

    class MockTask(object):
        argument_spec = {}
        connection = 'test_connection'

    class MockPlayContext(object):
        check_mode = False

    class MockConnection(object):
        def __init__(self):
            self.transport = 'mock_transport'
            self.transport_test = lambda: True

    class MockConnection2(object):
        def __init__(self):
            self.transport = 'mock_transport2'

    class MockConnection3(MockConnection):
        def reset(self):
            pass

    class MockConnection4(MockConnection):
        pass

    class MockConnection5(MockConnection):
        def transport_test(self):
            return True


# Generated at 2022-06-21 03:31:00.066506
# Unit test for method run of class ActionModule
def test_ActionModule_run():
    import unittest
    import ansible.utils.display
    import ansible.playbook.play_context

    module = ActionModule()

    class MockTask(object):
        def __init__(self):
            self.__dict__['args'] = dict()

        def __setattr__(self, name, value):
            raise NotImplementedError("Attempt to rewrite task attribute '%s' to value %s" % (name, value))

    module._task = MockTask()

    class MockPlayContext(ansible.playbook.play_context.PlayContext):
        def __init__(self, check_mode=False):
            super(MockPlayContext, self).__init__(check_mode)
            self.__dict__['check_mode'] = check_mode


# Generated at 2022-06-21 03:31:03.032066
# Unit test for constructor of class ActionModule
def test_ActionModule():
    """This is a test of the constructor of the class ActionModule."""

    action_module = ActionModule(task=None, connection=None, play_context=None, loader=None, templar=None, shared_loader_obj=None)
    assert action_module

# Generated at 2022-06-21 03:31:05.088582
# Unit test for constructor of class ActionModule
def test_ActionModule():
  action_module = ActionModule(task=dict(), connection=None, play_context=dict(), loader=None, templar=None, shared_loader_obj=None)
  assert action_module is not None