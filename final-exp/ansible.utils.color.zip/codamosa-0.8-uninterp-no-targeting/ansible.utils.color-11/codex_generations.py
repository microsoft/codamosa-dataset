

# Generated at 2022-06-21 08:11:57.356658
# Unit test for function hostcolor
def test_hostcolor():
    import pytest
    assert hostcolor(u'localhost', dict(changed=0, failures=1), color=True) == u'localhost\033[31m               \033[0m'
    assert hostcolor(u'localhost', dict(changed=1, failures=0), color=True) == u'localhost\033[33m               \033[0m'
    assert hostcolor(u'localhost', dict(changed=0, failures=0), color=True) == u'localhost\033[32m               \033[0m'
    assert hostcolor(u'localhost', dict(changed=0, failures=1), color=False) == u'localhost               '
    assert hostcolor(u'localhost', dict(changed=1, failures=0), color=False) == u'localhost               '

# Generated at 2022-06-21 08:12:07.427722
# Unit test for function stringc
def test_stringc():
    print("Test stringc")
    print("    stringc(text, 'blue')")
    print("    blue text")
    print("    stringc(text, 'rgb255255000')")
    print("    rgb255255000 text")
    print("    stringc(text, 'gray8')")
    print("    gray8 text")
    print("    stringc(text, 'rgb(255,255,0)')")
    print("    rgb(255,255,0) text")
    print("    stringc(text, 'color10')")
    print("    color10 text")
    print("    stringc(text, 'color21')")
    print("    color21 text")
    print("    stringc(text, 'color57')")
    print("    color57 text")



# Generated at 2022-06-21 08:12:13.919273
# Unit test for function stringc
def test_stringc():
        # This test is a regression test against issue #12905. The
        # following test was added to ensure the fix of issue #12905
        # against a regression.
        test_string = 'this is a test'
        color = 'red'
        expected_result = u'\033[31mthis is a test\033[0m'
        result = stringc(test_string, color)
        assert result == expected_result

# -- end "pretty"

# Generated at 2022-06-21 08:12:21.110903
# Unit test for function colorize
def test_colorize():
    """
    ansible ansible.utils.color.colorize -m debug -a "msg={{ colorize('ok', 0, 'black') }}" localhost
    ansible ansible.utils.color.colorize -m debug -a "msg={{ colorize('changed', 1, 'green') }}" localhost
    ansible ansible.utils.color.colorize -m debug -a "msg={{ colorize('failed', 2, 'yellow') }}" localhost
    ansible ansible.utils.color.colorize -m debug -a "msg={{ colorize('skipped', 3, 'blue') }}" localhost
    ansible ansible.utils.color.colorize -m debug -a "msg={{ colorize('unreachable', 99, 'red') }}" localhost
    """
    pass


# Generated at 2022-06-21 08:12:22.465167
# Unit test for function colorize
def test_colorize():
    pass
    # colorize("!", 4, 'red')

# --- end "pretty"

# Generated at 2022-06-21 08:12:33.710540
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('bold', 'bold') == u'\033[1mbold\033[0m'
        assert stringc('italic', 'italic') == u'\033[3mitalic\033[0m'
        assert stringc('underline', 'underline') == u'\033[4munderline\033[0m'
        assert stringc('strikethrough', 'strikethrough') == u'\033[9mstrikethrough\033[0m'
        assert stringc('red', 'red') == u'\033[31mred\033[0m'
        assert stringc('green', 'green') == u'\033[32mgreen\033[0m'

# Generated at 2022-06-21 08:12:41.698138
# Unit test for function stringc
def test_stringc():
    assert ANSIBLE_COLOR

    # Test color lookup
    assert parsecolor('green') == u'32'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('rgb125') == u'38;5;39'
    assert parsecolor('rgb241') == u'38;5;69'
    assert parsecolor('gray0') == u'38;5;232'

    # Test wrapping
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'red', wrap_nonvisible_chars=True) == u'\001\033[31m\002foo\001\033[0m\002'

    # Test multiline wrapping
    # The text with ANSI codes should still

# Generated at 2022-06-21 08:12:49.642935
# Unit test for function colorize
def test_colorize():
    print("Testing parsecolor()")
    assert parsecolor("green") == '32'
    assert parsecolor("normal") == '39'
    assert parsecolor("color10") == '38;5;10'
    assert parsecolor("rgb124") == '38;5;166'
    assert parsecolor("gray10") == '38;5;242'
    assert parsecolor("fred") == '39'
    assert parsecolor("color256") == '39'
    assert parsecolor("rgb1245") == '39'
    assert parsecolor("gray2565") == '39'



# Generated at 2022-06-21 08:13:01.412487
# Unit test for function parsecolor

# Generated at 2022-06-21 08:13:08.389563
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('success', 33, 'green')
    'success=33  '
    >>> colorize('changed', 22, 'yellow')
    'changed=22  '
    >>> colorize('failures', 2, 'red')
    'failures=2  '
    >>> colorize('unreachable', 1, 'red')
    'unreachable=1'
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# --- end "pretty"

# Generated at 2022-06-21 08:13:12.837577
# Unit test for function colorize
def test_colorize():
    pass

# Generated at 2022-06-21 08:13:22.742943
# Unit test for function hostcolor
def test_hostcolor():
    host_pass   = 'foo.example.org'
    host_fail   = 'bar.example.org'
    host_unreac = 'far.example.org'
    host_chg    = 'zar.example.org'

    # The following should all produce the same result for all hosts
    # (assuming all code paths are exercised below)
    #
    # Tuple items:
    #   - stats dict
    #   - expected color


# Generated at 2022-06-21 08:13:35.666692
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb123') == u'38;5;201'
    assert parsecolor('rgb555') == u'38;5;255'
    assert parsecolor('rgb123') == u'38;5;201'
    assert parsecolor('rgb333') == u'38;5;119'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray5') == u'38;5;237'
    assert parsecolor('gray9') == u'38;5;241'
    # Should fail silently and return the default for unrecognized strings
    assert parsecolor('color256') == u'35'


# Generated at 2022-06-21 08:13:45.950071
# Unit test for function colorize
def test_colorize():
    """ Print some colorized test output """

    colors = ['blue', 'green', 'magenta', 'red', 'yellow']

    print()
    print(u"Colorized test output:")
    print(u"======================")
    print()

    print(u"%-8s  %-8s  %-8s  %-8s  %-8s" % tuple(colors))
    for c1 in colors:
        l = []
        for c2 in colors:
            l.append(colorize('>', 7, c1) + colorize('>', 5, c2))
        print(u"%-8s  %-8s  %-8s  %-8s  %-8s" % tuple(l))
    print()


# Generated at 2022-06-21 08:13:55.970518
# Unit test for function parsecolor
def test_parsecolor():
    color_names = ['black', 'red', 'green', 'yellow',
                   'blue', 'magenta', 'cyan', 'white',
                   'default']
    for name in color_names:
        sgr_param = parsecolor(name)
        # Check if parsecolor returns an SGR parameter string
        # that starts with an appropriate code
        # (e.g., '39' for default color, '38;5;x' for xterm-256 color)
        assert sgr_param.startswith(C.COLOR_CODES[name].split(';')[0])



# Generated at 2022-06-21 08:14:06.800257
# Unit test for function hostcolor
def test_hostcolor():
    # I am not sure how to write unit test for this function, because it
    #   depends on ANSIBLE_COLOR and C.COLOR_CHANGED
    # So, I use varying ANSIBLE_COLOR and C.COLOR_CHANGED to write unit test
    #   for hostcolor
    saved_color = ANSIBLE_COLOR
    saved_color_changed = C.COLOR_CHANGED

# Generated at 2022-06-21 08:14:15.565330
# Unit test for function parsecolor
def test_parsecolor():
    """Tests for function parsecolor()."""
    assert u'38;5;0' == parsecolor('black')
    assert u'38;5;15' == parsecolor('white')
    assert u'38;5;1' == parsecolor('red')
    assert u'38;5;2' == parsecolor('green')
    assert u'38;5;3' == parsecolor('yellow')
    assert u'38;5;4' == parsecolor('blue')
    assert u'38;5;5' == parsecolor('magenta')
    assert u'38;5;6' == parsecolor('cyan')
    assert u'38;5;7' == parsecolor('gray')
    assert u'38;5;8' == parsecolor('grey')

# Generated at 2022-06-21 08:14:20.201944
# Unit test for function hostcolor
def test_hostcolor():
    h = 'foo.example.org'
    stats = dict(failures=0, unreachable=0, changed=0)
    assert 'foo.example.org' in hostcolor(h, stats, False)
    assert 'foo.example.org' in hostcolor(h, stats, True)


# Generated at 2022-06-21 08:14:28.757767
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "black") == u'\x1b[30mfoo\x1b[0m'
    assert stringc("foo", "lightgray") == u'\x1b[37mfoo\x1b[0m'
    assert stringc("foo", "darkgray") == u'\x1b[90mfoo\x1b[0m'
    assert stringc("foo", "lightblue") == u'\x1b[94mfoo\x1b[0m'
    assert stringc("foo", "lightgreen") == u'\x1b[92mfoo\x1b[0m'
    assert stringc("foo", "lightcyan") == u'\x1b[96mfoo\x1b[0m'
    assert stringc("foo", "lightred") == u

# Generated at 2022-06-21 08:14:31.502325
# Unit test for function colorize
def test_colorize():
    """Returns the expected string"""
    results = [colorize(u'foo', 0, u'green'),
               colorize(u'foo', 1, u'green'),
               colorize(u'foo', 0, None),
               colorize(u'foo', 1, None)]
    assert results == [u'foo=0   ', u'foo=1   ', u'foo=0   ', u'foo=1   ']



# Generated at 2022-06-21 08:14:43.282730
# Unit test for function hostcolor
def test_hostcolor():
    fakehost = 'my-fake-host'
    assert hostcolor(fakehost, {'failures': 1}, color=True) == stringc(u"%-26s" % fakehost, C.COLOR_ERROR)
    assert hostcolor(fakehost, {'changed': 1}, color=True) == stringc(u"%-26s" % fakehost, C.COLOR_CHANGED)
    assert hostcolor(fakehost, {'ok': 1}, color=True) == stringc(u"%-26s" % fakehost, C.COLOR_OK)
    assert hostcolor(fakehost, {'ok': 1}, color=False) == u"%-26s" % fakehost



# Generated at 2022-06-21 08:14:55.044788
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color
    stats_failed = {
        'changed': 0,
        'dark': 0,
        'failures': 1,
        'ok': 2,
        'processed': 2,
        'skipped': 0,
        'unreachable': 0,
    }
    stats_ok = {
        'changed': 0,
        'dark': 0,
        'failures': 0,
        'ok': 2,
        'processed': 2,
        'skipped': 0,
        'unreachable': 0,
    }
    stats_changed = {
        'changed': 1,
        'dark': 0,
        'failures': 0,
        'ok': 2,
        'processed': 2,
        'skipped': 0,
        'unreachable': 0,
    }
   

# Generated at 2022-06-21 08:15:03.548169
# Unit test for function colorize
def test_colorize():

    # Color is disabled
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('test:', 12, 'green') == 'test=12  '
    assert colorize('test:', 123, 'green') == 'test=123 '

    # Color is enabled
    ANSIBLE_COLOR = True
    assert colorize('test:', 12, 'green') == 'test=12  \n'
    assert colorize('test:', 123, 'green') == 'test=123 \n'
    ANSIBLE_COLOR = False


# Generated at 2022-06-21 08:15:15.792174
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("black") == "30"
    assert parsecolor("darkgray") == "90"
    assert parsecolor("red") == "31"
    assert parsecolor("lightgreen") == "92"
    assert parsecolor("yellow") == "93"
    assert parsecolor("lightblue") == "94"
    assert parsecolor("magenta") == "95"
    assert parsecolor("lightcyan") == "96"
    assert parsecolor("white") == "97"
    assert parsecolor("default") == "39"
    assert parsecolor("color8") == "38;5;8"
    assert parsecolor("color14") == "38;5;14"
    assert parsecolor("color88") == "38;5;88"

# Generated at 2022-06-21 08:15:24.761771
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, "green") == stringc("foo=0", "green")
    assert colorize("foo", 1, "green") == stringc("foo=1", "green")
    assert colorize("foo", -1, "green") == stringc("foo=-1", "green")
    assert colorize("x" * 1000, 0, "green") == stringc("foo=0", "green")
    assert colorize("x" * 1000, 1, "green") == stringc("foo=1", "green")
    assert colorize("x" * 1000, -1, "green") == stringc("foo=-1", "green")



# Generated at 2022-06-21 08:15:35.846638
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('gray') == '37'
    assert parsecolor('lightgray') == '37'

    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'

# Generated at 2022-06-21 08:15:49.224349
# Unit test for function hostcolor
def test_hostcolor():
    def c(c):
        if c:
            return c.replace(u'\033[', '').replace(u'm', '').replace(u'\033[0', '')
        else:
            return c
    # Make sure these test cases return the expected number of characters
    assert len(hostcolor(u'foobaz', {u'failures': 0, u'changed': 0, u'ok': 0})) == 37
    assert len(hostcolor(u'foobaz', {u'failures': 0, u'changed': 0, u'ok': 0}, color=False)) == 26
    # Make sure the function returns a string
    assert isinstance(hostcolor(u'foobaz', {u'failures': 0, u'changed': 0, u'ok': 0}), basestring)
    # Make sure the

# Generated at 2022-06-21 08:15:59.217799
# Unit test for function stringc
def test_stringc():
    assert stringc("some text", "green") == "\033[32msome text\033[0m"
    assert stringc("some text", "0") == "\033[38;5;0msome text\033[0m"
    assert stringc("some text", "rgb255255255") == "\033[38;5;15msome text\033[0m"
    assert stringc("some text", "rgb000") == "\033[38;5;16msome text\033[0m"
    assert stringc("some text", "rgb123") == "\033[38;5;17msome text\033[0m"
    assert stringc("some text", "rgb024") == "\033[38;5;18msome text\033[0m"
    assert stringc("some text", "rgb333")

# Generated at 2022-06-21 08:16:05.525059
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foohost'
    stats = {'changed': 0, 'failures': 0, 'ok': 10, 'skipped': 0, 'unreachable': 0}
    color = True
    expected = u"%-37s" % stringc(host, C.COLOR_OK)
    actual = hostcolor(host, stats, color)
    print('expected: %s' % expected)
    print('  actual: %s' % actual)
    if expected != actual:
        print(hostcolor(host, stats, color))
    return
# test_hostcolor()

# --- end "pretty"


# Generated at 2022-06-21 08:16:16.689916
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host.example.com', dict(
        changed=0,
        failures=0,
        unreachable=0,
    )) == u"host.example.com                     "
    assert hostcolor('host.example.com', dict(
        changed=1,
        failures=0,
        unreachable=0,
    )) == u"host.example.com                     "
    assert hostcolor('host.example.com', dict(
        changed=1,
        failures=1,
        unreachable=0,
    )) == u"host.example.com                     "
    assert hostcolor('host.example.com', dict(
        changed=1,
        failures=0,
        unreachable=1,
    )) == u"host.example.com                     "


# Generated at 2022-06-21 08:16:34.603921
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('bold') == '1'
    assert parsecolor('bright red') == '91'
    assert parsecolor('bright yellow') == '93'
    assert parsecolor('color09') == '38;5;9'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color12') == '38;5;12'
    assert parsecolor('color220') == '38;5;220'
    assert parsecolor('rgb100500') == '38;5;105'
    assert parsecolor('gray1') == '38;5;235'
    assert parsecolor('gray8') == '38;5;252'

# Generated at 2022-06-21 08:16:42.023979
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == u'%-37s' % 'localhost'
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}, True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}, True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}, True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-21 08:16:52.667317
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == '\n'.join([u'\033[32mfoo\033[0m'])
    assert stringc('foo\nbar', 'red') == '\n'.join([u'\033[31mfoo\033[0m', u'\033[31mbar\033[0m'])
    assert stringc('foo\nbar', 'rgb255') == '\n'.join([u'\033[38;5;196mfoo\033[0m', u'\033[38;5;196mbar\033[0m'])

# Generated at 2022-06-21 08:16:55.301056
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('brightred') == u'38;5;196'
    assert parsecolor('red') == u'38;5;160'


# Generated at 2022-06-21 08:16:59.934222
# Unit test for function colorize
def test_colorize():
    """
    >>> print(colorize('ok', 0, 'black'))
    ok=0
    >>> print(colorize('changed', 1, 'yellow'))
    \x1b[33mchanged=1\x1b[0m
    """


# Generated at 2022-06-21 08:17:11.300846
# Unit test for function stringc
def test_stringc():
    for color in ('k', 'r', 'g', 'y', 'b', 'm', 'c', 'w', 'K', 'R', 'B', 'M', 'C', 'W'):
        print(u" This is a test in %s color \n" % color)

    for bgcolor in ('on_k', 'on_r', 'on_g', 'on_y', 'on_b', 'on_m', 'on_c', 'on_w'):
        print(u" This is a test in %s bgcolor \n" % bgcolor)

    for attr in ('bold', 'dark', '', 'underline', 'blink', 'reverse', 'concealed'):
        print(u" This is a test in %s attr \n" % attr)


# Generated at 2022-06-21 08:17:13.620240
# Unit test for function colorize
def test_colorize():
    for i in range(1, 11):
        print(colorize(str(i) + ': ', i, None))
# --- end of "pretty" ---



# Generated at 2022-06-21 08:17:26.061466
# Unit test for function colorize
def test_colorize():
    # Test with ANSI terminal
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert colorize(u'ok', 0, C.COLOR_OK) == u'ok=0  '
    assert colorize(u'changed', 1, C.COLOR_CHANGED) == u'\033[0;32;40mchanged=1\033[0m'
    assert colorize(u'unreachable', 2, C.COLOR_UNREACHABLE) == u'\033[0;33;40munreachable=2\033[0m'
    assert colorize(u'failures', 0, C.COLOR_ERROR) == u'failures=0 '

    # Test without ANSI terminal
    ANSIBLE_COLOR = False

# Generated at 2022-06-21 08:17:35.048764
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == parsecolor('color4')
    assert parsecolor('rgb222') == parsecolor('rgb2 2 2')
    assert parsecolor('rgb123') == parsecolor('rgb1 2 3')
    assert parsecolor('rgb321') == parsecolor('rgb3 2 1')
    assert parsecolor('gray5') == parsecolor('color237')
    assert parsecolor('gray0') == parsecolor('color232')
    assert parsecolor('gray8') == parsecolor('color239')
    assert parsecolor('invalid') == u''

# Generated at 2022-06-21 08:17:37.865170
# Unit test for function colorize
def test_colorize():
    for c in ('red','green','yellow','blue','magenta','cyan','white','dark','bold','reset','black','lightgray'):
        print("%s %s %s" % (colorize('XXX', 999, c), stringc(c, c), c))
    print("%s %s" % (colorize('XXX', 0, 'blue'), 'blue'))


# Generated at 2022-06-21 08:18:07.851623
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '34'
    assert parsecolor('red') == '31'
    assert parsecolor('foobar') == C.COLOR_CODES['foobar']
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color232') == '38;5;232'
    assert parsecolor('rgb333') == '38;5;233'
    assert parsecolor('rgb355') == '38;5;124'
    assert parsecolor('rgb533') == '38;5;92'
    assert parsecolor('rgb555') == '38;5;15'
    assert parsecolor('gray0') == '38;5;232'
    assert par

# Generated at 2022-06-21 08:18:19.175494
# Unit test for function parsecolor
def test_parsecolor():
    # foreground colors
    test = parsecolor('red')
    assert test == '31', test
    test = parsecolor('cyan')
    assert test == '36', test
    test = parsecolor('green')
    assert test == '32', test
    test = parsecolor('orange')
    assert test == '33', test
    test = parsecolor('blue')
    assert test == '34', test
    test = parsecolor('magenta')
    assert test == '35', test
    test = parsecolor('color07')
    assert test == '37', test
    # background colors
    test = parsecolor('on_red')
    assert test == '41', test
    test = parsecolor('on_cyan')
    assert test == '46', test

# Generated at 2022-06-21 08:18:22.865045
# Unit test for function hostcolor
def test_hostcolor():
    host = "local"
    stats = {'changed': 0,
             'failures': 0,
             'ok': 1,
             'skipped': 0,
             'unreachable': 0}
    color = True
    print(hostcolor(host, stats, color))



# Generated at 2022-06-21 08:18:31.257457
# Unit test for function colorize
def test_colorize():  # pragma: no cover
    print(colorize('ok', 0, 'black'))
    print(colorize('changed', 0, 'black'))
    print(colorize('unreachable', 0, 'black'))
    print(colorize('failed', 0, 'black'))

    print(colorize('ok', 0, 'white'))
    print(colorize('changed', 0, 'white'))
    print(colorize('unreachable', 0, 'white'))
    print(colorize('failed', 0, 'white'))

    print(colorize('ok', 0, 'green'))
    print(colorize('changed', 0, 'green'))
    print(colorize('unreachable', 0, 'green'))
    print(colorize('failed', 0, 'green'))


# Generated at 2022-06-21 08:18:35.807882
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"red") == u"31"
    assert parsecolor(u"color01") == u"38;5;1"
    assert parsecolor(u"rgb123") == u"38;5;18"
    assert parsecolor(u"gray9") == u"38;5;245"
    assert parsecolor(u"foo") == C.COLOR_ERROR


# Generated at 2022-06-21 08:18:47.825042
# Unit test for function stringc
def test_stringc():
    def assert_stringc(text, color):
        assert stringc(text, color) == u"\033[%sm%s\033[0m" % (parsecolor(color), text)

    assert_stringc(u'foo', u'blue')
    assert_stringc(u'foo', u'rgb255000')
    assert_stringc(u'foo', u'rgb000255')
    assert_stringc(u'foo', u'rgb255255000')
    assert_stringc(u'foo', u'rgb000255255')
    assert_stringc(u'foo', u'rgb255255255')
    assert_stringc(u'foo', u'rgb000')
    assert_stringc(u'foo', u'rgb555')

# Generated at 2022-06-21 08:18:58.761157
# Unit test for function parsecolor
def test_parsecolor():
    from os import linesep


# Generated at 2022-06-21 08:19:08.268486
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""

    assert colorize('ok', 1234, 'blue') == 'ok=1234'
    assert colorize('changed', 0, 'red') == 'changed=0'
    assert colorize('dark red', 100, 'dark red') != 'dark red=100'
# --- end "pretty"

# --- begin "graph"
#
# graph - A mini library that provides a DOT format graph writer.
#
# Copyright (c) 2012 Cisco Systems, Inc.
#
# Permission is hereby granted, free of charge, to any person obtaining a copy
# of this software and associated documentation files (the "Software"), to deal
# in the Software without restriction, including without limitation the rights
# to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
# copies of the Software, and to permit persons

# Generated at 2022-06-21 08:19:20.192865
# Unit test for function colorize
def test_colorize():
    #Save stdout
    stdout_fd = sys.stdout
    my_fd = open('/dev/null','w')
    sys.stdout = my_fd

    #Turn off color
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    # test without color, lead = 'num'
    lead = 'test'
    num = '0'
    color = 'blue'
    expected = '%s=%-4s' % (lead, num)
    result = colorize(lead, num, color)
    assert result == expected

    # test with color
    ANSIBLE_COLOR = True
    expected = '%s=%-4s' % (stringc(lead, color), num)
    result = colorize(lead, num, color)
    assert result == expected

    # test with color and num

# Generated at 2022-06-21 08:19:28.373722
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""

    def test_c(s, c):
        """Test stringc for given color code."""
        return stringc(s, c) == u"\033[%sm%s\033[0m" % (parsecolor(c), s)

    assert test_c('foo', 'black')
    assert test_c('foo', 'red')
    assert test_c('foo', 'green')
    assert test_c('foo', 'yellow')
    assert test_c('foo', 'blue')
    assert test_c('foo', 'magenta')
    assert test_c('foo', 'cyan')
    assert test_c('foo', 'white')
    assert test_c('foo', '8')
    assert test_c('foo', '250')

# Generated at 2022-06-21 08:19:57.398388
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {
        'changed': 0,
        'failures': 0,
        'ok': 1,
        'skipped': 0,
        'unreachable': 0,
    }

    def _test_hostcolor(color=True):
        return hostcolor(host, stats, color)

    def _assert_color_in(color, s):
        assert s.startswith(u'\033[%sm' % (parsecolor(color),))
        assert s.endswith(u'\033[0m')

    _assert_hostcolor_ok = _test_hostcolor(color=True)

    assert not hostcolor(host, stats, color=False).startswith(u'\033')

    _assert_color_in('green', _assert_hostcolor_ok)



# Generated at 2022-06-21 08:20:06.885187
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == "31"
    assert parsecolor("RED") == "31"
    assert parsecolor("rgb255255255") == "38;5;15"
    assert parsecolor("rgb000255255") == "38;5;6"
    assert parsecolor("rgb255255000") == "38;5;220"
    assert parsecolor("rgb000255000") == "38;5;2"
    assert parsecolor("rgb255000000") == "38;5;196"
    assert parsecolor("rgb000000000") == "38;5;16"
    assert parsecolor("rgb100100100") == "38;5;232"
    assert parsecolor("gray23") == "38;5;59"

# Generated at 2022-06-21 08:20:12.764837
# Unit test for function stringc
def test_stringc():
    global ANSIBLE_COLOR

    ANSIBLE_COLOR = True
    assert stringc('TEST', 'blue') == '\033[34mTEST\033[0m'
    assert stringc('TEST', 'color10') == '\033[38;5;10mTEST\033[0m'
    assert stringc('TEST', 'rgb2551525') == '\033[38;5;9mTEST\033[0m'
    assert stringc('TEST', 'gray0') == '\033[38;5;232mTEST\033[0m'

    # when ANSIBLE_COLOR is False, the string should pass through, unchanged
    ANSIBLE_COLOR = False
    assert stringc('TEST', 'blue') == 'TEST'

# Generated at 2022-06-21 08:20:20.972880
# Unit test for function hostcolor
def test_hostcolor():
    # This function has a lot of logic, it's best to check it as
    # thoroughly as possible.
    host = "myhost"
    fails = {"failures":1, "unreachable":0, "changed":0}
    unreach = {"failures":0, "unreachable":1, "changed":0}
    changed = {"failures":0, "unreachable":0, "changed":1}
    nochange = {"failures":0, "unreachable":0, "changed":0}
    color_true = {"color":True}
    color_false = {"color":False}
    # Check that host is not colorized if color is False
    assert hostcolor(host, fails, **color_false) == "%-26s" % host

# Generated at 2022-06-21 08:20:30.707464
# Unit test for function stringc
def test_stringc():
    print(stringc("stringc", "blue"))
    print(stringc("stringc", "blue", True))
    print(stringc("stringc", "rgb100"))
    print(stringc("stringc", "rgb010"))
    print(stringc("stringc", "rgb001"))
    print(stringc("stringc", "gray0"))
    print(stringc("stringc", "gray7"))
    print(stringc("stringc", "gray15"))


if __name__ == '__main__':
    ANSIBLE_COLOR = True
    test_stringc()

# --- end "pretty"

# Generated at 2022-06-21 08:20:40.455323
# Unit test for function colorize
def test_colorize():
    pass
    # def get_color_diff(color_from, color_to):
    #     from_code = parsecolor(color_from)
    #     to_code = parsecolor(color_to)
    #     return stringc("color", from_code, to_code)
    # lead = "Test"
    # num = 0
    # for color in C.COLOR_CODES:
    #     print("%s = %s" % (color, colorize(lead, num, color)))
    # num = 1
    # for color in C.COLOR_CODES:
    #     print("%s = %s" % (color, colorize(lead, num, color)))

# --- end of "pretty"



# Generated at 2022-06-21 08:20:47.067739
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'34'
    assert parsecolor('black') == u'30'
    assert parsecolor('white') == u'37'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('ansiblered') == u'31'
    assert parsecolor('ansiblegreen') == u'32'
    assert parsecolor('ansibleyellow') == u'33'
    assert parsecolor('ansibleblue') == u'34'
    assert parsecolor('ansiblemagenta') == u'35'
    assert parsecolor('ansiblecyan') == u'36'
    assert parsecolor('ansiblewhite') == u'37'
    assert parsecolor('ansiblegrey') == u'90'

# Generated at 2022-06-21 08:20:58.818056
# Unit test for function parsecolor
def test_parsecolor():
    """@TODO: Docstring for test_parsecolor.
    :returns: @TODO

    """
    colors = [
        "color8",
        "color17",
        "color88",
        "color177",
        "color288",
        "color3",
        "color14",
        "color25",
        "rgb300",
        "rgb333",
        "rgb222",
        "gray7",
        "gray0"
    ]

    print('')
    print('Testing parsecolor():')
    print('=====================')

    passed = 0
    failed = 0
    total = 0

    for color in colors:
        print('Testing color: %s' % color)
        print('Expected: %s' % C.COLOR_CODES[color])


# Generated at 2022-06-21 08:21:09.238213
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""
    if ANSIBLE_COLOR:
        assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
        assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"
        assert stringc('foo', 'blue') == u"\033[34mfoo\033[0m"
        assert stringc('foo', 'magenta') == u"\033[35mfoo\033[0m"
        assert stringc('foo', 'cyan') == u"\033[36mfoo\033[0m"
        assert stringc('foo', 'white') == u"\033[37mfoo\033[0m"

# Generated at 2022-06-21 08:21:15.525962
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}, color=True))
    print(hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1}, color=True))
    print(hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 2}, color=True))
    print(hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0}, color=True))
    print(hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0}, color=True))
    print(hostcolor('host', {'failures': 1, 'unreachable': 1, 'changed': 2}, color=True))

# --- end of "pretty

# Generated at 2022-06-21 08:21:45.429688
# Unit test for function colorize
def test_colorize():
    def assert_equal(actual, expected):
        assert actual == expected, "got %s but expected %s" % (actual, expected)

    assert_equal(colorize('test', 0, 'red'), "test=0   ")
    assert_equal(colorize('test', 1, 'green'), "test=1   ")
    assert_equal(colorize('test', 'ignored', 'blue'), "test=ignore")
    assert_equal(colorize('test', 2, 'yellow'), "test=2   ")

# --- end "pretty"

# This is set to True (color on) when we explicitly set color off in the CLI.
# This is so we can enable color output when the terminal supports it, if the
# user specifies color=yes in ansible.cfg.
#
# This is a hack, but I wanted to avoid