

# Generated at 2022-06-21 08:11:54.511289
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor('localhost', dict(failures=1, unreachable=0, changed=0))
    hostcolor('localhost', dict(failures=0, unreachable=1, changed=0))
    hostcolor('localhost', dict(failures=0, unreachable=0, changed=1))
    hostcolor('localhost', dict(failures=0, unreachable=0, changed=0))

# --- end "pretty"

# supported colors for .ansible.cfg


# Generated at 2022-06-21 08:11:59.924949
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == "localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == "localhost                "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == "localhost                "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == "localhost                "
    # TODO: test the output with ANSIBLE_COLOR=False



# Generated at 2022-06-21 08:12:03.722146
# Unit test for function hostcolor
def test_hostcolor():
    """Test hostcolor method"""
    stats = dict(failures=0, unreachable=0, changed=0)
    host = 'test'
    print(hostcolor(host, stats, color=True))

# Generated at 2022-06-21 08:12:11.152062
# Unit test for function stringc
def test_stringc():
    r = u"\033[31mred\033[0m"
    assert stringc(u'red', 'red') == r
    assert stringc(u' red ', 'red') == r
    assert stringc(u'\nred\n', 'red') == u"\n%s\n" % r
    assert stringc(u'\n red \n', 'red') == u"\n %s \n" % r


# --- end "pretty"

# Generated at 2022-06-21 08:12:19.815446
# Unit test for function stringc

# Generated at 2022-06-21 08:12:30.723078
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        # For a given color name, it should print
        # the ANSI escape sequence for that color.
        assert stringc(u"foo", u'blue') == u"\033[34mfoo\033[0m"

        # For a given color name, it should print
        # the ANSI escape sequence for that color.
        assert stringc(u"foo", u'bold') == u"\033[1mfoo\033[0m"

        # For a given color name, it should print
        # the ANSI escape sequence for that color.
        assert stringc(u"foo", u'brown') == u"\033[33mfoo\033[0m"

        # For a given color name, it should print
        # the ANSI escape sequence for that color.

# Generated at 2022-06-21 08:12:39.979425
# Unit test for function hostcolor
def test_hostcolor():
    testhost = 'host.example.com'
    # Test different combinations of stats[]
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    s = hostcolor(testhost, stats)
    assert (s == 'host.example.com               ')
    stats['changed'] = 1
    s = hostcolor(testhost, stats)
    assert (s == stringc('host.example.com', C.COLOR_CHANGED))
    stats['changed'] = 0
    stats['unreachable'] = 1
    s = hostcolor(testhost, stats)
    assert (s == stringc('host.example.com', C.COLOR_ERROR))
    stats['unreachable'] = 0
    stats['failures'] = 1

# Generated at 2022-06-21 08:12:50.087598
# Unit test for function stringc
def test_stringc():
    print(stringc("text", "green"))
    print(stringc("text", "COLOR_GREEN"))
    print(stringc("text", "yellow"))
    print(stringc("text", "COLOR_YELLOW"))
    print(stringc("text", "blue"))
    print(stringc("text", "COLOR_BLUE"))
    print(stringc("text", "magenta"))
    print(stringc("text", "COLOR_MAGENTA"))
    print(stringc("text", "cyan"))
    print(stringc("text", "COLOR_CYAN"))
    print(stringc("text", "white"))
    print(stringc("text", "COLOR_WHITE"))
    print(stringc("text", "red"))
    print(stringc("text", "COLOR_RED"))

# Generated at 2022-06-21 08:12:58.069049
# Unit test for function parsecolor
def test_parsecolor():
    """Test method for parsecolor"""
    assert parsecolor("YELLOW") == u"33"
    assert parsecolor("RED") == u"31"
    assert parsecolor("BLACK") == u"30"
    assert parsecolor("color8") == u"38;5;8"
    assert parsecolor("rgb2553300") == u"38;5;196"
    assert parsecolor("gray00") == u"38;5;232"


# --- end "pretty"

# Generated at 2022-06-21 08:13:08.890635
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(), True) == u"\x1b[0;32mlocalhost               \x1b[0;0m"
    assert hostcolor("localhost", dict(failures=1), True) == u"\x1b[0;31mlocalhost               \x1b[0;0m"
    assert hostcolor("localhost", dict(failures=1, unreachable=1), True) == u"\x1b[0;31mlocalhost               \x1b[0;0m"
    assert hostcolor("localhost", dict(changed=1), True) == u"\x1b[0;33mlocalhost               \x1b[0;0m"
    # Right color, but incorrect number of characters
    assert hostcolor("localhost", dict(changed=1), False) == u"localhost             "

# Generated at 2022-06-21 08:13:22.741862
# Unit test for function stringc

# Generated at 2022-06-21 08:13:35.666621
# Unit test for function parsecolor
def test_parsecolor():
    def test(value, expected, desc):
        """Assert that parsecolor(value) == expected."""
        result = parsecolor(value)
        if result != expected:
            raise AssertionError("%s: %r != %r" % (desc, result, expected))

    test("black", "30", "basic color name")
    test("rgb000", "38;5;16", "rgb color")
    test("rgb010", "38;5;22", "rgb color")
    test("rgb322", "38;5;124", "rgb color")
    test("rgb333", "38;5;124", "rgb color")
    test("gray0", "38;5;232", "gray color")
    test("gray1", "38;5;233", "gray color")


# Generated at 2022-06-21 08:13:44.275505
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == "31"
    assert parsecolor('0') == "38;5;0"
    assert parsecolor('rgb255000') == "38;5;9"
    assert parsecolor('rgb255024') == "38;5;10"
    assert parsecolor('rgb255255255') == "38;5;231"
    assert parsecolor('gray0') == "38;5;232"
    assert parsecolor('gray23') == "38;5;255"
    assert parsecolor('bogus') == "38;5;0"

# tests for function hostcolor

# Generated at 2022-06-21 08:13:57.165189
# Unit test for function hostcolor
def test_hostcolor():
    HOST = "testhost"
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(HOST, stats) == u"%-26s" % HOST
    assert hostcolor(HOST, stats, False) == u"%-26s" % HOST
    assert hostcolor(HOST, stats, True) == u"%-37s" % stringc(HOST, C.COLOR_OK)

    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor(HOST, stats, True) == u"%-37s" % stringc(HOST, C.COLOR_ERROR)

    stats = dict(failures=0, unreachable=0, changed=1)

# Generated at 2022-06-21 08:14:03.719155
# Unit test for function stringc
def test_stringc():
    assert stringc("Hello world", "green", True) == "\001\033[38;5;28m\002Hello world\001\033[0m\002"
    assert stringc("Hello world", "green") == "\033[38;5;28mHello world\033[0m"
    assert stringc("Hello world", "rgb255255255") == "\033[38;5;231mHello world\033[0m"
    return True


# Generated at 2022-06-21 08:14:13.536741
# Unit test for function colorize
def test_colorize():
    from ansible.utils import py3

    if py3:
        str_class = str
    else:
        str_class = unicode

    assert type(colorize(u"foo", 0, None)) == str_class
    assert type(colorize(u"foo", 1, u"blue")) == str_class

    # color is ignored if ANSIBLE_COLOR == False
    try:
        orig_AC = ANSIBLE_COLOR
        ANSIBLE_COLOR = False
        assert type(colorize(u"foo", 1, u"blue")) == str_class
    finally:
        ANSIBLE_COLOR = orig_AC

    # color is used if ANSIBLE_COLOR == True

# Generated at 2022-06-21 08:14:24.272807
# Unit test for function stringc
def test_stringc():

    # Test standard colors
    assert stringc(u"blue", u"blue") == u"\033[34mblue\033[0m"
    assert stringc(u"yellow", u"yellow") == u"\033[33myellow\033[0m"
    assert stringc(u"red", u"red") == u"\033[31mred\033[0m"
    assert stringc(u"green", u"green") == u"\033[32mgreen\033[0m"
    assert stringc(u"cyan", u"cyan") == u"\033[36mcyan\033[0m"
    assert stringc(u"white", u"white") == u"\033[37mwhite\033[0m"

    # Test bright colors

# Generated at 2022-06-21 08:14:38.571047
# Unit test for function stringc
def test_stringc():
    assert stringc(u"hello world", u"blue") == '\033[34mhello world\033[0m'
    assert stringc(u"hello world", u"0") == '\033[38;5;0mhello world\033[0m'
    assert stringc(u"hello world", u"rgb555") == '\033[38;5;123mhello world\033[0m'
    assert stringc(u"hello world", u"rgb123") == '\033[38;5;15mhello world\033[0m'
    assert stringc(u"hello world", u"rgb333") == '\033[38;5;60mhello world\033[0m'

# Generated at 2022-06-21 08:14:45.810177
# Unit test for function colorize
def test_colorize():
    print(u"Testing colorize()")
    assert colorize(u'ok', 1, C.COLOR_OK) == u'\033[42mok=1   \033[0m'
    assert colorize(u'changed', 2, C.COLOR_CHANGED) == u'\033[43mchanged=2 \033[0m'
    assert colorize(u'failures', 3, C.COLOR_ERROR) == u'\033[41mfailures=3\033[0m'
    assert colorize(u'ok', 0, C.COLOR_OK) == u'ok=0   '
    assert colorize(u'changed', 0, C.COLOR_CHANGED) == u'changed=0 '

# Generated at 2022-06-21 08:14:57.290194
# Unit test for function stringc
def test_stringc():
    print(u"Testing colorization in ANSIBLE_COLOR=%s" % ANSIBLE_COLOR)
    print(u"Tests of colorization with various escape sequences")
    print(u"Note that invisible characters are not printed in most terminals.")
    print(u"Expected output is between '[' and ']' below.")
    print(u"[\x1b[35mThis is magenta text\x1b[0m]")
    print(u"[\x1b[35mThis is \x1b[01;31mred text on a magenta background\x1b[0m]")
    print(u"[\x1b[01;31mThis is red text on a normal terminal background\x1b[0m]")
    print(stringc(u"This is magenta text", u"magenta"))
    print

# Generated at 2022-06-21 08:15:10.078597
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, 'blue') == "foo=0   "
    assert colorize("foo", 1, 'blue') == "\001\033[38;5;12m\002foo=1   \001\033[0m\002"


# Generated at 2022-06-21 08:15:22.235310
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('default')            == u'39'
    assert parsecolor('black')              == u'30'
    assert parsecolor('darkred')            == u'31'
    assert parsecolor('red')                == u'31'
    assert parsecolor('red_hi')             == u'31'
    assert parsecolor('darkgreen')          == u'32'
    assert parsecolor('green')              == u'32'
    assert parsecolor('green_hi')           == u'32'
    assert parsecolor('brown')              == u'33'
    assert parsecolor('yellow')             == u'33'
    assert parsecolor('yellow_hi')          == u'33'
    assert parsecolor('darkblue')           == u'34'

# Generated at 2022-06-21 08:15:34.078495
# Unit test for function stringc
def test_stringc():
    """Test stringc with all color names."""
    cnames = tuple(C.COLOR_CODES.keys())

# Generated at 2022-06-21 08:15:39.054677
# Unit test for function colorize
def test_colorize():
    print(colorize('ok', 0, None))
    print(colorize('changed', 0, C.COLOR_CHANGED))
    print(colorize('unreachable', 0, C.COLOR_UNREACHABLE))
    print(colorize('failed', 0, C.COLOR_ERROR))
    print(colorize('ok', 10, None))
    print(colorize('changed', 10, C.COLOR_CHANGED))
    print(colorize('unreachable', 10, C.COLOR_UNREACHABLE))
    print(colorize('failed', 10, C.COLOR_ERROR))


# Generated at 2022-06-21 08:15:49.857137
# Unit test for function stringc
def test_stringc():
    # Check that list is parsable
    for key in C.COLOR_CODES:
        # get the color for this key
        color = parsecolor(key)
    # Check that the key 'white' exists in the color list
    assert parsecolor('white') == '97'
    # Check that the key 'rgb888' exists in the color list
    assert parsecolor('rgb888') == '38;5;245'


# --- end of "pretty" code from here to EOF ---

# code which used to exist in ansible.utils.color but was moved into this file
# in order to make it possible to remove ansible.utils.color with PYTHONOPTIMIZE=1



# Generated at 2022-06-21 08:15:57.806594
# Unit test for function colorize
def test_colorize():
    assert colorize(u'foo', u'0', u'none') == u'foo=0   '
    assert colorize(u'foo', u'0', u'black') == u'foo=0   '
    assert colorize(u'foo', u'0', u'white') == u'foo=0   '
    assert colorize(u'foo', u'0', u'blue') == u'foo=0   '

    assert colorize(u'bar', u'10', u'none') == u'bar=10  '
    assert colorize(u'bar', u'10', u'black') == u'bar=10  '
    assert colorize(u'bar', u'10', u'white') == u'bar=10  '
    assert colorize(u'bar', u'10', u'blue')

# Generated at 2022-06-21 08:16:09.758530
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        h = 'testhost'
        s = {'failures': 0, 'unreachable': 0, 'ok': 1}
        assert hostcolor(h, s, color=False) == u"%-26s" % h
        assert hostcolor(h, s) == u"%-37s" % stringc(h, C.COLOR_OK)
        s = {'failures': 0, 'unreachable': 1, 'ok': 0}
        assert hostcolor(h, s) == u"%-37s" % stringc(h, C.COLOR_ERROR)
        s = {'failures': 1, 'unreachable': 0, 'ok': 0}
        assert hostcolor(h, s) == u"%-37s" % stringc(h, C.COLOR_ERROR)

# Generated at 2022-06-21 08:16:16.296317
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 100, 'blue') == 'foo=100 '


# --- end "pretty"

# Generated at 2022-06-21 08:16:27.179413
# Unit test for function hostcolor
def test_hostcolor():
    test_stats = {
        'failures': 1,
        'unreachable': 0,
        'changed': 0
    }
    test_stats2 = {
        'failures': 0,
        'unreachable': 0,
        'changed': 1
    }
    test_stats3 = {
        'failures': 0,
        'unreachable': 0,
        'changed': 0
    }

    test_host = u"foo_host"
    test_candidate = u"%-37s" % stringc(test_host, C.COLOR_ERROR)
    test_candidate2 = u"%-37s" % stringc(test_host, C.COLOR_CHANGED)
    test_candidate3 = u"%-37s" % stringc(test_host, C.COLOR_OK)
   

# Generated at 2022-06-21 08:16:34.858004
# Unit test for function hostcolor
def test_hostcolor():
    import random
    host = 'host123'
    stats = {'failures': random.randrange(0,3),
             'unreachable': random.randrange(0,3),
             'changed': random.randrange(0,3)}
    print(hostcolor(host, stats))


# --- begin ansible.utils.unicode

# unicode handling for Python 2 and 3 - from http://python-future.org/unicode_literals.html
if sys.version_info[0] >= 3:
    import builtins
    text_type = str
    binary_type = bytes
    string_types = (str,)
    integer_types = (int,)
    class_types = (type,)
    unicode = str
    basestring = (str, bytes)
    long = int

# Generated at 2022-06-21 08:16:44.976189
# Unit test for function stringc
def test_stringc():
    assert stringc("Test", 'blue') == u"\033[34mTest\033[0m"

# Generated at 2022-06-21 08:16:54.620884
# Unit test for function stringc
def test_stringc():
    """Tests for function stringc."""

    assert u"\033[31mfoo\033[0m" == stringc(u"foo", u"RED")
    assert u"\033[38;5;124mfoo\033[0m" == stringc(u"foo", u"124")
    assert u"\033[38;5;124mfoo\033[0m" == stringc(u"foo", u"rgb20204")
    assert u"\033[38;5;124mbar\033[0m" == stringc(u"bar", u"rgb2 0 2 04")
    assert u"\033[38;5;229mfoo\033[0m" == stringc(u"foo", u"gray1")

# Generated at 2022-06-21 08:17:03.414315
# Unit test for function stringc
def test_stringc():
    from nose.tools import assert_equal

    # test the color codes
    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        assert_equal(stringc('foo', color.upper()), '\033[%smfoo\033[0m' % C.COLOR_CODES[color])

    # test the rgb codes
    assert_equal(stringc('foo', 'rgb123'), '\033[38;5;100mfoo\033[0m')

    # test the gray codes
    assert_equal(stringc('foo', 'gray9'), '\033[38;5;231mfoo\033[0m')



# Generated at 2022-06-21 08:17:14.215108
# Unit test for function colorize
def test_colorize():
    colorcodes = C.COLOR_CODES
    code = parsecolor('green')
    assert code != colorcodes['green']
    assert code == '32'
    code = parsecolor('blue')
    assert code != colorcodes['blue']
    assert code == '34'
    code = parsecolor('yellow')
    assert code != colorcodes['yellow']
    assert code == '33'
    code = parsecolor('lightgray')
    assert code != colorcodes['lightgray']
    assert code == '37'
    code = parsecolor('darkgray')
    assert code != colorcodes['darkgray']
    assert code == '90'


# -- end "pretty"

# -----------------------------------------------------------
# each plugin should have it's own object,
# so ansible.plugins.foo is the file foo.py
# the global

# Generated at 2022-06-21 08:17:23.683399
# Unit test for function colorize
def test_colorize():
    if not (colorize('foo', 0, None) == u'foo=0   ' and
            colorize('foo', 0, 'blue') == u'foo=0   ' and
            colorize('foo', 1, 'blue') == u'\033[94mfoo=1  \033[0m'):
        sys.exit(1)

if __name__ == '__main__':
    test_colorize()

# --- end "pretty"

# global counter for number of items/tasks processed

counter = 0



# Generated at 2022-06-21 08:17:29.691839
# Unit test for function stringc
def test_stringc():
    assert u'[0m' == stringc(u'', None)
    assert u'[0m' == stringc(u'', u'')
    assert u'[0;31merr[0m' == stringc(u'err', u'RED')
    assert u'[0;31merr[0m' == stringc(u'err', u'RED')
    assert u'[0;32mok[0m' == stringc(u'ok', u'GREEN')
    assert u'[0;33mchanged[0m' == stringc(u'changed', u'YELLOW')
    assert u'[0;34mblue[0m' == stringc(u'blue', u'BLUE')

# Generated at 2022-06-21 08:17:40.402423
# Unit test for function hostcolor

# Generated at 2022-06-21 08:17:53.059964
# Unit test for function colorize
def test_colorize():
    """Unit test for colorize()"""
    # TODO: only tests the terminal output - _is_ the output correct?
    import textwrap

    def w(s):
        return textwrap.wrap(s, 76)[0]

    # Don't colorize
    C.ANSIBLE_NOCOLOR = True
    print(w(u'changed: [server1] => {changed=1}'))
    print(w(u'failed: [server1] => {failed=0}'))

    # Colorize changed only
    C.ANSIBLE_NOCOLOR = False
    print(w(u'changed: [server1] => {changed=1}'))
    print(w(u'failed: [server1] => {failed=0}'))

    # Colorize failed only

# Generated at 2022-06-21 08:18:00.430323
# Unit test for function stringc
def test_stringc():
    assert stringc("a string", "black") == u"\033[30ma string\033[0m"
    assert stringc("color256", "color256") == u"\033[38;5;256mcolor256\033[0m"
    assert stringc("rgb123", "rgb123") == u"\033[38;5;123mrgb123\033[0m"
    assert stringc("gray24", "gray24") == u"\033[38;5;250mgray24\033[0m"


# colorize unit test

# Generated at 2022-06-21 08:18:13.222713
# Unit test for function colorize
def test_colorize():
    # ANSIBLE_COLOR is False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('lead', 'num', 'color') == u'lead=num '
    ANSIBLE_COLOR = True

    # num=0
    assert colorize('lead', 0, None) == u'lead=0   '

    # num!=0 and color=None
    assert colorize('lead', 'num', None) == u'lead=num '

    # num!=0 and color!=None
    sys.stdout.isatty = lambda: True
    # Define function parsecolor
    def parsecolor(color):
        return color

# Generated at 2022-06-21 08:18:29.707143
# Unit test for function stringc
def test_stringc():
    # Test single line without newline
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"

    # Test single line with newline
    assert stringc("bar\nbaz", "blue") == u"\033[34mbar\n\033[0mbaz\033[0m"

    # Test multiple lines with newline
    assert stringc("bar\nbaz\nqux", "green") == u"\033[32mbar\n\033[0mbaz\n\033[0mqux\033[0m"

    # Test that newlines are preserved outside of ANSI color codes

# Generated at 2022-06-21 08:18:33.011132
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, "green") == "foo=0   "
    assert colorize("foo", 1, "green") == stringc("foo=1   ", "green")
    assert colorize("foo", 255, "green") == stringc("foo=255 ", "green")


# Generated at 2022-06-21 08:18:39.892370
# Unit test for function hostcolor
def test_hostcolor():
    """ simple unit test to make sure the hostcolor function is doing what it should """
    test_hosts = [
        ('foo', {'ok': 10, 'changed': 4, 'unreachable': 0, 'failures': 0}),
        ('bar', {'ok': 10, 'changed': 0, 'unreachable': 1, 'failures': 0}),
        ('baz', {'ok': 10, 'changed': 0, 'unreachable': 0, 'failures': 1}),
    ]
    for host, stats in test_hosts:
        print(hostcolor(host, stats))



# Generated at 2022-06-21 08:18:52.058085
# Unit test for function hostcolor
def test_hostcolor():
    s = dict(changed=0, failures=0, unreachable=0)
    assert hostcolor("localhost", s) == u"localhost"
    assert hostcolor("localhost", s, False) == u"localhost"

    s = dict(changed=1, failures=0, unreachable=0)
    assert hostcolor("localhost", s) != u"localhost"
    assert hostcolor("localhost", s, False) == u"localhost"

    s = dict(changed=0, failures=1, unreachable=0)
    assert hostcolor("localhost", s) != u"localhost"
    assert hostcolor("localhost", s, False) == u"localhost"

    s = dict(changed=0, failures=0, unreachable=1)
    assert hostcolor("localhost", s) != u"localhost"

# Generated at 2022-06-21 08:19:01.548275
# Unit test for function colorize
def test_colorize():
    """ unit test for colorize function """
    test_str = u"12345"
    assert len(colorize(test_str, 0, 'black')) == len(test_str) + 6
    assert colorize(test_str, 0, 'black').endswith("0")
    assert len(colorize(test_str, 3, 'black')) == len(test_str) + 6
    assert colorize(test_str, 3, 'black').endswith("3")
    assert len(colorize(test_str, 3, 'black')) == len(colorize(test_str, 30, 'black'))



# Generated at 2022-06-21 08:19:09.495297
# Unit test for function stringc
def test_stringc():
    import sys
    # print ("sys.stdout.isatty() = %r" % (sys.stdout.isatty()))
    if sys.stdout.isatty():
        pass
        # print ("ANSI color works in Console")
    else:
        pass
        # print ("Nope. This won't work in Console")
    s = stringc(u"This is color!", "red")
    # print (s)
    s = stringc(u"This is color!", "green")
    # print (s)
    s = stringc(u"This is color!", "rgb255")
    # print (s)
    s = stringc(u"This is color!", "rgb255", True)
    # print (s)

# Generated at 2022-06-21 08:19:21.103235
# Unit test for function colorize
def test_colorize():
    print(u"Testing colorize()")
    print(u"------------------")
    print(u"Tests for colorize(lead='ok', num=0, color='green')")
    print(colorize(u'ok', 0, color='green'))
    for i in range(1, 51):
        print(u"Tests for colorize(lead='ok', num=%d, color='green')" % i)
        print(colorize(u'ok', i, color='green'))

    print(u"Tests for colorize(lead='changed', num=0, color='yellow')")
    print(colorize(u'changed', 0, color='yellow'))

# Generated at 2022-06-21 08:19:26.730823
# Unit test for function colorize
def test_colorize():
    # Colorize a string
    assert colorize("x", "1", "red") == stringc("x=1   ", "red")

    # Colorize a string, but with zero
    assert colorize("x", "0", "red") == "x=0   "

    # disable coloring
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False

    # Colorize a string, with ANSIBLE_COLOR disabled
    assert colorize("x", "1", "red") == "x=1   "

# Generated at 2022-06-21 08:19:38.988031
# Unit test for function colorize
def test_colorize():
    # Test with leading space for make target
    # Test C.COLOR_SKIP
    # Test C.COLOR_WARN
    # Test no color
    print(u"%-26s" % u"")
    print(u"%-26s" % (u"SKIPPED = %d" % 1))
    print(u"%-26s" % (u"SKIPPED = %d" % 1))
    print(u"%-26s" % (u"SKIPPED = %d" % 0))
    print(u"%-26s" % (u"CHANGED = %d" % 1))
    print(u"%-26s" % (u"CHANGED = %d" % 0))
    print(u"%-26s" % (u"OK = %d" % 1))

# Generated at 2022-06-21 08:19:50.448355
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '38;5;4'
    assert parsecolor('bright purple') == '38;5;141'
    assert parsecolor('rgb123') == '38;5;113'
    assert parsecolor('rgb321') == '38;5;111'
    assert parsecolor('rgb213') == '38;5;118'
    assert parsecolor('rgb231') == '38;5;116'
    assert parsecolor('rgb312') == '38;5;119'
    assert parsecolor('rgb132') == '38;5;103'
    assert parsecolor('rgb123') == '38;5;113'
    assert parsecolor('rgb222') == '38;5;244'

# Generated at 2022-06-21 08:20:07.076885
# Unit test for function parsecolor

# Generated at 2022-06-21 08:20:14.036904
# Unit test for function colorize
def test_colorize():
    lead = "test"
    num1 = 1
    num2 = 0
    color1 = 'red'
    color2 = None
    assert colorize(lead, num1, color1) == u'\n'.join([u"\001\033[38;5;9m\002test=1   \001\033[0m\002"])
    assert colorize(lead, num2, color2) == u'test=0   '
# --- end of pretty



# Generated at 2022-06-21 08:20:20.046762
# Unit test for function stringc
def test_stringc():
    """Your terminal should show a red 'red', a green 'green',
    and a blue 'blue' if this function is working properly."""

    # Byte-compilation fails if ANSIBLE_COLOR is not set, so set it here
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    print(stringc("red", "RED"))
    print(stringc("green", "GREEN"))
    print(stringc("blue", "BLUE"))


if __name__ == "__main__":
    test_stringc()

# --- end "pretty"

# Generated at 2022-06-21 08:20:25.325661
# Unit test for function colorize
def test_colorize():
    lead, num, color = u"test", u"1", "red"
    s = "%s=%-4s" % (lead, num)
    s_test = colorize(lead, num, color)
    assert(s_test == s)
# --- end "pretty"

# Generated at 2022-06-21 08:20:27.982081
# Unit test for function stringc
def test_stringc():
    """Test stringc formatting with color"""
    s = stringc('blue text', 'blue')
    assert s == u"\033[34mblue text\033[0m"



# Generated at 2022-06-21 08:20:30.945577
# Unit test for function stringc
def test_stringc():
    assert stringc(u'test', 'black', False) == u"\x1b[30mtest\x1b[0m"


# --- end of "pretty"


# Generated at 2022-06-21 08:20:41.358025
# Unit test for function hostcolor
def test_hostcolor():
    test_passed = True
    test_msg = []

    stats = {'failures': 0,
             'unreachable': 0,
             'changed': 0,
             'ok': 0,
             'skipped': 0}

    # Happy flow
    color = hostcolor("localhost", stats)
    if color != u"%-37s" % u"localhost":
        test_passed = False
        test_msg.append("Testcase 1: Expected color for localhost is '%-37s' but it is '%s'" % (u"localhost", color))

    # Test changed
    stats['changed'] = 1
    color = hostcolor("localhost", stats)
    if color != u"%-37s" % stringc("localhost", C.COLOR_CHANGED):
        test_passed = False
        test_msg.append

# Generated at 2022-06-21 08:20:53.265361
# Unit test for function parsecolor

# Generated at 2022-06-21 08:20:55.797219
# Unit test for function colorize
def test_colorize():
    # a test where we know the answer
    assert colorize("foo", 1, 'red') == stringc("foo=1   ", 'red')

# Generated at 2022-06-21 08:21:06.499513
# Unit test for function hostcolor
def test_hostcolor():
    """
    >>> hostcolor("localhost", dict(ok=1, changed=1, unreachable=0,
    ... failed=0))
    'localhost                 '
    >>> hostcolor("localhost", dict(ok=1, changed=0, unreachable=1,
    ... failed=0))
    'localhost                 '
    >>> hostcolor("localhost", dict(ok=1, changed=0, unreachable=0,
    ... failed=1))
    'localhost                 '
    """

# --- end "pretty"

# --- begin "pager"

if not sys.stdout.isatty() or not sys.stdout.encoding:
    try:
        import locale
        locale.getdefaultlocale()
    except:
        C.ANSIBLE_PAGER = False


# Generated at 2022-06-21 08:21:24.755364
# Unit test for function colorize
def test_colorize():
    global ANSIBLE_COLOR
    old_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = True

# Generated at 2022-06-21 08:21:28.567244
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'blue', 'yellow', 'cyan',
              'magenta', 'white', 'black', 'default'):
        print(u"%12s %s" % (c, colorize(u'foo', 42, c)))


# Generated at 2022-06-21 08:21:32.639429
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert parsecolor('red') == u'31'
        assert parsecolor('color1') == u'38;5;1'
        assert parsecolor('rgb111') == u'38;5;18'
        assert parsecolor('gray2') == u'38;5;234'


# Generated at 2022-06-21 08:21:45.021986
# Unit test for function hostcolor
def test_hostcolor():
    # pylint: disable=W8201
    host = 'localhost'
    stats = dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0)

    # Color defaults to True
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)

    # When ANSIBLE_COLOR is False, color is False by default.
    assert hostcolor(host, stats, color=False) == u"%-37s" % stringc(host, C.COLOR_OK)
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_OK)

    # When ANSIBLE_COLOR is False, hostcolor should not be colored
    global ANSIBLE