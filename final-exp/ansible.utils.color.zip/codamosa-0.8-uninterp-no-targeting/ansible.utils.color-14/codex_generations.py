

# Generated at 2022-06-21 08:11:55.482492
# Unit test for function hostcolor
def test_hostcolor():
    # Don't use color
    assert hostcolor('localhost', {'failures': 0, 'changed': 0, 'unreachable': 0, 'ok': 0}, color=False) == "%-26s" % 'localhost'
    assert hostcolor('localhost', {'failures': 1, 'changed': 0, 'unreachable': 0, 'ok': 0}, color=False) == "%-26s" % 'localhost'
    assert hostcolor('localhost', {'failures': 0, 'changed': 1, 'unreachable': 0, 'ok': 0}, color=False) == "%-26s" % 'localhost'
    assert hostcolor('localhost', {'failures': 0, 'changed': 0, 'unreachable': 1, 'ok': 0}, color=False) == "%-26s" % 'localhost'

    # Use color
    assert host

# Generated at 2022-06-21 08:12:01.758417
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {
        'changed': 0,
        'failures': 0,
        'ok': 0,
        'skipped': 0,
        'unreachable': 0
    }
    # should return a string colored with C.COLOR_OK
    print(hostcolor(host, stats))
    # should return a string colored with C.COLOR_CHANGED
    stats['changed'] = 1
    print(hostcolor(host, stats))
    # should return a string colored with C.COLOR_ERROR
    stats['changed'] = 0
    stats['failures'] = 1
    print(hostcolor(host, stats))
    # should return a string not colored
    print(hostcolor(host, stats, color=False))

if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-21 08:12:13.267660
# Unit test for function parsecolor
def test_parsecolor():
    from ansible.playbook.play_context import PlayContext

    def test(s, color):
        assert parsecolor(s) == color

    test('black', u'38;5;0')
    test('red', u'38;5;1')
    test('green', u'38;5;2')
    test('yellow', u'38;5;3')
    test('blue', u'38;5;4')
    test('purple', u'38;5;5')
    test('cyan', u'38;5;6')
    test('white', u'38;5;7')
    test('BRIGHT_BLACK', u'38;5;8')
    test('BRIGHT_RED', u'38;5;9')

# Generated at 2022-06-21 08:12:18.889212
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == '%-26s' % stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == '%-26s' % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == '%-26s' % stringc("localhost", C.COLOR_CHANGED)



# Generated at 2022-06-21 08:12:29.173613
# Unit test for function parsecolor
def test_parsecolor():
    # Negative test: attempt to parse an invalid color name
    try:
        parsecolor('foobar')
    except KeyError as err:
        if str(err) == "'foobar'":
            pass
        else:
            raise

    # Negative test: attempt to parse an unknown escape sequence
    try:
        parsecolor('unknown')
    except KeyError as err:
        if str(err) == "'unknown'":
            pass
        else:
            raise

    # Positive tests: parse color names
    if parsecolor('black') != '30':
        raise Exception("Color name 'black' failed")
    if parsecolor('red') != '31':
        raise Exception("Color name 'red' failed")
    if parsecolor('green') != '32':
        raise Exception("Color name 'green' failed")

# Generated at 2022-06-21 08:12:39.146412
# Unit test for function hostcolor
def test_hostcolor():
    host = 'www.example.com'
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 1

    assert hostcolor(host, stats, color=True) != hostcolor(host, stats, color=False)

    stats['changed'] = 0
    assert hostcolor(host, stats, color=True) != hostcolor(host, stats, color=False)

    stats['unreachable'] = 1
    assert hostcolor(host, stats, color=True) != hostcolor(host, stats, color=False)

    stats['unreachable'] = 0
    stats['failures'] = 1
    assert hostcolor(host, stats, color=True) != hostcolor(host, stats, color=False)

# --- End "pretty"

# Generated at 2022-06-21 08:12:49.316902
# Unit test for function parsecolor
def test_parsecolor():
    def eq(color, expected):
        assert expected == parsecolor(color)

    eq('black', '30')
    eq('white', '37')
    eq('red', '31')
    eq('green', '32')
    eq('brown', '33')
    eq('blue', '34')
    eq('cyan', '36')
    eq('yellow', '33')
    eq('dark gray', '1;30')
    eq('light red', '1;31')
    eq('light green', '1;32')
    eq('light blue', '1;34')
    eq('light cyan', '1;36')
    eq('light gray', '37')

    eq('color0', '38;5;0')
    eq('color1', '38;5;1')

# Generated at 2022-06-21 08:12:55.987183
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=0, failures=0, unreachable=0)
    assert hostcolor('host1', stats, True) == u'host1                     '
    assert hostcolor('host2', stats, False) == u'host2                    '
    stats['changed'] = 1
    assert hostcolor('host3', stats, True) == u'host3                      \x1b[0;34m\x1b[0m'
    assert hostcolor('host4', stats, False) == u'host4                    '
    stats['changed'] = 0
    stats['failures'] = 1
    assert hostcolor('host5', stats, True) == u'host5                      \x1b[0;31m\x1b[0m'
    assert hostcolor('host6', stats, False) == u'host6                    '

# Generated at 2022-06-21 08:13:00.120090
# Unit test for function colorize
def test_colorize():
    print(u"TEST ", end="")
    print(colorize("a", 1, "blue"))
    print(u"TEST ", end="")
    print(colorize("a", 1, None))

# Generated at 2022-06-21 08:13:11.669484
# Unit test for function hostcolor

# Generated at 2022-06-21 08:13:32.697588
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    assert stringc("test", "black") == u"\x1b[0mtest\x1b[0m"
    assert stringc("test", "blue") == u'\x1b[34mtest\x1b[0m'
    assert stringc("test", "green") == u'\x1b[32mtest\x1b[0m'
    assert stringc("test", "magenta") == u'\x1b[35mtest\x1b[0m'
    assert stringc("test", "red") == u'\x1b[31mtest\x1b[0m'
    assert stringc("test", "yellow") == u'\x1b[33mtest\x1b[0m'

# Generated at 2022-06-21 08:13:44.234930
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('none') == C.COLOR_CODES['none']
    assert parsecolor('black') == C.COLOR_CODES['black']
    assert parsecolor('red') == C.COLOR_CODES['red']
    assert parsecolor('green') == C.COLOR_CODES['green']
    assert parsecolor('yellow') == C.COLOR_CODES['yellow']
    assert parsecolor('blue') == C.COLOR_CODES['blue']
    assert parsecolor('magenta') == C.COLOR_CODES['magenta']
    assert parsecolor('cyan') == C.COLOR_CODES['cyan']
    assert parsecolor('white') == C.COLOR_CODES['white']

# Generated at 2022-06-21 08:13:55.013596
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", "red") == u"\033[31mhello\033[0m"
    assert stringc("hello", "blue") == u"\033[34mhello\033[0m"
    assert stringc("hello", "on_green") == u"\033[42mhello\033[0m"
    assert stringc("hello", "on_bright_yellow") == u"\033[103mhello\033[0m"
    assert stringc("hello", "red", True) == u"\u0011\033[31m\u0012hello\u0011\033[0m\u0012"


# Generated at 2022-06-21 08:14:06.067961
# Unit test for function stringc
def test_stringc():
    assert stringc(u"SAMPLE", u"blue", True) == u"\n\001\033[38;5;4m\002SAMPLE\001\033[0m\002"
    assert stringc(u"SAMPLE", u"blue", False) == u"\n\033[38;5;4mSAMPLE\033[0m"
    assert stringc(u"SAMPLE\nLINE", u"blue") == u"\n\033[38;5;4mSAMPLE\nLINE\033[0m"
    assert stringc(u"SAMPLE\nLINE", u"rgb001") == u"\n\033[38;5;16mSAMPLE\nLINE\033[0m"

# Generated at 2022-06-21 08:14:15.130128
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('hello', dict(changed=1), True) == '%-37s' % stringc('hello', C.COLOR_CHANGED)
    assert hostcolor('hello', dict(changed=0), True) == '%-37s' % stringc('hello', C.COLOR_OK)
    assert hostcolor('hello', dict(failed=1), True) == '%-37s' % stringc('hello', C.COLOR_ERROR)
    assert hostcolor('hello', dict(failed=0), True) == '%-37s' % stringc('hello', C.COLOR_OK)
    assert hostcolor('hello', dict(unreachable=1), True) == '%-37s' % stringc('hello', C.COLOR_ERROR)
    assert hostcolor('hello', dict(unreachable=0), True) == '%-37s' % string

# Generated at 2022-06-21 08:14:25.645476
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello world", "green"))
    print(stringc("Hello world", "green", True))
    print(stringc("Hello world", "RED", True))
    print(stringc("Hello world", "purple", True))
    print(stringc("Hello world", "blue", True))
    print(stringc("Hello world", "yellow", True))
    print(stringc("Hello world", "cyan", True))
    print(stringc("Hello world", "lightgray", True))
    print(stringc("Hello world", "rgb255255255", True))
    print(stringc("Hello world", "rgb000120", True))
    print(stringc("Hello world", "rgb12", True))
    print(stringc("Hello world", "rgb33003", True))

# Generated at 2022-06-21 08:14:38.570226
# Unit test for function stringc
def test_stringc():
    testColors = (
        u'black',
        u'red',
        u'green',
        u'brown',
        u'blue',
        u'purple',
        u'cyan',
        u'light_gray',
        u'dark_gray',
        u'light_red',
        u'light_green',
        u'yellow',
        u'light_blue',
        u'light_purple',
        u'light_cyan',
        u'white',
    )

# Generated at 2022-06-21 08:14:45.782625
# Unit test for function stringc
def test_stringc():
    # ANSIBLE_COLOR is not defined, the function should always return the text
    text = u'This is a test'
    assert stringc(text, 'blue') == text
    assert stringc(text, 'blue', wrap_nonvisible_chars=True) == text

    # ANSIBLE_COLOR is false, the function should always return the text too
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert stringc(text, 'blue') == text
    assert stringc(text, 'blue', wrap_nonvisible_chars=True) == text
    ANSIBLE_COLOR = True

    # The function colorizes the text
    assert stringc(text, 'blue') == u"\033[34mThis is a test\033[0m"

# Generated at 2022-06-21 08:14:52.032322
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize('ok', '1', 'blue') == u"ok=1  \033[34m\033[0m"
    else:
        assert colorize('ok', '1', 'blue') == u"ok=1  "

ansible_prompt = u"[%s] " + stringc("$ ", C.COLOR_WARN)


# Generated at 2022-06-21 08:14:58.217689
# Unit test for function stringc
def test_stringc():
    import sys
    import doctest
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    suite = doctest.DocTestSuite(__name__)
    unittest.TextTestRunner(verbosity=2).run(suite)

if __name__ == '__main__':
    test_stringc()
# --- end "pretty"

# Generated at 2022-06-21 08:15:19.256456
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "white") == u"\033[37mtest\033[0m"
    assert stringc("test", "black") == u"\033[30mtest\033[0m"
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"

# Generated at 2022-06-21 08:15:22.443979
# Unit test for function stringc
def test_stringc():
    """Basic test of function stringc"""
    assert stringc('hello world', 'CYAN') \
        == "\033[96mhello world\033[0m"



# Generated at 2022-06-21 08:15:34.363221
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "black") == u"\033[30mfoo\033[0m"
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-21 08:15:39.844998
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", "blue") == '\033[34mhello\033[0m'
    assert stringc("hello", "color32") == '\033[38;5;32mhello\033[0m'
    assert stringc("hello", "color125") == '\033[38;5;125mhello\033[0m'
    assert stringc("hello", "rgb555") == '\033[38;5;123mhello\033[0m'
    assert stringc("hello", "gray1") == '\033[38;5;234mhello\033[0m'



# Generated at 2022-06-21 08:15:46.294390
# Unit test for function hostcolor
def test_hostcolor():
    hostname = "myhost"
    stats = {}

    for s in ['changed', 'failures', 'unreachable', 'ok']:
        stats = {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 0}
        stats[s] = 1
        hostcolor(hostname, stats, False)


# --- end of pretty library ---



# Generated at 2022-06-21 08:15:55.795044
# Unit test for function stringc
def test_stringc():
    assert (stringc('hello', 'blue') ==
            '\033[34mhello\033[0m'), "colorizing 'hello' in blue has failed"
    assert (stringc('hello', 'red') ==
            '\033[31mhello\033[0m'), "colorizing 'hello' in red has failed"
    assert (stringc('hello', 'green') ==
            '\033[32mhello\033[0m'), "colorizing 'hello' in green has failed"
    assert (stringc('hello', 'yellow') ==
            '\033[33mhello\033[0m'), "colorizing 'hello' in yellow has failed"
    assert (stringc('hello', 'magenta') ==
            '\033[35mhello\033[0m'), "colorizing 'hello' in magenta has failed"

# Generated at 2022-06-21 08:16:04.790489
# Unit test for function stringc
def test_stringc():
    # Make sure \n is handled properly
    assert(stringc("hello\nworld", 'green')=="\033[32mhello\nworld\033[0m")
    # Make sure invalid color fails
    assert(stringc("hello", 'invalidcolor')=="\033[32mhello\033[0m")

# --- end "pretty"

# This dictionary controls the mapping of unrolled dictionary key/values
# to the short form used on the CLI. These will be updated in the main
# playbook code to reflect the actual data present in a given execution.
# Changing these values here may lead to confusion.


# Generated at 2022-06-21 08:16:16.205481
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo\nbar", "blue") == "\033[34mfoo\nbar\033[0m"
    assert stringc("foo", "none") == "foo"

    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo\nbar", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\nbar\001\033[0m\002"
    assert stringc("foo", "none", wrap_nonvisible_chars=True) == "foo"


# --- end "pretty"

# Generated at 2022-06-21 08:16:26.999932
# Unit test for function parsecolor
def test_parsecolor():
    # 256 color system tests
    if parsecolor('color1') == u'38;5;1':
        pass
    else:
        print(u"Error: parsecolor('color1') != '38;5;1'")

    if parsecolor('rgb255255255') == u'38;5;255':
        pass
    else:
        print(u"Error: parsecolor('rgb255255255') != '38;5;255'")

    if parsecolor('gray23') == u'38;5;249':
        pass
    else:
        print(u"Error: parsecolor('gray23') != '38;5;249'")

    if parsecolor('default') == u'0':
        pass

# Generated at 2022-06-21 08:16:34.734733
# Unit test for function colorize
def test_colorize():
    try:
        print(stringc('hello', 'red'))
        print(stringc('hello', 'blue'))
        print(stringc('hello', 'green'))
        print(stringc('hello', 'yellow'))
        print(stringc('hello', 'pink'))
        print(stringc('hello', 'cyan'))
        print(stringc('hello', 'grey'))
        print(stringc('hello', 'white'))
        print(stringc('hello', 'color3'))
        print(stringc('hello', 'rgb124'))
        print(stringc('hello', 'gray19'))
        print(stringc('hello', 'black'))
    except Exception as e:
        print(e)


if __name__ == "__main__":
    test_colorize()
#

# Generated at 2022-06-21 08:16:53.975209
# Unit test for function stringc
def test_stringc():

    def _test(text, color, expected):
        actual = stringc(text, color)
        if actual != expected:
            print("Expected: %s, actual: %s, for text: %s, color: %s" %
                  (expected, actual, text, color))
        else:
            print("Expected: %s, actual: %s" %
                  (expected, actual))

    # Test bad color
    _test("foo", "bogus", "foo")

    # Test a few simple cases
    _test("foo", "black", "foo")
    _test("foo", "red", "\x1b[38;5;9mfoo\x1b[0m")
    _test("foo", "bold", "\x1b[1mfoo\x1b[0m")

    # Test that color names

# Generated at 2022-06-21 08:17:03.626568
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('aaa') == '', 'no color'
    assert parsecolor('color1') == '38;5;1', 'invalid: color1'
    assert parsecolor('color01') == '38;5;1', 'invalid: color01'
    assert parsecolor('color25') == '38;5;25', 'invalid: color25'
    assert parsecolor('color255') == '38;5;255', 'invalid: color255'
    assert parsecolor('color256') == '', 'invalid: color256'
    assert parsecolor('rgb') == '', 'no rgb'
    assert parsecolor('rgb1') == '38;5;16', 'invalid: rgb1'

# Generated at 2022-06-21 08:17:14.368361
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(
        'testhost',
        {
            'failures': 0,
            'unreachable': 0,
            'changed': 0,
            'ok': 0},
        color=False) == 'testhost               '

    assert hostcolor(
        'testhost',
        {
            'failures': 1,
            'unreachable': 0,
            'changed': 0,
            'ok': 0},
        color=False) == 'testhost               '

    assert hostcolor(
        'testhost',
        {
            'failures': 0,
            'unreachable': 1,
            'changed': 0,
            'ok': 0},
        color=False) == 'testhost               '


# Generated at 2022-06-21 08:17:26.433335
# Unit test for function stringc
def test_stringc():
    assert stringc(u"text", u"blue") == u'\033[0;34mtext\033[0m'
    assert stringc(u"text", u"red") == u'\033[0;31mtext\033[0m'
    assert stringc(u"text", u"green") == u'\033[0;32mtext\033[0m'
    assert stringc(u"text", u"yellow") == u'\033[0;33mtext\033[0m'
    assert stringc(u"text", u"reset") == u'\033[0mtext\033[0m'
    assert stringc(u"text", u"bold") == u'\033[1mtext\033[0m'

# Generated at 2022-06-21 08:17:37.981396
# Unit test for function colorize
def test_colorize():
    """Unit tests for function colorize"""
    assert colorize(u'ok', 0, C.COLOR_OK) == 'ok=0   '
    assert colorize(u'changed', 0, C.COLOR_CHANGED) == 'changed=0   '
    assert colorize(u'unreachable', 0, C.COLOR_UNREACHABLE) == 'unreachable=0   '
    assert colorize(u'failed', 0, C.COLOR_ERROR) == 'failed=0   '

    assert colorize(u'ok', 1, C.COLOR_OK) == 'ok=1   '
    assert colorize(u'changed', 2, C.COLOR_CHANGED) == 'changed=2  '

# Generated at 2022-06-21 08:17:49.631021
# Unit test for function stringc
def test_stringc():

    # This code block is specific to the PyUnit
    # test runner (e.g. `python setup.py test`)
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    class TestPretty(unittest.TestCase):
        def test_stringc(self):
            def cstr(text, color):
                return stringc(text, color)

            # Only test for ANSIBLE_COLOR == True, the
            # other case is unittested in ansible/utils/__init__.py
            if ANSIBLE_COLOR:
                self.assertEquals(cstr('test', 'white'), u'\033[37mtest\033[0m')

# Generated at 2022-06-21 08:18:00.420712
# Unit test for function parsecolor
def test_parsecolor():
    # Test all basic colors
    assert u'38;5;0' == parsecolor('black')
    assert u'38;5;1' == parsecolor('dark_red')
    assert u'38;5;2' == parsecolor('green')
    assert u'38;5;3' == parsecolor('dark_yellow')
    assert u'38;5;4' == parsecolor('blue')
    assert u'38;5;5' == parsecolor('dark_magenta')
    assert u'38;5;6' == parsecolor('dark_cyan')
    assert u'38;5;7' == parsecolor('light_gray')
    assert u'38;5;8' == parsecolor('dark_gray')

# Generated at 2022-06-21 08:18:11.664768
# Unit test for function colorize
def test_colorize():
    """ Unit tests for function colorize """
    tests = (
        (u'ok', 1, C.COLOR_OK, u'ok=1 '),
        (u'changed', 2, C.COLOR_CHANGED, u'changed=2 '),
        (u'unreachable', 0, C.COLOR_UNREACHABLE, u'unreachable=0 '),
        (u'failed', 0, C.COLOR_ERROR, u'failed=0 '),
    )
    for test in tests:
        for color in (True, False):
            ret = colorize(test[0], test[1], test[2])
            assert ret == test[3], test


# --- end

# Generated at 2022-06-21 08:18:17.155857
# Unit test for function stringc
def test_stringc():
    from ansible.compat.tests import unittest
    class TestStringc(unittest.TestCase):
        def test_color(self):
            self.assertTrue(re.match("\033\[1;31m(.+)\033\[0m",
                                     stringc("test", "red", False)))

        def test_rgb(self):
            self.assertTrue(re.match("\033\[1;31m(.+)\033\[0m",
                                     stringc("test", "rgb255", False)))

        def test_nocolor(self):
            if ANSIBLE_COLOR:
                self.assertTrue(re.match("test", stringc("test", "nocolor",
                                         False)))

# Generated at 2022-06-21 08:18:26.865007
# Unit test for function colorize
def test_colorize():
    global ANSIBLE_COLOR
    orig_color = ANSIBLE_COLOR

    ANSIBLE_COLOR = False
    assert 'ok=1  ' == colorize('ok', 1, 'green')
    assert 'changed=1  ' == colorize('changed', 1, 'yellow')
    assert 'failures=1  ' == colorize('failures', 1, 'red')
    assert 'unreachable=1  ' == colorize('unreachable', 1, 'red')

    ANSIBLE_COLOR = True
    assert 'ok=1  ' == colorize('ok', 1, 'green')
    assert u'\033[33mchanged=1  \033[0m' == colorize('changed', 1, 'yellow')

# Generated at 2022-06-21 08:18:52.953788
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    print(colorize(u'ok', 1, u'green'))
    print(colorize(u'changed', 1, u'yellow'))
    print(colorize(u'unreachable', 1, u'red'))
    print(colorize(u'failures', 1, u'magenta'))
    print(colorize(u'ok', 1, None))


# ----------------------------------
# Terminal column printing functions
# ----------------------------------

# Checks if the terminal has a given capability


# Generated at 2022-06-21 08:18:54.002795
# Unit test for function hostcolor
def test_hostcolor():
    # Add tests later.
    pass



# Generated at 2022-06-21 08:19:05.021040
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('gray') == '90'
    assert parsecolor('dark gray') == '90'
    assert parsecolor('bright gray') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('bright red') == '91'
    assert parsecolor('bright green') == '92'
    assert parsecolor('bright yellow') == '93'

# Generated at 2022-06-21 08:19:17.024487
# Unit test for function parsecolor

# Generated at 2022-06-21 08:19:27.008780
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('black') == u'30'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('bold') == u'1'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('unknown') == u'37'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('rgb123') == u'38;5;300'
    assert parsecolor('rgb321') == u'38;5;130'
    assert parsecolor('rgb213') == u'38;5;60'
    assert parsecolor('rgb111') == u'38;5;232'


# Generated at 2022-06-21 08:19:39.192574
# Unit test for function stringc
def test_stringc():
    print(stringc('this is 1', 'red'))
    print(stringc('this is 1', 'rgb255'))
    print(stringc('this is 1', 'rgb330'))
    print(stringc('this is 1', 'color1'))
    print(stringc('this is 1', 'color0'))
    print(stringc('this is 1', 'rgb255rgb255rgb255'))
    print(stringc('this is 1', 'rgb255rgb255rgb25'))
    print(stringc('this is 1', 'rgb255rgb255rgb25z'))
    print(stringc('this is 1', 'rgb255rgb255rgb25z') + stringc('this is 2', 'color256'))

# Generated at 2022-06-21 08:19:50.528550
# Unit test for function colorize
def test_colorize():
    # pylint: disable=too-many-function-args
    assert colorize(u"foo", 0, None) == u'foo=0   '
    assert colorize(u"foo", 1, None) == u'foo=1   '
    assert colorize(u"foo", 12, None) == u'foo=12  '
    assert colorize(u"foo", 123, None) == u'foo=123 '
    assert colorize(u"foo", 1234, None) == u'foo=1234'
    assert colorize(u"foo", 0, u"red") == u'foo=0   '
    assert colorize(u"foo", 1, u"red") != u'foo=1   '
    assert colorize(u"foo", 12, u"red") != u'foo=12  '
   

# Generated at 2022-06-21 08:20:02.811881
# Unit test for function colorize
def test_colorize():
    print(u"     failures=1 changed=1 unreachable=1")
    print(u"      %s %s %s" % (colorize(u"failures", 1, C.COLOR_ERROR),
                              colorize(u"changed", 1, C.COLOR_CHANGED),
                              colorize(u"unreachable", 1, C.COLOR_UNREACHABLE)))
    print(u"")
    print(u"     failures=0 changed=1 unreachable=0")
    print(u"      %s %s %s" % (colorize(u"failures", 0, C.COLOR_ERROR),
                              colorize(u"changed", 1, C.COLOR_CHANGED),
                              colorize(u"unreachable", 0, C.COLOR_UNREACHABLE)))



# Generated at 2022-06-21 08:20:15.149313
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "green") == u'\033[32mtest\033[0m'
    assert stringc("test", "color1") == u'\033[38;5;1mtest\033[0m'
    assert stringc("test", "rgb255") == u'\033[38;5;231mtest\033[0m'
    assert stringc("test", "rgb21") == u'\033[38;5;33mtest\033[0m'
    assert stringc("test", "rgb333") == u'\033[38;5;233mtest\033[0m'
    assert stringc("test", "gray0") == u'\033[38;5;232mtest\033[0m'

# Generated at 2022-06-21 08:20:19.956741
# Unit test for function hostcolor
def test_hostcolor():
    expected_result = u'%s=%-4s' % (u"dark_gray", str(0))
    assert expected_result == hostcolor(u"dark_gray", {'dark_gray': 0}, True)
    expected_result = u'%s=%-4s' % (u"red", str(1))
    assert expected_result == hostcolor(u"red", {'red': 1}, True)
    assert u"dark_gray=0    " == hostcolor(u"dark_gray", {'dark_gray': 0}, False)



# Generated at 2022-06-21 08:20:45.885179
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, u'blue') == u"foo=0   "
    assert colorize(u"foo", 1, u'blue') == stringc(u"foo=1   ", u'blue')
    assert colorize(u"foo", 0, None) == u"foo=0   "
    assert colorize(u"foo", 1, None) == u"foo=1   "
    assert colorize(u"foo", -17, u'blue') == stringc(u"foo=-17 ", u'blue')
    assert colorize(u"foo", None, u'blue') == u"foo=None "
    assert colorize(u"foo", u'', u'blue') == u"foo=     "

# Generated at 2022-06-21 08:20:58.206007
# Unit test for function stringc
def test_stringc():
    """Pretty: Unit test for function stringc"""
    print("Testing function stringc")
    # Standard color should work
    assert stringc("test", "black") == u"\033[30mtest\033[0m"
    # Check that bad color name is rejected
    try:
        stringc("test", "badcolor")
        assert False, "Should not be able to get here"
    except KeyError:
        pass
    # Check that optional parameters work
    assert stringc("test", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002test\001\033[0m\002"
    # Subclassing StringIO to show differences in color
    class StringIO(StringIO.StringIO):
        def getvalue(self):
            return self.buf
    # Testing with the String

# Generated at 2022-06-21 08:21:03.238198
# Unit test for function parsecolor
def test_parsecolor():
    """Test function parsecolor"""
    assert parsecolor('green') == u'32'
    assert parsecolor('color33') == u'38;5;33'
    assert parsecolor('rgb222') == u'38;5;18'
    assert parsecolor('gray1') == u'38;5;234'



# Generated at 2022-06-21 08:21:11.306426
# Unit test for function stringc
def test_stringc():
    assert stringc('Red text', 'red') == u'\033[31mRed text\033[0m'
    assert stringc('a\nb', 'blue') == u'\033[34ma\n\033[0mb\033[0m'
    assert stringc('a\nb', 'blue', wrap_nonvisible_chars=True) == u'\001\033[34m\002a\n\001\033[0m\002b\033[0m'
    assert stringc('No color', None) == u'No color'
    assert stringc('Green text', 'green') == u'\033[32mGreen text\033[0m'
# --- end "pretty"

# Generated at 2022-06-21 08:21:20.045336
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    for color in C.COLOR_OK, C.COLOR_CHANGED, C.COLOR_ERROR:
        yield check_hostcolor, color, stats, True
        stats['changed'] = 1
        yield check_hostcolor, color, stats, True
        stats['changed'] = 0
        stats['unreachable'] = 1
        yield check_hostcolor, color, stats, True
        stats['unreachable'] = 0
        stats['failures'] = 1
        yield check_hostcolor, color, stats, True
        stats['failures'] = 0



# Generated at 2022-06-21 08:21:25.501212
# Unit test for function colorize
def test_colorize():
    # Simple test that just calls the function.
    colorize(1, 0, None)
    # Test keyword arguments.
    colorize(lead=1, num=0, color=None)
    # Test with list arguments
    colorize(*[1, 0, None])
    # Test with dictionary arguments.
    colorize(**dict(lead=1, num=0, color=None))

# --- end "pretty"

# Generated at 2022-06-21 08:21:34.407623
# Unit test for function colorize
def test_colorize():
    from ansible.compat.tests import unittest
    from ansible.utils.color import colorize, parsecolor, ANSIBLE_COLOR

    class TestColorize(unittest.TestCase):
        original_color = ANSIBLE_COLOR
        def setUp(self):
            ANSIBLE_COLOR = True

        def tearDown(self):
            ANSIBLE_COLOR = self.original_color

        def test_colorize(self):
            self.assertEqual(colorize('', 1, None), u'=1   ')
            self.assertEqual(colorize('', 1, 'black'), u'=1   ')
            self.assertEqual(colorize('', 1, 'blue'), u'\033[94m=1   \033[0m')


# Generated at 2022-06-21 08:21:45.563586
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'red') == '\x1b[31mtest\x1b[0m'
    assert stringc('test', 'color1') == '\x1b[38;5;1mtest\x1b[0m'
    assert stringc('test', 'color9') == '\x1b[38;5;9mtest\x1b[0m'
    assert stringc('test', 'color10') == '\x1b[38;5;10mtest\x1b[0m'
    assert stringc('test', 'color11') == '\x1b[38;5;11mtest\x1b[0m'
    assert stringc('test', 'color19') == '\x1b[38;5;19mtest\x1b[0m'
