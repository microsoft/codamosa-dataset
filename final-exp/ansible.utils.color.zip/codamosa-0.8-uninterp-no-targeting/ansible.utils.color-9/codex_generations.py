

# Generated at 2022-06-21 08:11:58.953290
# Unit test for function stringc
def test_stringc():
    codes = {'blue': u'1;94', 'red': u'0;91', 'green': u'0;92', 'yellow': u'0;93', 'default': u'0'}

    assert stringc(u"test", u"default") == u"\x1b[%smtest\x1b[0m" % codes['default']
    assert stringc(u"test", u"blue") == u"\x1b[%smtest\x1b[0m" % codes['blue']
    assert stringc(u"test", u"red") == u"\x1b[%smtest\x1b[0m" % codes['red']

# Generated at 2022-06-21 08:12:10.995882
# Unit test for function stringc

# Generated at 2022-06-21 08:12:19.659052
# Unit test for function hostcolor
def test_hostcolor():
    stats = {
        'failures': 0,
        'unreachable': 0,
        'changed': 0
    }
    assert hostcolor('ok', stats, color=True) == u'\x1b[0;32m%-37s\x1b[0m' % 'ok'
    stats = {
        'failures': 1,
        'unreachable': 0,
        'changed': 0
    }
    assert hostcolor('fail1', stats, color=True) == u'\x1b[0;31m%-37s\x1b[0m' % 'fail1'
    stats = {
        'failures': 0,
        'unreachable': 1,
        'changed': 0
    }

# Generated at 2022-06-21 08:12:30.555097
# Unit test for function colorize

# Generated at 2022-06-21 08:12:39.883234
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(color='black') == u'38;5;0'
    assert parsecolor(color='white') == u'38;5;15'
    assert parsecolor(color='red') == u'38;5;9'
    assert parsecolor(color='rgb012') == u'38;5;6'
    assert parsecolor(color='rgb503') == u'38;5;34'
    assert parsecolor(color='rgb223') == u'38;5;118'
    assert parsecolor(color='gray0') == u'38;5;232'
    assert parsecolor(color='gray7') == u'38;5;245'
    assert parsecolor(color='gray8') == u'38;5;246'

# Generated at 2022-06-21 08:12:49.023061
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u'%-37s' % 'foo'
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('foo', C.COLOR_CHANGED)



# Generated at 2022-06-21 08:12:53.184415
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, C.COLOR_ERROR) == u"foo=0   "
    assert colorize(u"foo", 1, C.COLOR_ERROR) == u"foo=1   "
    assert colorize(u"foo", 0, None) == u"foo=0   "
    assert colorize(u"foo", 1, None) == u"foo=1   "



# Generated at 2022-06-21 08:13:05.892030
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('white') == u'38;5;15'
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('red') == u'38;5;124'
    assert parsecolor('green') == u'38;5;46'
    assert parsecolor('yellow') == u'38;5;136'
    assert parsecolor('blue') == u'38;5;21'
    assert parsecolor('magenta') == u'38;5;129'
    assert parsecolor('cyan') == u'38;5;51'
    assert parsecolor('lightgray') == u'38;5;250'
    assert parsecolor('darkgray') == u'38;5;59'

# Generated at 2022-06-21 08:13:11.723472
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"blue") == u"34"
    assert parsecolor(u"color1") == u"38;5;1"
    assert parsecolor(u"rgb100") == u"38;5;34"
    assert parsecolor(u"gray1") == u"38;5;234"


# Generated at 2022-06-21 08:13:21.683991
# Unit test for function colorize
def test_colorize():

    # ANSIBLE_COLOR=False, no color
    assert colorize('a', 3, 'blue') == 'a=3   '
    assert colorize('b', 0, 'blue') == 'b=0   '

    # ANSIBLE_COLOR=False, with color
    C.ANSIBLE_FORCE_COLOR = True
    assert colorize('a', 3, 'blue') == 'a=3   '
    assert colorize('b', 0, 'blue') == 'b=0   '
    C.ANSIBLE_FORCE_COLOR = False

    # ANSIBLE_COLOR=True, with color
    assert colorize('c', 1, 'blue') == 'c=1   '
    assert colorize('d', 0, 'blue') == 'd=0   '



# Generated at 2022-06-21 08:13:38.745207
# Unit test for function stringc
def test_stringc():
    print("Test stringc")
    print(stringc("Test red", "RED"), end='')
    print(stringc("Test blue", "BLUE"), end='')
    print(stringc("Test default", "DEFAULT"), end='')
    # Test the 16 defined ANSI colors
    colors = ["black", "blue", "green", "cyan", "red", "magenta", "yellow", "white",
              "BLACK", "BLUE", "GREEN", "CYAN", "RED", "MAGENTA", "YELLOW", "WHITE"]
    for color in colors:
        print(stringc("Test %s" % color, color), end='')
    # Test the 256 colors
    colors = ["color%d" % n for n in range(256)]

# Generated at 2022-06-21 08:13:47.871480
# Unit test for function parsecolor
def test_parsecolor():
    # test color names
    assert parsecolor("red") == u"31"
    assert parsecolor("black") == u"30"

    # test raw 8-bit color codes
    assert parsecolor("color2") == u"38;5;2"
    assert parsecolor("color15") == u"38;5;15"
    assert parsecolor("color230") == u"38;5;230"
    assert parsecolor("color243") == u"38;5;243"

    # test rgb color codes
    assert parsecolor("rgb000") == u"38;5;232"
    assert parsecolor("rgb300") == u"38;5;235"
    assert parsecolor("rgb333") == u"38;5;236"
    assert parsecolor("rgb555") == u

# Generated at 2022-06-21 08:14:00.596100
# Unit test for function colorize
def test_colorize():
    print(u"\nTESTING COLORS\n")

    print(u"Testing colorize()")
    print(colorize(u"good:", 0, u"green"))
    print(colorize(u"bad:", 1, u"red"))
    print(colorize(u"neutral:", 0, None))

    print(u"Testing stringc()")
    print(stringc(u"good", u"green"))
    print(stringc(u"bad", u"red"))
    print(stringc(u"normal", None))

    print(u"Testing hostcolor()")
    print(hostcolor(u"foo", dict(failures=0, unreachable=0, changed=0)))
    print(hostcolor(u"foo", dict(failures=1, unreachable=0, changed=0)))
   

# Generated at 2022-06-21 08:14:03.572529
# Unit test for function colorize
def test_colorize():
    #print colorize("test", 1, "blue")
    #print colorize("test", 0, "blue")
    #print colorize("test", 1, None)
    pass



# Generated at 2022-06-21 08:14:12.810481
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"green") == u"\n".join([
        u"\033[38;5;10mfoo\033[0m"])
    assert stringc(u"foo", u"color11") == u"\n".join([
        u"\033[38;5;11mfoo\033[0m"])
    assert stringc(u"foo", u"rgb125") == u"\n".join([
        u"\033[38;5;54mfoo\033[0m"])
    assert stringc(u"foo", u"gray1") == u"\n".join([
        u"\033[38;5;233mfoo\033[0m"])



# Generated at 2022-06-21 08:14:22.089511
# Unit test for function hostcolor
def test_hostcolor():
    """Testing of hostcolor function"""
    hc = hostcolor
    assert hc("test_host", dict(changed=1, failures=0, unreachable=0)) == u"test_host                  "
    assert hc("test_host", dict(changed=0, failures=1, unreachable=0)) == u"test_host                  "
    assert hc("test_host", dict(changed=0, failures=0, unreachable=1)) == u"test_host                  "
    assert hc("test_host", dict(changed=0, failures=0, unreachable=0)) == u"test_host                  "

# --- end of "pretty" ---

# --- begin "blather"

# Generated at 2022-06-21 08:14:25.349693
# Unit test for function colorize
def test_colorize():
    for c in ['red', 'green', 'blue', '0', 'rgb255255255', 'rgb000255255']:
        teststr = lead + '=' + num
        assert stringc(teststr, c)



# Generated at 2022-06-21 08:14:37.946645
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor, ANSIBLE_COLOR
    from ansible.constants import C
    ANSIBLE_COLOR = True
    # check host string
    assert hostcolor(u"localhost", {}) == u"%-37s" % stringc(u"localhost", C.COLOR_OK)
    # check stats
    stats = {"failures" : 1}
    assert hostcolor(u"localhost", stats) == u"%-37s" % stringc(u"localhost", C.COLOR_ERROR)
    stats = {"changed" : 1}
    assert hostcolor(u"localhost", stats) == u"%-37s" % stringc(u"localhost", C.COLOR_CHANGED)
    # check color
    ANSIBLE_COLOR = False
    assert hostcolor(u"localhost", {}, color=False)

# Generated at 2022-06-21 08:14:45.467318
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor("localhost", dict(failures=0, unreachable=0, changed=0))
           == u"%-37s" % stringc("localhost", C.COLOR_OK))
    assert(hostcolor("localhost", dict(failures=1, unreachable=0, changed=0))
           == u"%-37s" % stringc("localhost", C.COLOR_ERROR))
    assert(hostcolor("localhost", dict(failures=0, unreachable=0, changed=1))
           == u"%-37s" % stringc("localhost", C.COLOR_CHANGED))
    # in case of all zeros, the color should be OK

# Generated at 2022-06-21 08:14:57.245686
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), True) == stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), True) == stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), True) == stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), True) == stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), False) == u"localhost                "

# Generated at 2022-06-21 08:15:09.520689
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo\nbar", "blue") == u"\033[34mfoo\033[0m\n\033[34mbar\033[0m"
    assert stringc("foo", "color256") == u"\033[38;5;256mfoo\033[0m"
    assert stringc("foo", "rgb123") == u"\033[38;5;151mfoo\033[0m"
    assert stringc("foo", "gray7") == u"\033[38;5;239mfoo\033[0m"
    assert stringc("foo", "normal") == u"\033[0mfoo\033[0m"

# Generated at 2022-06-21 08:15:15.792983
# Unit test for function colorize
def test_colorize():
    print(colorize('ok', 0, 'green'))
    print(colorize('changed', 0, 'yellow'))
    print(colorize('unreachable', 0, 'red'))
    print(colorize('ok', 1, 'green'))
    print(colorize('changed', 2, 'yellow'))
    print(colorize('unreachable', 3, 'red'))


# Generated at 2022-06-21 08:15:26.289632
# Unit test for function colorize
def test_colorize():
    c = colorize('foo', 0, 'blue')
    assert c == u'foo=0   ', "colorize returned bad output: %s" % c
    c = colorize('foo', 1, 'blue')
    assert c == u'foo=1   ', "colorize returned bad output: %s" % c
    c = colorize('foo', 12, 'blue')
    assert c == u'foo=12  ', "colorize returned bad output: %s" % c
    c = colorize('foo', 123, 'blue')
    assert c == u'foo=123 ', "colorize returned bad output: %s" % c
    c = colorize('foo', 1234, 'blue')
    assert c == u'foo=1234', "colorize returned bad output: %s" % c


# --- end "pretty"



# Generated at 2022-06-21 08:15:37.054773
# Unit test for function parsecolor
def test_parsecolor():

    text = u"\033[%sm%s\033[0m" % (parsecolor("green"), u"This is green.")
    print(u"%-17s %s" % (u"text:", text))

    text = u"\033[%sm%s\033[0m" % (parsecolor("blue"), u"This is blue.")
    print(u"%-17s %s" % (u"text:", text))

    text = u"\033[%sm%s\033[0m" % (parsecolor("white"), u"This is white.")
    print(u"%-17s %s" % (u"text:", text))

    text = u"\033[%sm%s\033[0m" % (parsecolor("red"), u"This is red.")

# Generated at 2022-06-21 08:15:49.854554
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {"failures": 0, "unreachable": 0, "changed": 0}
    hc = hostcolor(host, stats)
    assert(hc == u"%-26s")
    stats = {"failures": 0, "unreachable": 0, "changed": 1}
    hc = hostcolor(host, stats)
    assert(hc == u"%-37s")
    stats = {"failures": 0, "unreachable": 1, "changed": 0}
    hc = hostcolor(host, stats)
    assert(hc == u"%-37s")
    stats = {"failures": 1, "unreachable": 0, "changed": 0}
    hc = hostcolor(host, stats)
    assert(hc == u"%-37s")

test_host

# Generated at 2022-06-21 08:16:00.136474
# Unit test for function stringc
def test_stringc():
    print(stringc("hello", "blue"))
    print(stringc("hello", "red"))
    print(stringc("hello", "green"))
    print(stringc("hello", "blue", wrap_nonvisible_chars=True))
    print(stringc("hello", "red", wrap_nonvisible_chars=True))
    print(stringc("hello", "green", wrap_nonvisible_chars=True))
    print(stringc("hello", "color123"))
    print(stringc("hello", "rgb123"))
    print(stringc("hello", "gray123"))
    print(stringc("hello", "color123", wrap_nonvisible_chars=True))
    print(stringc("hello", "rgb123", wrap_nonvisible_chars=True))

# Generated at 2022-06-21 08:16:13.206123
# Unit test for function colorize
def test_colorize():
    import sys
    if sys.stdout.isatty():
        # We are in a terminal, let's try
        print(colorize(u"Test", 1234, u"blue"))
        print(colorize(u"Test", 1234, u"green"))
        print(colorize(u"Test", 1234, u"red"))
        print(colorize(u"Test", 0, u"red"))
        print(colorize(u"Test", 0, None))
    else:
        # We are not in a terminal, no colors
        print(colorize(u"Test", 1234, u"blue"))
        print(colorize(u"Test", 1234, u"green"))
        print(colorize(u"Test", 1234, u"red"))

# Generated at 2022-06-21 08:16:21.425735
# Unit test for function stringc
def test_stringc():
    """invoke function stringc()"""

# Generated at 2022-06-21 08:16:31.193345
# Unit test for function parsecolor
def test_parsecolor():
    # Test xterm color rules
    assert parsecolor('black') == '30'
    assert parsecolor('brightgrey') == '37'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('rgb255255255') == '38;5;15'
    assert parsecolor('rgb000255000') == '38;5;2'
    assert parsecolor('rgb255255000') == '38;5;3'
    assert parsecolor('rgb255000255') == '38;5;5'
    assert parsecolor('rgb255000000') == '38;5;9'
    assert parsecolor('rgb255000000') == '38;5;9'
    assert parsecolor('rgb000000255') == '38;5;13'
   

# Generated at 2022-06-21 08:16:36.372246
# Unit test for function colorize
def test_colorize():
    from . import get_examples

    for line in get_examples('colorize_output.txt'):
        line = line.strip()
        if not line.startswith("#"):
            assert get_examples('colorize_output.txt').pop(0).strip() == line


if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-21 08:16:51.977129
# Unit test for function parsecolor
def test_parsecolor():
    '''
    Return the SGR parameter for the specified color name
    '''
    if not ANSIBLE_COLOR:
        return [u"Console is not a terminal",
                u"No ANSI color support"]

    if not hasattr(sys.stdout, 'isatty') or not sys.stdout.isatty():
        return [u"Console is not a terminal",
                u"No ANSI color support"]

    try:
        import curses
        curses.setupterm()
        if curses.tigetnum('colors') < 0:
            return [u"Console is not a terminal",
                    u"No ANSI color support"]
    except ImportError:
        # curses library was not found
        return [u"Console is not a terminal",
                u"No ANSI color support"]

# Generated at 2022-06-21 08:16:59.275849
# Unit test for function colorize
def test_colorize():
    """returned string should contain ANSI escape code if and only if
    specified color is not None and ANSIBLE_COLOR is True.
    """
    ANSIBLE_COLOR_SAVE = ANSIBLE_COLOR

# Generated at 2022-06-21 08:17:09.613392
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('foo.example.com', dict(changed=0, failures=0, unreachable=0), color=True))
    print(hostcolor('foo.example.com', dict(changed=1, failures=0, unreachable=0), color=True))
    print(hostcolor('foo.example.com', dict(changed=0, failures=1, unreachable=0), color=True))
    print(hostcolor('foo.example.com', dict(changed=0, failures=0, unreachable=1), color=True))
    print(hostcolor('foo.example.com', dict(changed=10, failures=3, unreachable=1), color=True))

# --- end "pretty"

# Generated at 2022-06-21 08:17:22.202192
# Unit test for function hostcolor
def test_hostcolor():
    print('Testing hostcolor:', end='')
    stats = {}
    stats['failures'] = 0
    stats['changed'] = 0
    stats['unreachable'] = 0
    if '\033[31m' not in hostcolor('foohost', stats):
        print("\nERROR: hostcolor does not return color when failures == 0 and unreachable == 0")
        return
    stats['failures'] = 5
    if '\033[31m' not in hostcolor('foohost', stats):
        print("\nERROR: hostcolor does not return color when unreachable == 0")
        return
    stats['failures'] = 0
    stats['unreachable'] = 5

# Generated at 2022-06-21 08:17:33.403595
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u"%-26s" % 'foo'
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0), color=False) == u"%-26s" % 'foo'
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc('foo', C.COLOR_ERROR)

# Generated at 2022-06-21 08:17:42.401865
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        assert colorize('x', 1, 'blue') == "x=1   "
        assert colorize('x', 1, None) == "x=1   "
    else:
        # ANSIBLE_COLOR was True, so the terminal supports
        # color codes
        assert colorize('x', 1, 'blue') == "\x1b[0;34mx=1   \x1b[0m"
        assert colorize('x', 1, None) == "x=1   "

    # If the terminal doesn't support color codes, then the
    # colorize function should behave as above (no color)
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('x', 1, 'blue') == "x=1   "

# Generated at 2022-06-21 08:17:47.720161
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize("foo", -2, "red")
    'foo=-2  '
    >>> colorize("foo", 2, "green")
    'foo=2   '
    >>> colorize("foo", 0, "blue")
    'foo=0   '
    """


# Generated at 2022-06-21 08:17:59.376670
# Unit test for function parsecolor
def test_parsecolor():
    def tcolor(color, expect):
        actual = parsecolor(color)
        if actual != expect:
            print("Expected %s but got %s" % (expect, actual))

    tcolor("black", '30')
    tcolor("red", '31')
    tcolor("green", '32')
    tcolor("yellow", '33')
    tcolor("blue", '34')
    tcolor("magenta", '35')
    tcolor("cyan", '36')
    tcolor("white", '37')
    tcolor("color0", '38;5;0')
    tcolor("color1", '38;5;1')
    tcolor("color2", '38;5;2')
    tcolor("color3", '38;5;3')

# Generated at 2022-06-21 08:18:03.177666
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {'failures': 0, 'unreachable': 0, 'changed': 0}, color=True) == u"%-26s" % stringc("localhost", C.COLOR_OK)



# Generated at 2022-06-21 08:18:15.647140
# Unit test for function stringc
def test_stringc():
    print(u"-" * 78)
    for color in C.COLOR_CODES:
        sys.stdout.write(color + u":\t")
        sys.stdout.write(stringc(u"XYZ", color) + u"\t")
        sys.stdout.write(stringc(u"foo", color) + u"\t")
        sys.stdout.write(stringc(u"bar", color) + u"\t")
        sys.stdout.write(stringc(u"This is a fairly long string of text", color) + u"\n")
        sys.stdout.flush()
    print(u"-" * 78)
    # Test out the keyword parameters

# Generated at 2022-06-21 08:18:25.306509
# Unit test for function colorize
def test_colorize():
    ok_ = colorize('ok', 33, 'green')
    changed_ = colorize('changed', 44, 'yellow')
    unreachable_ = colorize('unreachable', 5, 'red')
    failed_ = colorize('failed', 0, 'red')
    print("Colorize: %s %s %s %s" % (ok_, changed_, unreachable_, failed_))


# Generated at 2022-06-21 08:18:28.179528
# Unit test for function stringc
def test_stringc():
    assert stringc(u"text", u"red") == u"\033[31mtext\033[0m"
    assert stringc(u"text", u"black") == u"\033[30mtext\033[0m"



# Generated at 2022-06-21 08:18:36.151070
# Unit test for function stringc
def test_stringc():
    test_vec = (
        (u'foo', u'blue', u'\033[34mfoo\033[0m'),
        (u'foo', u'1', u'\033[38;5;1mfoo\033[0m'),
        (u'foo', u'rgb123', u'\033[38;5;33mfoo\033[0m'),
        (u'foo', u'gray7', u'\033[38;5;239mfoo\033[0m'),
        (u'foo\nbar', u'blue', u'\033[34mfoo\033[0m\n\033[34mbar\033[0m'),
        (u'foo', None, u'foo'),
        (u'foo', u'bar', u'foo'),
    )

# Generated at 2022-06-21 08:18:48.233225
# Unit test for function hostcolor
def test_hostcolor():
    host = "default"
    stats = {
        "changed": 0,
        "failures": 1,
        "ok": 2,
        "skipped": 0,
        "unreachable": 1,
    }
    correct_output = u"%-37s" % stringc(host, C.COLOR_ERROR)
    assert hostcolor(host, stats, True) == correct_output

    stats = {
        "changed": 1,
        "failures": 0,
        "ok": 2,
        "skipped": 0,
        "unreachable": 0,
    }
    correct_output = u"%-37s" % stringc(host, C.COLOR_CHANGED)
    assert hostcolor(host, stats, True) == correct_output
