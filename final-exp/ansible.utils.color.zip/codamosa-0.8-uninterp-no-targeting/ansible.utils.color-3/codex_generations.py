

# Generated at 2022-06-21 08:11:57.614879
# Unit test for function parsecolor
def test_parsecolor():
    assert '38;5;0' == parsecolor('black')
    assert '38;5;1' == parsecolor('red')
    assert '38;5;2' == parsecolor('green')
    assert '38;5;3' == parsecolor('yellow')
    assert '38;5;4' == parsecolor('blue')
    assert '38;5;5' == parsecolor('magenta')
    assert '38;5;6' == parsecolor('cyan')
    assert '38;5;7' == parsecolor('white')
    assert '38;5;8' == parsecolor('color8')
    assert '38;5;15' == parsecolor('color15')
    assert '38;5;16' == parsecolor('color16')

# Generated at 2022-06-21 08:12:04.421096
# Unit test for function colorize
def test_colorize():
    print(u"colorize()")
    assert u'changed=1   ' == colorize(u"changed", 1, C.COLOR_CHANGED)
    assert u"failed=1    " == colorize(u"failed", 1, C.COLOR_ERROR)
    assert u"ok=1        " == colorize(u"ok", 1, C.COLOR_OK)
    print(u"colorize() ok")


if __name__ == u'__main__':
    test_colorize()

# --- end "pretty"

# Generated at 2022-06-21 08:12:12.520839
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 12, 'blue') == 'foo=12  '
    assert colorize('foo', 123, 'blue') == 'foo=123 '
    assert colorize('foo', 1234, 'blue') == 'foo=1234'
    assert colorize('foo', 12345, 'blue') == 'foo=12345'


# --- end of pretty



# Generated at 2022-06-21 08:12:20.518874
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;196' == parsecolor('red')
    assert u'38;5;219' == parsecolor('yellow')
    assert u'38;5;48' == parsecolor('green')
    assert u'38;5;250' == parsecolor('blue')
    assert u'38;5;166' == parsecolor('magenta')
    assert u'38;5;50' == parsecolor('cyan')
    assert u'38;5;230' == parsecolor('darkgray')
    assert u'38;5;144' == parsecolor('darkred')
    assert u'38;5;184' == parsecolor('darkyellow')
    assert u'38;5;64' == parsecolor('darkgreen')
    assert u'38;5;24' == parsec

# Generated at 2022-06-21 08:12:31.569825
# Unit test for function parsecolor

# Generated at 2022-06-21 08:12:40.412543
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.unicode import to_unicode
    assert u"%-26s" % to_unicode('foohost') == hostcolor('foohost', dict(ok=1))
    assert u"%-26s" % to_unicode(u'≥ foohost') == hostcolor('≥ foohost', dict(ok=1))
    assert u"%-26s" % to_unicode(u'≥ foohost') == hostcolor(u'≥ foohost', dict(ok=1))
    assert u"%-26s" % to_unicode('foohost') == hostcolor(u'foohost', dict(ok=1))

# Generated at 2022-06-21 08:12:50.479874
# Unit test for function hostcolor
def test_hostcolor():
    """ ansible.module_utils.color.test_hostcolor """

    # Load in the color CLI arguments
    args = dict()
    args['color'] = True
    args['force_color'] = False

    # Create empty host stats
    stats = dict()
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0

    # Name of the host
    name = 'host1'

    # If color is forced, check that the host is colored
    args['force_color'] = True
    assert hostcolor(name, stats, args['force_color']) == u"%-37s" % u'\x1b[0mhost1\x1b[0m'

    # If color is not forced, check that the host is not colored
    args['force_color'] = False


# Generated at 2022-06-21 08:13:02.709064
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('blue') == '34'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('dark gray') == '90'
    assert parsecolor('light red') == '91'
    assert parsecolor('light green') == '92'
    assert parsecolor('light yellow') == '93'
    assert parsecolor('light blue') == '94'
    assert parsecolor('light magenta') == '95'
    assert parsecolor('light cyan') == '96'
    assert parsecolor('white') == '97'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color0') == '38;5;0'

# Generated at 2022-06-21 08:13:14.329340
# Unit test for function hostcolor
def test_hostcolor():
    """ hostcolor(host, stats, color=True) """

    assert hostcolor(u'foo', dict(
        ok=0, changed=0, unreachable=0, failures=0), True) == u'%-37s' % u'foo'
    assert hostcolor(u'foo', dict(
        ok=0, changed=0, unreachable=0, failures=0), False) == u'%-26s' % u'foo'

    try:
        stringc(hostcolor(u'foo', dict(
            ok=0, changed=0, unreachable=0, failures=1), True), 'error')
    except SystemExit:
        pass
    except Exception:
        # A non-zero exit code signals the unit test has failed.
        sys.exit(-1)


# Generated at 2022-06-21 08:13:23.732377
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('darkgray') == u'1;30'
    assert parsecolor('red') == u'31'
    assert parsecolor('brightred') == u'1;31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('default') == u'39'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'

# Generated at 2022-06-21 08:13:38.514188
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'darkred.example.com', dict(failures=1, unreachable=0, changed=0, ok=8)) == \
        u"darkred.example.com            "
    assert hostcolor(u'lightgreen.example.com', dict(failures=0, unreachable=0, changed=1, ok=8)) == \
        u"lightgreen.example.com         "
    assert hostcolor(u'yellow.example.com', dict(failures=0, unreachable=0, changed=0, ok=8)) == \
        u"yellow.example.com             "


# Generated at 2022-06-21 08:13:48.228946
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('default') == u'39'
    assert parsecolor('black') == u'30'
    assert parsecolor('blue') == u'34'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('green') == u'32'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('red') == u'31'
    assert parsecolor('white') == u'37'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('color16') == u'38;5;16'
    assert parsecolor('color232') == u'38;5;232'

# Generated at 2022-06-21 08:14:00.889871
# Unit test for function colorize
def test_colorize():
    def test_term(term_name, expected_result):
        """
        Helper function to test colorize output for a given term.
        """
        result = colorize("", 0, term_name)
        assert result == expected_result, \
            u"colorize returned '%s', expected '%s' for term %s" % \
            (result, expected_result, term_name)

    test_term("white", "=0   ")
    test_term("grey", "=0   ")
    test_term("black", "=0   ")
    test_term("red", "=0   ")
    test_term("green", "=0   ")
    test_term("yellow", "=0   ")
    test_term("blue", "=0   ")

# Generated at 2022-06-21 08:14:11.559935
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'34'
    assert parsecolor('bright purple') == u'35'
    assert parsecolor('white') == u'37'
    assert parsecolor('red') == u'1;31'
    assert parsecolor('on_red') == u'41'
    assert parsecolor('on_bright_yellow') == u'1;103'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('color5') == u'38;5;5'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('black') == u'30'
    assert parsecolor('on_black') == u'40'

# Generated at 2022-06-21 08:14:23.709006
# Unit test for function colorize
def test_colorize():
    C.ANSIBLE_NOCOLORS = False
    assert colorize("foo", 0, 'blue') == "\033[34mfoo=0   \033[0m"
    assert colorize("bar", 1, 'blue') == "\033[34mbar=1   \033[0m"
    assert colorize("baz", 2, 'blue') == "\033[34mbaz=2   \033[0m"
    assert colorize("qux", 10, 'blue') == "\033[34mqux=10  \033[0m"
    assert colorize("quux", 100, 'blue') == "\033[34mquux=100\033[0m"
    assert colorize("corge", 1000, 'blue') == "\033[34mcorge=1000\033[0m"

# Generated at 2022-06-21 08:14:30.610637
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'changed': 2, 'failures': 0, 'ok': 4, 'skipped': 0, 'unreachable': 0}
    host = u"This is a test"
    result = u"This is a test"
    assert hostcolor(host, stats, False) == u"%-26s" % result


# --- end of "pretty" ---



# Generated at 2022-06-21 08:14:40.997936
# Unit test for function colorize
def test_colorize():
    """Basic tests for colorize()."""
    assert colorize("foo", 0, None) == u"foo=0   "
    assert colorize("foo", 100, None) == u"foo=100 "
    assert colorize("foo", 1000, None) == u"foo=1000"

    assert colorize("foo", 0, 'blue') == u"foo=0   "
    assert colorize("foo", 100, 'blue') == u"foo=100 "
    assert colorize("foo", 1000, 'blue') == u"foo=1000"

    if ANSIBLE_COLOR:
        # Cannot test for exact strings, as the ANSI sequences depend on
        # the value of parsecolor().
        assert colorize("foo", 0, 'red') != u"foo=0"
        assert colorize("foo", 100, 'red') != u

# Generated at 2022-06-21 08:14:53.042852
# Unit test for function stringc
def test_stringc():
    assert stringc("stringc", "white", wrap_nonvisible_chars=True) == u"\001\033[38;5;15m\002stringc\001\033[0m\002"
    assert stringc("stringc", "white", wrap_nonvisible_chars=False) == u"\033[38;5;15mstringc\033[0m"
    assert stringc("stringc", "black", wrap_nonvisible_chars=False) == u"\033[38;5;0mstringc\033[0m"
    assert stringc("stringc", "red", wrap_nonvisible_chars=False) == u"\033[38;5;1mstringc\033[0m"
    assert stringc("stringc", "green", wrap_nonvisible_chars=False) == u

# Generated at 2022-06-21 08:15:04.122125
# Unit test for function hostcolor
def test_hostcolor():
    import json
    stats = json.loads("""{
        "localhost": {
            "changed": 1,
            "dark": 1,
            "failures": 1,
            "ok": 1,
            "processed": 1,
            "skipped": 1,
            "unreachable": 1
        }
    }""")

    assert hostcolor("localhost", stats) == u"localhost                 \033[0;32m \033[0;33m \033[0;31m=1  \033[0;31m=1  \033[0;32m=1  \033[0m \033[0m=0  \033[0m \033[0m"
    assert hostcolor("localhost", stats, False) == u"localhost                 =1  =1  =1  =0  =0  "

#

# Generated at 2022-06-21 08:15:10.930346
# Unit test for function stringc
def test_stringc():
    """Usage: python -c "import ansible.utils.colorize as c; c.test_stringc()" """
    prints = [(u"test1", C.COLOR_CHANGED),
              (u"test2", C.COLOR_ERROR),
              (u"test3", C.COLOR_OK),
              (u"test4", C.COLOR_SKIP),
              (u"test5", C.COLOR_UNREACHABLE),
              (u"test6", C.COLOR_WARN)]
    for (text, color) in prints:
        print(stringc(text, color))
    for i in range(16):
        print(u"%s: %s" % (i, stringc(repr(i), u"color%d" % i)))

# Generated at 2022-06-21 08:15:19.712116
# Unit test for function colorize
def test_colorize():
    for c in [ C.COLOR_ERROR, C.COLOR_CHANGED, C.COLOR_OK, None ]:
        s = colorize("foo", 7, c)
        assert s == "foo=7   "

# Generated at 2022-06-21 08:15:26.434731
# Unit test for function colorize
def test_colorize():
    assert colorize('xxx', 0, 'blue') == stringc('xxx=0', 'blue')
    assert colorize('xxx', 1, 'blue') == stringc('xxx=1', 'blue')
    assert colorize('xxx', 12, 'blue') == stringc('xxx=12', 'blue')
    assert colorize('xxx', 123, 'blue') == stringc('xxx=123', 'blue')
    assert colorize('xxx', 1234, 'blue') == stringc('xxx=1234', 'blue')


# --- end of "pretty" code



# Generated at 2022-06-21 08:15:37.129140
# Unit test for function stringc
def test_stringc():
    for code in list(C.COLOR_CODES.values()):
        # Assert that the function does not fail with invalid color code
        try:
            assert stringc('Test', code)
        except:
            assert False

    # Assert that the function does not fail when color is disabled
    assert stringc('Test', 'green')

    # Assert that the function returns the expected results
    assert stringc('Test', 'green') == '\x1b[32mTest\x1b[0m'
    assert stringc('Test', 'rgb255255255') == '\x1b[38;5;15mTest\x1b[0m'
    assert stringc('Test', 'rgb0255255') == '\x1b[38;5;14mTest\x1b[0m'
    assert string

# Generated at 2022-06-21 08:15:49.896243
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("example.com", dict(failures=1, unreachable=0, changed=0)) == u"\033[31;01mexample.com\033[0m      "
    assert hostcolor("example.com", dict(failures=0, unreachable=1, changed=0)) == u"\033[31;01mexample.com\033[0m      "
    assert hostcolor("example.com", dict(failures=0, unreachable=0, changed=1)) == u"\033[34;01mexample.com\033[0m      "
    assert hostcolor("example.com", dict(failures=0, unreachable=0, changed=0)) == u"\033[32;01mexample.com\033[0m      "

# Generated at 2022-06-21 08:15:57.837681
# Unit test for function parsecolor
def test_parsecolor():
    assert (parsecolor(u"red") == u"31")
    assert (parsecolor(u"blue") == u"34")
    assert (parsecolor(u"magenta") == u"35")
    assert (parsecolor(u"magenTa") == u"35")
    assert (parsecolor(u"on_blue") == u"44")
    assert (parsecolor(u"on_white") == u"47")
    assert (parsecolor(u"on_magenta") == u"45")
    assert (parsecolor(u"purple") == u"35")
    assert (parsecolor(u"dark gray") == u"1;30")
    assert (parsecolor(u"dark grey") == u"1;30")

# Generated at 2022-06-21 08:16:08.924836
# Unit test for function hostcolor
def test_hostcolor():
    host = u'foohost'
    stats = {'failures': 0, 'ok': 10, 'changed': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == u"%-26s" % u'\x1b[32mfoohost\x1b[0m'

    stats['changed'] = 1
    assert hostcolor(host, stats) == u"%-26s" % u'\x1b[33mfoohost\x1b[0m'

    stats['unreachable'] = 1
    assert hostcolor(host, stats) == u"%-26s" % u'\x1b[31mfoohost\x1b[0m'



# Generated at 2022-06-21 08:16:19.129351
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'

    assert parsecolor('darkgray') == '90'
    assert parsecolor('darkred') == '91'
    assert parsecolor('darkgreen') == '92'
    assert parsecolor('darkyellow') == '93'
    assert parsecolor('darkblue') == '94'
    assert parsecolor('darkmagenta') == '95'

# Generated at 2022-06-21 08:16:29.688962
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("myhost", dict(failures=0, unreachable=0, changed=0)) == "%-26s" % "myhost"
    assert hostcolor("myhost", dict(failures=1, unreachable=0, changed=0)) == "%-37s" % stringc("myhost", C.COLOR_ERROR)
    assert hostcolor("myhost", dict(failures=0, unreachable=1, changed=0)) == "%-37s" % stringc("myhost", C.COLOR_ERROR)
    assert hostcolor("myhost", dict(failures=0, unreachable=0, changed=1)) == "%-37s" % stringc("myhost", C.COLOR_CHANGED)

# Generated at 2022-06-21 08:16:34.554686
# Unit test for function colorize
def test_colorize():  # pragma: no cover
    for color in C.COLOR_CODES:
        print("This is how %s looks like." % colorize("something",
                                                      "here",
                                                      color))
    print("This is how %s looks like." % colorize("something",
                                                  "here",
                                                  None))

# Generated at 2022-06-21 08:16:41.872167
# Unit test for function parsecolor

# Generated at 2022-06-21 08:16:57.782224
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red').upper() == '31'
    assert parsecolor('grey').upper() == '90'
    assert parsecolor('yellow').upper() == '33'
    assert parsecolor('green').upper() == '32'
    assert parsecolor('blue').upper() == '34'
    assert parsecolor('magenta').upper() == '35'
    assert parsecolor('cyan').upper() == '36'
    assert parsecolor('white').upper() == '37'
    assert parsecolor('normal').upper() == '0'
    assert parsecolor('black').upper() == '30'
    # Test some invalid color names, should return black
    assert parsecolor('invalid_color_name').upper() == '30'
    # Test some valid rgb values

# Generated at 2022-06-21 08:17:05.553345
# Unit test for function stringc
def test_stringc():
    """Colorize string to ANSI SGR codes."""
    # Color names
    print(stringc('color_black', 'black'))
    print(stringc('color_red', 'red'))
    print(stringc('color_green', 'green'))
    print(stringc('color_yellow', 'yellow'))
    print(stringc('color_blue', 'blue'))
    print(stringc('color_magenta', 'magenta'))
    print(stringc('color_cyan', 'cyan'))
    print(stringc('color_white', 'white'))

    # Color numbers
    print(stringc('color_0', 'color0'))
    print(stringc('color_1', 'color1'))
    print(stringc('color_2', 'color2'))

# Generated at 2022-06-21 08:17:13.780040
# Unit test for function colorize
def test_colorize():
    print("Test colorize")
    print("------------")
    print(u"Colorize: %s" % colorize("Test", "abc", C.COLOR_ERROR))
    print(u"Colorize: %s" % colorize("Test", "123", C.COLOR_ERROR))
    print(u"Colorize: %s" % colorize("Test", 0, C.COLOR_ERROR))
    print(u"Colorize: %s" % colorize("Test", 101, C.COLOR_ERROR))
    print(u"Colorize: %s" % colorize("Test", 4, C.COLOR_ERROR))
    print("-----------")


# Generated at 2022-06-21 08:17:24.264254
# Unit test for function parsecolor
def test_parsecolor():
    # Color names
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('bold') == '1'  # special case
    assert parsecolor('reset') == '0'  # special case

    # 256 color numeric values
    asser

# Generated at 2022-06-21 08:17:34.684017
# Unit test for function stringc
def test_stringc():
    print(u"colorize()")
    print(stringc(u"error", u"RED"))
    print(stringc(u"warning", u"YELLOW"))
    print(stringc(u"info", u"BLUE"))
    print(stringc(u"question", u"MAGENTA"))
    print(stringc(u"bold white", u"BOLD WHITE"))
    print(stringc(u"invalid", u"INVALID"))
    print(stringc(u"color10", u"color10"))
    print(stringc(u"rgb255", u"rgb255"))
    print(stringc(u"gray99", u"gray99"))


if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-21 08:17:42.031683
# Unit test for function hostcolor
def test_hostcolor():
    # pylint: disable=redefined-outer-name
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    import copy

    stats = copy.copy(PlayContext.global_stats)
    assert hostcolor('fakehost', stats, False) == '%-26s' % 'fakehost'
    assert hostcolor('fakehost', stats, True) == '%-37s' % stringc('fakehost', C.COLOR_OK)

    stats['failures'] = 1
    stats['ok'] = 1
    stats['unreachable'] = 1
    assert hostcolor('fakehost', stats, True) == '%-37s' % stringc('fakehost', C.COLOR_ERROR)

    stats['failures'] = 0
    stats['changed'] = 1
    assert host

# Generated at 2022-06-21 08:17:54.932741
# Unit test for function parsecolor
def test_parsecolor():
    try:
        import curses
    except ImportError:
        raise SkipTest("curses library not found, skipping parsecolor test")
    try:
        curses.setupterm()
    except curses.error:
        raise SkipTest("terminal not found, skipping parsecolor test")
    if curses.tigetnum("colors") < 0:
        raise SkipTest("no colors, skipping parsecolor test")
    for name, expected in C.COLOR_CODES.items():
        actual = parsecolor(name)
        yield check_parsecolor, name, expected, actual
    for color in ["color%d" % i for i in range(16)]:
        yield check_parsecolor, color, "38;5;%s" % color[-1], parsecolor(color)

# Generated at 2022-06-21 08:18:02.734581
# Unit test for function stringc
def test_stringc():
    s = stringc(u"foo bar baz", "blue")
    assert s == u"\u001b[34mfoo bar baz\u001b[0m", "got " + s
    s = stringc(u"foo bar baz", "rgb255255255")
    assert s == u"\u001b[38;5;15mfoo bar baz\u001b[0m", "got " + s
    s = stringc(u"foo bar baz", "rgb000255255 gray8", wrap_nonvisible_chars=True)
    assert s == u"\u001b[38;5;119m\u001b[38;5;48;5;232mfoo bar baz\u001b[0m\u001b[0m", "got " + s
# --- end "pretty

# Generated at 2022-06-21 08:18:09.538765
# Unit test for function stringc
def test_stringc():
    """
    >>> print stringc('test', 'green')
    \x1b[32mtest\x1b[0m
    >>> print stringc('test', 'green', wrap_nonvisible_chars=True)
    \001\x1b[32m\002test\001\x1b[0m\002
    """
    pass



# Generated at 2022-06-21 08:18:16.685085
# Unit test for function colorize
def test_colorize():
    ''' colorize unit test'''
    assert colorize(u"foo", 0, u"green") == u"foo=0   "
    assert colorize(u"bar", 255, u"red") == u"bar=255 "
    assert colorize(u"baz", 1000, None) == u"baz=1000"
    #TODO: Add test cases for ANSIBLE_NOCOLOR and ANSIBLE_FORCE_COLOR

# --- end of "pretty"



# Generated at 2022-06-21 08:18:32.299800
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    print(u"Testing function stringc")
    print(u"  Supported colors: ", end=' ')
    for color in C.COLOR_CODES:
        print(u"%s " % color, end=' ')
    print()
    for color in C.COLOR_CODES:
        print(u"  Testing color %-10s: %s"
              % (color, stringc('color %s' % color, color)))
    for color in C.COLOR_CODES:
        print(u"  Testing color %-10s: %s"
              % (color, stringc('color %s if ANSI_COLOR_SUPPORTED=true' % color, color, True)))
    # Test the rgb colors
    print()

# Generated at 2022-06-21 08:18:38.704829
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {'changed': 1, 'failures': 0, 'ok': 3, 'skipped': 0, 'unreachable': 0}
    color0 = hostcolor(host, stats, True)
    if color0 != '%-37s' % stringc(host, C.COLOR_CHANGED):
        return False
    stats = {'changed': 0, 'failures': 0, 'ok': 3, 'skipped': 0, 'unreachable': 0}
    color1 = hostcolor(host, stats, True)

# Generated at 2022-06-21 08:18:50.429436
# Unit test for function stringc
def test_stringc():
    print(stringc("This is a test", "blue"))
    print(stringc("This is a test", "red"))
    print(stringc("This is a test", "on_green"))
    print(stringc("This is a test", "on_blue"))
    print(stringc("This is a test", "green"))
    print(stringc("This is a test", "on_black"))
    print(stringc("This is a test", "blue", wrap_nonvisible_chars=True))
    print(stringc("This is a test", "red", wrap_nonvisible_chars=True))
    print(stringc("This is a test", "on_green", wrap_nonvisible_chars=True))
    print(stringc("This is a test", "on_blue", wrap_nonvisible_chars=True))

# Generated at 2022-06-21 08:18:52.793693
# Unit test for function colorize
def test_colorize():
    assert 'ok ' == colorize('ok ', 0, 'green')
    assert 'changed=' == colorize('changed=', 0, 'yellow')
    assert 'dark red' in colorize('fail=', 1, 'dark red') # color output may vary by terminal



# Generated at 2022-06-21 08:19:00.800458
# Unit test for function colorize
def test_colorize():
    res = colorize(u"num", 42, C.COLOR_SKIP)
    assert res == u"num=42  ", res

    res = colorize(u"n", 42, C.COLOR_SKIP)
    assert res == u"n=42   ", res

    res = colorize(u"num", 42, None)
    assert res == u"num=42  ", res

    res = colorize(u"n", 42, None)
    assert res == u"n=42   ", res



# Generated at 2022-06-21 08:19:09.201127
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    # Get the raw result of colorize, without any escape sequences
    def raw_colorize(lead, num, color):
        return re.sub('\x1b.*?m', '', colorize(lead, num, color))

    # Leading spaces added so that no test fails with cuts that cut out
    # leading whitespace, showing that line wrapping works with
    # colorize.  We don't actually want that in practice.
    for color in ['black', 'red', 'green', 'yellow', 'blue',
                  'magenta', 'cyan', 'white']:
        # assert instead of print to make it easy to add more tests
        assert raw_colorize('ok', '0', color) == "ok=0   "

# Generated at 2022-06-21 08:19:14.250103
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, u'red') == u"foo=0   "
    assert colorize(u"foo", 123, u'blue') == u"foo=123 "
    assert colorize(u"foo", 1234, u'green') == u"foo=1234"

# --- end "pretty"



# Generated at 2022-06-21 08:19:24.924624
# Unit test for function parsecolor
def test_parsecolor():
    def test(color, result):
        assert parsecolor(color) == result

    # colorN (N = 0-255)
    for i in range(0, 256):
        test("color%d" % i, "38;5;%d" % i)

    # rgbXYZ (X, Y, Z = 0-5)
    for r in range(0, 6):
        for g in range(0, 6):
            for b in range(0, 6):
                test("rgb%d%d%d" % (r, g, b), "38;5;%d" % (16 + 36 * r + 6 * g + b))

    # grayN (N = 0-23)

# Generated at 2022-06-21 08:19:36.956894
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('k') == C.COLOR_CODES['k']
    assert parsecolor('blacK') == C.COLOR_CODES['k']
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('rgb123') == '38;5;123'
    assert parsecolor('rgb555') == '38;5;15'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray7') == '38;5;239'
    assert parsecolor('gray8') == C.COLOR_CODES['k']
    # Unit test for function stringc
    assert stringc('None', 'k') == '\033[0mNone\033[0m'

# Generated at 2022-06-21 08:19:45.315502
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, C.COLOR_OK) == 'ok=0   '
    assert colorize('changed', 0, C.COLOR_CHANGED) == 'changed=0   '
    assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == 'unreachable=0   '
    assert colorize('failed', 0, C.COLOR_ERROR) == 'failed=0   '
    assert colorize(u'\u2713', 0, C.COLOR_OK) == u'\u2713=0   '
    assert colorize('foo', 1, 'RED') == 'foo=1   '
    assert colorize('foo', 1, '00;31') == 'foo=1   '
    assert colorize('foo', 1, '31') == 'foo=1   '
    assert colorize

# Generated at 2022-06-21 08:20:05.379671
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {'failures' : 0, 'changed' : 1}
    assert hostcolor(host, stats) == u"%-37s" % u"\033[0;32mlocalhost\033[0m"
    stats = {'failures' : 1, 'changed' : 0}
    assert hostcolor(host, stats) == u"%-37s" % u"\033[0;31mlocalhost\033[0m"
    stats = {'failures' : 0, 'changed' : 0}
    assert hostcolor(host, stats) == u"%-37s" % u"\033[0;33mlocalhost\033[0m"
    ANSIBLE_COLOR = False
    host = "localhost"
    stats = {'failures' : 0, 'changed' : 1}

# Generated at 2022-06-21 08:20:16.933418
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('cyan') == u'38;5;6'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('purple') == u'38;5;5'
    assert parsecolor('pink') == u'38;5;13'
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('white') == u'38;5;15'

# Generated at 2022-06-21 08:20:27.450341
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("host", dict(
        failures=0,
        unreachable=0,
        changed=0,
    ), True) == u"host                 "

    assert hostcolor("host", dict(
        failures=1,
        unreachable=0,
        changed=0,
    ), True) == u"\x1b[31mhost                 \x1b[0m"

    assert hostcolor("host", dict(
        failures=0,
        unreachable=1,
        changed=0,
    ), True) == u"\x1b[31mhost                 \x1b[0m"


# Generated at 2022-06-21 08:20:38.527145
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == stringc('foo=0   ', 'blue')
    assert colorize('foo', 2, 'blue') == stringc('foo=2   ', 'blue')
    assert colorize('foo', 22, 'blue') == stringc('foo=22  ', 'blue')
    assert colorize('foo', 222, 'blue') == stringc('foo=222 ', 'blue')
    assert colorize('foo', 2222, 'blue') == stringc('foo=2222', 'blue')

    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 2, None) == 'foo=2   '
    assert colorize('foo', 22, None) == 'foo=22  '
    assert colorize('foo', 222, None) == 'foo=222 '

# Generated at 2022-06-21 08:20:44.674045
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', '1', C.COLOR_OK) == stringc('ok=1', C.COLOR_OK)
    assert colorize('changed', '2', C.COLOR_CHANGED) == stringc('changed=2', C.COLOR_CHANGED)
    assert colorize('unreachable', '3', C.COLOR_UNREACHABLE) == stringc('unreachable=3', C.COLOR_UNREACHABLE)
    assert colorize('failed', '4', C.COLOR_ERROR) == stringc('failed=4', C.COLOR_ERROR)


# --- end "pretty"

# Generated at 2022-06-21 08:20:55.707836
# Unit test for function colorize
def test_colorize():
    """ Unit test for colorize """
    color_map = (
        (0, 'dark gray'),
        (1, C.COLOR_OK),
        (2, C.COLOR_CHANGED),
        (3, C.COLOR_SKIPPED),
        (4, C.COLOR_UNREACHABLE),
        (5, C.COLOR_ERRORS),
    )

    for lead in ('ok', 'changed', 'skip', 'unreachable', 'failed'):
        for num in [0, 1, 2]:
            for colordef in color_map:
                s = colorize(lead, num, colordef[1])
                print(u"colorize: %s" % s)



# Generated at 2022-06-21 08:21:06.418954
# Unit test for function stringc
def test_stringc():
    from ansible.compat.tests.mock import patch

    # first make sure we're testing the right thing
    assert stringc('My text', 'blue') == '\033[94mMy text\033[0m'

    with patch.dict(C.__dict__, {'ANSIBLE_NOCOLOR': True}):
        # if ANSIBLE_NOCOLOR = True, ANSIBLE_COLOR = False
        assert stringc('My text', 'blue') == 'My text'

    with patch.dict(C.__dict__, {'ANSIBLE_NOCOLOR': False}):
        # if ANSIBLE_NOCOLOR = False, but no tty, ANSIBLE_COLOR = False
        with patch.object(sys.stdout, 'isatty', return_value=False):
            assert stringc

# Generated at 2022-06-21 08:21:14.188606
# Unit test for function stringc
def test_stringc():
    reset = "\033[0m"
    black = "\033[30m"
    red = "\033[31m"
    green = "\033[32m"
    yellow = "\033[33m"
    blue = "\033[34m"
    magenta = "\033[35m"
    cyan = "\033[36m"
    white = "\033[37m"
    bold_black = "\033[30;1m"
    bold_red = "\033[31;1m"
    bold_green = "\033[32;1m"
    bold_yellow = "\033[33;1m"
    bold_blue = "\033[34;1m"
    bold_magenta = "\033[35;1m"
    bold_cyan = "\033[36;1m"

# Generated at 2022-06-21 08:21:24.975831
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('abc.xyz.com', dict(failures=0, unreachable=0, changed=0), False) == u'abc.xyz.com             '
    assert hostcolor('abc.xyz.com', dict(failures=0, unreachable=0, changed=0), True) == u'\033[0;32mabc.xyz.com             \033[0m'
    assert hostcolor('abc.xyz.com', dict(failures=0, unreachable=0, changed=1), True) == u'\033[0;33mabc.xyz.com             \033[0m'

# Generated at 2022-06-21 08:21:34.089764
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == "\033[32mfoo\033[0m"
    assert stringc('foo', 'red') == "\033[31mfoo\033[0m"
    assert stringc('foo', 'blue') == "\033[34mfoo\033[0m"
    assert stringc('foo', 'rgb123') == "\033[38;5;6mfoo\033[0m"
    assert stringc('foo', 'rgb000') == "\033[38;5;232mfoo\033[0m"
    assert stringc('foo', 'rgb543') == "\033[38;5;94mfoo\033[0m"
    assert stringc('foo', 'rgb354') == "\033[38;5;138mfoo\033[0m"

# Generated at 2022-06-21 08:21:42.093671
# Unit test for function colorize
def test_colorize():
    pass

