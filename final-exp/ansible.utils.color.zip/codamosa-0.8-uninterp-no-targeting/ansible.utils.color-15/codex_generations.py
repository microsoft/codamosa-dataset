

# Generated at 2022-06-21 08:11:59.113812
# Unit test for function colorize
def test_colorize():
    print(stringc("This is a test!", "green"))
    print(stringc("This is a test!", "red"))
    print(stringc('This is a test!', 'blue'))
    print(stringc('This is a test!', 'default'))
    print(stringc('This is a test!', 'rgb255144108'))
    print(stringc('This is a test!', 'rgb000255255'))
    print(stringc('This is a test!', 'rgb000124255'))
    print(stringc('This is a test!', 'rgb255255255'))
    print(stringc('This is a test!', 'rgb0102000255'))
    print(stringc('This is a test!', 'rgb255255255'))

# Generated at 2022-06-21 08:12:10.248815
# Unit test for function stringc
def test_stringc():
    """String in color."""

    # Iterate over available color names and check that they produce
    # the expected output.
    for key, value in C.COLOR_CODES.items():
        # color=0 should not have any coloring, which we expect to be
        # the default behavior.
        if key != '0':
            # We need to provide some non-whitespace character for the
            # test to work as expected.
            s = stringc('x', key)
            assert(s == '\033[%sm%s\033[0m' % (value, 'x'))
            # Negative test
            assert(s != '\033[%sm%s\033[0m' % (int(value) + 1, 'x'))



# Generated at 2022-06-21 08:12:19.161092
# Unit test for function hostcolor
def test_hostcolor():
    """ Return a string used to colorize the prompt header """
    try:
        from nose.tools import assert_equal
    except ImportError:
        # nosetests 2.x compatibility
        try:
            from nose2.tools import eq_ as assert_equal
        except ImportError:
            # nose 1.x compatibility
            try:
                from nose.tools import eq_ as assert_equal
            except ImportError:
                # nose 0.x compatibility (python3)
                from nose.tools import assert_equal
    assert_equal(hostcolor("ok", dict(ok=1, changed=0, unreachable=0, failed=0)),
                 u"ok                           ")
    assert_equal(hostcolor("changed", dict(ok=0, changed=1, unreachable=0, failed=0)),
                 u"changed                      ")
   

# Generated at 2022-06-21 08:12:30.028948
# Unit test for function hostcolor
def test_hostcolor():
    host = 'somehost'
    stats = dict(
        ok=0,
        changed=0,
        unreachable=0,
        failures=0
    )
    assert hostcolor(host, stats, False) == "%-26s" % host
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_OK)

    stats = dict(
        ok=0,
        changed=1,
        unreachable=0,
        failures=0
    )
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_CHANGED)

    stats = dict(
        ok=0,
        changed=0,
        unreachable=0,
        failures=1
    )

# Generated at 2022-06-21 08:12:39.467366
# Unit test for function parsecolor
def test_parsecolor():
    """
    parsecolor - test the parsecolor function
    :return:
    """
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('cyan') == u'38;5;6'
    assert parsecolor('white') == u'38;5;7'
    assert parsecolor('black') == u'38;5;8'

    assert parsecolor('dark red') == u'38;5;9'
    assert parsecolor('dark green') == u

# Generated at 2022-06-21 08:12:49.603927
# Unit test for function parsecolor
def test_parsecolor():
    # Test color names
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    # Test color number
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color99') == u'38;5;99'
    # Test greyscale
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsec

# Generated at 2022-06-21 08:13:01.365951
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('30') == '38;5;16'
    assert parsecolor('rgb444') == '38;5;234'
    assert parsecolor('rgb212') == '38;5;172'
    assert parsecolor('rgb344') == '38;5;190'
    assert parsecolor('rgb155') == '38;5;94'


# Generated at 2022-06-21 08:13:13.156710
# Unit test for function parsecolor
def test_parsecolor():
    def assertEqual(a, b):
        if a != b:
            raise ValueError("Error: %r != %r" % (a, b))
    assertEqual(parsecolor('blue'), '34')
    assertEqual(parsecolor('color33'), '38;5;33')
    assertEqual(parsecolor('rgb123'), '38;5;161')
    assertEqual(parsecolor('rgb100'), '38;5;89')
    assertEqual(parsecolor('rgb222'), '38;5;250')
    assertEqual(parsecolor('rgb000'), '38;5;16')
    assertEqual(parsecolor('gray1'), '38;5;233')
    assertEqual(parsecolor('gray5'), '38;5;237')

# Generated at 2022-06-21 08:13:22.962216
# Unit test for function colorize
def test_colorize():
    # CYAN = '\033[96m'
    # RESET = '\033[0m'
    if ANSIBLE_COLOR:
        # print('ansible color is ON')
        pass
    else:
        # print('ansible color is OFF')
        pass

    # print(colorize('ok', 0, C.COLOR_OK))
    # print(colorize('changed', 0, C.COLOR_CHANGED))
    # print(colorize('unreachable', 0, C.COLOR_ERROR))
    # print(colorize('skipped', 0, C.COLOR_SKIP))
    # print(colorize('failed', 0, C.COLOR_ERROR))
    #
    # print(colorize('ok', 1, C.COLOR_OK))
    # print(colorize('changed', 2, C.COLOR_

# Generated at 2022-06-21 08:13:29.103673
# Unit test for function colorize
def test_colorize():
    """Return a string with color info for the given host"""
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    module.exit_json(changed=False, metadata={u'hostcolors': {u'black': colorize(u'ok', 0, u'blue')}})



# Generated at 2022-06-21 08:13:45.054820
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"default") == u"39"
    assert parsecolor(u"normal") == u"39"
    assert parsecolor(u"red") == u"31"
    assert parsecolor(u"rgb123") == u"38;5;125"
    assert parsecolor(u"gray0") == u"38;5;232"
    assert parsecolor(u"gray01") == u"38;5;232"
    assert parsecolor(u"gray12") == u"38;5;244"


# end "pretty"


# --- begin safeyaml


# Generated at 2022-06-21 08:13:50.427038
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('darkred', 3, 'darkred') == u'\033[31mdarkred=3   \033[0m'


# Generated at 2022-06-21 08:14:01.913106
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('black') == u'30'
    assert parsecolor('blue') == u'34'
    assert parsecolor('bright red') == u'91'
    assert parsecolor('color17') == u'38;5;17'
    assert parsecolor('rgb123') == u'38;5;66'
    assert parsecolor('rgb255') == u'38;5;231'
    assert parsecolor('rgb123') != u'38;5;67'
    assert parsecolor('rgb255') != u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('gray50') == u'38;5;244'
    assert parsecolor

# Generated at 2022-06-21 08:14:12.557632
# Unit test for function hostcolor
def test_hostcolor():
    class host_class(object):
        def __init__(self):
            self.name = 'host1'
    host = host_class()
    stats = dict(changed=0, failures=0, unreachable=0)
    host1 = hostcolor(host.name, stats)
    host2 = hostcolor(host.name, stats, color=False)
    assert host1 == 'host1                 '
    assert host1 == host2

    stats = dict(changed=0, failures=1, unreachable=0)
    host1 = hostcolor(host.name, stats)
    host2 = hostcolor(host.name, stats, color=False)
    assert host1 == '\x1b[31mhost1                 \x1b[0m'
    assert host1 != host2


# Generated at 2022-06-21 08:14:23.273008
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('lightgray') == '37'
    assert parsecolor('darkgray') == '90'
    assert parsecolor('lightred') == '91'
    assert parsecolor('lightgreen') == '92'
    assert parsecolor('lightyellow') == '93'
    assert parsecolor('lightblue') == '94'
    assert parsecolor('lightmagenta') == '95'

# Generated at 2022-06-21 08:14:30.243454
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize(u"ok", 0, C.COLOR_OK) == "\nok=0  "
        assert colorize(u"changed", 0, C.COLOR_CHANGED) == "\nchanged=0  "
        assert colorize(u"skipping", 0, C.COLOR_SKIP) == "\nskipping=0  "
        assert colorize(u"unreachable", 0, C.COLOR_ERROR) == "\nunreachable=0  "
        assert colorize(u"failed", 0, C.COLOR_ERROR) == "\nfailed=0  "
        assert colorize(u"ok", 10, C.COLOR_OK) == stringc("\nok=10  ", C.COLOR_OK)

# Generated at 2022-06-21 08:14:39.131524
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 1, 'black') == 'foo=1   '
    assert colorize('foo', 10, 'black') == 'foo=10  '
    assert colorize('foo', 100, 'black') == 'foo=100 '
    assert colorize('foo', 1000, 'black') == 'foo=1000'
    assert colorize('foo', 10000, 'black') == 'foo=10000'
    assert colorize('foo', 100000, 'black') == 'foo=100000'

# --- end "pretty"

# === Some Utility Functions ===


# Generated at 2022-06-21 08:14:46.145327
# Unit test for function parsecolor
def test_parsecolor():
    # The following invocations should return the same color codes

    # ANSI/ECMA 48 color
    assert parsecolor('black') == parsecolor('color0')
    assert parsecolor('red') == parsecolor('color1')
    assert parsecolor('green') == parsecolor('color2')
    assert parsecolor('yellow') == parsecolor('color3')
    assert parsecolor('blue') == parsecolor('color4')
    assert parsecolor('magenta') == parsecolor('color5')
    assert parsecolor('cyan') == parsecolor('color6')
    assert parsecolor('white') == parsecolor('color7')

    # RGB color
    assert parsecolor('red') == parsecolor('rgb300')

# Generated at 2022-06-21 08:14:57.616940
# Unit test for function stringc
def test_stringc():
    # Use in a test scenario like this:
    # # Show the string 'Test String' in the colors red, green, yellow,
    # # blue, magenta, cyan and white, then reset.
    # >>> print test_stringc()
    #
    # File "pretty.py", line 204, in test_stringc
    #     assert s == expected, "%r != %r" % (s, expected)
    # AssertionError: '\x1b[31mTest String\x1b[0m' != '\x1b[31mTest String\x1b[0m'

    colors = ('red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white')
    for color in colors:
        expected = u'\x1b[%smTest String\x1b[0m'

# Generated at 2022-06-21 08:15:07.336411
# Unit test for function stringc
def test_stringc():
    assert stringc(u"This is Red", "RED") == u"\033[31mThis is Red\033[0m"
    assert stringc(u"This is red, too", "RED", True) == u"\001\033[31m\002This is red, too\001\033[0m\002"
    assert stringc(u"Green", "GREEN") == u"\033[32mGreen\033[0m"
    assert stringc(u"Yellow", "YELLOW") == u"\033[33mYellow\033[0m"
    assert stringc(u"Blue", "BLUE") == u"\033[34mBlue\033[0m"
    assert stringc(u"Cyan", "CYAN") == u"\033[36mCyan\033[0m"

# Generated at 2022-06-21 08:15:22.647342
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {'failures': 0, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 1}) == stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", {'failures': 0, 'changed': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", {'failures': 0, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == stringc("localhost", C.COLOR_OK)

# --- end "pretty"

# Generated at 2022-06-21 08:15:34.410710
# Unit test for function parsecolor
def test_parsecolor():
    # Parse color colors
    assert parsecolor("color0") == u'38;5;0'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("color2") == u'38;5;2'
    assert parsecolor("color3") == u'38;5;3'
    assert parsecolor("color4") == u'38;5;4'
    assert parsecolor("color5") == u'38;5;5'
    assert parsecolor("color6") == u'38;5;6'
    assert parsecolor("color7") == u'38;5;7'
    assert parsecolor("color8") == u'38;5;8'
    assert parsecolor("color9") == u'38;5;9'

# Generated at 2022-06-21 08:15:46.245963
# Unit test for function stringc
def test_stringc():
    """ Test that stringc return value matches the reference_output. """

    import pprint

# Generated at 2022-06-21 08:15:55.319771
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31', 'failed on red'
    assert parsecolor('green') == u'32', 'failed on green'
    assert parsecolor('blue') == u'34', 'failed on blue'
    assert parsecolor('magenta') == u'35', 'failed on magenta'
    assert parsecolor('cyan') == u'36', 'failed on cyan'
    assert parsecolor('color1') == u'38;5;1', 'failed on color1'
    assert parsecolor('color200') == u'38;5;200', 'failed on color1'
    assert parsecolor('rgb123') == u'38;5;21', 'failed on rgb123'
    assert parsecolor('rgb121') == u'38;5;29', 'failed on rgb121'

# Generated at 2022-06-21 08:16:04.668755
# Unit test for function hostcolor
def test_hostcolor():
    test_host = 'localhost'
    test_stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(test_host, test_stats) == u'localhost               '
    test_stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor(test_host, test_stats) == u'\x1b[0;34mlocalhost\x1b[0m      '
    test_stats = dict(failures=1, unreachable=1, changed=1)
    assert hostcolor(test_host, test_stats) == u'\x1b[0;31mlocalhost\x1b[0m      '
    ANSIBLE_COLOR = False
    assert hostcolor(test_host, test_stats) == u'localhost      '
   

# Generated at 2022-06-21 08:16:08.560751
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert parsecolor(u"red") == u"31"
        assert parsecolor(u"RED") == u"31"
        assert parsecolor(u"nocolor") is None


# Generated at 2022-06-21 08:16:18.864746
# Unit test for function stringc
def test_stringc():
    print("Test the function stringc (colorize the string)")
    print("NC = Not Colorised, NVP = Non visible chars")
    print("%-10s%-10s%-10s%-10s" % ("NC","VP","NVP","VP"))
    print("-" * 45)
    for color in C.COLOR_CODES.keys():
        print("%-10s%-10s%-10s%-10s" % (
            stringc("test", color),
            stringc("test", color, wrap_nonvisible_chars=True),
            stringc("test", color, wrap_nonvisible_chars=True),
            stringc("test", color)))
    # Special cases

# Generated at 2022-06-21 08:16:26.257610
# Unit test for function colorize
def test_colorize():
    C.ANSIBLE_NOCOLOR = True
    assert colorize('x', 0, 'green') == 'x=0   '
    assert colorize('x', 255, 'red') == 'x=255 '

    C.ANSIBLE_NOCOLOR = False
    assert colorize('x', 0, 'green') == 'x=0   '
    assert colorize('x', 255, 'red') == '\x1b[31mx=255\x1b[0m'

# Generated at 2022-06-21 08:16:34.233162
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('black') == u'30'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4')

# Generated at 2022-06-21 08:16:36.689268
# Unit test for function colorize
def test_colorize():
    """
    >>> print(colorize(u"foo", 42, u'blue'))
    foo=42
    >>> print(colorize(u"bar", 0, u'green'))
    bar=0
    """

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 08:16:52.018277
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"red") == u"31"
    assert parsecolor(u"green") == u"32"
    assert parsecolor(u"blue") == u"34"
    assert parsecolor(u"0") == u"38;5;0"
    assert parsecolor(u"1") == u"38;5;1"
    assert parsecolor(u"rgb255255255") == u"38;5;15"
    assert parsecolor(u"rgb000") == u"38;5;0"
    assert parsecolor(u"rgb001") == u"38;5;1"
    assert parsecolor(u"rgb010") == u"38;5;2"
    assert parsecolor(u"rgb100") == u"38;5;4"

# Generated at 2022-06-21 08:16:59.301245
# Unit test for function hostcolor
def test_hostcolor():
    h = u"%.37s" % u'foo'  # host string padded to 37 chars
    assert hostcolor(h, dict(failures=0, unreachable=0, changed=0)) == \
        u"%-37s" % stringc(h, 'green')
    assert hostcolor(h, dict(failures=1, unreachable=0, changed=0)) == \
        u"%-37s" % stringc(h, 'red')
    assert hostcolor(h, dict(failures=0, unreachable=1, changed=0)) == \
        u"%-37s" % stringc(h, 'red')
    assert hostcolor(h, dict(failures=0, unreachable=0, changed=1)) == \
        u"%-37s" % stringc(h, 'yellow')
    # test no

# Generated at 2022-06-21 08:17:02.380237
# Unit test for function stringc
def test_stringc():
    s = stringc("Test String", "blue")
    fmt = "\033[%sm%s\033[0m"
    assert s == fmt % (C.COLOR_CODES["blue"], "Test String")



# Generated at 2022-06-21 08:17:13.496785
# Unit test for function colorize
def test_colorize():
    from .color import colorize, stringc
    from .color import ANSIBLE_COLOR, parsecolor, C

    old_color = ANSIBLE_COLOR

    ANSIBLE_COLOR = True
    assert colorize("foo", 12, "blue") == "foo=12  "
    assert stringc("foo", "blue") == "\033[94mfoo\033[0m"

    ANSIBLE_COLOR = False
    assert colorize("foo", 12, "blue") == "foo=12  "
    assert stringc("foo", "blue") == "foo"

    assert parsecolor("blue") == C.COLOR_CODES['blue']
    assert parsecolor("cyan") == C.COLOR_CODES['cyan']
    assert parsecolor("green") == C.COLOR_CODES['green']
   

# Generated at 2022-06-21 08:17:26.027334
# Unit test for function colorize
def test_colorize():
    # Exerpt from ansible-playbook output
    #
    # PLAY RECAP *********************************************************************
    # 192.0.2.1              : ok=2    changed=1    unreachable=0    failed=0
    # 192.0.2.11             : ok=2    changed=1    unreachable=0    failed=0
    # 192.0.2.12             : ok=0    changed=0    unreachable=1    failed=0
    # localhost              : ok=7    changed=3    unreachable=0    failed=0

    lead = 'XXX'

    print(colorize(lead, 2, C.COLOR_OK))
    print(colorize(lead, 1, C.COLOR_CHANGED))
    print(colorize(lead, 0, None))

# Generated at 2022-06-21 08:17:29.866788
# Unit test for function colorize
def test_colorize():
    lead = u"test"
    num = 42
    color = u"green"
    assert colorize(lead, num, color) == stringc(u"%s=%-4s" % (lead, str(num)), color)

# Generated at 2022-06-21 08:17:40.523471
# Unit test for function parsecolor
def test_parsecolor():

    # Color tests
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('white') == u'38;5;7'
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('cyan') == u'38;5;6'
    assert parsecolor('magenta') == u'38;5;5'

    # Gray tests
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor

# Generated at 2022-06-21 08:17:54.055004
# Unit test for function colorize
def test_colorize():
    """
    Colorize: (lead, num, color)
    lead = string printed left of the '=' sign
    num = integer printed right of the '=' sign
    color = name of the color to use for the line

    This function is also used in most of the Ansible modules
    """

    from ansible.utils.color import colorize, ANSIBLE_COLOR

    if ANSIBLE_COLOR:
        nocolor = u"nocolor"
        red = u"\033[31mred\033[0m"
        blue = u"\033[34mblue\033[0m"
        cyan = u"\033[36mcyan\033[0m"
        green = u"\033[32mgreen\033[0m"
    else:
        nocolor = u"nocolor"
       

# Generated at 2022-06-21 08:18:02.371078
# Unit test for function stringc
def test_stringc():
    import sys
    import curses
    curses.setupterm()

# Generated at 2022-06-21 08:18:14.936827
# Unit test for function parsecolor

# Generated at 2022-06-21 08:18:32.264436
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('test_host', dict(failures=0, unreachable=0, ok=1, changed=0), color=False) == 'test_host                  '
    assert hostcolor('test_host', dict(failures=0, unreachable=0, ok=1, changed=0), color=True) == 'test_host                  '
    assert hostcolor('test_host', dict(failures=0, unreachable=0, ok=1, changed=1), color=False) == 'test_host                  '
    assert hostcolor('test_host', dict(failures=0, unreachable=0, ok=1, changed=1), color=True) == 'test_host                  '

# Generated at 2022-06-21 08:18:39.825574
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "red"   ) == '\033[31mtext\033[0m'
    assert stringc("text", "green" ) == '\033[32mtext\033[0m'
    assert stringc("text", "yellow") == '\033[33mtext\033[0m'
    assert stringc("text", "blue"  ) == '\033[34mtext\033[0m'
    assert stringc("text", "0"     ) == '\033[30mtext\033[0m'
    assert stringc("text", "1"     ) == '\033[31mtext\033[0m'
    assert stringc("text", "2"     ) == '\033[32mtext\033[0m'