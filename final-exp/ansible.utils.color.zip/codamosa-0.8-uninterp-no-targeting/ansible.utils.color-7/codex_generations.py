

# Generated at 2022-06-21 08:11:51.747544
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == '31'
    assert parsecolor("color01") == '38;5;1'
    assert parsecolor("rgb125") == '38;5;21'
    assert parsecolor("gray15") == '38;5;242'



# Generated at 2022-06-21 08:11:57.241775
# Unit test for function stringc
def test_stringc():
    if curses.COLORS == 256:
        # 256 color support is available.
        print(stringc('test', 'blue'))
        print(stringc('test', 'rgb105'))
        print(stringc('test', 'gray10'))
    else:
        # 256 color support is not available.
        print(stringc('test', 'blue'))
        print(stringc('test', 'rgb105'))
        print(stringc('test', 'gray10'))
# --- end "pretty"

# Generated at 2022-06-21 08:12:07.201271
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils.six import StringIO
    from ansible.plugins.callback import CallbackBase

    class TestCallback(CallbackBase):
        def __init__(self, *args, **kwargs):
            self._output = StringIO()
            super(TestCallback, self).__init__(*args, **kwargs)

        def v2_on_any(self, *args, **kwargs):
            pass

        @property
        def output(self):
            return self._output.getvalue()

        def _print(self, msg, **kwargs):
            self._output.write(msg)

    # The default inventory has the host localhost
    # the default hostvars contains a localhost entry

    cb = TestCallback()
    # No color
    cb.color = False

# Generated at 2022-06-21 08:12:17.373927
# Unit test for function stringc
def test_stringc():
    # Ensure that color codes are created appropriately
    # Cases: <color_name>, color<number>, rgb<number>, gray<number>
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('red') == u'38;5;196'
    assert parsecolor('white') == u'38;5;231'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color10') == u'38;5;10'
    assert parsecolor('color250') == u'38;5;250'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('rgb111') == u'38;5;17'

# Generated at 2022-06-21 08:12:22.828393
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'ok': 1, 'changed': 0, 'unreachable': 0, 'skipped': 0, 'failed': 0}) == 'host                    '
    assert hostcolor('host', {'ok': 1, 'changed': 1, 'unreachable': 0, 'skipped': 0, 'failed': 0}) == u'\x1b[0;34mhost\x1b[0m                    '
    assert hostcolor('host', {'ok': 1, 'changed': 0, 'unreachable': 1, 'skipped': 0, 'failed': 0}) == u'\x1b[0;31mhost\x1b[0m                    '

# Generated at 2022-06-21 08:12:34.092696
# Unit test for function stringc
def test_stringc():
    reset = u'\033[0m'
    class bcolors:
        HEADER = u'\033[95m'
        OKBLUE = u'\033[94m'
        OKGREEN = u'\033[92m'
        WARNING = u'\033[93m'
        FAIL = u'\033[91m'
        ENDC = u'\033[0m'

    s = stringc(u'blue', u'blue')
    assert s == bcolors.OKBLUE + u'blue' + reset, s

    s = stringc(u'green', u'green')
    assert s == bcolors.OKGREEN + u'green' + reset, s

    s = stringc(u'red', u'red')

# Generated at 2022-06-21 08:12:41.957019
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo.example.org', {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == u"%-37s" % stringc('foo.example.org', C.COLOR_OK)
    assert hostcolor('foo.example.org', {'failures': 1, 'unreachable': 0, 'changed': 0}, True) == u"%-37s" % stringc('foo.example.org', C.COLOR_ERROR)
    assert hostcolor('foo.example.org', {'failures': 0, 'unreachable': 1, 'changed': 0}, True) == u"%-37s" % stringc('foo.example.org', C.COLOR_ERROR)

# Generated at 2022-06-21 08:12:51.440169
# Unit test for function stringc
def test_stringc():
    def ansi_strip(s):
        return re.sub(r'\x1b\[[0-9;]*m', '', s)

    assert stringc("foo", "red") == u"\u001b[31mfoo\u001b[0m"
    assert stringc("foo\nbar", "red") == u"\u001b[31mfoo\nbar\u001b[0m"
    assert stringc("foo", "color256") == u"\u001b[38;5;256mfoo\u001b[0m"
    assert stringc("foo", "gray8") == u"\u001b[38;5;244mfoo\u001b[0m"
    assert ansi_strip(stringc("foo", "blue")) == "foo"

# Generated at 2022-06-21 08:13:03.670299
# Unit test for function stringc

# Generated at 2022-06-21 08:13:12.433359
# Unit test for function colorize
def test_colorize():
    assert "k=0" == colorize("k", 0, None)
    assert "k=0" == colorize("k", 0, "black")
    assert "\033[0;37mk=0\033[0m" == colorize("k", 0, "white")
    assert "k=1" == colorize("k", 1, None)
    assert "k=1" == colorize("k", 1, "black")
    assert "\033[0;37mk=1\033[0m" == colorize("k", 1, "white")

# --- end "pretty"

# Generated at 2022-06-21 08:13:23.115095
# Unit test for function parsecolor
def test_parsecolor():
    # Test named color
    assert parsecolor('blue') == '34'

    # Test RGB colors
    assert parsecolor('rgb000') == '30'
    assert parsecolor('rgb123') == '38;5;21'
    assert parsecolor('rgb321') == '38;5;94'
    assert parsecolor('rgb222') == '38;5;58'

    # Test grayscale colors
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'

# End of pretty



# Generated at 2022-06-21 08:13:24.230013
# Unit test for function colorize
def test_colorize():
    pass



# Generated at 2022-06-21 08:13:29.056867
# Unit test for function colorize
def test_colorize():
  lead = "mylead"
  num = 0
  color = "red"
  color_test = u"%s=%-4s" % ("mylead", str(0))
  assert colorize(lead, num, color) == color_test


# Generated at 2022-06-21 08:13:40.808918
# Unit test for function colorize
def test_colorize():
    """Return a string indicating how many tests failed, or all OK"""
    failed = 0;
    all_tests = 0;
    if not ANSIBLE_COLOR:
        print('colorize tests require ansible to be run in color mode.')
        return 'OK'

    def checkcolor(color, expected):
        global failed
        global all_tests
        all_tests += 1
        result = parsecolor(color)
        if result != expected:
            print(u"colorize(%s) returned %s, expected %s" % (color, result, expected))
            failed += 1
        else:
            print(u"colorize(%s) returned %s as expected" % (color, result))

    checkcolor(color='color7', expected='38;5;7')

# Generated at 2022-06-21 08:13:52.634167
# Unit test for function colorize
def test_colorize():
    """

    colorize: Print 'lead' = 'num' in 'color'
    """

    # Set ANSIBLE_COLOR to True to display color in unit test,
    # Make sure ANSIBLE_COLOR is set to default value before
    # exiting.
    prev_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # 1. When num is 0, colorize should not return string in color
    s = colorize(u'ok', 0, C.COLOR_OK)
    assert s == u'ok=0   '

    # 2. When num is not 0, colorize should return string in color
    s = colorize(u'ok', 10, C.COLOR_OK)
    assert s == u'\x1b[92mok=10  \x1b[0m'

    # Reset ANS

# Generated at 2022-06-21 08:14:03.720012
# Unit test for function stringc
def test_stringc():
    """ Test for stringc function. """
    assert stringc('test', 'red') == '\033[31mtest\033[0m'
    assert stringc('test', 'blue') == '\033[34mtest\033[0m'
    assert stringc('test', 'color1') == '\033[38;5;1mtest\033[0m'
    assert stringc('test', 'rgb123') == '\033[38;5;23mtest\033[0m'
    assert stringc('test', None) == '\033[39mtest\033[0m'
    assert stringc('test', 'NOT_A_COLOR') == '\033[39mtest\033[0m'

# --- end "pretty"



# Generated at 2022-06-21 08:14:08.381295
# Unit test for function colorize
def test_colorize():
    assert colorize(u'foo', 0, C.COLOR_ERROR) == u'foo=0   '
    assert colorize(u'foo', 1, C.COLOR_CHANGED) == u'foo=1   '
    # test wrapping of non-visible characters
    assert colorize(u'foo', 1, C.COLOR_CHANGED,
                    wrap_nonvisible_chars=True) == u'\x01\x1b[31m\x02foo=1  \x01\x1b[0m\x02'
    # test default color
    assert colorize(u'foo', 1) == u'foo=1   '

# Generated at 2022-06-21 08:14:16.483812
# Unit test for function hostcolor

# Generated at 2022-06-21 08:14:26.631954
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', color=False) == u"%-26s" % 'localhost'
    assert hostcolor('localhost', color=True) == stringc(u"%-26s" % 'localhost', C.COLOR_OK)

    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=False) == u"%-26s" % 'localhost'
    assert hostcolor('localhost', stats, color=True) == stringc(u"%-26s" % 'localhost', C.COLOR_OK)

    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=False) == u"%-26s" % 'localhost'

# Generated at 2022-06-21 08:14:34.776876
# Unit test for function stringc
def test_stringc():
    print('Testing stringc()')
    import sys
    for color in C.COLOR_CODES:
        sys.stdout.write(stringc(color, color, wrap_nonvisible_chars=True))
        sys.stdout.write(stringc('\n', color, wrap_nonvisible_chars=True))


if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-21 08:14:46.708286
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('rgb255255255') == u'38;5;231'
    assert parsecolor('rgb0255255') == u'38;5;51'
    assert parsecolor('rgb255255255') == u'38;5;231'
    assert parsecolor('rgb0255255') == u'38;5;51'
    assert parsecolor('rgb000255') == u'38;5;4'
    assert parsecolor('color231') == u'38;5;231'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray23') == u'38;5;255'

# Generated at 2022-06-21 08:14:58.087302
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, None) == "foo=0   "
    assert colorize("foo", 1, None) == "foo=1   "
    assert colorize("foo", 2, None) == "foo=2   "
    assert colorize("foo", 12, None) == "foo=12  "
    assert colorize("foo", 512, None) == "foo=512 "
    assert colorize("foo", 0, 'blue') == "foo=0   "
    assert colorize("foo", 1, 'blue') == "foo=\033[94m1\033[0m   "
    assert colorize("foo", 2, 'blue') == "foo=\033[94m2\033[0m   "

# Generated at 2022-06-21 08:15:07.726897
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('default') == '39'

    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'

# Generated at 2022-06-21 08:15:19.926940
# Unit test for function colorize
def test_colorize():
    try:
        from ansible.module_utils.six import StringIO
    except ImportError:
        from cStringIO import StringIO

    def _reset_stdout():
        sys.stdout = sys.__stdout__

    def _capture_stdout(func, *args, **kwargs):
        output = StringIO()
        try:
            sys.stdout = output
            func(*args, **kwargs)
        finally:
            _reset_stdout()
        return output.getvalue()

    # cases to test
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False

    color = None
    lead = 'test'
    num = 0
    out = colorize(lead=lead, num=num, color=color)
    assert out == 'test=0   '

    color = C.COLOR

# Generated at 2022-06-21 08:15:29.181570
# Unit test for function colorize
def test_colorize():
    s = u"%s = %-76s ... %s" % (colorize('xxx', 0, C.COLOR_SKIP), u'skip me ...', C.COLOR_RESET)
    assert s == u"\033[34mxxx\033[0m = \033[30m\033[47mskip me ...                                                                \033[0m\033[0m ... \033[0m"
    s = u"%s = %-76s ... %s" % (colorize('xxx', 1, C.COLOR_ERROR), u'red me ...', C.COLOR_RESET)
    assert s == u"\033[31mxxx\033[0m = \033[30m\033[41mred me ...                                                                \033[0m\033[0m ... \033[0m"


# Generated at 2022-06-21 08:15:38.593560
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('darkgray') == u'38;5;250'
    assert parsecolor('red') == u'38;5;196'
    assert parsecolor('lightred') == u'38;5;203'
    assert parsecolor('green') == u'38;5;46'
    assert parsecolor('lightgreen') == u'38;5;154'
    assert parsecolor('yellow') == u'38;5;226'
    assert parsecolor('lightyellow') == u'38;5;229'
    assert parsecolor('blue') == u'38;5;21'
    assert parsecolor('lightblue') == u'38;5;69'

# Generated at 2022-06-21 08:15:50.552381
# Unit test for function stringc
def test_stringc():
    """Test function stringc, which wraps a string in ANSI color codes."""
    # no color
    assert stringc('hello world', 'blue') == 'hello world'
    # my shell is not a tty (automated testing)
    sys.stdout.isatty = lambda: False
    assert stringc('hello world', 'blue') == 'hello world'
    # ok now it is
    del sys.stdout.isatty
    # I'm on windows (no ANSI color codes)
    if sys.platform == 'win32':
        assert stringc('hello world', 'blue') == 'hello world'
    # It's a tty, I'm on unix, color works

# Generated at 2022-06-21 08:15:58.279217
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('light_red') == u'31'
    assert parsecolor('light_blue') == u'34'
    assert parsecolor('light_green') == u'32'
    assert parsecolor('light_yellow') == u'33'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('rgb30000') == u'38;5;52'
    assert parsecolor('rgb03000') == u'38;5;22'

# Generated at 2022-06-21 08:16:02.116461
# Unit test for function colorize
def test_colorize():
        assert colorize("foo", 4, "red") == "foo=4   "
        assert colorize("foo", 40, "blue") == "foo=40  "
        assert colorize("foo", 400, "green") == "foo=400 "
        assert colorize("foo", 0, "yellow") == "foo=0   "

# Generated at 2022-06-21 08:16:09.756285
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', C.COLOR_CHANGED) == '\033[32mfoo\033[0m'
    assert stringc('foo', 'rgb255255255') == '\033[97mfoo\033[0m'
    assert stringc('foo', 'rgb255255255', wrap_nonvisible_chars=True) == '\001\033[97m\002foo\001\033[0m\002'


# --- end "pretty"



# Generated at 2022-06-21 08:16:22.499141
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('bold') == u'1'
    assert parsecolor('WHITE') == u'38;5;15'
    assert parsecolor('on_red') == u'41'
    assert parsecolor('on_bright_yellow') == u'103'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('rgb013') == u'38;5;94'
    assert parsecolor('rgb233') == u'38;5;124'
    assert parsecolor('rgb122') == u'38;5;22'
    assert parsecolor('rgb211') == u'38;5;130'

# Generated at 2022-06-21 08:16:32.036823
# Unit test for function hostcolor
def test_hostcolor():
    """hostcolor Accepts a hostname and a dictionary of stats about that
    host.  It returns a version of the hostname colored based on the stats.
    """

# Generated at 2022-06-21 08:16:41.582373
# Unit test for function colorize
def test_colorize():
    # Set ANSIBLE_COLOR=True
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    for color, code in C.COLOR_CODES.items():
        assert(stringc('teststring', color) == '\033[%smteststring\033[0m' % code)
    assert(stringc('teststring', 'testcolor') == 'teststring')

    assert(colorize('ok', 0, C.COLOR_OK) == 'ok=0   ')
    assert(colorize('changed', 0, C.COLOR_CHANGED) == 'changed=0   ')
    assert(colorize('unreachable', 0, C.COLOR_UNREACHABLE) == 'unreachable=0   ')

# Generated at 2022-06-21 08:16:48.525803
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, C.COLOR_ERROR) == u"foo=0   "
    assert colorize(u"foo", 1, C.COLOR_ERROR) == stringc(u"foo=1   ", C.COLOR_ERROR)
    assert colorize(u"foo", 2, None) == u"foo=2   "
    assert colorize(u"foo", 3, C.COLOR_CHANGED) == stringc(u"foo=3   ", C.COLOR_CHANGED)


# Generated at 2022-06-21 08:16:57.443905
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == u'38;5;4'
    assert parsecolor("color8") == u'38;5;8'
    assert parsecolor("rgb004") == u'38;5;0'
    assert parsecolor("rgb123") == u'38;5;99'
    assert parsecolor("rgb222") == u'38;5;18'
    assert parsecolor("rgb333") == u'38;5;59'
    assert parsecolor("rgb444") == u'38;5;60'
    assert parsecolor("rgb555") == u'38;5;61'
    assert parsecolor("rgb666") == u'38;5;62'
    assert parsecolor("rgb555") == u'38;5;61'

# Generated at 2022-06-21 08:17:05.427072
# Unit test for function hostcolor
def test_hostcolor():
    test_dict = {u"darkred": u"\u001b[31m%s\u001b[0m",
                 u"darkgreen": u"\u001b[32m%s\u001b[0m",
                 u"darkyellow": u"\u001b[33m%s\u001b[0m",
                 u"darkcyan": u"\u001b[36m%s\u001b[0m"}
    for color in test_dict.keys():
        x = hostcolor(color, {u"failures": 0, u"unreachable": 0}, True)
        assert x == test_dict[color] % color

# Generated at 2022-06-21 08:17:15.123042
# Unit test for function hostcolor
def test_hostcolor():
    from ansible import callbacks
    stats = callbacks.AggregateStats()
    stats.compute_diff()

    # Unreachable
    stats.unreachable = 1
    assert hostcolor(u'hostname', stats, color=True) == u'\033[91mhostname            \033[0m'  # noqa
    stats.unreachable = 0

    # Changed
    stats.changed = 1
    assert hostcolor(u'hostname', stats, color=True) == u'\033[33mhostname            \033[0m'  # noqa
    stats.changed = 0

    # Ok
    stats.ok = 1
    assert hostcolor(u'hostname', stats, color=True) == u'\033[32mhostname            \033[0m'  # noqa
    stats.ok

# Generated at 2022-06-21 08:17:26.825048
# Unit test for function stringc
def test_stringc():
    class AssertEqual(object):
        def __init__(self):
            self.str = ""
        def __call__(self, str):
            assert self.str == str, "%r != %r" % (self.str, str)

    # no color
    global ANSIBLE_COLOR
    old_ANSIBLE_COLOR = ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assertEqual = AssertEqual()
    assertEqual(stringc('text', 'blue', wrap_nonvisible_chars=True))
    ANSIBLE_COLOR = old_ANSIBLE_COLOR

    # color
    assertEqual = AssertEqual()
    assertEqual.str = u"\033[33mtext\033[0m"
    assertEqual(stringc('text', 'yellow'))


# Generated at 2022-06-21 08:17:38.358523
# Unit test for function hostcolor
def test_hostcolor():
    fake_host = 'foo'
    assert len(hostcolor(fake_host, {})) == 26
    assert len(hostcolor(fake_host, {}, color=False)) == 26

    # No fatal errors
    assert len(hostcolor(fake_host, {'failures': 0})) == 26
    assert len(hostcolor(fake_host, {'failures': 0}, color=False)) == 26

    # Fatal error
    # 37 = len(fake_host) + len('=') + len(' ')
    assert len(hostcolor(fake_host, {'failures': 1})) == 37
    assert len(hostcolor(fake_host, {'failures': 1}, color=False)) == 37

    # No unreachable
    assert len(hostcolor(fake_host, {'unreachable': 0})) == 26

# Generated at 2022-06-21 08:17:43.827900
# Unit test for function colorize
def test_colorize():
    print(colorize(u"ok", 22, C.COLOR_OK))
    print(colorize(u"changed", 0, C.COLOR_CHANGED))
    print(colorize(u"unreachable", 0, C.COLOR_UNREACHABLE))
    print(colorize(u"failed", 0, C.COLOR_ERROR))

# Test for function stringc

# Generated at 2022-06-21 08:17:55.016140
# Unit test for function parsecolor
def test_parsecolor():
    assert(u'38;5;124') == parsecolor(u'color124')
    assert(u'38;5;124') == parsecolor(u'rgb342521')
    assert(u'38;5;243') == parsecolor(u'gray9')


# Generated at 2022-06-21 08:18:05.626312
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""

    tests = [("color1", "color1"),
             ("color10", "color10"),
             ("rgb555", "rgb555"),
             ("rgb123", "rgb123"),
             ("rgb321", "rgb321"),
             ("rgb000", "rgb000"),
             #("rgb256", "rgb256"),  # ValueError
             ("gray0", "gray0"),
             ("gray7", "gray7")]

    for test in tests:
        color_code = parsecolor(test[0])
        fmt = u"\033[%sm%s\033[0m"
        assert stringc(test[1], test[0]) == fmt % (color_code, test[1])

# Generated at 2022-06-21 08:18:17.668785
# Unit test for function colorize
def test_colorize():
    """Tests function colorize()"""
    # Zero looks like this
    s = colorize("rc", 0, 'green')
    if s != u'rc=0   ':
        raise AssertionError("colorize() of zero failed")

    # Positive numbers look like this
    s = colorize("rc", 1, 'green')
    if s != u"\033[32mrc=1   \033[0m":
        raise AssertionError("colorize() of positive int failed")

    # Negative numbers look like this
    s = colorize("rc", -1, 'green')
    if s != u"\033[32mrc=-1  \033[0m":
        raise AssertionError("colorize() of negative int failed")

#
# --- end "pretty"


# Generated at 2022-06-21 08:18:27.263930
# Unit test for function colorize
def test_colorize():
    assert (colorize('a', 2, 'red') == u'a=2   ')
    assert (colorize('a', 0, 'red') == u'a=0   ')
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert (colorize('a', 2, 'red') == u'a=2   ')
    assert (colorize('a', 0, 'red') == u'a=0   ')
    ANSIBLE_COLOR = False
    assert (colorize('a', 2, 'red') == u'a=2   ')
    assert (colorize('a', 0, 'red') == u'a=0   ')
    ANSIBLE_COLOR = True
    assert (colorize('a', 2, None) == u'a=2   ')

# Generated at 2022-06-21 08:18:35.377889
# Unit test for function colorize
def test_colorize():

    # All the colors in all formats
    colors = C.COLOR_CODES
    color_formats = (None, 'bold', 'underscore', 'blink', 'reverse',
                     'concealed')
    for color_format in color_formats:
        for colorname in colors:
            nocolor = colorname
            if colorname == 'black':
                nocolor = 'dark gray'
            if color_format:
                colorname = "%s %s" % (color_format, colorname)
            color_code = parsecolor(colorname)
            assert (u"\033[%sm%s\033[0m" % (color_code, nocolor)) == \
                u"%s" % stringc(nocolor, colorname)

# Generated at 2022-06-21 08:18:44.812094
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('RED') == u'31'
    assert parsecolor('rEd') == u'31'
    assert parsecolor('red1') == u'31'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('gray10') == u'38;5;250'
    try:
        parsecolor('unknown')
        assert()
    except KeyError:
        assert()


# Generated at 2022-06-21 08:18:54.925982
# Unit test for function parsecolor
def test_parsecolor():
    assert (parsecolor("red") == "31")
    assert (parsecolor("white") == "37")
    assert (parsecolor("color1") == "38;5;1")
    assert (parsecolor("color99") == "38;5;99")
    assert (parsecolor("rgb123") == "38;5;109")
    assert (parsecolor("rgb111") == "38;5;119")
    assert (parsecolor("rgb333") == "38;5;231")
    assert (parsecolor("rgb555") == "38;5;231")
    assert (parsecolor("rgb123") == "38;5;109")
    assert (parsecolor("rgb123") == "38;5;109")
# --- end "pretty"

# Generated at 2022-06-21 08:19:06.075335
# Unit test for function hostcolor
def test_hostcolor():
    from unittest import TestCase
    from ansible.compat.tests import unittest

    class TestHostColors(TestCase):
        def test_hostcolor(self):
            # no stats
            host = 'host'
            s = hostcolor(host, {})
            self.assertEqual('%-26s', s)

            # no failures or unreachable
            s = hostcolor(host, {'failures': 0, 'unreachable': 0}, True)
            self.assertEqual(u'%-37s', s)
            s = hostcolor(host, {'failures': 0, 'unreachable': 0}, False)
            self.assertEqual(u'%-26s', s)

            # failures/unreachable

# Generated at 2022-06-21 08:19:13.362525
# Unit test for function parsecolor
def test_parsecolor():
    for color, sgr_param in C.COLOR_CODES.items():
        assert parsecolor(color) == sgr_param
        assert parsecolor(color[len('color_'):]) == sgr_param
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('rgb2551550') == u'38;5;196'



# Generated at 2022-06-21 08:19:24.382842
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('hostname', {'failures': 1, 'changed': 6, 'ok': 2,
                                  'skipped': 0, 'unreachable': 0}) == \
        u'\033[31mhostname\033[0m'
    assert hostcolor('hostname', {'failures': 0, 'changed': 6, 'ok': 2,
                                  'skipped': 0, 'unreachable': 0}) == \
        u'\033[33mhostname\033[0m'
    assert hostcolor('hostname', {'failures': 0, 'changed': 0, 'ok': 2,
                                  'skipped': 0, 'unreachable': 0}) == \
        u'\033[32mhostname\033[0m'

# Generated at 2022-06-21 08:19:39.254912
# Unit test for function stringc
def test_stringc():
    s = "string"
    print(stringc(s, 'green'))
    print(stringc(s, 'darkgray'))
    print(stringc(s, 'red'))
    print(stringc(s, 'magenta'))
    print(stringc(s, 'blue'))
    print(stringc(s, 'cyan'))
    print(stringc(s, 'yellow'))
    print(stringc(s, 'white'))
# --- end "pretty"

if __name__ == '__main__':
    # Wrap this test for Python 2 compatibility, since this module was
    # only added to Python 3.
    test_stringc()

# Generated at 2022-06-21 08:19:50.529430
# Unit test for function hostcolor
def test_hostcolor():
    # Failure modes
    assert hostcolor(u'127.0.0.1', {'failures': 1, 'changed': 0, 'unreachable': 0, 'skipped': 0}, True) == u'\x1b[31m127.0.0.1\x1b[0m                 '
    assert hostcolor(u'127.0.0.1', {'failures': 0, 'changed': 0, 'unreachable': 1, 'skipped': 0}, True) == u'\x1b[31m127.0.0.1\x1b[0m                 '
    # Skipped

# Generated at 2022-06-21 08:20:02.811865
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        stringc(u"variation", u"black")
        stringc(u"variation", u"red")
        stringc(u"variation", u"green")
        stringc(u"variation", u"yellow")
        stringc(u"variation", u"blue")
        stringc(u"variation", u"magenta")
        stringc(u"variation", u"cyan")
        stringc(u"variation", u"white")
        stringc(u"variation", u"default")
        stringc(u"variation", u"gray01")
        stringc(u"variation", u"gray02")
        stringc(u"variation", u"gray03")
        stringc(u"variation", u"gray04")
        string

# Generated at 2022-06-21 08:20:15.149317
# Unit test for function stringc
def test_stringc():
    # Colored string.
    assert stringc("Hello", "blue") == u"\033[34mHello\033[0m"
    # Non-existent color.
    assert stringc("Hello", "X") == "Hello"
    # Term with no color capabilities.
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert stringc("Hello", "blue") == "Hello"
    ANSIBLE_COLOR = True
    # Newline in string.
    assert stringc("Hello\nworld", "blue") == u"\033[34mHello\nworld\033[0m"
    # Color code in string.
    assert stringc("\033[34mHello", "blue") == u"\033[34m\033[34mHello\033[0m"
    # Invalid color code in string.


# Generated at 2022-06-21 08:20:18.757379
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 456, None) == "foo=456 "
    assert colorize("foo", 0, "red") == "foo=0   "
    assert colorize("foo", 0, None) == "foo=0   "
    assert colorize("foo", 123, "red") == u"foo=123 "
    assert colorize("foo", 123, None) == u"foo=123 "



# Generated at 2022-06-21 08:20:30.380170
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), True) == u"\u001b[32mlocalhost\033[0m          "
        assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), True) == u"\u001b[31mlocalhost\033[0m          "
        assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), True) == u"\u001b[31mlocalhost\033[0m          "
        assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), True) == u"\u001b[33mlocalhost\033[0m          "

# --- end "pretty"


# Generated at 2022-06-21 08:20:39.442967
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor("host", dict(changed=1)) == u"\x1b[38;5;34mhost            \x1b[0m")
    assert(hostcolor("host", dict(failures=1)) == u"\x1b[38;5;124mhost            \x1b[0m")
    assert(hostcolor("host", dict(unreachable=1)) == u"\x1b[38;5;124mhost            \x1b[0m")
    assert(hostcolor("host", dict(changed=1, failures=1)) == u"\x1b[38;5;34mhost            \x1b[0m")



# Generated at 2022-06-21 08:20:46.537111
# Unit test for function stringc
def test_stringc():
    u"""Tests for function stringc."""

    # Basic test
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"

    # Test with color number
    assert stringc(u"foo", u"color256") == u"\033[38;5;256mfoo\033[0m"

    # Test with RGB color
    assert stringc(u"foo", u"rgb123") == u"\033[38;5;61mfoo\033[0m"

    # Test with grayscale color
    assert stringc(u"foo", u"gray5") == u"\033[38;5;239mfoo\033[0m"

    # Test with ANSI color

# Generated at 2022-06-21 08:20:55.884588
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test for function parsecolor."""
    test_color = ['black', 'red', 'green', 'yellow',
                  'blue', 'magenta', 'cyan', 'white']
    # test_color = ['color0', 'color1', 'color2', 'color3', 'color4', 'color5',
    #               'color6', 'color7', 'color8', 'color9']
    for color in test_color:
        res = parsecolor(color)
        assert isinstance(res, unicode), "Fail to format the SGR string"
        assert len(res) == 2



# Generated at 2022-06-21 08:21:06.590574
# Unit test for function colorize
def test_colorize():
    assert u"\033[1;91mfailures=1   \033[0m" == colorize(u'failures', 1, u'red')
    assert u"\033[1;92mchanged=1    \033[0m" == colorize(u'changed', 1, u'green')
    assert u"\033[1;93munreachable=1\033[0m" == colorize(u'unreachable', 1, u'yellow')
    assert u"\033[1;32mok=1         \033[0m" == colorize(u'ok', 1, u'green')
    assert u"skipped=1" == colorize(u'skipped', 1, None)
    assert u"rescued=1 " == colorize(u'rescued', 1, None)

# Generated at 2022-06-21 08:21:21.136139
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('color1') == "38;5;1")
    assert(parsecolor('color022') == "38;5;22")
    assert(parsecolor('color255') == "38;5;255")
    assert(parsecolor('rgb123') == "38;5;123")
    assert(parsecolor('rgb255') == "38;5;255")
    assert(parsecolor('rgb555') == "38;5;231")
    assert(parsecolor('gray1') == "38;5;234")
    assert(parsecolor('gray22') == "38;5;255")
    assert(parsecolor('color0') == "")
    assert(parsecolor('rgb256') == "")
    assert(parsecolor('rgb2550') == "")

# Generated at 2022-06-21 08:21:31.379087
# Unit test for function stringc
def test_stringc():
    if parsecolor("red") != "31":
        raise Exception("failed color red")

    if parsecolor("blue") != "34":
        raise Exception("failed color blue")

    if parsecolor("bright red") != "31;1":
        raise Exception("failed color bright red")

    if parsecolor("bright blue") != "34;1":
        raise Exception("failed color bright blue")

    if parsecolor("color8") != "38;5;8":
        raise Exception("failed color number")

    if parsecolor("rgb250") != "38;5;250":
        raise Exception("failed color rgb250")

    if parsecolor("rgb331") != "38;5;58":
        raise Exception("failed color rgb331")


# Generated at 2022-06-21 08:21:44.671458
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = dict(failures=0, unreachable=1, changed=10)
    print("Test 1: unreachable, color=True")
    print("Expected: \033[91mlocalhost\033[0m           ")
    print("Actual:   ", hostcolor(host, stats, color=True))
    print("Test 2: unreachable, color=False")
    print("Expected: localhost")
    print("Actual:   ", hostcolor(host, stats, color=False))
    print("Test 3: changed, color=True")
    print("Expected: \033[93mlocalhost\033[0m           ")
    print("Actual:   ", hostcolor(host, dict(failures=0, unreachable=0, changed=1), color=True))