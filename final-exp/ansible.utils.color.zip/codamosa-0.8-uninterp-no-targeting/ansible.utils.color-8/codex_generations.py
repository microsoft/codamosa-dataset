

# Generated at 2022-06-21 08:11:56.742622
# Unit test for function colorize
def test_colorize():

    # check to make sure we detect lack of terminal support for color correctly
    global ANSIBLE_COLOR
    ANSIBLE_COLOR=True
    try:
        import curses
        curses.setupterm()
        assert curses.tigetnum("colors") > 0
    except:
        ANSIBLE_COLOR=False

    # Test for color off
    global ANSIBLE_NOCOLOR
    ANSIBLE_NOCOLOR = True

    assert "ok=1   " == colorize("ok", 1, C.COLOR_OK)
    assert "changed=1 " == colorize("changed", 1, C.COLOR_CHANGED)
    assert "failed=1 " == colorize("failed", 1, C.COLOR_ERROR)

# Generated at 2022-06-21 08:11:59.824375
# Unit test for function colorize
def test_colorize():
    pass
    # FIXME:  Can this be converted to a proper unittest?
    #print "tests to be written..."

# Initialize colorama
if ANSIBLE_COLOR:
    try:
        from ansible.colorama import init
        init()
    except:
        ANSIBLE_COLOR = False

# --- end "pretty"


# Generated at 2022-06-21 08:12:11.913256
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('34') == '38;5;34'
    assert parsecolor('rgb333') == '38;5;62'
    assert parsecolor('rgb777') == '38;5;231'
    assert parsecolor('rgb888') == '38;5;255'
    assert parsecolor('rgb123') == '38;5;21'


# Generated at 2022-06-21 08:12:20.235784
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc(u"hello world", u"black", True) == u"\001\033[38;5;0m\002hello world\001\033[0m\002"
    assert stringc(u"hello world", u"red", True) == u"\001\033[31m\002hello world\001\033[0m\002"
    assert stringc(u"hello world", u"rgb255255255", True) == u"\001\033[38;5;15m\002hello world\001\033[0m\002"
    assert stringc(u"hello world", u"rgb0255255", True) == u"\001\033[38;5;6m\002hello world\001\033[0m\002"

# --- end

# Generated at 2022-06-21 08:12:31.273438
# Unit test for function colorize
def test_colorize():
    from ansible.callbacks import AggregateStats
    ag = AggregateStats()
    ag.process_raw_stats(dict(failures=1, unreachable=2, changed=3), dict(contacted={}))
    assert colorize('fail', ag.failures, C.COLOR_ERROR)    == u"\x1b[31mfail=1  \x1b[0m"
    assert colorize('unre', ag.unreachable, C.COLOR_ERROR) == u"\x1b[31munre=2  \x1b[0m"
    assert colorize('chng', ag.changed, C.COLOR_CHANGED)   == u"\x1b[33mchng=3 \x1b[0m"

# Generated at 2022-06-21 08:12:39.779774
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor("127.0.0.1", dict(failures=1)))
    print(hostcolor("127.0.0.1", dict(changed=1)))
    print(hostcolor("127.0.0.1", dict(changed=1, failures=1)))
    print(hostcolor("127.0.0.1", dict(ok=1)))
    print(hostcolor("127.0.0.1", dict(failed=1, unreachable=1)))
    print(hostcolor("127.0.0.1", dict(skipped=1)))
    print(hostcolor("127.0.0.1", dict(ok=1, changed=1)))

if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-21 08:12:49.887692
# Unit test for function hostcolor
def test_hostcolor():
    h1 = "test.example.com"
    s1 = {'failures': 0, 'ok': 2, 'changed': 1, 'skipped': 0, 'unreachable': 0}
    r1 = hostcolor(h1, s1)
    assert r1 == u"test.example.com              ", "hostcolor() returned the wrong result for host " + h1 + " with stats " + str(s1)

    h2 = "test.example.com"
    s2 = {'failures': 1, 'ok': 2, 'changed': 1, 'skipped': 0, 'unreachable': 0}
    r2 = hostcolor(h2, s2)
    assert r2 != r1, "hostcolor() should return a different string when the host " + h2 + " has a failure"



# Generated at 2022-06-21 08:12:51.819583
# Unit test for function stringc
def test_stringc():
    assert stringc("stringc() UNIT TEST", "blue") == u"\033[34mstringc() UNIT TEST\033[0m"



# Generated at 2022-06-21 08:12:56.113476
# Unit test for function stringc
def test_stringc():
    print(stringc("banana", "red"))
    print(stringc("banana", "white", wrap_nonvisible_chars=True))


if __name__ == "__main__":
    test_stringc()
# --- end "pretty"

# Generated at 2022-06-21 08:13:07.493384
# Unit test for function stringc
def test_stringc():
    assert u"\033[33mTEST\033[0m" == stringc("TEST", "yellow")
    assert u"\033[1mTEST\033[0m" == stringc("TEST", "bold")
    assert u"\033[33mTEST\033[0m" == stringc("TEST", "color33")
    assert u"\033[31mTEST\033[0m" == stringc("TEST", "red")
    assert u"\033[33mTEST\033[0m" == stringc("TEST", "yellow")
    assert u"\033[33mTEST\033[0m" == stringc("TEST", "color60")
    assert u"\033[33mTEST\033[0m" == stringc("TEST", "rgb222")

# Generated at 2022-06-21 08:13:22.206519
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    C.ANSIBLE_FORCE_COLOR = False
    assert stringc(u"test", u"green") == u"test"
    assert stringc(u"test", u"black") == u"test"
    assert stringc(u"test", u"color236") == u"test"
    assert stringc(u"test", u"color255") == u"test"
    assert stringc(u"test", u"rgb0") == u"test"
    assert stringc(u"test", u"rgb5") == u"test"
    assert stringc(u"test", u"rgb15") == u"test"
    assert stringc(u"test", u"rgb255") == u"test"

# Generated at 2022-06-21 08:13:22.855736
# Unit test for function parsecolor
def test_parsecolor():
    pass

# Generated at 2022-06-21 08:13:26.138979
# Unit test for function colorize
def test_colorize():
    assert colorize('test', 1, 'red') == u"test=1   "

# --- end "pretty"


# Generated at 2022-06-21 08:13:37.389526
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    print(u"OK: %s" % hostcolor(u"localhost", stats, False))
    print(u"OK: %s" % hostcolor(u"localhost", stats, True))
    stats['changed'] = 1
    print(u"Changed: %s" % hostcolor(u"localhost", stats, False))
    print(u"Changed: %s" % hostcolor(u"localhost", stats, True))
    stats['failures'] = 1
    print(u"Failed: %s" % hostcolor(u"localhost", stats, False))
    print(u"Failed: %s" % hostcolor(u"localhost", stats, True))



# Generated at 2022-06-21 08:13:41.365522
# Unit test for function stringc
def test_stringc():
    print(u"Color codes:")
    for color_name, color_code in C.COLOR_CODES.items():
        print(u"  %s: %s" % (color_name, stringc(color_code, color_name)))



# Generated at 2022-06-21 08:13:49.376031
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;1' == parsecolor('red')
    assert u'38;5;2' == parsecolor('green')
    assert u'38;5;3' == parsecolor('yellow')
    assert u'38;5;4' == parsecolor('blue')
    assert u'38;5;5' == parsecolor('magenta')
    assert u'38;5;6' == parsecolor('cyan')
    assert u'38;5;7' == parsecolor('grey')
    assert u'38;5;8' == parsecolor('white')
    assert u'38;5;9' == parsecolor('color1')
    assert u'38;5;10' == parsecolor('color2')

# Generated at 2022-06-21 08:14:01.360449
# Unit test for function hostcolor
def test_hostcolor():
    # Little hack to be able to import and test this module
    # independently of the rest of Ansible
    import ansible.constants as C
    C.COLOR_ERROR = 'red'
    C.COLOR_OK = 'green'
    C.COLOR_CHANGED = 'magenta'
    ANSIBLE_COLOR = True
    # Test 1: no failures, no changes
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor('host', stats) == u'host\033[0m              '
    # Test 2: failures
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor('host', stats) == u'host\033[0m              '
    # Test 3: unreachable

# Generated at 2022-06-21 08:14:11.999268
# Unit test for function stringc
def test_stringc():
    """ Unit test to make sure stringc works as it should """
    # Test a normal color
    test_string = 'This is a test of stringc'
    color_string = stringc(test_string, 'blue')
    assert color_string.startswith(u'\033[94m'), 'Ansi color code not found in string: %s' % color_string
    assert color_string.endswith(u'\033[0m'), 'Ansi color reset not found in string: %s' % color_string
    assert color_string[-4] != u'm', 'Ansi color reset is not at the end of the string: %s' % color_string

    # Test color with non visible characters wrapped
    test_string = '>>> This is a test of stringc with non visible characters'

# Generated at 2022-06-21 08:14:22.865062
# Unit test for function colorize
def test_colorize():
    import sys

    class DummyStream:
        def write(self, msg):
            sys.stderr.write(msg.encode('string_escape'))
            sys.stderr.write('\n')

    orig_stderr = sys.stderr

    try:
        sys.stderr = DummyStream()
        colorize('foo', 4, 'red')
        colorize('foo', 0, 'red')
        colorize('foo', 4, None)
        colorize('foo', 0, None)
    finally:
        sys.stderr = orig_stderr
# --- end "pretty"

# --- begin "termcap"
#
# termcap     - A simple example of how to use the termcap module for
#               Python. This is public domain code.
#
# Copyright (C)

# Generated at 2022-06-21 08:14:30.026708
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('default') == '39'
    assert parsecolor('black') == '30'
    assert parsecolor('blue') == '34'
    assert parsecolor('cyan') == '36'
    assert parsecolor('green') == '32'
    assert parsecolor('lblack') == '90'
    assert parsecolor('lblue') == '94'
    assert parsecolor('lcyan') == '96'
    assert parsecolor('lgreen') == '92'
    assert parsecolor('lmagenta') == '95'
    assert parsecolor('lred') == '91'
    assert parsecolor('lwhite') == '97'
    assert parsecolor('lyellow') == '93'
    assert parsecolor('magenta') == '35'
    assert parsecolor

# Generated at 2022-06-21 08:14:37.307199
# Unit test for function colorize
def test_colorize():
    c = C.COLOR_ERROR
    assert colorize('>', 0, c) == '>=  0'
    assert colorize('>', 1, c) == u'\u001b[31m>=\u001b[0m 1'
    assert colorize('>', 123, c) == u'\u001b[31m>=\u001b[0m 123'

# --- end "pretty"



# Generated at 2022-06-21 08:14:39.484482
# Unit test for function stringc
def test_stringc():
    # print stringc("fubar", "red")
    print(stringc("fubar", "red"))



# Generated at 2022-06-21 08:14:50.710493
# Unit test for function colorize
def test_colorize():
    for i in (0, 2, 99, 256):
        print(u"%4d: %s" % (i, colorize(u'VAR', i, 'bold')))

    ANSIBLE_COLOR = False
    print(u"Now with ANSIBLE_COLOR = False")
    for i in (0, 2, 99, 256):
        print(u"%4d: %s" % (i, colorize(u'VAR', i, 'bold')))
# --- end of "pretty" ---

# The codes below are adapted from the following URL:
# http://stackoverflow.com/questions/287871/print-in-terminal-with-colors-using-python

CODE_RESET = t_reset = 0
CODE_BOLD = t_bold = 1  ### bold
CODE

# Generated at 2022-06-21 08:15:02.193800
# Unit test for function colorize
def test_colorize():
    # normal
    assert colorize(u"foo", u"3", u'green') == u"\033[32mfoo=3  \033[0m"
    # 0 is the default (neutral) color
    assert colorize(u"foo", u"0", u'green') == u"foo=0  "
    # if the term doesn't support color, we shouldn't get color codes
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize(u"foo", u"3", u'green') == u"foo=3  "

# --- end pretty

# HERE BE DRAGONS!

BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = list(range(8))

# These are the sequences need to get colored ouput
RESET_

# Generated at 2022-06-21 08:15:14.596444
# Unit test for function colorize
def test_colorize():
    # Set these parameters to enable colorized output.
    # ANSIBLE_FORCE_COLOR=True sets ANSIBLE_COLOR=True
    C.ANSIBLE_FORCE_COLOR=True
    ANSIBLE_COLOR=True
    global ANSIBLE_COLOR
    ANSIBLE_COLOR=True

    fmt = u"\033[%sm%s\033[0m"

    # print hosts with changed=0, unreachable=0, failed=0 in green
    assert colorize(u"green", 0, C.COLOR_OK) == fmt % (u'32', u'green=0   ')

    # print hosts with changed=0, unreachable=0, failed=1 in red
    assert colorize(u"red", 1, C.COLOR_ERROR) == fmt % (u'31', u'red=1     ')



# Generated at 2022-06-21 08:15:25.579857
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        # Color name
        assert parsecolor('blue') == '34'
        assert parsecolor('bright purple') == '35'
        # XTerm 256 color
        assert parsecolor('color9') == '38;5;9'
        assert parsecolor('color99') == '38;5;99'
        assert parsecolor('rgb25533117') == '38;5;196'
        # XTerm 256 grayscale
        assert parsecolor('gray0') == '38;5;232'
        assert parsecolor('gray7') == '38;5;239'
        assert parsecolor('gray8') == '38;5;244'
        assert parsecolor('gray9') == '38;5;249'

# Generated at 2022-06-21 08:15:33.878270
# Unit test for function colorize
def test_colorize():
    print("Testing colorize()")
    # Test 'skipped' color
    if ANSIBLE_COLOR:
        s = colorize("S", 33, C.COLOR_SKIP)
        assert s == stringc("S=33", C.COLOR_SKIP)
    else:
        s = colorize("S", 33, C.COLOR_SKIP)
        assert s == "S=33  "

    # Test 'ok' color
    if ANSIBLE_COLOR:
        s = colorize("O", 0, C.COLOR_OK)
        assert s == "O=0   "
    else:
        s = colorize("O", 0, C.COLOR_OK)
        assert s == "O=0   "

    # Test 'changed' color

# Generated at 2022-06-21 08:15:40.742243
# Unit test for function stringc
def test_stringc():
    """Pretty Print - String in Color (stringc)."""

    assert stringc(u"this is red", u"RED") == u"\033[31mthis is red\033[0m"
    assert stringc(u"this is blue", u"BLUE") == u"\033[34mthis is blue\033[0m"
    assert stringc(u"this is orange", u"ORANGE") == u"\033[33mthis is orange\033[0m"
    assert stringc(u"gray70", u"gray70") == u"\033[37mgray70\033[0m"
    assert stringc(u"color233", u"color233") == u"\033[38;5;233mcolor233\033[0m"

# Generated at 2022-06-21 08:15:46.873514
# Unit test for function stringc
def test_stringc():
    """ Unit test for function stringc """
    assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"
    assert stringc('foo', 'rgb33') == u"\033[38;5;119mfoo\033[0m"
    assert stringc('foo', 'rgb322') == u"\033[38;5;183mfoo\033[0m"



# Generated at 2022-06-21 08:15:50.697652
# Unit test for function colorize
def test_colorize():
    assert colorize('le', 'ad', 'blue') == "le=ad  "
    assert colorize('lead', 'ad', 'blue') == "lead=ad "
    assert colorize('lead', 'a', 'blue') == "lead=a   "
    assert colorize('lead', 'textthatiswaytoolong', 'blue') == "lead=textthatiswaytoolong"



# Generated at 2022-06-21 08:16:01.167084
# Unit test for function hostcolor
def test_hostcolor():
    from . import callbacks
    stats = callbacks.AggregateStats()
    stats.compute_diff()
    assert '\033[0m' not in hostcolor('foo', stats, color=False)
    assert '\033[1;31m' not in hostcolor('foo', stats, color=False)
    assert '\033[0m' not in hostcolor('foo', stats, color=True)

# --- end "pretty"

# Generated at 2022-06-21 08:16:13.759076
# Unit test for function colorize
def test_colorize():
    print("colorize():")
    print("color_black: " + colorize("black", 0, "black"))
    print("color_red: " + colorize("red", 1, "red"))
    print("color_green: " + colorize("green", 2, "green"))
    print("color_yellow: " + colorize("yellow", 3, "yellow"))
    print("color_blue: " + colorize("blue", 4, "blue"))
    print("color_magenta: " + colorize("magenta", 5, "magenta"))
    print("color_cyan: " + colorize("cyan", 6, "cyan"))
    print("color_white: " + colorize("white", 7, "white"))
    print("color_default: " + colorize("default", 8, "default"))
# --- end of pretty

# Generated at 2022-06-21 08:16:22.385837
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("error") == C.COLOR_CODES["error"]
    assert parsecolor("color0") == u'38;5;0'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("color234") == u'38;5;234'
    assert parsecolor("rgb000") == u'38;5;16'
    assert parsecolor("rgb555") == u'38;5;231'
    assert parsecolor("rgb123") == u'38;5;36'
    assert parsecolor("gray0") == u'38;5;232'
    assert parsecolor("gray1") == u'38;5;233'

# Generated at 2022-06-21 08:16:31.963399
# Unit test for function stringc
def test_stringc():
    assert stringc("hello world", "red") == u"\033[31mhello world\033[0m"
    assert stringc("hello world", "green") == u"\033[32mhello world\033[0m"
    assert stringc("hello world", "blue") == u"\033[34mhello world\033[0m"
    assert stringc("hello world", "yellow") == u"\033[33mhello world\033[0m"
    assert stringc("hello world", "purple") == u"\033[35mhello world\033[0m"
    assert stringc("hello world", "cyan") == u"\033[36mhello world\033[0m"

# Generated at 2022-06-21 08:16:41.516949
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == "31"
    assert parsecolor("blue") == "34"
    assert parsecolor("default") == "39"
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("color10") == "38;5;10"
    assert parsecolor("color99") == "38;5;99"
    assert parsecolor("rgb123") == "38;5;21"
    assert parsecolor("rgb222") == "38;5;58"
    assert parsecolor("rgb333") == "38;5;95"
    assert parsecolor("rgb012") == "38;5;16"
    assert parsecolor("rgb021") == "38;5;22"

# Generated at 2022-06-21 08:16:52.272613
# Unit test for function stringc
def test_stringc():
    for colorname in C.COLOR_CODES.keys():
        assert re.match(
            r'\033\[(?:0|\d\d;?){1,2}m',
            stringc(u'test', colorname).decode('utf-8')
        ), "Missing escape characters in stringc output"
    assert re.match(
        r'\033\[(?:0|\d\d;?){1,2}m',
        stringc(u'test', 'rgb250').decode('utf-8')
    ), "RGB values not converted to correct ANSI code"
#
# --- end "pretty"


# Generated at 2022-06-21 08:16:59.447434
# Unit test for function parsecolor
def test_parsecolor():
    assert u"38;5;3" == parsecolor("red")
    assert u"38;5;2" == parsecolor("green")
    assert u"38;5;4" == parsecolor("blue")
    assert u"38;5;11" == parsecolor("yellow")
    assert u"38;5;10" == parsecolor("cyan")
    assert u"38;5;13" == parsecolor("purple")
    assert u"38;5;14" == parsecolor("orange")
    assert u"38;5;9" == parsecolor("brightgreen")
    assert u"38;5;12" == parsecolor("brightblue")
    assert u"38;5;5" == parsecolor("brightred")
    assert u"38;5;15" == parsecolor

# Generated at 2022-06-21 08:17:10.908444
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, None) == "foo=0   "
    assert colorize("foo", 1, None) == "foo=1   "
    assert colorize("foo", 10, None) == "foo=10  "
    assert colorize("foo", 100, None) == "foo=100 "
    assert colorize("foo", 1000, None) == "foo=1000"
    assert colorize("foo", 10000, None) == "foo=10000"

    assert colorize("foo", 0, "blue") == "foo=0   "
    assert colorize("foo", 1, "blue") == "foo=1   "
    assert colorize("foo", 10, "blue") == "foo=10  "
    assert colorize("foo", 100, "blue") == "foo=100 "

# Generated at 2022-06-21 08:17:25.079928
# Unit test for function stringc
def test_stringc():
    """Unit tests for stringc()."""
    assert stringc("blah", "red") == "\033[31mblah\033[0m"
    assert stringc("blah", "blue") == "\033[34mblah\033[0m"
    assert stringc("blah", "yellow") == "\033[33mblah\033[0m"
    assert stringc("blah", "black") == "\033[30mblah\033[0m"
    assert stringc("blah", "default") == "\033[39mblah\033[0m"
    assert stringc("blah", "purple") == "\033[35mblah\033[0m"
    assert stringc("blah", "cyan") == "\033[36mblah\033[0m"
    assert stringc("blah", "green")

# Generated at 2022-06-21 08:17:36.035668
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'blue', 'yellow', 'cyan', 'gray', 'magenta', 'darkgray', 'lightred', 'lightgreen'):
        lead = 'LEAD'
        num = 123
        colored = colorize(lead, num, c)
        if colored is None:
            continue
        assert colored.startswith(lead + "=")
        assert colored.endswith("123")
        # This function wraps the color code around the lead, so we need
        # to strip it out
        color_code = re.search("^\033\[(.*)mLEAD", colored).group(1)
        assert colored == lead + "=" + stringc("123", color_code, wrap_nonvisible_chars=True)
# --- end

# Generated at 2022-06-21 08:17:56.944554
# Unit test for function stringc
def test_stringc():
    assert stringc("ansible", "bold") == u"\033[1mansible\033[0m"
    assert stringc("ansible", "red") == u"\033[31mansible\033[0m"
    assert stringc("ansible", "rgb020") == u"\033[38;5;94mansible\033[0m"
    assert stringc("ansible", "color01") == u"\033[38;5;1mansible\033[0m"
    assert stringc("ansible", "rgb255") == u"\033[38;5;15mansible\033[0m"
    assert stringc("ansible", "gray10") == u"\033[38;5;250mansible\033[0m"
    assert stringc("ansible", "on_red") == u

# Generated at 2022-06-21 08:18:09.949099
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test for function parsecolor"""

    assert(parsecolor('cyan') == '36')
    assert(parsecolor('black') == '30')
    assert(parsecolor('red') == '31')
    assert(parsecolor('yellow') == '33')
    assert(parsecolor('green') == '32')
    assert(parsecolor('blue') == '34')
    assert(parsecolor('magenta') == '35')
    assert(parsecolor('white') == '37')

    assert(parsecolor('bright_cyan') == '96')
    assert(parsecolor('bright_black') == '90')
    assert(parsecolor('bright_red') == '91')
    assert(parsecolor('bright_yellow') == '93')

# Generated at 2022-06-21 08:18:20.286917
# Unit test for function colorize
def test_colorize():
    assert colorize("ok", 0, C.COLOR_OK) == u"ok=0  "
    assert colorize("changed", 0, C.COLOR_OK) == u"changed=0  "
    assert colorize("ok", 1, C.COLOR_OK) == u"ok=1  "
    assert colorize("failed", 1, C.COLOR_ERROR) == u"\nfailed=1  "
    assert colorize("failed", 1, 'foo') == u"failed=1  "
    assert colorize("foo", 0, 'foo') == u"foo=0   "
    assert colorize("foo", "bar", 'foo') == u"foo=bar   "
    assert colorize("foo", None, 'foo') == u"foo=None "


# Generated at 2022-06-21 08:18:29.304880
# Unit test for function parsecolor
def test_parsecolor():
    assert '38;5;11' == parsecolor('blue')
    assert '38;5;1' == parsecolor('color1')
    assert '38;5;2' == parsecolor('color2')
    assert '38;5;3' == parsecolor('color3')
    assert '38;5;4' == parsecolor('color4')
    assert '38;5;5' == parsecolor('color5')
    assert '38;5;6' == parsecolor('color6')
    assert '38;5;7' == parsecolor('color7')
    assert '38;5;8' == parsecolor('color8')
    assert '38;5;9' == parsecolor('color9')
    assert '38;5;10' == parsecolor('color10')

# Generated at 2022-06-21 08:18:37.451125
# Unit test for function stringc
def test_stringc():
    # Test colors
    assert stringc('red', 'red') == '\033[31mred\033[0m'
    assert stringc('green', 'green') == '\033[32mgreen\033[0m'
    assert stringc('blue', 'blue') == '\033[34mblue\033[0m'
    # Test the wrap_nonvisible_chars option
    assert stringc('test', 'red', wrap_nonvisible_chars=True) == '\001\033[31m\002test\001\033[0m\002'
    # Test invalid colors
    assert stringc('test', 'invalid_color') == 'test'
    # Test resetting of attribute
    assert stringc('test', 'red') == '\033[31mtest\033[0m'

# Generated at 2022-06-21 08:18:44.405048
# Unit test for function stringc
def test_stringc():
    # These two statements should produce the same output
    print(u"\nNormal:\n" + stringc(u"This is a test", 'blue') +
          "\n")
    print(u"\nNon-visible characters:\n" + stringc(u"This is a test", 'blue',
                                                  wrap_nonvisible_chars=True) + "\n")



# Generated at 2022-06-21 08:18:50.711699
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('red') == u'38;5;88'
    assert parsecolor('green') == u'38;5;76'
    assert parsecolor('yellow') == u'38;5;94'
    assert parsecolor('blue') == u'38;5;21'
    assert parsecolor('magenta') == u'38;5;175'
    assert parsecolor('cyan') == u'38;5;54'
    assert parsecolor('white') == u'38;5;145'
    assert parsecolor('rc0') == u'38;5;16'
    assert parsecolor('rc1') == u'38;5;88'