

# Generated at 2022-06-21 08:11:57.938011
# Unit test for function stringc
def test_stringc():
    class BW:
        r = 'red'
        e = 'red'
        g = 'green'
        a = 'green'
        b = 'blue'
        m = 'magenta'
        y = 'yellow'
        k = 'black'
        w = 'white'
        def __init__(self):
            self.i = '\033[%dm%%s\033[0m' % (0)
            self.bold = '\033[%dm%%s\033[0m' % (1)
            self.ul = '\033[%dm%%s\033[0m' % (4)
            self.inv = '\033[%dm%%s\033[0m' % (7)
            self.strike = '\033[%dm%%s\033[0m' % (9)

   

# Generated at 2022-06-21 08:12:08.826214
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        sys.stderr.write("no color support detected")
        return False

    COLORS = ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white')
    GOOD = u'ok       '
    BAD = u'fail     '
    UNREACHABLE = u'dead    '
    CHANGED = u'changed  '

    for c in COLORS:
        lead = '-' * 7
        s = colorize(lead, GOOD, c)
        if GOOD not in s:
            print("failed on GOOD with %s" % c)
            return False

        s = colorize(lead, BAD, c)
        if BAD not in s:
            print("failed on BAD with %s" % c)
            return False

        s = color

# Generated at 2022-06-21 08:12:18.440537
# Unit test for function colorize
def test_colorize():
    """Function colorize() Unit Test"""

    stats = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    host = 'localhost'
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert hostcolor(host, stats, color=True) == u'\033[0;32mlocalhost\033[0m             '
    assert colorize('ok',1,'green') == u'\033[0;32mok=1   \033[0m'
    assert colorize('changed',1,'yellow') == u'\033[0;33mchanged=1   \033[0m'
    assert colorize('failures',1,'red') == u'\033[0;31mfailures=1  \033[0m'


# Generated at 2022-06-21 08:12:23.020023
# Unit test for function hostcolor
def test_hostcolor():
    stats = {
            'ok': 10,
            'failures': 0,
            'changed': 2,
            'skipped': 2,
            'unreachable': 0,
            'rescued': 0,
            'ignored': 0
    }
    print(hostcolor('localhost', stats))
    stats['failures'] = 1
    print(hostcolor('localhost', stats))
# --- end "pretty"

# Generated at 2022-06-21 08:12:32.881614
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"red") == u"31"
    assert parsecolor(u"rgb255000") == u"31"
    assert parsecolor(u"rgb000255") == u"34"
    assert parsecolor(u"rgb255255255") == u"37"
    assert parsecolor(u"rgb255") == u"38;5;231"
    assert parsecolor(u"color1") == u"38;5;1"
    assert parsecolor(u"gray100") == u"38;5;255"
    assert parsecolor(u"xyz") == C.COLOR_CODES[u"xyz"]

# Generated at 2022-06-21 08:12:43.260769
# Unit test for function parsecolor

# Generated at 2022-06-21 08:12:52.457947
# Unit test for function colorize
def test_colorize():
    # set ANSIBLE_COLOR=False
    global ANSIBLE_COLOR
    saved_ansible_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    # Normal call
    assert colorize(u"A", 1, u"red") == u"A=1   "

    # Now turn on ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    # Call it again with same args
    assert colorize(u"A", 1, u"red") == u"\033[31mA=1   \033[0m"

    # reset ANSIBLE_COLOR
    ANSIBLE_COLOR = saved_ansible_color


# --- end "pretty"
#
# This is a quite common pattern to avoid expensive repeated look-ups in globals
# and builtins.
# Without this pattern, we would have to

# Generated at 2022-06-21 08:13:05.139853
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=True) == u"\x1b[0;32mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), color=True) == u"\x1b[0;31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), color=True) == u"\x1b[0;31mlocalhost\x1b[0m          "

# Generated at 2022-06-21 08:13:17.069466
# Unit test for function stringc
def test_stringc():
    print(u"\nTesting function stringc() from pretty")
    print(u"\nShould look like:\n"
          u"\033[31mtext in red\033[0m\n"
          u"\033[32mtext in green\033[0m\n"
          u"\033[33mtext in yellow\033[0m\n"
          u"\033[34mtext in blue\033[0m\n"
          u"\033[0mtext in normal\033[0m\n"
          u"\033[38;5;208mtext in magenta\033[0m\n")

# Generated at 2022-06-21 08:13:24.230655
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('abc', dict(failures=0, unreachable=0, changed=0)) == u"abc                          "
    assert hostcolor('abc', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mabc                      \x1b[0m"
    assert hostcolor('abc', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mabc                      \x1b[0m"
    assert hostcolor('abc', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mabc                      \x1b[0m"



# Generated at 2022-06-21 08:13:39.433218
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'light blue') == u'38;5;117'
    assert parsecolor(u'color32') == u'38;5;32'
    assert parsecolor(u'rgb324') == u'38;5;168'
    assert parsecolor(u'rgb255') == u'38;5;231'
    assert parsecolor(u'rgb111') == u'38;5;144'
    assert parsecolor(u'gray4') == u'38;5;240'
    assert parsecolor(u'gray0') == u'38;5;232'


# end "pretty" functions
# ---

# --- begin "diff" functions



# Generated at 2022-06-21 08:13:44.676175
# Unit test for function colorize
def test_colorize():
    colorize_test = colorize(u"TEST", u"123", u"green")
    colorize_test_1 = colorize(u"TEST", u"123", None)

    assert(colorize_test == u"\x1b[32mTEST=123\x1b[0m")
    assert(colorize_test_1 == u"TEST=123")

# --- end "pretty"

# Generated at 2022-06-21 08:13:55.308749
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('lightred') == u'31'
    assert parsecolor('nocolor') == u'39'
    assert parsecolor('lightgreen') == u'92'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('rgb255255255') == u'38;5;7'
    assert parsecolor('gray7') == u'38;5;239'
    assert parsecolor('gray') == u'39'
    assert parsecolor('badcolor') == u'39'

# --- end of "pretty"

# Generated at 2022-06-21 08:14:06.311761
# Unit test for function parsecolor
def test_parsecolor():
    # Test color
    assert u'38;5;1' == parsecolor(u'color1')
    assert u'38;5;200' == parsecolor(u'color200')
    assert u'38;5;232' == parsecolor(u'color232')
    assert u'38;5;255' == parsecolor(u'color255')

    # Test rgb
    assert u'38;5;16' == parsecolor(u'rgb000')
    assert u'38;5;231' == parsecolor(u'rgb555')
    assert u'38;5;51' == parsecolor(u'rgb220')

    # Test gray
    assert u'38;5;232' == parsecolor(u'gray0')
    assert u'38;5;255' == parsec

# Generated at 2022-06-21 08:14:15.285618
# Unit test for function stringc
def test_stringc():
    print(stringc('this is a test', 'green'))
    print(stringc('this is a test', 'red'))
    print(stringc('this is a test', 'blue'))
    print(stringc('this is a test', 'magenta'))
    print(stringc('this is a test', 'cyan'))
    print(stringc('this is a test', 'white'))
    print(stringc('this is a test', 'black'))
    print(stringc('this is a test', 'yellow'))
    print(stringc('this is a test', 'bright_green'))
    print(stringc('this is a test', 'bright_red'))
    print(stringc('this is a test', 'bright_blue'))

# Generated at 2022-06-21 08:14:25.852361
# Unit test for function stringc
def test_stringc():
    ''' Unit tests: stringc '''

    # Set up some strings for testing stringc

    text = u'\nHello World!'
    color = u'green'

    # Perform the test
    formatted_text = stringc(text, color)

    # Add the test strings to a list and the strings we expect to get from
    # stringc to another list.

    test_strings = [
        [u'\nHello World!', u'green'],
        [u'\u00a5', u'green'],  # Unicode Japanese yen sign
        [u'\u2665', u'red'],  # Unicode black heart suit
        [u'\n\u00a5\u2665', u'blue'],
    ]

# Generated at 2022-06-21 08:14:38.584583
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('default') == u'39'
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('darkgray') == u'90'
    assert parsecolor('darkred') == u'91'
    assert parsecolor('darkgreen') == u'92'
    assert parsecolor('darkyellow') == u'93'
    assert parsecolor('darkblue') == u

# Generated at 2022-06-21 08:14:48.505293
# Unit test for function stringc

# Generated at 2022-06-21 08:15:00.244438
# Unit test for function hostcolor
def test_hostcolor():
    module_utils.basic._ANSIBLE_ARGS = module_utils.basic.AnsibleOptions(connection='local', module_path=['/to/mymodules'], forks=10, become=None, become_method=None, become_user=None, check=False, diff=False, listhosts=None, listtasks=None, listtags=None, syntax=None, verbosity=3)
    stats = dict(failures=1, unreachable=0, changed=1)

    host = 'server'
    color = True
    s = hostcolor(host, stats, color)
    print(s)

    stats = dict(failures=0, unreachable=0, changed=0)

    host = 'server'
    color = True
    s = hostcolor(host, stats, color)
    print(s)

#

# Generated at 2022-06-21 08:15:08.485556
# Unit test for function colorize
def test_colorize():

    # Store stdout so it can be restored later
    old_stdout = sys.stdout

    # Create fake stdout for this test
    class FakeFile(object):
        ''' file-like object that records what was written to it '''
        content = list()
        def write(self, x):
            self.content.append(x)
    fake_stdout = FakeFile()
    sys.stdout = fake_stdout

    # Run colorize with a bunch of test cases
    colorize("test", "0", C.COLOR_ERROR)

    # Restore stdout
    sys.stdout = old_stdout

    # Colorize should have printed a line to stdout
    assert(len(fake_stdout.content) == 1)
    # And it should be the right line

# Generated at 2022-06-21 08:15:21.501679
# Unit test for function stringc
def test_stringc():
    """
    >>> print(stringc('foo','red','blue','on_yellow','bold','underline','blink','reverse','concealed'))
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 08:15:29.785352
# Unit test for function colorize
def test_colorize():
    red = parsecolor('red')
    green = parsecolor('green')
    blue = parsecolor('blue')
    color_list = [
        (0, 'ok', green),
        (1, 'changed', green),
        (0, 'skip', blue),
        (1, 'failed', red),
        (0, 'unreachable', red),
        (1, 'skipped', blue),
        (0, 'ok', green),
        (1, 'changed', green),
        (0, 'skipped', blue),
    ]
    for num, lead, col in color_list:
        out = colorize(lead, num, col)
        assert out.split('=')[0] == lead
        assert out.split('=')[1].strip() == str(num)
# --- end prettyed


# Generated at 2022-06-21 08:15:38.907419
# Unit test for function hostcolor
def test_hostcolor():
    host = "192.168.1.1"

    stats_failed = dict(failures=1, unreachable=0, changed=0)
    stats_unreachable = dict(failures=0, unreachable=1, changed=0)
    stats_changed = dict(failures=0, unreachable=0, changed=1)
    stats_ok = dict(failures=0, unreachable=0, changed=0)

    assert hostcolor(host, stats_ok, True) == u"%-37s" % stringc(host, C.COLOR_OK)
    assert hostcolor(host, stats_changed, True) == u"%-37s" % stringc(host, C.COLOR_CHANGED)

# Generated at 2022-06-21 08:15:51.066400
# Unit test for function parsecolor

# Generated at 2022-06-21 08:15:59.489253
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert ANSIBLE_COLOR
        assert parsecolor('normal') == u'39'
        assert parsecolor('42') == u'38;5;42'
        assert parsecolor('rgb255') == u'38;5;231'
        assert parsecolor('rgb000') == u'38;5;16'
        assert parsecolor('rgb123') == u'38;5;18'
        assert parsecolor('gray0') == u'38;5;232'
        assert parsecolor('gray23') == u'38;5;255'



# Generated at 2022-06-21 08:16:06.675113
# Unit test for function colorize
def test_colorize():
    """
    colorize:Print 'lead' = 'num' in 'color'
    """
    results = colorize("ok", 0, 'green')
    assert results == "ok=0   "
    results = colorize("changed", 2, 'yellow')
    assert results == "\x1b[33mchanged=2  \x1b[0m"
    results = colorize("failed", 1, 'red')
    assert results == "\x1b[31mfailed=1  \x1b[0m"
    results = colorize("skipped", 0, 'cyan')
    assert results == "skipped=0 "
    results = colorize("unreachable", 3, 'red')
    assert results == "\x1b[31munreachable=3\x1b[0m"

# Generated at 2022-06-21 08:16:10.982108
# Unit test for function stringc
def test_stringc():
    assert stringc('abc', 'yellow') == "\033[33mabc\033[0m"
    assert stringc('abc\ndef', 'yellow') == "\033[33mabc\033[0m\n\033[33mdef\033[0m"



# Generated at 2022-06-21 08:16:16.731576
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"blue") == u'34'
    assert parsecolor(u"color21") == u'38;5;21'
    assert parsecolor(u"rgb510") == u'38;5;19'
    assert parsecolor(u"gray7") == u'38;5;249'
    assert parsecolor(u"bluish") == u'34'


# Generated at 2022-06-21 08:16:27.643035
# Unit test for function colorize
def test_colorize():
    try:
        import curses
    except ImportError:
        print("Unable to run colorize tests - module curses is not installed")
        return

    sys.stdout.write("Testing ANSIBLE_NOCOLOR...")
    sys.stdout.flush()
    try:
        s = colorize("x", 2, "red")
        if s == "x=2   ":
            sys.stdout.write("success\n")
        else:
            sys.stdout.write("failed: %s\n" % s)
    except:
        sys.stderr.write("failed\n")

    sys.stdout.write("Testing ANSIBLE_COLOR...")
    sys.stdout.flush()

# Generated at 2022-06-21 08:16:35.150447
# Unit test for function stringc
def test_stringc():
    import sys
    import datetime
    from ansible.utils.color import stringc

    start_time = datetime.datetime.now().time()
    score = 0
    tests = []

    tests.append(u"Foo %s" % stringc(u'Bar', u'black'))
    tests.append(u"Foo %s" % stringc(u'Bar', u'blue'))
    tests.append(u"Foo %s" % stringc(u'Bar', u'cyan'))
    tests.append(u"Foo %s" % stringc(u'Bar', u'green'))
    tests.append(u"Foo %s" % stringc(u'Bar', u'magenta'))

# Generated at 2022-06-21 08:16:55.378832
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test", dict(failures=1, unreachable=1, changed=1)) == u"\x1b[31;01mtest\x1b[0m      "
    assert hostcolor("test", dict(failures=1, unreachable=0, changed=1)) == u"\x1b[31;01mtest\x1b[0m      "
    assert hostcolor("test", dict(failures=0, unreachable=1, changed=1)) == u"\x1b[31;01mtest\x1b[0m      "
    assert hostcolor("test", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31;01mtest\x1b[0m      "

# Generated at 2022-06-21 08:17:04.775501
# Unit test for function parsecolor

# Generated at 2022-06-21 08:17:12.848476
# Unit test for function colorize
def test_colorize():
    ANSIBLE_COLOR = True

    print(colorize("YES", 0, "color1"))
    assert stringc("YES=0", "color1") == u"\033[38;5;12mYES=0\033[0m"

    print(colorize("NO", 0, None))
    assert "NO=0" == u"NO=0"

    print(colorize("YES", 0, "color1"))
    assert stringc("YES=0", "color1") == u"\033[38;5;12mYES=0\033[0m"

# --- end  "pretty"

# Generated at 2022-06-21 08:17:25.836376
# Unit test for function colorize

# Generated at 2022-06-21 08:17:37.307182
# Unit test for function stringc
def test_stringc():
    assert isinstance(stringc(None, None), str)
    assert u"\033[1;31mfoo\033[0m" == stringc(u"foo", "RED")
    assert u"\033[1;36mfoo\033[0m" == stringc(u"foo", "CYAN")
    assert u"\033[0;36mfoo\033[0m" == stringc(u"foo", "LIGHT_CYAN")
    assert u"\033[0;33mfoo\033[0m" == stringc(u"foo", "YELLOW")
    assert u"\033[1;33mfoo\033[0m" == stringc(u"foo", "BRIGHT_YELLOW")
    assert u"\033[0;32mfoo\033[0m" == string

# Generated at 2022-06-21 08:17:47.943123
# Unit test for function stringc
def test_stringc():
    assert stringc("normal", "normal") == "\033[00;00mnormal\033[00m"
    assert stringc("bright", "bright") == "\033[01;00mbright\033[00m"
    assert stringc("dim", "dim") == "\033[02;00mdim\033[00m"
    assert stringc("underline", "underline") == "\033[04;00munderline\033[00m"
    assert stringc("blink", "blink") == "\033[05;00mblink\033[00m"
    assert stringc("reverse", "reverse") == "\033[07;00mreverse\033[00m"
    assert stringc("hidden", "hidden") == "\033[08;00mhidden\033[00m"


# Generated at 2022-06-21 08:17:59.533308
# Unit test for function stringc

# Generated at 2022-06-21 08:18:12.522514
# Unit test for function colorize
def test_colorize():
    """ ansible.utils.ansible_color_test """

    # Test colorize()
    s = colorize(u"ok", 5, C.COLOR_OK)
    assert s == stringc(u"ok=5", C.COLOR_OK), "1: " + s
    s = colorize(u"changed", 1, C.COLOR_CHANGED)
    assert s == stringc(u"changed=1", C.COLOR_CHANGED), "2: " + s
    s = colorize(u"unreachable", 0, C.COLOR_UNREACHABLE)
    assert s == stringc(u"unreachable=0", C.COLOR_UNREACHABLE), "3: " + s
    s = colorize(u"fatal", 1, C.COLOR_ERROR)

# Generated at 2022-06-21 08:18:18.180657
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    case1 = hostcolor("127.0.0.1", {"ok": 1, "changed": 0, "failures": 0, "unreachable": 0, "skipped": 0}, True)
    case2 = hostcolor("127.0.0.1", {"ok": 0, "changed": 1, "failures": 0, "unreachable": 0, "skipped": 0}, True)
    case3 = hostcolor("127.0.0.1", {"ok": 0, "changed": 0, "failures": 1, "unreachable": 0, "skipped": 0}, True)
    case4 = hostcolor("127.0.0.1", {"ok": 0, "changed": 0, "failures": 0, "unreachable": 1, "skipped": 0}, True)

# Generated at 2022-06-21 08:18:23.651489
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u"foo=0   "
    assert colorize('foo', 255, 'blue') == u"foo=255 "
    assert colorize('foo', 1000, 'blue') == u"foo=1000"
    assert colorize('foo', 1, 'blue') == u"foo=1   "



# Generated at 2022-06-21 08:18:39.410400
# Unit test for function parsecolor
def test_parsecolor():
    print(parsecolor('red'))
    print(parsecolor('white'))
    print(parsecolor('blue'))
    print(parsecolor('bright_blue'))
    print(parsecolor('reset'))
    print(parsecolor('none'))
    print(parsecolor('color0'))
    print(parsecolor('color8'))
    print(parsecolor('rgb255'))
    print(parsecolor('rgb0'))
    print(parsecolor('rgb123'))
    print(parsecolor('gray0'))
    print(parsecolor('gray7'))
    print(parsecolor('gray23'))
    print(parsecolor('gray24'))



# Generated at 2022-06-21 08:18:48.710505
# Unit test for function stringc
def test_stringc():
    try:
        curses.setupterm()
        color_support = curses.tigetnum('colors') > 0
    except:
        color_support = False
    if not color_support:
        print("Colors not supported or terminal not set up properly, skipping test_stringc")
        return
    def test(text, color):
        result = stringc(text, color)
        print(result)
    test(u"test text", "blue")
    test(u"test text", "rgb254")

test_stringc()

# --- end "pretty"

# Generated at 2022-06-21 08:18:56.306576
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        return

    print(colorize("ok", 10, "green"))
    print(colorize("changed", 5, "yellow"))
    print(colorize("unreachable", 1, "red"))
    print(colorize("failed", 1, "red"))
    print(colorize("skipped", 1, "blue"))

#
# --- end "pretty"


# global variable to store color settings per host
HOST_PASSED = dict()
HOST_UNREACHABLE = dict()
HOST_FAILED = dict()



# Generated at 2022-06-21 08:19:06.987040
# Unit test for function stringc
def test_stringc():
    # Print the colors because we can't predict the actual colors
    # the terminal will use
    print("color = %s" % stringc("color", "color18"))
    print("rgb = %s" % stringc("rgb", "rgb555"))
    print("gray = %s" % stringc("gray", "gray2"))
    print("color = %s" % stringc("color", "color18", True))
    print("rgb = %s" % stringc("rgb", "rgb555", True))
    print("gray = %s" % stringc("gray", "gray2", True))
    print("color = %s" % stringc("color", "color18", False))
    print("rgb = %s" % stringc("rgb", "rgb555", False))

# Generated at 2022-06-21 08:19:18.040116
# Unit test for function hostcolor
def test_hostcolor():
    """Make sure colorize works properly"""
    assert u'ok=1   ' == hostcolor('server1', dict(ok=1), True)
    assert u'server1' == hostcolor('server1', dict(ok=1), False)
    assert u'\x1b[31mserver1\x1b[0m' == hostcolor('server1', dict(failed=1), True)
    assert u'server1' == hostcolor('server1', dict(failed=1), False)
    assert u'\x1b[32mchanged=1\x1b[0m' == hostcolor('server1', dict(changed=1), True)
    assert u'changed=1' == hostcolor('server1', dict(changed=1), False)


# Generated at 2022-06-21 08:19:27.359305
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0'
    assert colorize('failed', 0, 'red') == 'failed=0     '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0    '

    assert colorize('ok', 1, 'green') == 'ok=1   '
    assert colorize('changed', 2, 'yellow') == 'changed=2   '
    assert colorize('unreachable', 3, 'red') == 'unreachable=3'
    assert colorize('failed', 4, 'red') == 'failed=4     '

# Generated at 2022-06-21 08:19:39.498601
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"red") == "31"
    assert parsecolor(u"green") == "32"
    assert parsecolor(u"blue") == "34"
    assert parsecolor(u"magenta") == "35"
    assert parsecolor(u"none") == "39"
    assert parsecolor(u"color0") == "38;5;0"
    assert parsecolor(u"color1") == "38;5;1"
    assert parsecolor(u"color9") == "38;5;9"
    assert parsecolor(u"color10") == "38;5;10"
    assert parsecolor(u"color11") == "38;5;11"
    assert parsecolor(u"color12") == "38;5;12"
    assert par

# Generated at 2022-06-21 08:19:49.244292
# Unit test for function colorize
def test_colorize():
    # Setup mocks to simulate color available
    old_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # Test default value
    assert colorize("", 0, None) == "=0   "

    # Test a few possibilities
    assert colorize("", 0, "blue") == "=0   "
    assert colorize("", 1, "blue") == stringc("=1  ", "blue")
    assert colorize("", 1, "RED") == stringc("=1  ", "RED")
    assert colorize("", 123, "green") == stringc("=123", "green")

    # Restore
    ANSIBLE_COLOR = old_color


# Generated at 2022-06-21 08:20:01.235685
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize('foo', 0, 'blue') == stringc('foo=0   ', 'blue')
        assert colorize('foo', 1, 'blue') == stringc('foo=1   ', 'blue')
        assert colorize('foo', 11, 'blue') == stringc('foo=11  ', 'blue')
        assert colorize('foo', 111, 'blue') == stringc('foo=111 ', 'blue')
        assert colorize('foo', 1111, 'blue') == stringc('foo=1111', 'blue')
    else:
        assert colorize('foo', 0, 'blue') == 'foo=0   '
        assert colorize('foo', 1, 'blue') == 'foo=1   '
        assert colorize('foo', 11, 'blue') == 'foo=11  '

# Generated at 2022-06-21 08:20:04.968551
# Unit test for function colorize
def test_colorize():
    """
    %(start)s
    """
    def eq(a, b):
        return a == b

    not_eq = lambda a, b: not eq(a, b)

    c = colorize

    ok = c("ok", 0, "green")
    failed = c("failed", 1, "red")
    unreachable = c("unreachable", 1, "red")
    changed = c("changed", 1, "yellow")
    skipped = c("skipped", 1, "cyan")

    assert eq(ok, "ok=0   ")
    assert eq(failed, "failed=1  ")
    assert eq(unreachable, "unreachable=1  ")
    assert eq(changed, "changed=1  ")
    assert eq(skipped, "skipped=1  ")



# Generated at 2022-06-21 08:20:28.690315
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('white') == '37'
    assert parsecolor('color15') == '38;5;15'
    assert parsecolor('rgb123') == '38;5;105'
    assert parsecolor('gray9') == '38;5;241'

# Units test for function stringc

# Generated at 2022-06-21 08:20:36.617845
# Unit test for function hostcolor
def test_hostcolor():
    print(u"%-37s" % stringc(u"foobar", C.COLOR_ERROR))
    print(u"%-37s" % stringc(u"foobar", C.COLOR_CHANGED))
    print(u"%-37s" % stringc(u"foobar", C.COLOR_OK))
    print(u"%-26s" % C.COLOR_ERROR)
    print(u"%-26s" % C.COLOR_CHANGED)
    print(u"%-26s" % C.COLOR_OK)

# --- end "pretty"

# Generated at 2022-06-21 08:20:40.678047
# Unit test for function colorize
def test_colorize():
    print(colorize(u"test", 255, C.COLOR_ERROR))
    print(colorize(u"test", 0, C.COLOR_OK))
    print(colorize(u"test", 1, C.COLOR_CHANGED))
    print(colorize(u"test", 1, None))



# Generated at 2022-06-21 08:20:52.801376
# Unit test for function colorize
def test_colorize():
    # Set these to True if debugging to allow pdb to work
    try:
        from unittest.case import SkipTest
    except ImportError:
        from nose import SkipTest
    # raise SkipTest("Debugging")
    ANSIBLE_COLOR = True

    def field_present(field, text):
        return (text.find(field) >= 0)

    # Failing host
    lead = 'test'
    num = 0
    color = C.COLOR_ERROR
    text = colorize(lead, num, color)
    assert field_present('test=%s' % num, text)
    assert field_present(C.COLOR_ERROR, text)

    # Passing host
    lead = 'test'
    num = 0
    color = C.COLOR_OK
    text = colorize(lead, num, color)

# Generated at 2022-06-21 08:21:03.975759
# Unit test for function stringc
def test_stringc():
    from colorama import init, deinit
    from colorama import Fore, Back

    init(autoreset=True)
    print(u"\033[1;37;40m" +
          u"alice" + u"\033[0m" + u"\033[0;37;40m: " +
          u"\033[37;41m" + u"bob" + u"\033[0m")
    print(stringc(u"alice", u"white") + u": " +
          stringc(u"bob", u"red"))

    deinit()

    init(autoreset=True)

# Generated at 2022-06-21 08:21:12.638664
# Unit test for function parsecolor
def test_parsecolor():
    # Test the string 'colorX' where X is an integer from 0-255.
    for x in range(256):
        color1 = parsecolor("color%d" % x)
        color2 = parsecolor("color%03d" % x)
        assert(color1 == color2)
        assert(color1 == u"38;5;%d" % x)

    # Test the string 'rgbXXX' where X is an integer from 0-5.
    for r in range(6):
        for g in range(6):
            for b in range(6):
                color1 = parsecolor("rgb%d%d%d" % (r, g, b))
                color2 = parsecolor("rgb%1d%1d%1d" % (r, g, b))

# Generated at 2022-06-21 08:21:22.943351
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost                    '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[0;32;49mlocalhost\x1b[0m         '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[0;31;49mlocalhost\x1b[0m         '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[0;31;49mlocalhost\x1b[0m         '
# --- end of "pretty"

# Generated at 2022-06-21 08:21:32.718167
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test for function parsecolor"""
    # Test some common color names
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'

    # Test 256 colors
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert par

# Generated at 2022-06-21 08:21:45.061727
# Unit test for function hostcolor