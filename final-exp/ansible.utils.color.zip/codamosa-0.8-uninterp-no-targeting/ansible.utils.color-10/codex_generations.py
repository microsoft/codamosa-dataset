

# Generated at 2022-06-21 08:11:59.144211
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('yellow') == '33'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('blue') == '34'
    assert parsecolor('green') == '32'
    assert parsecolor('default') == '39'
    assert parsecolor('nocolor') == '39'
    assert parsecolor('white') == '97'
    assert parsecolor('black') == '30'
    assert parsecolor('gray') == '90'
    assert parsecolor('grey') == '90'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color227') == '38;5;227'
    assert par

# Generated at 2022-06-21 08:12:11.086057
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'black') == u"\033[30mfoo\033[0m"
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"
    assert stringc('foo', 'yellow') == u"\033[33mfoo\033[0m"
    assert stringc('foo', 'blue') == u"\033[34mfoo\033[0m"
    assert stringc('foo', 'magenta') == u"\033[35mfoo\033[0m"
    assert stringc('foo', 'cyan') == u"\033[36mfoo\033[0m"

# Generated at 2022-06-21 08:12:19.755545
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('white') == u'37'
    assert parsecolor('blue') == u'34'
    assert parsecolor('brightred') == u'91'
    assert parsecolor('red') == u'31'
    assert parsecolor('brightgreen') == u'92'
    assert parsecolor('green') == u'32'
    assert parsecolor('brightyellow') == u'93'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('color9') == u'38;5;9'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('rgb333') == u'38;5;61'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsec

# Generated at 2022-06-21 08:12:30.639156
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=True) == 'localhost              '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), color=True) == 'localhost              '
    assert hostcolor('localhost', dict(failures=0, unreachable=2, changed=0), color=True) == 'localhost              '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=3), color=True) == 'localhost              '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == 'localhost      '

#
# --- end "pretty"

#
# --- begin "simplejson compat"
#
# simplejson compat
# Ansible started requiring

# Generated at 2022-06-21 08:12:37.319953
# Unit test for function colorize
def test_colorize():
    ''' colorize unit test'''
    tests = ['ok', 'changed', 'failures', 'darkgray', 'skipped', 'unreachable']
    res = [u'ok=0   ', u'changed=1', u'failures=3', u'darkgray=100', u'skipped=0 ', u'unreachable=1']
    for i in range(len(tests)):
        assert colorize(tests[i], i, tests[i]) == res[i]


# Generated at 2022-06-21 08:12:43.695185
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test_host", dict(failures=1, unreachable=0, changed=0)) == \
        u"%-37s" % stringc("test_host", C.COLOR_ERROR)
    assert hostcolor("test_host", dict(failures=0, unreachable=1, changed=0)) == \
        u"%-37s" % stringc("test_host", C.COLOR_ERROR)
    assert hostcolor("test_host", dict(failures=0, unreachable=0, changed=1)) == \
        u"%-37s" % stringc("test_host", C.COLOR_CHANGED)

# Generated at 2022-06-21 08:12:52.747754
# Unit test for function hostcolor
def test_hostcolor():
    # Set the color to always on
    color = True
    # Check that hostcolor returns the correct color
    # when there are no stats
    stats = {}
    result = hostcolor('This is a test', stats, color)
    assert result == u'%-37s' % stringc('This is a test', C.COLOR_OK)
    # Check that hostcolor returns the correct color
    # when there are changes
    stats = {"changed": 1}
    result = hostcolor('This is a test', stats, color)
    assert result == u'%-37s' % stringc('This is a test', C.COLOR_CHANGED)
    # Check that hostcolor returns the correct color
    # when there are failures
    stats = {"failures": 1}
    result = hostcolor('This is a test', stats, color)

# Generated at 2022-06-21 08:13:05.468371
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'green') == '\033[32mtest\033[0m'
    assert stringc('test', 'rgb255255255') == '\033[37mtest\033[0m'
    assert stringc('test', 'rgb000255000') == '\033[32mtest\033[0m'
    assert stringc('test', 'rgb255000255') == '\033[35mtest\033[0m'
    assert stringc('test', 'rgb234011111') == '\033[38;5;166mtest\033[0m'
    assert stringc('test', 'graya') == '\033[30mtest\033[0m'
    assert stringc('test', 'blink') == '\033[5mtest\033[0m'

# Generated at 2022-06-21 08:13:17.389442
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"black", wrap_nonvisible_chars=True) == u"\001\033[38;5;0m\002foo\001\033[0m\002"


# --- end "pretty"
#
# --- begin "JSON"
#
# JSON formatting from ansible/compat/json_ansible.py
#

json_dict_unicode_to_bytes = None


# Generated at 2022-06-21 08:13:23.671139
# Unit test for function hostcolor
def test_hostcolor():
    # use the default hostcolor()
    assert hostcolor("host1", dict(changed=1, failures=2, unreachable=3)) == u"host1                   "
    # use the hostcolor() without coloring
    assert hostcolor("host1", dict(changed=1, failures=2, unreachable=3), color=False) == u"host1                   "
    # use the hostcolor() with coloring
    assert hostcolor("host1", dict(changed=1, failures=2, unreachable=3), color=True) == u"host1                   "

# --- end "pretty"


# Generated at 2022-06-21 08:13:44.082189
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   ', 'colorize failed'
    assert colorize('foo', 2, None) == 'foo=2   ', 'colorize failed'
    assert colorize('foo', 2, 'blue') == '\n'.join(['', '\033[94mfoo=2   ', '\033[0m']), 'colorize failed'
    assert colorize('foo', 0, 'blue') == 'foo=0   ', 'colorize failed'
    assert colorize('foo', 256, 'black') == 'foo=256 ', 'colorize failed'
    assert colorize('foo', 255, 'black') == 'foo=255 ', 'colorize failed'


# --- end of "pretty"
#
# --- begin of "termstyle"
#
# Stolen from a post by Fredrik

# Generated at 2022-06-21 08:13:56.905021
# Unit test for function parsecolor
def test_parsecolor():
    """Test parsing color strings"""
    assert 0 == int(parsecolor('black'))
    assert 1 == int(parsecolor('red'))
    assert 2 == int(parsecolor('green'))
    assert 3 == int(parsecolor('yellow'))
    assert 4 == int(parsecolor('blue'))
    assert 5 == int(parsecolor('magenta'))
    assert 6 == int(parsecolor('cyan'))
    assert 7 == int(parsecolor('lightgray'))
    assert 8 == int(parsecolor('lightgrey'))
    assert 15 == int(parsecolor('white'))
    assert 16 == int(parsecolor('color0'))
    assert 15 == int(parsecolor('color15'))
    assert 231 == int(parsecolor('gray0'))

# Generated at 2022-06-21 08:14:07.606512
# Unit test for function parsecolor
def test_parsecolor():
    #color, result
    test_params = (
        ('white', u'38;5;15'),
        ('color0', u'38;5;0'),
        ('color8', u'38;5;8'),
        ('gray0', u'38;5;232'),
        ('gray9', u'38;5;241'),
        ('rgb010', u'38;5;34'),
        ('rgb234', u'38;5;95'),
        ('rgb543', u'38;5;208'),
        ('rgb255', u'38;5;255'),
    )

    fail_list = []
    for item in test_params:
        result = parsecolor(item[0])
        if result != item[1]:
            fail_list.append(item)

# Generated at 2022-06-21 08:14:16.071390
# Unit test for function parsecolor
def test_parsecolor():
    print("Testing function parsecolor")
    assert parsecolor('blue') == '34'
    assert parsecolor('BLUE') == '34'
    assert parsecolor('blUe') == '34'
    assert parsecolor('bright red') == '91'
    assert parsecolor('color34') == '38;5;34'
    assert parsecolor('rgb323') == '38;5;12'
    assert parsecolor('rgb038') == '38;5;22'
    assert parsecolor('gray10') == '38;5;234'
    assert parsecolor('gray99') == '38;5;255'
    try:
        parsecolor('gray100')
        assert False
    except KeyError:
        assert True
    except:
        assert False



# Generated at 2022-06-21 08:14:26.422620
# Unit test for function parsecolor
def test_parsecolor():
    import random
    import shlex

    # List of all 88 colors supported by parsecolor.
    #
    # The list was generated using the following code:
    #  sgr = ('%s;5;%d' % (mode, color) for mode in {38, 48}
    #                                     for color in range(0, 256))
    #  sgr = ', '.join(sgr)
    #  for i in shlex.split(sgr):
    #      print(i)

# Generated at 2022-06-21 08:14:39.439248
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return
    print("Testing function 'stringc'...")

# Generated at 2022-06-21 08:14:46.320808
# Unit test for function colorize
def test_colorize():
    from io import StringIO
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestColorize(unittest.TestCase):

        @patch.object(ANSIBLE_COLOR, 'getvalue')
        @patch.object(sys, 'stdout', new_callable=StringIO)
        def test_colorize_with_color(self, ansible_color, getvalue):
            ANSIBLE_COLOR = True
            getvalue.return_value = u"32mfakecolor32m"
            sys.stdout.isatty = lambda: True

            # Test color, no wrap
            colored = colorize(u"lead", u"num", u"fakecolor")
            ansible_color.assert_called_with()

# Generated at 2022-06-21 08:14:55.964028
# Unit test for function hostcolor
def test_hostcolor():
    def i(txt): return stringc(txt, C.COLOR_OK)
    assert hostcolor(u"myhost.com", dict(failures=0, unreachable=0, changed=0), True)  == i(u"myhost.com")
    assert hostcolor(u"myhost.com", dict(failures=2, unreachable=5, changed=0), True)  == stringc(u"myhost.com", C.COLOR_ERROR)
    assert hostcolor(u"myhost.com", dict(failures=0, unreachable=0, changed=10), True) == stringc(u"myhost.com", C.COLOR_CHANGED)



# Generated at 2022-06-21 08:15:00.465860
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    print(u"Test for function stringc")
    for color in C.COLOR_CODES:
        print(stringc(u"colored %s" % color, color))



# Generated at 2022-06-21 08:15:08.641296
# Unit test for function stringc
def test_stringc():
    """@todo: Docstring for test_stringc.
    :returns: @todo

    """
    print(u"  testing a bold red underline")
    print(stringc(u"bold red underline", u'RED_BOLD_UNDERLINE'))

    print(u"  testing a bold cyan")
    print(stringc(u"bold cyan", u'CYAN_BOLD'))

    print(u"  testing a bold white on blue bg")
    print(stringc(u"bold white on blue", u'B_WHITE_ON_BLUE'))

    print(u"  testing a red bg")
    print(stringc(u"red bg", u'ON_RED'))

    print(u"  testing a green")

# Generated at 2022-06-21 08:15:23.162317
# Unit test for function colorize
def test_colorize():
    return (colorize("foo", 0, "black") == u"foo=0   " and
            colorize("foo", 0, "red") == u"foo=0   " and
            colorize("foo", 1, "red") == u"foo=1   " and
            colorize("foo", 2, "green") == u"foo=2   ")


# Generated at 2022-06-21 08:15:34.500871
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize('ok', 0, None) == 'ok=0   '
        assert colorize('ok', 123, 'blue') == '\x1b[0;34mok=123 \x1b[0m'
        assert colorize('changed', 0, None) == 'changed=0   '
        assert colorize('changed', 123, 'blue') == '\x1b[0;34mchanged=123 \x1b[0m'
        assert colorize('unreachable', 0, None) == 'unreachable=0 '
        assert colorize('unreachable', 123, 'blue') == '\x1b[0;34munreachable=123\x1b[0m'
        assert colorize('failed', 0, None) == 'failed=0    '
        assert color

# Generated at 2022-06-21 08:15:36.946250
# Unit test for function stringc
def test_stringc():
    assert stringc('test','red') == '\033[31mtest\033[0m'
    assert stringc('test','blue','True') == '\001\033[34m\002test\001\033[0m\002'

# --- end of pretty

# Generated at 2022-06-21 08:15:49.855113
# Unit test for function parsecolor
def test_parsecolor():
    def test(expected, input):
        if expected != parsecolor(input):
            print((u'%r != %r' % (expected, input)))
    test(u'38;5;15', u'red')
    test(u'38;5;34', u'blue')
    test(u'38;5;82', u'green')
    test(u'38;5;14', u'brightred')
    test(u'38;5;39', u'brightblue')
    test(u'38;5;48', u'brightblack')
    test(u'38;5;220', u'brightpurple')
    test(u'38;5;226', u'brightyellow')
    test(u'1', u'bold')
    test(u'4', u'underline')
   

# Generated at 2022-06-21 08:15:57.806907
# Unit test for function hostcolor
def test_hostcolor():
    # Test all possibilities for ansible color
    from ansible.constants import COLORS

    hosts = ['localhost', '127.0.0.1']
    stats_list = [
        {'changed': 1, 'failures': 1, 'ok': 1, 'skipped': 1, 'unreachable': 1},
        {'changed': 1, 'failures': 0, 'ok': 1, 'skipped': 1, 'unreachable': 0},
        {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 1, 'unreachable': 0},
    ]
    ljust_len = 26


# Generated at 2022-06-21 08:16:05.984324
# Unit test for function stringc
def test_stringc():
    from nose.tools import assert_equals

    assert_equals(stringc("Hello World", 'red'), u"\033[31mHello World\033[0m")
    assert_equals(stringc("Hello World", 'blue'), u"\033[34mHello World\033[0m")
    assert_equals(stringc("Hello World", 'gray'), u"\033[38;5;240mHello World\033[0m")
    assert_equals(stringc("Hello World", 'color16'), u"\033[38;5;16mHello World\033[0m")
    assert_equals(stringc("Hello World", 'rgb123'), u"\033[38;5;177mHello World\033[0m")

# Generated at 2022-06-21 08:16:17.026824
# Unit test for function stringc
def test_stringc():
    test_colors = dict(
        black='color0',
        red='color1',
        green='color2',
        yellow='color3',
        blue='color4',
        magenta='color5',
        cyan='color6',
        white='color7',
        default='color9',
    )
    for color in test_colors:
        yield check_colorize, 'Test for color %s' % color, color, test_colors[color]


# Generated at 2022-06-21 08:16:25.396653
# Unit test for function colorize
def test_colorize():
    from ansible.callbacks import display
    display.colors = {
        'GREEN': '32',
        'CYAN': '36',
        'SKIP': '36',
        'UNREACHABLE': '31',
    }
    display.display(colorize('ok', 0, 'GREEN'))
    display.display(colorize('changed', 1, 'CYAN'))
    display.display(colorize('skipped', 2, 'SKIP'))
    display.display(colorize('failed', 3, 'UNREACHABLE'))


# Generated at 2022-06-21 08:16:30.207243
# Unit test for function parsecolor
def test_parsecolor():
    """
    >>> parsecolor('blue')
    '34'
    >>> parsecolor('blink')
    '5'
    >>> parsecolor('color16')
    '38;5;16'
    >>> parsecolor('rgb255100100')
    '38;5;196'
    >>> parsecolor('gray3')
    '38;5;235'
    """



# Generated at 2022-06-21 08:16:40.288418
# Unit test for function hostcolor
def test_hostcolor():
    """ Library unit tests for color
    """
    from ansible.utils.color import hostcolor

    assert hostcolor('plain host', {'failures': 0, 'ok': 0, 'unreachable': 0, 'changed': 0}, ANSIBLE_COLOR) == '%-37s' % stringc('plain host', C.COLOR_OK)
    assert hostcolor('changed host', {'failures': 0, 'ok': 0, 'unreachable': 0, 'changed': 1}, ANSIBLE_COLOR) == '%-37s' % stringc('changed host', C.COLOR_CHANGED)
    assert hostcolor('failed host', {'failures': 1, 'ok': 0, 'unreachable': 0, 'changed': 0}, ANSIBLE_COLOR) == '%-37s' % stringc('failed host', C.COLOR_ERROR)


# Generated at 2022-06-21 08:16:54.382526
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'ok': 1, 'changed': 3, 'dark': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0}
    color = hostcolor('testhost', stats, color=True)
    assert color == stringc('testhost', C.COLOR_CHANGED)
    color = hostcolor('otherhost', stats, color=False)
    assert color == 'otherhost          '

# Generated at 2022-06-21 08:17:04.028843
# Unit test for function parsecolor
def test_parsecolor():
    def test(color, code):
        a = parsecolor(color)
        if a != code:
            print('parsecolor("%s") != "%s" (is "%s")' % (color, code, a))
    test('default', '39')
    test('black', '30')
    test('white', '97')
    test('red', '31')
    test('green', '32')
    test('blue', '34')
    test('cyan', '36')
    test('magenta', '35')
    test('yellow', '33')
    test('bright black', '90')
    test('bright red', '91')
    test('bright green', '92')
    test('bright yellow', '93')
    test('bright blue', '94')
    test('bright magenta', '95')


# Generated at 2022-06-21 08:17:11.839371
# Unit test for function colorize
def test_colorize():
    # Test ANSIBLE_COLOR is disabled
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert u"pre=val" == colorize(u"pre=", u"val", C.COLOR_ERROR)

    # Test ANSIBLE_COLOR is enabled
    ANSIBLE_COLOR = True
    assert u"pre=val" == colorize(u"pre=", u"val", None)
    assert u"pre=val" == colorize(u"pre=", u"val", C.COLOR_ERROR)



# Generated at 2022-06-21 08:17:25.366343
# Unit test for function colorize
def test_colorize():
    """
    prints out colorized results.

    >>> test_colorize()
    ok 31           changes=0    unreachable=0   failed=0
    changed 12      changes=12   unreachable=0   failed=0
    unreachable 5   changes=0    unreachable=5   failed=0
    failed 2        changes=0    unreachable=0   failed=2
    >>>

    """
    from ansible import callbacks
    stats = callbacks.AggregateStats()
    stats.compute(
        ok=31, changed=12, unreachable=5, failed=2, skipped=0
    )

    hostcolor = lambda h: h
    print(u"%-26s %s" % (hostcolor(u'ok'), colorize(u'changes', stats.summarize(u'changes'), C.COLOR_CHANGED)))

# Generated at 2022-06-21 08:17:32.217973
# Unit test for function stringc
def test_stringc():
    """
    >>> print(stringc('hello', 'blue', wrap_nonvisible_chars=False))
    \x1b[34mhello\x1b[0m
    >>> print(stringc('hello', 'blue', wrap_nonvisible_chars=True))
    \x01\x1b[34m\x02hello\x01\x1b[0m\x02
    """
    pass

# end "pretty" block



# Generated at 2022-06-21 08:17:41.902123
# Unit test for function parsecolor
def test_parsecolor():

    def assert_color_eq(colorcode, color):
        assert parsecolor(color) == colorcode

    assert_color_eq('31', 'red')
    assert_color_eq('32', 'green')
    assert_color_eq('33', 'yellow')
    assert_color_eq('34', 'blue')
    assert_color_eq('35', 'magenta')
    assert_color_eq('36', 'cyan')
    assert_color_eq('0', 'black')
    assert_color_eq('1', 'brightred')
    assert_color_eq('2', 'brightgreen')
    assert_color_eq('3', 'brightyellow')
    assert_color_eq('4', 'brightblue')
    assert_color_eq('5', 'brightmagenta')

# Generated at 2022-06-21 08:17:54.777720
# Unit test for function stringc
def test_stringc():
    print("Testing function stringc")
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "light gray") == u"\033[37mtest\033[0m"

# Generated at 2022-06-21 08:18:02.693755
# Unit test for function stringc
def test_stringc():
    """A simple unit test for function stringc()."""
    from ansible.utils.color import stringc

    if ANSIBLE_COLOR:
        print(stringc("Normal text.", "normal"))
        print(stringc("Success!", "green"))
        print(stringc("Warning!", "yellow"))
        print(stringc("Error!", "red"))
        print(stringc("White-on-blue text.", "blue,bold"))
        print(stringc("Bright magenta text on gray.", "magenta,bold", "on_grey"))
        print(stringc("Red text on yellow.", "white", "on_yellow"))
        print(stringc("Underlined text.", underline=True))
        print(stringc("Blinks, twice.", blink=2))
        print(stringc("Reversed video", reverse=True))



# Generated at 2022-06-21 08:18:15.240509
# Unit test for function hostcolor
def test_hostcolor():
    def check(expected_output, expected_color, host, stats):
        color = True
        result = hostcolor(host, stats, color)
        assert result == expected_output, "%r != %r" % (result, expected_output)
        color = False
        result = hostcolor(host, stats, color)
        assert result == expected_output, "%r != %r" % (result, expected_output)
        if expected_color:
            color = True
            if not ANSIBLE_COLOR or not sys.stdout.isatty():
                color = False
            result = hostcolor(host, stats, color)
            res_tpl = result.replace(host, 'HOST')
            exp_tpl = expected_output.replace(host, 'HOST')

# Generated at 2022-06-21 08:18:24.150660
# Unit test for function colorize
def test_colorize():
    # Setup
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play_context.remote_addr = '127.0.0.1'
    play_context.prompt = dict(
        success=dict(
            text='success prompt',
        ),
    )
    colorize('SUCCESS', 1, 'green', play_context=play_context)
    colorize('SUCCESS', 0, 'green', play_context=play_context)
    colorize('FAILURE', 1, 'red', play_context=play_context)
    colorize('FAILURE', 0, 'red', play_context=play_context)



# Generated at 2022-06-21 08:18:38.057754
# Unit test for function colorize
def test_colorize():
    tests = [
        ('R', 0, 'dark gray', u'R=0  '),
        ('G', 50, 'green', u'\033[32mG=50 \033[0m'),
        ('B', 100, 'blue', u'\033[34mB=100\033[0m'),
        ('Y', 0, None, u'Y=0  '),
    ]

    for args, expected in tests:
        assert colorize(*args) == expected

# --- end "pretty"



# Generated at 2022-06-21 08:18:41.981321
# Unit test for function stringc
def test_stringc():
    print(stringc("%s %s" % (u'foo', u'bar'),
                  u'blue', wrap_nonvisible_chars=True))

# --- end pretty

if __name__ == '__main__':
    test_stringc()