

# Generated at 2022-06-21 08:11:56.357722
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'green') == 'foo=0   '
    assert colorize('foo', 0, 'red') == 'foo=0   '
    assert colorize('foo', 1, 'green') == stringc('foo=1   ', 'green')
    assert colorize('foo', 2, 'red') == stringc('foo=2   ', 'red')
    assert colorize('foo', 3, 'yellow') == stringc('foo=3   ', 'yellow')
    assert colorize('foo', 4, 'blue') == stringc('foo=4   ', 'blue')

    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '


if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-21 08:12:02.159604
# Unit test for function hostcolor
def test_hostcolor():
    # single line output
    host = 'www.example.com'
    stats = dict(ok=1)
    assert hostcolor(host, stats, color=True) == u"%-37s" % hostcolor(host, stats, color=False)
    stats = dict(changed=1)
    assert hostcolor(host, stats, color=True) == u"%-37s" % hostcolor(host, stats, color=False)
    stats = dict(unreachable=1)
    assert hostcolor(host, stats, color=True) == u"%-37s" % hostcolor(host, stats, color=False)
    stats = dict(failures=1)
    assert hostcolor(host, stats, color=True) == u"%-37s" % hostcolor(host, stats, color=False)
    # multiline output


# Generated at 2022-06-21 08:12:13.593370
# Unit test for function colorize
def test_colorize():
    # Lead string is 'failures', num is 0, color is error, no color set
    assert colorize(u'failures', 0, C.COLOR_ERROR) == u'failures=0   '

    # Lead string is 'ok', num is 10, color is ok, no color set
    assert colorize(u'ok', 10, C.COLOR_OK) == u'ok=10         '

    # Lead string is 'changed', num is 0, color is changed, color set
    ANSIBLE_COLOR = True
    assert colorize(u'changed', 0, C.COLOR_CHANGED) == u'changed=0   '

    # Lead string is 'unreachable', num is 20, color is error, color set

# Generated at 2022-06-21 08:12:20.339419
# Unit test for function colorize
def test_colorize():
    print(u"\nTESTING CONTRAST COLOR FUNCTIONS")
    print(colorize(u"PINK", 1, u"pink"))
    print(colorize(u"BLUE", 1, u"blue"))
    print(colorize(u"RED", 1, u"red"))
    print(colorize(u"GREEN", 1, u"green"))
    print(colorize(u"YELLOW", 1, u"yellow"))
    print(colorize(u"CYAN", 1, u"cyan"))
    print(colorize(u"WHITE", 1, u"white"))
    print(colorize(u"RESET", 1, u"reset"))



# Generated at 2022-06-21 08:12:27.894049
# Unit test for function hostcolor
def test_hostcolor():
    res = hostcolor(u"foo", dict(failures=0, unreachable=0, changed=1))
    assert res == u"%-37s" % u"\n".join([u"\033[0;32mfoo\033[0m"])
    res = hostcolor(u"foo", dict(failures=1, unreachable=1, changed=0))
    assert res == u"%-37s" % u"\n".join([u"\033[0;31mfoo\033[0m"])



# Generated at 2022-06-21 08:12:38.176683
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '38;5;4'
    assert parsecolor('bright red') == '38;5;9'
    assert parsecolor('color101') == '38;5;101'
    assert parsecolor('rgb123') == '38;5;123'
    assert parsecolor('rgb112') == '38;5;111'
    assert parsecolor('rgb211') == '38;5;99'
    assert parsecolor('rgb021') == '38;5;20'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('gray8') == '38;5;239'

# Generated at 2022-06-21 08:12:41.231262
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize("foo", 42, "blue") # doctest: +ELLIPSIS
    'foo=42'
    """
    pass


# --- end "pretty"


# Generated at 2022-06-21 08:12:50.909104
# Unit test for function parsecolor

# Generated at 2022-06-21 08:13:03.390338
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('faux.localhost', dict()) == u"faux.localhost                 "
    assert hostcolor('faux.localhost', dict(warnings=0), color=False) == u"faux.localhost              "
    assert hostcolor('faux.localhost', dict(failures=0, unreachable=0), color=False) == u"faux.localhost              "
    assert hostcolor('faux.localhost', dict(failures=0, unreachable=0), color=True) == u"faux.localhost                 "
    assert hostcolor('faux.localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u"faux.localhost              "

# Generated at 2022-06-21 08:13:08.156579
# Unit test for function stringc
def test_stringc():
    # Set 'False' for unittest to work
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    stringc('\n'.join(["ok", "ok", "not ok"] * 10), 'red', wrap_nonvisible_chars=False)

# Generated at 2022-06-21 08:13:22.205852
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return
    import six
    import os
    import sys

    orig_stdout = sys.stdout

    def restore_stdout(saved):
        if six.PY3:
            sys.stdout = saved.buffer
        else:
            sys.stdout = saved

    sys.stdout = open(os.devnull, "w")

    color_tests = (
        dict(failures=0, unreachable=0, changed=0),
        dict(failures=1, unreachable=0, changed=0),
        dict(failures=0, unreachable=1, changed=0),
        dict(failures=0, unreachable=0, changed=1),
    )

    for stats in color_tests:
        hostcolor('test', stats)

    restore_std

# Generated at 2022-06-21 08:13:27.828912
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor_test = hostcolor('host1',{'failures': 0, 'unreachable': 0, 'changed': 0})
    print(hostcolor_test)
    if hostcolor_test != 'host1':
        print('Test failed.')

# --- end "pretty"



# Generated at 2022-06-21 08:13:39.750924
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('black') == u'30'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('lightgray') == u'37'
    assert parsecolor('darkgray') == u'30'
    assert parsecolor('lightred') == u'31'
    assert parsecolor('lightgreen') == u'32'
    assert parsecolor('lightyellow') == u'33'
    assert parsecolor('lightblue') == u'34'

# Generated at 2022-06-21 08:13:51.345512
# Unit test for function hostcolor
def test_hostcolor():
    h = 'foobar'
    s = dict(ok=1, changed=0, unreachable=0, failures=0)
    assert hostcolor(h, s) == stringc(h, C.COLOR_OK)
    s = dict(ok=0, changed=1, unreachable=0, failures=0)
    assert hostcolor(h, s) == stringc(h, C.COLOR_CHANGED)
    s = dict(ok=0, changed=0, unreachable=1, failures=0)
    assert hostcolor(h, s) == stringc(h, C.COLOR_ERROR)
    s = dict(ok=0, changed=0, unreachable=0, failures=1)
    assert hostcolor(h, s) == stringc(h, C.COLOR_ERROR)

# Generated at 2022-06-21 08:13:57.061761
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures':0,
             'unreachable':0,
             'changed':0}
    print("%-37s" % stringc("test", C.COLOR_OK))
    assert u"%-37s" % stringc("test", C.COLOR_OK) == hostcolor("test", stats)

# --- end "pretty"



# Generated at 2022-06-21 08:14:07.761472
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestAnsibleColor(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-21 08:14:11.441160
# Unit test for function parsecolor
def test_parsecolor():
    parsecolor('red') == C.COLOR_CODES['red']
    parsecolor('color1') == u'38;5;1'
    parsecolor('rgb100') == u'38;5;46'
    parsecolor('gray1') == u'38;5;233'
    parsecolor('missing_color') == C.COLOR_CODES[C.COLOR_ERROR]


# Generated at 2022-06-21 08:14:18.183134
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return

    from ansible.utils.color import stringc
    from ansible.constants import COLORS
    for (color,code) in COLORS.items():
        print("%s: %s" % (color, stringc("foo", color)))
        # Colors that have aliases also have a 2-digit code
        if '2' in code:
            print("%s2: %s" % (color, stringc("foo", code)))

    print("colorize: %s" % (colorize("foo", 10, 'green')))
    print("colorize: %s" % (colorize("bar", 0, 'yellow')))
    print("colorize: %s" % (colorize("baz", -10, 'red')))

# vim: set expandtab ts=4 sw=

# Generated at 2022-06-21 08:14:27.667763
# Unit test for function colorize
def test_colorize():
    """
    colorize:
    """
    # These color names are currently supported.
    color_names = (
        'black', 'red', 'green', 'yellow',
        'blue', 'magenta', 'cyan', 'white'
    )
    # For each of the color names above, make sure that
    # colorizing the lead text results in the correct terminal
    # escape sequence being present in the output string.
    for color_name in color_names:
        lead_text = 'text'
        color_num = 1234
        result = colorize(lead_text, color_num, color_name)
        assert u'\x1b[%sm%s' % (parsecolor(color_name), lead_text) in result

# --- end "pretty"
# stuff imported from old utils, but with ANSIBLE

# Generated at 2022-06-21 08:14:39.750557
# Unit test for function stringc
def test_stringc():
    """simple test to verify correct termcodes are generated"""
    if not ANSIBLE_COLOR:
        return
    assert stringc('foo', 'white') == '\033[37mfoo\033[0m'
    assert stringc('foo', 'black') == '\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'

# Generated at 2022-06-21 08:14:55.366558
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foohost', dict(
        ok=0,
        changed=0,
        unreachable=0,
        failed=0)) \
        == u'foohost                        '
    assert hostcolor('foohost', dict(
        ok=0,
        changed=1,
        unreachable=0,
        failed=0)) \
        == stringc(u'foohost                        ', C.COLOR_CHANGED)
    assert hostcolor('foohost', dict(
        ok=0,
        changed=0,
        unreachable=0,
        failed=1)) \
        == stringc(u'foohost                        ', C.COLOR_ERROR)

# Generated at 2022-06-21 08:15:05.862617
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}

    if not ANSIBLE_COLOR:
        assert hostcolor("foo", stats) == u"%-26s" % "foo"
        return 0

    # Tests for true color
    assert hostcolor("foo", stats) == u"%-37s" % stringc("foo", C.COLOR_OK)

    stats['failures'] = 1
    assert hostcolor("foo", stats) == u"%-37s" % stringc("foo", C.COLOR_ERROR)

    stats['failures'] = 0
    stats['changed'] = 1
    assert hostcolor("foo", stats) == u"%-37s" % stringc("foo", C.COLOR_CHANGED)

    # Tests for no color

# Generated at 2022-06-21 08:15:18.475936
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'34'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('rgb255') == u'38;5;231'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('rgb333') == u'38;5;7'
    assert parsecolor('rgb210') == u'38;5;11'
    assert parsecolor('rgb100') == u'38;5;16'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray8') == u'38;5;240'

# Generated at 2022-06-21 08:15:28.275356
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 4, 'green') == stringc(u'foo=4', 'green')
    assert colorize("foo", 0, 'green') == "foo=0  "
    assert colorize("foo", 4, None) == u"foo=4  "
    assert colorize("foo", 0, None) == "foo=0  "
    try:
        ANSIBLE_COLOR = False
        assert colorize("foo", 4, 'green') == "foo=4  "
        assert colorize("foo", 0, 'green') == "foo=0  "
        assert colorize("foo", 4, None) == "foo=4  "
        assert colorize("foo", 0, None) == "foo=0  "
    except:
        raise
    finally:
        ANSIBLE_COLOR = True
    # Test

# Generated at 2022-06-21 08:15:38.145825
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black',) == '30'
    assert parsecolor('red',) == '31'
    assert parsecolor('green',) == '32'
    assert parsecolor('yellow',) == '33'
    assert parsecolor('blue',) == '34'
    assert parsecolor('magenta',) == '35'

# Generated at 2022-06-21 08:15:50.298547
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('RED') == u'38;5;9'
    assert parsecolor('rgb255000') == u'38;5;196'
    assert parsecolor('rgb000255') == u'38;5;21'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb010203') == u'38;5;60'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray8') == u'38;5;240'
    assert parsecolor('gray15') == u'38;5;254'
    assert parsecolor('blue') == u'38;5;4'
    assert par

# Generated at 2022-06-21 08:15:58.105548
# Unit test for function stringc
def test_stringc():
    """Test for function stringc."""
    text = u"Testing all the colors"
    foreground = [u"black", u"red", u"green", u"yellow", u"blue", u"magenta",
                  u"cyan", u"white"]
    background = [u"on_black", u"on_red", u"on_green", u"on_yellow",
                  u"on_blue", u"on_magenta", u"on_cyan", u"on_white"]
    attri = ["bold", "dark", "", "underline", "blink", "", "reverse",
             "concealed"]
    for f in foreground:
        n = foreground.index(f)
        print(stringc(text, f))
        print(stringc(text, attri[n]))

# Generated at 2022-06-21 08:16:06.137062
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 0
    display.columns = 80

    stats = dict(failures=1, unreachable=0, changed=0)
    display.display(hostcolor('foo', stats), color=False)
    display.display(hostcolor('foo', stats), color=True)

    stats = dict(failures=0, unreachable=1, changed=0)
    display.display(hostcolor('foo', stats), color=False)
    display.display(hostcolor('foo', stats), color=True)

    stats = dict(failures=0, unreachable=0, changed=1)
    display.display(hostcolor('foo', stats), color=False)
    display.display(hostcolor('foo', stats), color=True)

    stats = dict

# Generated at 2022-06-21 08:16:17.147148
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("GREEN") == u'32'
    assert parsecolor("yellow") == u'33'
    assert parsecolor("blue") == u'34'
    assert parsecolor("magenta") == u'35'
    assert parsecolor("cyan") == u'36'
    assert parsecolor("green") == u'32'
    assert parsecolor("white") == "37"
    assert parsecolor("default") == "39"
    assert parsecolor("black") == "30"
    assert parsecolor("color1") == u"38;5;1"
    assert parsecolor("color255") == u"38;5;255"
    assert parsecolor("rgb255255255") == u"38;5;231"


# Generated at 2022-06-21 08:16:20.398059
# Unit test for function stringc
def test_stringc():
    from ansible import constants
    from ansible.utils.color import parsecolor
    colors = constants.COLOR_OK
    for color in colors.split():
        stringc(u"This is a test", color)



# Generated at 2022-06-21 08:16:30.634902
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('ok', '1', 'green')
    u'ok=1   '
    >>> colorize('changed', '2', 'yellow')
    u'changed=2 '
    >>> colorize('unreachable', '30', 'red')
    u'unreachable=30'
    >>> colorize('skipped', '100', 'blue')
    u'skipped=100 '
    """
# --- end "pretty"

# Generated at 2022-06-21 08:16:40.599292
# Unit test for function hostcolor
def test_hostcolor():
    """ Make sure that hostcolor works correctly"""

    # We need to call init_hostcolor since the hostcolor function depends
    # on the color settings from init_hostcolor
    init_hostcolor(C.ANSIBLE_FORCE_COLOR, C.ANSIBLE_NOCOLOR)

    color_string = u"%-37s"

    # Test that hostcolor returns the same format independent of whether
    # or not we use color
    assert hostcolor(u"asdf.example.org", {}, color=True) == color_string
    assert hostcolor(u"asdf.example.org", {}, color=False) == color_string

    # Test that hostcolor returns the expected result when using color

# Generated at 2022-06-21 08:16:48.841689
# Unit test for function stringc
def test_stringc():
    if parsecolor('red') != "31":
        raise Exception('red is not red')
    if parsecolor('rgb255') != "38;5;196":
        raise Exception('rgb255 is not rgb255')
    if parsecolor('nocolor') != None:
        raise Exception('nocolor is not nocolor')
    print(stringc('hello world', 'red'))
    print(stringc('hello world', 'rgb255'))
    print(stringc('hello world', 'nocolor'))

if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-21 08:16:55.379326
# Unit test for function parsecolor
def test_parsecolor():
    def assert_parsed(expected, color):
        assert expected == parsecolor(color)

    assert_parsed('1', 'bold')
    assert_parsed('31', 'red')
    assert_parsed('38;5;1', 'color1')
    assert_parsed('38;5;123', 'rgb123')
    assert_parsed('38;5;233', 'gray0')
    assert_parsed('38;5;232', 'gray1')

# Generated at 2022-06-21 08:17:04.776516
# Unit test for function hostcolor
def test_hostcolor():
    """hostcolor() should return these exact strings given these inputs"""
    from ansible.utils.display import Display

    display = Display()
    display.verbosity = 3

    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost             \x1b[0m"
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[35mlocalhost             \x1b[0m"
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"\x1b[32mlocalhost             \x1b[0m"

# Generated at 2022-06-21 08:17:14.750918
# Unit test for function stringc
def test_stringc():
    """Tests for stringc function"""
    import unittest

    class StringCTestCase(unittest.TestCase):
        """Unit tests for stringc function"""
        def test_stringc_color(self):
            """Correct color for strings"""
            self.assertEqual(stringc('test', 'blue'),
                             u'\x1b[34mtest\x1b[0m')

        def test_stringc_noncolor(self):
            """Non-color is not changed"""
            global ANSIBLE_COLOR
            ANSIBLE_COLOR = False

            self.assertEqual(stringc('test', 'blue'), 'test')

            ANSIBLE_COLOR = True

        def test_stringc_rgb_color(self):
            """Correct color for strings (rgb)"""
            self.assertEqual

# Generated at 2022-06-21 08:17:26.191553
# Unit test for function hostcolor
def test_hostcolor():
    from nose.tools import assert_equals
    stats = dict(ok=1)
    color = ANSIBLE_COLOR
    assert_equals(u'%-26s' % 'ansible.test', hostcolor('ansible.test', stats, color))

    stats = dict(ok=0, changed=1)
    assert_equals(stringc('%-26s' % 'ansible.test', C.COLOR_CHANGED),
                  hostcolor('ansible.test', stats, color))

    stats = dict(ok=0, failures=1)
    assert_equals(stringc('%-26s' % 'ansible.test', C.COLOR_ERROR),
                  hostcolor('ansible.test', stats, color))

#
# --- end of "pretty" code

# Generated at 2022-06-21 08:17:37.719377
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor('localhost', {'unreachable': 0, 'failures': 0, 'skipped': 0, 'ok': 1, 'changed': 0}, True)
    hostcolor('localhost', {'unreachable': 0, 'failures': 0, 'skipped': 0, 'ok': 1, 'changed': 1}, True)
    hostcolor('localhost', {'unreachable': 0, 'failures': 1, 'skipped': 0, 'ok': 0, 'changed': 0}, True)
    hostcolor('localhost', {'unreachable': 1, 'failures': 0, 'skipped': 0, 'ok': 0, 'changed': 0}, True)
    hostcolor('localhost', {'unreachable': 0, 'failures': 0, 'skipped': 0, 'ok': 1, 'changed': 0}, False)

# Unit test

# Generated at 2022-06-21 08:17:48.944868
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"localhost", {u"failures": 1, u"changed": 0, u"ok": 1, u"skipped": 0, u"unreachable": 0}) == u"localhost                 \x1b[31m\x1b[1m\n"
    assert hostcolor(u"localhost", {u"failures": 0, u"changed": 1, u"ok": 1, u"skipped": 0, u"unreachable": 0}) == u"localhost                 \x1b[33m\x1b[1m\n"

# Generated at 2022-06-21 08:17:57.869304
# Unit test for function stringc
def test_stringc():
    from ansible.utils.color import stringc

    assert stringc("this is the inner string", "blue") == u'\n'.join([
        u'\u001b[34m',
        u'this is the inner string',
        u'\u001b[0m'])

    assert stringc("this is the inner string", "rgb255") == u'\n'.join([
        u'\u001b[38;5;231m',
        u'this is the inner string',
        u'\u001b[0m'])

# Generated at 2022-06-21 08:18:13.913355
# Unit test for function colorize
def test_colorize():
    from ansible.color import colorize
    from ansible.color import stringc
    assert colorize('ok', 0, 'green') == stringc('ok=0', 'green')
    assert colorize('changed', 0, 'yellow') == stringc('changed=0', 'yellow')
    assert colorize('dark', 0, 'cyan') == stringc('dark=0', 'cyan')
    assert colorize('failed', 0, 'red') == stringc('failed=0', 'red')


# --- end "pretty"

# --- begin "console"

if not C.DEFAULT_TRANSPORT == 'smart':
    ANSIBLE_COLOR = False

# output constants
HOST_PADDING = 34

# colors
BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN,

# Generated at 2022-06-21 08:18:24.432687
# Unit test for function stringc
def test_stringc():
    def t(func, expected):
        actual = func(u"foo", u"red")
        expected_utf8 = expected.encode('utf-8')
        actual_utf8 = actual.encode('utf-8')
        assert actual_utf8 == expected_utf8, "%r != %r" % (actual_utf8, expected_utf8)
    # fmt: off
    t(stringc, u"\033[31mfoo\033[0m")
    t(lambda *args: stringc(*args, wrap_nonvisible_chars=True),
      u"\001\033[31m\002foo\001\033[0m\002")
    # fmt: on
    print(u"stringc: ok")
    sys.exit(0)


# --- end "pretty"

# --- begin "as

# Generated at 2022-06-21 08:18:32.491138
# Unit test for function stringc
def test_stringc():
    from ansible.utils.color import stringc
    from ansible import constants as C

    assert stringc("This is blue", "blue") == "\033[0;34mThis is blue\033[0m"
    assert stringc("This is red", "red") == "\033[0;31mThis is red\033[0m"
    assert stringc("This is bold", "bold") == "\033[1mThis is bold\033[0m"
    assert stringc("This is UNDERLINE", "UNDERLINE") == "\033[4mThis is UNDERLINE\033[0m"
    assert stringc("This is italic", "italic") == "\033[3mThis is italic\033[0m"

# Generated at 2022-06-21 08:18:39.066463
# Unit test for function stringc
def test_stringc():
    """This is a test"""
    assert stringc(u"This is a test", u"red") == u"\033[31mThis is a test\033[0m"
    assert stringc(u"This is a test", u"green") == u"\033[32mThis is a test\033[0m"
    assert stringc(u"This is a test", u"color250") == u"\033[38;5;250mThis is a test\033[0m"
    assert stringc(u"This is a test", u"rgb255255255") == u"\033[38;5;255mThis is a test\033[0m"

