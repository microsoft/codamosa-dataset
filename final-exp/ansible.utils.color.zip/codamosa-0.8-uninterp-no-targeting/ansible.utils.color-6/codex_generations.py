

# Generated at 2022-06-21 08:11:58.388619
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("white") == "97"
    assert parsecolor("white") == parsecolor("color7")
    assert parsecolor("color0") == "30"
    assert parsecolor("color1") == "31"
    assert parsecolor("color2") == "32"
    assert parsecolor("color3") == "33"
    assert parsecolor("color4") == "34"
    assert parsecolor("color5") == "35"
    assert parsecolor("color6") == "36"
    assert parsecolor("color7") == "37"
    assert parsecolor("rgb255255255") == "97"
    assert parsecolor("rgb111111111") == "15"
    assert parsecolor("rgb0000000") == "16"

# Generated at 2022-06-21 08:12:03.099180
# Unit test for function parsecolor
def test_parsecolor():
    assert stringc("test", "red") == "\n".join(["\033[31mtest\033[0m"])
    assert stringc("test", "rgb255") == "\n".join(["\033[38;5;15mtest\033[0m"])
    assert stringc("test", "rgb255255255") == "\n".join(["\033[38;5;15mtest\033[0m"])
    assert stringc("test", "gray1") == "\n".join(["\033[38;5;235mtest\033[0m"])
    assert stringc("test", "gray1", True) == "\n".join(["\001\033[38;5;235m\002test\001\033[0m\002"])

# Generated at 2022-06-21 08:12:08.124856
# Unit test for function colorize
def test_colorize():
    for t in ['', 'foo', '-1234']:
        yield colorize, 'pre', t, 'green'
    for t in ['ok', 'changed']:
        for num in ['0', '1', '2']:
            yield colorize, 'pre', num, t


# Generated at 2022-06-21 08:12:18.053926
# Unit test for function hostcolor

# Generated at 2022-06-21 08:12:23.164145
# Unit test for function hostcolor
def test_hostcolor():
    # Empty stats
    stats = {}
    host = 'test'
    assert hostcolor(host, stats) == u"%-26s" % host

    # Non empty stats
    stats = {'failures' : 1}
    assert hostcolor(host, stats) == u"%-26s" % stringc(host, C.COLOR_ERROR)
    stats = {'unreachable' : 1}
    assert hostcolor(host, stats) == u"%-26s" % stringc(host, C.COLOR_ERROR)
    stats = {'changed' : 1}
    assert hostcolor(host, stats) == u"%-26s" % stringc(host, C.COLOR_CHANGED)
    stats = {'ok' : 1}

# Generated at 2022-06-21 08:12:34.389470
# Unit test for function stringc
def test_stringc():
    ## \033 = \x1b = \E = ESC (the escape character)
    assert stringc("text", 'red', wrap_nonvisible_chars=False) == u'\033[31mtext\033[0m'
    assert stringc("text", 'green', wrap_nonvisible_chars=False) == u'\033[32mtext\033[0m'

    assert stringc("text", 'red', wrap_nonvisible_chars=True) == u'\x01\x1b[31m\x02text\x01\x1b[0m\x02'
    assert stringc("text", 'green', wrap_nonvisible_chars=True) == u'\x01\x1b[32m\x02text\x01\x1b[0m\x02'

    # Test

# Generated at 2022-06-21 08:12:42.154884
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;0' == parsecolor('black')
    assert u'38;5;1' == parsecolor('red')
    assert u'38;5;2' == parsecolor('green')
    assert u'38;5;3' == parsecolor('yellow')
    assert u'38;5;4' == parsecolor('blue')
    assert u'38;5;5' == parsecolor('magenta')
    assert u'38;5;6' == parsecolor('cyan')
    assert u'38;5;7' == parsecolor('white')
    assert u'38;5;8' == parsecolor('color8')
    assert u'38;5;9' == parsecolor('color9')

# Generated at 2022-06-21 08:12:51.623534
# Unit test for function colorize
def test_colorize():
    # FIXME: pretty.colorize() returns a unicode object
    #        we should be able to just call assertEqual()
    #        and fix colorize() to return bytes instead
    if sys.version_info < (2, 7):
        assert colorize('a', u'b', 'c') == u'a=b'
    else:
        assert colorize('a', u'b', 'c') == 'a=b'
    assert colorize(u'a', 'b', 'c') == 'a=b'
    assert colorize(u'a', u'b', 'c') == 'a=b'
    assert colorize('a', 'b', u'c') == 'a=b'
    assert colorize(u'a', 'b', u'c') == 'a=b'

# Generated at 2022-06-21 08:12:52.402322
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"



# Generated at 2022-06-21 08:13:03.021968
# Unit test for function colorize
def test_colorize():
    # bnez's pretty.py has this as a test, but it doesn't really test anything
    # so I've replaced it with something that makes sense
    assert colorize(u"foo", u"0", 'black') == u"foo=0   "
    assert colorize(u"foo", u"10", 'black') == u"foo=10  "
    assert colorize(u"foo", u"100", 'black') == u"foo=100 "
    assert colorize(u"foo", u"1000", 'black') == u"foo=1000"

# ---- end of "pretty"

# -- begin terminal safe string functions


# Generated at 2022-06-21 08:13:20.311209
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        # Some terminals do not support all 16 colors
        curses.setupterm()
        max_colors = curses.tigetnum('colors')
        # more than 8 colors
        if max_colors > 7:
            assert stringc('foo', 'black') == '\x1b[30mfoo\x1b[0m'
            assert stringc('foo', 'red') == '\x1b[31mfoo\x1b[0m'
            assert stringc('foo', 'green') == '\x1b[32mfoo\x1b[0m'
            assert stringc('foo', 'yellow') == '\x1b[33mfoo\x1b[0m'

# Generated at 2022-06-21 08:13:32.472755
# Unit test for function stringc
def test_stringc():
    """Simple unit test."""
    if ANSIBLE_COLOR:
        assert stringc(u"foo", u"red") == u"\033[91mfoo\033[0m"
        assert stringc(u"foo", u"blue") == u"\033[94mfoo\033[0m"
        assert stringc(u"foo", u"green") == u"\033[92mfoo\033[0m"
        assert stringc(u"foo", u"yellow") == u"\033[93mfoo\033[0m"
        assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"
        assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"

# Generated at 2022-06-21 08:13:43.969324
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    assert hostcolor("localhost", dict(changed=0, failures=0, unreachable=0, ok=1), color=True) == u"localhost                    "
    assert hostcolor("localhost", dict(changed=0, failures=1, unreachable=0, ok=0), color=True) == u"localhost                    "
    assert hostcolor("localhost", dict(changed=1, failures=0, unreachable=0, ok=0), color=True) == u"localhost                    "
    assert hostcolor("localhost", dict(changed=0, failures=0, unreachable=1, ok=0), color=True) == u"localhost                    "
    assert hostcolor("localhost", dict(changed=0, failures=0, unreachable=0, ok=1), color=False) == u"localhost                    "

# Generated at 2022-06-21 08:13:56.690644
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.playbook import PlayBook
    play = PlayBook()

    hosts = ['localhost']
    # test with no colors
    stats = play.callbacks.set_stats(hosts)
    stats.compute(play)
    assert hostcolor('localhost', stats, False) == u"%-37s" % u'localhost'
    assert hostcolor('localhost', stats) == u"%-37s" % u'localhost'

    # test with colors
    stats = play.callbacks.set_stats(hosts)
    stats.compute(play)
    assert hostcolor('localhost', stats, False) == u"%-37s" % u'localhost'
    assert hostcolor('localhost', stats) == u"%-37s" % u'localhost'


# Generated at 2022-06-21 08:14:03.143367
# Unit test for function colorize
def test_colorize():
    color = True
    for num in [0, 1, 2]:
        print(colorize("ok", num, C.COLOR_OK))
        print(colorize("changed", num, C.COLOR_CHANGED))
        print(colorize("unreachable", num, C.COLOR_UNREACHABLE))
        print(colorize("failures", num, C.COLOR_ERROR))

# --- end of pretty.py
#
#
# --- begin "configuration"
#



# Generated at 2022-06-21 08:14:13.204062
# Unit test for function parsecolor
def test_parsecolor():
    print(parsecolor('red'))
    print(parsecolor('blue'))
    print(parsecolor('yellow'))
    print(parsecolor('white'))
    print(parsecolor('black'))
    print(parsecolor('green'))
    print(parsecolor('color1'))
    print(parsecolor('color2'))
    print(parsecolor('color3'))
    print(parsecolor('rgb255'))
    print(parsecolor('rgb255'))
    print(parsecolor('rgb255'))
    print(parsecolor('rgb123'))
    print(parsecolor('rgb321'))
    print(parsecolor('rgb231'))
    print(parsecolor('rgb111'))

# Generated at 2022-06-21 08:14:23.762592
# Unit test for function colorize
def test_colorize():
    s = colorize("foo", 0, "blue")
    assert s == "foo=0   ", "colorize failed: expected %s, got %s" % ("foo=0   ", s)
    s = colorize("foo", 1, "blue")
    assert s == "foo=1   ", "colorize failed: expected %s, got %s" % ("foo=1   ", s)
    s = colorize("foo", 12, "blue")
    assert s == "foo=12  ", "colorize failed: expected %s, got %s" % ("foo=12  ", s)
    s = colorize("foo", 123, "blue")
    assert s == "foo=123 ", "colorize failed: expected %s, got %s" % ("foo=123 ", s)

# Generated at 2022-06-21 08:14:29.876969
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, None) == "foo=0   "
    assert colorize("foo", 0, "black") == "foo=0   "
    assert colorize("foo", 1, "green") == "foo=1   "
    assert colorize("foo", 1, None) == "foo=1   "

# Generated at 2022-06-21 08:14:40.483788
# Unit test for function stringc
def test_stringc():
    test_table = {
        ("foo", "red"):
        "\x1b[31mfoo\x1b[0m",
        ("bar", "blue"):
        "\x1b[34mbar\x1b[0m",
        ("foobar", "yellow"):
        "\x1b[33mfoobar\x1b[0m",
    }
    for (entry, test) in test_table.items():
        ansible_color_setting = ANSIBLE_COLOR
        ANSIBLE_COLOR = True
        assert test == stringc(entry[0], entry[1]), "Stringc test failed."
        ANSIBLE_COLOR = False
        assert entry[0] == stringc(entry[0], entry[1]), "Stringc test failed."
        ANSIBLE_COLOR = ansible_color_

# Generated at 2022-06-21 08:14:52.335323
# Unit test for function stringc
def test_stringc():
    """Test the stringc() function."""
    print(u"Testing the stringc() function.")
    for name in sorted(C.COLOR_CODES.keys()):
        print(u"%s: %s" % (name, stringc(name, name)))
    for i in range(8):
        print(u"color%d: %s" % (i, stringc(u"color%d" % i, u"color%d" % i)))
    for i in range(0, 6):
        for j in range(0, 6):
            for k in range(0, 6):
                rgb = u"rgb%d%d%d" % (i, j, k)
                print(u"%s: %s" % (rgb, stringc(rgb, rgb)))

# Generated at 2022-06-21 08:15:14.545470
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('127.0.0.1', dict(
        ok=0, changed=0, unreachable=0, failures=0)) == '127.0.0.1               '  # noqa
    assert hostcolor('127.0.0.1', dict(
        ok=0, changed=1, unreachable=0, failures=0)) == '\x1b[0;32m127.0.0.1         \x1b[0m'  # noqa
    assert hostcolor('127.0.0.1', dict(
        ok=0, changed=0, unreachable=1, failures=0)) == '\x1b[0;31m127.0.0.1         \x1b[0m'  # noqa

# Generated at 2022-06-21 08:15:25.541597
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'blue') != None
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'red') != None
    assert parsecolor(u'red') == u'31'
    assert parsecolor(u'cyan') != None
    assert parsecolor(u'cyan') == u'36'
    assert parsecolor(u'green') != None
    assert parsecolor(u'green') == u'32'
    assert parsecolor(u'yellow') != None
    assert parsecolor(u'yellow') == u'33'
    assert parsecolor(u'white') != None
    assert parsecolor(u'white') == u'37'
    assert parsecolor(u'black') != None
    assert parsecolor(u'black')

# Generated at 2022-06-21 08:15:36.596442
# Unit test for function stringc
def test_stringc():
    """Verify that stringc() has the expected behavior"""
    # pylint: disable=too-many-branches
    import unittest

    colors_dict = dict(red=31, green=32, yellow=33, blue=34,
                       magenta=35, cyan=36, white=37, black=30,
                       none=0)

    class stringc_test_case(unittest.TestCase):

        def test_color_name(self):
            """stringc with name of color"""
            self.assertEqual("\033[%dm%s\033[0m" % (colors_dict['red'], "test"),
                             stringc("test", 'red'))

        def test_color_code(self):
            """stringc with color code"""

# Generated at 2022-06-21 08:15:46.975908
# Unit test for function colorize
def test_colorize():
    assert colorize(u"xxxx", 0, None) == "xxxx=0   "
    assert colorize(u"xxxx", 1, C.COLOR_CHANGED) == "\033[0;34mxxxx=1   \033[0;0m"
    assert colorize(u"xxxx", 1, C.COLOR_ERROR) == "\033[0;91mxxxx=1   \033[0;0m"
    assert colorize(u"xxxx", 1, C.COLOR_OK) == "\033[0;32mxxxx=1   \033[0;0m"



# Generated at 2022-06-21 08:15:56.104594
# Unit test for function colorize
def test_colorize():
    """Basic test to make sure the colour code is correct"""
    lead = "[lead]"
    num = "1234"

    # Test colour with ANSIBLE_COLOR = False
    assert colorize(lead, num, None) == "[lead]=1234"
    assert colorize(lead, num, False) == "[lead]=1234"
    assert colorize(lead, num, True) == "[lead]=1234"

    # Test color with ANSIBLE_COLOR = True
    ANSIBLE_COLOR = True
    assert colorize(lead, num, False) == "[lead]=1234"
    assert colorize(lead, num, None) == "[lead]=1234"
    assert colorize(lead, num, "green") == "\033[32m[lead]=1234\033[0m"



# Generated at 2022-06-21 08:16:04.987917
# Unit test for function colorize
def test_colorize():
    s = u"{0}".format(colorize('foo', 0, 'blue'))
    assert s == u"foo=0   "
    s = u"{0}".format(colorize('foo', 1, 'blue'))
    assert s == u"foo=1   "
    s = u"{0}".format(colorize('foo', 2, 'blue'))
    assert s == u"foo=2   "
    s = u"{0}".format(colorize('foo', 3, 'blue'))
    assert s == u"foo=3   "

    # Unit test disabled:  This test fails when ANSIBLE_COLOR env var is not set
    #s = u"{0}".format(colorize('foo', 0, 'blue'))
    #assert s == u"foo=0   "


# Generated at 2022-06-21 08:16:16.251837
# Unit test for function parsecolor
def test_parsecolor():
    assert int(parsecolor('black')) == C.COLOR_CODES['black']
    assert int(parsecolor('red')) == C.COLOR_CODES['red']
    assert int(parsecolor('green')) == C.COLOR_CODES['green']
    assert int(parsecolor('yellow')) == C.COLOR_CODES['yellow']
    assert int(parsecolor('blue')) == C.COLOR_CODES['blue']
    assert int(parsecolor('magenta')) == C.COLOR_CODES['magenta']
    assert int(parsecolor('cyan')) == C.COLOR_CODES['cyan']
    assert int(parsecolor('white')) == C.COLOR_CODES['white']
    assert int(parsecolor('22'))

# Generated at 2022-06-21 08:16:27.106389
# Unit test for function hostcolor
def test_hostcolor():
    import ansible.constants as C
    ansible_color = True
    host = u"localhost"
    stats = dict(skipped=0, ok=1, changed=0, unreachable=0, failures=0)
    color = True
    assert hostcolor(host, stats, color) == stringc(host, C.COLOR_OK) + u"            "

    host = u"localhost"
    stats = dict(skipped=0, ok=0, changed=1, unreachable=0, failures=0)
    color = True
    assert hostcolor(host, stats, color) == stringc(host, C.COLOR_CHANGED) + u"            "

    host = u"localhost"
    stats = dict(skipped=0, ok=0, changed=0, unreachable=1, failures=0)

# Generated at 2022-06-21 08:16:32.484422
# Unit test for function stringc
def test_stringc():
    assert stringc('hello', 'blue') == u"\033[34mhello\033[0m"
    assert stringc('hello', C.COLOR_OK) == u"\033[32mhello\033[0m"
    assert stringc('hello', C.COLOR_ERROR) == u"\033[31mhello\033[0m"
    assert stringc('hello', 'white') == u"\033[37mhello\033[0m"

test_stringc()
# --- end "pretty"

# Generated at 2022-06-21 08:16:41.875152
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(changed=1, dark=2)) == u'localhost               '
    assert hostcolor("localhost", dict(ok=1, dark=2)) == u'\x1b[0;32mlocalhost             \x1b[0m'
    assert hostcolor("localhost", dict(failures=1, dark=2)) == u'\x1b[0;31mlocalhost             \x1b[0m'
    assert hostcolor("localhost", dict(changed=1, dark=2), color=False) == u'localhost               '
    assert hostcolor("localhost", dict(ok=1, dark=2), color=False) == u'localhost               '
    assert hostcolor("localhost", dict(failures=1, dark=2), color=False) == u'localhost               '



# Generated at 2022-06-21 08:16:57.021533
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 0, 'blue') == 'foo=0   '    # blue on black is invisible
    assert colorize('foo', 255, 'blue') == 'foo=255 '
    assert colorize('foo', 255, 'blue') == 'foo=255 '


# --- end "pretty"

# --- begin colored output helper functions


# Generated at 2022-06-21 08:17:05.215930
# Unit test for function stringc
def test_stringc():
    # check that the eight ANSI base colors work
    for color in [ 'black', 'red', 'green', 'yellow',
                   'blue', 'magenta', 'cyan', 'white' ]:
        text = u'This is %s text' % color
        colored_text = stringc(text, color)
        # there should be a color code around the text
        match = re.search(r'\[\d\d?m(.*?)\[0m', colored_text)
        assert match.group(1) == text

    # check that the color codes are parsed
    text = u'There are \033[1;31m31\033[0m red roses'
    colored_text = stringc(text, 'color0')
    assert colored_text == text

    # check that the color codes are wrapped but not changed
   

# Generated at 2022-06-21 08:17:15.004217
# Unit test for function parsecolor
def test_parsecolor():
    for color, code in C.COLOR_CODES.items():
        assert parsecolor(color) == code
    for color in (1, 2, 3, 4, 5, 6, 7, 8, 9,
                  1, 0, 3, 2, 5, 4, 7, 6, 9,
                  1, 2, 0, 3, 4, 5, 6, 7, 8, 9,
                  232, 233, 234, 235, 236, 237, 238, 239, 240,
                  241, 242, 243, 244, 245, 246, 247, 248, 249,
                  250, 251, 252, 253, 254, 255):
        assert parsecolor(str(color)) == u'38;5;%d' % color

# Generated at 2022-06-21 08:17:26.737455
# Unit test for function parsecolor
def test_parsecolor():
    """Unit tests for parsecolor."""
    import os
    import subprocess
    import tempfile

    def run(script):
        """
        Run `script` using python and return stdout as a string.
        """
        with tempfile.NamedTemporaryFile('w', delete=False) as fd:
            fd.file.write(script)
        try:
            with open(os.devnull, 'r+') as devnull:
                p = subprocess.Popen(['python', fd.name], stdin=devnull,
                                     stdout=subprocess.PIPE,
                                     stderr=subprocess.STDOUT)
                stdout, _ = p.communicate()
                return stdout
        finally:
            os.unlink(fd.name)


# Generated at 2022-06-21 08:17:38.313778
# Unit test for function stringc
def test_stringc():
    # Fails with utf-8
    backup = sys.getdefaultencoding()
    sys.setdefaultencoding('ascii')

# Generated at 2022-06-21 08:17:44.697441
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host='localhost', stats={'failures': 0, 'changed': 0, 'ok': 0}, color=True) == u'%-37s'
    assert hostcolor(host='localhost', stats={'failures': 1, 'changed': 0, 'ok': 0}, color=True) == u'%-37s'
    assert hostcolor(host='localhost', stats={'failures': 0, 'changed': 0, 'ok': 1}, color=True) == u'%-37s'
    assert hostcolor(host='localhost', stats={'failures': 0, 'changed': 1, 'ok': 0}, color=True) == u'%-37s'
    assert hostcolor(host='localhost', stats={'failures': 0, 'changed': 0, 'ok': 0}, color=False) == u'%-26s'



# Generated at 2022-06-21 08:17:57.406332
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert "\033[31mHello\033[0m World" == stringc("Hello World", 'red')
        assert "\033[42mHello\033[0m World" == stringc("Hello World", 'green')
        assert "\033[44mHello\033[0m World" == stringc("Hello World", 'blue')
        assert "\033[45mHello\033[0m World" == stringc("Hello World", 'magenta')
        assert "\033[46mHello\033[0m World" == stringc("Hello World", 'cyan')
        assert "\033[1mHello\033[0m World" == stringc("Hello World", 'bold')
        assert "Hello World" == stringc("Hello World", 'nocolor')
    else:
        assert "Hello World" == stringc

# Generated at 2022-06-21 08:18:10.660109
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('bright black') == u'01;30'
    assert parsecolor('red') == u'31'
    assert parsecolor('bright red') == u'01;31'
    assert parsecolor('green') == u'32'
    assert parsecolor('bright green') == u'01;32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('bright yellow') == u'01;33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('bright blue') == u'01;34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('bright magenta') == u'01;35'
    assert parsecolor('cyan') == u

# Generated at 2022-06-21 08:18:21.309274
# Unit test for function parsecolor
def test_parsecolor():
    # Ref: https://en.wikipedia.org/wiki/ANSI_escape_code
    # Except for gray range (gray 16-231)
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'

# Generated at 2022-06-21 08:18:30.078746
# Unit test for function stringc
def test_stringc():
    import pytest
    assert stringc(u"some text", u"blue") == u"\033[34msome text\033[0m"
    assert stringc(u"some text", u"rgb255255255") == u"\033[38;5;15msome text\033[0m"
    assert stringc(u"some text", u"rgb000255255") == u"\033[38;5;51msome text\033[0m"
    assert stringc(u"some text", u"rgb123000150") == u"\033[38;5;125msome text\033[0m"
    assert stringc(u"some text", u"gray0") == u"\033[38;5;232msome text\033[0m"

# Generated at 2022-06-21 08:18:53.406818
# Unit test for function colorize
def test_colorize():
    lead = u'foo'
    num = 42
    assert 'foo=42' == colorize(lead, num, None)
    num = 12345
    assert 'foo=12345' == colorize(lead, num, None)
    num = 0
    assert 'foo=0   ' == colorize(lead, num, None)
    num = -42
    assert 'foo=-42 ' == colorize(lead, num, None)

# --- end of "pretty"



# Generated at 2022-06-21 08:19:04.519311
# Unit test for function parsecolor
def test_parsecolor():
    def check(x):
        return x % (u'expected', u'parsed')


# Generated at 2022-06-21 08:19:11.145304
# Unit test for function stringc
def test_stringc():
    print(u"Testing function stringc()")
    correct = 0
    test = stringc(u"This is a test", u"red")
    if test == u"\x1b[31mThis is a test\x1b[0m":
        correct += 1
    test = stringc(u"This is a test", u"rgb000")
    if test == u"\x1b[38;5;16mThis is a test\x1b[0m":
        correct += 1
    test = stringc(u"This is a test", u"rgb123")
    if test == u"\x1b[38;5;54mThis is a test\x1b[0m":
        correct += 1
    test = stringc(u"This is a test", u"rgb333")

# Generated at 2022-06-21 08:19:22.350440
# Unit test for function stringc
def test_stringc():
    class TestColor(object):
        def __init__(self, color, wanted):
            self.color = color
            self.wanted = wanted

    test_colors = [TestColor('black', u'\033[30m'), TestColor('red', u'\033[31m'),
                   TestColor('green', u'\033[32m'), TestColor('yellow', u'\033[33m'),
                   TestColor('blue', u'\033[34m'), TestColor('magenta', u'\033[35m'),
                   TestColor('cyan', u'\033[36m'), TestColor('white', u'\033[37m'),
                   TestColor('default', u'\033[39m'), TestColor('bg_default', u'\033[49m')]


# Generated at 2022-06-21 08:19:33.918595
# Unit test for function colorize
def test_colorize():
    # pylint: disable=missing-docstring
    assert not ANSIBLE_COLOR

    def test_colorize_none(lead, num, color):
        assert colorize(lead, num, color) == u"%s=%-4s" % (lead, str(num))

    test_colorize_none("ok", 0, None)
    test_colorize_none("ok", 1, None)

    global ANSIBLE_COLOR
    original_ansible_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    def test_colorize_ansible_color_true(lead, num, color):
        assert colorize(lead, num, color) == u"%s=%-4s" % (lead, str(num))


# Generated at 2022-06-21 08:19:43.337444
# Unit test for function parsecolor
def test_parsecolor():
    print('\nColor name to SGR parameter string test cases')

# Generated at 2022-06-21 08:19:52.392893
# Unit test for function colorize
def test_colorize():
    assert colorize('zzz', 0, 'red') == 'zzz=0   '
    assert colorize(u'\u263a', 42, 'green') == u'\u263a=42  '
    assert colorize(u'\u263a', 42, C.COLOR_SKIP) == u'\u263a=42  '

    if ANSIBLE_COLOR:
        assert colorize(u'aaa', 1, 'red') == '\033[31maaa=1   \033[0m'
        assert colorize(u'\u263a', 42, 'green') == u'\033[32m\u263a=42  \033[0m'

# Generated at 2022-06-21 08:20:04.086310
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == '31'
    assert parsecolor("lightred") == '91'
    assert parsecolor("color1") == '38;5;1'
    assert parsecolor("rgb150") == '38;5;130'
    assert parsecolor("rgb5550") == '38;5;114'
    assert parsecolor("rgb25550") == '38;5;94'
    assert parsecolor("gray0") == '38;5;232'
    assert parsecolor("gray24") == '38;5;250'
    assert parsecolor("gray23") == '38;5;249'
    assert parsecolor("gray8") == '38;5;240'

# Generated at 2022-06-21 08:20:14.382574
# Unit test for function colorize
def test_colorize():
    failed = colorize("FAILED", 0, "green")
    assert failed == "FAILED=0   "

    unreachable = colorize("UNREACHABLE", 0, "red")
    assert unreachable == "UNREACHABLE=0"

    ok = colorize("OK", 0, "blue")
    assert ok == "OK=0       "

    changed = colorize("CHANGED", 0, "yellow")
    assert changed == "CHANGED=0  "

    dark_gray = colorize("DARK GRAY", 0, "dark_gray")
    assert dark_gray == "DARK GRAY=0"



# Generated at 2022-06-21 08:20:21.888753
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "color0") == u"\033[38;5;0mtext\033[0m"
    assert stringc("text", "color1") == u"\033[38;5;1mtext\033[0m"
    assert stringc("text", "color9") == u"\033[38;5;9mtext\033[0m"
    assert stringc("text", "color16") == u"\033[38;5;16mtext\033[0m"
    assert stringc("text", "color21") == u"\033[38;5;21mtext\033[0m"

# Generated at 2022-06-21 08:20:45.946291
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 1, 'blue') == stringc('foo=1   ', 'blue')
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '



# Generated at 2022-06-21 08:20:58.307912
# Unit test for function parsecolor
def test_parsecolor():
    # We should return an integer corresponding to the color between
    # 0 and 255.
    assert type(parsecolor('red')) == unicode
    assert int(parsecolor('red')) >= 0
    assert int(parsecolor('red')) <= 255

    assert type(parsecolor('blue')) == unicode
    assert int(parsecolor('blue')) >= 0
    assert int(parsecolor('blue')) <= 255

    assert type(parsecolor('green')) == unicode
    assert int(parsecolor('green')) >= 0
    assert int(parsecolor('green')) <= 255

    # The gray levels should go from 0 (black) to 23 (white).
    # Note that the value 24 is specified as default in the code and
    # is used as default in the tests as well.
    assert type

# Generated at 2022-06-21 08:21:08.773030
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('lightred') == u'38;5;1'
    assert parsecolor('lightgreen') == u'38;5;2'
    assert parsecolor('lightyellow') == u'38;5;3'
    assert parsecolor('blue') == '34'
    assert parsecolor('lightblue') == u'38;5;4'
    assert parsecolor('magenta') == '35'
    assert parsecolor('lightmagenta') == u'38;5;5'
    assert parsecolor('lightcyan') == u'38;5;6'
    assert parsecolor('green') == '32'
    assert parsec

# Generated at 2022-06-21 08:21:15.299790
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"red") == u"\x1b[31mfoo\x1b[0m"
    assert stringc(u"foo\nbar", u"red") == u"\x1b[31mfoo\x1b[0m\n\x1b[31mbar\x1b[0m"
    assert stringc(u"foo", u"rgb245") == u"\x1b[38;5;131mfoo\x1b[0m"
    assert stringc(u"foo", u"gray8") == u"\x1b[38;5;244mfoo\x1b[0m"

# Generated at 2022-06-21 08:21:18.990950
# Unit test for function colorize
def test_colorize():
    for color in [None, 'blue', 'bold white', 'magenta', 'green']:
        s = colorize(u"foo", 42, color)
        assert(s == u"foo=42  ")


# Generated at 2022-06-21 08:21:29.190603
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('gray') == '1;30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'

# Generated at 2022-06-21 08:21:36.291854
# Unit test for function hostcolor
def test_hostcolor():
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    stats['ok'] = 1
    stats['skipped'] = 0
    assert hostcolor('test_host',stats,True) == u"test_host                 "
    stats['changed'] = 1
    assert hostcolor('test_host',stats,True) == u"test_host                 "
    stats['changed'] = 0
    stats['failures'] = 1
    assert hostcolor('test_host',stats,True) == u"test_host                 "
    stats['failures'] = 0
    stats['unreachable'] = 1
    assert hostcolor('test_host',stats,True) == u"test_host                 "


# Generated at 2022-06-21 08:21:46.116991
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        # errors
        assert hostcolor('host', dict(failures=1), True) == \
            u'\033[31mhost      \033[0m'
        assert hostcolor('host', dict(failures=1), False) == \
            u'host                '
        # changed
        assert hostcolor('host', dict(changed=1), True) == \
            u'\033[33mhost      \033[0m'
        assert hostcolor('host', dict(changed=1), False) == \
            u'host                '
        # ok
        assert hostcolor('host', dict(ok=1), True) == \
            u'\033[32mhost      \033[0m'