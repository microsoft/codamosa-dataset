

# Generated at 2022-06-21 08:11:59.390932
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 5, u"green") == u'foo=5   '
    assert colorize(u"foo", 0, u"red") == u'foo=0   '
    assert colorize(u"foo", -1, u"yellow") == u'foo=-1  '
    # Test with ANSIBLE_FORCE_COLOR
    C.ANSIBLE_FORCE_COLOR = True

# Generated at 2022-06-21 08:12:11.382486
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('redwap.in', {}) == 'redwap.in'
    assert hostcolor('', {}) == ''
    assert hostcolor('redwap.in', { 'changed': 1, 'unreachable': 0, 'failures': 0}) == 'redwap.in'
    assert hostcolor('redwap.in', { 'changed': 0, 'unreachable': 0, 'failures': 0}) == 'redwap.in'
    assert hostcolor('redwap.in', { 'changed': 0, 'unreachable': 0, 'failures': 1}) == 'redwap.in'
    assert hostcolor('redwap.in', { 'changed': 0, 'unreachable': 1, 'failures': 0}) == 'redwap.in'

# Generated at 2022-06-21 08:12:18.092947
# Unit test for function colorize
def test_colorize():
    """Basic functionality test for colorize function"""
    for color in C.COLOR_CODES.keys():
        lead = color
        num = color
        result = colorize(lead, num, color)
        print(result)
        # The tests below don't really work, because we can't plug in
        # curses with the colors
        # assert result.find(lead) >= 0
        # assert result.find(num) >= 0
        # assert result.find(color) >= 0

if __name__ == '__main__':
    test_colorize()

# --- end "pretty"

# Generated at 2022-06-21 08:12:28.065936
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('COLOR_DEFAULT') == '39'
    assert parsecolor('bright-black') == '90'
    assert parsecolor('bright-red') == '91'
    assert parsecolor('bright-green') == '92'
    assert parsecolor('bright-yellow') == '93'
    assert parsecolor('bright-blue') == '94'

# Generated at 2022-06-21 08:12:38.289771
# Unit test for function hostcolor
def test_hostcolor():
    color_codes = [
        u'\033[0;30;43m',
        u'\033[0;30;42m',
        u'\033[0;30;41m',
    ]
    stats = [
        {'changed': 3, 'failures': 0, 'skipped': 1, 'ok': 6, 'unreachable': 0, 'rescue': 0, 'ignore': 0},
        {'changed': 0, 'failures': 3, 'skipped': 1, 'ok': 6, 'unreachable': 0, 'rescue': 0, 'ignore': 0},
        {'changed': 0, 'failures': 0, 'skipped': 1, 'ok': 6, 'unreachable': 3, 'rescue': 0, 'ignore': 0},
    ]


# Generated at 2022-06-21 08:12:48.631877
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        fails=0,
        unreachable=0,
        changed=0,
    )
    print(hostcolor('test_host', stats, False))
    stats = dict(
        fails=0,
        unreachable=0,
        changed=1,
    )
    print(hostcolor('test_host', stats, False))
    stats = dict(
        fails=0,
        unreachable=0,
        changed=0,
    )
    print(hostcolor('test_host', stats, True))
    stats = dict(
        fails=0,
        unreachable=0,
        changed=1,
    )
    print(hostcolor('test_host', stats, True))
    stats = dict(
        fails=1,
        unreachable=0,
        changed=0,
    )

# Generated at 2022-06-21 08:12:55.591396
# Unit test for function hostcolor
def test_hostcolor():
    # these should all have ANSIBLE_COLOR=True
    assert hostcolor(u'foo', dict(failures=1, unreachable=0, changed=0, ok=0), True) == u'foo                       '
    assert hostcolor(u'foo', dict(failures=0, unreachable=1, changed=0, ok=0), True) == u'foo                       '
    assert hostcolor(u'foo', dict(failures=0, unreachable=0, changed=1, ok=0), True) == u'foo                       '
    assert hostcolor(u'foo', dict(failures=0, unreachable=0, changed=0, ok=0), True) == u'foo                       '

    # these should all have ANSIBLE_COLOR=False

# Generated at 2022-06-21 08:13:05.934847
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('example', {}) == '%-37s' % 'example'
    assert hostcolor('example', {'failures': 1}) == '%-37s' % stringc('example', C.COLOR_ERROR)
    assert hostcolor('example', {'failures': 0, 'changed': 1}) == '%-37s' % stringc('example', C.COLOR_CHANGED)
    assert hostcolor('example', {'failures': 0, 'changed': 0}) == '%-37s' % stringc('example', C.COLOR_OK)
    assert hostcolor('example', {'failures': 0, 'changed': 0}, color=False) == '%-26s' % 'example'



# Generated at 2022-06-21 08:13:17.935879
# Unit test for function stringc
def test_stringc():
    assert str(stringc("foo", "red")) == "\033[31mfoo\033[0m"
    assert str(stringc("foo\nbar", "red")) == "\033[31mfoo\nbar\033[0m"
    assert str(stringc("foo\nbar\nbaz", "red")) == "\033[31mfoo\nbar\nbaz\033[0m"
    assert str(stringc("foo", "red", True)) == "\001\033[31m\002foo\001\033[0m\002"
    assert str(stringc("foo\nbar", "red", True)) == "\001\033[31m\002foo\nbar\001\033[0m\002"

# Generated at 2022-06-21 08:13:23.795730
# Unit test for function parsecolor
def test_parsecolor():
    print("Testing parsecolor")
    assert parsecolor("red") == C.COLOR_CODES["red"]
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("rgb255000") == "38;5;9"
    assert parsecolor("rgb255255255") == "38;5;231"
    assert parsecolor("gray0") == "38;5;232"
    assert parsecolor("gray23") == "38;5;255"


# Generated at 2022-06-21 08:13:36.847046
# Unit test for function stringc
def test_stringc():
    test_str = "Test"
    assert stringc(test_str, "red") == u"\033[31m%s\033[0m" % test_str
    assert stringc(test_str, "rgb110") == u"\033[38;5;52m%s\033[0m" % test_str
    #assert stringc(test_str, "gray20") == u"\033[38;5;231m%s\033[0m" % test_str
    assert stringc(test_str, "blue") == u"\033[34m%s\033[0m" % test_str
    assert stringc(test_str, "1") == u"\033[31m%s\033[0m" % test_str

# Generated at 2022-06-21 08:13:46.868196
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""

    if not ANSIBLE_COLOR:
        return

    print(stringc("Hello World this is a test", "GREEN"))
    print(stringc("I like tests! I like them a lot", "RED"))
    print(stringc("This is a grey color test", "GREY"))
    print(stringc("Color number 5", "COLOR5"))
    print(stringc("This is rgb color test", "RGB 255 0 255"))
    print(stringc("This is an underline test", "UNDERLINE"))
    print(stringc("Bold text test", "BOLD"))
    print(stringc("This test is a bold underline", "BOLD,UNDERLINE"))
    print(stringc("This is a bold underline color test", "BOLD,UNDERLINE,GREEN"))
    print

# Generated at 2022-06-21 08:13:59.509127
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == '\x1b[32mfoo\x1b[0m'
    assert stringc('foo', 'red') == '\x1b[31mfoo\x1b[0m'
    assert stringc('foo', 'blue') == '\x1b[34mfoo\x1b[0m'
    assert stringc('foo', 'magenta') == '\x1b[35mfoo\x1b[0m'
    assert stringc('foo', 'cyan') == '\x1b[36mfoo\x1b[0m'
    assert stringc('foo', 'yellow') == '\x1b[33mfoo\x1b[0m'

# Generated at 2022-06-21 08:14:05.057502
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("black") == u"30"
    assert parsecolor("red") == u"31"
    assert parsecolor("green") == u"32"
    assert parsecolor("yellow") == u"33"
    assert parsecolor("blue") == u"34"
    assert parsecolor("magenta") == u"35"
    assert parsecolor("cyan") == u"36"
    assert parsecolor("white") == u"37"
    assert parsecolor("color240") == u"38;5;240"
    assert parsecolor("rgb123") == u"38;5;166"
    assert parsecolor("rgb111") == u"38;5;23"
    assert parsecolor("rgb255") == u"38;5;231"

# Generated at 2022-06-21 08:14:14.466576
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, u"black") == u"foo=0   "
    assert colorize(u"foo", 1, u"black") == u"foo=1   "
    assert colorize(u"foo", -1, u"black") == u"foo=-1  "
    assert colorize(u"foo", 0, u"black") == u"foo=0   "
    assert colorize(u"foo", 1, u"green") == u"foo=1   "
    assert colorize(u"foo", -1, u"red") == u"foo=-1  "
    assert colorize(u"foo", 123, u"blue") == u"foo=123 "
    assert colorize(u"foo", 1234, u"blue") == u"foo=1234"

# Generated at 2022-06-21 08:14:25.219275
# Unit test for function parsecolor
def test_parsecolor():
    from ansible.module_utils.six import assertCountEqual
    assert parsecolor('red') == '31'
    assert parsecolor('RED') == '31'
    assert parsecolor('black') == '30'
    assert parsecolor('COLOR0') == '30'
    assert parsecolor('COLOR256') == '38;5;256'
    assert parsecolor('rgb255255255') == '38;5;15'
    assert parsecolor('rgb000000') == '38;5;16'
    assert parsecolor('rgb255255255') == '38;5;15'
    assert parsecolor('rgb2550000255') == '38;5;5'
    assert parsecolor('rgb0000255255') == '38;5;33'

# Generated at 2022-06-21 08:14:37.750063
# Unit test for function colorize
def test_colorize():
    leads = ['ok:', 'changed:', 'unreachable:', 'failed:']
    nums = [0, 4, 1, 12]
    colors = [C.COLOR_OK, C.COLOR_CHANGED, C.COLOR_ERROR, C.COLOR_ERROR]
    for i in range(0, 4):
        result = colorize(leads[i], nums[i], colors[i])
        # result = colorize(leads[i],nums[i],None)
        # print result
        assert result[0] == '\n'
        assert result[7] == '='
        assert result[11] == '\n'
        if nums[i] != 0:
            assert result[9] == '\033'
        else:
            assert result[9] != '\033'


# Generated at 2022-06-21 08:14:45.314804
# Unit test for function stringc
def test_stringc():
    red = u"\033[31mRed\033[0m"
    assert stringc(u'Red', u'red') == red
    assert stringc(u'Red', u'color1') == red
    assert stringc(u'Red', u'rgb511') == red
    assert stringc(u'Red', u'gray1') == red

    assert stringc(u'Red', u'red', wrap_nonvisible_chars=True) == '\001\033[31m\002Red\001\033[0m\002'

    green = u"\033[32mGreen\033[0m"
    assert stringc(u'Green', u'green') == green
    assert stringc(u'Green', u'color2') == green

# Generated at 2022-06-21 08:14:57.200753
# Unit test for function hostcolor
def test_hostcolor():
    # Set the ANSIBLE_COLOR environment variable to true in order to ensure
    # color is used in the output
    import os
    os.environ['ANSIBLE_COLOR'] = '1'
    stats = dict(changed=0, failures=0, unreachable=0)
    host = 'hostname'
    color = True
    result = hostcolor(host, stats, color)
    assert result == u"%-37s" % '\033[92mhostname\033[0m'
    # If the system does not support color the output should not be modified
    os.environ['ANSIBLE_COLOR'] = '0'
    color = True
    result = hostcolor(host, stats, color)
    assert result == u"%-26s" % host
    # Color should not be used if color is set to false
    color = False

# Generated at 2022-06-21 08:15:07.000796
# Unit test for function stringc
def test_stringc():
    assert stringc('Hello World!', 'blue') == u"\033[34mHello World!\033[0m"
    assert stringc('Hello World!', 'rgb255') == u"\033[38;5;11mHello World!\033[0m"
    assert stringc('Hello World!', 'rgb253') == u"\033[38;5;9mHello World!\033[0m"
    assert stringc('Hello World!', 'rgb000') == u"\033[38;5;16mHello World!\033[0m"
    assert stringc('Hello World!', 'rgb123') == u"\033[38;5;33mHello World!\033[0m"

# Generated at 2022-06-21 08:15:21.607433
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'green') == u'ok=0   '
    assert colorize('changed', 0, 'yellow') == u'changed=0   '
    assert colorize('unreachable', 0, 'red') == u'unreachable=0   '
    assert colorize('skipping', 0, 'cyan') == u'skipping=0   '
    assert colorize('failed', 0, 'red') == u'failed=0   '


# Generated at 2022-06-21 08:15:24.084491
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, "blue") == u"foo=0   "
    assert colorize("f", 0, "blue") == u"f=0     "



# Generated at 2022-06-21 08:15:32.961218
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor("example.com", {'ok': 10, 'changed': 0, 'unreachable': 0, 'failures': 0}))
    print(hostcolor("example.com", {'ok': 0, 'changed': 0, 'unreachable': 1, 'failures': 0}))
    print(hostcolor("example.com", {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 1}))
    print(hostcolor("example.com", {'ok': 0, 'changed': 1, 'unreachable': 0, 'failures': 0}))


# Generated at 2022-06-21 08:15:40.319341
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == C.COLOR_CODES["red"], "parsecolor(red) failed"
    assert parsecolor("rgb153") == C.COLOR_CODES["rgb153"], "parsecolor(rgb153) failed"
    assert parsecolor("graya8") == C.COLOR_CODES["graya8"], "parsecolor(graya8) failed"
    assert parsecolor("color4") == C.COLOR_CODES["color4"], "parsecolor(color4) failed"
    assert parsecolor("color33") == C.COLOR_CODES["color33"], "parsecolor(color33) failed"
    assert parsecolor("color256") == C.COLOR_CODES["color256"], "parsecolor(color256) failed"

# Generated at 2022-06-21 08:15:51.606092
# Unit test for function stringc
def test_stringc():
    """Tests the stringc function
    The function is meant to format the specified text in a specified color,
    so we test that a colored string is returned when both parameters are
    specified, a non-colored string when only text is specified, and an
    empty string when no parameters are specified.
    """
    test_string = u"test_string"
    test_color = u"blue"
    colored_string_result = stringc(test_string, test_color)
    non_colored_string_result = stringc(test_string, '')
    empty_string_result = stringc('', '')

    assert u"\033[34mtest_string\033[0m" == colored_string_result
    assert test_string == non_colored_string_result
    assert '' == empty_string_result

# --- end of "

# Generated at 2022-06-21 08:16:02.155698
# Unit test for function hostcolor
def test_hostcolor():
    # print hostcolor fails if ANSIBLE_COLOR is True
    import __builtin__
    old_print = __builtin__.print
    def print_mock(*args, **kwargs):
        raise AssertionError(args)
    __builtin__.print = print_mock
    hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0})
    hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1})
    hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0})
    hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0})
    __builtin__.print = old_print

# End of pretty
# ---

# ---

# Generated at 2022-06-21 08:16:14.480217
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == "31"
    assert parsecolor('bold red') == "1;31"
    assert parsecolor('on_green') == "42"
    assert parsecolor('dim on_blue') == "2;44"
    assert parsecolor('color5') == "38;5;5"
    assert parsecolor('color5 bold on_green') == "1;38;5;5;42"
    assert parsecolor('rgb555') == "38;5;231"
    assert parsecolor('rgb255') == "38;5;9"
    assert parsecolor('rgb255 bold') == "1;38;5;9"
    assert parsecolor('gray1') == "38;5;234"

# Generated at 2022-06-21 08:16:20.756560
# Unit test for function colorize
def test_colorize():
    lead = 'LEAD'
    num = 42
    color = 'magenta'

    result = colorize(lead, num, color)

    if ANSIBLE_COLOR and color is not None:
        result_fmt = "\033[%(color)smLEAD=%-4s\033[0m" % {'color': '35'}
    else:
        result_fmt = "%(lead)s=%-4s"
        num = 0
    assert result == result_fmt % {'lead': lead, 'num': str(num)}


# --- end "pretty"



# Generated at 2022-06-21 08:16:30.788857
# Unit test for function hostcolor
def test_hostcolor():
    test_hosts = [
        'localhost',
        'invincible',
        'helpless',
        'already_deployed',
        'still_alive',
        'testing',
    ]

# Generated at 2022-06-21 08:16:40.744436
# Unit test for function stringc
def test_stringc():
    # TODO: split this in individual test
    # Test with color enabled
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "rgb255") == "\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb000") == "\033[38;5;16mtest\033[0m"
    assert stringc("test", "rgb555") == "\033[38;5;8mtest\033[0m"
    assert stringc("test", "rgb222") == "\033[38;5;51mtest\033[0m"
    assert stringc("test", "rgb123") == "\033[38;5;94mtest\033[0m"

# Generated at 2022-06-21 08:17:03.993055
# Unit test for function hostcolor
def test_hostcolor():
    # Legit 'host' and 'stats' arguments
    host1 = u'localhost'
    stats1 = {'changed': 0, 'failures': 0, 'ok': 6, 'skipped': 0, 'unreachable': 0}

    assert hostcolor(host1, stats1, color=True) == u'localhost               '
    assert hostcolor(host1, stats1, color=False) == u'localhost              '

    # Bad 'host' argument
    host2 = None
    assert hostcolor(host2, stats1, color=True) == u'None                    '
    assert hostcolor(host2, stats1, color=False) == u'None                   '

    # Bad 'stats' argument
    stats3 = None
    assert hostcolor(host1, stats3, color=True) == u'localhost               '
    assert hostcolor

# Generated at 2022-06-21 08:17:14.528043
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    # Print some test text in all known colors
    print ("\nTerminal colors:")
    for color in C.COLOR_CODES.keys():
        print ("\t%s" % stringc(color, color))
    # Print some test text in all possible 16-color terminal formats
    print ("\nTerminal 16-color codes:")
    for i in range(16):
        print ("\t%s" % stringc('%x' % i, 'color%d' % i))
    # Print some test text in all possible 256-color terminal formats
    print ("\nTerminal 256-color codes:")

# Generated at 2022-06-21 08:17:26.507785
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    # Disable this test when run by Hudson
    if os.environ.has_key('HUDSON_URL'):
        return
    # Check if color is turned on
    if ANSIBLE_COLOR:
        import sys
        # Wrap sys.stdout; this is needed to catch the escape sequence
        # inserted by colorize()
        orig_stdout = sys.stdout
        sys.stdout = cStringIO.StringIO()
        colorize(u"test", 4, u"white")
        color = sys.stdout.getvalue()
        sys.stdout.close()
        sys.stdout = orig_stdout
        assert color == u"\x1b[97mtest=4\x1b[0m"
        colorize(u"test", 4, None)

# Generated at 2022-06-21 08:17:38.079411
# Unit test for function stringc
def test_stringc():
    assert(u"\033[32mtext\033[0m" == stringc(u"text", u"green"))
    assert(u"\033[31mtext\033[0m" == stringc(u"text", u"red"))
    assert(u"\033[32mtext\033[0m" == stringc(u"text", u"34"))
    assert(u"\033[38;5;197mtext\033[0m" == stringc(u"text", u"197"))
    assert(u"\033[38;5;111mtext\033[0m" == stringc(u"text", u"rgb333"))
    assert(u"\033[38;5;245mtext\033[0m" == stringc(u"text", u"gray23"))

# Generated at 2022-06-21 08:17:47.355864
# Unit test for function stringc
def test_stringc():
    """Verify that colors work."""

    text = u"stringc should have color"

    sys.stdout.write(u"\nverify colors: ")
    if ANSIBLE_COLOR:
        for color in C.COLOR_CODES:
            sys.stdout.write(stringc(text, color))
            sys.stdout.write(u" ")
        sys.stdout.write(u"\n")
    else:
        sys.stdout.write(u"colored output is disabled, skipping\n")
    sys.stdout.write(u"\n")

# --- end "pretty"



# Generated at 2022-06-21 08:17:59.094776
# Unit test for function parsecolor
def test_parsecolor():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestParseColor(unittest.TestCase):
        """ test cases for function parsecolor """
        def test_color(self):
            self.assertEqual(parsecolor('color01'), u'38;5;1')
            self.assertEqual(parsecolor('color01'), '38;5;1')
            self.assertEqual(parsecolor('color00'), u'38;5;0')
            self.assertEqual(parsecolor('color00'), '38;5;0')
            self.assertEqual(parsecolor('color09'), u'38;5;9')
            self.assertEqual(parsecolor('color09'), '38;5;9')


# Generated at 2022-06-21 08:18:12.134057
# Unit test for function parsecolor
def test_parsecolor():
    f = parsecolor
    assert f("black") == u"38;5;0"
    assert f("red") == u"38;5;1"
    assert f("green") == u"38;5;2"
    assert f("yellow") == u"38;5;3"
    assert f("blue") == u"38;5;4"
    assert f("magenta") == u"38;5;5"
    assert f("cyan") == u"38;5;6"
    assert f("white") == u"38;5;7"
    assert f("color0") == u"38;5;0"
    assert f("color1") == u"38;5;1"
    assert f("color2") == u"38;5;2"

# Generated at 2022-06-21 08:18:22.584628
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    ok_stats = dict(changed=0, failures=0, unreachable=0)
    changed_stats = dict(changed=1, failures=0, unreachable=0)
    failed_stats = dict(changed=0, failures=1, unreachable=0)
    unreachable_stats = dict(changed=0, failures=0, unreachable=1)

    assert '\x1b[0;32m%-26s\x1b[0m' == hostcolor(host, ok_stats, color=True)
    assert '\x1b[0;33m%-26s\x1b[0m' == hostcolor(host, changed_stats, color=True)

# Generated at 2022-06-21 08:18:31.015034
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('', 'red') == u'\033[31m\033[0m'
        assert stringc('\n', 'red') == u'\033[31m\n\033[0m'
        assert stringc('\n', 'white', wrap_nonvisible_chars=True) == u'\001\033[97m\002\n\001\033[0m\002'
        assert stringc('\n\n', 'white', wrap_nonvisible_chars=True) == u'\001\033[97m\002\n\n\001\033[0m\002'

# Generated at 2022-06-21 08:18:38.888699
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'yellow') == u'33'
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'cyan') == u'36'
    assert parsecolor(u'white') == u'37'
    assert parsecolor(u'black') == u'30'
    assert parsecolor(u'bright purple') == u'35'
    assert parsecolor(u'dark gray') == u'90'
    assert parsecolor(u'light blue') == u'94'
    assert parsecolor(u'light green') == u'92'
    assert parsecolor(u'light gray') == u'37'
    assert parsecolor(u'01') == u'38;5;1'
    assert parsecolor(u'gray1') == u

# Generated at 2022-06-21 08:19:20.866198
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == C.COLOR_CODES['red']
    # RGB
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('rgb100') == u'38;5;124'
    assert parsecolor('rgb530') == u'38;5;136'
    # Grayscale
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('gray23') == u'38;5;254'
    # color0-15 (the first 16 `normal' ANSI colors)
    assert parsecolor('color0') == u'38;5;0'

# Generated at 2022-06-21 08:19:28.766052
# Unit test for function hostcolor
def test_hostcolor():
    def test_hostcolor(host, stats, expected_output, expected_color):
        lead = "foo"
        result = hostcolor(host, stats, color=True)
        assert result == expected_output
        color = ANSIBLE_COLOR
        ANSIBLE_COLOR = expected_color
        result = hostcolor(host, stats, color=True)
        ANSIBLE_COLOR = color
        assert result == expected_output
        result = hostcolor(host, stats, color=False)
        assert result == expected_output

    test_hostcolor("myhost", {'failures': 0, 'unreachable': 0, 'changed': 0}, "myhost                 ", True)
    test_hostcolor("myhost", {'failures': 1, 'unreachable': 0, 'changed': 0}, "myhost                 ", True)
    test

# Generated at 2022-06-21 08:19:40.557242
# Unit test for function hostcolor
def test_hostcolor():
    host1 = "host1"
    host2 = "host2"
    host3 = "host3"
    stats1 = dict(changed=0, failures=0, unreachable=0)
    stats2 = dict(changed=1, failures=0, unreachable=0)
    stats3 = dict(changed=0, failures=1, unreachable=0)
    stats4 = dict(changed=0, failures=0, unreachable=1)

    # Test cases for color output
    assert hostcolor(host1, stats1, True) == stringc(host1, C.COLOR_OK)
    assert hostcolor(host2, stats2, True) == stringc(host2, C.COLOR_CHANGED)
    assert hostcolor(host3, stats3, True) == stringc(host3, C.COLOR_ERROR)
   

# Generated at 2022-06-21 08:19:51.188413
# Unit test for function stringc
def test_stringc():
    print("TEXT NORMAL")
    print("TEXT BRIGHT")
    print("TEXT RED")
    print("TEXT GREEN")
    print("TEXT YELLOW")
    print("TEXT BLUE")
    print("TEXT MAGENTA")
    print("TEXT CYAN")
    print("TEXT WHITE")
    print("TEXT DEFAULT")

    print("TEXT ON_BLACK",
          "TEXT ON_RED",
          "TEXT ON_GREEN",
          "TEXT ON_YELLOW",
          "TEXT ON_BLUE",
          "TEXT ON_MAGENTA",
          "TEXT ON_CYAN",
          "TEXT ON_WHITE")

    print("color5")
    print("color10")
    print("color15")
    print("color20")
    print("color30")
    print("color40")

# Generated at 2022-06-21 08:20:03.495362
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('37') == u'38;5;37'
    assert parsecolor('rgb122') == u'38;5;83'
    assert parsecolor('rgb224') == u'38;5;69'
    assert parsecolor('rgb211') == u'38;5;92'
    assert parsecolor('rgb320') == u'38;5;124'
    assert parsecolor('rgb211') == u'38;5;92'
    assert parsecolor('rgb000') == u'38;5;232'
    assert parsecolor('rgb555') == u'38;5;255'
    assert parsecolor('rgb999') == u'38;5;231'
    assert par

# Generated at 2022-06-21 08:20:11.243548
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == C.COLOR_CODES['red']
    assert parsecolor('blink') == C.COLOR_CODES['blink']
    assert parsecolor('color201') == '38;5;201'
    assert parsecolor('rgb10040') == '38;5;196'
    assert parsecolor('gray80') == '38;5;250'


# Generated at 2022-06-21 08:20:20.015192
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;197' == parsecolor('blue')
    assert u'38;5;82' == parsecolor('color82')
    assert u'38;5;52' == parsecolor('gray2')
    assert u'38;5;52' == parsecolor('gray02')
    assert u'38;5;52' == parsecolor('grey2')
    assert u'38;5;52' == parsecolor('grey02')
    assert u'38;5;196' == parsecolor('rgb511')
    assert u'38;5;196' == parsecolor('rgb511')
    assert u'38;5;196' == parsecolor('rgb511')
    assert u'38;5;196' == parsecolor('rgb511')
    return True

#

# Generated at 2022-06-21 08:20:32.301445
# Unit test for function colorize
def test_colorize():
    RESET = "\x1b"
    if sys.platform == "win32":
        RESET = ""

    def t(exp, lead, num, color):
        act = colorize(lead, num, color)
        if act != exp:
            raise AssertionError("expected %r, got %r" % (exp, act))

    print("Testing colorize.")
    t("OK=1234", "OK", 1234, "green")
    t("OK=1234", "OK", 1234, None)
    t("OK=1234", "OK", 1234, "")
    t("OK=1234", "OK", 1234, "blue")
    t("OK=1234", "OK", 1234, "random")
    t("OK=0", "OK", 0, "green")

# Generated at 2022-06-21 08:20:38.017833
# Unit test for function colorize
def test_colorize():
    assert 'ok ' == colorize('ok', '', None)
    assert 'changed=1  ' == colorize('changed', 1, 'green')
    # Test that invisible chars are wrapped in the right way.
    assert '\x01\x1b[32m\x02changed=1  \x01\x1b[0m\x02' == colorize('changed', 1, 'green', True)

# Generated at 2022-06-21 08:20:45.721770
# Unit test for function parsecolor
def test_parsecolor():
    """Unit tests for parsecolor function.
    :returns: Return true if all tests pass
    :rtype: bool
    """
    # Test that when providing inputs that should return a "valid"
    # color code, it does
    assert(parsecolor("red") == u'31')
    assert(parsecolor("blue") == u'34')
    assert(parsecolor("white") == u'37')
    assert(parsecolor("color33") == u'38;5;33')
    assert(parsecolor("rgb221") == u'38;5;186')
    assert(parsecolor("rgb123") == u'38;5;67')
    assert(parsecolor("gray7") == u'38;5;239')

    # Test the different invalid inputs, and make sure that they
    #