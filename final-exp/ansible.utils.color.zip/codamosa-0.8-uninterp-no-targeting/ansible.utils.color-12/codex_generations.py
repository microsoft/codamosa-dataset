

# Generated at 2022-06-21 08:11:52.780101
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color off
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(u"localhost", stats, False) == u"%-26s" % u"localhost"
    # Test with color on
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(u"localhost", stats, True) == u"\x1b[31m%-37s\x1b[0m" % u"localhost"



# Generated at 2022-06-21 08:12:00.301533
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0)) == "localhost                 "
    assert hostcolor("localhost", dict(failures=0, unreachable=1)) == "localhost                 "
    assert hostcolor("localhost", dict(failures=1, unreachable=0)) == "localhost                 "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=1)) == "localhost                 "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), False) == "localhost                 "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), False) == "localhost                 "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == "localhost                 "


# def color

# Generated at 2022-06-21 08:12:08.536848
# Unit test for function stringc
def test_stringc():
    """ Unit test for function stringc """
    # call the function
    s = stringc("hello world", "blue")
    # check the results
    assert type(s) == unicode
    #assert s == u'\x1b[34mhello world\x1b[0m' # not outputting unicode
    assert s == '\x1b[34mhello world\x1b[0m'


if __name__ == '__main__':
    test_stringc()
    # pretty - end
# --- end "pretty"

# Generated at 2022-06-21 08:12:13.308009
# Unit test for function colorize
def test_colorize():
    """Return verbose output for use with the '-v' option."""
    # Make these tests independent of locale. We may be running in a locale
    # that has multibyte characters and this can cause issues when running
    # inside the test suite.

    import locale
    import os
    try:
        c = locale.getpreferredencoding()
        os.environ['LC_ALL'] = 'C'
        reload(locale)
        locale.setlocale(locale.LC_ALL, 'C')
    except:
        pass
    old_lc_all = locale.getlocale(locale.LC_ALL)
    locale.setlocale(locale.LC_ALL, ('C', 'UTF-8'))

    s = colorize(u"foo", u"1", u"blue")

# Generated at 2022-06-21 08:12:14.780107
# Unit test for function stringc
def test_stringc():
    """
    >>> stringc("text", "blue")
    u'\\x1b[34mtext\\x1b[0m'
    >>> stringc("text", "black")
    u'\\x1b[30mtext\\x1b[0m'
    """



# Generated at 2022-06-21 08:12:17.948014
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'blue') == u'\033[94mtest\033[0m'
    assert stringc('test', 'black', True) == u'\001\033[30m\002test\001\033[0m\002'



# Generated at 2022-06-21 08:12:21.206003
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("31") == u'31'
    assert parsecolor("84") == u'38;5;84'
    assert parsecolor("rgb323") == u'38;5;208'
    assert parsecolor("gray3") == u'38;5;235'
# --- end of "pretty" library



# Generated at 2022-06-21 08:12:32.578516
# Unit test for function colorize
def test_colorize():
    assert ANSIBLE_COLOR
    assert colorize(u"foo", 0, None) == u"foo=0   "
    assert colorize(u"foo", 0, u"blue") == u"foo=0   "
    assert colorize(u"foo", 1, u"blue") == u'\033[94mfoo=-1  \033[0m'
    assert colorize(u"foo", 1, u"color1") == u'\033[38;5;1mfoo=-1  \033[0m'
    assert colorize(u"foo", 1, u"rgb150") == u'\033[38;5;66mfoo=-1  \033[0m'

# Generated at 2022-06-21 08:12:43.151144
# Unit test for function hostcolor
def test_hostcolor():
    from ansible import constants as C

    class FakeStats:
        def __init__(self, failures, unreachable, changed):
            self.failures = failures
            self.unreachable = unreachable
            self.changed = changed

    # Test if hostcolor is printed correctly for different cases
    # i.e. different values for stats['failed'], stats['unreachable'],
    # stats['changed'].
    host = 'localhost'
    stats = FakeStats(0, 0, 0)
    color_true = hostcolor(host, stats, True)
    color_false = hostcolor(host, stats, False)
    assert color_true.endswith(u'\033[0m')
    assert color_false.endswith(' ')

    stats = FakeStats(1, 0, 0)

# Generated at 2022-06-21 08:12:52.357492
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '34'
    assert parsecolor('bold blue') == '1;34'
    assert parsecolor('on_blue') == '44'
    assert parsecolor('bold on_blue') == '1;44'
    assert parsecolor('black') == '30'
    assert parsecolor('bold black') == '1;30'
    assert parsecolor('on_black') == '40'
    assert parsecolor('bold on_black') == '1;40'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color15') == '38;5;15'
    assert parsecolor('color16') == '38;5;16'
    assert par

# Generated at 2022-06-21 08:13:02.719755
# Unit test for function hostcolor
def test_hostcolor():
    # Tests whether the output of hostcolor is correctly colorized

    from ansible import constants as C
    from ansible.utils.color import AnsiColor
    from ansible.utils.display import Display

    class MockTerminal:
        def __init__(self, stream):
            self.stream = stream
            self.color = 0
            self.bold = 0

    class MockStdout:
        def __init__(self):
            self.buf = u''

        def write(self, text):
            self.buf += text

        def getvalue(self):
            return self.buf

        def isatty(self):
            return True

    def get_terminal_size():
        return (80, 24)

    display = Display()
    display.columns = get_terminal_size()[0]
    display.verb

# Generated at 2022-06-21 08:13:14.327550
# Unit test for function hostcolor

# Generated at 2022-06-21 08:13:20.696884
# Unit test for function colorize
def test_colorize():
    fail = False
    if colorize('a', 1, 'red') != u'a=1   ':
        fail = True
    if colorize('a', 1000, None) != u'a=1000':
        fail = True
    if colorize('b', 0, 'blue') != u'b=0   ':
        fail = True
    print('TEST: colorize: %s' % ('FAILED' if fail else 'ok'))


# Generated at 2022-06-21 08:13:26.471203
# Unit test for function colorize
def test_colorize():
    assert 'changed' in colorize('foo', 1, C.COLOR_CHANGED)
    assert 'ok' in colorize('foo', 0, C.COLOR_OK)
    assert 'error' in colorize('foo', 1, C.COLOR_ERROR)
    assert 'changed' in colorize('foo', 1, C.COLOR_CHANGED)

# Generated at 2022-06-21 08:13:38.514214
# Unit test for function colorize
def test_colorize():
    assert colorize('test', '1', 'green') == 'test=1   '
    assert colorize('test', '1', None) == 'test=1   '
    assert colorize('test', '0', 'green') == 'test=0   '
    assert colorize('test', '0', None) == 'test=0   '
    assert colorize('test', '-1', 'green') == 'test=-1  '
    assert colorize('test', '-1', None) == 'test=-1  '
    assert colorize('test', 'foobar', 'green') == 'test=foobar'
    assert colorize('test', 'foobar', None) == 'test=foobar'

# Generated at 2022-06-21 08:13:47.747370
# Unit test for function hostcolor
def test_hostcolor():
    test_stats = dict(failures=0, unreachable=0, changed=0)

    assert hostcolor("testhost1", test_stats) == u"testhost1                  "
    assert hostcolor("testhost2", dict(failures=1, unreachable=0, changed=0), True) == u"\x1b[31mtesthost2              \x1b[0m"
    assert hostcolor("testhost3", dict(failures=0, unreachable=1, changed=0), True) == u"\x1b[31mtesthost3              \x1b[0m"
    assert hostcolor("testhost4", dict(failures=0, unreachable=0, changed=1), True) == u"\x1b[33mtesthost4              \x1b[0m"


# Generated at 2022-06-21 08:14:00.066218
# Unit test for function stringc
def test_stringc():
    """Tests function stringc (colorize string)"""

    f = open('/tmp/ansible_stringc_test_output', 'w')
    f.write(stringc("Hello World\n", 'blue') + stringc("Hello World\n", 'red') + stringc("Hello World\n", 'green'))
    f.close()

    f = open('/tmp/ansible_stringc_test_output')
    output = f.read()
    f.close()

    assert output[0:12] == "\x1b[0;34mHello World"
    assert output[13:26] == "\x1b[0;31mHello World"
    assert output[27:40] == "\x1b[0;32mHello World"



# Generated at 2022-06-21 08:14:10.737849
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('lightblue') == '38;5;148'
    assert parsecolor('light yellow') == '38;5;178'
    assert parsecolor('nonexistent') == '38;5;208'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb255255255') == '38;5;15'
    assert parsecolor('rgb0255255') == '38;5;14'
    assert parsecolor('rgb000') == '38;5;0'
    assert parsecolor('rgb0') == '38;5;0'
    assert parsecolor('rgb555')

# Generated at 2022-06-21 08:14:17.789844
# Unit test for function stringc
def test_stringc():
    print(stringc("test", "green"))
    print(stringc("test", "red"))
    print(stringc("test", "blue"))
    print(stringc("test", "white"))

    print(stringc("test", "color4"))
    print(stringc("test", "color7"))
    print(stringc("test", "rgb101"))
    print(stringc("test", "rgb555"))
    print(stringc("test", "rgb333"))
    print(stringc("test", "rgb123"))
    print("*" * 40)
    print(stringc("test", "gray0"))
    print(stringc("test", "gray1"))
    print(stringc("test", "gray2"))
    print(stringc("test", "gray3"))

# Generated at 2022-06-21 08:14:27.423362
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '

    # ANSIBLE_COLOR is off and color is given
    assert colorize('foo', 0, C.COLOR_ERROR) == 'foo=0   '
    assert colorize('foo', 1, C.COLOR_ERROR) == 'foo=1   '

    # ANSIBLE_COLOR is on and color is None
    ANSIBLE_COLOR = True
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '

    # ANSIBLE_COLOR is on, color is given and num != 0
    old_ansible_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = True

# Generated at 2022-06-21 08:14:39.951877
# Unit test for function parsecolor
def test_parsecolor():
    import pytest
    assert parsecolor("red") == u'31'
    assert parsecolor("blue") == u'34'
    assert parsecolor("red") == u'31'
    assert parsecolor("color8") == u'38;5;8'
    assert parsecolor("color16") == u'38;5;16'
    assert parsecolor("color255") == u'38;5;255'
    assert parsecolor("rgb123") == u'38;5;123'
    with pytest.raises(KeyError):
        parsecolor("invalid")

# Generated at 2022-06-21 08:14:47.898641
# Unit test for function colorize
def test_colorize():
    color_codes = dict(
        C.COLOR_CODES,
        neutral=u'38;5;244',
        darkneutr=u'38;5;240',
    )
    test_data = (
        (u'ok', 0, u'neutral'),
        (u'changed', 12, u'changed'),
        (u'results', 0, None),
    )
    for lead, num, color in test_data:
        yield (colorize, lead, num, color_codes[color])

# Generated at 2022-06-21 08:14:57.943241
# Unit test for function colorize
def test_colorize():
    leads = [ u'ok', u'changed', u'unreachable', u'failed' ]
    nums  = [ 0, 1, 26, 3 ]
    colors = [ None, None, None, None ]

    for i in range(4):
        res = colorize(leads[i], nums[i], colors[i])
        if nums[i] != 0:
            res = u'%s=%s' % (leads[i], nums[i])
            if ANSIBLE_COLOR:
                res = u'%s=%s' % (leads[i], stringc(str(nums[i]), C.COLOR_OK))
        print('expected: %s' % res)


# Generated at 2022-06-21 08:15:03.505264
# Unit test for function colorize
def test_colorize():
    for color in [u'black', u'red', u'green', u'yellow', u'blue', u'magenta', u'cyan', u'white', u'black', u'black']:
        print(u"%sX" % colorize(color, u'XXX', True), end=u' ')
    print()


# --- end of "pretty" code



# Generated at 2022-06-21 08:15:10.554812
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black')   == 'foo=0   '
    assert colorize('foo', 1, 'black')   == u'foo=1   '
    assert colorize('foo', 2, 'red')     == u'foo=\u001b[31m2\u001b[0m '
    assert colorize('foo', 3, 'green')   == u'foo=\u001b[32m3\u001b[0m '
    assert colorize('foo', 4, 'yellow')  == u'foo=\u001b[33m4\u001b[0m '
    assert colorize('foo', 5, 'blue')    == u'foo=\u001b[34m5\u001b[0m '

# Generated at 2022-06-21 08:15:22.699147
# Unit test for function stringc
def test_stringc():
    # Test colorization
    assert stringc("test", "blue") == "\033[34mtest\033[0m"

    # Test state
    if ANSIBLE_COLOR:
        color = True
    else:
        color = False

    # Test black
    assert stringc("test", "black") == "\033[30mtest\033[0m" if color else "test"
    assert stringc("test", "black", wrap_nonvisible_chars=True) == "\001\033[30m\002test\001\033[0m\002" if color else "test"

    # Test red
    assert stringc("test", "red") == "\033[31mtest\033[0m" if color else "test"

# Generated at 2022-06-21 08:15:34.410206
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("33") == u'33'
    # assert parsecolor("fg-red") == u'31'
    # assert parsecolor("fg-33") == u'33'
    assert parsecolor("bg-red") == u'41'
    assert parsecolor("bg-33") == u'43'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("color33") == u'38;5;33'
    assert parsecolor("rgb123") == u'38;5;115'
    assert parsecolor("rgb333") == u'38;5;255'
    assert parsecolor("rgb123x") is None

# Generated at 2022-06-21 08:15:40.062632
# Unit test for function hostcolor
def test_hostcolor():
    hc_fail_unreach = hostcolor('testhost', {'failures': 1, 'unreachable': 1})
    hc_fail = hostcolor('testhost', {'failures': 1})
    hc_unreach = hostcolor('testhost', {'unreachable': 1})
    hc_ok_unreach = hostcolor('testhost', {'unreachable': 1}, color=False)
    assert hc_fail_unreach == u'\x1b[31;01mtesthost\x1b[0m         '
    assert hc_fail == u'\x1b[31;01mtesthost\x1b[0m               '
    assert hc_unreach == u'\x1b[31;01mtesthost\x1b[0m            '
    assert hc_

# Generated at 2022-06-21 08:15:51.566284
# Unit test for function parsecolor
def test_parsecolor():
    def eqcolor(color, sgrcolor):
        return eq(parsecolor(color), sgrcolor)
    eq(parsecolor('default'), u'39')
    eqcolor('color0', u'38;5;0')
    eqcolor('color1', u'38;5;1')
    eqcolor('color99', u'38;5;99')
    eqcolor('rgb123', u'38;5;123')
    eqcolor('rgb555', u'38;5;231')
    eqcolor('rgb555', u'38;5;231')
    eqcolor('rgb024', u'38;5;47')
    eqcolor('rgb000', u'38;5;16')
    eqcolor('rgb555', u'38;5;231')

# Generated at 2022-06-21 08:15:58.742597
# Unit test for function stringc
def test_stringc():
    """Test stringc function"""
    # test colors
    text = '''
teststring black
teststring red
teststring green
teststring yellow
teststring blue
teststring magenta
teststring cyan
teststring white
'''
    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        fmt = u"\033[%sm%%s\033[0m" % C.COLOR_CODES[color]
        assert (stringc('teststring ' + color, color) == fmt % ('teststring ' + color)) == ANSIBLE_COLOR

# Generated at 2022-06-21 08:16:14.895370
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u"31"
    assert parsecolor("blue") == u"34"
    assert parsecolor("on_red") == u"41"
    assert parsecolor("some_unknown_color") == u"30"
    assert parsecolor("color10") == u"38;5;10"
    assert parsecolor("rgb124") == u"38;5;70"
    assert parsecolor("rgb543") == u"38;5;111"
    assert parsecolor("rgb555") == u"38;5;15"
    assert parsecolor("rgb100") == u"38;5;60"
    assert parsecolor("gray0") == u"38;5;232"
    assert parsecolor("gray1") == u"38;5;233"

# Generated at 2022-06-21 08:16:23.668697
# Unit test for function colorize
def test_colorize():
    # Using assert_equal because it will show the diff that caused a failure.
    # Using assert_true or assert_false alone will just show a message.
    from nose.tools import assert_equal

    # colorize('msg', 0, 'blue') == 'msg=0   '
    s = colorize('msg', 0, 'blue')
    assert_equal(s, 'msg=0   ')
    # colorize('msg', 0, None) == 'msg=0   '
    s = colorize('msg', 0, None)
    assert_equal(s, 'msg=0   ')

    # colorize('msg', 1, 'blue') == 'msg=1   '
    s = colorize('msg', 1, 'blue')
    assert_equal(s, 'msg=1   ')
    # colorize('msg', 1

# Generated at 2022-06-21 08:16:32.611798
# Unit test for function hostcolor
def test_hostcolor():
    test_host = 'localhost'
    test_stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    # Test with ansible_nocolor set to True
    C.ANSIBLE_NOCOLOR = True
    result = hostcolor(test_host, test_stats, False)
    assert result == '%-26s' % test_host
    # Test with ansible_nocolor set to False
    C.ANSIBLE_NOCOLOR = False
    result = hostcolor(test_host, test_stats, False)
    assert result == '%-26s' % test_host
    # Test with ansible_nocolor set to False and color set to True
    result = hostcolor(test_host, test_stats, True)
    assert result == '%-26s' % test_host

# Generated at 2022-06-21 08:16:41.940774
# Unit test for function parsecolor

# Generated at 2022-06-21 08:16:52.581650
# Unit test for function parsecolor
def test_parsecolor():
    from nose.tools import assert_equals

    # Basic color names
    assert_equals(parsecolor('black'), '30')
    assert_equals(parsecolor('red'), '31')
    assert_equals(parsecolor('green'), '32')
    assert_equals(parsecolor('yellow'), '33')
    assert_equals(parsecolor('blue'), '34')
    assert_equals(parsecolor('magenta'), '35')
    assert_equals(parsecolor('cyan'), '36')
    assert_equals(parsecolor('white'), '37')

    # Extended color names
    assert_equals(parsecolor('brightgreen'), '92')
    assert_equals(parsecolor('brightyellow'), '93')

# Generated at 2022-06-21 08:16:57.250824
# Unit test for function stringc
def test_stringc():
    assert stringc("Hello", 'w') == u"\n".join([u"\033[1;37mHello\033[0m"])
    assert stringc("Hello", 'g') == u"\n".join([u"\033[1;32mHello\033[0m"])

# ---- end "pretty"


# Generated at 2022-06-21 08:17:03.268392
# Unit test for function hostcolor
def test_hostcolor():
    try:
        curses.setupterm()
        assert curses.tigetnum('colors') >= 8
    except:
        raise AssertionError()
    for color in [C.COLOR_CHANGED, C.COLOR_ERROR, C.COLOR_OK]:
        yield (check_hostcolor, u"myhost", {'nop': 0, 'changed': 0, 'dark': 0, 'failures': 0, 'ignored': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}, color)


# Generated at 2022-06-21 08:17:14.137088
# Unit test for function parsecolor
def test_parsecolor():
    print("Testing parsecolor()")
    assert parsecolor("blue") == u"34"
    assert parsecolor("red") == u"31"
    assert parsecolor("purple") == u"35"
    assert parsecolor("yellow") == u"33"
    assert parsecolor("green") == u"32"
    assert parsecolor("cyan") == u"36"
    assert parsecolor("color3") == u"38;5;3"
    assert parsecolor("color12") == u"38;5;12"
    assert parsecolor("color99") == u"38;5;99"
    assert parsecolor("rgb243") == u"38;5;102"
    assert parsecolor("rgb211") == u"38;5;90"

# Generated at 2022-06-21 08:17:26.332546
# Unit test for function parsecolor
def test_parsecolor():
    # predefined colors
    assert_parsecolor('red', 1)
    assert_parsecolor('green', 2)
    assert_parsecolor('bright green', 3)
    assert_parsecolor('yellow', 3)
    assert_parsecolor('blue', 4)
    assert_parsecolor('bright blue', 5)
    assert_parsecolor('magenta', 5)
    assert_parsecolor('cyan', 6)
    assert_parsecolor('bright cyan', 7)
    assert_parsecolor('white', 7)

    # color numbers
    assert_parsecolor('color0', 0)
    assert_parsecolor('color1', 1)
    assert_parsecolor('color9', 9)
    assert_parsecolor('color10', 10)

# Generated at 2022-06-21 08:17:37.874870
# Unit test for function parsecolor
def test_parsecolor():

    # Test that parsecolor returns the correct integer representation of the
    # given color string
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('brightblack') == u'38;5;240'
    assert parsecolor('darkgrey') == u'38;5;242'
    assert parsecolor('red') == u'38;5;124'
    assert parsecolor('brightred') == u'38;5;196'
    assert parsecolor('green') == u'38;5;28'
    assert parsecolor('brightgreen') == u'38;5;46'
    assert parsecolor('yellow') == u'38;5;208'
    assert parsecolor('brightyellow') == u'38;5;224'
    assert parsecolor('blue') == u

# Generated at 2022-06-21 08:17:53.005760
# Unit test for function hostcolor
def test_hostcolor():
    hc = hostcolor('localhost', dict(failures=1))
    assert hc == u"%-26s" % stringc('localhost', C.COLOR_ERROR)
    hc = hostcolor('localhost', dict(failures=0))
    assert hc == u"%-26s" % stringc('localhost', C.COLOR_OK)
    hc = hostcolor('localhost', dict(failures=0, changed=1))
    assert hc == u"%-26s" % stringc('localhost', C.COLOR_CHANGED)
    hc = hostcolor('localhost', dict(failures=0, unreachable=1))
    assert hc == u"%-26s" % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-21 08:18:00.126937
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        return
    import unittest
    from ansible.compat.tests import unittest
    from ansible.utils.color import stringc, colorize

    class TestSequenseFunctions(unittest.TestCase):

        def test_colorize(self):
            good = colorize('ok', 'green')
            self.assertEqual(good, u'\033[32mok=green\033[0m')

    unittest.main()

# end of pretty



# Generated at 2022-06-21 08:18:02.498016
# Unit test for function stringc
def test_stringc():
    assert stringc("Success!", "green") == "\033[32mSuccess!\033[0m"



# Generated at 2022-06-21 08:18:15.037980
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;196' == parsecolor(u'red')
    assert u'38;5;160' == parsecolor(u'color160')
    assert u'38;5;237' == parsecolor(u'gray7')
    assert u'38;5;115' == parsecolor(u'rgb400')
    assert u'38;5;118' == parsecolor(u'rgb403')
    assert u'38;5;194' == parsecolor(u'rgb442')
    assert u'38;5;215' == parsecolor(u'rgb522')
    assert u'38;5;240' == parsecolor(u'rgb555')
    assert u'38;5;250' == parsecolor(u'rgb565')


# end "pretty

# Generated at 2022-06-21 08:18:25.049561
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        ok=2,
        changed=0,
        unreachable=0,
        failures=0,
        skipped=0,
    )
    host = '127.0.0.1'
    assert hostcolor(host, stats) == '{0}'.format(host)
    stats = dict(
        ok=2,
        changed=1,
        unreachable=0,
        failures=0,
        skipped=0,
    )
    assert hostcolor(host, stats) == '{0}'.format(stringc(host, C.COLOR_CHANGED))
    stats = dict(
        ok=2,
        changed=0,
        unreachable=0,
        failures=1,
        skipped=0,
    )

# Generated at 2022-06-21 08:18:33.309078
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red1') == '31'
    assert parsecolor('green1') == '32'
    assert parsecolor('yellow1') == '33'
    assert parsecolor('blue1') == '34'
    assert parsecolor('magenta1') == '35'
    assert parsecolor('cyan1') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('bright red') == '91'
    assert parsecolor('bright green') == '92'
    assert parsecolor('bright yellow') == '93'
    assert parsecolor('bright blue') == '94'
    assert parsecolor('bright magenta') == '95'
    assert parsecolor('bright cyan') == '96'

# Generated at 2022-06-21 08:18:37.519085
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor('dummy1', dict(failures=0, unreachable=0, changed=0))
    hostcolor('dummy2', dict(failures=0, unreachable=0, changed=1))
    hostcolor('dummy3', dict(failures=1, unreachable=0, changed=0))
    hostcolor('dummy4', dict(failures=0, unreachable=1, changed=0))

# Generated at 2022-06-21 08:18:48.050970
# Unit test for function stringc
def test_stringc():
    from ansible.compat.tests import unittest

    class TestStringc(unittest.TestCase):
        def test_stringc(self):
            self.assertEqual(stringc(u"foo", u'blue'), u"\033[34mfoo\033[0m")
            self.assertEqual(stringc(u"foo", u'blue', True), u"\001\033[34m\002foo\001\033[0m\002")

    unittest.main()

# --- end "pretty"

# --- begin "commandline"

# commandline - A simple command line processor that allows the use of "--option value" arguments

# Generated at 2022-06-21 08:18:49.397781
# Unit test for function colorize
def test_colorize():
    # TODO: implement unit test
    return


# Generated at 2022-06-21 08:19:00.851750
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color34') == u'38;5;34'
    assert parsecolor('rgb123') == u'38;5;46'
    assert parsecolor('rgb543') == u'38;5;129'
    assert parsecolor('rgb321') == u'38;5;94'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('gray9') == u'38;5;241'
    assert parsecolor('gray10') == u'38;5;242'
   

# Generated at 2022-06-21 08:19:11.016628
# Unit test for function colorize
def test_colorize():
    from ansible.constants import *
    print("Basic Colors:")
    print(colorize("YELLOW", "foo", "yellow"))
    print(colorize("MAGENTA", "foo", "magenta"))
    print(colorize("BLUE", "foo", "blue"))
    print(colorize("CYAN", "foo", "cyan"))
    print(colorize("GREEN", "foo", "green"))
    print(colorize("WHITE", "foo", "white"))
    print("")
    print("Extended Colors:")
    print(colorize("DARK GRAY", "foo", "darkgray"))
    print(colorize("LIGHT BLUE", "foo", "lightblue"))
    print(colorize("LIGHT CYAN", "foo", "lightcyan"))

# Generated at 2022-06-21 08:19:15.276468
# Unit test for function colorize
def test_colorize():
    """$0 --colorize"""
    print(colorize('ok', 0, C.COLOR_OK))
    print(colorize('changed', 0, C.COLOR_CHANGED))
    print(colorize('unreachable', 0, C.COLOR_UNREACHABLE))
    print(colorize('failed', 0, C.COLOR_ERROR))
    print(colorize('ok', 1, C.COLOR_OK))
    print(colorize('changed', 2, C.COLOR_CHANGED))
    print(colorize('unreachable', 3, C.COLOR_UNREACHABLE))
    print(colorize('failed', 4, C.COLOR_ERROR))

# --- end "pretty" ---


# Generated at 2022-06-21 08:19:25.712479
# Unit test for function parsecolor
def test_parsecolor():
    def test_assert(name, result):
        if result == parsecolor(name):
            return True, ""

        return False, "Expected %s, got %s" % (result, parsecolor(name))


# Generated at 2022-06-21 08:19:38.368809
# Unit test for function stringc
def test_stringc():
    """Pretty Print"""

    # This doesn't actually test the color codes - it just tests to
    # make sure that the codes are inserted into the right place into
    # the string.

    test_string = 'This is a test string'

    c_red = u'\033[31m'
    c_green = u'\033[32m'
    c_yellow = u'\033[33m'
    c_end = u'\033[0m'

    assert stringc(test_string, 'red') == c_red + test_string + c_end
    assert stringc(test_string, 'green') == c_green + test_string + c_end
    assert stringc(test_string, 'yellow') == c_yellow + test_string + c_end


test_stringc()



# Generated at 2022-06-21 08:19:40.271519
# Unit test for function colorize
def test_colorize():
    colorize("message", 5, "red")

# end pretty

# Generated at 2022-06-21 08:19:46.756812
# Unit test for function stringc
def test_stringc():
    t = stringc("Test", "okgreen")
    assert t == '\x1b[32mTest\x1b[0m'
    t = stringc("Test", "Color256", wrap_nonvisible_chars=True)
    assert t == '\001\x1b[38;5;28m\002Test\001\x1b[0m\002'


# Generated at 2022-06-21 08:19:57.344911
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor("red") == "31")
    assert(parsecolor("blue") == "34")
    assert(parsecolor("green") == "32")
    assert(parsecolor("cyan") == "36")
    assert(parsecolor("magenta") == "35")
    assert(parsecolor("white") == "37")
    assert(parsecolor("black") == "30")
    assert(parsecolor("yellow") == "33")
    assert(parsecolor("brightred") == "91")
    assert(parsecolor("brightblue") == "94")
    assert(parsecolor("brightgreen") == "92")
    assert(parsecolor("brightcyan") == "96")
    assert(parsecolor("brightmagenta") == "95")

# Generated at 2022-06-21 08:20:01.439919
# Unit test for function colorize
def test_colorize():
    for color in C.COLOR_CODES:
        lead = u"LEAD"
        num = 0
        print(colorize(lead, num, color))
        num = 1
        print(colorize(lead, num, color))



# Generated at 2022-06-21 08:20:03.841180
# Unit test for function colorize
def test_colorize():
    """
    >>> print(colorize(u'ok', u'1', u'green'))
    ok=1
    >>> print(colorize(u'changed', u'2', u'yellow'))
    changed=2
    >>> print(colorize(u'unreachable', u'3', u'red'))
    unreachable=3
    >>> print(colorize(u'failed', u'4', u'red'))
    failed=4
    """



# Generated at 2022-06-21 08:20:15.353872
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(
        failures=0,
        unreachable=0,
        changed=0,
    )) == u'foo                          '
    assert hostcolor('foo', dict(
        failures=1,
        unreachable=0,
        changed=0,
    )) == stringc('foo                          ', C.COLOR_ERROR)
    assert hostcolor('foo', dict(
        failures=0,
        unreachable=1,
        changed=0,
    )) == stringc('foo                          ', C.COLOR_ERROR)
    assert hostcolor('foo', dict(
        failures=0,
        unreachable=0,
        changed=1,
    )) == stringc('foo                          ', C.COLOR_CHANGED)



# Generated at 2022-06-21 08:20:28.860298
# Unit test for function stringc
def test_stringc():
    assert stringc('some text', 'blue') == u"\033[34msome text\033[0m"
    assert stringc('some other text', 'black', wrap_nonvisible_chars=True) == \
        u'\001\033[30m\002some other text\001\033[0m\002'



# Generated at 2022-06-21 08:20:39.592822
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        print(u"--- ansible no color")
        return
    if C.ANSIBLE_NOCOLOR:
        return False
    print(u"--- ansible color")
    print(u"%-20s %s %s %s %s" %
          (u'HOST', u'RC', u'OK/CHG/FAI', u'WARN', u'DELTA'))
    print(u"%-20s %s %s %s %s" %
          (u'------------------------', u'---', u'------------', u'---', u'-----'))
    print(u"%-20s %s %s %s %s" %
          (u'bing', u'0', u'ok', u'0', u'0:00:01.42'))
    print

# Generated at 2022-06-21 08:20:46.600776
# Unit test for function hostcolor
def test_hostcolor():
    host = u'hostname'
    stats = {'changed': 0, 'failures': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == u'hostname                           '
    assert hostcolor(host, stats, False) == u'hostname                     '

    stats1 = {'changed': 2, 'failures': 0, 'unreachable': 0}
    assert hostcolor(host, stats1) == u'\x1b[0;34mhostname                 \x1b[0m'   # noqa

    stats2 = {'changed': 0, 'failures': 0, 'unreachable': 2}
    assert hostcolor(host, stats2) == u'\x1b[0;31mhostname                 \x1b[0m'   # noqa


# Generated at 2022-06-21 08:20:54.976353
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats) == u"localhost               "
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == u"localhost               "
    stats['failures'] = 1
    assert hostcolor('localhost', stats) == u"localhost               "
    stats['unreachable'] = 2
    assert hostcolor('localhost', stats) == u"localhost               "


# Generated at 2022-06-21 08:21:05.776575
# Unit test for function stringc
def test_stringc():
    import unittest
    import textwrap


# Generated at 2022-06-21 08:21:12.637583
# Unit test for function stringc
def test_stringc():
    tests = [('color', 'Blue', u'\x1b[34mBlue\x1b[0m'),
             ('rgb', 'rgb323', u'\x1b[38;5;59m323\x1b[0m'),
             ('gray', 'gray8', u'\x1b[38;5;250m8\x1b[0m'),
             ('nonexistent', 'nonexistent', u'nonexistent')]
    for test in tests:
        assert(stringc(test[1], test[0]) == test[2])


if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-21 08:21:16.488876
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 42, u"blue") == u"foo=42"
    assert colorize(u"foo", 0, u"blue") == u"foo=0"
    assert colorize(u"foo", 0, None) == u"foo=0"



# Generated at 2022-06-21 08:21:26.763836
# Unit test for function stringc
def test_stringc():
    assert stringc(u'foo', u'normal') == u'\033[0mfoo\033[0m'
    assert stringc(u'foo', u'red') == u'\033[31mfoo\033[0m'
    assert stringc(u'foo', u'green') == u'\033[32mfoo\033[0m'
    assert stringc(u'foo', u'yellow') == u'\033[33mfoo\033[0m'
    assert stringc(u'foo', u'blue') == u'\033[34mfoo\033[0m'
    assert stringc(u'foo', u'magenta') == u'\033[35mfoo\033[0m'

# Generated at 2022-06-21 08:21:34.994102
# Unit test for function hostcolor
def test_hostcolor():
    s = u"foobar"
    assert hostcolor(s, dict(failures=0, unreachable=0, changed=0)) == u"%-37s" % s
    assert hostcolor(s, dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc(s, C.COLOR_ERROR)
    assert hostcolor(s, dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc(s, C.COLOR_ERROR)
    assert hostcolor(s, dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc(s, C.COLOR_CHANGED)

# --- end "pretty"



# Generated at 2022-06-21 08:21:43.576961
# Unit test for function colorize
def test_colorize():
    assert colorize(u'foo', 10, u'blue') == u'foo=10  '
    assert colorize(u'foo', 0, u'blue') == u'foo=0   '
    assert colorize(u'foo', 0, None) == u'foo=0   '
    assert colorize(u'foo', 1, u'red') == 'foo=1   '
    assert colorize(u'foo', 100, u'green') == u'foo=100 '
    assert colorize(u'foo', 1000, u'green') == u'foo=1000'

