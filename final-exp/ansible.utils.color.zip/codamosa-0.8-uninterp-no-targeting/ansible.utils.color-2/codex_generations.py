

# Generated at 2022-06-21 08:11:57.904070
# Unit test for function hostcolor
def test_hostcolor():
    # pylint: disable=unused-variable
    class Host:
        def __init__(self, hostname):
            self.name = hostname

    class Play:
        def __init__(self, host, changed=0, failures=0, unreachable=0):
            self.host = host
            self.changed = changed
            self.failures = failures
            self.unreachable = unreachable

        def serialize(self):
            return {
                "host": self.host,
                "changed": self.changed,
                "failures": self.failures,
                "unreachable": self.unreachable
            }

    hosts = []
    for hostname in ("localhost", "127.0.1.1", "127.0.1.2", "127.0.1.3"):
        hosts

# Generated at 2022-06-21 08:12:01.727596
# Unit test for function colorize
def test_colorize():
    print(stringc(u"Test Message", u"blue"))
    print(colorize(u"Success", 0, u"green"))
    print(colorize(u"Failure", 1, u"red"))

if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-21 08:12:11.344826
# Unit test for function hostcolor
def test_hostcolor():
    host = u'test_host'
    for stats in [dict(failures=0, unreachable=0, changed=0),  # no color
                  dict(failures=0, unreachable=0, changed=1),  # changed
                  dict(failures=1, unreachable=1, changed=0),  # failed
                  ]:
        print(u"%s" % (repr(hostcolor(host, stats, True))))
        print(u"%s" % (repr(hostcolor(host, stats, False))))
        print(u"%s" % (repr(hostcolor(host, stats, None))))
    return

# --- end "pretty"

# Generated at 2022-06-21 08:12:19.933820
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == "34"
    assert parsecolor("red") == "31"
    assert parsecolor("green") == "32"
    assert parsecolor("yellow") == "33"
    assert parsecolor("pink") == "35"
    assert parsecolor("cyan") == "36"
    assert parsecolor("rgb255255255") == "37"
    assert parsecolor("rgb0255255") == "36"
    assert parsecolor("rgb255255255") == "37"
    assert parsecolor("rgb255255255") == "37"
    assert parsecolor("rgb255255255") == "37"
    assert parsecolor("rgb255255255") == "37"
    assert parsecolor("rgb255255255") == "37"


# Generated at 2022-06-21 08:12:31.048552
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""

    def assert_color(color, sgr):
        """Assert the SGR string for color value 'color'."""

        assert parsecolor(color) == sgr

    assert_color('black', u'30')
    assert_color('bright black', u'30;1')
    assert_color('red', u'31')
    assert_color('bright red', u'31;1')
    assert_color('green', u'32')
    assert_color('bright green', u'32;1')
    assert_color('yellow', u'33')
    assert_color('bright yellow', u'33;1')
    assert_color('blue', u'34')
    assert_color('bright blue', u'34;1')
    assert_color('magenta', u'35')
   

# Generated at 2022-06-21 08:12:40.135485
# Unit test for function colorize
def test_colorize():
    print(u'Test colorize')
    for color in C.COLOR_CODES:
        print(u'%s %s' % (colorize(u'VAR', color, color), colorize(u'', u'NORMAL', None)))

    if ANSIBLE_COLOR:
        print(stringc(u"This is %s!" % u'great', u'GREEN'))
        print(stringc(u"This is %s!" % u'phony', u'black'))
        print(stringc(u"This is %s!" % u'unknown', u'SpongeBob'))
        print(stringc(u"Current terminal appears to support 256 colors "
                      u"(%s)" % curses.tigetstr(b'tparm').decode(), u'GREEN'))

# Generated at 2022-06-21 08:12:47.537831
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=1)) == u'\x1b[31mhost                  \x1b[0m'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[32mhost                  \x1b[0m'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'\x1b[0mhost                  \x1b[0m'



# Generated at 2022-06-21 08:12:54.913452
# Unit test for function hostcolor
def test_hostcolor():
    assert u'\033[0;34mok\033[0m' == hostcolor('ok', dict(
            darkgreen=2, darkblue=2, green=2, blue=2, changed=0, unreachable=0, failures=0))
    assert u'\033[0;31mnot ok\033[0m' == hostcolor('not ok', dict(
            darkgreen=2, darkblue=2, green=2, blue=2, changed=0, unreachable=0, failures=2))
    assert u'\033[0;31mnot ok\033[0m' == hostcolor('not ok', dict(
        darkgreen=2, darkblue=2, green=2, blue=2, changed=0, unreachable=2, failures=0))

# Generated at 2022-06-21 08:13:06.860427
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo", {'failures': 1, 'unreachable': 1, 'changed': 1}, False) == "%-26s" % "foo"
    assert hostcolor("foo", {'failures': 1, 'unreachable': 1, 'changed': 1}, True) == u"\033[31mfoo\033[0m              "
    assert hostcolor("foo", {'failures': 1, 'unreachable': 1, 'changed': 0}, True) == u"\033[31mfoo\033[0m              "
    assert hostcolor("foo", {'failures': 0, 'unreachable': 0, 'changed': 1}, True) == u"\033[33mfoo\033[0m              "

# Generated at 2022-06-21 08:13:18.925880
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '34'
    assert parsecolor('bright blue') == '1;34'
    assert parsecolor('blink blue') == '5;34'
    assert parsecolor('black') == '30'
    assert parsecolor('on blue') == '44'
    assert parsecolor('underline blue') == '4;34'
    assert parsecolor('blink underline red') == '5;4;31'
    assert parsecolor('bright blink red') == '1;5;31'
    assert parsecolor('bright black') == '1;30'
    assert parsecolor('color12') == '38;5;12'
    assert parsecolor('rgb123') == '38;5;118'

# Generated at 2022-06-21 08:13:36.639504
# Unit test for function parsecolor
def test_parsecolor():
    def t(c, s):
        v = parsecolor(c)
        assert v == s
    t('black', '30')
    t('red', '31')
    t('green', '32')
    t('yellow', '33')
    t('blue', '34')
    t('magenta', '35')
    t('cyan', '36')
    t('white', '37')
    t('bright_black', '30;1')
    t('bright_red', '31;1')
    t('bright_green', '32;1')
    t('bright_yellow', '33;1')
    t('bright_blue', '34;1')
    t('bright_magenta', '35;1')
    t('bright_cyan', '36;1')

# Generated at 2022-06-21 08:13:46.710416
# Unit test for function stringc
def test_stringc():
    print(u"stringc():")
    print(stringc(u"black", u"black"))
    print(stringc(u"red", u"red"))
    print(stringc(u"green", u"green"))
    print(stringc(u"yellow", u"yellow"))
    print(stringc(u"blue", u"blue"))
    print(stringc(u"magenta", u"magenta"))
    print(stringc(u"cyan", u"cyan"))
    print(stringc(u"white", u"white"))
    print(stringc(u"BRIGHT BLACK", u"BRIGHT BLACK"))
    print(stringc(u"BRIGHT RED", u"BRIGHT RED"))
    print(stringc(u"BRIGHT GREEN", u"BRIGHT GREEN"))

# Generated at 2022-06-21 08:13:59.301247
# Unit test for function parsecolor
def test_parsecolor():
    print(u"Test parsecolor")
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'BLUE') == u'34'
    assert parsecolor(u'0') == u'30'
    assert parsecolor(u'1') == u'31'
    assert parsecolor(u'2') == u'32'
    assert parsecolor(u'3') == u'33'
    assert parsecolor(u'4') == u'34'
    assert parsecolor(u'5') == u'35'
    assert parsecolor(u'6') == u'36'
    assert parsecolor(u'7') == u'37'
    assert parsecolor(u'8') == u'38'

# Generated at 2022-06-21 08:14:01.591547
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)

    if hostcolor("srv.my.domain", stats, True) != u"\033[0;32msrv.my.domain\033[0m ":
        print("hostcolor() failed")



# Generated at 2022-06-21 08:14:12.260164
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'
# --- end of "pretty" code

# Generated at 2022-06-21 08:14:17.059940
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'blue', 'yellow', 'cyan', 'magenta'):
        print((colorize('foo', 42, c)))
    print((stringc('bar', 'blue')))

if __name__ == '__main__':
    test_colorize()

# --- end of "pretty"

# Generated at 2022-06-21 08:14:18.936342
# Unit test for function stringc
def test_stringc():
    print(stringc('this is red', 'RED'))

# --- end of pretty library



# Generated at 2022-06-21 08:14:26.595584
# Unit test for function stringc
def test_stringc():
    """Test ansible.utils.stringc()."""
    def _is_str(s):
        return isinstance(s, str)

    def _is_unicode(s):
        return isinstance(s, str)

    assert _is_str(stringc('foo', 'red'))
    assert _is_str(stringc('foo', 'red'))
    assert _is_str(stringc('foo', 'rgb255255255'))
    assert _is_str(stringc('foo', 'color255'))
    assert _is_str(stringc('foo', 'gray10'))



# Generated at 2022-06-21 08:14:34.726100
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('rgb555') == u'38;5;123'
    assert parsecolor('gray2') == u'38;5;234'
    assert parsecolor('red') == C.COLOR_CODES['red']


# Generated at 2022-06-21 08:14:43.250653
# Unit test for function stringc
def test_stringc():
    assert '\033[1;32mfoo\033[0m' == stringc('foo', 'green', False)
    assert '\033[1;32mfoo\033[0m' == stringc('foo', u'green', False)
    assert '\033[0;32mfoo\033[0m' == stringc('foo', 'lightgreen', False)
    assert '\033[0;32mfoo\033[0m' == stringc('foo', u'lightgreen', False)
    assert '\033[30;42mfoo\033[0m' == stringc('foo', 'blackonlightgreen', False)
    assert '\033[30;42mfoo\033[0m' == stringc('foo', u'blackonlightgreen', False)

# Generated at 2022-06-21 08:14:58.704154
# Unit test for function hostcolor
def test_hostcolor():
    stats_changed = dict(changed=1, unreachable=0, failures=0)
    stats_failure = dict(changed=0, unreachable=1, failures=1)
    stats_ok = dict(changed=0, unreachable=0, failures=0)

    # For now, just check that we get something back in color mode
    test_host = u"foobar.example.com"

    result = hostcolor(test_host, stats_changed, color=True)
    assert result != u"%-37s" % test_host
    result = hostcolor(test_host, stats_changed, color=False)
    assert result == u"%-37s" % test_host
    result = hostcolor(test_host, stats_failure, color=True)
    assert result != u"%-37s" % test_host
   

# Generated at 2022-06-21 08:15:08.461351
# Unit test for function colorize
def test_colorize():
    # Case; colorize is called with an invalid color
    lead = 'foo'
    num = 'bar'
    color = 'baz'
    colorize_result = colorize(lead, num, color)
    assert colorize_result == u"foo=bar ", colorize_result

    # Case; colorize is called with a valid color, no ANSIBLE_COLOR
    # and no color
    lead = 'foo'
    num = 'bar'
    color = None
    colorize_result = colorize(lead, num, color)
    assert colorize_result == u"foo=bar ", colorize_result

    # Case; colorize is called with a valid color and ANSIBLE_COLOR
    # and no color
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = 'True'
    lead = 'foo'


# Generated at 2022-06-21 08:15:20.503683
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == color(1)
    assert parsecolor('green') == color(2)
    assert parsecolor('yellow') == color(3)
    assert parsecolor('blue') == color(4)
    assert parsecolor('cyan') == color(6)
    assert parsecolor('white') == color(7)
    assert parsecolor('RANDOM') == color(8)
    assert parsecolor('rgb151') == color(rgb(1, 5, 1))
    assert parsecolor('rgb123') == color(rgb(1, 2, 3))
    assert parsecolor('gray1') == color(gray(1))
    assert parsecolor('gray10') == color(gray(10))
    assert parsecolor('gray15') == color(gray(15))
   

# Generated at 2022-06-21 08:15:32.197157
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('') == u'39', "Empty color should default to white"
    assert parsecolor('random') == u'39', "Unknown color should default to white"
    assert parsecolor('blue'), "blue color is missing?"
    assert parsecolor('lightblue') == "94", "lightblue color is missing?"
    assert parsecolor('red')
    assert parsecolor('lightred') == "91", "lightred color is missing?"
    assert parsecolor('green')
    assert parsecolor('lightgreen') == "92", "lightgreen color is missing?"
    assert parsecolor('yellow')
    assert parsecolor('lightyellow') == "93", "lightyellow color is missing?"
    assert parsecolor('cyan')

# Generated at 2022-06-21 08:15:39.056485
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test function for function parsecolor
    """
    # test color
    color = parsecolor("color232")
    assert color == "38;5;232", "Failed to convert  'color232' got '%s'" % color
    color = parsecolor("color20")
    assert color == "38;5;20", "Failed to convert  'color20' got '%s'" % color
    color = parsecolor("color206")
    assert color == "38;5;206", "Failed to convert  'color206' got '%s'" % color
    color = parsecolor("gray0")
    assert color == "38;5;232", "Failed to convert  'gray0' got '%s'" % color
    color = parsecolor("gray1")

# Generated at 2022-06-21 08:15:44.085493
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'yellow', 'blue', 'cyan', 'magenta', 'white'):
        print(colorize('  lead', 'num', c))

# end of pretty
# ---



# Generated at 2022-06-21 08:15:46.975878
# Unit test for function parsecolor
def test_parsecolor():
    if parsecolor('red') == u'38;5;1':
        return True
    else:
        return False

# --- end of "pretty" ---


# Generated at 2022-06-21 08:15:56.105326
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('bold_black') == u'30;1'
    assert parsecolor('bold_red') == u'31;1'
    assert parsecolor('bold_green') == u'32;1'
    assert parsecolor('bold_yellow') == u'33;1'

# Generated at 2022-06-21 08:16:04.960409
# Unit test for function parsecolor
def test_parsecolor():
    # the color names should match
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'

    # gray color
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('gray2') == u'38;5;234'

# Generated at 2022-06-21 08:16:16.251377
# Unit test for function stringc
def test_stringc():
    """Test function stringc"""
    testing = u"test"
    assert stringc(testing, u'black') == u"\033[30mtest\033[0m"
    assert stringc(testing, u'red') == u"\033[31mtest\033[0m"
    assert stringc(testing, u'red') == u"\033[31mtest\033[0m"
    assert stringc(testing, u'green') == u"\033[32mtest\033[0m"
    assert stringc(testing, u'yellow') == u"\033[33mtest\033[0m"
    assert stringc(testing, u'blue') == u"\033[34mtest\033[0m"

# Generated at 2022-06-21 08:16:31.049544
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=1, failures=1, unreachable=1)
    assert hostcolor("foo.example.org", stats, True) == u"\x1b[31mfoo.example.org\x1b[0m         "
    stats = dict(ok=1, failures=1, unreachable=1)
    assert hostcolor("foo.example.org", stats, False) == u"foo.example.org         "
    stats = dict(ok=1, changed=1)
    assert hostcolor("foo.example.org", stats, True) == u"\x1b[33mfoo.example.org\x1b[0m         "
    stats = dict(ok=1)

# Generated at 2022-06-21 08:16:32.974057
# Unit test for function colorize
def test_colorize():
    for i in range(-1, 2):
        print(u"%s" % colorize(u"test", i, u"red"), end=u'')


# Generated at 2022-06-21 08:16:34.453563
# Unit test for function stringc
def test_stringc():
    for k, v in C.COLOR_CODES.items():
        sys.stdout.write(stringc(u"%s" % k, k))

# Generated at 2022-06-21 08:16:37.087862
# Unit test for function colorize
def test_colorize():
    """Test colorize function"""
    items = [(2, C.COLOR_CHANGED),
             (0, C.COLOR_ERROR),
             (7, C.COLOR_OK),
             (0, None)]
    for (num, color) in items:
        yield colorize, 'test', num, color



# Generated at 2022-06-21 08:16:44.332492
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = {'failures': 1, 'ok': 5, 'changed': 0, 'skipped': 0, 'unreachable': 0}
    stats2 = {'failures': 0, 'ok': 4, 'changed': 1, 'skipped': 0, 'unreachable': 0}
    stats3 = {'failures': 0, 'ok': 4, 'changed': 0, 'skipped': 1, 'unreachable': 0}
    stats4 = {'failures': 0, 'ok': 4, 'changed': 0, 'skipped': 0, 'unreachable': 1}
    stats5 = {'failures': 0, 'ok': 4, 'changed': 0, 'skipped': 0, 'unreachable': 0}

    # With color

# Generated at 2022-06-21 08:16:54.100028
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        host = 'test_hostcolor'
        stats = {'failures': 0, 'unreachable': 0, 'ok': 1, 'skipped': 0, 'changed': 1}
        assert hostcolor(host, stats, color=True) == u"\033[32m%-37s\033[0m" % host

        stats = {'failures': 0, 'unreachable': 0, 'ok': 1, 'skipped': 0, 'changed': 0}
        assert hostcolor(host, stats, color=True) == u"\033[32m%-37s\033[0m" % host

        stats = {'failures': 1, 'unreachable': 0, 'ok': 0, 'skipped': 0, 'changed': 0}

# Generated at 2022-06-21 08:16:55.339021
# Unit test for function colorize
def test_colorize():
    return u"%-26s" % hostcolor(host, stats)

# Generated at 2022-06-21 08:16:58.031881
# Unit test for function stringc
def test_stringc():
    import doctest
    doctest.testmod()

# --- end "pretty"



# Generated at 2022-06-21 08:17:10.670896
# Unit test for function parsecolor
def test_parsecolor():
    def test(color, x):
        assert parsecolor(color)[-len(x):] == x

    test('red', '38;5;1')
    test('color1', '38;5;1')
    test('color9', '38;5;9')
    test('color10', '38;5;10')
    test('color15', '38;5;15')
    test('color255', '38;5;255')
    test('rgb555', '38;5;7')
    test('rgb333', '38;5;21')
    test('rgb000', '38;5;16')
    test('rgb123', '38;5;51')
    test('rgb321', '38;5;69')
    test('rgb321', '38;5;69')


# Generated at 2022-06-21 08:17:23.904997
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert u"a=1" == stringc(u"a=1", u'blue')
        assert u"\033[38;5;82ma=1  \033[0m" == stringc(u"a=1  ", u'blue')
        assert u"\033[38;5;82ma=1  \033[0m" == stringc(u"a=1  ", u'rgb332')
        assert u"\033[38;5;82ma=1  \033[0m" == stringc(u"a=1  ", u'color82')
        assert u"\033[38;5;82ma=1  \033[0m" == \
            colorize(u'a', 1, u'blue')

# Generated at 2022-06-21 08:17:39.704880
# Unit test for function hostcolor
def test_hostcolor():
    host = 'myhost'
    stats = dict(ok=1, failures=0, unreachable=0, skipped=0, changed=0)
    assert hostcolor(host, stats, color=True) == u'\u001b[32;1m%-37s\u001b[0m' % host

    host = 'myhost'
    stats = dict(ok=1, failures=1, unreachable=0, skipped=0, changed=0)
    assert hostcolor(host, stats, color=True) == u'\u001b[31;1m%-37s\u001b[0m' % host

    host = 'myhost'
    stats = dict(ok=1, failures=0, unreachable=0, skipped=0, changed=1)

# Generated at 2022-06-21 08:17:52.277138
# Unit test for function parsecolor
def test_parsecolor():
    """Ensure that we correctly parse color values."""
    assert parsecolor("color0") == "38;5;0"
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("color2") == "38;5;2"
    assert parsecolor("color3") == "38;5;3"
    assert parsecolor("color4") == "38;5;4"
    assert parsecolor("color5") == "38;5;5"
    assert parsecolor("color6") == "38;5;6"
    assert parsecolor("color7") == "38;5;7"
    assert parsecolor("color8") == "38;5;8"
    assert parsecolor("color9") == "38;5;9"

# Generated at 2022-06-21 08:17:59.093622
# Unit test for function hostcolor
def test_hostcolor():
    # Generate the actual output
    from ansible.utils.color import hostcolor
    actual = hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0})

    # Generate the desired output
    if ANSIBLE_COLOR:
        desired = 'localhost'.ljust(26) + '\x1b[0m'
    else:
        desired = 'localhost'.ljust(26)

    # Assert actual == desired
    assert actual == desired

# Generated at 2022-06-21 08:18:12.132737
# Unit test for function parsecolor
def test_parsecolor():
    from ansible.compat.tests import unittest
    class TestParseColor(unittest.TestCase):
        def test_valid_color(self):
            self.assertEqual(parsecolor('orange'), '38;5;208')

        def test_valid_color256(self):
            self.assertEqual(parsecolor('color123'), '38;5;123')

        def test_valid_rgb(self):
            # black
            self.assertEqual(parsecolor('rgb000'), '38;5;16')
            # white
            self.assertEqual(parsecolor('rgb555'), '38;5;231')
            # red
            self.assertEqual(parsecolor('rgb500'), '38;5;196')
            # green

# Generated at 2022-06-21 08:18:17.699371
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;0' == parsecolor('black')
    assert u'38;5;1' == parsecolor('red')
    assert u'38;5;2' == parsecolor('green')
    assert u'38;5;3' == parsecolor('yellow')
    assert u'38;5;4' == parsecolor('blue')
    assert u'38;5;5' == parsecolor('magenta')
    assert u'38;5;6' == parsecolor('cyan')
    assert u'38;5;7' == parsecolor('white')
    assert u'38;5;8' == parsecolor('color8')
    assert u'38;5;9' == parsecolor('color9')

# Generated at 2022-06-21 08:18:27.265206
# Unit test for function colorize
def test_colorize():
    """ test colorize function """
    from ansible.cli.playbook import PlaybookCLI
    p = PlaybookCLI(['ansible-playbook', '-h'])
    p.parse()
    c = p.base_parser._option_string_actions['--color'].default

    if ANSIBLE_COLOR:
        assert colorize('foo', 4, None) == u'foo=4   '
        assert colorize('foo', 0, 'blue') == u'foo=0   '
        assert colorize('foo', 4, 'blue') == u'\033[94mfoo=4   \033[0m'
        assert colorize('foo', 0, 'dark gray') == u'foo=0   '

# Generated at 2022-06-21 08:18:35.354306
# Unit test for function stringc

# Generated at 2022-06-21 08:18:41.653566
# Unit test for function stringc
def test_stringc():
    "Tests for class methods of stringc"
    # Set ANSIBLE_COLOR=1 in environment and test 24-bit color
    if ANSIBLE_COLOR:
        assert stringc("string", "blue") == u"\033[38;5;12mstring\033[0m"
        assert stringc("color234", "color234") == u"\033[38;5;234mcolor234\033[0m"
        assert stringc("rgbrgb555", "rgb555") == u"\033[38;5;231mrgbrgb555\033[0m"
        assert stringc("gray8", "gray8") == u"\033[38;5;244mgray8\033[0m"

# Generated at 2022-06-21 08:18:53.298444
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color99') == '38;5;99'
    assert parsecolor('color099') == '38;5;99'
    assert parsecolor('rgb255255255') == '38;5;15'
    assert parsecolor('rgb255255000') == '38;5;226'
    assert parsecolor('rgb000255000') == '38;5;46'
    assert parsecolor('rgb000255255') == '38;5;45'

# Generated at 2022-06-21 08:19:04.475443
# Unit test for function stringc
def test_stringc():

    assert(stringc('hello', 'blue') == '\033[34mhello\033[0m')
    assert(stringc('hello', '5') == '\033[38;5;5mhello\033[0m')
    assert(stringc('hello', 'rgb255') == '\033[38;5;9mhello\033[0m')
    assert(stringc('hello', 'rgb253') == '\033[38;5;7mhello\033[0m')
    assert(stringc('hello', 'rgb211') == '\033[38;5;12mhello\033[0m')
    assert(stringc('hello', 'rgb177') == '\033[38;5;28mhello\033[0m')

# Generated at 2022-06-21 08:19:25.083391
# Unit test for function hostcolor
def test_hostcolor():

    # Reference output -- ANSIBLE_COLOR on, color off
    assert(hostcolor("host.example.org", {"failures": 0, "unreachable": 0, "changed": 0}, color=False) == "host.example.org               ")
    assert(hostcolor("host.example.org", {"failures": 0, "unreachable": 0, "changed": 1}, color=False) == "host.example.org               ")
    assert(hostcolor("host.example.org", {"failures": 0, "unreachable": 1, "changed": 0}, color=False) == "host.example.org               ")
    assert(hostcolor("host.example.org", {"failures": 1, "unreachable": 0, "changed": 0}, color=False) == "host.example.org               ")

# Generated at 2022-06-21 08:19:37.201373
# Unit test for function parsecolor

# Generated at 2022-06-21 08:19:44.190246
# Unit test for function stringc
def test_stringc():
    text = stringc("hello world", "red")
    print(text)
    text = stringc("hello world", "rgb255255255")
    print(text)
    text = stringc("hello world", "white")
    print(text)
    text = stringc("hello world", "blue")
    print(text)
    text = stringc("hello world", "black")
    print(text)
    text = stringc("hello world", "green")
    print(text)
    text = stringc("hello world", "yellow")
    print(text)


if __name__ == "__main__":
    test_stringc()

# --- end of "pretty"

# Generated at 2022-06-21 08:19:54.927436
# Unit test for function hostcolor
def test_hostcolor():
    # Basic
    print(hostcolor('localhost', {'failures': 0, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}))
    print(hostcolor('localhost', {'failures': 0, 'changed': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}))
    print(hostcolor('localhost', {'failures': 1, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}))
    # Basic no-colors
    print(hostcolor('localhost', {'failures': 0, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}, False))

# Generated at 2022-06-21 08:20:06.161119
# Unit test for function parsecolor
def test_parsecolor():
    try:
        curses.setupterm()
        colors = [color.strip()
                  if color.strip() != 'default'
                  else 'white'
                  for color in curses.tigetstr('setaf').decode().split(';')]
    except Exception:
        colors = [color.strip()
                  if color.strip() != 'default'
                  else 'white'
                  for color in 'black red green yellow blue magenta cyan white'.split()]
    colors += ['rgb%d%d%d' % (r, g, b)
               for r in range(0, 6)
               for g in range(0, 6)
               for b in range(0, 6)]
    colors += ['color%d' % no for no in range(0, 256)]
    colors += ['default']


# Generated at 2022-06-21 08:20:17.365549
# Unit test for function stringc

# Generated at 2022-06-21 08:20:21.078004
# Unit test for function stringc
def test_stringc():
    text = 'foo'
    color_code = parsecolor('BLUE')

    if color_code:
        text = u"\033[%sm%s\033[0m" % (color_code, text)
    else:
        text = u"%s" % text

    print(text)

if __name__ == '__main__':
    test_stringc()

# --- end of pretty library

# Generated at 2022-06-21 08:20:33.836123
# Unit test for function colorize
def test_colorize():
    # just to be sure: without color
    ANSIBLE_COLOR = False
    assert colorize('a', 0, 'red') == u'a=0   '
    assert colorize('a', 10, 'red') == u'a=10  '
    assert colorize('a', 100, 'red') == u'a=100 '
    assert colorize('a', 1000, 'red') == u'a=1000'
    ANSIBLE_COLOR = True
    assert colorize('a', 0, 'red') == u'a=0   '
    assert colorize('a', 10, 'red') == u'a=10  '
    assert colorize('a', 100, 'red') == u'a=100 '
    assert colorize('a', 1000, 'red') == u'a=1000'
    #
    # Windows console

# Generated at 2022-06-21 08:20:43.104362
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'

    assert parsecolor('darkgray') == u'1;30'
    assert parsecolor('lightred') == u'1;31'
    assert parsecolor('lightgreen') == u'1;32'
    assert parsecolor('lightyellow') == u'1;33'
    assert parsecolor('lightblue') == u'1;34'


# Generated at 2022-06-21 08:20:55.481894
# Unit test for function stringc
def test_stringc():
    """Test function stringc"""

# Generated at 2022-06-21 08:21:13.272309
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('black') == u'30'
    assert parsecolor('blue') == u'34'
    assert parsecolor('reset') == u'0'
    assert parsecolor('brightpurple') == u'35;1'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb555') == u'38;5;23'
    assert parsecolor('rgb255') == u'38;5;15'
    assert parsecolor('rgb123') == u'38;5;11'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray7') == u'38;5;239'

# Generated at 2022-06-21 08:21:23.994051
# Unit test for function hostcolor
def test_hostcolor():
    ret = hostcolor('localhost', dict(ok=1, failures=0, unreachable=0,
                                      changed=0))
    assert ret == u'%-26s' % stringc('localhost', 'green')

    ret = hostcolor('localhost', dict(ok=0, failures=1, unreachable=0,
                                      changed=0))
    assert ret == u'%-26s' % stringc('localhost', 'red')

    ret = hostcolor('localhost', dict(ok=0, failures=0, unreachable=1,
                                      changed=0))
    assert ret == u'%-26s' % stringc('localhost', 'red')

    ret = hostcolor('localhost', dict(ok=0, failures=0, unreachable=0,
                                      changed=1))

# Generated at 2022-06-21 08:21:33.373237
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo',
                     dict(changed=0, failures=0, unreachable=0, ok=1),
                     color=True) == u'foo                              '

    assert hostcolor('foo.bar.baz',
                     dict(changed=1, failures=0, unreachable=0, ok=0),
                     color=True) == u'foo.bar.baz                       '

    assert hostcolor('foo.bar.baz',
                     dict(changed=0, failures=1, unreachable=0, ok=0),
                     color=True) == u'foo.bar.baz                       '

    assert hostcolor('foo.bar.baz',
                     dict(changed=0, failures=0, unreachable=1, ok=0),
                     color=True) == u'foo.bar.baz                       '

    assert hostcolor

# Generated at 2022-06-21 08:21:38.192828
# Unit test for function hostcolor
def test_hostcolor():

    from ansible.constants import COLOR_OK, COLOR_CHANGED, COLOR_ERROR
    from ansible.module_utils.six import PY3


# Generated at 2022-06-21 08:21:46.789215
# Unit test for function hostcolor
def test_hostcolor():
    # {} is an empty dictionary in Python
    # dictionary is a collection of key-value pairs
    stats = {}
    stats['failures']   = 1
    stats['unreachable'] = 0
    stats['changed']     = 0
    assert hostcolor('test', stats, True) == u"\033[91mtest\033[0m      "
    del stats['failures']
    stats['changed']     = 1
    assert hostcolor('test', stats, True) == u"\033[33mtest\033[0m      "
    del stats['changed']
    assert hostcolor('test', stats, True) == u"\033[92mtest\033[0m      "
    assert hostcolor('test', stats, False) == u"test                "

# --- end pretty

