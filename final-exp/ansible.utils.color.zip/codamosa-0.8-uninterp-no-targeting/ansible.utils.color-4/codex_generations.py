

# Generated at 2022-06-21 08:11:55.947977
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue", False) == u'\033[34mfoo\033[0m'
    assert stringc("foo\nbar", "blue", False) == u'\033[34mfoo\nbar\033[0m'
    assert stringc("foo", "blue") == u'\001\033[34m\002foo\001\033[0m\002'
    assert stringc("foo\nbar", "blue") == u'\001\033[34m\002foo\nbar\001\033[0m\002'
    assert stringc("foo", "rgb255255255", False) == u'\033[38;5;15mfoo\033[0m'

# Generated at 2022-06-21 08:12:01.954621
# Unit test for function colorize
def test_colorize():
    failed = "\033[91m=FAILED!\033[0m"
    passed = "\033[92m=PASSED\033[0m"
    skipped = "\033[93m-SKIPPED\033[0m"
    if colorize("TEST", "FAILED!", "red") != failed:
        print("failed: colorize(\"TEST\", \"FAILED!\", \"red\") != " + failed)
        return False
    if colorize("TEST", "PASSED", "green") != passed:
        print("failed: colorize(\"TEST\", \"PASSED\", \"green\") != " + passed)
        return False

# Generated at 2022-06-21 08:12:13.426068
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color on
    assert hostcolor(u"test.example.com",
                     dict(failures=1, unreachable=0, changed=0),
                     True) == u"%-37s" % stringc(u"test.example.com", C.COLOR_ERROR)
    assert hostcolor(u"test.example.com",
                     dict(failures=0, unreachable=0, changed=1),
                     True) == u"%-37s" % stringc(u"test.example.com", C.COLOR_CHANGED)
    assert hostcolor(u"test.example.com",
                     dict(failures=0, unreachable=0, changed=0),
                     True) == u"%-37s" % stringc(u"test.example.com", C.COLOR_OK)
    # Test with color off


# Generated at 2022-06-21 08:12:20.832555
# Unit test for function stringc

# Generated at 2022-06-21 08:12:26.608633
# Unit test for function stringc
def test_stringc():
    print(stringc('foo', 'blue'))
    print(stringc('foo', 'red'))
    print(stringc('foo', 'green'))
    print(stringc('foo', 'yellow'))
    print(stringc('foo', 'purple'))
    print(stringc('foo', 'cyan'))
    print(stringc('foo', 'white', wrap_nonvisible_chars=True))

# Generated at 2022-06-21 08:12:37.398972
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("blue") == u'34'
    assert parsecolor("green") == u'32'
    assert parsecolor("1") == u'38;5;1'
    assert parsecolor("10") == u'38;5;10'
    assert parsecolor("100") == u'38;5;100'
    assert parsecolor("100") == u'38;5;100'
    assert parsecolor("rgb000") == u'30'
    assert parsecolor("rgb111") == u'38;5;18'
    assert parsecolor("rgb222") == u'38;5;27'
    assert parsecolor("rgb123") == u'38;5;36'

# Generated at 2022-06-21 08:12:43.744345
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "black", wrap_nonvisible_chars=False) == u'\033[30mfoo\033[0m'
    assert stringc("foo", "black", wrap_nonvisible_chars=True) == u'\x01\033[30m\x02foo\x01\033[0m\x02'
    assert stringc("foo", "red", wrap_nonvisible_chars=False) == u'\033[31mfoo\033[0m'
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u'\x01\033[31m\x02foo\x01\033[0m\x02'

# Generated at 2022-06-21 08:12:52.778753
# Unit test for function stringc
def test_stringc():
    """Function stringc() test."""
    assert stringc(u"My string", u"red") == u'\x1b[31mMy string\x1b[0m'
    assert stringc(u"My string", u"red", wrap_nonvisible_chars=True) == u'\001\x1b[31m\002My string\001\x1b[0m\002'
    assert stringc(u"My string", u"color333") == u'\x1b[38;5;333mMy string\x1b[0m'
    assert stringc(u"My string", u"color333", wrap_nonvisible_chars=True) == u'\001\x1b[38;5;333m\002My string\001\x1b[0m\002'
    assert string

# Generated at 2022-06-21 08:13:05.511848
# Unit test for function colorize
def test_colorize():
    """ Test the colorize() function """
    lead = "test"
    num  = 4
    color_exp = "test=4"
    color = None
    color_act = colorize(lead, num, color)
    assert color_exp == color_act

    color_exp = "\033[32mtest=4\033[0m"
    color = "green"
    color_act = colorize(lead, num, color)
    assert color_exp == color_act

    lead = "test"
    num  = 0
    color_exp = "test=0"
    color = None
    color_act = colorize(lead, num, color)
    assert color_exp == color_act

    color_exp = "test=0"
    color = "green"

# Generated at 2022-06-21 08:13:13.929835
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert '\x1b[0;31m' in hostcolor('foo', dict(unreachable=1, failures=0, skipped=0, changed=1))
        assert '\x1b[0;32m' in hostcolor('foo', dict(unreachable=1, failures=0, skipped=0, changed=0))
        assert '\x1b[0;33m' in hostcolor('foo', dict(unreachable=0, failures=1, skipped=0, changed=1))



# Generated at 2022-06-21 08:13:33.388901
# Unit test for function stringc
def test_stringc():
    print(stringc("foo", color="blue", wrap_nonvisible_chars=False))
    print(stringc("bar", color="black on_white", wrap_nonvisible_chars=False))
    print(stringc("foo", color="blue", wrap_nonvisible_chars=True))
    print(stringc("bar", color="black on_white", wrap_nonvisible_chars=True))
    print(stringc("#ANSIBLECTL[500]", color="blue", wrap_nonvisible_chars=True))


if __name__ == "__main__":
    test_stringc()
# --- end "pretty"

# Generated at 2022-06-21 08:13:44.804096
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('default') == '39'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'

# Generated at 2022-06-21 08:13:55.971245
# Unit test for function colorize
def test_colorize():
    # Tests that colorize works
    print(u"\n===TESTING COLORS===")
    for color in C.COLOR_STATUS:
        print(u"Testing Color: " + color)
        print(u"changed: " + colorize(u'changed', 1, color))
        print(u"failed: " + colorize(u'failed', 1, color))
        print(u"skipped: " + colorize(u'skipped', 1, color))
        print(u"unreachable: " + colorize(u'unreachable', 1, color))
        print(u"ok: " + colorize(u'ok', 1, color))


# Generated at 2022-06-21 08:13:59.345803
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        ok=2,
        changed=0,
        unreachable=0,
        failures=1,
        skipped=0,
        rescued=0,
        ignored=0
    )
    print(hostcolor("localhost", stats))
    stats['failures'] = 0
    stats['changed'] = 1
    print(hostcolor("localhost", stats))
    stats['changed'] = 0
    print(hostcolor("localhost", stats))

# -----------------------------------------------------------------------------
# --- end of "pretty" library
# -----------------------------------------------------------------------------

# Generated at 2022-06-21 08:14:02.685158
# Unit test for function colorize
def test_colorize():
    c = colorize(u"", 0, C.COLOR_SKIP)
    assert c == "=0   "
    c = colorize(u"", 10, C.COLOR_SKIP)
    assert c == "=10  "
    c = colorize(u"", 100, C.COLOR_SKIP)
    assert c == "=100 "
    c = colorize(u"", 1000, C.COLOR_SKIP)
    assert c == "=1000"



# Generated at 2022-06-21 08:14:12.852088
# Unit test for function stringc
def test_stringc():
    print(stringc("This is an important message", "white"))
    print(stringc("This is a critical error message", "red", wrap_nonvisible_chars=True))
    print(stringc("This is an important message", "yellow"))
    print(stringc("This is a %s message" % ("debug"), "blue"))
    print(stringc("This is a %s message" % ("debug"), "blue", wrap_nonvisible_chars=True))
    print(stringc("This is a %s message" % ("debug"), "color10"))
    print(stringc("This is a %s message" % ("debug"), "rgb255000255"))
    print(stringc("This is a %s message" % ("debug"), "gray3"))

# --- end of "pretty"

# ansible-test
AT_P

# Generated at 2022-06-21 08:14:23.373046
# Unit test for function hostcolor
def test_hostcolor():
    h = "testhostname.example.com"

# Generated at 2022-06-21 08:14:32.082684
# Unit test for function stringc
def test_stringc():
    # Just assert that ansible.constants.COLOR_CODES matches the output of parsecolor
    for color in C.COLOR_CODES.keys():
        assert stringc(parsecolor(color), color) == u"\033[%sm%s\033[0m" % (C.COLOR_CODES[color], color)
        assert stringc(u"test", color) == u"\033[%smtest\033[0m" % C.COLOR_CODES[color]

# --- end "pretty"


# Generated at 2022-06-21 08:14:41.878774
# Unit test for function parsecolor
def test_parsecolor():
    # Valid cases
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('rgb123') == u'38;5;124'
    assert parsecolor('rgb000') == u'38;5;0'
    assert parsecolor('gray0') == u'38;5;0'
    assert parsecolor('gray7') == u'38;5;234'

    # Invalid cases
    assert parsecolor('black1') is None
    assert parsecolor('color-1') is None
    assert parsecolor('rgb') is None
    assert parsecolor('rgba') is None
    assert parsecolor('rgb0') is None

# Generated at 2022-06-21 08:14:54.150991
# Unit test for function hostcolor
def test_hostcolor():
    stats_ok = dict(ok=10, failures=0, unreachable=0, changed=0)

    result = hostcolor('host_ok', stats_ok, color=False)
    assert result == "%-26s" % 'host_ok'
    result = hostcolor('host_ok', stats_ok, color=True)
    assert result == u"%-37s" % 'host_ok'

    stats_changed = dict(ok=10, failures=0, unreachable=0, changed=99)

    result = hostcolor('host_changed', stats_changed, color=False)
    assert result == "%-26s" % 'host_changed'
    result = hostcolor('host_changed', stats_changed, color=True)

# Generated at 2022-06-21 08:15:14.596244
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"foo.example.org", dict(changes=0, unreachable=0, failures=0), True) == u"%-37s" % stringc(u"foo.example.org", C.COLOR_OK)
    assert hostcolor(u"foo.example.org", dict(changes=1, unreachable=0, failures=0), True) == u"%-37s" % stringc(u"foo.example.org", C.COLOR_CHANGED)
    assert hostcolor(u"foo.example.org", dict(changes=0, unreachable=1, failures=0), True) == u"%-37s" % stringc(u"foo.example.org", C.COLOR_ERROR)

# Generated at 2022-06-21 08:15:25.578735
# Unit test for function parsecolor

# Generated at 2022-06-21 08:15:33.881174
# Unit test for function hostcolor
def test_hostcolor():

    print(u'Testing function hostcolor')

    test_host = u'hostname'
    test_stats = {'ok': 10}
    test_color = None
    print(hostcolor(test_host, test_stats, test_color))

    test_host = u'hostname'
    test_stats = {'ok': 10, 'changed': 0}
    test_color = None
    print(hostcolor(test_host, test_stats, test_color))

    test_host = u'hostname'
    test_stats = {'ok': 0, 'changed': 5}
    test_color = None
    print(hostcolor(test_host, test_stats, test_color))

    test_host = u'hostname'
    test_stats = {'ok': 5, 'changed': 10}
    test_

# Generated at 2022-06-21 08:15:39.876956
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('dark red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('dark green') == '32'
    assert parsecolor('brown') == '33'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('dark blue') == '34'
    assert parsecolor('dark cyan') == '36'
    assert parsecolor('dark magenta') == '35'
    assert parsecolor('light gray') == '37'
    assert parsecolor('light grey') == '37'
    assert parsecolor('bright red') == '1;31'
    assert parsecolor('bright green') == '1;32'
    assert par

# Generated at 2022-06-21 08:15:51.567019
# Unit test for function colorize
def test_colorize():
    # test if no ANSIBLE_COLOR works
    global ANSIBLE_COLOR
    backup_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    eq_(colorize("a", "1", None), "a=1   ")
    eq_(colorize("longer", "1", None), "longer=1   ")
    # test without color and without stats
    ANSIBLE_COLOR = True
    eq_(colorize("a", "1", None), "a=1   ")
    eq_(colorize("longer", "1", None), "longer=1   ")
    # test with color and without stats
    eq_(colorize("a", "1", 'blue'), u'a=1   ')

# Generated at 2022-06-21 08:16:02.155695
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('testhost', dict(
        failures=0, unreachable=0, changed=0), color=False) == 'testhost'
    assert hostcolor('testhost', dict(
        failures=0, unreachable=0, changed=0), color=True) == u'\033[0;32mtesthost\033[0m'
    assert hostcolor('testhost', dict(
        failures=1, unreachable=0, changed=0), color=True) == u'\033[0;31mtesthost\033[0m'
    assert hostcolor('testhost', dict(
        failures=0, unreachable=1, changed=0), color=True) == u'\033[0;31mtesthost\033[0m'

# Generated at 2022-06-21 08:16:14.479870
# Unit test for function hostcolor
def test_hostcolor():
    host = 'host'
    stats1 = dict(ok=1, failures=1, unreachable=0, changed=0, skipped=0)
    stats2 = dict(ok=1, failures=0, unreachable=1, changed=0, skipped=0)
    stats3 = dict(ok=1, failures=0, unreachable=0, changed=1, skipped=0)
    stats4 = dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0)
    assert 'host\033[0;31m' in hostcolor(host, stats1)
    assert 'host\033[0;31m' in hostcolor(host, stats2)
    assert 'host\033[0;33m' in hostcolor(host, stats3)
    assert 'host\033[0;32m' in host

# Generated at 2022-06-21 08:16:25.120725
# Unit test for function parsecolor
def test_parsecolor():
    # Test some basic colors
    assert parsecolor('black') == '38;5;16'
    assert parsecolor('blue') == '38;5;4'
    assert parsecolor('cyan') == '38;5;6'
    assert parsecolor('green') == '38;5;2'
    assert parsecolor('magenta') == '38;5;5'
    assert parsecolor('red') == '38;5;1'
    assert parsecolor('white') == '38;5;15'
    assert parsecolor('yellow') == '38;5;3'
    # Test gray colors
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'

# Generated at 2022-06-21 08:16:30.901587
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize(u"foo", 4, C.COLOR_CHANGED)
    u'foo=4   '

    >>> colorize(u"foo", 1, C.COLOR_ERROR)
    u'foo=1   '

    >>> colorize(u"foo", 3, C.COLOR_OK)
    u'foo=3   '

    >>> colorize(u"foo", 0, C.COLOR_SKIPPED)
    u'foo=0   '
    """



# Generated at 2022-06-21 08:16:40.814828
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black1') == '38;5;232'
    assert parsecolor('black2') == '38;5;233'
    assert parsecolor('black3') == '38;5;234'
    assert parsecolor('black4') == '38;5;235'
    assert parsecolor('black5') == '38;5;236'
    assert par

# Generated at 2022-06-21 08:16:57.664856
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('RED') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('GReeN') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('BLUe') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('YELLOW') == '33'
    assert parsecolor('cyan') == '36'
    assert parsecolor('CYAN') == '36'
    assert parsecolor('magenta') == '35'
    assert parsecolor('MAGENTA') == '35'

    assert parsecolor('color1') == '38;5;1'

# Generated at 2022-06-21 08:17:05.513626
# Unit test for function hostcolor
def test_hostcolor():
    # These tests assume ANSIBLE_COLOR is True
    assert hostcolor('localhost', {'ok': 1, 'changed': 0, 'unreachable': 0, 'skipped': 0, 'failed': 0}) == 'localhost'.encode('utf-8')

    assert hostcolor('localhost', {'ok': 0, 'changed': 0, 'unreachable': 0, 'skipped': 0, 'failed': 0}) == 'localhost'.encode('utf-8')

    assert hostcolor('localhost', {'ok': 1, 'changed': 1, 'unreachable': 0, 'skipped': 0, 'failed': 0}) == '\x1b[0;34mlocalhost\x1b[0m'.encode('utf-8')


# Generated at 2022-06-21 08:17:11.344434
# Unit test for function colorize
def test_colorize():
    c1 = colorize('foo', 0, 'blue')
    assert c1 == "foo=0   ", "colorize(%r) == %r" % ('foo=0   ', c1)
    c2 = colorize('foo', 2, 'blue')
    assert c2 != "foo=2   ", "colorize(%r) != %r" % ('foo=2   ', c2)



# Generated at 2022-06-21 08:17:18.697370
# Unit test for function stringc
def test_stringc():
    # TODO: add a test for color 16-231 (the 6x6x6 color cube)
    codes = [0, 1, 4, 7, 8, 30, 31, 32, 33, 34, 35, 36, 37, 39,
             40, 41, 42, 43, 44, 45, 46, 47, 90, 91, 92, 93, 94, 95,
             96, 97, 100, 101, 104, 107, 108,
             130, 131, 132, 133, 134, 135, 136, 137, 139,
             140, 141, 142, 143, 144, 145, 146, 147, 190, 191, 192, 193, 194,
             195, 196, 197, 200, 201, 204, 207, 208]

# Generated at 2022-06-21 08:17:29.705723
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return
    assert u"\033[31mtest\033[0m" == stringc(u"test", u"RED", wrap_nonvisible_chars=False)
    assert u"\033[31mtest\033[0m" == stringc(u"test", u"1;31", wrap_nonvisible_chars=False)
    assert u"\033[31mtest\033[0m" == stringc(u"test", u"31", wrap_nonvisible_chars=False)
    assert u"\033[1;31mtest\033[0m" == stringc(u"test", u"1;31", wrap_nonvisible_chars=True)

# Generated at 2022-06-21 08:17:33.290684
# Unit test for function parsecolor
def test_parsecolor():
    print("***Testing parsecolor***")
    # color
    print("Testing %s" % stringc("color0", "color0"))
    print("Testing %s" % stringc("color1", "color1"))
    print("Testing %s" % stringc("color2", "color2"))
    print("Testing %s" % stringc("color3", "color3"))
    print("Testing %s" % stringc("color4", "color4"))
    print("Testing %s" % stringc("color5", "color5"))
    print("Testing %s" % stringc("color6", "color6"))
    print("Testing %s" % stringc("color7", "color7"))
    # rgb
    print("Testing %s" % stringc("rgb000", "rgb000"))

# Generated at 2022-06-21 08:17:41.656178
# Unit test for function colorize
def test_colorize():
    # Light Grey
    assert colorize(u"lead", u"num", u"color0") == u'lead=num '
    # Dark Grey
    assert colorize(u"lead", u"num", u"color7") == u'lead=num '
    # Blue
    assert colorize(u"lead", u"num", u"color12") == u'lead=num '
    # Light Red
    assert colorize(u"lead", u"num", u"color9") == u'lead=num '
    # Orange
    assert colorize(u"lead", u"num", u"color172") == u'lead=num '

# --- end "pretty"
#
# ANSIBALLZ



# Generated at 2022-06-21 08:17:54.517719
# Unit test for function parsecolor
def test_parsecolor():
    if parsecolor('color1') != u'38;5;1':
        return False
    if parsecolor('rgb123') != u'38;5;56':
        return False
    if parsecolor('rgb111') != u'38;5;16':
        return False
    if parsecolor('rgb255') != u'38;5;231':
        return False
    if parsecolor('rgb256') != u'38;5;231':
        return False
    if parsecolor('rgb000') != u'38;5;232':
        return False
    if parsecolor('gray0') != u'38;5;232':
        return False
    if parsecolor('gray1') != u'38;5;233':
        return False

# Generated at 2022-06-21 08:17:58.770945
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 42
    color = 'blue'
    s = colorize(lead, num, color)
    print("colorize returned '%s'" % s)
    # should print: 'foo=42' in blue (or nothing if no ANSI color)


# Generated at 2022-06-21 08:18:05.079185
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb255000') == '38;5;9'
    assert parsecolor('gray8') == '38;5;240'
    assert parsecolor('gray0') == '38;5;232'



# Generated at 2022-06-21 08:18:19.196545
# Unit test for function parsecolor
def test_parsecolor():
    """ Unit test for function parsecolor """
    assert parsecolor("red") == u'31', "Expect red"
    assert parsecolor("RED") == u'31', "Expect RED"
    assert parsecolor("38;5;7") == u'38;5;7', "Expect 38;5;7"
    assert parsecolor("color07") == u'38;5;7', "Expect color07"
    assert parsecolor("rgb333") == u'38;5;60', "Expect rgb333"
    assert parsecolor("gray8") == u'38;5;244', "Expect gray8"
    assert parsecolor("gray55") == u'38;5;250', "Expect gray55"

# Generated at 2022-06-21 08:18:23.960341
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "color3") == u"\033[38;5;51mtext\033[0m"
    assert stringc("text", "rgb222") == u"\033[38;5;18mtext\033[0m"
    assert stringc("text", "rgb123") == u"\033[38;5;33mtext\033[0m"
    assert stringc("text", "rgb333") == u"\033[38;5;63mtext\033[0m"
    assert stringc("text", "rgb000") == u"\033[38;5;16mtext\033[0m"
    assert stringc("text", "rgb111") == u

# Generated at 2022-06-21 08:18:32.157145
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("") == ""

    assert parsecolor("color0") == "38;5;0"
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("color2") == "38;5;2"
    assert parsecolor("color3") == "38;5;3"
    assert parsecolor("color4") == "38;5;4"
    assert parsecolor("color5") == "38;5;5"
    assert parsecolor("color6") == "38;5;6"
    assert parsecolor("color7") == "38;5;7"
    assert parsecolor("color8") == "38;5;8"
    assert parsecolor("color9") == "38;5;9"

    assert parsecolor("color00")

# Generated at 2022-06-21 08:18:39.745057
# Unit test for function parsecolor
def test_parsecolor():
    from nose.plugins.skip import SkipTest

    supported_colors = (
        'black', 'darkgray',
        'red', 'lightred',
        'green', 'lightgreen',
        'brown', 'yellow',
        'blue', 'lightblue',
        'purple', 'pink', 'lightpurple',
        'cyan', 'lightcyan',
    )

    # Test a few colors
    colors = ['color1', 'color', 'rgb125']
    expected = ['38;5;1', '38;5;8', '38;5;21']
    for color, exp in zip(colors, expected):
        actual = parsecolor(color)
        assert actual == exp,  \
            'Invalid SGR parameter, expected %s, got %s' \
            % (exp, actual)

   

# Generated at 2022-06-21 08:18:51.894028
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor("blue") == "34")
    assert(parsecolor("red") == "31")
    assert(parsecolor("blue_background") == "44")
    assert(parsecolor("red_background") == "41")
    assert(parsecolor("white_background") == "47")
    assert(parsecolor("color1") == "38;5;1")
    assert(parsecolor("rgb255255255") == "38;5;255")
    assert(parsecolor("rgb0255255") == "38;5;6")
    assert(parsecolor("rgb255255255") == "38;5;255")
    assert(parsecolor("rgb0255255") == "38;5;6")

# Generated at 2022-06-21 08:18:55.130700
# Unit test for function colorize
def test_colorize():

    color = 'red'
    lead = 'testing'
    num = '0'
    result = u'testing=0'

    assert colorize(lead, num, color) == result


# --- end of "pretty" library


# Generated at 2022-06-21 08:19:06.322930
# Unit test for function stringc
def test_stringc():
    """Test for function stringc()."""
    # When ANSIBLE_COLOR is False, do not add color markup.
    ANSIBLE_COLOR = False
    assert stringc(u"test", u"red") == u"test"

    # When ANSIBLE_COLOR is True and name is a known color name, add SGR
    # parameter markup.
    ANSIBLE_COLOR = True
    ansi_red = u"\033[41mtest\033[0m"
    assert stringc(u"test", u"red") == ansi_red

    # When ANSIBLE_COLOR is True and name is an unknown color name, print it
    # literally.
    ansi_foo = u"\033[foo]test\033[0m"
    assert stringc(u"test", u"foo") == ansi_foo

# Generated at 2022-06-21 08:19:18.144243
# Unit test for function colorize
def test_colorize():
    # Check colorize without color
    ANSIBLE_COLOR = False
    assert colorize(u"lead", 0, C.COLOR_ERROR) == u"lead=0   "
    assert colorize(u"lead", 1234, C.COLOR_ERROR) == u"lead=1234"
    # Check colorize with color
    ANSIBLE_COLOR = True
    assert colorize(u"lead", 0, C.COLOR_ERROR) == u"lead=0   "
    assert colorize(u"lead", 1234, C.COLOR_ERROR) == u"lead=1234"
    # Check colorize with color and color
    assert colorize(u"lead", 0, C.COLOR_CHANGED) == u"lead=0   "

# Generated at 2022-06-21 08:19:20.458822
# Unit test for function stringc
def test_stringc():
    print(stringc('foo', 'magenta', wrap_nonvisible_chars=True))



# Generated at 2022-06-21 08:19:28.540080
# Unit test for function hostcolor
def test_hostcolor():
    host = "testhost"
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-26s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 1}
    assert hostcolor(host, stats, True) == u"%-26s" % stringc(host, C.COLOR_ERROR)
    assert hostcolor(host, stats, False) == u"%-26s" % host
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-26s" % stringc(host, C.COLOR_ERROR)

# Generated at 2022-06-21 08:19:45.794035
# Unit test for function stringc
def test_stringc():
    assert stringc("blah", "green") == "\033[32mblah\033[0m"


# --- end "pretty"

args = dict()
args['up'] = C.UP_CHAR
args['down'] = C.DOWN_CHAR
args['skipped'] = colorize(u"Skipped", 0, None)
args['black'] = C.COLOR_BLACK
args['darkgray'] = C.COLOR_DARKGRAY
args['lightgray'] = C.COLOR_LIGHTGRAY
args['white'] = C.COLOR_WHITE
args['red'] = C.COLOR_RED
args['lightred'] = C.COLOR_LIGHTRED
args['green'] = C.COLOR_GREEN
args['lightgreen'] = C.COLOR_LIGHTGREEN
args['yellow'] = C.COLOR_YELLOW
args

# Generated at 2022-06-21 08:19:54.927895
# Unit test for function stringc
def test_stringc():
    """Internal test for stringc"""
    tests = [
        ('color', parsecolor('color1')),
        ('color', parsecolor('color9')),
        ('color', parsecolor('color11')),
        ('color', parsecolor('color232')),
        ('rgb', parsecolor('rgb555')),
        ('rgb', parsecolor('rgb123')),
        ('rgb', parsecolor('rgb333')),
        ('gray', parsecolor('gray0')),
        ('gray', parsecolor('gray7')),
        ('gray', parsecolor('gray15')),
    ]
    for t in tests:
        print(t)
        assert parsecolor(t[0]) == t[1]

# --- end "pretty"

# Generated at 2022-06-21 08:20:06.160516
# Unit test for function hostcolor
def test_hostcolor():
    _ansible_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    stats_green = {'failures': 0, 'unreachable': 0, 'changed': 0}
    stats_yellow = {'failures': 0, 'unreachable': 0, 'changed': 1}
    stats_red = {'failures': 1, 'unreachable': 2, 'changed': 0}

    assert hostcolor('testHost', stats_green) == u'\033[0;32m%-37s\033[0m' % (u'testHost')
    assert hostcolor('testHost', stats_yellow) == u'\033[0;33m%-37s\033[0m' % (u'testHost')

# Generated at 2022-06-21 08:20:12.871723
# Unit test for function colorize
def test_colorize():
    assert colorize('test', '5', 'red') == u"\033[31mtest=5   \033[0m"
    assert colorize('test', '0', 'green') == u"\033[32mtest=0   \033[0m"
    assert colorize('test', '-9', 'green') == u"\033[32mtest=-9  \033[0m"



# Generated at 2022-06-21 08:20:21.047334
# Unit test for function parsecolor
def test_parsecolor():
    # Standard XTerm/ANSI Colors (0-7)
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'

    # Extended XTerm/ANSI Colors (0-255)
    assert parsecolor('gray0') == u'38;5;0'
    assert parsecolor('red1') == u'38;5;1'

# Generated at 2022-06-21 08:20:31.887959
# Unit test for function stringc
def test_stringc():
    assert(stringc('\x1b[1;31mfoo\x1b[0m', 'RED', True) == u"\x1b[1;31mfoo\x1b[0m")
    assert(stringc('\x1b[1;31mfoo\x1b[0m', 'RED', False) == u"foo")
    for color in [u"RED", u"GREEN", u"YELLOW"]:
        assert(stringc('foo', color, True) == u"\x1b[31mfoo\x1b[0m")
    assert(stringc(u'foo', u'bogus', True) == u"foo")



# Generated at 2022-06-21 08:20:41.880556
# Unit test for function colorize
def test_colorize():
    return True
# --- end "pretty"

if __name__ == "__main__":
    print(u"\nUNIT TESTING: %s" % __file__)
    print(u"pretty.py:parsecolor(\"white\") = %s" % parsecolor(u"white"))
    print(u"pretty.py:parsecolor(\"green\") = %s" % parsecolor(u"green"))
    print(u"pretty.py:parsecolor(\"green3\") = %s" % parsecolor(u"green3"))
    print(u"pretty.py:parsecolor(\"rgb255255255\") = %s" % parsecolor(u"rgb255255255"))

# Generated at 2022-06-21 08:20:54.275209
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('none')         == u''
    assert parsecolor('black')        == u'30'
    assert parsecolor('red')          == u'31'
    assert parsecolor('green')        == u'32'
    assert parsecolor('yellow')       == u'33'
    assert parsecolor('blue')         == u'34'
    assert parsecolor('magenta')      == u'35'
    assert parsecolor('cyan')         == u'36'
    assert parsecolor('white')        == u'37'
    assert parsecolor('reset')        == u'0'
    assert parsecolor('bold')         == u'1'
    assert parsecolor('dark')         == u'2'
    assert parsecolor('underline')    == u'4'
    assert par

# Generated at 2022-06-21 08:21:02.404886
# Unit test for function hostcolor
def test_hostcolor():
    import os, sys, subprocess

    cmd = [sys.executable, os.path.join(os.path.dirname(__file__), 'test_utils.py')]
    res = subprocess.check_output(cmd)
    assert u"OK       127.0.0.1" in res.decode('utf-8')
    assert u"CHANGED  example.com" in res.decode('utf-8')
    assert u"FAILED   notthere.example.com" in res.decode('utf-8')

# --- end "pretty"

# Generated at 2022-06-21 08:21:07.097701
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'normal') == 'foo=0   '
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 10, 'normal') == 'foo=10  '
    assert colorize('foo', 10, 'blue') == 'foo=10  '


# End of pretty
######################################################################

# Generated at 2022-06-21 08:21:26.493500
# Unit test for function stringc
def test_stringc():
    if sys.version_info < (3, 0):
        assert(stringc('foo', 'blue') == '\033[34mfoo\033[0m')
    else:
        assert(stringc('foo', 'blue') == '\033[34mfoo\033[0m')

# Colorize the entire line ('prefix: suffix' part) based on the JSON return result
# prefix = the first part of the line, usually a play or task name
# result = the return result from the JSON dump
# diff = None/True/False. If None, use the diff setting from the config
# indents = string, add indents to this line
# line_prefix = string, adds prefix to the beginning of the line (e.g. 'TASK [')
# wrap_nonvisible_chars = whether to wrap non-visible characters with \001 \

# Generated at 2022-06-21 08:21:30.435175
# Unit test for function colorize
def test_colorize():
    #setup for colored output

    # Color is supported
    ANSIBLE_COLOR = True

    # Color is not supported
    ANSIBLE_COLOR = False


if __name__ == '__main__':
    test_colorize()

# --- end "pretty"

# Generated at 2022-06-21 08:21:44.306522
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return

    host = u"Test Host"

    stats = dict(failures=0, unreachable=0, changed=0)
    colorized_host = hostcolor(host, stats)
    assert unicode.find(colorized_host, C.COLOR_OK) > -1

    stats = dict(failures=1, unreachable=0, changed=0)
    colorized_host = hostcolor(host, stats)
    assert unicode.find(colorized_host, C.COLOR_ERROR) > -1

    stats = dict(failures=0, unreachable=1, changed=0)
    colorized_host = hostcolor(host, stats)
    assert unicode.find(colorized_host, C.COLOR_ERROR) > -1
