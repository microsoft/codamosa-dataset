

# Generated at 2022-06-11 17:45:14.367466
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor(u'red') == '31'
    assert parsecolor('yellow') == '33'
    assert parsecolor('bold red') == '1;31'
    assert parsecolor('on_grey') == '40'
    assert parsecolor('unknown_color') == '39'
    assert parsecolor('on red') == '41'
    assert parsecolor('on_yellow') == '43'
    assert parsecolor('on_bold red') == '1;41'
    assert parsecolor('on_bold yellow') == '1;43'
    assert parsecolor('on grey') == '100'
    assert parsecolor('on_grey') == '40'
    assert parsecolor('dark red') == '31'
    assert parsec

# Generated at 2022-06-11 17:45:23.240654
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), color=True) == stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), color=False) == "localhost"
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), color=True) == stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), color=True) == stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), color=True) == stringc("localhost", C.COLOR_ERROR)
    # In case of

# Generated at 2022-06-11 17:45:35.539386
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('dark red') == u'38;5;1'
    assert parsecolor('green') == u'38;5;35'
    assert parsecolor('dark green') == u'38;5;22'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('dark yellow') == u'38;5;11'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('dark blue') == u'38;5;20'
    assert parsecolor('magenta') == u'38;5;5'

# Generated at 2022-06-11 17:45:44.557673
# Unit test for function hostcolor
def test_hostcolor():
    failed = dict(darkred='\033[31;1m', lightred='\033[31;2m', darkyellow='\033[33;1m', lightyellow='\033[33;2m')
    changed = dict(darkgreen='\033[32;1m', lightgreen='\033[32;2m', darkblue='\033[34;1m', lightblue='\033[34;2m')
    unreachable = dict(darkred='\033[31;1m', lightred='\033[31;2m', darkgray='\033[30;1m', lightgray='\033[30;2m')

# Generated at 2022-06-11 17:45:52.765043
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('testhost', {'failures': 0, 'unreachable': 0, 'skipped': 0, 'changed': 0}, color=True))
    print(hostcolor('testhost', {'failures': 0, 'unreachable': 0, 'skipped': 0, 'changed': 1}, color=True))
    print(hostcolor('testhost', {'failures': 1, 'unreachable': 0, 'skipped': 0, 'changed': 0}, color=True))
    print(hostcolor('testhost', {'failures': 0, 'unreachable': 1, 'skipped': 0, 'changed': 0}, color=True))
    print(hostcolor('testhost', {'failures': 0, 'unreachable': 0, 'skipped': 0, 'changed': 0}, color=False))

# Generated at 2022-06-11 17:46:00.505279
# Unit test for function parsecolor
def test_parsecolor():
    print(u"Parsecolor - simple color")
    assert parsecolor(u"blue") == u"34"

    print(u"Parsecolor - rgb color")
    assert parsecolor(u"rgb123") == u"38;5;90"

    print(u"Parsecolor - gray color")
    assert parsecolor(u"gray5") == u"38;5;238"

    print(u"Parsecolor - color number")
    assert parsecolor(u"color10") == u"38;5;10"



# Generated at 2022-06-11 17:46:11.704801
# Unit test for function hostcolor
def test_hostcolor():
    assert "%-37s" % hostcolor('a.example.com',
                               {'skipped': 0, 'failures': 0, 'ok': 1,
                                'changed': 0, 'unreachable': 0}) == \
           "a.example.com                 "
    assert "%-37s" % hostcolor('b.example.com',
                               {'skipped': 0, 'failures': 0, 'ok': 0,
                                'changed': 1, 'unreachable': 0}) == \
           u"b.example.com               \u001b[0;34m\u002b\u001b[0m"

# Generated at 2022-06-11 17:46:16.423963
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('myhost.mydomain', {'skipped': 0, 'failed': 0, 'changed': 1, 'ok': 10, 'unreachable': 0}, True))
    # output: 'myhost.mydomain                '
# end of "pretty"



# Generated at 2022-06-11 17:46:24.854470
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("black") == u'30'
    assert parsecolor("red") == u'31'
    assert parsecolor("green") == u'32'
    assert parsecolor("yellow") == u'33'
    assert parsecolor("blue") == u'34'
    assert parsecolor("magenta") == u'35'
    assert parsecolor("cyan") == u'36'
    assert parsecolor("white") == u'37'
    assert parsecolor("rgb123") == u'38;5;50'
    assert parsecolor("rgb321") == u'38;5;19'
    assert parsecolor("rgb113") == u'38;5;36'
    assert parsecolor("rgb000") == u'38;5;16'
    assert parsecolor

# Generated at 2022-06-11 17:46:32.943090
# Unit test for function stringc
def test_stringc():
    """Tests the function stringc"""
    def test_foreground():
        """Tests the foreground colors"""
        foregrounds = {'black': u"\033[30mblack\033[0m",
                       'red': u"\033[31mred\033[0m",
                       'green': u"\033[32mgreen\033[0m",
                       'yellow': u"\033[33myellow\033[0m",
                       'blue': u"\033[34mblue\033[0m",
                       'magenta': u"\033[35mmagenta\033[0m",
                       'cyan': u"\033[36mcyan\033[0m",
                       'white': u"\033[37mwhite\033[0m"}


# Generated at 2022-06-11 17:46:47.952386
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    stats_changed = {'failures': 0, 'unreachable': 0, 'changed': 1}
    stats_fail = {'failures': 1, 'unreachable': 0, 'changed': 0}
    stats_unreach = {'failures': 0, 'unreachable': 1, 'changed': 0}
    stats_fail_unreach = {'failures': 1, 'unreachable': 1, 'changed': 0}
    stats_all = {'failures': 1, 'unreachable': 1, 'changed': 1}

    assert(hostcolor(host, stats) == u'localhost              ')

# Generated at 2022-06-11 17:46:56.880142
# Unit test for function stringc
def test_stringc():
    # Test all names
    for color in C.COLOR_CODES:
        yield do_test_stringc, color, "test", color
    # Test color numbers
    for n in range(0, 256):
        yield do_test_stringc, "color%d" % n, "test", "color%d" % n
    # Test rgb colors
    for r in range(0, 6):
        for g in range(0, 6):
            for b in range(0, 6):
                yield do_test_stringc, "rgb%d%d%d" % (r, g, b), "test", "rgb%d%d%d" % (r, g, b)
    # Test grayscale

# Generated at 2022-06-11 17:46:58.354988
# Unit test for function stringc
def test_stringc():
    print(stringc('hello world', 'red'))


# ---- end "pretty"

# Generated at 2022-06-11 17:47:05.559143
# Unit test for function hostcolor
def test_hostcolor():
    # Set up some mock stats data
    stats = {}
    stats['changed'] = 0
    stats['failures'] = 0
    stats['ok'] = 5
    stats['skipped'] = 0
    stats['unreachable'] = 0

    # Reset ANSIBLE_COLOR to True
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # Test a host with all OK stats
    host = 'localhost'
    assert hostcolor(host, stats) == u"\x1b[0;32m%-37s\x1b[0m" % host

    # Test a host with changed stats
    stats['changed'] = 1
    assert hostcolor(host, stats) == u"\x1b[0;33m%-37s\x1b[0m" % host

    # Test a host with failures and unre

# Generated at 2022-06-11 17:47:11.321962
# Unit test for function stringc
def test_stringc():
    """stringc test"""
    print(stringc("%s -- %s" % ("this is a test", "this is only a test"), "blue"))
    print(stringc("%s -- %s" % ("this is a test", "this is only a test"), "red"))


if __name__ == "__main__":
    test_stringc()

# --- end "pretty"

# Generated at 2022-06-11 17:47:20.569300
# Unit test for function parsecolor
def test_parsecolor():
    # Valid
    assert parsecolor("red") == u'31'
    assert parsecolor("green") == u'32'
    assert parsecolor("yellow") == u'33'
    assert parsecolor("blue") == u'34'
    assert parsecolor("cyan") == u'36'
    assert parsecolor("magenta") == u'35'
    assert parsecolor("white") == u'97'
    assert parsecolor("black") == u'30'
    assert parsecolor("color0") == u'38;5;0'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("color2") == u'38;5;2'
    assert parsecolor("color3") == u'38;5;3'
    assert parsecolor

# Generated at 2022-06-11 17:47:31.646532
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('www.example.com', dict(failures=0, unreachable=0, ok=1, changed=0)) == hostcolor('www.example.com', dict(failures=0, unreachable=0, ok=1, changed=0), color=False)
    assert hostcolor('www.example.com', dict(failures=0, unreachable=0, ok=0, changed=1)) == hostcolor('www.example.com', dict(failures=0, unreachable=0, ok=0, changed=1), color=False)
    assert hostcolor('www.example.com', dict(failures=0, unreachable=1, ok=0, changed=0)) != hostcolor('www.example.com', dict(failures=0, unreachable=1, ok=0, changed=0), color=False)
   

# Generated at 2022-06-11 17:47:44.631104
# Unit test for function stringc
def test_stringc():
    """Pretty Print - Testing."""
    from ansible.compat.tests import unittest

    @unittest.skipUnless(ANSIBLE_COLOR, "terminal does not support color")
    class TestColor(unittest.TestCase):
        """Test class for function stringc()."""

        def test_return_value_type(self):
            """Test return value is unicode."""
            self.assertIsInstance(stringc('foo', color='red'), unicode)

        def test_return_value_format_string(self):
            """Test return value is a formatted string."""
            self.assertRegexpMatches(stringc('foo', color='red'),
                                     r'^\x1b\[\d+;\d+mfoo\x1b\[0m$')


# Generated at 2022-06-11 17:47:51.184741
# Unit test for function colorize
def test_colorize():
    from ansible.utils.color import colorize, stringc, hostcolor
    from ansible.constants import COLOR_NOCOLOR, COLOR_CHANGED, COLOR_OK
    assert 'k=0   ' == colorize('k', 0, None)
    assert 'k=' + stringc('0', COLOR_NOCOLOR) == colorize('k', 0, COLOR_NOCOLOR)
    assert 'k=' + stringc('1', COLOR_CHANGED) == colorize('k', 1, COLOR_CHANGED)
    assert 'k=' + stringc('1', COLOR_OK) == colorize('k', 1, COLOR_OK)
    assert hostcolor('foo', {}, False) == '%-26s' % 'foo'

# Generated at 2022-06-11 17:47:59.399772
# Unit test for function stringc
def test_stringc():
    print(stringc('test', 'green'))
    print(stringc('test', 'color3'))
    print(stringc('test', 'color9'))
    print(stringc('test', 'color11'))
    print(stringc('test', 'color19'))
    print(stringc('test', 'color232'))
    print(stringc('test', 'color255'))
    print(stringc('test', 'rgb123'))
    print(stringc('test', 'rgb321'))
    print(stringc('test', 'rgb213'))
    print(stringc('test', 'rgb231'))
    print(stringc('test', 'rgb312'))
    print(stringc('test', 'rgb132'))

# Generated at 2022-06-11 17:48:11.903616
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "black") == u"\033[30mfoo\033[0m"
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-11 17:48:21.128169
# Unit test for function stringc
def test_stringc():
    msg1 = "this is an info"
    msg2 = "this is an error"

    print("C.COLOR_OK='%s'" % C.COLOR_OK)
    print("COLOR_CHANGED='%s'" % C.COLOR_CHANGED)
    print("COLOR_ERROR='%s'" % C.COLOR_ERROR)
    print("COLOR_SKIP='%s'" % C.COLOR_SKIP)
    print("COLOR_UNREACHABLE='%s'" % C.COLOR_UNREACHABLE)
    print("COLOR_WARN='%s'" % C.COLOR_WARN)

    print(stringc(msg1, C.COLOR_OK))
    print(stringc(msg2, C.COLOR_ERROR))
    print(stringc(msg2, 'blink'))

# Generated at 2022-06-11 17:48:32.771562
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 1, 'green') == 'lead=1   '
    assert colorize('lead', 0, 'green') == 'lead=0   '
    assert colorize('lead', -1, 'green') == 'lead=-1  '
    assert colorize('lead', 'foo', 'green') == 'lead=foo '
    assert colorize('lead', 123456789, 'green') == 'lead=123456789'


# --- end "pretty"

# --- begin "terminal"
#
# Terminal - A pretty output class for colorizing text and formatting with
#            indentation and alignment for readable output. This code is
#            public domain - there is no license except that you must leave
#            this header.
#
# Copyright (C) 2008 Brian Nez <thedude at bri1 dot com>



# Generated at 2022-06-11 17:48:43.862140
# Unit test for function hostcolor
def test_hostcolor():
    from ansible import constants as C
    from ansible.utils.color import hostcolor

    stats = {'changed': 0, 'failures': 0, 'skipped': 0, 'ok': 1}
    wrong_hostcolor = 'hostname                          '
    correct_hostcolor = u'hostname                          '
    if ANSIBLE_COLOR:
        correct_hostcolor = stringc(correct_hostcolor, C.COLOR_OK)
    assert hostcolor('hostname', stats) == correct_hostcolor

    stats = dict(skipped=0, ok=0, changed=1, unreachable=0, failures=0)
    wrong_hostcolor = 'hostname                          '
    correct_hostcolor = u'hostname                          '

# Generated at 2022-06-11 17:48:52.153861
# Unit test for function stringc
def test_stringc():
    assert stringc('hello world', 'green') == '\033[32mhello world\033[0m'
    assert stringc('hello world', 'color256') == '\033[38;5;256mhello world\033[0m'
    assert stringc('hello world', 'rgb255000') == '\033[38;5;202mhello world\033[0m'
    assert stringc('hello world', 'gray15') == '\033[38;5;247mhello world\033[0m'



# Generated at 2022-06-11 17:48:53.818181
# Unit test for function hostcolor
def test_hostcolor():
    assert 1000 == len(hostcolor('a' * 1000, {}))

# --- end "pretty"



# Generated at 2022-06-11 17:49:03.668731
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 2, 'yellow') == 'changed=2'
    assert colorize('dark', 3, 'darkgray') == 'dark=3 '
    assert colorize('aborted', 255, 'red') == 'aborted=255'

    assert colorize('ok', 0, None) == 'ok=0   '
    assert colorize('changed', 2, None) == 'changed=2'
    assert colorize('dark', 3, None) == 'dark=3 '
    assert colorize('aborted', 255, None) == 'aborted=255'

test_colorize()

# Generated at 2022-06-11 17:49:11.314181
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"host1", dict(ok=1, changed=0, unreachable=0, failed=0)) == u"host1                 "
    assert hostcolor(u"host2", dict(ok=0, changed=1, unreachable=0, failed=0)) == u"host2                 "
    assert hostcolor(u"host3", dict(ok=0, changed=0, unreachable=1, failed=0)) == u"host3                 "
    assert hostcolor(u"host4", dict(ok=0, changed=0, unreachable=0, failed=1)) == u"host4                 "

# --- end "pretty"


# Generated at 2022-06-11 17:49:21.898725
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foobar', dict(failures=0, unreachable=0, changed=0)) == u"%s%-37s%s" % (u"\033[0m",
                                                                                              u"foobar",
                                                                                              u"\033[0m")
    assert hostcolor('foobar', dict(failures=1, unreachable=0, changed=0), color=True) == u"%s%-37s%s" % (u"\033[91m",
                                                                                                      u"foobar",
                                                                                                      u"\033[0m")

# Generated at 2022-06-11 17:49:29.166407
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        print("Skipping color tests on this terminal.")
        return

    def se(e):
        sys.stderr.write(e)

    # Tests common to both color and non-color output
    se(stringc('foo', 'blue'))
    se(stringc('foo', 'black'))
    se(stringc('foo', 'red'))
    se(stringc('foo', 'green'))
    se(stringc('foo', 'yellow'))
    se(stringc('foo', 'magenta'))
    se(stringc('foo', 'cyan'))
    se(stringc('foo', 'white'))
    se(stringc('foo', 'black', wrap_nonvisible_chars=True))

# Generated at 2022-06-11 17:49:46.657705
# Unit test for function colorize
def test_colorize():

    # Show color is forced off
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('ok', 0, 'blue') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0   '
    assert colorize('rescued', 0, 'magenta') == 'rescued=0   '
    assert colorize('ignored', 0, 'green') == 'ignored=0   '

    # Show color is forced on
    ANSIBLE_COLOR = True

    assert color

# Generated at 2022-06-11 17:49:58.487331
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {u"changed": 1, u"failures": 0, u"ok": 1, u"unreachable": 0, u"skipped": 0}) \
        == u"localhost".encode(u'utf-8')
    assert hostcolor("localhost", {u"changed": 1, u"failures": 1, u"ok": 1, u"unreachable": 0, u"skipped": 0}) \
        == u"localhost".encode(u'utf-8')
    assert hostcolor("localhost", {u"changed": 0, u"failures": 1, u"ok": 1, u"unreachable": 0, u"skipped": 0}) \
        == u"localhost".encode(u'utf-8')

# Generated at 2022-06-11 17:50:10.954025
# Unit test for function stringc
def test_stringc():
    """Returns True on success and False on failure"""

# Generated at 2022-06-11 17:50:19.312051
# Unit test for function colorize
def test_colorize():
    # Just some basic sanity checks
    color_me = 'color_me'
    assert colorize('foo', color_me, 'blue')  ==  stringc('foo=%s' % color_me, 'blue')
    assert colorize('foo', 0, 'blue')         ==  'foo=0   '
    assert colorize('foo', None, 'blue')      ==  'foo=None'
    assert colorize('foo', False, 'blue')     ==  'foo=False'
    assert colorize('foo', 1234567, 'blue')   ==  'foo=1234567'



# Generated at 2022-06-11 17:50:26.336064
# Unit test for function hostcolor
def test_hostcolor():
    HOST = "localhost"
    A = {'changed': 0, 'unreachable': 0, 'failures': 0}
    B = {'changed': 0, 'unreachable': 0, 'failures': 1}
    C = {'changed': 0, 'unreachable': 1, 'failures': 0}
    D = {'changed': 1, 'unreachable': 0, 'failures': 0}

    assert hostcolor(HOST, A) == "%-26s" % "localhost"
    assert hostcolor(HOST, B) == "%-37s" % stringc(HOST, C.COLOR_ERROR)
    assert hostcolor(HOST, C) == "%-37s" % stringc(HOST, C.COLOR_ERROR)
    assert hostcolor(HOST, D) == "%-37s" % string

# Generated at 2022-06-11 17:50:30.113305
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "color9") == "\033[38;5;9mfoo\033[0m"



# Generated at 2022-06-11 17:50:40.231868
# Unit test for function stringc
def test_stringc():
    ansible_color = ANSIBLE_COLOR

# Generated at 2022-06-11 17:50:50.974993
# Unit test for function colorize
def test_colorize():
    # Test setup
    test_string = "Test"
    c0 = "blue"
    c1 = "red"

    # Test without colored output
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    res = colorize(test_string, 0, c0)
    assert res == u"Test=0   "

    # Test with colored output
    ANSIBLE_COLOR = True
    res = colorize(test_string, 0, c0)
    assert res == u"Test=\n"
    res = colorize(test_string, 1, c0)
    assert res == u"\033[38;5;21m%s\033[0m=1   " % test_string
    res = colorize(test_string, 1, c1)

# Generated at 2022-06-11 17:51:02.661338
# Unit test for function hostcolor
def test_hostcolor():
    def test_color(name, stats, expectedcolor, expecteddisplay):
        display = hostcolor(name, stats, True)
        color = display[-14:-2]
        display = display[:-14]
        #print "got %s, should be %s - %s"%(color, expectedcolor, display)
        assert(color == expectedcolor and display == expecteddisplay)

    # Should get the normal, non-colorized version if color is false
    display = hostcolor("hostname", {}, False)
    assert(display == u"%-26s" % "hostname")


    # No failures
    test_color("hostname",
               {"failures" : 0, "unreachable" : 0, "changed" : 0, "ok" : 1},
               C.COLOR_OK, "hostname")

   

# Generated at 2022-06-11 17:51:14.387691
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = dict(
        ok=1,
        failures=1,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )
    stats2 = dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=1,
        skipped=0,
        rescued=0,
        ignored=0
    )
    stats3 = dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )


# Generated at 2022-06-11 17:51:41.445753
# Unit test for function colorize
def test_colorize():
    c1 = '\033[32m'
    c2 = '\033[31m'
    c3 = '\033[33m'
    c4 = '\033[0m'
    x = 'ok       '
    y = 'changed  '
    z = 'unreachable='
    e = 'failed   '
    assert colorize(x, 0, C.COLOR_OK) == x
    assert colorize(y, 0, C.COLOR_CHANGED) == y
    assert colorize(z, 0, C.COLOR_UNREACHABLE) == z
    assert colorize(e, 0, C.COLOR_ERROR) == e
    assert colorize(x, 1, C.COLOR_OK) == c1 + x + c4
    assert colorize(y, 2, C.COLOR_CHANGED)

# Generated at 2022-06-11 17:51:50.125860
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0, ok=1), True) == stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0, ok=0), True) == stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0, ok=0), True) == stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1, ok=0), True) == stringc('localhost', C.COLOR_CHANGED)

if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-11 17:51:53.009575
# Unit test for function stringc
def test_stringc():
    print(stringc("one", "black", 'on_white'))
    print(stringc("two", "white", 'on_black'))
    print(stringc("three", "blue", 'on_blue'))
    print(stringc("four", "green", 'on_magenta'))

if __name__ == '__main__':
    test_stringc()

# --- end "pretty"

# Generated at 2022-06-11 17:52:03.255818
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        raise Exception("Terminal does not support colors")

    stats = dict(failures=0, unreachable=0, changed=0)
    color = hostcolor("test_host", stats)
    assert color == u'\u001b[0;32mtest_host\u001b[0m'

    stats = dict(failures=1, unreachable=0, changed=0)
    color = hostcolor("test_host", stats)
    assert color == u'\u001b[0;31mtest_host\u001b[0m'

    stats = dict(failures=0, unreachable=0, changed=1)
    color = hostcolor("test_host", stats)

# Generated at 2022-06-11 17:52:13.914793
# Unit test for function stringc
def test_stringc():
    # The visible characters are wrapped into non-visible characters
    # and then unwrapped, so only the wrapping is tested.
    assert stringc(u'coucou', 'black', True) == u'\001\033[30mcoucou\001\033[0m\002'
    # Wrap the non-visible characters
    assert stringc(u'cou\ncou', 'black', True) == u'\001\033[30mcou\ncou\001\033[0m\002'
    # Make sure that we can handle multiline strings before wrapping them
    assert stringc(u'cou\ncou', 'black', False) == u'\033[30mcou\ncou\033[0m'


# --- end of "pretty"

# Generated at 2022-06-11 17:52:25.299967
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=0, failures=0, unreachable=0)
    assert hostcolor('foo.example.com', stats) == u"foo.example.com               "
    stats['changed'] = 1
    assert hostcolor('foo.example.com', stats) == u"\033[0;32mfoo.example.com\033[0m               "
    stats['unreachable'] = 1
    assert hostcolor('foo.example.com', stats) == u"\033[0;31mfoo.example.com\033[0m               "
    stats['changed'] = 0
    assert hostcolor('foo.example.com', stats) == u"\033[0;31mfoo.example.com\033[0m               "

# --- end "pretty"

# Generated at 2022-06-11 17:52:34.850288
# Unit test for function stringc
def test_stringc():
    """Test for function stringc"""
    class dummy:
        def __init__(self):
            self.nocolor = False

    class dummy_visible_characters_wrapping:
        def __init__(self):
            self.nocolor = False
            self.ansible_wrap_nonvisible_characters = True

    class dummy_no_visible_characters_wrapping:
        def __init__(self):
            self.nocolor = False
            self.ansible_wrap_nonvisible_characters = False

    # no visible_characters_wrapping
    C.ANSIBLE_FORCE_COLOR = False
    C.ANSIBLE_NOCOLOR = False

# Generated at 2022-06-11 17:52:40.476793
# Unit test for function hostcolor
def test_hostcolor():
    """
    dummy test_hostcolor, copied from test_utils
    """
    from ansible.constants import DEFAULT_HOST_LIST

    hc = hostcolor(DEFAULT_HOST_LIST, dict(changed=1, failures=1, unreachable=0))
    assert hc == u'\n'.join(stringc(DEFAULT_HOST_LIST, C.COLOR_CHANGED, wrap_nonvisible_chars=True).split(u'\n')) + u" "*11

# --- end pretty



# Generated at 2022-06-11 17:52:50.924242
# Unit test for function hostcolor
def test_hostcolor():
    """ hostcolor: testing  """
    from ansible.utils.color import hostcolor
    import sys

    # Function name (should be same as the function name)
    function_name = "hostcolor"

    # initialize host and stats
    host = "host=localhost"
    stats = {
        "failures": 0,
        "changed": 0,
        "unreachable": 0,
    }

    ######################################
    # Case 1: colorize = True            #
    ######################################
    print("\nTest Case 1: colorize = True")

    # print to sys.stdout
    print("\nCase 1.1: (failures=0, unreachable=0) - print to sys.stdout")
    stats["failures"] = 0
    stats["unreachable"] = 0

# Generated at 2022-06-11 17:52:58.690536
# Unit test for function hostcolor
def test_hostcolor():
    # test printing a host in the color ok
    result = hostcolor("testhost", dict(changed=0, failures=0, unreachable=0), True)
    assert result == u"%-37s" % stringc("testhost", C.COLOR_OK)

    # test printing a host in the color changed
    result = hostcolor("testhost", dict(changed=1, failures=0, unreachable=0), True)
    assert result == u"%-37s" % stringc("testhost", C.COLOR_CHANGED)

    # test printing a host in the color error
    result = hostcolor("testhost", dict(changed=0, failures=1, unreachable=0), True)
    assert result == u"%-37s" % stringc("testhost", C.COLOR_ERROR)

# Generated at 2022-06-11 17:53:33.040430
# Unit test for function colorize
def test_colorize():
    return stringc("Hello World!", "yellow")

# Generated at 2022-06-11 17:53:44.141122
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import *
    from ansible.constants import *
    from types import *
    if not ANSIBLE_COLOR:
        return True

    host = 'testhost'
    failed_stats = {
        'host': 'testhost',
        'ok': 2,
        'changed': 0,
        'unreachable': 2,
        'failures': 2,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0
    }
    changed_stats = {
        'host': 'testhost',
        'ok': 2,
        'changed': 2,
        'unreachable': 0,
        'failures': 0,
        'skipped': 0,
        'rescued': 0,
        'ignored': 0
    }
    ok

# Generated at 2022-06-11 17:53:52.946483
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'notacolor') == '\033[39mfoo\033[0m'
    assert stringc('foo', 'rgb255255255') == '\033[97mfoo\033[0m'
    assert stringc('foo', 'rgb000255000') == '\033[92mfoo\033[0m'
    assert stringc('foo', 'rgb01200020') == '\033[41mfoo\033[0m'
    assert stringc('foo', 'gray8') == '\033[90mfoo\033[0m'
    assert stringc('foo', 'gray10') == '\033[90mfoo\033[0m'

# Generated at 2022-06-11 17:54:00.483954
# Unit test for function parsecolor
def test_parsecolor():
    def assert_eq(x, y):
        if x != y:
            raise AssertionError("%s != %s" % (x, y))

    assert_eq(parsecolor("blue"), "34")
    assert_eq(parsecolor("0"), "38;5;0")
    assert_eq(parsecolor("1"), "38;5;1")
    assert_eq(parsecolor("2"), "38;5;2")
    assert_eq(parsecolor("3"), "38;5;3")
    assert_eq(parsecolor("4"), "38;5;4")
    assert_eq(parsecolor("5"), "38;5;5")
    assert_eq(parsecolor("6"), "38;5;6")

# Generated at 2022-06-11 17:54:09.090996
# Unit test for function hostcolor

# Generated at 2022-06-11 17:54:21.189004
# Unit test for function hostcolor
def test_hostcolor():
    # With color
    assert(hostcolor("localhost", {'ok': 1}) == u"%-37s" % u'\033[32mlocalhost\033[0m')
    assert(hostcolor("localhost", {'changed': 1}) == u"%-37s" % u'\033[33mlocalhost\033[0m')
    assert(hostcolor("localhost", {'failures': 1}) == u"%-37s" % u'\033[31mlocalhost\033[0m')
    assert(hostcolor("localhost", {'unreachable': 1}) == u"%-37s" % u'\033[31mlocalhost\033[0m')
    # Without color
    C.ANSIBLE_NOCOLOR = True

# Generated at 2022-06-11 17:54:32.775667
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('server.example.com', dict(changed=0, unreachable=0,
                                                failures=0)) == 'server.example.com      '
    assert hostcolor('server.example.com', dict(changed=1, unreachable=0,
                                                failures=0)) == '\x1b[33mserver.example.com\x1b[0m'
    assert hostcolor('server.example.com', dict(changed=0, unreachable=1,
                                                failures=0)) == '\x1b[31mserver.example.com\x1b[0m'
    assert hostcolor('server.example.com', dict(changed=0, unreachable=0,
                                                failures=1)) == '\x1b[31mserver.example.com\x1b[0m'


# Generated at 2022-06-11 17:54:40.628455
# Unit test for function stringc
def test_stringc():
    """ Test function stringc """
    assert stringc("YELLOW", "yellow") == u'\033[33mYELLOW\033[0m'
    assert stringc("RED", "red") == u'\033[31mRED\033[0m'
    assert stringc("RED ON GREEN", "red", "green") == u'\033[41m\033[31mRED ON GREEN\033[0m'
    # make sure wrapping of non-visible chars works for ANSIBLE_FORCE_COLOR
    # and normal cases

# Generated at 2022-06-11 17:54:51.715768
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        print("Not testing color output, ANSIBLE_FORCE_COLOR is not set and stdout is not a terminal.")
        return

    print("Testing color and formatting of output:")
    print("html:", stringc("<33>", 'red', wrap_nonvisible_chars=True))
    print("url :", stringc("https://www.ansible.com", 'blue', wrap_nonvisible_chars=True))
    print("file:", stringc("/etc/ansible/hosts", 'green', wrap_nonvisible_chars=True))
    print("time:", stringc("Thu Oct 27 12:59:59 CEST 2016", 'magenta', wrap_nonvisible_chars=True))

# Generated at 2022-06-11 17:54:59.018841
# Unit test for function hostcolor
def test_hostcolor():
    color1 = hostcolor('localhost', dict(failures=1, changed=0, unreachable=0))
    color2 = hostcolor('localhost', dict(failures=0, changed=1, unreachable=0))
    color3 = hostcolor('localhost', dict(failures=0, changed=0, unreachable=1))
    color4 = hostcolor('localhost', dict(failures=0, changed=0, unreachable=0))
    assert color1 != color4
    assert color2 != color4
    assert color3 != color4

# --- end of printfuncs.py