

# Generated at 2022-06-11 17:45:09.050144
# Unit test for function colorize
def test_colorize():
    # Assertions for colorize()
    for i in range(-10, 10):
        lead = str(i)
        if i < 0:
            s = colorize(lead, i, 'red')
        elif i > 0:
            s = colorize(lead, i, 'green')
        else:
            s = colorize(lead, i, 'blue')
        assert s.endswith(lead), "colorize() result does not end with lead string"
        if ANSIBLE_COLOR:
            assert "\033[" in s, "colorize() result missing ANSI escape"
        else:
            assert "\033[" not in s, "colorize() result should not have ANSI escape"



# Generated at 2022-06-11 17:45:20.512223
# Unit test for function stringc
def test_stringc():
    """Unit tests for function stringc()."""

    assert stringc('autumn', 'autumn') == '\033[38;5;127mautumn\033[0m'
    assert stringc('chartreuse', 'chartreuse') == '\033[38;5;106mchartreuse\033[0m'
    assert stringc('color10', 'color10') == '\033[38;5;10mcolor10\033[0m'
    assert stringc('gray2', 'gray2') == '\033[38;5;242mgray2\033[0m'
    assert stringc('rgb100100100', 'rgb100100100') == '\033[38;5;115mrgb100100100\033[0m'

# Generated at 2022-06-11 17:45:29.448899
# Unit test for function stringc
def test_stringc():
    """ Unit tests for function stringc """
    assert stringc("host", "ok") == stringc("host", "green")
    assert stringc("host", "changed") == stringc("host", "yellow")
    assert stringc("host", "error") == stringc("host", "red")
    assert stringc("host", "skipped") == stringc("host", "cyan")
    assert stringc("host", "dark gray") == stringc("host", "darkgray")
    assert stringc("host", "light green") == stringc("host", "lightgreen")

# --- end "pretty"



# Generated at 2022-06-11 17:45:39.998464
# Unit test for function hostcolor
def test_hostcolor():
    test_stats = {}
    assert hostcolor(u"test_host", test_stats) == u"test_host                  "
    test_stats['changed'] = 1
    assert hostcolor(u"test_host", test_stats) == u"\033[0;33mtest_host            \033[0m"
    test_stats['failed'] = 1
    assert hostcolor(u"test_host", test_stats) == u"\033[0;31mtest_host            \033[0m"
    test_stats['unreachable'] = 1
    assert hostcolor(u"test_host", test_stats) == u"\033[0;31mtest_host            \033[0m"



# Generated at 2022-06-11 17:45:44.648257
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"hostname", {"changed": 0, "failures": 0, "unreachable": 0}, True) == u"hostname                "
    assert hostcolor(u"hostname", {"changed": 1, "failures": 0, "unreachable": 0}, True) == u"hostname                "

# --- end "pretty"


# Generated at 2022-06-11 17:45:52.809806
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('somehost.example.org', dict(ok=1, failures=0, changed=0, unreachable=0)) == u"somehost.example.org         "
    assert hostcolor('somehost.example.org', dict(ok=1, failures=0, changed=1, unreachable=0)) == u"\033[0;34msomehost.example.org\033[0m"
    assert hostcolor('somehost.example.org', dict(ok=1, failures=1, changed=0, unreachable=0)) == u"\033[0;31msomehost.example.org\033[0m"

# Generated at 2022-06-11 17:46:02.385713
# Unit test for function parsecolor
def test_parsecolor():
    import re
    import pytest
    from ansible.utils.color import parsecolor

    # test valid color names
    color_names = ['black', 'red', 'green', 'yellow',
                   'blue', 'magenta', 'cyan', 'white']
    for color_name in color_names:
        result = parsecolor(color_name)
        assert isinstance(result, str)
        assert re.match(r'^3[01][;]5[;][0-9]+$', result)

    # test valid color numbers
    color_numbers = range(8)
    for color_number in color_numbers:
        result = parsecolor(color_number)
        assert isinstance(result, str)

# Generated at 2022-06-11 17:46:12.201897
# Unit test for function stringc
def test_stringc():
    class Wrap(object):
        def __init__(self, s):
            self.s = s
        def wrapped_lines(self, msg):
            return msg.splitlines()
        def __repr__(self):
            return '<Wrap>'
    class Opts(object):
        def __init__(self):
            self.format = 'smart'
            self.wrap_width = 80
            self.width = 80
            self.output_file = Wrap('test')
    for opts in [Opts(), None]:
        for use_ansi_color, wrap_nonvisible_chars in [
                (True, False), (True, True), (False, False)]:
            orig_ansi_color = ANSIBLE_COLOR
            ANSIBLE_COLOR = use_ansi_color

# Generated at 2022-06-11 17:46:23.003112
# Unit test for function parsecolor
def test_parsecolor():
    retval = parsecolor('green')
    assert retval == '32', retval
    retval = parsecolor('blue')
    assert retval == '34', retval
    retval = parsecolor('red')
    assert retval == '31', retval
    retval = parsecolor('black')
    assert retval == '30', retval
    retval = parsecolor('white')
    assert retval == '37', retval
    retval = parsecolor('brown')
    assert retval == '33', retval
    retval = parsecolor('darkgreen')
    assert retval == '32', retval
    retval = parsecolor('darkred')
    assert retval == '31', retval
    retval = parsecolor('darkwhite')
    assert retval == '37', ret

# Generated at 2022-06-11 17:46:31.666278
# Unit test for function stringc
def test_stringc():
    assert stringc("bold and bright", dict(ok="bold", changed="bright", error="dark red"))
    assert stringc("bold and dark red", dict(bold="bold", dark_red="dark red", error="dark red"))
    assert stringc("red", dict(red="dark red", ok="bold", error="dark red"))
    assert stringc("bold", dict(ok="bright", changed="bright", error="dark red"))
    assert stringc("dark red and dark red", dict(error="dark red", changed="bright", ok="bold"))
    assert stringc("bold and bright", dict(ok="bold", changed="bright", error="dark red"))



# Generated at 2022-06-11 17:46:45.651149
# Unit test for function stringc
def test_stringc():
    color_code = parsecolor('blue')
    fmt = u"\033[%sm%s\033[0m"
    assert stringc(u"test", 'blue') == fmt % (color_code, 'test')
    print(stringc(u"test", 'blue'))



# Generated at 2022-06-11 17:46:55.661747
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    if ANSIBLE_COLOR:
        # Test all possible states of stats variable.
        stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
        assert(u"%-37s" % stringc('localhost', C.COLOR_OK) == hostcolor('localhost', stats))
        stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
        assert(u"%-37s" % stringc('localhost', C.COLOR_ERROR) == hostcolor('localhost', stats))
        stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
        assert(u"%-37s" % stringc('localhost', C.COLOR_ERROR) == hostcolor('localhost', stats))

# Generated at 2022-06-11 17:47:00.347682
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'red', wrap_nonvisible_chars=True) == u'\001\033[31m\002foo\001\033[0m\002'



# Generated at 2022-06-11 17:47:11.465549
# Unit test for function parsecolor
def test_parsecolor():
    for color in C.COLOR_CODES:
        assert parsecolor(color) == C.COLOR_CODES[color]
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color232') == u'38;5;232'
    assert parsecolor('rgb222') == u'38;5;14'  # Red
    assert parsecolor('rgb555') == u'38;5;20'  # Light red
    assert parsecolor('rgb022') == u'38;5;22'  # Green
    assert parsecolor('rgb200') == u'38;5;60'  # Yellow
    assert parsecolor('rgb202') == u'38;5;62'  # Light yellow

# Generated at 2022-06-11 17:47:20.633525
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'host1', dict(ok=1), True) == stringc(u'host1', C.COLOR_OK) + ' '
    assert hostcolor(u'host1', dict(ok=1), False) == u'host1       '
    assert hostcolor(u'host1', dict(ok=0, changed=1, unreachable=0), True) == stringc(u'host1', C.COLOR_CHANGED) + ' '
    assert hostcolor(u'host1', dict(ok=0, changed=1, unreachable=0), False) == u'host1       '
    assert hostcolor(u'host1', dict(ok=0, changed=0, unreachable=1), True) == stringc(u'host1', C.COLOR_ERROR) + ' '

# Generated at 2022-06-11 17:47:31.716344
# Unit test for function stringc

# Generated at 2022-06-11 17:47:44.683703
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", "black") == u"\033[30mhello\033[0m"
    assert stringc("hello", "red") == u"\033[31mhello\033[0m"
    assert stringc("hello", "green") == u"\033[32mhello\033[0m"
    assert stringc("hello", "yellow") == u"\033[33mhello\033[0m"
    assert stringc("hello", "blue") == u"\033[34mhello\033[0m"
    assert stringc("hello", "magenta") == u"\033[35mhello\033[0m"
    assert stringc("hello", "cyan") == u"\033[36mhello\033[0m"

# Generated at 2022-06-11 17:47:48.562790
# Unit test for function colorize
def test_colorize():
    for C in ('red', 'green', 'blue', 'yellow', 'cyan', 'magenta', 'white', 'black'):
        print(('colorize = %s, num = %s' % (C, colorize('lead', C, C))))


# --- end of "pretty"



# Generated at 2022-06-11 17:47:58.106841
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('rgb212') == u'38;5;130'
    assert parsecolor('rgb122') == u'38;5;94'
    assert parsecolor('rgb222') == u'38;5;100'
    assert parsecolor('rgb100') == u'38;5;16'
    assert parsecolor('rgb101') == u'38;5;94'
    assert parsecolor('black') == u'30'
    assert parsecolor('white') == u'37'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('green') == u'32'

# Generated at 2022-06-11 17:48:02.583525
# Unit test for function stringc
def test_stringc():
    """ Test colorize function """
    assert stringc("This is a test", "blue") == u"\033[34;1mThis is a test\033[0m"
    assert stringc("This is a test", "31") == u"\033[31;1mThis is a test\033[0m"



# Generated at 2022-06-11 17:48:20.890424
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils.six import PY3
    import six
    if not PY3:
        test_stats = {
            'failures': 0,
            'unreachable': 0,
            'changed': 0
        }
        assert hostcolor(u"test", test_stats, False) == u"%-26s" % (u"test")

        ANSIBLE_COLOR = True
        assert hostcolor(u"test", test_stats) == u"%-37s" % stringc(u"test", C.COLOR_OK)

        test_stats = {
            'failures': 1,
            'unreachable': 0,
            'changed': 0
        }

# Generated at 2022-06-11 17:48:32.695258
# Unit test for function hostcolor
def test_hostcolor():
    # These test strings were generated using the default
    # value of ANSIBLE_NOCOLOR (False), ANSIBLE_FORCE_COLOR
    # (False), and a terminal type with support for color.
    ok_string = u"\u001b[0mok                                           \u001b[0m"
    changed_string = u"\u001b[0mchanged                                      \u001b[0m"
    unreachable_string = u"\u001b[0munreachable                                  \u001b[0m"
    failed_string = u"\u001b[0mfailed                                       \u001b[0m"

    # Test ok
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(u"ok", stats) == ok_

# Generated at 2022-06-11 17:48:43.860494
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0, ok=1), color=True) == stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0, ok=0), color=False) == u'localhost            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1, ok=0), color=True) == stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0, ok=0), color=False) == u'localhost            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0, ok=0), color=True) == string

# Generated at 2022-06-11 17:48:54.968735
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor('test_host', {}, True) == stringc('test_host', C.COLOR_OK)
        assert hostcolor('test_host', {'failures': 1}, True) == stringc('test_host', C.COLOR_ERROR)
        assert hostcolor('test_host', {'changed': 1}, True) == stringc('test_host', C.COLOR_CHANGED)
    else:
        assert hostcolor('test_host', {}, True) == '%-26s' % 'test_host'
        assert hostcolor('test_host', {'failures': 1}, True) == '%-26s' % 'test_host'
        assert hostcolor('test_host', {'changed': 1}, True) == '%-26s' % 'test_host'



# Generated at 2022-06-11 17:49:06.462486
# Unit test for function hostcolor
def test_hostcolor():
    host = 'somehost'
    stats = dict(changed=1)
    test = hostcolor(host, stats, True)
    assert test == u"%-37s" % stringc(host, C.COLOR_CHANGED, True)
    stats = dict(failures=1)
    test = hostcolor(host, stats, True)
    assert test == u"%-37s" % stringc(host, C.COLOR_ERROR, True)
    stats = dict(unreachable=1)
    test = hostcolor(host, stats, True)
    assert test == u"%-37s" % stringc(host, C.COLOR_ERROR, True)
    stats = dict(changed=0, failures=0, unreachable=0)
    test = hostcolor(host, stats, True)
    assert test == u"%-37s"

# Generated at 2022-06-11 17:49:13.788554
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('somehost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == 'somehost'
    assert hostcolor('somehost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == 'somehost'
    assert hostcolor('somehost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == 'somehost'
    assert hostcolor('somehost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == 'somehost'

# --- end "pretty"
#
# --- begin "ansible"

# ANSIBLE AND ITS PLUGINS AND MODULES ARE NOT COMPLETELY SECURE. IT IS POSSIBLE TO
# USE ANSIBLE TO INTRODUCE OTHER SECURITY PROBLEMS.

# Generated at 2022-06-11 17:49:24.336471
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    print(hostcolor("Ok color", stats, color=True))
    print(hostcolor("No color", stats, color=False))
    stats = dict(failures=1, unreachable=1, changed=0)
    print(hostcolor("Ok color", stats, color=True))
    print(hostcolor("No color", stats, color=False))
    stats = dict(failures=0, unreachable=0, changed=1)
    print(hostcolor("Ok color", stats, color=True))
    print(hostcolor("No color", stats, color=False))

# --- end "pretty" ---

if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-11 17:49:34.684319
# Unit test for function stringc
def test_stringc():
    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white', 'darkgray'):
        for bgcolor in ('on_black', 'on_red', 'on_green', 'on_yellow', 'on_blue', 'on_magenta', 'on_cyan', 'on_white'):
            text = stringc("This is %s %s text" % (color, bgcolor),
                           '%s %s' % (color, bgcolor))
            text_nocolor = stringc("This is %s %s text" % (color, bgcolor),
                                   '%s %s' % (color, bgcolor), False)

# Generated at 2022-06-11 17:49:44.697613
# Unit test for function hostcolor
def test_hostcolor():
    class FakeStats(object):
        def __init__(self):
            self.failures = 0
            self.unreachable = 0
            self.changed = 0

    stats = FakeStats()
    assert hostcolor("localhost", stats) == "localhost               "

    stats.changed = 1
    assert hostcolor("localhost", stats, True) == stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", stats, False) == "localhost               "

    stats.changed = 0
    stats.unreachable = 1
    assert hostcolor("localhost", stats, True) == stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", stats, False) == "localhost               "

    stats.unreachable = 0
    stats.failures = 1

# Generated at 2022-06-11 17:49:51.755223
# Unit test for function stringc
def test_stringc():
    def cprint(expected, text, color, wrap_nonvisible_chars=False):
        if ANSIBLE_COLOR:
            s = stringc(text, color, wrap_nonvisible_chars)
            assert s == expected, "stringc(%r, %r, %r) returned %r." % (text, color, wrap_nonvisible_chars, s)
        else:
            assert text == expected, "stringc(%r, %r) returned %r." % (text, color, text)

    def tprint(text, color, wrap_nonvisible_chars=False):
        cprint(text, text, color, wrap_nonvisible_chars)


# Generated at 2022-06-11 17:50:12.384538
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('localhost', dict(
        ok=0,
        skipped=0,
        changed=0,
        unreachable=0,
        failures=0,
    )))
    print(hostcolor('localhost', dict(
        ok=0,
        skipped=0,
        changed=0,
        unreachable=0,
        failures=1,
    )))
    print(hostcolor('localhost', dict(
        ok=0,
        skipped=0,
        changed=1,
        unreachable=0,
        failures=0,
    )))
    print(hostcolor('localhost', dict(
        ok=0,
        skipped=0,
        changed=0,
        unreachable=1,
        failures=0,
    )))



# Generated at 2022-06-11 17:50:19.069794
# Unit test for function stringc
def test_stringc():
    # Set the terminal width to a fixed value for the test
    global COLUMNS
    COLUMNS = 80
    color = 'white'
    txt = 'this is a color test'
    colored_txt = stringc(txt, color)
    print(colored_txt)
    txt = 'this is a wrapped test'
    colored_txt = stringc(txt, color, wrap_nonvisible_chars=True)
    print(colored_txt)



# Generated at 2022-06-11 17:50:28.660973
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""

    def assert_equal(actual, expected):
        """Check that actual and expected are equal."""
        if actual != expected:
            print('actual: %r' % actual)
            print('expected: %r' % expected)
            raise AssertionError('actual != expected')

    assert_equal(stringc('foo', 'green'),
                 u'\033[32mfoo\033[0m')
    assert_equal(stringc(u'foo', u'green'),
                 u'\033[32mfoo\033[0m')
    assert_equal(stringc(u'foo\nbar', u'green'),
                 u'\033[32mfoo\nbar\033[0m')

# Generated at 2022-06-11 17:50:38.432655
# Unit test for function hostcolor
def test_hostcolor():
    """hostcolor() returns string with ANSI color escape codes
    when ANSIBLE_COLOR is enabled, and if not then no color codes
    """
    host = 'test123'
    stats = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}

    # Test with ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert u"\x1b[0;32m%-37s\x1b[0m" % host == hostcolor(host, stats)

    # Test without ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert u"%-26s" % host == hostcolor(host, stats)



# Generated at 2022-06-11 17:50:49.526589
# Unit test for function stringc
def test_stringc():
    assert stringc(u'Test me', 'red') == u'\x1b[31mTest me\x1b[0m'
    assert stringc(u'Test me', 'RED') == u'\x1b[31mTest me\x1b[0m'
    assert stringc(u'Test me', 'rgb255255255') == u'\x1b[37mTest me\x1b[0m'
    assert stringc(u'Test me', 'rgb0101010') == u'\x1b[30mTest me\x1b[0m'
    assert stringc(u'Test me', 'rgb0000255') == u'\x1b[34mTest me\x1b[0m'

# Generated at 2022-06-11 17:51:00.766740
# Unit test for function stringc
def test_stringc():
    from pprint import pprint
    from copy import copy

    def assert_equal(got, expected):
        if got != expected:
            print("** assert_equal: FAIL")
            pprint(expected, width=1)
            pprint(got, width=1)
            raise AssertionError("assert_equal failure")

    # Strings to test colorization with
    S1 = u"hello"
    S2 = u"world"

    # SGR parameter values
    SGR_COLOR = u"38;5"
    SGR_STYLE = u"1"
    SGR_RESET = u"0"

    # Values for background color and style
    BG_COLOR = u"48;5"
    BG_STYLE = u"4"

    # List of SGR parameters for testing

# Generated at 2022-06-11 17:51:08.199740
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(ok=10, failures=0, unreachable=0, changed=0)
    assert hostcolor("foo", stats) == u"\u001b[32m%-37s\u001b[0m" % "foo"
    stats = dict(ok=0, failures=1, unreachable=0, changed=0)
    assert hostcolor("foo", stats) == u"\u001b[31m%-37s\u001b[0m" % "foo"
    stats = dict(ok=0, failures=0, unreachable=1, changed=0)
    assert hostcolor("foo", stats) == u"\u001b[31m%-37s\u001b[0m" % "foo"
    stats = dict(ok=0, failures=0, unreachable=0, changed=1)

# Generated at 2022-06-11 17:51:12.601878
# Unit test for function hostcolor
def test_hostcolor():
    host = 'shell'
    stats = {'changed': 0, 'failures': 0, 'ok': 10, 'skipped': 0, 'unreachable': 0}

    return hostcolor(host, stats, True)

if __name__ == '__main__':
    print(test_hostcolor())

# Generated at 2022-06-11 17:51:21.542508
# Unit test for function stringc
def test_stringc():
    tests = (
        # simple test, works with most normal terminals
        ('test', 'red', u'test'),
        # smybolic color name
        ('test', 'red', u'test'),
        # 8-color name
        ('test', 'color1', u'test'),
        # 256-color name
        ('test', 'color1', u'test'),
        # 24-bit color name
        ('test', 'rgb255255255', u'test'),
        # greyscale
        ('test', 'gray10', u'test'),
        # greyscale
        ('test', 'gray1', u'test'),
    )

    for test in tests:
        assert stringc(test[0], test[1]) == test[2]

# Generated at 2022-06-11 17:51:26.013932
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize(u"foo", 42, None)
    'foo=42  '
    >>> print(colorize(u"foo", 0, u"blue"))
    foo=0
    >>> print(colorize(u"foo", 3, u"blue"))
    foo=3  \n\033[0m
    """



# Generated at 2022-06-11 17:51:51.527161
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", "red") == u"\033[31mhello\033[0m"


#
# --- end "pretty"

#
# The following functions were taken from the Pygments project.  The
# copyright / license for the code is as follows:
#
# Copyright (c) 2006-2013 by the respective authors (see AUTHORS file).
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are
# met:
#
#     * Redistributions of source code must retain the above copyright
#       notice, this list of conditions and the following disclaimer.
#
#     * Redistributions in binary form must reproduce the above
#       copyright notice, this list of conditions and the following
#       disclaimer in the documentation and/or other

# Generated at 2022-06-11 17:52:01.537991
# Unit test for function colorize
def test_colorize():
    test_passed = True
    test_failed = True

    # test_passed
    print(u"Testing colorize() for PASSED")
    line = colorize(u"PASSED", 5, C.COLOR_OK)
    if u"PASSED=5" in line:
        print(u"PASSED")
        test_passed = True
    else:
        print(u"FAILED")
        test_passed = False

    # test_failed
    print(u"Testing colorize() for FAILED")
    line = colorize(u"FAILED", 5, C.COLOR_ERROR)
    if u"\033[31mFAILED=5\033[0m" in line:
        print(u"PASSED")
        test_failed = True

# Generated at 2022-06-11 17:52:10.632262
# Unit test for function parsecolor
def test_parsecolor():
    assert sys.stdout.isatty()

    colors = ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']
    for col in colors:
        assert parsecolor(col) == C.COLOR_CODES[col]

    assert parsecolor('rgbrgbrgb') == parsecolor('rgb224040')
    assert parsecolor('grgrgrgrgrgrgr') == parsecolor('gray0')
    assert parsecolor('color88') == u'38;5;88'


# --- end "pretty" ---


# Generated at 2022-06-11 17:52:18.459226
# Unit test for function stringc
def test_stringc():
    # needs to be run in an xterm
    print(stringc("Hello", "red", True))
    print(stringc("Hello", "green", True))
    print(stringc("Hello", "yellow", True))
    print(stringc("Hello", "blue", True))
    print(stringc("Hello", "magenta", True))
    print(stringc("Hello", "cyan", True))
    print(stringc("Hello", "white", True))
    print(stringc("Hello", "gray", True))
    print(stringc("Hello", "black", True))
    print(stringc("Hello", "bgred", True))
    print(stringc("Hello", "bggreen", True))
    print(stringc("Hello", "bgyellow", True))

# Generated at 2022-06-11 17:52:27.942667
# Unit test for function colorize
def test_colorize():

    class FakeStdout:
        def __init__(self):
            self.string = ""

        def write(self, s):
            self.string = self.string + s

        def isatty(self):
            return True

    old_stdout = sys.stdout
    fake_stdout = FakeStdout()
    sys.stdout = fake_stdout

    colorize("foo", 0, None)
    assert fake_stdout.string == "foo=0   "
    fake_stdout.string = ""

    colorize("foo", 0, 'yellow')
    assert fake_stdout.string == "foo=0   "
    fake_stdout.string = ""

    colorize("foo", 0, 'red')
    assert fake_stdout.string == "foo=0   "
    fake_stdout

# Generated at 2022-06-11 17:52:35.837188
# Unit test for function stringc
def test_stringc():
    a = stringc('red', 'red', wrap_nonvisible_chars=False)
    assert a == u'\033[31mred\033[0m'

    a = stringc('green', 'green', wrap_nonvisible_chars=False)
    assert a == u'\033[32mgreen\033[0m'

    a = stringc('blue', 'blue', wrap_nonvisible_chars=False)
    assert a == u'\033[34mblue\033[0m'

    # wrap color codes
    a = stringc('white', 'white', wrap_nonvisible_chars=True)
    assert a == u'\001\033[37m\002white\001\033[0m\002'

# --- end "pretty"

# Generated at 2022-06-11 17:52:42.648514
# Unit test for function stringc
def test_stringc():
    "Test the stringc() function"

    assert stringc("foo", "blue") == "\033[0;34mfoo\033[0m"
    assert stringc("\nbar\n", "lightgreen") == "\033[92mbar\033[0m"

    print("OK 1")

    assert stringc("foo", "lightblue") == "\033[94mfoo\033[0m"
    assert stringc("\nbar\n", "lightgreen") == "\033[92mbar\033[0m"

    print("OK 2")

    assert stringc("foo", "black on_white") == "\033[0;30;47mfoo\033[0m"
    assert stringc("\nbar\n", "black on_white") == "\033[0;30;47mbar\033[0m"



# Generated at 2022-06-11 17:52:48.638092
# Unit test for function stringc

# Generated at 2022-06-11 17:52:57.379130
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils._text import to_text

    results = dict(contacted=dict(localhost=dict(changed=0, unreachable=0, failed=0)), darkhost=dict(changed=1, unreachable=0, failed=0), darkstar=dict(changed=0, unreachable=1, failed=0), darkside=dict(changed=0, unreachable=0, failed=1), lightside=dict(changed=0, unreachable=0, failed=0))
    color = True
    print(to_text(hostcolor("localhost", results['contacted']['localhost'], color)))
    print(to_text(hostcolor("darkstar", results['contacted']['darkstar'], color)))
    print(to_text(hostcolor("darkhost", results['contacted']['darkhost'], color)))

# Generated at 2022-06-11 17:53:04.250118
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.collections import defaultdict
    stats = defaultdict(lambda: defaultdict(int))
    stats['ok'] = 1
    stats['changed'] = 1

    print(hostcolor('testhost', stats))
    print(hostcolor('testhost', stats, False))
    ok_(hostcolor('testhost', stats).startswith('\x1b['))
    assert_false(hostcolor('testhost', stats, False).startswith('\x1b['))

# Generated at 2022-06-11 17:53:31.702478
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', -10, None) == 'foo=-10 '
    assert colorize('foo', 10, 'red') == 'foo=10  '
    assert colorize('foo', 0, 'red') == 'foo=0   '
    assert colorize('foo', -10, 'red') == 'foo=-10 '
    assert re.match(r"foo=10\s*", colorize('foo', 10, 'blue'))
    assert re.match(r"foo=0\s*", colorize('foo', 0, 'blue'))
    assert re.match(r"foo=-10\s*", colorize('foo', -10, 'blue'))


# Generated at 2022-06-11 17:53:43.104023
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return

    # Test has changed
    stats = {'changed': 1, 'failures': 0, 'ok': 1, 'processed': 1, 'skipped': 0, 'unreachable': 0}
    assert hostcolor('localhost', stats, color=True) == stringc('localhost', C.COLOR_CHANGED)

    # Test is ok
    stats = {'changed': 0, 'failures': 0, 'ok': 1, 'processed': 1, 'skipped': 0, 'unreachable': 0}
    assert hostcolor('localhost', stats, color=True) == stringc('localhost', C.COLOR_OK)

    # Test is failed

# Generated at 2022-06-11 17:53:52.848129
# Unit test for function stringc

# Generated at 2022-06-11 17:54:00.243015
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) == hostcolor(host, stats, False)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) != hostcolor(host, stats, False)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, True) != hostcolor(host, stats, False)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
    assert hostcolor(host, stats, True) != hostcolor(host, stats, False)



# Generated at 2022-06-11 17:54:08.921443
# Unit test for function stringc
def test_stringc():
    assert stringc("none", None) == "none"
    assert stringc("bold", None) == "bold"
    assert stringc("green", None, wrap_nonvisible_chars=True) == "\001\033[0m\002green\001\033[0m\002"
    assert stringc("green", "green") == "\033[0;32mgreen\033[0m"
    assert stringc("green", "color2") == "\033[0;38;5;2mgreen\033[0m"
    assert stringc("green", "rgb234") == "\033[0;38;5;60mgreen\033[0m"
    assert stringc("green", "gray7") == "\033[0;38;5;239mgreen\033[0m"


# Generated at 2022-06-11 17:54:21.016300
# Unit test for function hostcolor
def test_hostcolor():
    try:
        from ansible.constants import HOST_PASSED, HOST_FAILED, HOST_UNREACHABLE
    except ImportError:
        from ansible.runner.constants import HOST_PASSED, HOST_FAILED, HOST_UNREACHABLE

    host = u"foobar"
    stats = {'skipped': 0, 'ok': 1, 'changed': 0, 'failures': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == u"%-37s" % host
    stats = {'skipped': 0, 'ok': 1, 'changed': 1, 'failures': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == u"%-37s" % host

# Generated at 2022-06-11 17:54:31.814864
# Unit test for function hostcolor
def test_hostcolor():
    # Setup
    host = 'testhost'

    # Test error
    color = hostcolor(host, {'failures': 1})
    assert u'%-37s' % stringc(host, C.COLOR_ERROR) in color

    # Test change
    color = hostcolor(host, {'changed': 1})
    assert u'%-37s' % stringc(host, C.COLOR_CHANGED) in color

    # Test no color
    color = hostcolor(host, {}, False)
    assert '{0:-37s}'.format(host) in color

    # Test ok, and color
    color = hostcolor(host, {})
    assert u"%-37s" % stringc(host, C.COLOR_OK) in color



# Generated at 2022-06-11 17:54:40.048241
# Unit test for function colorize
def test_colorize():
    assert u'foo=0' == colorize(u'foo', 0, None)
    assert u'foo=1  ' == colorize(u'foo', 1, None)
    assert u'foo=255' == colorize(u'foo', 255, None)
    assert u'foo=0' == colorize(u'foo', 0, C.COLOR_ERROR)
    assert u'foo=1  ' == colorize(u'foo', 1, C.COLOR_OK)
    assert u'foo=255' == colorize(u'foo', 255, C.COLOR_CHANGED)
    # Make sure the color code is in the same location every time.
    # This helps the terminal to optimize redrawing the same line.
    assert u'\x1b[31mfoo=1  \x1b[0m' == color

# Generated at 2022-06-11 17:54:47.138455
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 42
    color = 'red'
    s = colorize(lead, num, color)
    assert s == "\x1b[31mfoo=42  \x1b[0m"
    # non-zero value with ANSIBLE_COLOR=False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    s = colorize(lead, num, color)
    assert s == "foo=42  "

# --- end "pretty"

# Generated at 2022-06-11 17:54:54.763407
# Unit test for function hostcolor
def test_hostcolor():
    test_stats = {
        'changed': 0,
        'failures': 0,
        'ok': 2,
        'skipped': 0,
        'unreachable': 0
    }
    assert hostcolor('test', test_stats) == u'%-37s' % 'test'

    test_stats['changed'] = 1
    assert hostcolor('test', test_stats) == u'%-37s' % stringc('test', C.COLOR_CHANGED)

    test_stats['changed'] = 0
    test_stats['failures'] = 1
    assert hostcolor('test', test_stats) == u'%-37s' % stringc('test', C.COLOR_ERROR)