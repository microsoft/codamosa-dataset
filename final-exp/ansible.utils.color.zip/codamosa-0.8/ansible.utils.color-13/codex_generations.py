

# Generated at 2022-06-11 17:45:10.105229
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('purple') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('default') == '39'
    assert parsecolor('0') == '38;5;0'
    assert parsecolor('1') == '38;5;1'
    assert parsecolor('2') == '38;5;2'
    assert parsecolor('3') == '38;5;3'

# Generated at 2022-06-11 17:45:19.827124
# Unit test for function stringc
def test_stringc():
    ok = "ok"
    warn = "warn"
    text = "This is a test."

    # Should output "This is a test." in normal text.
    print(stringc(text, ok))

    # Should output "This is a test." in bright red.
    print(stringc(text, warn))

    # Should output "This is a test." in normal text.
    print(stringc(text, ok, wrap_nonvisible_chars=True))

    # Should output "This is a test." in bright red.
    print(stringc(text, warn, wrap_nonvisible_chars=True))
# --- end of "pretty" method



# Generated at 2022-06-11 17:45:31.981870
# Unit test for function stringc

# Generated at 2022-06-11 17:45:42.365982
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize('ok', 0, C.COLOR_OK) == 'ok=0   '
        assert colorize('changed', 0, C.COLOR_CHANGED) == 'changed=0   '
        assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == 'unreachable=0   '
        assert colorize('failed', 0, C.COLOR_ERROR) == 'failed=0   '

        assert colorize('ok', 1, C.COLOR_OK) == 'ok=1   '
        assert colorize('changed', 1, C.COLOR_CHANGED) == 'changed=1   '
        assert colorize('unreachable', 1, C.COLOR_UNREACHABLE) == 'unreachable=1   '

# Generated at 2022-06-11 17:45:51.495665
# Unit test for function parsecolor
def test_parsecolor():
    """
    Print all color combinations - to verify that all colors are working, run
    this python script and check for any missing or incorrect colors in the
    output.
    """

# Generated at 2022-06-11 17:46:01.777111
# Unit test for function parsecolor
def test_parsecolor():
    # For a list of colors see
    # http://www.calmar.ws/vim/256-xterm-24bit-rgb-color-chart.html
    if ANSIBLE_COLOR:
        assert parsecolor("red") == u"31"
        assert parsecolor("brightred") == u"91"
        assert parsecolor("green") == u"32"
        assert parsecolor("brightgreen") == u"92"
        assert parsecolor("yellow") == u"33"
        assert parsecolor("brightyellow") == u"93"
        assert parsecolor("blue") == u"34"
        assert parsecolor("brightblue") == u"94"
        assert parsecolor("magenta") == u"35"
        assert parsecolor("brightmagenta") == u"95"
        assert par

# Generated at 2022-06-11 17:46:11.981452
# Unit test for function hostcolor
def test_hostcolor():
    # Use a small subset of the possible dict for the stats.
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}

    # All stats are zero so it should display in the "ok" color
    assert hostcolor("bob.example.com", stats) == "bob.example.com            "
    assert hostcolor("bob.example.com", stats, color=False) == "bob.example.com            "

    # Add unreachable. It should display in the "error" color.
    stats['unreachable'] = 1
    assert hostcolor("bob.example.com", stats) == "bob.example.com            "
    assert hostcolor("bob.example.com", stats, color=False) == "bob.example.com            "

    # Add failures. It should display in

# Generated at 2022-06-11 17:46:22.901316
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}, color=True) == u"%-26s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}, color=True) == u"%-26s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}, color=True) == u"%-26s" % stringc('localhost', C.COLOR_CHANGED)

# pretty.py ends here
# --- end "pretty"

# these are constant strings that are used in outputing
# different kinds of status of a host (colorization, etc)
HOST_ERROR

# Generated at 2022-06-11 17:46:31.564930
# Unit test for function stringc
def test_stringc():
    ''' python 2.6 doesn't support the %s format specifier inside the braces of a
    final format specifier so we need to use older style formatting to test stringc
    '''
    assert stringc("normal", "normal") == "normal"
    assert stringc("non-normal", "red") == "\033[31mnon-normal\033[0m"
    assert stringc("non-normal", "color1") == "\033[38;5;1mnon-normal\033[0m"
    assert stringc("non-normal", "rgb255") == "\033[38;5;231mnon-normal\033[0m"
    assert stringc("non-normal", "rgb253") == "\033[38;5;229mnon-normal\033[0m"

# Generated at 2022-06-11 17:46:41.997930
# Unit test for function stringc
def test_stringc():
    """
    >>> stringc('Hello World!', 'red', True)
    u'\\x01\\x1b[31m\\x02Hello World!\\x01\\x1b[0m\\x02'
    >>> stringc('Hello World!', 'red', False)
    u'\\x1b[31mHello World!\\x1b[0m'
    >>> stringc('Hello World!', 'rgb255000255', True)
    u'\\x01\\x1b[38;5;201m\\x02Hello World!\\x01\\x1b[0m\\x02'
    >>> stringc('Hello World!', 'rgb255000255', False)
    u'\\x1b[38;5;201mHello World!\\x1b[0m'
    """

# Generated at 2022-06-11 17:46:54.870183
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return True
    else:
        print(u"\nTesting hostcolor():")
        test_data = {'localhost':{'ok':15,'changed':0,'unreachable':0,'failures':0},'example.com':{'ok':0,'changed':15,'unreachable':0,'failures':0},'example.net':{'ok':1,'changed':0,'unreachable':0,'failures':15},'example.org':{'ok':0,'changed':0,'unreachable':15,'failures':0}}
        for host in test_data:
            print(hostcolor(host, test_data[host]))

# Test for colorize()

# Generated at 2022-06-11 17:47:00.889840
# Unit test for function colorize
def test_colorize():
    import pprint
    for c in ('blue', 'cyan', 'green', 'magenta', 'red', 'white', 'yellow'):
        print(c, ":", colorize('foo', 42, c))
    print('', ":", colorize('foo', 42, None))
    pprint.pprint(C.COLOR_CODES)

# --- end "pretty"



# Generated at 2022-06-11 17:47:11.022231
# Unit test for function stringc
def test_stringc():
    """Unit tests for function stringc"""
    import random

    def test_color(color):
        s = 'XyZ'
        sc = stringc(s, color)
        if color in C.COLOR_CODES:
            assert sc.startswith("\033[%sm" % C.COLOR_CODES[color])
            assert sc.endswith("\033[0m")
        else:
            assert sc == s

    # test all colors
    for color in C.COLOR_CODES:
        yield test_color, color

    # random tests
    for i in range(100):
        color = random.choice(C.COLOR_CODES.keys())
        yield test_color, color

# Generated at 2022-06-11 17:47:20.326058
# Unit test for function hostcolor
def test_hostcolor():
    ''' hostcolor returns the correct color and length of a string '''
    h = 'testhost'
    s = {
        'changed' : 1,
        'failures' : 0,
        'ok' : 5,
        'skipped' : 0,
        'unreachable': 0
        }
    assert( hostcolor( h, s, True) == u'%-37s' % stringc(h, C.COLOR_CHANGED))

    s = {
        'changed' : 0,
        'failures' : 1,
        'ok' : 5,
        'skipped' : 0,
        'unreachable': 0
        }
    assert( hostcolor( h, s, True) == u'%-37s' % stringc(h, C.COLOR_ERROR))


# Generated at 2022-06-11 17:47:31.510533
# Unit test for function stringc
def test_stringc():
    """This function tests the functionality of stringc."""
    # Testing without color
    # Test for escaping special characters
    assert stringc("\x1b[31m\n", 'red') == "\x1b[31m\n"

    # Test for escaping ANSI color codes
    assert stringc(u"\033[0m\n", 'red') == "\033[0m\n"

    # Testing with color
    assert stringc("\x1b[31m\n", 'red', wrap_nonvisible_chars=True) == "\001\033[31m\002\x1b[31m\n\001\033[0m\002"

# Generated at 2022-06-11 17:47:44.442631
# Unit test for function stringc
def test_stringc():
    for ansi in ['black', 'blue', 'cyan', 'green', 'magenta', 'red', 'white', 'yellow']:
        for fg_sgr in [30, 1, 5]:
            for bg_sgr in [40, 4, 7]:
                color = "%s%s" % (fg_sgr, bg_sgr)
                color_code = u"%sm" % color
                assert "%s%s" % (color_code, ansi) in stringc(ansi, color)
                assert "%s%s" % (color_code, ansi) in stringc(ansi, color)
                assert "%s%s" % (color_code, ansi) in stringc(ansi, color)
                assert "\033[0m" in stringc(ansi, color)

# Generated at 2022-06-11 17:47:54.710769
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'color8') == u'38;5;8'
    assert parsecolor(u'rgb888') == u'38;5;232'
    assert parsecolor(u'gray0') == u'38;5;232'
    assert parsecolor(u'gray1') == u'38;5;233'
    assert parsecolor(u'gray23') == u'38;5;253'


# End of pretty module

# this code is used to check for disable_color flag
# It is largely the same code as in pretty, because it's used in both
# modes of this module
DISABLE_COLOR = False
if C.DISABLE_COLOR:
    DISABLE_COLOR = True

# Generated at 2022-06-11 17:48:03.969853
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("testhost", {}) == "testhost                  "
    if ANSIBLE_COLOR:
        assert hostcolor("testhost", {"failures": 1}) == "\x1b[31mtesthost                \x1b[0m"
        assert hostcolor("testhost", {"changed": 1}) == "\x1b[34mtesthost                \x1b[0m"
        assert hostcolor("testhost", {"unreachable": 1}) == "\x1b[31mtesthost                \x1b[0m"
        assert hostcolor("testhost", {"ok": 1}) == "\x1b[32mtesthost                \x1b[0m"
        assert hostcolor("testhost", {"ok": 1, "changed": 1}) == "\x1b[34mtesthost                \x1b[0m"


# Generated at 2022-06-11 17:48:08.017954
# Unit test for function stringc
def test_stringc():
    assert(
        stringc('hello', 'blue') == u"\033[34mhello\033[0m")
    assert(
        stringc('hello', 'white', True) == u"\001\033[37m\002hello\001\033[0m\002")



# Generated at 2022-06-11 17:48:18.393000
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("white") == u"38;5;15"
    assert parsecolor("black") == u"38;5;16"
    assert parsecolor("red") == u"38;5;124"
    assert parsecolor("blue") == u"38;5;21"
    assert parsecolor("cyan") == u"38;5;51"
    assert parsecolor("magenta") == u"38;5;201"
    assert parsecolor("yellow") == u"38;5;11"
    assert parsecolor("green") == u"38;5;28"
    assert parsecolor("34") == u"38;5;34"
    assert parsecolor("255") == u"38;5;255"

# Generated at 2022-06-11 17:48:34.022519
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.display import HostColor

    assert hostcolor('host1.example.com', dict(ok=0, failures=0, unreachable=0, changed=0)) == u'host1.example.com                '
    assert hostcolor('host1.example.com', dict(ok=0, failures=0, unreachable=0, changed=0), color=False) == u'host1.example.com              '
    assert hostcolor('host1.example.com', dict(ok=1, failures=0, unreachable=0, changed=0)) == u'\x1b[0;32mhost1.example.com       \x1b[0m'

# Generated at 2022-06-11 17:48:39.264857
# Unit test for function stringc
def test_stringc():
    tests = (
        (u'the quick brown fox', 'red'),
        (u'jumps over the lazy dog', 'green'),
        (u'the quick brown fox jumps over the lazy dog', 'blue')
    )
    for t in tests:
        print(stringc(t[0], t[1]))
# --- end "pretty"



# Generated at 2022-06-11 17:48:47.820770
# Unit test for function stringc
def test_stringc():
    global ANSIBLE_COLOR
    colors = ['black', 'red', 'green', 'yellow', 'blue', 'purple', 'cyan', 'white', 'gray']
    ANSIBLE_COLOR = False
    assert stringc(u'foo', u'black') == u'foo'
    ANSIBLE_COLOR = True
    for col in colors:
        assert stringc(u'foo', col) == u'\033[3%d;40mfoo\033[0m' % (colors.index(col))
    assert stringc(u'foo\nbar', u'blue') == '\033[34;40mfoo\nbar\033[0m'
    assert stringc(u'foo\nbar', 'color16') == '\033[38;5;16mfoo\nbar\033[0m'


# Generated at 2022-06-11 17:48:56.889891
# Unit test for function hostcolor

# Generated at 2022-06-11 17:49:08.075285
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("host", dict(failures=0, unreachable=0, changed=0), True) == \
        u"\x1b[32m%-37s\x1b[0m" % 'host'
    assert hostcolor("host", dict(failures=1, unreachable=0, changed=0), True) == \
        u"\x1b[31m%-37s\x1b[0m" % 'host'
    assert hostcolor("host", dict(failures=0, unreachable=0, changed=1), True) == \
        u"\x1b[33m%-37s\x1b[0m" % 'host'

# Generated at 2022-06-11 17:49:14.099959
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(ok=10, failures=1, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=False) == '%-26s' % 'localhost'
    assert hostcolor('localhost', stats) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

    stats['failures'] = 0
    assert hostcolor('localhost', stats) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

    stats['changed'] = 0
    assert hostcolor('localhost', stats) == u'%-37s' % stringc('localhost', C.COLOR_OK)



# Generated at 2022-06-11 17:49:16.708363
# Unit test for function colorize
def test_colorize():
    print(colorize('foo', 0, 'blue'))
    print(colorize('bar', 12, 'red'))



# Generated at 2022-06-11 17:49:26.582351
# Unit test for function stringc
def test_stringc():
    test_str = 'test'
    assert parsecolor('red') == '31'
    assert parsecolor('GREEN') == '32'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('rgb123') == '38;5;94'
    assert parsecolor('gray10') == '38;5;244'
    assert stringc(test_str, 'red') == u'\033[31mtest\033[0m'
    assert stringc(test_str, 'GREEN') == u'\033[32mtest\033[0m'
    assert stringc(test_str, 'color3') == u'\033[38;5;3mtest\033[0m'

# Generated at 2022-06-11 17:49:36.165333
# Unit test for function stringc

# Generated at 2022-06-11 17:49:46.273844
# Unit test for function hostcolor
def test_hostcolor():
    # Test default case
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 0}
    host = 'host'
    value = u"%-37s" % host
    assert hostcolor(host, stats) == value
    # Test fails case
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0, 'ok': 0}
    host = 'host'
    value = u"%-37s" % stringc(host, C.COLOR_ERROR)
    assert hostcolor(host, stats) == value
    # Test unreachable case
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0, 'ok': 0}
    host = 'host'

# Generated at 2022-06-11 17:50:00.658450
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color
    stats = dict(changed=0, unreachable=0, failures=0)
    h = hostcolor("okhost", stats, True)
    assert h == stringc("okhost", C.COLOR_OK)

    stats = dict(changed=2, unreachable=0, failures=0)
    h = hostcolor("changed", stats, True)
    assert h == stringc("changed", C.COLOR_CHANGED)

    stats = dict(changed=0, unreachable=1, failures=0)
    h = hostcolor("unreachable", stats, True)
    assert h == stringc("unreachable", C.COLOR_ERROR)

    stats = dict(changed=0, unreachable=0, failures=3)
    h = hostcolor("failed", stats, True)

# Generated at 2022-06-11 17:50:12.912743
# Unit test for function colorize
def test_colorize():

    red = [1, 2, 3, 4, 5]
    green = [6, 7, 8, 9, 10]
    numbers = red + green
    for num in numbers:
        if num in red:
            assert colorize('foo', num, 'red') == u"\033[31mfoo=%-4s\033[0m" % str(num)
        elif num in green:
            assert colorize('foo', num, 'green') == u"\033[32mfoo=%-4s\033[0m" % str(num)
        else:
            pass


# def disable_color(color=True):
#     """ Disable ANSIBLE_COLOR """
#     global ANSIBLE_COLOR
#     global C
#     ANSIBLE_COLOR = False
#     C = ANSIBLE_NOCOLOR

# Generated at 2022-06-11 17:50:22.740199
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""

    assert(stringc('foo', 'red') == u'\033[31mfoo\033[0m')
    assert(stringc('foo', 'blue') == u'\033[34mfoo\033[0m')
    assert(stringc('foo', 'green') == u'\033[32mfoo\033[0m')
    assert(stringc('foo', 'yellow') == u'\033[33mfoo\033[0m')
    assert(stringc('foo', '0') == u'\033[38;5;0mfoo\033[0m')
    assert(stringc('foo', '15') == u'\033[38;5;15mfoo\033[0m')

# Generated at 2022-06-11 17:50:32.266330
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor_test_host = 'hostcolor_test_host'
    assert hostcolor(hostcolor_test_host, {'failures': 0, 'unreachable': 0, 'ok': 1, 'changed': 1, 'skipped': 0}) == u"%-37s" % stringc('hostcolor_test_host', C.COLOR_CHANGED)
    assert hostcolor(hostcolor_test_host, {'failures': 1, 'unreachable': 0, 'ok': 1, 'changed': 1, 'skipped': 0}) == u"%-37s" % stringc('hostcolor_test_host', C.COLOR_ERROR)

# Generated at 2022-06-11 17:50:41.678750
# Unit test for function colorize
def test_colorize():
    # from ansible import callbacks
    # cb = callbacks.DefaultRunnerCallbacks()
    def test(color, result):
        # cb.colorize = colorize
        print(stringc("colorize: %s" % color, color, True))
        print(stringc("colorize: %s" % result, result, True))
        # print(cb.colorize("foo", -1, color))
        print("\n")
    test("normal", "normal")
    test("black", "black")
    test("blue", "blue")
    test("brown", "brown")
    test("cyan", "cyan")
    test("darkgray", "darkgray")
    test("green", "green")
    test("lightblue", "lightblue")
    test("lightcyan", "lightcyan")
   

# Generated at 2022-06-11 17:50:52.003302
# Unit test for function hostcolor
def test_hostcolor():
    import sys
    import pytest

    stats = {'ok': 10, 'failures': 20, 'unreachable': 30, 'changed': 40}

    # Color off
    ANSIBLE_COLOR = False
    assert hostcolor('test', stats, color=True) == '%-26s' % 'test'

    # Color on
    ANSIBLE_COLOR = True

    # OK
    assert hostcolor('test', {'ok': 10}, color=True) == '%-26s' % stringc('test', C.COLOR_OK)

    # Changed
    assert hostcolor('test', {'changed': 40}, color=True) == '%-26s' % stringc('test', C.COLOR_CHANGED)

    # Failed
    assert hostcolor('test', {'failures': 20}, color=True) == '%-26s'

# Generated at 2022-06-11 17:51:03.394794
# Unit test for function hostcolor
def test_hostcolor():

    class Dummy:
        def __init__(self, **kw):
            for k, v in kw.items():
                setattr(self, k, v)

    # No color
    stats = Dummy(failures=1, unreachable=0, changed=0)
    assert hostcolor('host', stats, False) == 'host                  '

    # Color
    stats = Dummy(failures=1, unreachable=0, changed=0)
    assert hostcolor('host', stats, True) == stringc('host', C.COLOR_ERROR)

    stats = Dummy(failures=0, unreachable=0, changed=0)
    assert hostcolor('host', stats, True) == stringc('host', C.COLOR_OK)

    stats = Dummy(failures=0, unreachable=1, changed=0)


# Generated at 2022-06-11 17:51:14.792343
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat import unittest
    class TestColorize(unittest.TestCase):

        def setUp(self):
            self.stats_ok = {
                'ok': 10,
                'changed': 5,
                'unreachable': 0,
                'skipped': 0,
                'failed': 0,
            }
            self.stats_changed = {
                'ok': 10,
                'changed': 0,
                'unreachable': 0,
                'skipped': 0,
                'failed': 5,
            }
            self.stats_fail = {
                'ok': 10,
                'changed': 0,
                'unreachable': 0,
                'skipped': 0,
                'failed': 0,
            }
            self.host_ok = 'host1.example.com'

# Generated at 2022-06-11 17:51:23.768786
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = dict(changed=1, ok=2, skipped=3, failed=4, unreachable=5)
    stats2 = dict(changed=0, ok=1, skipped=0, failed=0, unreachable=0)
    stats3 = dict(changed=0, ok=1, skipped=2, failed=1, unreachable=0)

    if ANSIBLE_COLOR:
        assert hostcolor("test", stats1) == u'%-37s' % u'\033[0;31;40mtest\033[0m'
        assert hostcolor("test", stats2) == u'%-37s' % u'\033[0;32;40mtest\033[0m'

# Generated at 2022-06-11 17:51:28.455908
# Unit test for function hostcolor
def test_hostcolor():
    # hostcolor is not pep8 compliant, but that is ok
    assert hostcolor("foobar", dict(ok=1), color=False) == u"foobar                 "
    assert hostcolor("foobar", dict(ok=1), color=True) == u"\x1b[0;32mfoobar               \x1b[0m"



# Generated at 2022-06-11 17:51:43.090597
# Unit test for function hostcolor
def test_hostcolor():
    if C.ANSIBLE_FORCE_COLOR:
        assert hostcolor('example.com', {"failures": 0, "unreachable": 0, "changed": 0}) == u'\u001b[0;32mexample.com        \u001b[0m'
        assert hostcolor('example.com', {"failures": 0, "unreachable": 0, "changed": 1}) == u'\u001b[0;33mexample.com        \u001b[0m'
        assert hostcolor('example.com', {"failures": 0, "unreachable": 1, "changed": 0}) == u'\u001b[0;31mexample.com        \u001b[0m'

# Generated at 2022-06-11 17:51:51.101866
# Unit test for function hostcolor
def test_hostcolor():
    clist = [None, 'blue', 'cyan', 'green', 'magenta',
             'red', 'white', 'yellow']
    olist = [u'ok', u'changed', u'unreachable', u'failed']

    for color in clist:
        for result in olist:
            host = 'test_' + result
            stats = {
                'ok': 1,
                'changed': 1,
                'unreachable': 1,
                'failures': 1,
            }
            if result == 'ok':
                stats['changed'] = 0
            elif result == 'changed':
                stats['failures'] = 0
                stats['unreachable'] = 0
            elif result == 'unreachable':
                stats['ok'] = 0
                stats['changed'] = 0

# Generated at 2022-06-11 17:52:01.019599
# Unit test for function stringc
def test_stringc():
    # We make the following tests:
    #   - A simple string in red
    #   - A string with a newline in red
    #   - A string with ANSI color codes in it already in blue
    #   - A string with ANSI color codes in it already and a newline in blue

    # The strings
    msg = u"This is a simple test"
    msgnl = u"This is a simple test\nwith a newline in it"
    msg_ansi = u"This is a simple test\n" \
               u"\033[36mwith an ANSI color in it\033[0m"

# Generated at 2022-06-11 17:52:03.615763
# Unit test for function colorize
def test_colorize():
    assert colorize("S", 0, None) == u"S=0   "
    assert colorize("S", 0, "yellow") == u"S=0   "
    lead = u"\u2713"
    num = 1
    assert colorize(lead, num, "green") == u"\u2713=1   "



# Generated at 2022-06-11 17:52:14.515806
# Unit test for function stringc
def test_stringc():
    assert u"\033[38;5;196mfoo\033[0m" == stringc(u"foo", "red", False)
    assert u"\033[38;5;196mfoo\033[0m" == stringc(u"foo", "color196", False)
    assert u"\033[38;5;160mfoo\033[0m" == stringc(u"foo", "rgb500", False)

    assert u"\001\033[38;5;196m\002foo\001\033[0m\002" == stringc(u"foo", "red", True)
    assert u"\001\033[38;5;196m\002foo\001\033[0m\002" == stringc(u"foo", "color196", True)

# Generated at 2022-06-11 17:52:26.033335
# Unit test for function stringc
def test_stringc():
    assert stringc(u"omg", u'bad color', False) == u'omg'
    assert stringc(u"omg", u'yellow', False) == u'\x1b[33momg\x1b[0m'
    assert stringc(u"omg", u'green', False) == u'\x1b[32momg\x1b[0m'
    assert stringc(u"omg", u'rgb0123', False) == u'\x1b[38;5;130momg\x1b[0m'
    assert stringc(u"omg", u'color001', False) == u'\x1b[38;5;1momg\x1b[0m'
    assert stringc(u"omg", u'gray99', False) == u

# Generated at 2022-06-11 17:52:35.234555
# Unit test for function stringc

# Generated at 2022-06-11 17:52:42.442966
# Unit test for function hostcolor
def test_hostcolor():
    # pylint: disable=anomalous-backslash-in-string
    def func_test(hostname, stats, color, result):
        def _compare(val1, val2):
            if getattr(val1, "__dict__", None) and val2 and getattr(val1, "__dict__", None) == val2.__dict__:
                return True
            else:
                return str(val1) == str(val2)

        hostcolor_result = hostcolor(hostname, stats, color)
        assert _compare(hostcolor_result, result), (
            "hostcolor(%s, %s, %s) returned '%r', expected '%r'" %
            (hostname, stats, color, hostcolor_result, result))


# Generated at 2022-06-11 17:52:47.552189
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host="host", stats=dict(failures=0, unreachable=0, changed=0), color=True) == u"%-37s"
    assert hostcolor(host="host", stats=dict(failures=5, unreachable=0, changed=0), color=True) == u"%-37s"
    assert hostcolor(host="host", stats=dict(failures=0, unreachable=0, changed=5), color=True) == u"%-37s"
    assert hostcolor(host="host", stats=dict(failures=0, unreachable=0, changed=0), color=False) == u"%-26s"


# Generated at 2022-06-11 17:52:56.902842
# Unit test for function stringc
def test_stringc():
    print(u"Testing function 'stringc'")
    print(stringc(u"Test stringc.", u"blue"))
    print(stringc(u"Test stringc.", u"red"))
    print(stringc(u"Test stringc.", u"CYAN"))
    print(stringc(u"Test stringc.", u"0"))
    print(stringc(u"Test stringc.", u"gReEn"))
    print(stringc(u"Test stringc.", u"rgb0120"))
    print(stringc(u"Test stringc.", u"rgb0120", wrap_nonvisible_chars=True))
    print(stringc(u"Test stringc.", u"rgb1200"))
    print(stringc(u"Test stringc.", u"rgb2120"))

# Generated at 2022-06-11 17:53:08.428868
# Unit test for function stringc
def test_stringc():
    """Returns True if stringc() works as expected."""

# Generated at 2022-06-11 17:53:19.178415
# Unit test for function hostcolor
def test_hostcolor():
    """Unit test for hostcolor"""
    from ansible.utils.unicode import to_unicode
    hstring = to_unicode(u'hostname')
    hstats = dict(failures=0, unreachable=0, changed=0)

    ANSIBLE_COLOR = True
    assert hostcolor(hstring, hstats) == u'\x1b[32;1mhostname            \x1b[0m'
    assert hostcolor(hstring, dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31;1mhostname            \x1b[0m'
    assert hostcolor(hstring, dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31;1mhostname            \x1b[0m'

# Generated at 2022-06-11 17:53:29.536685
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""

    # color forward
    s = u'test FORWARD'
    assert stringc(s, 'red') == u'\033[31m' + s + u'\033[0m'

    # color (w/leading space)
    s = u'test ' + s
    assert stringc(s, 'blue') == u'\033[34m' + s + u'\033[0m'

    # wrap_nonvisible_chars
    assert stringc(s, 'cyan', wrap_nonvisible_chars=True) == \
           u'\001\033[36m\002' + s + u'\001\033[0m\002'

    print(u'Function stringc: OK')


# Generated at 2022-06-11 17:53:41.163885
# Unit test for function stringc
def test_stringc():
    assert stringc("foo bar", "red", wrap_nonvisible_chars=False) == u'\x1b[31mfoo bar\x1b[0m'
    assert stringc("foo\nbar", "green", wrap_nonvisible_chars=False) == u'\x1b[32mfoo\nbar\x1b[0m'

    # Test colors

# Generated at 2022-06-11 17:53:48.292017
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    # color names
    assert stringc("red", "red") == u"\033[31mred\033[0m"
    assert stringc("green", "green") == u"\033[32mgreen\033[0m"
    assert stringc("blue", "blue") == u"\033[34mblue\033[0m"
    assert stringc("on_red", "on_red") == u"\033[41mon_red\033[0m"
    assert stringc("on_green", "on_green") == u"\033[42mon_green\033[0m"
    assert stringc("on_blue", "on_blue") == u"\033[44mon_blue\033[0m"

    # numeric color

# Generated at 2022-06-11 17:53:58.117922
# Unit test for function stringc
def test_stringc():
    """ stringc(text, color)

    Simple test for the stringc function.
    """
    # Get a color object for testing
    curses.setupterm()
    def get_color(color):
        """Return the SGR parameters for color."""
        return curses.tigetstr(u"setaf") + curses.tparm(curses.tigetstr(u"setaf"),
                                                        curses.color_content(color))
    assert get_color(curses.COLOR_YELLOW) != u''
    # Test simple string
    assert stringc(u'TestString', C.COLOR_ERROR) == (
        u'\033[31mTestString\033[0m')
    # Test color matching

# Generated at 2022-06-11 17:54:03.775281
# Unit test for function stringc
def test_stringc():
    assert stringc(u"This is a test.",
                   u"green") == u'\033[32mThis is a test.\033[0m'
    assert stringc(u"This is a test.",
                   u"color233",
                   wrap_nonvisible_chars=True) == u'\001\033[38;5;233m\002This is a test.\001\033[0m\002'

# Generated at 2022-06-11 17:54:10.423999
# Unit test for function stringc
def test_stringc():
    ''' test_stringc unit tests '''
    # Colored result and expected result differ in case, because
    # the terminal is unable to display upercase
    assert stringc("hello", 'red') == '\033[31mhello\033[0m'
    assert stringc("hello", 'RED') == '\033[31mhello\033[0m'
    assert stringc("hello", 'Green') == '\033[32mhello\033[0m'
    assert stringc("hello\nworld!", 'blue') == '\033[34mhello\nworld!\033[0m'
    assert stringc("hello\nworld!", 'GREEN') == '\033[32mhello\nworld!\033[0m'
    # Check invisible characters works

# Generated at 2022-06-11 17:54:22.057424
# Unit test for function stringc

# Generated at 2022-06-11 17:54:33.639806
# Unit test for function stringc

# Generated at 2022-06-11 17:54:43.743557
# Unit test for function colorize
def test_colorize():
    colors = ['blue', 'dark gray', 'green', 'light gray', 'red', 'white', 'yellow']
    for color in colors:
        print(colorize('>', '>', color))



# Generated at 2022-06-11 17:54:53.877731
# Unit test for function hostcolor
def test_hostcolor():
    from collections import namedtuple
    stats = namedtuple('Stats', 'changed, failures, unreachable')
    # No changes, nothing bad happened
    assert hostcolor('localhost', stats(changed=0, failures=0, unreachable=0)) == u'localhost                    '
    # Something was changed
    assert hostcolor('localhost', stats(changed=1, failures=0, unreachable=0)) == u'localhost                    '
    # Host unreachable
    assert hostcolor('localhost', stats(changed=0, failures=0, unreachable=1)) == u'localhost                    '
    # Host failed
    assert hostcolor('localhost', stats(changed=0, failures=1, unreachable=0)) == u'localhost                    '
    # Dummy test for ANSIBLE_NOCOLOR check

# Generated at 2022-06-11 17:55:04.314369
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"green", wrap_nonvisible_chars=True) == u"\001\033[32m\002foo\001\033[0m\002"
    assert stringc(u"foo", u"color15") == u"\033[38;5;15mfoo\033[0m"
    assert stringc(u"foo", u"rgb255") == u"\033[38;5;231mfoo\033[0m"
    assert stringc(u"foo", u"rgb255", wrap_nonvisible_chars=True) == u"\001\033[38;5;231m\002foo\001\033[0m\002"

   