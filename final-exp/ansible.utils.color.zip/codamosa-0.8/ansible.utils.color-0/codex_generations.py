

# Generated at 2022-06-11 17:45:17.851625
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('test',
                     {'failures': 0, 'unreachable': 0, 'ok': 1, 'changed': 1, 'skipped': 0}) == u'%-37s' % stringc('test', C.COLOR_CHANGED)
    assert hostcolor('test',
                     {'failures': 0, 'unreachable': 0, 'ok': 1, 'changed': 0, 'skipped': 0}) == u'%-37s' % stringc('test', C.COLOR_OK)
    assert hostcolor('test',
                     {'failures': 1, 'unreachable': 0, 'ok': 0, 'changed': 0, 'skipped': 0}) == u'%-37s' % stringc('test', C.COLOR_ERROR)

# Generated at 2022-06-11 17:45:24.627825
# Unit test for function parsecolor
def test_parsecolor():
    def _test(color, sgr):
        if parsecolor(color) != sgr:
            raise AssertionError("parsecolor(%r) != %r" % (color, sgr))

    # color
    for color in range(0, 256):
        _test("color%d" % color, "38;5;%d" % color)

    _test("color257", "38;5;1")
    _test("color-1", "38;5;255")

    # rgb

# Generated at 2022-06-11 17:45:36.952431
# Unit test for function hostcolor
def test_hostcolor():
    # see also test in ansible/lib/test/unit/test_utils.py
    for color in [C.COLOR_OK, C.COLOR_CHANGED, C.COLOR_ERROR]:
        assert parsecolor(color) is not None
    for color in ["color0", "color1", "color2", "color3", "color4", "color5", "color6", "color7", "color8", "color9", "color10", "color11", "color12"]:
        assert parsecolor(color) is not None
    assert hostcolor('some_host', {'changed': 0, 'ok':34, 'unreachable' : 0, 'failures' : 0}, color=C.ANSIBLE_FORCE_COLOR) is not None

# Generated at 2022-06-11 17:45:45.329054
# Unit test for function parsecolor
def test_parsecolor():
    # Testing for all named colors
    for color in C.COLOR_CODES:
        assert parsecolor(color) == C.COLOR_CODES[color]
    # Testing for all ANSI RGB values
    for i in range(16):
        assert parsecolor('color%d' % i) == u'38;5;%d' % i
    for i in range(16):
        assert parsecolor('rgb%d%d%d' % (i / 36, (i / 6) % 6, i % 6)) == u'38;5;%d' % (16 + i)
    # Testing for all ANSI Gray values
    for i in range(24):
        assert parsecolor('gray%d' % i) == u'38;5;%d' % (232 + i)

# Generated at 2022-06-11 17:45:53.054436
# Unit test for function hostcolor
def test_hostcolor():
    from os.path import basename
    import optparse
    from ansible.playbook.play_context import PlayContext

    parser = optparse.OptionParser("usage: %prog [options]")
    parser.add_option('--no-color', dest='no_color', action="store_true",
            default=False, help="don't colorize output")

    (options, args) = parser.parse_args()

    pc = PlayContext()
    pc.remote_addr = '127.0.0.1'
    pc.remote_user = 'user'
    pc.no_log = True


# Generated at 2022-06-11 17:46:02.509406
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 12, 'blue') == u'foo=12  '
    assert colorize('foo', 123, 'blue') == u'foo=123 '
    assert colorize('foo', 1234, 'blue') == u'foo=1234'
    assert colorize('foo', 12345, 'blue') == u'foo=12345'
    assert colorize('foo', -1, 'blue') == u'foo=-1  '
    assert colorize('foo', -12, 'blue') == u'foo=-12 '
    assert colorize('foo', -123, 'blue') == u'foo=-123'

# Generated at 2022-06-11 17:46:12.230815
# Unit test for function colorize
def test_colorize():
    # No color
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'
    assert colorize('foo', 10000, None) == 'foo=10000'

    # With color
    ANSIBLE_COLOR = True
    assert colorize('foo', 0, 'blue') == '\033[38;5;27mfoo=0   \033[0m'
    assert colorize('foo', 1, 'blue') == '\033[38;5;27mfoo=1   \033[0m'
   

# Generated at 2022-06-11 17:46:22.196766
# Unit test for function colorize
def test_colorize():
    """Simple test for colorize()"""
    assert colorize('test', 4, 'blue') == u'test=4   '
    assert colorize('test', 4, None) == 'test=4   '
    assert colorize('test', 0, 'red') == u'test=0   '
    assert colorize('test', 0, None) == 'test=0   '
    assert colorize('test', -4, 'red') == u'test=-4  '
    assert colorize('test', -4, None) == 'test=-4  '
    assert colorize('test', '???', 'red') == u'test=??? '
    assert colorize('test', '???', None) == 'test=??? '

# Generated at 2022-06-11 17:46:31.110110
# Unit test for function stringc
def test_stringc():
    def compare(x, y):
        x = stringc(x, 'red', wrap_nonvisible_chars=True)
        assert x == y, "expected '%s' but got '%s'" % (y, x)

    compare("foo", "\001\033[31m\002foo\001\033[0m\002")
    compare("hello\nworld",
            "\001\033[31m\002hello\001\033[0m\002\n\001\033[31m\002world\001\033[0m\002")
    compare("hello\nworld\n",
            "\001\033[31m\002hello\001\033[0m\002\n\001\033[31m\002world\001\033[0m\002\n")
    compare("", "")


# Generated at 2022-06-11 17:46:41.261892
# Unit test for function stringc
def test_stringc():
    """ Testing color string functionality """
    class BColors:
        """ ANSI color escape sequences """
        HEADER = '\033[95m'
        OKBLUE = '\033[94m'
        OKGREEN = '\033[92m'
        WARNING = '\033[93m'
        FAIL = '\033[91m'
        ENDC = '\033[0m'
        BOLD = '\033[1m'
        UNDERLINE = '\033[4m'

    print(stringc('Basic colors: black red green yellow blue magenta cyan white',
                  'black', True))
    print(stringc('Basic colors: black red green yellow blue magenta cyan white',
                  'red', True))

# Generated at 2022-06-11 17:46:54.795030
# Unit test for function colorize
def test_colorize():
    expected = u"foo=1   "
    current = colorize("foo", 1, None)
    assert current == expected, "%s != %s" % (current, expected)

    expected = u"foo=1   "
    current = colorize("foo", 1, "normal")
    assert current == expected, "%s != %s" % (current, expected)

    expected = u"foo=N/A "
    current = colorize("foo", 0, "normal")
    assert current == expected, "%s != %s" % (current, expected)


# --- end "pretty"

# special color handling for action plugin errors


# Generated at 2022-06-11 17:47:04.279938
# Unit test for function stringc
def test_stringc():
    s = stringc("Normal text.", 'white', True)
    assert s == u"\001\033[97m\002Normal text.\001\033[0m\002"
    s = stringc("Normal text.", 'white', False)
    assert s == u"\033[97mNormal text.\033[0m"
    s = stringc("Normal text.\nSecond line.", 'white', False)
    assert s == u"\033[97mNormal text.\033[0m\n\033[97mSecond line.\033[0m"
    s = stringc("Normal text.\nSecond line.", 'white', True)

# Generated at 2022-06-11 17:47:15.541012
# Unit test for function hostcolor
def test_hostcolor():
    host = "test_host"
    stats = {'failures': 1, 'unreachable': 1, 'ok': 8, 'changed': 2}
    color = True
    if not hostcolor(host, stats, color).startswith(stringc(host, C.COLOR_ERROR)):
        raise Exception()
    stats = {'failures': 0, 'unreachable': 0, 'ok': 8, 'changed': 2}
    if not hostcolor(host, stats, color).startswith(stringc(host, C.COLOR_CHANGED)):
        raise Exception()
    stats = {'failures': 0, 'unreachable': 0, 'ok': 8, 'changed': 0}
    if not hostcolor(host, stats, color).startswith(stringc(host, C.COLOR_OK)):
        raise

# Generated at 2022-06-11 17:47:22.853933
# Unit test for function colorize
def test_colorize():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert colorize("ok", 5, C.COLOR_OK) == u"\n".join([u"\033[32mok=5   \033[0m"]*2)
    assert colorize("changed", 1, C.COLOR_CHANGED) == u"\n".join([u"\033[33mchanged=1 \033[0m"]*2)
    assert colorize("unreachable", 0, C.COLOR_UNREACHABLE) == u"\n".join([u"\033[31munreachable=0\033[0m"]*2)
    assert colorize("failed", 1, C.COLOR_ERROR) == u"\n".join([u"\033[31mfailed=1  \033[0m"]*2)


# Generated at 2022-06-11 17:47:32.331997
# Unit test for function hostcolor
def test_hostcolor():
    pass
    # To manually test these, comment out the 'pass' statement above and
    # then run
    #    ansible-playbook -i tests/inventory tests/playbooks/test_hostcolor.yml
    #
    #assert hostcolor('host1', dict(ok=1), True) == u'\033[32mhost1\033[0m'
    #assert hostcolor('host2', dict(changed=1), True) == u'\033[33mhost2\033[0m'
    #assert hostcolor('host3', dict(failed=1), True) == u'\033[31mhost3\033[0m'
    #assert hostcolor('host4', dict(unreachable=1), True) == u'\033[31mhost4\033[0m'
    #assert hostcolor('host

# Generated at 2022-06-11 17:47:45.107556
# Unit test for function parsecolor
def test_parsecolor():
    def test_color(color, expected):
        result = ANSIBLE_COLOR and parsecolor(color)
        if result != expected:
            print(u"FAIL: Expected parsecolor(%s) == %s, got %s" %
                  (color, expected, result))
        else:
            print(u"PASS: Got expected result for parsecolor(%s)" % color)

    test_color('blue', u'38;5;4')
    test_color('dark gray', u'38;5;234')
    test_color('color234', u'38;5;234')
    test_color('rgb255000255', u'38;5;203')
    test_color('rgb12345', u'38;5;123')
    test_color('rgb999', None)
    test

# Generated at 2022-06-11 17:47:51.350817
# Unit test for function colorize
def test_colorize():
    assert colorize('le', 0, 'blue') == 'le=0   '
    assert colorize('ad', 4, 'blue') == 'ad=4   '
    assert colorize('ad', 4, 'bogus') == 'ad=4   '


# --- end "pretty"


# Function to compare version strings. Return True if
# first version is less than second. This function returns
# False if the versions represent the same software.

# Generated at 2022-06-11 17:47:59.440169
# Unit test for function stringc
def test_stringc():
    assert stringc("abc", "black") == u"\033[30mabc\033[0m"
    assert stringc("abc", "red") == u"\033[31mabc\033[0m"
    assert stringc("abc", "green") == u"\033[32mabc\033[0m"
    assert stringc("abc", "yellow") == u"\033[33mabc\033[0m"
    assert stringc("abc", "blue") == u"\033[34mabc\033[0m"
    assert stringc("abc", "magenta") == u"\033[35mabc\033[0m"
    assert stringc("abc", "cyan") == u"\033[36mabc\033[0m"

# Generated at 2022-06-11 17:48:08.305589
# Unit test for function stringc
def test_stringc():
    print(stringc('foo', 'blue'))
    print(stringc('foo', 'blue', wrap_nonvisible_chars=True))
    print(stringc('foo', 'color3'))
    print(stringc('foo', 'color3', wrap_nonvisible_chars=True))
    print(stringc('foo', 'rgb125'))
    print(stringc('foo', 'rgb125', wrap_nonvisible_chars=True))
    print(stringc('foo', 'gray5'))
    print(stringc('foo', 'gray5', wrap_nonvisible_chars=True))


# --- end of "pretty"

# Generated at 2022-06-11 17:48:18.778551
# Unit test for function stringc
def test_stringc():
    ''' Output should be the same as input because ANSIBLE_COLOR=False '''
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    text1 = "\n"
    text2 = "Hello world"
    text3 = "\x1b[;31mHello\x1b[0m world"
    def test_output(text, color):
        output = stringc(text, color)
        print(u"\ninput:  \"{0}\"".format(text))
        print(u"output: \"{0}\"".format(output))
        assert output == text
    # - Test 1: empty string
    test_output(text1, 'red')
    # - Test 2: plain string
    test_output(text2, 'red')
    # - Test 3: colored string
    test_

# Generated at 2022-06-11 17:48:34.472793
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('GREEN') == '32'
    assert parsecolor('yEllow') == '33'
    assert parsecolor('blUe') == '34'
    assert parsecolor('magEnTA') == '35'
    assert parsecolor('cyAn') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'

# Generated at 2022-06-11 17:48:45.070433
# Unit test for function parsecolor
def test_parsecolor():
    # color number
    assert parsecolor("color16") == u"38;5;16"
    # rgb color
    assert parsecolor("rgb020") == u"38;5;46"
    assert parsecolor("rgb255") == u"38;5;231"
    assert parsecolor("rgb204") == u"38;5;178"
    assert parsecolor("rgb555") == u"38;5;231"
    # gray color
    assert parsecolor("gray0") == u"38;5;232"
    assert parsecolor("gray1") == u"38;5;233"
    assert parsecolor("gray23") == u"38;5;255"
    assert parsecolor("gray24") == u"38;5;255"
    # normal color
    assert parsec

# Generated at 2022-06-11 17:48:55.505896
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('green') == u'38;5;10'
    assert parsecolor('yellow') == u'38;5;11'
    assert parsecolor('blue') == u'38;5;12'
    assert parsecolor('magenta') == u'38;5;13'
    assert parsecolor('cyan') == u'38;5;14'
    assert parsecolor('lightgray') == u'38;5;7'
    assert parsecolor('darkgray') == u'38;5;8'
    assert parsecolor('lightred') == u'38;5;9'
    assert parsecolor('lightgreen') == u'38;5;10'

# Generated at 2022-06-11 17:49:07.025563
# Unit test for function stringc
def test_stringc():
    # Test color list
    for color, sgr in C.COLOR_CODES.items():
        test_str = 'test_stringc'
        sgr_str = u"\033[%sm%s\033[0m" % (sgr, test_str)
        assert stringc(test_str, color, False) == sgr_str
        assert stringc(test_str, sgr, False) == sgr_str

    # Test True color, RGB and gray
    assert stringc('test_stringc', 'color1') == u'\033[38;5;1mtest_stringc\033[0m'
    assert stringc('test_stringc', 'rgb211') == u'\033[38;5;11mtest_stringc\033[0m'

# Generated at 2022-06-11 17:49:14.936394
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('1') == '38;5;1'
    assert parsecolor('01') == '38;5;1'
    assert parsecolor('11') == '38;5;11'
    assert parsecolor('222') == '38;5;222'
    assert parsecolor('2222') == '38;5;222'
    assert parsecolor('rgb123') == '38;5;54'
    assert parsecolor('rgb121') == '38;5;50'
    assert parsecolor('rgb212') == '38;5;118'
    assert parsecolor('rgb111') == '38;5;16'
    assert parsecolor('rgb211') == '38;5;124'
    assert parsecolor('rgb121') == '38;5;50'

# Generated at 2022-06-11 17:49:21.894965
# Unit test for function hostcolor
def test_hostcolor():
    test_host = 'test_host'
    test_stats = {'failures': 0, 'changed': 0, 'ok': 4, 'skipped': 0, 'unreachable': 0}
    test_color_true = hostcolor(test_host, test_stats, True)
    test_color_false = hostcolor(test_host, test_stats, False)
    assert test_color_true == test_color_false


# Generated at 2022-06-11 17:49:29.222938
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, u'red') == u"foo=0   "
    assert colorize(u"foo", 10, u'red') == u"foo=10  "
    assert colorize(u"foo", 100, u'red') == u"foo=100 "
    assert colorize(u"foo", 1000, None) == u"foo=1000"
    assert colorize(u"foo", 1000, u'red') == u"foo=1000"
    assert colorize(u"foo", 1000, u'blue') == u"foo=1000"
    assert colorize(u"foo", 1000, u'yellow') == u"foo=1000"
    assert colorize(u"foo", -1, u'blue') == u"foo=-1  "

# Generated at 2022-06-11 17:49:37.760448
# Unit test for function colorize
def test_colorize():

    from ansible.cli.playbook import PlaybookCLI
    from ansible.playbook.play_context import PlayContext
    from ansible.module_utils.six import PY3
    import __builtin__
    if PY3:
        import builtins
        __builtin__ = builtins
    else:
        __builtin__.__dict__.update(dict(
        warn=lambda *a, **kw: None,
    ))

    sys.argv = ['ansible-playbook', '-c', 'local', '--hosts=127.0.0.1', '--limit=all']
    cli = PlaybookCLI()
    cli.parse()
    play_context = PlayContext(cli=cli)
    play_context.check = False
    play_context.diff = False
    setattr

# Generated at 2022-06-11 17:49:47.358341
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('green') == '32'
    assert parsecolor('normal') == '39'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('color256') == '38;5;256'
    assert parsecolor('rgb123') == '38;5;123'
    assert parsecolor('rgb16') == '38;5;16'
    assert parsecolor('rgb256') == '38;5;256'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray23') == '38;5;255'
    assert parsecolor('gray24') == '38;5;255'
    assert parsecolor('gray') == '38;5;241'


# --- end "pretty"
#

# Generated at 2022-06-11 17:49:58.873375
# Unit test for function hostcolor
def test_hostcolor():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    # no failed, unreachable, changed
    assert hostcolor("host1", {"failures": 0, "unreachable": 0, "changed": 0}) == u'\u001b[0mhost1\u001b[0m'
    # failed
    assert hostcolor("host2", {"failures": 1, "unreachable": 0, "changed": 0}) == u'\u001b[0;31mhost2\u001b[0m'
    # unreachable
    assert hostcolor("host3", {"failures": 0, "unreachable": 2, "changed": 0}) == u'\u001b[0;31mhost3\u001b[0m'
    # changed

# Generated at 2022-06-11 17:50:05.939044
# Unit test for function stringc
def test_stringc():
    assert stringc('hello', 'blue') == '\033[0;34mhello\033[0m'



# Generated at 2022-06-11 17:50:11.534687
# Unit test for function stringc
def test_stringc():
    color_codes = ('black', 'red', 'green', 'yellow', 'blue', 'magenta',
                   'cyan', 'white')
    for fg in color_codes:
        print(stringc(fg, fg))
    for bg in color_codes:
        print(stringc('bg:', fg, bg))

# Generated at 2022-06-11 17:50:14.719298
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 1, 'unreachable': 1, 'ok': 1, 'skipped': 1, 'changed': 1}
    print(hostcolor('localhost', stats))



# Generated at 2022-06-11 17:50:23.939999
# Unit test for function stringc
def test_stringc():
    print(stringc('some text', 'magenta', wrap_nonvisible_chars=False))
    print(stringc('some text', C.COLOR_CODES['magenta'], wrap_nonvisible_chars=False))
    print(stringc('some text', 'color25', wrap_nonvisible_chars=False))
    print(stringc('some text', 'rgb2552', wrap_nonvisible_chars=False))
    print(stringc('some text', 'rgb252', wrap_nonvisible_chars=False))
    print(stringc('some text', 'rgb25522', wrap_nonvisible_chars=False))
    print(stringc('some text', 'rgb255225', wrap_nonvisible_chars=False))

# Generated at 2022-06-11 17:50:29.134819
# Unit test for function colorize
def test_colorize():
    """
    %s = 4
    %s = 0
    %s = 1
    """

    _v = (colorize('a', 4, 'green'), colorize('b', 0, 'red'), colorize('c', 1, 'yellow'))
    assert stringc(_v, 'blue') == stringc('\n'.join(_v), 'blue')



# Generated at 2022-06-11 17:50:38.878400
# Unit test for function hostcolor
def test_hostcolor():
    s = {}
    assert hostcolor("localhost", s, True) == u"%-26s" % stringc("localhost", C.COLOR_OK)
    s['changed'] = 1
    assert hostcolor("localhost", s, True) == u"%-26s" % stringc("localhost", C.COLOR_CHANGED)
    s['changed'] = 0
    s['failures'] = 1
    assert hostcolor("localhost", s, True) == u"%-26s" % stringc("localhost", C.COLOR_ERROR)
    s['unreachable'] = 1
    assert hostcolor("localhost", s, True) == u"%-26s" % stringc("localhost", C.COLOR_ERROR)



# Generated at 2022-06-11 17:50:49.993302
# Unit test for function hostcolor
def test_hostcolor():
    # Set stats and color_error.
    stats = dict(changed=0, unreachable=1, failures=2)
    color = 'red'
    # Set host
    host = '127.0.0.1'

    # Test when ANSIBLE_COLOR is True.
    # Test function hostcolor
    ANSIBLE_COLOR = True
    assert hostcolor(host, stats, color) == \
        u"\033[31m%-37s\033[0m" % stringc(host, C.COLOR_ERROR)

    # Set stats and color_error.
    stats = dict(changed=2, unreachable=0, failures=0)
    color = 'red'
    # Set host
    host = '127.0.0.1'

    # Test when ANSIBLE_COLOR is True.
    # Test function host

# Generated at 2022-06-11 17:51:01.820925
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.playbook.play_context import PlayContext
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.inventory.ini import InventoryParser


# Generated at 2022-06-11 17:51:08.565000
# Unit test for function colorize
def test_colorize():
    s = colorize('a', 2, 'black')
    if s != "a=2   ":
        print("failed a")
        return 1
    s = colorize('a', 2, 'red_black')
    if s[0] != "\x1b":
        print("failed b")
        return 1
    if s[-5:] != "=2   ":
        print("failed c")
        return 1
    s = colorize('a', 100, 'red_black')
    if s[0] != "\x1b":
        print("failed d")
        return 1
    if s[-6:] != "=100  ":
        print("failed e")
        return 1
    s = colorize('a', 100, None)

# Generated at 2022-06-11 17:51:12.149186
# Unit test for function colorize
def test_colorize():
    assert colorize("x", 0, C.COLOR_ERROR) == u"x=0   "
    assert colorize("x", 1, C.COLOR_ERROR) == u"\033[31mx=1   \033[0m"



# Generated at 2022-06-11 17:51:22.272677
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0,
             'unreachable': 0,
             'changed': 0}
    assert hostcolor('localhost', stats, False) == 'localhost              '
    if ANSIBLE_COLOR:
        assert hostcolor('localhost', stats, True) == '\x1b[32mlocalhost\x1b[0m            '

    stats = {'failures': 1,
             'unreachable': 0,
             'changed': 0}
    assert hostcolor('localhost', stats, False) == 'localhost              '
    if ANSIBLE_COLOR:
        assert hostcolor('localhost', stats, True) == '\x1b[31mlocalhost\x1b[0m            '

    stats = {'failures': 0,
             'unreachable': 1,
             'changed': 0}

# Generated at 2022-06-11 17:51:26.625135
# Unit test for function colorize
def test_colorize():
    assert colorize(u'foo', 0, 'green') == u'foo=0   '
    assert colorize(u'foo', 1, 'green') == u'\x1b[32mfoo=1   \x1b[0m'
    assert colorize(u'foo', 1, None) == u'foo=1   '


# Generated at 2022-06-11 17:51:38.394423
# Unit test for function stringc
def test_stringc():
    ''' stringc returns the expected string '''
    assert stringc("test", "blue") == "\033[0;34mtest\033[0m"
    assert stringc("test", "bold blue") == "\033[1;34mtest\033[0m"
    assert stringc("test", "red") == "\033[0;31mtest\033[0m"
    assert stringc("test", "underline cyan") == "\033[4;36mtest\033[0m"
    assert stringc("test", "inverse blue") == "\033[7;34mtest\033[0m"
    assert stringc("test", "nocolor") == "test"


# Generated at 2022-06-11 17:51:46.236060
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == stringc('localhost', C.COLOR_OK)


# Generated at 2022-06-11 17:51:58.825706
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils.six import PY3
    if PY3:
        from io import StringIO
    else:
        from cStringIO import StringIO
    s = StringIO()
    backup = sys.stdout
    sys.stdout = s
    hostcolor(u'foohost', dict(changed=0, failures=0, skipped=0, unreachable=0, ok=1), True)
    sys.stdout = backup
    assert s.getvalue() == u"foohost  \n"
    s = StringIO()
    backup = sys.stdout
    sys.stdout = s
    hostcolor(u'foohost', dict(changed=0, failures=0, skipped=0, unreachable=0, ok=1), False)
    sys.stdout = backup
    assert s.get

# Generated at 2022-06-11 17:52:10.019860
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize

    This tests each of the parameters for failure, unreachable, and changed for
    each of the possible settings for ANSIBLE_COLOR (with color turned on or
    off).

    """

    # Set ANSIBLE_COLOR to False and do a true
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize(u'f', 0, C.COLOR_ERROR) == u"f=0   "
    assert colorize(u'u', 0, C.COLOR_ERROR) == u"u=0   "
    assert colorize(u'c', 0, C.COLOR_CHANGED) == u"c=0   "

    # Set ANSIBLE_COLOR to True and do a false
    ANSIBLE_COLOR = True

# Generated at 2022-06-11 17:52:17.986496
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc()."""
    assert console.stringc('hello', 'blue') == '\033[34mhello\033[0m'
    assert console.stringc('hello', 'black') == '\033[30mhello\033[0m'
    assert console.stringc('hello', 'default') == '\033[39mhello\033[0m'
    assert console.stringc('hello', 'darkgray') == '\033[90mhello\033[0m'
    assert console.stringc('hello', 'lightblue') == '\033[94mhello\033[0m'
    assert console.stringc('hello', 'white') == '\033[97mhello\033[0m'

# Generated at 2022-06-11 17:52:23.810144
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {"failures": 0, "changed": 0, "unreachable": 0}) == "%-26s" % "localhost"
    assert hostcolor("localhost", {"failures": 0, "changed": 1, "unreachable": 0}) == "%-37s" % stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", {"failures": 0, "changed": 0, "unreachable": 1}) == "%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", {"failures": 1, "changed": 1, "unreachable": 1}) == "%-37s" % stringc("localhost", C.COLOR_ERROR)

# Generated at 2022-06-11 17:52:30.259531
# Unit test for function colorize
def test_colorize():
    """ test for colorize() """
    if sys.version_info >= (3, 0):
        return
    if ord(u"\033") == 1:
        return
    if not ANSIBLE_COLOR:
        return

    def _strip_escapes(s):
        """ Strip '\x1b[1;31m' style escapes from the given string """
        return re.sub(r'\x1b\[(\d+)(;\d+)*m', '', s).replace(u"\001", u"").replace(u"\002", u"")

    lead = u"test"
    num = u"12345"
    color = None

    assert _strip_escapes(colorize(lead, num, color)) == u"%s=%s" % (lead, num)
    color = C.COLOR

# Generated at 2022-06-11 17:52:40.934568
# Unit test for function stringc
def test_stringc():
    """Tests the stringc function"""

    # ANSI color table
    # 0 Black
    # 1 Red
    # 2 Green
    # 3 Yellow
    # 4 Blue
    # 5 Magenta
    # 6 Cyan
    # 7 White
    # (8-15 are the bold-bright equivalents)

    # ANSI background table
    # 40 Black Background
    # 41 Red Background
    # 42 Green Background
    # 43 Yellow Background
    # 44 Blue Background
    # 45 Magenta Background
    # 46 Cyan Background
    # 47 White Background
    # (48-55 are the bold-bright equivalents)

    # ANSI 16-color table
    # 0-15: 16 basic colors
    # 16-231: 6x6x6 color cube
    # 232-255: grayscale ramp


# Generated at 2022-06-11 17:52:58.139212
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-26s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-26s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-26s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), False)

# Generated at 2022-06-11 17:53:03.215669
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('myhost.example.org', stats={'failures':0, 'unreachable':0, 'changed':0}, color=True) == u'\033[0;32m%-37s\033[0m'

# Generated at 2022-06-11 17:53:14.401741
# Unit test for function stringc
def test_stringc():
    # should return non-empty string
    assert len(stringc("test", "green"))

    # should remove color-related escape sequences
    assert stringc("test", "green", wrap_nonvisible_chars=True).startswith("\001")
    assert stringc("test", "green", wrap_nonvisible_chars=True).endswith("\002")
    assert not stringc("test", "green", wrap_nonvisible_chars=False).startswith("\001")
    assert not stringc("test", "green", wrap_nonvisible_chars=False).endswith("\002")

    # should add color-related escape sequences
    assert not stringc("test", "none", wrap_nonvisible_chars=True).startswith("\001\033[")

# Generated at 2022-06-11 17:53:22.365490
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return
    ANSIBLE_COLOR = True
    stats = {'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor('green', stats, True) == u'%-37s' % stringc('green', 'GREEN')
    stats = {'ok': 0, 'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor('red', stats, True) == u'%-37s' % stringc('red', 'RED')
    stats = {'ok': 0, 'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor('red', stats, True) == u'%-37s' % stringc('red', 'RED')

# Generated at 2022-06-11 17:53:30.017916
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('localhost', {'failures': 1, 'unreachable': 2, 'changed': 3, 'ok': 4}))
    print(hostcolor('localhost', {'failures': 1, 'unreachable': 2, 'changed': 0, 'ok': 4}))
    print(hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 3, 'ok': 4}))
    print(hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 4}))



# Generated at 2022-06-11 17:53:41.451987
# Unit test for function stringc
def test_stringc():
    """ Unit tests for function stringc """
    assert stringc(u'foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc(u'foo', 'green') == u"\033[32mfoo\033[0m"
    assert stringc(u'foo', 'yellow') == u"\033[33mfoo\033[0m"
    assert stringc(u'foo', 'blue') == u"\033[34mfoo\033[0m"
    assert stringc(u'foo', 'magenta') == u"\033[35mfoo\033[0m"
    assert stringc(u'foo', 'cyan') == u"\033[36mfoo\033[0m"

# Generated at 2022-06-11 17:53:48.464884
# Unit test for function hostcolor
def test_hostcolor():
    # hostcolor doesn't return color-coded strings unless ANSIBLE_COLOR is True
    # Test that it unconditionally returns an unmodified string if ANSIBLE_COLOR
    # is False
    ANSIBLE_COLOR = False
    unmodified_text = hostcolor('localhost', {'failures': 0, 'changed': 0, 'unreachable': 0})
    assert unmodified_text == u'localhost'
    ANSIBLE_COLOR = True
    # Test "localhost" being OK
    ok_text = hostcolor('localhost', {'failures': 0, 'changed': 0, 'unreachable': 0})
    ok_text = re.sub(r'\033\[\d+m', '', ok_text)
    assert ok_text == u'localhost'
    # Test "localhost" being unreachable
    unreachable_text = host

# Generated at 2022-06-11 17:53:58.217963
# Unit test for function stringc
def test_stringc():
    def clean_escapecodes(text):
        return re.sub(r"\x1b\[[0-9;]*m", '', text)

    if ANSIBLE_COLOR:
        assert clean_escapecodes(stringc('hello', 'black')) == 'hello'
        assert clean_escapecodes(stringc('hello', 'red')) == 'hello'
        assert clean_escapecodes(stringc('hello', 'green')) == 'hello'
        assert clean_escapecodes(stringc('hello', 'yellow')) == 'hello'
        assert clean_escapecodes(stringc('hello', 'blue')) == 'hello'
        assert clean_escapecodes(stringc('hello', 'magenta')) == 'hello'
        assert clean_escapecodes(stringc('hello', 'cyan')) == 'hello'
        assert clean_

# Generated at 2022-06-11 17:54:07.624733
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)

    assert hostcolor("foobar", stats) == "foobar                 "
    assert hostcolor("foobar", stats, False) == "foobar                 "

    stats['failures'] = 1
    stats['unreachable'] = 1
    assert hostcolor("foobar", stats) == stringc("foobar", C.COLOR_ERROR)
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 1
    assert hostcolor("foobar", stats) == stringc("foobar", C.COLOR_CHANGED)

    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0

# Generated at 2022-06-11 17:54:12.907664
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('001') == u'38;5;1'
    assert parsecolor('rgb123') == u'38;5;21'
    assert parsecolor('gray4') == u'38;5;246'

# --- end of "pretty"


# Generated at 2022-06-11 17:54:33.324547
# Unit test for function colorize
def test_colorize():
    # Test default colors.
    s = colorize("foo", 42, None)
    assert s == "foo=42  ", "Default color test failed: %s" % s

    # Test red.
    s = colorize("foo", 42, 'RED')
    assert s == "\x1b[31mfoo=42  \x1b[0m", "RED color test failed: %s" % s

    # Test green.
    s = colorize("foo", 42, 'GREEN')
    assert s == "\x1b[32mfoo=42  \x1b[0m", "GREEN color test failed: %s" % s

    # Test yellow.
    s = colorize("foo", 42, 'YELLOW')

# Generated at 2022-06-11 17:54:40.317427
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                         '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost                       \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost                       \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost                       \x1b[0m'

# --- end "pretty"

# Generated at 2022-06-11 17:54:51.481359
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo.example.net", dict(
        changed=0,
        unreachable=0,
        failures=0,
    )) == "\x1b[0mfoo.example.net\x1b[0m  "
    assert hostcolor("foo.example.net", dict(
        changed=0,
        unreachable=1,
        failures=0,
    )) == "\x1b[91mfoo.example.net\x1b[0m  "
    assert hostcolor("foo.example.net", dict(
        changed=1,
        unreachable=0,
        failures=0,
    )) == "\x1b[33mfoo.example.net\x1b[0m  "

# Generated at 2022-06-11 17:55:01.679443
# Unit test for function stringc
def test_stringc():
    """Colorized string test"""
    import sys
    # Test foreground colors
    test_string = u'Foreground color test: '
    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta',
                  'cyan', 'white', 'color8', 'color9', 'color10', 'color11',
                  'color12', 'color13', 'color14', 'color15', 'color16'):
        test_string += stringc(color, color) + u' '
    test_string += '\n'

    # Test "gray" foreground colors
    test_string += u'Gray color test: '