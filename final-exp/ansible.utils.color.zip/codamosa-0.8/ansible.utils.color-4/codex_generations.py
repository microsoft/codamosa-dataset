

# Generated at 2022-06-11 17:45:10.171048
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color12") == u"\033[38;5;12mtest\033[0m"
    assert stringc("test", "rgb156") == u"\033[38;5;172mtest\033[0m"
    assert stringc("test", "gray9") == u"\033[38;5;244mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb256") == u"\033[38;5;231mtest\033[0m"

# Generated at 2022-06-11 17:45:21.172149
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"127.0.0.1", {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == u"127.0.0.1                 "
    assert hostcolor(u"127.0.0.1", {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == u"127.0.0.1                 "
    assert hostcolor(u"127.0.0.1", {'changed': 0, 'failures': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == u"127.0.0.1                 "

# Generated at 2022-06-11 17:45:23.308766
# Unit test for function parsecolor
def test_parsecolor():
    assert 14 == parsecolor('e')
    assert parsecolor('foo') is None


# Generated at 2022-06-11 17:45:26.262044
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 42
    color = 'blue'
    assert colorize(lead, num, color) == 'foo=42'



# Generated at 2022-06-11 17:45:38.489089
# Unit test for function parsecolor

# Generated at 2022-06-11 17:45:45.872695
# Unit test for function colorize
def test_colorize():
    # Catch both the string and color escape sequences
    p = re.compile(r'(\x1b\[[0-?]*[ -/]*[@-~])|(.)')
    # \x1b = ESC (27/0x1b)

    # These tests should print PASS or FAIL
    for color in ('red','green','YELLOW','BLUE','mAgenta','cyan','WHITE'):
        s = colorize('TEST', 'PASS', color)
        m = p.findall(s)
        # Just make sure there is a color sequence in the string
        assert(m[0][0] != '' or m[1][0] != '')
        sys.stdout.write(s + ' ')
        s = colorize('TEST', 'FAIL', color)

# Generated at 2022-06-11 17:45:53.278230
# Unit test for function hostcolor
def test_hostcolor():
    host = ''
    stats = dict()
    assert hostcolor(host, stats) == "%-26s" % host

    host = 'some host'
    assert hostcolor(host, stats) == "%-26s" % host

    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    assert hostcolor(host, stats) == "%-26s" % host

    stats['failures'] = 1
    assert hostcolor(host, stats, False) == "%-26s" % host
    assert hostcolor(host, stats, True).startswith(u"\n")


# from http://stackoverflow.com/a/21912744/145400
if sys.version_info < (3, 0):
    import codecs

    def u(x):
        return codec

# Generated at 2022-06-11 17:46:02.626298
# Unit test for function hostcolor
def test_hostcolor():
    # Using in-memory objects
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), color=False) == "localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), color=True) == "localhost               "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), color=False) == "localhost               "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), color=True) == "localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), color=False) == "localhost               "

# Generated at 2022-06-11 17:46:12.258776
# Unit test for function stringc
def test_stringc():
    """Test ANSI color strings."""
    assert stringc('Test', 'green') == '\x1b[32mTest\x1b[0m'
    assert stringc('Test', 'green', wrap_nonvisible_chars=True) == '\x01\x1b[32m\x02Test\x01\x1b[0m\x02'
    assert stringc('Test', 'unknown') == '\x1b[32mTest\x1b[0m'
    assert stringc('Test', 'color3') == '\x1b[38;5;3mTest\x1b[0m'
    assert stringc('Test', 'rgb123') == '\x1b[38;5;66mTest\x1b[0m'
    assert stringc('Test', 'gray3')

# Generated at 2022-06-11 17:46:23.033122
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('black') == u'30'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('rgb255255000') == u'38;5;11'
    assert parsecolor('rgb25500') == u'38;5;2'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray7') == u'38;5;239'
    assert parsecolor('gray8') == u'38;5;240'

# Generated at 2022-06-11 17:46:34.963184
# Unit test for function stringc
def test_stringc():
    assert stringc(u"spam", "blue") == u"\033[34m\033[1mspam\033[0m\033[0m"
    assert stringc(u"foo\nbar", "bright purple") == u"\033[95m\033[1mfoo\nbar\033[0m\033[0m"
    assert stringc(u"eggs", "white on_red") == u"\033[47m\033[1m\033[37meggs\033[0m\033[0m\033[0m"



# Generated at 2022-06-11 17:46:45.798892
# Unit test for function hostcolor
def test_hostcolor():
    """
    hostcolor: nothing => white
    hostcolor: failures => red
    hostcolor: unreachable => red
    hostcolor: ok => green
    hostcolor: changed => yellow
    """
    host = 'localhost'
    stats = dict(failures=0, unreachable=0, ok=0, changed=0)
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_OK)

    stats = dict(failures=1, unreachable=0, ok=0, changed=0)
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_ERROR)

    stats = dict(failures=0, unreachable=1, ok=0, changed=0)
    assert hostcolor(host, stats, True)

# Generated at 2022-06-11 17:46:53.414251
# Unit test for function hostcolor
def test_hostcolor():
    assert 'error' in hostcolor('foo', {'changed': 0, 'failures': 1, 'ok': 15, 'skipped': 0, 'unreachable': 0})
    assert 'changed' in hostcolor('foo', {'changed': 1, 'failures': 0, 'ok': 15, 'skipped': 0, 'unreachable': 0})
    assert 'ok' in hostcolor('foo', {'changed': 0, 'failures': 0, 'ok': 15, 'skipped': 0, 'unreachable': 0})



# Generated at 2022-06-11 17:47:03.590114
# Unit test for function stringc
def test_stringc():
    assert stringc('[0;32mfoo', 'green')

# --- end of pretty
#

# This function is taken from the python2 source tree at
# http://hg.python.org/cpython/file/2.7/Lib/getpass.py
# which is licensed under the PSF-2.0
#
# Copyright 2001-2013 Python Software Foundation; All Rights Reserved
# Copyright 2001 Guido van Rossum
#
# PYTHON SOFTWARE FOUNDATION LICENSE VERSION 2
# --------------------------------------------
#
# 1. This LICENSE AGREEMENT is between the Python Software Foundation
# ("PSF"), and the Individual or Organization ("Licensee") accessing and
# otherwise using this software ("Python") in source or binary form and
# its associated documentation.
#
# 2. Subject to the terms and conditions of this License Agreement, PSF
#

# Generated at 2022-06-11 17:47:06.353611
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo bar", u'blue') == u"\033[34mfoo bar\033[0m"



# Generated at 2022-06-11 17:47:17.055607
# Unit test for function hostcolor
def test_hostcolor():
    """Test that hostcolor function returns expected output."""
    from ansible import constants as C
    from ansible.color import hostcolor
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    class TestHostcolor(unittest.TestCase):
        host = "testhost.example.com"
        color_ok = C.COLOR_OK
        color_changed = C.COLOR_CHANGED
        color_error = C.COLOR_ERROR
        color_unreachable = C.COLOR_UNREACHABLE
        # For the happy path, test with a failure and/or a change,
        # no failures or changes, and not with color.
        host_hostcolor = hostcolor(host, {})

# Generated at 2022-06-11 17:47:20.042372
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    assert u"\033[31mfoo\033[0m" == stringc(u"foo", u"RED")


# Generated at 2022-06-11 17:47:31.323945
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return

    s = dict(skipped=10, changed=20, unreachable=30, failures=40)
    print('test_hostcolor', end=' ')
    print(hostcolor('test_hostcolor', s, color=True), end=' ')
    print(hostcolor('test_hostcolor', s, color=False))


# --- end "pretty"


# --- begin "progress"
#
# progress - Library for displaying progress bars and spinners in terminals.
# Copyright (C) 2016 Lars Gustäbel <lars@gustaebel.de>
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (

# Generated at 2022-06-11 17:47:44.264703
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(ok=10, failures=0, unreachable=0, changed=0)
    assert hostcolor(u'foo.bar.baz', stats, False) == u'%-26s' % u'foo.bar.baz'
    assert hostcolor(u'foo.bar.baz', stats, True) == u"%-37s" % stringc(u'foo.bar.baz', C.COLOR_OK)

    stats = dict(ok=0, failures=1, unreachable=1, changed=0)
    if ANSIBLE_COLOR:
        assert hostcolor(u'foo.bar.baz', stats, True) == u"%-37s" % stringc(u'foo.bar.baz', C.COLOR_ERROR)

# Generated at 2022-06-11 17:47:51.064085
# Unit test for function colorize
def test_colorize():
    def test_colors(lead, num, color, expected):
        s = colorize(lead, num, color)
        assert s == expected, "colorize(%r, %r, %r) == %r (expected %r)" % (lead, num, color, s, expected)

    for col in ['blue', 'cyan', 'green', 'magenta', 'red', 'yellow', 'black']:
        for n in range(-100, 100):
            test_colors('-', n, col, '-=%4d' % n)

    # 0 should never be colored
    for col in ['blue', 'cyan', 'green', 'magenta', 'red', 'yellow', 'black', None]:
        test_colors('-', 0, col, '-=   0')



# Generated at 2022-06-11 17:48:03.969320
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = {'ok': 1234, 'changed': 45, 'unreachable': 0, 'failures': 0}
    assert hostcolor('test1', stats1, color=True) == u"test1                         "

    stats2 = {'ok': 1234, 'changed': 0, 'unreachable': 0, 'failures': 45}
    assert hostcolor('test2', stats2, color=True) == u"test2                         "

    stats3 = {'ok': 1234, 'changed': 0, 'unreachable': 45, 'failures': 0}
    assert hostcolor('test3', stats3, color=True) == u"test3                         "

# --- end pretty

# Generated at 2022-06-11 17:48:07.361311
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host.example.com', {'failures': 0, 'unreachable': 0, 'changed': 0}) == \
        u"host.example.com               "

# --- end of pretty


# Generated at 2022-06-11 17:48:10.765711
# Unit test for function colorize
def test_colorize():
    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        print(colorize("--", 0, color), colorize("--", 1, color), colorize("--", 2, color))



# Generated at 2022-06-11 17:48:20.338377
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'127.0.0.1', dict(failures=1, unreachable=0, ok=0, changed=0)) == u'127.0.0.1                  '
    assert hostcolor(u'127.0.0.1', dict(failures=0, unreachable=1, ok=0, changed=0)) == u'127.0.0.1                  '
    assert hostcolor(u'127.0.0.1', dict(failures=0, unreachable=0, ok=1, changed=1)) == u'127.0.0.1                  '
    assert hostcolor(u'127.0.0.1', dict(failures=0, unreachable=0, ok=0, changed=1)) == u'127.0.0.1                  '

# Generated at 2022-06-11 17:48:32.316357
# Unit test for function hostcolor
def test_hostcolor():
    good = dict(failures=0, unreachable=0, changed=0)
    bad = dict(failures=1, unreachable=0, changed=0)
    changed = dict(failures=0, unreachable=0, changed=1)
    bad_changed = dict(failures=1, unreachable=0, changed=1)

    assert hostcolor('green', good) == u"%-26s" % stringc('green', C.COLOR_OK)
    assert hostcolor('red', bad) == u"%-26s" % stringc('red', C.COLOR_ERROR)
    assert hostcolor('yellow', changed) == u"%-26s" % stringc('yellow', C.COLOR_CHANGED)

# Generated at 2022-06-11 17:48:43.745305
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return


# Generated at 2022-06-11 17:48:54.929650
# Unit test for function hostcolor
def test_hostcolor():
    s = dict(ok=12, failures=0, unreachable=0, changed=0)
    assert hostcolor("test", s) == u"test                            "

    s = dict(ok=12, failures=1, unreachable=0, changed=0)
    assert hostcolor("test", s) == u"\x1b[31;01mtest\x1b[0m                  "

    s = dict(ok=12, failures=0, unreachable=1, changed=0)
    assert hostcolor("test", s) == u"\x1b[31;01mtest\x1b[0m                  "

    s = dict(ok=12, failures=0, unreachable=0, changed=1)

# Generated at 2022-06-11 17:49:06.413855
# Unit test for function stringc
def test_stringc():

    s = u"This is a test of color coding"
    assert stringc(s, C.COLOR_HIGHLIGHT) == u"\033[41mThis is a test of color coding\033[0m"
    assert stringc(s, C.COLOR_VERBOSE) == u"\033[46mThis is a test of color coding\033[0m"
    assert stringc(s, C.COLOR_WARN) == u"\033[43mThis is a test of color coding\033[0m"
    assert stringc(s, C.COLOR_ERROR) == u"\033[41mThis is a test of color coding\033[0m"
    assert stringc(s, C.COLOR_DEBUG) == u"\033[44mThis is a test of color coding\033[0m"

# Generated at 2022-06-11 17:49:13.761683
# Unit test for function hostcolor
def test_hostcolor():
    test_data = ((u"localhost", {u"ok": 1}, C.COLOR_OK),
                 (u"localhost", {u"changed": 1}, C.COLOR_CHANGED),
                 (u"localhost", {u"failures": 1}, C.COLOR_ERROR),
                 (u"localhost", {u"unreachable": 1}, C.COLOR_ERROR),
                 (u"localhost", {}, C.COLOR_OK))

    for host, stats, color in test_data:
        result = hostcolor(host, stats, True)
        assert result == stringc(host, color), \
            "hostcolor() returned %s, expected %s" % (result, stringc(host, color))



# Generated at 2022-06-11 17:49:17.854946
# Unit test for function stringc
def test_stringc():
    text = 'hello'
    assert stringc(text, 'red') == '\033[31mhello\033[0m'
    assert stringc(text, 'blue', True) == '\001\033[34m\002hello\001\033[0m\002'



# Generated at 2022-06-11 17:49:29.186581
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat import StringIO
    stdout_bak = sys.stdout
    # disable color for the test
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False

    stats = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    hostname = 'localhost'
    stdout = StringIO()
    sys.stdout = stdout
    hostcolor(hostname, stats)
    assert stdout.getvalue() == '%-26s' % hostname
    stdout.close()

    stats = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    hostname = 'localhost'
    ANSIBLE_COLOR = True
    stdout = StringIO

# Generated at 2022-06-11 17:49:37.734416
# Unit test for function stringc
def test_stringc():
    print(stringc('stringc', 'blue'))
    print(stringc('stringc', 'bold'))
    print(stringc('stringc', 'brightpurple'))
    print(stringc('stringc', 'green'))
    print(stringc('stringc', 'magenta'))
    print(stringc('stringc', 'red'))
    print(stringc('stringc', 'white', wrap_nonvisible_chars=True))
    print(stringc('stringc', 'yellow'))
    print(stringc('stringc', 'rgb250200100'))
    print(stringc('stringc', 'rgb255255255'))
    print(stringc('stringc', 'gray8'))
    print(stringc('stringc', 'gray15'))

# Generated at 2022-06-11 17:49:47.321363
# Unit test for function colorize
def test_colorize():
    print(colorize(u"ok", 27, 'green'), colorize(u"changed", 3, 'yellow'), colorize(u"unreachable", 1, 'red'), colorize(u"failed", 1, 'red'), colorize(u"skipped", 6, 'cyan'))
    print(colorize(u"ok", 0, 'green'), colorize(u"changed", 0, 'yellow'), colorize(u"unreachable", 0, 'red'), colorize(u"failed", 0, 'red'), colorize(u"skipped", 0, 'cyan'))
    print(colorize(u"ok", 0, None), colorize(u"changed", 0, None), colorize(u"unreachable", 0, None), colorize(u"failed", 0, None), colorize(u"skipped", 0, None))

# Generated at 2022-06-11 17:49:54.727149
# Unit test for function hostcolor
def test_hostcolor():
    try:
        if hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) != u"%-37s":
            print('hostcolor function test FAILED, wrong format')
    except RuntimeError:
        # this is only for python3 runtime, python2 cannot run this test without ansible running
        pass
    except ImportError:
        # this is only for python3 runtime, python2 cannot run this test without ansible running
        pass
# --- end "pretty"

# Generated at 2022-06-11 17:50:02.863851
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), True) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)



# Generated at 2022-06-11 17:50:14.672754
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'changed': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor('testhost', stats, False) == '%-26s' % 'testhost'
    assert hostcolor('testhost', stats, True) == '%-37s' % 'testhost'

    stats = {'changed': 1, 'failures': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor('testhost', stats, False) == '%-26s' % 'testhost'
    assert hostcolor('testhost', stats, True) == '%-37s' % stringc('testhost', C.COLOR_CHANGED)

    stats = {'changed': 0, 'failures': 1, 'skipped': 0, 'unreachable': 0}

# Generated at 2022-06-11 17:50:23.636622
# Unit test for function stringc
def test_stringc():
    def assertColor(text, color):
        assert stringc(text, color, False) == '\033[%sm%s\033[0m' % (parsecolor(color), text)
        assert stringc(text, color, True) == '\001\033[%sm\002%s\001\033[0m\002' % (parsecolor(color), text)

    assertColor('foo', 'green')
    assertColor('foo\nbar', 'blue')
    assertColor('foo\nbar\nbaz', 'red')

    assertColor('foo', 'rgb255')

    assertColor('foo', 'rgb123')

    assertColor('foo', 'gray1')
    assertColor('foo', 'gray9')

# end "pretty"

# Generated at 2022-06-11 17:50:26.906270
# Unit test for function colorize
def test_colorize():
    # no color
    assert colorize("foo", 4, None) == "foo=4   "
    if ANSIBLE_COLOR:
        assert colorize("foo", 4, 'blue') == stringc("foo=4   ", 'blue')



# Generated at 2022-06-11 17:50:34.763390
# Unit test for function colorize
def test_colorize():
    """ quick and dirty test function for colorize function """
    fail = 0

    fail += 1
    if colorize(" ", 10, None) != " =10   ":
        print("Expected: =10. Got:", colorize(" ", 10, None))

    fail += 1
    if colorize(" ", 0, "red") != " =0    ":
        print("Expected: =0. Got:", colorize(" ", 0, "red"))

    fail += 1
    if colorize(" ", 123, "blue") != " =123  ":
        print("Expected: =123. Got:", colorize(" ", 123, "blue"))

    return fail > 0

# --- end "pretty"

#
# ANSIBLE_COLOR defined in constants.py, but it's a global env
# variable, so check and set it here

# Generated at 2022-06-11 17:50:42.536433
# Unit test for function hostcolor
def test_hostcolor():
    host = u'host1'
    stats = {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 0, 'skipped': 0}
    if hostcolor(host, stats) != '%-26s' % host:
        raise AssertionError("function hostcolor() didn't return %s" % ("%-26s" % host))
    stats['changed'] = 1
    if hostcolor(host, stats) != '%-37s' % 'host1':
        raise AssertionError('function hostcolor() didn\'t return %s' % 'host1')
    stats = {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 1, 'skipped': 0}
    if hostcolor(host, stats) != '%-37s' % 'host1':
        raise

# Generated at 2022-06-11 17:50:54.927091
# Unit test for function hostcolor
def test_hostcolor():
    print(stringc("foo:", C.COLOR_CHANGED) + " " + stringc("bar", C.COLOR_ERROR))
    print(stringc("foo:", C.COLOR_ERROR) + " " + stringc("bar", C.COLOR_CHANGED))
    print(stringc("foo:", C.COLOR_OK) + " " + stringc("bar", C.COLOR_OK))
    print(stringc("foo:", C.COLOR_CHANGED) + " " + stringc("bar", C.COLOR_OK))
    print(hostcolor(stringc("foo", C.COLOR_OK), {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}))

# Generated at 2022-06-11 17:51:05.403320
# Unit test for function stringc
def test_stringc():
    def assert_stringc(text, color, expected_result, wrrap_nonvisible_chars=False):
        global ANSIBLE_COLOR
        ANSIBLE_COLOR = True
        assert stringc(text, color, wrrap_nonvisible_chars) == expected_result
        ANSIBLE_COLOR = False
        assert stringc(text, color, wrrap_nonvisible_chars) == text

    assert_stringc("Hello World!", 'blue', u'\033[34mHello World!\033[0m')
    assert_stringc("Hello World!", 'black', u'\033[30mHello World!\033[0m')
    assert_stringc("Hello World!", 'red', u'\033[31mHello World!\033[0m')

# Generated at 2022-06-11 17:51:16.221955
# Unit test for function hostcolor
def test_hostcolor():
    good_stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor("myhost", good_stats) == u"%-26s" % "myhost"
    assert hostcolor("myhost", good_stats, color=False) == u"%-26s" % "myhost"
    bad_stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor("myhost", bad_stats) == u"%-37s" % stringc("myhost", C.COLOR_ERROR)
    change_stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor("myhost", change_stats) == u"%-37s" % stringc("myhost", C.COLOR_CHANGED)



# Generated at 2022-06-11 17:51:21.871546
# Unit test for function stringc
def test_stringc():
    print("Testing function stringc")
    print("%-8s %-8s %-8s %-8s" % ('Color', 'Code', 'Expect', 'Reality'))
    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        code = parsecolor(color)
        expect = u"\033[%smcolor\033[0m" % code
        reality = stringc(u'color', color)
        print("%-8s %-8s %-8s %-8s" % (color, code, expect, reality))
    print("color in gray")
    print("%-8s %-8s %-8s %-8s" % ('Color', 'Code', 'Expect', 'Reality'))

# Generated at 2022-06-11 17:51:33.059491
# Unit test for function hostcolor
def test_hostcolor():      # type: () -> None
    host_color = hostcolor("foo", {'failures': 0, 'unreachable': 0, 'changed': 0})
    assert u"\033[32m%-37s\033[0m" == host_color
    host_color = hostcolor("foo", {'failures': 0, 'unreachable': 0, 'changed': 1})
    assert u"\033[33m%-37s\033[0m" == host_color
    host_color = hostcolor("foo", {'failures': 1, 'unreachable': 0, 'changed': 0})
    assert u"\033[31m%-37s\033[0m" == host_color
    host_color = hostcolor("foo", {'failures': 0, 'unreachable': 1, 'changed': 0})
    assert u

# Generated at 2022-06-11 17:51:43.892562
# Unit test for function colorize
def test_colorize():
    from ansible import constants as C
    print(colorize('ok', 0, None))
    print(colorize('changed', 0, None))
    print(colorize('unreachable', 0, None))
    print(colorize('failed', 0, None))
    print(colorize('ok', 1, None))
    print(colorize('changed', 1, None))
    print(colorize('unreachable', 1, None))
    print(colorize('failed', 1, None))

    print(colorize('ok', 0, C.COLOR_OK))
    print(colorize('changed', 0, C.COLOR_CHANGED))
    print(colorize('unreachable', 0, C.COLOR_UNREACHABLE))
    print(colorize('failed', 0, C.COLOR_ERROR))

# Generated at 2022-06-11 17:51:51.579128
# Unit test for function stringc
def test_stringc():
    from ansible.color import stringc
    from ansible.constants import color_ansi
    from ansible.constants import color_ansi_reset

    import os

    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        for text in ('this is ', 'a test'):
            start = color_ansi['32']
            if color == 'black':
                start = color_ansi['30']
            elif color == 'red':
                start = color_ansi['31']
            elif color == 'green':
                start = color_ansi['32']
            elif color == 'yellow':
                start = color_ansi['33']
            elif color == 'blue':
                start = color_ansi['34']
           

# Generated at 2022-06-11 17:51:59.145490
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    # Using the color setting to be False for this test.
    def _fake_color(x, y):
        return False
    hostcolor._original_ansible_color = hostcolor.ansible_color
    hostcolor.ansible_color = _fake_color
    assert hostcolor('foobar.example.com', {}) == 'foobar.example.com      '
    hostcolor.ansible_color = hostcolor._original_ansible_color
    # End of unit test
    del hostcolor._original_ansible_color



# Generated at 2022-06-11 17:52:10.352878
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host.example.org', {'changed':0, 'failures':0, 'ok':0, 'skipped':0, 'unreachable':0}, color=False) == 'host.example.org             '
    assert hostcolor('host.example.org', {'changed':0, 'failures':0, 'ok':0, 'skipped':0, 'unreachable':0}) == '\033[0;32mhost.example.org             \033[0m'
    assert hostcolor('a very long host.example.org', {'changed':0, 'failures':0, 'ok':0, 'skipped':0, 'unreachable':0}) == '\033[0;32ma very long host.example.org\033[0m'

# Generated at 2022-06-11 17:52:18.255595
# Unit test for function colorize
def test_colorize():
    """
    sanity checks for colorize
    """
    lead = u"foo"
    num = 42
    assert colorize(lead, num, None) == u'foo=42  '
    assert colorize(lead, num, 'black') == u'foo=42  '
    assert colorize(lead, num, 'red') != u'foo=42  '
    assert colorize(lead, 0, 'red') == u'foo=0   '
    assert colorize(lead, 0, None) == u'foo=0   '


# --- end "pretty"

# ==============================================================
# main
#
# code below is for testing this library
# ==============================================================

if __name__ == '__main__':
    """
    stand alone test harness
    """

    c_list = C.COLOR_COD

# Generated at 2022-06-11 17:52:29.961699
# Unit test for function hostcolor
def test_hostcolor():
    host = u'localhost'
    stats = dict(
        ok=0,
        changed=0,
        unreachable=0,
        failures=0,
    )
    assert hostcolor(host, stats, False) == u'%-26s' % host, u"Test without color failed"
    assert hostcolor(host, stats, True) == u'%-37s' % stringc(host, C.COLOR_OK, True), u"Test with color (OK) failed"

    stats = dict(
        ok=0,
        changed=1,
        unreachable=0,
        failures=0,
    )
    assert hostcolor(host, stats, False) == u'%-26s' % host, u"Test without color failed"

# Generated at 2022-06-11 17:52:34.031985
# Unit test for function stringc
def test_stringc():
    assert stringc('hello', 'blue') == '\x1b[94mhello\x1b[0m'

# --- end of "pretty" ---



# Generated at 2022-06-11 17:52:41.751714
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foobar', {}, False) == '%-26s' % 'foobar'
    assert hostcolor('foobar', {'failures': 1}, False) == '%-26s' % 'foobar'
    assert hostcolor('foobar', {'failures': 1}, True) == '%-37s' % stringc('foobar', C.COLOR_ERROR)
    assert hostcolor('foobar', {'changed': 1}, True) == '%-37s' % stringc('foobar', C.COLOR_CHANGED)
    assert hostcolor('foobar', {'failures': 0, 'changed': 0}, True) == '%-37s' % stringc('foobar', C.COLOR_OK)



# Generated at 2022-06-11 17:52:52.366083
# Unit test for function hostcolor
def test_hostcolor():
    # create a dict host_name -> stats
    stats = {}
    stats['localhost'] = {'failures': 0, 'unreachable': 0, 'changed': 0}
    #tests OK
    assert hostcolor('localhost', stats['localhost'], True) == u"\x1b[0;32m%-26s\x1b[0m" % u'localhost'
    #tests KO
    stats['localhost']['failures'] = stats['localhost']['unreachable'] = 1
    assert hostcolor('localhost', stats['localhost'], True) == u"\x1b[0;31m%-26s\x1b[0m" % u'localhost'
    #tests changed
    stats['localhost']['unreachable'] = 0

# Generated at 2022-06-11 17:52:59.427828
# Unit test for function colorize
def test_colorize():
    try:
        import curses
    except ImportError:
        return True
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0'
    assert colorize('skipping', 0, 'cyan') == 'skipping=0  '
    assert colorize('ok', 1, 'green') == '\x1b[32mok=1   \x1b[0m'
    assert colorize('changed', 2, 'yellow') == '\x1b[33mchanged=2  \x1b[0m'

# Generated at 2022-06-11 17:53:06.964430
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "color45") == u"\033[38;5;45mfoo\033[0m"
    assert stringc("foo", "rgb254") == u"\033[38;5;187mfoo\033[0m"
    assert stringc("foo", "rgb203") == u"\033[38;5;143mfoo\033[0m"
    assert stringc("foo", "gray3") == u"\033[38;5;235mfoo\033[0m"


# --- end "pretty"



# Generated at 2022-06-11 17:53:17.433024
# Unit test for function colorize
def test_colorize():
    from ansible.compat.tests import unittest

    class TestColorize(unittest.TestCase):
        def test_colorize(self):
            s = colorize(u"foo", u"1", None)
            self.assertEqual(u"foo=1   ", s)

    unittest.main()

# --- end of "pretty"

# --- begin "terminal"
#
# terminal - An object that can be used to put the terminal
# into one-character-ata-time mode to display progress bars.
#
# Originally created by Michael DeHaan <michael.dehaan@gmail.com>
#
# This code is public domain - there is no license except
# that you must leave this header.



# Generated at 2022-06-11 17:53:23.709353
# Unit test for function stringc
def test_stringc():
    # Add this before importing ansible so that the unit tests work
    sys.modules['__main__'].__file__ = 'ansible-playbook'

    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils import six

    # Early check if we run in a terminal
    if not sys.__stdout__.isatty():
        sys.exit(2)

    # If we run in a terminal, check if there is enough color support
    try:
        import curses
        curses.setupterm()
        if curses.tigetnum('colors') < 0:
            sys.exit(2)
    except ImportError:
        # curses library was not found
        sys.exit(2)

# Generated at 2022-06-11 17:53:31.563170
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"localhost", dict(failures=0, unreachable=0, changed=0), True) == u"\033[0;32mlocalhost               \033[0m"
    assert hostcolor(u"localhost", dict(failures=0, unreachable=0, changed=0), False) == u"localhost                "
    assert hostcolor(u"localhost", dict(failures=0, unreachable=0, changed=1), True) == u"\033[0;33mlocalhost               \033[0m"
    assert hostcolor(u"localhost", dict(failures=0, unreachable=1, changed=1), True) == u"\033[0;31mlocalhost               \033[0m"


# Generated at 2022-06-11 17:53:42.934573
# Unit test for function hostcolor
def test_hostcolor():
    h = "127.0.0.1"
    s = {"changed": 0, "failures": 0, "ok": 10, "skipped": 0, "unreachable": 0}
    colorize_string = hostcolor(h, s, color=True)
    if not isinstance(colorize_string, unicode):
        raise AssertionError
    colorize_string = hostcolor(h, s, color=False)
    if not isinstance(colorize_string, unicode):
        raise AssertionError
    s = {"changed": 0, "failures": 1, "ok": 10, "skipped": 0, "unreachable": 0}
    colorize_string = hostcolor(h, s, color=True)
    if not isinstance(colorize_string, unicode):
        raise AssertionError


# Generated at 2022-06-11 17:53:57.202932
# Unit test for function stringc
def test_stringc():
    p = sys.stdout.isatty()
    sys.stdout.isatty = lambda: True
    assert stringc("foo", "red") == "\x1b[31mfoo\x1b[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\x1b[31m\002foo\001\x1b[0m\002"
    sys.stdout.isatty = lambda: False
    assert stringc("foo", "red") == "foo"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "foo"
    sys.stdout.isatty = p

# --- end "pretty"

# ------------------------
#
# Main API
#


# Generated at 2022-06-11 17:54:05.201685
# Unit test for function stringc
def test_stringc():
    import sys
    import types
    for color in [u'blue', u'bold']:
        if not ANSIBLE_COLOR:
            assert type(stringc(u'foo', color)) == types.UnicodeType
        else:
            assert type(stringc(u'foo', color)) == types.StringType
        assert stringc(u'foo', color, wrap_nonvisible_chars=True).startswith(u'\001\033[')
        assert stringc(u'foo', color, wrap_nonvisible_chars=True).endswith(u'\002')



# Generated at 2022-06-11 17:54:06.555402
# Unit test for function stringc
def test_stringc():
    print(stringc('Hello World', 'red'))
    print(stringc('Hello World', 'blue'))

# Generated at 2022-06-11 17:54:18.475909
# Unit test for function hostcolor
def test_hostcolor():
    """ test function hostcolor """
    host = u"foo"
    color = True
    stats = {u'ok': 1}
    s = hostcolor(host, stats, color)
    assert s == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {u'ok': 1, u'changed': 1}
    s = hostcolor(host, stats, color)
    assert s == u"%-37s" % stringc(host, C.COLOR_CHANGED)
    stats = {u'failures': 1, u'changed': 1}
    s = hostcolor(host, stats, color)
    assert s == u"%-37s" % stringc(host, C.COLOR_ERROR)

# Generated at 2022-06-11 17:54:27.406020
# Unit test for function colorize
def test_colorize():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    if colorize("test", 1, "red") != u'\x1b[31mtest=1   \x1b[0m':
        raise AssertionError("color test 1 failed")
    if colorize("test", 0, "red") != u'test=0   ':
        raise AssertionError("color test 2 failed")
    ANSIBLE_COLOR = False
    if colorize("test", 1, "red") != u'test=1   ':
        raise AssertionError("color test 3 failed")
    if colorize("test", 0, "red") != u'test=0   ':
        raise AssertionError("color test 4 failed")

# --- end "pretty"

# Indicate whether we support ANSI coloring. This

# Generated at 2022-06-11 17:54:37.380260
# Unit test for function stringc
def test_stringc():
    # Test a color
    assert stringc('test', 'red') == u"\033[31mtest\033[0m"
    # Test a color and modifiers
    assert stringc('test', 'red,bold') == u"\033[1;31mtest\033[0m"
    # Test a color with space
    assert stringc('test', 'red, bold') == u"\033[1;31mtest\033[0m"
    # Test multiple colors
    assert stringc('test', 'red,blue,bold') == u"\033[1;34;31mtest\033[0m"
    # Test for resetting colors
    assert stringc('test', 'red', True) == u"\001\033[31m\002test\001\033[0m\002"


# ---


# Generated at 2022-06-11 17:54:48.103515
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                   "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;34mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=1)) == u"\x1b[0;31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=1)) == u"\x1b[0;31mlocalhost\x1b[0m          "

# Generated at 2022-06-11 17:54:56.282747
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('foo', {'failures': 1}, True))
    print(hostcolor('foo', {'failures': 0, 'changed': 1}, True))
    print(hostcolor('foo', {'failures': 0, 'changed': 0}, True))
    print(hostcolor('foo', {'failures': 1}, False))
    print(hostcolor('foo', {'failures': 0, 'changed': 1}, False))
    print(hostcolor('foo', {'failures': 0, 'changed': 0}, False))

# --- end "pretty"
