

# Generated at 2022-06-11 17:45:03.686943
# Unit test for function stringc
def test_stringc():
    for color in C.COLOR_CODES:
        text = color
        text = stringc(text, color)
        text = stringc(text, color, wrap_nonvisible_chars=True)
    assert text == u'ZOPHAR'

# --- end "pretty"



# Generated at 2022-06-11 17:45:14.463161
# Unit test for function colorize
def test_colorize():
    c_r = "\033[1;31m"
    c_w = "\033[1;37m"
    c_nocolor = "\033[0m"
    assert colorize('a', 0, 'red') == "a=0   "
    assert colorize('a', 1, 'red') == "%sa=1   %s" % (c_r, c_nocolor)
    assert colorize('a', 1234, 'white') == "%sa=1234%s" % (c_w, c_nocolor)
    if sys.version_info < (2, 6):
        sys.stdout.write("Skipping colorize tests for python < 2.6\n")

# Generated at 2022-06-11 17:45:23.290270
# Unit test for function parsecolor
def test_parsecolor():
    # This is what it should look like
    assert parsecolor('yellow') == u'33'
    assert parsecolor('bright yellow') == u'93'
    assert parsecolor('color252') == u'38;5;252'
    assert parsecolor('rgb123') == u'38;5;117'
    assert parsecolor('rgb321') == u'38;5;51'
    assert parsecolor('rgb210') == u'38;5;59'
    assert parsecolor('rgb201') == u'38;5;52'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray7') == u'38;5;239'
    # And this is what is should not look like
    assert not parsecolor('red') == u

# Generated at 2022-06-11 17:45:35.586958
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('fake_host', stats, True) == \
        u"%-37s" % stringc('fake_host', C.COLOR_OK)
    stats['failures'] += 1
    stats['unreachable'] += 1
    assert hostcolor('fake_host', stats, True) == \
        u"%-37s" % stringc('fake_host', C.COLOR_ERROR)
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] += 1
    assert hostcolor('fake_host', stats, True) == \
        u"%-37s" % stringc('fake_host', C.COLOR_CHANGED)
    stats['changed'] = 0
    stats['failures'] += 1


# Generated at 2022-06-11 17:45:44.590621
# Unit test for function parsecolor
def test_parsecolor():
    """Test the ansible.utils.parsecolor function"""
    # Test named colors
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('yellow') == u'38;5;11'
    assert parsecolor('cyan') == u'38;5;14'
    # Test RGB
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb000255000') == u'38;5;2'
    assert parsecolor('rgb777777777') == u'38;5;231'
    assert parsecolor('rgb000000000') == u'38;5;16'
    # Test grays
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor

# Generated at 2022-06-11 17:45:48.123870
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {}) == "%-26s" % "localhost"
    assert hostcolor("localhost", {"failures" : 1}) == stringc("%-26s" % "localhost", C.COLOR_ERROR)
    assert hos

# Generated at 2022-06-11 17:45:54.792055
# Unit test for function stringc
def test_stringc():
    print(u"%s" % stringc("This is the test stringc function.", "green"))
    print(u"%s" % stringc("This is the test stringc function.", "blue"))
    print(u"%s" % stringc("This is the test stringc function.", "purple"))
    print(u"%s" % stringc("This is the test stringc function.", "red"))


# Generated at 2022-06-11 17:45:58.015811
# Unit test for function hostcolor
def test_hostcolor():
    import pytest
    assert hostcolor("test_host", {"failures":0, "unreachable":0, "changed":0}) == "test_host                 "



# Generated at 2022-06-11 17:46:09.360313
# Unit test for function hostcolor
def test_hostcolor():
    assert '\x1b[41mfoobar' == stringc('foobar', C.COLOR_ERROR)
    assert '\x1b[41mfoobar\x1b[0m' == hostcolor('foobar', {'failures': 1}, True)
    assert '\x1b[42mfoobar\x1b[0m' == hostcolor('foobar', {'changed': 1}, True)
    assert '\x1b[32mfoobar\x1b[0m' == hostcolor('foobar', {}, True)
    assert '\x1b[32mfoobar' == stringc('foobar', C.COLOR_OK)
    assert '\x1b[32mfoobar\x1b[0m' == hostcolor('foobar', {}, True)

# Generated at 2022-06-11 17:46:16.294702
# Unit test for function stringc
def test_stringc():
    assert stringc('This is ' + C.COLOR_CHANGED + 'red', C.COLOR_CHANGED) == \
        u"\033[31mThis is red\033[0m"
    assert stringc('This is ' + C.COLOR_ERROR + 'red', C.COLOR_ERROR) == \
        u"\033[31mThis is red\033[0m"


# Generated at 2022-06-11 17:46:28.717740
# Unit test for function colorize
def test_colorize():
    def _test_colorize(func):
        # We don't have any other way to check the color except looking
        # at the returned string.
        def _check(passed):
            assert 'XXXXX' in func('XXXXX', 500, colorize)
            assert 'XXX=500' in func('XXX', 500, colorize)
            assert 'XXX=500' in func('XXX', 500, colorize)
            assert 'XXX=-500'in func('XXX', -500, colorize)
        try:
            _check(is_passed=True)
        except AssertionError:
            _check(is_passed=False)
    _test_colorize(colorize)

# Generated at 2022-06-11 17:46:34.734727
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        no_color = u"\033[0m"
    else:
        no_color = u''
    # black
    assert stringc(u"black", "black") == u"\033[30mblack\033[0m"
    assert stringc(u"black", "color0") == u"\033[30mblack\033[0m"
    assert stringc(u"black", "gray0") == u"\033[30mblack\033[0m"
    assert stringc(u"black", "rgb0") == u"\033[30mblack\033[0m"
    # red
    assert stringc(u"red", "red") == u"\033[31mred\033[0m"

# Generated at 2022-06-11 17:46:45.557061
# Unit test for function hostcolor
def test_hostcolor():
    import random
    import textwrap
    test_host = 'foo' + str(int(random.random() * 10000))
    (test_stats, set) = ({'failures':0, 'unreachable':0, 'changed':0}, False)
    for i in range(0, 2):
        for s in ['failures', 'unreachable', 'changed']:
            test_stats[s] += 1
            assert(re.match(r'\x1b\[\d{2}m' + test_host + r'\x1b\[0m',
                            hostcolor(test_host, test_stats, True)))
    test_stats['changed'] -= 1

# Generated at 2022-06-11 17:46:55.561329
# Unit test for function hostcolor
def test_hostcolor():
    def hc(hostname, stats, color=True):
        return hostcolor(hostname, stats, color=color)

    def st(*args, **kwargs):
        return dict(zip(['ok', 'changed', 'unreachable', 'failures'], args), **kwargs)

    class Tests:
        def test_ok_color(self):
            assert hc('host', st(0, 0, 0, 0)) == 'host                 '
            assert hc('host', st(0, 0, 0, 0), color=False) == 'host                 '
        def test_changed_color(self):
            assert hc('host', st(0, 1, 0, 0)) == u'\x1b[0;34mhost\x1b[0m               '

# Generated at 2022-06-11 17:47:04.642482
# Unit test for function stringc
def test_stringc():
    tests = [
        ['test', 'blue', 'test'],
        ['test', 'rgb255', 'test'],
        ['test', 'rgb222', 'test'],
        ['test', 'rgb055', 'test'],
        ['test', 'rgb333', 'test'],
        ['test', 'rgb000', 'test'],
        ['test', 'rgb111', 'test'],
        ['test', 'rgb123', 'test'],
        ['test', 'rgb321', 'test'],
        ['test', 'rgb132', 'test'],
        ['test', 'rgb213', 'test'],
        ['test', 'rgb231', 'test'],
    ]

    for t in tests:
        assert stringc(t[0], t[1]) == t[2]

# Generated at 2022-06-11 17:47:15.806469
# Unit test for function hostcolor
def test_hostcolor():
    test_host = 'some.host.com'

# Generated at 2022-06-11 17:47:22.918825
# Unit test for function stringc
def test_stringc():
    black_on_blue = u"\033[0;30;44m%s\033[0m" % u'Black on blue'
    red_on_yellow = u"\033[0;31;43m%s\033[0m" % u'Red on yellow'
    green_on_white = u"\033[0;32;47m%s\033[0m" % u'Green on white'

# Generated at 2022-06-11 17:47:32.355526
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == u'foo=0   '
    assert re.match(r'^foo=[1-9]   \033\[38;5;.*m$', colorize('foo', 1, 'black'))
    assert re.match(r'^foo=[1-9]   \033\[38;5;.*m$', colorize('foo', 1, 'rgb000'))
    assert re.match(r'^foo=[1-9]   \033\[38;5;.*m$', colorize('foo', 1, 'rgb123'))
    assert re.match(r'^foo=[1-9]   \033\[38;5;.*m$', colorize('foo', 1, 'rgb555'))

# Generated at 2022-06-11 17:47:37.844848
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    rc = hostcolor('host1', stats, True)
    assert rc == u'host1                           '

    stats = dict(failures=1, unreachable=0, changed=0)
    rc = hostcolor('host2', stats, True)
    assert rc == u'\x1b[31mhost2\x1b[0m                       '

    stats = dict(failures=0, unreachable=1, changed=0)
    rc = hostcolor('host3', stats, True)
    assert rc == u'\x1b[31mhost3\x1b[0m                       '

    stats = dict(failures=0, unreachable=0, changed=1)
    rc = hostcolor('host4', stats, True)
   

# Generated at 2022-06-11 17:47:48.586438
# Unit test for function hostcolor
def test_hostcolor():
    helpers = {
        'ok': {'ok': 1, 'changed': 0, 'unreachable': 0, 'failures': 0},
        'changed': {'ok': 1, 'changed': 1, 'unreachable': 0, 'failures': 0},
        'failures': {'ok': 1, 'changed': 0, 'unreachable': 0, 'failures': 1},
        'unreachable': {'ok': 1, 'changed': 0, 'unreachable': 1, 'failures': 0},
    }
    for state in helpers:
        assert hostcolor(state, helpers[state], True) == u'%-26s' % stringc(state, C.COLOR_CODES[state])
        assert hostcolor(state, helpers[state], False) == u'%-26s' % state

# --- end "

# Generated at 2022-06-11 17:47:59.825345
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0, ok=0, skipped=0)

    # All stats at zero
    assert hostcolor('test_host', stats, True) == u"%-37s" % stringc('test_host', C.COLOR_OK)

    # failures
    stats['failures'] = 1
    assert hostcolor('test_host', stats, True) == u"%-37s" % stringc('test_host', C.COLOR_ERROR)
    stats['failures'] = 0
    assert hostcolor('test_host', stats, False) == u"%-26s" % 'test_host'

    # unreachable
    stats['unreachable'] = 1

# Generated at 2022-06-11 17:48:10.154132
# Unit test for function hostcolor
def test_hostcolor():
    test_inventory = [
        u"test1",
        u"test2",
        ]

    test_stats = {
        u"ok": 2,
        u"changed": 0,
        u"unreachable": 0,
        u"failures": 0,
        u"skipped": 0
        }

    test_colors = {
        "ok": C.COLOR_OK,
        "changed": C.COLOR_CHANGED,
        "unreachable": C.COLOR_ERROR,
        "failed": C.COLOR_ERROR
        }


# Generated at 2022-06-11 17:48:19.968345
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize('ok', 0, C.COLOR_OK) == 'ok=0   '
        assert colorize('changed', 0, C.COLOR_CHANGED) == 'changed=0   '
        assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == 'unreachable=0 '
        assert colorize('failed', 0, C.COLOR_ERROR) == 'failed=0    '
    else:
        assert colorize('ok', 0, C.COLOR_OK) == 'ok=0   '
        assert colorize('changed', 0, C.COLOR_CHANGED) == 'changed=0   '
        assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == 'unreachable=0 '

# Generated at 2022-06-11 17:48:32.089359
# Unit test for function stringc
def test_stringc():
    assert u"\033[31mhello\033[0m" == stringc("hello", "RED")
    assert u"\033[31mhello\033[0m" == stringc("hello", "red")
    assert u"\033[39mhello\033[0m" == stringc("hello", "none")
    assert u"\033[39mhello\033[0m" == stringc("hello", "")

    assert u"\033[38;5;124mhello\033[0m" == stringc("hello", "purple")
    assert u"\033[38;5;124mhello\033[0m" == stringc("hello", "color124")
    assert u"\033[38;5;124mhello\033[0m" == stringc("hello", "rgb524")


# Generated at 2022-06-11 17:48:41.862934
# Unit test for function colorize
def test_colorize():
    # Check basic one liner
    assert colorize(u"gid", 1000, u"blue") == u"\033[94mgid=1000\033[0m"
    # Check multiline
    assert colorize(u"gid", u"1000\n1001\n1002", u"blue") == u"\033[94mgid=1000\n    1001\n    1002\033[0m"
    # Check color off
    ANSIBLE_COLOR = False
    assert colorize(u"gid", 1000, u"blue") == u"gid=1000"
    ANSIBLE_COLOR = True


# Generated at 2022-06-11 17:48:53.393389
# Unit test for function stringc
def test_stringc():
    import sys
    if ANSIBLE_COLOR:
        assert stringc("text", "blue", True) == u"\001\033[34m\002text\001\033[0m\002\n"
        assert stringc("text", "blue", False) == u"\033[34mtext\033[0m\n"
        assert stringc("text", "stdout_with_unix_text", True) == u"\001\033[0m\002text\001\033[0m\002\n"
        assert stringc("text", "stdout_with_unix_text", False) == u"\033[0mtext\033[0m\n"

# Generated at 2022-06-11 17:48:56.300706
# Unit test for function colorize
def test_colorize():
    for c in ('white', 'black', 'grey', 'blue', 'cyan', 'green', 'magenta', 'red', 'yellow', 'default'):
        print(colorize('Foo', 42, c))



# Generated at 2022-06-11 17:49:00.836435
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", "1", "blue") == u"foo=1  "
    assert colorize("foo", "10", "blue") == u"foo=10 "
    assert colorize("foo", "100", "blue") == u"foo=100"



# Generated at 2022-06-11 17:49:11.009918
# Unit test for function hostcolor
def test_hostcolor():
    # pylint: disable=import-error
    from ansible.utils.color import hostcolor
    from ansible.playbook.play_context import PlayContext

    stats = dict(
        ok=1,
        changed=0,
        unreachable=0,
        failed=0,
    )
    color = PlayContext(connection='local').prompt_color
    assert hostcolor('localhost', stats, color=color) == u'\033[0;32mlocalhost\033[0m'

    stats = dict(
        ok=0,
        changed=1,
        unreachable=0,
        failed=0,
    )
    assert hostcolor('localhost', stats, color=color) == u'\033[0;34mlocalhost\033[0m'


# Generated at 2022-06-11 17:49:20.943589
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("host.name", dict(failures=1)) == u"host.name               "
    assert hostcolor("host.name", dict(failures=1), False) == u"host.name               "
    assert hostcolor("host.name", dict(failures=1), True) == u"host.name               "
    assert hostcolor("host.name", dict(failures=0, changed=1)) == u"host.name               "
    assert hostcolor("host.name", dict(failures=0, changed=1), False) == u"host.name               "
    assert hostcolor("host.name", dict(failures=0, changed=1), True) == u"host.name               "
    assert hostcolor("host.name", dict(failures=0)) == u"host.name               "
    assert hostcolor

# Generated at 2022-06-11 17:49:37.409948
# Unit test for function hostcolor

# Generated at 2022-06-11 17:49:47.095605
# Unit test for function stringc
def test_stringc():
    print(stringc('foo', 'blue'))
    print(stringc('foo', 'black', wrap_nonvisible_chars=True))
    print(stringc('foo', 'blue', wrap_nonvisible_chars=True))
    print(stringc('foo', 'black'))
    print(stringc('foo', 'blue'))
    print(stringc('foo', 'blue', wrap_nonvisible_chars=True))
    print(stringc('foo', 'black', wrap_nonvisible_chars=True))
    print(stringc('foo', 'black'))
    print(stringc('foo', 'blue'))
    print(stringc('foo', 'red'))
    print(stringc('foo', 'green'))
    print(stringc('foo', 'yellow'))

# Generated at 2022-06-11 17:49:58.748010
# Unit test for function hostcolor
def test_hostcolor():
    result = hostcolor("local", {"failures": 0, "changed": 0, "ok": 1, "dark": 0, "skipped": 0, "unreachable": 0})
    assert result == u"%-37s" % stringc("local", "green")

    result = hostcolor("local", {"failures": 1, "changed": 0, "ok": 1, "dark": 0, "skipped": 0, "unreachable": 0})
    assert result == u"%-37s" % stringc("local", "red")

    result = hostcolor("local", {"failures": 0, "changed": 1, "ok": 1, "dark": 0, "skipped": 0, "unreachable": 0})
    assert result == u"%-37s" % stringc("local", "yellow")

# --- end pretty -----------------------------------------------------------




# Generated at 2022-06-11 17:50:11.341618
# Unit test for function colorize
def test_colorize():
    """ Unit test for function colorize """
    failure_msg = u'FAILURE in function colorize(). '

    # Test 1 - 'changed', 0, 'green'
    lead = u'changed'
    num = 0
    color = u'green'
    expected_result = u'changed=0  '
    actual_result = colorize(lead, num, color)
    assert actual_result == expected_result, \
        "%sExpected %s, got %s." % (failure_msg, expected_result, actual_result)

    # Test 2 - 'changed', 5, 'green'
    lead = u'changed'
    num = 5
    color = u'green'
    expected_result = u'\033[32mchanged=5  \033[0m'

# Generated at 2022-06-11 17:50:21.672356
# Unit test for function hostcolor
def test_hostcolor():
    hosts_all = dict()
    hosts_all['test1'] = dict()
    hosts_all['test2'] = dict()
    hosts_all['test3'] = dict()
    for h in hosts_all:
        hosts_all[h]['changed'] = False
        hosts_all[h]['failures'] = False
        hosts_all[h]['ok'] = False
        hosts_all[h]['dark'] = False
        hosts_all[h]['processed'] = False
        hosts_all[h]['skipped'] = False
        hosts_all[h]['unreachable'] = False
        hosts_all[h]['failures'] = 0
        hosts_all[h]['changed'] = 0
        hosts_all[h]['ok'] = 0
        hosts_all[h]['dark']

# Generated at 2022-06-11 17:50:31.523027
# Unit test for function colorize
def test_colorize():
    assert 'fail=1' == colorize('fail', 1, 'red')
    assert 'skip=2' == colorize('skip', 2, 'cyan')
    assert 'ok=3' == colorize('ok', 3, 'green')
    assert 'changed=4' == colorize('changed', 4, 'yellow')
    assert 'unreachable=5' == colorize('unreachable', 5, 'blue')


# --- end "pretty"

# --- begin "terminal"
#
# terminal - A terminal library to facilitate output from within
#            playbook code. This code is public domain - there is
#            no license except that you must leave this header.
#            Modified for ansible by Michael DeHaan.
#
# Copyright (C) 2008 Brian Nez <thedude at bri1 dot com>
# Copyright (C) 2014

# Generated at 2022-06-11 17:50:41.187788
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor, ANSIBLE_COLOR
    from ansible.utils.color import C
    from ansible.utils.color import stringc

    stats = dict(
        ok=1,
        changed=2,
        unreachable=3,
        skipped=4,
        failed=5
    )
    #print stats

    ANSIBLE_COLOR=True
    assert u"%-26s" % (stringc('127.0.0.1', C.COLOR_CHANGED)) == hostcolor('127.0.0.1', dict(changed=1), True)
    assert u"%-26s" % (stringc('127.0.0.1', C.COLOR_ERROR)) == hostcolor('127.0.0.1', dict(failed=1), True)

# Generated at 2022-06-11 17:50:50.658999
# Unit test for function stringc
def test_stringc():
    color_visible = '[0mhello [1mworld [0m'
    color_invisible = '\001\033[0mhello \002\001\033[1mworld \001\033[0m\002'

    # Disabled colorization
    global ANSIBLE_COLOR; ANSIBLE_COLOR = False
    assert stringc('hello world', 'RED', False) == 'hello world'
    assert stringc('hello world', 'RED', True) == 'hello world'

    # Enabled colorization
    ANSIBLE_COLOR = True
    assert stringc('hello world', 'RED', False) == color_visible
    assert stringc('hello world', 'RED', True) == color_invisible

# Generated at 2022-06-11 17:51:02.567182
# Unit test for function stringc
def test_stringc():
    # Test 1: plain, positive case
    assert stringc('test', 'blue') == u'\033[34mtest\033[0m'

    # Test 2: plain, negative case
    assert stringc('test', 'blue') != u'\033[34mtest'

    # Test 3: plain, negative case
    assert stringc('test', 'blue') != u'test\033[0m'

    # Test 4: negative case (wrong color code)
    assert stringc('test', 'blue') != u'\033[35mtest\033[0m'

    # Test 5: negative case (wrong color code)
    assert stringc('test', 'blue') != u'\033[34mtest'

    # Test 6: negative case (wrong color code)

# Generated at 2022-06-11 17:51:13.581626
# Unit test for function hostcolor
def test_hostcolor():
    ansible_color = C.ANSIBLE_COLOR
    C.ANSIBLE_COLOR = True
    stats = dict(
        ok=2,
        changed=0,
        unreachable=0,
        skipped=0,
        failures=1,
    )
    assert hostcolor('host', stats) == u'host                          '
    stats['changed'] = 2
    assert hostcolor('host', stats) == u'host                          '
    stats['failures'] = 0
    assert hostcolor('host', stats) == u'host                          '
    stats['changed'] = 0
    stats['unreachable'] = 2
    assert hostcolor('host', stats) == u'host                          '
    C.ANSIBLE_COLOR = ansible_color



# Generated at 2022-06-11 17:51:36.350765
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo.example.com', dict(ok=1), True) == u"foo.example.com               "
    assert hostcolor('foo.example.com', dict(ok=1), False) == u"foo.example.com"
    assert hostcolor('foo.example.com', dict(failures=1), True) == "foo.example.com               "

# --- end "pretty"



# Generated at 2022-06-11 17:51:46.602730
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    from nose.tools import eq_
    eq_(u'hello', stringc(u'hello', None, False))
    eq_(u'hello', stringc(u'hello', None, True))
    eq_(u'\001\033[0;31m\002hello\001\033[0m\002', stringc(u'hello', 'red', True))
    eq_(u'\001\033[0;37m\002hello\001\033[0m\002', stringc(u'hello', 'white', True))
    eq_(u'\001\033[0;37m\002hello\001\033[0m\002', stringc(u'hello', '0', True))

# Generated at 2022-06-11 17:51:51.282028
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test.example.com", {'failures': 0, 'changed': 0, 'unreachable': 0}) == "test.example.com                "



# Generated at 2022-06-11 17:52:01.170643
# Unit test for function colorize
def test_colorize():
    # For stringc()
    if ANSIBLE_COLOR is False:
        assert stringc("test", "black") == "test"
        assert stringc("test", "dark red") == "test"

    # Colorize with ANSIBLE_COLOR=True
    if ANSIBLE_COLOR is True:
        assert colorize("a", 0, C.COLOR_SKIP) == 'a=0   '
        assert colorize("a", 1, C.COLOR_SKIP) == 'a=1   '
        assert colorize("a", 1, None) == u'a=1   '
        assert colorize(u"a", 1, C.COLOR_SKIP) == u'a=1   '
        assert colorize(u"a", 1, None) == u'a=1   '

    # Colorize with ANSIBLE_

# Generated at 2022-06-11 17:52:12.851675
# Unit test for function hostcolor
def test_hostcolor():
    host = 'myhost'
    stats = {'failures':0, 'unreachable':0, 'changed':0, 'ok':1}
    assert hostcolor(host, stats) == u'%-37s' % host
    stats['failures'] = stats['unreachable'] = 1
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats['failures'] = 0
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats['unreachable'] = 0
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_CHANGED)
    stats['changed'] = 0

# Generated at 2022-06-11 17:52:14.245625
# Unit test for function colorize
def test_colorize():
    import doctest
    doctest.testmod()
# --- end of "pretty" ---

# Generated at 2022-06-11 17:52:25.924086
# Unit test for function hostcolor
def test_hostcolor():
    test_stats = dict(skipped=0, ok=0, failures=1, unreachable=0, changed=0)
    assert hostcolor('localhost', test_stats, color=True) == stringc('localhost', C.COLOR_ERROR)
    test_stats = dict(skipped=0, ok=0, failures=0, unreachable=0, changed=1)
    assert hostcolor('localhost', test_stats, color=True) == stringc('localhost', C.COLOR_CHANGED)
    test_stats = dict(skipped=0, ok=1, failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', test_stats, color=True) == stringc('localhost', C.COLOR_OK)

# Generated at 2022-06-11 17:52:34.739510
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "color7") == u"\033[38;5;7mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "gray0") == u"\033[38;5;232mfoo\033[0m"
    assert stringc("foo", "gray8") == u"\033[38;5;240mfoo\033[0m"
    assert stringc("foo", "gray15") == u"\033[38;5;255mfoo\033[0m"


# Generated at 2022-06-11 17:52:42.215211
# Unit test for function stringc
def test_stringc():
    c0 = 'black'
    c1 = 'dark gray'
    c2 = 'blue'
    c3 = 'light blue'
    c4 = 'green'
    c5 = 'light green'
    c6 = 'cyan'
    c7 = 'light cyan'
    c8 = 'red'
    c9 = 'light red'
    c10 = 'purple'
    c11 = 'light purple'
    c12 = 'brown'
    c13 = 'yellow'
    c14 = 'light gray'
    c15 = 'white'


# Generated at 2022-06-11 17:52:43.463305
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {}) == u'localhost                 '



# Generated at 2022-06-11 17:53:09.971244
# Unit test for function hostcolor
def test_hostcolor():
    test_hosts = ['127.0.0.1', 'localhost', 'hostname', '1234567890abcdefg', 'abcdefg1234567890']
    test_stats = ['ok', 'changed', 'failed', 'unreachable']
    for host in test_hosts:
        for stat in test_stats:
            yield _test_hostcolor, host, stat, True
            yield _test_hostcolor, host, stat, False



# Generated at 2022-06-11 17:53:19.685853
# Unit test for function hostcolor
def test_hostcolor():
    result = hostcolor('host1', dict(ok=10, changed=0, unreachable=0, skipped=0, failures=0))
    assert result == u"host1-----------------------", result

    result = hostcolor('host2', dict(ok=0, changed=10, unreachable=0, skipped=0, failures=0))
    assert result == u"host2-----------------------", result

    result = hostcolor('host3', dict(ok=0, changed=0, unreachable=10, skipped=0, failures=0))
    assert result == u"host3-----------------------", result

    result = hostcolor('host4', dict(ok=0, changed=0, unreachable=0, skipped=10, failures=0))
    assert result == u"host4-----------------------", result


# Generated at 2022-06-11 17:53:30.107808
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor('host', stats) == u"%-37s" % stringc(u'host', C.COLOR_CHANGED)
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('host', stats) == u"%-37s" % stringc(u'host', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('host', stats) == u"%-37s" % stringc(u'host', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=0, changed=0)

# Generated at 2022-06-11 17:53:41.498356
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == '\x1b[32mfoo\x1b[0m'
    assert stringc('foo', 'red') == '\x1b[31mfoo\x1b[0m'
    assert stringc('foo', 'yellow') == '\x1b[33mfoo\x1b[0m'
    assert stringc('foo', 'blue') == '\x1b[34mfoo\x1b[0m'
    assert stringc('foo', 'magenta') == '\x1b[35mfoo\x1b[0m'
    assert stringc('foo', 'cyan') == '\x1b[36mfoo\x1b[0m'

# Generated at 2022-06-11 17:53:48.510653
# Unit test for function hostcolor

# Generated at 2022-06-11 17:53:58.256093
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(changed=0, failures=0, unreachable=0, ok=1)) == "%-26s" % "localhost", "hostcolor ERROR"
    assert hostcolor("localhost", dict(changed=0, failures=0, unreachable=1, ok=0)) == "%-26s" % "localhost", "hostcolor ERROR"
    assert hostcolor("localhost", dict(changed=0, failures=1, unreachable=0, ok=0)) == "%-26s" % "localhost", "hostcolor ERROR"
    assert hostcolor("localhost", dict(changed=1, failures=0, unreachable=0, ok=0)) == "%-26s" % "localhost", "hostcolor ERROR"

# Generated at 2022-06-11 17:54:06.471938
# Unit test for function stringc
def test_stringc():
    """Test colorization of strings.

    >>> stringc(u"Hello", u"blue")
    u'\\x1b[34mHello\\x1b[0m'
    >>> stringc(u"Hello", u"rgb255000")
    u'\\x1b[38;5;9mHello\\x1b[0m'
    >>> stringc(u"Hello", u"green", wrap_nonvisible_chars=True)
    u'\\x01\\x1b[32m\\x02Hello\\x01\\x1b[0m\\x02'

    """
    import doctest
    doctest.testmod()
# END "pretty"



# Generated at 2022-06-11 17:54:18.391179
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    if hostcolor(u"localhost", stats, False) != u"%-26s" % u"localhost":
        return False
    if hostcolor(u"localhost", stats, True) != u"%-37s" % stringc(u"localhost", C.COLOR_OK):
        return False
    stats['changed'] = 1
    if hostcolor(u"localhost", stats, True) != u"%-37s" % stringc(u"localhost", C.COLOR_CHANGED):
        return False
    stats['changed'] = 0
    stats['unreachable'] = 1
    if hostcolor(u"localhost", stats, True) != u"%-37s" % stringc(u"localhost", C.COLOR_ERROR):
        return False

# Generated at 2022-06-11 17:54:27.347419
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, C.COLOR_SKIP) == u"foo=0   "
    assert colorize("foo", 1, C.COLOR_SKIP) == u"foo=1   "
    assert colorize("foo", 2, C.COLOR_SKIP) == u"foo=2   "
    assert colorize("foo", 3, C.COLOR_SKIP) == u"foo=3   "
    assert colorize("foo", -1, C.COLOR_SKIP) == u"foo=-1  "
    assert colorize("foo", -2, C.COLOR_SKIP) == u"foo=-2  "
    assert colorize("foo", -3, C.COLOR_SKIP) == u"foo=-3  "

    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert colorize

# Generated at 2022-06-11 17:54:37.323904
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        changed=2,
        unreachable=0,
        failures=0,
    )
    print(hostcolor('example.com', stats, color=False))
    print(hostcolor('example.com', stats, color=True))

    stats = dict(
        changed=0,
        unreachable=2,
        failures=0,
    )
    print(hostcolor('example.com', stats, color=False))
    print(hostcolor('example.com', stats, color=True))

    stats = dict(
        changed=0,
        unreachable=0,
        failures=2,
    )
    print(hostcolor('example.com', stats, color=False))
    print(hostcolor('example.com', stats, color=True))
