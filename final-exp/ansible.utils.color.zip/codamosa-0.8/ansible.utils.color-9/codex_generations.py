

# Generated at 2022-06-11 17:45:08.811894
# Unit test for function hostcolor
def test_hostcolor():
    from collections import Counter
    from ansible.utils.color import hostcolor
    from ansible.utils.color import stringc

    failed_stats = Counter()
    failed_stats['failures'] = 2
    failed_host = "failed_host"
    assert stringc(
        hostcolor(failed_host, failed_stats), C.COLOR_ERROR) == u"%-37s" % stringc(failed_host, C.COLOR_ERROR)

    ok_stats = Counter()
    ok_stats['failures'] = 0
    ok_stats['changed'] = 0
    ok_host = "ok_host"
    assert stringc(
        hostcolor(ok_host, ok_stats), C.COLOR_OK) == u"%-37s" % stringc(ok_host, C.COLOR_OK)

    changed_stats = Counter()

# Generated at 2022-06-11 17:45:19.299339
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("testhost1", dict(failures=0, unreachable=0, changed=0)) == "testhost1                 "
    assert hostcolor("testhost1", dict(failures=1, unreachable=0, changed=0)) == "testhost1                 "
    color_string = re.compile(u'[\033\001].*?[\033\002]')
    assert color_string.match(hostcolor("testhost1", dict(failures=0, unreachable=0, changed=0), color=True))
    assert not color_string.match(hostcolor("testhost1", dict(failures=0, unreachable=0, changed=0), color=False))



# Generated at 2022-06-11 17:45:31.041737
# Unit test for function hostcolor
def test_hostcolor():
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0

    # test hostcolor when color is disabled
    assert hostcolor(u"127.0.0.1", stats, color=False) == u"127.0.0.1               "

    # test hostcolor with changed
    stats['changed'] = 10
    assert hostcolor(u"127.0.0.1", stats, color=True) == "\x1b[0;34m127.0.0.1             \x1b[0m"

    # test hostcolor with unreachable
    stats['changed'] = 0
    stats['unreachable'] = 1

# Generated at 2022-06-11 17:45:31.872260
# Unit test for function hostcolor
def test_hostcolor():
    assert "this is a test" == "this is a test"



# Generated at 2022-06-11 17:45:42.282931
# Unit test for function parsecolor
def test_parsecolor():
    from pprint import pprint

# Generated at 2022-06-11 17:45:51.428821
# Unit test for function colorize
def test_colorize():
    print(u"\n%-9s %s %s %s %s %s %s %s %s" %
          (u'Module', u'=', u'success', u'=', u'failures', u'=',
           u'changed', u'=', u'unreachable'))

    for mod in (u'ping', u'setup'):
        print(u"%-9s %s" % (mod, u'~' * 70))
        for host in (u'slave1', u'slave2'):
            stats = {
                u'success': 12,
                u'failures': 2,
                u'changed': 0,
                u'unreachable': 0,
                u'ignored': 0
            }

# Generated at 2022-06-11 17:45:56.712573
# Unit test for function parsecolor
def test_parsecolor():
    """ Test parsecolor function """
    result = "38;5;9"
    assert result == parsecolor("color9")
    result = "38;5;208"
    assert result == parsecolor("gray6")
    result = "38;5;15"
    assert result == parsecolor("rgb555")
# --- end "pretty"

# Generated at 2022-06-11 17:46:07.670890
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == u"34"
    assert parsecolor("rgb123") == u"38;5;01"
    assert parsecolor("rgb234") == u"38;5;28"
    assert parsecolor("rgb345") == u"38;5;59"
    assert parsecolor("rgb012") == u"38;5;16"
    assert parsecolor("rgb021") == u"38;5;19"
    assert parsecolor("rgb102") == u"38;5;22"
    assert parsecolor("rgb120") == u"38;5;24"
    assert parsecolor("rgb201") == u"38;5;26"
    assert parsecolor("rgb210") == u"38;5;27"
    assert parsecolor

# Generated at 2022-06-11 17:46:20.074602
# Unit test for function hostcolor
def test_hostcolor():
    from nose.tools import assert_equals

    hc = hostcolor('test.example.com', dict(failures=0, unreachable=0, ok=20, changed=0), False)
    assert_equals(hc, 'test.example.com             ')

    hc = hostcolor('test.example.com', dict(failures=0, unreachable=0, ok=20, changed=0), True)
    assert_equals(hc, 'test.example.com             ')

    hc = hostcolor('test.example.com', dict(failures=0, unreachable=0, ok=20, changed=1), True)
    assert_equals(hc, '\x1b[0;34mtest.example.com             \x1b[0m')


# Generated at 2022-06-11 17:46:29.965369
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("dark gray") == u'38;5;242'
    assert parsecolor("white") == u'97'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("rgb255252249") == u'38;5;231'
    assert parsecolor("rgb000") == u'38;5;16'
    assert parsecolor("rgb255000") == u'38;5;196'
    assert parsecolor("rgb255000000") == u'38;5;124'
    assert parsecolor("rgb255255255") == u'38;5;231'
    assert parsecolor("rgb000255") == u'38;5;21'
    assert parsecolor("rgb00000255") == u'38;5;33'

# Generated at 2022-06-11 17:46:36.747665
# Unit test for function colorize
def test_colorize():
    assert "\033[31m=0   \033[0m" == colorize("=", 0, "red"), "colorize failed."



# Generated at 2022-06-11 17:46:47.858475
# Unit test for function stringc
def test_stringc():
    import sys
    import unittest
    import colorp
    colorp.ANSIBLE_COLOR = True

    class Test(unittest.TestCase):
        def test_should_be_changed(self):
            s = colorp.stringc(u"hello", u"blue")
            self.assertEqual(u"\033[34mhello\033[0m", s)

        def test_should_be_changed_rgb(self):
            s = colorp.stringc(u"hello", u"rgb255255255")
            self.assertEqual(u"\033[38;5;231mhello\033[0m", s)

        def test_should_be_changed_gray(self):
            s = colorp.stringc(u"hello", u"gray0")
            self.assertEqual

# Generated at 2022-06-11 17:46:52.989463
# Unit test for function colorize
def test_colorize():
    lead = 'test'
    num = 1
    color = 'green'

    if not ANSIBLE_COLOR:
        color = None
    s = colorize(lead, num, color)
    assert num in s
    assert lead in s
    if ANSIBLE_COLOR:
        assert color in s
    else:
        assert color not in s

# Generated at 2022-06-11 17:47:03.486532
# Unit test for function stringc
def test_stringc():
    """Tests for function stringc."""

    assert u"\033[0m" == stringc(u"reset", u"reset")

    assert u"\033[31m" == stringc(u"", u"red")
    assert u"\033[31mtext\033[0m" == stringc(u"text", u"red")
    assert (u"\033[31mtext\n"
            u"spanning\n"
            u"multiple lines\033[0m") == stringc(u"text\nspanning\nmultiple "
                                                 u"lines", u"red")

    assert u"\033[38;5;0m" == stringc(u"", u"color0")

# Generated at 2022-06-11 17:47:12.894636
# Unit test for function colorize
def test_colorize():
    ''' colorize() returns strings that match expected patterns '''
    assert re.match('ok=\\-?[0-9]+',
                    colorize('ok', 0, None))
    assert re.match('changed=\\-?[0-9]+',
                    colorize('changed', 0, C.COLOR_CHANGED))
    # \d+\s*=\s*\d+\s*\n
    assert re.match('failed=\\-?[0-9]+',
                    colorize('failed', 0, C.COLOR_ERROR))


if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-11 17:47:20.216099
# Unit test for function stringc
def test_stringc():
    """Test stringc"""
    # Test known mappings
    assert stringc('foo', 'red') == u'\u001b[31mfoo\u001b[0m'
    # Test basic rgb function
    assert stringc('foo', 'rgb25060') == u'\u001b[38;5;208mfoo\u001b[0m'
    # Test basic gray function
    assert stringc('foo', 'gray8') == u'\u001b[38;5;244mfoo\u001b[0m'
    # Test invalid color
    assert stringc('foo', 'does-not-exist') == u'foo'



# Generated at 2022-06-11 17:47:31.477774
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-37s' % u"\033[0;32mlocalhost\033[0m"
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % u"\033[0;31mlocalhost\033[0m"
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % u"\033[0;31mlocalhost\033[0m"
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % u"\033[0;33mlocalhost\033[0m"



# Generated at 2022-06-11 17:47:44.442414
# Unit test for function parsecolor
def test_parsecolor():
    # Test some valid color values
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('default') == u'39'
    assert parsecolor('white') == u'38;5;15'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('rgb255000255') == u'38;5;13'
    assert parsecolor('rgb000255255') == u'38;5;14'
    assert parsecolor('rgb255255000') == u'38;5;11'
    assert parsecolor('rgb000255000') == u'38;5;2'

# Generated at 2022-06-11 17:47:51.126885
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=0, failures=0, unreachable=0)
    assert hostcolor('foo.bar.baz', stats)
    stats = dict(changed=1, failures=0, unreachable=0)
    assert hostcolor('foo.bar.baz', stats)
    stats = dict(changed=0, failures=1, unreachable=0)
    assert hostcolor('foo.bar.baz', stats)
    stats = dict(changed=0, failures=0, unreachable=1)
    assert hostcolor('foo.bar.baz', stats)
    stats = dict(changed=1, failures=1, unreachable=1)
    assert hostcolor('foo.bar.baz', stats)

# --- end "pretty" ---

# FIXME: remove
# This is provided as a temporary override and the specific use cases

# Generated at 2022-06-11 17:47:59.376780
# Unit test for function hostcolor
def test_hostcolor():
    data = dict(failed=0, changed=0, ok=0, skipped=0, unreachable=0)
    assert hostcolor("localhost", data, True) == u"%-37s" % stringc("localhost", C.COLOR_OK)

    data = dict(failed=0, changed=1, ok=0, skipped=0, unreachable=0)
    assert hostcolor("localhost", data, True) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)

    data = dict(failed=1, changed=0, ok=0, skipped=0, unreachable=0)
    assert hostcolor("localhost", data, True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)


# Generated at 2022-06-11 17:48:04.950378
# Unit test for function hostcolor
def test_hostcolor():
    # TODO
    pass



# Generated at 2022-06-11 17:48:12.580063
# Unit test for function colorize
def test_colorize():
    assert colorize("test", 0, "green") == u"test=0   "
    assert colorize("test", 1, "green") == u"test=1   "
    assert colorize("test", 2, "green") == u"test=2   "
    assert colorize("test", 3, "green") == u"test=3   "
    assert colorize("test1", 1234, "green") == u"test1=1234"
    assert colorize("test2", -1234, "green") == u"test2=-1234"
    assert colorize("test3", -1, "green") == u"test3=-1  "
    assert colorize("test", 0, None) == u"test=0   "
    assert colorize("test", 1, None) == u"test=1   "

# Generated at 2022-06-11 17:48:20.763527
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=False) == u"localhost            "
    stats = dict(failures=1, unreachable=0, changed=0)
    assert u'\033[31m' in hostcolor('localhost', stats, color=True)
    stats = dict(failures=0, unreachable=1, changed=0)
    assert u'\033[31m' in hostcolor('localhost', stats, color=True)
    stats = dict(failures=0, unreachable=0, changed=1)
    assert u'\033[33m' in hostcolor('localhost', stats, color=True)



# Generated at 2022-06-11 17:48:32.567508
# Unit test for function colorize
def test_colorize():

    # the color codes are reset at the end of the string, so we need to reset the
    # color inbetween tests.
    def test_colorize_inner(lead, num, color, exp):
        s = colorize(lead, num, color)
        assert s == u"%s" % exp

    test_colorize_inner("ok", 0, C.COLOR_OK, "ok=0  ")
    test_colorize_inner("changed", 0, C.COLOR_CHANGED, "changed=0  ")
    test_colorize_inner("failed", 0, C.COLOR_ERROR, "failed=0  ")
    test_colorize_inner("failed", 0, None, "failed=0  ")
    test_colorize_inner("ok", 0, None, "ok=0  ")
    test_

# Generated at 2022-06-11 17:48:43.822008
# Unit test for function stringc
def test_stringc():
    """ Tests for the stringc() function. """
    print(u"\n=== Testing stringc() ===")

    # Each test is of the form (text, color, expected)

# Generated at 2022-06-11 17:48:47.924516
# Unit test for function stringc
def test_stringc():
    assert '\033[31mfoo\033[0m' == stringc('foo', 'red')
    assert '\033[31mfoo\033[0m' == stringc('foo', 'rgb255000')
    assert '\033[32mfoo\033[0m' == stringc('foo', 'green')
    assert '\033[33mfoo\033[0m' == stringc('foo', 'yellow')



# Generated at 2022-06-11 17:48:56.030235
# Unit test for function hostcolor
def test_hostcolor():
    host = "testhost.example.com"
    stats = dict(
        ok=1,
        failures=1,
        unreachable=1,
        changed=1)
    for k in ['ok', 'failures', 'unreachable', 'changed']:
        host_with_color = hostcolor(host, dict(ok=stats[k]), color=True)
        no_color = hostcolor(host, dict(ok=stats[k]), color=False)
        assert host_with_color == no_color  # no color for k == stats[k]
        assert host_with_color == u"%-37s" % host  # and no color for color=False

# Generated at 2022-06-11 17:49:07.460002
# Unit test for function stringc
def test_stringc():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert stringc('foo', 'red', False) == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'red', True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc('foo', 'color3', False) == u"\033[38;5;207mfoo\033[0m"
    assert stringc('foo', 'color3', True) == u"\001\033[38;5;207m\002foo\001\033[0m\002"
    assert stringc('foo', 'rgb3', False) == u"\033[38;5;22mfoo\033[0m"

# Generated at 2022-06-11 17:49:13.454076
# Unit test for function colorize
def test_colorize():
    # Prints "ok" in green, "changed" in yellow, else red
    print(u"%-15s" % colorize(u"ok:", 0, C.COLOR_OK))
    print(u"%-15s" % colorize(u"changed:", 1, C.COLOR_CHANGED))
    print(u"%-15s" % colorize(u"failures:", 1, C.COLOR_ERROR))
    print(u"%-15s" % colorize(u"skipped:", 3, C.COLOR_SKIP))

# --- end "pretty"

# Generated at 2022-06-11 17:49:24.296230
# Unit test for function stringc
def test_stringc():
    ANSIBLE_COLOR = True
    assert stringc("foobar", "red", wrap_nonvisible_chars=True) == u"\u001b[31mfoobar\u001b[0m"
    assert stringc("foobar", "red", wrap_nonvisible_chars=False) == u"\u001b[31mfoobar\u001b[0m"
    ANSIBLE_COLOR = False
    assert stringc("foobar", "red", wrap_nonvisible_chars=True) == u"foobar"
    assert stringc("foobar", "red", wrap_nonvisible_chars=False) == u"foobar"

    # Test for non-existing SGR color

# Generated at 2022-06-11 17:49:31.680330
# Unit test for function colorize
def test_colorize():
    lead = u"test"
    num = 2
    color = C.COLOR_OK
    assert colorize(lead, num, color) == u"test=2   "

# END pretty.py
# ---


# Generated at 2022-06-11 17:49:38.923245
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    assert stringc('hello', 'red') == u"\033[31mhello\033[0m"
    assert stringc('hello', 'blue') == u"\033[34mhello\033[0m"
    assert stringc('hello', 'on_red') == u"\033[41mhello\033[0m"
    assert stringc('hello', 'on_blue') == u"\033[44mhello\033[0m"
    assert stringc('hello', 'red', True) == u"\001\033[31m\002hello\001\033[0m\002"
    assert stringc('hello', 'blue', True) == u"\001\033[34m\002hello\001\033[0m\002"

# Generated at 2022-06-11 17:49:44.964351
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    # Assert returns the expected string when there are no failures or
    # unreachable hosts in color.
    assert(hostcolor('testhost', stats) == '\033[32mtesthost\033[0m')
    # Assert that changing stats['changed'] returns the expected string
    # with the color
    stats['changed'] = 1
    assert(hostcolor('testhost', stats) == '\033[33mtesthost\033[0m')
    # Assert that changing stats['failures'] returns the expected string
    # with the color
    stats['changed'] = 0
    stats['failures'] = 1
    assert(hostcolor('testhost', stats) == '\033[31mtesthost\033[0m')
    # Ass

# Generated at 2022-06-11 17:49:49.737815
# Unit test for function colorize
def test_colorize():
    """Make sure colorize returns the correct strings for color and non-color
    environments."""
    assert colorize('foo', 4, 'red') == u"foo=4   "
    assert colorize('foo', 4, None) == u"foo=4   "
    assert colorize('foo', 0, 'red') == u"foo=0   "
    assert colorize('foo', 0, None) == u"foo=0   "


# --- end "pretty"



# Generated at 2022-06-11 17:49:56.977729
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(ok=1)) == u"localhost               "
    assert hostcolor('localhost', dict(ok=1, changed=1)) == u"\x1b[0;34mlocalhost               \x1b[0m"
    assert hostcolor('localhost', dict(ok=1, unreachable=1)) == u"\x1b[0;31mlocalhost               \x1b[0m"

# --- end "pretty"



# Generated at 2022-06-11 17:50:04.132662
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foobar', {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}) == 'foobar                     '
    assert hostcolor('foobar', {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == u'\u001b[0;33mfoobar\u001b[0m                     '
    assert hostcolor('foobar', {'changed': 0, 'failures': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == u'\u001b[0;31mfoobar\u001b[0m                     '

# Generated at 2022-06-11 17:50:15.697091
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("testhost", {"failures": 0, "unreachable": 0, "changed": 1}) \
        == u"%-37s" % stringc("testhost", C.COLOR_CHANGED)
    assert hostcolor("testhost", {"failures": 0, "unreachable": 1, "changed": 0}) \
        == u"%-37s" % stringc("testhost", C.COLOR_ERROR)
    assert hostcolor("testhost", {"failures": 1, "unreachable": 0, "changed": 0}) \
        == u"%-37s" % stringc("testhost", C.COLOR_ERROR)

# Generated at 2022-06-11 17:50:24.447091
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        print("\033[31m" + "This text should be red" + "\033[0m")
        print("\033[32m" + "This text should be green" + "\033[0m")
        print("\033[33m" + "This text should be yellow" + "\033[0m")
        print("\033[34m" + "This text should be blue" + "\033[0m")
        print("\033[35m" + "This text should be magenta" + "\033[0m")
        print("\033[36m" + "This text should be cyan" + "\033[0m")
        print("\033[37m" + "This text should be white" + "\033[0m")


# Generated at 2022-06-11 17:50:33.506079
# Unit test for function stringc
def test_stringc():
    expected = u'\033[31mfoo\033[0m'
    actual = stringc('foo', 'red')
    assert expected == actual, 'Expected %s but got %s' % (expected, actual)
    actual = stringc('foo', 'color1')
    assert expected == actual, 'Expected %s but got %s' % (expected, actual)
    expected = u'\033[38;5;124mfoo\033[0m'
    actual = stringc('foo', 'rgb124')
    assert expected == actual, 'Expected %s but got %s' % (expected, actual)
    expected = u'\033[38;5;124m\nfoo\n\033[0m'
    actual = stringc('\nfoo\n', 'rgb124')

# Generated at 2022-06-11 17:50:42.201801
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo", {'changed': 0, 'skipped': 0, 'failed': 0, 'ok': 1}, True) == u"%-37s" % u"\033[0;32mfoo\033[0m"
    assert hostcolor("bar", {'changed': 0, 'skipped': 0, 'failed': 0, 'ok': 0}, True) == u"%-37s" % u"\033[0;31mbar\033[0m"
    assert hostcolor("baz", {'changed': 1, 'skipped': 0, 'failed': 0, 'ok': 0}, True) == u"%-37s" % u"\033[0;33mbaz\033[0m"

# Generated at 2022-06-11 17:51:02.298392
# Unit test for function colorize
def test_colorize():
    print('colorize')
    print(colorize('ok', 0, C.COLOR_OK))
    print(colorize('changed', 0, C.COLOR_CHANGED))
    print(colorize('unreachable', 0, C.COLOR_UNREACHABLE))
    print(colorize('failed', 0, C.COLOR_ERROR))
    print(colorize('skipped', 0, None))
    print(colorize('ok', 1, C.COLOR_OK))
    print(colorize('changed', 2, C.COLOR_CHANGED))
    print(colorize('unreachable', 3, C.COLOR_UNREACHABLE))
    print(colorize('failed', 4, C.COLOR_ERROR))
    print(colorize('skipped', 5, None))

# --- end "pretty"

# Generated at 2022-06-11 17:51:08.770699
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor

    stats = {'ok':10, 'failures': 0, 'changed': 0, 'unreachable':0}
    assert hostcolor('fake_host', stats, True) == u"%-37s" % stringc('fake_host', C.COLOR_OK)
    stats = {'ok':10, 'failures': 1, 'changed': 0, 'unreachable':0}
    assert hostcolor('fake_host', stats, True) == u"%-37s" % stringc('fake_host', C.COLOR_ERROR)
    assert hostcolor('fake_host', stats, False) == u"%-37s" % 'fake_host'

# --- end of "pretty"

# a specialized version of the above hostcolor() for  single hosts

# Generated at 2022-06-11 17:51:18.460899
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost : ok=1    changed=0    unreachable=0    failed=0",
                     dict(ok=1, changed=0, unreachable=0, failed=0),
                     color=True) == u'localhost : ok=1    changed=0    unreachable=0    failed=0'
    assert hostcolor("localhost : ok=1    changed=0    unreachable=0    failed=0",
                     dict(ok=1, changed=0, unreachable=0, failed=1),
                     color=True) == u'localhost : \x1b[31mok=1    changed=0    unreachable=0    failed=0\x1b[0m'

# Generated at 2022-06-11 17:51:23.661355
# Unit test for function stringc
def test_stringc():
    """Example:
    $ ./pretty.py
    This is just a test
    ==> |This is just a test             |
    This is a test in red
    ==> |\x1b[31mThis is a test in red\x1b[0m|
    """

    def chk(color, s):
        s2 = stringc(s, color)
        if s2 != s:
            print("==> |%s|" % s2)

    print("This is just a test")
    chk("blue", "This is just a test")
    print("This is a test in red")
    chk("RED",  "This is a test in red")
    print("This is a bold test in red")

# Generated at 2022-06-11 17:51:35.045493
# Unit test for function stringc

# Generated at 2022-06-11 17:51:43.138138
# Unit test for function hostcolor
def test_hostcolor():

    host = u"myhost.mydomain.com"
    stats = {}

    # Test 1
    stats = {
       'failures': 0,
       'unreachable': 0,
       'skipped': 0,
       'changed': 0,
       'ok': 4
    }
    color = hostcolor(host, stats, True)
    assert color == stringc(host, C.COLOR_OK)

    # Test 2
    stats['changed'] = 1
    color = hostcolor(host, stats, True)
    assert color == stringc(host, C.COLOR_CHANGED)

# Generated at 2022-06-11 17:51:51.131423
# Unit test for function colorize
def test_colorize():
    # Colorize should return color codes when ANSIBLE_COLOR=True
    # and no color codes when ANSIBLE_COLOR=False
    ANSIBLE_COLOR_SAVE = ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    result = colorize(u'foo', u'0', u'black')
    assert u"\033[0mfoo=0   \033[0m" == result
    result = colorize(u'foo', u'0', None)
    assert u"foo=0   " == result
    result = colorize(u'foo', u'2', u'black')
    assert u"\033[0mfoo=2   \033[0m" == result
    result = colorize(u'foo', u'3', u'green')

# Generated at 2022-06-11 17:52:01.019708
# Unit test for function stringc
def test_stringc():
    """Test the function stringc"""
    colors = C.COLOR_CODES.keys()
    colors.remove('black')
    colors.remove('white')
    colors.remove('blue')
    colors.remove('bright_blue')
    colors.remove('red')
    colors.remove('bright_red')
    colors.remove('green')
    colors.remove('bright_green')
    colors.remove('yellow')
    colors.remove('bright_yellow')
    colors.remove('cyan')
    colors.remove('bright_cyan')
    colors.remove('magenta')
    colors.remove('bright_magenta')
    colors.remove('reset')
    colors.remove('yellow_red')
    colors.remove('green_red')
    colors.remove('unreachable')

    # Make sure they print

# Generated at 2022-06-11 17:52:05.129543
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0, ok=1)) == u'\x1b[32mlocalhost\x1b[0m'
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0, ok=0)) == u'\x1b[31mlocalhost\x1b[0m'
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1, ok=1)) == u'\x1b[33mlocalhost\x1b[0m'



# Generated at 2022-06-11 17:52:15.679579
# Unit test for function hostcolor
def test_hostcolor():
    stats_changed = dict(changed=1, ok=2)
    stats_unreachable_or_failed = dict(failures=1, unreachable=1, changed=1)
    stats_ok = dict(ok=1, changed=0)

    # ansible_color is True if the output is not redirected
    if ANSIBLE_COLOR:
        assert hostcolor("foohost", stats_ok) == u"\033[32mfoohost\033[0m"
        assert hostcolor("foohost", stats_changed) == u"\033[33mfoohost\033[0m"
        assert hostcolor("foohost", stats_unreachable_or_failed) == u"\033[31mfoohost\033[0m"

# Generated at 2022-06-11 17:52:37.149233
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'

# Generated at 2022-06-11 17:52:45.109324
# Unit test for function hostcolor
def test_hostcolor():
    # Colorize host string only if color is enabled
    assert hostcolor('host1', {}, color=True) == u"%-37s" % stringc('host1', 'dark green')
    assert hostcolor('host1', {}, color=False) == u"%-26s" % 'host1'

    # Colorize host string based on stats
    assert hostcolor('host1', {'failures': 0, 'unreachable': 0, 'changed': 0}, color=True) == u"%-37s" % stringc('host1', 'dark green')
    assert hostcolor('host1', {'failures': 0, 'unreachable': 0, 'changed': 1}, color=True) == u"%-37s" % stringc('host1', 'yellow')

# Generated at 2022-06-11 17:52:54.566974
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'black') == u'30'
    assert parsecolor(u'bright black') == u'30;1'
    assert parsecolor(u'red3') == u'31'
    assert parsecolor(u'on_blue') == u'44'
    assert parsecolor(u'dark gray') == u'90'
    assert parsecolor(u'color232') == u'38;5;232'
    assert parsecolor(u'color8') == u'38;5;8'
    assert parsecolor(u'color0') == u'38;5;0'
    assert parsecolor(u'color0') == u'38;5;0'
    assert parsecolor(u'color15') == u'38;5;15'

# Generated at 2022-06-11 17:52:57.175697
# Unit test for function stringc
def test_stringc():
    # Test to see if the bottom of the cube is black.
    assert parsecolor("rgb500") == "38;5;16"
    assert parsecolor("rgb444") == "38;5;232"
# --- end "pretty"

# Generated at 2022-06-11 17:53:06.932923
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "black") == u"\033[30mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "purple") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-11 17:53:09.619589
# Unit test for function stringc
def test_stringc():
    pass
    # TODO: Write unit test

__all__ = ['stringc', 'hostcolor', 'colorize']

# Generated at 2022-06-11 17:53:15.837164
# Unit test for function stringc
def test_stringc():
    assert ANSIBLE_COLOR
    assert stringc('hello world', 'blue') == '\033[34mhello world\033[0m'
    assert stringc('hello world', color='red') == '\033[41mhello world\033[0m'
    return True
# --- end of "pretty" ---

# Cache colorized values for faster display
_HOST_CACHE = {}
_CACHE_SIZE = 10000



# Generated at 2022-06-11 17:53:22.901564
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('testhost', {'failures': 0, 'changed': 0, 'unreachable': 0}, True) == u'%-37s' % stringc('testhost', C.COLOR_OK)
    assert hostcolor('testhost', {'failures': 0, 'changed': 1, 'unreachable': 0}, True) == u'%-37s' % stringc('testhost', C.COLOR_CHANGED)
    assert hostcolor('testhost', {'failures': 1, 'changed': 0, 'unreachable': 0}, True) == u'%-37s' % stringc('testhost', C.COLOR_ERROR)

# Generated at 2022-06-11 17:53:31.724757
# Unit test for function hostcolor
def test_hostcolor():
    # Case 1: Colorize test host with unreachable
    stats = {'changed': 0, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 1}
    host = 'test-host'
    colorized_result = hostcolor(host, stats)
    assert colorized_result == u"\x1b[31m-                test-host\x1b[0m"

    # Case 2: Colorize test host with failure
    stats = {'changed': 0, 'failures': 1, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    host = 'test-host'
    colorized_result = hostcolor(host, stats)
    assert colorized_result == u"\x1b[31m-                test-host\x1b[0m"



# Generated at 2022-06-11 17:53:43.103418
# Unit test for function stringc
def test_stringc():
    for fg in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white',
               'color1', 'color2', 'color3', 'color4', 'color5', 'color6', 'color7', 'color8',
               'color9', 'color10', 'color11', 'color12', 'color13', 'color14', 'color15', 'color16'):
        for bg in ('', 'on_black', 'on_red', 'on_green', 'on_yellow', 'on_blue', 'on_magenta', 'on_cyan', 'on_white'):
            if bg != '':
                color = bg.replace('on_', '') + '+' + fg
            else:
                color = fg

# Generated at 2022-06-11 17:54:26.980997
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor("red") == '31')
    assert(parsecolor("blue") == '34')
    assert(parsecolor("lightblue") == '94')
    assert(parsecolor("brightpurple") == '95')
    assert(parsecolor("yellow") == '33')
    assert(parsecolor("magenta") == '35')
    assert(parsecolor("brightgreen") == '92')
    assert(parsecolor("darkgray") == '90')
    assert(parsecolor("darkred") == '91')
    assert(parsecolor("darkgreen") == '32')
    assert(parsecolor("color7") == '38;5;7')
    assert(parsecolor("rgb123") == '38;5;38')

# Generated at 2022-06-11 17:54:36.968716
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("bold red") == "1;31"
    assert parsecolor("unknown color") == "0"
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("rgb255000") == "38;5;9"
    assert parsecolor("rgb255255255") == "38;5;15"
    assert parsecolor("rgb000255000") == "38;5;10"
    assert parsecolor("rgb000000255") == "38;5;12"
    assert parsecolor("rgb255255000") == "38;5;11"
    assert parsecolor("rgb000255255") == "38;5;13"
    assert parsecolor("rgb255000255") == "38;5;5"

# Generated at 2022-06-11 17:54:42.824051
# Unit test for function hostcolor
def test_hostcolor():
    good = 'localhost                  '
    bad = 'darkstar                   '
    changed = 'titan                      '

    stats = {
           'darkstar': {'unreachable': 1, 'skipped': 0, 'ok': 0, 'changed': 0, 'failures': 0},
           'titan': {'unreachable': 0, 'skipped': 0, 'ok': 1, 'changed': 1, 'failures': 0},
           'localhost': {'unreachable': 0, 'skipped': 0, 'ok': 1, 'changed': 0, 'failures': 0}
           }

    assert good == hostcolor('localhost', stats['localhost'])
    assert changed == hostcolor('titan', stats['titan'])
    assert bad == hostcolor('darkstar', stats['darkstar'])

# Generated at 2022-06-11 17:54:53.278831
# Unit test for function stringc
def test_stringc():
    """
    Test the stringc function
    """

    def test_stringc_call(color, expected_string):
        """
        Test a single stringc call
        """

        output = stringc(u"foo", color)
        assert output == expected_string

    # Test stringc with several different colors
    test_stringc_call(u'black', u'\033[30mfoo\033[0m')
    test_stringc_call(u'red', u'\033[31mfoo\033[0m')
    test_stringc_call(u'green', u'\033[32mfoo\033[0m')
    test_stringc_call(u'yellow', u'\033[33mfoo\033[0m')