

# Generated at 2022-06-11 17:45:08.577265
# Unit test for function parsecolor
def test_parsecolor():
    color_list = ['red','green','yellow','blue','magenta','cyan','white','black','brred','brgreen','bryellow','brblue','brmagenta','brcyan','brwhite']
    for color in color_list:
        if parsecolor(color) != C.COLOR_CODES[color]:
            return False
    if parsecolor('color1') != '38;5;1':
        return False
    if parsecolor('rgb255') != '38;5;231':
        return False
    if parsecolor('gray7') != '38;5;7':
        return False
    return True

# --- end "pretty"

# --- begin plugin code



# Generated at 2022-06-11 17:45:20.110775
# Unit test for function hostcolor
def test_hostcolor():
    # Create fake data for testing
    fakehost = 'fakehost'
    fakestats0 = {'failures': 0, 'unreachable': 0, 'changed': 0}
    fakestats1 = {'failures': 1, 'unreachable': 0, 'changed': 0}
    fakestats2 = {'failures': 0, 'unreachable': 1, 'changed': 0}
    fakestats3 = {'failures': 0, 'unreachable': 0, 'changed': 1}

    # Check that function returns expected values when color is True
    assert hostcolor(fakehost, fakestats0) == "%-37s" % stringc(fakehost, C.COLOR_OK)

# Generated at 2022-06-11 17:45:22.014165
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", "blue") == u"\033[34mhello\033[0m"



# Generated at 2022-06-11 17:45:28.911471
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "white") == u"\033[37mtext\033[0m"
    assert stringc("text", "color1") == u"\033[38;5;1mtext\033[0m"
    assert stringc("text", "color1", wrap_nonvisible_chars=True) == u"\001\033[38;5;1m\002text\001\033[0m\002"



# Generated at 2022-06-11 17:45:40.651445
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    expected_color_ok = u'%-37s' % stringc('test_ok', C.COLOR_OK)
    assert hostcolor('test_ok', stats, True) == expected_color_ok

    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    expected_color_error = u'%-37s' % stringc('test_error', C.COLOR_ERROR)
    assert hostcolor('test_error', stats, True) == expected_color_error

    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor('test_error', stats, True) == expected_color_error


# Generated at 2022-06-11 17:45:50.434597
# Unit test for function hostcolor
def test_hostcolor():
    test_color = hostcolor('foo', dict(ok=1, changed=0, unreachable=0, failures=0), color=True)
    assert test_color == stringc('foo', C.COLOR_OK) + u'                        '
    test_color = hostcolor('foo', dict(ok=1, changed=1, unreachable=0, failures=0), color=True)
    assert test_color == stringc('foo', C.COLOR_CHANGED) + u'                        '
    test_color = hostcolor('foo', dict(ok=1, changed=0, unreachable=1, failures=0), color=True)
    assert test_color == stringc('foo', C.COLOR_ERROR) + u'                        '

# Generated at 2022-06-11 17:46:01.211763
# Unit test for function stringc
def test_stringc():
    test_passed = True

# Generated at 2022-06-11 17:46:08.040787
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == '34'
    assert parsecolor("color2") == '38;5;2'
    assert parsecolor("rgb123") == '38;5;14'
    assert parsecolor("gray255") == '38;5;255'
    assert parsecolor("yellow") == '33'
    assert parsecolor("x") == '30'

# --- end "pretty"

# Generated at 2022-06-11 17:46:13.656930
# Unit test for function hostcolor
def test_hostcolor():
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    assert "ok" in hostcolor("ok", stats, True)
    stats['changed'] = 1
    assert "changed" in hostcolor("changed", stats, True)
    stats['unreachable'] = 1
    assert "unreachable" in hostcolor("unreachable", stats, True)
    stats['failures'] = 1
    assert "failed" in hostcolor("failed", stats, True)
    assert "ok" in hostcolor("ok", stats, False)

# --- end of "pretty"



# Generated at 2022-06-11 17:46:23.641469
# Unit test for function stringc
def test_stringc():
    class tc:
        ljust = 30
    text = u"Just some text"

# Generated at 2022-06-11 17:46:29.815900
# Unit test for function stringc
def test_stringc():
    assert stringc('blah', 'blue') == u'\033[34mblah\033[0m'


# --- end "pretty"

# Generated at 2022-06-11 17:46:35.249874
# Unit test for function stringc

# Generated at 2022-06-11 17:46:46.078942
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor(u"localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31;01mlocalhost\x1b[0m        "
    assert hostcolor(u"localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31;01mlocalhost\x1b[0m        "
    assert hostcolor(u"localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33;01mlocalhost\x1b[0m        "
    # Test preservation of the string length

# Generated at 2022-06-11 17:46:47.712406
# Unit test for function hostcolor
def test_hostcolor():
    # TODO: Unit test
    return True

# --- end "pretty"

# Generated at 2022-06-11 17:46:56.736953
# Unit test for function stringc
def test_stringc():
    """ Test function stringc """
    assert stringc('hello', 'green') == u'\033[32mhello\033[0m'
    assert stringc('hello', 'red') == u'\033[31mhello\033[0m'
    assert stringc('hello', 'blue') == u'\033[34mhello\033[0m'
    assert stringc('hello', 'green', wrap_nonvisible_chars=True) == u'\001\033[32m\002hello\001\033[0m\002'
    assert stringc('hello', 'red', wrap_nonvisible_chars=True) == u'\001\033[31m\002hello\001\033[0m\002'

# Generated at 2022-06-11 17:47:05.010968
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.constants import DEFAULT_HOST_LIST

    # No color
    assert hostcolor('localhost', {
        'failures': 2, 'changed': 2, 'ok': 3, 'skipped': 2, 'unreachable': 0,
    }) == "%-37s" % 'localhost'

    # Color
    assert hostcolor('localhost', {
        'failures': 2, 'changed': 2, 'ok': 3, 'skipped': 2, 'unreachable': 0,
    }, True) == stringc('localhost', C.COLOR_ERROR)

    # No color
    assert hostcolor('localhost', {
        'failures': 0, 'changed': 2, 'ok': 3, 'skipped': 2, 'unreachable': 0,
    }) == "%-37s" % 'localhost'

    # Color

# Generated at 2022-06-11 17:47:16.196889
# Unit test for function hostcolor
def test_hostcolor():
    ansible_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    if hostcolor('localhost', dict(failures=1)) != u'\x1b[31m%-37s\x1b[0m':
        raise AssertionError("hostcolor don't produce red when it should")
    if hostcolor('localhost', dict(changed=1)) != u'\x1b[33m%-37s\x1b[0m':
        raise AssertionError("hostcolor don't produce yellow when it should")
    if hostcolor('localhost', dict()) != u'\x1b[32m%-37s\x1b[0m':
        raise AssertionError("hostcolor don't produce green when it should")
    ANSIBLE_COLOR = ansible_color



# Generated at 2022-06-11 17:47:23.089615
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'host.example.com', dict(failures=0, unreachable=0, changed=0)) == 'host.example.com          '
    assert hostcolor(u'host.example.com', dict(failures=1, unreachable=0, changed=0)) == 'host.example.com          '
    assert hostcolor(u'host.example.com', dict(failures=0, unreachable=1, changed=0)) == 'host.example.com          '
    assert hostcolor(u'host.example.com', dict(failures=0, unreachable=0, changed=1)) == 'host.example.com          '
    assert hostcolor(u'host.example.com', dict(failures=1, unreachable=1, changed=0)) == 'host.example.com          '
    assert hostcolor

# Generated at 2022-06-11 17:47:32.405264
# Unit test for function hostcolor
def test_hostcolor():
    from ansible import color
    assert color.hostcolor(u"host", {'failures': 1, 'changed': 0, 'unreachable': 0, 'ok': 1}, True) == u'\x1b[31mhost                 \x1b[0m'
    assert color.hostcolor(u"host", {'failures': 0, 'changed': 1, 'unreachable': 0, 'ok': 1}, True) == u'\x1b[33mhost                 \x1b[0m'
    assert color.hostcolor(u"host", {'failures': 0, 'changed': 0, 'unreachable': 1, 'ok': 1}, True) == u'\x1b[31mhost                 \x1b[0m'

# Generated at 2022-06-11 17:47:45.149942
# Unit test for function hostcolor
def test_hostcolor():
    import json

    def check_color(x, y, color):
        if not y:
            y = ''
        setattr(check_color, 'ok', True)
        print(x)
        print(y + '\033[0m')
        if x != y + '\033[0m':
            setattr(check_color, 'ok', False)

    # Test success
    check_color(hostcolor('host1', json.loads(
        '{ "ok": 1, "changed": 0, "failures": 0 }')), '\033[32mhost1',
        C.COLOR_OK)

    # Test failure

# Generated at 2022-06-11 17:47:55.925589
# Unit test for function colorize
def test_colorize():
    lead = "foo"
    num = 42
    color = "blue"
    assert u"foo=42  " == colorize(lead, num, color)

# --- end "pretty" ---



# Generated at 2022-06-11 17:48:06.259334
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('testhost', {'failures': 0,
                                  'unreachable': 0,
                                  'changed': 0}, True) == u"%-37s" % stringc('testhost', C.COLOR_OK)

    assert hostcolor('testhost', {'failures': 1,
                                  'unreachable': 0,
                                  'changed': 0}, True) == u"%-37s" % stringc('testhost', C.COLOR_ERROR)

    assert hostcolor('testhost', {'failures': 1,
                                  'unreachable': 0,
                                  'changed': 1}, True) == u"%-37s" % stringc('testhost', C.COLOR_ERROR)


# Generated at 2022-06-11 17:48:13.132951
# Unit test for function hostcolor
def test_hostcolor():
    ''' unit tests for function hostcolor '''

    # two test classes to make testing easier
    class Args:
        host = ''
        stats = {'failures': 0, 'unreachable': 0, 'changed': 0}

    class Returned:
        color = ''


# Generated at 2022-06-11 17:48:19.824450
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'changed': 1, 'failures': 0, 'ok': 3, 'skipped': 0, 'unreachable': 0}) == 'localhost'
    assert hostcolor('localhost', {'changed': 0, 'failures': 1, 'ok': 3, 'skipped': 0, 'unreachable': 0}) == 'localhost'
    assert hostcolor('localhost', {'changed': 0, 'failures': 0, 'ok': 3, 'skipped': 0, 'unreachable': 1}) == 'localhost'



# Generated at 2022-06-11 17:48:31.872137
# Unit test for function parsecolor
def test_parsecolor():
    # Test default color codes
    assert parsecolor('blue') == u'34'
    assert parsecolor('blue', wrap_nonvisible_chars=True) == u'\001\033[34m\002'
    assert parsecolor('bright purple') == u'35;1'
    assert parsecolor('bright purple', wrap_nonvisible_chars=True) == u'\001\033[35;1m\002'
    assert parsecolor('red') == u'31'
    assert parsecolor('on_red') == u'41'
    # Test explicit color codes
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color254') == u'38;5;254'
    assert parsecolor('color254', wrap_nonvisible_chars=True)

# Generated at 2022-06-11 17:48:38.931635
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert stringc("colorized", "blue") == "\033[34mcolorized\033[0m"
        assert stringc("colorized", "color1") == "\033[38;5;1mcolorized\033[0m"
        assert stringc("colorized", "color99") == "\033[38;5;99mcolorized\033[0m"
        assert stringc("colorized", "color256") == "\033[38;5;255mcolorized\033[0m"
        assert stringc("colorized", "gray0") == "\033[38;5;232mcolorized\033[0m"
        assert stringc("colorized", "gray1") == "\033[38;5;233mcolorized\033[0m"

# Generated at 2022-06-11 17:48:43.967989
# Unit test for function hostcolor
def test_hostcolor():
    for color in (True, False):
        for host in ('host1', 'host2'):
            for stats in ({'failures': 1}, {'unreachable': 1}, {'changed': 1}, {'failures': 0}):
                print(hostcolor(host, stats, color))


if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-11 17:48:55.009566
# Unit test for function stringc
def test_stringc():
    assert("\033[31mhello\033[0m" == stringc("hello", "RED"))
    assert("\033[31mhello\033[0m" == stringc("hello", "red"))
    assert("\033[32mhello\033[0m" == stringc("hello", "green"))
    assert("\033[33mhello\033[0m" == stringc("hello", "yellow"))
    assert("\033[34mhello\033[0m" == stringc("hello", "blue"))
    assert("\033[35mhello\033[0m" == stringc("hello", "magenta"))
    assert("\033[36mhello\033[0m" == stringc("hello", "cyan"))

# Generated at 2022-06-11 17:49:06.506883
# Unit test for function hostcolor
def test_hostcolor():
    # Enable color
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    host = "localhost"
    stats1 = dict(failed=0, ok=1, changed=0, unreachable=0)
    stats2 = dict(failed=1, ok=0, changed=0, unreachable=0)
    stats3 = dict(failed=0, ok=0, changed=1, unreachable=0)
    stats4 = dict(failed=0, ok=0, changed=0, unreachable=1)

    assert hostcolor(host, stats1, True) == u"\x1b[0;32;m%-26s\x1b[0m" % host

# Generated at 2022-06-11 17:49:13.855184
# Unit test for function stringc
def test_stringc():
    print(stringc('hello', 'black'))
    print(stringc('hello', 'dark gray'))
    print(stringc('hello', 'red'))
    print(stringc('hello', 'light red'))
    print(stringc('hello', 'green'))
    print(stringc('hello', 'light green'))
    print(stringc('hello', 'brown'))
    print(stringc('hello', 'yellow'))
    print(stringc('hello', 'blue'))
    print(stringc('hello', 'light blue'))
    print(stringc('hello', 'purple'))
    print(stringc('hello', 'light purple'))
    print(stringc('hello', 'cyan'))
    print(stringc('hello', 'light cyan'))

# Generated at 2022-06-11 17:49:38.019472
# Unit test for function hostcolor
def test_hostcolor():
    hc = hostcolor('foo', None, False)
    assert hc == '%-26s' % 'foo'
    hc = hostcolor('foo', None)
    assert hc == '%-37s' % 'foo'
    hc = hostcolor('foo', {'failures': 1, 'unreachable': 0, 'changed': 0}, False)
    assert hc == '%-26s' % 'foo'
    hc = hostcolor('foo', {'failures': 1, 'unreachable': 0, 'changed': 0})
    assert hc == '%-37s' % stringc('foo', C.COLOR_ERROR)
    hc = hostcolor('foo', {'failures': 0, 'unreachable': 1, 'changed': 0}, False)
    assert hc == '%-26s' % 'foo'

# Generated at 2022-06-11 17:49:47.462935
# Unit test for function hostcolor
def test_hostcolor():
    ''' hostcolor should colorize strings or not based on ANSIBLE_COLOR '''
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert hostcolor('foo.example.com', {}, True)   == u"%-37s" % stringc('foo.example.com', C.COLOR_OK)
    assert hostcolor('foo.example.com', {'changed' : 3}, True) == u"%-37s" % stringc('foo.example.com', C.COLOR_CHANGED)
    assert hostcolor('foo.example.com', {'failed' : 3}, True) == u"%-37s" % stringc('foo.example.com', C.COLOR_ERROR)
    assert hostcolor('foo.example.com', {}, False) == u"%-26s" % 'foo.example.com'


# Generated at 2022-06-11 17:49:58.914905
# Unit test for function hostcolor
def test_hostcolor():
    from ansible import color as clr
    from ansible import constants as C
    if C.ANSIBLE_NOCOLOR:
        assert clr.hostcolor('host', {'failures': 10}) == u"%-37s" % 'host'
    else:
        assert clr.hostcolor('host', {'failures': 10}).encode('UTF-8') == u"%-37s" % stringc('host', C.COLOR_ERROR).encode('UTF-8')
        assert clr.hostcolor('host', {'changed': 10}).encode('UTF-8') == u"%-37s" % stringc('host', C.COLOR_CHANGED).encode('UTF-8')

# Generated at 2022-06-11 17:50:11.534748
# Unit test for function stringc
def test_stringc():
    import os
    # Test command line options
    os.environ['ANSIBLE_FORCE_COLOR'] = 'true'
    assert ANSIBLE_COLOR == True
    os.environ['ANSIBLE_NOCOLOR'] = 'true'
    assert ANSIBLE_COLOR == True
    os.environ['ANSIBLE_FORCE_COLOR'] = 'false'
    assert ANSIBLE_COLOR == False
    del os.environ['ANSIBLE_NOCOLOR']
    assert ANSIBLE_COLOR == False

    assert stringc("foo", "black") == u"\033[30mfoo\033[0m"
    assert stringc("foo", "white", wrap_nonvisible_chars=True) == u"\001\033[38;5;15m\002foo\001\033[0m\002"
   

# Generated at 2022-06-11 17:50:16.302415
# Unit test for function colorize
def test_colorize():
    field = 'test'
    num = '1'
    # 1. Test that the text is the same when color is disabled
    assert stringc(field + num, color='black', wrap_nonvisible_chars=True) == field + num

    # 2. Test that the disabled color is the same as the default color
    assert stringc(field + num, color=None) == field + num
    assert stringc(field + num, color=False) == field + num

    # 3. Test that the same text is returned if color is invalid
    assert stringc(field + num, color='red') == field + num
    assert stringc(field + num, color='invalid') == field + num

    # 4. Test that color is the same as the expected color

# Generated at 2022-06-11 17:50:24.569741
# Unit test for function hostcolor
def test_hostcolor():
    host = 'www.example.com'
    stats = {'changed': 0, 'failures': 0, 'ok': 5, 'skipped': 0, 'unreachable': 0}

    assert(hostcolor(host, stats, color=False) == u"%-26s" % host)

    assert(hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_OK))

    stats = {'changed': 1, 'failures': 0, 'ok': 4, 'skipped': 0, 'unreachable': 0}

    assert(hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_CHANGED))


# Generated at 2022-06-11 17:50:33.563971
# Unit test for function stringc
def test_stringc():
    """
    Test for function stringc
    """
    # Color not specified
    test = stringc('test', 'default')
    assert type(test) is unicode

    # Color not specified
    test = stringc('test', None)
    assert type(test) is unicode

    # Color not specified
    test = stringc('test', 12345)
    assert type(test) is unicode

    # Color not supported
    test = stringc('test', 'FAIL')
    assert type(test) is unicode

    # Color valid
    test = stringc('test', 'red')
    assert type(test) is unicode

    # Color valid
    test = stringc('test', 'rgb123')
    assert type(test) is unicode

    # Color valid
    test = stringc('test', 'gray1')


# Generated at 2022-06-11 17:50:42.222094
# Unit test for function stringc
def test_stringc():
    assert u"\n".join(stringc("test", "blue").split("\033")) == "test" # test that we actually get escapes stripped
    assert u"\n".join(stringc("test", "blue").split("[0m")) == "test" # test that we actually get escapes stripped
    assert u"\n".join(stringc("test", "blue").split("[0;34m")) == "test" # test that we actually get escapes stripped

    # test different color codes
    assert stringc("test", "blue") == "test" # test that we actually get escapes stripped
    assert stringc("test", "red") == "test" # test that we actually get escapes stripped
    assert stringc("test", "green") == "test" # test that we actually get escapes stripped
    assert stringc("test", "black") == "test"

# Generated at 2022-06-11 17:50:52.408935
# Unit test for function stringc
def test_stringc():
    import sys
    import tempfile
    import subprocess
    from subprocess import Popen, PIPE

    def check_ansible_color_setting(expected_ansible_color):
        _, tmpfile = tempfile.mkstemp(prefix="test_pretty_", suffix=".py")

# Generated at 2022-06-11 17:51:03.718848
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo.example.com', dict(failures=0, unreachable=0, changed=0), True) == '\x1b[32mfoo.example.com\x1b[0m      '
    assert hostcolor('foo.example.com', dict(failures=0, unreachable=0, changed=1), True) == '\x1b[33mfoo.example.com\x1b[0m      '
    assert hostcolor('foo.example.com', dict(failures=1, unreachable=0, changed=0), True) == '\x1b[31mfoo.example.com\x1b[0m      '

# Generated at 2022-06-11 17:51:25.380430
# Unit test for function colorize
def test_colorize():
    assert 'failures=1   ' == colorize('failures', 1, C.COLOR_ERROR)
    assert 'failures=0   ' == colorize('failures', 0, C.COLOR_ERROR)
    assert 'changed=1    ' == colorize('changed', 1, C.COLOR_CHANGED)
    assert 'changed=0    ' == colorize('changed', 0, C.COLOR_CHANGED)
    assert 'ok=1         ' == colorize('ok', 1, C.COLOR_OK)
    assert 'ok=0         ' == colorize('ok', 0, C.COLOR_OK)

# Generated at 2022-06-11 17:51:29.907379
# Unit test for function colorize
def test_colorize():
    for color in ['red', 'green', 'yellow', 'blue', 'cyan', 'magenta', 'black', 'white']:
        print(u"%s colorize(*) = * color" % color)
        print(u"%s" % colorize(u"*", u"*", color))
        print(u"")


# Generated at 2022-06-11 17:51:41.951092
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'localhost', {'changed': 0, 'unreachable': 0, 'failures': 0}, True) == u"%-37s" % '\033[0;32mlocalhost\033[0m'
    assert hostcolor(u'localhost', {'changed': 1, 'unreachable': 0, 'failures': 0}, True) == u"%-37s" % '\033[0;33mlocalhost\033[0m'
    assert hostcolor(u'localhost', {'changed': 0, 'unreachable': 0, 'failures': 1}, True) == u"%-37s" % '\033[0;31mlocalhost\033[0m'

# Generated at 2022-06-11 17:51:50.459405
# Unit test for function stringc
def test_stringc():
    """Test stringc()."""
    assert stringc("123", "red") == u"\033[31m123\033[0m"
    assert stringc("123", "green") == u"\033[32m123\033[0m"
    assert stringc("123", "yellow") == u"\033[33m123\033[0m"
    assert stringc("123", "blue") == u"\033[34m123\033[0m"
    assert stringc("123", "magenta") == u"\033[35m123\033[0m"
    assert stringc("123", "cyan") == u"\033[36m123\033[0m"
    assert stringc("123", "white") == u"\033[37m123\033[0m"

# Generated at 2022-06-11 17:52:00.785203
# Unit test for function stringc
def test_stringc():
        assert stringc('hello', 'green') == '\033[32mhello\033[0m'
        assert stringc('hello', 'black') == '\033[30mhello\033[0m'
        assert stringc('hello', 'blue') == '\033[34mhello\033[0m'
        assert stringc('hello', 'red') == '\033[31mhello\033[0m'
        assert stringc('hello', 'magenta') == '\033[35mhello\033[0m'
        assert stringc('hello', 'yellow') == '\033[33mhello\033[0m'
        assert stringc('hello', 'cyan') == '\033[36mhello\033[0m'

# Generated at 2022-06-11 17:52:06.119340
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(ok=10, changed=5, unreachable=1, failures=1, skipped=1)
    assert hostcolor('localhost', stats, color=False) == '%-26s' % 'localhost'
    assert hostcolor('localhost', stats, color=True) == stringc(u"%-26s" % 'localhost', C.COLOR_CHANGED)

    stats = dict(ok=10, changed=0, unreachable=1, failures=2, skipped=0)
    assert hostcolor('localhost', stats, color=False) == '%-26s' % 'localhost'
    assert hostcolor('localhost', stats, color=True) == stringc(u"%-26s" % 'localhost', C.COLOR_ERROR)

    stats = dict(ok=10, changed=0, unreachable=0, failures=0, skipped=0)


# Generated at 2022-06-11 17:52:16.306348
# Unit test for function stringc
def test_stringc():
    assert stringc("This is a blue string.", "blue") == "\033[34mThis is a blue string.\033[0m"
    assert stringc("This is a red string.", "red") == "\033[31mThis is a red string.\033[0m"
    assert stringc("This is a color235 string.", "color235") == "\033[38;5;235mThis is a color235 string.\033[0m"
    assert stringc("This is a rgb333 string.", "rgb333") == "\033[38;5;53mThis is a rgb333 string.\033[0m"
    assert stringc("This is a gray7 string.", "gray7") == "\033[38;5;239mThis is a gray7 string.\033[0m"


# Generated at 2022-06-11 17:52:26.699943
# Unit test for function hostcolor
def test_hostcolor():
    host = "test_host"
    # stats for UNREACHABLE
    stats1 = {
        'changed': 0,
        'failures': 0,
        'ok': 6,
        'skipped': 0,
        'unreachable': 2
    }
    # stats for FAILED
    stats2 = {
        'changed': 0,
        'failures': 2,
        'ok': 4,
        'skipped': 0,
        'unreachable': 0
    }
    # stats for OK
    stats3 = {
        'changed': 0,
        'failures': 0,
        'ok': 6,
        'skipped': 0,
        'unreachable': 0
    }
    # stats for CHANGED

# Generated at 2022-06-11 17:52:35.284852
# Unit test for function hostcolor
def test_hostcolor():

    # Create different stats and host color options
    tests = [
        {
            'failures': 0,
            'unreachable': 0,
            'changed': 0,
            'color': True
        },
        {
            'failures': 0,
            'unreachable': 0,
            'changed': 0,
            'color': False
        },
        {
            'failures': 0,
            'unreachable': 0,
            'changed': 1,
            'color': True
        },
        {
            'failures': 1,
            'unreachable': 0,
            'changed': 0,
            'color': True
        },
        {
            'failures': 0,
            'unreachable': 1,
            'changed': 0,
            'color': True
        },
    ]

   

# Generated at 2022-06-11 17:52:42.465892
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'blue', False) == u"\033[0;34mtest\033[0m", "stringc failed to return blue test"
    assert stringc('test', 'blue', True) == u"\001\033[0;34m\002test\001\033[0m\002", "stringc failed to return blue test"
    assert stringc('test', 'badcolor') == u"\033[0;39mtest\033[0m", "stringc failed to return white test"
    assert stringc('test', 'color11') == u"\033[38;5;11mtest\033[0m", "stringc failed to return color11 test"

# Generated at 2022-06-11 17:53:23.369919
# Unit test for function hostcolor
def test_hostcolor():
    colors = {'hostname': 'default', 'hostname_fail': C.COLOR_ERROR, 'hostname_changed': C.COLOR_CHANGED}
    stats = {'changed': 1, 'failures': 1, 'unreachable': 1} #changed hosts: ok, failures hosts: failures, unreachable hosts: failures
    for host_name, color in colors.items():
        assert hostcolor(host_name, stats, color=True) == u"%-37s" % stringc(host_name, color)
        assert hostcolor(host_name, stats, color=False) == u"%-26s" % host_name

# --- end "pretty" ---

# --- begin "terminal" ---


# Generated at 2022-06-11 17:53:31.909264
# Unit test for function stringc
def test_stringc():
    """Test stringc."""
    string = 'brian'
    assert stringc(string, 'red') == u"\033[31mbrian\033[0m"
    assert stringc(string, 'green') == u"\033[32mbrian\033[0m"
    assert stringc(string, 'yellow') == u"\033[33mbrian\033[0m"
    assert stringc(string, 'blue') == u"\033[34mbrian\033[0m"
    assert stringc(string, 'magenta') == u"\033[35mbrian\033[0m"
    assert stringc(string, 'cyan') == u"\033[36mbrian\033[0m"
    assert stringc(string, 'white') == u"\033[37mbrian\033[0m"

# Generated at 2022-06-11 17:53:43.311620
# Unit test for function stringc
def test_stringc():
    if stringc("hello", C.COLOR_ERROR) != "\033[31mhello\033[0m":
        raise Exception("Test 1 fails")
    if stringc("hello", "color3") != "\033[38;5;11mhello\033[0m":
        raise Exception("Test 2 fails")
    if stringc("hello", "color54") != "\033[38;5;63mhello\033[0m":
        raise Exception("Test 3 fails")
    if stringc("hello", "rgb255") != "\033[38;5;231mhello\033[0m":
        raise Exception("Test 4 fails")
    if stringc("hello", "rgb000") != "\033[38;5;16mhello\033[0m":
        raise Exception("Test 5 fails")

# Generated at 2022-06-11 17:53:51.171927
# Unit test for function hostcolor
def test_hostcolor():
    """Unit test for function hostcolor."""
    stats = {
        'unreachable': 0,
        'skipped': 0,
        'changed': 0,
        'failures': 0,
    }

    assert hostcolor('localhost', stats) == "localhost                         "
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == "localhost       "
    stats['changed'] = 0
    stats['failures'] = 1
    assert hostcolor('localhost', stats) == "localhost       "


# --- end "pretty"

# --- begin "cli"



# Generated at 2022-06-11 17:53:59.844335
# Unit test for function stringc
def test_stringc():
    print(stringc(u"Hello, World!", u"blue"))
    for color in [u"black", u"blue", u"cyan", u"green", u"magenta", u"red", u"white", u"yellow"]:
        print(stringc(u"Hello, World!", u"color%s" % color))
    for color in [u"0", u"255"]:
        print(stringc(u"Hello, World!", u"gray%s" % color))
    for red in [u"0", u"5"]:
        for green in [u"0", u"5"]:
            for blue in [u"0", u"5"]:
                print(stringc(u"Hello, World!", u"rgb%s%s%s" % (red, green, blue)))
# --- end "pretty

# Generated at 2022-06-11 17:54:08.633675
# Unit test for function stringc
def test_stringc():
    print(stringc('This is a test', 'black', wrap_nonvisible_chars=False))
    print(stringc('This is a test', 'red', wrap_nonvisible_chars=False))
    print(stringc('This is a test', 'green', wrap_nonvisible_chars=False))
    print(stringc('This is a test', 'yellow', wrap_nonvisible_chars=False))
    print(stringc('This is a test', 'blue', wrap_nonvisible_chars=False))
    print(stringc('This is a test', 'magenta', wrap_nonvisible_chars=False))
    print(stringc('This is a test', 'cyan', wrap_nonvisible_chars=False))

# Generated at 2022-06-11 17:54:20.707044
# Unit test for function colorize
def test_colorize():
    assert colorize('a', 0, 'green') == u'a=0   '
    assert colorize('a', 1, 'green')  == u'a=1   '
    assert colorize('a', 0, 'red') == u'a=0   '
    assert colorize('a', 1, 'red')  == u'a=1   '

    assert colorize('a', 0, None) == u'a=0   '
    assert colorize('a', 1, None)  == u'a=1   '
    assert colorize('a', 0, None) == u'a=0   '
    assert colorize('a', 1, None)  == u'a=1   '

    C.ANSIBLE_NOCOLOR = True
    ANSIBLE_COLOR = False

# Generated at 2022-06-11 17:54:32.069846
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("127.0.0.1", dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc("127.0.0.1", C.COLOR_ERROR)
    assert hostcolor("127.0.0.1", dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc("127.0.0.1", C.COLOR_ERROR)
    assert hostcolor("127.0.0.1", dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc("127.0.0.1", C.COLOR_CHANGED)

# Generated at 2022-06-11 17:54:37.539737
# Unit test for function hostcolor
def test_hostcolor():
    stats = {
        'failed': 0,
        'ok': 6,
        'dark': 0,
        'changed': 0,
        'skipped': 1,
        'unreachable': 0,
        'failures': 0,
    }

    # Default color=True
    color = hostcolor('localhost', stats)
    assert color == u"%-37s" % stringc('localhost', C.COLOR_OK)

# --- end "pretty"



# Generated at 2022-06-11 17:54:48.348678
# Unit test for function stringc
def test_stringc():
    """Test function stringc"""
    assert stringc(u"text", u"blue") == u'\033[0;34mtext\033[0m'
    assert stringc(u"text", u"color1") == u'\033[0;38;5;1mtext\033[0m'
    assert stringc(u"text", u"rgb255") == u'\033[0;38;5;15mtext\033[0m'
    assert stringc(u"text", u"rgb100") == u'\033[0;38;5;13mtext\033[0m'
    assert stringc(u"text", u"rgb010") == u'\033[0;38;5;31mtext\033[0m'