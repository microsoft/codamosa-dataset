

# Generated at 2022-06-11 17:45:10.149671
# Unit test for function stringc
def test_stringc():
    print("TEST: stringc")
    results = ["\n",
               stringc("hello", "red"),
               stringc("hello\nworld", "red"),
               stringc("hello", "red", wrap_nonvisible_chars=True)]

    expected = ["\n",
                u"\033[31mhello\033[0m",
                u"\033[31mhello\033[0m\n\033[31mworld\033[0m",
                u"\001\033[31m\002hello\001\033[0m\002"]

    rc = 0
    for i in range(0, len(results)):
        result = results[i]
        expected_result = expected[i]

# Generated at 2022-06-11 17:45:21.131965
# Unit test for function hostcolor
def test_hostcolor():
    """Unit test for function hostcolor"""
    class Options(object):
        """Placeholder for options"""
        pass

    class RunnerOptions(object):
        """Placeholder for runner options"""
        def __init__(self):
            self.timeout = 10
            self.connection = 'smart'
            self.module_path = None
            self.forks = 5
            self.remote_user = 'root'
            self.ask_pass = False
            self.private_key_file = None
            self.ssh_common_args = None
            self.ssh_extra_args = None
            self.sftp_extra_args = None
            self.scp_extra_args = None
            self.become = False
            self.become_method = 'sudo'
            self.become_user = 'root'
            self

# Generated at 2022-06-11 17:45:33.604653
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('default') == u'39'
    assert parsecolor('darkwhite') == u'37'
    assert parsecolor('darkyellow') == u'33'
    assert parsecolor('lightred') == u'91'
    assert parsecolor('lightgreen') == u'92'
    assert parsecolor('lightyellow') == u

# Generated at 2022-06-11 17:45:43.391172
# Unit test for function stringc
def test_stringc():
    """Unit test for stringc"""

    print("Testing basic ANSIBLE_COLOR=True output ...")
    print("===== Expect =====")

# Generated at 2022-06-11 17:45:51.028959
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 0, 'yellow') == 'foo=0   '
    assert colorize('foo', 255, 'black') == 'foo=255 '
    assert colorize('foo', 255, 'yellow') == 'foo=255 '
    assert colorize('foo', 256, 'black') == 'foo=256 '
    assert colorize('foo', 256, 'yellow') == 'foo=256 '


# Use terminal colors to display errors in color
green = C.COLOR_OK
brightred = C.COLOR_ERROR

# --- end pretty ---



# Generated at 2022-06-11 17:46:01.509963
# Unit test for function hostcolor
def test_hostcolor():
    def hc(host, stats, color=True):
        return hostcolor(host, stats, color)

    assert hc("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hc("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;32mlocalhost\x1b[0m         "
    assert hc("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m         "
    assert hc("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m         "

# Generated at 2022-06-11 17:46:11.008582
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test for function parsecolor."""
    assert parsecolor('normal') == u'39'
    assert parsecolor('bright gray') == u'37;1'
    assert parsecolor('red') == u'31'
    assert parsecolor('color5') == u'38;5;5'
    assert parsecolor('rgb555') == u'38;5;123'
    assert parsecolor('gray2') == u'38;5;234'
    assert parsecolor('color15') == u'38;5;15'
    assert parsecolor('rgb355') == u'38;5;93'
    assert parsecolor('gray3') == u'38;5;235'

# Generated at 2022-06-11 17:46:22.306651
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        return
    # I know, I should use unittest.TestCase for this
    def assertEquals(x, y):
        assert x == y
    from ansible.compat.tests.mock import patch
    from ansible.compat.six import StringIO
    from ansible.utils.color import ANSIBLE_COLOR, colorize
    old_stdout = sys.stdout

# Generated at 2022-06-11 17:46:31.218417
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('cyan') == u'38;5;14'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('white') == u'38;5;15'
    assert parsecolor('rgb255255255') == u'38;5;231'
    assert parsecolor('rgb000255255') == u'38;5;14'

# Generated at 2022-06-11 17:46:41.358627
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u"\033[34mfoo\033[0m"
    assert stringc('foo', 'cyan') == u"\033[36mfoo\033[0m"
    assert stringc('foo', 'bright purple') == u"\033[95mfoo\033[0m"
    assert stringc('foo', 'bright magenta') == u"\033[95mfoo\033[0m"
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'bright red') == u"\033[91mfoo\033[0m"
    assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"

# Generated at 2022-06-11 17:46:55.864956
# Unit test for function stringc
def test_stringc():
    assert stringc('blue', 'blue') == u'\033[34mblue\033[0m'
    assert stringc('bold_blue', 'bold_blue') == u'\033[94mbold_blue\033[0m'
    assert stringc('bold_bright_cyan', 'bold_bright_cyan') == u'\033[96mbold_bright_cyan\033[0m'
    assert stringc('bright_black', 'bright_black') == u'\033[90mbright_black\033[0m'
    assert stringc('bright_black', 'brightblack') == u'\033[90mbright_black\033[0m'
    assert stringc('bright_blue', 'bright_blue') == u'\033[94mbright_blue\033[0m'
    assert stringc

# Generated at 2022-06-11 17:47:04.721184
# Unit test for function colorize
def test_colorize():
    from ansible.compat.six import StringIO

    captured = StringIO()
    sys.stdout = captured

    # Call the function
    colorize(u"ok", 34, C.COLOR_OK)
    colorize(u"changed", 3, C.COLOR_CHANGED)
    colorize(u"unreachable", 2, C.COLOR_UNREACHABLE)
    colorize(u"failed", 1, C.COLOR_ERROR)
    colorize(u"skipped", 0, C.COLOR_SKIP)

    # restore stdout
    sys.stdout = sys.__stdout__
    lines = captured.getvalue().rstrip().splitlines()
    captured.close()

    # verify the captured output
    assert len(lines) == 5
    assert lines[0] == u'ok=34  '


# Generated at 2022-06-11 17:47:13.123795
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('C:\\Foo\\Bar\\Baz', 'blue') == u'\033[34mC:\\Foo\\Bar\\Baz\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'magenta', wrap_nonvisible_chars=True) == u'\001\033[35m\002foo\001\033[0m\002'

# Generated at 2022-06-11 17:47:21.586288
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.callbacks import AggregateStats
    stats = AggregateStats()
    stats.compute(dict(ok=dict(changed=4), failed=dict(failed=1, unreachable=1)))

    # The expected ouput depends on the ANSIBLE_COLOR, ANSIBLE_NOCOLOR and
    # ANSIBLE_FORCE_COLOR environment variables. Here, we establish the
    # expected output depending on the context.
    if ANSIBLE_COLOR:
        expected_ok = stringc(u'ok', C.COLOR_OK)
        expected_changed = stringc(u'changed', C.COLOR_CHANGED)
        expected_failed = stringc(u'failed', C.COLOR_ERROR)
    else:
        expected_ok = u'ok'
        expected_changed = u'changed'
        expected

# Generated at 2022-06-11 17:47:32.020035
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    for color in ['bold', 'black', 'dark red', 'green', 'yellow', 'blue',
                  'magenta', 'cyan', 'white']:
        print("\nstringc(%s):" % color)
        print(stringc("Normal text", color))
        print(stringc("Underlined text", color + ",underline"))
        print(stringc("Reversed text", color + ",reverse"))
        print(stringc("Bold text", color + ",bold"))
        print(stringc("Blinking text", color + ",blink"))

    print("\nstringc(rgb0):")
    print(stringc("Normal text", "rgb0"))
    print(stringc("Underlined text", "rgb0,underline"))

# Generated at 2022-06-11 17:47:44.969363
# Unit test for function stringc
def test_stringc():
    # Normal Color test
    colorlist = [
        'black',
        'dark_gray',
        'blue',
        'light_blue',
        'green',
        'light_green',
        'cyan',
        'light_cyan',
        'red',
        'light_red',
        'purple',
        'light_purple',
        'brown',
        'yellow',
        'light_gray',
        'white'
    ]

    for color in colorlist:
        text = stringc("test", color)
        assert text == "\033[%smtest\033[0m" % C.COLOR_CODES[color], text

    # Color number test
    text = stringc("test", 'color16')

# Generated at 2022-06-11 17:47:55.572182
# Unit test for function stringc
def test_stringc():
    assert 'hello' == stringc('hello', 'black')
    assert '\033[31mhello\033[0m' == stringc('hello', 'red')
    assert '\033[32mhello\033[0m' == stringc('hello', 'green')
    assert '\033[34mhello\033[0m' == stringc('hello', 'blue')
    assert '\033[37mhello\033[0m' == stringc('hello', 'white')
    assert '\033[1;37mhello\033[0m' == stringc('hello', 'bright white')
    assert '\033[0;31;45mhello\033[0m' == stringc('hello', 'red,bgblue')

# Generated at 2022-06-11 17:48:05.584375
# Unit test for function hostcolor

# Generated at 2022-06-11 17:48:12.890762
# Unit test for function stringc
def test_stringc():
    """Test function."""
    if not ANSIBLE_COLOR:
        return

    assert stringc('red', 'red') == u'\x1b[91mred\x1b[0m'
    assert stringc('black', '#000') == u'\x1b[30mblack\x1b[0m'
    assert stringc('white', '#fff') == u'\x1b[97mwhite\x1b[0m'
    assert stringc('red', 'rgb255000') == u'\x1b[91mred\x1b[0m'
    assert stringc('black', 'rgb001') == u'\x1b[30mblack\x1b[0m'

# Generated at 2022-06-11 17:48:21.445393
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("hostname", dict(changed=0, unreachable=0, failures=1)) == u"hostname                 \033[31;01m\033[K"
    assert hostcolor("hostname", dict(changed=0, unreachable=0, failures=0)) == u"hostname                 \033[32;01m\033[K"
    assert hostcolor("hostname", dict(changed=1, unreachable=0, failures=0)) == u"hostname                 \033[33;01m\033[K"
    assert hostcolor("hostname", dict(changed=0, unreachable=1, failures=0)) == u"hostname                 \033[31;01m\033[K"

if __name__ == "__main__":
    test_hostcolor()

# Generated at 2022-06-11 17:48:38.442160
# Unit test for function stringc
def test_stringc():
    def test_eq(actual, expected):
        if actual != expected:
            raise Exception("Text comparison failed\n"
                            "actual  : %r\n"
                            "expected: %r" % (actual, expected))

    if ANSIBLE_COLOR:
        # Use `str` to get bytes in Python 2, Unicode string in Python 3
        test_eq(str(stringc(u"text", "blue")), u"\033[34mtext\033[0m")
        test_eq(str(stringc(u"text", "blue", wrap_nonvisible_chars=True)),
                u"\001\033[34m\002text\001\033[0m\002")

# Generated at 2022-06-11 17:48:44.513176
# Unit test for function hostcolor
def test_hostcolor():
    host = 'myhost'
    stats = {
        'failures': 1,
        'changed': 1,
        'unreachable': 1,
    }

    # For each stat test if it changes the color in the output
    for var in stats:
        new_stats = stats.copy()
        new_stats[var] = 0
        assert "%-37s" % stringc(host, C.COLOR_OK) == hostcolor(host, new_stats)



# Generated at 2022-06-11 17:48:55.237682
# Unit test for function colorize
def test_colorize():
    ''' assert that we've correctly colorized strings '''
    assert colorize("foo", 1, "blue") == u"foo=1   "
    assert colorize("foo", 0, "blue") == u"foo=0   "
    assert colorize("foo", 0, None) == u"foo=0   "

    assert colorize("foo", 1234, "blue") == u"foo=1234"
    assert colorize("foo", 1234, None) == u"foo=1234"

    # Force color off for these tests
    global ANSIBLE_COLOR
    ANSIBLE_COLOR=False
    assert colorize("foo", 1, "blue") == u"foo=1   "
    assert colorize("foo", 0, "blue") == u"foo=0   "

# Generated at 2022-06-11 17:49:06.754465
# Unit test for function hostcolor
def test_hostcolor():
    stats = {
        'changed': 0,
        'dark': 0,
        'failures': 0,
        'ok': 0,
        'processed': 0,
        'skipped': 0,
        'unreachable': 0,
        'ignored': 0
    }
    assert hostcolor('foo', stats) == u"%-26s" % 'foo'
    assert hostcolor('foo', stats, color=False) == u"%-26s" % 'foo'
    stats['unreachable'] = 1
    assert hostcolor('foo', stats) == u"%-37s" % stringc('foo', C.COLOR_ERROR)
    stats['unreachable'] = 0
    stats['failures'] = 1

# Generated at 2022-06-11 17:49:14.764394
# Unit test for function stringc
def test_stringc():
    assert stringc("foo\nbar", "green") == "\033[32mfoo\nbar\033[0m"
    assert stringc("foo bar", "red") == "\033[31mfoo bar\033[0m"
    assert stringc("foo bar", "blue") == "\033[34mfoo bar\033[0m"
    assert stringc("foo bar", "magenta") == "\033[35mfoo bar\033[0m"
    assert stringc("foo bar", "reset") == "\033[0mfoo bar\033[0m"
    assert stringc("foo bar", "color1") == "\033[38;5;1mfoo bar\033[0m"
    assert stringc("foo bar", "color2") == "\033[38;5;2mfoo bar\033[0m"

# Generated at 2022-06-11 17:49:24.727826
# Unit test for function hostcolor
def test_hostcolor():
    stats_failure = {'failures': 1, 'unreachable': 0, 'ok': 1, 'changed': 2}
    stats_ok =      {'failures': 0, 'unreachable': 0, 'ok': 3, 'changed': 2}
    stats_cantreach = {'failures': 0, 'unreachable': 1, 'ok': 2, 'changed': 0}

    test_host = "localhost"
    assert hostcolor(test_host, stats_failure) == u'localhost                 '
    assert hostcolor(test_host, stats_ok) == u'localhost                   '
    assert hostcolor(test_host, stats_cantreach) == u'localhost               '



# Generated at 2022-06-11 17:49:29.059376
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize('foo', 42, 'blue') == u"\033[34mfoo=42\033[0m"
    else:
        assert colorize('foo', 42, 'blue') == u"foo=42"

# end "pretty"

# Generated at 2022-06-11 17:49:33.415569
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('hello', 'red') == '\x1b[31mhello\x1b[0m'
    else:
        assert stringc('hello', 'red') == 'hello'
        assert stringc('hello', 'bad_color') == 'hello'



# Generated at 2022-06-11 17:49:43.262288
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("color01") == u'38;5;1'
    assert parsecolor("rgb000") == u'38;5;232'
    assert parsecolor("rgb123") == u'38;5;18'
    assert parsecolor("rgb333") == u'38;5;236'
    assert parsecolor("rgb444") == u'38;5;59'
    assert parsecolor("grayerror") == u'38;5;240'
    try:
        parsecolor("grayerror")
    except KeyError:
        pass
    else:
        raise AssertionError("'grayerror' is not a valid color name")

# Generated at 2022-06-11 17:49:51.085111
# Unit test for function colorize

# Generated at 2022-06-11 17:50:19.838031
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red', False)           == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'red', True)            == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc('foo', 'rgb255255255', False)  == u"\033[38;5;15mfoo\033[0m"
    assert stringc('foo', 'rgb255255255', True)   == u"\001\033[38;5;15m\002foo\001\033[0m\002"
    assert stringc('foo', 'rgb0255255', False)    == u"\033[38;5;118mfoo\033[0m"

# Generated at 2022-06-11 17:50:26.635925
# Unit test for function colorize
def test_colorize():
    print(u'Testing function: colorize')
    print(u'These should be different colors:')
    print(colorize(u'VAR', 32, u'blue'))
    print(colorize(u'VAR', 0, u'blue'))
    print(colorize(u'VAR', 99, None))
    print(colorize(u'VAR', 99, u'red'))
    print(colorize(u'VAR', 99, u'green'))
    print(colorize(u'VAR', 22, u'pink'))
    print(colorize(u'VAR', 22, u'green'))
    print(u'These should all be the same color:')

# Generated at 2022-06-11 17:50:32.550244
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'blue') == u'\033[34mtest\033[0m'
    assert stringc('test', 'color3') == u'\033[38;5;11mtest\033[0m'
    assert stringc('test', 'rgb123') == u'\033[38;5;21mtest\033[0m'
    assert stringc('test', 'gray1') == u'\033[38;5;244mtest\033[0m'



# Generated at 2022-06-11 17:50:41.837742
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""

    TESTS = [
        (u"failed", -5, C.COLOR_ERROR, u"failed=-5  "),
        (u"failed", 0, C.COLOR_ERROR, u"failed=0   "),
        (u"failed", 1, C.COLOR_ERROR, u"failed=1   "),
        (u"ok", 0, C.COLOR_OK, u"ok=0     "),
        (u"changed", 99, C.COLOR_CHANGED, u"changed=99 ")
    ]

    # First, test some normal use cases
    # This can be done with a for, but it's more readable this way
    (lead, num, color, expected) = TESTS[0]
    actual = colorize(lead, num, color)
    assert actual

# Generated at 2022-06-11 17:50:52.107012
# Unit test for function colorize
def test_colorize():
    """ basic sanity testing for colorization function """

    # NOTE: ANSIBLE_NOCOLOR environment variable is also tested here
    # because we rely on it in colorize()

    # setup test environment
    from ansible.utils.color import stringc

    # no color
    C.ANSIBLE_NOCOLOR = True
    assert stringc("a", "blue") == "a"

    # no terminal
    C.ANSIBLE_NOCOLOR = False
    del(sys.stdout.isatty)
    sys.stdout.isatty = lambda: False
    assert stringc("a", "blue") == "a"

    # no tigetnum
    del(sys.stdout.isatty)
    sys.stdout.isatty = lambda: True
    import curses

# Generated at 2022-06-11 17:51:03.477007
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor_test = dict(
        passed=dict(
            host1=dict(
                changed=0,
                failures=0,
                ok=20,
                skipped=0,
                unreachable=0,
                rescues=0,
                ignored=0
            )
        ),
        failed=dict(
            host2=dict(
                changed=20,
                failures=1,
                ok=20,
                skipped=0,
                unreachable=0,
                rescues=0,
                ignored=0
            )
        ),
        unreachable=dict(
            host3=dict(
                changed=0,
                failures=0,
                ok=0,
                skipped=0,
                unreachable=1,
                rescues=0,
                ignored=0
            )
        )
    )



# Generated at 2022-06-11 17:51:14.878961
# Unit test for function hostcolor
def test_hostcolor():
    # Test no color
    host = 'localhost'
    stats = dict(
        ok=0, skipped=0, unreachable=0, failed=0, changed=0, dark=0)
    assert hostcolor(host, stats, False) == u'%-37s' % host

    # Test with all zeroes
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_OK)

    # Test with failures
    stats['failures'] = 1
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)

    # Test with unreachable
    stats['failures'] = 0
    stats['unreachable'] = 1

# Generated at 2022-06-11 17:51:23.761202
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    from ansible import utils
    from ansible.utils import pprint
    class Tmp_Test(object):
        def __init__(self):
            self._result = {
                'dark': {
                    'failures': 0,
                    'skipped': 0,
                    'ok': 0,
                    'changed': 0,
                    'unreachable': 0,
                    'processed': 0,
                    'dark': None,
                },
                'contacted': {
                    'failures': 0,
                    'skipped': 0,
                    'ok': 2,
                    'changed': 3,
                    'unreachable': 0,
                    'processed': 5,
                    'dark': None,
                }
            }
    res = Tmp_Test()
    pprint.no_

# Generated at 2022-06-11 17:51:35.148277
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils.six import b
    res = hostcolor('host1', {'failures': 0, 'unreachable': 0, 'changed': 0})
    assert type(res) == str or type(res) == unicode
    res = hostcolor('host1', {'failures': 0, 'unreachable': 1, 'changed': 0})
    assert type(res) == str or type(res) == unicode
    res = hostcolor('host1', {'failures': 1, 'unreachable': 0, 'changed': 0})
    assert type(res) == str or type(res) == unicode
    res = hostcolor('host1', {'failures': 0, 'unreachable': 0, 'changed': 1})
    assert type(res) == str or type(res) == unicode

    #

# Generated at 2022-06-11 17:51:45.854046
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=1, failures=0, unreachable=0)
    expected = 'CHANGED=1   '
    assert(expected == hostcolor("test_host", stats, color=True)[-12:])

    stats = dict(changed=0, failures=1, unreachable=0)
    expected = 'FAILED=1    '
    assert(expected == hostcolor("test_host", stats, color=True)[-12:])

    stats = dict(changed=0, failures=0, unreachable=1)
    expected = 'UNREACHABLE=1'
    assert(expected == hostcolor("test_host", stats, color=True)[-12:])

    stats = dict(changed=0, failures=0, unreachable=0)
    expected = 'ok          '

# Generated at 2022-06-11 17:52:14.318356
# Unit test for function stringc
def test_stringc():
    assert stringc('abcd', 'blue') == '\033[0;34mabcd\033[0m'
    assert stringc('abcd', 'blue', wrap_nonvisible_chars=True) == '\001\033[0;34m\002abcd\001\033[0m\002'
    assert stringc('abcd', '00') == '\033[38;5;16mabcd\033[0m'
    assert stringc('abcd', '01') == '\033[38;5;17mabcd\033[0m'
    assert stringc('abcd', '02') == '\033[38;5;18mabcd\033[0m'
    assert stringc('abcd', '03') == '\033[38;5;19mabcd\033[0m'

# Generated at 2022-06-11 17:52:25.959238
# Unit test for function hostcolor
def test_hostcolor():
    """ Test for function hostcolor. """
    test_hostname = u'Test'
    stats_ok = {
        u'changed': 0,
        u'failures': 0,
        u'rescued': 0,
        u'ok': 1,
        u'skipped': 0,
        u'unreachable': 0,
    }
    stats_changed = {
        u'changed': 1,
        u'failures': 0,
        u'rescued': 0,
        u'ok': 0,
        u'skipped': 0,
        u'unreachable': 0,
    }

# Generated at 2022-06-11 17:52:32.891610
# Unit test for function stringc

# Generated at 2022-06-11 17:52:33.809989
# Unit test for function stringc
def test_stringc():
    return



# Generated at 2022-06-11 17:52:40.530220
# Unit test for function stringc
def test_stringc():
    assert stringc('Test', 'red', False) == u"\033[31mTest\033[0m"
    assert stringc('Test', 'red', True) == u"\001\033[31m\002Test\001\033[0m\002"
    assert stringc('Test', 'color8', False) == u"\033[38;5;8mTest\033[0m"
    assert stringc('Test', 'color8', True) == u"\001\033[38;5;8m\002Test\001\033[0m\002"



# Generated at 2022-06-11 17:52:48.955770
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        ok=1,
        changed=2,
        unreachable=4,
        failures=8
    )
    for color in (True, False):
        # no problems
        assert hostcolor('host', dict(ok=1), color=color) == u'host'
        # changed
        assert hostcolor('host', dict(changed=1), color=color) == u'host'
        # unreachable
        assert hostcolor('host', dict(unreachable=1), color=color) == u'host'
        # failures
        assert hostcolor('host', dict(failures=1), color=color) == u'host'



# Generated at 2022-06-11 17:52:57.593617
# Unit test for function parsecolor
def test_parsecolor():
    _test_parsecolor(u"white", u'38;5;15')
    _test_parsecolor(u"black", u'38;5;16')
    _test_parsecolor(u"blue", u'38;5;69')
    _test_parsecolor(u"brightpurple", u'38;5;141')
    _test_parsecolor(u"green", u'38;5;83')
    _test_parsecolor(u"lightblue", u'38;5;87')
    _test_parsecolor(u"lightcyan", u'38;5;89')
    _test_parsecolor(u"lightgreen", u'38;5;119')
    _test_parsecolor(u"lightpurple", u'38;5;173')
    _

# Generated at 2022-06-11 17:53:07.086954
# Unit test for function stringc
def test_stringc():
    print(u"Testing function stringc()")
    print(u"Testing parameter 'color'")
    print(u"Parameter color = 'red'")
    print(u"red text", end=u'')
    print(stringc(u"Test for red text.", u"red"))
    print(u"Parameter color = 'green'")
    print(stringc(u"Test for green text.", u"green"))
    print(u"Parameter color = 'yellow'")
    print(stringc(u"Test for yellow text.", u"yellow"))
    print(u"Parameter color = 'blue'")
    print(stringc(u"Test for blue text.", u"blue"))
    print(u"Parameter color = 'magenta'")
    print(stringc(u"Test for magenta text.", u"magenta"))

# Generated at 2022-06-11 17:53:18.247475
# Unit test for function stringc
def test_stringc():
    test_message = "This is a test."
    assert stringc(test_message, "black") == "\033[38;5;0mThis is a test.\033[0m"
    assert stringc(test_message, "red") == "\033[38;5;1mThis is a test.\033[0m"
    assert stringc(test_message, "green") == "\033[38;5;2mThis is a test.\033[0m"
    assert stringc(test_message, "yellow") == "\033[38;5;3mThis is a test.\033[0m"
    assert stringc(test_message, "blue") == "\033[38;5;4mThis is a test.\033[0m"

# Generated at 2022-06-11 17:53:29.406344
# Unit test for function hostcolor
def test_hostcolor():
    hc = hostcolor('test-host', {'failures': 0, 'unreachable': 0, 'changed': 0}, True)
    assert hc == u"test-host                        "
    hc = hostcolor('test-host', {'failures': 10, 'unreachable': 20, 'changed': 0}, True)
    assert hc == u"test-host                        "
    hc = hostcolor('test-host', {'failures': 0, 'unreachable': 0, 'changed': 10}, True)
    assert hc == u"test-host                        "
    hc = hostcolor('test-host', {'failures': 10, 'unreachable': 20, 'changed': 3}, True)
    assert hc == u"test-host                        "

# --- end "pretty"


# Generated at 2022-06-11 17:53:52.134913
# Unit test for function colorize
def test_colorize():
    print(colorize("changed", 6, "red"), end=" ")
    print(colorize("unreachable", 0, "red"), end=" ")
    print(colorize("failed", 0, "red"), end=" ")
    print(colorize("ok", 15, "green"))

# Generated at 2022-06-11 17:54:00.186234
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo\nbar", "blue") == "\033[34mfoo\nbar\033[0m"
    assert stringc("foo\n\033[32mbar\033[0m", "red") == "\033[31mfoo\n\033[32mbar\033[0m\033[0m"
    assert stringc("foo", "green", wrap_nonvisible_chars=True) == "\001\033[38;5;2m\002foo\001\033[0m\002"
    assert stringc("foo", "rgb255000") == "\033[38;5;9mfoo\033[0m"

# Generated at 2022-06-11 17:54:08.892252
# Unit test for function hostcolor
def test_hostcolor():
# The function hostcolor prints a hostname in color, depending on the
# status of the host.
    # Set ANSIBLE_COLOR to True, to activate the test
    from ansible.constants import ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    # The to be tested host
    host = "testhost"
    # No problems with the host
    stats = {'skipped': 0, 'ok': 1, 'failures': 0, 'changed': 0, 'unreachable': 0}
    print("%r" % hostcolor(host, stats))
    # Host is unreachable
    stats = {'skipped': 0, 'ok': 0, 'failures': 0, 'changed': 0, 'unreachable': 1}
    print(hostcolor(host, stats))
    # The host has failed

# Generated at 2022-06-11 17:54:16.650895
# Unit test for function colorize
def test_colorize():
    assert (colorize("ok", 0, C.COLOR_OK) == u"ok=0   ")
    assert (colorize("changed", 0, C.COLOR_CHANGED) == u"changed=0   ")
    assert (colorize("unreachable", 0, C.COLOR_UNREACHABLE) == u"unreachable=0   ")
    assert (colorize("failed", 0, C.COLOR_ERROR) == u"failed=0   ")

# end of "pretty"

# Generated at 2022-06-11 17:54:26.239434
# Unit test for function stringc

# Generated at 2022-06-11 17:54:33.046852
# Unit test for function stringc
def test_stringc():
    print(stringc(u"abc", 'green'))
    print(stringc(u"def", 'green', wrap_nonvisible_chars=True))
    print(stringc(u"abc\ndef", 'green'))
    print(stringc(u"abc\ndef", 'green', wrap_nonvisible_chars=True))


# --- end "pretty"

__all__ = ['stringc', 'test_stringc', 'colorize', 'hostcolor']

# Generated at 2022-06-11 17:54:38.851550
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', None, 'blue') == 'foo=None'
    assert re.match(r'foo\x1b\[34m=100\x1b\[0m', colorize('foo', 100, 'blue'))

# --- end of "pretty"

# ---- some generic syntax formatting helpers

# TODO: deprecate before 2.0



# Generated at 2022-06-11 17:54:50.356262
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""

    # Ensure that the various color codes are parsed correctly.
    assert parsecolor("black") == u'38;5;0'
    assert parsecolor("blue") == u'38;5;4'
    assert parsecolor("green") == u'38;5;2'
    assert parsecolor("cyan") == u'38;5;6'
    assert parsecolor("red") == u'38;5;1'
    assert parsecolor("magenta") == u'38;5;5'
    assert parsecolor("yellow") == u'38;5;3'
    assert parsecolor("white") == u'38;5;7'
    assert parsecolor("color0") == u'38;5;0'

# Generated at 2022-06-11 17:54:57.368589
# Unit test for function hostcolor
def test_hostcolor():
    # Set no_log to False to enable debugging
    no_log = True

    # Test case: all_ok
    success = (0, 0, 0)
    color = hostcolor(u'localhost', {u'failures': 0, u'changed': 0, u'ok': 1, u'unreachable': 0}, True)
    assert color is not None
    if not no_log:
        print("Success: " + color)

    # Test case: failures
    failure = (100, 0, 0)
    color = hostcolor(u'localhost', {u'failures': 100, u'changed': 0, u'ok': 0, u'unreachable': 0}, True)
    assert color is not None
    if not no_log:
        print("Failure: " + color)

    # Test case: unreachable
    unre