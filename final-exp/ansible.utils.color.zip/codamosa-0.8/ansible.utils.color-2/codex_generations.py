

# Generated at 2022-06-11 17:45:08.961685
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"host.example.com", dict(failures=0, unreachable=0, changed=0), True) == u"%-26s" % u"host.example.com"
    assert hostcolor(u"host.example.com", dict(failures=1, unreachable=0, changed=0), True) == u"%-26s" % stringc(u"host.example.com", C.COLOR_ERROR)
    assert hostcolor(u"host.example.com", dict(failures=0, unreachable=1, changed=0), True) == u"%-26s" % stringc(u"host.example.com", C.COLOR_ERROR)

# Generated at 2022-06-11 17:45:19.064497
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', dict(ok=1)) == u"host1                 "
    assert hostcolor('host1', dict(ok=1, changed=2)) == u"host1                 "
    assert hostcolor('host1', dict(changed=2)) == u"host1                 "
    assert hostcolor('host1', dict(failed=1)) == u"host1                 "
    assert hostcolor('host1', dict(failures=1)) == u"host1                 "
    assert hostcolor('host1', dict(unreachable=1)) == u"host1                 "
    assert hostcolor('host1', dict(ok=1, unreachable=1)) == u"host1                 "

# Generated at 2022-06-11 17:45:30.685720
# Unit test for function stringc
def test_stringc():
    assert stringc(u'abcde', 'black') == u'\x1b[30mabcde\x1b[0m'
    assert stringc(u'abcde', 'red') == u'\x1b[31mabcde\x1b[0m'
    assert stringc(u'abcde', 'green') == u'\x1b[32mabcde\x1b[0m'
    assert stringc(u'abcde', 'yellow') == u'\x1b[33mabcde\x1b[0m'
    assert stringc(u'abcde', 'blue') == u'\x1b[34mabcde\x1b[0m'

# Generated at 2022-06-11 17:45:36.334904
# Unit test for function colorize
def test_colorize():
    """print in color"""
    print("colorize")
    print(colorize("1:", 123, None))
    print(colorize("2:", 0, "normal"))
    print(colorize("3:", 1, "blue"))
    print(colorize("4:", 2, "magenta"))
    print(colorize("5:", 3, "red"))



# Generated at 2022-06-11 17:45:40.439600
# Unit test for function colorize
def test_colorize():
    print("Testing colorize")
    print("correct: " +
          colorize("foo", 0, "green") +
          colorize("bar", 1, "yellow") +
          colorize("baz", 2, "red") +
          " end")



# Generated at 2022-06-11 17:45:50.189446
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test", dict(failures=1)) == "test" + u" " * 31
    assert hostcolor("test", dict(failures=0, unreachable=1)) == "test" + u" " * 31
    assert hostcolor("test", dict(failures=0, unreachable=0, changed=1)) == "test" + u" " * 31
    assert hostcolor("test", dict(failures=0, unreachable=0, changed=0)) == "test" + u" " * 31
    assert hostcolor("test", dict(failures=1), color=False) == "test" + u" " * 31
    assert hostcolor("test", dict(failures=0, unreachable=1), color=False) == "test" + u" " * 31

# Generated at 2022-06-11 17:46:01.196729
# Unit test for function parsecolor
def test_parsecolor():
    """ parsecolor() unit tests """
    # Get all color names (keys) in COLOR_CODES dict
    color_names = C.COLOR_CODES.keys()
    for s_color in color_names:
        i_color = parsecolor(s_color)
        # Check if the color is a number
        assert(bool(re.match(r'^[0-9]+$', i_color)))
    # Test some invalid color names
    assert(parsecolor('reds') is None)
    assert(parsecolor('lom') is None)
    assert(parsecolor('') is None)
    assert(parsecolor('rgb123') is None)
    assert(parsecolor('rgb1236') is None)
    assert(parsecolor('rgb123456') is None)


# Generated at 2022-06-11 17:46:11.849236
# Unit test for function parsecolor
def test_parsecolor():
    def _eq(val, dest):
        assert(val == dest), "%s != %s" % (val, dest)

    _eq(parsecolor('green'), '32')
    _eq(parsecolor('bright green'), '92')
    _eq(parsecolor('color1'), '38;5;1')
    _eq(parsecolor('gray0'), '38;5;232')
    _eq(parsecolor('gray3'), '38;5;235')
    _eq(parsecolor('gray8'), '38;5;240')
    _eq(parsecolor('gray11'), '38;5;243')
    _eq(parsecolor('gray15'), '38;5;247')
    _eq(parsecolor('rgb01'), '38;5;16')

# Generated at 2022-06-11 17:46:19.489324
# Unit test for function hostcolor
def test_hostcolor():
    import ansible
    host = 'fart'
    stats = {'failures': 0}
    print(hostcolor(host, stats))
    stats['failures'] += 1
    stats['unreachable'] += 1
    print(hostcolor(host, stats))
    stats['unreachable'] = 0
    stats['changed'] = 1
    print(hostcolor(host, stats))
    stats['changed'] = 0
    print(hostcolor(host, stats))


# Generated at 2022-06-11 17:46:27.099532
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb255005') == u'\033[38;5;30mfoo\033[0m'
    assert stringc('foo', 'rgb000') == u'\033[38;5;16mfoo\033[0m'
    assert stringc('foo', 'rgb255000') == u'\033[38;5;196mfoo\033[0m'
    assert stringc('foo', 'rgb000255') == u'\033[38;5;21mfoo\033[0m'

# Generated at 2022-06-11 17:46:42.243351
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "black") == u"\033[30mtext\033[0m"
    assert stringc("text", "red") == u"\033[31mtext\033[0m"
    assert stringc("text", "green") == u"\033[32mtext\033[0m"
    assert stringc("text", "yellow") == u"\033[33mtext\033[0m"
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "magenta") == u"\033[35mtext\033[0m"
    assert stringc("text", "cyan") == u"\033[36mtext\033[0m"

# Generated at 2022-06-11 17:46:46.243903
# Unit test for function stringc
def test_stringc():
    assert parsecolor('black') == '30'
    assert parsecolor('default') == '39'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('lightgray') == '37'
    assert parsecolor('darkgray') == '90'
    assert parsecolor('lightred') == '91'
    assert parsecolor('lightgreen') == '92'
    assert parsecolor('lightyellow') == '93'
    assert parsecolor('lightblue') == '94'

# Generated at 2022-06-11 17:46:53.782568
# Unit test for function hostcolor
def test_hostcolor():
    if hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) != 'localhost':
        return False
    if hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) != 'localhost':
        return False
    if hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) != 'localhost':
        return False
    if hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) != 'localhost':
        return False
    return True



# Generated at 2022-06-11 17:47:03.965631
# Unit test for function colorize
def test_colorize():
    """Colorize: Print 'lead' = 'num' in 'color' """
    assert colorize(u"foo", 1, u"blue") == "\x1b[0;34mfoo=1  \x1b[0m"
    assert colorize(u"foo", 0, u"blue") == "foo=0  "
    assert colorize(u"foo", 1, None)    == "foo=1  "
    assert colorize(u"foooooooooooooo", 1, u"blue") == "\x1b[0;34mfoooooooooooooo=1 \x1b[0m"

# --- end "pretty"

# --- begin "console"
#
# Code originally from http://www.piware.de/2011/01/creating-an-https-server-in-python/
#
# Adopted

# Generated at 2022-06-11 17:47:15.205467
# Unit test for function stringc
def test_stringc():
    assert stringc('hello world', 'blue') == '\033[34mhello world\033[0m'
    assert stringc('hello world', 'bold') == '\033[1mhello world\033[0m'
    assert stringc('hello world', 'green', wrap_nonvisible_chars=True) == '\001\033[32m\002hello world\001\033[0m\002'
    assert stringc('hello world', 'on_yellow') == '\033[43mhello world\033[0m'
    assert stringc('hello world', 'purple') == '\033[35mhello world\033[0m'
    assert stringc('hello world', 'underline_blue') == '\033[4;34mhello world\033[0m'
    assert stringc('hello world', 'white')

# Generated at 2022-06-11 17:47:21.222383
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u'\033[31mtest\033[0m'
    assert stringc("test", "blue") == u'\033[34mtest\033[0m'
    assert stringc("test", "badcolor") == u'\033[31mtest\033[0m'
    assert stringc("test", "30") == u'\033[30mtest\033[0m'
    assert stringc("test", "255") == u'\033[97mtest\033[0m'


# --- end "pretty"


# Generated at 2022-06-11 17:47:31.843053
# Unit test for function stringc

# Generated at 2022-06-11 17:47:44.824007
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'ok': 1, 'changed': 0}
    assert hostcolor(host, stats, color=True) == stringc(host, C.COLOR_OK)
    stats = {'failures': 0, 'unreachable': 0, 'ok': 1, 'changed': 1}
    assert hostcolor(host, stats, color=True) == stringc(host, C.COLOR_CHANGED)
    stats = {'failures': 1, 'unreachable': 0, 'ok': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'ok': 1, 'changed': 0}


# Generated at 2022-06-11 17:47:53.007482
# Unit test for function hostcolor
def test_hostcolor():
    color_true = u"\033[0;32mok=0   \033[0m"
    color_false = "ok=0   "
    assert (color_true == hostcolor("ok", {'changed': 0, 'failures': 0, 'success': 0, 'dark': 0, 'unreachable': 0, 'skipped': 0}, True))
    assert (color_false == hostcolor("ok", {'changed': 0, 'failures': 0, 'success': 0, 'dark': 0, 'unreachable': 0, 'skipped': 0}, False))

# end "pretty"
# ---


# Generated at 2022-06-11 17:47:58.467407
# Unit test for function hostcolor
def test_hostcolor():
    # Set up test data
    host = 'any_host'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    if ANSIBLE_COLOR:
        expected = u"%-37s" % C.COLOR_HOSTNAME(host)
    else:
        expected = u"%-12s" % host
    # Ensure function returns expected value
    assert hostcolor(host, stats) == expected

# --- end of pretty ---

# Functions to print messages in color.


# Generated at 2022-06-11 17:48:17.764840
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'changtino': 0,
             'failures': 0,
             'ok': True,
             'skipped': 0,
             'unreachable': 0}
    print('Testing for a changed host (should be yellow)', end=' ')
    stats['changed'] = 1
    test_color = hostcolor('testhost', stats, True)
    if re.search(r'\x1b\[33;1m', test_color):
        print('YES')
    else:
        print('NO')

    print('Testing for an unchallenged host (should be green)', end=' ')
    stats['changed'] = 0
    test_color = hostcolor('testhost', stats, True)
    if re.search(r'\x1b\[32;1m', test_color):
        print

# Generated at 2022-06-11 17:48:28.599631
# Unit test for function hostcolor
def test_hostcolor():
    fake_stats = {
        'changed': 0,
        'failures': 1,
        'ok': 10,
        'skipped': 0,
        'unreachable': 2,
    }
    assert hostcolor('localhost', fake_stats) == u'\033[31;01mlocalhost\033[0m'
    assert hostcolor('localhost', fake_stats, color=False) == u'localhost          '
    fake_stats['failures'] = 0
    fake_stats['unreachable'] = 0
    fake_stats['changed'] = 1
    assert hostcolor('localhost', fake_stats) == u'\033[33;01mlocalhost\033[0m'
    assert hostcolor('localhost', fake_stats, color=False) == u'localhost          '
    fake_stats['changed'] = 0
    assert host

# Generated at 2022-06-11 17:48:37.801622
# Unit test for function stringc
def test_stringc():
    # print "testing stringc"
    assert stringc(None, 'green') == "\033[32mNone\033[0m"
    assert stringc('', 'green') == "\033[32m\033[0m"
    assert stringc('foo', 'green') == "\033[32mfoo\033[0m"
    assert stringc('foo\nbar\nbaz', 'green') == "\033[32mfoo\033[0m\n\033[32mbar\033[0m\n\033[32mbaz\033[0m"

# Generated at 2022-06-11 17:48:47.152068
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('foo.example.org', stats) == 'foo.example.org             '
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor('foo.example.org', stats) == \
        '\033[0;34mfoo.example.org\033[0m'
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('foo.example.org', stats) == \
        '\033[0;31mfoo.example.org\033[0m'
    stats = dict(failures=1, unreachable=0, changed=0)

# Generated at 2022-06-11 17:48:56.679974
# Unit test for function stringc
def test_stringc():
    print(stringc("This is an %s", "emphasized", "emphasis"))
    print(stringc("This is a %s", "warning", "warning"))
    print(stringc("This is an %s", "alert", "alert"))
    print(stringc("This is an %s", "error", "error"))
    print(stringc("This is some %s", "red text", "red"))
    print(stringc("This is some %s", "yellow text", "yellow"))
    print(stringc("This is some %s", "green text", "green"))
    print(stringc("This is some %s", "light red text", "light red"))
    print(stringc("This is some %s", "cyan text", "cyan"))

# Generated at 2022-06-11 17:49:08.034061
# Unit test for function stringc
def test_stringc():
    assert u"\u001b[38;5;1mcol\u001b[0m" == stringc(u'col', u"red")
    assert u"\u001b[38;5;1mcol\u001b[0m" == stringc(u'col', u"color1")
    assert u"\u001b[38;5;196mgray24\u001b[0m" == stringc(u'gray24', u"gray24")
    assert u"\u001b[38;5;196mgray24\u001b[0m" == stringc(u'gray24', u"gray24")
    assert u"\u001b[38;5;196mcol\u001b[0m" == stringc(u'col', u"rgb444")

# Generated at 2022-06-11 17:49:15.463739
# Unit test for function stringc
def test_stringc():
    assert stringc('this is a test', 'red') == '\x1b[31mthis is a test\x1b[0m'
    assert stringc('this is a test', 'rgb255000') == '\x1b[38;5;196mthis is a test\x1b[0m'
    assert stringc('this is a test', 'rgb255255255') == '\x1b[38;5;255mthis is a test\x1b[0m'
    assert stringc('this is a test', 'gray10') == '\x1b[38;5;250mthis is a test\x1b[0m'
    assert stringc('this is a test', color=None) == 'this is a test'

# Generated at 2022-06-11 17:49:20.515332
# Unit test for function hostcolor
def test_hostcolor():
    s = hostcolor('localhost', {})
    print(s)
    assert s == u'%-37s' % 'localhost'

    s = hostcolor('localhost', {'changed': 10})
    print(s)
    assert s == u'%-37s' % 'localhost'

# --- end "pretty"



# Generated at 2022-06-11 17:49:24.256997
# Unit test for function colorize
def test_colorize():
    assert colorize("a", "b", C.COLOR_ERROR) == "\033[91ma=b   \033[0m"
    return True

# --- end "pretty"

if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-11 17:49:28.393484
# Unit test for function colorize
def test_colorize():
    for c in ('dark gray', 'light red', 'green', 'light purple'):
        print(colorize('>', 0, c))
        print(colorize('>', 10, c))
        print(colorize('>', 100, c))


# --- end "pretty"

# Generated at 2022-06-11 17:49:58.393217
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('cyan') == '36'
    assert parsecolor('bright purple') == '95'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('rgb123') == '38;5;61'
    assert parsecolor('rgb321') == '38;5;126'
    assert parsecolor('rgb213') == '38;5;95'
    assert parsecolor('rgb111') == '38;5;16'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray7') == '38;5;239'
    assert par

# Generated at 2022-06-11 17:49:59.456111
# Unit test for function colorize
def test_colorize():
    pass


# --- end "pretty"

# Generated at 2022-06-11 17:50:01.423099
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello world", "red"))



# Generated at 2022-06-11 17:50:13.518015
# Unit test for function hostcolor

# Generated at 2022-06-11 17:50:20.651465
# Unit test for function colorize
def test_colorize():
    colorize("test", 10, 'red') == "\x1b[31mtest=10\x1b[0m"
#
# --- end "pretty"

# Things to do:
#   - convert this file to be more like the one above
#   - convert the errors to use list/dicts instead of tuples, so "rc" for return code can be added
#   - make ANSIBLE_NOCOLOR work
#   - re-introduce "ur"(unsure) color for non-tty, non-color stdout



# Generated at 2022-06-11 17:50:30.638064
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("reset") == '39'
    assert parsecolor("black") == '30'
    assert parsecolor("red") == '31'
    assert parsecolor("green") == '32'
    assert parsecolor("yellow") == '33'
    assert parsecolor("blue") == '34'
    assert parsecolor("magenta") == '35'
    assert parsecolor("cyan") == '36'
    assert parsecolor("lightgray") == '37'
    assert parsecolor("darkgray") == '90'
    assert parsecolor("lightred") == '91'
    assert parsecolor("lightgreen") == '92'
    assert parsecolor("lightyellow") == '93'
    assert parsecolor("lightblue") == '94'

# Generated at 2022-06-11 17:50:39.468486
# Unit test for function hostcolor
def test_hostcolor():
    """ hostcolor returns strings with proper color codes"""
    stats1 = dict(failures=1, unreachable=0, changed=0)
    stats2 = dict(failures=0, unreachable=1, changed=0)
    stats3 = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor("foo", stats1, color=True).startswith("\033[31m")
    assert hostcolor("foo", stats2, color=True).startswith("\033[31m")
    assert hostcolor("foo", stats3, color=True).startswith("\033[33m")

# end of pretty
# ---



# Generated at 2022-06-11 17:50:50.498785
# Unit test for function colorize
def test_colorize():
    """Colorize function unit test"""
    # 8 colors + 1 normal, 16 colors + 1 normal, 256 colors + 1 normal
    for c in [8, 16, 256]:
        # Test set - all values should be 0
        zero_values = [0, 0, 0, 0, 0]
        assert colorize('ok', zero_values[0], c) == 'ok=0   '
        assert colorize('changed', zero_values[1], c) == 'changed=0'
        assert colorize('unreachable', zero_values[2], c) == 'unreachable=0  '

# Generated at 2022-06-11 17:51:02.298393
# Unit test for function hostcolor
def test_hostcolor():
    fakehost = u'www.example.com'
    color_output = u'\033[0;32m%-37s\033[0m' % fakehost
    monochrome_output = u'%-26s' % fakehost
    try:
        from ansible import constants as C
    except ImportError:
        from ansible.constants import C

    # Make sure we are testing with color enabled
    C.ANSIBLE_NOCOLOR = False
    C.ANSIBLE_FORCE_COLOR = True

    # Test with color=True
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(fakehost, stats, color=True) == color_output
    stats = dict(failures=1, unreachable=0, changed=0)

# Generated at 2022-06-11 17:51:08.770248
# Unit test for function stringc
def test_stringc():
    # Test color
    str = stringc("Test", "green")
    if sys.version_info >= (3, 0):
        assert str == u"\033[32mTest\033[0m"
    else:
        assert str == u"\033[32mTest\033[0m".encode("utf-8")

    # Test color with background
    str = stringc("Test", "on_green")
    if sys.version_info >= (3, 0):
        assert str == u"\033[42mTest\033[0m"
    else:
        assert str == u"\033[42mTest\033[0m".encode("utf-8")

    # Test special formatting
    str = stringc("Test", "bold")
    if sys.version_info >= (3, 0):
        assert str

# Generated at 2022-06-11 17:51:36.820282
# Unit test for function stringc
def test_stringc():
    colors = {
        'black': '0;30',
        'bright gray': '0;37',
        'blue': '0;34',
        'white': '1;37',
        'green': '0;32',
        'bright blue': '1;34',
        'cyan': '0;36',
        'bright green': '1;32',
        'red': '0;31',
        'bright cyan': '1;36',
        'purple': '0;35',
        'bright red': '1;31',
        'yellow': '0;33',
        'bright purple': '1;35',
        'dark gray': '1;30',
        'bright yellow': '1;33',
        'normal': '0',
    }
    # Disable color support, test should return the same string


# Generated at 2022-06-11 17:51:46.881937
# Unit test for function hostcolor
def test_hostcolor():
    host = dict()
    stats = dict()
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 1
    stats['ok'] = 1
    host['hostname'] = 'localhost'
    assert hostcolor(host['hostname'], stats) == u"\033[32m%-37s\033[0m"
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    stats['ok'] = 1
    assert hostcolor(host['hostname'], stats) == u"\033[32m%-37s\033[0m"
    stats['failures'] = 1
    stats['unreachable'] = 0
    stats['changed'] = 1
    stats['ok'] = 1

# Generated at 2022-06-11 17:51:59.351403
# Unit test for function hostcolor
def test_hostcolor():
    # pylint: disable=W0621
    from ansible.playbook.play_context import PlayContext

    stats = dict(
        ok=0,
        changed=0,
        unreachable=0,
        failed=0,
        skipped=0,
    )

    # no errors
    color = hostcolor('host1', stats)
    if C.ANSIBLE_FORCE_COLOR:
        assert color == u"%-37s" % stringc('host1', C.COLOR_OK)
    else:
        assert color == '%-26s' % ('host1')

    # unreachable
    stats['unreachable'] = 1
    color = hostcolor('host2', stats)
    assert color == u"%-37s" % stringc('host2', C.COLOR_ERROR)

    # failures

# Generated at 2022-06-11 17:52:06.110243
# Unit test for function hostcolor
def test_hostcolor():
    """
    >>> hostcolor('localhost', dict(failures=3, unreachable=0, ok=3, changed=0), False)
    u'localhost               '
    >>> hostcolor('localhost', dict(failures=0, unreachable=0, ok=3, changed=0), False)
    u'localhost               '
    >>> hostcolor('localhost', dict(failures=0, unreachable=0, ok=3, changed=3), False)
    u'localhost               '
    """



# Generated at 2022-06-11 17:52:16.306088
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('hostname', {'skipped': 0, 'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0, 'dark': 0}) == u"hostname"
    assert hostcolor('hostname', {'skipped': 0, 'ok': 0, 'failures': 0, 'unreachable': 0, 'changed': 1, 'dark': 0}) == u"\033[36mhostname\033[0m"
    assert hostcolor('hostname', {'skipped': 0, 'ok': 0, 'failures': 1, 'unreachable': 0, 'changed': 0, 'dark': 0}) == u"\033[31mhostname\033[0m"

# Generated at 2022-06-11 17:52:26.698843
# Unit test for function hostcolor
def test_hostcolor():
    _hostcolor = hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0, 'ok': 0}, True)
    assert _hostcolor == stringc('host', 'red')

    _hostcolor = hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0, 'ok': 0}, True)
    assert _hostcolor == stringc('host', 'red')

    _hostcolor = hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1, 'ok': 0}, True)
    assert _hostcolor == stringc('host', 'yellow')

    _hostcolor = hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 1}, True)

# Generated at 2022-06-11 17:52:35.283738
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'blue', 'yellow',
              'default_color',
              'rgb254', 'rgb038', 'rgb123', 'rgb222', 'rgb050',
              'gray01', 'gray05', 'gray10', 'gray15', 'gray20', 'gray23', 'gray27', 'gray30',
              'gray33', 'gray37', 'gray40', 'gray43', 'gray47', 'gray50', 'gray54', 'gray60',
              'gray66', 'gray70', 'gray73', 'gray77', 'gray80', 'gray83', 'gray85', 'gray90'
              ):
        assert colorize('ok', 0, c), "%s: Failed zero color test" % c

# Generated at 2022-06-11 17:52:42.466103
# Unit test for function hostcolor
def test_hostcolor():
    # Test the function with color True
    assert hostcolor('foo', dict(failures=5, unreachable=0, changed=0)) == u'\x1b[31mfoo                         \x1b[0m'
    assert hostcolor('foo', dict(failures=0, unreachable=5, changed=0)) == u'\x1b[31mfoo                         \x1b[0m'
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=5)) == u'\x1b[33mfoo                         \x1b[0m'
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u'\x1b[32mfoo                         \x1b[0m'

# Generated at 2022-06-11 17:52:48.548400
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    # Test named colors
    assert stringc("text", u"black") == "\033[30mtext\033[0m"
    assert stringc("text", u"red") == "\033[31mtext\033[0m"
    assert stringc("text", u"green") == "\033[32mtext\033[0m"
    assert stringc("text", u"yellow") == "\033[33mtext\033[0m"
    assert stringc("text", u"blue") == "\033[34mtext\033[0m"
    assert stringc("text", u"magenta") == "\033[35mtext\033[0m"
    assert stringc("text", u"cyan") == "\033[36mtext\033[0m"

# Generated at 2022-06-11 17:52:57.350318
# Unit test for function stringc
def test_stringc():
    print(stringc("This is red", "RED"))
    print(stringc("This is red, but not with a real color", "not_a_real_color"))
    print(stringc("This is bold", "BOLD"))
    print(stringc("This is BLINK", "BLINK"))
    print(stringc("This is underline", "UNDERLINE"))
    print(stringc("This is BLACK", "BLACK"))
    print(stringc("This is dark gray", "DARKGRAY"))
    print(stringc("This is red", "LIGHTRED"))
    print(stringc("This is light green", "LIGHTGREEN"))
    print(stringc("This is YELLOW", "YELLOW"))
    print(stringc("This is BLUE", "BLUE"))

# Generated at 2022-06-11 17:53:44.140671
# Unit test for function hostcolor
def test_hostcolor():
    stat = dict()

    stat['done'] = 1
    stat['changed'] = 0
    stat['failures'] = 0
    stat['unreachable'] = 0
    assert hostcolor('host1', stat) == 'host1                 '

    stat['done'] = 1
    stat['changed'] = 1
    stat['failures'] = 0
    stat['unreachable'] = 0
    assert hostcolor('host2', stat) == 'host2                 '

    stat['done'] = 1
    stat['changed'] = 0
    stat['failures'] = 1
    stat['unreachable'] = 0
    assert hostcolor('host3', stat) == 'host3                 '

    stat['done'] = 1
    stat['changed'] = 0
    stat['failures'] = 0
    stat['unreachable'] = 1

# Generated at 2022-06-11 17:53:53.193413
# Unit test for function stringc

# Generated at 2022-06-11 17:54:00.605058
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = []
    stats.append({'failures': 0,
                  'unreachable': 0,
                  'changed': 0})
    stats.append({'failures': 1,
                  'unreachable': 0,
                  'changed': 0})
    stats.append({'failures': 0,
                  'unreachable': 1,
                  'changed': 0})
    stats.append({'failures': 0,
                  'unreachable': 0,
                  'changed': 1})
    stats.append({'failures': 1,
                  'unreachable': 1,
                  'changed': 0})
    stats.append({'failures': 1,
                  'unreachable': 0,
                  'changed': 1})

# Generated at 2022-06-11 17:54:09.143632
# Unit test for function stringc

# Generated at 2022-06-11 17:54:21.189446
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc

    This is a simple unit test for the stringc function.
    """

    def test_stringc_color(color, target):
        testcase = stringc("Testing", color)
        if target not in testcase:
            return False
        return True

    assert test_stringc_color("black", "30;")
    assert test_stringc_color("red", "31;")
    assert test_stringc_color("green", "32;")
    assert test_stringc_color("yellow", "33;")
    assert test_stringc_color("blue", "34;")
    assert test_stringc_color("magenta", "35;")
    assert test_stringc_color("cyan", "36;")
    assert test_stringc_color("white", "37;")


# Generated at 2022-06-11 17:54:32.776663
# Unit test for function stringc

# Generated at 2022-06-11 17:54:36.329135
# Unit test for function colorize
def test_colorize():
    assert colorize(u'foo', 0, 'red') == u'foo=0   '
    assert colorize(u'foo', 10, 'red') == u'foo=10  '
    assert colorize(u'foo', 100, 'red') == u'foo=100 '
    assert colorize(u'foo', 1000, 'red') == u'foo=1000'

# Test for function stringc

# Generated at 2022-06-11 17:54:41.556109
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo'
    stats = {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 0}
    assert(hostcolor(host, stats) == u"%-26s" % host)
    stats['changed'] = 1
    assert(hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_CHANGED))
    stats['changed'] = 0
    stats['failures'] = 1
    assert(hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR))



# Generated at 2022-06-11 17:54:52.355728
# Unit test for function stringc
def test_stringc():
    assert u"\033[35m\033[0m" == stringc(u'', 'purple')
    assert u"\033[35m\033[0m" == stringc(u' ', 'purple')
    assert u"\033[35mTEXT\033[0m" == stringc(u'TEXT', 'purple')
    assert u"\033[35mTEXT\033[0m" == stringc(u'TEXT ', 'purple')
    assert u"\033[35mTE\033[0mXT" == stringc(u'TE XT', 'purple')
    assert u"\033[35mTE\033[0m \033[35mXT\033[0m" == stringc(u'TE XT', 'purple', wrap_nonvisible_chars=True)