

# Generated at 2022-06-11 17:45:10.100866
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'blue', True) == u'\001\033[34m\002foo\001\033[0m\002'
    assert stringc('foo', 'rgb123') == u'\033[38;5;65mfoo\033[0m'
    assert stringc('foo', 'rgb111') == u'\033[38;5;116mfoo\033[0m'
    assert stringc('foo', 'gray3') == u'\033[38;5;243mfoo\033[0m'
    assert stringc('foo', 'color254') == u'\033[38;5;254mfoo\033[0m'

# Generated at 2022-06-11 17:45:21.093250
# Unit test for function stringc
def test_stringc():
    print(u"colors:", [x for x in dir(C) if x.startswith('COLOR') or x.startswith('ANSI')])
    for color in dir(C):
        if color.startswith('COLOR'):
            print(stringc(color, getattr(C, color)))
    sys.stdout.write(stringc(u'\u00A7', 'black', wrap_nonvisible_chars=True))
    sys.stdout.write(u'\n')
    assert stringc(u'\u001b\u001b', 'black', wrap_nonvisible_chars=True) == u'\u001b\u001b'
    assert stringc(u'\u001b\u001b', 'black') == u'\u001b\u001b'

# Generated at 2022-06-11 17:45:33.552462
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == C.COLOR_CODES['red']
    assert parsecolor('rgb255255255') == C.COLOR_CODES['rgb255255255']
    assert parsecolor('rgb255225525') == C.COLOR_CODES['rgb255225525']
    assert parsecolor('rgb025502550') == C.COLOR_CODES['rgb025502550']
    assert parsecolor('rgb025525500') == C.COLOR_CODES['rgb025525500']
    assert parsecolor('gray252') == C.COLOR_CODES['gray252']
    assert parsecolor('gray22') == C.COLOR_CODES['gray22']
    assert parsecolor('gray2') == C.COLOR_CODES

# Generated at 2022-06-11 17:45:43.308109
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(None) == '39'
    assert parsecolor('') == '39'

    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'

    assert parsecolor('default') == '39'
    assert parsecolor('darkgray') == '90'
    assert parsecolor('lightgray') == '37'

    assert parsecolor('color0') == '30'

# Generated at 2022-06-11 17:45:52.171080
# Unit test for function stringc
def test_stringc():
    from ansible.compat.six import string_types
    assert isinstance(stringc(u"test", u"black"), string_types)
    assert isinstance(stringc(u"test", u"rgb255255255"), string_types)
    assert isinstance(stringc(u"test", u"gray10"), string_types)
    assert isinstance(stringc(u"test", u"warn"), string_types)
    assert stringc(u"test", u"black") == u'\033[30mtest\033[0m'
    assert stringc(u"test", u"rgb255255255", wrap_nonvisible_chars=True) == u'\001\033[38;5;15m\002test\001\033[0m\002'

# Generated at 2022-06-11 17:45:57.354313
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'changed': 0, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}, color=True) == '\x1b[0;32mlocalhost               \x1b[0m'


# --- end "pretty"



# Generated at 2022-06-11 17:46:08.515847
# Unit test for function stringc
def test_stringc():
    """Test method for function stringc"""
    from ansible.utils import py3compat

    def test(text, color, wrap_nonvisible_chars=False, expected=None):
        expected = expected if expected is not None else text
        text = py3compat.unicode_to_bytes(text)
        color = py3compat.unicode_to_bytes(color)
        expected = py3compat.unicode_to_bytes(expected)
        result = py3compat.unicode_to_bytes(stringc(text, color, wrap_nonvisible_chars=wrap_nonvisible_chars))

        assert result == expected

    # When ANSIBLE_COLOR is disabled, the 'text' value won't change.
    ANSIBLE_COLOR = False

# Generated at 2022-06-11 17:46:21.085352
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('blue') == '34'
    assert parsecolor('black') == '30'
    assert parsecolor('red', True) == '31'
    assert parsecolor('blue', True) == '34'
    assert parsecolor('black', True) == '30'
    assert parsecolor('lightred') == '1;31'
    assert parsecolor('lightblue') == '1;34'
    assert parsecolor('lightblack') == '1;30'
    assert parsecolor('lightgreen') == '1;32'
    assert parsecolor('lightcyan') == '1;36'
    assert parsecolor('lightred', True) == '1;31'

# Generated at 2022-06-11 17:46:29.213109
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('bar', 'green') == u"\033[32mbar\033[0m"
    assert stringc('baz', 'blue') == u"\033[34mbaz\033[0m"
    assert stringc('foo', 'yellow') == u"\033[33mfoo\033[0m"
    assert stringc('bar', 'pink') == u"\033[35mbar\033[0m"
    assert stringc('baz', 'cyan') == u"\033[36mbaz\033[0m"



# Generated at 2022-06-11 17:46:32.729862
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"foobar\nfoobar\nfoobar", {'failures': 0, 'unreachable': 0, 'changed': 0}, False) == u'foobar\nfoobar\nfoobar          '



# Generated at 2022-06-11 17:46:48.441186
# Unit test for function colorize
def test_colorize():

    if ANSIBLE_COLOR:
        assert colorize(u"foo", 0, u'blue') == u'foo=0   '
        assert colorize(u"foo", 1, u'blue') == u'\033[94mfoo=1   \033[0m'
        assert colorize(u"bar", 100, u'green') == u'\033[92mbar=100 \033[0m'
        assert colorize(u"far", 10, u'red') == u'\033[91mfar=10  \033[0m'
    else:
        assert colorize(u"foo", 0, u'blue') == u'foo=0   '
        assert colorize(u"foo", 1, u'blue') == u'foo=1   '

# Generated at 2022-06-11 17:46:54.023717
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, C.COLOR_OK) == 'ok=0   '
    assert colorize('changed', 0, C.COLOR_CHANGED) == 'changed=0   '
    assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == 'unreachable=0   '
    assert colorize('failed', 0, C.COLOR_ERROR) == 'failed=0   '

# Generated at 2022-06-11 17:46:58.995817
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=1, failures=0, ok=0, skipped=0, unreachable=0)
    color = 'yellow'
    host = 'host'
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, color)



# Generated at 2022-06-11 17:47:09.584446
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    if ANSIBLE_COLOR:
        assert u"\033[%smfoo\033[0m" % parsecolor('red') == stringc(u'foo', u'red')
        assert u"\033[%smfoo\033[0m" % parsecolor('blue') == stringc(u'foo', u'blue')
        assert u"\033[%smfoo\033[0m" % parsecolor('green') == stringc(u'foo', u'green')
        assert u"\033[%smfoo\033[0m" % parsecolor('yellow') == stringc(u'foo', u'yellow')

# Generated at 2022-06-11 17:47:18.310983
# Unit test for function stringc
def test_stringc():
    s = "this is a test"
    if sys.platform.startswith('win'):
        assert stringc(s, 'cyan') == s
    else:
        assert stringc(s, 'cyan') == "\033[36mthis is a test\033[0m"
    assert stringc(s, 'white', True) == "\001\033[37m\002this is a test\001\033[0m\002"
    assert stringc(s, 'color100') == "\033[38;5;100mthis is a test\033[0m"
    assert stringc(s, 'rgb102') == "\033[38;5;102mthis is a test\033[0m"



# Generated at 2022-06-11 17:47:29.770281
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(skipped=0, ok=4, failures=1, unreachable=0, changed=3)
    assert hostcolor('foo', stats, True) == '\x1b[0;32mfoo\x1b[0m             '
    stats = dict(skipped=0, ok=4, failures=0, unreachable=1, changed=3)
    assert hostcolor('foo', stats, True) == '\x1b[0;31mfoo\x1b[0m             '
    stats = dict(skipped=0, ok=3, failures=0, unreachable=0, changed=3)
    assert hostcolor('foo', stats, True) == '\x1b[0;33mfoo\x1b[0m             '

# Generated at 2022-06-11 17:47:42.156422
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return

    print(u"black: ", end=u"")
    print(stringc(u"This is black.", u'black'))

    print(u"red: ", end=u"")
    print(stringc(u"This is red.", u'red'))

    print(u"green: ", end=u"")
    print(stringc(u"This is green.", u'green'))

    print(u"yellow: ", end=u"")
    print(stringc(u"This is yellow.", u'yellow'))

    print(u"blue: ", end=u"")
    print(stringc(u"This is blue.", u'blue'))

    print(u"magenta: ", end=u"")

# Generated at 2022-06-11 17:47:50.236780
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc(u"foo", color="yellow") == u"\033[33mfoo\033[0m"
        assert stringc(u"foo", color="0") == u"\033[38;5;0mfoo\033[0m"
        assert stringc(u"foo", color="rgb255255255") == u"\033[38;5;15mfoo\033[0m"
        assert stringc(u"foo", color="rgb000255000") == u"\033[38;5;2mfoo\033[0m"
        assert stringc(u"foo", color="rgb0000000") == u"\033[38;5;0mfoo\033[0m"
        assert stringc(u"foo", color="rgb100100100") == u

# Generated at 2022-06-11 17:47:58.931191
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'localhost', dict(changed=0, unreachable=0,
                                        failures=0)) == u'%-37s' % 'localhost'
    assert hostcolor(u'localhost', dict(changed=0, unreachable=0,
                                        failures=2)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor(u'localhost', dict(changed=3, unreachable=0,
                                        failures=0)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor(u'localhost', dict(changed=0, unreachable=2,
                                        failures=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-11 17:48:09.393036
# Unit test for function stringc
def test_stringc():
    """Unit test for stringc"""
    assert stringc("test", "debug") == '\033[0;37mtest\033[0m'
    assert stringc("test", "black", True) == '\001\033[30m\002test\001\033[0m\002'
    assert stringc("test", "color15") == '\033[38;5;15mtest\033[0m'
    assert stringc("test", "rgb123") == '\033[38;5;18mtest\033[0m'
    assert stringc("test", "gray7") == '\033[38;5;249mtest\033[0m'
    assert stringc("test", "bad-color") == '\033[0;37mtest\033[0m'



# Generated at 2022-06-11 17:48:28.789305
# Unit test for function colorize
def test_colorize():
    # Note that this test won't pass unless ANSIBLE_COLOR is True
    assert colorize(u'ok', 0, C.COLOR_OK) == stringc(u'ok=0', C.COLOR_OK)
    assert colorize(u'changed', 0, C.COLOR_CHANGED) == stringc(u'changed=0', C.COLOR_CHANGED)
    assert colorize(u'failed', 0, C.COLOR_ERROR) == stringc(u'failed=0', C.COLOR_ERROR)

    assert colorize(u'ok', 123, C.COLOR_OK) == stringc(u'ok=123', C.COLOR_OK)
    assert colorize(u'changed', 123, C.COLOR_CHANGED) == stringc(u'changed=123', C.COLOR_CHANGED)
    assert color

# Generated at 2022-06-11 17:48:36.363279
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == 'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=1)) == 'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=1)) == 'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == 'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=0)) == 'localhost                     '



# Generated at 2022-06-11 17:48:46.178945
# Unit test for function stringc
def test_stringc():
    from ansible.utils import common
    from ansible.utils import plugins

    def __load_module(path):
        return plugins.module_finder._load_from_file(path)

    ANSIBLE_COLOR = True
    C.COLOR_OK = "green"
    C.COLOR_CHANGED = "yellow"
    C.COLOR_SKIP = "cyan"
    C.COLOR_UNREACHABLE = "red"
    C.COLOR_ERROR = "red"
    C.COLOR_WARN = "purple"
    C.COLOR_DEPRECATE = "purple"

    test_class = type(common.AnsibleModule)
    test_class.load_module = __load_module

# Generated at 2022-06-11 17:48:51.231085
# Unit test for function stringc
def test_stringc():
    from ansible.callbacks import display
    display.display(stringc('asdf', 'red'))
    display.display(stringc('asdf', 'blue'))
    display.display(stringc('asdf', '1'))
    display.display(stringc('asdf', 'green'))
    display.display(stringc('asdf', 'rgb220'))
    display.display(stringc('asdf', 'rgb250'))
    display.display(stringc('asdf', 'rgb255'))
    display.display(stringc('asdf', 'rgb255', wrap_nonvisible_chars=True))



# Generated at 2022-06-11 17:48:53.949354
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, 'black') == "foo=0   "
    assert colorize(u"bar", 1, 'green') == stringc("bar=1   ", 'green')


# Generated at 2022-06-11 17:49:05.346854
# Unit test for function stringc
def test_stringc():
    t = stringc("text", "red")
    assert t == '\x1b[31mtext\x1b[0m'
    t = stringc("text", "blue")
    assert t == '\x1b[34mtext\x1b[0m'
    t = stringc("text", "rgb255255255")
    assert t == '\x1b[38;5;15mtext\x1b[0m'
    t = stringc("text", "rgb0255255")
    assert t == '\x1b[38;5;6mtext\x1b[0m'
    t = stringc("text", "rgb25525511")
    assert t == '\x1b[38;5;11mtext\x1b[0m'
    t = stringc

# Generated at 2022-06-11 17:49:13.930743
# Unit test for function hostcolor
def test_hostcolor():
    """Test the hostcolor function."""
    from ansible.compat.tests import unittest
    host = u"localhost"
    stats = {'ok': 0, 'failures': 0, 'changed': 0, 'skipped': 0,
             'unreachable': 0}
    # Default: False
    result = hostcolor(host, stats, False)
    expected = u"%-26s" % host
    assert result == expected
    # Basic test (same result as default)
    result = hostcolor(host, stats, True)
    assert result.startswith(u"\033[")
    assert result.endswith(u"\033[0m")
    # Testing color_error
    error_color = C.COLOR_ERROR
    stats['failures'] = 1

# Generated at 2022-06-11 17:49:23.166418
# Unit test for function hostcolor
def test_hostcolor():
    hcol = hostcolor('testhost', dict(changed=0, failures=0, unreachable=0))
    assert hcol == u"testhost                  "
    hcol = hostcolor('testhost', dict(changed=0, failures=0, unreachable=1))
    assert hcol == u"testhost                  "
    hcol = hostcolor('testhost', dict(changed=0, failures=1, unreachable=0))
    assert hcol == u"testhost                  "
    hcol = hostcolor('testhost', dict(changed=1, failures=0, unreachable=0))
    assert hcol == u"testhost                  "



# Generated at 2022-06-11 17:49:33.619332
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    assert hostcolor(host, {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == stringc('%-26s' % host, 'green')
    assert hostcolor(host, {'failures': 0, 'unreachable': 0, 'changed': 1}, True) == stringc('%-26s' % host, 'yellow')
    assert hostcolor(host, {'failures': 0, 'unreachable': 1, 'changed': 0}, True) == stringc('%-26s' % host, 'red')
    assert hostcolor(host, {'failures': 1, 'unreachable': 0, 'changed': 0}, True) == stringc('%-26s' % host, 'red')

# Generated at 2022-06-11 17:49:40.119065
# Unit test for function stringc
def test_stringc():
    from ansible.utils.color import stringc
    from ansible.utils.color import parsecolor
    # non-empty string (grey on black)
    assert stringc('foo', 'grey') == u'\033[38;5;250mfoo\033[0m'
    # empty string (grey on black)
    assert stringc('', 'grey') == u'\033[38;5;250m\033[0m'



# Generated at 2022-06-11 17:49:57.244784
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'host1                          '
    assert hostcolor('host1', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'host1                          '
    assert hostcolor('host1', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'host1                          '
    assert hostcolor('host1', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'host1                          '



# Generated at 2022-06-11 17:50:00.508970
# Unit test for function colorize
def test_colorize():
    c1 = colorize(u'foo', 456, u'blue')
    assert c1 == u'foo=456'

    c2 = colorize(u'bar', 0, u'blue')
    assert c2 == u'bar=0'


# Generated at 2022-06-11 17:50:07.556179
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('rgb24242') == u'38;5;172'
    assert parsecolor('gray7') == u'38;5;239'
    try:
        parsecolor('bogus')
        raise Exception('Failed to detect bogus color name')
    except:
        pass


# Generated at 2022-06-11 17:50:19.069909
# Unit test for function colorize
def test_colorize():
    assert colorize('test', 'OK', 'green') == u'test=OK  '
    assert colorize('test', 'FAILED', 'red') == u'test=FAILED'
    assert colorize('test', 'CHANGED', 'yellow') == u'test=CHANGED'
    assert colorize('test', 'UNREACHABLE', 'red') == u'test=UNREACHABLE'
    assert colorize('test', 'RUNNING', None) == u'test=RUNNING'
    assert colorize('test', 'PENDING', None) == u'test=PENDING'
    assert colorize('test', 'SKIPPED', None) == u'test=SKIPPED'

# --- end pretty

# =========================================
# Display functions for different outputs
#

# Display a colorized header if

# Generated at 2022-06-11 17:50:22.922428
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=1)) == "localhost               "
    assert hostcolor("localhost", dict(failures=0)) == "localhost               "
    assert hostcolor("localhost", dict(changed=1)) == "localhost               "
    assert hostcolor("localhost", dict(changed=0)) == "localhost               "



# Generated at 2022-06-11 17:50:32.413413
# Unit test for function hostcolor
def test_hostcolor():
    assert (hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) ==
            u"%-37s" % stringc('localhost', C.COLOR_OK))
    assert (hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) ==
            u"%-37s" % stringc('localhost', C.COLOR_ERROR))
    assert (hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) ==
            u"%-37s" % stringc('localhost', C.COLOR_ERROR))
    assert (hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) ==
            u"%-37s" % stringc('localhost', C.COLOR_CHANGED))


# Generated at 2022-06-11 17:50:41.055696
# Unit test for function colorize
def test_colorize():
    """
    %prog [color] [lead] [num]

    %prog green rc 4
    rc=4
    %prog green rc 104
    rc=104
    %prog green rc 0
    rc=0
    """
    import os
    os.environ['ANSIBLE_FORCE_COLOR'] = "True"
    color = 'green'
    lead = 'rc'
    num = 4
    print(colorize(lead, num, color))
    num = 104
    print(colorize(lead, num, color))
    num = 0
    print(colorize(lead, num, color))

if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-11 17:50:46.406050
# Unit test for function hostcolor
def test_hostcolor():
    host = u"test1.example.org"
    stats = {
        'changed':    0,
        'failures':   0,
        'ok':         0,
        'skipped':    0,
        'unreachable':0,
        }
    print(hostcolor(host, stats, True))
# --- end "pretty"



# Generated at 2022-06-11 17:50:54.548724
# Unit test for function hostcolor
def test_hostcolor():
    # Test for red color (failed or unreachable)
    stats = dict(ok=10, changed=0, failures=1, unreachable=0)
    assert C.COLOR_OK not in hostcolor("localhost", stats)
    assert C.COLOR_CHANGED not in hostcolor("localhost", stats)
    assert C.COLOR_ERROR in hostcolor("localhost", stats)
    stats = dict(ok=10, changed=0, failures=0, unreachable=1)
    assert C.COLOR_OK not in hostcolor("localhost", stats)
    assert C.COLOR_CHANGED not in hostcolor("localhost", stats)
    assert C.COLOR_ERROR in hostcolor("localhost", stats)
    # Test for green color (ok)
    stats = dict(ok=10, changed=0, failures=0, unreachable=0)
    assert C

# Generated at 2022-06-11 17:50:57.554616
# Unit test for function colorize
def test_colorize():
    """Colorize: print 'foo' = 'bar' in 'baz' """
    print(colorize(u'foo', u'bar', u'baz'))



# Generated at 2022-06-11 17:51:16.628544
# Unit test for function stringc
def test_stringc():  # pragma: no cover
    class args:
        def __init__(self, color):
            self.color = color

    # These tests are automatically skipped when the terminal
    # does not support color, or when --no-color is specified
    # on the command line.

    # Print a string in black
    print(stringc("This is black", "black"))

    # Print a string in red
    print(stringc("This is red", "red"))

    # Print a string in green
    print(stringc("This is green", "green"))

    # Print a string in yellow
    print(stringc("This is yellow", "yellow"))

    # Print a string in blue
    print(stringc("This is blue", "blue"))

    # Print a string in purple
    print(stringc("This is purple", "purple"))

   

# Generated at 2022-06-11 17:51:22.399196
# Unit test for function stringc
def test_stringc():
    test_str = 'This is a test string'

    if parsecolor('default') != u'':
        print(u"Failed: default does not equal empty string")
        return 1

    if parsecolor('black') != u'30':
        print(u"Failed: black does not equal 30")
        return 1

    if parsecolor('red') != u'31':
        print(u"Failed: red does not equal 31")
        return 1

    if parsecolor('green') != u'32':
        print(u"Failed: green does not equal 32")
        return 1

    if parsecolor('yellow') != u'33':
        print(u"Failed: yellow does not equal 33")
        return 1


# Generated at 2022-06-11 17:51:33.549195
# Unit test for function colorize
def test_colorize():
    """Just a simple function to test colorize"""

    def colorize_tester(x, y, z):
        """A helper for the test_colorize() test"""
        if colorize(x, y, z) == stringc('%s=%-4s' % (x, str(y)), z):
            print('ok')
        else:
            print('failed')

    print('Testing colorize():')
    colorize_tester('ok', 0, 'green')
    colorize_tester('changed', 1234, 'yellow')
    colorize_tester('skipped', 10, 'cyan')
    colorize_tester('unreachable', 2, 'red')
    colorize_tester('failed', 0, 'red')
    colorize_tester('failed', 1, 'red')


# Generated at 2022-06-11 17:51:44.367633
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'ok': 1, 'failures': 0, 'unreachable': 0, 'skipped': 0, 'changed': 0}
    assert hostcolor("test", stats) == u"\033[32mtest\033[0m                  "
    stats = {'ok': 0, 'failures': 0, 'unreachable': 1, 'skipped': 0, 'changed': 0}
    assert hostcolor("test", stats, True) == u"\033[31mtest\033[0m                  "
    stats = {'ok': 0, 'failures': 1, 'unreachable': 0, 'skipped': 0, 'changed': 0}
    assert hostcolor("test", stats, True) == u"\033[31mtest\033[0m                  "

# Generated at 2022-06-11 17:51:51.814716
# Unit test for function hostcolor
def test_hostcolor():

    assert hostcolor("server1", dict(changed=0, failures=0, unreachable=0)) == u"%-37s" % stringc("server1", C.COLOR_OK)
    assert hostcolor("server2", dict(changed=1, failures=0, unreachable=0)) == u"%-37s" % stringc("server2", C.COLOR_CHANGED)
    assert hostcolor("server3", dict(changed=0, failures=0, unreachable=2)) == u"%-37s" % stringc("server3", C.COLOR_ERROR)
    assert hostcolor("server4", dict(changed=0, failures=3, unreachable=0)) == u"%-37s" % stringc("server4", C.COLOR_ERROR)

# --- end "pretty"

# ----- BEGIN lib/ansible/module_utils

# Generated at 2022-06-11 17:51:59.309763
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("myhost", {"failures": 0, "unreachable": 0, "changed": 0}) == "myhost                  "
    assert hostcolor("myhost", {"failures": 1, "unreachable": 0, "changed": 0}, color=False) == "myhost                  "
    assert hostcolor("myhost", {"failures": 0, "unreachable": 1, "changed": 0}) == "myhost                  "
    assert hostcolor("myhost", {"failures": 0, "unreachable": 0, "changed": 1}) == "myhost                  "



# Generated at 2022-06-11 17:52:10.537340
# Unit test for function hostcolor
def test_hostcolor():
    # setup for test
    # create a test stats
    stats = {}
    stats['changed'] = 1
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['ok'] = 0

    # create a test host
    host = 'example.org'

    # test colorize with all hosts changed
    assert hostcolor(host, stats) == u'\x1b[0;36;49m%-37s\x1b[0m' % 'example.org'

    # test colorize with only one host changed
    stats['changed'] = 0
    assert hostcolor(host, stats) == u'\x1b[0;32;49m%-37s\x1b[0m' % 'example.org'

    # test colorize with all hosts unreachable

# Generated at 2022-06-11 17:52:18.392512
# Unit test for function hostcolor
def test_hostcolor():
    ''' hostcolor() returns strings that are colored based on the state of the host '''
    color_codes = C.COLOR_CODES

# Generated at 2022-06-11 17:52:27.915046
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("myhost", {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}, True) == u'\033[90mmyhost\033[0m                 '
    assert hostcolor("myhost", {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}, True) == u'\033[32mmyhost\033[0m                 '
    assert hostcolor("myhost", {'changed': 0, 'failures': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}, True) == u'\033[31mmyhost\033[0m                 '

# Generated at 2022-06-11 17:52:34.264766
# Unit test for function parsecolor
def test_parsecolor():
    import ansible.constants as C
    for color in C.COLOR_CODES:
        parse_color = parsecolor(color)
        a=stringc(color, color, True)
        # FIXME: Hack to get rid of the escape sequence from terminal
        b=stringc(color, color, True).replace(u'\x1b', u'')
        if parse_color != C.COLOR_CODES[color]:
            print(u"%s:%s:%s" % (a, b, C.COLOR_CODES[color]))
#
# --- end "pretty"

# vim: set noexpandtab:

# Generated at 2022-06-11 17:52:44.941439
# Unit test for function stringc
def test_stringc():
    print(stringc("test text", "red", wrap_nonvisible_chars=True))



# Generated at 2022-06-11 17:52:54.373990
# Unit test for function hostcolor
def test_hostcolor():
    # Testing both color and non-color mode
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=False) == '%-26s' % 'localhost'

    assert hostcolor('localhost', stats, color=True) == '%-37s' % 'localhost'
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), color=True) \
        == '%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), color=True) \
        == '%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-11 17:53:05.403461
# Unit test for function hostcolor
def test_hostcolor():

    host = 'host'
    stats_success = dict(changed=0, unreachable=0, failed=0)
    stats_changed = dict(changed=1, unreachable=0, failed=0)
    stats_failure = dict(changed=0, unreachable=0, failed=1)
    stats_both = dict(changed=1, unreachable=0, failed=1)

    for stats in [stats_success, stats_changed, stats_failure, stats_both]:
        colorized_host = hostcolor(host, stats, color=False)
        assert host == colorized_host

    for stats in [stats_success, stats_changed]:
        colorized_host = hostcolor(host, stats, color=True)
        assert (u'%-37s' % host) == colorized_host


# Generated at 2022-06-11 17:53:16.498168
# Unit test for function colorize
def test_colorize():
    def colortest(lead, num, color, result):
        if colorize(lead, num, color) != result:
            print("colorize(%s, %s, %s) != %s" % (lead, str(num), color, result))
    colortest("x", 0, "blue", "x=0   ")
    colortest("x", 0, None, "x=0   ")
    colortest("x", 1, "blue", "x=1   ")
    colortest("x", 2, "blue", "x=2   ")
    colortest("x", 10, "blue", "x=10  ")
    colortest("x", 100, "blue", "x=100 ")
    colortest("y", 123, None, "y=123 ")
   

# Generated at 2022-06-11 17:53:23.229018
# Unit test for function hostcolor
def test_hostcolor():
    teststats = dict()
    testhost = 'host'
    teststats['failures'] = 0
    teststats['unreachable'] = 0
    teststats['changed'] = 0
    assert hostcolor(testhost, teststats, color=True) == "%-37s" % stringc(testhost, C.COLOR_OK)
    teststats['failures'] = 1
    assert hostcolor(testhost, teststats, color=True) == "%-37s" % stringc(testhost, C.COLOR_ERROR)
    teststats['failures'] = 0
    teststats['changed'] = 1
    assert hostcolor(testhost, teststats, color=True) == "%-37s" % stringc(testhost, C.COLOR_CHANGED)
    teststats['failures'] = 1
    teststats['unreachable']

# Generated at 2022-06-11 17:53:30.729958
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(
        changed=0,
        failures=0,
        unreachable=0)) == u"foo                         "

    assert hostcolor('foo', dict(
        changed=1,
        failures=0,
        unreachable=0)) == u"foo                         "

    assert hostcolor('foo', dict(
        changed=0,
        failures=1,
        unreachable=0)) == u"foo                         "

    assert hostcolor('foo', dict(
        changed=0,
        failures=0,
        unreachable=1)) == u"foo                         "

# Test for function colorize

# Generated at 2022-06-11 17:53:34.788762
# Unit test for function stringc
def test_stringc():
    assert stringc("\x1b[31mtest - \033[0m",
                   'red', True) == "\x1b[0m\x1b[31mtest - \x1b[0m\x1b[0m"

# Generated at 2022-06-11 17:53:44.937133
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures':1, 'unreachable':0, 'ok': 0, 'changed': 0, 'skipped': 0}
    assert hostcolor(u"host", stats, color=True) == u"\n".join([u"\033[31;01mhost\033[0m        "])
    stats = {'failures':0, 'unreachable':1, 'ok': 0, 'changed': 0, 'skipped': 0}
    assert hostcolor(u"host", stats, color=True) == u"\n".join([u"\033[31;01mhost\033[0m        "])
    stats = {'failures':0, 'unreachable':0, 'ok': 0, 'changed': 1, 'skipped': 0}

# Generated at 2022-06-11 17:53:48.446781
# Unit test for function stringc
def test_stringc():
    print("Testing stringc as a function")
    color = "RED"
    text = "Hello World"
    print("\033[%sm%s\033[0m" % (parsecolor(color), text))
    print(stringc(text, color))

# --- end of "pretty"


# Generated at 2022-06-11 17:53:56.201265
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "red") == '\033[31mtext\033[0m'
    assert stringc("text", "red", wrap_nonvisible_chars=True) == '\001\033[31m\002text\001\033[0m\002'
    assert stringc("text", "rgb17") == '\033[38;5;41mtext\033[0m'
    assert stringc("text", "gray1") == '\033[38;5;235mtext\033[0m'


#
# --- end "pretty"


# Generated at 2022-06-11 17:54:14.802107
# Unit test for function hostcolor
def test_hostcolor():
    '''
    Run a unit test on the hostcolor function
    '''
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
    assert hostcolor(host, stats) == stringc(host, C.COLOR_CHANGED) + u'                                  '
    stats['changed'] = 0
    assert hostcolor(host, stats) == stringc(host, C.COLOR_OK) + u'                                     '
    stats['unreachable'] = 1
    assert hostcolor(host, stats) == stringc(host, C.COLOR_ERROR) + u'                                  '
    stats['unreachable'] = 0
    stats['failures'] = 1
    assert hostcolor(host, stats) == stringc(host, C.COLOR_ERROR) + u'                                  '

# Generated at 2022-06-11 17:54:24.986287
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        import sys
        print(stringc(u"This is a test", u"black", wrap_nonvisible_chars=False))
        print(stringc(u"This is a test", u"black", wrap_nonvisible_chars=True))
        print(stringc(u"This is a test", u"red", wrap_nonvisible_chars=False))
        print(stringc(u"This is a test", u"red", wrap_nonvisible_chars=True))
        print(stringc(u"This is a test", u"green", wrap_nonvisible_chars=False))
        print(stringc(u"This is a test", u"green", wrap_nonvisible_chars=True))

# Generated at 2022-06-11 17:54:35.294029
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat.tests import unittest

    class TestHostColor(unittest.TestCase):

        def setUp(self):
            self.setup_color_tests()

        def tearDown(self):
            self.teardown_color_tests()

        def setup_color_tests(self):
            self._old_ANSIBLE_COLOR = ANSIBLE_COLOR

        def teardown_color_tests(self):
            ANSIBLE_COLOR = self._old_ANSIBLE_COLOR

        def test_colorize(self):
            host = "foo\n"
            stats = {"failures": 10, "changed": 20, "ok": 30, "skipped": 40, "unreachable": 50}
            self.assertEqual(hostcolor(host, stats, False), "%-37s" % host)



# Generated at 2022-06-11 17:54:38.987746
# Unit test for function stringc
def test_stringc():
    """
    >>> test_stringc()
    u'\\u001b[31mERROR\\u001b[0m'

    """
    if ANSIBLE_COLOR:
        return u'\033[31mERROR\033[0m'
    else:
        return u'ERROR'



# Generated at 2022-06-11 17:54:47.548193
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'yellow', 'blue', '0', '1', '2', '3', '4'):
        lead = 'LEAD'
        num = 7
        colored = colorize(lead, num, c)
        if c == '0':
            assert colored == "%s=%-4s" % (lead, str(num))
        else:
            assert colored == "\033[%sm%s=%-4s\033[0m" % (parsecolor(c), lead, str(num))

# http://stackoverflow.com/a/3620972

# Generated at 2022-06-11 17:54:51.942994
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo", dict(failures=1)) == 'foo                    '
    assert hostcolor("bar", dict(changed=1)) == 'bar                    '
    assert hostcolor("baz", dict(ok=1)) == 'baz                    '

# --- end of "pretty" library


# Generated at 2022-06-11 17:54:54.443266
# Unit test for function colorize
def test_colorize():
    assert colorize('test', 0, 'green') == 'test=0   '
    assert colorize('test', 1, 'green') == '\x1b[32mtest=1   \x1b[0m'



# Generated at 2022-06-11 17:55:04.636858
# Unit test for function hostcolor
def test_hostcolor():
    pass
    #assert hostcolor('hostname', {'ok': 1, 'changed': 0, 'unreachable': 0, 'failures': 0}, True) == u'\x1b[0;32mhostname\x1b[0m'
    #assert hostcolor('hostname', {'ok': 0, 'changed': 1, 'unreachable': 0, 'failures': 0}, True) == u'\x1b[0;33mhostname\x1b[0m'
    #assert hostcolor('hostname', {'ok': 0, 'changed': 0, 'unreachable': 1, 'failures': 0}, True) == u'\x1b[0;31mhostname\x1b[0m'
    #assert hostcolor('hostname', {'ok': 0, 'changed': 0, 'un