

# Generated at 2022-06-11 17:45:14.653956
# Unit test for function stringc
def test_stringc():
    """Test stringc"""
    assert parsecolor("blue") == "34"
    assert parsecolor("none") == "39"
    a = u"this is a test"
    assert stringc(a, "blue") == u"\033[34mthis is a test\033[0m"
    assert stringc(a, "bold", wrap_nonvisible_chars=True) == u"\001\033[1m\002this is a test\001\033[0m\002"
    assert stringc(a, "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002this is a test\001\033[0m\002"

# Generated at 2022-06-11 17:45:23.387376
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'34'   # color blue
    assert parsecolor('rgb255') == u'38;5;226'   # rgb alias
    assert parsecolor('rgb255255') == u'38;5;226'   # rgb alias
    assert parsecolor('rgb255255255') == u'38;5;15'   # rgb alias
    assert parsecolor('rgb255,0,0') == u'38;5;196'   # rgb
    assert parsecolor('rgb255,255,0') == u'38;5;226'   # rgb
    assert parsecolor('rgb255,255,255') == u'38;5;15'   # rgb
    assert parsecolor('white') == u'38;5;15'   # gray alias
    assert par

# Generated at 2022-06-11 17:45:35.697359
# Unit test for function hostcolor
def test_hostcolor():
    class Host():
        def __init__(self, name):
            self.name = name
            self.vars = {}
        def get_name(self):
            return self.name

    myhost = Host('myhost')
    myhost.vars = dict(ansible_ssh_host="203.0.113.10",
                       ansible_ssh_port="22")
    stats = dict(changed=0,
                 unreachable=0,
                 failures=0)

# Generated at 2022-06-11 17:45:44.645087
# Unit test for function stringc
def test_stringc():
    # ANSI codes used in this module.  These are copied from
    # http://en.wikipedia.org/wiki/ANSI_escape_code
    #
    # The codes are embedded in strings below because the format
    # string syntax is different between Python 2 and 3, and this
    # makes maintenance easier.

    # Code   Meaning
    BLACK   = 0
    RED     = 1
    GREEN   = 2
    YELLOW  = 3
    BLUE    = 4
    MAGENTA = 5
    CYAN    = 6
    WHITE   = 7
    RESET   = 9

    SGR_CODE_TEMPLATE = u"\033[%d;%d;%dm"

    # Test properties of the `RESET` color code:
    # - should reset to default terminal settings
    # - should be non-empty


# Generated at 2022-06-11 17:45:52.809943
# Unit test for function parsecolor
def test_parsecolor():
    def test(cstr, expected):
        result = parsecolor(cstr)
        assert result == expected
    yield test, 'red', '31'
    yield test, 'black', '30'
    yield test, 'blue', '34'
    yield test, 'on_black', '40'
    yield test, 'on_red', '41'
    yield test, 'on_green', '42'
    yield test, 'on_blue', '44'
    yield test, 'on_yellow', '43'
    yield test, 'on_magenta', '45'
    yield test, 'on_cyan', '46'
    yield test, 'on_white', '47'
    yield test, 'underline', '4'
    yield test, 'bold', '1'

# Generated at 2022-06-11 17:46:02.386762
# Unit test for function hostcolor
def test_hostcolor():
    # Test case: no stats, no color
    p = hostcolor('host1', {}, False)
    assert p == u"%-26s" % 'host1'
    # Test case: stats, color
    p = hostcolor('host1', {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}, True)
    assert p == u"\033[0;32m%-37s\033[0m" % 'host1'
    # Test case: stats, no color
    p = hostcolor('host1', {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}, False)
    assert p == u"%-26s" % 'host1'


# Generated at 2022-06-11 17:46:06.905918
# Unit test for function stringc
def test_stringc():
    prompt = stringc('[root@master ansible]# ', 'green', wrap_nonvisible_chars=True)
    assert prompt == '\001\033[32m\002[root@master ansible]# \001\033[0m\002'



# Generated at 2022-06-11 17:46:19.171768
# Unit test for function hostcolor
def test_hostcolor():
    def _test(host, s, result, expected):
        r = hostcolor(host, s, color=True)
        if r != expected:
            raise AssertionError("hostcolor(%s, %s, color=%s) returned '%s' but expected '%s'" % (host, s, result, r, expected))

    _test('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}, 'ok', 'localhost                    ')
    _test('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}, 'error', '\x1b[31mlocalhost\x1b[0m             ')

# Generated at 2022-06-11 17:46:26.923743
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == u'34'
    assert parsecolor("color32") == u'38;5;32'
    assert parsecolor("rgb255") == u'38;5;231'
    assert parsecolor("rgb2550") == u'38;5;94'
    assert parsecolor("rgb255255255") == u'38;5;15'
    assert parsecolor("gray23") == u'38;5;250'
    assert parsecolor("gray123") == u'38;5;55'
    assert parsecolor("bogus") == C.COLOR_CODES['white']
    assert parsecolor("bogus", default=None) is None

if __name__ == '__main__':
    test_parsecolor()

# Generated at 2022-06-11 17:46:32.518713
# Unit test for function stringc
def test_stringc():
    """
    Test function `stringc'.

    >>> code = parsecolor('red')
    >>> fmt = u'\033[%sm%%s\033[0m' % code
    >>> expected = fmt % u'hello'
    >>> expected == stringc(u'hello', 'red')
    True

    >>> code = parsecolor('gray')
    >>> fmt = u'\033[%sm%%s\033[0m' % code
    >>> expected = fmt % u'hello'
    >>> expected == stringc(u'hello', 'gray')
    True
    """



# Generated at 2022-06-11 17:46:49.187134
# Unit test for function colorize
def test_colorize():
    # the linux command 'tput' is used here to test
    # if the terminal supports the values for color
    red, green, yellow, blue, magenta, cyan, nocolor = u'', u'', u'', u'', u'', u'', u''
    try:
        red = tput("setaf", "1")
    except ValueError:
        pass
    try:
        green = tput("setaf", "2")
    except ValueError:
        pass
    try:
        yellow = tput("setaf", "3")
    except ValueError:
        pass
    try:
        blue = tput("setaf", "4")
    except ValueError:
        pass
    try:
        magenta = tput("setaf", "5")
    except ValueError:
        pass

# Generated at 2022-06-11 17:46:50.998738
# Unit test for function colorize
def test_colorize():
    print("(Foreground should change to red)")
    print("(Foreground should change to red and blink)")

# Generated at 2022-06-11 17:46:57.962913
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor('foo_changed', {'failures': 0, 'unreachable': 0, 'changed': 1}, color=True) == \
            stringc('foo_changed', C.COLOR_CHANGED)
        assert hostcolor('foo_failed', {'failures': 1, 'unreachable': 0, 'changed': 0}, color=True) == \
            stringc('foo_failed', C.COLOR_ERROR)
        assert hostcolor('foo_unreachable', {'failures': 0, 'unreachable': 1, 'changed': 0}, color=True) == \
            stringc('foo_unreachable', C.COLOR_ERROR)

# Generated at 2022-06-11 17:47:01.500587
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, "green") == "foo=0   "
    assert colorize("foo", 0, None) == "foo=0   "
    assert colorize("foo", 4, "green") == stringc("foo=4   ", "green")



# Generated at 2022-06-11 17:47:11.803158
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == "\033[34mfoo\033[0m"
    assert stringc('foo', 'color5') == "\033[38;5;5mfoo\033[0m"
    assert stringc('foo', 'rgb255') == "\033[38;5;231mfoo\033[0m"
    assert stringc('foo', 'rgb555') == "\033[38;5;7mfoo\033[0m"
    assert stringc('foo', 'rgb333') == "\033[38;5;59mfoo\033[0m"
    assert stringc('foo', 'gray2') == "\033[38;5;250mfoo\033[0m"
# -- end "pretty"

# Generated at 2022-06-11 17:47:20.868593
# Unit test for function hostcolor
def test_hostcolor():
    host = u"foo.example.com"
    stats = { 'ok': 1, 'failures': 0, 'changed': 0, 'unreachable': 0 }
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_OK)
    stats = { 'ok': 10, 'failures': 1, 'changed': 0, 'unreachable': 0 }
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = { 'ok': 10, 'failures': 0, 'changed': 1, 'unreachable': 0 }
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_CHANGED)

# Generated at 2022-06-11 17:47:26.017864
# Unit test for function stringc
def test_stringc():
    if 0:
        print(stringc('foo', 'red', True))
        print(stringc('foo', 'red'))
        print(stringc('foo', 'blue', True))
        print(stringc('foo', 'blue'))
# --- end "pretty"

# Generated at 2022-06-11 17:47:33.759721
# Unit test for function hostcolor
def test_hostcolor():
    h = 'foo.example.org'
    s = dict(failures=1, unreachable=0, changed=0)
    result = hostcolor(h, s, True)
    if result == u'foo.example.org           ':
        sys.stderr.write('not ok 1\n')
    else:
        sys.stderr.write('ok 1\n')

    s = dict(failures=0, unreachable=1, changed=0)
    result = hostcolor(h, s, True)
    if result == u'foo.example.org           ':
        sys.stderr.write('not ok 2\n')
    else:
        sys.stderr.write('ok 2\n')

    s = dict(failures=0, unreachable=0, changed=1)
    result

# Generated at 2022-06-11 17:47:38.956219
# Unit test for function stringc
def test_stringc():
    assert stringc('hello', 'red') == "\033[31mhello\033[0m"
    assert stringc('hello', 'blue') == "\033[34mhello\033[0m"
    assert stringc('hello', 'green') == "\033[32mhello\033[0m"



# Generated at 2022-06-11 17:47:46.261942
# Unit test for function hostcolor
def test_hostcolor():
    return

# This is used to test one or more of the colors by name
#
# Usage:
#    print stringc(ALL_COLORS, 'blue')
#    print stringc(ALL_COLORS, 'bold')
#    print stringc(ALL_COLORS, 'lightgray')
ALL_COLORS = u"\n".join([u"%s=%-7s" % (c, c) for c in C.COLOR_CODES])
# --- end "pretty"

# Generated at 2022-06-11 17:47:59.354771
# Unit test for function stringc
def test_stringc():
    test_inputs = [
        #    text                color
        (u"test", u"black", u"test"),
        (u"test", u"red", u"\033[38;5;9mtest\033[0m"),
        (u"test", u"rgb255255255", u"\033[38;5;231mtest\033[0m"),
        (u"test", u"gray99", u"\033[38;5;252mtest\033[0m"),
        (u"test", u"blue", u"\033[38;5;12mtest\033[0m"),
    ]


# Generated at 2022-06-11 17:48:09.746786
# Unit test for function colorize
def test_colorize():
    # check colorize()
    debug_msg = "colorize ok"
    try:
        import ansible.plugins.callback.default
    except ImportError:
        # can't test this unless the callback plugin is already loaded
        debug_msg = "can't test colorize(), callback plugin not loaded"
        pass
    except NameError:
        # can't test this unless the callback plugin is already loaded
        debug_msg = "can't test colorize(), callback plugin not set"
        pass
    else:
        if ansible.plugins.callback.default.display.verbosity < 3:
            # only test colorize if verbosity is >= 3
            debug_msg = "can't test colorize(), verbosity < 3"
            pass
        else:
            s = colorize("ok", 0, C.COLOR_OK)

# Generated at 2022-06-11 17:48:17.722811
# Unit test for function colorize
def test_colorize():
    for color in [u"red", u"normal"]:
        for num in [0, 1]:
            for lead in [u"ok", u"changed", u"failed"]:
                s = colorize(lead, num, color)
                if num == 0 or color == u"normal":
                    assert not s.startswith(u"\x1b[")
                else:
                    assert s.startswith(u"\x1b[")

if __name__ == u"__main__":
    test_colorize()
# --- end "pretty"

# Generated at 2022-06-11 17:48:28.526602
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-11 17:48:37.770858
# Unit test for function hostcolor
def test_hostcolor():
    def test_hostcolor_helper(host, stats, expected_hostcolor):
        if hostcolor(host, stats) != expected_hostcolor:
            raise AssertionError("hostcolor() failed to correctly"
                                 " colorize the host name")
    stats = dict(changed=0, failures=0, unreachable=0)
    test_hostcolor_helper("foo", stats, "%-37s" % "foo")
    # changing host state
    stats['changed'] = 1
    test_hostcolor_helper("foo", stats, "%-37s" % stringc("foo", C.COLOR_CHANGED))
    # moving to failing state
    stats['changed'] = 0
    stats['failures'] = 1

# Generated at 2022-06-11 17:48:43.894311
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = dict(changed=1)
    stats2 = dict(failures=2)
    stats3 = dict(failed=1, unreachable=1)
    stats4 = dict()
    print(hostcolor("hostname1", stats1))
    print(hostcolor("hostname2", stats2))
    print(hostcolor("hostname3", stats3))
    print(hostcolor("hostname4", stats4))



# Generated at 2022-06-11 17:48:50.263016
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        ok=1,
        changed=2,
        unreachable=3,
        failures=4,
    )
    assert hostcolor('foo', stats, False) == "%-26s" % 'foo'
    assert hostcolor('foo', stats, True) == "%-37s" % 'foo'
    assert hostcolor('foo', dict(ok=1), False) == "%-26s" % 'foo'
    assert hostcolor('foo', dict(ok=1), True) == "%-37s" % u"\033[0;32mfoo\033[0m"
    assert hostcolor('foo', dict(changed=1), False) == "%-26s" % 'foo'

# Generated at 2022-06-11 17:48:57.754071
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("testhost", dict(failures=0, unreachable=0, changed=0)) == u"%-37s" % stringc("testhost", C.COLOR_OK)
    assert hostcolor("testhost", dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc("testhost", C.COLOR_ERROR)
    assert hostcolor("testhost", dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc("testhost", C.COLOR_ERROR)
    assert hostcolor("testhost", dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc("testhost", C.COLOR_CHANGED)

# Generated at 2022-06-11 17:49:06.058138
# Unit test for function hostcolor
def test_hostcolor():
    for C in [0, 1]:
        ANSIBLE_COLOR = C
        print((hostcolor('host1', dict(changed=0, failures=0, unreachable=0), color=True),
               hostcolor('host2', dict(changed=1, failures=0, unreachable=0), color=True),
               hostcolor('host3', dict(changed=0, failures=1, unreachable=0), color=True),
               hostcolor('host4', dict(changed=0, failures=0, unreachable=1), color=True)))
# --- end "pretty"



# Generated at 2022-06-11 17:49:12.708610
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        C.COLOR_CHANGED = 'cyan'
        C.COLOR_ERROR = 'red'
        C.COLOR_OK = 'blue'
        assert colorize(u"foo", 0, 'blue') == u"foo=0   "
        assert colorize(u"foo", 1, 'cyan') == u"foo=1   "
        assert colorize(u"foo", 2, 'green') == u"foo=2   "
        assert colorize(u"foo", 3, 'red') == u"foo=3   "
        assert colorize(u"foo", 4, 'yellow') == u"foo=4   "
    else:
        assert colorize(u"foo", 0, None) == u"foo=0   "

# Generated at 2022-06-11 17:49:29.142502
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color9') == '38;5;9'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color11') == '38;5;11'
    assert parsecolor('color12') == '38;5;12'
    assert parsecolor('rgb100') == '38;5;11'
    assert parsecolor('rgb222') == '38;5;58'

# --- end of "pretty" module

ANSIBLE_COLOR = parsecolor(C.DEFAULT_ANSIBLE_COLOR)
ANSI_RESET = u'\033[0m'


# Generated at 2022-06-11 17:49:37.785040
# Unit test for function stringc
def test_stringc():
    assert stringc("Text without a color", None) == "Text without a color"
    assert stringc("Text without a color", "RED") == "\033[31mText without a color\033[0m"
    assert stringc("Text without a color", "COLOR_RED") == "\033[31mText without a color\033[0m"
    assert stringc("Text without a color", "RED", True) == "\001\033[31m\002Text without a color\001\033[0m\002"
    assert stringc("Text without a color", "COLOR_RED", True) == "\001\033[31m\002Text without a color\001\033[0m\002"

# Generated at 2022-06-11 17:49:47.363325
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        sys.stderr.write('\033[1;31mANSIBLE_NOCOLOR set, skipping color test\033[0m\n')
        return
    def run(color_name, black_color, red_color, green_color, yellow_color,
            blue_color, magenta_color, cyan_color, white_color):
        sys.stderr.write('%s\n' % stringc('color_name', color_name))
        sys.stderr.write('%s\n' % stringc('black_color', black_color))
        sys.stderr.write('%s\n' % stringc('red_color', red_color))

# Generated at 2022-06-11 17:49:58.873500
# Unit test for function hostcolor
def test_hostcolor():
    '''
    hostcolor test case
    '''

    host = 'test_host'
    result = {
        'changed': 0,
        'failures': 0,
        'ok': 1,
        'skipped': 0,
        'unreachable': 0
    }
    result_c = hostcolor(host, result, True)
    assert result_c.startswith(u"%-37s" % stringc(host, C.COLOR_OK)),\
        "hostcolor: first test failed"

    result['changed'] = 1
    result_c = hostcolor(host, result)
    assert result_c.startswith(u"%-37s" % stringc(host, C.COLOR_CHANGED)),\
        "hostcolor: second test failed"

    result['failures'] = 1
    result_

# Generated at 2022-06-11 17:50:11.486610
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("color0") == "38;5;0"
    assert parsecolor("color255") == "38;5;255"
    assert parsecolor("color256") == "38;5;16"
    assert parsecolor("color-1") == "38;5;16"
    assert parsecolor("color257") == "38;5;17"
    assert parsecolor("rgb000") == "38;5;0"
    assert parsecolor("rgb111") == "38;5;72"
    assert parsecolor("rgb222") == "38;5;136"
    assert parsecolor("rgb333") == "38;5;142"
    assert parsecolor("rgb444") == "38;5;148"

# Generated at 2022-06-11 17:50:13.566500
# Unit test for function stringc
def test_stringc():
    for color in C.COLOR_CODES:
        yield colorize_ok, color



# Generated at 2022-06-11 17:50:23.091020
# Unit test for function stringc
def test_stringc():
    assert stringc("some text", "blue") == u"\033[0;34msome text\033[0m"
    assert stringc("some text", "blue", True) == u"\001\033[0;34m\002some text\001\033[0m\002"
    assert stringc("some text", "color16") == u"\033[38;5;16msome text\033[0m"
    assert stringc("some text", "rgb255000255") == u"\033[38;5;213msome text\033[0m"
    assert stringc("some text", "gray10") == u"\033[38;5;244msome text\033[0m"

# Generated at 2022-06-11 17:50:32.415809
# Unit test for function stringc
def test_stringc():
   
    s = u"This is normal text"
    assert stringc(s, None) == s

    if ANSIBLE_COLOR:
        s = u"This is red text"
        assert stringc(s, 'red') == u"\033[31m%s\033[0m" % s

        s = u"This is yellow text"
        assert stringc(s, 'yellow') == u"\033[33m%s\033[0m" % s

        s = u"This is red text with invisible characters"
        assert stringc(s, 'red', True) == u"\001\033[31m\002%s\001\033[0m\002" % s

        s = u"This is yellow text with invisible characters"

# Generated at 2022-06-11 17:50:36.020890
# Unit test for function colorize
def test_colorize():
    for i in range(0, 11):
        print(colorize("test", i, "green"), end=' ')
    print(str(''))


# Generated at 2022-06-11 17:50:42.805180
# Unit test for function colorize
def test_colorize():
    """Test function colorize"""
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == \
        u"\033[38;5;12mfoo=1   \033[0m"
    ANSIBLE_COLOR = False
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 0, 'blue') == 'foo=0   '

# Generated at 2022-06-11 17:51:03.678542
# Unit test for function stringc
def test_stringc():
    try:
        import curses
        curses.setupterm()
        if curses.tigetnum('colors') < 0:
            ANSIBLE_COLOR = False
    except ImportError:
        # curses library was not found
        ANSIBLE_COLOR = False
    except curses.error:
        # curses returns an error (e.g. could not find terminal)
        ANSIBLE_COLOR = False

    if ANSIBLE_COLOR:
        return stringc("Testing text for color", "green")
    else:
        return "Testing text for color"


# --- end of "pretty"

# --- begin "unixy"
#
# unixy - A miniature library that provides a Python print and stdout
# wrapper that makes colored terminal text easier to use (e.g. without
# having to mess around with ANSI escape sequences). This

# Generated at 2022-06-11 17:51:15.206095
# Unit test for function stringc
def test_stringc():
    def test(text, color, wrap_nonvisible_chars=False, expected=None):
        actual = stringc(text, color, wrap_nonvisible_chars=wrap_nonvisible_chars)
        print(text.encode('utf-8', 'ignore'))
        if actual is not None:
            print(actual.encode('utf-8', 'ignore'))
        if actual != expected:
            print(actual, 'should be', expected)

    test('test', 'blue', expected='\033[94mtest\033[0m')
    test('test', 'RED', expected='\033[91mtest\033[0m')
    test('test', 'color1', expected='\033[38;5;1mtest\033[0m')

# Generated at 2022-06-11 17:51:23.977877
# Unit test for function stringc
def test_stringc():
    assert stringc("plain") == "plain"
    assert stringc("rgb", "rgb255000255") == u"\033[38;5;45mrgb\033[0m"
    assert stringc("gray", "gray23") == u"\033[38;5;249mgray\033[0m"
    assert stringc("color", "color234") == u"\033[38;5;234mcolor\033[0m"
    assert stringc("plain\ncolored", "red") == u"\033[31mplain\033[0m\n\033[31mcolored\033[0m"

# Generated at 2022-06-11 17:51:35.427347
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor(u"localhost", {"failures": 0, "changed": 0,
                         "unreachable": 0}, True) == u"\033[0;32m%-37s\033[0m"
        assert hostcolor(u"localhost", {"failures": 1, "changed": 0,
                         "unreachable": 0}, True) == u"\033[0;31m%-37s\033[0m"
        assert hostcolor(u"localhost", {"failures": 0, "changed": 1,
                         "unreachable": 0}, True) == u"\033[0;33m%-37s\033[0m"

# Generated at 2022-06-11 17:51:44.558033
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('localhost', {'failures': 0, 'changed': 1, 'unreachable': 0, 'skipped': 3, 'ok': 1}))
    print(hostcolor('localhost', {'failures': 0, 'changed': 0, 'unreachable': 0, 'skipped': 3, 'ok': 1}))
    print(hostcolor('localhost', {'failures': 1, 'changed': 0, 'unreachable': 0, 'skipped': 3, 'ok': 1}))
    print(hostcolor('localhost', {'failures': 0, 'changed': 0, 'unreachable': 1, 'skipped': 3, 'ok': 1}))



# Generated at 2022-06-11 17:51:48.389798
# Unit test for function stringc
def test_stringc():
    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan',
                  'white'):
        print("%s" % stringc("This is a test", color))

if __name__ == "__main__":
    test_stringc()
# --- end "pretty"


# Generated at 2022-06-11 17:52:00.221853
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor("host1", dict(failures=0, unreachable=0, changed=0, ok=1)))
    print(hostcolor("host1", dict(failures=1, unreachable=0, changed=0, ok=0)))
    print(hostcolor("host1", dict(failures=0, unreachable=1, changed=0, ok=0)))
    print(hostcolor("host1", dict(failures=0, unreachable=0, changed=1, ok=0)))
    print(hostcolor("host1", dict(failures=0, unreachable=0, changed=0, ok=0)))
    print(hostcolor("host2", dict(failures=0, unreachable=0, changed=0, ok=0)))

# --- end "pretty"


# Generated at 2022-06-11 17:52:02.644711
# Unit test for function colorize
def test_colorize():
    assert u"test=1" == colorize(u"test", 1, None)
    if ANSIBLE_COLOR:
        assert u"test=1" == colorize(u"test", 1, C.COLOR_ERROR)



# Generated at 2022-06-11 17:52:11.031460
# Unit test for function stringc
def test_stringc():
    sys.stdout.write("Testing function stringc ... ")
    result = stringc("This is a test", "blue")
    if re.match("\x1b\[34mThis is a test\x1b\[0m$", result):
        print("OK")
    else:
        print("Failed")
    sys.stdout.write("\n")

# --- end pretty
#
#
# Code originally from: http://stackoverflow.com/a/17016470/3030065
# Modified slightly to work with Python 2 and 3

# Generated at 2022-06-11 17:52:18.653506
# Unit test for function stringc
def test_stringc():
    print(u"Testing stringc")

    for color in C.COLOR_CODES.keys():
        print(u"%-10s" % color, stringc(u"This is a test.", color))

    for bg in ('bg_white', 'bg_black', 'bg_blue', 'bg_cyan', 'bg_green',
               'bg_magenta', 'bg_red', 'bg_yellow'):
        print(stringc(u"This is a test.", bg))

    for r in range(6):
        for g in range(6):
            for b in range(6):
                c = 16 + r * 36 + g * 6 + b
                print(u"rgb(%d,%d,%d) = %3s" % (r, g, b, c), end=' ')
                print

# Generated at 2022-06-11 17:52:40.494559
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 4, 'blue') == u'\x1b[94mfoo=4   \x1b[0m'
    assert colorize("foo", 0, 'blue') == u'foo=0   '
    assert colorize("bar", 6, None) == u'bar=6   '


# Generated at 2022-06-11 17:52:50.926147
# Unit test for function hostcolor
def test_hostcolor():
    def test(host, stats, color):
        test.total += 1
        result = hostcolor(host, stats, color)
        if ANSIBLE_COLOR:
            if stats['failures'] != 0 or stats['unreachable'] != 0:
                expected = u"%-37s" % stringc(host, C.COLOR_ERROR)
            elif stats['changed'] != 0:
                expected = u"%-37s" % stringc(host, C.COLOR_CHANGED)
            else:
                expected = u"%-37s" % stringc(host, C.COLOR_OK)
        else:
            expected = u"%-26s" % host
        if result == expected:
            return True
        else:
            print("%s != %s" % (result, expected))
            return False


# Generated at 2022-06-11 17:52:58.691278
# Unit test for function colorize
def test_colorize():
    print("Expect:")
    print(u"ok=0   changed=1   unreachable=2   failed=3")
    print("Received:")
    print(u"%s %s %s %s" % tuple(colorize(lead, num, color)
                                 for (lead, num, color) in
                                 (("ok", 0, C.COLOR_OK),
                                  ("changed", 1, C.COLOR_CHANGED),
                                  ("unreachable", 2, C.COLOR_UNREACHABLE),
                                  ("failed", 3, C.COLOR_ERROR))))
    # If we don't want color, change ANSIBLE_COLOR to False
    global ANSIBLE_COLOR
    # pylint: disable=global-statement
    ANSIBLE_COLOR = False
    print("Expect:")
    print

# Generated at 2022-06-11 17:53:07.602584
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        failures=0,
        unreachable=0,
        changed=0,
    )
    assert hostcolor('foohost.example.org', stats, True) == u'%-37s' % '\n'.join([u'\033[32mfoohost.example.org\033[0m', u'\033[32mfoohost.example.org\033[0m'])
    stats = dict(
        failures=1,
        unreachable=0,
        changed=0,
    )

# Generated at 2022-06-11 17:53:18.573484
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('test_host', stats, True) == u"\033[31mtest_host\033[0m       "
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('test_host', stats, True) == u"\033[31mtest_host\033[0m       "
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor('test_host', stats, True) == u"\033[33mtest_host\033[0m       "
    stats = dict(failures=0, unreachable=0, changed=0)

# Generated at 2022-06-11 17:53:29.568143
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '34'
    assert parsecolor('color333') == '38;5;333'
    assert parsecolor('rgb333') == '38;5;188'
    assert parsecolor('rgb355') == '38;5;216'
    assert parsecolor('gray8') == '38;5;244'
    assert parsecolor('gray9') == '38;5;245'
    assert parsecolor('gray10') == '38;5;246'
    assert parsecolor('gray11') == '38;5;247'
    assert parsecolor('gray12') == '38;5;248'
    assert parsecolor('gray13') == '38;5;249'
    assert parsecolor('gray14') == '38;5;250'
    assert parsec

# Generated at 2022-06-11 17:53:34.344136
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\u001b[31mfoo\u001b[0m"
    assert stringc("foo", "red") == u"\u001b[31mfoo\u001b[0m"



# Generated at 2022-06-11 17:53:44.658568
# Unit test for function stringc
def test_stringc():
    from ansible import utils
    set_text = u"Hi, I am [0mBold\033[1m\033[32m, \033[1m\033[31mRed\033[0m and \033[34mBlue\033[0m"
    expected = u"Hi, I am \033[3mBold\033[23m\033[3m\033[32m, \033[23m\033[3m\033[31mRed\033[23m\033[3m and \033[34mBlue\033[23m\033[3m"

# Generated at 2022-06-11 17:53:53.222473
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'changed': 0, 'failures': 1, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    assert hostcolor('localhost', stats) == 'localhost                \033[31m\033[1m\n\033[0m'
    stats = {'changed': 1, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    assert hostcolor('localhost', stats) == 'localhost                \033[33m\033[1m\n\033[0m'
    stats = {'changed': 0, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    assert hostcolor('localhost', stats) == 'localhost                \033[32m\033[1m\n\033[0m'
   

# Generated at 2022-06-11 17:54:00.626692
# Unit test for function stringc
def test_stringc():
    # Un-colorized output
    assert stringc("foo", "red") == "foo"

    # Colorized output
    assert stringc("foo", "red") == "\x1b[31mfoo\x1b[0m"

    # Colorized output with non-visible wrapping
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\x01\x1b[31m\x02foo\x01\x1b[0m\x02"

    # Valid colors and color aliases
    #  - colors 0-255
    assert stringc("foo", "color0") == "\x1b[38;5;0mfoo\x1b[0m"

# Generated at 2022-06-11 17:54:27.671486
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    # Each tuple will be converted to a test case.
    # The first element of a tuple is a tuple of arguments.
    # The second element of a tuple is the expected result.
    test_data = (
        (("host", "green"), "host"),
        # No colors
        (("host", "green", False), "host"),
        (("host", C.COLOR_OK), "host"),
        (("host", C.COLOR_OK, False), "host"),
        (("host", C.COLOR_ERROR), "host"),
        (("host", C.COLOR_ERROR, False), "host"),
    )

    # Save original value
    ansible_color = ANSIBLE_COLOR

# Generated at 2022-06-11 17:54:37.596871
# Unit test for function stringc
def test_stringc():
    """Test color code generation of function stringc."""
    # Test without suffix
    assert parsecolor('blue') == u'1;34', 'blue'
    assert parsecolor('bright purple') == u'1;35', 'bright purple'
    assert parsecolor('green') == u'32', 'green'
    assert parsecolor('bright blue') == u'1;94', 'bright blue'
    assert parsecolor('bright white') == u'97', 'bright white'
    assert parsecolor('normal') == u'39', 'normal'
    assert parsecolor('white') == u'37', 'white'
    assert parsecolor('39') == u'39', '39'
    # Test with suffix
    assert parsecolor('blue') == u'1;34', 'blue'

# Generated at 2022-06-11 17:54:44.094312
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test for function parsecolor"""
    assert parsecolor("red") == u'31'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("rgb123") == u'38;5;19'
    assert parsecolor("gray9") == u'38;5;241'
    assert parsecolor("invalid") == u'37'


if __name__ == '__main__':
    test_parsecolor()

# Generated at 2022-06-11 17:54:54.109667
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    assert stringc('foo', 'blue') == u"\033[34mfoo\033[0m"
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'blink') == u"\033[5mfoo\033[0m"
    assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"
    assert stringc('foo', 'lightgray') == u"\033[37mfoo\033[0m"
    assert stringc('foo', 'lightblue') == u"\033[94mfoo\033[0m"
    assert stringc('foo', 'lightred') == u"\033[91mfoo\033[0m"
    assert string

# Generated at 2022-06-11 17:55:04.453662
# Unit test for function colorize
def test_colorize():
    def check(lead, num, color, result):
        r = colorize(lead, num, color)
        if r != result:
            raise AssertionError("colorize(%r, %r, %r) returned %r, expected %r" % (lead, num, color, r, result))

    check("x", 0, "red", "x=0   ")
    check("x", 1, "red", "\x1b[31mx=1   \x1b[0m")
    check("x", 0, None, "x=0   ")
    check("xx", 0, "red", "xx=0  ")
    check("xx", 1, "red", "\x1b[31mxx=1  \x1b[0m")