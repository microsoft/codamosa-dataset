

# Generated at 2022-06-11 17:45:12.610273
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, 'red') == stringc(u"foo=0", 'red')
    assert colorize(u"foo", 1, 'red') == stringc(u"foo=1", 'red')
    assert colorize(u"foo", 2, 'red') == stringc(u"foo=2", 'red')
    assert colorize(u"foo", 0, None) == u'foo=0  '
    assert colorize(u"foo", 1, None) == u'foo=1  '
    assert colorize(u"foo", 2, None) == u'foo=2  '



# Generated at 2022-06-11 17:45:17.552917
# Unit test for function parsecolor
def test_parsecolor():
    """Test parsecolor input/ouput"""
    assert parsecolor(u'yellow') == u'33'
    assert parsecolor(u'0') == u'38;5;0'
    assert parsecolor(u'255') == u'38;5;255'
    assert parsecolor(u'rgb123') == u'38;5;33'
    assert parsecolor(u'gray0') == u'38;5;232'
    assert parsecolor(u'gray23') == u'38;5;255'

    try:
        parsecolor(u'undefined_color')
    except KeyError:
        pass
    else:
        assert False, u'parsecolor() did not raise KeyError'


# --- end of "pretty" library ---

# DEPRECATED

# Generated at 2022-06-11 17:45:24.492724
# Unit test for function parsecolor
def test_parsecolor():
    # Test standard ansible colors
    assert parsecolor("red") == u"31"
    assert parsecolor("green") == u"32"
    assert parsecolor("blue") == u"34"
    assert parsecolor("yellow") == u"33"
    # Test 256 color values
    assert parsecolor("color1") == u"38;5;1"
    assert parsecolor("color99") == u"38;5;99"
    assert parsecolor("color255") == u"38;5;255"
    # Test color values
    assert parsecolor("rgb123") == u"38;5;123"
    assert parsecolor("rgb255") == u"38;5;231"
    assert parsecolor("rgb555") == u"38;5;231"
    # Test grays

# Generated at 2022-06-11 17:45:36.813864
# Unit test for function hostcolor
def test_hostcolor():
    host = 'hostname.example.com'
    stats = dict(changed=0, failures=1, unreachable=0, skipped=0)
    colored = hostcolor(host, stats, True)
    is_color = True if ANSIBLE_COLOR else False
    assert colored == (u"%-37s" % stringc(host, C.COLOR_ERROR, is_color))

    stats = dict(changed=1, failures=1, unreachable=0, skipped=0)
    colored = hostcolor(host, stats, True)
    assert colored == (u"%-37s" % stringc(host, C.COLOR_CHANGED, is_color))

    stats = dict(changed=1, failures=0, unreachable=1, skipped=0)
    colored = hostcolor(host, stats, True)

# Generated at 2022-06-11 17:45:41.502156
# Unit test for function stringc
def test_stringc():
    """Test for function stringc"""
    for color in C.COLOR_CODES:
        s = stringc(color, color)
        assert color in s
        assert '\033[0m' == s[-4:]
        assert '\033[%sm' % C.COLOR_CODES[color] == s[-9:-4]



# Generated at 2022-06-11 17:45:50.822468
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test", stats={'failures': 0, 'unreachable': 0, 'changed': 0}, color=False) == "%-26s" % "test"
    assert hostcolor("test", stats={'failures': 0, 'unreachable': 0, 'changed': 0}, color=True) == "%-37s" % "test"
    assert hostcolor("test", stats={'failures': 1, 'unreachable': 0, 'changed': 0}, color=True) == "%-37s" % "\x1b[31mtest\x1b[0m"
    assert hostcolor("test", stats={'failures': 0, 'unreachable': 1, 'changed': 0}, color=True) == "%-37s" % "\x1b[31mtest\x1b[0m"

# Generated at 2022-06-11 17:46:01.338152
# Unit test for function parsecolor
def test_parsecolor():
    def test(msg, got, expected):
        if got == expected:
            print(u"OK: %s: %s -> %s" % (msg, repr(got), repr(expected)))
        else:
            print(u"FAIL: %s: %s != %s" % (msg, repr(got), repr(expected)))
    test(u"black", parsecolor(u'black'), u'30')
    test(u"red", parsecolor(u'red'), u'31')
    test(u"green", parsecolor(u'green'), u'32')
    test(u"yellow", parsecolor(u'yellow'), u'33')
    test(u"blue", parsecolor(u'blue'), u'34')

# Generated at 2022-06-11 17:46:11.844892
# Unit test for function stringc
def test_stringc():
    assert stringc('hello world', 'green') == u"\033[0;32mhello world\033[0m"
    assert stringc('hello world', 'red') == u"\033[0;31mhello world\033[0m"
    assert stringc('hello world', 'color123') == u"\033[38;5;123mhello world\033[0m"
    assert stringc('hello world', 'rgb255255255') == u"\033[38;5;15mhello world\033[0m"
    assert stringc('hello world', 'rgb000255255') == u"\033[38;5;70mhello world\033[0m"
    assert stringc('hello world', 'gray12') == u"\033[38;5;244mhello world\033[0m"
   

# Generated at 2022-06-11 17:46:18.165116
# Unit test for function hostcolor
def test_hostcolor():
    host = u"localhost"
    stats = {
        'changed': 0,
        'dark': 0,
        'failures': 0,
        'ok': 0,
        'processed': 0,
        'skipped': 0,
        'unreachable': 0
    }
    assert hostcolor(host=host, stats=stats) == u"%-26s" % host



# Generated at 2022-06-11 17:46:26.167890
# Unit test for function parsecolor
def test_parsecolor():
    # Existing color name
    assert parsecolor('black') == u'30'
    # Named color
    assert parsecolor('color8') == u'38;5;8'
    # RGB
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('rgb123') == u'38;5;38'
    assert parsecolor('rgb333') == u'38;5;59'
    assert parsecolor('rgb555') == u'38;5;60'
    assert parsecolor('rgb255') == u'38;5;231'
    # gray
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray8') == u'38;5;251'
    # error
    assert parsec

# Generated at 2022-06-11 17:46:36.214514
# Unit test for function stringc
def test_stringc():
    """Unit test for stringc"""
    # This is a very limited test, but hey, it works. :)
    assert stringc('red', 'red') == '\033[31mred\033[0m'
    assert stringc('blue', 'blue') == '\033[34mblue\033[0m'


#
# --- end of "pretty"

__all__ = ['stringc', 'parsecolor', 'colorize', 'hostcolor', 'ANSIBLE_COLOR']

# Generated at 2022-06-11 17:46:47.055186
# Unit test for function hostcolor
def test_hostcolor():

    stats = dict(
        failures  = 1,
        unreachable = 0,
        changed = 0,
    )

    # Verify that stats errors or unreachable host are shown as red
    assert hostcolor('localhost', dict(failures=1)) == '\x1b[31mlocalhost            \x1b[0m'
    assert hostcolor('localhost', dict(unreachable=1)) == '\x1b[31mlocalhost            \x1b[0m'
    assert hostcolor('localhost', stats) == '\x1b[31mlocalhost            \x1b[0m'

    # Verify that a changed host is shown as yellow
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 1

# Generated at 2022-06-11 17:46:56.527190
# Unit test for function hostcolor
def test_hostcolor():
    MOCK_STATS = {'changed': 1,'dark': 0,'failures': 0,'ok': 1,'processed': 1,'skipped': 0,'unreachable': 0}
    TEST1 = hostcolor("OK", MOCK_STATS, True)
    EXPECT1 = "%-37s" % '\033[32mOK\033[0m'
    assert(TEST1 == EXPECT1)

    MOCK_STATS = {'changed': 0,'dark': 0,'failures': 1,'ok': 1,'processed': 1,'skipped': 0,'unreachable': 0}
    TEST2 = hostcolor("FAILED", MOCK_STATS, True)
    EXPECT2 = "%-37s" % '\033[31mFAILED\033[0m'
    assert(TEST2 == EXPECT2)

# Generated at 2022-06-11 17:47:04.965795
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(u'localhost', stats, False) == u'localhost           '
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor(u'localhost', stats, False) == u'localhost           '
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor(u'localhost', stats, False) == u'localhost           '
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(u'localhost', stats, False) == u'localhost           '

    stats = dict(failures=1, unreachable=0, changed=0)

# Generated at 2022-06-11 17:47:16.154329
# Unit test for function colorize
def test_colorize():
    """
    Test function colorize by converting its results to strings,
    performing string comparisons.
    """
    assert str(colorize('ok', 0, C.COLOR_OK)) == "ok=0   "
    assert str(colorize('changed', 0, C.COLOR_CHANGED)) == "changed=0 "
    assert str(colorize('failed', 0, C.COLOR_ERROR)) == "failed=0 "
    assert str(colorize('unreachable', 0, C.COLOR_UNREACHABLE)) == "unreachable=0 "
    assert str(colorize('skipped', 0, C.COLOR_SKIP)) == "skipped=0 "
    assert str(colorize('rescued', 0, C.COLOR_OK)) == "rescued=0    "

# Generated at 2022-06-11 17:47:22.553401
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=1, changed=0)
    assert u'%-37s' % stringc(u'localhost', C.COLOR_ERROR) == hostcolor(u'localhost', stats)
    stats = dict(failures=1, unreachable=0, changed=1)
    assert u'%-37s' % stringc(u'localhost', C.COLOR_CHANGED) == hostcolor(u'localhost', stats)
    stats = dict(failures=0, unreachable=0, changed=0)
    assert u'%-37s' % stringc(u'localhost', C.COLOR_OK) == hostcolor(u'localhost', stats)

# --- end "pretty"



# Generated at 2022-06-11 17:47:27.267607
# Unit test for function stringc
def test_stringc():
    s = stringc("foo bar baz", 'yellow')
    if not s.startswith("\033["):
        sys.stderr.write("ERROR: stringc() does not appear to contain ansi codes")
        sys.exit(1)

# --- end "pretty" ---



# Generated at 2022-06-11 17:47:37.617746
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3
    assert hostcolor(u'foo', dict(failures=1, unreachable=0, changed=0), True) == u'\x1b[31mfoo\x1b[0m               '
    assert hostcolor(u'foo', dict(failures=0, unreachable=0, changed=1), True) == u'\x1b[33mfoo\x1b[0m               '
    assert hostcolor(u'foo', dict(failures=0, unreachable=0, changed=0), True) == u'\x1b[32mfoo\x1b[0m               '

# Generated at 2022-06-11 17:47:48.556193
# Unit test for function hostcolor
def test_hostcolor():
    # Test that changing color is based on changed, unreachable and failures
    host = "server01"
    stats = dict(skipped=1, ok=1)
    color = hostcolor(host, stats)
    assert color == "%-37s" % "server01"

    stats = dict(skipped=1, ok=1, changed=1)
    color = hostcolor(host, stats)
    assert color == u"%-37s" % stringc("server01", C.COLOR_CHANGED)

    stats = dict(skipped=1, ok=1, unreachable=1)
    color = hostcolor(host, stats)
    assert color == u"%-37s" % stringc("server01", C.COLOR_ERROR)

    stats = dict(skipped=1, ok=1, failures=1)
    color = host

# Generated at 2022-06-11 17:47:56.377362
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('fakehost', dict(changed=1)) == u'%-26s' % stringc('fakehost', C.COLOR_CHANGED, wrap_nonvisible_chars=False)
    assert hostcolor('fakehost', dict(failures=1)) == u'%-26s' % stringc('fakehost', C.COLOR_ERROR, wrap_nonvisible_chars=False)
    assert hostcolor('fakehost', dict(ok=1)) == u'%-26s' % stringc('fakehost', C.COLOR_OK, wrap_nonvisible_chars=False)



# Generated at 2022-06-11 17:48:12.006543
# Unit test for function hostcolor
def test_hostcolor():
    'hostcolor should color hostname based on counter values'
    host = 'testhost'
    assert hostcolor(host, {'failures': 0, 'unreachable': 0, 'changed': 0}) == '{0}'.format(u"%-26s".format(u"{0}\033[0m".format(u"\033[0;32m{0}".format(host))))
    assert hostcolor(host, {'failures': 1, 'unreachable': 0, 'changed': 0}) == '{0}'.format(u"%-26s".format(u"{0}\033[0m".format(u"\033[1;31m{0}".format(host))))
    assert hostcolor(host, {'failures': 0, 'unreachable': 1, 'changed': 0}) == '{0}'.format

# Generated at 2022-06-11 17:48:21.186274
# Unit test for function stringc

# Generated at 2022-06-11 17:48:27.336904
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils.common._collections_compat import Mapping

    host = u'host1'
    stats = {u'unreachable': 0, u'failures': 0, u'changed': 0}

    assert hostcolor(host, stats) == u'host1                 '
    stats[u'changed'] = 1
    assert hostcolor(host, stats) == u'host1                 \n'



# Generated at 2022-06-11 17:48:36.076892
# Unit test for function hostcolor
def test_hostcolor():
    """Unit test for function hostcolor"""
    def _test(stats, expected):
        assert expected == hostcolor('somehost', stats)

    _test({'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0},
          u"%-26s" % u"somehost")
    _test({'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0},
          u"%-37s" % u"\033[0;33msomehost\033[0m")

# Generated at 2022-06-11 17:48:43.466659
# Unit test for function hostcolor
def test_hostcolor():
    import io
    import sys
    tmp_stdout = io.StringIO()
    orig_stdout = sys.stdout
    sys.stdout = tmp_stdout
    stats = {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 0}
    hostcolor("test", stats)
    output = tmp_stdout.getvalue()
    sys.stdout = orig_stdout
    assert output == '%s' % (u'%-26s') % "test"



# Generated at 2022-06-11 17:48:54.765411
# Unit test for function hostcolor
def test_hostcolor():
    testhost = 'host0035'
    teststats = {'ok': 10, 'changed': 1, 'unreachable': 1, 'failures': 0}
    teststats2 = {'ok': 10, 'changed': 0, 'unreachable': 0, 'failures': 1}
    teststats3 = {'ok': 10, 'changed': 0, 'unreachable': 1, 'failures': 1}
    assert '%-37s' % testhost == hostcolor(testhost, teststats2, False)
    assert '\033[0;32m%-37s\033[0m' % testhost == hostcolor(testhost, teststats2, True)
    assert '\033[0;33m%-37s\033[0m' % testhost == hostcolor(testhost, teststats, True)

# Generated at 2022-06-11 17:49:06.269954
# Unit test for function stringc
def test_stringc():
    class TestClass:
        def __init__(self, test, expected_result):
            self.test = test
            self.expected_result = expected_result

    # Some notes about the character code:
    #  - it is the hex value of the ord() command
    #    (e.g., ord('a') = 0x61)
    #  - the high bit is required to activate the color control
    #  - the next two bits form the SGR background
    #  - the last four bits form the SGR foreground
    #
    # As of now, this is coded as:
    #  - SGR background = 0
    #  - SGR foreground = 8+x where x is the color code
    #
    # For more information, please see:
    #    http://en.wikipedia.org/wiki/ANSI_escape_

# Generated at 2022-06-11 17:49:14.439990
# Unit test for function stringc
def test_stringc():
    """Test if stringc() can handle all color types
    """
    print(u"Testing text color and background color")
    print(stringc(u"Hello World!", color=u"red", bgcolor=u"blue"))

    print(u"\nTesting text color, background color and attrs")
    print(stringc(u"Hello World!", color=u"red", bgcolor=u"blue", attrs=u"bold"))

    print(u"\nTesting color name")
    print(stringc(u"Hello World!", color=u"red"))

    print(u"\nTesting color code")
    print(stringc(u"Hello World!", color=u"123"))

    print(u"\nTesting rgb color")
    print(stringc(u"Hello World!", color=u"rgb333"))

   

# Generated at 2022-06-11 17:49:25.277963
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        ok=10,
        changed=5,
        unreachable=0,
        failed=0,
    )
    assert hostcolor('example.com', stats, True) == u'\033[32;1m%-37s\033[0m'

    stats = dict(
        ok=10,
        changed=0,
        unreachable=0,
        failed=5,
    )
    assert hostcolor('example.com', stats, True) == u'\033[31;1m%-37s\033[0m'

    stats = dict(
        ok=10,
        changed=0,
        unreachable=5,
        failed=0,
    )

# Generated at 2022-06-11 17:49:35.216012
# Unit test for function hostcolor
def test_hostcolor():

    def fun(host, stats, color, expected):
        res = hostcolor(host, stats, color)
        assert res == expected, "%s != %s (%s)" % (res, expected, str(stats))

    host = 'darkpeace.vm.bytemark.co.uk'
    stats = {'changed': 0, 'dark': 0}
    fun(host, stats, True, u'%-26s' % u'\033[0;32mdarkpeace.vm.bytemark.co.uk\033[0m')
    fun(host, stats, False, u'%-26s' % host)
    stats = {'changed': 1, 'dark': 0}

# Generated at 2022-06-11 17:49:50.411485
# Unit test for function stringc
def test_stringc():
    from ansible_test import helpers
    helpers.skip_if_no_terminal()

    def _test(c, exp_c, fmt, args=None, exp_args=None,
              wrap_nonvisible_chars=False):
        res = stringc(c, fmt, wrap_nonvisible_chars)
        exp_res = stringc(exp_c, exp_args, wrap_nonvisible_chars)
        assert res == exp_res, (res, exp_res)

    _test('abc', 'abc', 'blue')
    _test('abc\n123', 'abc\n123', 'blue')
    _test('abc', 'abc', 'blue', wrap_nonvisible_chars=True)

# Generated at 2022-06-11 17:50:00.869252
# Unit test for function hostcolor
def test_hostcolor():
    # Test colors
    assert hostcolor('foohost', dict(failures=0, unreachable=1, changed=0), True) == u'\x1b[31m%-37s\x1b[0m'
    assert hostcolor('foohost', dict(failures=1, unreachable=0, changed=0), True) == u'\x1b[31m%-37s\x1b[0m'
    assert hostcolor('foohost', dict(failures=0, unreachable=0, changed=1), True) == u'\x1b[33m%-37s\x1b[0m'

# Generated at 2022-06-11 17:50:04.391024
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 5, 'blue') == "foo=5   "
    assert colorize("foo", 50, None) == "foo=50  "


# Generated at 2022-06-11 17:50:16.342788
# Unit test for function stringc
def test_stringc():
    color_codes = {
        "red": u'\033[31m',
        "green": u'\033[32m',
        "blue": u'\033[34m',
        "reset": u'\033[0m'
    }
    for color, code in color_codes.items():
        assert stringc('foo', color) == (code + 'foo' + color_codes["reset"])
        assert stringc('foo\nbar\nbaz', color) == (
            code + 'foo' + color_codes["reset"] + '\n' +
            code + 'bar' + color_codes["reset"] + '\n' +
            code + 'baz' + color_codes["reset"])

# Generated at 2022-06-11 17:50:24.597060
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test1", {"failures": 1, "unreachable": 0, "changed": 0}, True) == u"%-37s" % stringc("test1", C.COLOR_ERROR)
    assert hostcolor("test2", {"failures": 0, "unreachable": 1, "changed": 0}, True) == u"%-37s" % stringc("test2", C.COLOR_ERROR)
    assert hostcolor("test3", {"failures": 0, "unreachable": 0, "changed": 1}, True) == u"%-37s" % stringc("test3", C.COLOR_CHANGED)
    assert hostcolor("test4", {"failures": 0, "unreachable": 0, "changed": 0}, True) == u"%-37s" % stringc("test4", C.COLOR_OK)
   

# Generated at 2022-06-11 17:50:33.119567
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor("localhost", stats) == u'localhost              '

    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor("localhost", stats) == u'\x1b[31mlocalhost          \x1b[0m'

    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor("localhost", stats) == u'\x1b[34mlocalhost          \x1b[0m'


# --- end "pretty"
#
# --- begin terminal size code
#
# terminal size preserving code from fabric:
# http://github.com/bitprophet/fabric/



# Generated at 2022-06-11 17:50:38.026647
# Unit test for function colorize
def test_colorize():
    assert u"ok=123" == colorize("ok", 123, None)
    assert u"ok=123" == colorize("ok", 123, "green")
    assert u"\033[32mok=123\033[0m" == colorize("ok", 123, "green")


# Generated at 2022-06-11 17:50:43.125845
# Unit test for function hostcolor
def test_hostcolor():
    """ Unit test for function hostcolor """
    assert hostcolor("127.0.0.1 | SUCCESS =>", dict(
        changed=0,
        dark=0,
        failures=0,
        ok=1,
        skipped=0,
        unreachable=0)) == u"127.0.0.1 | SUCCESS    =>"



# Generated at 2022-06-11 17:50:52.856673
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("darkgreen", dict(failures=0, unreachable=0, changed=0)) == "darkgreen                "
    assert hostcolor("darkblue", dict(failures=0, unreachable=0, changed=1)) == "darkblue                 "
    assert hostcolor("darkred", dict(failures=1, unreachable=0, changed=0)) == "darkred                 "
    assert hostcolor("darkyellow", dict(failures=0, unreachable=1, changed=0)) == "darkyellow              "
    assert hostcolor("OK", dict(failures=0, unreachable=0, changed=0)) == "OK                      "
    assert hostcolor("FAILED", dict(failures=1, unreachable=0, changed=0)) == "FAILED                  "

# Generated at 2022-06-11 17:51:03.876194
# Unit test for function colorize
def test_colorize():
    """ colorize: prints in color """
    # reset
    colors = ['black', 'darkgray', 'lightgray', 'white', 'red', 'green',
              'blue', 'cyan', 'magenta', 'yellow', 'brightred', 'brightgreen',
              'brightyellow', 'brightblue', 'brightmagenta', 'brightcyan']

    print(u'{0}.'.format(u'-' * 78))
    print(u"Testing colorize()")
    print(u'{0}'.format('-' * 78))
    print(u"%-8s => %s" % ("Color", "Text"))
    print(u'{0}.'.format('-' * 78))
    for c in colors:
        print(u"%-8s => %s" % (c, colorize("color", c, c)))
   

# Generated at 2022-06-11 17:51:21.191891
# Unit test for function hostcolor
def test_hostcolor():
    TEST_HOST = 'fake1.example.com'
    TEST_STATS = { 'unreachable': 0, 'skipped': 0, 'ok': 1, 'changed': 0, 'failures': 0 }
    print(hostcolor(TEST_HOST, TEST_STATS))
    TEST_STATS = { 'unreachable': 0, 'skipped': 0, 'ok': 0, 'changed': 1, 'failures': 0 }
    print(hostcolor(TEST_HOST, TEST_STATS))
    TEST_STATS = { 'unreachable': 0, 'skipped': 0, 'ok': 0, 'changed': 0, 'failures': 1 }
    print(hostcolor(TEST_HOST, TEST_STATS))

# Generated at 2022-06-11 17:51:32.181447
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor

    stats1 = dict(failures=0, unreachable=0, changed=0)
    stats2 = dict(failures=1, unreachable=0, changed=1)
    stats3 = dict(failures=0, unreachable=1, changed=1)

    assert hostcolor('host1', stats1, color=True) == u"%-37s" % u"host1"
    assert hostcolor('host2', stats2, color=True) == u"%-37s" % u"\x1b[91mhost2\x1b[0m"
    assert hostcolor('host3', stats3, color=True) == u"%-37s" % u"\x1b[91mhost3\x1b[0m"

# Generated at 2022-06-11 17:51:43.274380
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(ok=1, changed=0, unreachable=0, failed=0), True) == u'%-37s' % stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(ok=0, changed=0, unreachable=1, failed=0), True) == u'%-37s' % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(ok=0, changed=1, unreachable=0, failed=0), True) == u'%-37s' % stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(ok=0, changed=2, unreachable=1, failed=0), True) == u'%-37s' % stringc("localhost", C.COLOR_ERROR)

# Generated at 2022-06-11 17:51:51.216372
# Unit test for function stringc
def test_stringc():
    """Test that function stringc behaves as expected"""
    text = u'hello world'
    colorless = stringc(text, None)
    assert colorless == text, 'Expected %s, got %s' % (text, colorless)

    available_colors = C.COLOR_CODES.keys()
    for color in available_colors:
        ansi_color = stringc(text, color)
        assert ansi_color != text, 'Expected %s to differ from %s' % (ansi_color, text)

        rgb_color = stringc(text, 'rgb255', wrap_nonvisible_chars=True)
        assert ansi_color != text, 'Expected %s to differ from %s' % (rgb_color, text)

# Generated at 2022-06-11 17:52:01.095570
# Unit test for function hostcolor
def test_hostcolor():
    # Define some host stats and call hostcolor with them.
    # Hostcolor should always return a unicode string
    # regardless of input.
    # It should return 'host' in color, unless ANSIBLE_COLOR is set to False
    stats = {'changed': 0, 'failures': 0, 'unreachable': 0}
    unicode_host = u"test_host"
    assert isinstance(hostcolor(unicode_host, stats, color=True), unicode)
    assert isinstance(hostcolor(unicode_host, stats, color=False), unicode)
    assert hostcolor(unicode_host, stats, color=True) == u"%-37s" % stringc(unicode_host, C.COLOR_OK)

# Generated at 2022-06-11 17:52:12.806442
# Unit test for function stringc
def test_stringc():
    print("Testing function 'stringc' in module 'utils.color'")
    print("1..5")
    # Color
    test_1 = stringc("test", "red")
    if ANSIBLE_COLOR:
        if test_1 == u"\033[31mtest\033[0m":
            print("ok 1 - stringc")
        else:
            print("not ok 1 - stringc")
    else:
        if test_1 == u"test":
            print("ok 1 - stringc")
        else:
            print("not ok 1 - stringc")
    # Gray
    test_2 = stringc("test", "gray30")

# Generated at 2022-06-11 17:52:24.672432
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    if not ANSIBLE_COLOR:
        return
    from ansible.utils.color import stringc
    assert stringc('hello world', 'red') == u'\x1b[31mhello world\x1b[0m'
    assert stringc('hello world', 'green') == u'\x1b[32mhello world\x1b[0m'
    assert stringc('hello world', 'yellow') == u'\x1b[33mhello world\x1b[0m'
    assert stringc('hello world', 'blue') == u'\x1b[34mhello world\x1b[0m'
    assert stringc('hello world', 'magenta') == u'\x1b[35mhello world\x1b[0m'
    assert string

# Generated at 2022-06-11 17:52:30.760166
# Unit test for function colorize
def test_colorize():
    assert colorize('host', '1', 'red') == stringc('host=1', 'red')
    assert colorize('host', '0', 'red') == 'host=0  '
    assert colorize('host', '1', None) == 'host=1  '
    assert colorize('host', '0', None) == 'host=0  '



# Generated at 2022-06-11 17:52:41.137035
# Unit test for function stringc
def test_stringc():
    print(u'[%s]' % stringc(u'TEST', 'red'))
    print(u'[%s]' % stringc(u'TEST', 'green'))
    print(u'[%s]' % stringc(u'TEST', 'yellow'))
    print(u'[%s]' % stringc(u'TEST', 'blue'))
    print(u'[%s]' % stringc(u'TEST', 'magenta'))
    print(u'[%s]' % stringc(u'TEST', 'cyan'))
    print(u'[%s]' % stringc(u'TEST', 'white'))
    print(u'[%s]' % stringc(u'TEST', 'color0'))

# Generated at 2022-06-11 17:52:45.938290
# Unit test for function colorize
def test_colorize():
    lead = 'test'
    num = 3
    color = 'red'
    s = u"{lead}={num}".format(lead=lead, num=num)
    result = colorize(lead, num, color)
    assert result == s

# --- end "pretty"



# Generated at 2022-06-11 17:53:08.844407
# Unit test for function hostcolor
def test_hostcolor():
    hc1 = hostcolor('server1', dict(failures=1, unreachable=0, changed=3))
    hc2 = hostcolor('server2', dict(failures=0, unreachable=4, changed=0))
    hc3 = hostcolor('server3', dict(failures=0, unreachable=0, changed=0))
    if hc1 != stringc('server1', C.COLOR_ERROR):
        raise AssertionError("hostcolor failed test 1")
    if hc2 != stringc('server2', C.COLOR_ERROR):
        raise AssertionError("hostcolor failed test 2")
    if hc3 != stringc('server3', C.COLOR_OK):
        raise AssertionError("hostcolor failed test 3")
    print("hostcolor: ok")


# Generated at 2022-06-11 17:53:19.248233
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat.tests import unittest

    # pylint: disable=missing-docstring
    class TestHostColor(unittest.TestCase):

        def setUp(self):
            self._saved_color = ANSIBLE_COLOR
            ANSIBLE_COLOR = True

        def tearDown(self):
            ANSIBLE_COLOR = self._saved_color

        def test_ok_hostcolor(self):
            stats = dict(
                failures=0,
                changed=0,
                unreachable=0,
            )
            self.assertEqual(hostcolor("host", stats, color=True), u"host\033[0m")
            self.assertEqual(hostcolor("host", stats, color=False), "host")


# Generated at 2022-06-11 17:53:25.953491
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('text', 'red', wrap_nonvisible_chars=False) == u'\033[31mtext\033[0m'
        assert stringc('text', 'black on_red', wrap_nonvisible_chars=False) == u'\033[41m\033[30mtext\033[0m'


# --- end of "pretty"



# Generated at 2022-06-11 17:53:32.387158
# Unit test for function stringc
def test_stringc():
    assert stringc("normal", "green") == u"\033[38;5;2mnormal\033[0m"
    assert stringc("normal", "blue") == u"\033[38;5;4mnormal\033[0m"
    assert stringc("escape \\033", "blue") == u"\033[38;5;4mescape \\033\033[0m"
    assert stringc("color256", "color256") == u"\033[38;5;1280mcolor256\033[0m"
    assert stringc("rgb", "rgb100") == u"\033[38;5;11mrgb\033[0m"
    assert stringc("gray", "gray1") == u"\033[38;5;234mgray\033[0m"

# Generated at 2022-06-11 17:53:43.752432
# Unit test for function hostcolor
def test_hostcolor():
    _no_color_data = dict(darkgreen='darkgreen',
                          ok='[ok]', changed='[changed]', unreachable='[unreachable]', failures='[failed]',
                          reset='[0m')
    _no_color_data_keys = _no_color_data.keys()


# Generated at 2022-06-11 17:53:53.133707
# Unit test for function hostcolor
def test_hostcolor():
    """
    >>> hostcolor("foo", {})
    u'foo                           '
    >>> hostcolor("foo", {'failures': 1, 'ok': 2, 'changed': 3, 'unreachable': 0}, True)
    u'\\x1b[31mfoo\\x1b[0m                       '
    >>> hostcolor("foo", {'failures': 0, 'ok': 2, 'changed': 3, 'unreachable': 0}, True)
    u'\\x1b[33mfoo\\x1b[0m                       '
    >>> hostcolor("foo", {'failures': 0, 'ok': 2, 'changed': 0, 'unreachable': 0}, True)
    u'\\x1b[32mfoo\\x1b[0m                       '
    """
    pass



# Generated at 2022-06-11 17:54:00.580637
# Unit test for function stringc
def test_stringc():
    def assertEquals(a, b, msg=None):
        if a != b:
            print("%sFAILED%s: %s expected %s but got %s" % (
                stringc('', 'RED'), stringc('', 'NORMAL'), msg, a, b))

    assertEquals(stringc('some text', 'NORMAL'), u'some text')
    assertEquals(stringc('some text', 'BOLD'), u'\033[1msome text\033[0m')
    assertEquals(stringc('some text', 'RED'), u'\033[31msome text\033[0m')
    assertEquals(stringc('some text', 'GREEN'), u'\033[32msome text\033[0m')

# Generated at 2022-06-11 17:54:09.144886
# Unit test for function colorize
def test_colorize():
    colors = ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white')
    color_codes = [str(color) for color in range(0, 8)]

    print(u'%-12s%-12s%-12s%-12s' % ('color', 'fg_color', 'colorize', 'color_code'))
    for color, color_code in zip(colors, color_codes):
        print(u'%-12s%-12s%-12s%-12s' % (color, colorize(color, color_code, color),
                                         colorize(color, color_code, color), color_code))
    print(u'')

    # gray colors
    gray_colors = [str(gray) for gray in range(232, 256)]

# Generated at 2022-06-11 17:54:21.189598
# Unit test for function stringc
def test_stringc():
    print(stringc("test", "black"))
    print(stringc("test", "black on_yellow"))
    print(stringc("test", "on_yellow"))
    print(stringc("test", "yellow on_black"))
    print(stringc("test", "black on_bright_yellow"))
    print(stringc("test", "bright_red on_bright_blue"))
    print(stringc("test", "black on_bright_blue"))
    print(stringc("test", "color8"))
    print(stringc("test", "bright_magenta"))
    print(stringc("test", "color0"))
    print(stringc("test", "rgb255255100"))
    print(stringc("test", "rgb123123123"))
    print(stringc("test", "rgb255255255"))
   

# Generated at 2022-06-11 17:54:31.253464
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    test_host = 'example'
    for stats in [ {'failures': 1, 'unreachable':0, 'ok': 0, 'changed': 0},
                   {'failures': 0, 'unreachable':1, 'ok': 0, 'changed': 0},
                   {'failures': 0, 'unreachable':0, 'ok': 0, 'changed': 1},
                   {'failures': 0, 'unreachable':0, 'ok': 1, 'changed': 0} ]:
        assert hostcolor(test_host, stats, True) == '{0}=1   '.format(test_host)
