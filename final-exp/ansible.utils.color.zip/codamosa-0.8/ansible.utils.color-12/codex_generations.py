

# Generated at 2022-06-11 17:45:10.072756
# Unit test for function stringc
def test_stringc():
    tests = (
        (u"stringc('hello', 'green')",
         u"\033[32mhello\033[0m"),
        (u"stringc('hello', 'color3')",
         u"\033[38;5;100mhello\033[0m"),
        (u"stringc('hello', 'rgb2551525')",
         u"\033[38;5;197mhello\033[0m"),
        (u"stringc('hello', 'gray7')",
         u"\033[38;5;249mhello\033[0m"),
    )
    for test in tests:
        test_str = test[0]
        result = test[1]

# Generated at 2022-06-11 17:45:21.093143
# Unit test for function stringc
def test_stringc():
    assert stringc(u"hello", 'green') == u"\033[32mhello\033[0m"
    assert stringc(u"hello", u"blue") == u"\033[34mhello\033[0m"
    assert stringc(u"hello", u"color1") == u"\033[38;5;1mhello\033[0m"
    assert stringc(u"hello", u"color223") == u"\033[38;5;223mhello\033[0m"
    assert stringc(u"hello", u"rgb255000255") == u"\033[38;5;21mhello\033[0m"
    assert stringc(u"hello", u"rgb255255255") == u"\033[38;5;15mhello\033[0m"


# Generated at 2022-06-11 17:45:33.553177
# Unit test for function stringc

# Generated at 2022-06-11 17:45:43.307969
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('default') == u'39'
    assert parsecolor('black') == u'30'
    assert parsecolor('white') == u'97'
    assert parsecolor('lightwhite') == u'37'
    assert parsecolor('lightgrey') == u'37'
    assert parsecolor('darkgrey') == u'90'
    assert parsecolor('red') == u'31'
    assert parsecolor('darkred') == u'91'
    assert parsecolor('lightred') == u'91'
    assert parsecolor('green') == u'32'
    assert parsecolor('darkgreen') == u'92'
    assert parsecolor('lightgreen') == u'92'
    assert parsecolor('yellow') == u'33'

# Generated at 2022-06-11 17:45:52.198460
# Unit test for function stringc
def test_stringc():
    import sys
    print(u'*** Testing function stringc ***', file=sys.stderr)
    print(u'stringc(None) = %s' % stringc(None), file=sys.stderr)
    print(u'stringc(True) = %s' % stringc(True), file=sys.stderr)
    print(u'stringc(False) = %s' % stringc(False), file=sys.stderr)
    print(u'stringc(0) = %s' % stringc(0), file=sys.stderr)
    print(u'stringc(1) = %s' % stringc(1), file=sys.stderr)

# Generated at 2022-06-11 17:46:02.190486
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('none') == '')
    assert(parsecolor('black') == '30')
    assert(parsecolor('red') == '31')
    assert(parsecolor('green') == '32')
    assert(parsecolor('yellow') == '33')
    assert(parsecolor('blue') == '34')
    assert(parsecolor('magenta') == '35')
    assert(parsecolor('cyan') == '36')
    assert(parsecolor('white') == '37')
    assert(parsecolor('color0') == '38;5;0')
    assert(parsecolor('color1') == '38;5;1')
    assert(parsecolor('color2') == '38;5;2')

# Generated at 2022-06-11 17:46:12.118547
# Unit test for function hostcolor
def test_hostcolor():

    stats1 = dict(
        ok=10,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
    )
    stats2 = dict(
        ok=10,
        failures=1,
        unreachable=0,
        changed=0,
        skipped=0,
    )
    stats3 = dict(
        ok=10,
        failures=0,
        unreachable=0,
        changed=1,
        skipped=0,
    )
    assert (hostcolor(u"localhost", stats1, True) ==
            hostcolor(u"localhost", stats1, False))
    assert (hostcolor(u"localhost", stats2, True) ==
            hostcolor(u"localhost", stats2, False))

# Generated at 2022-06-11 17:46:17.962983
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', {'failures': 0, 'changed': 0, 'unreachable': 0, 'skipped': 0}) == 'foo                    '
    assert hostcolor('bar', {'failures': 0, 'changed': 0, 'unreachable': 0, 'skipped': 0}, False) == 'bar                    '



# Generated at 2022-06-11 17:46:25.910739
# Unit test for function stringc
def test_stringc():
    """ Unit test for function stringc """
    # Test normal string
    test_string = "test"
    assert stringc(test_string, "blue") == "\033[0;34mtest\033[0m"

    # Test empty string
    test_string = ""
    assert stringc(test_string, "red") == "\033[0;31m\033[0m"

    # Test color name that contains a number
    test_string = "test"
    assert stringc(test_string, "black1") == "\033[0;38;5;232mtest\033[0m"

    # Test RGB color code
    test_string = "test"
    assert stringc(test_string, "rgb111") == "\033[0;38;5;60mtest\033[0m"

    # Test gray

# Generated at 2022-06-11 17:46:33.827783
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'38;5;%s' % C.COLOR_CODES['red']
    assert parsecolor('yellow') == u'38;5;%s' % C.COLOR_CODES['yellow']
    assert parsecolor('green') == u'38;5;%s' % C.COLOR_CODES['green']
    assert parsecolor('blue') == u'38;5;%s' % C.COLOR_CODES['blue']
    assert parsecolor('magenta') == u'38;5;%s' % C.COLOR_CODES['magenta']
    assert parsecolor('cyan') == u'38;5;%s' % C.COLOR_CODES['cyan']

# Generated at 2022-06-11 17:46:53.743603
# Unit test for function colorize
def test_colorize():
    print("Testing colorize")
    color_re = '[\x1b[\d;]*[\w]+'
    assert re.search(color_re, colorize('foo', 0, 'red'))
    assert re.search(color_re, colorize('foo', 1, 'red'))
    assert not re.search(color_re, colorize('foo', 0))
    assert not re.search(color_re, colorize('foo', 1))
    assert re.search(color_re, colorize('foo', 'x', 'red'))

# --- end "pretty"

# --- begin "termstyle"
#
# termstyle - style terminal output
#
# Author: Peter Odding <peter@peterodding.com>
# Last Change: February 6, 2015
# URL: https://github.com

# Generated at 2022-06-11 17:47:03.898131
# Unit test for function colorize
def test_colorize():
    # 1) Uncolorized output
    ANSIBLE_COLOR = False
    assert "#1", colorize("ok", 0, "green") == "ok=0   "
    assert "#2", colorize("changed", 10, "yellow") == "changed=10"
    assert "#3", colorize("skipped", 100, "cyan") == "skipped=100"
    assert "#4", colorize("failed", 1000, "red") == "failed=1000"
    assert "#5", colorize("unreachable", 10000, "red") == "unreachable=10000"
    assert "#6", colorize("rescued", 100000, "magenta") == "rescued=100000"
    assert "#7", colorize("ignored", 1000000, "blue") == "ignored=1000000"

    # 2) Colorized output


# Generated at 2022-06-11 17:47:15.158413
# Unit test for function hostcolor
def test_hostcolor():
    # Given a host, a stats dict and color set to True
    # when stats contains a failure
    # then hostcolor is colored with the error color
    host = "localhost"
    stats = {"failures": 1}
    color = True
    assert hostcolor(host, stats, color).endswith(u"\033[31m")

    # Given a host, a stats dict and color set to True
    # when stats contains a unreachable
    # then hostcolor is colored with the error color
    host = "localhost"
    stats = {"unreachable": 1}
    color = True
    assert hostcolor(host, stats, color).endswith(u"\033[31m")

    # Given a host, a stats dict and color set to True
    # when stats contains a change
    # then hostcolor is colored with the changed color


# Generated at 2022-06-11 17:47:20.429920
# Unit test for function colorize
def test_colorize():
    for clr in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        lead = 'XX'
        num = 42
        print('colorize(%s, %d, %s) = %s' % (lead, num, clr, colorize(lead, num, clr)))


if __name__ == '__main__':
    test_colorize()
    os._exit(0)
# --- end of "pretty"

# Generated at 2022-06-11 17:47:31.578101
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(ok=5, failures=0, unreachable=0, changed=0)
    C.ANSIBLE_NOCOLOR = False

    # ok
    assert hostcolor('host1', stats, color=True) == stringc('host1', C.COLOR_OK) + '            '

    stats['changed'] = 2
    # changed
    assert hostcolor('host1', stats, color=True) == stringc('host1', C.COLOR_CHANGED) + '           '

    stats['failures'] = 1
    # chagend + failed
    assert hostcolor('host1', stats, color=True) == stringc('host1', C.COLOR_ERROR) + '           '

    # ok
    stats = dict(ok=5, failures=0, unreachable=0, changed=0)

# Generated at 2022-06-11 17:47:37.710218
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 10, 'green') == "\x1b[0;32mfoo=10  \x1b[0m"
    assert colorize("foo", 0, 'green') == "foo=0   "
    assert colorize("foo", 10, None) == "foo=10   "
    assert colorize("foo", 0, None) == "foo=0   "


# Generated at 2022-06-11 17:47:48.560277
# Unit test for function stringc
def test_stringc():
    """Test the stringc function"""
    # The string should be wrapped in color
    assert u"\033[32mfoo\033[0m" == stringc(u"foo", u"green")

    # The string should be wrapped in color, ignoring case
    assert u"\033[32mfoo\033[0m" == stringc(u"FOO", u"Green")

    # The string should be wrapped in color, using a number
    assert u"\033[38;5;1mfoo\033[0m" == stringc(u"foo", u"color1")

    # The string should be wrapped in color, using an rgb value
    assert u"\033[38;5;1mfoo\033[0m" == stringc(u"foo", u"rgb100")


# --- end "pretty"
# =================================

# Generated at 2022-06-11 17:47:58.353512
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('on_blue') == u'44'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('bold') == u'1'
    assert parsecolor('underline') == u'4'
    assert parsecolor('underline') == u'4'
    assert parsecolor('on_black') == u'40'
    assert parsecolor('on_red') == u'41'
    assert parsecolor('on_green') == u'42'

# Generated at 2022-06-11 17:48:08.995875
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('default') == u'39'
    assert parsecolor('darkgray') == u'90'
    assert parsecolor('lightred') == u'91'
    assert parsecolor('lightgreen') == u'92'
    assert parsecolor('lightyellow') == u'93'
    assert parsecolor('lightblue') == u

# Generated at 2022-06-11 17:48:19.678996
# Unit test for function hostcolor
def test_hostcolor():
    hosts = {'host1': {
                'changed': 10,
                'failures': 2,
                'ok': 11,
                'skipped': 3,
                'unreachable': 2
             },
             'host2': {
                'changed': 11,
                'failures': 2,
                'ok': 12,
                'skipped': 3,
                'unreachable': 2
             },
             'host3': {
                'changed': 12,
                'failures': 2,
                'ok': 13,
                'skipped': 3,
                'unreachable': 2
             },
             'host4': {
                'changed': 13,
                'failures': 2,
                'ok': 14,
                'skipped': 3,
                'unreachable': 2
             },
            }

   

# Generated at 2022-06-11 17:48:38.143312
# Unit test for function stringc
def test_stringc():
    print(stringc('hello world', 'green'))
    print(stringc('hello world', 'black'))
    print(stringc('hello world', 'red'))
    print(stringc('hello world', 'blue'))
    print(stringc('hello world', 'cyan'))
    print(stringc('hello world', 'white'))
    print(stringc('hello world', 'color0'))
    print(stringc('hello world', 'color7'))
    print(stringc('hello world', 'color8'))
    print(stringc('hello world', 'color15'))
    print(stringc('hello world', 'color3'))
    print(stringc('hello world', 'rgb333'))
    print(stringc('hello world', 'rgb555'))

# Generated at 2022-06-11 17:48:43.744739
# Unit test for function colorize
def test_colorize():
    assert colorize("", -2, "32") == "=   -2"
    assert colorize("", -1, "32") == "=   -1"
    assert colorize("", 0, "32") == "=    0"
    assert colorize("", 1, "32") == "=    1"
    assert colorize("", 2, "32") == "=    2"



# Generated at 2022-06-11 17:48:54.929491
# Unit test for function stringc
def test_stringc():
    assert ANSIBLE_COLOR
    assert u'\033[31mhello\033[0m' == stringc(u'hello', 'red')
    assert u'\033[31mhello\033[0m' == stringc(u'hello', 'COLOR_RED')
    assert u'\033[31mhello\033[0m' == stringc(u'hello', '31')
    assert u'\033[31mhello\033[0m' == stringc(u'hello', '31m')
    assert u'\033[1;31mhello\033[0m' == stringc(u'hello', '1;31')
    assert u'\033[1;31mhello\033[0m' == stringc(u'hello', '1;31m')

# Generated at 2022-06-11 17:49:06.415562
# Unit test for function stringc
def test_stringc():
    """Some simple unit tests for stringc"""
    assert stringc("foo", "green") == (
                u"\033[38;5;2mfoo\033[0m")
    assert stringc("foo", "bright purple") == (
                u"\033[38;5;13mfoo\033[0m")
    assert stringc("foo", "rgb255") == (
                u"\033[38;5;231mfoo\033[0m")
    assert stringc("foo", "rgb000") == (
                u"\033[38;5;0mfoo\033[0m")
    assert stringc("foo", "rgb123") == (
                u"\033[38;5;21mfoo\033[0m")

# Generated at 2022-06-11 17:49:13.686752
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""

    from pprint import pprint as pp


# Generated at 2022-06-11 17:49:19.054621
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        print(u"Terminal does not support color")
    else:
        for name, code in C.COLOR_CODES.items():
            print(u"%s %s %s test" % (code, stringc(u"test", name), code))
        print(u"\033[0m\n")  # clear all attributes



# Generated at 2022-06-11 17:49:27.895540
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31', parsecolor('red')
    assert parsecolor('blue') == u'34', parsecolor('blue')
    assert parsecolor('white') == u'37', parsecolor('white')
    assert parsecolor('color1') == u'38;5;1', parsecolor('color1')
    assert parsecolor('color255') == u'38;5;255', parsecolor('color255')
    assert parsecolor('rgb123') == u'38;5;123', parsecolor('rgb123')
    assert parsecolor('rgb555') == u'38;5;231', parsecolor('rgb555')
    assert parsecolor('rgb123') == u'38;5;123', parsecolor('rgb123')
    assert par

# Generated at 2022-06-11 17:49:36.962722
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == u"%-37s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}, True) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 1, 'changed': 1}, True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}, False) == u"%-26s" % 'localhost'
# --- end "pretty"



# Generated at 2022-06-11 17:49:46.738156
# Unit test for function parsecolor
def test_parsecolor():
    print(u'Testing function parsecolor')

# Generated at 2022-06-11 17:49:58.530583
# Unit test for function stringc
def test_stringc():
    assert(stringc(u'this is a test', 'blue') == u"\033[34mthis is a test\033[0m")
    assert(stringc(u'this is a test', 'lightblue') == u"\033[94mthis is a test\033[0m")
    assert(stringc(u'this is a test', 'blackon_yellow') == u"\033[40;33mthis is a test\033[0m")
    assert(stringc(u'this is a test', 'blackon_lightyellow') == u"\033[103mthis is a test\033[0m")
    assert(stringc(u'this is a test', 'green') == u"\033[31mthis is a test\033[0m")

# Generated at 2022-06-11 17:50:18.806019
# Unit test for function hostcolor
def test_hostcolor():
    assert (hostcolor("www.example.com", {"failures": 0, "unreachable": 0, "changed": 0}) ==
            u"www.example.com               ")
    assert (hostcolor("www.example.com", {"failures": 0, "unreachable": 0, "changed": 1}) ==
            u"\033[0;32mwww.example.com\033[0m")
    assert (hostcolor("www.example.com", {"failures": 1, "unreachable": 0, "changed": 0}) ==
            u"\033[0;31mwww.example.com\033[0m")

# Generated at 2022-06-11 17:50:21.534874
# Unit test for function colorize
def test_colorize():
    assert colorize("debug", 1, "blue") == stringc("debug=1  ", "blue")
    assert colorize("debug", 1, None) == "debug=1  "
    assert colorize("debug", 0, "blue") == "debug=0  "



# Generated at 2022-06-11 17:50:31.408621
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"host", {u"failures": 0, u"changed": 0, u"unreachable": 0}) == u"host                    "
    assert hostcolor(u"host", {u"failures": 1, u"changed": 0, u"unreachable": 0}) == u"host                    "
    assert hostcolor(u"host", {u"failures": 0, u"changed": 1, u"unreachable": 0}) == u"host                    "
    assert hostcolor(u"host", {u"failures": 1, u"changed": 1, u"unreachable": 0}) == u"host                    "
    assert hostcolor(u"host", {u"failures": 0, u"changed": 0, u"unreachable": 1}) == u"host                    "

# Generated at 2022-06-11 17:50:41.122227
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("hostname",
                     dict(failures=0, unreachable=0, changed=0, ok=1)) == u'hostname                 '
    assert hostcolor("hostname",
                     dict(failures=1, unreachable=0, changed=0, ok=1)) == u'hostname                 '
    assert hostcolor("hostname",
                     dict(failures=0, unreachable=1, changed=0, ok=1)) == u'hostname                 '
    assert hostcolor("hostname",
                     dict(failures=0, unreachable=0, changed=1, ok=1)) == u'hostname                 '
    assert hostcolor("hostname",
                     dict(failures=0, unreachable=0, changed=0, ok=1), False) == u'hostname               '



# Generated at 2022-06-11 17:50:47.716641
# Unit test for function stringc
def test_stringc():
    pass
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green', wrap_nonvisible_chars=False) == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'green', wrap_nonvisible_chars=True) == u'\001322mfoo\0013[0m'



# Generated at 2022-06-11 17:50:55.197992
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(host, stats) == '%-26s' % stringc(host, C.COLOR_OK)

    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(host, stats) == '%-26s' % stringc(host, C.COLOR_ERROR)

    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor(host, stats) == '%-26s' % stringc(host, C.COLOR_ERROR)

    stats = dict(failures=0, unreachable=0, changed=1)

# Generated at 2022-06-11 17:51:01.735176
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray8') == '38;5;240'

# Generated at 2022-06-11 17:51:08.542134
# Unit test for function stringc
def test_stringc():
    # Based off of the list of standard color names in the X11
    # documentation:
    # http://cgit.freedesktop.org/xorg/proto/rgb/plain/rgb.txt
    assert stringc('hi', 'white') == u'\033[37mhi\033[0m'
    assert stringc('hi', 'black') == u'\033[30mhi\033[0m'
    assert stringc('hi', 'red') == u'\033[31mhi\033[0m'
    assert stringc('hi', 'green') == u'\033[32mhi\033[0m'
    assert stringc('hi', 'yellow') == u'\033[33mhi\033[0m'

# Generated at 2022-06-11 17:51:18.277239
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo.bar.com'
    stats = dict(
        ok=1,
        failures=0,
        unreachable=0,
    )
    assert hostcolor(host, stats, color=False) == u"%s" % host
    assert hostcolor(host, stats, color=True) == u"%s" % stringc(host, C.COLOR_OK)

    stats = dict(
        ok=1,
        failures=3,
        unreachable=0,
    )
    assert hostcolor(host, stats, color=True) == u"%s" % stringc(host, C.COLOR_ERROR)

    stats = dict(
        ok=1,
        failures=0,
        unreachable=4,
    )

# Generated at 2022-06-11 17:51:22.280646
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""

    assert stringc(u'foo', 'red') == "\033[31mfoo\033[0m"
    assert stringc(u'foo', 'rgb888') == "\033[38;5;231mfoo\033[0m"



# Generated at 2022-06-11 17:51:37.724058
# Unit test for function colorize
def test_colorize():
    print("no color")
    print(colorize("foo", 0, None))
    print(colorize("foo", 1, None))
    print("\nwith color")
    print(colorize("foo", 0, "blue"))
    print(colorize("foo", 1, "blue"))


# end "pretty" (from github.com/bri/pretty)

__all__ = ["stringc", "hostcolor", "colorize"]

# Generated at 2022-06-11 17:51:47.617807
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == "\033[33mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "cyan") == "\033[36mfoo\033[0m"
    assert stringc("foo", "color1") == "\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "color4") == "\033[38;5;4mfoo\033[0m"

# Generated at 2022-06-11 17:51:59.811461
# Unit test for function stringc
def test_stringc():
    import re
    assert re.match("\033\[.*?m", stringc("foo", "black"))
    assert re.match("\033\[.*?m", stringc("foo", "red"))
    assert re.match("\033\[.*?m", stringc("foo", "green"))
    assert re.match("\033\[.*?m", stringc("foo", "yellow"))
    assert re.match("\033\[.*?m", stringc("foo", "blue"))
    assert re.match("\033\[.*?m", stringc("foo", "magenta"))
    assert re.match("\033\[.*?m", stringc("foo", "cyan"))
    assert re.match("\033\[.*?m", stringc("foo", "white"))

# Generated at 2022-06-11 17:52:05.877029
# Unit test for function stringc
def test_stringc():
    print(stringc('Hello', 'blue'))
    print(stringc('Hello', 'blue', True))
    print(stringc('Hello', 'red'))
    print(stringc('Hello', 'red', True))
    print(stringc('Hello', 'white'))
    print(stringc('Hello', 'white', True))
    print(stringc('Hello', 'yellow'))
    print(stringc('Hello', 'yellow', True))



# Generated at 2022-06-11 17:52:09.693403
# Unit test for function colorize
def test_colorize():
    for color in C.COLOR_CODES.keys():
        lead = 'X'
        num = color
        yield colorize, lead, num, color


# --- end pretty, begin custom additions


# Generated at 2022-06-11 17:52:17.858630
# Unit test for function stringc
def test_stringc():
    assert stringc("", "black") == "\033[30m\033[0m"
    assert stringc("", "red") == "\033[31m\033[0m"
    assert stringc("", "green") == "\033[32m\033[0m"
    assert stringc("", "yellow") == "\033[33m\033[0m"
    assert stringc("", "blue") == "\033[34m\033[0m"
    assert stringc("", "magenta") == "\033[35m\033[0m"
    assert stringc("", "cyan") == "\033[36m\033[0m"
    assert stringc("", "white") == "\033[37m\033[0m"

# Generated at 2022-06-11 17:52:23.725991
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'changed': 0, 'unreachable': 0, 'skipped': 0, 'failures': 0}
    assert hostcolor('localhost', stats) == u"localhost                    "
    stats['changed'] = 1
    assert hostcolor('localhost', stats, False) == u"localhost                    "
    assert hostcolor('localhost', stats, True) == u"\033[0;32mlocalhost               \033[0m"
    stats['failures'] = 1
    assert hostcolor('localhost', stats, False) == u"localhost                    "
    assert hostcolor('localhost', stats, True) == u"\033[0;31mlocalhost               \033[0m"
    stats['unreachable'] = 1
    assert hostcolor('localhost', stats, False) == u"localhost                    "
    assert hostcolor('localhost', stats, True)

# Generated at 2022-06-11 17:52:30.220044
# Unit test for function hostcolor
def test_hostcolor():

    # Basic test
    stats = {'ok': 1, 'changed': 0, 'unreachable': 0, 'failures': 0}
    host = '127.0.0.1'
    assert hostcolor(host, stats) == u'%-26s' % "\x1b[32m127.0.0.1\x1b[0m"

    # Error on remote host
    stats = {'ok': 1, 'changed': 0, 'unreachable': 1, 'failures': 0}
    assert hostcolor(host, stats) == u'%-26s' % "\x1b[31m127.0.0.1\x1b[0m"

    # Error on remote host
    stats = {'ok': 1, 'changed': 0, 'unreachable': 1, 'failures': 0}
    assert host

# Generated at 2022-06-11 17:52:40.934301
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.display import Display
    d = Display()
    assert hostcolor('foo.example.org', {'failures': 1}, color=True) == u'\x1b[31mfoo.example.org\x1b[0m     '
    assert hostcolor('foo.example.org', {'failures': 0}, color=True) == u'\x1b[32mfoo.example.org\x1b[0m     '
    assert hostcolor('foo.example.org', {'changed': 0}, color=True) == u'\x1b[32mfoo.example.org\x1b[0m    '

# Generated at 2022-06-11 17:52:51.605091
# Unit test for function stringc

# Generated at 2022-06-11 17:53:08.182795
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = dict(
        failures=0,
        unreachable=0,
        changed=0,
    )
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)

    stats = dict(
        failures=0,
        unreachable=0,
        changed=1,
    )
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_CHANGED)

    stats = dict(
        failures=1,
        unreachable=0,
        changed=0,
    )
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)


# Generated at 2022-06-11 17:53:17.350164
# Unit test for function colorize
def test_colorize():
    color = colorize('test', 0, 'blue')
    assert color == 'test=0   '

    sys.modules['ansible.constants'] = type('MockConstants', (), dict(COLOR_OK='green'))

    color = colorize('test', 0, 'blue')
    assert color == 'test=0   '

    color = colorize('test', 1, 'blue')
    assert color == 'test=1   '

    color = colorize('test', 1, None)
    assert color == 'test=1   '

    color = colorize('test', 0, None)
    assert color == 'test=0   '



# Generated at 2022-06-11 17:53:23.670613
# Unit test for function stringc
def test_stringc():
    assert stringc(u"stringc\ncolor\ncode", u"cyan") == u'\n'.join([
        u'\x1b[36mstringc\x1b[0m',
        u'\x1b[36mcolor\x1b[0m',
        u'\x1b[36mcode\x1b[0m'])
    assert stringc(u"stringc\ncolor\ncode", u"color124") == u'\n'.join([
        u'\x1b[38;5;124mstringc\x1b[0m',
        u'\x1b[38;5;124mcolor\x1b[0m',
        u'\x1b[38;5;124mcode\x1b[0m'])
    assert string

# Generated at 2022-06-11 17:53:28.206212
# Unit test for function hostcolor
def test_hostcolor():
    ansible_colored = hostcolor(u"host", {u"changed": 1})
    ansible_nocolored = hostcolor(u"host", {u"changed": 1}, False)
    assert (ansible_colored != ansible_nocolored)



# Generated at 2022-06-11 17:53:39.534821
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return

    # Ensure that if "COLOR_CHANGED" and "COLOR_ERROR" are the same,
    # then the result is the same, regardless of which order the words
    # are checked in the function.
    C.COLOR_CHANGED = C.COLOR_ERROR = '31'
    host = 'foo'
    stats = {'failures': 1, 'unreachable': 2, 'changed': 3}
    expected = stringc(host, C.COLOR_ERROR)
    assert hostcolor(host, stats) == expected

    stats = {'failures': 2, 'unreachable': 1, 'changed': 3}
    assert hostcolor(host, stats) == expected

    stats = {'failures': 3, 'unreachable': 2, 'changed': 1}
    assert hostcolor

# Generated at 2022-06-11 17:53:47.419330
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {'failures': 0, 'unreachable': 0, 'changed': 2}, color=True) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)  # pylint: disable=line-too-long
    assert hostcolor("localhost", {'failures': 1, 'unreachable': 0, 'changed': 0}, color=True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", {'failures': 0, 'unreachable': 2, 'changed': 0}, color=True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)

# Generated at 2022-06-11 17:53:52.899072
# Unit test for function colorize
def test_colorize():
    print(colorize("foo", 0, "green"))
    print(colorize("foo", 1, "green"))
    print(colorize("foo", 0, "red"))
    print(colorize("foo", 1, "red"))
    print(colorize("foo", 0, None))
    print(colorize("foo", 1, None))

# --- end "pretty"


# Generated at 2022-06-11 17:54:00.459134
# Unit test for function stringc
def test_stringc():
    from ansible.compat.tests import unittest

    class TestStringC(unittest.TestCase):
        """Validate function stringc"""
        def validate_color(self, color):
            colored = stringc(u"This is a test", color, wrap_nonvisible_chars=True)
            self.assertIn(u"\001" + colored, u"\001\033[%sm\002This is a test\001\033[0m\002" % parsecolor(color))

        def test_color_black(self):
            self.validate_color(u'black')

        def test_color_red(self):
            self.validate_color(u'red')

        def test_color_green(self):
            self.validate_color(u'green')


# Generated at 2022-06-11 17:54:09.065074
# Unit test for function hostcolor
def test_hostcolor():
    good_stats = {u"ok": 1, u"changed": 0, u"failures": 0, u"unreachable": 0}
    bad_stats = {u"ok": 0, u"changed": 0, u"failures": 1, u"unreachable": 0}

    assert ANSIBLE_COLOR is True
    assert hostcolor(u'localhost', good_stats) == u"\x1b[32m%-37s\x1b[0m" % u'localhost'
    assert hostcolor(u'localhost', bad_stats) == u"\x1b[31m%-37s\x1b[0m" % u'localhost'


# Generated at 2022-06-11 17:54:21.146884
# Unit test for function stringc
def test_stringc():
    """ Unit test for function stringc """

    text = 'some test text'

    if ANSIBLE_COLOR:
        # Test all named colors
        for color in C.COLOR_CODES:
            assert isinstance(stringc(text, color), unicode)
        # Test bad color
        assert isinstance(stringc(text, 'bad_color'), unicode)
        # Test color number
        assert isinstance(stringc(text, 'color9'), unicode)
        # Test RGB color
        assert isinstance(stringc(text, 'rgb123'), unicode)
        # Test bad RGB color
        assert isinstance(stringc(text, 'rgb12345'), unicode)
        # Test RGB color too small
        assert isinstance(stringc(text, 'rgb0'), unicode)
        # Test RGB color too big

# Generated at 2022-06-11 17:54:37.871687
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        print("Terminal does not support color. Skipping...")
        return

    color_names = list(C.COLOR_CODES.keys())
    color_names += [
        'color1', 'color16', 'color232', 'color255', 'rgb123', 'rgb555',
        'gray1', 'gray23', 'gray99'
    ]

    for color_name in color_names:
        print("Testing color %s" % color_name)
        print(stringc("Hello, World!", color_name))
        print(stringc("Hello, World!", color_name, wrap_nonvisible_chars=True))
        print("")

if __name__ == "__main__":
    test_stringc()

# Generated at 2022-06-11 17:54:48.467737
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foobar', {'unreachable': 0, 'failures': 0, 'changed': 0}) == u'foobar'
    if ANSIBLE_COLOR:
        assert hostcolor('foobar', {'unreachable': 0, 'failures': 0, 'changed': 0}, True) == u'\033[32mfoobar\033[0m'
        assert hostcolor('foobar', {'unreachable': 0, 'failures': 1, 'changed': 0}, True) == u'\033[31mfoobar\033[0m'
        assert hostcolor('foobar', {'unreachable': 0, 'failures': 0, 'changed': 1}, True) == u'\033[33mfoobar\033[0m'

# Generated at 2022-06-11 17:54:56.511341
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('abc', dict(failures=1, changed=0, unreachable=0), True) == stringc('abc', C.COLOR_ERROR)
    assert hostcolor('abc', dict(failures=0, changed=1, unreachable=0), True) == stringc('abc', C.COLOR_CHANGED)
    assert hostcolor('abc', dict(failures=0, changed=0, unreachable=0), True) == stringc('abc', C.COLOR_OK)
    assert hostcolor('abc', dict(failures=1, changed=1, unreachable=0), True) == stringc('abc', C.COLOR_CHANGED)
    assert hostcolor('abc', dict(failures=1, changed=0, unreachable=1), True) == stringc('abc', C.COLOR_ERROR)