

# Generated at 2022-06-11 17:45:14.275936
# Unit test for function parsecolor

# Generated at 2022-06-11 17:45:23.187944
# Unit test for function hostcolor
def test_hostcolor():
    host = u"test.example.com"
    stats = {u"failures": 0, u"unreachable": 0, u"changed": 0}
    assert hostcolor(host, stats, False) == u"%-26s" % host
    assert hostcolor(host, stats, False) == u"%-26s" % host

    stats = {u"failures": 1, u"unreachable": 0, u"changed": 0}
    assert hostcolor(host, stats, False) == u"%-26s" % host
    assert hostcolor(host, stats, False) == u"%-26s" % host

    stats = {u"failures": 0, u"unreachable": 0, u"changed": 1}
    assert hostcolor(host, stats, False) == u"%-26s" % host
    assert hostcolor

# Generated at 2022-06-11 17:45:32.288786
# Unit test for function hostcolor
def test_hostcolor():
    """
    >>> hostcolor('localhost', dict(failures=1, unreachable=0, changed=0))
    u'localhost                              '
    >>> hostcolor('localhost', dict(failures=0, unreachable=1, changed=0))
    u'localhost                              '
    >>> hostcolor('localhost', dict(failures=0, unreachable=0, changed=1))
    u'localhost                              '
    >>> hostcolor('localhost', dict(failures=0, unreachable=0, changed=0))
    u'localhost                              '
    """


# Generated at 2022-06-11 17:45:42.515301
# Unit test for function parsecolor
def test_parsecolor():
    """Test function parsecolor."""

    # Test normal 16-color palette
    assert parsecolor("red") == "31"
    assert parsecolor("RED") == "31"
    assert parsecolor("Red") == "31"
    assert parsecolor("blue") == "34"
    assert parsecolor("bLuE") == "34"
    assert parsecolor("magenta") == "35"
    assert parsecolor("mAgEnTa") == "35"
    assert parsecolor("cyan") == "36"
    assert parsecolor("CYAN") == "36"
    assert parsecolor("white") == "37"
    assert parsecolor("BLACK") == "30"
    assert parsecolor("yellow") == "33"
    assert parsecolor("yellow") == "33"
   

# Generated at 2022-06-11 17:45:51.609717
# Unit test for function parsecolor
def test_parsecolor():
    for color in C.COLOR_CODES:
        parsecolor(color)
    for i in range(16):
        parsecolor('color%d' % i)
    for i in range(16):
        parsecolor('gray%d' % i)
    for i in range(6):
        for j in range(6):
            for k in range(6):
                parsecolor('rgb%d%d%d' % (i, j, k))

# --- end of "pretty"

if __name__ == '__main__':
    print(u"stringc='%s'" % stringc(u'foo', 'normal'))
    print(u"stringc='%s'" % stringc(u'foo', 'bold'))

# Generated at 2022-06-11 17:45:58.015247
# Unit test for function parsecolor
def test_parsecolor():
    valid_colors = ('red', 'blue', 'green', 'yellow', 'green', 'white', 'reset', 'bright', 'default')
    for color in valid_colors:
        assert parsecolor(color)
    invalid_colors = ('red1', 'bad-color', 'white ', ' color9 ')
    for color in invalid_colors:
        assert not parsecolor(color)



# Generated at 2022-06-11 17:46:09.360348
# Unit test for function parsecolor

# Generated at 2022-06-11 17:46:20.820935
# Unit test for function parsecolor
def test_parsecolor():
    for i in range(0, 15):
        assert parsecolor("color%d" % i) == u"38;5;%d" % i
    for i in range(0, 24):
        assert parsecolor("gray%d" % i) == u"38;5;%d" % (232 + i)
    for i in range(0, 6):
        for j in range(0, 6):
            for k in range(0, 6):
                c = 16 + 36 * i + 6 * j + k
                assert parsecolor("rgb%d%d%d" % (i, j, k)) == u"38;5;%d" % c

if __name__ == '__main__':
    test_parsecolor()

# Generated at 2022-06-11 17:46:30.372647
# Unit test for function stringc
def test_stringc():
    """Unit test for ansible.utils.color.stringc"""

    assert(ANSIBLE_COLOR)

    # Test foreground colors
    for color in C.COLOR_CODES:
        assert(parsecolor(color) == C.COLOR_CODES[color])

    # Test foreground colors with numeric names.
    assert(parsecolor(u'color8') == '38;5;8')
    assert(parsecolor(u'color16') == '38;5;16')

    # Test rgb colors.
    assert(parsecolor(u'rgb000') == '38;5;16')
    assert(parsecolor(u'rgb255') == '38;5;231')
    assert(parsecolor(u'rgb301') == '38;5;9')

# Generated at 2022-06-11 17:46:40.753082
# Unit test for function hostcolor
def test_hostcolor():
    host = 'www.example.com'
    stats = {}
    assert '\x1b[31m%-37s\x1b[0m' == hostcolor(host, stats)
    stats = {'failures': 1}
    assert '\x1b[31m%-37s\x1b[0m' == hostcolor(host, stats)
    stats = {'unreachable': 1}
    assert '\x1b[31m%-37s\x1b[0m' == hostcolor(host, stats)
    stats = {'changed': 2}
    assert '\x1b[33m%-37s\x1b[0m' == hostcolor(host, stats)
    stats = {'ok': 2}

# Generated at 2022-06-11 17:46:55.987069
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0,
                                   'changed': 0,
                                   'unreachable': 0,
                                   'ok': 0}, True) == "%-37s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', {'failures': 0,
                                   'changed': 3,
                                   'unreachable': 0,
                                   'ok': 0}, True) == "%-37s" % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', {'failures': 1,
                                   'changed': 0,
                                   'unreachable': 0,
                                   'ok': 0}, True) == "%-37s" % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-11 17:47:04.772302
# Unit test for function hostcolor
def test_hostcolor():
    print(u"%-26s" % hostcolor(u"127.0.0.1", {'failures': 0, 'unreachable': 0, 'changed': 0}))
    print(u"%-26s" % hostcolor(u"127.0.0.2", {'failures': 1, 'unreachable': 0, 'changed': 0}))
    print(u"%-26s" % hostcolor(u"127.0.0.3", {'failures': 0, 'unreachable': 1, 'changed': 0}))
    print(u"%-26s" % hostcolor(u"127.0.0.4", {'failures': 0, 'unreachable': 0, 'changed': 1}))

# Generated at 2022-06-11 17:47:09.355497
# Unit test for function colorize
def test_colorize():
    # Tests all combinations of a color and
    # a value. Color should only be applied to
    # values greater than 0.
    for color in C.COLOR_CODES:
        for num in range(-1, 1):
            yield colorize, num, num, color



# Generated at 2022-06-11 17:47:13.987990
# Unit test for function hostcolor
def test_hostcolor():
    s = u"testhost"
    stats1 = {'failures': 0}
    stats2 = {'failures': 1}
    stats3 = {'changed': 0}
    stats4 = {'changed': 2}

    ok_str = hostcolor(s, stats1, True)
    assert ok_str == u"%-37s" % stringc(s, C.COLOR_OK)
    ok_str = hostcolor(s, stats3, True)
    assert ok_str == u"%-37s" % stringc(s, C.COLOR_OK)
    assert hostcolor(s, stats1, False) == u"%-26s" % s
    assert hostcolor(s, stats2, True) == u"%-37s" % stringc(s, C.COLOR_ERROR)

# Generated at 2022-06-11 17:47:22.073775
# Unit test for function hostcolor
def test_hostcolor():
    class Options(object):
        def __init__(self, color=None):
            self.color = color
    class Stats(object):
        def __init__(self, failures=0, unreachable=0, changed=0):
            self.failures = failures
            self.unreachable = unreachable
            self.changed = changed

    # If ANSIBLE_COLOR is false, the color should not be applied.
    options = Options(color=False)
    stats = Stats(failures=1, unreachable=1, changed=1)
    assert hostcolor(u'hostname', stats, options.color) == u'hostname              '
    assert hostcolor(u'anotherlongerhostname', stats, options.color) == u'anotherlongerhostname'

# Generated at 2022-06-11 17:47:32.137105
# Unit test for function stringc
def test_stringc():
    #                                              01234567890123456789012345678901
    assert stringc('test', 'black') == u'\x1b[30mtest\x1b[0m'
    assert stringc('test', 'red') == u'\x1b[31mtest\x1b[0m'
    assert stringc('test', 'green') == u'\x1b[32mtest\x1b[0m'
    assert stringc('test', 'yellow') == u'\x1b[33mtest\x1b[0m'
    assert stringc('test', 'blue') == u'\x1b[34mtest\x1b[0m'

# Generated at 2022-06-11 17:47:45.013983
# Unit test for function hostcolor
def test_hostcolor():
    def _hostcolor(host, stats, color, expected):
        got = hostcolor(host, stats, color)
        if got != expected:
            print("hostcolor(%r, %r, %r) returned %r, expected %r"
                  % (host, stats, color, got, expected))
    _hostcolor('localhost', dict(failures=0, unreachable=0, changed=0),
               True, u'localhost                 ')
    _hostcolor('localhost', dict(failures=1, unreachable=0, changed=0),
               True, u'\x1b[31;01mlocalhost\x1b[0m             ')

# Generated at 2022-06-11 17:47:55.561354
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('abc', 'black') == u"\033[30mabc\033[0m"
        assert stringc('abc', 'rgb000') == u"\033[30mabc\033[0m"
        assert stringc('abc', 'rgb100') == u"\033[31mabc\033[0m"
        assert stringc('abc', 'rgb010') == u"\033[32mabc\033[0m"
        assert stringc('abc', 'rgb001') == u"\033[34mabc\033[0m"
        assert stringc('abc', 'rgb200') == u"\033[91mabc\033[0m"

# Generated at 2022-06-11 17:48:05.585910
# Unit test for function hostcolor
def test_hostcolor():
    # for all results, when color is true
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0, ok=0), True) == u"\033[31mlocalhost                  \033[0m"
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1, ok=0), True) == u"\033[33mlocalhost                  \033[0m"
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0, ok=1), True) == u"\033[32mlocalhost                  \033[0m"
    assert hostcolor("localhost", dict(failures=1, unreachable=1, changed=1, ok=1), True) == u"\033[31mlocalhost                  \033[0m"


# Generated at 2022-06-11 17:48:12.892458
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("RED") == u'31'
    assert parsecolor("Blue") == u'34'
    assert parsecolor("blue") == u'34'
    assert parsecolor("bLUE") == u'34'
    assert parsecolor("cyan") == u'36'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("color253") == u'38;5;253'
    assert parsecolor("color255") == u'38;5;255'
    assert parsecolor("rgb123") == u'38;5;45'
    assert parsecolor("rgb321") == u'38;5;117'

# Generated at 2022-06-11 17:48:28.788929
# Unit test for function colorize
def test_colorize():
    """PrettyPrint - Test colorize"""
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('bar', 0, None) == 'bar=0   '

# Generated at 2022-06-11 17:48:37.889465
# Unit test for function hostcolor
def test_hostcolor():
    from ansible import colors
    colors.C.COLOR_OK = 'blue'
    colors.C.COLOR_CHANGED = 'yellow'
    colors.C.COLOR_ERROR = 'red'
    colors.ANSIBLE_COLOR = True

    # Changed
    assert hostcolor('host001', dict(changed=25, ok=25, failed=0, unreachable=0, skipped=0)) == u'\n'.join([
        u'\033[34mhost001              \033[0m',
        u'\033[34mhost001              \033[0m',
    ])

    # OK

# Generated at 2022-06-11 17:48:47.181386
# Unit test for function hostcolor
def test_hostcolor():

    results = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(u'computername', results, color=True) == u'%-37s' % stringc(u'computername', C.COLOR_OK)

    results = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(u'computername', results, color=True) == u'%-37s' % stringc(u'computername', C.COLOR_ERROR)

    results = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor(u'computername', results, color=True) == u'%-37s' % stringc(u'computername', C.COLOR_CHANGED)


# Generated at 2022-06-11 17:48:50.530820
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo.bar.org', dict(ok=1, changed=0, unreachable=0, failures=0)) == 'foo.bar.org                '



# Generated at 2022-06-11 17:49:00.789845
# Unit test for function hostcolor
def test_hostcolor():
    test_pass = dict(failures=0, changed=0, unreachable=0, skipped=0)
    test_fail = dict(failures=1, changed=0, unreachable=0, skipped=0)
    test_unreach = dict(failures=0, changed=0, unreachable=1, skipped=0)
    test_changed = dict(failures=0, changed=5, unreachable=0, skipped=0)

    assert hostcolor("localhost", test_pass) == "localhost                     "
    assert hostcolor("localhost", test_fail) == u"\x1b[31mlocalhost\x1b[0m               "
    assert hostcolor("localhost", test_unreach) == u"\x1b[31mlocalhost\x1b[0m               "

# Generated at 2022-06-11 17:49:10.917784
# Unit test for function stringc
def test_stringc():
    """Tests for function stringc."""
    # TODO: Some values are commented out since we cannot test for
    #       non-visible characters with a simple assertion
    #
    #       Though, we could test the output from `print` in which case
    #       the tests could look like this:
    #         print(u'\u001b[45m\u001b[33mfoo\u001b[0m')
    #         print(u'\u001b[45m\u001b[33m\u001b[2m\uc2a3\u001b[0m\u001b[0m')
    #         print(u'\u001b[45m\u001b[33m\u001b[2mfoo\u001b[0m\u001b[0m')

    assert string

# Generated at 2022-06-11 17:49:20.775484
# Unit test for function hostcolor
def test_hostcolor():
    """ Make sure the hostcolor function works as we expect """
    hc = hostcolor(u'localhost', dict(failures=0, unreachable=0, changed=0), color=False)
    assert hc == u"localhost                  "

    hc = hostcolor(u'localhost', dict(failures=0, unreachable=0, changed=0), color=True)
    assert hc == u"localhost                  "

    hc = hostcolor(u'localhost', dict(failures=1, unreachable=0, changed=0), color=True)
    assert hc == u"\n\033[31mlocalhost\033[0m               "

    hc = hostcolor(u'localhost', dict(failures=0, unreachable=1, changed=0), color=True)

# Generated at 2022-06-11 17:49:28.808897
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import stringc
    from ansible.constants import COLOR_ERROR, COLOR_CHANGED, COLOR_OK

    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), True) == stringc("localhost", COLOR_OK)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), True) == stringc("localhost", COLOR_CHANGED)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), True) == stringc("localhost", COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), True) == stringc("localhost", COLOR_ERROR)

# Generated at 2022-06-11 17:49:34.451363
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'color8') == u'38;5;8'
    assert parsecolor(u'rgb123') == u'38;5;21'
    assert parsecolor(u'gray7') == u'38;5;250'
    assert parsecolor(u'xyzzy') == u'1'  # default to bold



# Generated at 2022-06-11 17:49:44.398031
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat.tests import unittest

    class TestHostColor(unittest.TestCase):
        def setUp(self):
            global ANSIBLE_COLOR

            self.previous_value = ANSIBLE_COLOR
            ANSIBLE_COLOR = True

        def tearDown(self):
            global ANSIBLE_COLOR

            ANSIBLE_COLOR = self.previous_value

        def test_parse_colors(self):
            tests = dict(foreground=dict(red=91, yellow=33, green=32,
                                         blue=34, gray=90, white=97,
                                         default=39),
                         background=dict(red=101, yellow=43, green=42,
                                         blue=44, gray=100, white=107,
                                         default=49))

# Generated at 2022-06-11 17:50:00.548600
# Unit test for function hostcolor
def test_hostcolor():
    host = u"myhost"
    stats = {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 0}
    colored_host = hostcolor(host, stats, True)
    assert colored_host == u"%-37s" % u"\001\033[0;32m\002myhost\001\033[0m\002"
    colored_host = hostcolor(host, stats, False)
    assert colored_host == u"%-37s" % host
    stats['ok'] = 0
    stats['changed'] = 1
    colored_host = hostcolor(host, stats)
    assert colored_host == u"%-37s" % u"\001\033[0;33m\002myhost\001\033[0m\002"
    stats['ok'] = 0
    stats

# Generated at 2022-06-11 17:50:12.822572
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 10, 'blue') == u'foo=10  '
    assert colorize('foo', 100, 'blue') == u'foo=100 '
    assert colorize('foo', 1000, 'blue') == u'foo=1000'
    assert colorize('foo', 10000, 'blue') == u'foo=10000'
    ANSIBLE_COLOR = False
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 10, 'blue') == u'foo=10  '
    assert colorize

# Generated at 2022-06-11 17:50:22.670278
# Unit test for function stringc
def test_stringc():
    """This is a crude unit test for the stringc function."""

# Generated at 2022-06-11 17:50:25.040294
# Unit test for function stringc
def test_stringc():
    text = u"lorem ipsum"
    assert stringc(text, "blue") == u"\033[34mlorem ipsum\033[0m"



# Generated at 2022-06-11 17:50:32.687954
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        print(colorize('ok', 0, C.COLOR_OK))
        print(colorize('changed', 0, C.COLOR_CHANGED))
        print(colorize('unreachable', 3, C.COLOR_UNREACHABLE))
        print(colorize('failed', 0, C.COLOR_ERROR))
    else:
        print(colorize('ok', 0, None))
        print(colorize('changed', 0, None))
        print(colorize('unreachable', 3, None))
        print(colorize('failed', 0, None))

# --- end of pretty library



# Generated at 2022-06-11 17:50:41.861832
# Unit test for function hostcolor
def test_hostcolor():

    # Case 1: no color
    args = (u'localhost', dict(skipped=0, ok=20, failures=0, unreachable=0, changed=0), False)
    assert hostcolor(*args) == u'localhost             '

    # Case 2: color, ok
    args = (u'localhost', dict(skipped=0, ok=20, failures=0, unreachable=0, changed=0), True)
    res = u'\033[0;32mlocalhost\033[0m         '
    assert hostcolor(*args) == res

    # Case 3: color, changed
    args = (u'localhost', dict(skipped=0, ok=19, failures=0, unreachable=0, changed=1), True)
    res = u'\033[0;33mlocalhost\033[0m         '


# Generated at 2022-06-11 17:50:44.730331
# Unit test for function colorize
def test_colorize():
    a = colorize('ok', 20, C.COLOR_OK)
    b = colorize('changed', 1, C.COLOR_CHANGED)
    assert a == b


# Generated at 2022-06-11 17:50:53.723259
# Unit test for function colorize
def test_colorize():
    print(u'Testing function "colorize"')
    print(u'  Colorize a line with ANSIBLE_COLOR=false')
    sys.stdout.write(u'    ')
    sys.stdout.write(colorize(u'ok', 0, C.COLOR_OK))
    sys.stdout.write(u'    ')
    sys.stdout.write(colorize(u'changed', 0, C.COLOR_CHANGED))
    sys.stdout.write(u'    ')
    sys.stdout.write(colorize(u'unreachable', 0, C.COLOR_UNREACHABLE))
    sys.stdout.write(u'    ')
    sys.stdout.write(colorize(u'failed', 0, C.COLOR_ERROR))
    sys.stdout.write

# Generated at 2022-06-11 17:51:04.593865
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    orig = 'hello'
    color_codes = C.COLOR_CODES.iteritems()

    # Test that color codes and values match to specification

# Generated at 2022-06-11 17:51:15.972702
# Unit test for function hostcolor
def test_hostcolor():
    test_stats = {
        'failures': 0,
        'unreachable': 0,
        'changed': 1,
    }

    # Set ANSIBLE_COLOR to True
    setattr(C, 'ANSIBLE_COLOR', True)
    assert hostcolor("TestHost", test_stats) == u"\u001b[32mTestHost\u001b[0m   "
    assert test_stats['failures'] == 0
    assert test_stats['unreachable'] == 0
    assert test_stats['changed'] == 1

    # Set ANSIBLE_COLOR to False
    setattr(C, 'ANSIBLE_COLOR', False)
    assert hostcolor("TestHost", test_stats) == u"TestHost             "
    assert test_stats['failures'] == 0

# Generated at 2022-06-11 17:51:32.107434
# Unit test for function parsecolor
def test_parsecolor():
    import sys
    import unittest

    class ColorTest(unittest.TestCase):
        def color_test(self, color, ansi_value):
            self.assertEqual(parsecolor(color), ansi_value)

        def test_named_colors(self):
            self.color_test('red', '1')
            self.color_test('green', '2')
            self.color_test('yellow', '3')
            self.color_test('blue', '4')
            self.color_test('cyan', '6')
            self.color_test('white', '7')
            self.color_test('default', '9')

        def test_gray_colors(self):
            self.color_test('gray0', '232')

# Generated at 2022-06-11 17:51:43.179917
# Unit test for function stringc
def test_stringc():
    """This is a simple unit test for function stringc."""
    print(u"color test: " + stringc('color test', 'green'))
    print(u"rgb test: " + stringc('rgb test', 'rgb332'))
    print(u"color test: " + stringc('color test', 'color16'))
    print(u"color test: " + stringc('color test', 'color0'))
    print(u"color test: " + stringc('color test', 'color3'))
    print(u"color test: " + stringc('color test', 'color30'))
    print(u"color test: " + stringc('color test', 'color333'))
    print(u"color test: " + stringc('color test', 'color3334'))

# Generated at 2022-06-11 17:51:48.740164
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello World", "red"))
    print(stringc("Hello World", "green"))
    print(stringc("Hello World", "blue"))
    print(stringc("Hello World", "yellow"))
    print(stringc("Hello World", "bold red"))
    print(stringc("Hello World", "nocolor"))
    print(stringc("Hello World", "bold green on red"))

if __name__ == "__main__":
    test_stringc()

# --- end "pretty"

# Generated at 2022-06-11 17:51:59.892651
# Unit test for function hostcolor
def test_hostcolor():
    good = dict(failures=0, unreachable=0, changed=0)
    bad = dict(failures=1, unreachable=0, changed=0)
    changed = dict(failures=0, unreachable=0, changed=1)
    bad_changed = dict(failures=1, unreachable=0, changed=1)

    assert hostcolor('foo', good) == 'foo'
    assert hostcolor('foo', good, False) == 'foo'
    assert hostcolor('foo', bad) == stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', changed) == stringc('foo', C.COLOR_CHANGED)
    assert hostcolor('foo', bad_changed) == stringc('foo', C.COLOR_ERROR)

# --- end of "pretty"

# Generated at 2022-06-11 17:52:11.366667
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("host", dict(failures=0, unreachable=0, changed=1)) == "host                     "
    assert hostcolor("host", dict(failures=0, unreachable=0, changed=0)) == "host                     "
    assert hostcolor("host", dict(failures=0, unreachable=1, changed=0)) == "host                     "
    assert hostcolor("host", dict(failures=1, unreachable=0, changed=0)) == "host                     "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), False) == "localhost          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), False) == "localhost          "

# Generated at 2022-06-11 17:52:14.745037
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foobar'
    stats = dict(changed=0, failures=0, ok=0, skipped=0, unreachable=0)

    assert hostcolor(host, stats, color=True) == u"%-26s" % stringc(host, C.COLOR_OK)



# Generated at 2022-06-11 17:52:26.252806
# Unit test for function stringc
def test_stringc():
    # Note that this test may falsely fail if your console happens to
    # support more colors than I have listed here :-)
    color_codes = [('black', '0;30'), ('darkgray', '1;30'), ('blue', '0;34'), ('lightblue', '1;34'), ('green', '0;32'), ('lightgreen', '1;32'), ('cyan', '0;36'), ('lightcyan', '1;36'), ('red', '0;31'), ('lightred', '1;31'), ('purple', '0;35'), ('lightpurple', '1;35'), ('brown', '0;33'), ('yellow', '1;33'), ('lightgray', '0;37'), ('white', '1;37')]


# Generated at 2022-06-11 17:52:35.234718
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    # create stats for testing
    stats = {}
    stats['unreachable'] = 0
    stats['failures'] = 0
    stats['changed'] = 0
    # set color to False
    color = hostcolor(host, stats, color=False)
    assert color == u"%-26s" % host
    # set color to True
    color = hostcolor(host, stats, color=True)
    assert color == u"\033[0;32m%-37s\033[0m" % host
    # set unreachable
    stats['unreachable'] = 1
    color = hostcolor(host, stats, color=True)
    assert color == u"\033[0;31m%-37s\033[0m" % host
    # reset unreachable, set changed

# Generated at 2022-06-11 17:52:42.442833
# Unit test for function hostcolor
def test_hostcolor():
    # Test to see if 'host' is printed in red if stats dict has a non-zero value for 'failures'
    color = True
    host = '127.0.0.1'
    stats = {'failures' : 1}
    res = hostcolor(host, stats, color)
    assert '\x1b[31m' in res

    # Test to see if 'host' is printed in green if stats dict has a non-zero value for 'changed'
    color = True
    host = '127.0.0.1'
    stats = {'changed' : 1}
    res = hostcolor(host, stats, color)
    assert '\x1b[32m' in res

    # Test to see if 'host' is printed in yellow if stats dict has no non-zero value
    color = True

# Generated at 2022-06-11 17:52:48.528044
# Unit test for function hostcolor
def test_hostcolor():
    # hostcolor - test for ANSIBLE_COLOR=false
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert hostcolor("host1", dict(failures=1, changed=0, unreachable=0)) == u"host1"
    assert hostcolor("host1", dict(failures=0, changed=1, unreachable=0)) == u"host1"
    assert hostcolor("host1", dict(failures=0, changed=0, unreachable=1)) == u"host1"
    assert hostcolor("host1", dict(failures=0, changed=0, unreachable=0)) == u"host1"
    assert hostcolor("host1", dict(failures=1, changed=1, unreachable=1)) == u"host1"

    # hostcolor - test for ANSIBLE_COLOR

# Generated at 2022-06-11 17:53:07.573481
# Unit test for function hostcolor
def test_hostcolor():
    """ hostcolor() -- test hostcolor()
    1: test the cases where stats['failures'] or stats['unreachable'] is different than 0
    2: test the cases where stats['changed'] is different than 0
    3: test the cases where stats['failures'] or stats['unreachable'] is 0
    4: test the case where color is False
    """

    # case 1
    print('_' * 80)
    color = hostcolor(host='host1', color=True, stats={'changed': 0, 'failures': 0, 'ok': 5, 'skipped': 0, 'unreachable': 0})
    print(color)

    # case 2
    print('_' * 80)

# Generated at 2022-06-11 17:53:18.520269
# Unit test for function stringc
def test_stringc():
    """Function stringc unit test."""
    assert stringc('abc', 'red') == '\033[31mabc\033[0m'
    assert stringc('def', 'color3') == '\033[38;5;99mdef\033[0m'
    assert stringc('ghi', 'rgb25515') == '\033[38;5;9mghi\033[0m'
    assert stringc('jkl', 'rgb25500') == '\033[38;5;8mjkl\033[0m'
    assert stringc('mno', 'rgb25505') == '\033[38;5;11mno\033[0m'
    assert stringc('pqr', 'gray9') == '\033[38;5;245mpqr\033[0m'


# Generated at 2022-06-11 17:53:29.029479
# Unit test for function hostcolor
def test_hostcolor():
    def hc(h, f, u, c, r):
        stats = {
                 "failures": f,
                 "unreachable": u,
                 "changed": c
        }
        return hostcolor(h, stats).rstrip()
    assert hc("localhost", 0, 0, 0, 0) == "localhost"
    assert hc("localhost", 1, 0, 0, 0) == stringc("localhost", C.COLOR_ERROR)
    assert hc("localhost", 0, 1, 0, 0) == stringc("localhost", C.COLOR_ERROR)
    assert hc("localhost", 0, 0, 1, 0) == stringc("localhost", C.COLOR_CHANGED)

#
# end of pretty
# ---


# Generated at 2022-06-11 17:53:40.558335
# Unit test for function stringc
def test_stringc():
    test = stringc("test", "yellow", True)
    assert test[0] == "\001"
    assert test[7] == "\002"
    assert test[8] == "\033"
    assert test[11] == "3"
    assert test[12] == "3"
    assert test[14] == "m"
    assert test[15] == "t"
    assert test[16] == "e"
    assert test[17] == "s"
    assert test[18] == "t"
    assert test[-7] == "\001"
    assert test[-6] == "\033"
    assert test[-3] == "0"
    assert test[-2] == "m"
    assert test[-1] == "\002"

if __name__ == '__main__':
    test_

# Generated at 2022-06-11 17:53:48.015748
# Unit test for function hostcolor
def test_hostcolor():
    h = "a1"
    s = dict(failures=1, unreachable=2, changed=3, ok=4)
    assert hostcolor(h, s) == "a1                          "
    s = dict(failures=0, unreachable=0, changed=0, ok=4)
    assert hostcolor(h, s) == "a1                          "
    s = dict(failures=0, unreachable=0, changed=3, ok=1)
    assert hostcolor(h, s) == "a1                          "
    s = dict(failures=1, unreachable=0, changed=0, ok=3)
    assert hostcolor(h, s) == "a1                          "
    s = dict(failures=0, unreachable=2, changed=0, ok=2)
    assert host

# Generated at 2022-06-11 17:53:57.912877
# Unit test for function stringc
def test_stringc():
    print("Testing function stringc...", end=u"")

    def test(input, output, color_code):
        """Test that `stringc` generates the expected output."""
        assert input == u"\033[%sm%s\033[0m" % (color_code, output)

    test(stringc(u"hello", u"red"), u"hello", u"31")
    test(stringc(u"hello", u"blue"), u"hello", u"34")
    test(stringc(u"hello", u"lightblue"), u"hello", u"94")
    test(stringc(u"hello", u"lightblue"), u"hello", u"94")
    test(stringc(u"hello", u"lightyellow"), u"hello", u"93")

# Generated at 2022-06-11 17:54:07.559249
# Unit test for function hostcolor
def test_hostcolor():
    host = u"localhost"
    stats = {u'changed': 0, u'failures': 0, u'ok': 0, u'skipped': 0, u'unreachable': 0}
    assert hostcolor(host, stats, True)  == u'%-26s' % u'\n'.join([u'\033[32m%s\033[0m' % t for t in host.split(u'\n')])

# --- end "pretty"

# LEGACY CODE WARNING
# The following code is here for backwards compatibility reasons
# In Ansible 2.3 and older, we used to use the following functions for
# color output (no longer necessary since we use the pretty library
# above). We keep the functions here for backwards compatibility so
# that playbooks that use these functions will keep working.
#
# Once we drop support for Ans

# Generated at 2022-06-11 17:54:19.064064
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize."""
    from .color import ANSIBLE_COLOR, colorize

    # FIXME:
    try:
        from unittest import TestCase
    except ImportError:
        # Python 2.6
        from unittest2 import TestCase

    class TestAnsibleColorize(TestCase):
        """Unit test for function colorize."""

        def test_colorize(self):
            """Unit test for function colorize."""
            ANSIBLE_COLOR = True

            self.assertEqual(colorize('lead', 'num', 'green'),
                             u"\n".join([u"\033[32m%s=%-4s\033[0m" %
                                         (t, 'num') for t in 'lead'.split()]))

# Generated at 2022-06-11 17:54:26.747037
# Unit test for function colorize
def test_colorize():
    # Set color mode to True (we detect that colors work on this
    # platform)
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # 0 is white
    assert u"\u001b[37m0=0   \u001b[0m" == colorize(u"0", 0, u"white")
    # 1 is red
    assert u"\u001b[37m1=1   \u001b[0m" == colorize(u"1", 1, u"white")
    assert u"\u001b[31m1=1   \u001b[0m" == colorize(u"1", 1, u"red")



# Generated at 2022-06-11 17:54:29.996424
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, True) == 'localhost                     '


# Generated at 2022-06-11 17:54:54.278325
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, changed=0, unreachable=0)
    assert hostcolor('localhost', stats) == '%-26s' % 'localhost'
    stats = dict(failures=0, changed=1, unreachable=0)
    assert hostcolor('localhost', stats, color=False) == '%-26s' % 'localhost'


# Generated at 2022-06-11 17:55:02.939197
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        """
        output = stringc("Hello", "green", False)
        assert output == "\033[32mHello\033[0m"
        """
        output = stringc("Hello", "none", False)
        assert output == "Hello"
        output = stringc("Hello", "green", True)
        assert output == "\001\033[32m\002Hello\001\033[0m\002"

    else:
        output = stringc("Hello", "green", False)
        assert output == "Hello"

# ---- end "pretty"