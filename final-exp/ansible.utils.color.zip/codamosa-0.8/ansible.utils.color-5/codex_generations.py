

# Generated at 2022-06-11 17:45:07.340389
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {}) == '%-26s' % 'localhost'
    assert hostcolor('localhost', {'failures': 1}) == stringc('%-26s' % 'localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'changed': 1}) == stringc('%-26s' % 'localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', {'ok': 1}) == stringc('%-26s' % 'localhost', C.COLOR_OK)

# ---- end pretty
#
#
#
#



# Generated at 2022-06-11 17:45:15.964448
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats) == "%-37s" % "localhost"
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == "%-37s" % "\x1b[0;34mlocalhost\x1b[0;0m"
    stats['changed'] = 0
    stats['unreachable'] = 1
    assert hostcolor('localhost', stats) == "%-37s" % "\x1b[0;31mlocalhost\x1b[0;0m"

# Generated at 2022-06-11 17:45:21.791155
# Unit test for function stringc
def test_stringc():
    assert stringc("Hello", "red") == "\033[31mHello\033[0m"
    assert stringc("Hello", "rgb333") == "\033[38;5;59mHello\033[0m"
    assert stringc("Hello", "color8") == "\033[38;5;8mHello\033[0m"
    assert stringc("Hello", "gray4") == "\033[38;5;244mHello\033[0m"



# Generated at 2022-06-11 17:45:34.481273
# Unit test for function colorize
def test_colorize():
    # Verify the SGR string for parsecolor.
    for color in ['black', 'red', 'green', 'yellow', 'blue', 'magenta',
                  'cyan', 'white', 'dark gray', 'reset']:
        if color == 'reset':
            assert parsecolor(color) == u'0'
        else:
            assert parsecolor(color) == u'31'
    # Verify the SGR string for parsecolor.
    matches = re.match(r"^38;5;([0-9]+)", parsecolor('color3'))
    assert matches.group(1) == u'3'
    # Verify the SGR string for parsecolor.
    matches = re.match(r"^38;5;([0-9]+)", parsecolor('rgb123'))

# Generated at 2022-06-11 17:45:40.815041
# Unit test for function colorize
def test_colorize():
    test_color = "blue"
    test_string = "string"
    test_num = 5

    result = colorize(test_string, test_num, test_color)

    if ANSIBLE_COLOR:
        assert result == "%s=%-4s" % (stringc(test_string, test_color), str(test_num))
    else:
        assert result == "%s=%-4s" % (test_string, str(test_num))

# Generated at 2022-06-11 17:45:47.149485
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb123') == '38;5;52'
    assert parsecolor('gray5') == '38;5;237'

# --- End of pretty.py ---

# ===========================================
# pretty print for ansible-playbook
# by Fotis Gimian
# Aug 8, 2012
# ===========================================

# Generated at 2022-06-11 17:45:53.380443
# Unit test for function colorize
def test_colorize():
    pass
    #print (colorize("ok", 0, 'green'))
    #print (colorize("changed", 0, 'yellow'))
    #print (colorize("unreachable", 0, 'red'))
    #print (colorize("failed", 0, 'red'))
    #print (colorize("skipped", 0, 'cyan'))
    #print (colorize("ok", 1, 'green'))
    #print (colorize("changed", 1, 'yellow'))
    #print (colorize("unreachable", 1, 'red'))
    #print (colorize("failed", 1, 'red'))
    #print (colorize("skipped", 1, 'cyan'))


# Generated at 2022-06-11 17:45:54.949227
# Unit test for function hostcolor
def test_hostcolor():
    import doctest
    doctest.testmod()

# --- end "pretty"

# Generated at 2022-06-11 17:46:04.616922
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('darkgray') == u'38;5;8'
    assert parsecolor('lightgray') == u'38;5;252'
    assert parsecolor('white') == u'38;5;15'
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('darkred') == u'38;5;1'
    assert parsecolor('lightred') == u'38;5;9'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('darkgreen') == u'38;5;2'
    assert parsecolor('lightgreen') == u'38;5;10'

# Generated at 2022-06-11 17:46:13.067764
# Unit test for function colorize
def test_colorize():
    lead = u"test"
    num = 0
    color = None
    if colorize(lead, num, color) != u"test=0   ":
        raise Exception('test_colorize() failed')
    num = 3
    color = None
    if colorize(lead, num, color) != u"test=3   ":
        raise Exception('test_colorize() failed')
    num = 3
    color = 'blue'
    if colorize(lead, num, color) != u"test=3   ":
        raise Exception('test_colorize() failed')
    num = 0
    color = 'blue'
    if colorize(lead, num, color) != u"test=0   ":
        raise Exception('test_colorize() failed')
    num = 3
    color = 'blue'

# Generated at 2022-06-11 17:46:24.238828
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'changed': 0, 'failures': 0, 'ok': 10, 'unreachable': 0}
    assert hostcolor(host, stats, color=True) == 'localhost'

    stats = {'changed': 0, 'failures': 0, 'ok': 10, 'unreachable': 1}
    assert hostcolor(host, stats, color=True) == u'\033[31mlocalhost\033[0m'

    stats = {'changed': 1, 'failures': 0, 'ok': 10, 'unreachable': 0}
    assert hostcolor(host, stats, color=True) == u'\033[34mlocalhost\033[0m'

    stats = {'changed': 0, 'failures': 1, 'ok': 10, 'unreachable': 0}

# Generated at 2022-06-11 17:46:32.281840
# Unit test for function hostcolor
def test_hostcolor():
    if hostcolor('test', {'ok': 1, 'changed': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0}) != u"%-37s":
        print(u"\ncolor is off")
    if hostcolor('test', {'ok': 0, 'changed': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0}) != u"%-37s":
        print(u"\ncolor is off")
    if hostcolor('test', {'ok': 0, 'changed': 1, 'failures': 0, 'skipped': 0, 'unreachable': 0}) != u"%-37s":
        print(u"\ncolor is off")

# Generated at 2022-06-11 17:46:42.046996
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'ok': 1, 'failures': 0, 'changed': 0, 'skipped': 0, 'unreachable': 1}
    assert hostcolor(host, stats) == stringc(host, C.COLOR_ERROR)
    stats = {'ok': 1, 'failures': 0, 'changed': 1, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == stringc(host, C.COLOR_CHANGED)
    stats = {'ok': 1, 'failures': 0, 'changed': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == stringc(host, C.COLOR_OK)



# Generated at 2022-06-11 17:46:52.988256
# Unit test for function stringc
def test_stringc():
    # Normal string
    assert(stringc('Hello World!', 'red') == '\033[31mHello World!\033[0m')
    # Unclosed sequence
    assert(stringc('Hello World!\033[31m', 'red') == '\033[31mHello World!\033[0m\033[31m\033[0m')
    # Unopened sequence
    assert(stringc('\033[31mHello World!', 'red') == '\033[31m\033[31mHello World!\033[0m\033[0m')
    # No sequence
    assert(stringc('Hello World!', 'red', wrap_nonvisible_chars=True) == '\001\033[31m\002Hello World!\001\033[0m\002')
    # Sequence without closing

# Generated at 2022-06-11 17:47:03.449883
# Unit test for function stringc
def test_stringc():
    print((u'Testing function stringc'))
    print((u'Format: "text" = "expected result"'))
    print((u'"Bold text" = \033[1mbold text\033[0m'))
    res = stringc(u"bold text", u'bold')
    if res == u'\033[1mbold text\033[0m':
        print((u'OK'))
    else:
        print((u"Error in test_stringc: 'Bold test' is not returning expected result"))
        print((u"Actual result: %s" % res))
        raise Exception('test_stringc error')
    print((u'"Underline text" = \033[4munderline text\033[0m'))
    res = stringc(u"underline text", u'underline')
   

# Generated at 2022-06-11 17:47:07.383080
# Unit test for function colorize
def test_colorize():
    for i in range(-10, 10):
        print(u"%s %s" % (colorize(u"<", i, None), colorize(u">", i, None)))



# Generated at 2022-06-11 17:47:17.653299
# Unit test for function hostcolor
def test_hostcolor():
    fake_color = True
    test_stats = {'contacted': 0,
                  'dark': 0,
                  'failures': 0,
                  'ok': 0,
                  'skipped': 0,
                  'unreachable': 0,
                  'changed': 0}
    assert hostcolor('host1', test_stats, fake_color) == u'host1                     '

    test_stats.update({'contacted': 1, 'ok': 1})
    assert hostcolor('host2', test_stats, fake_color) == u'host2                     '

    test_stats.update({'changed': 1, 'ok': 0})
    assert hostcolor('host3', test_stats, fake_color) == u'host3                     '

    test_stats.update({'failures': 1})

# Generated at 2022-06-11 17:47:19.661384
# Unit test for function colorize
def test_colorize():
    return colorize('foo', 1234, 'blue')

# --- end of "pretty"



# Generated at 2022-06-11 17:47:31.098064
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "nocolor") == "test"
    assert stringc("test", "error") == "\033[31mtest\033[0m"
    assert stringc("test\nmultiline", "red") == "\033[31mtest\nmultiline\033[0m"
    assert stringc("test\nmultiline", "nocolor") == "test\nmultiline"
    assert stringc("test", "rgb255255255") == "\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb000255255") == "\033[38;5;51mtest\033[0m"

# Generated at 2022-06-11 17:47:43.865675
# Unit test for function stringc
def test_stringc():
    """Tests for function stringc."""
    assert stringc(u"black text", u"black", wrap_nonvisible_chars=False) == u"\033[30mblack text\033[0m"
    assert stringc(u"red text", u"red", wrap_nonvisible_chars=False) == u"\033[31mred text\033[0m"
    assert stringc(u"green text", u"green", wrap_nonvisible_chars=False) == u"\033[32mgreen text\033[0m"
    assert stringc(u"yellow text", u"yellow", wrap_nonvisible_chars=False) == u"\033[33myellow text\033[0m"

# Generated at 2022-06-11 17:47:57.384579
# Unit test for function stringc
def test_stringc():
    # Test use of color names
    assert stringc(u'foo', u'blue') == u"\033[34mfoo\033[0m"
    assert stringc(u'foo', u'blue', wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    # Test use of color number
    assert stringc(u'foo', u'2') == "\033[38;5;12mfoo\033[0m"
    assert stringc(u'foo', u'2', wrap_nonvisible_chars=True) == u"\001\033[38;5;12m\002foo\001\033[0m\002"
    # Test use of rgb color
    assert stringc(u'foo', u'rgb255255255')

# Generated at 2022-06-11 17:48:02.124438
# Unit test for function stringc
def test_stringc():
    """
    >>> print(stringc('foo', 'green'))
    foo
    >>> print(stringc('foo', 'color9'))
    foo
    >>> print(stringc('foo', 'rgb363'))
    foo
    >>> print(stringc('foo', 'gray1'))
    foo
    """



# Generated at 2022-06-11 17:48:11.205328
# Unit test for function colorize
def test_colorize():
    assert colorize(u"test", 0, C.COLOR_ERROR) == u"test=0   "
    assert colorize(u"test", 0, None) == u"test=0   "
    assert colorize(u"test", 0, False) == u"test=0   "
    assert colorize(u"test", u"3", C.COLOR_ERROR) == u"test=3   "
    assert colorize(u"test", u"3", None) == u"test=3   "
    assert colorize(u"test", u"3", False) == u"test=3   "
    assert colorize(u"test", 3, C.COLOR_ERROR) == u"test=3   "
    assert colorize(u"test", 3, None) == u"test=3   "

# Generated at 2022-06-11 17:48:20.634543
# Unit test for function stringc
def test_stringc():
    """Test for function stringc"""
    def test(text, color, expected, wrap_nonvisible=False):
        if wrap_nonvisible:
            print(u"testing non visible wrapping: %%s in color %%s" % (repr(text), color,))
        else:
            print(u"testing %s in color %s" % (repr(text), color,))
        result = stringc(text, color, wrap_nonvisible)
        if result == expected:
            print(u" ok")
        else:
            print(u" FAILED")
            print(u"input   : %r" % text)
            print(u"color   : %r" % color)
            print(u"result  : %r" % result)
            print(u"expected: %r" % expected)
            raise Assert

# Generated at 2022-06-11 17:48:32.443273
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor("host", dict(failures=1, unreachable=0, changed=0)) == u"\033[0;31mhost               \033[0m"
        assert hostcolor("host", dict(failures=0, unreachable=1, changed=0)) == u"\033[0;31mhost               \033[0m"
        assert hostcolor("host", dict(failures=1, unreachable=0, changed=1)) == u"\033[0;31mhost               \033[0m"
        assert hostcolor("host", dict(failures=0, unreachable=1, changed=1)) == u"\033[0;31mhost               \033[0m"

# Generated at 2022-06-11 17:48:43.782881
# Unit test for function stringc
def test_stringc():
    assert stringc(u'foo', C.COLOR_ERROR) == u'\x1b[31mfoo\x1b[0m'
    assert stringc(u'foo', u'color9') == u'\x1b[38;5;9mfoo\x1b[0m'
    assert stringc(u'foo', u'rgb123') == u'\x1b[38;5;14mfoo\x1b[0m'
    assert stringc(u'foo', u'gray5') == u'\x1b[38;5;237mfoo\x1b[0m'
    assert stringc(u'foo', u'other') == u'foo'
    # Test with non-visible characters wrapper

# Generated at 2022-06-11 17:48:54.929571
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(
        argument_spec=dict(
            test_failed=dict(default=False, type='bool'),
            test_changed=dict(default=False, type='bool'),
        ),
    )

    host_name = "test_host"
    stats = {}

    # Tests for regular display
    stats['failures'] = 0
    stats['changed'] = 0
    color = True
    output = hostcolor(host_name, stats, color)
    assert output == u"%-37s" % stringc(host_name, C.COLOR_OK)

    stats['failures'] = 1
    stats['changed'] = 0
    output = hostcolor(host_name, stats, color)
    assert output == u"%-37s" % stringc

# Generated at 2022-06-11 17:48:59.422289
# Unit test for function colorize
def test_colorize():
    colorize("ok", 0, C.COLOR_OK)
    colorize("changed", 0, C.COLOR_CHANGED)
    colorize("unreachable", 0, C.COLOR_UNREACHABLE)
    colorize("failed", 0, C.COLOR_ERROR)



# Generated at 2022-06-11 17:49:09.854503
# Unit test for function colorize
def test_colorize():
    colorize("foo", 0, None)
    colorize("foo", 0, "black")
    colorize("foo", 0, "red")
    colorize("foo", 0, "green")
    colorize("foo", 0, "yellow")
    colorize("foo", 0, "blue")
    colorize("foo", 0, "magenta")
    colorize("foo", 0, "cyan")
    colorize("foo", 0, "white")
    colorize("foo", 0, "color1")
    colorize("foo", 0, "color2")
    colorize("foo", 0, "color3")
    colorize("foo", 0, "color4")
    colorize("foo", 0, "color5")
    colorize("foo", 0, "color6")
    colorize("foo", 0, "color7")

# Generated at 2022-06-11 17:49:13.856048
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0'
    assert colorize('failed', 0, 'red') == 'failed=0    '
# --- end "pretty"



# Generated at 2022-06-11 17:49:28.856950
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0), color=True) == 'foo                         '
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0), color=True) == u'\x1b[31mfoo                         \x1b[0m'
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=1), color=True) == u'\x1b[33mfoo                         \x1b[0m'
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=1), color=True) == u'\x1b[31mfoo                         \x1b[0m'

# Generated at 2022-06-11 17:49:33.864896
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor('foo', dict(failures=0, unreachable=0, changed=0))
    hostcolor('foo', dict(failures=1, unreachable=0, changed=0))
    hostcolor('foo', dict(failures=0, unreachable=1, changed=0))
    hostcolor('foo', dict(failures=0, unreachable=0, changed=1))



# Generated at 2022-06-11 17:49:44.191253
# Unit test for function stringc
def test_stringc():
    assert stringc('text', 'red') == u'\033[31mtext\033[0m'
    assert stringc('text', 'rgb200') == u'\033[38;5;208mtext\033[0m'
    assert stringc('text', 'rgb020') == u'\033[38;5;58mtext\033[0m'
    assert stringc('text', 'rgb002') == u'\033[38;5;16mtext\033[0m'
    assert stringc('text', 'rgb200', True) == u'\001\033[38;5;208m\002text\001\033[0m\002'

# Generated at 2022-06-11 17:49:50.526532
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo.bar.example.com'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) == u'\033[0;32m%-26s\033[0m' % host
    stats['changed'] = 1
    assert hostcolor(host, stats, True) == u'\033[0;33m%-26s\033[0m' % host
    stats['unreachable'] = 1
    assert hostcolor(host, stats, True) == u'\033[0;31m%-26s\033[0m' % host

# Generated at 2022-06-11 17:49:56.113480
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, C.COLOR_ERROR) == 'ok=0   '
    assert colorize('changed', 1, C.COLOR_CHANGED) == 'changed=1 '
    assert colorize('failed', 0, C.COLOR_OK) == 'failed=0 '
    assert colorize('failed', 1, None) == 'failed=1 '


# end "pretty"

# Generated at 2022-06-11 17:50:04.265243
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'ok': 0, 'changed':0, 'unreachable':0, 'failures':0}
    assert hostcolor('host1', stats, color=False) == 'host1               '
    assert hostcolor('host2', stats, color=False) == 'host2               '

    stats['unreachable'] = 1
    assert hostcolor('host1', stats, color=True) == u"\n\x1b[31mhost1                             \x1b[0m"
    assert hostcolor('host2', stats, color=False) == 'host2               '

    stats['unreachable'] = 0
    stats['failures'] = 1
    assert hostcolor('host1', stats, color=True) == u"\n\x1b[31mhost1                             \x1b[0m"
   

# Generated at 2022-06-11 17:50:13.415812
# Unit test for function hostcolor
def test_hostcolor():
    for host in [ 'localhost', 'mymachine.mydomain.com' ]:
        for stats in [ {'failures':0, 'unreachable':0, 'changed':0},
                       {'failures':0, 'unreachable':1, 'changed':0},
                       {'failures':1, 'unreachable':0, 'changed':0},
                       {'failures':1, 'unreachable':1, 'changed':0},
                       {'failures':0, 'unreachable':0, 'changed':1} ]:
            print(hostcolor(host, stats))


# Generated at 2022-06-11 17:50:18.081336
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('rgb123') == u'38;5;202'
    assert parsecolor('gray5') == u'38;5;234'
    assert parsecolor('color255') == u'38;5;255'



# Generated at 2022-06-11 17:50:25.626270
# Unit test for function stringc
def test_stringc():
    sys.stdout = open('/dev/null', 'w')  # Don't really print to stdout
    if not ANSIBLE_COLOR:
        print("Warning: ANSIBLE_COLOR not set so test_stringc() won't work")
        return

    format = u'{t.normal}, {t.black}, {t.red}, {t.green}, {t.yellow}, ' \
             u'{t.blue}, {t.magenta}, {t.cyan}, {t.white}, {t.black_bg}, ' \
             u'{t.red_bg}, {t.green_bg}, {t.yellow_bg}, ' \
             u'{t.blue_bg}, {t.magenta_bg}, {t.cyan_bg}, {t.white_bg}.'


# Generated at 2022-06-11 17:50:34.300466
# Unit test for function hostcolor
def test_hostcolor():
    host = "foo"
    stats = {'failed': 0, 'changed': 0, 'unreachable': 0}
    assert hostcolor(host, stats, color=True) == '\033[0;32mfoo               \033[0m'
    stats = {'failed': 1, 'changed': 0, 'unreachable': 0}
    assert hostcolor(host, stats, color=True) == '\033[0;31mfoo               \033[0m'
    stats = {'failed': 0, 'changed': 1, 'unreachable': 0}
    assert hostcolor(host, stats, color=True) == '\033[0;33mfoo               \033[0m'
    stats = {'failed': 0, 'changed': 0, 'unreachable': 1}

# Generated at 2022-06-11 17:50:51.506253
# Unit test for function hostcolor
def test_hostcolor():
    import sys
    sys.stdout.isatty = lambda: True
    assert hostcolor('foobar', dict(failures=0, unreachable=0, changed=0)) == u"\x1b[0;32m%-26s\x1b[0m" % 'foobar'
    assert hostcolor('foobar', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31m%-26s\x1b[0m" % 'foobar'
    assert hostcolor('foobar', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;33m%-26s\x1b[0m" % 'foobar'

# Generated at 2022-06-11 17:51:03.040298
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'red') == u'\033[31;1mtest\033[0m'
    assert stringc('test', 'white') == u'\033[37;1mtest\033[0m'
    assert stringc('test', 'color3') == u'\033[38;5;3mtest\033[0m'
    assert stringc('test', 'rgb255') == u'\033[38;5;231mtest\033[0m'
    assert stringc('test', 'gray10') == u'\033[38;5;245mtest\033[0m'
    assert stringc('test', 'bgcolor1') == u'\033[48;5;1mtest\033[0m'

# Generated at 2022-06-11 17:51:14.627852
# Unit test for function hostcolor
def test_hostcolor():
    # We mock the statistics structure to be able to test colorize()
    stats = dict(
        ok=10,
        changed=0,
        unreachable=0,
        failures=0
    )
    host = 'test.example.org'
    assert 'test.example.org' in hostcolor(host, stats, False)
    assert 'test.example.org' in hostcolor(host, stats, True)
    assert 'test.example.org' not in stringc(host, C.COLOR_ERROR)
    assert 'test.example.org' not in stringc(host, C.COLOR_OK)
    stats = dict(
        ok=0,
        changed=0,
        unreachable=0,
        failures=1
    )

# Generated at 2022-06-11 17:51:21.725132
# Unit test for function hostcolor
def test_hostcolor():
    """
    >>> hostcolor("127.0.0.1", dict(ok=1, changed=0, unreachable=0, failed=0))
    u'127.0.0.1                           '
    >>> hostcolor("127.0.0.1", dict(ok=0, changed=1, unreachable=0, failed=0))
    u'127.0.0.1                           '
    >>> hostcolor("127.0.0.1", dict(ok=0, changed=0, unreachable=1, failed=0))
    u'127.0.0.1                           '
    >>> hostcolor("127.0.0.1", dict(ok=0, changed=0, unreachable=0, failed=1))
    u'127.0.0.1                           '
    """
    pass



# Generated at 2022-06-11 17:51:32.952581
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == "34"
    assert parsecolor("white") == "37"
    assert parsecolor("color42") == "38;5;42"
    assert parsecolor("color09") == "38;5;9"
    assert parsecolor("color111") == "38;5;111"
    assert parsecolor("color255") == "38;5;255"
    assert parsecolor("rgb001") == "38;5;16"
    assert parsecolor("rgb555") == "38;5;231"
    assert parsecolor("rgb123") == "38;5;54"
    assert parsecolor("rgb124") == "38;5;58"
    assert parsecolor("rgb222") == "38;5;118"

# Generated at 2022-06-11 17:51:43.796791
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"black", False) == u"\033[30mfoo\033[0m"
    assert stringc(u"foo", u"#ff00ff", False) == u"\033[38;5;213mfoo\033[0m"
    assert stringc(u"foo", u"rgb255000", False) == u"\033[38;5;9mfoo\033[0m"
    assert stringc(u"foo", u"rgb255255255", False) == u"\033[38;5;231mfoo\033[0m"
    assert stringc(u"foo", u"gray8", False) == u"\033[38;5;244mfoo\033[0m"
    assert stringc(u"foo", u"white", False) == u

# Generated at 2022-06-11 17:51:48.915114
# Unit test for function stringc
def test_stringc():
    for color in ['black', 'dark gray', 'blue', 'light blue', 'green', 'light green',
                  'cyan', 'light cyan', 'red', 'light red', 'purple', 'light purple',
                  'brown', 'yellow', 'light gray', 'white']:
        print("%sThis is %s text%s" % (stringc("==>", C.COLOR_ERROR), color, stringc("<==", C.COLOR_ERROR)))



# Generated at 2022-06-11 17:52:00.268225
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.playbook.task import Task
    from ansible.inventory.host import Host

    mytask = Task()
    mytask.name = 'test'
    host = Host(name="hostname")
    color = True

    stats = host.get_variable_manager().get_vars(host=host)['hostvars'][host.name]
    stats['failures'] = stats['changed'] = stats['unreachable'] = stats['ok'] = 0

    assert hostcolor(u"hostname", stats, color) == u"hostname                  "

    stats['failures'] = stats['changed'] = stats['unreachable'] = 1
    assert u"\033" in hostcolor(u"hostname", stats, color)

    stats['failures'] = stats['changed'] = stats['unreachable'] = 0
   

# Generated at 2022-06-11 17:52:05.880826
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        ok=1,
        changed=2,
        unreachable=3,
        failures=4,
        skipped=5,
    )
    host = 'host'
    assert hostcolor(host, stats) == 'host                          '
    assert hostcolor(host, stats, color=False) == 'host                                        '

    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert hostcolor(host, stats) == 'host                          '
    ANSIBLE_COLOR = True

    stats['failures'] = 0
    assert hostcolor(host, stats) == '\x1b[0;32mhost                          \x1b[0m'
    stats['changed'] = 0

# Generated at 2022-06-11 17:52:16.133433
# Unit test for function hostcolor
def test_hostcolor():
    # Test when color is set to True and False
    for color in [True, False]:
        # Test for various state combinations
        for state in [['failures', 'unreachable'], ['changed', 'unreachable']]:
            # Use a different integer value for each state
            host = 'test.example.com'
            state_value = (('failures', 1), ('unreachable', 2), ('changed', 3))
            stats = dict([(v,k) for k,v in state_value])
            assert hostcolor(host, stats, color) == '%-37s' % ('test.example.com=%d' % stats[state[0]]), 'hostcolor failed for host %s' % host

        # Test for the remaining state
        host = 'test.example.com'
        state = 'ok'

# Generated at 2022-06-11 17:52:41.336850
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    # all ok
    assert hostcolor("testhost", stats) == u"testhost                    "  # no color
    assert hostcolor("testhost", stats, color=True) == u"testhost                    "  # no color
    # changed
    stats['changed'] = 1
    assert hostcolor("testhost", stats) == u"testhost                    "  # no color
    assert hostcolor("testhost", stats, color=True) == u"\x1b[0;34;49mtesthost\x1b[0m            "  # ok
    # failures
    stats['changed'] = 0
    stats['failures'] = 1
    assert hostcolor("testhost", stats) == u"testhost                    "  # no color

# Generated at 2022-06-11 17:52:51.931569
# Unit test for function hostcolor
def test_hostcolor():
    tests = [
        ('red', {'changed': 0, 'failures': 1, 'ok': 3, 'skipped': 0, 'unreachable': 0},
         u'%-37s' % stringc('red', C.COLOR_ERROR)),
        ('green', {'changed': 5, 'failures': 0, 'ok': 3, 'skipped': 0, 'unreachable': 0},
         u'%-37s' % stringc('green', C.COLOR_CHANGED)),
        ('blue', {'changed': 0, 'failures': 0, 'ok': 3, 'skipped': 0, 'unreachable': 0},
         u'%-37s' % stringc('blue', C.COLOR_OK)),
    ]

# Generated at 2022-06-11 17:52:59.205313
# Unit test for function hostcolor

# Generated at 2022-06-11 17:53:07.766120
# Unit test for function hostcolor
def test_hostcolor():
    C.COLOR_OK = None
    C.COLOR_ERROR = None
    C.COLOR_CHANGED = None
    assert hostcolor('foo.example.com', {'failures': 2, 'unreachable': 0, 'changed': 0}) == 'foo.example.com        '
    assert hostcolor('foo.example.com', {'failures': 0, 'unreachable': 1, 'changed': 0}) == 'foo.example.com        '
    assert hostcolor('foo.example.com', {'failures': 0, 'unreachable': 0, 'changed': 1}) == 'foo.example.com        '
    C.COLOR_OK = 'blue'
    C.COLOR_ERROR = 'red'
    C.COLOR_CHANGED = 'yellow'

# Generated at 2022-06-11 17:53:18.706380
# Unit test for function hostcolor
def test_hostcolor():
    fake_host = 'juniper-switch'
    stats = {'ignored': 0, 'changed': 1, 'failures': 0, 'dark': 0, 'unreachable': 0,
             'skipped': 0, 'ok': 2}

    # Test with unreachable host
    stats['unreachable'] = 1
    result = hostcolor(fake_host, stats, color=True)
    assert result == u"\x1b[31m%-37s\x1b[0m", 'Bad color when host is unreachable'

    # Test with changed host
    stats['unreachable'] = 0
    stats['changed'] = 1
    result = hostcolor(fake_host, stats, color=True)

# Generated at 2022-06-11 17:53:29.601187
# Unit test for function stringc
def test_stringc():
    def check(text, color, wrap_nonvisible_chars=False):
        if not isinstance(text, str):
            text = text.encode('utf-8')
        if not isinstance(color, str):
            color = color.encode('utf-8')
        if not isinstance(wrap_nonvisible_chars, bool):
            wrap_nonvisible_chars = wrap_nonvisible_chars.encode('utf-8')
        print(u"stringc(%s, %s, %s) = %s" % (text, color, wrap_nonvisible_chars, stringc(text, color, wrap_nonvisible_chars)))

    check(u"normal", "green")
    check(u"normal", u"green")
    check(u"normal", "color2")

# Generated at 2022-06-11 17:53:41.265409
# Unit test for function hostcolor

# Generated at 2022-06-11 17:53:48.371102
# Unit test for function stringc
def test_stringc():
    # Test border cases of color names
    assert stringc("HELLO", "red") == "\033[31mHELLO\033[0m"
    assert stringc("HELLO", "RED") == "\033[31mHELLO\033[0m"
    assert stringc("HELLO", "bLue") == "\033[34mHELLO\033[0m"

    # Test some color numbers
    assert stringc("HELLO", "color16") == "\033[38;5;16mHELLO\033[0m"
    assert stringc("HELLO", "color109") == "\033[38;5;109mHELLO\033[0m"

    # Test some RGB values

# Generated at 2022-06-11 17:53:58.150713
# Unit test for function colorize
def test_colorize():

    good = 'ok      '
    fail = 'fail    '
    unreach = 'unreach '
    changed = 'changed '

    # tests for ANSIBLE_COLOR=False
    assert colorize(good, 0, 'blue') == good
    assert colorize(good, 0, None) == good
    assert colorize(good, 1, 'blue') == good
    assert colorize(good, 1, None) == good
    assert colorize(good, 0, 'blue') == good
    assert colorize(fail, 1, 'red') == fail
    assert colorize(fail, 1, None) == fail
    assert colorize(unreach, 1, 'red') == unreach
    assert colorize(changed, 0, 'yellow') == changed

    # tests for ANSIBLE_COLOR=True
    global ANSIBLE_COLOR
   

# Generated at 2022-06-11 17:54:07.591133
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor("test_host", dict(failures=1, unreachable=1, changed=0)) == u"%-37s" % stringc("test_host", C.COLOR_ERROR)
        assert hostcolor("test_host", dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc("test_host", C.COLOR_CHANGED)
        assert hostcolor("test_host", dict(failures=0, unreachable=0, changed=0)) == u"%-37s" % stringc("test_host", C.COLOR_OK)
        assert hostcolor("test_host", dict(failures=1, unreachable=0, changed=1)) == u"%-37s" % stringc("test_host", C.COLOR_ERROR)


# Generated at 2022-06-11 17:54:51.598838
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    color = False

    assert hostcolor("host.example.com", stats, color) == u"host.example.com          "
    color = True
    stats['failures'] = 1
    assert hostcolor("host.example.com", stats, color) == u"host.example.com          "
    stats['failures'] = 0
    stats['changed'] = 1
    assert hostcolor("host.example.com", stats, color) == u"host.example.com          "
    stats['changed'] = 0
    assert hostcolor("host.example.com", stats, color) == u"host.example.com          "

# --- end "pretty"

# Generated at 2022-06-11 17:54:57.783763
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == "foo=0   "
    assert colorize('foo', 1, 'blue') == "foo=1   "
    assert colorize('foo', 12, 'blue') == "foo=12  "
    assert colorize('foo', 123, 'blue') == "foo=123 "
    assert colorize('foo', 1234, 'blue') == "foo=1234"
    assert colorize('foo', 12345, 'blue') == "foo=12345"

# --- end