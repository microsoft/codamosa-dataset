

# Generated at 2022-06-23 13:43:45.049788
# Unit test for function stringc
def test_stringc():
    """sample test"""
    print(u"\nstringc()")

# Generated at 2022-06-23 13:43:53.189445
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host=u"host",
                     stats={u'changed': 0,
                            u'failures': 0,
                            u'ok': 0,
                            u'skipped': 0,
                            u'unreachable': 0}) == u"host                 "
    assert hostcolor(host=u"host",
                     stats={u'changed': 1,
                            u'failures': 0,
                            u'ok': 0,
                            u'skipped': 0,
                            u'unreachable': 0},
                     color=True) == u"\x1b[0;36mhost\x1b[0m               "

# Generated at 2022-06-23 13:44:02.611135
# Unit test for function parsecolor

# Generated at 2022-06-23 13:44:10.098605
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '38;5;4'
    assert parsecolor('bright purple') == '38;5;141'
    assert parsecolor('white') == '38;5;15'
    assert parsecolor('color01') == '38;5;1'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('rgb111') == '38;5;7'
    assert parsecolor('rgb123') == '38;5;21'
    assert parsecolor('rgb333') == '38;5;111'
    assert parsecolor('rgb321') == '38;5;101'
    assert parsecolor('rgb000') == '38;5;16'

# Generated at 2022-06-23 13:44:21.902593
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"www.example.com", {'changed': 0, 'failures': 0, 'ok': 10, 'skipped': 0, 'unreachable': 0}, color=True) == u"\033[0;32m%-37s\033[0m" % u"www.example.com"
    assert hostcolor(u"www.example.com", {'changed': 1, 'failures': 0, 'ok': 10, 'skipped': 0, 'unreachable': 0}, color=True) == u"\033[0;33m%-37s\033[0m" % u"www.example.com"
    assert hostcolor(u"www.example.com", {'changed': 0, 'failures': 1, 'ok': 10, 'skipped': 0, 'unreachable': 0}, color=True)

# Generated at 2022-06-23 13:44:29.209768
# Unit test for function parsecolor
def test_parsecolor():
    import unittest

    class TestParseColor(unittest.TestCase):
        def test_default_colors(self):
            for k, v in C.COLOR_CODES.items():
                self.assertEqual(parsecolor(k), v)

        def test_256_colors(self):
            self.assertEqual(parsecolor('color0'), u'38;5;0')
            self.assertEqual(parsecolor('color255'), u'38;5;255')
            self.assertEqual(parsecolor('color256'), u'38;5;0')
            self.assertEqual(parsecolor('color257'), u'38;5;1')
            self.assertEqual(parsecolor('color51'), u'38;5;51')
            self.assertEqual

# Generated at 2022-06-23 13:44:32.362190
# Unit test for function colorize
def test_colorize():
    pass #print stringc("this is {{status}}", "{{status|colorize(color)}}", dict(status='failed', color='red'))


# Generated at 2022-06-23 13:44:38.339449
# Unit test for function stringc
def test_stringc():
    assert stringc("this is a test", "red") == "\033[31mthis is a test\033[0m"
    assert stringc("this is a test", "blue") == "\033[34mthis is a test\033[0m"
    assert stringc("this is a test", "magenta") == "\033[35mthis is a test\033[0m"

test_stringc()

# --- end of pretty code
#



# Generated at 2022-06-23 13:44:48.952895
# Unit test for function hostcolor
def test_hostcolor():
    # Return host in color or not
    assert(hostcolor('foohost', {'failures': 1}, True).startswith('\033') == ANSIBLE_COLOR)
    # Return in color when a host is unreachable, has changed or is ok
    assert(hostcolor('foohost', {'unreachable': 1}, ANSIBLE_COLOR).startswith('\033') == ANSIBLE_COLOR)
    assert(hostcolor('foohost', {'changed': 1}, ANSIBLE_COLOR).startswith('\033') == ANSIBLE_COLOR)
    assert(hostcolor('foohost', {'ok': 1}, ANSIBLE_COLOR).startswith('\033') == ANSIBLE_COLOR)
    # Return not in color when a host is ok

# Generated at 2022-06-23 13:44:59.973907
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(changed=1)) == u"%-26s" % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1)) == u"%-26s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(unreachable=1)) == u"%-26s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(ok=1)) == u"%-26s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(changed=1), color=False) == u"%-26s" % 'localhost'

# --- end "pretty" ----



# Generated at 2022-06-23 13:45:04.463093
# Unit test for function colorize
def test_colorize():
    assert colorize(u"test", 1, C.COLOR_ERROR) == stringc(u"test=1", C.COLOR_ERROR)
    assert colorize(u"test", 0, C.COLOR_ERROR) == u"test=0  "



# Generated at 2022-06-23 13:45:15.459081
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo.example.com", {'failures': 1, 'ok': 2, 'changed': 3, 'unreachable': 0}, True) == u'\033[31mfoo.example.com\033[0m            '
    assert hostcolor("foo.example.com", {'failures': 0, 'ok': 2, 'changed': 3, 'unreachable': 1}, True) == u'\033[31mfoo.example.com\033[0m            '
    assert hostcolor("foo.example.com", {'failures': 0, 'ok': 2, 'changed': 3, 'unreachable': 0}, True) == u'\033[33mfoo.example.com\033[0m            '

# Generated at 2022-06-23 13:45:25.508120
# Unit test for function colorize

# Generated at 2022-06-23 13:45:37.799213
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('color9') == '38;5;9'
    assert parsecolor('color10') == '38;5;10'

# Generated at 2022-06-23 13:45:45.430774
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    else:
        assert stringc("foo", "red") == "foo"
        assert stringc("foo", "red", wrap_nonvisible_chars=True) == "foo"


# --- end "pretty"
#
#
#
# --- begin custom
#



# Generated at 2022-06-23 13:45:57.370761
# Unit test for function hostcolor
def test_hostcolor():
    # check case where host is OK
    hostOK = u"127.0.0.1"
    statsOK = dict(failures=0, unreachable=0, ok=3, changed=0, skipped=0)

    # check case where host is changed
    hostChanged = u"192.168.0.1"
    statsChanged = dict(failures=0, unreachable=0, ok=3, changed=1, skipped=0)

    # check case where host is failed
    hostFailed = u"::1"
    statsFailed = dict(failures=1, unreachable=0, ok=3, changed=0, skipped=0)

    # check case where host is unreachable
    hostUnreachable = u"8.8.8.8"

# Generated at 2022-06-23 13:46:05.464884
# Unit test for function stringc
def test_stringc():
    s = stringc("Hello World!", "red")
    print(s)
    assert s == u'\033[31mHello World!\033[0m'
    s = stringc("Hello World!", "rgb255255255")
    print(s)
    assert s == u'\033[38;5;15mHello World!\033[0m'
    s = stringc("Hello World!", "rgb000255000")
    print(s)
    assert s == u'\033[38;5;10mHello World!\033[0m'
# --- end "pretty"

if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-23 13:46:15.883541
# Unit test for function hostcolor
def test_hostcolor():
    ''' hostcolor unit tests '''
    # Ansible config set to disable color
    C.ANSIBLE_NOCOLOR = True
    assert hostcolor('foobar', dict(changed=1), True) == u'foobar        '
    assert hostcolor('foobar', dict(changed=1), False) == u'foobar        '
    C.ANSIBLE_NOCOLOR = False

    # Missing color codes
    C.COLOR_ERROR = None
    C.COLOR_CHANGED = None
    C.COLOR_OK = None
    assert hostcolor('foobar', dict(changed=1), True) == u'foobar        '
    assert hostcolor('foobar', dict(changed=1), False) == u'foobar        '
    C.COLOR_ERROR = 'red'

# Generated at 2022-06-23 13:46:26.444485
# Unit test for function stringc
def test_stringc():
    """Unit test for stringc"""
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "color1") == "\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb000") == "\033[38;5;16mtest\033[0m"
    assert stringc("test", "rgb555") == "\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb555", True) == "\001\033[38;5;231m\002test\001\033[0m\002"
    assert stringc("test", "gray0") == "\033[38;5;232mtest\033[0m"

# Generated at 2022-06-23 13:46:33.205806
# Unit test for function colorize
def test_colorize():
    # Test 1: colorize with num == 0 and color == None
    lead = 'lead'
    num = 0
    color = None
    expected = 'lead=0   '
    result = colorize(lead, num, color)
    assert result == expected

    # Test 2: colorize with num != 0 and color != None
    lead = 'lead'
    num = 1
    color = 'blue'
    if ANSIBLE_COLOR:
        expected = stringc(lead + '=' + str(num), color)
    else:
        expected = lead + '=' + str(num)
    result = colorize(lead, num, color)
    assert result == expected

    # Test 3: colorize with num != 0 and ANSIBLE_COLOR == False
    lead = 'lead'
    num = 1
    color = 'blue'


# Generated at 2022-06-23 13:46:42.845060
# Unit test for function stringc
def test_stringc():
    """Test the stringc() function."""
    assert stringc("Test", "blue") == u"\033[34mTest\033[0m"
    assert stringc("Test", "rgb050") == u"\033[38;5;82mTest\033[0m"
    assert stringc("Test", "rgb255") == u"\033[38;5;15mTest\033[0m"
    assert stringc("Test", "rgb205") == u"\033[38;5;45mTest\033[0m"
    assert stringc("Test", "rgb220") == u"\033[38;5;51mTest\033[0m"

# Generated at 2022-06-23 13:46:51.729909
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'green') == stringc('foo=0   ', 'green')
    assert colorize('foo', 1, 'green') == stringc('foo=1   ', 'green')
    assert colorize('foo', 10, 'green') == stringc('foo=10  ', 'green')
    assert colorize('foo', 100, 'green') == stringc('foo=100 ', 'green')
    assert colorize('foo', 1000, 'green') == stringc('foo=1000', 'green')


# --- end "pretty"


# Generated at 2022-06-23 13:46:59.203193
# Unit test for function hostcolor
def test_hostcolor():
    test_colorize = hostcolor(u'host', {u'failures': 0, u'ok': 1, u'changed': 0, u'unreachable': 0}, color=True)
    test_noncolorize = hostcolor(u'host', {u'failures': 0, u'ok': 1, u'changed': 0, u'unreachable': 0}, color=False)
    correct_colorize = u'\x1b[0;32mhost                 \x1b[0m'
    correct_noncolorize = u'host                   '
    assert test_colorize == correct_colorize
    assert test_noncolorize == correct_noncolorize



# Generated at 2022-06-23 13:47:09.678042
# Unit test for function hostcolor
def test_hostcolor():
    # There is no test of hostcolor with no change or failure
    stats = dict(changed=1, failures=0, unreachable=0)
    assert hostcolor(u'1.2.3.4', stats) == u"1.2.3.4                       "
    assert hostcolor(u'1.2.3.4', stats, color=False) == u"1.2.3.4             "
    stats = dict(changed=0, failures=1, unreachable=0)
    assert hostcolor(u'1.2.3.4', stats) == u"\x1b[31;01m1.2.3.4              \x1b[0m"
    assert hostcolor(u'1.2.3.4', stats, color=False) == u"1.2.3.4             "
    stats

# Generated at 2022-06-23 13:47:22.485635
# Unit test for function stringc
def test_stringc():
    from ansible.utils.color import stringc

    # Test all the color names
    for color in ('black', 'red', 'green', 'yellow', 'blue',
                  'magenta', 'cyan', 'white'):
        print(stringc("This text should be %s." % color, color))

    # Test numeric values
    for color in range(0, 256):
        # Skip normal foreground / background colors
        if color < 8 or color > 15:
            print(stringc("This text should be color #%s." % color,
                          "color%d" % color))

    # Test several shades of gray
    for color in range(0, 24):
        print(stringc("This text should be gray #%s." % color,
                      "gray%d" % color))

    # Test RGB color values

# Generated at 2022-06-23 13:47:34.158179
# Unit test for function stringc
def test_stringc():
    class DummyOpts:
        pass
    opts = DummyOpts()
    opts.color = True
    print(stringc(u'this is a test','red'))
    print(stringc(u'this is a test','blue'))
    print(stringc(u'this is a test','green'))
    print(stringc(u'this is a test','yellow'))
    print(stringc(u'this is a test','purple'))
    print(stringc(u'this is a test','cyan'))
    print(stringc(u'this is a test','white'))
    print(stringc(u'this is a test','black'))
    print(stringc(u'this is a test','brightyellow'))

# Generated at 2022-06-23 13:47:40.401708
# Unit test for function parsecolor
def test_parsecolor():
    """Test parsing of color parameter."""
    # these should all yield the same result
    assert parsecolor('color15') == parsecolor(15)
    assert parsecolor('color15') == parsecolor('rgb555')
    assert parsecolor('color15') == parsecolor('gray0')
    # these should all yield the same result
    assert parsecolor('color21') == parsecolor(21)
    assert parsecolor('color21') == parsecolor('rgb555')
    assert parsecolor('color21') == parsecolor('rgb543')
    assert parsecolor('color21') == parsecolor('rgb520')
    assert parsecolor('color21') == parsecolor('gray1')
    # these should all yield the same result
    assert parsecolor('color234') == parsec

# Generated at 2022-06-23 13:47:45.278118
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = dict(changed=0, failures=0, unreachable=0)

    assert hostcolor(host, stats, color=True) != hostcolor(host, stats, color=False)
    assert hostcolor(host, stats, color=False) == u"%-26s" % host


# Generated at 2022-06-23 13:47:51.157828
# Unit test for function hostcolor
def test_hostcolor():
    ''' hostcolor returns the correct color and padding'''
    # ANSIBLE_COLOR is True
    assert hostcolor('server', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'%-37s'
    assert hostcolor('server', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'%-37s'
    assert hostcolor('server', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'%-37s'
    assert hostcolor('server', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'%-37s'

    # ANSIBLE_COLOR is False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False

# Generated at 2022-06-23 13:48:01.906211
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '1'
    assert parsecolor('black') == '30'
    assert parsecolor('darkgray') == '1;30'
    assert parsecolor('lightgreen') == '1;32'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb124') == '38;5;172'
    assert parsecolor('rgb333') == '38;5;89'
    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb123') == '38;5;101'
    assert parsecolor('gray0') == '38;5;232'

# Generated at 2022-06-23 13:48:09.385062
# Unit test for function colorize
def test_colorize():
    lead = u"test_lead"
    num = 42
    assert u"test_lead=42" == colorize(lead, num, None)
    assert u"test_lead=42" == colorize(lead, num, False)
    assert lead + u"=\033[32m42\033[0m" == colorize(lead, num, C.COLOR_CHANGED)
    assert lead + u"=\033[32m42\033[0m" == colorize(lead, num, True)
# --- end "pretty"



# Generated at 2022-06-23 13:48:21.213017
# Unit test for function stringc

# Generated at 2022-06-23 13:48:32.522315
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(ok=1, changed=0, unreachable=0, failures=0), color=True) == u"host                 \033[0;32m\033[0m"
    assert hostcolor('host', dict(ok=0, changed=1, unreachable=0, failures=0), color=True) == u"host                 \033[0;33m\033[0m"
    assert hostcolor('host', dict(ok=0, changed=0, unreachable=1, failures=0), color=True) == u"host                 \033[0;31m\033[0m"
    assert hostcolor('host', dict(ok=0, changed=0, unreachable=0, failures=1), color=True) == u"host                 \033[0;31m\033[0m"
    assert host

# Generated at 2022-06-23 13:48:42.317097
# Unit test for function hostcolor

# Generated at 2022-06-23 13:48:54.117074
# Unit test for function colorize
def test_colorize():
    # A sample output of Ansible
    outstr = ("\n"
              "10.0.2.15               : ok=2    changed=1    unreachable=0    failed=0   \n"
              "10.0.2.16               : ok=2    changed=1    unreachable=0    failed=0   \n")
    # The output with colorized "changed"
    rightstr = ("\n"
                "10.0.2.15               : ok=2    \033[0;32;40mchanged\033[0m=1    unreachable=0    failed=0   \n"
                "10.0.2.16               : ok=2    \033[0;32;40mchanged\033[0m=1    unreachable=0    failed=0   \n")

# Generated at 2022-06-23 13:49:05.406289
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'ok': 1}
    host = u"yourhostname.com"
    # expects yourhostname.com to be set to green
    print(hostcolor(host, stats))
    stats = {'failures': 1}
    # expects yourhostname.com to be set to red
    print(hostcolor(host, stats))
    stats = {'changed': 1}
    # expects yourhostname.com to be set to yellow
    print(hostcolor(host, stats))
    stats = {'ok': 1, 'changed': 1, 'failures': 1, 'unreachable': 1}
    # expects yourhostname.com to be set to red
    print(hostcolor(host, stats))
    stats = {'ok': 2, 'changed': 1, 'failures': 3, 'unreachable': 4}


# Generated at 2022-06-23 13:49:14.905976
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc("test", "red") == "\x1b[31mtest\x1b[0m"
        assert stringc("test", "blue") == "\x1b[34mtest\x1b[0m"
        assert stringc("test", "color5") == "\x1b[38;5;5mtest\x1b[0m"
        assert stringc("test", "rgb123") == "\x1b[38;5;61mtest\x1b[0m"
        assert stringc("test", "rgb213") == "\x1b[38;5;129mtest\x1b[0m"
        assert stringc("test", "rgb345") == "\x1b[38;5;184mtest\x1b[0m"

# Generated at 2022-06-23 13:49:24.876788
# Unit test for function stringc
def test_stringc():
    """Run some tests on stringc() to ensure it's
       working as expected."""
    assert stringc('foo', 'green', wrap_nonvisible_chars=True) == u"\001\033[32m\002foo\001\033[0m\002"
    # Unix systems will add a space
    assert stringc('bar', 'blue') in [u"\033[34mbar\033[0m", u"\033[34mbar \033[0m"]
    # Windows systems won't add a space
    assert stringc('bar', 'blue')[:-1] == u"\033[34mbar"

# --- end of code from "pretty" ---



# Generated at 2022-06-23 13:49:30.574240
# Unit test for function stringc
def test_stringc():
    tests = [("test", "blue"),
             (u"\u2192", "green"),
             ("\x1B[33mtest", "default"),
             (u"\u2192\x1B[37m", "blue"),
             ("test", "color13"),
             ("test", "rgb010"),
             ("test", "grAy8")]
    for txt, color in tests:
        yield check_stringc, txt, color


# Generated at 2022-06-23 13:49:36.660406
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('skipped', 3, 'cyan') == 'skipped=3   '



# Generated at 2022-06-23 13:49:48.444833
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 0}) == u"%-37s" % 'foo'
    assert hostcolor('foo', {'failures': 1, 'unreachable': 0, 'changed': 0, 'ok': 0}) == u"%-37s" % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', {'failures': 0, 'unreachable': 1, 'changed': 0, 'ok': 0}) == u"%-37s" % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', {'failures': 0, 'unreachable': 0, 'changed': 1, 'ok': 0}) == u"%-37s" % stringc('foo', C.COLOR_CHANGED)
   

# Generated at 2022-06-23 13:49:59.356490
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('foo', 'red', False) == u'\033[31mfoo\033[0m'
        assert stringc('foo', 'red', True) == u'\001\033[31m\002foo\001\033[0m\002'
        assert stringc('foo\n', 'red', False) == u'\033[31mfoo\n\033[0m'
        assert stringc('foo\n', 'red', True) == u'\001\033[31m\002foo\n\001\033[0m\002'

# Generated at 2022-06-23 13:50:09.679018
# Unit test for function hostcolor
def test_hostcolor():
    import ansible.constants as C

    host = 'localhost'
    stats = {'changed': 0, 'failures': 0, 'ok': 6, 'skipped': 0, 'unreachable': 0}
    color_ok = hostcolor(host, stats, color=True)
    color_off = hostcolor(host, stats, color=False)
    assert color_ok == u"%-37s" % stringc(host, C.COLOR_OK)
    assert color_off == u"%-26s" % host

    stats = {'changed': 1, 'failures': 0, 'ok': 5, 'skipped': 0, 'unreachable': 0}
    color_ok = hostcolor(host, stats, color=True)
    color_off = hostcolor(host, stats, color=False)

# Generated at 2022-06-23 13:50:16.108406
# Unit test for function colorize
def test_colorize():
    """Tests to ensure that colorize prints what we expect it to."""
    assert u"ok=0  " == colorize(u"ok", 0, C.COLOR_OK)
    assert u"ok=123" == colorize(u"ok", 123, C.COLOR_OK)
    assert u"changed=123" == colorize(u"changed", 123, C.COLOR_CHANGED)
    assert u"failed=123" == colorize(u"failed", 123, C.COLOR_ERROR)



# Generated at 2022-06-23 13:50:21.517987
# Unit test for function hostcolor
def test_hostcolor():
    host = "testhost"
    stats = {
            'changed': 0,
            'dark': 0,
            'failures': 0,
            'ok': 0,
            'processed': 0,
            'skipped': 0,
            'unreachable': 0,
            }
    # 1. test all zeroes
    assert hostcolor(host, stats) == "%-26s" % host
    # 2. test with ANSIBLE_COLOR=0
    C.ANSIBLE_NOCOLOR = True
    assert hostcolor(host, stats) == "%-26s" % host
    C.ANSIBLE_NOCOLOR = False
    # 3. test with ANSIBLE_COLOR=1 and failures
    stats['failures'] = 1

# Generated at 2022-06-23 13:50:34.120557
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('dark red') == '38;5;9'
    assert parsecolor('bright green') == '38;5;2'
    assert parsecolor('default') == '38;5;15'
    assert parsecolor('darkgray') == '38;5;234'
    assert parsecolor('white') == '38;5;15'
    assert parsecolor('brightyellow') == '38;5;11'
    assert parsecolor('darkmagenta') == '38;5;5'
    assert parsecolor('brightyellow') == '38;5;11'
    assert parsecolor('yellow') == '38;5;11'
    assert parsecolor('23') == '38;5;23'
    assert parsecolor('rgb255255255') == '38;5;15'


# Generated at 2022-06-23 13:50:43.028494
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc("This is a test", "green") == "\033[32mThis is a test\033[0m"
        assert stringc("This is a test", "0;31") == "\033[0;31mThis is a test\033[0m"

# --- end "pretty" ---

# --- begin "plugins/filter/core.py"
#
# (c) 2012-2014, Michael DeHaan <michael.dehaan@gmail.com>
#

import os
import shlex
import operator
import getpass
from collections import OrderedDict
from itertools import groupby, chain
from ansible import __version__
from ansible import constants as C
from jinja2.filters import environmentfilter
from ansible.plugins.filter.ipaddr import *


# Generated at 2022-06-23 13:50:54.368955
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'default') == '\033[39mfoo\033[0m'
    assert stringc('foo', 'black') == '\033[30mfoo\033[0m'

    assert stringc('foo\nbar', 'blue') == '\033[34mfoo\nbar\033[0m'


# Generated at 2022-06-23 13:51:01.264235
# Unit test for function hostcolor
def test_hostcolor():
    # Use empty dict for stats
    stats = {}

    for color in [C.COLOR_ERROR, C.COLOR_CHANGED, C.COLOR_OK]:
        assert hostcolor(u"hostname", stats, color).endswith(u"hostname")
    assert (hostcolor(u"hostname", stats, False).endswith(u"hostname"))

# --- end "pretty"



# Generated at 2022-06-23 13:51:10.494762
# Unit test for function parsecolor

# Generated at 2022-06-23 13:51:18.978933
# Unit test for function hostcolor
def test_hostcolor():
    for host in [u"host0", u"host12.example.org", u"long-host-name-0.example.org"]:
        assert hostcolor(host, {}) == u"%-26s" % host
        assert hostcolor(host, {u'changed': 0}) == u"%-26s" % host
        assert hostcolor(host, {u'changed': 1}) == u"%-37s" % stringc(host, 'green')
        assert hostcolor(host, {u'changed': 1, u'failures': 1}) == u"%-37s" % stringc(host, 'red')
        assert hostcolor(host, {u'changed': 1, u'failures': 1, u'unreachable': 1}) == u"%-37s" % stringc(host, 'red')

# Generated at 2022-06-23 13:51:30.977630
# Unit test for function parsecolor
def test_parsecolor():
    test_data = dict()
    test_data[0] = dict()
    test_data[0]['input'] = 'default'
    test_data[0]['expected_output'] = '39'
    test_data[1] = dict()
    test_data[1]['input'] = 'color0'
    test_data[1]['expected_output'] = '38;5;0'
    test_data[2] = dict()
    test_data[2]['input'] = 'color15'
    test_data[2]['expected_output'] = '38;5;15'
    test_data[3] = dict()
    test_data[3]['input'] = 'color255'
    test_data[3]['expected_output'] = '38;5;255'
    test_data

# Generated at 2022-06-23 13:51:38.123871
# Unit test for function stringc
def test_stringc():
    assert repr(parsecolor('black')) == u"'30'"
    assert repr(stringc(u'test', 'black')) == u"'\\x1b[30mtest\\x1b[0m'"


# --- end "pretty"
#
# The following code is also from pretty.py, but is modified to remove
# the "wrapping" behavior of stringc, so that the exact text is displayed
# without leading/trailing escape characters.
#

# Generated at 2022-06-23 13:51:48.005452
# Unit test for function stringc
def test_stringc():
    print(stringc("test", "blue"))
    print(stringc("test", "orange"))
    print(stringc("test", "yellow"))
    print(stringc("test", "red"))
    print(stringc("test", "magenta"))
    print(stringc("test", "green"))
    print(stringc("test", "cyan"))
    print(stringc("test", "white"))
    print(stringc("test", "gray"))
    print(stringc("test", "color8"))
    print(stringc("test", "rgb123"))
    print(stringc("test", "rgb222"))
    print(stringc("test", "rgb321"))
    print(stringc("test", "rgb212"))
    print(stringc("test", "rgb122"))

# Generated at 2022-06-23 13:52:00.671156
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'black') == '\x1b[30mtest\x1b[0m'
    assert stringc('test', 'red') == '\x1b[31mtest\x1b[0m'
    assert stringc('test', 'green') == '\x1b[32mtest\x1b[0m'
    assert stringc('test', 'yellow') == '\x1b[33mtest\x1b[0m'
    assert stringc('test', 'blue') == '\x1b[34mtest\x1b[0m'
    assert stringc('test', 'magenta') == '\x1b[35mtest\x1b[0m'

# Generated at 2022-06-23 13:52:11.928292
# Unit test for function stringc
def test_stringc():
    # Test simple color strings
    assert stringc("Hello", "red") == u'\033[91mHello\033[0m'
    assert stringc("Hello", "green") == u'\033[92mHello\033[0m'
    assert stringc("Hello", "yellow") == u'\033[93mHello\033[0m'
    assert stringc("Hello", "blue") == u'\033[94mHello\033[0m'
    assert stringc("Hello", "magenta") == u'\033[95mHello\033[0m'
    assert stringc("Hello", "cyan") == u'\033[96mHello\033[0m'

    # Test gray strings

# Generated at 2022-06-23 13:52:24.784827
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('hostname', dict(failures=0, unreachable=0, changed=0)) == u"hostname                   "
    assert hostcolor('hostname', dict(failures=1, unreachable=0, changed=0)) == u"hostname                   "
    assert hostcolor('hostname', dict(failures=0, unreachable=1, changed=0)) == u"hostname                   "
    assert hostcolor('hostname', dict(failures=0, unreachable=0, changed=1)) == u"hostname                   "
    assert hostcolor('hostname', dict(failures=0, unreachable=0, changed=0), False) == u"hostname                   "
    ANSIBLE_COLOR = True

# Generated at 2022-06-23 13:52:35.308896
# Unit test for function colorize
def test_colorize():
    import ansible.constants as C
    from ansible.utils.color import colorize

    for color in [ 'black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan',
                  'white', 'rgb0', 'rgb1', 'rgb2', 'rgb3', 'rgb4', 'rgb5', 'rgb6',
                  'rgb7', 'rgb8', 'rgb9', 'rgb10', 'rgb11', 'rgb12', 'rgb13',
                  'rgb14', 'rgb15' ]:
        s = colorize('=', 1, color)
        print(s)

# --- end "pretty"
#

# --- begin "lexer"
#
# src: https://github.com/mitsuhiko/japronto

# Generated at 2022-06-23 13:52:46.238990
# Unit test for function stringc
def test_stringc():
    """ a simple test for stringc """
    tests = (('red', 'color1'),
             ('color1', 'color1'),
             ('rgb123', 'rgb123'),
             ('rgb313', 'rgb313'),
             ('rgb331', 'rgb331'),
             ('rgb333', 'rgb333'),
             ('gray0', 'gray0'),
             ('gray7', 'gray7'))
    for t in tests:
        try:
            p = parsecolor(t[0])
            if p != C.COLOR_CODES[t[1]]:
                raise Exception("bad match for color %s" % t[0])
        except:
            raise Exception("could not match color %s" % t[0])
    print("SUCCESS: all test cases for parsecolor passed")

# Generated at 2022-06-23 13:52:57.128372
# Unit test for function stringc
def test_stringc():
    assert stringc('teststring', 'blue') == u'\033[34mteststring\033[0m'
    assert stringc('teststring', 'red') == u'\033[31mteststring\033[0m'
    assert stringc('teststring', 'color30') == u'\033[30mteststring\033[0m'
    assert stringc('teststring', 'color40') == u'\033[40mteststring\033[0m'
    assert stringc('teststring', 'rgb0 1 1') == u'\033[36mteststring\033[0m'
    assert stringc('teststring', 'rgb1 1 0') == u'\033[43mteststring\033[0m'

# Generated at 2022-06-23 13:53:05.031278
# Unit test for function stringc
def test_stringc():
    print(stringc("foo", "blue"))
    print(stringc("foo", "red"))
    print(stringc("foo", "green"))
    print(stringc("foo", "yellow"))
    print(stringc("foo", "magenta"))
    print(stringc("foo", "cyan"))
    print(stringc("foo", "white"))
    print(stringc("foo", "black"))
    print(stringc("foo", "color0"))
    print(stringc("foo", "color1"))
    print(stringc("foo", "color2"))
    print(stringc("foo", "color3"))
    print(stringc("foo", "color4"))
    print(stringc("foo", "color5"))
    print(stringc("foo", "color6"))

# Generated at 2022-06-23 13:53:15.889450
# Unit test for function colorize
def test_colorize():
    # we need to reset colors
    print_stderr(u"TEST: colorize(): Colors should reset themselves")
    print_stderr(colorize(u'ok', 1, C.COLOR_OK))
    print_stderr(colorize(u'changed', 1, C.COLOR_CHANGED))
    print_stderr(colorize(u'unreachable', 1, C.COLOR_UNREACHABLE))
    print_stderr(colorize(u'failed', 1, C.COLOR_ERROR))
    print_stderr(colorize(u'qty', 1, None))

    print_stderr(u"TEST: colorize(): 0 counts should not be colorized")
    print_stderr(colorize(u'ok', 0, C.COLOR_OK))
    print_st

# Generated at 2022-06-23 13:53:27.655591
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=0), color=True) == u"host1                          "
    assert hostcolor('host1', dict(failures=1, unreachable=0, changed=0), color=True) == u"host1                          "
    assert hostcolor('host1', dict(failures=0, unreachable=1, changed=0), color=True) == u"host1                          "
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=1), color=True) == u"host1                          "

# --- end "pretty"

# ANSIBALLZ colorization constants
BG_BLACK = u"\033[40m"
BG_RED = u"\033[41m"
BG_GREEN = u

# Generated at 2022-06-23 13:53:33.930270
# Unit test for function stringc
def test_stringc():
    """Convenience function for doctests."""
    # `textwrap` is used to compare the results of calling
    # `stringc` with and without the `wrap_nonvisible_chars`
    # option, because Python 3 returns a byte string from
    # `stringc` which causes the comparison to fail.
    from textwrap import dedent
    lead = u"*"
    num = 1
    color = u"green"
    s = colorize(lead, num, color)
    assert s == u"*=1   ", u"colorize error: %r" % s
    color = u"badcolor"
    s = colorize(lead, num, color)
    assert s == u"*=1   ", u"colorize error: %r" % s
    color = None

# Generated at 2022-06-23 13:53:34.750765
# Unit test for function hostcolor
def test_hostcolor():
    # Can't reliably test this
    assert True

