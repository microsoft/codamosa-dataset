

# Generated at 2022-06-23 13:43:41.906564
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', dict(failures=1, unreachable=0, changed=0, ok=0), color=True) == stringc('host1', C.COLOR_ERROR) + u' '
    assert hostcolor('host2', dict(failures=0, unreachable=1, changed=0, ok=0), color=True) == stringc('host2', C.COLOR_ERROR) + u' '
    assert hostcolor('host3', dict(failures=0, unreachable=0, changed=1, ok=0), color=True) == stringc('host3', C.COLOR_CHANGED) + u' '
    assert hostcolor('host4', dict(failures=0, unreachable=0, changed=0, ok=1), color=True) == stringc('host4', C.COLOR_OK) + u

# Generated at 2022-06-23 13:43:51.288870
# Unit test for function stringc
def test_stringc():
    # Simple test of colorization
    assert stringc('Invisible', 'red') == '\033[31mInvisible\033[0m'

    # Test that colorization is not performed if ANSIBLE_COLOR is False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert stringc('Invisible', 'red') == 'Invisible'
    ANSIBLE_COLOR = True

    # Test that quotes and backslashes in input string are preserved
    assert stringc('The characters `"\` should be preserved', 'red') == '\033[31mThe characters `"\\` should be preserved\033[0m'

    # Test that newlines are processed properly

# Generated at 2022-06-23 13:43:58.706331
# Unit test for function stringc
def test_stringc():
    assert(stringc(u"test", u"red") ==
           u"\033[38;5;9mtest\033[0m")
    assert(stringc(u"test", u"lightgray") ==
           u"\033[38;5;250mtest\033[0m")
    assert(stringc(u"test", u"color7") ==
           u"\033[38;5;7mtest\033[0m")
    assert(stringc(u"test", u"rgb123") ==
           u"\033[38;5;33mtest\033[0m")
    assert(stringc(u"test", u"rgb321") ==
           u"\033[38;5;87mtest\033[0m")

# Generated at 2022-06-23 13:44:08.146325
# Unit test for function stringc
def test_stringc():
    # Can't test fancy colors with doctest,
    # but we can at least make sure no exceptions are raised
    stringc("Text", "black")
    stringc("Text", "dark gray")
    stringc("Text", "dark red")
    stringc("Text", "light red")
    stringc("Text", "dark green")
    stringc("Text", "light green")
    stringc("Text", "brown")
    stringc("Text", "yellow")
    stringc("Text", "dark blue")
    stringc("Text", "light blue")
    stringc("Text", "dark magenta")
    stringc("Text", "light magenta")
    stringc("Text", "dark cyan")
    stringc("Text", "light cyan")
    stringc("Text", "light gray")
    stringc("Text", "white")

# Generated at 2022-06-23 13:44:20.491064
# Unit test for function stringc
def test_stringc():
    good_colors = C.COLOR_CODES.keys()
    good_colors.extend([u"gray0", u"gray1", u"gray2", u"gray3", u"gray4",
                        u"gray5", u"gray6", u"gray7", u"gray8", u"gray9"])
    good_colors.extend([u"rgb000", u"rgb122", u"rgb333", u"rgb444", u"rgb555",
                        u"rgb777", u"rgb888", u"rgb999", u"rgbaaa", u"rgbdbb"])
    good_colors.extend([u"color" + str(c) for c in range(0, 256)])
    good_colors.extend([None])

# Generated at 2022-06-23 13:44:28.994023
# Unit test for function stringc
def test_stringc():
    assert '\033[32mval\033[0mue' == stringc("value", "green")
    assert '\033[32mval\033[0mue' == stringc("value", "color2")
    assert '\033[32mval\033[0mue' == stringc("value", "rgb20")
    assert '\033[32mval\033[0mue' == stringc("value", "rgb2010")
    assert '\033[32mval\033[0mue' == stringc("value", "rgb00200")
    assert '\033[32mval\033[0mue' == stringc("value", "rgb22000")
    assert '\033[32mval\033[0mue' == stringc("value", "gray8")

# Generated at 2022-06-23 13:44:40.413728
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = dict(changed=1, failures=1, unreachable=0, skipped=0, ok=1)
    stats2 = dict(changed=0, failures=0, unreachable=0, skipped=0, ok=1)
    stats3 = dict(changed=0, failures=0, unreachable=0, skipped=1, ok=1)
    stats4 = dict(changed=0, failures=0, unreachable=0, skipped=0, ok=0)


# Generated at 2022-06-23 13:44:50.499376
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('black') == '30'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color100') == '38;5;100'
    assert parsecolor('rgb123') == '38;5;105'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('gray3') == '38;5;235'
    assert parsecolor('gray4') == '38;5;236'
    assert parsecolor('gray8') == '38;5;240'
    assert parsecolor('gray9')

# Generated at 2022-06-23 13:45:02.580171
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        return

    # ANSIBLE_COLOR should now be true (or undefined)
    assert(colorize(u"test", u"0"))
    assert(colorize(u"test", u"1"))
    assert(colorize(u"test", u"2"))
    assert(colorize(u"test", u"3"))

    # Make sure that ANSIBLE_NOCOLOR=1 works
    old_color = ANSIBLE_COLOR
    globals()['ANSIBLE_COLOR'] = False
    assert(colorize(u"test", u"0"))
    assert(colorize(u"test", u"1"))
    assert(colorize(u"test", u"2"))
    assert(colorize(u"test", u"3"))

# Generated at 2022-06-23 13:45:08.273631
# Unit test for function stringc

# Generated at 2022-06-23 13:45:15.066037
# Unit test for function hostcolor
def test_hostcolor():
    for host in [("localhost", {'failures': 0, 'unreachable': 0, 'changed': 0}),
                 ("localhost", {'failures': 0, 'unreachable': 0, 'changed': 1}),
                 ("localhost", {'failures': 0, 'unreachable': 1, 'changed': 0}),
                 ("localhost", {'failures': 1, 'unreachable': 0, 'changed': 0})]:
        print("%-20s %s" % (host[0], hostcolor(*host)))



# Generated at 2022-06-23 13:45:23.783078
# Unit test for function parsecolor
def test_parsecolor():
    from sys import stderr
    def t(name, expected):
        result = parsecolor(name)
        if result != expected:
            stderr.write("%r should parse as %r but instead parsed as %r\n" %
                         (name, expected, result))
    t("black", u"30")
    t("red", u"31")
    t("green", u"32")
    t("yellow", u"33")
    t("blue", u"34")
    t("magenta", u"35")
    t("cyan", u"36")
    t("white", u"37")
    t("nocolor", u"39")
    t("default", u"39")
    t("color0", u"38;5;0")

# Generated at 2022-06-23 13:45:24.363367
# Unit test for function stringc
def test_stringc():
    stringc("1", "rgb025")



# Generated at 2022-06-23 13:45:36.578456
# Unit test for function colorize
def test_colorize():
    for i in range(0, 2):
        for j in range(0, 2):
            for k in range(0, 2):
                msg = "( Ok:" + str(i) + " Changes:" + str(j) + " Unreachable:" + str(k) + " )"
                print("%s %s" % (colorize("Ok", i, C.COLOR_OK), msg))
                print("%s %s" % (colorize("Changed", j, C.COLOR_CHANGED), msg))
                print("%s %s" % (colorize("Unreachable", k, C.COLOR_UNREACHABLE), msg))
                print("%s %s" % (colorize("Failures", k, C.COLOR_ERROR), msg))


# Generated at 2022-06-23 13:45:44.512859
# Unit test for function parsecolor
def test_parsecolor():
    """Test function parsecolor"""
    assert parsecolor('black') == '30'
    assert parsecolor('dark gray') == '90'
    assert parsecolor('blue') == '34'
    assert parsecolor('bright magenta') == '95'
    assert parsecolor('bright green') == '92'
    assert parsecolor('cyan') == '36'
    assert parsecolor('default') == '39'
    assert parsecolor('bright black') == '90'
    assert parsecolor('color199') == '38;5;199'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb123') == '38;5;54'
    assert parsecolor('rgb333') == '38;5;102'
    assert parsecolor

# Generated at 2022-06-23 13:45:52.942121
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0, ok=1)) == "host                            "
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0, ok=0)) == "host                            "
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0, ok=0)) == "host                            "
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1, ok=0)) == "host                            "



# Generated at 2022-06-23 13:46:03.770670
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('green') == '32'
    assert parsecolor('dark gray') == '90'
    assert parsecolor('color234') == '38;5;234'
    assert parsecolor('rgb123') == '38;5;37'
    assert parsecolor('rgb123') == '38;5;37'
    assert parsecolor('rgb555') == '38;5;255'
    assert parsecolor('rgb123') == '38;5;37'
    assert parsecolor('rgb123') == '38;5;37'
    assert parsecolor('rgb123') == '38;5;37'
    assert parsecolor('rgb123') == '38;5;37'
    assert parsecolor('gray0') == '38;5;232'

# Generated at 2022-06-23 13:46:14.889486
# Unit test for function hostcolor
def test_hostcolor():
    # No color should be the same for all
    stats = dict.fromkeys(['failures', 'unreachable', 'changed'], 0)
    assert hostcolor('host', stats, color=False) == hostcolor('host', stats, color=True)

    # One color for each possible stats combinations
    for stats in [dict(failures=1), dict(unreachable=1), dict(changed=1)]:
        color_host = hostcolor('host', dict(stats, **dict(changed=0)), color=True)
        assert color_host != hostcolor('host', dict(stats, **dict(changed=1)), color=True)
        assert color_host != hostcolor('host', dict(stats, **dict(changed=0, failures=0)), color=True)

# Generated at 2022-06-23 13:46:24.956504
# Unit test for function hostcolor
def test_hostcolor():
    # TODO: Mock ansible.constants.COLOR_ERROR, COLOR_CHANGED, COLOR_OK
    if ANSIBLE_COLOR:
        assert hostcolor("test", dict(failures=0, unreachable=0, changed=0)) == u"%-26s" % stringc("test", C.COLOR_OK)
        assert hostcolor("test", dict(failures=1, unreachable=0, changed=0)) == u"%-26s" % stringc("test", C.COLOR_ERROR)
        assert hostcolor("test", dict(failures=0, unreachable=0, changed=1)) == u"%-26s" % stringc("test", C.COLOR_CHANGED)

# Generated at 2022-06-23 13:46:26.447211
# Unit test for function colorize
def test_colorize():
    ''' colorize should print colors '''
    for i in range(100):
        colorize('test', i, 'red')

# Test for function parsecolor

# Generated at 2022-06-23 13:46:28.855826
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 4, 'blue') == u"foo=4   "
    assert colorize(u'\u00a5', 4, 'red') == u"\u00a5=4   "



# Generated at 2022-06-23 13:46:39.794609
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test for function parsecolor"""
    def _test(result, data):
        return '%s => %s' % (data, result)
    def _assert(result, data):
        return _test(result, data) + ' => %s' % (result == data)

    assert parsecolor('default') == '39'
    assert parsecolor('0') == '38;5;0'
    assert parsecolor('1') == '38;5;1'
    assert parsecolor('2') == '38;5;2'
    assert parsecolor('3') == '38;5;3'
    assert parsecolor('4') == '38;5;4'
    assert parsecolor('5') == '38;5;5'

# Generated at 2022-06-23 13:46:47.820581
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', {}, False) == 'foo                 '
    assert hostcolor('foo', {}, True) == u"%-26s" % stringc('foo', C.COLOR_OK)
    assert hostcolor('foo', {'changed': 15}, True) == \
        u"%-26s" % stringc('foo', C.COLOR_CHANGED)
    assert hostcolor('foo', {'unreachable': 1}, True) == \
        u"%-26s" % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', {'failures': 3}, True) == \
        u"%-26s" % stringc('foo', C.COLOR_ERROR)

# Generated at 2022-06-23 13:46:57.678609
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        # These strings should all be the same after stripping invisible
        # characters
        assert u"\001\033[38;5;10m\002foo\001\033[0m\002" == stringc(
            u'foo', u'color10', wrap_nonvisible_chars=True)
        assert u"\001\033[38;5;10m\002foo\001\033[0m\002" == stringc(
            u'foo', u'color10')
        assert u"\001\033[38;5;10m\002foo\001\033[0m\002" == stringc(
            u'foo', u'rgb2030')

# Generated at 2022-06-23 13:47:09.532591
# Unit test for function parsecolor
def test_parsecolor():

    parsecolor('red')
    parsecolor('rgb123')
    parsecolor('rgb555')
    parsecolor('rgb124')
    parsecolor('rgb1234')
    parsecolor('color1')
    parsecolor('color2')
    parsecolor('color3')
    parsecolor('color4')
    parsecolor('color5')
    parsecolor('color6')
    parsecolor('color7')
    parsecolor('color8')
    parsecolor('color9')
    parsecolor('color10')
    parsecolor('color11')
    parsecolor('color12')
    parsecolor('color13')
    parsecolor('color14')
    parsecolor('color15')
    parsecolor('color16')

# Generated at 2022-06-23 13:47:20.751610
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('RED') == '31'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color100') == '38;5;100'
    assert parsecolor('rgb123') == '38;5;63'
    assert parsecolor('rgb321') == '38;5;119'
    assert parsecolor('rgb223') == '38;5;51'
    assert parsecolor('rgb233') == '38;5;57'


# --- end "pretty"



# Generated at 2022-06-23 13:47:22.687184
# Unit test for function stringc
def test_stringc():
    assert stringc(u"text here", u'blue') == u"\033[34mtext here\033[0m"



# Generated at 2022-06-23 13:47:34.365211
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5') == u'38;5;5'
    assert parsecolor('color6') == u'38;5;6'
    assert parsecolor('color7') == u'38;5;7'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('color9') == u'38;5;9'
    assert parsecolor('color10')

# Generated at 2022-06-23 13:47:46.323062
# Unit test for function hostcolor
def test_hostcolor():
    u"hostcolor()"
    host = u'localhost'

    # Test with 'color' enabled
    assert hostcolor(host, dict(failures=0, unreachable=0, changed=0), True) == u"%-37s" % stringc(host, C.COLOR_OK)
    assert hostcolor(host, dict(failures=1, unreachable=0, changed=0), True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    assert hostcolor(host, dict(failures=0, unreachable=1, changed=0), True) == u"%-37s" % stringc(host, C.COLOR_ERROR)

# Generated at 2022-06-23 13:47:48.452786
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        sys.stderr.write('\nwarning: terminal does not support color\n')



# Generated at 2022-06-23 13:48:00.277435
# Unit test for function hostcolor
def test_hostcolor():
    host = "host1"
    stats = {'changed':0, 'failures':0, 'unreachable':0}
    print(hostcolor(host, stats))
    stats = {'changed':1, 'failures':0, 'unreachable':0}
    print(hostcolor(host, stats))
    stats = {'changed':0, 'failures':1, 'unreachable':0}
    print(hostcolor(host, stats))
    stats = {'changed':0, 'failures':0, 'unreachable':1}
    print(hostcolor(host, stats))
    stats = {'changed':1, 'failures':1, 'unreachable':0}
    print(hostcolor(host, stats))

# --- end of "pretty" ---



# Generated at 2022-06-23 13:48:07.113366
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'

    stats = dict(
        ok         = 0,
        failures   = 0,
        unreachable= 0,
        changed    = 0,
        skipped    = 0,
    )
    res = hostcolor(host, stats)

    assert res == '%-37s' % stringc(host, C.COLOR_OK, wrap_nonvisible_chars=False)

    stats = dict(
        ok         = 0,
        failures   = 1,
        unreachable= 0,
        changed    = 0,
        skipped    = 0,
    )
    res = hostcolor(host, stats)

    assert res == '%-37s' % stringc(host, C.COLOR_ERROR, wrap_nonvisible_chars=False)


# Generated at 2022-06-23 13:48:12.124005
# Unit test for function colorize
def test_colorize():
    for i in range(4):
        print(u"%s ... %s" % (colorize(u'V', i, u'green'), colorize(u'X', i, u'red')))

# --- end "pretty"



# Generated at 2022-06-23 13:48:22.553234
# Unit test for function stringc
def test_stringc():
    assert stringc("GREEN", "green") == u'\033[32mGREEN\033[0m'
    assert stringc("YELLOW", "yellow") == u'\033[33mYELLOW\033[0m'
    assert stringc("MAGENTA", "magenta") == u'\033[35mMAGENTA\033[0m'
    assert stringc("CYAN", "cyan") == u'\033[36mCYAN\033[0m'

    assert stringc("GREEN", "color2") == u'\033[38;5;2mGREEN\033[0m'
    assert stringc("YELLOW", "color3") == u'\033[38;5;3mYELLOW\033[0m'
    assert stringc("MAGENTA", "color5") == u

# Generated at 2022-06-23 13:48:33.911050
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('blue') == '34'
    assert parsecolor('bold') == '1'
    assert parsecolor('cyan') == '36'
    assert parsecolor('green') == '32'
    assert parsecolor('lightgray') == '37'
    assert parsecolor('lightgrey') == '37'
    assert parsecolor('magenta') == '35'
    assert parsecolor('red') == '31'
    assert parsecolor('white') == '97'
    assert parsecolor('yellow') == '33'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'

# Generated at 2022-06-23 13:48:41.617516
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor_test = 'foo'
    stats_test = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(hostcolor_test, stats_test, True) == u'\x1b[0;32mfoo\x1b[0m              '
    assert hostcolor(hostcolor_test, stats_test, False) == u'foo                    '

    stats_test = {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(hostcolor_test, stats_test, True) == u'\x1b[0;33mfoo\x1b[0m              '


# Generated at 2022-06-23 13:48:53.931343
# Unit test for function colorize
def test_colorize():
    # dummy data for unit test
    colorize_data = [('ok', 10, None), ('changed', 5, None), ('dark_green', 2, None),
                     ('failed', 1, None), ('unreachable', 0, None), ('skipped', 0, None)]
    # expected output for unit test
    colorize_output = '[ok=10   ][changed=5  ][dark_green=2 ][failed=1   ][unreachable=0][skipped=0   ]'
    # variable to hold the output from function colorize
    colorize_result = ''

    # Test function colorize()
    for data in colorize_data:
        colorize_result += colorize(data[0], data[1], data[2])

    #assert that the result matches the expected output
    assert colorize_result == colorize_output

# Generated at 2022-06-23 13:49:05.174519
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor("testhost", dict(failures=1, unreachable=1, changed=1), True))
    print(hostcolor("testhost", dict(failures=1, unreachable=1, changed=0), True))
    print(hostcolor("testhost", dict(failures=0, unreachable=1, changed=1), True))
    print(hostcolor("testhost", dict(failures=0, unreachable=0, changed=1), True))
    print(hostcolor("testhost", dict(failures=0, unreachable=0, changed=0), True))


# --- end "pretty"

# --- begin "constants"

# ANSI color codes (from http://www.kde.org/faq.html)
#
# Code: 0   1   2   3   4   5   6  

# Generated at 2022-06-23 13:49:08.451257
# Unit test for function colorize
def test_colorize():
    print(colorize("FF  ", "100%", "green"))
    print(colorize("FF  ", "100%", "red"))
    print(colorize("FF  ", "100%", None))



# Generated at 2022-06-23 13:49:11.485595
# Unit test for function colorize
def test_colorize():
    colors = ['black', 'red', 'green', 'yellow', 'blue', 'purple', 'cyan', 'white']
    for c in colors:
        print(colorize("", c, c))


# unit test for function hostcolor

# Generated at 2022-06-23 13:49:22.116483
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = dict(
        changed=0,
        skipped=0,
        unreachable=0,
        failed=0,
    )
    stats2 = dict(
        changed=0,
        skipped=0,
        unreachable=1,
        failed=0,
    )
    stats3 = dict(
        changed=1,
        skipped=0,
        unreachable=0,
        failed=0,
    )
    stats4 = dict(
        changed=1,
        skipped=0,
        unreachable=1,
        failed=0,
    )
    assert hostcolor('ok_host', stats1) == u'ok_host                 '
    assert hostcolor('unreachable_host', stats2) == u'unreachable_host     '

# Generated at 2022-06-23 13:49:29.165354
# Unit test for function colorize
def test_colorize():
    BLACK, RED, GREEN, YELLOW, BLUE, MAGENTA, CYAN, WHITE = range(30, 38)
    _STRINGC_COLORS = ('black', 'red', 'green', 'yellow',
                       'blue', 'magenta', 'cyan', 'white')
    for c in _STRINGC_COLORS:
        assert colorize("xxx", 0, c) == stringc("xxx=0", c)
        assert colorize("xxx", 1, c) == stringc("xxx=1", c)
        assert colorize("xxx", 12, c) == stringc("xxx=12", c)
        assert colorize("xxx", 123, c) == stringc("xxx=123", c)
        assert colorize("xxx", 1234, c) == stringc("xxx=1234", c)


# Generated at 2022-06-23 13:49:33.504359
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;12' == parsecolor(u'color12')
    assert u'38;5;123' == parsecolor(u'rgb101112')
    assert u'38;5;232' == parsecolor(u'gray0')
    assert u'38;5;250' == parsecolor(u'gray7')
    assert u'38;5;15' == parsecolor(u'rgb505050')
# --- end "pretty"

# Generated at 2022-06-23 13:49:44.385640
# Unit test for function hostcolor
def test_hostcolor():
    for a_c in [True, False]:
        yield hostcolor, "localhost", dict(failures=0, unreachable=0, changed=0), a_c
        yield hostcolor, "localhost", dict(failures=1, unreachable=0, changed=0), a_c
        yield hostcolor, "localhost", dict(failures=0, unreachable=1, changed=0), a_c
        yield hostcolor, "localhost", dict(failures=0, unreachable=0, changed=1), a_c
        yield hostcolor, "localhost", dict(failures=0, unreachable=0, changed=0), a_c

# --- end of "pretty"
#
# pager() and paginate() are left here until Ansible 1.8 is EOL, then they
# will go away in 2.0. In the meantime

# Generated at 2022-06-23 13:49:51.190043
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost               '
    assert hostcolor(u'localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor(u'localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor(u'localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[33mlocalhost\x1b[0m        '

# Generated at 2022-06-23 13:49:59.462760
# Unit test for function parsecolor
def test_parsecolor():
    '''Test parsecolor function'''
    tc = [('color0', 38, 5, 0),
          ('color1', 38, 5, 1),
          ('color1', 38, 5, 1),
          ('rgb356', 38, 5, 218),
          ('rgb355', 38, 5, 213),
          ('rgb554', 38, 5, 238),
          ('rgb535', 38, 5, 229),
          ('rgb555', 38, 5, 231),
          ('gray0', 38, 5, 232),
          ('gray1', 38, 5, 233),
          ('gray24', 38, 5, 255),
          ]
    for t in tc:
        color = t[0]
        parts = parsecolor(t[0]).split(';')
        if parts[0] == t[1]:
            pass

# Generated at 2022-06-23 13:50:09.833942
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(u'hostname', stats, color=False) == u'hostname               '
    assert hostcolor(u'hostname', stats, color=True) == u'\x1b[31;01mhostname      \x1b[0m '
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor(u'hostname', stats, color=False) == u'hostname               '
    assert hostcolor(u'hostname', stats, color=True) == u'\x1b[31;01mhostname      \x1b[0m '
    stats = dict(failures=0, unreachable=0, changed=1)

# Generated at 2022-06-23 13:50:11.281891
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor(None, None)

# Generated at 2022-06-23 13:50:21.136365
# Unit test for function colorize
def test_colorize():
    # pylint: disable=missing-docstring
    def assert_str(func, param, expected, expected_color=True):
        res = func(*param)
        assert isinstance(res, str)
        assert res == expected
        assert ANSIBLE_COLOR == expected_color

    assert_str(colorize,
               ("test", "1234", "red"),
               "test=1234")

    assert_str(colorize,
               ("test", "1234", None),
               "test=1234")

    assert_str(colorize,
               ("test", "1234", "blue"),
               "\x1b[94mtest=1234\x1b[0m")

# --- end "pretty"



# Generated at 2022-06-23 13:50:25.714199
# Unit test for function stringc
def test_stringc():
    assert stringc(u'123', u'red') == '\033[31m123\033[0m'
    assert stringc(u'123', u'rgb255') == '\033[38;5;9m123\033[0m'



# Generated at 2022-06-23 13:50:32.788856
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u'red') == u'\033[31mfoo\033[0m'
    assert stringc(u"foo", u'GREEN') == u'\033[92mfoo\033[0m'
    assert stringc(u"foo\nbar", u'blue', wrap_nonvisible_chars=True) == u'\001\033[94m\002foo\nbar\001\033[0m\002'

# Generated at 2022-06-23 13:50:41.640693
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost               '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[33mlocalhost\x1b[0m        '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m        '



# Generated at 2022-06-23 13:50:52.390428
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = dict(failures=0, unreachable=0, changed=0)
    color = True
    assert 'localhost' in hostcolor(host, stats, color)
    stats = dict(failures=1, unreachable=0, changed=0)
    assert 'localhost' in hostcolor(host, stats, color)
    stats = dict(failures=0, unreachable=0, changed=1)
    assert 'localhost' in hostcolor(host, stats, color)
    stats = dict(failures=0, unreachable=1, changed=0)
    assert 'localhost' in hostcolor(host, stats, color)

# --- end "pretty"



# Generated at 2022-06-23 13:51:04.384669
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor("darkblue", stats, False) == "darkblue                  "
    assert hostcolor("darkblue", stats, True) == u"\u001b[34mdarkblue\u001b[0m               "
    stats['changed'] = 1
    assert hostcolor("darkblue", stats, False) == "darkblue                  "
    assert hostcolor("darkblue", stats, True) == u"\u001b[33mdarkblue\u001b[0m               "
    stats['unreachable'] = 1
    stats['changed'] = 0
    assert hostcolor("darkblue", stats, False) == "darkblue                  "

# Generated at 2022-06-23 13:51:16.364539
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('black') == u'30')
    assert(parsecolor('red') == u'31')
    assert(parsecolor('green') == u'32')
    assert(parsecolor('yellow') == u'33')
    assert(parsecolor('blue') == u'34')
    assert(parsecolor('magenta') == u'35')
    assert(parsecolor('cyan') == u'36')
    assert(parsecolor('white') == u'37')
    # gray is an alias to white
    assert(parsecolor('gray') == u'37')
    # grey is an alias to white
    assert(parsecolor('grey') == u'37')
    assert(parsecolor('default') == u'39')

# Generated at 2022-06-23 13:51:18.897356
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "red") == "\033[31mtext\033[0m"



# Generated at 2022-06-23 13:51:30.897368
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo.example.org'
    stats = {
        'changed': 0,
        'unreachable': 0,
        'failures': 0,
        'ok': 1,
        'skipped': 0
    }
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats['changed'] = 1
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_CHANGED)
    stats['changed'] = 0
    stats['unreachable'] = 1
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats['unreachable'] = 0
    stats['failures'] = 1

# Generated at 2022-06-23 13:51:38.872865
# Unit test for function colorize
def test_colorize():
    result = colorize(u"foo", u"1", C.COLOR_CHANGED)
    assert result == u'foo=1   ', result

    result = colorize(u"foo", u"0", C.COLOR_CHANGED)
    assert result == u'foo=0   ', result

    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    result = colorize(u"foo", u"1", C.COLOR_CHANGED)
    assert result == u'foo=1   ', result
    ANSIBLE_COLOR = True

# Generated at 2022-06-23 13:51:45.322050
# Unit test for function stringc
def test_stringc():
    print(stringc('foo', 'green'))
    print(stringc('foo', 'rgb255255255'))
    print(stringc('foo', 'rgb255255255', wrap_nonvisible_chars=True))
    print(stringc('foo', 'color16'))
    print(stringc('foo', 'color16', wrap_nonvisible_chars=True))


if __name__ == "__main__":
    test_stringc()
# --- end "pretty"

# Generated at 2022-06-23 13:51:58.548759
# Unit test for function hostcolor
def test_hostcolor():
    """ Unit tests for function hostcolor """

    hcol = lambda h, s: hostcolor(h, s, color=True)

    # Test cases for each combination of result statistics

# Generated at 2022-06-23 13:52:10.188344
# Unit test for function stringc
def test_stringc():
    assert stringc(u"abc", u'blue') == u'\033[34mabc\033[0m'
    assert stringc(u"abc", u'blue', wrap_nonvisible_chars=True) == u'\001\033[34m\002abc\001\033[0m\002'
    assert stringc(u"abc", u'color12') == u'\033[38;5;12mabc\033[0m'
    assert stringc(u"abc", u'color12', wrap_nonvisible_chars=True) == u'\001\033[38;5;12m\002abc\001\033[0m\002'
    assert stringc(u"abc", u'rgb255255255') == u'\033[38;5;231mabc\033[0m'


# Generated at 2022-06-23 13:52:23.207820
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('web1', dict(failures=0, unreachable=0, changed=0), True) == u"web1                    "
    assert hostcolor('web1', dict(failures=0, unreachable=0, changed=0), False) == u"web1                    "

    assert hostcolor('web2', dict(failures=1, unreachable=0, changed=0), True) == u"\n\x1b[31mweb2                \x1b[0m"
    assert hostcolor('web2', dict(failures=1, unreachable=0, changed=0), False) == u"web2                    "


# Generated at 2022-06-23 13:52:32.274408
# Unit test for function stringc
def test_stringc():
    # TODO: Rewrite this function to use unittest.TestCase
    import sys

    print(stringc("Normal", "green", wrap_nonvisible_chars=True))
    print(stringc("Bright", "red", wrap_nonvisible_chars=True))
    print(stringc("Underline", "blue", wrap_nonvisible_chars=True))
    print(stringc("Reverse", "magenta", wrap_nonvisible_chars=True))
    print(stringc("Normal", "white"))
    print(stringc("Bright", "white"))
    print(stringc("Underline", "white"))
    print(stringc("Reverse", "white"))
    print(stringc("Normal", "white"))
    print(stringc("on_red", "white"))

# Generated at 2022-06-23 13:52:36.777613
# Unit test for function colorize
def test_colorize():
    # Expected string to return if ANSIBLE_COLOR is True
    expected_color_string = u'\033[38;5;196m=\033[38;5;118mok  \033[0m'
    result = colorize(u'=', u'ok', C.COLOR_OK)

    assert result == expected_color_string


# Generated at 2022-06-23 13:52:47.353709
# Unit test for function hostcolor
def test_hostcolor():
    h = hostcolor('www.example.com', {'changed': 1,
                               'failures': 0,
                               'ok': 6,
                               'skipped': 0,
                               'unreachable': 0}, True)
    assert (h == u"\033[0;34mwww.example.com\033[0m      ")
    h = hostcolor('www.example.com', {'changed': 0,
                               'failures': 0,
                               'ok': 6,
                               'skipped': 0,
                               'unreachable': 0}, True)
    assert (h == u"\033[0;32mwww.example.com\033[0m      ")

# Generated at 2022-06-23 13:52:54.146927
# Unit test for function hostcolor
def test_hostcolor():
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['ok'] = 1
    stats['skipped'] = 0
    stats['changed'] = 0

    # global color set to True
    ansible_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert hostcolor('host', stats) == u'host'
    ANSIBLE_COLOR = ansible_color



# Generated at 2022-06-23 13:52:58.546254
# Unit test for function colorize
def test_colorize():
    print(colorize('Test', 0, 'black'))
    print(colorize('Test', 1, 'red'))
    print(colorize('Test', 2, 'blue'))


# --- end "pretty"


# Generated at 2022-06-23 13:53:05.779679
# Unit test for function parsecolor
def test_parsecolor():
    # color
    assert parsecolor("color0") == '38;5;0'
    assert parsecolor("color255") == '38;5;255'
    # xterm256
    assert parsecolor("rgb000") == '38;5;0'
    assert parsecolor("rgb555") == '38;5;59'
    assert parsecolor("rgb555") == '38;5;59'
    assert parsecolor("rgb123") == '38;5;18'
    assert parsecolor("rgb123") == '38;5;18'
    assert parsecolor("rgb333") == '38;5;51'
    assert parsecolor("rgb333") == '38;5;51'
    assert parsecolor("rgb543") == '38;5;115'


# Generated at 2022-06-23 13:53:12.740888
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.callbacks import display
    assert hostcolor(u"test", {u"failures": 1, u"ok": 1, u"unreachable": 1, u"skipped": 1}, color=True) == u"test                 "
    assert hostcolor(u"test", {u"failures": 0, u"ok": 1, u"unreachable": 0, u"skipped": 0}, color=True) == u"test                 "
    assert hostcolor(u"test", {u"failures": 1, u"ok": 1, u"unreachable": 0, u"skipped": 0}, color=True) == u"test                 "
    assert hostcolor(u"test", {u"failures": 0, u"ok": 0, u"unreachable": 1, u"skipped": 0}, color=True)

# Generated at 2022-06-23 13:53:24.360335
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', {'unreachable': 1}) == stringc(u"foo", C.COLOR_ERROR)
    assert hostcolor('foo', {'changed': 1}) == stringc(u"foo", C.COLOR_CHANGED)
    assert hostcolor('foo', {'ok': 1}) == u"%-26s" % stringc(u"foo", C.COLOR_OK)
    assert hostcolor('foo', {'failed': 0, 'ok': 1, 'done': 1}) == u"%-26s" % stringc(u"foo", C.COLOR_OK)
    assert hostcolor('foo', {'failed': 1, 'ok': 1, 'done': 1}) == u"%-26s" % stringc(u"foo", C.COLOR_ERROR)

# Generated at 2022-06-23 13:53:34.315300
# Unit test for function stringc
def test_stringc():
    """Test colorize text."""
    assert stringc("Some text", "green") == u"\033[32mSome text\033[0m"
    assert stringc("Some text\non two lines", "green", wrap_nonvisible_chars=True) == u"\001\033[32m\002Some text\n\001\033[0m\002on two lines"
    assert stringc("Some text\non two lines", "green") == u"\033[32mSome text\n\033[0mon two lines\033[0m"
    assert stringc("Some text", "green", wrap_nonvisible_chars=True) == u"\001\033[32m\002Some text\001\033[0m\002"

# Generated at 2022-06-23 13:53:40.228288
# Unit test for function parsecolor
def test_parsecolor():
    # Test that a valid color name works
    assert parsecolor('blue') == '34'
    # Test that an invalid color name returns a value that causes no change
    assert parsecolor('invalid') == '39'
    # Test that a color number works
    assert parsecolor('color123') == '38;5;123'
    # Test that a gray color works
    assert parsecolor('gray1') == '38;5;242'
    # Test that a rgb color works
    assert parsecolor('rgb123') == '38;5;62'

test_parsecolor()
# --- end "pretty"

if __name__ == '__main__':
    print(stringc("This is %s!" % "blue", 'blue'))