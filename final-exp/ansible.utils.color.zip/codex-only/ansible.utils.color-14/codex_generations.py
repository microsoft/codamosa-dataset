

# Generated at 2022-06-23 13:43:39.524585
# Unit test for function stringc
def test_stringc():
    assert u'\033[31mfoo\033[0m' == stringc('foo', 'RED')

if __name__ == "__main__":
    test_stringc()

# Generated at 2022-06-23 13:43:46.046288
# Unit test for function parsecolor
def test_parsecolor():
    # Test color0
    result = parsecolor("color0")
    assert result == '38;5;0'

    # Test color1
    result = parsecolor("color1")
    assert result == '38;5;1'

    # Test color255
    result = parsecolor("color255")
    assert result == '38;5;255'

    # Test rgb123
    result = parsecolor("rgb123")
    assert result == '38;5;18'

    # Test rgb654
    result = parsecolor("rgb654")
    assert result == '38;5;94'

    # Test gray0
    result = parsecolor("gray0")
    assert result == '38;5;232'

    # Test gray0
    result = parsecolor("gray23")

# Generated at 2022-06-23 13:43:50.627540
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('rgb255000') == u'38;5;196'
    assert parsecolor('gray4') == u'38;5;238'
    assert parsecolor('unknown') == u'38;5;208'



# Generated at 2022-06-23 13:43:54.216791
# Unit test for function colorize
def test_colorize():
    print(u"\nTEST COLORS:")
    for i in ['green', 'MAGENTA', 'bLUE','GeRY','red','white','black','cyan','yellow']:
        print(stringc("This is %s!" % i, i))



# Generated at 2022-06-23 13:44:03.450415
# Unit test for function stringc

# Generated at 2022-06-23 13:44:10.503327
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.playbook.play_context import PlayContext
    play_context = PlayContext()
    play_context.connection = 'local'
    host_pattern = u'host*'
    stats = dict(
        changed=0,
        failures=0,
        unreachable=0,
        skipped=0,
        ok=1,
    )
    assert hostcolor(host_pattern, stats) == u"host*                 "
    stats['changed'] = 1
    assert hostcolor(host_pattern, stats) == u"host*                 "
    stats['failures'] = 1
    assert hostcolor(host_pattern, stats) == u"host*                 "
    stats['unreachable'] = 1
    assert hostcolor(host_pattern, stats) == u"host*                 "

# Generated at 2022-06-23 13:44:22.276533
# Unit test for function stringc
def test_stringc():
    def parse(string):
        codes = []
        p = re.compile(r'\033\[([0-9]+)m')
        for _ in p.finditer(string):
            codes.append(_.group(1))
        return codes

    # Test isatty
    ANSIBLE_COLOR = True
    assert parse(stringc(u"OK", 'green')) == [u'32']
    if hasattr(sys.stdout, 'isatty') and not sys.stdout.isatty():
        ANSIBLE_COLOR = False
    assert parse(stringc(u"OK", 'green')) == []

    # Test nocolor
    ANSIBLE_COLOR = True
    C.ANSIBLE_NOCOLOR = True

# Generated at 2022-06-23 13:44:29.898465
# Unit test for function stringc
def test_stringc():
    print(stringc("test", "red"))
    print(stringc("test", "white"))
    print(stringc("test", "blue"))
    print(stringc("test", "green"))
    print(stringc("test", "cyan"))
    print(stringc("test", "yellow"))
    print(stringc("test", "magenta"))
    print(stringc("test", "rainbow"))
    print(stringc("test", "color256", True))
    print(stringc("test", "rgb123", True))
    print(stringc("test", "gray9", True))


# --- end of pretty.py ---

# --- begin new pretty prints ---


# Generated at 2022-06-23 13:44:32.902150
# Unit test for function colorize
def test_colorize():
    for lead in ["ok", "changed", "unreachable", "failed"]:
        for num in range(5):
            print(colorize(lead, num, None))


# Generated at 2022-06-23 13:44:38.550091
# Unit test for function parsecolor
def test_parsecolor():
    print('Test parsecolor:')
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('none') == '0'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('gray0') == '38;5;232'
    print('  OK')



# Generated at 2022-06-23 13:44:44.823087
# Unit test for function colorize
def test_colorize():
    print(colorize(u"-", 45, u"blue"))
    print(colorize(u"+", 23, u"green"))
    print(colorize(u"*", 23, u"red"))
    print(u"blah")
    print(colorize(u"*", 0, u"red"))
    print(colorize(u"*", 1, None))

# End of pretty



# Generated at 2022-06-23 13:44:49.925080
# Unit test for function colorize
def test_colorize():
    try:
        import curses
    except ImportError:
        return
    curses.setupterm()
    if curses.tigetnum("colors") <= 0:
        return
    f = open("/dev/tty", "w")
    for i in range(0, 256):
        f.write(str(i) + ": " + stringc(str(i), "color" + str(i)) + "\n")

    f.close()


# Generated at 2022-06-23 13:45:01.356535
# Unit test for function hostcolor
def test_hostcolor():
    # expected output
    test_host = "abc"
    test_ok_output = u"abc"
    test_error_output = u"\u001b[31mabc\u001b[0m"

    # test ok
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(test_host, stats) == test_ok_output

    # test failures
    stats = {'failures': 1, 'unreachable': 1, 'changed': 0}
    assert hostcolor(test_host, stats) == test_error_output

    # test unreachable
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(test_host, stats) == test_error_output

    # test changed

# Generated at 2022-06-23 13:45:07.337625
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('lightgreen') == '92'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color183') == '38;5;183'
    assert parsecolor('rgb123') == '38;5;34'
    assert parsecolor('rgb332') == '38;5;166'
    assert parsecolor('rgb212') == '38;5;112'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('gray23') == '38;5;253'

# Generated at 2022-06-23 13:45:16.637110
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color on
    color = True
    # Changed:
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}, color) == 'localhost               '
    # Failures:
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}, color) == 'localhost               '
    # Unreachable:
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}, color) == 'localhost               '
    # No color:
    color = False
    # Changed:
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}, color) == 'localhost               '
    # Failures:

# Generated at 2022-06-23 13:45:23.437883
# Unit test for function hostcolor
def test_hostcolor():
    hosts = ['localhost', 'myserver', 'myserver2']
    stats = {'unreachable': 0, 'skipped': 0, 'ok': 0, 'changed': 0, 'failures': 0}
    print((u"this test should print three lines: localhost, %s, %s" % (stringc(hosts[1], C.COLOR_OK),
                                                                        stringc(hosts[2], C.COLOR_OK))))
    for host in hosts:
        print((hostcolor(host, stats, True)))



# Generated at 2022-06-23 13:45:29.819947
# Unit test for function hostcolor
def test_hostcolor():
    import textwrap
    results = dict(contacted=dict(localhost=dict(changed=0,
                                                 skipped=0,
                                                 unreachable=0,
                                                 failed=0)),
                  dark=dict(changed=0,
                            skipped=0,
                            unreachable=0,
                            failed=0),
                  stats=dict(localhost=dict(changed=0,
                                            skipped=0,
                                            unreachable=0,
                                            failed=0)))

    results['contacted']['dark'] = dict(changed=0,
                                        skipped=0,
                                        unreachable=0,
                                        failed=0,
                                        ok=0)
    host = 'localhost'
    color = True
    s = hostcolor(host, results, color)

# Generated at 2022-06-23 13:45:36.476208
# Unit test for function stringc
def test_stringc():
    """Tests for function stringc"""

    print(stringc("reset", "reset"))
    print(stringc("bold", "bold"))
    print(stringc("dark", "dark"))
    print(stringc("underline", "underline"))
    print(stringc("underscore", "underscore"))
    print(stringc("blink", "blink"))
    print(stringc("reverse", "reverse"))
    print(stringc("concealed", "concealed"))

    print(stringc("red", "red"))
    print(stringc("green", "green"))
    print(stringc("yellow", "yellow"))
    print(stringc("blue", "blue"))
    print(stringc("magenta", "magenta"))
    print(stringc("cyan", "cyan"))

# Generated at 2022-06-23 13:45:44.448956
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == "31"
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("color9") == "38;5;9"
    assert parsecolor("color10") == "38;5;10"
    assert parsecolor("color15") == "38;5;15"
    assert parsecolor("color16") == "38;5;16"
    assert parsecolor("color214") == "38;5;214"
    assert parsecolor("color245") == "38;5;245"
    assert parsecolor("color255") == "38;5;255"
    assert parsecolor("rgb000") == "38;5;232"
    assert parsecolor("rgb123") == "38;5;12"
    assert parsec

# Generated at 2022-06-23 13:45:50.495166
# Unit test for function parsecolor
def test_parsecolor():
    print("Testing function parsecolor")
    assert parsecolor('normal')==u'39'
    assert parsecolor('red')==u'31'
    assert parsecolor('rgb255255255')==u'37'
    assert parsecolor('rgb000255000')==u'32'
    print("Test for function parsecolor: Passed")


# Generated at 2022-06-23 13:46:00.571943
# Unit test for function stringc
def test_stringc():
    def test_output(name, color, expected):
        actual = stringc(u"x", color, wrap_nonvisible_chars=True)
        if expected != actual:
            print(u"%14s: expected %s, actual %s" % (name, expected, actual))

    test_output(u'black', u"black", u"\x01\x1b[30mx\x01\x1b[0m\x02")
    test_output(u'red', u"red", u"\x01\x1b[31mx\x01\x1b[0m\x02")
    test_output(u'green', u"green", u"\x01\x1b[32mx\x01\x1b[0m\x02")

# Generated at 2022-06-23 13:46:08.038086
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("host", {"failures": 0, "unreachable": 0, "changed": 0}, color=False) == "host                 "
    assert hostcolor("host", {"failures": 0, "unreachable": 0, "changed": 0}, color=True) == "host                 "
    assert hostcolor("host", {"failures": 0, "unreachable": 0, "changed": 1}, color=True) == "\x1b[0;34mhost                 \x1b[0m"
    assert hostcolor("host", {"failures": 0, "unreachable": 1, "changed": 0}, color=True) == "\x1b[0;31mhost                 \x1b[0m"
    assert hostcolor("host", {"failures": 1, "unreachable": 0, "changed": 0}, color=True)

# Generated at 2022-06-23 13:46:12.036161
# Unit test for function stringc
def test_stringc():
    """Unit tests for the 'stringc' function.

    >>> print(stringc("text", 'blue'))
    \x1b[34mtext\x1b[0m
    """



# Generated at 2022-06-23 13:46:22.662827
# Unit test for function parsecolor
def test_parsecolor():
    for color in C.ANSIBLE_CONSOLE_COLORS:
        assert parsecolor(color), "Can't parse color '%s'" % color
        # Test parsing of grey too, as the function is a bit hairy
        assert parsecolor('color%s' % color), "Can't parse color 'color%s'" % color
    assert parsecolor('gray15') == '38;5;250'
    assert parsecolor('color9') == '35'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color12') == '38;5;12'
    assert parsecolor('color15') == '38;5;15'
    assert parsecolor('color20') == '38;5;20'

# Generated at 2022-06-23 13:46:30.770866
# Unit test for function stringc
def test_stringc():
    """Colorized strings for logging and debug output."""
    print(u"\nTesting pretty.c")

    COLOR_NAMES = [u'black', u'red', u'green', u'yellow', u'blue', u'purple', u'cyan', u'white', u'normal']
    COLORS = [u'rgb5', u'rgb15', u'rgb255', u'rgb0']
    COLORS.extend(COLOR_NAMES)

    sys.stdout.write(u" Testing stringc():")
    for color in COLORS:
        print(u"     %s" % stringc(u"stringc() test in %s" % color, color))

    print(u"")

if __name__ == u"__main__":
    test_stringc()

# ---

# Generated at 2022-06-23 13:46:40.822424
# Unit test for function colorize
def test_colorize():
    from ansible.utils.color import colorize, stringc
    assert colorize(u"foo", u"1", u'blue') == u"foo=1   "
    assert colorize(u"bar", u"2", None) == u"bar=2   "
    assert colorize(u"baz", u"2", u'red') == u"baz=2   "
    assert stringc(u"foo", u"blue") == u'\033[94mfoo\033[0m'
    assert stringc(u"bar", u"red") == u'\033[91mbar\033[0m'
    assert stringc(u"baz", None) == u"baz"

# --- end of "pretty"

ANSIBLE_NOCOLOR = not ANSIBLE_COLOR

#
#

# Generated at 2022-06-23 13:46:50.394455
# Unit test for function colorize
def test_colorize():
    print(u"colorize(\"foo\", 0, \"blue\") =", end=' ')
    print(colorize(u"foo", 0, u"blue"))
    print(u"colorize(\"foo\", 1, \"blue\") =", end=' ')
    print(colorize(u"foo", 1, u"blue"))
    print(u"colorize(\"foo\", -1, None) =", end=' ')
    print(colorize(u"foo", -1, None))

# --- end of "pretty"

# Generated at 2022-06-23 13:46:57.537952
# Unit test for function colorize
def test_colorize():
    ANSIBLE_COLOR = True
    # Colorize using a leading str and trailing color dict
    assert colorize("num", 1, dict(ok=True)) == u"num=1  "
    # Make sure color is skipped if ANSIBLE_COLOR not set
    ANSIBLE_COLOR = False
    assert colorize("num", 1, dict(ok=True)) == u'num=1  '
    ANSIBLE_COLOR = True
    # Make sure a tuple can be passed in for color
    assert colorize("num", 1, dict(changed=True)) == u"num=1  "


# Generated at 2022-06-23 13:47:09.534489
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = {'changed': 1, 'failures': 1, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    stats2 = {'changed': 1, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    stats3 = {'changed': 0, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    assert(hostcolor('alpha', stats1, True) ==
           u"\033[31;01malpha\033[0m                 ")
    assert(hostcolor('alpha', stats1, False) ==
           u"alpha                        ")
    assert(hostcolor('alpha', stats2, True) ==
           u"\033[33;01malpha\033[0m                 ")
   

# Generated at 2022-06-23 13:47:16.831387
# Unit test for function stringc
def test_stringc():
    print(stringc('text', 'blue'))
    print(stringc('text', 'rgb255'))
    print(stringc('text', 'rgb000'))
    print(stringc('text', 'gray0'))
    print(stringc('text', 'gray7'))
    print(stringc('text', 'gray8'))
    print(stringc('text', 'gray9'))



# Generated at 2022-06-23 13:47:26.222201
# Unit test for function hostcolor
def test_hostcolor():
    # ANSIBLE_COLOR isn't set, thus it is False
    if hasattr(sys.stdout, 'isatty'):
        del sys.stdout.isatty

    # ANSIBLE_COLOR is False
    assert hostcolor('127.0.0.1', {'failures': 0, 'changed': 0, 'unreachable': 0}) == "%-26s" % '127.0.0.1'
    assert hostcolor('127.0.0.1', {'failures': 1, 'changed': 0, 'unreachable': 0}) == "%-26s" % '127.0.0.1'

# Generated at 2022-06-23 13:47:36.164791
# Unit test for function colorize
def test_colorize():
    try:
        from nose.tools import assert_equals
    except:
        print('1..0 # SKIP could not import nose.tools')
        return

    # ANSIBLE_COLOR = True
    print('Testing colorize()')
    assert_equals(colorize('foo', 0, 'blue'), 'foo=0   ')
    assert_equals(colorize('foo', 0, None), 'foo=0   ')
    assert_equals(colorize('foo', 1, 'blue'), u'\u001b[38;5;46mfoo=1   \u001b[0m')
    assert_equals(colorize('foo', 10, 'blue'), u'\u001b[38;5;46mfoo=10  \u001b[0m')

# Generated at 2022-06-23 13:47:47.451950
# Unit test for function hostcolor
def test_hostcolor():
    host = ('localhost')
    stats = {'failures': 0, 'changed': 0, 'ok': 6, 'skipped': 0,
             'unreachable': 0}
    color_host = hostcolor(host, stats, True)
    assert color_host == u"\033[0;32mlocalhost               \033[0m"
    color_host = hostcolor(host, stats, False)
    assert color_host == u"localhost               "
    stats = {'failures': 5, 'changed': 0, 'ok': 6, 'skipped': 0,
             'unreachable': 0}
    color_host = hostcolor(host, stats, True)
    assert color_host == u"\033[0;31mlocalhost               \033[0m"

# Generated at 2022-06-23 13:47:59.708699
# Unit test for function stringc
def test_stringc():
    assert stringc(u"This is white", "white") == u"\033[37mThis is white\033[0m"
    assert stringc(u"This is white", "black") == u"\033[30mThis is white\033[0m"
    assert stringc(u"This is white", "clear") == u"This is white"
    assert stringc(u"This is white", "white", True) == u"\033[37mThis is white\033[0m"
    assert stringc(u"This is white", "black", True) == u"\033[30mThis is white\033[0m"
    assert stringc(u"This is white", "clear", True) == u"This is white"


# Generated at 2022-06-23 13:48:10.808970
# Unit test for function hostcolor
def test_hostcolor():
    host = 'hostname'
    color = True
    assert hostcolor(host, {'failures': 0, 'unreachable': 0, 'changed': 0}, color) == u'%-37s' % stringc(host, 'green')
    assert hostcolor(host, {'failures': 1, 'unreachable': 0, 'changed': 0}, color) == u'%-37s' % stringc(host, 'red')
    assert hostcolor(host, {'failures': 0, 'unreachable': 1, 'changed': 0}, color) == u'%-37s' % stringc(host, 'red')
    assert hostcolor(host, {'failures': 0, 'unreachable': 0, 'changed': 1}, color) == u'%-37s' % stringc(host, 'yellow')

# Generated at 2022-06-23 13:48:16.143541
# Unit test for function stringc
def test_stringc():
    class FakeStream:
        def __init__(self):
            self.stringio = StringIO()

        def write(self, string):
            self.stringio.write(string)

        def read(self):
            self.stringio.seek(0)
            return self.stringio.read()

        def reset(self):
            self.stringio.seek(0)
            self.stringio.truncate(0)

    class FakeColor:
        ansible_force_color = True

    fake_stdout = FakeStream()
    sys.stdout = fake_stdout
    stringc('Test', color='red', wrap_nonvisible_chars=True)

# Generated at 2022-06-23 13:48:26.145291
# Unit test for function colorize
def test_colorize():
    """
    Tests for module 'pretty.colorize'

    Functions used: pretty.colorize
    """
    lead = 'mylead'
    num_ok = '10'
    num_changed = '20'
    num_darkred = '30'
    num_error = '40'

    # Absent ANSIBLE_COLOR, no color codes
    global ANSIBLE_COLOR
    original_ansible_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize(lead, num_ok, C.COLOR_OK) == u"mylead=10  "
    assert colorize(lead, num_changed, C.COLOR_CHANGED) == u"mylead=20  "

# Generated at 2022-06-23 13:48:36.492636
# Unit test for function colorize
def test_colorize():
    from io import StringIO
    from ansible.playbook.play_context import PlayContext
    from ansible.playbook.task_include import TaskInclude
    from ansible.executor.task_result import TaskResult
    from ansible.vars import VariableManager
    from ansible.parsing.dataloader import DataLoader

    host = u"example.com"
    color = None
    s = u"test"
    lead = u"test"
    num = 5

    play_context = PlayContext()
    play_context.remote_addr = host

    task = TaskInclude()
    task_vars = dict()
    templar = None
    loader = DataLoader()
    variable_manager = VariableManager()


# Generated at 2022-06-23 13:48:45.199721
# Unit test for function stringc

# Generated at 2022-06-23 13:48:53.938820
# Unit test for function hostcolor
def test_hostcolor():
    host = '127.0.0.1'
    stats = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(host, stats, color=True) == u'%-37s' % host
    assert hostcolor(host, stats, color=False) == u'%-26s' % host
    stats = {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(host, stats, color=True) == u'%-37s' % host
    assert hostcolor(host, stats, color=False) == u'%-26s' % host

# Generated at 2022-06-23 13:49:05.174432
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'34'
    assert parsecolor('brightyellow') == u'93'
    assert parsecolor('brightblue') == u'94'
    assert parsecolor('brightcyan') == u'96'
    assert parsecolor('brightgreen') == u'92'
    assert parsecolor('brightmagenta') == u'95'
    assert parsecolor('brightred') == u'91'
    assert parsecolor('brightyellow') == u'93'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('default') == u'39'
    assert parsecolor('green') == u'32'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('red') == u'31'
    assert parsec

# Generated at 2022-06-23 13:49:09.734454
# Unit test for function colorize
def test_colorize():
    assert(colorize('foo', 3, 'red') == 'foo=3   ')
    assert(colorize('foo', 0, 'red') == 'foo=0   ')
    assert(colorize('f' * 50, 0, 'red') == 'f' * 47 + '0   ')


# Generated at 2022-06-23 13:49:21.004510
# Unit test for function parsecolor
def test_parsecolor():
    if parsecolor('black') != u'30':
        raise ValueError("Expected 30, got " + str(parsecolor('black')))
    if parsecolor('red') != u'31':
        raise ValueError("Expected 31, got " + str(parsecolor('red')))
    if parsecolor('green') != u'32':
        raise ValueError("Expected 32, got " + str(parsecolor('green')))
    if parsecolor('yellow') != u'33':
        raise ValueError("Expected 33, got " + str(parsecolor('yellow')))
    if parsecolor('blue') != u'34':
        raise ValueError("Expected 34, got " + str(parsecolor('blue')))
    if parsecolor('magenta') != u'35':
        raise ValueError

# Generated at 2022-06-23 13:49:31.478339
# Unit test for function colorize
def test_colorize():
    print(stringc("1. this is black", "black"))
    print(stringc("2. this is red", "red"))
    print(stringc("3. this is green", "green"))
    print(stringc("4. this is yellow", "yellow"))
    print(stringc("5. this is blue", "blue"))
    print(stringc("6. this is purple", "purple"))
    print(stringc("7. this is cyan", "cyan"))
    print(stringc("8. this is white", "white"))
    print(stringc("9. this is gray", "gray"))
    print(stringc("10. this is grey", "grey"))
    print(stringc("11. this is white", "colour1"))
    #print(stringc("12. this is colour2", "colour2"))
   

# Generated at 2022-06-23 13:49:42.509581
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'localhost', {u'unreachable': 0, u'failures': 0, u'ok': 3, u'changed': 0, u'ignored': 0}) == u'localhost                '
    assert hostcolor(u'localhost', {u'unreachable': 0, u'failures': 0, u'ok': 3, u'changed': 0, u'ignored': 0}, False) == u'localhost                '
    assert hostcolor(u'localhost', {u'unreachable': 0, u'failures': 1, u'ok': 2, u'changed': 0, u'ignored': 0}) == u'\033[31;01mlocalhost                \033[0m'

# Generated at 2022-06-23 13:49:54.706705
# Unit test for function hostcolor
def test_hostcolor():
    h = 'the_host'
    s = dict(ok=1, failures=0, unreachable=0, changed=0)
    assert hostcolor(h, s) == u"%-26s" % stringc(h, C.COLOR_OK)
    s = dict(ok=1, failures=1, unreachable=0, changed=0)
    assert hostcolor(h, s) == u"%-26s" % stringc(h, C.COLOR_ERROR)
    s = dict(ok=0, failures=1, unreachable=1, changed=0)
    assert hostcolor(h, s) == u"%-26s" % stringc(h, C.COLOR_ERROR)
    s = dict(ok=0, failures=0, unreachable=1, changed=1)
    assert hostcolor(h, s) == u

# Generated at 2022-06-23 13:50:05.572454
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31', parsecolor('red')
    assert parsecolor('green') == u'32', parsecolor('green')
    assert parsecolor('rgb255255255') == u'37', parsecolor('rgb255255255')
    assert parsecolor('rgb000255000') == u'32', parsecolor('rgb000255000')
    assert parsecolor('rgb255000000') == u'31', parsecolor('rgb255000000')
    assert parsecolor('rgb000') == u'38;5;94', parsecolor('rgb000')
    assert parsecolor('gray0') == u'30', parsecolor('gray0')
    assert parsecolor('gray8') == u'38;5;245', parsecolor('gray8')
   

# Generated at 2022-06-23 13:50:16.892690
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost                     '
    assert hostcolor(u'localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'localhost                     '
    assert hostcolor(u'localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'localhost                     '
    assert hostcolor(u'localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'localhost                     '
    assert hostcolor(u'localhost', {'failures': 1, 'unreachable': 1, 'changed': 0}) == u'localhost                     '

# Generated at 2022-06-23 13:50:25.411631
# Unit test for function colorize
def test_colorize():
    # ANSIBLE_COLOR is True and color is set - color will be used
    assert u"ok       =0   " == colorize('ok', 0, 'green')
    assert u"changed  =1   " == colorize('changed', 1, 'yellow')
    assert u"unreachable=2 " == colorize('unreachable', 2, 'red')
    assert u"failed      =3" == colorize('failed', 3, 'red')

    # ANSIBLE_COLOR is False and color is set - no color will be used
    ANSIBLE_COLOR = False
    assert u"ok       =0   " == colorize('ok', 0, 'green')
    assert u"changed  =1   " == colorize('changed', 1, 'yellow')

# Generated at 2022-06-23 13:50:29.736889
# Unit test for function colorize
def test_colorize():
    print(colorize('foo', 1, 'green'))
    print(colorize('foo', 0, 'green'))
    print(colorize('foo', -1, 'red'))
    print(colorize('foo', 1, None))


# Generated at 2022-06-23 13:50:39.588423
# Unit test for function colorize
def test_colorize():
    class MockColors:
        CYAN = 'cyan'
        GREEN = 'green'
        RED = 'red'
        RESET = 'reset'

    if ANSIBLE_COLOR:

        def test(lead, num, color, result):
            assert colorize(lead, num, color) == result
    else:

        def test(lead, num, color, result):
            assert colorize(lead, num, color) == (lead + '=' + str(num))

    test('ok', '0', MockColors.GREEN, 'ok=0   ')
    test('changed', '0', MockColors.CYAN, 'changed=0 ')
    test('failed', '2', MockColors.RED, 'failed=2 ')


# --- end of pretty library



# Generated at 2022-06-23 13:50:46.688501
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert parsecolor('black') == u'30'
        assert parsecolor('red') == u'31'
        assert parsecolor('green') == u'32'
        assert parsecolor('yellow') == u'33'
        assert parsecolor('blue') == u'34'
        assert parsecolor('violet') == u'35'
        assert parsecolor('cyan') == u'36'
        assert parsecolor('white') == u'37'
        assert parsecolor('color0') == u'38;5;0'
        assert parsecolor('color1') == u'38;5;1'
        assert parsecolor('color2') == u'38;5;2'
        assert parsecolor('color3') == u'38;5;3'


# Generated at 2022-06-23 13:50:56.069939
# Unit test for function hostcolor
def test_hostcolor():
    host = u'host1.example.com'
    stats = dict(failed=0, changed=0, dark=0, unreachable=0)

    assert hostcolor(host, stats) == u"%-26s" % host

    stats = dict(failed=0, changed=1, dark=0, unreachable=0)
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_CHANGED)

    stats = dict(failed=1, changed=0, dark=0, unreachable=0)
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)

    stats = dict(failed=0, changed=0, dark=0, unreachable=1)

# Generated at 2022-06-23 13:50:58.530429
# Unit test for function stringc
def test_stringc():
    """ This function tests the function stringc. """
    test_str = stringc("Hello", "green")
    expected = "\033[32mHello\033[0m"
    if test_str != expected:
        print(test_str)
        print(expected)
    assert test_str == expected



# Generated at 2022-06-23 13:51:08.989772
# Unit test for function stringc
def test_stringc():
    cases = (
        (u'Bold', u'bold'),
        (u'Underline', u'underline'),
        (u'Red', u'RED'),
        (u'Green', u'green'),
        (u'Color01', u'color01'),
        (u'Rgb255', u'rgb255'),
        (u'Rgb512', u'rgb512'),
        (u'Rgb523', u'rgb523'),
        (u'Gray8', u'gray8'),
        (u'Gray15', u'gray15'),
    )
    for expected, color in cases:
        got = stringc(u'caption', color)
        if len(got) == 0:
            # None is most likely returned by ANSIBLE_NOCOLOR.
            assert expected == u'caption'

# Generated at 2022-06-23 13:51:14.869303
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    # Save the current value of ANSIBLE_COLOR, restore it before returning.
    ansible_color = ANSIBLE_COLOR

# Generated at 2022-06-23 13:51:18.024383
# Unit test for function colorize
def test_colorize():
    """Test colorize function"""
    # Test green
    assert(colorize(u"Testgreen", 2, u"green") == u"Testgreen=2  ")
    # Test red
    assert(colorize(u"Testred", 1, u"red") == u"Testred=1   ")



# Generated at 2022-06-23 13:51:24.380849
# Unit test for function colorize
def test_colorize():

    if ANSIBLE_COLOR:
        assert colorize('ok', 0, C.COLOR_OK) == u'ok=0   '
        assert colorize('changed', 0, C.COLOR_CHANGED) == u'changed=0   '
        assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == u'unreachable=0   '
        assert colorize('failed', 0, C.COLOR_ERROR) == u'failed=0   '
    else:
        assert colorize('ok', 0, C.COLOR_OK) == u'ok=0'
        assert colorize('changed', 0, C.COLOR_CHANGED) == u'changed=0'
        assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == u'unreachable=0'
        assert color

# Generated at 2022-06-23 13:51:29.006207
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'dark gray') == u'foo=0   '
    assert colorize('foo', 0, None) == u'foo=0   '
    assert colorize('foo', 0, '') == u'foo=0   '



# Generated at 2022-06-23 13:51:40.427616
# Unit test for function colorize
def test_colorize():
    lead = u"Æ"
    num = 1
    color = u"green"
    print(u"TEST colorize(%s, %s, %s)" % (lead, num, color))
    print(u"  colorize returned:" + colorize(lead, num, color))
    lead = u'\u00c6'
    num = 1
    color = u"green"
    print(u"TEST colorize(%s, %s, %s)" % (lead, num, color))
    print(u"  colorize returned:" + colorize(lead, num, color))
    lead = u'Æ'
    num = 1
    color = u"brown"
    print(u"TEST colorize(%s, %s, %s)" % (lead, num, color))

# Generated at 2022-06-23 13:51:48.360204
# Unit test for function colorize
def test_colorize():
    """
    >>> test_colorize()
    changed=1     dark green
    skipped=2     dark cyan
    unreachable=3 dark red
    failed=4      dark red
    ok=5          dark green
    """
    print(colorize("changed", 1, 'dark green'))
    print(colorize("skipped", 2, 'dark cyan'))
    print(colorize("unreachable", 3, 'dark red'))
    print(colorize("failed", 4, 'dark red'))
    print(colorize("ok", 5, 'dark green'))

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-23 13:51:49.168919
# Unit test for function colorize
def test_colorize():
    pass



# Generated at 2022-06-23 13:52:01.481742
# Unit test for function parsecolor

# Generated at 2022-06-23 13:52:12.441482
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor('somehost', dict(changed=1, failures=0, unreachable=0)) == stringc('somehost', C.COLOR_CHANGED)
        assert hostcolor('otherhost', dict(changed=0, failures=1, unreachable=0)) == stringc('otherhost', C.COLOR_ERROR)
        assert hostcolor('another', dict(changed=0, failures=0, unreachable=1)) == stringc('another', C.COLOR_ERROR)
        assert hostcolor('yetanother', dict(changed=0, failures=0, unreachable=0)) == stringc('yetanother', C.COLOR_OK)
    else:
        assert hostcolor('somehost', dict(changed=1, failures=0, unreachable=0)) == 'somehost               '

# Generated at 2022-06-23 13:52:25.064969
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('black') == '30')
    assert(parsecolor('red') == '31')
    assert(parsecolor('green') == '32')
    assert(parsecolor('yellow') == '33')
    assert(parsecolor('blue') == '34')
    assert(parsecolor('magenta') == '35')
    assert(parsecolor('cyan') == '36')
    assert(parsecolor('white') == '37')
    assert(parsecolor('color124') == '38;5;124')
    assert(parsecolor('rgb124') == '38;5;124')
    assert(parsecolor('rgb231') == '38;5;231')
    assert(parsecolor('rgb123') == '38;5;123')

# Generated at 2022-06-23 13:52:35.345528
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo.example.com", {'failures': 0,
                                         'unreachable': 0,
                                         'changed': 0}, True) == u"foo.example.com               "
    assert hostcolor("foo.example.com", {'failures': 0,
                                         'unreachable': 1,
                                         'changed': 0}, True) == u"\n".join([u"\x1b[31mfoo.example.com\x1b[0m", u"               "])
    assert hostcolor("foo.example.com", {'failures': 1,
                                         'unreachable': 0,
                                         'changed': 0}, True) == u"\n".join([u"\x1b[31mfoo.example.com\x1b[0m", u"               "])

# Generated at 2022-06-23 13:52:42.635348
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('foo', 'black') == u"\033[30mfoo\033[0m"
        assert stringc('foo', 'bold black') == u"\033[30;1mfoo\033[0m"
        assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
        assert stringc('foo', 'bold red') == u"\033[31;1mfoo\033[0m"
        assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"
        assert stringc('foo', 'bold green') == u"\033[32;1mfoo\033[0m"
        assert stringc('foo', 'yellow') == u"\033[33mfoo\033[0m"

# Generated at 2022-06-23 13:52:50.394213
# Unit test for function hostcolor
def test_hostcolor():
    """ hostcolor: Testing terminal color output """
    teststats = dict(failures=1, unreachable=1, ok=2, changed=2)
    assert hostcolor('testhost', teststats) == u'\x1b[31mtesthost               \x1b[0m'
    assert hostcolor('testhost', teststats, False) == u'testhost                 '
    teststats = dict(failures=0, unreachable=0, ok=1, changed=1)
    assert hostcolor('testhost', teststats) == u'\x1b[34mtesthost               \x1b[0m'
    assert hostcolor('testhost', teststats, False) == u'testhost                 '
    teststats = dict(failures=0, unreachable=0, ok=0, changed=0)

# Generated at 2022-06-23 13:53:01.076303
# Unit test for function stringc
def test_stringc():
    assert stringc("ansible", "green") == u"\033[32mansible\033[0m"
    assert stringc("ansible", "color0") == u"\033[38;5;0mansible\033[0m"
    assert stringc("ansible", "color1") == u"\033[38;5;1mansible\033[0m"
    assert stringc("ansible", "color2") == u"\033[38;5;2mansible\033[0m"
    assert stringc("ansible", "color3") == u"\033[38;5;3mansible\033[0m"
    assert stringc("ansible", "color4") == u"\033[38;5;4mansible\033[0m"
    assert stringc("ansible", "color5")

# Generated at 2022-06-23 13:53:09.546752
# Unit test for function hostcolor
def test_hostcolor():
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['ok'] = 0
    stats['changed'] = 0

    stats['ok'] = 1
    assert(hostcolor('localhost', stats) == '%-37s' % u'localhost')
    stats['changed'] = 1
    assert(hostcolor('localhost', stats) == '%-37s' % u'localhost')
    stats['unreachable'] = 1
    assert(hostcolor('localhost', stats) == '%-37s' % u'localhost')
    # The failures statistic takes precedence over the unreachable
    # one in the host colorization phase.
    stats['failures'] = 1
    assert(hostcolor('localhost', stats, False) == '%-26s' % u'localhost')

# Generated at 2022-06-23 13:53:22.586799
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color35') == '38;5;35'
    assert parsecolor('color131') == '38;5;131'
    assert parsecolor('color232') == '38;5;232'
    assert parsecolor('color233') == '38;5;233'
    assert parsecolor('color239') == '38;5;239'
    assert parsecolor('color240') == '38;5;240'
    assert parsecolor('color244') == '38;5;244'
    assert parsecolor('color245') == '38;5;245'
    assert parsecolor('color255') == '38;5;255'

# Generated at 2022-06-23 13:53:31.863466
# Unit test for function hostcolor
def test_hostcolor():
    # Test result will be stored in this variable
    result = []

    # Test scenarios

# Generated at 2022-06-23 13:53:40.644921
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == u'\x1b[34mtest\x1b[0m'
    assert stringc("test", "red", True) == u'\001\x1b[31m\002test\001\x1b[0m\002'
    if ANSIBLE_COLOR:
        assert stringc("test", "nonexistent") == u'\x1b[01;37mtest\x1b[0m'
    else:
        assert stringc("test", "nonexistent") == u'test'
# --- end "pretty"

