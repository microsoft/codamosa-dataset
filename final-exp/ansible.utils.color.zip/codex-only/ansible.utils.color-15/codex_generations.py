

# Generated at 2022-06-23 13:43:44.937906
# Unit test for function parsecolor
def test_parsecolor():
    print("Testing color parsing")
    print("Testing parsing color16")
    assert parsecolor("color16") == "38;5;16"
    print("Testing parsing color100")
    assert parsecolor("color100") == "38;5;100"
    print("Testing parsing rgb012")
    assert parsecolor("rgb012") == "38;5;16"
    print("Testing parsing rgb123")
    assert parsecolor("rgb123") == "38;5;54"
    print("Testing parsing rgb222")
    assert parsecolor("rgb222") == "38;5;58"
    print("Testing parsing gray0")
    assert parsecolor("gray0") == "38;5;232"
    print("Testing parsing gray8")
    assert parsecolor("gray8") == "38;5;240"

# Generated at 2022-06-23 13:43:53.088060
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('RED') == '31'
    assert parsecolor('blink') == '5'
    assert parsecolor('color123') == '38;5;123'
    assert parsecolor('rgb124124124') == '38;5;253'
    assert parsecolor('gray7') == '38;5;239'

test_colorize = u"ok"
test_colorize += " " + colorize(u"changed", 1, C.COLOR_CHANGED)
test_colorize += " " + colorize(u"unreachable", 2, C.COLOR_UNREACHABLE)
test_colorize += " " + colorize(u"failed", 0, C.COLOR_ERROR)

# Generated at 2022-06-23 13:44:04.209603
# Unit test for function stringc
def test_stringc():
    assert parsecolor('red') == '31'
    assert parsecolor('blue') == '34'
    assert parsecolor('boldon') == '1'
    assert parsecolor('reset') == '0'
    assert parsecolor('rgb255255255') == '37'
    assert parsecolor('rgb255255255') == '37'
    assert parsecolor('rgb255255255') == '37'
    assert parsecolor('rgb255255255') == '37'
    assert parsecolor('rgb255255255') == '37'
    assert parsecolor('rgb255255255') == '37'
    assert parsecolor('rgb255255255') == '37'
    assert parsecolor('rgb255255255') == '37'

# Generated at 2022-06-23 13:44:12.587543
# Unit test for function hostcolor
def test_hostcolor():
    host = 'www.example.com'
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    colorhost = hostcolor(host, stats)
    assert (colorhost.startswith(stringc(host, C.COLOR_ERROR)))
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    colorhost = hostcolor(host, stats)
    assert (colorhost.startswith(stringc(host, C.COLOR_ERROR)))
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
    colorhost = hostcolor(host, stats)
    assert (colorhost.startswith(stringc(host, C.COLOR_CHANGED)))

# Generated at 2022-06-23 13:44:24.573860
# Unit test for function colorize
def test_colorize():
    from ansible import utils
    from ansible.utils import colorize
    from ansible.utils.color import stringc, parsecolor

    C.ANSIBLE_FORCE_COLOR = True
    for color in C.COLOR_CODES:
        s = stringc("text", color)
        assert color in parsecolor(color), "Color key %s is not in %s" % (color, s)
        assert s == utils.ANSI_SGR_START + parsecolor(color) + "mtext" + utils.ANSI_SGR_RESET_ALL, \
               "%s != %s" % (s, utils.ANSI_SGR_START + parsecolor(color) + "mtext" + utils.ANSI_SGR_RESET_ALL)

    C.ANSIBLE_

# Generated at 2022-06-23 13:44:31.707022
# Unit test for function hostcolor

# Generated at 2022-06-23 13:44:34.542539
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', {}) == u'host1                 '
    assert hostcolor('host2', {'changed': 1}) == u'host2               '

# --- end "pretty"

# Generated at 2022-06-23 13:44:41.550233
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo", {"failures": 0, "changed": 0, "unreachable": 0}) == u"%-37s" % 'foo'
    assert hostcolor("foo", {"failures": 1, "changed": 0, "unreachable": 0}) == u"%-37s" % stringc("foo", C.COLOR_ERROR)
    assert hostcolor("foo", {"failures": 0, "changed": 1, "unreachable": 0}) == u"%-37s" % stringc("foo", C.COLOR_CHANGED)



# Generated at 2022-06-23 13:44:45.199172
# Unit test for function colorize
def test_colorize():
    s = colorize(u"aname", 1, u"blue")
    assert(s == u"\033[38;5;69maname=1  \033[0m")


# end "pretty"



# Generated at 2022-06-23 13:44:53.228647
# Unit test for function stringc
def test_stringc():
    for color in ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white', 'color236', 'color8', 'color1']:
        print(color, '\t-> ', stringc("Hello", color), sep='')
        assert stringc("Hello", color).endswith('\033[0m') == True
        assert stringc("Hello", color).startswith(u'\033[') == True

    print(stringc("Hello", 'color8'), sep='')
    assert stringc("Hello", 'color8').endswith('\033[0m') == True
    assert stringc("Hello", 'color8').startswith(u'\033[') == True

    print(stringc("Hello", 'rgb255255255'), sep='')
    assert stringc

# Generated at 2022-06-23 13:45:04.407874
# Unit test for function stringc
def test_stringc():
    """
    >>> ansible.utils.stringc("text", "green")
    '\\x1b[32mtext\\x1b[0m'
    >>> ansible.utils.stringc("text", "blue")
    '\\x1b[34mtext\\x1b[0m'
    >>> ansible.utils.stringc("text", "0")
    '\\x1b[30mtext\\x1b[0m'
    >>> ansible.utils.stringc("text", "rgb255255255")
    '\\x1b[37mtext\\x1b[0m'
    """
    return True


# When called as a script, run the test.
if __name__ == "__main__":
    import doctest

    failed, total = doctest.testmod()

    status = 0

# Generated at 2022-06-23 13:45:13.865852
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor(host='host', stats={'failures': 0, 'unreachable': 0, 'changed': 0}, color=True)
    if ANSIBLE_COLOR:
        hostcolor(host='host', stats={'failures': 0, 'unreachable': 0, 'changed': 1}, color=True)
        hostcolor(host='host', stats={'failures': 1, 'unreachable': 0, 'changed': 0}, color=True)
        hostcolor(host='host', stats={'failures': 0, 'unreachable': 1, 'changed': 0}, color=True)
# --- end of "pretty" ---



# Generated at 2022-06-23 13:45:25.018325
# Unit test for function hostcolor
def test_hostcolor():
    # If a host has no errors, it is displayed in green
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert '\033[32m' in hostcolor('localhost', stats)
    # If a host has errors, it is displayed in red
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert '\033[31m' in hostcolor('localhost', stats)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert '\033[31m' in hostcolor('localhost', stats)
    # If a host has changed, it is displayed in yellow
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-23 13:45:37.575123
# Unit test for function stringc
def test_stringc():
    class proto:
        def __init__(self, isatty):
            self.isatty = isatty
        def fileno(self):
            return sys.stdout.fileno()


# Generated at 2022-06-23 13:45:50.948911
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('brightred') == '91'
    assert parsecolor('brightgreen') == '92'
    assert parsecolor('brightyellow') == '93'
    assert parsecolor('brightblue') == '94'
    assert parsecolor('brightmagenta') == '95'
    assert parsecolor('brightcyan') == '96'

# Generated at 2022-06-23 13:46:00.856076
# Unit test for function hostcolor
def test_hostcolor():
    color=False
    stats = dict(ok=0, skipped=0, failed=10, unreachable=5, changed=0)
    host = u"10.0.0.1"
    s = hostcolor(host, stats, color)
    assert s == u'10.0.0.1               '

    color=True
    stats = dict(ok=0, skipped=0, failed=10, unreachable=5, changed=0)
    host = u"10.0.0.1"
    s = hostcolor(host, stats, color)
    assert s == u"\033[31m10.0.0.1             \033[0m"

    color=False
    stats = dict(ok=0, skipped=0, failed=0, unreachable=5, changed=0)

# Generated at 2022-06-23 13:46:06.672781
# Unit test for function hostcolor
def test_hostcolor():
    # create a results structure
    stats = dict(
        skips=0,
        ok=0,
        changed=0,
        unreachable=0,
        failures=0
    )

    colorize('a', 0, 'red')
    colorize('a', 1, 'red')

    hostcolor('test', stats, color=False)
    hostcolor('test', stats, color=True)

    stats['unreachable'] = 1
    hostcolor('test', stats, color=False)
    hostcolor('test', stats, color=True)



# Generated at 2022-06-23 13:46:15.760321
# Unit test for function colorize
def test_colorize():
    """ Print some colorized text to make sure it's working
    """
    print("colorize red: " + colorize("PENIS", "fat", "red"))
    print("colorize blue: " + colorize("PENIS", "fat", "blue"))
    print("colorize yellow: " + colorize("PENIS", "fat", "yellow"))
    print("colorize default: " + colorize("PENIS", "fat"))
    print("colorize no: " + colorize("PENIS", "fat", None))


# --- end "pretty"

# ==============================================================
# Main: unit test for colorize

if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-23 13:46:22.824299
# Unit test for function colorize
def test_colorize():
    color_tests = [(u'changed', 12, C.COLOR_CHANGED),
                   (u'failed', 0, C.COLOR_ERROR),
                   (u'unreachable', 10, C.COLOR_UNREACHABLE),
                   (u'ok', 0, C.COLOR_OK),
                   (u'ok', 1, C.COLOR_OK),
                   (u'skipped', 0, C.COLOR_SKIP)]

    for (lead, num, color) in color_tests:
        yield colorize, lead, num, color

# end of "pretty"


# Generated at 2022-06-23 13:46:30.804064
# Unit test for function parsecolor
def test_parsecolor():
    # Test cases
    assert parsecolor('black') == u'30'
    assert parsecolor('bright gray') == u'37'
    assert parsecolor('blue') == u'34'
    assert parsecolor('white') == u'97'
    assert parsecolor('green') == u'32'
    assert parsecolor('hi black') == u'90'
    assert parsecolor('hi red') == u'91'
    assert parsecolor('hi green') == u'92'
    assert parsecolor('hi yellow') == u'93'
    assert parsecolor('hi blue') == u'94'
    assert parsecolor('hi magenta') == u'95'
    assert parsecolor('hi cyan') == u'96'
    assert parsecolor('hi white') == u'97'

# Generated at 2022-06-23 13:46:40.825220
# Unit test for function colorize

# Generated at 2022-06-23 13:46:46.892851
# Unit test for function colorize
def test_colorize():
    """ colorize() - unit test for function colorize """
    for color in ('normal', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        print(colorize('Test', 1, color))
        print(colorize('Test', 0, color))


# Generated at 2022-06-23 13:46:57.374201
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('brightgray') == '37'
    assert parsecolor('blue') == '34'
    assert parsecolor('cyan') == '36'
    assert parsecolor('green') == '32'
    assert parsecolor('lightblue') == '94'
    assert parsecolor('lightcyan') == '96'
    assert parsecolor('lightgreen') == '92'
    assert parsecolor('lightmagenta') == '95'
    assert parsecolor('lightred') == '91'
    assert parsecolor('lightwhite') == '97'
    assert parsecolor('lightyellow') == '93'
    assert parsecolor('magenta') == '35'
    assert parsecolor('red') == '31'
    assert parsecolor

# Generated at 2022-06-23 13:47:09.456849
# Unit test for function colorize
def test_colorize():
    from ansible.compat import unittest

    class TestColorize(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_colorize(self):
            # Test lead string
            input_string = u"abc"
            for color in C.COLOR_CODES:
                self.assertTrue(u'\033[' in colorize(input_string, 0, color))
            self.assertEqual(u'abc=0', colorize(input_string, 0, None))

            # Test number
            input_number = 0
            self.assertEqual(u'abc=0', colorize(input_string, input_number, None))

            input_number = "0"

# Generated at 2022-06-23 13:47:20.645755
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('blue') == '34'
    assert parsecolor('bold') == '1'

    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('rgb230') == '38;5;130'
    assert parsecolor('rgb323') == '38;5;35'
    assert parsecolor('gray8') == '38;5;244'
    assert parsecolor('gray0') == '38;5;232'

# Local Variables:
# mode: python
# py-indent-offset: 4
# End:
# vi: set ft=python :

# Generated at 2022-06-23 13:47:32.165352
# Unit test for function stringc
def test_stringc():
    assert stringc('a', 'blue', wrap_nonvisible_chars=True) == '\001\033[38;5;4m\002a\001\033[0m\002'
    assert stringc('a', 'blue') == '\033[38;5;4ma\033[0m'
    assert stringc('a', 'blue') == '\033[38;5;4ma\033[0m'
    assert stringc('a', 'rgb255255255') == '\033[38;5;15ma\033[0m'
    assert stringc('a', 'rgb255255255') == '\033[38;5;15ma\033[0m'
    assert stringc('a', 'rgb255255255') == '\033[38;5;15ma\033[0m'


# Generated at 2022-06-23 13:47:44.207347
# Unit test for function parsecolor
def test_parsecolor():
    import ansible.constants as C
    for color in C.COLOR_CODES:
        if color == 'RESET':
            continue
        assert parsecolor(color) == C.COLOR_CODES[color]
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb555') == '38;5;231'

# Generated at 2022-06-23 13:47:56.039309
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor, ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # Test cases:
    # (host, stats, exp_host)

# Generated at 2022-06-23 13:48:05.615934
# Unit test for function stringc
def test_stringc():
    assert type(stringc('test', 'red')) == unicode
    assert stringc('test', 'red') == u'\033[31mtest\033[0m'
    assert stringc('test', 'bold') == u'\033[1mtest\033[0m'
    assert stringc('test', 'underline') == u'\033[4mtest\033[0m'
    assert stringc('test', 'green') == u'\033[32mtest\033[0m'
    assert stringc('test', 'badcolor') == u'test'


# Generated at 2022-06-23 13:48:19.464510
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color256') == u'38;5;256'
    assert parsecolor('rgb123') == u'38;5;28'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray23') == u'38;5;255'
    assert parsecolor('default') == u'39'
    assert parsecolor('BLACK') == u'30'

# Generated at 2022-06-23 13:48:21.668269
# Unit test for function colorize
def test_colorize():
    test_string = "TEST STRING TEST STRING"
    print(colorize(test_string, "1", "red"))


# Generated at 2022-06-23 13:48:32.000113
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        ok=0,
        changed=0,
        skipped=0,
        failures=0,
        unreachable=0)
    host = u'host.example.org'
    assert hostcolor(host, stats, True) == u"%-26s" % u"host.example.org"
    assert hostcolor(host, stats, False) == u"%-26s" % u"host.example.org"

    stats['changed'] = 1
    assert hostcolor(host, stats, True) == u"%-37s" % u"\n".join([u'\033[1;33mhost.example.org\033[0m'])
    assert hostcolor(host, stats, False) == u"%-26s" % u"host.example.org"

    stats['changed'] = 0
    stats

# Generated at 2022-06-23 13:48:38.709245
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return
    print(stringc("TEST STRING", "GREEN"))
    print(stringc("TEST STRING", "red"))
    print(stringc("TEST STRING", "grAy3"))
    print(stringc("TEST STRING", "rgb124"))
    print(stringc("TEST STRING", "color176"))
    print(stringc("TEST STRING", "nonexistent_color"))

# --- end "pretty"



# Generated at 2022-06-23 13:48:44.495721
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "

# --- end "pretty"

# Generated at 2022-06-23 13:48:51.271576
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo", {'failures': 1, 'changed': 0, 'skipped': 0, 'ok': 0, 'unreachable': 0}) == stringc("foo", C.COLOR_ERROR)
    assert hostcolor("foo", {'failures': 0, 'changed': 1, 'skipped': 0, 'ok': 0, 'unreachable': 0}) == stringc("foo", C.COLOR_CHANGED)
    assert hostcolor("foo", {'failures': 0, 'changed': 0, 'skipped': 0, 'ok': 1, 'unreachable': 0}) == stringc("foo", C.COLOR_OK)


# Generated at 2022-06-23 13:49:00.100114
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('cyan') == u'38;5;6'
    assert parsecolor('light_gray') == u'38;5;7'
    assert parsecolor('dark_gray') == u'38;5;8'
    assert parsecolor('light_red') == u'38;5;9'

# Generated at 2022-06-23 13:49:09.825165
# Unit test for function hostcolor
def test_hostcolor():
    test_stats = dict(
        ok=100,
        changed=1,
        unreachable=0,
        failures=0
    )
    host_string = hostcolor('localhost', test_stats, color=True)
    assert host_string == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)

    test_stats['changed'] = 0
    host_string = hostcolor('localhost', test_stats, color=True)
    assert host_string == u"%-37s" % stringc('localhost', C.COLOR_OK)

    test_stats['unreachable'] = 1
    host_string = hostcolor('localhost', test_stats, color=True)
    assert host_string == u"%-37s" % stringc('localhost', C.COLOR_ERROR)


# Generated at 2022-06-23 13:49:21.136174
# Unit test for function hostcolor
def test_hostcolor():
    good = {'changed': 0, 'failures': 0, 'ok': 6, 'skipped': 0, 'unreachable': 0}
    bad = {'changed': 1, 'failures': 2, 'ok': 3, 'skipped': 4, 'unreachable': 5}
    one = {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    two = {'changed': 0, 'failures': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    three = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 1}

# Generated at 2022-06-23 13:49:30.161952
# Unit test for function parsecolor

# Generated at 2022-06-23 13:49:36.114935
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == u'34'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("rgb222") == u'38;5;18'
    assert parsecolor("rgb123") == u'38;5;19'
    assert parsecolor("rgb321") == u'38;5;21'
    assert parsecolor("rgb555") == u'38;5;231'
    assert parsecolor("gray1") == u'38;5;234'
    assert parsecolor("foo") is None


# Generated at 2022-06-23 13:49:48.154442
# Unit test for function stringc
def test_stringc():
    """Unit test"""
    if ANSIBLE_COLOR:
        assert stringc("Test", "green") == u"\033[32mTest\033[0m"
        assert stringc("Test", "0") == u"\033[38;5;0mTest\033[0m"
        assert stringc("Test", "rgb255255255") == u"\033[38;5;15mTest\033[0m"
        assert stringc("Test", "rgb000255255") == u"\033[38;5;6mTest\033[0m"
        assert stringc("Test", "rgb255255000") == u"\033[38;5;11mTest\033[0m"

# Generated at 2022-06-23 13:49:58.189704
# Unit test for function stringc

# Generated at 2022-06-23 13:50:07.657826
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test_host", dict(failures=0, unreachable=0, changed=0)) == u"test_host                 "
    assert hostcolor("test_host", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mtest_host                 \x1b[0m"
    assert hostcolor("test_host", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mtest_host                 \x1b[0m"
    assert hostcolor("test_host", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mtest_host                 \x1b[0m"

# Generated at 2022-06-23 13:50:18.838417
# Unit test for function parsecolor
def test_parsecolor():
    '''
    Make sure colors are parsed correctly
    '''
    assert parsecolor('dark gray') == u'38;5;242'
    assert parsecolor('light blue') == u'38;5;39'
    assert parsecolor('light green') == u'38;5;41'
    assert parsecolor('light cyan') == u'38;5;51'
    assert parsecolor('light red') == u'38;5;9'
    assert parsecolor('light magenta') == u'38;5;199'
    assert parsecolor('yellow') == u'38;5;11'
    assert parsecolor('white') == u'38;5;15'
    assert parsecolor('default') == u'39'
    assert parsecolor('dark gray') == u'38;5;242'

# Generated at 2022-06-23 13:50:23.544766
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost                 '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'localhost                 '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'localhost                 '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'localhost                 '



# Generated at 2022-06-23 13:50:35.511712
# Unit test for function stringc
def test_stringc():
    # Test foreground colors
    assert '\033[30m' + 'black' + '\033[0m' == stringc('black', 'black')
    assert '\033[31m' + 'red' + '\033[0m' == stringc('red', 'red')
    assert '\033[32m' + 'green' + '\033[0m' == stringc('green', 'green')
    assert '\033[33m' + 'yellow' + '\033[0m' == stringc('yellow', 'yellow')
    assert '\033[34m' + 'blue' + '\033[0m' == stringc('blue', 'blue')
    assert '\033[35m' + 'magenta' + '\033[0m' == stringc('magenta', 'magenta')

# Generated at 2022-06-23 13:50:47.655855
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"red") == u"38;5;1"
    assert parsecolor(u"GREEN") == u"38;5;2"
    assert parsecolor(u"blue") == u"38;5;4"
    assert parsecolor(u"bLUE") == u"38;5;4"
    assert parsecolor(u"black") == u"38;5;0"
    assert parsecolor(u"orange") == u"38;5;202"
    assert parsecolor(u"yellow") == u"38;5;11"
    assert parsecolor(u"violet") == u"38;5;13"
    assert parsecolor(u"color0") == u"38;5;0"

# Generated at 2022-06-23 13:50:56.504261
# Unit test for function hostcolor
def test_hostcolor():
    import copy
    hosts = {'foo': {'unreachable': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'changed': 0}}
    assert hostcolor(u'foo', hosts['foo'], color=False) == u'%-26s' % u'foo'

    assert hostcolor(u'foo', hosts['foo']) == u'%-37s' % u'\033[0;32mfoo\033[0m'
    hosts['foo']['changed'] = 1
    assert hostcolor(u'foo', hosts['foo']) == u'%-37s' % u'\033[0;33mfoo\033[0m'
    hosts['foo']['changed'] = 0
    hosts['foo']['failures'] = 1

# Generated at 2022-06-23 13:51:07.711688
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('black') == '30'
    assert parsecolor('yellow') == '33'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color99') == '38;5;99'
    assert parsecolor('color123') == '38;5;123'
    assert parsecolor('color256') == '38;5;256'
    assert parsecolor('color300') == '38;5;300'
    assert parsecolor('rgb123') == '38;5;6'
    assert parsecolor('rgb456') == '38;5;114'
    assert parsecolor('rgb789') == '38;5;172'


# Generated at 2022-06-23 13:51:17.250272
# Unit test for function colorize
def test_colorize():
    from six import StringIO

    class MockTerm:
        def __init__(self):
            self.old = sys.stdout
            self.handle = StringIO()
            self.color = True
        def __enter__(self):
            sys.stdout = self.handle
            return self
        def __exit__(self, type, value, traceback):
            sys.stdout = self.old
            self.color = False

    with MockTerm() as mt:
        print(colorize("foo", 0, u'red'))
        assert("foo=0   " == mt.handle.getvalue())

        print(colorize("foo", 1, u'red'))
        assert("foo=1   " == mt.handle.getvalue())

        print(colorize("foo", 0, u'red'), end='')
       

# Generated at 2022-06-23 13:51:29.425202
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'warn', True) == "\n".join([u"\001\033[93m\002foo\001\033[0m\002"])
    assert stringc('foo', 'error', True) == "\n".join([u"\001\033[91m\002foo\001\033[0m\002"])
    assert stringc('foo', 'warn', False) == "\n".join([u"\033[93mfoo\033[0m"])


# --- end "pretty"

# global color settings for all text
ansible_color = C.COLOR_OK

# Stuff that ends up in the output, should get a reset
out_color = [C.COLOR_WARN, C.COLOR_ERROR, C.COLOR_SKIP, C.COLOR_OK, C.COLOR_CHANGED]

# Generated at 2022-06-23 13:51:40.923999
# Unit test for function colorize
def test_colorize():
    """ ansible colorization tests """

    # test list of tuples (lead, num, color)
    # any failure in the colorization should result in a failed test

    testlist = [
        (u"ok", 1234, C.COLOR_OK),
        (u"changed", 4321, C.COLOR_CHANGED),
        (u"darkred", 0, C.COLOR_ERROR),
        (u"darkgreen", 1, C.COLOR_OK),
        (u"darkyellow", 2, C.COLOR_CHANGED),
        (u"darkblue", 3, C.COLOR_UNREACHABLE)
    ]

    for lead, num, color in testlist:
        yield colorize, lead, num, color

# end pretty

if __name__ == '__main__':
    import nose
    nose.run

# Generated at 2022-06-23 13:51:49.114117
# Unit test for function stringc
def test_stringc():
    # from bpython import embed
    # embed()
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'default') == u'\033[39mfoo\033[0m'
    assert stringc('foo', 'teal') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'

# Generated at 2022-06-23 13:51:59.575281
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('somehost', dict(ok=1, failures=0, unreachable=0, changed=0)) == u"%-37s" % 'somehost'
    assert hostcolor('somehost', dict(ok=1, failures=1, unreachable=0, changed=0)) == u"%-37s" % u"\u001b[31msomehost\u001b[0m"
    assert hostcolor('somehost', dict(ok=1, failures=0, unreachable=0, changed=1)) == u"%-37s" % u"\u001b[33msomehost\u001b[0m"



# Generated at 2022-06-23 13:52:11.346757
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert parsecolor('red') == u'31'
        assert parsecolor('black') == u'30'
        assert parsecolor('01') == u'38;5;1'
        assert parsecolor('16') == u'38;5;16'
        assert parsecolor('15') == u'38;5;15'
        assert parsecolor('231') == u'38;5;231'
        assert parsecolor('rgb255255255') == u'38;5;231'
        assert parsecolor('rgb000') == u'38;5;16'
        assert parsecolor('rgb2550000255') == u'38;5;213'
        assert parsecolor('rgb0000255') == u'38;5;21'
        assert parsecolor

# Generated at 2022-06-23 13:52:15.997159
# Unit test for function colorize
def test_colorize():
    lead = u'foo'
    num = 42
    color = 'red'
    expected = stringc(u'foo=42', 'red')
    res = colorize(lead, num, color)
    assert res == expected


# Generated at 2022-06-23 13:52:25.714398
# Unit test for function colorize
def test_colorize():
    # ANSIBLE_COLOR not set
    global ANSIBLE_COLOR
    old_ansible_color = ANSIBLE_COLOR
    ANSIBLE_COLOR = False

    assert colorize('abc', 0, 'red') == 'abc=0   '
    assert colorize('abc', 123, 'red') == 'abc=123 '
    assert colorize('abc', 12345, 'red') == 'abc=12345'
    assert colorize('abc', -1, 'red') == 'abc=-1  '
    assert colorize('abc', -123, 'red') == 'abc=-123'

    ANSIBLE_COLOR = old_ansible_color


# Generated at 2022-06-23 13:52:35.168232
# Unit test for function hostcolor
def test_hostcolor():
    sys.stdout.write(u"Test 1: ")
    assert hostcolor(u"foo1.example.org", {u'ok': 10, u'changed': 0, u'unreachable': 0, u'failures': 0}, color=False) == u"foo1.example.org           ", "No color: foo1.example.org"
    assert hostcolor(u"foo1.example.org", {u'ok': 10, u'changed': 0, u'unreachable': 0, u'failures': 0}, color=True) == u"foo1.example.org           ", "Green: foo1.example.org"
    assert hostcolor(u"foo2.example.org", {u'ok': 0, u'changed': 10, u'unreachable': 0, u'failures': 0}, color=False)

# Generated at 2022-06-23 13:52:46.195978
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('bad') is None
    assert parsecolor('blue') == '34'
    assert parsecolor('brightpurple') == '35'
    assert parsecolor('red') == '31'
    assert parsecolor('onred') == '41'
    assert parsecolor('onbrightred') == '101'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color252') == '38;5;252'
    assert parsecolor('color256') is None
    assert parsecolor('rgb255255255') == '38;5;231'
    assert parsecolor('rgb256256256') is None
    assert parsecolor('rgb2550') is None
    assert parsecolor('rgb25500') is None

# Generated at 2022-06-23 13:52:49.182978
# Unit test for function colorize
def test_colorize():
    for i in range(-10, 10):
        out = colorize('test', i, 'blue')
        print(out)



# Generated at 2022-06-23 13:53:00.279085
# Unit test for function parsecolor
def test_parsecolor():
    def assert_parsecolor(name, result):
        if parsecolor(name) != result:
            print(u"Parsecolor: FAIL", name, parsecolor(name), result)
        else:
            print(u"Parsecolor: OK", name)

    assert_parsecolor('blue', '38;5;4')
    assert_parsecolor('brightpurple', '38;5;93')
    assert_parsecolor('red', '38;5;9')
    assert_parsecolor('green', '38;5;2')
    assert_parsecolor('white', '38;5;15')
    assert_parsecolor('rgb255000255', '38;5;213')
    assert_parsecolor('rgb255255255', '38;5;231')
    assert_par

# Generated at 2022-06-23 13:53:08.368704
# Unit test for function colorize
def test_colorize():
    """ ansible colorize - tests colorize function """

# Generated at 2022-06-23 13:53:18.418157
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"color30") == u"\033[38;5;30mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"

# Generated at 2022-06-23 13:53:28.388685
# Unit test for function colorize
def test_colorize():
    # Use this to test the function colorize

    def test_color(lead, num, color):
        """ Print 'lead' = 'num' in 'color' """
        sys.stdout.write(colorize(lead, num, color))
        sys.stdout.write(" ")

    print("testing ANSIBLE_COLOR=True")
    test_color("changed", 2, C.COLOR_CHANGED)
    test_color("failures", 0, C.COLOR_ERROR)
    test_color("ok", 22, C.COLOR_OK)
    test_color("dark red", 3, "dark red")
    test_color("dark green", 4, "dark green")
    test_color("blue", 5, "blue")
    test_color("red", 6, "red")

# Generated at 2022-06-23 13:53:32.869608
# Unit test for function hostcolor
def test_hostcolor():
    # 1. Using ansible-playbook colorized output
    stats = {'ok': 0, 'changed': 1, 'failures': 0, 'unreachable': 0}
    print(hostcolor('localhost', stats))
    # 2. Using ansible-playbook non-colorized output
    stats = {'ok': 7, 'changed': 5, 'failures': 2, 'unreachable': 1}
    print(hostcolor('localhost', False, stats))

# --- end "pretty"

# Utility functions for printing non-colorized data

# Generated at 2022-06-23 13:53:43.011385
# Unit test for function colorize
def test_colorize():
    ''' colorize() function unit test '''
    from ansible.utils.unicode import to_unicode

    # Set our lead string and numeric value
    lead = to_unicode("LEAD")
    num = 0

    # Set ANSIBLE_COLOR to True and test that color is applied
    state = ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # Test num == 0 with and without color
    for color in (None, "blue"):
        assert colorize(lead, num, color) == u"LEAD=0   "

    # Test num != 0 with and without color
    num = 1