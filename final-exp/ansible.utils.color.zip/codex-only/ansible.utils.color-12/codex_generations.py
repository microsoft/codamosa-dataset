

# Generated at 2022-06-23 13:43:39.440659
# Unit test for function stringc
def test_stringc():
    for code in C.COLOR_CODES:
        print("this is %s" % (stringc("code " + code, code)))
    print("this is %s" % (stringc("unchanged text", None)))
    print("this is %s" % (stringc("\na multiline \nstring\nwith newlines\n", "red", True)))



# Generated at 2022-06-23 13:43:46.047485
# Unit test for function parsecolor
def test_parsecolor():
    for name, code in C.COLOR_CODES.items():
        assert parsecolor(name) == code
    assert parsecolor(u"color8") == u"38;5;8"
    assert parsecolor(u"color16") == u"38;5;16"
    assert parsecolor(u"color99") == u"38;5;99"
    assert parsecolor(u"rgb100") == u"38;5;16"
    assert parsecolor(u"rgb150") == u"38;5;34"
    assert parsecolor(u"rgb555") == u"38;5;231"
    assert parsecolor(u"rgb511") == u"38;5;231"

# Generated at 2022-06-23 13:43:55.150042
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc("color", "white") == u"\033[1;37mcolor\033[0m"
        assert stringc("color", "black") == u"\033[1;30mcolor\033[0m"
        assert stringc("color", "lightgray") == u"\033[1;37mcolor\033[0m"
        assert stringc("color", "darkgray") == u"\033[30;1mcolor\033[0m"
        assert stringc("color", "red") == u"\033[1;31mcolor\033[0m"
        assert stringc("color", "green") == u"\033[1;32mcolor\033[0m"

# Generated at 2022-06-23 13:44:04.495236
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.callbacks import AggregateStats
    from ansible.utils.color import hostcolor

    hc = hostcolor(u"foobar", AggregateStats(), True)
    assert hc == u"%-37s" % u"foobar", hc

    hc = hostcolor(u"foobar", AggregateStats(dark=dict(failures=1)), True)
    assert hc == u"%-37s" % stringc(u"foobar", C.COLOR_ERROR), hc

    hc = hostcolor(u"foobar", AggregateStats(dark=dict(changed=1)), True)
    assert hc == u"%-37s" % stringc(u"foobar", C.COLOR_CHANGED), hc


# Generated at 2022-06-23 13:44:12.835398
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(changed=1, failures=0, unreachable=0)) == "localhost                        "
    assert hostcolor("localhost", dict(changed=0, failures=1, unreachable=0)) == "localhost                        "
    assert hostcolor("localhost", dict(changed=0, failures=0, unreachable=1)) == "localhost                        "
    assert hostcolor("localhost", dict(changed=0, failures=0, unreachable=0)) == "localhost                        "

# --- end "pretty"

# --- begin "remove_ansible_colors"


# Generated at 2022-06-23 13:44:24.715692
# Unit test for function hostcolor
def test_hostcolor():
    os.environ["ANSIBLE_NOCOLOR"] = "False"
    os.environ["ANSIBLE_FORCE_COLOR"] = "False"
    if hasattr(sys.stdout, 'isatty') and sys.stdout.isatty():
        os.environ['TERM'] = "xterm-color"
    else:
        os.environ['TERM'] = "dumb"
    hostcolor_test = "_hostcolor_test"
    # Test with color = True, a hostname starting with '_hostcolor_test'
    # and stats = {'failures': 0, 'unreachable': 0, 'changed': 0} (OK)
    result = hostcolor(hostcolor_test, {'failures': 0, 'unreachable': 0, 'changed': 0}, color=True)

# Generated at 2022-06-23 13:44:31.725844
# Unit test for function hostcolor
def test_hostcolor():
    """
    Black       0;30     Dark Gray     1;30
    Red         0;31     Light Red     1;31
    Green       0;32     Light Green   1;32
    Brown/Orange 0;33     Yellow        1;33
    Blue        0;34     Light Blue    1;34
    Purple      0;35     Light Purple  1;35
    Cyan        0;36     Light Cyan    1;36
    Light Gray  0;37     White         1;37
    """
    # When color is disabled, the hostname should be correctly formatted.
    assert hostcolor(u"myhost", dict(ok=1, changed=0, unreachable=0, failures=0), color=False) == u"myhost            "
    # When all stats are zero, color should be C.COLOR_OK

# Generated at 2022-06-23 13:44:41.640732
# Unit test for function stringc
def test_stringc():
    assert not stringc(u"test", u"")
    assert (stringc(u"test", u"red") ==
            u"\x1b[31mtest\x1b[0m")
    assert (stringc(u"test", u"red", True) ==
            u"\001\x1b[31m\002test\001\x1b[0m\002")
    assert (stringc(u"test", u"color255") ==
            u"\x1b[38;5;255mtest\x1b[0m")
    assert (stringc(u"test", u"rgb255255255") ==
            u"\x1b[38;5;231mtest\x1b[0m")

# Generated at 2022-06-23 13:44:47.232699
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'127.0.0.1', dict(
        ok=10,
        failures=0,
        unreachable=0,
        changed=0
    )) == u'127.0.0.1                        '

    assert hostcolor(u'127.0.0.1', dict(
        ok=0,
        changed=2,
        failures=1,
        unreachable=1
    )) == u'127.0.0.1                        '



# Generated at 2022-06-23 13:44:59.974566
# Unit test for function stringc
def test_stringc():
    """Test that stringc returns correct characters."""
    tests = [u'\033[38;5;%dm%s\033[0m' % (i, i) for i in xrange(0, 16)] + \
        [u'\033[38;5;%dm%s\033[0m' % (16+i, 16+i) for i in xrange(0, 6)] + \
        [u'\033[38;5;%dm%s\033[0m' % (232+i, 232+i) for i in xrange(0, 24)]

    for i in xrange(0, 16):
        assert stringc(unicode(i), unicode(i)) == tests[i]

# Generated at 2022-06-23 13:45:12.666432
# Unit test for function stringc
def test_stringc():
    """This function is called from ANSIBLE_LIBRARY/test/test_color.py"""
    import sys
    ERRORCODE = 1

    def eprint(*args, **kwargs):
        print(*args, file=sys.stderr, **kwargs)

    def assert_equal(s1, s2):
        if s1 != s2:
            eprint('%r != %r' % (s1, s2))
            sys.exit(ERRORCODE)

    assert_equal(parsecolor('bold'), '1')
    assert_equal(parsecolor('UNKNOWN'), None)
    assert_equal(stringc('hello', 'bold'), '\033[1mhello\033[0m')

    # Not supported by the default curses on Fedora
    assert_equal(parsecolor('color1'), None)

# Generated at 2022-06-23 13:45:24.687214
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"foo", dict(failures=1, unreachable=0, changed=0)) == u"\033[0;31mfoo\033[0m             "
    assert hostcolor(u"foo", dict(failures=0, unreachable=1, changed=0)) == u"\033[0;31mfoo\033[0m             "
    assert hostcolor(u"foo", dict(failures=0, unreachable=0, changed=1)) == u"\033[0;33mfoo\033[0m             "
    assert hostcolor(u"foo", dict(failures=0, unreachable=0, changed=0)) == u"\033[0;32mfoo\033[0m             "
    assert hostcolor(None, dict(failures=0, unreachable=0, changed=0))

# Generated at 2022-06-23 13:45:37.347087
# Unit test for function stringc
def test_stringc():
    color_codes = set(C.COLOR_CODES.values()) | {u'38;5;%d' % i for i in range(0, 256)}
    all_codes = (None,) + color_codes
    labels = ('none',) + tuple(C.COLOR_CODES) + tuple(u'color%d' % i for i in range(0, 256))
    print(u'Testing function stringc')
    for c in all_codes:
        for s in labels:
            if c is None:
                cs = u''
            else:
                cs = u'\033[%sm' % c
            t = u'This is an example string with color %s.' % s

# Generated at 2022-06-23 13:45:50.756661
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('ansible blue') == u'34'
    assert parsecolor('Color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('brown') == u'38;5;94'
    assert parsecolor('rgb123') == u'38;5;130'
    assert parsecolor('RGB234') == u'38;5;172'
    assert parsecolor('rgb333') == u'38;5;236'
    assert parsecolor('rgb111') == u'38;5;16'
    assert parsecolor('gray2') == u'38;5;234'

# Generated at 2022-06-23 13:46:00.732621
# Unit test for function hostcolor
def test_hostcolor():
    test_name = 'test'
    stats_failed = {'failures': 1, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    stats_unreachable = {'failures': 0, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 1}
    stats_changed = {'failures': 0, 'changed': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    stats_ok = {'failures': 0, 'changed': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(test_name, stats_changed, True) == stringc(test_name, C.COLOR_CHANGED)

# Generated at 2022-06-23 13:46:08.105708
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('1') == u'38;5;1'
    assert parsecolor('01') == u'38;5;1'
    assert parsecolor('10') == u'38;5;16'
    assert parsecolor('220') == u'38;5;220'
    assert parsecolor('2220') == u'38;5;220'
    assert parsecolor('-1') == u'38;5;1'
    assert parsecolor('-01') == u'38;5;1'
    assert parsecolor('-10') == u'38;5;16'
    assert parsecolor('-220') == u'38;5;220'
    assert parsecolor('-2220') == u'38;5;220'

    assert parsecolor('rgb000') == u

# Generated at 2022-06-23 13:46:20.096247
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        # This just means color won't be enabled for the test
        print("Color not enabled for tests")
        sys.exit(0)
    stringc('this is blue', 'blue')
    stringc('this is red', 'red')
    stringc('this is cyan', 'cyan')
    stringc('this is green', 'green')
    stringc('this is yellow', 'yellow')
    stringc('this is white', 'white')
    stringc('this is purple', 'purple')
    stringc('this is normal', 'normal')
    stringc('this is reset', '')
    stringc('this is an unknown color', 'unknown')
    stringc('this is a bold white', 'bold white')
    stringc('this is an underlined red bold', 'underline red', True)

# Generated at 2022-06-23 13:46:29.943985
# Unit test for function hostcolor
def test_hostcolor():
    _hostcolor = lambda h, f, u, c: hostcolor(h, dict(failures=f, unreachable=u, changed=c), color=True)
    # Passes the test if it returns the same string
    assert _hostcolor('host0', 0, 0, 0)     == hostcolor('host0', dict(failures=0, unreachable=0, changed=0), color=False)
    assert _hostcolor('host1', 1, 0, 0)     == hostcolor('host1', dict(failures=1, unreachable=0, changed=0), color=False)
    assert _hostcolor('host2', 0, 1, 0)     == hostcolor('host2', dict(failures=0, unreachable=1, changed=0), color=False)

# Generated at 2022-06-23 13:46:40.295947
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'green') == u'32'
    assert parsecolor(u'color2') == u'38;5;2'
    assert parsecolor(u'rgb252') == u'38;5;94'
    assert parsecolor(u'rgb2520') == u'38;5;94'
    assert parsecolor(u'rgb2255') == u'38;5;81'
    assert parsecolor(u'rgb220') == u'38;5;80'
    assert parsecolor(u'gray1') == u'38;5;234'
    assert parsecolor(u'gray0') == u'38;5;232'
    assert parsecolor(u'gray8') == u'38;5;242'


# Generated at 2022-06-23 13:46:46.036504
# Unit test for function stringc
def test_stringc():
    s = stringc('foo', C.COLOR_OK, wrap_nonvisible_chars=True)
    assert s == u"\x01\x1b[32m\x02foo\x01\x1b[0m\x02"


if __name__ == "__main__":
    test_stringc()

# Generated at 2022-06-23 13:46:56.629087
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "blue") == u"\n\033[34mtext\033[0m"
    assert stringc("text\nmultiline", "red") == u"\n\033[31mtext\033[0m\n\033[31mmultiline\033[0m"
    assert stringc("text", "color5") == u"\n\033[38;5;5mtext\033[0m"
    assert stringc("text", "rgb4114") == u"\n\033[38;5;112mtext\033[0m"
    assert stringc("text", "gray5") == u"\n\033[38;5;238mtext\033[0m"
# --- end "pretty"

# Generated at 2022-06-23 13:47:03.613246
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"bar", u"rgb255255255") == u"\033[38;5;15mbar\033[0m"
    assert stringc(u"baz", u"color0") == u"\033[38;5;0mbaz\033[0m"
    assert stringc(u"foo\nbar\nbaz", u"green") == u"\033[32mfoo\033[0m\n\033[32mbar\033[0m\n\033[32mbaz\033[0m"

if __name__ == '__main__':
    test_stringc()
    print(u"All tests passed.")

# --- end "pretty"

# Generated at 2022-06-23 13:47:11.792279
# Unit test for function hostcolor
def test_hostcolor():
    # TODO: use mock object istead of `dict`
    stats = dict(ok=1, failures=1, unreachable=1, changed=1)
    assert hostcolor('host', stats, False) == 'host              '
    assert hostcolor('host', stats, True) == u'\u001b[0mhost\u001b[0m            '
    stats['unreachable'] = 0
    assert hostcolor('host', stats, True) == u'\u001b[0;36mhost\u001b[0m         '
    stats['changed'] = 0
    assert hostcolor('host', stats, True) == u'\u001b[0;31mhost\u001b[0m       '

if __name__ == "__main__":
    test_hostcolor()

# Generated at 2022-06-23 13:47:23.622522
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'

    # Tests for ANSIBLE_COLOR being True
    assert hostcolor(host, {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == '%-37s' % stringc(host, C.COLOR_OK)
    assert hostcolor(host, {'failures': 0, 'unreachable': 0, 'changed': 1}, True) == '%-37s' % stringc(host, C.COLOR_CHANGED)
    assert hostcolor(host, {'failures': 1, 'unreachable': 0, 'changed': 1}, True) == '%-37s' % stringc(host, C.COLOR_ERROR)
    assert hostcolor(host, {'failures': 0, 'unreachable': 1, 'changed': 1}, True) == '%-37s' % stringc

# Generated at 2022-06-23 13:47:27.016228
# Unit test for function stringc
def test_stringc():
    """Test function `stringc`."""
    assert stringc("text", "red") == u"\033[31mtext\033[0m"



# Generated at 2022-06-23 13:47:35.497782
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    print(stringc("stringc() testing", "red", True))
    for color in ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']:
        for background in ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']:
            print(stringc("%s on %s" % (color, background),
                          "color%d on_color%d" % (int(color), int(background)), True))

if __name__ == "__main__":
    test_stringc()
# --- end "pretty"

# Generated at 2022-06-23 13:47:47.414508
# Unit test for function colorize
def test_colorize():
    def TestParseColor():
        """ Test function ``parsecolor`` """
        assert parsecolor('blue') == '34'  # check random color
        assert parsecolor('red') == '31'  # check random color
        assert parsecolor('green') == '32'  # check random color
        assert parsecolor('yellow') == '33'  # check random color
        assert parsecolor('magenta') == '35'  # check random color
        assert parsecolor('cyan') == '36'  # check random color
        assert parsecolor('white') == '37'  # check random color
        assert parsecolor('black') == '30'  # check random color
        assert parsecolor('darkblue') == '34'  # check generic color
        assert parsecolor('darkred') == '31'  #

# Generated at 2022-06-23 13:47:59.669089
# Unit test for function stringc
def test_stringc():
    print((u"Testing pretty - stringc()"))
    print((u"Trying to set text to white text on red background..."))
    print((stringc(u"Testing...Testing...1...2...3...", u"white on_red")))
    print((u"Trying to set text to blue on black..."))
    print((stringc(u"Testing...Testing...1...2...3...", u"blue")))
    print((u"Trying to set text to yellow on blue..."))
    print((stringc(u"Testing...Testing...1...2...3...", u"yellow on_blue")))
    print((u"Trying to set text to bold cyan..."))
    print((stringc(u"Testing...Testing...1...2...3...", u"bold cyan")))

# Generated at 2022-06-23 13:48:10.775592
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("ok_host", dict(ok=1, failures=0, unreachable=0, skipped=0, changed=0)) == u"%-26s" % stringc("ok_host", C.COLOR_OK)
    assert hostcolor("changed_host", dict(ok=1, failures=0, unreachable=0, skipped=0, changed=1)) == u"%-26s" % stringc("changed_host", C.COLOR_CHANGED)
    assert hostcolor("failed_host", dict(ok=1, failures=1, unreachable=0, skipped=0, changed=1)) == u"%-26s" % stringc("failed_host", C.COLOR_ERROR)

# Generated at 2022-06-23 13:48:16.126613
# Unit test for function stringc
def test_stringc():
    assert stringc('hello', 'blue') == u"\033[34mhello\033[0m"
    assert stringc('hello', 'black') == u"\033[30mhello\033[0m"
    assert stringc('hello', 'white') == u"\033[37mhello\033[0m"
    assert stringc('hello', 'gray7') == u"\033[38;5;247mhello\033[0m"
    assert stringc('hello', 'gray25') == u"\033[38;5;247mhello\033[0m"
    assert stringc('hello', 'gray250') == u"\033[38;5;247mhello\033[0m"

# Generated at 2022-06-23 13:48:22.414853
# Unit test for function colorize
def test_colorize():
    # returns a color string on supported platforms
    assert colorize('foo', 4, 'blue') == stringc('foo=4', 'blue')
    # returns a color string on supported platforms
    assert colorize('foo', 0, 'blue') == 'foo=0'
    # returns a color string on supported platforms
    assert colorize('foo', 4, None) == 'foo=4'
    # returns a color string on supported platforms
    assert colorize('foo', 0, None) == 'foo=0'


# Generated at 2022-06-23 13:48:25.931066
# Unit test for function stringc
def test_stringc():
    """Test string in color."""

    assert u'\001\033[38;5;124m\002foo\001\033[0m\002' == stringc(u'foo', u'orange', wrap_nonvisible_chars=True)

# Generated at 2022-06-23 13:48:36.193822
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"host", dict(failures=1, unreachable=0, changed=0), False) == u"host                         "
    assert hostcolor(u"host", dict(failures=1, unreachable=0, changed=0), True) == u"\x1b[91mhost                         \x1b[0m"
    assert hostcolor(u"host", dict(failures=0, unreachable=1, changed=0), True) == u"\x1b[91mhost                         \x1b[0m"
    assert hostcolor(u"host", dict(failures=0, unreachable=0, changed=1), True) == u"\x1b[33mhost                         \x1b[0m"

# Generated at 2022-06-23 13:48:44.269093
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc("test", "green") == "\033[32mtest\033[0m"
        assert stringc("test", "red") == "\033[31mtest\033[0m"
        assert stringc("test", "blue") == "\033[34mtest\033[0m"
        assert stringc("test", "gray") == "\033[38;5;7mtest\033[0m"
        assert stringc("test", "rgb255") == "\033[38;5;231mtest\033[0m"


if __name__ == '__main__':
    test_stringc()
    print("Successfully completed 2 tests.")
    sys.exit(0)

# Generated at 2022-06-23 13:48:53.178445
# Unit test for function stringc
def test_stringc():
    compare = lambda t, c: stringc(t, c) == u"\033[%sm%s\033[0m" % (parsecolor(c), t)
    assert compare(u'black', u'black')
    assert compare(u'light gray', u'light gray')
    assert compare(u'white', u'white')
    assert compare(u'red', u'bright red')
    assert compare(u'blue', u'bright blue')
    assert compare(u'green', u'bright green')
    assert compare(u'yellow', u'bright yellow')
    assert compare(u'cyan', u'bright cyan')
    assert compare(u'magenta', u'bright magenta')
    assert compare(u'white', u'rgb555')
    assert compare(u'black', u'rgb000')

# Generated at 2022-06-23 13:49:02.108214
# Unit test for function hostcolor
def test_hostcolor():
    print("hostcolor")
    stats = dict(failures=0, unreachable=0, changed=0)
    print("ok:", hostcolor("foobar", stats))
    stats = dict(failures=1, unreachable=0, changed=0)
    print("fail:", hostcolor("foobar", stats))
    stats = dict(failures=0, unreachable=1, changed=0)
    print("unreachable:", hostcolor("foobar", stats))
    stats = dict(failures=0, unreachable=0, changed=1)
    print("changed:", hostcolor("foobar", stats))
    stats = dict(failures=3, unreachable=4, changed=5)
    print("mixed:", hostcolor("foobar", stats))
    print(u"")


# Generated at 2022-06-23 13:49:10.278812
# Unit test for function parsecolor
def test_parsecolor():
    colors = ("red", "green", "blue", "yellow", "magenta", "cyan", "white",
              "black", "color0", "color1", "color2", "color3", "color4",
              "color5", "color6", "color7", "color8", "color9", "color10",
              "color11", "color12", "color13", "color14", "color15",
              "rgb255255255", "rgb000255000", "rgb255255000", "rgb255000255")
    for c in colors:
        print(stringc(u"This text is ", c, True))
    for c in colors:
        print(stringc(u"This text is ", c, False))


# Generated at 2022-06-23 13:49:21.685502
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '34'
    assert parsecolor('dark gray') == '90'
    assert parsecolor('light blue') == '94'
    assert parsecolor('light gray') == '37'
    assert parsecolor('light green') == '92'
    assert parsecolor('light red') == '91'
    assert parsecolor('bright black') == '90'
    assert parsecolor('bright red') == '91'
    assert parsecolor('bright green') == '92'
    assert parsecolor('bright yellow') == '93'
    assert parsecolor('bright blue') == '94'
    assert parsecolor('bright magenta') == '95'
    assert parsecolor('bright cyan') == '96'
    assert parsecolor('bright white') == '97'
    assert par

# Generated at 2022-06-23 13:49:28.828636
# Unit test for function stringc
def test_stringc():
    """Test parsecolor and stringc functions"""
    colors = 'black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white', 'color1', 'color1', 'color2', 'color3', 'color4', 'color5', 'color6', 'color7', 'color8', 'color9', 'color10', 'color11', 'color12', 'color13', 'color14', 'color15'
    for color in colors:
        assert "\x1b[%sm" % parsecolor(color) in stringc('stringc', color)
        assert "\x1b[0m" in stringc('stringc', color)
    assert "color" in stringc('color', 'color1')
    assert "color" in stringc('color', 'rgb255')

# Generated at 2022-06-23 13:49:35.562433
# Unit test for function parsecolor
def test_parsecolor():
    c = ANSIBLE_COLOR

    ANSIBLE_COLOR = True
    if parsecolor("red") != u'31':
        raise AssertionError("RED color code")
    if parsecolor("green") != u'32':
        raise AssertionError("GREEN color code")
    if parsecolor("blue") != u'34':
        raise AssertionError("BLUE color code")
    if parsecolor("gray") != u'30':
        raise AssertionError("GRAY color code")
    if parsecolor("magenta") != C.COLOR_CODES['magenta']:
        raise AssertionError("MAGENTA color code")
    if parsecolor("color12") != u'38;5;12':
        raise AssertionError("COLOR12 color code")

# Generated at 2022-06-23 13:49:45.802699
# Unit test for function stringc
def test_stringc():
    assert(stringc('foo', 'green') == '\x1b[32mfoo\x1b[0m')
    assert(stringc('foo', 'badcolor') == '\x1b[32mfoo\x1b[0m')
    assert(stringc('foo', 'bold') == '\x1b[1mfoo\x1b[0m')
    assert(stringc('foo', 'underline') == '\x1b[4mfoo\x1b[0m')
    assert(stringc('foo', 'on_green') == '\x1b[42mfoo\x1b[0m')

# Generated at 2022-06-23 13:49:57.460738
# Unit test for function stringc
def test_stringc():
    # Test parsecolor() first:
    assert parsecolor("blue") == "38;5;4"
    assert parsecolor("0") == "38;5;0"
    assert parsecolor("1") == "38;5;1"
    assert parsecolor("16") == "38;5;16"
    assert parsecolor("color16") == "38;5;16"
    assert parsecolor("gray0") == "38;5;232"
    assert parsecolor("gray8") == "38;5;232"
    assert parsecolor("gray15") == "38;5;255"
    assert parsecolor("rgb0") == "38;5;16"
    assert parsecolor("rgb111") == "38;5;37"

# Generated at 2022-06-23 13:50:00.963407
# Unit test for function colorize
def test_colorize():
    """Unit test for function :func:`colorize`
    """
    assert u"[0;31mfoo=100\033[0m" == colorize(u"foo", 100, C.COLOR_ERROR)


# Generated at 2022-06-23 13:50:05.672334
# Unit test for function colorize
def test_colorize():
    # This is just a simple unit test. There's no reason to require
    # nose or anything fancy for this.
    for color in C.COLOR_CODES:
        print(color)
        print(colorize(u"x", u"1", color))
        print(colorize(u"x", u"0", color))
    print(colorize(u"x", u"0", None))

# Generated at 2022-06-23 13:50:16.983100
# Unit test for function hostcolor
def test_hostcolor():
    stats_changed = {'changed': 1, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    stats_failures = {'changed': 0, 'failures': 1, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    stats_ok = {'changed': 0, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    stats_unreachable = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 1}

# Generated at 2022-06-23 13:50:25.476694
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '1'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color9') == '38;5;9'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color11') == '38;5;11'
    assert parsecolor('color12') == '38;5;12'
    assert parsecolor('color13') == '38;5;13'
    assert parsecolor('color14') == '38;5;14'
    assert parsecolor('color15') == '38;5;15'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color17') == '38;5;17'

# Generated at 2022-06-23 13:50:37.141477
# Unit test for function colorize
def test_colorize():
    """Colorize - Unit Test"""
    # pylint: disable=unused-variable

    # Test the colorize function with a good run
    (good, red, blue, yellow, white, cyan) = range(6)
    msg = u'This task'
    (i, j, k) = (1, 12, 22)
    assert colorize(msg, i, good) == u'This task=1   '
    assert colorize(msg, j, good) == u'This task=12  '
    assert colorize(msg, k, good) == u'This task=22  '

    # Test the colorize function with a bad run
    assert colorize(msg, i, red  ) == stringc(u'This task=1   ', C.COLOR_ERROR)
    assert colorize(msg, i, blue ) == string

# Generated at 2022-06-23 13:50:48.638244
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('red') == u'38;5;196'
    assert parsecolor('green') == u'38;5;46'
    assert parsecolor('yellow') == u'38;5;226'
    assert parsecolor('blue') == u'38;5;21'
    assert parsecolor('magenta') == u'38;5;201'
    assert parsecolor('cyan') == u'38;5;51'
    assert parsecolor('white') == u'38;5;231'
    assert parsecolor('rgb255255255') == u'38;5;231'
    assert parsecolor('rgb25526500') == u'38;5;208'

# Generated at 2022-06-23 13:51:00.308491
# Unit test for function hostcolor
def test_hostcolor():
    # errors/failures are always red
    stats = dict(
        ok=0, failed=1, unreachable=0, changed=0, ignored=0, skipped=0
    )
    hostname = 'test'
    assert 'test' in hostcolor(hostname,stats,True)
    assert '<41>' in hostcolor(hostname,stats,True)

    # changed is yellow
    stats = dict(
        ok=0, failed=0, unreachable=0, changed=1, ignored=0, skipped=0
    )
    hostname = 'test'
    assert 'test' in hostcolor(hostname,stats,True)
    assert '<43>' in hostcolor(hostname,stats,True)

    # ok is green

# Generated at 2022-06-23 13:51:09.984036
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return
    from ansible import utils
    class dummy:
        def __init__(self):
            self.good = {
                "failures": 0,
                "unreachable": 0,
                "changed": 0,
            }
            self.bad = {
                "failures": 1,
                "unreachable": 0,
                "changed": 0,
            }
            self.ugly = {
                "failures": 0,
                "unreachable": 1,
                "changed": 0,
            }
            self.changed = {
                "failures": 0,
                "unreachable": 0,
                "changed": 1,
            }
    h = dummy()
    assert hostcolor(u"good.example.com", h.good, False) == u

# Generated at 2022-06-23 13:51:18.702071
# Unit test for function colorize
def test_colorize():
    # The tests for colorize use filecmp to compare the output
    # against previously saved output to verify correctness.
    # The saved output was generated with ansible-playbook
    # with the --diff option set to true.
    #
    # The tests require the following directory structure
    # relative to the test file:
    #
    #   .../test/utils
    #                  /output
    #                      /colorize.txt
    #                  /unittests
    #                      /test_colorize.py
    #
    # Run the test in the unittests directory.
    import filecmp
    import os

    cwd = os.path.dirname(__file__)
    out_file = os.path.join(cwd, "..", "..", "test", "utils", "output", "colorize.txt")
    f

# Generated at 2022-06-23 13:51:30.692480
# Unit test for function parsecolor
def test_parsecolor():
    for color, code in C.COLOR_CODES.items():
        if code != parsecolor(color):
            raise AssertionError(
                "parsecolor(%r) returned %r but expected %r"
                % (color, parsecolor(color), code))

    for color_code in range(16, 231):
        if u"38;5;%d" % color_code != parsecolor("color%d" % color_code):
            raise AssertionError(
                "parsecolor(%r) returned %r but expected %r"
                % ("color%d" % color_code, parsecolor("color%d" % color_code),
                   u"38;5;%d" % color_code))


# Generated at 2022-06-23 13:51:40.922570
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', {}) == u"%-26s" % u"foo"
    assert hostcolor('foo', {'changed': 1}) == u"%-37s" % stringc('foo', C.COLOR_CHANGED)
    assert hostcolor('foo', {'failures': 1}) == u"%-37s" % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', {'unreachable': 1}) == u"%-37s" % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', {'failures': 1, 'unreachable': 1}) == u"%-37s" % stringc('foo', C.COLOR_ERROR)



# Generated at 2022-06-23 13:51:49.109910
# Unit test for function stringc
def test_stringc():
    class _WritelnDecorator(object):
        """Used to decorate file-like objects with a handy 'writeln' method"""

        def __init__(self, stream):
            self.stream = stream

        def __getattr__(self, attr):
            if attr in ('stream', '__getstate__'):
                raise AttributeError(attr)
            return getattr(self.stream, attr)

        def writeln(self, arg=None):
            if arg:
                self.write(arg)
            self.write('\n')  # text-mode streams translate to \r\n if needed

    # The class that provides the capability to capture stdout/stderr
    # for unit testing
    class _Capturing(list):
        """A context manager and data structure that captures stdout/stderr"""



# Generated at 2022-06-23 13:51:59.988658
# Unit test for function hostcolor
def test_hostcolor():
    print("Testing hostcolor")
    print(hostcolor("green", {'failures': 0, 'unreachable': 0, 'changed': 0}))
    print(hostcolor("ok", {'failures': 0, 'unreachable': 0, 'changed': 0}))
    print(hostcolor("changed", {'failures': 0, 'unreachable': 0, 'changed': 1}))
    print(hostcolor("failed", {'failures': 1, 'unreachable': 0, 'changed': 1}))
    print(hostcolor("unreachable", {'failures': 0, 'unreachable': 1, 'changed': 1}))


# --- end "pretty"



# Generated at 2022-06-23 13:52:11.479608
# Unit test for function stringc
def test_stringc():
    from ansible import colors
    colors.stringc("Normal", "CYAN")
    colors.stringc("Bold", "BOLD")
    colors.stringc("Underline", "UNDERLINE")
    colors.stringc("Blink", "BLINK")


# --- end "pretty"
#
# --- begin "termstyle"
#
# termstyle - A mini library for colorizing output for terminals.
#
# Author: Peter Odding <peter@peterodding.com>
# Last Change: November 6, 2014
# URL: https://github.com/xolox/python-termstyle

# Semi-standard module versioning.

__version__ = '1.0.1'


# Generated at 2022-06-23 13:52:24.381908
# Unit test for function parsecolor
def test_parsecolor():

    def color_test(color, expected_code):
        color_code = parsecolor(color)
        assert color_code == expected_code

    color_test('red', '31')
    color_test('bright red', '91')
    color_test('dark gray', '90')
    color_test('color8', '38;5;8')
    color_test('rgb255', '38;5;231')
    color_test('rgb123', '38;5;50')
    color_test('rgb112', '38;5;37')
    color_test('rgb211', '38;5;116')
    color_test('rgb000', '38;5;16')
    color_test('rgb222', '38;5;18')

# Generated at 2022-06-23 13:52:30.354094
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('33') == u'33'
    assert parsecolor('rgb255255255') == u'38;5;231'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray23') == u'38;5;255'



# Generated at 2022-06-23 13:52:42.308443
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('white') == u'38;5;15'
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('magenta') == u'38;5;13'
    assert parsecolor('color256') == u'38;5;256'
    assert parsecolor('rgb111') == u'38;5;72'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('rgb123') == u'38;5;109'
    assert parsecolor('rgb333') == u'38;5;59'
    assert parsecolor('rgb321') == u'38;5;93'
    assert parsecolor('rgb211') == u'38;5;51'
    assert parsecolor

# Generated at 2022-06-23 13:52:50.246303
# Unit test for function hostcolor
def test_hostcolor():
    h = 'foo'
    s = dict(skipped=0)
    # Default: no color in non-tty
    assert hostcolor(h, s, False) == u"%-26s" % h
    # Default: no color if ANSIBLE_NOCOLOR is set
    h = 'foo'
    assert hostcolor(h, s, False) == u"%-26s" % h
    # Color off
    assert hostcolor(h, s, True) == u"%-26s" % stringc(h, C.COLOR_OK)
    # Color on: changed
    s = dict(changed=1)
    assert hostcolor(h, s, True) == u"%-26s" % stringc(h, C.COLOR_CHANGED)
    # Color on: failed
    s = dict(failures=1)

# Generated at 2022-06-23 13:53:01.075857
# Unit test for function hostcolor
def test_hostcolor():
    final_result = hostcolor('localhost', {'changed': 2, 'failures': 3, 'ok': 4, 'skipped': 0, 'unreachable': 0}, True)
    assert final_result == u"localhost                       "
    final_result = hostcolor('localhost', {'changed': 0, 'failures': 3, 'ok': 4, 'skipped': 0, 'unreachable': 0}, True)
    assert final_result == u"localhost                       "
    final_result = hostcolor('localhost', {'changed': 0, 'failures': 0, 'ok': 4, 'skipped': 0, 'unreachable': 0}, True)
    assert final_result == u"localhost                       "

# Generated at 2022-06-23 13:53:09.535405
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == stringc('foo=0   ', 'blue')
    assert colorize('foo', 1, 'blue') == stringc('foo=1   ', 'blue')
    assert colorize('foo', 11, 'blue') == stringc('foo=11  ', 'blue')
    assert colorize('foo', 111, 'blue') == stringc('foo=111 ', 'blue')
    assert colorize('foo', 1111, 'blue') == stringc('foo=1111', 'blue')
    # colorize returns a str for Python2, unicode for Python3.
    # We want to ensure that the color strings are unicode,
    # but the non-color strings are str.

# Generated at 2022-06-23 13:53:22.578329
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test for parsecolor()."""

    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('default') == '39'

    assert parsecolor('darkgray') == '90'
    assert parsecolor('darkred') == '91'
    assert parsecolor('darkgreen') == '92'
    assert parsecolor('darkyellow') == '93'

# Generated at 2022-06-23 13:53:26.661975
# Unit test for function colorize
def test_colorize():
    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        print(color, colorize('VAR', 111, color), colorize('VAR', 0, color))


# Generated at 2022-06-23 13:53:32.645214
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == '31'
    assert parsecolor("rgb255255255") == '38;5;231'
    assert parsecolor("rgb0255255") == '38;5;118'
    assert parsecolor("rgb000255") == '38;5;21'
    assert parsecolor("rgb255255000") == '38;5;226'
    assert parsecolor("rgb255000255") == '38;5;201'
    assert parsecolor("rgb000255000") == '38;5;22'
    assert parsecolor("rgb2550000255") == '38;5;199'
    assert parsecolor("rgb2550000000") == '38;5;196'