

# Generated at 2022-06-23 13:43:43.718956
# Unit test for function hostcolor
def test_hostcolor():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    stats_fail = dict(ok=1, failures=1, skipped=1, unreachable=0, changed=1, dark=dict(failures=1))
    stats_ok   = dict(ok=1, failures=0, skipped=0, unreachable=0, changed=1, dark=dict(ok=1))
    stats_dark = dict(ok=1, failures=0, skipped=0, unreachable=0, changed=1, dark=dict(ok=1, changed=1))
    assert hostcolor("localhost", stats_fail, True) == stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", stats_ok, True) == stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", stats_dark, True)

# Generated at 2022-06-23 13:43:52.530467
# Unit test for function stringc
def test_stringc():
    # Test foreground colors
    assert stringc("text", "black") == "\033[38;5;16mtext\033[0m", "failed to color 'text' black"
    assert stringc("text", "red") == "\033[38;5;1mtext\033[0m", "failed to color 'text' red"
    assert stringc("text", "green") == "\033[38;5;2mtext\033[0m", "failed to color 'text' green"
    assert stringc("text", "yellow") == "\033[38;5;3mtext\033[0m", "failed to color 'text' yellow"
    assert stringc("text", "blue") == "\033[38;5;4mtext\033[0m", "failed to color 'text' blue"

# Generated at 2022-06-23 13:43:55.012928
# Unit test for function stringc
def test_stringc():
    print(u"\n".join(stringc(t, color)
                     for color in C.COLOR_CODES
                     for t in ('this is a test',)))
    print(stringc(u'\u21b5', u'RED_BG'))


# --- end of "pretty" library functions



# Generated at 2022-06-23 13:43:56.821948
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('foo', 'green')



# Generated at 2022-06-23 13:44:03.950901
# Unit test for function colorize
def test_colorize():
    class DummyOpts():
        verbosity = 0

    options = DummyOpts()
    for clr in ('red', 'green', 'blue', 'white', 'yellow', 'magenta', 'cyan'):
        print(colorize(clr, 0, clr), colorize(clr, 1, clr), colorize(clr, 2, clr))

# end "pretty"

# Generated at 2022-06-23 13:44:12.461279
# Unit test for function stringc
def test_stringc():
    s = stringc("This is a test", "green")
    if not (re.match(r"\033\[[0-9;]*mThis is a test\033\[0m", s)):
        print("bad, no match")
    s = stringc("This is a test", "blue", True)
    if not (re.match(r"\001\033\[[0-9;]*m\002This is a test\001\033\[0m\002", s)):
        print("bad, no match")
    s = stringc("This is a test", "rgb255255255", True)

# Generated at 2022-06-23 13:44:17.681962
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc.

    String in color.
    """
    import doctest
    doctest.testmod(verbose=True)

if __name__ == '__main__':
    # Unit test for function stringc
    test_stringc()

# --- end "pretty"

# Generated at 2022-06-23 13:44:28.278195
# Unit test for function stringc
def test_stringc():
    def test(color, code):
        if code != parsecolor(color):
            print('%s -> %s != %s' % (color, parsecolor(color), code))
    # test colors
    colors = ("black", "red", "green", "yellow", "blue", "magenta", "cyan", "white")
    for i, color in enumerate(colors):
        test(color, u"30+%d" % i)
    # test rgb colors
    for r in range(6):
        for g in range(6):
            for b in range(6):
                code = 16 + 36 * r + 6 * g + b
                test("rgb%d%d%d" % (r, g, b), u"38;5;%d" % code)
    # test grayscale colors
   

# Generated at 2022-06-23 13:44:38.302639
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'1'
    assert parsecolor('green') == u'2'
    assert parsecolor('blue') == u'4'
    assert parsecolor('bold') == u'1'
    assert parsecolor('grey') == u'30'
    assert parsecolor('black') == u'30'
    assert parsecolor('white') == u'37'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('default') == u'39'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('gray2') == u'38;5;234'

# Generated at 2022-06-23 13:44:48.912477
# Unit test for function parsecolor
def test_parsecolor():
    # Test standard colors
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'

    # Test color attributes
    assert parsecolor('bold') == u'1'
    assert parsecolor('underscore') == u'4'
    assert parsecolor('blink') == u'5'
    assert parsecolor('reverse') == u'7'

    # Test integer colors
    assert parsecolor('color0')

# Generated at 2022-06-23 13:45:00.736924
# Unit test for function parsecolor
def test_parsecolor():
    ok = u'\033[38;5;%dmOK\033[0m'
    eq = u'\033[38;5;%dmFAIL\033[0m'

# Generated at 2022-06-23 13:45:08.870928
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {"failures": 1, "changed": 0, "unreachable": 0})
    assert hostcolor("localhost", {"failures": 0, "changed": 0, "unreachable": 1})
    assert hostcolor("localhost", {"failures": 0, "changed": 1, "unreachable": 0})
    assert hostcolor("localhost", {"failures": 0, "changed": 0, "unreachable": 0})



# Generated at 2022-06-23 13:45:16.884928
# Unit test for function stringc
def test_stringc():
    assert stringc('some string', 'red') == u'\033[31msome string\033[0m'
    assert stringc('some string', 'rgb255') == u'\033[38;5;201msome string\033[0m'
    assert stringc('some string', 'rgb220') == u'\033[38;5;188msome string\033[0m'
    assert stringc('some string', 'gray7') == u'\033[38;5;239msome string\033[0m'
    assert stringc('some string', 'gray8') == u'\033[38;5;240msome string\033[0m'


# vim: expandtab shiftwidth=4 softtabstop=4

# Generated at 2022-06-23 13:45:19.285728
# Unit test for function colorize
def test_colorize():
    class FakeAnsibleModule():
        def __init__(self):
            self.C = C

    am = FakeAnsibleModule()
    colorize(am, 'test', 1, 'red')


# Generated at 2022-06-23 13:45:22.520076
# Unit test for function colorize
def test_colorize():
   assert colorize(u"rc", 1, u"red") == u"rc=1  "
   assert colorize(u"rc", 1, None) == u"rc=1  "
   assert colorize(u"rc", 0, u"red") == u"rc=0  "
   assert colorize(u"rc", 0, None) == u"rc=0  "



# Generated at 2022-06-23 13:45:29.833482
# Unit test for function stringc
def test_stringc():
    print(stringc('whatever', 'green'))
    print(stringc('whatever', 'red'))
    print(stringc('whatever', 'blue'))
    print(stringc('whatever', 'color3'))
    print(stringc('whatever', 'rgb235'))
    print(stringc('whatever', 'rgb323'))
    print(stringc('whatever', 'rgb332'))
    print(stringc('whatever', 'rgb333'))
    print(stringc('whatever', 'rgb123'))
    print(stringc('whatever', 'rgb213'))
    print(stringc('whatever', 'rgb231'))
    print(stringc('whatever', 'rgb312'))
    print(stringc('whatever', 'rgb321'))

# Generated at 2022-06-23 13:45:39.134024
# Unit test for function colorize
def test_colorize():
    passed = colorize('passed', '1234', None)
    failed = colorize('failed', 0, 'red')
    skip = colorize('skipped', 0, 'cyan')
    print("colorize: " + passed + ", " + failed + ", " + skip)
    assert passed == 'passed=1234'
    assert failed == u"failed=0  \033[31m\033[1m"
    assert skip == u"skipped=0 \033[0;36m\033[1m"


# --- end "pretty"

if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-23 13:45:45.275561
# Unit test for function colorize
def test_colorize():
    try:
        import curses
    except ImportError:
        # curses library was not found
        return False

    # Basic test
    assert colorize("myvar", 3, None) == "myvar=3   "

    # Basic functionality test
    assert colorize("myvar", 3, C.COLOR_CHANGED) == stringc("myvar=3   ", C.COLOR_CHANGED)

    # Check that = is not colorized
    assert colorize("myvar", 3, C.COLOR_CHANGED).split('=')[1] == "3   "

    # Check that padding with space is not colorized
    assert colorize("myvar", 3, C.COLOR_CHANGED).split('3')[1] == "   "

    global ANSIBLE_COLOR
    # Test without colors

# Generated at 2022-06-23 13:45:55.731074
# Unit test for function stringc
def test_stringc():  # pragma: no cover
    # expected results
    assert stringc('hello world', 'blue') == '\033[34mhello world\033[0m'
    assert stringc('hello world', 'rgb0255255') == '\033[38;5;6mhello world\033[0m'
    assert stringc('hello world', 'gray2') == '\033[38;5;234mhello world\033[0m'
    # invalid color
    assert stringc('hello world', 'invalid') == '\033[39mhello world\033[0m'
    # no color
    assert stringc('hello world', 'none') == 'hello world'

# Generated at 2022-06-23 13:46:02.755553
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    stringc("test", "red")
    stringc("test", "blue")
    stringc("test", "green")
    stringc("test", "yellow")
    stringc("test", "magenta")
    stringc("test", "cyan")
    stringc("test", "white")
    stringc("test", "gray")
    stringc("test", "grey")
    stringc("test", "color15")
    stringc("test", "color16")
    stringc("test", "color17")
    stringc("test", "color18")
    stringc("test", "color19")
    stringc("test", "color1")
    stringc("test", "rgb255255255")
    stringc("test", "rgb000255255")
    stringc

# Generated at 2022-06-23 13:46:10.417510
# Unit test for function colorize
def test_colorize():
    ''' return the difference between expected and actual '''
    # we use 'error' as the color if there is a difference
    expected = stringc(u'foo=bar', C.COLOR_ERROR)
    actual = colorize(u'foo', u'bar', C.COLOR_ERROR)
    if expected != actual:
        return u"colorize() failed: expected %s, actual %s" % (expected, actual)
    return None
# --- end of "pretty"



# Generated at 2022-06-23 13:46:21.183575
# Unit test for function stringc
def test_stringc():
    # Here we use a special ANSI escape code sequence
    # to request the terminal to report its mask of
    # supported extensions.
    #
    # This test is skipped if the sequence isn't recognized.
    if ANSIBLE_COLOR:
        term_extensions = u"\033[?9999h\033[6n"
        sys.stdout.write(term_extensions)
        sys.stdout.flush()
        (dummy, mask) = sys.stdin.read(2)
        if int(mask) == 255:
            print(u'skipping ansi test')
            return

# Generated at 2022-06-23 13:46:22.958806
# Unit test for function stringc
def test_stringc():
    if u"\033" in stringc(u"foo", u"blue"):
        return True
    return False


# --- end "pretty"

# Generated at 2022-06-23 13:46:29.204516
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", "1", "blue") == u"\n".join([u"\033[34mfoo=1   \033[0m"])
    # the following test is platform dependent and may fail under
    # non-Linux operating systems
    if sys.platform.startswith("linux"):
        assert colorize("foo", "1", "1") == u"\n".join([u"\033[38;5;1mfoo=1   \033[0m"])
    assert colorize("foo", "0", "red") == u"foo=0   "



# Generated at 2022-06-23 13:46:40.000254
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"www.example.com", {'changed': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0}) == u'www.example.com               '
    assert hostcolor(u"www.example.com", {'changed': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0}, color=False) == u'www.example.com               '
    assert hostcolor(u"www.example.com", {'changed': 0, 'failures': 0, 'skipped': 0, 'unreachable': 1}) == u'www.example.com               '
    assert hostcolor(u"www.example.com", {'changed': 1, 'failures': 0, 'skipped': 0, 'unreachable': 0}) == u'www.example.com               '

# Generated at 2022-06-23 13:46:47.838941
# Unit test for function hostcolor

# Generated at 2022-06-23 13:46:57.715917
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('darkgray') == '1;30'
    assert parsecolor('lightgray') == '0;37'
    assert parsecolor('darkred') == '1;31'
    assert parsecolor('lightred') == '1;31'
    assert parsecolor('darkgreen') == '1;32'

# Generated at 2022-06-23 13:47:04.986889
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'blue') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '


# Generated at 2022-06-23 13:47:11.905726
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=0), True) == 'host1                           '
    assert hostcolor('host1', dict(failures=1, unreachable=0, changed=0), True) == u'\033[31mhost1\033[0m                        '
    assert hostcolor('host1', dict(failures=0, unreachable=1, changed=0), True) == u'\033[31mhost1\033[0m                        '
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=1), True) == u'\033[34mhost1\033[0m                        '

# --- end "pretty"



# Generated at 2022-06-23 13:47:16.499704
# Unit test for function colorize
def test_colorize():
    # There should be a color and a reset code in the first and last
    # positions of the string.
    assert re.match('^\033.+\033.+$', colorize('foo', 1, 'blue'))



# Generated at 2022-06-23 13:47:26.064516
# Unit test for function hostcolor
def test_hostcolor():
    stats_success = dict(
        ok=1,
        changed=1,
        unreachable=0,
        failed=0,
    )
    stats_fail = dict(
        ok=1,
        changed=1,
        unreachable=1,
        failed=1,
    )
    stats_unreachable = dict(
        ok=0,
        changed=0,
        unreachable=1,
        failed=0,
    )
    stats_changed = dict(
        ok=1,
        changed=1,
        unreachable=0,
        failed=0,
    )
    assert re.search(r'\x1b\[0m', hostcolor('localhost', stats_success))

# Generated at 2022-06-23 13:47:29.618593
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=0, failures=1, ok=27, skipped=0, unreachable=0)
    print(u"%s" % hostcolor(u"localhost", stats, True))



# Generated at 2022-06-23 13:47:35.389982
# Unit test for function stringc
def test_stringc():
    assert stringc('hello', 'blue') == '\033[34mhello\033[0m'
    assert stringc('goodbye', 'cyan') == '\033[36mgoodbye\033[0m'
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('bar', 'magenta') == '\033[35mbar\033[0m'
    assert stringc('baz', 'red') == '\033[31mbaz\033[0m'
    assert stringc('qux', 'white') == '\033[37mqux\033[0m'
    assert stringc('zap', 'yellow') == '\033[33mzap\033[0m'



# Generated at 2022-06-23 13:47:47.298225
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.color import hostcolor
    import sys

    def _colorize(val):
        return stringc(val, C.COLOR_OK) + '\n'
    sys.stdout.write('Testing hostcolor:\n')
    sys.stdout.write('    ok              ' + _colorize(hostcolor('ok', {'failures': 0, 'unreachable': 0, 'changed': 0}, True)))
    sys.stdout.write('    changed         ' + _colorize(hostcolor('changed', {'failures': 0, 'unreachable': 0, 'changed': 1}, True)))
    sys.stdout.write('    failures        ' + _colorize(hostcolor('failures', {'failures': 1, 'unreachable': 0, 'changed': 0}, True)))

# Generated at 2022-06-23 13:47:59.548749
# Unit test for function colorize
def test_colorize():
    """ Unit test for function colorize """

    def _colorize(lead, num, color, result):
        """ helper function for unit test """
        ansible_color = ANSIBLE_COLOR
        try:
            global ANSIBLE_COLOR
            ANSIBLE_COLOR = True
            assert colorize(lead, num, color) == result
            ANSIBLE_COLOR = False
            assert colorize(lead, num, color) == result
            ANSIBLE_COLOR = True
            assert colorize(lead, num, None) == result
            ANSIBLE_COLOR = False
            assert colorize(lead, num, None) == result
        finally:
            ANSIBLE_COLOR = ansible_color

    # let's test
    _colorize('ok', 0, 'green', 'ok=0   ')

# Generated at 2022-06-23 13:48:10.701563
# Unit test for function colorize
def test_colorize():
    import sys

    from ansible.compat.six import StringIO
    from ansible.playbook.play_context import PlayContext

    old_stdout = sys.stdout
    old_color = C.ANSIBLE_FORCE_COLOR
    C.ANSIBLE_FORCE_COLOR = True
    sys.stdout = StringIO()
    stringio = sys.stdout
    print(stringc('test', 'blue'))
    print(stringc('test', 'red'))
    print(colorize('test', 0, None))
    print(colorize('test', 1, 'red'))
    print(colorize('test', 0, 'blue'))
    print(colorize('test', 1, 'blue'))


# Generated at 2022-06-23 13:48:21.623463
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"foobar", dict(failures=1), color=True) == u"\033[31mfoobar\033[0m               "
    assert hostcolor(u"foobar", dict(failures=1), color=False) == u"foobar                   "
    assert hostcolor(u"foobar", dict(unreachable=1), color=True) == u"\033[31mfoobar\033[0m               "
    assert hostcolor(u"foobar", dict(unreachable=1), color=False) == u"foobar                   "
    assert hostcolor(u"foobar", dict(failures=1, unreachable=1), color=True) == u"\033[31mfoobar\033[0m               "

# Generated at 2022-06-23 13:48:32.871025
# Unit test for function colorize
def test_colorize():
    # These colors should get printed correctly
    colors = ('red', 'blue', 'black', 'white', 'yellow', 'cyan', 'magenta',
              'green', 'normal', 'bold', 'purple', 'darkgray', 'lightblue',
              'lightcyan', 'lightgreen', 'lightpurple', 'lightred', 'lightwhite',
              'lightyellow')

    for color in colors:
        # This is necessary because we can't print ANSI color codes
        # into a file
        if not ANSIBLE_COLOR:
            print("(%s)" % color)
        else:
            print("%-20s" % colorize("lead", "num", color), end=' ')
            print("%-20s" % stringc("text", color), end=' ')

# Generated at 2022-06-23 13:48:42.386346
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(
        ok=1,
        skipped=0,
        failed=0,
        unreachable=0,
        changed=0)
    assert hostcolor("test.example.com", stats) == u"test.example.com      "
    stats = dict(
        ok=0,
        skipped=0,
        failed=1,
        unreachable=0,
        changed=0)
    assert hostcolor("test.example.com", stats) == u"\033[31;01mtest.example.com\033[0m"
    stats = dict(
        ok=0,
        skipped=0,
        failed=0,
        unreachable=1,
        changed=0)

# Generated at 2022-06-23 13:48:47.959475
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'blue', 'cyan', 'yellow', 'magenta'):
        print('This is %s' % (stringc('colorful', c)))

# if __name__ == '__main__':
#    test_colorize()

# Generated at 2022-06-23 13:48:57.567495
# Unit test for function colorize

# Generated at 2022-06-23 13:49:06.643523
# Unit test for function stringc
def test_stringc():
    """ Run module unit tests """
    assert stringc("plain", "blue") == u"\033[34mplain\033[0m"
    assert stringc("underline", "underline") == u"\033[4munderline\033[0m"
    assert stringc("plain", "black", True) == u"\001\033[38;5;16m\002plain\001\033[0m\002"
    assert stringc("blue", "color4", True) == u"\001\033[38;5;52m\002blue\001\033[0m\002"
    assert stringc("red", "rgb222", True) == u"\001\033[38;5;124m\002red\001\033[0m\002"

# Generated at 2022-06-23 13:49:14.620862
# Unit test for function colorize
def test_colorize():

    tests = [
        {'lead': 'test1', 'num': '5', 'color': 'blue', 'output': u"test1=5   "},
        {'lead': 'test1', 'num': '5', 'color': None, 'output': u"test1=5   "},
    ]

    stats = {'changed': 0, 'dark': 0, 'failures': 0, 'ok': 0, 'processed': 0, 'skipped': 0, 'unreachable': 0}

    for test in tests:
        assert colorize(test['lead'], test['num'], test['color']) == test['output']


if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-23 13:49:24.157110
# Unit test for function stringc
def test_stringc():
    ''' stringc returns the correct values '''
    assert stringc('test', 'green') == u'\033[32mtest\033[0m'
    assert stringc('test', 'color3') == u'\033[38;5;3mtest\033[0m'
    assert stringc('test', 'rgb123') == u'\033[38;5;45mtest\033[0m'
    assert stringc('test', 'gray2') == u'\033[38;5;238mtest\033[0m'
    assert stringc('test', 'bad_color') == False  # Should fail with an error

# Generated at 2022-06-23 13:49:32.996776
# Unit test for function stringc
def test_stringc():
    failures = 0

# Generated at 2022-06-23 13:49:38.912872
# Unit test for function colorize
def test_colorize():
    # Does nothing if ANSIBLE_COLOR is False
    # Lead does not have a trailing space
    # num is left justified
    assert colorize('skipping', 0, 'blue') == 'skipping=0   '
    # num is left justified (even if color is None)
    assert colorize('skipping', 1, None) == 'skipping=1   '



# Generated at 2022-06-23 13:49:48.986844
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('bold red') == '1;31'
    assert parsecolor('on_green') == '42'
    assert parsecolor('bold on_white') == '1;47'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('rgb0') == '38;5;16'
    assert parsecolor('rgb7') == '38;5;55'
    assert parsecolor('rgb8') == '38;5;56'
    assert parsecolor('rgb9') == '38;5;57'

# Generated at 2022-06-23 13:49:59.771316
# Unit test for function parsecolor
def test_parsecolor():
    print("\nTesting function parsecolor. It should print the color name followed by colons, e.g. 'green:'.")
    print("You should see a green word, followed by a red word, followed by a blue word, followed by a gray word.")
    print("If you do not see colored text, your terminal does not support ANSI color.")
    print("If you do see colored text, the color name in the body text should match the background color.")
    print("")

    for i in C.COLOR_CODES:
        sgr = parsecolor(i)
        if ANSIBLE_COLOR:
            print("\033[%sm%-12s:\033[0m" % (sgr, i.upper()), end='')
        else:
            print("%-12s:" % i.upper(), end='')


# Generated at 2022-06-23 13:50:10.290028
# Unit test for function parsecolor
def test_parsecolor():
    assert_equals(parsecolor('black'), u'38;5;0')
    assert_equals(parsecolor('red'), u'38;5;1')
    assert_equals(parsecolor('brightyellow'), u'38;5;11')
    assert_equals(parsecolor('color8'), u'38;5;8')
    assert_equals(parsecolor('color12'), u'38;5;12')
    assert_equals(parsecolor('middlegray'), u'38;5;243')
    assert_equals(parsecolor('rgb012'), u'38;5;6')
    assert_equals(parsecolor('rgb333'), u'38;5;123')

# Generated at 2022-06-23 13:50:16.546776
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"%-37s"
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"%-37s"
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"%-37s"
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"%-26s"
# --- end "pretty"

# Generated at 2022-06-23 13:50:25.150466
# Unit test for function hostcolor
def test_hostcolor():
    """AnsibleModule.hostcolor() Test Case"""
    # Set initial stats
    stats = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}

    assert hostcolor('foobarbaz', stats, color=False) == u'%-26s' % 'foobarbaz'
    assert hostcolor('foobarbaz', stats, color=True) == u'%-37s' % stringc('foobarbaz', C.COLOR_OK)

    stats['changed'] = 1
    assert hostcolor('foobarbaz', stats) == u'%-37s' % stringc('foobarbaz', C.COLOR_CHANGED)

    stats['changed'] = 0
    stats['unreachable'] = 1
    assert hostcolor('foobarbaz', stats)

# Generated at 2022-06-23 13:50:36.838470
# Unit test for function stringc
def test_stringc():
    import sys

    # Make sure that curses is installed
    try:
        import curses
    except ImportError:
        print('WARN: No curses module found; function testing disabled.')
        return

    if sys.version_info[0] > 2:
        return
    else:
        str_ = str

    # We are going to be using curses, so we will want to restore the terminal
    # to a sane state when we exit, regardless of how we exit.

# Generated at 2022-06-23 13:50:41.089252
# Unit test for function colorize
def test_colorize():
    assert (colorize(u'ok', u'20', C.COLOR_OK) ==
            stringc(u'ok=20  ', C.COLOR_OK))
    assert (colorize(u'changed', u'10', C.COLOR_CHANGED) ==
            stringc(u'changed=10', C.COLOR_CHANGED))


# ---- end of "pretty"



# Generated at 2022-06-23 13:50:47.230738
# Unit test for function colorize
def test_colorize():
    tests = ((u"test", 0, 'green'),
             (u"test", 1, 'yellow'),
             (u"test", 2, 'red'))
    for k, v, c in tests:
        assert colorize(k, v, c) == u"test=%s" % v



# Generated at 2022-06-23 13:50:56.295941
# Unit test for function stringc
def test_stringc():
    a = u'hello'
    print(stringc(a, 'blue'))
    print(stringc(a, 'black'))
    print(stringc(a, 'green'))
    print(stringc(a, 'red'))
    print(stringc(a, 'cyan'))
    print(stringc(a, 'white'))
    print(stringc(a, 'magenta'))
    print(stringc(a, 'yellow'))

    print(stringc(a, 'color0'))
    print(stringc(a, 'color1'))
    print(stringc(a, 'color2'))
    print(stringc(a, 'color3'))
    print(stringc(a, 'color4'))
    print(stringc(a, 'color5'))
   

# Generated at 2022-06-23 13:51:07.558553
# Unit test for function parsecolor

# Generated at 2022-06-23 13:51:15.027750
# Unit test for function hostcolor
def test_hostcolor():
    host = "testhost.example.com"
    # Test with all zero values.
    stats = {
        'unreachable': 0,
        'failures': 0,
        'changed': 0,
        'ok': 1,
        'skipped': 0,
        'processed': 1
    }
    assert hostcolor(host, stats, True) == u"%-37s" % u"\n".join([u"\033[0;32m%s\033[0m" % t for t in host.split(u'\n')])

#
# -- end pretty --

# Generated at 2022-06-23 13:51:21.461078
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {}
    assert hostcolor(host, stats) == u"%-26s" % host
    stats = dict(
        failures=1,
        unreachable=0,
        changed=0
    )
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = dict(
        failures=0,
        unreachable=1,
        changed=0
    )
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = dict(
        failures=0,
        unreachable=0,
        changed=1
    )

# Generated at 2022-06-23 13:51:32.578908
# Unit test for function stringc
def test_stringc():
    assert stringc("ABC", 10) == u"\033[38;5;10mABC\033[0m"
    assert stringc("ABC", "10") == u"\033[38;5;10mABC\033[0m"
    assert stringc("ABC", "color10") == u"\033[38;5;10mABC\033[0m"
    assert stringc("ABC", "rgb123") == u"\033[38;5;57mABC\033[0m"
    assert stringc("ABC", "rgb211") == u"\033[38;5;70mABC\033[0m"
    assert stringc("ABC", "rgb321") == u"\033[38;5;123mABC\033[0m"

# Generated at 2022-06-23 13:51:43.940210
# Unit test for function hostcolor
def test_hostcolor():
    if hostcolor('host1', dict(failures=1, unreachable=2, changed=3)) != u'host1':
        print(hostcolor('host1', dict(failures=1, unreachable=2, changed=3)))
        raise AssertionError()
    if hostcolor('host2', dict(failures=0, unreachable=0, changed=3)) != u'host2':
        print(hostcolor('host2', dict(failures=0, unreachable=0, changed=3)))
        raise AssertionError()
    if hostcolor('host3', dict(failures=0, unreachable=0, changed=0)) != u'host3':
        print(hostcolor('host3', dict(failures=0, unreachable=0, changed=0)))
        raise AssertionError()



# Generated at 2022-06-23 13:51:49.133062
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("myhost", dict(failures=1, unreachable=0, changed=0)) == u"myhost               "
    assert hostcolor("myhost", dict(failures=0, unreachable=1, changed=0)) == u"myhost               "
    assert hostcolor("myhost", dict(failures=0, unreachable=0, changed=1)) == u"myhost               "
    assert hostcolor("myhost", dict(failures=0, unreachable=0, changed=0)) == u"myhost               "

# Generated at 2022-06-23 13:52:01.481821
# Unit test for function stringc
def test_stringc():
    colors = [u"black", u"red", u"green", u"yellow", u"blue", u"magenta", u"cyan", u"white"]
    colormap = {
        u"black": 0,
        u"red": 1,
        u"green": 2,
        u"yellow": 3,
        u"blue": 4,
        u"magenta": 5,
        u"cyan": 6,
        u"white": 7
    }


# Generated at 2022-06-23 13:52:12.441321
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1)) == u"localhost                     "
    assert hostcolor('localhost', dict(failures=0)) == u"localhost                     "
    assert hostcolor('localhost', dict(failures=1, unreachable=0)) == u"localhost                     "
    assert hostcolor('localhost', dict(failures=1, unreachable=1)) == u"localhost                     "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                     "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost                     "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u"localhost               "

# Generated at 2022-06-23 13:52:21.486700
# Unit test for function stringc
def test_stringc():
    assert stringc("Hello", "red") == u"\033[31mHello\033[0m"
    assert stringc("Hello", "blue") == u"\033[34mHello\033[0m"
    assert stringc("Hello", "color236") == u"\033[38;5;236mHello\033[0m"
    # Test that color is stripped before wraping
    assert stringc("Hello", "red", True) == u"\001\033[31m\002Hello\001\033[0m\002"

# Generated at 2022-06-23 13:52:32.795043
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'green') == '\033[32mtest\033[0m'
    assert stringc('test', 'bad') == '\033[mtest\033[0m'
    assert stringc('test', 'color4') == '\033[38;5;4mtest\033[0m'
    assert stringc('test', 'color8') == '\033[38;5;8mtest\033[0m'
    assert stringc('test', 'rgb123') == '\033[38;5;111mtest\033[0m'
    assert stringc('test', 'rgb112') == '\033[38;5;98mtest\033[0m'

# Generated at 2022-06-23 13:52:40.724801
# Unit test for function hostcolor
def test_hostcolor():

    success_stats = {
        'skipped': 0,
        'ok': 20,
        'changed': 0,
        'failures': 0,
        'unreachable': 0
    }

    fail_stats = {
        'skipped': 0,
        'ok': 0,
        'changed': 0,
        'failures': 1,
        'unreachable': 0
    }

    unreachable_stats = {
        'skipped': 0,
        'ok': 0,
        'changed': 0,
        'failures': 0,
        'unreachable': 1
    }

    # Test 0 failures and 0 unreachable
    assert hostcolor(u"test1", success_stats, True) == u"test1                             "

# Generated at 2022-06-23 13:52:49.290720
# Unit test for function stringc
def test_stringc():
    assert ANSIBLE_COLOR == True
    print(stringc("text", "blue"))
    print(stringc("text", "red"))
    print(stringc("text", "green"))
    print(stringc("text", "yellow"))
    print(stringc("text", "white"))
    print(stringc("text", "black"))
    print(stringc("text", "cyan"))
    print(stringc("text", "magenta"))
    print(stringc("text", "gray"))
    print(stringc("text", "blue", wrap_nonvisible_chars=True))
    print(stringc("text", "red", wrap_nonvisible_chars=True))
    print(stringc("text", "green", wrap_nonvisible_chars=True))

# Generated at 2022-06-23 13:52:53.911366
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == stringc("test", "0;34") == "\033[0;34mtest\033[0m"
    assert stringc("test", "red") == stringc("test", "1;31") == "\033[1;31mtest\033[0m"



# Generated at 2022-06-23 13:53:03.502840
# Unit test for function hostcolor
def test_hostcolor():
    test_stats = dict(
        failures=1,
        unreachable=0,
        changed=0)
    test_host = 'localhost'
    assert hostcolor(test_host, test_stats) == stringc(test_host, C.COLOR_ERROR)
    test_stats = dict(
        failures=0,
        unreachable=0,
        changed=1)
    assert hostcolor(test_host, test_stats) == stringc(test_host, C.COLOR_CHANGED)
    test_stats = dict(
        failures=0,
        unreachable=0,
        changed=0)
    assert hostcolor(test_host, test_stats) == stringc(test_host, C.COLOR_OK)



# Generated at 2022-06-23 13:53:09.546361
# Unit test for function hostcolor
def test_hostcolor():
    hosts = {}
    stats = {}
    for color in [C.COLOR_OK, C.COLOR_CHANGED, C.COLOR_ERROR]:
        for key in ['failed', 'unreachable']:
            hosts[color] = dict(stats)
            stats[key] = 1
            assert hostcolor(color, hosts[color]) != hostcolor(color, stats)
            stats[key] = 0
            assert hostcolor(color, hosts[color]) == hostcolor(color, stats)

# --- end "pretty"


# Generated at 2022-06-23 13:53:22.578202
# Unit test for function stringc
def test_stringc():
    """
    >>> from ansible.utils.color import stringc
    >>> print stringc("hello", "red")
    \x1b[31mhello\x1b[0m
    >>> print stringc("hello", "black", wrap_nonvisible_chars=True)
    \001\x1b[30m\002hello\001\x1b[0m\002
    """
    pass

# end "pretty"
# ---

# --- begin ANSI color wrapper
#
#   Some of this code was borrowed/modified from the 'fast' implementation
#   of termcolor (https://pypi.python.org/pypi/termcolor)
#
#   This is a slightly modified copy of a function found in the 'fast'
#   implementation of termcolor (https://pypi.python.org/pyp

# Generated at 2022-06-23 13:53:31.815237
# Unit test for function stringc
def test_stringc():
    from ansible.parsing.vault import VaultLib
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    sys.stderr = StringIO()
    tests = (
        (u"no color", u"abc", u"abc", False),
        (u"blue", u"abc", u"\033[34mabc\033[0m", True),
        (u"red", u"abc", u"\033[31mabc\033[0m", True),
        (u"bold", u"abc", u"\033[1mabc\033[0m", True),
    )
    for name, text, expected, color in tests:
        actual = stringc(text, name, wrap_nonvisible_chars=True)

# Generated at 2022-06-23 13:53:42.458426
# Unit test for function hostcolor
def test_hostcolor():
    colors = {
        u'127.0.0.1': [0, 0, 0, 0],
        u'127.0.0.2': [0, 1, 0, 0],
        u'127.0.0.3': [1, 0, 0, 0],
        u'127.0.0.4': [0, 0, 1, 0],
        u'127.0.0.5': [1, 1, 0, 0],
        u'127.0.0.6': [0, 0, 0, 1],
        u'127.0.0.7': [1, 0, 1, 0],
        u'127.0.0.8': [0, 1, 1, 0],
        u'127.0.0.9': [1, 1, 1, 0],
    }
