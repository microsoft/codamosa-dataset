

# Generated at 2022-06-23 13:43:43.718493
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor("foo", dict(failures=0, unreachable=0, changed=0), color=True) == u"\x1b[32m%-26s\x1b[0m" % "foo"
        assert hostcolor("foo", dict(failures=0, unreachable=1, changed=0), color=True) == u"\x1b[31m%-26s\x1b[0m" % "foo"
        assert hostcolor("foo", dict(failures=0, unreachable=0, changed=1), color=True) == u"\x1b[33m%-26s\x1b[0m" % "foo"

# Generated at 2022-06-23 13:43:50.689721
# Unit test for function colorize
def test_colorize():
    result = colorize('Z', 0, 'green')
    assert result == 'Z=0   ', "colorize() failed to return 'Z=0   ' but got %s" % result


# --- end "pretty"
#

if __name__ == "__main__":
    print(stringc("Hello, World!", 'blue', wrap_nonvisible_chars=True))
    print(stringc("Hello, World!", 'green', wrap_nonvisible_chars=True))
    print(stringc("Hello, World!", 'red', wrap_nonvisible_chars=True))
    print(stringc("Hello, World!", 'black', wrap_nonvisible_chars=True))
    test_colorize()

# Generated at 2022-06-23 13:44:00.273284
# Unit test for function stringc
def test_stringc():
    '''Tests to make sure stringc function works correctly'''
    # Test good color string
    assert type(stringc("TEST", "blue")) == unicode
    # Test good color value
    assert type(stringc("TEST", 4)) == unicode
    # Test good rgb value
    assert type(stringc("TEST", "rgb255")) == unicode
    # Test good grayscale value
    assert type(stringc("TEST", "gray10")) == unicode
    # Test bad color string
    assert type(stringc("TEST", "not-a-color")) == unicode
    # Test if we get unicode back when not using color
    assert type(stringc("TEST", "blue", False)) == unicode


# --- end "pretty"



# Generated at 2022-06-23 13:44:09.309635
# Unit test for function parsecolor
def test_parsecolor():
    """Test function parsecolor"""
    assert parsecolor('red') == u'38;5;9'
    assert parsecolor('bright red') == u'38;5;9'
    assert parsecolor('dark red') == u'38;5;1'

    assert parsecolor('light red') == u'38;5;9'
    assert parsecolor('light red') == u'38;5;9'
    assert parsecolor('light red') == u'38;5;9'

    assert parsecolor('rgb255000') == u'38;5;9'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb010101') == u'38;5;232'


# Generated at 2022-06-23 13:44:21.089453
# Unit test for function parsecolor
def test_parsecolor():
    # Basic colors
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('default') == u'39'
    # Bright colors
    assert parsecolor('bright') == u'39'
    assert parsecolor('brightblack') == u'30'
    assert parsecolor('brightred') == u'31'
    assert parsecolor('brightgreen') == u'32'

# Generated at 2022-06-23 13:44:30.313036
# Unit test for function parsecolor
def test_parsecolor():
    '''
    This function unit tests function parsecolor, which parses the rgb and
    color[0-9] options for terminal colors.
    '''

# Generated at 2022-06-23 13:44:36.417702
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 42
    color = 'blue'
    s = colorize(lead, num, color)
    m = re.match('\033\[38;5;21mfoo=42\033\[0m', s)
    assert m is not None
    # Now test with color off
    s = colorize(lead, num, color)
    m = re.match('foo=42', s)
    assert m is not None


# Generated at 2022-06-23 13:44:39.471295
# Unit test for function colorize
def test_colorize():
    """ basic test function for colorize """
    assert colorize("test", "1") == "test=1   "
    assert colorize("test", "0") == "test=0   "


# Generated at 2022-06-23 13:44:42.050824
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 4, 'blue') == u'foo=4   \033[38;5;12m'
    assert colorize('foo', 4, None) == u'foo=4   '



# Generated at 2022-06-23 13:44:51.261562
# Unit test for function stringc
def test_stringc():
    """Test function stringc with argument 'text', 'color' """

    assert stringc(u"test_stringc", u"red") == u"\033[31mtest_stringc\033[0m", \
        "Expected: %s, Got: %s" % (u"\033[31mtest_stringc\033[0m",
                                   stringc(u"test_stringc", u"red"))
    assert stringc(u"test_stringc", u"brightred") == u"\033[31mtest_stringc\033[0m", \
        "Expected: %s, Got: %s" % (u"\033[31mtest_stringc\033[0m",
                                   stringc(u"test_stringc", u"brightred"))

# Generated at 2022-06-23 13:45:02.853643
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat.tests import unittest
    from ansible.utils.color import hostcolor

    class TestUtilsColor(unittest.TestCase):

        def setUp(self):
            class Bunch:
                def __init__(self, **kwds):
                    self.__dict__.update(kwds)
            global C
            C.COLOR_OK = 'green'
            C.COLOR_CHANGED = 'yellow'
            C.COLOR_ERROR = 'red'
            self.fake_global_C = Bunch(COLOR_OK=C.COLOR_OK,
                                       COLOR_CHANGED=C.COLOR_CHANGED,
                                       COLOR_ERROR=C.COLOR_ERROR)
            self.stats = {}
            pass

        def tearDown(self):
            pass


# Generated at 2022-06-23 13:45:14.280719
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'green') == stringc('foo=0   ', 'green')
    assert colorize('foo', 1, 'green') == stringc('foo=1   ', 'green')
    assert colorize('foo', 10, 'green') == stringc('foo=10  ', 'green')
    assert colorize('foo', 100, 'green') == stringc('foo=100 ', 'green')
    assert colorize('foo', 1000, 'green') == stringc('foo=1000', 'green')
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', -1000, 'green') == stringc('foo=-1000', 'green')
    assert colorize('foo', -1000, None) == 'foo=-1000'
# --- end of "pretty"

# Set always_

# Generated at 2022-06-23 13:45:23.076939
# Unit test for function colorize
def test_colorize():
    """Unit test main method"""
    # Successful tests will not print anything.
    failed_tests = 0

    # Failures should be red
    failed_tests += 1
    failure_value = 1
    failure_color = C.COLOR_ERROR
    failure_lead = "failed"
    result = colorize(failure_lead, failure_value, failure_color)
    if ANSIBLE_COLOR:
        assert result == stringc(u"failed=1  ", failure_color)
    else:
        assert result == u"failed=1  "
    failed_tests -= 1
    if failed_tests == 0:
        print('colorize: All tests passed')

if __name__ == "__main__":
    test_colorize()

# Generated at 2022-06-23 13:45:34.147091
# Unit test for function stringc
def test_stringc():
    from ansible.utils.color import stringc

    # Test colors
    assert stringc(u'A text test in black', u'black') == u'\x1b[30mA text test in black\x1b[0m'
    assert stringc(u'A text test in red', u'red') == u'\x1b[31mA text test in red\x1b[0m'
    assert stringc(u'A text test in green', u'green') == u'\x1b[32mA text test in green\x1b[0m'
    assert stringc(u'A text test in yellow', u'yellow') == u'\x1b[33mA text test in yellow\x1b[0m'

# Generated at 2022-06-23 13:45:43.212366
# Unit test for function stringc

# Generated at 2022-06-23 13:45:55.594924
# Unit test for function stringc

# Generated at 2022-06-23 13:46:02.519526
# Unit test for function stringc
def test_stringc():
    assert (stringc("foo", "blue") == u'\033[34mfoo\033[0m')
    assert (stringc("foo", "red") == u'\033[31mfoo\033[0m')
    assert (stringc("foo", "on_blue") == u'\033[44mfoo\033[0m')
    assert (stringc("foo", "blue", wrap_nonvisible_chars=True) == u'\001\033[34m\002foo\001\033[0m\002')
    assert (stringc("foo", "on_blue", wrap_nonvisible_chars=True) == u'\001\033[44m\002foo\001\033[0m\002')

# --- End "pretty"



# Generated at 2022-06-23 13:46:14.217291
# Unit test for function colorize
def test_colorize():
    """ returns ok if all colors are printed as expected """


# Generated at 2022-06-23 13:46:23.984907
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == "\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[38;5;4mfoo\033[0m"
    assert stringc("foo", "red") == "\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "black") == "\033[38;5;0mfoo\033[0m"
    assert stringc("foo", "white") == "\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "yellow") == "\033[38;5;3mfoo\033[0m"
    assert stringc("foo", "default") == "\033[39mfoo\033[0m"

# Generated at 2022-06-23 13:46:31.621000
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '34'
    assert parsecolor('green') == '32'
    assert parsecolor('red') == '31'
    assert parsecolor('yellow') == '33'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('on_blue') == '44'
    assert parsecolor('on_green') == '42'
    assert parsecolor('on_red') == '41'
    assert parsecolor('on_yellow') == '43'
    assert parsecolor('on_magenta') == '45'
    assert parsecolor('on_cyan') == '46'
   

# Generated at 2022-06-23 13:46:41.127679
# Unit test for function stringc
def test_stringc():

    def test(args, colorvalues):
        testcolors = (('bold', '1'),
                      ('underscore', '4'),
                      ('blink', '5'),
                      ('reverse', '7'),
                      ('conceal', '8'))
        for color, value in testcolors:
            sys.stdout.write(stringc(args, color) + ' ')
        sys.stdout.flush()
        sys.stdout.write(stringc(args, 'blue', True) + ' ')
        sys.stdout.flush()
        for color in colorvalues:
            sys.stdout.write(stringc(args, 'color' + str(color)) + ' ')
        sys.stdout.flush()

# Generated at 2022-06-23 13:46:44.888107
# Unit test for function stringc
def test_stringc():
    a = stringc('color', 'blue')
    print(a)
    assert a == '\x1b[0;34mcolor\x1b[0m'



# Generated at 2022-06-23 13:46:56.181888
# Unit test for function hostcolor
def test_hostcolor():
    host = u"localhost"
    color = True
    stats = {u"failures": 0, u"unreachable": 0, u"changed": 0}
    assert hostcolor(host, stats, color) == u"localhost"

    stats = {u"failures": 1, u"unreachable": 0, u"changed": 0}
    assert hostcolor(host, stats, color) == u"\x1b[31m%-37s\x1b[0m" % host  # noqa
    assert hostcolor(host, stats, color) != u"%-37s" % host

    stats = {u"failures": 0, u"unreachable": 1, u"changed": 0}

# Generated at 2022-06-23 13:47:03.300747
# Unit test for function stringc
def test_stringc():
    """Tests for function stringc.

    run this script with the command: python pretty.py
    """
    print("Color: %s" % stringc("This is red.", "red"))
    print("Color: %s" % stringc("This is red.", "rgb255"))
    print("Color: %s" % stringc("This is red.", "rgb511"))
    print("Color: %s" % stringc("This is red.", "rgb522"))
    print("Color: %s" % stringc("This is cyan.", "rgb055"))
    print("Color: %s" % stringc("This is blue.", "rgb005"))
    print("Color: %s" % stringc("This is magenta.", "color13"))
    print("Color: %s" % stringc("This is yellow.", "color11"))


# Generated at 2022-06-23 13:47:08.304082
# Unit test for function colorize
def test_colorize():
    lead = u"foo"
    num = 42
    color = C.COLOR_CHANGED
    s = u"%s=%-4s" % (lead, str(num))
    if num != 0 and ANSIBLE_COLOR and color is not None:
        s = stringc(s, color)
    assert(s == colorize(lead, num, color))


# Generated at 2022-06-23 13:47:21.333542
# Unit test for function colorize
def test_colorize():
    from ansible.utils.unicode import to_unicode

    # The only case that is exercised differently by this test
    # is when ANSIBLE_COLOR=False. The other cases are in
    # test/units/test_playbook.py
    assert to_unicode(colorize('foo', 10, None)) == u'foo=10  '

    # Set ANSIBLE_COLOR to False
    setattr(C, "ANSIBLE_NOCOLOR", True)
    assert to_unicode(colorize('foo', 10, C.COLOR_ERROR)) == u'foo=10  '
    assert to_unicode(colorize('foo', 0, C.COLOR_ERROR)) == u'foo=0   '

    # Clean
    delattr(C, "ANSIBLE_NOCOLOR")

# Generated at 2022-06-23 13:47:26.574898
# Unit test for function hostcolor
def test_hostcolor():
    output = hostcolor(u'localhost', {u'changed': 0, u'failures': 0, u'ok': 1, u'skipped': 0, u'unreachable': 0}, color=True)
    assert output == u'localhost                 \033[0;32m\033[0m'
    output = hostcolor(u'localhost', {u'changed': 0, u'failures': 0, u'ok': 1, u'skipped': 0, u'unreachable': 0}, color=False)
    assert output == u'localhost                  '



# Generated at 2022-06-23 13:47:36.414923
# Unit test for function parsecolor
def test_parsecolor():
    # Test with color
    if ANSIBLE_COLOR:
        assert parsecolor('normal') == '39'
        assert parsecolor('black') == '30'
        assert parsecolor('red') == '31'
        assert parsecolor('green') == '32'
        assert parsecolor('yellow') == '33'
        assert parsecolor('blue') == '34'
        assert parsecolor('magenta') == '35'
        assert parsecolor('cyan') == '36'
        assert parsecolor('white') == '37'
        assert parsecolor('bright black') == '30'
        assert parsecolor('bright red') == '31'
        assert parsecolor('bright green') == '32'
        assert parsecolor('bright yellow') == '33'
        assert parsecolor('bright blue')

# Generated at 2022-06-23 13:47:47.526302
# Unit test for function hostcolor
def test_hostcolor():
    retval = hostcolor('darkred.example.org', dict(failures=1, unreachable=2, changed=3), color=True)
    assert retval == u'\033[31m%-37s\033[0m'
    retval = hostcolor('darkred.example.org', dict(failures=0, unreachable=2, changed=3), color=True)
    assert retval == u'\033[33m%-37s\033[0m'
    retval = hostcolor('darkred.example.org', dict(failures=0, unreachable=0, changed=3), color=True)
    assert retval == u'\033[35m%-37s\033[0m'

# Generated at 2022-06-23 13:47:59.785005
# Unit test for function stringc
def test_stringc():
    assert stringc('[-]', 'error') == u'\033[%sm[-]\033[0m' % C.COLOR_CODES['error']
    assert stringc('[+]', 'error', wrap_nonvisible_chars=True) == u'\001\033[%sm\002[+]\001\033[0m\002' % C.COLOR_CODES['error']
    assert stringc('[+]', 'error', wrap_nonvisible_chars=False) == u'\033[%sm[+]\033[0m' % C.COLOR_CODES['error']

# Generated at 2022-06-23 13:48:10.842108
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    try:
        curses.setupterm()
    except:
        # No curses, no testing
        return
    if curses.tigetnum('colors') < 0:
        # No colors available, skip the test
        return
    test = 'stringc'
    assert stringc(test, 'black') == '\x1b[30mstringc\x1b[0m'
    assert stringc(test, 'red') == '\x1b[31mstringc\x1b[0m'
    assert stringc(test, 'green') == '\x1b[32mstringc\x1b[0m'
    assert stringc(test, 'yellow') == '\x1b[33mstringc\x1b[0m'

# Generated at 2022-06-23 13:48:21.655186
# Unit test for function stringc
def test_stringc():
    assert stringc(u'abc', u'blue') == u'\033[34mabc\033[0m'
    assert stringc(u'abc', 'shadow_red') == u'\033[38;5;52mabc\033[0m'
    assert stringc(u'abc', u'rgb010') == u'\033[38;5;36mabc\033[0m'
    assert stringc(u'abc', u'gray50') == u'\033[38;5;236mabc\033[0m'
    assert stringc(u'abc', u'rgb110') == u'\033[38;5;131mabc\033[0m'
    assert stringc(u'abc', u'unknown color') == u'\033[31mabc\033[0m'

# Generated at 2022-06-23 13:48:31.999849
# Unit test for function stringc
def test_stringc():
    # colorful output should be on
    assert ANSIBLE_COLOR

    # some text

    assert stringc(u'Hello World !', u'green') == u"\033[32mHello World !\033[0m"

    # the same text, but with background color

    assert stringc(u'Hello World !', u'on_green') == u"\033[42mHello World !\033[0m"

    # color can also be specified as a numeric value

    assert stringc(u'Hello World !', u'color1') == u"\033[38;5;1mHello World !\033[0m"

    # numeric value can be in a two digit format

    assert stringc(u'Hello World !', u'color11') == u"\033[38;5;11mHello World !\033[0m"

# Generated at 2022-06-23 13:48:38.713723
# Unit test for function colorize
def test_colorize():

    assert colorize("foo", 3, None) == u"foo=3   "
    assert colorize("foo", -3, None) == u"foo=-3  "
    assert colorize("foo", 3, 'blue') == u"\x1b[0m\x1b[34mfoo=3   \x1b[0m"
    assert colorize("foo", -3, 'lightgreen') == u"\x1b[0m\x1b[92mfoo=-3  \x1b[0m"

# Generated at 2022-06-23 13:48:49.900574
# Unit test for function stringc
def test_stringc():
    print(u"\n=== Testing function stringc ===")
    print(stringc(u"RED", u"RED"))
    print(stringc(u"RED", u"red"))
    print(stringc(u"RED", u"color1"))
    print(stringc(u"RED", u"rgb255000255"))
    print(stringc(u"RED", u"rgb255100100"))
    print(stringc(u"RED", u"rgb255000100"))
    print(stringc(u"RED", u"rgb100255100"))
    print(stringc(u"RED", u"rgb100100255"))
    print(stringc(u"RED", u"rgb100100100"))
    print(stringc(u"RED", u"rgb100100100"))

# Generated at 2022-06-23 13:48:59.158260
# Unit test for function hostcolor
def test_hostcolor():
    # Test with dictionary of host statistics
    host_stats = {
        'changed': 0,
        'failures': 0,
        'ok': 0,
        'skipped': 0,
        'unreachable': 0
    }
    # Test different stats combinations
    assert hostcolor('localhost', host_stats) == 'localhost                 '
    host_stats['ok'] = 1
    assert hostcolor('localhost', host_stats) == '\x1b[0;32mlocalhost\x1b[0m         '
    host_stats['changed'] = 1
    assert hostcolor('localhost', host_stats) == '\x1b[0;33mlocalhost\x1b[0m         '
    host_stats['unreachable'] = 1

# Generated at 2022-06-23 13:49:08.886911
# Unit test for function stringc
def test_stringc():
    # Use cases for function stringc
    # *** list or set the color for a string.
    #
    # When a color is specified the output will be a string that the print
    # statement can use to print that string in the desired color
    assert stringc("print this string in color", color="blue") == r"\033[38;5;27mprint this string in color\033[0m"

    # *** print a string in color
    #
    # When a color is specified with the `wrap_nonvisible_chars` parameter,
    # the output will be a string that can be used by a readline enabled
    # edit line prompt to print the string in the desired color

# Generated at 2022-06-23 13:49:18.121711
# Unit test for function colorize
def test_colorize():
    def Test_colorize_val(lead, num, color, expect):
        result = colorize(lead, num, color)
        if result == expect:
            sys.stdout.write(".")
            return True
        else:
            sys.stdout.write("x")
            # print "For %s=%s in color %s Expected %s, Got %s" % (
            # lead, str(num), str(color), expect, result)
            return False

    def Test_colorize_tuple(t):
        return Test_colorize_val(t[0], t[1], t[2], t[3])


# Generated at 2022-06-23 13:49:27.238159
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == C.COLOR_CODES['red']
    assert parsecolor('32') == u'37'
    assert parsecolor('blue') == C.COLOR_CODES['blue']
    assert parsecolor('33') == u'38;5;11'
    assert parsecolor('rgb255') == u'38;5;231'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('rgb021') == u'38;5;94'
    assert parsecolor('rgb102') == u'38;5;117'
    assert parsecolor('rgb210') == u'38;5;149'
    assert parsecolor('gray0') == u'38;5;232'

# Generated at 2022-06-23 13:49:34.588537
# Unit test for function colorize
def test_colorize():
    for color in range(0, 7):
        for fg in range(0, 7):
            start = "\x1b[%d;3%dm" % (color, fg)
            end = "\x1b[0m"
            out = colorize(start, '1', fg)
            if fg == 0:
                assert(out == "%s1%s" % (start, end))
                sys.exit(0)
            if color == 0:
                assert(out == "%s=1  %s" % (start[:-4], end))
                sys.exit(0)
            if out == "%s=1  %s" % (start[:-4], end):
                sys.exit(0)

# Generated at 2022-06-23 13:49:45.172466
# Unit test for function colorize
def test_colorize():
    print(colorize('ok', 0, C.COLOR_OK))
    print(colorize('changed', 0, C.COLOR_CHANGED))
    print(colorize('unreachable', 0, C.COLOR_UNREACHABLE))
    print(colorize('fatal', 0, C.COLOR_ERROR))
    print(colorize('skipped', 0, C.COLOR_SKIP))
    print(colorize('ok', 1, C.COLOR_OK))
    print(colorize('changed', 2, C.COLOR_CHANGED))
    print(colorize('unreachable', 3, C.COLOR_UNREACHABLE))
    print(colorize('fatal', 4, C.COLOR_ERROR))
    print(colorize('skipped', 5, C.COLOR_SKIP))



# Generated at 2022-06-23 13:49:56.839255
# Unit test for function parsecolor

# Generated at 2022-06-23 13:50:01.480671
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('red') == '31')
    assert(parsecolor('rgb255000255') == '38;5;123')
    assert(parsecolor('grey1') == '38;5;232')
    assert(parsecolor('grey12') == '38;5;244')

# Generated at 2022-06-23 13:50:13.025556
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'

    assert parsecolor('rgb255255255') == u'38;5;231'
    assert parsecolor('rgb000255255') == u'38;5;114'

    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color30') == u'38;5;30'
    assert par

# Generated at 2022-06-23 13:50:20.019225
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 1, 'black') == 'foo=1   '
    assert colorize('foo', 10, 'black') == 'foo=10  '
    assert colorize('foo', 100, 'black') == 'foo=100 '
    assert colorize('foo', 1000, 'black') == 'foo=1000'


# Generated at 2022-06-23 13:50:25.526505
# Unit test for function colorize
def test_colorize():
    res = colorize('ok', 0, None)
    assert res == u'ok=0   '

    res = colorize('changed', 10, 'blue')
    assert res == u'changed=10  '

    res = colorize('failed', 20, 'red')
    assert res == u'failed=20  '



# Generated at 2022-06-23 13:50:31.795624
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("ok", dict(ok=1)) == "ok                          "
    assert hostcolor("changed", dict(changed=1)) == "changed                    "
    assert hostcolor("failed", dict(failed=1)) == "failed                     "
    assert hostcolor("fail_and_ok", dict(failed=1, ok=1)) == "fail_and_ok               "



# Generated at 2022-06-23 13:50:35.467260
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost') == u'%-37s' % u"localhost"
    assert hostcolor('localhost', dict(failures=1)) == u'%-37s' % stringc(u'localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(changed=1)) == u'%-37s' % stringc(u'localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(changed=0)) == u'%-37s' % stringc(u'localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(changed=0), False) == u'%-26s' % u'localhost'

# --- end "pretty"

# Generated at 2022-06-23 13:50:43.768605
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, 'red') == "foo=0   "
    assert colorize("bar", 0, None) == "bar=0   "
    assert colorize("car", 0, 'blue') == "car=0   "
    assert colorize("far", 1, 'red') == "far=1   "
    assert colorize("jar", 2, 'red') == "jar=2   "
    assert colorize("tar", 0, 'yellow') == "tar=0   "
    assert colorize("mar", 1, 'yellow') == "mar=1   "


# Generated at 2022-06-23 13:50:49.920791
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('green') == u'32'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb315') == u'38;5;13'
    assert parsecolor('gray7') == u'38;5;239'
    assert parsecolor('BLACK') == u'30'


# Generated at 2022-06-23 13:51:01.955999
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color0-1') == C.COLOR_CODES['color0-1']

    assert parsecolor('color252') == u'38;5;252'
    assert parsecolor('color253') == u'38;5;253'

    assert parsecolor('color15') == u'38;5;15'
    assert parsecolor('color16') == u'38;5;16'
    assert parsecolor('color255') == u'38;5;255'
    assert parsecolor('color256') == C.COLOR_CODES['color256']

    assert parsecolor('color0-1') == C.COLOR_COD

# Generated at 2022-06-23 13:51:09.497223
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foohost", dict(failures=0, unreachable=0, skipped=0, changed=0)) == u"foohost                    "
    assert hostcolor("foohost", dict(failures=1, unreachable=0, skipped=0, changed=0)) == u"foohost                    "
    assert hostcolor("foohost", dict(failures=0, unreachable=1, skipped=0, changed=0)) == u"foohost                    "
    assert hostcolor("foohost", dict(failures=0, unreachable=0, skipped=0, changed=1)) == u"foohost                    "



# Generated at 2022-06-23 13:51:13.535355
# Unit test for function hostcolor
def test_hostcolor():
    print(u"\nTesting function hostcolor")
    host = u"foobar"
    stats = {}
    print(hostcolor(host, stats, color=False))
    print(hostcolor(host, stats, color=True))
    stats['changed'] = 1
    stats['failures'] = 0
    print(hostcolor(host, stats, color=True))
    stats['changed'] = 0
    stats['failures'] = 1
    print(hostcolor(host, stats, color=True))



# Generated at 2022-06-23 13:51:16.306724
# Unit test for function colorize
def test_colorize():
    s = colorize(u'foo', 1, u'blue')
    assert s == u"foo=1   ", "colorize returned %s" % s

# end "pretty"

# Generated at 2022-06-23 13:51:28.103565
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}) == 'localhost                      '
    assert hostcolor('localhost', {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == 'localhost                      '
    assert hostcolor('localhost', {'changed': 0, 'failures': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}) == 'localhost                      '
    assert hostcolor('localhost', {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 1}) == 'localhost                      '



# Generated at 2022-06-23 13:51:38.981789
# Unit test for function parsecolor
def test_parsecolor():
    # Check color digit
    assert parsecolor("color1") == "38;5;1"
    # Check color RGB
    assert parsecolor("rgb555") == "38;5;61"
    # Check color gray
    assert parsecolor("gray0") == "38;5;16"
    # Check color name - black
    assert parsecolor("black") == "30"
    # Check color name - red
    assert parsecolor("red") == "31"
    # Check color name - green
    assert parsecolor("green") == "32"
    # Check color name - yellow
    assert parsecolor("yellow") == "33"
    # Check color name - blue
    assert parsecolor("blue") == "34"
    # Check color name - magenta

# Generated at 2022-06-23 13:51:48.575912
# Unit test for function hostcolor
def test_hostcolor():
    from collections import namedtuple
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.executor import playbook_executor
    from ansible.plugins.callback import CallbackBase
    from ansible.inventory.host import Host

# Generated at 2022-06-23 13:51:56.146077
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, C.COLOR_ERROR) == u"foo=0   "
    assert colorize(u"foo", 0, None) == u"foo=0   "
    assert colorize(u"foo", 1, C.COLOR_ERROR) != u"foo=1   "
    assert colorize(u"foo", 1, None) == u"foo=1   "


# Generated at 2022-06-23 13:52:05.879605
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 1, u"cyan") == u"\n".join([
        u"\033[96mfoo=1   \033[0m",
    ])
    assert colorize(u"foo", 0, u"cyan") == u"\n".join([
        u"foo=0   ",
    ])
    assert colorize(u"foo", -1, u"cyan") == u"\n".join([
        u"foo=-1  ",
    ])
    assert colorize(u"foo", 100, u"cyan") == u"\n".join([
        u"\033[96mfoo=100 \033[0m",
    ])
    assert colorize(u"foo", 0, None) == "foo=0   "

# Generated at 2022-06-23 13:52:09.438366
# Unit test for function colorize
def test_colorize():
    x = colorize('foo', 0, 'blue')
    y = colorize('foo', 0, None)
    assert(x == y)
    x = colorize('foo', 1, 'blue')
    assert(x != y)



# Generated at 2022-06-23 13:52:22.175029
# Unit test for function stringc
def test_stringc():
    for color in ('BLACK', 'RED', 'GREEN', 'YELLOW', 'BLUE', 'MAGENTA', 'CYAN', 'WHITE'):
        print(stringc('This is %s' % color, color))
    print(stringc('This is color 1', 'color1'))
    print(stringc('This is color 2', 'color2'))
    print(stringc('This is color 3', 'color3'))
    print(stringc('This is color 4', 'color4'))
    print(stringc('This is color 5', 'color5'))
    print(stringc('This is color 6', 'color6'))
    print(stringc('This is color 7', 'color7'))
    print(stringc('This is color 8', 'color8'))

# Generated at 2022-06-23 13:52:27.997331
# Unit test for function parsecolor

# Generated at 2022-06-23 13:52:35.529849
# Unit test for function hostcolor
def test_hostcolor():
    pc = u'\033[38;5;214m'
    if not ANSIBLE_COLOR:
        pc = u''

    if sys.version_info >= (3,):
        assert hostcolor(u'test1', {u'changed': 1, u'failures': 0, u'unreachable': 0}, color=True) == u'%stest1\033[0m' % pc
        assert hostcolor(u'test1', {u'changed': 0, u'failures': 1, u'unreachable': 0}, color=True) == u'%stest1\033[0m' % pc

# Generated at 2022-06-23 13:52:46.361168
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo.example.com', {'failures': 0, 'changed': 0, 'unreachable': 0}, True) == u'%-37s' % u'foo.example.com'
    assert hostcolor('foo.example.com', {'failures': 1, 'changed': 0, 'unreachable': 0}, True) == u'%-37s' % u'\x1b[31mfoo.example.com\x1b[0m'
    assert hostcolor('foo.example.com', {'failures': 0, 'changed': 1, 'unreachable': 0}, True) == u'%-37s' % u'\x1b[34mfoo.example.com\x1b[0m'

# Generated at 2022-06-23 13:52:57.202632
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('cyan') == u'38;5;6'
    assert parsecolor('light_gray') == u'38;5;7'
    assert parsecolor('dark_gray') == u'38;5;8'
    assert parsecolor('light_red') == u'38;5;9'

# Generated at 2022-06-23 13:53:05.115693
# Unit test for function stringc
def test_stringc():
    """This is a simple unit test for :py:func:`ansible.utils.ansible_color.stringc`"""

    print('\n---- Testing ansible.utils.ansible_color.stringc ----')

    assert(stringc('hello', 'blue') == '\033[34mhello\033[0m')
    assert(stringc('hello\nthere', 'blue', wrap_nonvisible_chars=True)
        == '\001\033[34m\002hello\001\033[0m\002\n\001\033[34m\002there\001\033[0m\002')
    assert(stringc('hello', 'blue', wrap_nonvisible_chars=True)
        == '\001\033[34m\002hello\001\033[0m\002')



# Generated at 2022-06-23 13:53:12.256829
# Unit test for function hostcolor
def test_hostcolor():
    test1 = dict(skipped=0, failures=0, unreachable=0, changed=0)
    test2 = dict(skipped=0, failures=1, unreachable=0, changed=0)
    test3 = dict(skipped=0, failures=0, unreachable=1, changed=0)
    test4 = dict(skipped=0, failures=0, unreachable=0, changed=1)
    test5 = dict(skipped=0, failures=1, unreachable=1, changed=0)
    test6 = dict(skipped=0, failures=0, unreachable=1, changed=1)
    test7 = dict(skipped=0, failures=1, unreachable=0, changed=1)

# Generated at 2022-06-23 13:53:21.910901
# Unit test for function parsecolor
def test_parsecolor():
    if not ANSIBLE_COLOR:
        return True
    color = parsecolor('white')
    if color != '38;5;15':
        return False
    color = parsecolor('06')
    if color != '38;5;6':
        return False
    color = parsecolor('rgb123')
    if color != '38;5;18':
        return False
    color = parsecolor('gray7')
    if color != '38;5;239':
        return False
    color = parsecolor('color12')
    if color != '38;5;12':
        return False
    return True


# Generated at 2022-06-23 13:53:31.338526
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils.common._collections_compat import namedtuple


# Generated at 2022-06-23 13:53:38.171439
# Unit test for function stringc
def test_stringc():
    from ansible.utils.unicode import to_bytes
    from ansible.utils.display import Display
    display = Display()
    for color in C.COLOR_CODES:
        display.display(to_bytes(stringc(u"This is a test", color), errors='surrogate_or_strict'), color=None)
    display.display(u"RGB 38;5;1", color=None)
    display.display(u"Gray 232", color=None)
    display.display(u"Gray 255", color=None)
