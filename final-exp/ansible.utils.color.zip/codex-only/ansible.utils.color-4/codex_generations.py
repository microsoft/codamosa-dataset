

# Generated at 2022-06-23 13:43:41.367397
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('test_host', {'failures': 1, 'changed': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}) == \
        u"test_host                         "
    assert hostcolor('test_host', {'failures': 0, 'changed': 1, 'ok': 2, 'skipped': 0, 'unreachable': 0}) == \
        u"test_host                         "
    assert hostcolor('test_host', {'failures': 0, 'changed': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}) == \
        u"test_host                         "

# Generated at 2022-06-23 13:43:49.947059
# Unit test for function parsecolor
def test_parsecolor():
    color_codes = {'black': '30', 'red': '31', 'green': '32', 'yellow': '33',
                   'blue': '34', 'magenta': '35', 'cyan': '36', 'white': '37',
                   'default': '39', 'blackbg': '40', 'redbg': '41',
                   'greenbg': '42', 'yellowbg': '43', 'bluebg': '44',
                   'magentabg': '45', 'cyanbg': '46', 'whitebg': '47',
                   '': '39'}

    # Testing named color
    delete_key = set()

# Generated at 2022-06-23 13:43:58.156533
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'bold') == u'1'
    assert parsecolor(u'faint') == u'2'
    assert parsecolor(u'italic') == u'3'
    assert parsecolor(u'underline') == u'4'
    assert parsecolor(u'blink') == u'5'
    assert parsecolor(u'overline') == u'6'
    assert parsecolor(u'black') == u'30'
    assert parsecolor(u'red') == u'31'
    assert parsecolor(u'green') == u'32'
    assert parsecolor(u'yellow') == u'33'
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'fuchsia') == u'35'


# Generated at 2022-06-23 13:44:07.806530
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"black") == u"30"
    assert parsecolor(u"red") == u'31'
    assert parsecolor(u"green") == u'32'
    assert parsecolor(u"yellow") == u'33'
    assert parsecolor(u"blue") == u'34'
    assert parsecolor(u"magenta") == u'35'
    assert parsecolor(u"cyan") == u'36'
    assert parsecolor(u"white") == u'37'
    assert parsecolor(u"unknown") == u'37'
    assert parsecolor(u"color234") == u'38;5;234'
    assert parsecolor(u"color12") == u'38;5;12'

# Generated at 2022-06-23 13:44:15.275351
# Unit test for function hostcolor
def test_hostcolor():
    hc = hostcolor('host', dict(failures=1))
    assert hc == u"%-37s" % u'\001\033[31m\002host\001\033[0m\002'
    hc = hostcolor('host', dict(failures=1), color=False)
    assert hc == u"%-26s" % u'host'

# --- end pretty



# Generated at 2022-06-23 13:44:26.612393
# Unit test for function hostcolor
def test_hostcolor():
    expected = u"%-37s" % stringc('ok', C.COLOR_OK)
    assert hostcolor('ok', dict(failures=0, unreachable=0, changed=0)) == expected
    expected = u"%-37s" % stringc('failures', C.COLOR_ERROR)
    assert hostcolor('failures', dict(failures=1, unreachable=0, changed=0)) == expected
    expected = u"%-37s" % stringc('unreachable', C.COLOR_ERROR)
    assert hostcolor('unreachable', dict(failures=0, unreachable=1, changed=0)) == expected
    expected = u"%-37s" % stringc('changed', C.COLOR_CHANGED)
    assert hostcolor('changed', dict(failures=0, unreachable=0, changed=1)) == expected

# Generated at 2022-06-23 13:44:33.547395
# Unit test for function colorize
def test_colorize():
    assert 'ok=0  ' == colorize(u'ok', 0, 'green')
    assert 'ok=1  ' == colorize(u'ok', 1, 'green')
    assert 'ok=32 ' == colorize(u'ok', 32, 'green')
    assert 'ok=127' == colorize(u'ok', 127, 'green')
    assert 'ok=128' == colorize(u'ok', 128, 'green')
    assert 'ok=1024' == colorize(u'ok', 1024, 'green')



# Generated at 2022-06-23 13:44:43.749746
# Unit test for function hostcolor
def test_hostcolor():
    stats = {"failures": 0, "changed": 0, "ok": 1, "skipped": 0, "unreachable": 0}
    color = hostcolor("127.0.0.1", stats, color=True)
    no_color = hostcolor("127.0.0.1", stats, color=False)
    assert color == u"\u001b[0;32m%-37s\u001b[0m" % "127.0.0.1"
    assert no_color == u"%-26s" % "127.0.0.1"
    # failure
    stats = {"failures": 1, "changed": 0, "ok": 0, "skipped": 0, "unreachable": 0}
    color = hostcolor("127.0.0.1", stats, color=True)
    no_color

# Generated at 2022-06-23 13:44:45.057134
# Unit test for function colorize
def test_colorize():
    # TODO
    pass


# Generated at 2022-06-23 13:44:49.793747
# Unit test for function stringc
def test_stringc():
    b = u"this is blue"
    r = u"this is red"
    s = u"this is normal"
    assert stringc(b, "blue") == u"\033[34m%s\033[0m" % b
    assert stringc(r, "red") == u"\033[31m%s\033[0m" % r
    assert stringc(s, "") == s
    assert stringc(s, None) == s

# End of pretty
# ---



# Generated at 2022-06-23 13:45:01.104676
# Unit test for function parsecolor
def test_parsecolor():
    print(parsecolor(color='color0'))
    print(parsecolor(color='color1'))
    print(parsecolor(color='color2'))
    print(parsecolor(color='color3'))
    print(parsecolor(color='color4'))
    print(parsecolor(color='color5'))
    print(parsecolor(color='color6'))
    print(parsecolor(color='color7'))
    print(parsecolor(color='color8'))
    print(parsecolor(color='color9'))

    print(parsecolor(color='color10'))
    print(parsecolor(color='color11'))
    print(parsecolor(color='color12'))
    print(parsecolor(color='color13'))

# Generated at 2022-06-23 13:45:13.567186
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return

    for color in ('black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        s = stringc(color, color)
        if s is None:
            raise AssertionError(u"Color %s not found" % color)
        if u'\033[0' not in s:
            raise AssertionError(u"Color %s not found in string %s" % (color, s))

    if u'\033[0m' not in stringc('TESTTESTTESTTEST', 'black', wrap_nonvisible_chars=True):
        raise AssertionError(u"String TESTTESTTESTTEST not in black")


# Generated at 2022-06-23 13:45:24.897444
# Unit test for function stringc
def test_stringc():
    assert stringc(u'foo', 'blue') == u"\033[34mfoo\033[0m"
    assert stringc(u'foo\nbar', 'blue') == u"\033[34mfoo\nbar\033[0m"
    assert stringc(u'foo', 'blue', wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert stringc(u'foo\nbar', 'blue', wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\nbar\001\033[0m\002"

# Generated at 2022-06-23 13:45:37.487081
# Unit test for function stringc
def test_stringc():
    assert stringc('FOO', 'green') == u"\033[32mFOO\033[0m"
    assert stringc('FOO', 'blue') == u"\033[34mFOO\033[0m"
    assert stringc('FOO', 'red') == u"\033[31mFOO\033[0m"
    assert stringc('FOO', 'normal') == u'FOO'
    assert stringc('FOO', 'bold') == u"\033[1mFOO\033[0m"
    assert stringc('FOO', 'yellow') == u"\033[33mFOO\033[0m"
    assert stringc('FOO', 'magenta') == u"\033[35mFOO\033[0m"
    assert stringc('FOO', 'cyan')

# Generated at 2022-06-23 13:45:50.847671
# Unit test for function colorize
def test_colorize():
    # ANSIBLE_COLOR = False
    assert colorize('foo', 0, color='red') == u"foo=0   "
    # ANSIBLE_COLOR = True
    assert colorize('foo', 0, color='red') == u"foo=0   "
    assert colorize('foo', 1, color='red') == u"foo=1   "
    assert colorize('foo', 10, color='red') == u"foo=10  "
    assert colorize('foo', 100, color='red') == u"foo=100 "
    assert colorize('foo', 1000, color='red') == u"foo=1000"
    assert colorize('foo', 10000, color='red') == u"foo=10000"
    assert colorize('foo', 12345, color='red') == u"foo=12345"
    # ANSIBLE

# Generated at 2022-06-23 13:46:01.970675
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    if hostcolor("localhost", stats) != "%-37s" % "localhost" \
            or hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) != "%-37s" % stringc("localhost", C.COLOR_ERROR) \
            or hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) != "%-37s" % stringc("localhost", C.COLOR_ERROR) \
            or hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) != "%-37s" % stringc("localhost", C.COLOR_CHANGED):
        return False
    else:
        return True
# --- end "pretty"

# Generated at 2022-06-23 13:46:13.937160
# Unit test for function parsecolor
def test_parsecolor():
    """
    Example:
    >>> test_parsecolor()
    """
    assert parsecolor('blue') == '34'
    assert parsecolor('dark blue') == '34'
    assert parsecolor('light blue') == '34'
    assert parsecolor('bright blue') == '94'
    assert parsecolor('bold blue') == '94'
    assert parsecolor('light blue') == '34'
    assert parsecolor('color15') == '38;5;15'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color19') == '38;5;19'
    assert parsecolor('color22') == '38;5;22'
    assert parsecolor('color255') == '38;5;255'

# Generated at 2022-06-23 13:46:23.759590
# Unit test for function hostcolor
def test_hostcolor():
    hosts = []
    hosts.append({'stats': {'failures': 1, 'unreachable': 0, 'changed': 0}})
    hosts.append({'stats': {'failures': 0, 'unreachable': 1, 'changed': 0}})
    hosts.append({'stats': {'failures': 0, 'unreachable': 0, 'changed': 1}})
    hosts.append({'stats': {'failures': 0, 'unreachable': 0, 'changed': 0}})
    hosts.append({'stats': {'failures': 0, 'unreachable': 0, 'changed': 0}})

    c = 1
    for h in hosts:
        c = c + 1
        h['host'] = 'host-%02d' % c


# Generated at 2022-06-23 13:46:31.532359
# Unit test for function parsecolor
def test_parsecolor():
    if parsecolor('black') != 16:
        print(u"parsecolor('black') returned %d instead of %d" % (parsecolor('black'), 16))
        return False
    if parsecolor('gray37') != 18:
        print(u"parsecolor('gray37') returned %d instead of %d" % (parsecolor('gray37'), 18))
        return False
    if parsecolor('white') != 231:
        print(u"parsecolor('white') returned %d instead of %d" % (parsecolor('white'), 231))
        return False
    if parsecolor('rgb555') != 124:
        print(u"parsecolor('rgb555') returned %d instead of %d" % (parsecolor('rgb555'), 124))
        return False

# Generated at 2022-06-23 13:46:37.757516
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 0, None) == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'\n'.join([u'\033[94mfoo=1   \033[0m'])
    assert colorize('foo', 1, None) == u'foo=1   '


# Generated at 2022-06-23 13:46:47.370119
# Unit test for function stringc
def test_stringc():
    assert stringc("This is a test.", "red") == "\033[31mThis is a test.\033[0m"
    assert stringc("This is a test.", "black") == "\033[30mThis is a test.\033[0m"
    assert stringc("This is a test.", "white") == "\033[1;37mThis is a test.\033[0m"
    assert stringc("This is a test.", "color1") == "\033[38;5;1mThis is a test.\033[0m"
    assert stringc("This is a test.", "color9") == "\033[38;5;9mThis is a test.\033[0m"

# Generated at 2022-06-23 13:46:52.002874
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(
        ok=0, changed=0, unreachable=0, failures=0), True) == u"localhost                \033[0m"
    assert hostcolor("localhost", dict(
        ok=0, changed=0, unreachable=0, failures=1), True) == u"localhost                \033[0;31m"
    assert hostcolor("localhost", dict(
        ok=0, changed=1, unreachable=0, failures=0), True) == u"localhost                \033[0;33m"



# Generated at 2022-06-23 13:47:00.067674
# Unit test for function colorize
def test_colorize():
    class Bcolors:
        """ Shell colors """
        RED = '\033[91m'
        ENDC = '\033[0m'
        BOLD = '\033[1m'
        UNDERLINE = '\033[4m'

    print(Bcolors.UNDERLINE + Bcolors.BOLD + 'Text in underline and bold'
          + Bcolors.ENDC)

    print(colorize('foo', 42, 'blue'))
    print(colorize('foo', 42, None))
    print(colorize('foo', 0, 'blue'))


# Generated at 2022-06-23 13:47:06.212186
# Unit test for function parsecolor
def test_parsecolor():
    # It should accept both integers and strings up to 256 as color indices
    assert parsecolor('0') == "38;5;0"
    assert parsecolor('1') == "38;5;1"
    assert parsecolor(255) == "38;5;255"
    assert parsecolor('255') == "38;5;255"

    # It should accept a range of rgb colors
    assert parsecolor('rgb000') == "38;5;16"
    assert parsecolor('rgb002') == "38;5;18"
    assert parsecolor('rgb200') == "38;5;124"
    assert parsecolor('rgb220') == "38;5;142"
    assert parsecolor('rgb222') == "38;5;146"

# Generated at 2022-06-23 13:47:17.204584
# Unit test for function hostcolor
def test_hostcolor():

    # Test old behavior where color is only used with failures
    # and unreachables
    _stats1 = dict(skipped=5, ok=10, failures=5, unreachable=0, changed=0)
    assert hostcolor("localhost", _stats1, True) == u"localhost               "
    _stats2 = dict(skipped=5, ok=10, failures=0, unreachable=0, changed=0)
    assert hostcolor("localhost", _stats2, True) == u"\x1b[0;32mlocalhost\x1b[0m              "
    _stats3 = dict(skipped=5, ok=10, failures=0, unreachable=0, changed=2)

# Generated at 2022-06-23 13:47:26.376775
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    # Test all named colors.
    for color in sorted(C.COLOR_CODES.keys()):
        # Test all text lengths.
        for i in range(14):
            text = 'A' * i
            stringc(text, color)
    # Test all color numbers.
    for i in range(256):
        text = 'A' * 13
        stringc(text, 'color%d' % i)
    # Test all rgb values.
    for red in range(6):
        for green in range(6):
            for blue in range(6):
                text = 'A' * 13
                stringc(text, 'rgb%d%d%d' % (red, green, blue))
    # Test all grays.
    for gray in range(24):
        text

# Generated at 2022-06-23 13:47:36.275895
# Unit test for function stringc
def test_stringc():
    print(u'Testing function stringc - no color')
    print(u'-' * 76)
    try:
        old_stdout, sys.stdout = sys.stdout, open('/dev/null', 'w')
        stringc(u'Testing String in Color', 'red')
    finally:
        sys.stdout.close()
        sys.stdout = old_stdout

    print(u'Testing function stringc - with color')
    print(u'-' * 76)
    try:
        old_stdout, sys.stdout = sys.stdout, open('/dev/tty', 'w')
        stringc(u'Testing String in Color', 'red')
        stringc(u'Testing String in Color', 'blue')
    finally:
        sys.stdout.close()
        sys.stdout = old

# Generated at 2022-06-23 13:47:47.525550
# Unit test for function hostcolor
def test_hostcolor():
    result = hostcolor("127.0.0.1", {"failures": 0, "unreachable": 0, "changed": 0}, color=ANSIBLE_COLOR)
    assert u"%-26s" % stringc("127.0.0.1", C.COLOR_OK) == result
    result = hostcolor("127.0.0.1", {"failures": 1, "unreachable": 0, "changed": 0}, color=ANSIBLE_COLOR)
    assert u"%-26s" % stringc("127.0.0.1", C.COLOR_ERROR) == result
    result = hostcolor("127.0.0.1", {"failures": 0, "unreachable": 1, "changed": 0}, color=ANSIBLE_COLOR)

# Generated at 2022-06-23 13:47:59.785255
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=0, failures=0, unreachable=0)
    assert hostcolor('host1', stats, color=False) == 'host1               '
    assert hostcolor('host1', stats) == 'host1               \033[0m'
    stats['changed'] = 1
    assert hostcolor('host1', stats) == '\033[0;32mhost1               \033[0m'
    stats['failures'] = 1
    assert hostcolor('host1', stats) == '\033[0;31mhost1               \033[0m'
    stats['changed'] = 0
    assert hostcolor('host1', stats) == '\033[0;31mhost1               \033[0m'
    stats['unreachable'] = 1

# Generated at 2022-06-23 13:48:06.757603
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("darkblue.example.com", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[34mdarkblue.example.com\x1b[0m"
    assert hostcolor("lightgreen.example.com", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlightgreen.example.com\x1b[0m"
    assert hostcolor("white.example.com", dict(failures=0, unreachable=0, changed=0)) == u"\x1b[32mwhite.example.com\x1b[0m"
    # Test that ANSIBLE_NOCOLOR takes precedence over C.ANSIBLE_FORCE_COLOR
    C.ANSIBLE_FORCE_COLOR = True
    C.ANS

# Generated at 2022-06-23 13:48:19.853937
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('1.1.1.1', dict(changed=1, failures=0, unreachable=0), color=True) == u"\x1b[0;32m1.1.1.1      \x1b[0m"
    assert hostcolor('1.1.1.1', dict(changed=1, failures=0, unreachable=0), color=False) == u"1.1.1.1            "
    assert hostcolor('1.1.1.1', dict(changed=0, failures=1, unreachable=0), color=True) == u"\x1b[0;31m1.1.1.1      \x1b[0m"
    assert hostcolor('1.1.1.1', dict(changed=0, failures=1, unreachable=0), color=False)

# Generated at 2022-06-23 13:48:30.692773
# Unit test for function stringc
def test_stringc():
    assert parsecolor('blue') == '34'
    assert parsecolor('red') == '31'
    assert parsecolor('default') == '39'
    assert parsecolor('dark gray') == '90'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('rgb333') == '38;5;59'
    assert parsecolor('rgb444') == '38;5;62'
    assert parsecolor('rgb555') == '38;5;63'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('gray8') == '38;5;239'
    assert parsecolor('gray9') == '38;5;240'

# Generated at 2022-06-23 13:48:35.600233
# Unit test for function hostcolor
def test_hostcolor():
    # Ensure that no color code is included when ANSIBLE_COLOR is false
    import os
    color = os.getenv("ANSIBLE_NOCOLOR", "False")
    os.environ["ANSIBLE_NOCOLOR"] = "True"
    assert hostcolor("test", {}) == "test                "
    os.environ["ANSIBLE_NOCOLOR"] = color

# Generated at 2022-06-23 13:48:44.346212
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    # test with only ok
    stats = {'ok': 10, 'changed': 0, 'unreachable': 0, 'skipped': 0, 'failed': 0}
    result = hostcolor(host, stats, color=ANSIBLE_COLOR)
    if ANSIBLE_COLOR:
        assert result == u"\033[92m%-37s\033[0m" % host
    else:
        assert result == u"%-37s" % host
    # test with some changed
    stats = {'ok': 10, 'changed': 2, 'unreachable': 0, 'skipped': 0, 'failed': 0}
    result = hostcolor(host, stats, color=ANSIBLE_COLOR)

# Generated at 2022-06-23 13:48:53.300948
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('brown') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('gray') == u'37'
    assert parsecolor('dark gray') == u'90'
    assert parsecolor('bright red') == u'91'
    assert parsecolor('bright green') == u'92'
    assert parsecolor('yellow') == u'93'
    assert parsecolor('bright blue') == u'94'

# Generated at 2022-06-23 13:49:02.240206
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'

    assert parsecolor('bright black') == '30;1'
    assert parsecolor('bright red') == '31;1'
    assert parsecolor('bright green') == '32;1'
    assert parsecolor('bright yellow') == '33;1'
    assert parsecolor('bright blue') == '34;1'

# Generated at 2022-06-23 13:49:10.878176
# Unit test for function stringc
def test_stringc():
    """ Test function stringc """
    assert stringc("text", "red") == "\033[31mtext\033[0m"
    assert stringc("text", "blue") == "\033[34mtext\033[0m"
    assert stringc("text", "black", wrap_nonvisible_chars=True) == "\001\033[30m\002text\001\033[0m\002"
    assert stringc("text", "color33", wrap_nonvisible_chars=True) == "\001\033[38;5;33m\002text\001\033[0m\002"
    assert stringc("text", "rgb300", wrap_nonvisible_chars=True) == "\001\033[38;5;8m\002text\001\033[0m\002"

# Generated at 2022-06-23 13:49:22.000594
# Unit test for function parsecolor

# Generated at 2022-06-23 13:49:29.067015
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        print("Terminal does not support color. Skipping test_stringc")
        return

    def test_single_line(text, color):
        assert stringc(text, color) == test_single_line.fmt % (test_single_line.color_code, text)

    test_single_line.fmt = u"\033[%sm%s\033[0m"
    test_single_line.color_code = parsecolor("blue")

    def test_multi_line(text, color):
        assert stringc(text, color) == test_multi_line.fmt % (test_multi_line.color_code, text)

    test_multi_line.fmt = u"\033[%sm%%s\033[0m" % parsecolor("red")

# Generated at 2022-06-23 13:49:35.723060
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color10') == u'38;5;10'
    assert parsecolor('color100') == u'38;5;100'
    assert parsecolor('rgb100') == u'38;5;100'
    assert parsecolor('rgb101') == u'38;5;101'
    assert parsecolor('rgb155') == u'38;5;155'
    assert parsecolor('rgb123') == u'38;5;123'
    assert parsecolor('rgb321') == u'38;5;211'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsec

# Generated at 2022-06-23 13:49:45.927076
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    if sys.version_info < (2, 7):
        return

    import collections
    import unittest

    class TestStringc(unittest.TestCase):
        def test_strings(self):
            """Test function stringc with strings as input."""
            test_string = 'foo'
            expected_string = u"\033[%smfoo\033[0m"
            for color_key in C.COLOR_CODES:
                self.assertEqual(stringc(test_string, color_key),
                                 expected_string % parsecolor(color_key))
            # Test wrap_nonvisible_chars=True

# Generated at 2022-06-23 13:49:57.533804
# Unit test for function parsecolor
def test_parsecolor():
    tests_true = ['red', 'rgb255255255', 'rgb00000', 'rgb255000',
                  'rgb255000000', 'rgb000255', 'rgb000000255', 'rgb000',
                  'rgb255', 'rgb000255255', 'rgb255255000', 'gray0',
                  'gray23', 'gray46', 'gray69', 'gray92', 'gray100']
    for color in tests_true:
        if not parsecolor(color):
            return False
    tests_false = ['green', 'blah', '0', '000', '256', '25500', '25500000',
                   '2550025500', '255002550025500', '2550025500255',
                   '2550025525500', '2550025525500255']

# Generated at 2022-06-23 13:50:06.724753
# Unit test for function stringc
def test_stringc():
    print(stringc("Sometext", "black"))
    print(stringc("Sometext", "red"))
    print(stringc("Sometext", "green"))
    print(stringc("Sometext", "yellow"))
    print(stringc("Sometext", "blue"))
    print(stringc("Sometext", "magenta"))
    print(stringc("Sometext", "cyan"))
    print(stringc("Sometext", "white"))
    print(stringc("Sometext", "255"))
    print(stringc("Sometext", "rgb255255255"))
    print(stringc("Sometext", "rgb255000255"))
    print(stringc("Sometext", "gray10"))
    print(stringc("Sometext", "gray20"))

# Generated at 2022-06-23 13:50:18.077565
# Unit test for function colorize
def test_colorize():
    """
    colorize: print 'lead' = 'num' in 'color'
    """
    try:
        import curses
    except ImportError:
        return
    assert "\x1b[31m-=-=\x1b[0m" == stringc("-=-=", "RED")
    assert "\x1b[31m-=-=\x1b[0m" == stringc("-=-=", "red")
    assert "\x1b[31m-=-=\x1b[0m" == stringc("-=-=", "COLOR_RED")
    assert "\x1b[31m-=-=\x1b[0m" == stringc("-=-=", "COLOR_red")

# Generated at 2022-06-23 13:50:24.790737
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('foo', 'normal') == u'\033[0mfoo\033[0m'
        assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
        assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
        assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
        assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
        assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
        assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'

# Generated at 2022-06-23 13:50:36.480270
# Unit test for function hostcolor
def test_hostcolor():
    h = 'host.example.com'

    # defaults to green
    assert  hostcolor(h, dict(failures=0, unreachable=0, changed=0)) == u"%-37s" % stringc(h, C.COLOR_OK)

    # red when failed
    assert hostcolor(h, dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc(h, C.COLOR_ERROR)

    # red when unreachable
    assert hostcolor(h, dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc(h, C.COLOR_ERROR)

    # yellow when changed
    assert hostcolor(h, dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc

# Generated at 2022-06-23 13:50:47.887959
# Unit test for function stringc
def test_stringc():
    """Test terminal coloring output."""
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-23 13:50:56.593515
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('something.example.com', dict(failures=1, unreachable=0, changed=0)) == u'\u001b[31msomething.example.com\u001b[0m      '
    assert hostcolor('something.example.com', dict(failures=0, unreachable=1, changed=0)) == u'\u001b[31msomething.example.com\u001b[0m      '
    assert hostcolor('something.example.com', dict(failures=0, unreachable=0, changed=1)) == u'\u001b[33msomething.example.com\u001b[0m      '

# Generated at 2022-06-23 13:51:01.109227
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'changed': 0,
             'failures': 1,
             'ok': 5,
             'skipped': 0,
             'unreachable': 0}
    assert hostcolor(host, stats) == stringc(host, C.COLOR_ERROR)

    stats = {'changed': 1,
             'failures': 0,
             'ok': 5,
             'skipped': 0,
             'unreachable': 0}
    assert hostcolor(host, stats) == stringc(host, C.COLOR_CHANGED)

    stats = {'changed': 0,
             'failures': 0,
             'ok': 5,
             'skipped': 0,
             'unreachable': 0}

# Generated at 2022-06-23 13:51:10.398412
# Unit test for function stringc

# Generated at 2022-06-23 13:51:18.953851
# Unit test for function colorize
def test_colorize():
    """ Unit test for function colorize
    """
    # If stdout is not a tty, then assume we don't want to
    # actually print any color codes.
    if not hasattr(sys.stdout, 'isatty') or not sys.stdout.isatty():
        return

    try:
        import curses
        curses.setupterm()
        # If curses returns an error (e.g. could not find terminal),
        # then assume we don't want to print color codes.
        if curses.tigetnum('colors') < 0:
            return
    except ImportError:
        # curses library was not found, so assume we don't need to
        # print color codes.
        return

    # Print some tests
    print()
    print(u"The following text should be red:")

# Generated at 2022-06-23 13:51:30.976963
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == "31"
    assert parsecolor("red bold") == "31;1"
    assert parsecolor("red_bold") == "31;1"
    assert parsecolor("red01") == "31;01"
    assert parsecolor("bold") == "1"
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("color01") == "38;5;01"
    assert parsecolor("color255") == "38;5;255"
    assert parsecolor("rgb123") == "38;5;123"
    assert parsecolor("rgb123123123") == "38;5;123"
    assert parsecolor("rgb255255255") == "38;5;231"

# Generated at 2022-06-23 13:51:42.485498
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize(u"foo", 0, C.COLOR_ERROR) == u"foo=0   "
        assert colorize(u"foo", 0, None) == u"foo=0   "
        assert (u"\001" not in colorize(u"foo", 10, C.COLOR_ERROR))
        assert (u"\002" not in colorize(u"foo", 10, C.COLOR_ERROR))
        assert colorize(u"foo", 1, C.COLOR_ERROR) != u"foo=1   "
        assert u"\033[31m" in colorize(u"foo", 1, C.COLOR_ERROR)
        assert u"\033[m" in colorize(u"foo", 1, C.COLOR_ERROR)

# Generated at 2022-06-23 13:51:50.674546
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=1, failures=2, unreachable=0)
    assert hostcolor('hostcolor', stats) == u"hostcolor                          "
    stats = dict(changed=0, failures=2, unreachable=0)
    assert hostcolor('hostcolor', stats) == u"hostcolor                          "
    stats = dict(changed=0, failures=2, unreachable=1)
    assert hostcolor('hostcolor', stats) == u"hostcolor                          "
    stats = dict(changed=0, failures=0, unreachable=0)
    assert hostcolor('hostcolor', stats) == u"hostcolor                          "

    stats = dict(changed=1, failures=2, unreachable=0)
    assert hostcolor('hostcolor', stats, color=False) == u"hostcolor                          "

# Generated at 2022-06-23 13:52:02.328108
# Unit test for function parsecolor
def test_parsecolor():
    """ Unit test for function parsecolor """
    def test_color(color, expected_color_code):
        """ Unit test for function parsecolor """
        color_code = parsecolor(color)
        assert color_code == expected_color_code
    test_color(u'blue', u'34')
    test_color(u'black', u'30')
    test_color(u'red', u'31')
    test_color(u'green', u'32')
    test_color(u'yellow', u'33')
    test_color(u'magenta', u'35')
    test_color(u'cyan', u'36')
    test_color(u'white', u'37')
    test_color(u'33', u'33')

# Generated at 2022-06-23 13:52:13.251587
# Unit test for function stringc
def test_stringc():
    """Simple test for function stringc"""

    assert(stringc('abcd', 'black') == '\033[30mabcd\033[0m')
    assert(stringc('abcd', 'red') == '\033[31mabcd\033[0m')
    assert(stringc('abcd', 'green') == '\033[32mabcd\033[0m')
    assert(stringc('abcd', 'yellow') == '\033[33mabcd\033[0m')
    assert(stringc('abcd', 'blue') == '\033[34mabcd\033[0m')
    assert(stringc('abcd', 'magenta') == '\033[35mabcd\033[0m')

# Generated at 2022-06-23 13:52:19.111598
# Unit test for function colorize
def test_colorize():
    a = colorize('foo', 100, 'blue')
    assert a == stringc(a, 'blue'), "%s is not blue" % a
    a = colorize('foo', 0, 'blue')
    assert a == stringc(a, 'blue'), "%s is not blue" % a



# Generated at 2022-06-23 13:52:29.561149
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    cases = [
        (u'ok', 0, 'green', u'ok=0  '),
        (u'changed', 1234, 'yellow', u'\033[33mchanged=1234\033[0m'),
        (u'failed', 1, 'red', u'\033[31mfailed=1   \033[0m'),
        (u'unreachable', 2, 'red', u'\033[31munreachable=2\033[0m'),
        (u'skipped', 3, 'cyan', u'\033[36mskipped=3  \033[0m'),
    ]
    for (lead, num, color, expected_output) in cases:
        assert colorize(lead, num, color) == expected_output

# --- end "pretty

# Generated at 2022-06-23 13:52:38.279347
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""

    test_text = "this is simple test"
    test_color = 'red'
    test_esc_text = u"\033[31mthis is simple test\033[0m"
    assert stringc(test_text, test_color) == test_esc_text
    assert parsecolor("255") == "38;5;255"
    assert parsecolor("white") == "38;5;15"
    assert parsecolor("rgb123") == "38;5;33"
    assert parsecolor("rgb255") == "38;5;231"
    assert parsecolor("rgb000") == "38;5;16"
    assert parsecolor("rgb222") == "38;5;59"

# Generated at 2022-06-23 13:52:42.789250
# Unit test for function colorize
def test_colorize():
    for c in ('blue', 'yellow', 'red', 'green', 'cyan', 'magenta'):
        print("Testing color ", c, ": ", end=' ')
        print("This should be ", c, end=' ')
        print("and this should be normal.")



# Generated at 2022-06-23 13:52:51.950585
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('3') == u'38;5;3'
    assert parsecolor('rgb214') == u'38;5;72'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray8') == u'38;5;240'
    assert parsecolor('gray16') == u'38;5;248'
# --- end "pretty"

# Generated at 2022-06-23 13:53:02.629364
# Unit test for function hostcolor
def test_hostcolor():
    # pylint: disable=protected-access, unused-argument
    host = '127.0.0.1'
    stats = {'changed': 0, 'unreachable': 0, 'skipped': 0, 'failures': 0, 'ok': 10, 'processed': 10}
    assert hostcolor(host, stats, True) == u'\033[32m%-37s\033[0m'
    stats = {'changed': 5, 'unreachable': 0, 'skipped': 0, 'failures': 0, 'ok': 5, 'processed': 10}
    assert hostcolor(host, stats, True) == u'\033[33m%-37s\033[0m'

# Generated at 2022-06-23 13:53:10.303179
# Unit test for function colorize
def test_colorize():
    """ prints colorized strings if $TERM allows it """

    print(u"Colorized by ANSIBLE_NOCOLOR=" + str(ANSIBLE_COLOR))

    if ANSIBLE_COLOR:
        print(u"Colorized by ANSIBLE_NOCOLOR=" + str(ANSIBLE_COLOR) +
              u" (should be True)")
        print(u"\nBasic colors:")
        print(stringc(u"black", 'black'))
        print(stringc(u"red", 'red'))
        print(stringc(u"green", 'green'))
        print(stringc(u"yellow", 'yellow'))
        print(stringc(u"blue", 'blue'))
        print(stringc(u"magenta", 'magenta'))

# Generated at 2022-06-23 13:53:15.824227
# Unit test for function colorize
def test_colorize():
    # Silent pytest warning that ANSIBLE_COLOR is not defined:
    # pylint: disable=no-member
    # pytest uses its own assertion, so pylint: disable=redefined-outer-name
    #
    if ANSIBLE_COLOR:
        # pylint: disable=no-member
        assert u"\033[31m=0   \033[0m" == colorize("=", 0, C.COLOR_ERROR)
        assert u"\033[31mchanged=3 \033[0m" == colorize("changed", 3, C.COLOR_ERROR)
        assert u"\033[31mrc=0   \033[0m" == colorize("rc", 0, C.COLOR_ERROR)

# Generated at 2022-06-23 13:53:27.607915
# Unit test for function colorize
def test_colorize():
    assert u"ok=0" == colorize(u"ok", 0, None)
    assert u"ok=1" == colorize(u"ok", 1, None)
    assert u"changed=8" == colorize(u"changed", 8, None)

    if ANSIBLE_COLOR:
        # color ansi sequences will be present in the string
        # \x1b[32m, \x1b[1m, \x1b[1m\x1b[32m and \x1b[0 are
        # also present.
        assert u"\x1b[1mchanged=\x1b[0m\x1b[1m\x1b[32m8\x1b[0m" == colorize(u"changed", 8, u"green")

# --- end "pretty"
#

# Generated at 2022-06-23 13:53:33.836979
# Unit test for function colorize
def test_colorize():
    """ ansible.utils.display.colorize() - basic unit tests """
    # Set up a complete color palette
    color_list = C.COLOR_OK, C.COLOR_CHANGED, C.COLOR_SKIP, C.COLOR_UNREACHABLE, C.COLOR_ERROR, C.COLOR_OBSOLETE, C.COLOR_FAILED
    color_palette_raw = u'\n'.join(["%-9s" % i for i in color_list])
    color_palette_colored = u'\n'.join(["%-9s" % stringc(i, i) for i in color_list])

    # Print raw colors
    assert colorize('FAKECODE', '16-bit', color_palette_raw) == "%-40s" % "FAKECODE=16-bit"

   