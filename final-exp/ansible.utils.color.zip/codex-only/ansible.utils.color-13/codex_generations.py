

# Generated at 2022-06-23 13:43:41.343713
# Unit test for function colorize
def test_colorize():
    assert (colorize("", 0, None) == "=0   ")
    assert (colorize("", 0, 'blue') == "=0   ")
    assert (colorize("", 1, 'blue') == "=1   ")
    assert (colorize("", 10, 'blue') == "=10  ")
    assert (colorize("", 100, 'blue') == "=100 ")
    assert (colorize("", 1000, 'blue') == "=1000")
    assert (colorize("", 10000, 'blue') == "=10000")
    assert (colorize("", 100000, 'blue') == "=100000")
    assert (colorize("foo", 0, None) == "foo=0   ")
    assert (colorize("foo", 0, 'blue') == "foo=0   ")

# Generated at 2022-06-23 13:43:50.855987
# Unit test for function stringc
def test_stringc():
    """Test the stringc() function"""

    # Do not run the test if color is not requested.
    if not ANSIBLE_COLOR:
        return

    import random
    import unittest

    # Test case for black
    class TestBlack(unittest.TestCase):

        def runTest(self):
            self.assertEqual(
                stringc('test', 'black'),
                '\033[30mtest\033[0m'
            )

    # Test case for red
    class TestRed(unittest.TestCase):

        def runTest(self):
            self.assertEqual(
                stringc('test', 'red'),
                '\033[31mtest\033[0m',
            )

    # Test case for green

# Generated at 2022-06-23 13:44:00.733744
# Unit test for function parsecolor
def test_parsecolor():
    def result_is(color, expected_value):
        value = parsecolor(color)
        message = "%r -> %r" % (color, expected_value)
        assert value == expected_value, message

    # Test all named colors
    named_colors = ('white', 'black', 'blue', 'cyan', 'green', 'magenta', 'red', 'yellow',
                    'default', 'lightwhite', 'lightblack', 'lightblue', 'lightcyan',
                    'lightgreen', 'lightmagenta', 'lightred', 'lightyellow')
    for name in named_colors:
        result_is(name, C.COLOR_CODES[name])

    # Test gray colors
    gray_colors = range(0, 23)

# Generated at 2022-06-23 13:44:09.336612
# Unit test for function stringc
def test_stringc():

    # colorize a string using a known color name
    assert stringc(u'x', u'red') == u"\033[31mx\033[0m"

    # colorize a string using an SGR parameter
    assert stringc(u'x', u'color9') == u"\033[38;5;9mx\033[0m"

    # colorize a string using an RGB triplet
    assert stringc(u'x', u'rgb217') == u"\033[38;5;187mx\033[0m"

    # colorize a string using a gray scale number
    assert stringc(u'x', u'gray3') == u"\033[38;5;235mx\033[0m"

    # colorize a string using many lines of text

# Generated at 2022-06-23 13:44:21.149253
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("blue") == u'34'
    assert parsecolor("cyan") == u'36'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("color233") == u'38;5;233'
    assert parsecolor("color0") == u'38;5;0'
    assert parsecolor("rgb123") == u'38;5;63'
    assert parsecolor("rgb555") == u'38;5;15'
    assert parsecolor("rgb000") == u'38;5;16'
    assert parsecolor("rgb111") == u'38;5;17'
    assert parsecolor("rgb222") == u'38;5;18'

# Generated at 2022-06-23 13:44:29.021007
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;0' == parsecolor('black')
    assert u'38;5;1' == parsecolor('darkred')
    assert u'38;5;2' == parsecolor('darkgreen')
    assert u'38;5;3' == parsecolor('brown')
    assert u'38;5;4' == parsecolor('darkblue')
    assert u'38;5;5' == parsecolor('purple')
    assert u'38;5;6' == parsecolor('teal')
    assert u'38;5;7' == parsecolor('lightgray')
    assert u'38;5;8' == parsecolor('darkgray')
    assert u'38;5;9' == parsecolor('lightred')

# Generated at 2022-06-23 13:44:34.217117
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 123, 'red')
    'foo=123  '
    >>> colorize('foo', 0, 'red')
    'foo=0    '
    >>> colorize('foo', 12345, 'red')
    'foo=12345'
    """
    pass



# Generated at 2022-06-23 13:44:39.970007
# Unit test for function hostcolor
def test_hostcolor():
    # For now, just make sure that calling the function does not produce an
    # exception; the actual output value is not easily checked, as it is
    # ANSI-escape-code-containing text.
    try:
        hostcolor("example.com", dict(failures=0, unreachable=0, changed=1))
    except:
        assert False
    assert True

# --- end "pretty"



# Generated at 2022-06-23 13:44:50.232692
# Unit test for function stringc
def test_stringc():
    for color in C.COLOR_CODES:
        print(stringc(color, color))
    for color in list(C.COLOR_CODES) + [
            'color16', 'rgb234', 'rgb123', 'rgb222', 'gray22', 'gray0']:
        print(stringc('hello world', color))

if __name__ == '__main__':
    test_stringc()

if ANSIBLE_COLOR:
    def colorize_idea(msg, prefix, color):
        if isinstance(msg, dict):
            msg = msg[msg.keys()[0]]
        if isinstance(msg, list):
            for m in msg:
                for line in m.split(u'\n'):
                    print(stringc(prefix, color) + line)

# Generated at 2022-06-23 13:45:02.248088
# Unit test for function colorize
def test_colorize():
    """ Unit test for function colorize, will print a table of colorized
    results when run standalone.  Note: the table is hardcoded to my terminal
    setup.
    """

    colorlist = [
        (None, "white"),
        (C.COLOR_DEBUG, "light blue"),
        (C.COLOR_ERROR, "light red"),
        (C.COLOR_SKIP, "light cyan"),
        (C.COLOR_CHANGED, "light cyan"),
        (C.COLOR_UNREACHABLE, "black"),
        (C.COLOR_OK, "light green"),
        (C.COLOR_VERBOSE, "magenta"),
    ]

    values = (0, 1, 25, 255)
    print("Unit test for function colorize")

# Generated at 2022-06-23 13:45:08.329001
# Unit test for function colorize
def test_colorize():
    from ansible.module_utils.six import StringIO
    test_out = StringIO()
    sys.stdout = test_out
    colorize(u'foo', 42, u'blue')
    sys.stdout = sys.__stdout__
    assert test_out.getvalue() == u'foo=42 '



# Generated at 2022-06-23 13:45:17.038274
# Unit test for function parsecolor
def test_parsecolor():
    # black
    assert parsecolor('black') == '30'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('gray0') == '38;5;232'
    # red
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('gray1') == '38;5;233'
    # green
    assert parsecolor('green') == '32'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('gray2') == '38;5;234'
    # yellow
    assert parsecolor('yellow') == '33'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor

# Generated at 2022-06-23 13:45:20.919183
# Unit test for function colorize
def test_colorize():
    for color in ('black', 'white', 'blue'):
        for n in range(1, 5):
            print(u"%s: %s" % (color, colorize('X', n, color)))
    for color in ('white', 'blue', None):
        print(u"%s: %s" % (color, colorize('X', 0, color)))



# Generated at 2022-06-23 13:45:24.394051
# Unit test for function colorize
def test_colorize():
    lead = "test"
    nums = [-1, 0, 1]
    colors = ["red", "white", "green"]
    for color in colors:
        for num in nums:
            print(colorize(lead, num, color))


# Generated at 2022-06-23 13:45:37.004530
# Unit test for function stringc
def test_stringc():
    assert stringc(u"text", u'red') == u"\033[31mtext\033[0m"
    assert stringc(u"text", u'RED') == u"\033[31mtext\033[0m"
    assert stringc(u"text", u'Red') == u"\033[31mtext\033[0m"
    assert stringc(u"text", u'rEd') == u"\033[31mtext\033[0m"
    assert stringc(u"text", u'blue') == u"\033[34mtext\033[0m"
    assert stringc(u"text", u'BLUE') == u"\033[34mtext\033[0m"

# Generated at 2022-06-23 13:45:37.993365
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"



# Generated at 2022-06-23 13:45:44.305251
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor("hostname", {'changed': 4, 'skipped': 4, 'ok': 4, 'failures': 4, 'unreachable': 4}) == "\033[1;33m%-37s\033[0m")
    assert(hostcolor("hostname", {'skipped': 4, 'ok': 4, 'failures': 4, 'unreachable': 4}) == "\033[91m%-37s\033[0m")
    assert(hostcolor("hostname", {'ok': 4, 'failures': 4, 'unreachable': 4}) == "\033[1;33m%-37s\033[0m")
    assert(hostcolor("hostname", {'failures': 4, 'unreachable': 4}) == "\033[91m%-37s\033[0m")

# Generated at 2022-06-23 13:45:56.590509
# Unit test for function stringc
def test_stringc():
    # We don't check for equality here because the color codes may
    # be different on different terminals.  The point is to test that
    # there is at least some escape sequences in the string, and that
    # the string ends in the expected substring.
    s = stringc("testing", 'blue')
    assert s.endswith('testing')
    assert re.search(r'\x1b\[', s)

    # Test custom color specifiers
    s = stringc("testing", 'rgb233')
    assert s.endswith('testing')
    assert re.search(r'\x1b\[', s)

    s = stringc("testing", 'color234')
    assert s.endswith('testing')
    assert re.search(r'\x1b\[', s)

    # Test without color


# Generated at 2022-06-23 13:46:05.394207
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(
        unreachable=0,
        failed=0,
        ok=1,
        skipped=0,
        changed=0
    )) == u"localhost                  "
    assert hostcolor('localhost', dict(
        unreachable=0,
        failed=1,
        ok=0,
        skipped=0,
        changed=0
    )) == u"\x1b[31mlocalhost\x1b[0m              "
    assert hostcolor('localhost', dict(
        unreachable=0,
        failed=0,
        ok=0,
        skipped=0,
        changed=1
    )) == u"\x1b[33mlocalhost\x1b[0m              "



# Generated at 2022-06-23 13:46:11.850149
# Unit test for function colorize
def test_colorize():
    assert parsecolor('blue') == '34'
    assert parsecolor('color15') == '38;5;15'
    assert parsecolor('rgb124') == '38;5;124'
    assert parsecolor('gray7') == '38;5;239'

    assert stringc('test', 'blue') == u'\033[34mtest\033[0m'



# Generated at 2022-06-23 13:46:20.130570
# Unit test for function colorize
def test_colorize():
    ''' colorize unit test'''
    assert colorize(u'ok', 3, u'green') == u'ok=3  '
    assert colorize(u'changed', 0, u'yellow') == u'changed=0'
    assert colorize(u'failed', 10, u'red') == u'failed=10 '
    assert colorize(u'unreachable', 0, u'blue') == u'unreachable=0'
    assert colorize(u'recursed', 3, u'magenta') == u'recursed=3  '



# Generated at 2022-06-23 13:46:29.974846
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor("127.0.0.1", {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 1}).startswith("127.0.0.1"))
    assert(hostcolor("127.0.0.1", {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 1}).endswith("\033[0m"))
    assert(hostcolor("127.0.0.2", {'failures': 1, 'unreachable': 0, 'changed': 0, 'ok': 0}).startswith("\033[31;01m"))

# Generated at 2022-06-23 13:46:40.335690
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc(u"test", u"") == u"test"
    assert stringc(u"test", u"red", True) == u"\x01\x1b[31m\x02test\x01\x1b[0m\x02"
    assert stringc(u"test\nmultiline", u"red", True) == u"\x01\x1b[31m\x02test\nmultiline\x01\x1b[0m\x02"
    assert stringc(u"test\nmultiline", u"red", False) == u"\x1b[31mtest\nmultiline\x1b[0m"

# Generated at 2022-06-23 13:46:53.168142
# Unit test for function stringc
def test_stringc():
    """Test the stringc function invocation"""
    assert stringc("Test", "red", wrap_nonvisible_chars=False)
    assert stringc("Test", "red", wrap_nonvisible_chars=True)
    assert stringc("Test", "blue", wrap_nonvisible_chars=False)
    assert stringc("Test", "blue", wrap_nonvisible_chars=True)
    assert stringc("Test", "rgb124", wrap_nonvisible_chars=False)
    assert stringc("Test", "rgb124", wrap_nonvisible_chars=True)
    assert stringc("Test", "gray8", wrap_nonvisible_chars=False)
    assert stringc("Test", "gray8", wrap_nonvisible_chars=True)

# Generated at 2022-06-23 13:47:01.978902
# Unit test for function stringc
def test_stringc():
    """Test stringc."""
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "red") == u"\033[31mtext\033[0m"
    assert stringc("text", "green") == u"\033[32mtext\033[0m"
    assert stringc("text", "rgb125") == u"\033[38;5;46mtext\033[0m"
    assert stringc("text", "rgb153") == u"\033[38;5;74mtext\033[0m"
    assert stringc("text", "rgb232") == u"\033[38;5;252mtext\033[0m"

# Generated at 2022-06-23 13:47:11.946191
# Unit test for function stringc
def test_stringc():
    pass_msg = u"This should be visible"
    fail_msg = u"\033[31mThis should be invisible\033[0m"
    assert parsecolor(u'black') == u'30'
    assert parsecolor(u'black') == C.COLOR_CODES[u'black']
    assert parsecolor(u'black') == C.COLOR_CODES[u'ansible-black']
    assert parsecolor(u'white') == u'97'
    assert parsecolor(u'white') == C.COLOR_CODES[u'white']
    assert parsecolor(u'white') == C.COLOR_CODES[u'ansible-white']
    assert parsecolor(u'blue') == u'34'

# Generated at 2022-06-23 13:47:23.740563
# Unit test for function colorize
def test_colorize():
    print(u'Testing function "colorize"')

    # Initialize the contents of the screen to nothing. This prevents the
    # initialization message of the curses library from being displayed as
    # part of the test results.
    import curses
    try:
        stdscr = curses.initscr()
        curses.nocbreak()
        stdscr.keypad(1)
        curses.echo()
        curses.endwin()
    except:
        pass

    # Create a string buffer to store the output of the test.
    from cStringIO import StringIO
    out = StringIO()
    # Redirect stdout to the buffer.
    sys.stdout = out

    # Run tests
    print(u'  Running test: colorize(\'changed\', 3, True)')

# Generated at 2022-06-23 13:47:34.738056
# Unit test for function stringc
def test_stringc():
    print(stringc('some text', 'red'))
    print(stringc('some text', 'green'))
    print(stringc('some text', 'blue'))
    print(stringc('some text', 'color26'))
    print(stringc('some text', 'rgb123'))
    print(stringc('some text', 'rgb543'))
    print(stringc('some text', 'rgb353'))
    print(stringc('some text', 'rgb3b5'))
    print(stringc('some text', 'rgb000'))
    print(stringc('some text', 'rgb255'))
    print(stringc('some text', 'color1'))
    print(stringc('some text', 'color2'))

# Generated at 2022-06-23 13:47:46.741890
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    goodstats = dict(failures=0, unreachable=0, changed=0)
    badstats = dict(failures=3, unreachable=0, changed=0)
    host = 'myhost'
    if not ANSIBLE_COLOR:
        assert hostcolor(host, goodstats, color=True) == hostcolor(host, goodstats, color=False)
        return
    assert hostcolor(host, goodstats, color=False) == '%-26s' % host
    assert hostcolor(host, goodstats, color=True) != hostcolor(host, badstats, color=True)
    assert hostcolor(host, goodstats, color=True) != '%-26s' % host
    assert hostcolor(host, badstats, color=True) != '%-26s' % host

# Generated at 2022-06-23 13:47:59.183793
# Unit test for function stringc
def test_stringc():
    """
    >>> print(stringc(u"hello", u"red"))
    \033[31mhello\033[0m
    >>> print(stringc(u"hello", u"rgb25020"))
    \033[38;5;130mhello\033[0m
    >>> print(stringc(u"hello", u"grey10"))
    \033[38;5;244mhello\033[0m
    >>> print(stringc(u"hello", u"color10"))
    \033[38;5;10mhello\033[0m
    >>> print(stringc(u"hello", u"foo"))
    \033[31mhello\033[0m
    >>> print(stringc(u"hello"))
    hello
    """

if __name__ == "__main__":
    import doctest

# Generated at 2022-06-23 13:48:10.449488
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(u"server1.example.com", stats) == u'\x1b[31mserver1.example.com\x1b[0m      '
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor(u"server1.example.com", stats) == u'\x1b[33mserver1.example.com\x1b[0m      '
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(u"server1.example.com", stats) == u'\x1b[32mserver1.example.com\x1b[0m      '

# Generated at 2022-06-23 13:48:21.590871
# Unit test for function stringc
def test_stringc():
    def assert_color(color, sgr_param):
        assert sgr_param == parsecolor(color)

    assert_color('black', u'38;5;0')
    assert_color('red', u'38;5;1')
    assert_color('green', u'38;5;2')
    assert_color('yellow', u'38;5;3')
    assert_color('blue', u'38;5;4')
    assert_color('magenta', u'38;5;5')
    assert_color('cyan', u'38;5;6')
    assert_color('light gray', u'38;5;7')
    assert_color('dark gray', u'38;5;8')
    assert_color('light red', u'38;5;9')

# Generated at 2022-06-23 13:48:32.827554
# Unit test for function stringc
def test_stringc():
    """Tests for stringc"""
    assert '\x1b[31mfoo\x1b[0m' == stringc('foo', 'RED')
    assert '\x1b[31mfoo\x1b[0m' == stringc('foo', '1;31')
    assert '\x1b[1;31mfoo\x1b[0m' == stringc('foo', 'BOLD_RED')
    assert '\x1b[0;31mfoo\x1b[0m' == stringc('foo', 'RESET_RED')
    assert '\x1b[0mfoo\x1b[0m' == stringc('foo', 'RESET')
    assert '\x1b[30mbar\x1b[0m' == stringc('bar', 'BLACK')

# Generated at 2022-06-23 13:48:36.575447
# Unit test for function colorize
def test_colorize():
    ''' colorize unit test'''
    assert colorize('foo', '1234', 'blue') == stringc('foo=1234', 'blue')
    assert colorize('foo', '1234', None) == 'foo=1234'


# Generated at 2022-06-23 13:48:45.277520
# Unit test for function parsecolor
def test_parsecolor():
    assert "\x1b[38;5;15m" == stringc('teststring', 'black')
    assert "\x1b[38;5;15mteststring\x1b[0m" == stringc('teststring', 'black', wrap_nonvisible_chars=True)
    assert "\x1b[38;5;15mteststring\x1b[0m" == stringc('teststring', 'color15', wrap_nonvisible_chars=True)
    assert "\x1b[38;5;16mteststring\x1b[0m" == stringc('teststring', 'color16', wrap_nonvisible_chars=True)

# Generated at 2022-06-23 13:48:54.003182
# Unit test for function hostcolor
def test_hostcolor():
    hostname = u'example.org'
    stats = dict()
    assert hostcolor(hostname, stats) == u'%-37s' % u'example.org'
    stats = dict(
        failures=0,
        unreachable=0,
        changed=0,
    )
    assert hostcolor(hostname, stats) == u'%-37s' % u'example.org'
    stats = dict(
        failures=0,
        unreachable=0,
        changed=1,
    )
    assert hostcolor(hostname, stats, color=False) == u'%-37s' % u'example.org'

# Generated at 2022-06-23 13:49:05.274087
# Unit test for function hostcolor

# Generated at 2022-06-23 13:49:14.850816
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('color12') == '38;5;12'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color214') == '38;5;214'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('rgb003') == '38;5;19'
    assert parsecolor('rgb111') == '38;5;60'
    assert parsecolor('rgb251') == '38;5;199'

# Generated at 2022-06-23 13:49:20.205364
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('green') == u'32'
    assert parsecolor('0') == u'38;5;0'
    assert parsecolor('129') == u'38;5;129'
    assert parsecolor('rgb124') == u'38;5;208'
    assert parsecolor('gray10') == u'38;5;250'



# Generated at 2022-06-23 13:49:31.251290
# Unit test for function colorize
def test_colorize():
    """ this is a kludge, but I can't find a better way to unit test functions
    that print to stdout """

# Generated at 2022-06-23 13:49:39.783820
# Unit test for function parsecolor
def test_parsecolor():
    """ Function ``parsecolor``
    """

    # Default color: blue
    assert(parsecolor('blue') == '34')

    # Default color: green
    assert(parsecolor('green') == '32')

    # Gray
    assert(parsecolor('gray9') == '38;5;246')

    # RGB
    assert(parsecolor('rgb555') == '38;5;123')
    assert(parsecolor('rgb123') == '38;5;111')

    # Color name
    assert(parsecolor('color7') == '38;5;7')

# Generated at 2022-06-23 13:49:49.067261
# Unit test for function stringc
def test_stringc():
    # pylint: disable=missing-docstring
    def equal(a, b):
        return a == b

    def testit(name, tests):
        for i, o in tests:
            result = stringc(i, name)
            assert result == o, "%s != %s for %s" % (result, o, i)

    testit('blue', [('foo', '\033[34mfoo\033[0m')])
    testit('rgb000', [('foo', '\033[38;5;16mfoo\033[0m')])
    testit('rgb123', [('foo', '\033[38;5;63mfoo\033[0m')])
    testit('rgb222', [('foo', '\033[38;5;186mfoo\033[0m')])

# Generated at 2022-06-23 13:49:51.777290
# Unit test for function colorize
def test_colorize():
    result = colorize('>', 10, 'blue')
    assert result == stringc(u"%s=%-4s" % ('>', 10), 'blue')


# Test for function hostcolor

# Generated at 2022-06-23 13:49:54.490995
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test", dict(ok=1, changed=1, unreachable=1, failed=1)) == u"test                        "

# --- end "pretty"

# Generated at 2022-06-23 13:50:05.446417
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor("red") == C.COLOR_CODES["red"])
    assert(parsecolor("green") == C.COLOR_CODES["green"])
    assert(parsecolor("blue") == C.COLOR_CODES["blue"])
    assert(parsecolor("yellow") == C.COLOR_CODES["yellow"])
    assert(parsecolor("magenta") == C.COLOR_CODES["magenta"])
    assert(parsecolor("cyan") == C.COLOR_CODES["cyan"])
    assert(parsecolor("white") == C.COLOR_CODES["white"])
    assert(parsecolor("darkgrey") == C.COLOR_CODES["darkgrey"])


# Generated at 2022-06-23 13:50:16.802882
# Unit test for function parsecolor
def test_parsecolor():
    """Unit test for function parsecolor"""

    assert parsecolor('black')    == '30'
    assert parsecolor('red')      == '31'
    assert parsecolor('green')    == '32'
    assert parsecolor('yellow')   == '33'
    assert parsecolor('blue')     == '34'
    assert parsecolor('magenta')  == '35'
    assert parsecolor('cyan')     == '36'
    assert parsecolor('white')    == '37'

    assert parsecolor('color0')   == '38;5;0'
    assert parsecolor('color1')   == '38;5;1'
    assert parsecolor('color10')  == '38;5;10'

# Generated at 2022-06-23 13:50:24.264266
# Unit test for function hostcolor
def test_hostcolor():
    host = 'www.example.com'
    stats1 = {'ok': 1, 'changed': 0, 'unreachable': 0, 'skipped': 0, 'failed': 0}
    stats2 = {'ok': 1, 'changed': 2, 'unreachable': 0, 'skipped': 0, 'failed': 0}
    stats3 = {'ok': 0, 'changed': 0, 'unreachable': 1, 'skipped': 0, 'failed': 0}
    stats4 = {'ok': 1, 'changed': 1, 'unreachable': 0, 'skipped': 0, 'failed': 0}
    assert hostcolor(host, stats1) == hostcolor(host, stats1, False)
    assert hostcolor(host, stats2) == hostcolor(host, stats2, False)

# Generated at 2022-06-23 13:50:30.263797
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", 'blue') == "\033[34mhello\033[0m"
    assert stringc("hello", 'color4') == "\033[38;5;4mhello\033[0m"
    assert stringc("hello", 'rgb255155000') == "\033[38;5;214mhello\033[0m"



# Generated at 2022-06-23 13:50:40.249500
# Unit test for function colorize
def test_colorize():
    """ test function colorize """
    def test(lead, num, color, result):
        print(u"testing: %s %s %s" % (lead, num, color))
        if colorize(lead, num, color) != result:
            print(u"got %s" % colorize(lead, num, color))
            print(u"expected: %s" % result)
            raise Exception(u"incorrect answer")

    test(u"", 0, None, u"=0   ")
    test(u"", 0, u'blue', u"=0   ")
    test(u"", 1, None, u"=1   ")
    test(u"", 1, u'blue', u"\033[34m=1   \033[0m")

# Generated at 2022-06-23 13:50:43.133965
# Unit test for function colorize
def test_colorize():
    print(colorize(u"foo", 1, C.COLOR_ERROR))
    print(colorize(u"bar", 0, C.COLOR_ERROR))
    print(colorize(u"baz", 2, C.COLOR_OK))



# Generated at 2022-06-23 13:50:54.446216
# Unit test for function colorize
def test_colorize():
    print(stringc(u"Reverse: \033[7mWORD\033[0m", 'reverse'))
    print(stringc(u"Gray: \033[30mWORD\033[0m", 'black'))
    print(stringc(u"Gray: \033[1;30mWORD\033[0m", 'bright black'))
    print(stringc(u"Red: \033[31mWORD\033[0m", 'red'))
    print(stringc(u"Red: \033[1;31mWORD\033[0m", 'bright red'))
    print(stringc(u"Green: \033[32mWORD\033[0m", 'green'))

# Generated at 2022-06-23 13:51:06.414665
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("black") == u'38;5;0'
    assert parsecolor("brightpurple") == u'38;5;141'
    assert parsecolor("color8") == u'38;5;8'
    assert parsecolor("rgb255153153") == u'38;5;196'
    assert parsecolor("rgb5255153") == u'38;5;70'
    assert parsecolor("rgb255154153") == u'38;5;197'
    assert parsecolor("rgb255153154") == u'38;5;198'
    assert parsecolor("gray8") == u'38;5;240'
    assert parsecolor("unknown") == u'38;5;15'


if __name__ == "__main__":
    test_parsec

# Generated at 2022-06-23 13:51:16.626025
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        text = 'something in color'
        color = 'green'

        assert stringc(text, color) == u"\033[32msomething in color\033[0m"
        assert stringc(text, 'rgb255255255') == u"\033[37msomething in color\033[0m"
        assert stringc(text, 'rgb104255104') == u"\033[92msomething in color\033[0m"
        assert stringc(text, 'rgb0255255') == u"\033[96msomething in color\033[0m"
        assert stringc(text, 'rgb255255102') == u"\033[93msomething in color\033[0m"

# Generated at 2022-06-23 13:51:23.207874
# Unit test for function stringc
def test_stringc():
    def test(text, color, wrap_nonvisible_chars=False):
        return stringc(text, color, wrap_nonvisible_chars) == (u'\033[%sm%s\033[0m' % (color, text))
    assert test("text", "black")
    assert test("text", "dark gray")
    assert test("text", "red")
    assert test("text", "dark red")
    assert test("text", "green")
    assert test("text", "dark green")
    assert test("text", "yellow")
    assert test("text", "dark yellow")
    assert test("text", "blue")
    assert test("text", "dark blue")
    assert test("text", "magenta")
    assert test("text", "dark magenta")
    assert test("text", "cyan")


# Generated at 2022-06-23 13:51:29.552522
# Unit test for function colorize
def test_colorize():
    print(colorize('ok', 0, C.COLOR_OK))
    print(colorize('changed', 0, C.COLOR_CHANGED))
    print(colorize('unreachable', 3, C.COLOR_UNREACHABLE))
    print(colorize('failed', 0, C.COLOR_ERROR))
    print(colorize('skipped', 1, C.COLOR_SKIP))



# Generated at 2022-06-23 13:51:41.037836
# Unit test for function parsecolor
def test_parsecolor():
    assert('38;5;124' == parsecolor('color124'))
    assert('38;5;124' == parsecolor('rgb422'))
    assert('38;5;124' == parsecolor('rgb4422'))
    assert('38;5;124' == parsecolor('rgb4242'))
    assert('38;5;79' == parsecolor('rgb400'))
    assert('38;5;79' == parsecolor('rgb040'))
    assert('38;5;79' == parsecolor('rgb004'))
    assert('38;5;90' == parsecolor('gray1'))
    assert('38;5;234' == parsecolor('gray22'))
    assert('38;5;59' == parsecolor('rgb222'))


# Generated at 2022-06-23 13:51:49.840660
# Unit test for function stringc
def test_stringc():
    '''
    This function is used to test the stringc function
    '''

# Generated at 2022-06-23 13:51:52.677203
# Unit test for function colorize
def test_colorize():
    assert colorize('TEST', 255, 'white') == 'TEST=255  '


# Generated at 2022-06-23 13:52:03.219821
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor(color="red") == u'31')
    assert(parsecolor(color="blue") == u'34')
    assert(parsecolor(color="32") == u'92')
    assert(parsecolor(color="rgb200") == u'38;5;75')
    assert(parsecolor(color="color123") == u'38;5;123')
    assert(parsecolor(color="gray99") == u'38;5;255')


# --- end of "pretty"

# --- begin "ANSIColors-8.6.1"
#
# ANSIColors - ANSI color text output for Python 2.6, 2.7 and 3.x
#
# Copyleft 2013-2016, Lars Yencken <lars.yencken@gmail.com>

# Generated at 2022-06-23 13:52:13.630135
# Unit test for function stringc
def test_stringc():
    assert u'\033[31m-\033[0m' == stringc(u'-', 'red')
    assert u'\033[31mfoo\033[0m' == stringc(u'foo', 'red')
    assert u'\033[31m(INF)-foo\033[0m' == stringc(u'(INF)-foo', 'red')
    assert u'\033[31mfoo\\n\033[0m' == stringc(u'foo\n', 'red')
    assert u'\033[31mfoo\\nbar\033[0m' == stringc(u'foo\nbar', 'red')

# Generated at 2022-06-23 13:52:25.966491
# Unit test for function colorize
def test_colorize():
    """ colorize() - Unit Test """
    test_passed = True
    test_msg = ""

    if not colorize("test", 0, None) == "test=0   ":
        test_passed = False
        test_msg += "colorize(test, 0, None) != 'test=0   '\n"

    if not colorize("test", 123, None) == "test=123 ":
        test_passed = False
        test_msg += "colorize(test, 123, None) != 'test=123 '\n"

    if not colorize("test", 123, "blue") == "test=123 ":
        test_passed = False
        test_msg += "colorize(test, 123, blue) != 'test=123 '\n"


# Generated at 2022-06-23 13:52:28.322813
# Unit test for function colorize
def test_colorize():
    for x in ('dark gray', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white'):
        print(colorize('Foo', 42, x))

# Generated at 2022-06-23 13:52:35.765242
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", "red") == u"\033[%dmhello\033[0m" % C.COLOR_CODES['red']
    assert stringc("hello", "rgb255255255") == u"\033[%dmhello\033[0m" % C.COLOR_CODES['white']
    assert stringc("hello", "rgb200200200") == u"\033[%dmhello\033[0m" % C.COLOR_CODES['bright gray']
    assert stringc("hello", "rgb055055055") == u"\033[%dmhello\033[0m" % C.COLOR_CODES['bright black']
    assert stringc("hello", "rgb282282282") == u"\033[%dmhello\033[0m" % C.COLOR_C

# Generated at 2022-06-23 13:52:46.520872
# Unit test for function hostcolor
def test_hostcolor():
    # For these tests, the COLOR_ERROR, COLOR_OK, and COLOR_CHANGED
    # constants are set to 'error', 'ok', and 'changed' respectively,
    # so that this test file doesn't need to be modified every time the
    # colors are changed.

    # Test that the color is set to COLOR_ERROR
    assert(hostcolor('host', {
                      'failures': 1,
                      'unreachable': 0,
                      'changed': 0,
                      'ok': 0,
                      }, True) == u"%-37s" % stringc('host', 'error'))

    # Test that the color is set to COLOR_CHANGED

# Generated at 2022-06-23 13:52:55.686452
# Unit test for function stringc
def test_stringc():
    # Print escape codes for all color names
    for color in sorted(C.COLOR_CODES):
        print(stringc(color, color))
    # str(int) to get an integer, which is then cast to a unicode string
    print(stringc(u'color 16', str(int(16))))
    # rgb(2, 3, 4) = 16 + 36 * 2 + 6 * 3 + 4 = 94
    print(stringc(u'rgb(2, 3, 4)', u'rgb234'))
    # gray3 = 232 + 3 = 235
    print(stringc(u'gray 3', u'gray3'))

# Generated at 2022-06-23 13:53:04.411515
# Unit test for function stringc
def test_stringc():
    ''' stringc should wrap strings in ANSI color codes. '''
    if ANSIBLE_COLOR:
        assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
        assert stringc('foo', 'red', wrap_nonvisible_chars=True) == '\001\033[31m\002foo\001\033[0m\002'
        assert stringc('foo', 'badcolor') == '\033[0mfoo\033[0m'
    else:
        assert stringc('foo', 'red') == 'foo'
        assert stringc('foo', 'red', wrap_nonvisible_chars=True) == 'foo'
        assert stringc('foo', 'badcolor') == 'foo'


# --- end "pretty"


# Generated at 2022-06-23 13:53:15.160052
# Unit test for function hostcolor
def test_hostcolor():
    # No failures, unreachables or changes
    stats1 = {'failures': 0, 'unreachable': 0, 'changed': 0}
    # One change
    stats2 = {'failures': 0, 'unreachable': 0, 'changed': 1}
    # One unreachable
    stats3 = {'failures': 0, 'unreachable': 1, 'changed': 0}
    # One failure
    stats4 = {'failures': 1, 'unreachable': 0, 'changed': 0}
    # Two changes and one unreachable
    stats5 = {'failures': 0, 'unreachable': 1, 'changed': 2}

    # Test string length
    assert len(hostcolor('test.example.com', stats1)) == 37
    assert len(hostcolor('test.example.com', stats2)) == 37

# Generated at 2022-06-23 13:53:22.943591
# Unit test for function colorize
def test_colorize():
    """ ansible.utils.color.colorize() - Unit test for function """
    # Test input values that are valid for the function and should return no
    # errors.

    # Test lead string return values
    lead = 'ok'
    num = 1
    color = u'green'
    exp = u'\033[32m%s=%-4s\033[0m' % (lead, num)
    rc = colorize(lead, num, color)
    assert exp == rc
    lead = 'failed'
    num = 1
    color = u'red'
    exp = u'\033[31m%s=%-4s\033[0m' % (lead, num)
    rc = colorize(lead, num, color)
    assert exp == rc

    # Test 'num' string return values

# Generated at 2022-06-23 13:53:29.580764
# Unit test for function colorize
def test_colorize():
    assert(colorize('foo', 0, None) == 'foo=0   ')
    assert(colorize('foo', 1, 'blue') == 'foo=1   ')
    assert(colorize('foo', 2, 'blue') == 'foo=2   ')
    assert(colorize('foo', 10, 'blue') == 'foo=10  ')
    assert(colorize('foo', 100, 'blue') == 'foo=100 ')
    assert(colorize('foo', 1000, 'blue') == 'foo=1000')



# Generated at 2022-06-23 13:53:37.741414
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""

    def _assert_equal(text, color, expected):
        actual = stringc(text, color)
        assert actual == expected, "%s != %s" % (actual, expected)

    orig_color = ANSIBLE_COLOR