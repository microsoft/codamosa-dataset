

# Generated at 2022-06-23 13:43:44.937683
# Unit test for function parsecolor
def test_parsecolor():
    assert str(parsecolor('black')) == u'30'
    assert str(parsecolor('blue')) == u'34'
    assert str(parsecolor('brightgray')) == u'37'
    assert str(parsecolor('brightyellow')) == u'93'
    assert str(parsecolor('cyan')) == u'36'
    assert str(parsecolor('darkgray')) == u'90'
    assert str(parsecolor('green')) == u'32'
    assert str(parsecolor('purple')) == u'35'
    assert str(parsecolor('red')) == u'31'
    assert str(parsecolor('white')) == u'97'
    assert str(parsecolor('yellow')) == u'33'


# Generated at 2022-06-23 13:43:48.836517
# Unit test for function hostcolor
def test_hostcolor():
    host_name = "localhost"
    host_stats = dict(changed=0, failuress=0, unreachable=0)
    host_str = hostcolor(host_name, host_stats)
    assert host_str == "%-26s" % host_name
    assert ANSIBLE_COLOR is not True



# Generated at 2022-06-23 13:43:55.468754
# Unit test for function stringc
def test_stringc():
    """ test code for function stringc """

    good_colors = {
        'red': u'\033[31mtext\033[0m',
        'green': u'\033[32mtext\033[0m',
        'yellow': u'\033[33mtext\033[0m',
        'cyan': u'\033[36mtext\033[0m'
    }

    for color in good_colors:
        ok_(stringc('text', color).endswith(good_colors[color]), msg=color)

# --- end of "pretty"

# Generated at 2022-06-23 13:44:07.390573
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("hostname", dict(changed=0), True) == u"%-26s" % stringc('hostname', C.COLOR_OK)
    assert hostcolor("hostname", dict(changed=1), True) == u"%-26s" % stringc('hostname', C.COLOR_CHANGED)
    assert hostcolor("hostname", dict(failures=1), True) == u"%-26s" % stringc('hostname', C.COLOR_ERROR)
    assert hostcolor("hostname", dict(unreachable=1), True) == u"%-26s" % stringc('hostname', C.COLOR_ERROR)
    assert hostcolor("hostname", dict(failures=1, unreachable=1), True) == u"%-26s" % stringc('hostname', C.COLOR_ERROR)
    assert host

# Generated at 2022-06-23 13:44:20.400375
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        return

    # If a color is specified, we expect these to be wrapped in ANSI
    # escape codes.
    fail_test = u"%s=%-4s" % ('F', '1')
    succ_test = u"%s=%-4s" % ('S', '2')

    # Check if the returned strings are wrapped in the expected escape code
    fail_ansi_codes = [u'\x1b[1;31m', u'\x1b[0m']
    succ_ansi_codes = [u'\x1b[1;32m', u'\x1b[0m']

    for code in fail_ansi_codes:
        assert code in colorize('F', '1', '1;31')


# Generated at 2022-06-23 13:44:26.928822
# Unit test for function colorize
def test_colorize():
    class fd:
        def write(self, text):
            print(text, end=' ')
    sys.stdout = fd()
    for color in C.COLOR_CODES:
        print(color, end=' ')
        print(stringc('test', color))
    #
    # test visible wrapping
    #
    print(stringc('test', 'blue', wrap_nonvisible_chars=True))

__all__ = ['stringc', 'parsecolor', 'colorize', 'hostcolor', 'test_colorize']

# Generated at 2022-06-23 13:44:31.752634
# Unit test for function stringc
def test_stringc():
    print(u"Testing function: stringc")
    s = u'abcd'
    print(u"Testing printing normal text")
    assert stringc(s, 'green') == u"\033[32mabcd\033[0m"
    print(u"Testing printing a colorized string")
    assert stringc(stringc(s, 'green'), 'blue') == u"\033[34m\033[32mabcd\033[0m\033[0m"
    print(u"Testing printing a string with non-visible characters")
    assert (stringc(s, 'green', wrap_nonvisible_chars=True) ==
            u"\001\033[32m\002abcd\001\033[0m\002")
    print(u"Testing printing a colorized string with non-visible characters")

# Generated at 2022-06-23 13:44:42.836991
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize(u"foo", 0, u"black") == u"foo=0   "
        assert colorize(u"foo", 0, u"c") == u"\033[0mfoo=0   \033[0m"
        assert colorize(u"foo", 0, u"rgb000") == u"\033[0mfoo=0   \033[0m"
        assert colorize(u"foo", 0, u"invalid") == u"\033[0mfoo=0   \033[0m"
        assert colorize(u"foo", 1, u"black") == u"\033[0mfoo=1   \033[0m"

# Generated at 2022-06-23 13:44:48.613224
# Unit test for function stringc
def test_stringc():
    ''' Unit test for function stringc '''
    reset = '\033[0m'
    for color in C.COLOR_CODES:
        string = "Test [%s] Text." % color
        output = stringc(string, color)
        if color == 'reset':
            assert output == "Test [reset] Text."
        else:
            search = re.match(r'Test \[\033\[\d\dm%s\033\[0m\] Text\.'
                       % color, output)
            assert bool(search)

# Generated at 2022-06-23 13:45:00.645852
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"red") == u'31'
    assert parsecolor(u"green") == u'32'
    assert parsecolor(u"yellow") == u'33'
    assert parsecolor(u"blue") == u'34'
    assert parsecolor(u"purple") == u'35'
    assert parsecolor(u"cyan") == u'36'
    assert parsecolor(u"dark gray") == u'90'
    assert parsecolor(u"dark red") == u'91'
    assert parsecolor(u"dark green") == u'92'
    assert parsecolor(u"dark yellow") == u'93'
    assert parsecolor(u"dark blue") == u'94'
    assert parsecolor(u"dark purple") == u'95'

# Generated at 2022-06-23 13:45:13.346758
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('red') == '31')
    assert(parsecolor('green') == '32')
    assert(parsecolor('yellow') == '33')
    assert(parsecolor('blue') == '34')
    assert(parsecolor('magenta') == '35')
    assert(parsecolor('cyan') == '36')
    assert(parsecolor('white') == '37')
    assert(parsecolor('dark_gray') == '90')
    assert(parsecolor('color3') == '38;5;3')
    assert(parsecolor('gray7') == '38;5;7')
    assert(parsecolor('color10') == '38;5;10')
    assert(parsecolor('color11') == '38;5;11')

# Generated at 2022-06-23 13:45:20.284145
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('35') == '38;5;35'
    assert parsecolor('magenta') == '35'
    assert parsecolor('rgb255') == '38;5;255'
    assert parsecolor('gray8') == '38;5;240'
    assert parsecolor('color8') == '38;5;8'



# Generated at 2022-06-23 13:45:23.745588
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "black") == u"\033[30mfoo\033[0m"
    assert stringc("foo", "default") == u"\033[39mfoo\033[0m"



# Generated at 2022-06-23 13:45:31.018922
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, C.COLOR_OK) == 'ok=0   '
    assert colorize('changed', 0, C.COLOR_CHANGED) == 'changed=0   '
    assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == 'unreachable=0   '
    assert colorize('failed', 0, C.COLOR_ERROR) == 'failed=0   '
    assert colorize('ok', 1, C.COLOR_OK) == stringc('ok=1   ', C.COLOR_OK)
    assert colorize('changed', 2, C.COLOR_CHANGED) == stringc('changed=2   ', C.COLOR_CHANGED)

# Generated at 2022-06-23 13:45:40.296998
# Unit test for function parsecolor
def test_parsecolor():
    tests = [('color1', u'38;5;1'),
             ('color252', u'38;5;252'),
             ('rgb000', u'38;5;16'),
             ('rgb555', u'38;5;231'),
             ('rgb123', u'38;5;114'),
             ('gray0', u'38;5;232'),
             ('gray24', u'38;5;255'),
             ('error', u'38;5;9'),
             ('continuation', u'38;5;11'),
             ]
    for color, code in tests:
        assert parsecolor(color) == code


# --- end "pretty"



# Generated at 2022-06-23 13:45:52.999682
# Unit test for function colorize
def test_colorize():
    """ Unit tests for function colorize """
    # Test single lines
    assert colorize("foo", "bar", "red") == stringc("foo=bar", "red")
    assert colorize("foo", "-bar", "red") == stringc("foo=-bar", "red")
    assert colorize("foo", "--bar", "red") == stringc("foo=--bar", "red")
    assert colorize("foo", "---bar", "red") == stringc("foo=---bar", "red")

    # Test multiple lines
    assert colorize("foo", "bar", "red") == stringc("foo=bar", "red")
    assert colorize("foo", "-bar\nbaz", "red") == stringc("foo=-bar\nfoo=baz", "red")

# Generated at 2022-06-23 13:46:01.954229
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    if ANSIBLE_COLOR:
        print(colorize("foo", 0, "red"), end='')
        print(colorize("foo", 1, "red"), end='')
        print(colorize("foo", 2, "red"))
        print(colorize("foo", 3, "red"), end='')
        print(colorize("bar", 0, "green"), end='')
        print(colorize("bar", 1, "green"), end='')
        print(colorize("bar", 2, "green"))
        print(colorize("bar", 3, "green"), end='')
        print(colorize("baz", 0, "blue"), end='')
        print(colorize("baz", 1, "blue"), end='')

# Generated at 2022-06-23 13:46:05.664863
# Unit test for function stringc
def test_stringc():
    assert stringc('hello world', 'red') == u"\033[31mhello world\033[0m"

if __name__ == '__main__':
    test_stringc()
# --- end "pretty"

# Generated at 2022-06-23 13:46:10.633823
# Unit test for function hostcolor
def test_hostcolor():

    print(u"Testing hostcolor()")

    # hostcolor(hostname, stats, color)
    # stats is a dictionary of host stats

    # Test no changes case (no color)
    # Default is no color, so this test is redundant
    #print( hostcolor('127.0.0.1', {'ok': 10, 'changed': 0, 'unreachable': 0,
    #                               'failures': 0}, False) )

    # Test no changes case (color)
    print(hostcolor('127.0.0.1', {'ok': 10, 'changed': 0, 'unreachable': 0,
                                  'failures': 0}, True))
    # Test changed case (color)

# Generated at 2022-06-23 13:46:21.404148
# Unit test for function stringc
def test_stringc():
    def assert_match(got, expected):
        assert got == expected, "got %r, expected %r" % (got, expected)

    assert_match(stringc("text", "blue"), "\033[34mtext\033[0m")
    assert_match(stringc("text", "red"), "\033[31mtext\033[0m")
    assert_match(stringc("text", "blue", wrap_nonvisible_chars=True),
                 "\001\033[34m\002text\001\033[0m\002")
    assert_match(stringc("text", "red", wrap_nonvisible_chars=True),
                 "\001\033[31m\002text\001\033[0m\002")

# Generated at 2022-06-23 13:46:27.734214
# Unit test for function colorize
def test_colorize():
    import ansible.utils.color as color_codes

    # Regression test for ensuring 256-color support works correctly
    assert(parsecolor('color256') == u'38;5;256')

    # Initialize some color attributes
    BD = 'on_' + color_codes.COLOR_BLUE
    RD = 'on_' + color_codes.COLOR_RED
    YL = 'on_' + color_codes.COLOR_YELLOW

    # The colorized version of string
    print(stringc("Test String", BD))

    # Colorized version of string with escapes
    print(stringc("\001\002Test\002\001 String", BD))

    # Print host=ok msg
    print(hostcolor('ok', {'failures': 0, 'changed': 0, 'unreachable': 0}))

    # Print ok

# Generated at 2022-06-23 13:46:35.644237
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == '34'
    assert parsecolor("color112") == '38;5;112'
    assert parsecolor("rgb501") == '38;5;188'
    assert parsecolor("rgb0141") == '38;5;19'
    assert parsecolor("rgb0153") == '38;5;21'
    assert parsecolor("gray7") == '38;5;241'



# Generated at 2022-06-23 13:46:45.900184
# Unit test for function parsecolor
def test_parsecolor():
    ansible_color = ANSIBLE_COLOR

# Generated at 2022-06-23 13:46:52.048761
# Unit test for function colorize
def test_colorize():
    ''' colorize() can be called with lead sting and number,
        to test if it returns expected output. '''
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 255, 'black') == 'foo=255 '
    assert colorize('foo', 256, 'black') == 'foo=256 '



# Generated at 2022-06-23 13:47:01.612595
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "reset") == "\033[0mtest\033[0m"
    assert stringc("test", "rgb12") == "\033[38;5;18mtest\033[0m"
    assert stringc("test", "rgb123") == "\033[38;5;21mtest\033[0m"
    assert stringc("test", "rgb213") == "\033[38;5;18mtest\033[0m"
    assert stringc("test", "rgb321") == "\033[38;5;17mtest\033[0m"

# Generated at 2022-06-23 13:47:10.721473
# Unit test for function colorize
def test_colorize():  # pragma: no cover
    """
    colorize(lead, num, color)
    """
    # pylint: disable=protected-access
    assert u'foo=1234' == colorize(u'foo', 1234, None)
    assert u'foo=0' == colorize(u'foo', 0, None)

    if ANSIBLE_COLOR:
        assert u'\001\033[32m\002foo=1234\001\033[0m\002' == colorize(u'foo', 1234, C.COLOR_OK)
        assert u'\001\033[31m\002foo=0\001\033[0m\002' == colorize(u'foo', 0, C.COLOR_ERROR)

# Generated at 2022-06-23 13:47:23.061517
# Unit test for function stringc
def test_stringc():
    pass

# Set colors for the Python logger module
import logging
logging.addLevelName(
    logging.CRITICAL,
    stringc(logging.getLevelName(logging.CRITICAL), "red", True))
logging.addLevelName(
    logging.ERROR,
    stringc(logging.getLevelName(logging.ERROR), "red", True))
logging.addLevelName(
    logging.WARNING,
    stringc(logging.getLevelName(logging.WARNING), "yellow", True))
logging.addLevelName(
    logging.INFO,
    stringc(logging.getLevelName(logging.INFO), "green", True))
logging.addLevelName(
    logging.DEBUG,
    stringc(logging.getLevelName(logging.DEBUG), "blue", True))

# Generated at 2022-06-23 13:47:23.894186
# Unit test for function stringc
def test_stringc():
    pass


# --- end "pretty"



# Generated at 2022-06-23 13:47:34.857065
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor, stringc
    from ansible import constants as C

    assert hostcolor('hostname', dict(failures=0, unreachable=0, changed=0)) == u'hostname                 '
    assert hostcolor('hostname', dict(failures=0, unreachable=0, changed=0), color=False) == u'hostname               '
    assert hostcolor('hostname', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mhostname               \x1b[0m'
    assert hostcolor('hostname', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mhostname               \x1b[0m'

# Generated at 2022-06-23 13:47:35.476484
# Unit test for function stringc
def test_stringc():
    pass

# Generated at 2022-06-23 13:47:43.288061
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        for num in [-2, -1, 0, 1, 2]:
            for color in ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']:
                assert colorize("XXX", num, color)
    else:
        x = colorize("XXX", -1, 'red')
        assert x == u"XXX=-1  "



# Generated at 2022-06-23 13:47:50.619547
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        print(u"\nColor is enabled. Test that color formatting doesn't mess up alignment in the terminal.")
        print(u"If the vertical bars (|) are aligned, and each line is the same width, this test passed.\n")
        print(u"|%-8s|" % stringc(u"bold", u"bold"))
        print(u"|%-8s|" % stringc(u"underline", u"underline"))
        print(u"|%-8s|" % stringc(u"green", u"green"))
        print(u"|%-8s|" % stringc(u"red", u"red"))
        print(u"|%-8s|" % stringc(u"blue", u"blue"))

# Generated at 2022-06-23 13:48:00.376820
# Unit test for function hostcolor
def test_hostcolor():
    """hostcolor function unit test"""
    for host, stats, color in [
            ("ok", {'failures': 0, 'changed': 0, 'unreachable': 0}, True),
            ("changed", {'failures': 0, 'changed': 1, 'unreachable': 0}, True),
            ("failure", {'failures': 1, 'changed': 0, 'unreachable': 0}, True),
            ("unreachable", {'failures': 0, 'changed': 0, 'unreachable': 1}, True),
            ("skip", {'failures': 0, 'changed': 0, 'unreachable': 0}, False)]:
        yield (check_hostcolor, host, stats, color)


# Generated at 2022-06-23 13:48:07.130649
# Unit test for function stringc

# Generated at 2022-06-23 13:48:20.058926
# Unit test for function hostcolor
def test_hostcolor():
    """Test the hostcolor function"""

    stats_success = {'changed': 0, 'dark': 0, 'failures': 0, 'ok': 1, 'processed': 1, 'rescued': 0, 'skipped': 0, 'unreachable': 0}
    stats_fail = {'changed': 0, 'dark': 0, 'failures': 1, 'ok': 0, 'processed': 1, 'rescued': 0, 'skipped': 0, 'unreachable': 0}
    stats_unreachable = {'changed': 0, 'dark': 0, 'failures': 0, 'ok': 0, 'processed': 1, 'rescued': 0, 'skipped': 0, 'unreachable': 1}

# Generated at 2022-06-23 13:48:30.934061
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {}) == u'host'
    assert hostcolor('host', {'changed': 1}) == u'host'
    assert hostcolor('host', {'failures': 1}) == u'host'
    assert hostcolor('host', {'failures': 1, 'changed': 1}) == u'host'
    assert hostcolor('host', {'unreachable': 1}) == u'host'
    assert hostcolor('host', {'unreachable': 1, 'failures': 1}) == u'host'
    assert hostcolor('host', {'unreachable': 1, 'changed': 1}) == u'host'
    assert hostcolor('host', {'unreachable': 1, 'changed': 1, 'failures': 1}) == u'host'

# Generated at 2022-06-23 13:48:39.791945
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(
        failures=0, unreachable=0, changed=0), False) == '%-26s' % 'localhost'
    assert hostcolor('localhost', dict(
        failures=0, unreachable=0, changed=0), True) == '%-37s' % stringc(
            'localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(
        failures=1, unreachable=0, changed=0), True) == '%-37s' % stringc(
            'localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(
        failures=0, unreachable=1, changed=0), True) == '%-37s' % stringc(
            'localhost', C.COLOR_ERROR)

# Generated at 2022-06-23 13:48:47.696138
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == "localhost               "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == "localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == "localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == "localhost               "



# Generated at 2022-06-23 13:48:53.544443
# Unit test for function colorize
def test_colorize():
    from ansible.constants import COLORS
    color = colorize('foo', 0, 'blue')
    assert color == u'foo=0   '
    for color in COLORS:
        color = colorize('foo', 0, color)
        assert color == u'foo=0   '
        color = colorize('foo', 1, color)
        assert color == u'\033[%smfoo=1   \033[0m' % COLORS[color]
# --- end of "pretty" module



# Generated at 2022-06-23 13:49:04.553956
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.playbook.task_include import TaskInclude
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.playbook.role import Role
    from ansible.playbook.conditional import Conditional
    from ansible.playbook.role_include import RoleInclude
    from ansible.playbook.play_context import PlayContext
    from ansible.executor.task_result import TaskResult
    from ansible.executor.task_queue_manager import TaskQueueManager
    from ansible.inventory.host import Host
    from ansible.vars.manager import VariableManager
    from ansible.parsing.dataloader import DataLoader

# Generated at 2022-06-23 13:49:13.925982
# Unit test for function parsecolor
def test_parsecolor():
    def test(test_string, expected_result):
        result = parsecolor(test_string)
        error_string = "Input: %s: Result: %s. Expected: %s" % \
                       (test_string, result, expected_result)
        assert result == expected_result, error_string

    test("red", u'31')
    test("none", u'0')
    test("blue", u'34')
    test("rgb123", u'38;5;177')
    test("gray2", u'38;5;252')
    test("color220", u'38;5;220')


# -----------------------------------------------------------------------------

if __name__ == "__main__":
    # Run module as a script
    test_parsecolor()

# Generated at 2022-06-23 13:49:25.424249
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {"failures": 0, "unreachable": 0, "changed": 0}, color=False) == "localhost               "
    assert hostcolor("localhost", {"failures": 1, "unreachable": 0, "changed": 0}, color=False) == "localhost               "
    assert hostcolor("localhost", {"failures": 0, "unreachable": 1, "changed": 0}, color=False) == "localhost               "
    assert hostcolor("localhost", {"failures": 0, "unreachable": 0, "changed": 1}, color=False) == "localhost               "
    assert hostcolor("localhost", {"failures": 0, "unreachable": 0, "changed": 0}, color=True) == "localhost               "

# Generated at 2022-06-23 13:49:34.028008
# Unit test for function colorize
def test_colorize():
    class args:
        nocolor = False
    assert colorize('foo', 0, 'green') == 'foo=0   '
    assert colorize('foo', 1, 'green') == u'foo=1   \u001b[32m\u002d\u001b[0m'
    assert colorize('foo', 2, 'green') == u'foo=2   \u001b[32m\u002d\u001b[0m'

    args.nocolor = True
    assert colorize('foo', 0, 'green') == 'foo=0   '
    assert colorize('foo', 1, 'green') == 'foo=1   '
    assert colorize('foo', 2, 'green') == 'foo=2   '

    assert colorize('foo', 0) == 'foo=0   '
    assert color

# Generated at 2022-06-23 13:49:44.823871
# Unit test for function stringc
def test_stringc():
    """Unit test"""
    # requires the curses library to be installed

# Generated at 2022-06-23 13:49:56.505306
# Unit test for function colorize
def test_colorize():
    # Expected sequences for different colors when ANSIBLE_COLOR=true
    print(u"\u001b[0m0=0\u001b[0m")
    print(u"\u001b[4;31m-1=-1\u001b[0m")
    print(u"\u001b[0;32m1=1\u001b[0m")
    print(u"\u001b[0;33m5=5\u001b[0m")

    # Check that colorize produces valid sequences without ANSIBLE_COLOR=true
    print(colorize(u'0', 0, True))
    print(colorize(u'-1', -1, True))
    print(colorize(u'1', 1, True))
    print(colorize(u'5', 5, True))



# Generated at 2022-06-23 13:50:04.842732
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return
    black = '\033[0;30m'
    bold_black = '\033[1;30m'
    red = '\033[0;31m'
    bold_red = '\033[1;31m'
    green = '\033[0;32m'
    bold_green = '\033[1;32m'
    yellow = '\033[0;33m'
    bold_yellow = '\033[1;33m'
    blue = '\033[0;34m'
    bold_blue = '\033[1;34m'
    magenta = '\033[0;35m'
    bold_magenta = '\033[1;35m'
    cyan = '\033[0;36m'
    bold_

# Generated at 2022-06-23 13:50:16.385257
# Unit test for function parsecolor

# Generated at 2022-06-23 13:50:21.776494
# Unit test for function colorize
def test_colorize():

    try:
        curses.setupterm()
    except:
        return False
    color_codes = {
        'black': u'30', 'bright gray': u'37', 'blue': u'34', 'white': u'37',
        'green': u'32', 'bright blue': u'34', 'cyan': u'36', 'bright green': u'32',
        'red': u'31', 'bright cyan': u'36', 'magenta': u'35', 'bright red': u'31',
        'yellow': u'33', 'bright magenta': u'35', 'default': u'39', 'bright yellow': u'33'
    }

    # Function colorize doesn't check `num` argument explicitly, so integer and string tests
    # concentrate more on the `lead` argument.

# Generated at 2022-06-23 13:50:34.545401
# Unit test for function parsecolor

# Generated at 2022-06-23 13:50:43.305697
# Unit test for function colorize
def test_colorize():
    lead = 'test'
    num_a = 0
    num_b = 1
    num_c = 2
    color_a = 'red'
    color_b = 'blue'
    color_c = 'green'

    if stringc(colorize(lead, num_a, color_a), color_a) != (
            "\033[31mtest=%s\033[0m" % '0'):
        raise AssertionError()

    if stringc(colorize(lead, num_b, color_b), color_b) != (
            "\033[34mtest=%s\033[0m" % '1'):
        raise AssertionError()


# Generated at 2022-06-23 13:50:54.592320
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == "34"
    assert parsecolor("brightblue") == "94"
    assert parsecolor("blackon_whiteon_green") == "30;103"
    assert parsecolor("green") == "32"
    assert parsecolor("on_green") == "42"
    assert parsecolor("red") == "31"
    assert parsecolor("magenta") == "35"
    assert parsecolor("yellow") == "33"
    assert parsecolor("cyan") == "36"
    assert parsecolor("white") == "37"
    assert parsecolor("brightblack") == "90"
    assert parsecolor("brightred") == "91"
    assert parsecolor("brightgreen") == "92"
    assert parsecolor("brightyellow") == "93"

# Generated at 2022-06-23 13:51:06.414897
# Unit test for function parsecolor
def test_parsecolor():
    print(u"Testing parsecolor(color)")
    print(u"  parsecolor('cyan') == %s" % parsecolor(u'cyan'))
    print(u"  parsecolor('blue') == %s" % parsecolor(u'blue'))
    print(u"  parsecolor('bright purple') == %s" % parsecolor(u'bright purple'))
    print(u"  parsecolor('rgb255000255') == %s" % parsecolor(u'rgb255000255'))
    print(u"  parsecolor('rgb000255000') == %s" % parsecolor(u'rgb000255000'))

# Generated at 2022-06-23 13:51:15.947991
# Unit test for function stringc
def test_stringc():
    """ Unit test for function stringc """


# Generated at 2022-06-23 13:51:19.963850
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", "red") == u"\033[31mhello\033[0m"
    assert stringc("hello", "blue") == u"\033[34mhello\033[0m"



# Generated at 2022-06-23 13:51:31.893827
# Unit test for function stringc
def test_stringc():
    # Set all colors to green to make the test automated
    C.COLOR_CODES['blue'] = '32'
    C.COLOR_CODES['red'] = '32'
    C.COLOR_CODES['green'] = '32'
    C.COLOR_CODES['teal'] = '32'
    C.COLOR_CODES['cyan'] = '32'
    C.COLOR_CODES['bold'] = '32'
    C.COLOR_CODES['dark gray'] = '32'
    C.COLOR_CODES['yellow'] = '32'
    C.COLOR_CODES['magenta'] = '32'

    # Prepare some texts

# Generated at 2022-06-23 13:51:43.632050
# Unit test for function stringc
def test_stringc():
    from ansible.compat.tests import unittest

    class TestStringc(unittest.TestCase):

        def test_parsecolor(self):
            self.assertEqual(parsecolor("red"), u'31')
            self.assertEqual(parsecolor("2"), u'38;5;2')
            self.assertEqual(parsecolor("blue"), u'34')
            self.assertEqual(parsecolor("rgb255"), u'38;5;231')
            self.assertEqual(parsecolor("rgb11"), u'38;5;17')
            self.assertEqual(parsecolor("gray2"), u'38;5;233')


# Generated at 2022-06-23 13:51:49.981458
# Unit test for function hostcolor
def test_hostcolor():
    """
    ansible.utils.hostcolor: Basic unit test for function hostcolor
    """
    host = 'host1.example.com'
    stats = dict(
        failures=0,
        unreachable=1,
        changed=0
    )
    assert hostcolor(host, stats) == u"%-26s" % stringc(host, C.COLOR_ERROR)
    stats['unreachable'] = 0
    assert hostcolor(host, stats) == u"%-26s" % stringc(host, C.COLOR_CHANGED)
    stats['changed'] = 0
    assert hostcolor(host, stats) == u"%-26s" % stringc(host, C.COLOR_OK)

# --- end "pretty"



# Generated at 2022-06-23 13:52:01.923611
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.playbook.play import Play
    from ansible.playbook.task import Task
    from ansible.playbook.block import Block
    from ansible.playbook.handler import Handler
    from ansible.vars.hostvars import HostVars
    from ansible.vars.manager import VariableManager

    # We're not actually going to run anything here, so just
    # make a fake play and task
    play = Play().load({}, variable_manager=VariableManager(), loader=None)
    task = Task().load({}, play=play)

    # play1 has only one task, and that one changed
    play1 = Play().load({}, variable_manager=VariableManager(), loader=None)
    task1 = Task().load({}, play=play1)

# Generated at 2022-06-23 13:52:12.882367
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test.testdomain.local'
    stats = dict(
        ok=10,
        changed=1,
        unreachable=0,
        failures=0
    )
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_CHANGED)
    stats = dict(
        ok=10,
        changed=0,
        unreachable=0,
        failures=0
    )
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_OK)
    stats = dict(
        ok=10,
        changed=0,
        unreachable=0,
        failures=1
    )
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)

# Generated at 2022-06-23 13:52:25.535035
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'yellow', 'blue', 'purple'):
        assert parsecolor(c) == C.COLOR_CODES[c]
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('foo', parsecolor('red')) == u"\033[31mfoo\033[0m"
    assert stringc('red', 'red') == u"\033[31mred\033[0m"
    assert stringc('foo\nbar', 'red') == u"\033[31mfoo\nbar\033[0m"

# Generated at 2022-06-23 13:52:29.381761
# Unit test for function colorize
def test_colorize():
    ''' colorize unit test '''
    print(colorize("foo", 0, 'black'))
    print(colorize("foo", 1, 'green'))
    print(colorize("foo", -1, 'red'))



# Generated at 2022-06-23 13:52:37.663000
# Unit test for function colorize
def test_colorize():
    for color_name in ['blue', 'red', 'yellow']:
        # ANSIBLE_COLOR is enabled by default
        assert ANSIBLE_COLOR
        # colorize function should return colored test string
        assert stringc('test', color_name) != 'test'
        # colorize function should return colored test string
        assert stringc('test', color_name) == '\x1b[%smtest\x1b[0m' % parsecolor(color_name)
        # ANSIBLE_COLOR is disabled
        C.ANSIBLE_NOCOLOR = True
        assert not ANSIBLE_COLOR
        # colorize function shouldn't return colored test string
        assert stringc('test', color_name) == 'test'



# Generated at 2022-06-23 13:52:47.777462
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('0') == u'38;5;0'
    assert parsecolor('255') == u'38;5;255'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray255') == u'38;5;255'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('rgb123') == u'38;5;56'
    assert parsecolor('rgb212') == u'38;5;114'
    assert parsecolor('rgb321') == u'38;5;172'

# Generated at 2022-06-23 13:52:58.728773
# Unit test for function colorize
def test_colorize():
    # Disable color so we can test the output
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('foo', 0, 'normal') == 'foo=0   '
    ANSIBLE_COLOR = True
    assert colorize('foo', 0, 'normal') == 'foo=0   '
    assert colorize('foo', 1, 'normal') == 'foo=1   '
    assert colorize('foo', 1234, 'normal') == 'foo=1234'
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 1234, 'blue') == 'foo=1234'

# Generated at 2022-06-23 13:53:05.848364
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "color3") == u"\033[38;5;39mfoo\033[0m"
    assert stringc("foo", "rgb100") == u"\033[38;5;38mfoo\033[0m"
    assert stringc("foo", "rgb111") == u"\033[38;5;39mfoo\033[0m"

# Generated at 2022-06-23 13:53:12.795542
# Unit test for function stringc

# Generated at 2022-06-23 13:53:24.393463
# Unit test for function hostcolor

# Generated at 2022-06-23 13:53:34.367682
# Unit test for function colorize
def test_colorize():
    ansible_color = ANSIBLE_COLOR