

# Generated at 2022-06-23 13:43:44.769775
# Unit test for function stringc
def test_stringc():
    """Unit tests for stringc"""
    if ANSIBLE_COLOR:
        assert stringc("foo", "red") == "\033[38;5;9mfoo\033[0m"
        assert stringc("foo", "dark red") == "\033[38;5;1mfoo\033[0m"
        assert stringc("foo", "rgb255") == "\033[38;5;231mfoo\033[0m"
        assert stringc("foo", "rgb000") == "\033[38;5;0mfoo\033[0m"
        assert stringc("foo", "rgb123") == "\033[38;5;36mfoo\033[0m"
        assert stringc("foo", "rgb321") == "\033[38;5;91mfoo\033[0m"
        assert stringc

# Generated at 2022-06-23 13:43:52.998895
# Unit test for function hostcolor
def test_hostcolor():
    def assert_hostcolor(host, stats, color_wanted):
        assert(hostcolor(host, stats, color=True) == color_wanted)
    assert_hostcolor(
        host='myhost_1',
        stats={
            'failures': 0,
            'unreachable': 0,
            'changed': 0
        },
        color_wanted=u"\x1b[32m%-37s\x1b[0m" % "myhost_1")
    assert_hostcolor(
        host='myhost_2',
        stats={
            'failures': 0,
            'unreachable': 1,
            'changed': 0
        },
        color_wanted=u"\x1b[31m%-37s\x1b[0m" % "myhost_2")
   

# Generated at 2022-06-23 13:43:59.647786
# Unit test for function stringc
def test_stringc():
    assert stringc(u"test", u"blue") == u"\033[34mtest\033[0m"
    assert stringc(u"test", u"b") == u"\033[34mtest\033[0m"
    assert stringc(u"test", u"rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc(u"nocolor") == u"nocolor"

# --- end "pretty"

# Generated at 2022-06-23 13:44:08.404028
# Unit test for function hostcolor
def test_hostcolor():
    # Test hostcolor()
    print("*" * 78)
    print("Test hostcolor()")
    print("*" * 78)
    hostcolor("localhost", {"failures": 0, "unreachable": 0, "changed": 0})
    hostcolor("localhost", {"failures": 0, "unreachable": 0, "changed": 1})
    hostcolor("localhost", {"failures": 0, "unreachable": 1, "changed": 0})
    hostcolor("localhost", {"failures": 1, "unreachable": 0, "changed": 0})
    hostcolor("localhost", {"failures": 1, "unreachable": 1, "changed": 1})
    print("*" * 78)


# --- end "pretty"


# Generated at 2022-06-23 13:44:15.453553
# Unit test for function stringc
def test_stringc():
    print("Testing function stringc()")
    text = "this is a test"
    color_list = ["black", "red", "green", "yellow", "blue", "magenta", "cyan", "white", "rgb255", "rgb000"]
    for color in color_list:
        print("%s\t: %s" % (color, stringc(text, color)))


# Generated at 2022-06-23 13:44:26.767110
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    # no such color
    assert parsecolor('pink') == ''
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'

# Generated at 2022-06-23 13:44:37.173256
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('dark gray') == u'90'
    assert parsecolor('light red') == u'91'
    assert parsecolor('light green') == u'92'
    assert parsecolor('yellow') == u'93'
    assert parsecolor('light blue') == u'94'
    assert parsecolor('light magenta') == u'95'
    assert parsecolor('light cyan') == u'96'
    assert parsecolor('white') == u'97'

    assert parsecolor('0') == u'38;5;0'
    assert parsecolor('8') == u'38;5;8'
    assert parsecolor('15') == u'38;5;15'

# Generated at 2022-06-23 13:44:46.038798
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, u"green") == u"foo=0   "
    assert colorize(u"foo", 1, u"green") == u"foo=1   "
    assert colorize(u"foo", 10, u"green") == u"foo=10  "
    assert colorize(u"foo", 100, u"green") == u"foo=100 "
    assert colorize(u"foo", 1000, u"green") == u"foo=1000"
    assert colorize(u"foo", 10000, u"green") == u"foo=10000"



# Generated at 2022-06-23 13:44:52.684075
# Unit test for function hostcolor
def test_hostcolor():
    h = hostcolor('foo', {
        'changed': 0,
        'failures': 0,
        'ok': 0,
        'skipped': 0,
        'unreachable': 0
    })
    assert h == '%-26s' % 'foo'

    h = hostcolor('foo', {
        'changed': 4,
        'failures': 0,
        'ok': 0,
        'skipped': 0,
        'unreachable': 0
    })
    assert h == '%-26s' % 'foo'

    assert not ANSIBLE_COLOR
    h = hostcolor('foo', {
        'changed': 4,
        'failures': 0,
        'ok': 0,
        'skipped': 0,
        'unreachable': 0
    }, color=False)

# Generated at 2022-06-23 13:44:57.966042
# Unit test for function parsecolor
def test_parsecolor():
    # Test parsecolor with some standard 16-colors
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'

    # Test foreground brightness (high intensity)
    assert parsecolor('bright_black') == u'90'
    assert parsecolor('bright_red') == u'91'
    assert parsecolor('bright_green') == u'92'

# Generated at 2022-06-23 13:45:01.317773
# Unit test for function colorize
def test_colorize():
    from ansible.utils.color import colorize
    lead = "Leading text"
    num = 10
    color = "blue"
    s = colorize(lead, num, color)
    print(s)
    num = 0
    s = colorize(lead, num, color)
    print(s)


# Generated at 2022-06-23 13:45:13.611040
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'

    stats = {}
    stats['changed'] = 0
    stats['failures'] = 0
    stats['unreachable'] = 0
    print(hostcolor(host, stats, color=True))

    stats['changed'] = 0
    stats['failures'] = 0
    stats['unreachable'] = 0
    print(hostcolor(host, stats, color=False))

    stats['changed'] = 1
    stats['failures'] = 0
    stats['unreachable'] = 0
    print(hostcolor(host, stats, color=True))

    stats['changed'] = 1
    stats['failures'] = 0
    stats['unreachable'] = 0
    print(hostcolor(host, stats, color=False))

    stats['changed'] = 0
    stats['failures'] = 1
    stats

# Generated at 2022-06-23 13:45:24.939247
# Unit test for function hostcolor
def test_hostcolor():
    # No color
    assert hostcolor('foo', {}) == u"%-26s" % 'foo'
    # Color
    assert hostcolor('foo', {}, color=True) == u"%-37s" % stringc('foo', C.COLOR_OK)

    # Color
    assert hostcolor('foo', {'changed': 1}, color=True) == u"%-37s" % stringc('foo', C.COLOR_CHANGED)

    # Color
    assert hostcolor('foo', {'changed': 1, 'failures': 2}, color=True) == u"%-37s" % stringc('foo', C.COLOR_ERROR)

    # No color
    assert hostcolor('foo', {'changed': 1, 'failures': 2}) == u"%-26s" % 'foo'



# Generated at 2022-06-23 13:45:37.529319
# Unit test for function parsecolor

# Generated at 2022-06-23 13:45:46.369081
# Unit test for function stringc
def test_stringc():
    if sys.version_info[0] == 3:
        stringc = 'mystring'
    else:
        stringc = u'mystring'
    # Check string returned
    assert stringc('test', 'blue') == u'\x1b[34mtest\x1b[0m'
    # Check string type (unicode for Python 2, string for Python 3)
    assert isinstance(stringc('test', 'blue'), type(stringc))



# Generated at 2022-06-23 13:45:58.036106
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        return
    assert u"\033[31mhi!\033[0m" == stringc(u"hi!", u"RED")
    assert u"\033[31mhi!\033[0m" == stringc(u"hi!", u"red")
    assert u"\033[38;5;11mhi!\033[0m" == stringc(u"hi!", u"rgb050")
    assert u"\033[1;31mhi!\033[0m" == stringc(u"hi!", u"BRED")
    assert u"\033[1;31mhi!\033[0m" == stringc(u"hi!", u"bred")

# Generated at 2022-06-23 13:46:06.825776
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == "31"
    assert parsecolor("green") == "32"
    assert parsecolor("yellow") == "33"
    assert parsecolor("blue") == "34"
    assert parsecolor("magenta") == "35"
    assert parsecolor("cyan") == "36"
    assert parsecolor("lightgray") == "37"
    assert parsecolor("darkgray") == "90"

    # extended colors are only available is term supports at least 256 colors
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("color2") == "38;5;2"
    assert parsecolor("color3") == "38;5;3"
    assert parsecolor("color234") == "38;5;234"

    # rgb colors

# Generated at 2022-06-23 13:46:11.270052
# Unit test for function parsecolor
def test_parsecolor():
    if parsecolor('31') == u'31':
        print(u"OK: parsecolor('31')")
    else:
        print(u"ERROR: parsecolor('31')")
    if parsecolor('rgb555') == u'38;5;124':
        print(u"OK: parsecolor('rgb555')")
    else:
        print(u"ERROR: parsecolor('rgb555')")
    if parsecolor('gray4') == u'38;5;239':
        print(u"OK: parsecolor('gray4')")
    else:
        print(u"ERROR: parsecolor('gray4')")
    if parsecolor('this is not a valid color name') is None:
        print(u"OK: parsecolor('this is not a valid color name')")

# Generated at 2022-06-23 13:46:18.580948
# Unit test for function colorize
def test_colorize():

    if ANSIBLE_COLOR:
        assert colorize('foo', 0, 'white') == u"foo=0   "
        assert colorize('foo', 0, 'blue') == u"\033[34mfoo=0  \033[0m"
        assert colorize('foo', 123, 'blue') == u"\033[34mfoo=123\033[0m"
        assert colorize('foo', 123, None) == u"foo=123 "

# --- end "pretty"



# Generated at 2022-06-23 13:46:27.110614
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('test_hostcolor', {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 1}) == u"test_hostcolor                 "
    assert hostcolor('test_hostcolor', {'failures': 1, 'unreachable': 0, 'changed': 0, 'ok': 0}) == u"test_hostcolor                 "
    assert hostcolor('test_hostcolor', {'failures': 0, 'unreachable': 1, 'changed': 0, 'ok': 0}) == u"test_hostcolor                 "
    assert hostcolor('test_hostcolor', {'failures': 0, 'unreachable': 0, 'changed': 1, 'ok': 0}) == u"test_hostcolor                 "

#
# --- end "pretty"

# Generated at 2022-06-23 13:46:39.067993
# Unit test for function hostcolor
def test_hostcolor():
    # Test for color and no color
    #    defaults to color = True in hostcolor
    assert hostcolor('foo', {'failures': 0, 'unreachable': 0, 'changed': 0},
                     True) == u"%-37s" % stringc('foo', C.COLOR_OK)
    assert hostcolor('foo', {'failures': 0, 'unreachable': 0, 'changed': 0},
                     False) == u"%-26s" % 'foo'

    # Test each color type with color enabled and disabled
    assert hostcolor('foo', {'failures': 1, 'unreachable': 0, 'changed': 0},
                     True) == u"%-37s" % stringc('foo', C.COLOR_ERROR)

# Generated at 2022-06-23 13:46:47.744302
# Unit test for function parsecolor
def test_parsecolor():
    """Verify parsecolor function."""
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('COLOR000') == u'38;5;0'
    assert parsecolor('COLOR001') == u'38;5;1'
    assert parsecolor('COLOR002') == u'38;5;2'

# Generated at 2022-06-23 13:46:51.835810
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('faux', dict(changed=0, failures=0, unreachable=0), True) == u"faux                            "
    assert hostcolor('faux', dict(changed=0, failures=0, unreachable=0), False) == u"faux                 "



# Generated at 2022-06-23 13:47:00.245110
# Unit test for function hostcolor
def test_hostcolor():
    # ANSIBLE_COLOR (defaults to True) allows calling stringc()
    #C.ANSIBLE_NOCOLOR = True
    testcases = []
    testcases.append({'host': 'host1', 'stats': dict(changed=0, failures=0, unreachable=0)})
    testcases.append({'host': 'host2', 'stats': dict(changed=0, failures=1, unreachable=0)})
    testcases.append({'host': 'host3', 'stats': dict(changed=1, failures=0, unreachable=0)})
    testcases.append({'host': 'host4', 'stats': dict(changed=1, failures=1, unreachable=0)})

# Generated at 2022-06-23 13:47:06.780637
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('default') == u'39'
    assert parsecolor('brightgray') == u'37'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb255255255') == u'38;5;231'
    assert parsecolor('gray253') == u'38;5;253'
    assert parsecolor('badcolor') == u'39'

# Generated at 2022-06-23 13:47:17.376018
# Unit test for function parsecolor
def test_parsecolor():
    import pytest

    color_codes = C.COLOR_CODES

    assert parsecolor('blue') == color_codes['blue']
    assert parsecolor('yellow') == color_codes['yellow']
    assert parsecolor('red') == color_codes['red']
    assert parsecolor('green') == color_codes['green']

    assert parsecolor('rgb200') == '38;5;172'
    assert parsecolor('rgb222') == '38;5;186'

    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('rgb100') == '38;5;52'
    assert parsecolor('rgb010') == '38;5;34'
    assert parsecolor('rgb001') == '38;5;18'
    assert par

# Generated at 2022-06-23 13:47:26.464177
# Unit test for function colorize
def test_colorize():
    from ansible.playbook.play_context import PlayContext

    # ANSIBLE_COLOR set False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    result = colorize(u'ok', 0, C.COLOR_OK)
    assert result == u'ok=0    '

    # ANSIBLE_COLOR set True
    ANSIBLE_COLOR = True
    result = colorize(u'ok', 0, C.COLOR_OK)
    assert result == u'ok=0    '
    result = colorize(u'changed', 1, C.COLOR_CHANGED)
    assert result == u'\n'.join([
        u'\033[0;34;49m'
        u'changed=1   '
        u'\033[0m'
    ])

# Generated at 2022-06-23 13:47:36.382259
# Unit test for function parsecolor
def test_parsecolor():
    assert '38;5;%d' % 0 == parsecolor('black')
    assert '38;5;%d' % 1 == parsecolor('bright_red')
    assert '38;5;%d' % 2 == parsecolor('bright_green')
    assert '38;5;%d' % 3 == parsecolor('bright_yellow')
    assert '38;5;%d' % 4 == parsecolor('bright_blue')
    assert '38;5;%d' % 5 == parsecolor('bright_magenta')
    assert '38;5;%d' % 6 == parsecolor('bright_cyan')
    assert '38;5;%d' % 7 == parsecolor('bright_white')
    assert '38;5;%d' % 8 == parsecolor('dark_gray')
   

# Generated at 2022-06-23 13:47:47.218695
# Unit test for function hostcolor
def test_hostcolor():
    h = hostcolor('host-1', {'ok': 10, 'changed': 1, 'failures': 1, 'unreachable': 1})
    assert h == u'host-1'
    h = hostcolor('host-2', {'ok': 10, 'changed': 1, 'failures': 0, 'unreachable': 0})
    assert h == u'host-2'
    h = hostcolor('host-3', {'ok': 10, 'changed': 0, 'failures': 1, 'unreachable': 0})
    assert h == u'host-3'
    h = hostcolor('host-4', {'ok': 10, 'changed': 0, 'failures': 0, 'unreachable': 1})
    assert h == u'host-4'



# Generated at 2022-06-23 13:47:56.704438
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('0') == '38;5;0'
    assert parsecolor('rgb255255255') == '38;5;15'
    assert parsecolor('rgb12301230') == '38;5;99'
    assert parsecolor('rgb000100') == '38;5;6'
    assert parsecolor('rgb255000000') == '38;5;9'
    assert parsecolor('gray10') == '38;5;252'
    assert parsecolor('black') == '30'



# Generated at 2022-06-23 13:48:08.184565
# Unit test for function stringc
def test_stringc():
    text = u"The quick brown fox jumps over the lazzy dog."
    assert stringc(text, 'blue') == u'\033[34mThe quick brown fox jumps over the lazzy dog.\033[0m'
    assert stringc(text, 'color3') == u'\033[38;5;107mThe quick brown fox jumps over the lazzy dog.\033[0m'
    assert stringc(text, 'rgb252') == u'\033[38;5;210mThe quick brown fox jumps over the lazzy dog.\033[0m'
    assert stringc(text, 'rgb252', wrap_nonvisible_chars=True) == u'\001338;5;210m\002The quick brown fox jumps over the lazzy dog.\001338;5;0m\002'
    assert string

# Generated at 2022-06-23 13:48:14.254644
# Unit test for function colorize
def test_colorize():
    # Set ANSIBLE_COLOR to the opposite of what it was, so we effectively toggle the value of ANSIBLE_COLOR.
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = not ANSIBLE_COLOR
    # Test to ensure that the colorization works properly
    assert colorize("test", 1, "red") == stringc("test=1", "red")
    # Test to ensure that if ANSIBLE_COLOR is set to False, then colorization isn't done
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize("test", 1, "red") == "test=1   "
    # Reset the value of ANSIBLE_COLOR to its original value
    ANSIBLE_COLOR = not ANSIBLE_COLOR

# Generated at 2022-06-23 13:48:23.977669
# Unit test for function stringc
def test_stringc():
    print(stringc('hello world', 'red', True))
    print(stringc('hello world', 'RED', False))
    print(stringc('hello world', 'blue', True))
    print(stringc('hello world', 'BLUE', False))
    print(stringc('hello world', 'magenta', True))
    print(stringc('hello world', 'MAGENTA', False))
    print(stringc('hello world', 'cyan', True))
    print(stringc('hello world', 'CYAN', False))
    print(stringc('hello world', 'green', True))
    print(stringc('hello world', 'GREEN', False))
    print(stringc('hello world', 'yellow', True))
    print(stringc('hello world', 'YELLOW', False))

# Generated at 2022-06-23 13:48:35.222177
# Unit test for function parsecolor
def test_parsecolor():
    if C.ANSIBLE_NOCOLOR:
        print("skipping test due to ANSIBLE_NOCOLOR")

    # Test #1
    ref = u'38;5;124'
    result = parsecolor('blue')
    assert result == ref

    # Test #2
    ref = u'38;5;88'
    result = parsecolor('rgb25500050')
    assert result == ref

    # Test #3
    ref = u'38;5;232'
    result = parsecolor('gray0')
    assert result == ref

    # Test #4
    ref = C.COLOR_CODES['dark gray']
    result = parsecolor('dark gray')
    assert result == ref

# --- end "pretty" ---


# Generated at 2022-06-23 13:48:42.609624
# Unit test for function stringc
def test_stringc():
    class TestStringc(unittest.TestCase):
        def test_black(self):
            self.assertEqual(stringc("foo", "black"), u"\033[30mfoo\033[0m")

        def test_red(self):
            self.assertEqual(stringc("bar", "red"), u"\033[31mbar\033[0m")

        def test_green(self):
            self.assertEqual(stringc("baz", "green"), u"\033[32mbaz\033[0m")

        def test_yellow(self):
            self.assertEqual(stringc("quux", "yellow"), u"\033[33mquux\033[0m")


# Generated at 2022-06-23 13:48:48.016056
# Unit test for function stringc
def test_stringc():
    assert stringc('hello world', 'blue') == '\033[34mhello world\033[0m'
    assert stringc('hello world', 'bright blue') == '\033[94mhello world\033[0m'

# --- end of "pretty"



# Generated at 2022-06-23 13:48:51.410875
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('bar', 1, 'green') == '\x1b[32mbar=1   \x1b[0m'



# Generated at 2022-06-23 13:49:00.191033
# Unit test for function hostcolor
def test_hostcolor():
    import __main__
    __main__.ANSIBLE_COLOR = True
    assert hostcolor(u"test.example.org", dict(failures=0, unreachable=0, changed=0), True) == u"%-37s" % u"\033[0;32mtest.example.org\033[0m"
    assert hostcolor(u"test.example.org", dict(failures=1, unreachable=0, changed=0), True) == u"%-37s" % u"\033[0;31mtest.example.org\033[0m"
    assert hostcolor(u"test.example.org", dict(failures=0, unreachable=1, changed=0), True) == u"%-37s" % u"\033[0;31mtest.example.org\033[0m"
   

# Generated at 2022-06-23 13:49:09.557701
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("black") == u'38;5;16'
    assert parsecolor("red") == u'38;5;196'
    assert parsecolor("green") == u'38;5;46'
    assert parsecolor("yellow") == u'38;5;226'
    assert parsecolor("blue") == u'38;5;21'
    assert parsecolor("magenta") == u'38;5;201'
    assert parsecolor("cyan") == u'38;5;51'
    assert parsecolor("lightgray") == u'38;5;250'
    assert parsecolor("darkgray") == u'38;5;240'
    assert parsecolor("lightred") == u'38;5;9'

# Generated at 2022-06-23 13:49:20.788998
# Unit test for function colorize
def test_colorize():
    ''' colorize unit test'''
    assert colorize("foo", 0, 'green')     == u'foo=0   '
    assert colorize("foo", 10, 'green')    == u'foo=10  '
    assert colorize("foo", 100, 'green')   == u'foo=100 '
    assert colorize("foo", 1000, 'green')  == u'foo=1000'
    assert colorize("foo", 10000, 'green') == u'foo=10000'
    assert colorize("foo", 0, 'red')       == u'foo=0   '
    assert colorize("foo", 10, 'red')      == u'foo=10  '
    assert colorize("foo", 100, 'red')     == u'foo=100 '

# Generated at 2022-06-23 13:49:29.832256
# Unit test for function stringc
def test_stringc():
    def _eq(s1, s2):
        import sys
        if sys.version_info[0] == 2:
            return s1 == s2
        else:
            return s1 == s2.encode()
    assert stringc('foo', 'black') == u"\033[30mfoo\033[0m"
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"
    assert stringc('foo', 'yellow') == u"\033[33mfoo\033[0m"
    assert stringc('foo', 'blue') == u"\033[34mfoo\033[0m"

# Generated at 2022-06-23 13:49:36.021639
# Unit test for function parsecolor
def test_parsecolor():
    # positive
    assert parsecolor(u'red') == u'31'
    assert parsecolor(u'green') == u'32'
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'color1') == u'38;5;1'
    assert parsecolor(u'color002') == u'38;5;2'
    assert parsecolor(u'color229') == u'38;5;229'
    assert parsecolor(u'rgb000') == u'38;5;232'
    assert parsecolor(u'rgb555') == u'38;5;15'
    assert parsecolor(u'rgb123') == u'38;5;57'

# Generated at 2022-06-23 13:49:46.161582
# Unit test for function stringc
def test_stringc():
    try:
        curses.setupterm()
    except curses.error:
        pass
    if curses.tigetnum('colors') < 0:
        # No support for color; nothing to test
        return

    gray_codes = [u'238', u'239', u'240', u'241', u'242', u'243', u'244', u'245', u'246', u'247']

    def assert_stringc(text, color, expected):
        actual = stringc(text, color, False)
        assert actual == expected, '%r != %r for text, color = %r, %r' % (
            actual, expected, text, color)

# Generated at 2022-06-23 13:49:55.661510
# Unit test for function hostcolor
def test_hostcolor():
    from io import StringIO
    import sys

    out = StringIO()
    stats = dict(
        unchanged=0,
        changed=0,
        unreachable=0,
        failed=0
    )
    host_str = hostcolor(u"myhost", stats, color=True)
    if host_str != u"\x1b[1;32m%s\x1b[0m" % u"%-26s":
        print(u"ERROR: `hostcolor` returned %r" % host_str)
        sys.exit(1)



# Generated at 2022-06-23 13:50:00.353720
# Unit test for function colorize
def test_colorize():
    # Set up
    lead = 'test'
    num = 0
    color = 'darkgray'

    # Call function
    s = colorize(lead, num, color)

    # Output
    #print s



# Generated at 2022-06-23 13:50:08.386086
# Unit test for function parsecolor
def test_parsecolor():
    def test(name, expected_result, test_value):
        res = parsecolor(test_value)
        if res != expected_result:
            raise AssertionError("\n%s: Parse result differs from expected\n   expected: %s\n     parsed: %s" %
                                 (name, expected_result, res))
    ###########################
    # testing color parameters
    ###########################
    test('color000', '38;5;0', 'color000')
    test('color000', '38;5;0', 'color0')
    test('color000', '38;5;0', 'color0')
    test('color000', '38;5;0', 'color0')
    test('color222', '38;5;222', 'color222')

# Generated at 2022-06-23 13:50:11.452181
# Unit test for function stringc
def test_stringc():
    assert stringc('foo bar', 'blue', wrap_nonvisible_chars=False) == u"\033[34mfoo bar\033[0m"

# --- end "pretty"



# Generated at 2022-06-23 13:50:21.904770
# Unit test for function parsecolor
def test_parsecolor():
    if not ANSIBLE_COLOR:
        sys.stderr.write("SKIPPING COLOR TESTS, terminal does not support color\n")
    else:
        assert parsecolor(u'normal')           == u''
        assert parsecolor(u'red')              == u'31'
        assert parsecolor(u'color3')           == u'38;5;3'
        assert parsecolor(u'color39')          == u'38;5;39'
        assert parsecolor(u'color255')         == u'38;5;255'
        assert parsecolor(u'rgb123')           == u'38;5;18'
        assert parsecolor(u'rgb321')           == u'38;5;39'

# Generated at 2022-06-23 13:50:34.755841
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(changed=1, failures=0, ok=4, skipped=0, unreachable=0)
    assert hostcolor('foo.example.org', stats, color=False) == "foo.example.org           "
    assert hostcolor('foo.example.org', stats, color=True) == u"\033[0;32mfoo.example.org\033[0m       "
    stats = dict(changed=0, failures=0, ok=4, skipped=0, unreachable=0)
    assert hostcolor('foo.example.org', stats, color=False) == "foo.example.org           "
    assert hostcolor('foo.example.org', stats, color=True) == u"\033[0;32mfoo.example.org\033[0m       "

# Generated at 2022-06-23 13:50:45.597226
# Unit test for function parsecolor
def test_parsecolor():
    # These test cases have been taken from ANSI-escape codes:
    # https://en.wikipedia.org/wiki/ANSI_escape_code#Colors
    assert parsecolor("black") == "30"
    assert parsecolor("red") == "31"
    assert parsecolor("green") == "32"
    assert parsecolor("yellow") == "33"
    assert parsecolor("blue") == "34"
    assert parsecolor("magenta") == "35"
    assert parsecolor("cyan") == "36"
    assert parsecolor("white") == "37"
    assert parsecolor("default") == "39"
    # Grayscale test cases
    assert parsecolor("gray0") == "38;5;232"

# Generated at 2022-06-23 13:50:55.710497
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        sys.stderr.write(u'\nAnsible support for terminal coloring could not be loaded. '
                         u'Test for function stringc() has been skipped.\n')
        return

    # Check that codes for color names are correct
    for color in C.COLOR_CODES:
        assert(parsecolor(color) == C.COLOR_CODES[color])

    # Check that codes for RGB colors are correct
    for red in range(6):
        for green in range(6):
            for blue in range(6):
                assert(parsecolor('rgb%d%d%d' % (red, green, blue)) ==
                       '38;5;%d' % (16 + 36 * red + 6 * green + blue))

    # Check that codes for gray colors are

# Generated at 2022-06-23 13:51:00.886581
# Unit test for function colorize
def test_colorize():
    # only to be run when ANSIBLE_COLOR is set to True
    if ANSIBLE_COLOR:
        assert colorize('test', 1, 'red') == stringc('test=1   ', 'red')
        assert colorize('test', 1, 'green') == stringc('test=1   ', 'green')



# Generated at 2022-06-23 13:51:10.299996
# Unit test for function stringc
def test_stringc():
    tests = {'red': u"\033[31mred\033[0m",
             'on_red': u"\033[41mon_red\033[0m",
             'red+underline': u"\033[31;4mred+underline\033[0m",
             u"red bold": u"\033[1;31mred bold\033[0m",
             u"on_red+underline": u"\033[41;4mon_red+underline\033[0m"}
    for text, control in tests.items():
        if stringc(text, text) != control:
            print("[%s](%s) != [%s](%s)" % (stringc(text, text), type(stringc(text, text)), control, type(control)))
            raise AssertionError

# Generated at 2022-06-23 13:51:16.876889
# Unit test for function colorize
def test_colorize():
    for clr in ('white', 'black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'lightgray'):
        res = colorize('VAR', 11, clr)
        print(res)
    for clr in ('darkgray', 'lightred', 'lightgreen', 'lightyellow', 'lightblue', 'lightmagenta', 'lightcyan', 'white'):
        res = colorize('VAR', 11, clr)
        print(res)



# Generated at 2022-06-23 13:51:22.588943
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('0') == '38;5;0'
    assert parsecolor('1') == '38;5;1'
    assert parsecolor('99') == '38;5;99'
    assert parsecolor('100') == '38;5;100'
    assert parsecolor('245') == '38;5;245'
    assert parsecolor('246') == '38;5;246'
    assert parsecolor('255') == '38;5;255'

    assert parsecolor('black') == '38;5;0'
    assert parsecolor('blue') == '38;5;4'
    assert parsecolor('green') == '38;5;2'
    assert parsecolor('cyan') == '38;5;6'

# Generated at 2022-06-23 13:51:32.935541
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u'localhost                       '
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost                       \x1b[0m'
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost                       \x1b[0m'
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost                       \x1b[0m'

# Generated at 2022-06-23 13:51:36.422405
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('Hello World!', 'green') == u'\033[32mHello World!\033[0m'


#
# --- end "pretty"
#



# Generated at 2022-06-23 13:51:46.709147
# Unit test for function parsecolor
def test_parsecolor():
    if not ANSIBLE_COLOR:
        return


# Generated at 2022-06-23 13:51:54.053980
# Unit test for function hostcolor
def test_hostcolor():
    s = "darkred on lightgray"
    expected = "\033[31m%-37s\033[0m" % s
    if sys.version_info[0] == 2:
        assert hostcolor(s, {}, True) == expected
    else:
        assert hostcolor(str(s), {}, True) == expected
# --- end "pretty"



# Generated at 2022-06-23 13:52:03.990776
# Unit test for function stringc
def test_stringc():
    """Test the string colorizing wrapper"""
    assert stringc('foo', 'black', True) == '\001\033[30m\002foo\001\033[0m\002'
    assert stringc('foo', 'red', True) == '\001\033[31m\002foo\001\033[0m\002'
    assert stringc('foo', 'green', True) == '\001\033[32m\002foo\001\033[0m\002'
    assert stringc('foo', 'yellow', True) == '\001\033[33m\002foo\001\033[0m\002'
    assert stringc('foo', 'blue', True) == '\001\033[34m\002foo\001\033[0m\002'

# Generated at 2022-06-23 13:52:08.709281
# Unit test for function stringc
def test_stringc():
    assert stringc('hello', 'blue') == u"\033[34mhello\033[0m"
    assert stringc('hello\nworld', 'blue') == u"\033[34mhello\033[0m\n\033[34mworld\033[0m"



# Generated at 2022-06-23 13:52:16.921632
# Unit test for function hostcolor

# Generated at 2022-06-23 13:52:24.823252
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 42
    color = 'blue'

    result = colorize(lead, num, color)
    print(result)

    # This should be u"\033[34mfoo=42\033[0m"
    # but it is u"foo=42"
    # since ANSIBLE_COLOR is False


# --- end "pretty"

# --- begin "api"

# plugin API for adding to callback_facts
# and for adding to display


# Generated at 2022-06-23 13:52:35.305870
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor, ANSIBLE_COLOR
    if ANSIBLE_COLOR:
        assert hostcolor("127.0.0.1", dict(failures=1, unreachable=0, changed=0)) == u"\033[31m127.0.0.1\033[0m      "
        assert hostcolor("127.0.0.1", dict(failures=0, unreachable=1, changed=0)) == u"\033[31m127.0.0.1\033[0m      "
        assert hostcolor("127.0.0.1", dict(failures=0, unreachable=0, changed=1)) == u"\033[33m127.0.0.1\033[0m      "

# Generated at 2022-06-23 13:52:46.238594
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, 'red') == u'foo=0   '
    assert colorize("foo", 0, None) == u'foo=0   '
    assert colorize("foo", 1, 'red') == u'foo=1   '
    assert colorize("foo", 2, 'red') == u'foo=2   '
    assert colorize("foo", 12, 'red') == u'foo=12  '
    assert colorize("foo", 123, 'red') == u'foo=123 '
    assert colorize("foo", 1234, 'red') == u'foo=1234'

# --- end "pretty"

# --- begin "pygments"


# Generated at 2022-06-23 13:52:54.007505
# Unit test for function stringc
def test_stringc():
    print()
    print("Testing stringc() - Colorized text string wrapper")
    print()
    for color in ('black', 'red', 'green', 'yellow', 'blue',
                  'magenta', 'cyan', 'white',
                  'bright black', 'bright red', 'bright green',
                  'bright yellow', 'bright blue', 'bright magenta',
                  'bright cyan', 'bright white',):
        print(stringc("Testing text in %s color" % color.upper(),
                      color=color))
    print()

# Generated at 2022-06-23 13:53:04.170191
# Unit test for function colorize
def test_colorize():
    def cmp_to_color(input_data, exp_return_code):
        # We need to capture the stdout to check the string
        try:
            from StringIO import StringIO
        except ImportError:
            from io import StringIO
        saved_stdout = sys.stdout
        try:
            out = StringIO()
            sys.stdout = out
            colorize(*input_data)
            output = out.getvalue().strip()
            assert output == exp_return_code
        finally:
            # restore stdout
            sys.stdout = saved_stdout
    # Valid Input

# Generated at 2022-06-23 13:53:14.896644
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor("red") == u'31')
    assert(parsecolor("RED") == u'31')
    assert(parsecolor("grEEN") == u'32')
    assert(parsecolor("green") == u'32')
    assert(parsecolor("black") == u'30')
    assert(parsecolor("blue") == u'34')
    assert(parsecolor("cyan") == u'36')
    assert(parsecolor("yellow") == u'33')
    assert(parsecolor("magenta") == u'35')
    assert(parsecolor("white") == u'37')
    assert(parsecolor("bg_white") == u'47')
    assert(parsecolor("bg_black") == u'40')

# Generated at 2022-06-23 13:53:22.698086
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('RED') == u'31'
    assert parsecolor('bold_red') == u'31;1'
    assert parsecolor('bold_RED') == u'31;1'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5') == u'38;5;5'
    assert parsecolor('color6') == u'38;5;6'

# Generated at 2022-06-23 13:53:31.967338
# Unit test for function stringc

# Generated at 2022-06-23 13:53:42.010620
# Unit test for function stringc
def test_stringc():
    assert stringc(u"hello", 'red') == u"\033[31mhello\033[0m"
    assert stringc(u"\n", 'bold') == u"\n"
    assert stringc(u"hello\n\nhello", 'blue') == u"\033[34mhello\033[0m\033[34m\n\nhello\033[0m"  # NOQA
    assert stringc(u"hello\n\nhello", 'blue', wrap_nonvisible_chars=True) == u"\001\033[34m\002hello\001\033[0m\002\001\033[34m\002\n\nhello\001\033[0m\002"  # NOQA