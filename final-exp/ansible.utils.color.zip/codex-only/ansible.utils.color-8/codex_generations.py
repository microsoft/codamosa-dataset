

# Generated at 2022-06-23 13:43:43.531523
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    # These tests require a terminal that can display 256 colors.
    # $ echo $TERM
    # screen-256color
    if sys.stdout.isatty():
        print(stringc('this is red', 'RED'))
        print(stringc('this is red', 'RED', wrap_nonvisible_chars=True))
        print(stringc('this is blue', 'BLUE'))
        print(stringc('this is blue', 'BLUE', wrap_nonvisible_chars=True))
        print(stringc('this is green', 'GREEN'))
        print(stringc('this is green', 'GREEN', wrap_nonvisible_chars=True))
        print(stringc('this is yellow', 'YELLOW'))

# Generated at 2022-06-23 13:43:52.403032
# Unit test for function stringc
def test_stringc():
    from ansible.compat.tests import unittest
    import sys

    class TestStringc(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_stringc(self):
            # The returned string must be unicode
            self.assertEqual(type(stringc("text", "green")), type(u""))
            self.assertEqual(stringc("text", "green"), u"\033[32mtext\033[0m")
            self.assertEqual(stringc("\ntext", "green"), u"\n\033[32mtext\033[0m")
            self.assertEqual(stringc("text\n", "green"), u"\033[32mtext\n\033[0m")

# Generated at 2022-06-23 13:44:03.294076
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('') == parsecolor('white') == C.COLOR_CODES['white']
    assert parsecolor('blue') == C.COLOR_CODES['blue']
    assert parsecolor('bold') == C.COLOR_CODES['bold']
    assert parsecolor('dark blue') == C.COLOR_CODES['dark blue']
    assert parsecolor('darkgray') == parsecolor('darkgrey') == C.COLOR_CODES['darkgray']
    assert parsecolor('green') == C.COLOR_CODES['green']
    assert parsecolor('light blue') == parsecolor('lightblue') == C.COLOR_CODES['light blue']
    assert parsecolor('light cyan') == parsecolor('lightcyan') == C.COLOR_CODES['light cyan']

# Generated at 2022-06-23 13:44:12.396623
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor_result = hostcolor(host='myhost', stats={'failures': 0,
                                                       'unreachable': 0,
                                                       'changed': 0})
    assert hostcolor_result == u'%-37s' % stringc('myhost', C.COLOR_OK)
    hostcolor_result = hostcolor(host='myhost', stats={'failures': 1,
                                                       'unreachable': 0,
                                                       'changed': 1})
    assert hostcolor_result == u'%-37s' % stringc('myhost', C.COLOR_CHANGED)
    hostcolor_result = hostcolor(host='myhost', stats={'failures': 0,
                                                       'unreachable': 1,
                                                       'changed': 1})

# Generated at 2022-06-23 13:44:24.409687
# Unit test for function parsecolor
def test_parsecolor():
    for color in ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white']:
        assert parsecolor(color) == C.COLOR_CODES[color]

    for x in range(0, 256):
        assert parsecolor("color%d" % x) == "38;5;%d" % x

    for color in ['rgb000', 'rgb123', 'rgb210', 'rgb321', 'rgb555']:
        assert parsecolor(color) == "38;5;%d" % (16 + 36 + 6 * int(color[3]) + int(color[4]))


# Generated at 2022-06-23 13:44:31.645264
# Unit test for function parsecolor
def test_parsecolor():
    """simple unit test for parsecolor"""
    def test_color(name, want):
        got = parsecolor(name)
        if got == want:
            return 'OK'
        return 'FAIL: got %s, want %s' % (got, want)
    print("%-9s %s" % ('gray8', test_color('gray8', '38;5;240')))
    print("%-9s %s" % ('color8', test_color('color8', '38;5;8')))
    print("%-9s %s" % ('rgb123', test_color('rgb123', '38;5;50')))
    print("%-9s %s" % ('green', test_color('green', '32')))

if __name__ == '__main__':
    test_parsec

# Generated at 2022-06-23 13:44:41.569887
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host=u"testhost", stats={'failures':0, 'unreachable':0, 'changed':0}) == (u"%-26s" % u"testhost")
    assert hostcolor(host=u"testhost", stats={'failures':1, 'unreachable':0, 'changed':0}) == u"%-37s" % stringc(u"testhost", C.COLOR_ERROR)
    assert hostcolor(host=u"testhost", stats={'failures':0, 'unreachable':1, 'changed':0}) == u"%-37s" % stringc(u"testhost", C.COLOR_ERROR)
    assert hostcolor(host=u"testhost", stats={'failures':0, 'unreachable':0, 'changed':1}) == u"%-37s" % stringc

# Generated at 2022-06-23 13:44:49.653159
# Unit test for function hostcolor
def test_hostcolor():
    # first test: no failures, no unreachable, no changed, colorize
    host = 'localhost'
    stats = {}
    assert hostcolor(host, stats) == u"\x1b[32mlocalhost               \x1b[0m"
    # second test: no failures, no unreachable, changed, colorize
    stats['changed'] = 1
    assert hostcolor(host, stats) == u"\x1b[33mlocalhost               \x1b[0m"
    # third test: failures, no unreachable, no changed, colorize
    stats = {'failures': 5}
    assert hostcolor(host, stats) == u"\x1b[31mlocalhost               \x1b[0m"
    # fourth test: no failures, unreachable, no changed, colorize

# Generated at 2022-06-23 13:44:56.353062
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello", "red", True))
    print(stringc("Hello", "red", False))
    print(stringc("Hello", "color33", True))
    print(stringc("Hello", "rgb123", True))
    print(stringc("Hello", "gray7", True))

if __name__ == "__main__":
    test_stringc()



# Generated at 2022-06-23 13:45:04.048062
# Unit test for function stringc

# Generated at 2022-06-23 13:45:07.359032
# Unit test for function colorize
def test_colorize():
    s = colorize("foo", 42, C.COLOR_ERROR)
    assert s == u"foo=42  "


# Generated at 2022-06-23 13:45:16.637094
# Unit test for function parsecolor
def test_parsecolor():
    if not ANSIBLE_COLOR:
        return

    assert parsecolor('black')  == u'38;5;0'
    assert parsecolor('red')    == u'38;5;1'
    assert parsecolor('green')  == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('blue')   == u'38;5;4'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('cyan')   == u'38;5;6'
    assert parsecolor('white')  == u'38;5;7'

    assert parsecolor('bright black')  == u'38;5;8'

# Generated at 2022-06-23 13:45:21.390505
# Unit test for function colorize
def test_colorize():
    print(u"colorize('>', 1, None) = %s" % colorize(u'>', 1, None))
    print(u"colorize('>', 0, C.COLOR_ERROR) = %s" % colorize(u'>', 0, C.COLOR_ERROR))
    print(u"colorize('>', 1, C.COLOR_ERROR) = %s" % colorize(u'>', 1, C.COLOR_ERROR))

# --- end "pretty"



# Generated at 2022-06-23 13:45:26.692437
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('hello', dict(changed=0, unreachable=0, failures=0)) == u'hello                    '
    assert hostcolor('hello', dict(changed=1, unreachable=0, failures=0)) == u'\n'.join(['\033[0;32mhello\033[0m'])
    assert hostcolor('hello', dict(changed=0, unreachable=1, failures=0)) == u'\n'.join(['\033[0;31mhello\033[0m'])



# Generated at 2022-06-23 13:45:31.854059
# Unit test for function colorize
def test_colorize():
    passed = colorize("passed", 0, "green")
    assert passed == "passed=0   "

    failed = colorize("failed", 42, "red")
    assert failed == u"\u001b[31mfailed=42  \u001b[0m"


# Generated at 2022-06-23 13:45:41.991314
# Unit test for function stringc
def test_stringc():
    assert stringc('This is black', 'black') == '\033[30mThis is black\033[0m'
    assert stringc('This is red', 'red') == '\033[31mThis is red\033[0m'
    assert stringc('This is green', 'green') == '\033[32mThis is green\033[0m'
    assert stringc('This is yellow', 'yellow') == '\033[33mThis is yellow\033[0m'
    assert stringc('This is blue', 'blue') == '\033[34mThis is blue\033[0m'
    assert stringc('This is magenta', 'magenta') == '\033[35mThis is magenta\033[0m'

# Generated at 2022-06-23 13:45:47.683100
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('white') == '97'
    assert parsecolor('blue') == '34'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('rgb255125') == '38;5;208'
    assert parsecolor('gray8') == '38;5;244'



# Generated at 2022-06-23 13:45:51.831504
# Unit test for function colorize
def test_colorize():
    assert colorize("foo:", 22, 'blue') == 'foo=22  '
    assert colorize("foo: ", 22, 'blue') == 'foo: 22 '
    assert colorize("foo: ", 2, 'blue') == 'foo: 2  '



# Generated at 2022-06-23 13:46:00.629017
# Unit test for function hostcolor
def test_hostcolor():
    assert "%-26s" % "localhost" == hostcolor("localhost", dict(changed=0, failures=0, unreachable=0, ok=1))
    assert "%-26s" % stringc("localhost", C.COLOR_ERROR) == hostcolor("localhost", dict(changed=0, failures=1, unreachable=0, ok=0))
    assert "%-26s" % stringc("localhost", C.COLOR_CHANGED) == hostcolor("localhost", dict(changed=1, failures=0, unreachable=0, ok=0))



# Generated at 2022-06-23 13:46:08.062547
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('bold') == '1'
    assert parsecolor('on_red') == '41'
    assert parsecolor('on_bold') == '1'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('rgb255255255') == '38;5;15'
    assert parsecolor('rgb101010') == '38;5;16'
    assert parsecolor('rgb5255255') == '38;5;118'
    assert parsecolor('rgb5255') == '38;5;112'
    assert parsecolor('rgb255') == '38;5;208'
    assert parsecolor('rgb000') == '38;5;8'
    assert parsecolor

# Generated at 2022-06-23 13:46:20.084946
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'green') == u'\033[32mtest\033[0m'
    assert stringc(u'test', 'green') == u'\033[32mtest\033[0m'
    assert stringc(u'tést', 'green') == u'\033[32mt\xe9st\033[0m'
    assert stringc(u'tést', 'green', wrap_nonvisible_chars=True) == u'\001\033[32m\002t\xe9st\001\033[0m\002'
    assert stringc('color16', 'color16') == u'\033[38;5;16mcolor16\033[0m'

# Generated at 2022-06-23 13:46:29.943808
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', 'red')
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', 'red')
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', 'yellow')
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', 'green')
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'%-37s' % stringc('localhost', 'red')

# Generated at 2022-06-23 13:46:40.296260
# Unit test for function parsecolor
def test_parsecolor():
    import json
    import os
    import sys
    import tempfile

    tmpfile = tempfile.NamedTemporaryFile(mode='r+b')
    colors = {}
    colors['color'] = u'\u001b[38;5;%;dm'
    colors['rgb']   = u'\u001b[38;5;%;dm'
    colors['gray']  = u'\u001b[38;5;%;dm'

    colors_json = json.dumps(colors)
    tmpfile.write(colors_json.encode('utf-8'))
    tmpfile.seek(0)
    os.environ['ANSIBLE_COLOR_PLUGIN_COLORS'] = tmpfile.name


# Generated at 2022-06-23 13:46:47.871111
# Unit test for function hostcolor
def test_hostcolor():
    # Test trivial, always 'green' case
    assert hostcolor('foo', {}) == '%-26s' % 'foo'

    # Test trivial, always 'red' case
    assert hostcolor('foo', {'failures' : 1, 'unreachable' : 0}) == '%-26s' % stringc('foo', 'RED')
    assert hostcolor('foo', {'failures' : 0, 'unreachable' : 1}) == '%-26s' % stringc('foo', 'RED')

    # Test trivial, always 'yellow' case
    assert hostcolor('foo', {'failures' : 0, 'unreachable' : 0, 'changed' : 1}) == '%-26s' % stringc('foo', 'YELLOW')

    # Test fallback, non-trivial case

# Generated at 2022-06-23 13:46:49.022601
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'white') == '\033[37mtest\033[0m'

# Generated at 2022-06-23 13:46:56.297416
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        return True
    assert colorize(u"foo", 0, u"green") == u"foo=0   "
    assert colorize(u"foo", 0, u"red") == u"foo=0   "
    assert colorize(u"foo", 1, u"green") == u"\033[0;32mfoo=1   \033[0m"
    assert colorize(u"foo", 2, u"red") == u"\033[0;31mfoo=2   \033[0m"



# Generated at 2022-06-23 13:47:03.388712
# Unit test for function colorize
def test_colorize():
    for i in range(0, 8):
        for j in range(0, 8):
            for k in range(0, 8):
                val = 16 + i * 36 + j * 6 + k
                cval = u'38;5;%d' % val
                assert parsecolor(u'rgb%d%d%d' % (i, j, k)) == cval,\
                    'rgb%d%d%d: %s != %s' % (i, j, k,
                                             parsecolor(u'rgb%d%d%d' % (i, j, k)),
                                             cval)

# Generated at 2022-06-23 13:47:13.960602
# Unit test for function colorize
def test_colorize():
    # setup
    lead = 'test'
    num = 3
    goodcolor = C.COLOR_OK
    badcolor = C.COLOR_ERROR
    # test success
    color = colorize(lead, num, goodcolor)
    expected = '%s=%-4s' % (lead, str(num))
    assert color == expected
    # test failure
    color = colorize(lead, num, badcolor)
    expected = '%s=%-4s' % (lead, str(num))
    assert color == expected
    # test empty
    color = colorize(lead, 0, badcolor)
    expected = '%s=%-4s' % (lead, str(num))
    assert color == expected
    # test none
    color = colorize(lead, num, None)

# Generated at 2022-06-23 13:47:24.712398
# Unit test for function colorize
def test_colorize():
    """ Unit test for function colorize
        calls function with various inputs
        and compares results with expected output
    """
    import pprint
    lead = u"testlead"
    num = 1
    color = "yellow"
    res = colorize(lead, num, color)
    exp = u"testlead=1   "
    try:
        assert res == exp
        print("colorize test1 [ok]")
    except AssertionError:
        print("colorize test1 [failed]")
        print("result: %s" % pprint.PrettyPrinter(indent=4).pformat(res))
        print("expected: %s" % pprint.PrettyPrinter(indent=4).pformat(exp))

    lead = u"testlead"
    num = 20
    color = "yellow"
    res = color

# Generated at 2022-06-23 13:47:35.488377
# Unit test for function stringc
def test_stringc():
    a = u''
    b = u'This is a test'
    c = u'This\nIs\na\nTest'

    try:
        parsecolor('black')
    except Exception:
        print(u'Error in parsecolor()')


# Generated at 2022-06-23 13:47:47.374663
# Unit test for function parsecolor
def test_parsecolor():
    import json

    def _t(name, expected):
        got = parsecolor(name)
        if got != expected:
            sys.stderr.write("expected %s, got %s\n" % (json.dumps(expected), json.dumps(got)))
            return False
        return True

    code(31, lambda: _t("red", u"31"))
    code(32, lambda: _t("color1", u"38;5;1"))
    code(33, lambda: _t("rgb123", u"38;5;18"))
    code(34, lambda: _t("rgb245", u"38;5;53"))
    code(35, lambda: _t("rgb555", u"38;5;231"))

# Generated at 2022-06-23 13:47:59.628925
# Unit test for function parsecolor
def test_parsecolor():
    assert (
        parsecolor('red') == parsecolor('color1') == parsecolor('rgb500') == '31'
    )
    assert (
        parsecolor('green') == parsecolor('color2') == parsecolor('rgb050') == '32'
    )
    assert (
        parsecolor('yellow') == parsecolor('color3') == parsecolor('rgb550') == '33'
    )
    assert (
        parsecolor('blue') == parsecolor('color4') == parsecolor('rgb005') == '34'
    )
    assert (
        parsecolor('magenta') == parsecolor('color5') == parsecolor('rgb505') == '35'
    )

# Generated at 2022-06-23 13:48:10.775835
# Unit test for function stringc
def test_stringc():
    """Automated test for function stringc."""
    if not ANSIBLE_COLOR:
        return True
    import curses
    curses.setupterm()
    # C.COLOR_CODES is a dict whose keys are ANSIBLE_COLOR_* constants
    for color_name, color_code in C.COLOR_CODES.items():
        color_code_str = parsecolor(color_name)
        example_str = stringc(color_name, color_name)
        assert example_str == u"\033[%sm%s\033[0m" % (color_code_str, color_name)
    # Try all the answers to the question
    # "How many colors does `curses.tigetnum('colors')` return?"
    # (at the time of this writing, it can return -1, 8

# Generated at 2022-06-23 13:48:16.126707
# Unit test for function hostcolor
def test_hostcolor():
    stats_good = dict(
        ok=10,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )
    assert hostcolor('example.com', stats_good, True) == u'%-37s' % stringc('example.com', C.COLOR_OK)
    stats_bad = dict(
        ok=0,
        failures=1,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )
    assert hostcolor('example.com', stats_bad, True) == u'%-37s' % stringc('example.com', C.COLOR_ERROR)

# Generated at 2022-06-23 13:48:25.419090
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), False) == u'localhost              ')
    assert(hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), False) == u'localhost              ')
    assert(hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), False) == u'localhost              ')
    assert(hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), False) == u'localhost              ')

    assert(hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'localhost              ')

# Generated at 2022-06-23 13:48:36.124481
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('hostname.example.com', {'ok': 1, 'failures': 0, 'changed': 0, 'unreachable': 0}, False) == \
        u'hostname.example.com             '
    assert hostcolor('hostname.example.com', {'ok': 1, 'failures': 0, 'changed': 0, 'unreachable': 0}, True) == \
        u'\x1b[32m\x1b[0mhostname.example.com\x1b[0m  '
    assert hostcolor('hostname.example.com', {'ok': 0, 'failures': 1, 'changed': 0, 'unreachable': 0}, False) == \
        u'hostname.example.com             '

# Generated at 2022-06-23 13:48:41.329867
# Unit test for function stringc
def test_stringc():
    from ansible.module_utils.six import StringIO
    save_stdout = sys.stdout
    try:
        sys.stdout = StringIO()
        colorcode = parsecolor('black')
        out = stringc('stringc', 'black', wrap_nonvisible_chars=True)
        assert out == u'\x01\x1b[%sm\x02stringc\x01\x1b[0m\x02' % colorcode
    finally:
        sys.stdout = save_stdout


# Generated at 2022-06-23 13:48:53.841294
# Unit test for function parsecolor
def test_parsecolor():
    """ Unit tests for function parsecolor """
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('darkgray') == u'38;5;250'
    assert parsecolor('blue') == u'38;5;21'
    assert parsecolor('lightblue') == u'38;5;39'
    assert parsecolor('green') == u'38;5;34'
    assert parsecolor('lightgreen') == u'38;5;100'
    assert parsecolor('cyan') == u'38;5;51'
    assert parsecolor('lightcyan') == u'38;5;127'
    assert parsecolor('red') == u'38;5;124'
    assert parsecolor('lightred') == u'38;5;202'
   

# Generated at 2022-06-23 13:48:59.285765
# Unit test for function stringc
def test_stringc():
    assert stringc(u"test", u"blue") == u"\033[34mtest\033[0m"
    assert stringc(u"\ntest\n", u"blue") == u"\033[34m\ntest\n\033[0m"
    assert stringc(u"\ntest\ntest\n", u"blue") == u"\033[34m\ntest\ntest\n\033[0m"


# Generated at 2022-06-23 13:49:07.019419
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('blue') == '34'
    assert parsecolor('1') == '38;5;1'
    assert parsecolor('250') == '38;5;250'
    assert parsecolor('rgb123') == '38;5;133'
    assert parsecolor('rgb112') == '38;5;131'
    assert parsecolor('gray1') == '38;5;232'
    assert parsecolor('gray24') == '38;5;250'

# Generated at 2022-06-23 13:49:13.424571
# Unit test for function stringc
def test_stringc():
    # (text, color, wrap_nonvisible_chars, expected)
    cases = [
        (u'foo', 'red', False, u'\033[31mfoo\033[0m'),
        (u'\033[1mbar\033[0m', 'red', False, u'\033[31m\033[1mbar\033[0m\033[0m'),
        (u'foo\nbar', 'red', False, u'\033[31mfoo\nbar\033[0m'),
        (u'foo\nbar', 'red', True, u'\001\033[31m\002foo\nbar\001\033[0m\002'),
    ]

# Generated at 2022-06-23 13:49:23.525696
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', {'failures': 0, 'unreachable': 0, 'ok': 0, 'changed': 0, 'skipped': 0}, True) == 'foo'
    assert hostcolor('foo', {'failures': 1, 'unreachable': 1, 'ok': 0, 'changed': 0, 'skipped': 0}, True) == 'foo'
    assert hostcolor('foo', {'failures': 0, 'unreachable': 0, 'ok': 0, 'changed': 1, 'skipped': 0}, True) == 'foo'
    assert hostcolor('foo', {'failures': 0, 'unreachable': 0, 'ok': 1, 'changed': 0, 'skipped': 0}, True) == 'foo'


# Generated at 2022-06-23 13:49:32.426043
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('color16') == u'38;5;16'
    assert parsecolor('red') == u'38;5;196'
    assert parsecolor('rgb255000255') == u'38;5;201'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb255000000') == u'38;5;196'
    assert parsecolor('rgb0255000') == u'38;5;34'
    assert parsecolor('rgb0255255') == u'38;5;39'
    assert parsecolor('rgb0255000000') == u'38;5;196'

# Generated at 2022-06-23 13:49:43.319091
# Unit test for function colorize
def test_colorize():
    """Functional tests for function colorize"""
    assert colorize(u"test", 0, u"blue") == u"test=0   ", \
        colorize(u"test", 0, u"blue")
    assert colorize(u"test", 20, u"blue") == u"test=20  ", \
        colorize(u"test", 20, u"blue")
    assert colorize(u"test", 256, u"blue") == u"test=256 ", \
        colorize(u"test", 256, u"blue")
    assert colorize(u"test", 1024, u"blue") == u"test=1024", \
        colorize(u"test", 1024, u"blue")
    print(u"All tests successful for function colorize")

# Generated at 2022-06-23 13:49:50.676182
# Unit test for function stringc
def test_stringc():
    """Test stringc."""

    class AssertInvisible(Exception):
        pass

    class AssertInvisibleCheck(object):

        def __enter__(self):
            pass

        def __exit__(self, exc_type, exc_value, traceback):
            if exc_type == AssertInvisible:
                return True

    def assert_invisible(cond):
        if not cond:
            raise AssertInvisible()

    def test(text, color, *args):
        """Simple test for stringc."""

        if len(args) > 0:
            s = stringc(text, color, *args)

# Generated at 2022-06-23 13:49:59.230550
# Unit test for function colorize
def test_colorize():
    ''' colorize() unit test'''

    from ansible.utils.color import colorize, stringc
    from ansible import constants as C

    # Set Colors to always, so the tests will always run even if the user has
    # disabled colors in their environment.
    C.ANSIBLE_FORCE_COLOR = True

    # Test with different colors and values
    assert "\033[31m=1   \033[0m" == stringc("=1", "RED")
    assert "\033[31m-=1  \033[0m" == stringc("-=1", "RED")
    assert "\033[32m+=0  \033[0m" == stringc("+=0", "GREEN")
    assert "\033[32m+=-1 \033[0m" == stringc("+=-1", "GREEN")

# Generated at 2022-06-23 13:50:07.172948
# Unit test for function colorize
def test_colorize():
    # Colorize function doesn't test for color support
    # so I've put a try/except here to handle it.
    try:
        # Set up a test where the failure is greater
        # than the changed but less than unreachable.
        test_lead = 'test lead'
        test_num = 4
        test_color = C.COLOR_ERROR
        assert colorize(test_lead, test_num, test_color) == test_lead
        test_num = 3
        assert colorize(test_lead, test_num, test_color) != test_lead
    except AssertionError:
        # This will catch the error and give the
        # error message to unittest
        raise


# --- end "pretty"



# Generated at 2022-06-23 13:50:10.968176
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('foo', 'bold') == u'\033[1mfoo\033[0m'
    else:
        assert stringc('foo', 'bold') == u'foo'


# --- end "pretty"



# Generated at 2022-06-23 13:50:21.294464
# Unit test for function colorize
def test_colorize():
    lead = "test_lead"
    num = 1
    color = "blue"
    ret = u"test_lead=1   "
    assert colorize(lead, num, color) == ret
    # False should be equivalent to None
    assert colorize(lead, num, False) == ret
    assert colorize(lead, num, None) == ret
    # It should colorize when ANSIBLE_COLOR is True
    assert colorize(lead, num, color) == stringc(ret,color)
    # It should not colorize when ANSIBLE_COLOR is False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize(lead, num, color) != stringc(ret,color)
    ANSIBLE_COLOR = True


# Generated at 2022-06-23 13:50:33.628794
# Unit test for function parsecolor
def test_parsecolor():
    print(stringc(parsecolor('rgb123'), 'rgb123') + ' ' + stringc(parsecolor('rgb111'), 'rgb111'))  # yellow

    print(stringc(parsecolor('rgb222'), 'rgb222') + ' ' + stringc(parsecolor('rgb121'), 'rgb121'))  # green

    print(stringc(parsecolor('rgb333'), 'rgb333') + ' ' + stringc(parsecolor('rgb211'), 'rgb211'))  # red

    print(stringc(parsecolor('rgb432'), 'rgb432') + ' ' + stringc(parsecolor('rgb321'), 'rgb321'))  # blue


# Generated at 2022-06-23 13:50:37.951995
# Unit test for function parsecolor
def test_parsecolor():
    if parsecolor('blue') != u'34':
        raise Exception()
    if parsecolor('bold') != u'1':
        raise Exception()
    if parsecolor('blink') != u'5':
        raise Exception()
    if parsecolor('underline') != u'4':
        raise Exception()
    if parsecolor('red') != u'31':
        raise Exception()
    if parsecolor('on_red') != u'41':
        raise Exception()
    if parsecolor('red_background') != u'41':
        raise Exception()

    if parsecolor('random') != u'38;5;208':
        raise Exception()

    if parsecolor('color8') != u'38;5;8':
        raise Exception()

# Generated at 2022-06-23 13:50:49.308766
# Unit test for function parsecolor
def test_parsecolor():
    # test some basic colors
    assert parsecolor("black") == u'30'
    assert parsecolor("white") == u'37'
    assert parsecolor("blue") == u'34'
    # test some extended colors
    assert parsecolor("color3") == u'38;5;3'
    assert parsecolor("rgb223") == u'38;5;45'
    assert parsecolor("rgb332") == u'38;5;111'
    assert parsecolor("rgb051") == u'38;5;40'
    # test some grayscale colors
    assert parsecolor("gray22") == u'38;5;244'
    assert parsecolor("gray0") == u'38;5;235'

# Generated at 2022-06-23 13:50:53.891303
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        # Check that a known color is interpreted correctly.
        assert(parsecolor('red') == u'38;5;9')
        # Check that an invalid color name is not changed.
        assert(parsecolor('nocolor') == 'nocolor')



# Generated at 2022-06-23 13:51:04.276855
# Unit test for function stringc
def test_stringc():
    def test(text, color, wrap_nonvisible_chars=False):
        ret = stringc(text, color, wrap_nonvisible_chars)
        if ret != "\n".join(C.EXPECTED_LINES[text][color]):
            print("Expected:\n%s\nGot:\n%s" % ("\n".join(C.EXPECTED_LINES[text][color]), ret))
            sys.exit(1)
    for text in C.EXPECTED_LINES:
        for color in C.EXPECTED_LINES[text]:
            yield test, text, color, True
            yield test, text, color, False


# Generated at 2022-06-23 13:51:16.322626
# Unit test for function hostcolor
def test_hostcolor():
    # color = True
    host = 'myhost'
    stats = dict()
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    colorized_string = hostcolor(host, stats)
    assert colorized_string == u'%-26s' % (stringc(host, C.COLOR_OK))
    stats['failures'] = 1
    colorized_string = hostcolor(host, stats)
    assert colorized_string == u'%-26s' % (stringc(host, C.COLOR_ERROR))
    stats['failures'] = 0
    stats['unreachable'] = 1
    colorized_string = hostcolor(host, stats)
    assert colorized_string == u'%-26s' % (stringc(host, C.COLOR_ERROR))
   

# Generated at 2022-06-23 13:51:29.335292
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('color1') == '38;5;1')
    assert(parsecolor('color2') == '38;5;2')
    assert(parsecolor('color3') == '38;5;3')
    assert(parsecolor('color4') == '38;5;4')
    assert(parsecolor('color5') == '38;5;5')
    assert(parsecolor('color6') == '38;5;6')
    assert(parsecolor('color7') == '38;5;7')
    assert(parsecolor('color8') == '38;5;8')
    assert(parsecolor('color9') == '38;5;9')
    assert(parsecolor('color10') == '38;5;10')

# Generated at 2022-06-23 13:51:40.813858
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc("test", 'null') == u"\x1b[00;00mtest\x1b[00m"
        assert stringc("test", 'black') == u"\x1b[00;30mtest\x1b[00m"
        assert stringc("test", 'red') == u"\x1b[00;31mtest\x1b[00m"
        assert stringc("test", 'green') == u"\x1b[00;32mtest\x1b[00m"
        assert stringc("test", 'yellow') == u"\x1b[00;33mtest\x1b[00m"

# Generated at 2022-06-23 13:51:49.713486
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert(parsecolor(u"red") == u"31")
        assert(parsecolor(u"green") == u"32")
        assert(parsecolor(u"yellow") == u"33")
        assert(parsecolor(u"blue") == u"34")
        assert(parsecolor(u"magenta") == u"35")
        assert(parsecolor(u"cyan") == u"36")
        assert(parsecolor(u"white") == u"37")
        assert(parsecolor(u"black") == u"30")
        assert(parsecolor(u"color1") == u"38;5;1")
        assert(parsecolor(u"color2") == u"38;5;2")

# Generated at 2022-06-23 13:52:00.623736
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u"foo=0   "
    assert colorize('foo', 0, None) == u"foo=0   "
    assert colorize('foo', 1, 'blue') == u"foo=1   "
    assert colorize('foo', 2, 'blue') == u"foo=2   "
    assert colorize('foo', 123, 'blue') == u"foo=123 "
    assert colorize('foo', 1234, 'blue') == u"foo=1234"
    assert colorize('f' * 50, 1234, 'blue') == u"foo=1234"
    assert colorize('f' * 100, 1234, 'blue') == u"foo=1234"

# Generated at 2022-06-23 13:52:02.458902
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'



# Generated at 2022-06-23 13:52:13.360938
# Unit test for function colorize
def test_colorize():
    # Color codes were tested against those from
    # https://github.com/chrisopedia/ansi-colors
    assert colorize('ok', 0, C.COLOR_OK) == stringc('ok=0', C.COLOR_OK)
    assert colorize('changed', 0, C.COLOR_CHANGED) == stringc('changed=0', C.COLOR_CHANGED)
    assert colorize('unreachable', 0, C.COLOR_UNREACHABLE) == stringc('unreachable=0', C.COLOR_UNREACHABLE)
    assert colorize('failed', 0, C.COLOR_ERROR) == stringc('failed=0', C.COLOR_ERROR)
    assert colorize('skipped', 0, C.COLOR_SKIP) == stringc('skipped=0', C.COLOR_SKIP)

# Generated at 2022-06-23 13:52:25.759109
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('ok.example.com', {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == u'%-26s' % stringc('ok.example.com', C.COLOR_OK)
    assert hostcolor('changed.example.com', {'failures': 0, 'unreachable': 0, 'changed': 1}, True) == u'%-37s' % stringc('changed.example.com', C.COLOR_CHANGED)
    assert hostcolor('failed.example.com', {'failures': 1, 'unreachable': 0, 'changed': 0}, True) == u'%-37s' % stringc('failed.example.com', C.COLOR_ERROR)

# Generated at 2022-06-23 13:52:35.732337
# Unit test for function colorize
def test_colorize():
    """ Basic tests for function colorize """
    assert colorize('ok', 0, None) == 'ok=0   '
    assert colorize('changed', 0, None) == 'changed=0   '
    assert colorize('failed', 0, None) == 'failed=0   '
    assert colorize('unreachable', 0, None) == 'unreachable=0 '

    # Check that colorize() works well when ANSIBLE_COLOR is set to False.

# Generated at 2022-06-23 13:52:46.519965
# Unit test for function hostcolor
def test_hostcolor():
    """PrettyPrintTest - test host color formatting."""
    pp = PrettyPrint()

    # No failures, no changes, not unreachable
    print(pp.hostcolor('spam', dict(failures=0, unreachable=0, changed=0)))

    # No failures, no changes, unreachable
    print(pp.hostcolor('spam', dict(failures=0, unreachable=5, changed=0)))

    # No failures, changes, not unreachable
    print(pp.hostcolor('spam', dict(failures=0, unreachable=0, changed=5)))

    # No failures, changes, unreachable
    print(pp.hostcolor('spam', dict(failures=0, unreachable=5, changed=5)))

    # Failures, no changes, not unreachable

# Generated at 2022-06-23 13:52:49.456859
# Unit test for function stringc
def test_stringc():
    print(stringc("test", "red"))
    print(stringc("test", "red", wrap_nonvisible_chars=True))



# Generated at 2022-06-23 13:53:00.530264
# Unit test for function hostcolor
def test_hostcolor():
    host = u'127.0.0.1'
    if hostcolor(host, dict(failures=0, unreachable=0, changed=0)) != u'%-37s' % host:
        print(u"failed 1")
        sys.exit(1)
    if hostcolor(host, dict(failures=1, unreachable=0, changed=0)) != u'%-37s' % stringc(host, 'red'):
        print(u"failed 2")
        sys.exit(1)
    if hostcolor(host, dict(failures=0, unreachable=1, changed=0)) != u'%-37s' % stringc(host, 'red'):
        print(u"failed 3")
        sys.exit(1)

# Generated at 2022-06-23 13:53:08.295796
# Unit test for function colorize
def test_colorize():
    # Needed for the function to function
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # Test all the colors
    for color in C.COLOR_CODES:
        # Compare the output of colorize to that of stringc
        assert colorize("lead", 1, color) == stringc("lead=1   ", color)

    # Make sure it doesn't barf on bad inputs
    assert colorize("lead", 1, None) == "lead=1   "
    assert colorize("lead", 1, "not_a_color") == "lead=1   "

    # Test the 0 case
    assert colorize("lead", 0, "white") == "lead=0   "

    # Restore the initial value
    ANSIBLE_COLOR = False



# Generated at 2022-06-23 13:53:18.394826
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        print(u"Printing a bunch of color combinations. If nothing is printed, the terminal doesn't support color")

        print(u"\nTest normal color names. These should have different colors:")
        for i in range(1, 100):
            print(stringc(u"%2d" % i, str(i - 1)))
        print(u"\nTest color 0, color 1 and color 255. These should be all the same:")
        print(stringc(u'color 0', '0'))
        print(stringc(u'color 1', '1'))
        print(stringc(u'color 255', '255'))

        print(u"\nTest gray. These should have different shades of gray:")

# Generated at 2022-06-23 13:53:29.723101
# Unit test for function colorize
def test_colorize():
    ''' hostcolor returns the correct value '''

    # Model of single task result
    task_result = {
        'stat': {
            'changed': 0,
            'dark': 0,
            'failures': 0,
            'ok': 0,
            'processed': 0,
            'rescued': 0,
            'skipped': 0,
            'ignored': 0,
            'unreachable': 0
        }
    }

    # Test all colorize cases
    for key in task_result['stat']:
        task_result['stat'][key] = 1
        for color in [C.COLOR_ERROR, C.COLOR_CHANGED, C.COLOR_OK, C.COLOR_SKIP]:
            c = colorize('', task_result['stat'][key], color)
            assert c
           

# Generated at 2022-06-23 13:53:37.829695
# Unit test for function stringc
def test_stringc():
    class FakeStream(object):
        def __init__(self):
            self.is_a_tty = False

    saved_stream = sys.stdout
    sys.stdout = FakeStream()