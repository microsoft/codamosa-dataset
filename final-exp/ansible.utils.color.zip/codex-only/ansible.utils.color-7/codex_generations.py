

# Generated at 2022-06-23 13:43:45.051312
# Unit test for function stringc
def test_stringc():
    text = 'world'
    color = 'green'
    assert '\033[0mworld\033[0m' == stringc(text, None)
    assert '\033[0m\033[32mworld\033[0m\033[0m' == stringc(text, color)
    assert '\033[0m\033[32mwo\033[0m\033[0mrld\033[0m\033[0m' == stringc(text, color, True)
    assert '\033[0m\033[32m\001\033[0m\033[32mw\033[32mo\033[32m\002\033[32m\001\033[32m\002\033[32mrld\033[0m' == stringc(text, color, True)

# --- end "

# Generated at 2022-06-23 13:43:49.562538
# Unit test for function colorize
def test_colorize():
    from ansible.utils.color import colorize
    assert(colorize("test", "Test", "blue") == u"\n".join([u"\033[94mtest=Test\033[0m"]))
    assert(colorize("test", "\"Test\"", "blue") == u"\n".join([u"\033[94mtest=\"Test\"\033[0m"]))

# end pretty



# Generated at 2022-06-23 13:43:57.874207
# Unit test for function colorize
def test_colorize():
    def c(lead, num, color):
        """local print analogue"""
        print(colorize(lead, num, color))

    print('Colors should be as follows:')
    c('+', 5, C.COLOR_CHANGED)
    c('+', 0, C.COLOR_CHANGED)
    c('>', 5, C.COLOR_OK)
    c('>', 0, C.COLOR_OK)

# Generated at 2022-06-23 13:44:03.034934
# Unit test for function stringc
def test_stringc():
    # Postive test
    text = "This is a string."
    assert stringc(text, "black") == u"\033[30m%s\033[0m" % text
    assert stringc(text, C.COLOR_OK) == u"\033[32m%s\033[0m" % text
    assert stringc(text, C.COLOR_WARN) == u"\033[33m%s\033[0m" % text
    assert stringc(text, C.COLOR_ERROR) == u"\033[31m%s\033[0m" % text
    # Negative test
    assert stringc(text, "foobar") == text
    # Testing wrap_nonvisible_chars param

# Generated at 2022-06-23 13:44:10.070620
# Unit test for function parsecolor
def test_parsecolor():
    color = parsecolor("green")
    print(color)
    color = parsecolor("color8")
    print(color)
    color = parsecolor("color8")
    print(color)
    color = parsecolor("rgb255")
    print(color)
    color = parsecolor("rgb255255255")
    print(color)
    color = parsecolor("rgb255255")
    print(color)
    color = parsecolor("rgb2552550")
    print(color)
    color = parsecolor("rgb0255255")
    print(color)
    color = parsecolor("rgb255255255")
    print(color)
    color = parsecolor("rgb255255255")
    print(color)


# Generated at 2022-06-23 13:44:16.417674
# Unit test for function parsecolor
def test_parsecolor():
    print(u"[?] Testing parsecolor()...")
    assert parsecolor(u'black') == u'30'
    assert parsecolor(u'red') == u'31'
    assert parsecolor(u'green') == u'32'
    assert parsecolor(u'yellow') == u'33'
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'purple') == u'35'
    assert parsecolor(u'cyan') == u'36'
    assert parsecolor(u'white') == u'37'
    assert parsecolor(u'color0') == u'38;5;0'
    assert parsecolor(u'color1') == u'38;5;1'
    assert parsecolor(u'color2') == u

# Generated at 2022-06-23 13:44:22.828660
# Unit test for function colorize
def test_colorize():
    assert stringc("foo", "green") == u'\033[32mfoo\033[0m'
    assert stringc("foo", "green", True) == u'\001\033[32m\002foo\001\033[0m\002'
    assert stringc("foo\nbar", "green", True) == u'\001\033[32m\002foo\nbar\001\033[0m\002'


# Generated at 2022-06-23 13:44:30.840939
# Unit test for function parsecolor
def test_parsecolor():
    # Test standard colors
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'

    # Test color literals
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('rgb333') == u'38;5;63'
    assert parsecolor('gray0') == u'38;5;232'

# Generated at 2022-06-23 13:44:40.930029
# Unit test for function parsecolor
def test_parsecolor():
    import collections
    import random
    TestCase = collections.namedtuple('TestCase', ['name', 'value'])
    tests = [TestCase('green', '32'),
             TestCase('Color1', '38;5;1'),
             TestCase('rgb255252240', '38;5;231'),
             TestCase('gray0', '38;5;232'),
             TestCase('noSuchColor', '')]
    for test in tests:
        assert parsecolor(test.name) == test.value

    # Test that rgb color codes have been generated correctly
    for i in range(16):
        red = i // 36
        green = i // 6 % 6
        blue = i % 6
        assert parsecolor('rgb%d%d%d' % (red, green, blue)) == '38;5;%d'

# Generated at 2022-06-23 13:44:50.787346
# Unit test for function stringc
def test_stringc():
    # Syntax error
    try:
        stringc('Hello, world!', 'red', 'anything')
        assert False
    except TypeError:
        assert True

    # Good usage
    assert stringc('Hello, world!', 'red') == u"\033[31mHello, world!\033[0m"
    assert stringc('Hello, world!', 'green') == u"\033[32mHello, world!\033[0m"
    assert stringc('Hello, world!', 'blue') == u"\033[34mHello, world!\033[0m"
    assert stringc('Hello, world!', 'bright white') == u"\033[97mHello, world!\033[0m"

    # No color
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert string

# Generated at 2022-06-23 13:44:56.868843
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"test.example.org", {'failures': 0, 'unreachable': 0, 'changed': 0}) == u"test.example.org            "
    assert hostcolor(u"test.example.org", {'failures': 1, 'unreachable': 0, 'changed': 0}) == u"test.example.org            "
    assert hostcolor(u"test.example.org", {'failures': 0, 'unreachable': 1, 'changed': 0}) == u"test.example.org            "
    assert hostcolor(u"test.example.org", {'failures': 0, 'unreachable': 0, 'changed': 1}) == u"test.example.org            "

# Generated at 2022-06-23 13:45:04.173325
# Unit test for function hostcolor
def test_hostcolor():
    # Tests with ANSIBLE_COLOR = True
    # Test 1: no stats
    host = "example.com"
    stats = dict(changed=0, failures=0, unreachable=0, ok=0)
    print("(" + hostcolor(host, stats, True) + ")")
    # Test 2: failures
    stats = dict(changed=0, failures=1, unreachable=0, ok=0)
    print("(" + hostcolor(host, stats, True) + ")")
    # Test 3: unreachable
    stats = dict(changed=0, failures=0, unreachable=1, ok=0)
    print("(" + hostcolor(host, stats, True) + ")")
    # Test 4: changed
    stats = dict(changed=1, failures=0, unreachable=0, ok=0)

# Generated at 2022-06-23 13:45:15.349046
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = dict(
        ok=1,
        failures=0,
        unreachable=0,
        changed=0,
        skipped=0,
        rescued=0,
        ignored=0
    )
    # Given ANSIBLE_COLOR=0, the hostcolor should return a string with length 26.
    ANSIBLE_COLOR = False
    assert len(hostcolor(host, stats, color=True)) == 26
    assert len(hostcolor(host, stats, color=False)) == 26

    # Given ANSIBLE_COLOR=1, but color=False, the hostcolor should return a string with length 26.
    ANSIBLE_COLOR = True
    assert len(hostcolor(host, stats, color=False)) == 26

    # # Given ANSIBLE_COLOR=1 and color=True,
   

# Generated at 2022-06-23 13:45:19.957846
# Unit test for function colorize
def test_colorize():
    if C.ANSIBLE_NOCOLOR:
        return True

    for good in (1, 2, 3, 4, 5):
        x = colorize(u"Test", good, C.COLOR_OK)
        assert u"Test=%s" % good in x, x

    x = colorize(u"Test", 0, C.COLOR_OK)
    assert u"Test=0" in x, x

# --- end "pretty"

# Generated at 2022-06-23 13:45:27.694463
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"localhost", {}) == u"%-26s" % u"localhost"
    assert hostcolor(u"localhost", {'changed': 1}) == u"%-37s" % stringc(u"localhost", C.COLOR_CHANGED)
    assert hostcolor(u"localhost", {'unreachable': 1}) == u"%-37s" % stringc(u"localhost", C.COLOR_ERROR)
    assert hostcolor(u"localhost", {'failed': 1}) == u"%-37s" % stringc(u"localhost", C.COLOR_ERROR)
    assert hostcolor(u"localhost", {'changed': 1, 'failed': 0, 'unreachable': 0}) == u"%-37s" % stringc(u"localhost", C.COLOR_CHANGED)

# --- end of "pretty"

# Generated at 2022-06-23 13:45:34.985098
# Unit test for function parsecolor
def test_parsecolor():
    # Valid color values
    assert parsecolor('green') == C.COLOR_CODES['green']
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color33') == '38;5;33'
    assert parsecolor('color99') == '38;5;99'
    assert parsecolor('color256') == '38;5;256'
    assert parsecolor('color9999') == '38;5;9999'
    assert parsecolor('color12345') == '38;5;12345'
    assert parsecolor('color00000') == '38;5;0'
    assert parsecolor('color99999') == '38;5;99999'

# Generated at 2022-06-23 13:45:46.899501
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('white') == u'37'
    assert parsecolor('blue') == u'34'
    assert parsecolor('blue bold') == u'1;34'
    assert parsecolor('blink') == u'5'
    assert parsecolor('underline') == u'4'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color234') == u'38;5;234'
    assert parsecolor('rgb123') == u'38;5;80'
    assert parsecolor('rgb333') == u'38;5;188'
    assert parsecolor('rgb212') == u'38;5;95'

# Generated at 2022-06-23 13:45:58.463162
# Unit test for function parsecolor

# Generated at 2022-06-23 13:46:07.030654
# Unit test for function hostcolor
def test_hostcolor():
    c_failure = hostcolor('github.com', {'failures': 1}, True)
    nc_failure = hostcolor('github.com', {'failures': 1}, False)
    c_changed = hostcolor('github.com', {'changed': 1}, True)
    nc_changed = hostcolor('github.com', {'changed': 1}, False)
    c_ok = hostcolor('github.com', {'failures': 0}, True)
    nc_ok = hostcolor('github.com', {'failures': 0}, False)
    # pylint complains about too many format string in stringc(), but the test
    # is here to ensure it works as expected.
    assert c_failure == '\033[31m%-37s\033[0m' % 'github.com'
    assert nc

# Generated at 2022-06-23 13:46:16.788065
# Unit test for function parsecolor
def test_parsecolor():

    assert(parsecolor('black') == '30')
    assert(parsecolor('darkgray') == '90')
    assert(parsecolor('blue') == '34')
    assert(parsecolor('brightblue') == '94')
    assert(parsecolor('red') == '31')
    assert(parsecolor('brightred') == '91')
    assert(parsecolor('green') == '32')
    assert(parsecolor('brightgreen') == '92')
    assert(parsecolor('yellow') == '33')
    assert(parsecolor('brightyellow') == '93')
    assert(parsecolor('pink') == '35')
    assert(parsecolor('brightpink') == '95')
    assert(parsecolor('cyan') == '36')

# Generated at 2022-06-23 13:46:25.000384
# Unit test for function colorize
def test_colorize():
    assert 'ok=1  ' == colorize('ok', 1, C.COLOR_OK)
    assert 'changed=1  ' == colorize('changed', 1, C.COLOR_CHANGED)
    assert 'failed=1  ' == colorize('failed', 1, C.COLOR_ERROR)
    assert 'skipped=1 ' == colorize('skipped', 1, C.COLOR_SKIP)
    assert 'rescued=1 ' == colorize('rescued', 1, C.COLOR_OK)
    assert 'ignored=1 ' == colorize('ignored', 1, C.COLOR_WARN)

# --- end of "pretty"


# Generated at 2022-06-23 13:46:36.097755
# Unit test for function parsecolor
def test_parsecolor():
    # Test that color string consists of the word 'color' followed by a
    # number.
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color10') == u'38;5;10'
    assert parsecolor('color99') == u'38;5;99'
    assert parsecolor('color255') == u'38;5;255'

    # Test that a color string consists of the word 'gray' followed by a
    # number.
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray2') == u'38;5;234'
    assert parsecolor('gray24') == u'38;5;255'

    #

# Generated at 2022-06-23 13:46:42.765661
# Unit test for function colorize
def test_colorize():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    msg = u"The %s is green."
    assert colorize(u'grass', u'green', u'green') == u'grass=green'
    assert colorize(u'apple', u'red', None) == u'apple=red'
    ANSIBLE_COLOR = False
    assert colorize(u'apple', u'red', None) == u'apple=red'

# Generated at 2022-06-23 13:46:54.822109
# Unit test for function colorize
def test_colorize():
    assert colorize("blah", 0, "green") == "blah=0   "
    assert colorize("blah", 0, "blue") == "blah=0   "
    assert colorize("blah", 0, "pink") == "blah=0   "
    assert colorize("blah", 123, "blue") == stringc("blah=123 ", "blue")
    assert colorize("blah", 123, "green") == stringc("blah=123 ", "green")
    assert colorize("blah", 123, "pink") == stringc("blah=123 ", "pink")
    assert colorize("foo", 0, None) == "foo=0    "
    assert colorize("foo", 42, None) == "foo=42   "

# --- end "pretty"



# Generated at 2022-06-23 13:47:02.303372
# Unit test for function parsecolor
def test_parsecolor():
    cases = [
        ('blue',    '38;5;4'),
        ('0',       '38;5;0'),
        ('rgb123',  '38;5;123'),
        ('gray4',   '38;5;240'),
        ('grey4',   '38;5;240'),
        ('grey 9',  '38;5;239'),
        ('foo',     '38;5;9'),
    ]
    for (colorname, sgr_param) in cases:
        result = parsecolor(colorname)
        if result != sgr_param:
            raise AssertionError("parsecolor(%r) = %r (must be %r)" % (colorname, result, sgr_param))
# --- end of "pretty"

# Generated at 2022-06-23 13:47:07.210707
# Unit test for function colorize
def test_colorize():
    from io import StringIO
    stream = StringIO()
    lead = 'test'
    num = 1
    color = 'red'
    colorize(lead, num, color)
    assert(stream.getvalue() == u"\x1b[91mtest=1  \x1b[0m")
    stream.close()


# Generated at 2022-06-23 13:47:19.634825
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        def _colorize(s, color):
            return u'\033[%sm%s\033[0m' % (parsecolor(color), s)

        assert(stringc(u"abc", u'blue') == _colorize(u"abc", u'blue'))
        assert(stringc(u"abc", u'color1') == _colorize(u"abc", u'color1'))
        assert(stringc(u"abc", u'rgb255') == _colorize(u"abc", u'rgb255'))
        assert(stringc(u"abc", u'rgb000') == _colorize(u"abc", u'rgb000'))

# Generated at 2022-06-23 13:47:31.083083
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("example.com", dict(failures=0, unreachable=0, changed=0)) == u"%-26s" % stringc("example.com", C.COLOR_OK)
    assert hostcolor("example.com", dict(failures=1, unreachable=0, changed=0)) == u"%-26s" % stringc("example.com", C.COLOR_ERROR)
    assert hostcolor("example.com", dict(failures=0, unreachable=1, changed=0)) == u"%-26s" % stringc("example.com", C.COLOR_ERROR)
    assert hostcolor("example.com", dict(failures=0, unreachable=0, changed=1)) == u"%-26s" % stringc("example.com", C.COLOR_CHANGED)
    # TODO: add checks for when

# Generated at 2022-06-23 13:47:38.764355
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, changed=0, unreachable=0)) == u"%-37s" % "localhost"
    assert hostcolor("localhost", dict(failures=0, changed=0, unreachable=0), color=False) == u"%-26s" % "localhost"
    assert hostcolor("localhost", dict(failures=1, changed=0, unreachable=0)) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, changed=1, unreachable=0)) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-23 13:47:48.768674
# Unit test for function stringc
def test_stringc():
    assert stringc("hola", "red") == u"\033[31mhola\033[0m"
    assert stringc("hola\nmundo", "red") == u"\033[31mhola\033[0m\n\033[31mundo\033[0m"
    assert stringc("hola\nmundo", "color220") == u"\033[38;5;220mhola\033[0m\n\033[38;5;220mundo\033[0m"
    assert stringc("hola\nmundo", "rgb122") == u"\033[38;5;122mhola\033[0m\n\033[38;5;122mundo\033[0m"

if __name__ == "__main__":
    test_stringc

# Generated at 2022-06-23 13:47:55.104660
# Unit test for function colorize
def test_colorize():
    assert colorize("ok", 0, "green") == "ok=0   "
    assert colorize("changed", 0, "yellow") == "changed=0   "
    assert colorize("unreachable", 0, "red") == "unreachable=0   "
    assert colorize("failed", 0, "red") == "failed=0   "



# Generated at 2022-06-23 13:48:07.112350
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('green') == '32'

    assert parsecolor('color16')  == '38;5;16'
    assert parsecolor('rgb123')   == '38;5;18'
    assert parsecolor('gray3')    == '38;5;235'

    # The following tests are from https://en.wikipedia.org/wiki/ANSI_escape_code#graphics
    assert parsecolor('black')    == '38;5;16'
    assert parsecolor('red')      == '38;5;196'
    assert parsecolor('green')    == '38;5;46'
    assert parsecolor('yellow')   == '38;5;226'
    assert parsecolor('blue')     == '38;5;21'

# Generated at 2022-06-23 13:48:20.063011
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"host.example.com", dict(failures=0, unreachable=0, changed=0)) == u"host.example.com               "
    assert hostcolor(u"host.example.com", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mhost.example.com       \x1b[0m"
    assert hostcolor(u"host.example.com", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mhost.example.com       \x1b[0m"

# Generated at 2022-06-23 13:48:30.934261
# Unit test for function parsecolor
def test_parsecolor():
    def check(color, ansi):
        try:
            assert(parsecolor(color) == ansi)
        except:
            print(color)
            raise

    check('blue',    '34')
    check('red',     '31')
    check('dark_gray', '1;30')
    check('color08', '38;5;8')
    check('color12', '38;5;12')
    check('color255', '38;5;255')
    check('rgb222',  '38;5;102')
    check('rgb111',  '38;5;18')
    check('rgb000',  '38;5;16')
    check('gray0',   '38;5;232')
    check('gray1',   '38;5;233')

# Generated at 2022-06-23 13:48:37.361241
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 42
    color = 'red'
    result = colorize(lead, num, color)
    print(u"test_colorize = %s" % result)
    # Expect assertion to fail if the colorize function is broken
    assert result == 'foo=42\x1b[31m\x1b[0m'

if __name__ == '__main__':
    test_colorize()
# --- end "pretty"

__all__ = ['stringc', 'colorize', 'hostcolor']

# Generated at 2022-06-23 13:48:46.046995
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"black") == u"30"
    assert parsecolor(u"blue") == u"34"
    assert parsecolor(u"red") == u"31"
    assert parsecolor(u"magenta") == u"35"
    assert parsecolor(u"green") == u"32"
    assert parsecolor(u"cyan") == u"36"
    assert parsecolor(u"yellow") == u"33"
    assert parsecolor(u"white") == u"37"
    assert parsecolor(u"color-0") == u"38;5;0"
    assert parsecolor(u"color-1") == u"38;5;1"
    assert parsecolor(u"color-2") == u"38;5;2"
    assert par

# Generated at 2022-06-23 13:48:54.388529
# Unit test for function parsecolor
def test_parsecolor():
    import six
    assert parsecolor("red") == u'31'
    assert parsecolor("2") == u'38;5;2'
    assert parsecolor("rgb255") == u'38;5;231'
    assert parsecolor("rgb2550") == u'38;5;95'
    assert parsecolor("rgb0505") == u'38;5;58'
    assert parsecolor("gray0") == u'38;5;232'
    assert parsecolor("gray255") == u'38;5;255'
    assert parsecolor("foo") == ''
#
# --- end "pretty"



# Generated at 2022-06-23 13:49:05.630189
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat.tests import unittest
    from ansible.utils import jsonify
    from ansible.utils import hostcolor

    test_hosts = {'host_1': {'changed': True, 'failures': 0, 'ok': True, 'skipped': 0, 'unreachable': 0},
                  'host_2': {'changed': False, 'failures': 0, 'ok': True, 'skipped': 0, 'unreachable': 0},
                  'host_3': {'changed': False, 'failures': 1, 'ok': True, 'skipped': 0, 'unreachable': 0},
                  'host_4': {'changed': False, 'failures': 0, 'ok': True, 'skipped': 0, 'unreachable': 1}}


# Generated at 2022-06-23 13:49:08.642421
# Unit test for function colorize
def test_colorize():
    lead = u"foo"
    num = 42
    color = u"red"
    res = colorize(lead, num, color)

    print(res)
    # assert(True)


# Generated at 2022-06-23 13:49:16.324522
# Unit test for function colorize
def test_colorize():
    """Testing function colorize"""

    good = u"ok      = 4"
    bad = u"failed  = 1"
    skipped = u"skipped = 1"

    # Test that we get no color
    assert colorize(u"ok", 4, None) == good

    if ANSIBLE_COLOR:
        # Test that we get color
        assert colorize(u"ok", 4, u"green") == stringc(good, u"green")
        assert colorize(u"failed", 1, u"red") == stringc(bad, u"red")
        assert colorize(u"skipped", 1, u"cyan") == stringc(skipped, u"cyan")

# Generated at 2022-06-23 13:49:25.121786
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'green') == stringc('foo=0   ', 'green')
    assert colorize('foo', 1, 'green') == stringc('foo=1   ', 'green')
    assert colorize('foo', 12, 'green') == stringc('foo=12  ', 'green')
    assert colorize('foo', 123, 'green') == stringc('foo=123 ', 'green')
    assert colorize('foo', 1234, 'green') == stringc('foo=1234', 'green')

# --- end "pretty"



# Generated at 2022-06-23 13:49:31.061731
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('none') == C.COLOR_CODES['none']
    assert parsecolor('reset') == C.COLOR_CODES['reset']
    assert parsecolor('random') == C.COLOR_CODES['random']
    assert parsecolor('black') == C.COLOR_CODES['black']
    assert parsecolor('red') == C.COLOR_CODES['red']
    assert parsecolor('green') == C.COLOR_CODES['green']
    asse

# Generated at 2022-06-23 13:49:37.956253
# Unit test for function hostcolor
def test_hostcolor():
    stats1 = dict(failures=0, unreachable=0, changed=0)
    stats2 = dict(failures=1, unreachable=0, changed=0)
    stats3 = dict(failures=0, unreachable=1, changed=0)
    stats4 = dict(failures=0, unreachable=0, changed=1)

    assert hostcolor("test_ok", stats1)    == u"%-37s" % "test_ok"
    assert hostcolor("test_fail", stats2)  == u"%-37s" % stringc("test_fail", C.COLOR_ERROR)
    assert hostcolor("test_unreach", stats3)  == u"%-37s" % stringc("test_unreach", C.COLOR_ERROR)

# Generated at 2022-06-23 13:49:48.601603
# Unit test for function stringc
def test_stringc():
    """Test the colored string function using all possible escape sequences."""
    assert stringc("", "red") == u"\033[31m\033[0m"
    assert stringc("", "green") == u"\033[32m\033[0m"
    assert stringc("", "yellow") == u"\033[33m\033[0m"
    assert stringc("", "blue") == u"\033[34m\033[0m"
    assert stringc("", "magenta") == u"\033[35m\033[0m"
    assert stringc("", "cyan") == u"\033[36m\033[0m"
    assert stringc("", "white") == u"\033[37m\033[0m"

# Generated at 2022-06-23 13:49:59.444900
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    from ansible.utils.color import ANSIBLE_COLOR
    from ansible import constants as C
    # Uncolorized output
    ANSIBLE_COLOR = False
    assert hostcolor("localhost", {'failures': 0,
                                   'unreachable': 0,
                                   'changed': 0}) == "%-26s" % "localhost"
    # Colorized output
    ANSIBLE_COLOR = True
    assert hostcolor("localhost", {'failures': 0,
                                   'unreachable': 0,
                                   'changed': 0}) == u"\n".join([u"\033[%sm%-37s\033[0m" % (C.COLOR_CODES[C.COLOR_OK], "localhost")])


# Generated at 2022-06-23 13:50:09.834207
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u"blue") == u"34"
    assert parsecolor(u"on_blue") == u"44"
    assert parsecolor(u"blue on_white") == u"34;47"
    assert parsecolor(u"blue,bold on_white,blink") == u"34;1;47;5"
    assert parsecolor(u"bold red on_yellow") == u"1;31;43"
    assert parsecolor(u"color7") == u"38;5;7"
    assert parsecolor(u"rgb123") == u"38;5;116"
    assert parsecolor(u"gray8") == u"38;5;240"
    try:
        parsecolor(u"invalid")
    except KeyError:
        pass

# Generated at 2022-06-23 13:50:18.882119
# Unit test for function hostcolor
def test_hostcolor():
    """ hostcolor function testing """

    print("Testing hostcolor function")

    stats = dict(ok=10, failures=0, unreachable=0, changed=0)
    result = hostcolor("localhost", stats)
    assert result == "localhost                      ", result

    stats = dict(ok=10, failures=1, unreachable=0, changed=0)
    result = hostcolor("localhost", stats)
    assert result == "\x1b[31mlocalhost\x1b[0m                     ", result

    stats = dict(ok=10, failures=0, unreachable=0, changed=1)
    result = hostcolor("localhost", stats)
    assert result == "\x1b[33mlocalhost\x1b[0m                     ", result



# Generated at 2022-06-23 13:50:25.048893
# Unit test for function stringc
def test_stringc():
    assert u"\033[31mfoo\033[0m" == stringc("foo", "red")
    assert u"\033[38;5;1mfoo\033[0m" == stringc("foo", "color1")
    assert u"\033[38;5;7mfoo\033[0m" == stringc("foo", "color7")
    assert u"\033[38;5;13mfoo\033[0m" == stringc("foo", "color13")
    assert u"\033[38;5;18mfoo\033[0m" == stringc("foo", "rgb000")
    assert u"\033[38;5;23mfoo\033[0m" == stringc("foo", "rgb222")

# Generated at 2022-06-23 13:50:36.750989
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo.bar'
    stats = {'changed': 1, 'failures': 1, 'ok': 2, 'skipped': 0, 'unreachable': 0}

    retval = hostcolor(host, stats, color=True)
    # output is something like: \n\033[31mfoo.bar\033[0m\n
    assert retval.startswith(u'\n\033[')
    assert retval.endswith(u'\033[0m\n')
    assert retval.find(host) > 0

    retval = hostcolor(host, stats, color=False)
    # output is a string like: '\nfoo.bar\n'
    assert retval.startswith(u'\n')
    assert retval.endswith(u'\n')
   

# Generated at 2022-06-23 13:50:48.118794
# Unit test for function stringc
def test_stringc():
    assert stringc(u'test', 'green') == u'\033[32mtest\033[0m'
    assert stringc(u'test', 'color1') == u'\x1b[38;5;1mtest\x1b[0m'
    assert stringc(u'test', 'rgb255255255') == u'\x1b[38;5;15mtest\x1b[0m'
    assert stringc(u'test', 'gray0') == u'\x1b[38;5;232mtest\x1b[0m'

# --- end "pretty"

# **NOTE**: The following are deprecated and will be removed in a future release
ERROR = C.COLOR_ERROR
WARN = C.COLOR_WARN
OK = C.COLOR_OK
SKIP = C.COLOR

# Generated at 2022-06-23 13:50:54.092226
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 123, C.COLOR_OK) == u'ok=123  '
    assert colorize('changed', 1, C.COLOR_CHANGED) == u'changed=1  '
    assert colorize('unreachable', 10, C.COLOR_UNREACHABLE) == u'unreachable=10'
    assert colorize('failed', 0, C.COLOR_ERROR) == u'failed=0   '

# Generated at 2022-06-23 13:51:00.810906
# Unit test for function stringc
def test_stringc():
    """Test function stringc with specified and special color."""

    for color, code in C.COLOR_CODES.items():
        result = stringc(u"Hello World", color)
        assert isinstance(result, unicode), "Wrong type of result"
        expected = u"\033[%smHello World\033[0m" % code
        assert result == expected, "Test failed for color " + color



# Generated at 2022-06-23 13:51:10.265386
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return

    def assert_ansi_color(host, color):
        host = u"%s" % host
        stats = dict(ok=1, changed=1, unreachable=0, skipped=0, failures=0)
        c = hostcolor(host, stats, color)
        m = re.search(r'^\x1b\[\d+m(.*?)(?:\x1b\[0m)?$', c, re.DOTALL)
        if not m:
            raise AssertionError('%r has no ansi color' % c)
        s = m.group(1)
        if s != host:
            raise AssertionError('%r != host %r' % (s, host))


# Generated at 2022-06-23 13:51:18.882554
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('blue') == '34'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color39') == '38;5;39'
    assert parsecolor('color105') == '38;5;105'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color99') == '38;5;99'
    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('rgb099') == '38;5;56'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb500') == '38;5;226'

# Generated at 2022-06-23 13:51:30.901301
# Unit test for function stringc
def test_stringc():
    # Test calling stringc with each of the color names.
    for color in C.COLOR_CODES:
        text = stringc(color, color)
        sys.stdout.write(text)
        sys.stdout.write('\n')
    # Test calling stringc with each of the color numbers.
    for n in range(16):
        text = stringc('Color %d' % n, 'color%d' % n)
        sys.stdout.write(text)
        sys.stdout.write('\n')
    sys.stdout.write('\n')
    # Test calling stringc with RGB colors.

# Generated at 2022-06-23 13:51:35.092992
# Unit test for function colorize
def test_colorize():
    text = colorize("Yay", 20, "blue")
    assert(text == '\033[94mYay=20  \033[0m')

if __name__ == "__main__":
    test_colorize()

# Generated at 2022-06-23 13:51:45.676253
# Unit test for function stringc
def test_stringc():
    # Foreground Color Test
    assert stringc('test', 'white') == u"\033[37mtest\033[0m"
    assert stringc('test', 'black') == u"\033[30mtest\033[0m"
    assert stringc('test', 'red') == u"\033[31mtest\033[0m"
    assert stringc('test', 'green') == u"\033[32mtest\033[0m"
    assert stringc('test', 'yellow') == u"\033[33mtest\033[0m"
    assert stringc('test', 'blue') == u"\033[34mtest\033[0m"
    assert stringc('test', 'magenta') == u"\033[35mtest\033[0m"

# Generated at 2022-06-23 13:51:58.650871
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.vars import HostVars
    stats = {
        'failures': 0,
        'unreachable': 0,
        'changed': 0,
    }
    assert hostcolor("localhost", stats) == u"localhost                     "

    stats = {
        'failures': 1,
        'unreachable': 0,
        'changed': 0,
    }
    assert re.match(r"localhost\s*\x1b\[31m\x1b\[0m\s*$", hostcolor("localhost", stats), re.U)

    stats = {
        'failures': 0,
        'unreachable': 1,
        'changed': 0,
    }

# Generated at 2022-06-23 13:52:06.635044
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('001') == u'38;5;1'
    assert parsecolor('rgb000') == u'38;5;232'
    assert parsecolor('rgb555') == u'38;5;23'
    assert parsecolor('rgb123') == u'38;5;55'
    assert parsecolor('rgb321') == u'38;5;173'
    assert parsecolor('gray99') == u'38;5;255'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('ON_blue') == u'44'

# --- end pretty


# Generated at 2022-06-23 13:52:13.660033
# Unit test for function hostcolor

# Generated at 2022-06-23 13:52:25.629128
# Unit test for function colorize
def test_colorize():
    def test_color(color):
        lead, num, color = "test", 10, color
        ansible_color = ANSIBLE_COLOR
        ANSIBLE_COLOR = True

        s = colorize(lead, num, color)
        assert type(s) is unicode
        hex_color = parsecolor(color)
        assert u'\033[%sm' % hex_color in s

        if color in C.COLOR_CODES:
            ANSIBLE_COLOR = False
            assert u'\033[%sm' % hex_color not in colorize(lead, num, color)

        ANSIBLE_COLOR = ansible_color

    for color in C.COLOR_CODES:
        test_color(color)
    test_color('nocolor')

# Generated at 2022-06-23 13:52:35.168483
# Unit test for function stringc
def test_stringc():
    assert stringc(u"normal", u"black") == u"\033[30mnormal\033[0m"
    assert stringc(u"normal", u"white") == u"\033[37mnormal\033[0m"
    assert stringc(u"normal", u"red") == u"\033[31mnormal\033[0m"
    assert stringc(u"normal", u"green") == u"\033[32mnormal\033[0m"
    assert stringc(u"normal", u"blue") == u"\033[34mnormal\033[0m"
    assert stringc(u"normal", u"cyan") == u"\033[36mnormal\033[0m"

# Generated at 2022-06-23 13:52:40.918532
# Unit test for function parsecolor
def test_parsecolor():
    # Test color names
    for color in ['black', 'red', 'green', 'yellow', 'blue', 'magenta',
                  'cyan', 'white']:
        assert C.COLOR_CODES[color] == parsecolor(color)
    # Test gray number
    assert '38;5;244' == parsecolor('gray19')
    # Test color number
    assert '38;5;196' == parsecolor('color197')
    # Test RGB number
    assert '38;5;33' == parsecolor('rgb200')


# --- end "pretty"



# Generated at 2022-06-23 13:52:44.761648
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('red') == u'31')
    assert(parsecolor('green') == u'32')
    assert(parsecolor('blue') == u'34')
    assert(parsecolor('color16') == u'38;5;16')
    assert(parsecolor('rgb123') == u'38;5;21')
    assert(parsecolor('gray7') == u'38;5;239')
    assert(parsecolor('gray0') == u'38;5;232')
    assert(parsecolor('magenta') == u'35')



# Generated at 2022-06-23 13:52:51.449591
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""

    # Test various styles
    print("TEST: bold")
    print(stringc("bold", "bold"))
    print("TEST: blink")
    print(stringc("blink", "blink"))
    print("TEST: dim")
    print(stringc("dim", "dim"))
    print("TEST: underline")
    print(stringc("underline", "underline"))
    print("TEST: reverse")
    print(stringc("reverse", "reverse"))
    print("TEST: hidden")
    print(stringc("hidden", "hidden"))

    # Test the xterm 256 color extension
    print("TEST: color16")
    print(stringc("color16", "color16"))
    print("TEST: color17")

# Generated at 2022-06-23 13:53:00.821166
# Unit test for function colorize
def test_colorize():
    from ansible.constants import TerminalPalette
    from ansible.utils.color import stringc
    assert colorize(u"foo", 42, u"red") == u"foo=42  "
    assert colorize(u"foo", 0, u"red") == u"foo=0   "
    assert colorize(u"foo", 42, None) == u"foo=42  "
    assert colorize(u"foo", 0, None) == u"foo=0   "
    for color in TerminalPalette.keys():
        assert colorize(u"foo", 0, color) == u"foo=0   "
        assert colorize(u"foo", 42, color) == u"foo=42  "



# Generated at 2022-06-23 13:53:02.407379
# Unit test for function stringc
def test_stringc():
    for color in C.COLOR_CODES:
        print(stringc("This is " + color, color))


# Generated at 2022-06-23 13:53:10.149205
# Unit test for function hostcolor
def test_hostcolor():
    # The following test cases are intentionally reduced to a minimum.
    # See test/units/callback_plugins/test_human_log.py for a more
    # comprehensive test suite.
    stats = dict(changed=0, failures=0, unreachable=0)
    assert hostcolor('host', stats, ANSIBLE_COLOR) == u'host'
    stats['changed'] = 1
    assert hostcolor('host', stats, ANSIBLE_COLOR) == u'host'
    stats['changed'] = 0
    stats['failures'] = 1
    assert hostcolor('host', stats, ANSIBLE_COLOR) == u'host'
    stats['unreachable'] = 1
    assert hostcolor('host', stats, ANSIBLE_COLOR) == u'host'

# Used by human_log to prevent double coloring of the same line
last_

# Generated at 2022-06-23 13:53:23.218778
# Unit test for function hostcolor
def test_hostcolor():
    color = hostcolor(u"testhost", dict(failures=0, unreachable=0, changed=1))
    assert color == "%-37s" % stringc(u"testhost", C.COLOR_CHANGED)

    color = hostcolor(u"testhost", dict(failures=0, unreachable=0, changed=0))
    assert color == "%-37s" % stringc(u"testhost", C.COLOR_OK)

    color = hostcolor(u"testhost", dict(failures=1, unreachable=0, changed=1))
    assert color == "%-37s" % stringc(u"testhost", C.COLOR_ERROR)

    color = hostcolor(u"testhost", dict(failures=0, unreachable=1, changed=1))

# Generated at 2022-06-23 13:53:29.487477
# Unit test for function colorize
def test_colorize():
    try:
        assert colorize("!", 42, "green") == u"\033[38;5;0042m!=42   \033[0m"
        assert colorize("!", 42, None) == u"!=42   "
        assert colorize("!", 42, "") == u"!=42   "
    except AssertionError:
        print(u"You will need to install the 'termcolor' module using"
              u" the python package manager 'pip install termcolor'")


# Generated at 2022-06-23 13:53:37.678267
# Unit test for function hostcolor
def test_hostcolor():
    host = "foohost"
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

    hostcol = hostcolor(host, stats, True)
    assert hostcol.startswith("\033[") and hostcol.endswith("m")

    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    hostcol = hostcolor(host, stats, True)
    assert hostcol.startswith("\033[") and hostcol.endswith("m")

    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    hostcol = hostcolor(host, stats, True)
    assert hostcol.startswith("\033[") and hostcol.endswith("m")
