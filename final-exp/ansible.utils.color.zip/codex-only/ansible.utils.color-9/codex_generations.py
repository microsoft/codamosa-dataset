

# Generated at 2022-06-23 13:43:45.100795
# Unit test for function parsecolor
def test_parsecolor():
    import pytest

    assert parsecolor("red") == "31"
    assert parsecolor("black") == "30"
    assert parsecolor("bright purple") == "35;1"
    assert parsecolor("red on blue") == "31;44"
    assert parsecolor("rgb255") == "1;38;5;255"
    assert parsecolor("rgb 0 0 128") == "1;38;5;24"
    assert parsecolor("rgb 0 1 0") == "1;38;5;22"
    assert pytest.raises(Exception, parsecolor, "rgb 0 1 256")
    assert pytest.raises(Exception, parsecolor, "rgb 0 0")
    assert pytest.raises(Exception, parsecolor, "rgb")
    assert pytest.ra

# Generated at 2022-06-23 13:43:54.531129
# Unit test for function parsecolor
def test_parsecolor():
    # 17 color test
    assert parsecolor("Red") == u"31"
    assert parsecolor("Green") == u"32"
    assert parsecolor("Yellow") == u"33"
    assert parsecolor("Blue") == u"34"
    assert parsecolor("Magenta") == u"35"
    assert parsecolor("Cyan") == u"36"
    assert parsecolor("White") == u"37"
    assert parsecolor("Black") == u"30"
    assert parsecolor("Crimson") == u"31"
    assert parsecolor("Orange") == u"31"
    assert parsecolor("LightGreen") == u"32"
    assert parsecolor("LightBlue") == u"36"
    assert parsecolor("LightMagenta") == u"35"
    assert par

# Generated at 2022-06-23 13:44:00.663904
# Unit test for function colorize
def test_colorize():
    ret = colorize(u"foo", u'0', u'red')
    assert ret == u"foo=0   ", ret
    ret = colorize(u"foo", u'0', None)
    assert ret == u"foo=0   ", ret
    ret = colorize(u"foo", u'10', u'green')
    assert ret == u"foo=10  ", ret

# --- end "pretty"



# Generated at 2022-06-23 13:44:09.336366
# Unit test for function colorize
def test_colorize():

    # Expected values
    lead = u'foo:'
    num = 42
    color_red = u'red'
    color_green = u'green'
    color_yellow = u'yellow'
    color_blue = u'blue'
    color_default = u'normal'
    colorize_red = u'foo:=42'
    colorize_green = u'foo:=42'
    colorize_yellow = u'foo:=42'
    colorize_blue = u'foo:=42'
    colorize_default = u'foo:=42'

    if ANSIBLE_COLOR:
        colorize_red = u"\033[31mfoo:=42\033[0m"
        colorize_green = u"\033[32mfoo:=42\033[0m"
        colorize

# Generated at 2022-06-23 13:44:21.149446
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1)) == u'localhost               '
    assert hostcolor('example.com', dict(failures=0, unreachable=1)) == u'example.com            '
    assert hostcolor('other.example.com', dict(changed=1)) == u'other.example.com       '

    assert hostcolor(u'localhost', dict(failures=1), False) == u'localhost               '
    assert hostcolor(u'localhost', dict(failures=1), False) == u'localhost               '
    assert hostcolor(u'localhost', dict(failures=1), False) == u'localhost               '
    assert hostcolor(u'localhost', dict(failures=1), False) == u'localhost               '

    assert hostcolor(u'localhost', dict(failures=1), True) == u

# Generated at 2022-06-23 13:44:29.020722
# Unit test for function colorize
def test_colorize():
    # simulate dark background terminals
    C.COLOR_ERROR = "red"
    C.COLOR_CHANGED = "green"
    C.COLOR_OK = "yellow"
    C.COLOR_SKIP = "blue"

    # simulate a failed command
    lead = "changed"
    num = 1
    color = C.COLOR_CHANGED
    res = colorize(lead, num, color)
    assert res == u'\033[38;5;2mchanged=1   \033[0m'

    # simulate a successful command
    lead = "ok"
    num = 2
    color = C.COLOR_OK
    res = colorize(lead, num, color)
    assert res == u'\033[38;5;3mok=2        \033[0m'

    # simulate a skipped command
    lead

# Generated at 2022-06-23 13:44:40.413177
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == parsecolor('1;34') == '1;34'
    assert parsecolor('bright blue') == parsecolor('1;94') == '1;94'
    assert parsecolor('green') == parsecolor('32') == '32'
    assert parsecolor('bright green') == parsecolor('1;32') == '1;32'
    assert parsecolor('red') == parsecolor('31') == '31'
    assert parsecolor('bright red') == parsecolor('1;31') == '1;31'
    assert parsecolor('white') == parsecolor('37') == '37'
    assert parsecolor('bright white') == parsecolor('1;37') == '1;37'
    assert parsecolor('yellow') == parsecolor('33')

# Generated at 2022-06-23 13:44:45.397712
# Unit test for function colorize
def test_colorize():
    """ Unit test for function colorize """

    # Syntax error
    assert colorize('test', 1, 'purple') == 'test=1   '
    assert colorize('test', 1, 'blue') == u'\x1b[34mtest=1   \x1b[0m'



# Generated at 2022-06-23 13:44:52.342479
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5') == u'38;5;5'
    assert parsecolor('color6') == u'38;5;6'
    assert parsecolor('color7') == u'38;5;7'
    assert parsecolor('color8') == u'38;5;8'

# Generated at 2022-06-23 13:45:00.833033
# Unit test for function colorize
def test_colorize():
    nums = {'pending': 10, 'failures': 0, 'ok': 2, 'dark': 12, 'changed': 0, 'skipped': 0, 'unreachable': 0}
    for color in C.COLOR_OK, C.COLOR_CHANGED, C.COLOR_SKIP, C.COLOR_ERROR:
        for name in 'ok', 'changed', 'unreachable', 'failures', 'skipped', None, 'dark':
            s = colorize(name, nums[name], color)
            print("%-8s %s" % (color, s))

# Run unit tests when invoked directly
if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-23 13:45:05.413114
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, 'blue') == stringc(u"foo=0", 'blue')
    assert colorize(u"bar", 1, 'blue') == stringc(u"bar=1", 'blue')

# Generated at 2022-06-23 13:45:16.021957
# Unit test for function hostcolor
def test_hostcolor():
    from collections import namedtuple

    Host = namedtuple('Host', ['name'])
    host = Host(name='localhost')

    class Record:
        host = host
        changed = 0
        failures = 0
        unreachable = 0

    # Test no failure, no change
    record = Record()
    assert hostcolor(host.name, record._asdict()) == "%-37s" % host.name

    # Test change, no failure
    record = Record(changed=1)
    assert hostcolor(host.name, record._asdict()) == "%-37s" % stringc(host.name, C.COLOR_CHANGED)

    # Test change and failure
    record = Record(changed=1, failures=1)

# Generated at 2022-06-23 13:45:25.872123
# Unit test for function hostcolor
def test_hostcolor():
    ansible_color = True
    stats = dict(
        changed=0,
        unreachable=0,
        failures=1,
    )
    assert hostcolor('localhost', stats, color=ansible_color) == stringc('localhost', C.COLOR_ERROR, wrap_nonvisible_chars=False)
    stats = dict(
        changed=1,
        unreachable=0,
        failures=0,
    )
    assert hostcolor('localhost', stats, color=ansible_color) == stringc('localhost', C.COLOR_CHANGED, wrap_nonvisible_chars=False)
    stats = dict(
        changed=0,
        unreachable=0,
        failures=0,
    )

# Generated at 2022-06-23 13:45:37.964962
# Unit test for function stringc
def test_stringc():
    def assert_stringc(arg, expect):
        result = stringc(arg, "white")
        assert result == "\033[97m%s\033[0m" % expect

    assert_stringc("hello world", "hello world")
    assert_stringc("hello world\n", "hello world\n")
    assert_stringc("hello\tworld\nfoo\tbar\n", "hello\tworld\nfoo\tbar\n")
    assert_stringc("hello\tworld\nfoo \tbar\n", "hello\tworld\nfoo \tbar\n")
    assert_stringc("hello\tworld\nfoo\t bar\n", "hello\tworld\nfoo\t bar\n")

# Generated at 2022-06-23 13:45:44.271268
# Unit test for function hostcolor
def test_hostcolor():
    assert (hostcolor("localhost.localdomain | SUCCESS => {", dict(changed=0, unreachable=0, failures=0)) == u"localhost.localdomain              ")
    assert (hostcolor("localhost.localdomain | SUCCESS => {", dict(changed=1, unreachable=0, failures=0)) == u"\x1b[0;32mlocalhost.localdomain\x1b[0m      ")
    assert (hostcolor("localhost.localdomain | FAILED => {", dict(changed=0, unreachable=0, failures=1)) == u"\x1b[0;31mlocalhost.localdomain\x1b[0m      ")

# Generated at 2022-06-23 13:45:56.553886
# Unit test for function parsecolor
def test_parsecolor():
    good_color = ['red', 'green', 'blue', 'yellow', 'grey',
                  'dark red', 'dark green', 'dark blue', 'dark yellow',
                  'dark grey', 'bright red', 'bright green',
                  'bright blue', 'bright yellow', 'bright grey',
                  'color8', 'color9', 'color10', 'color11']
    bad_color = ['bright grey', 'color8', 'color9', 'color10', 'color11']
    known_values_rgb = [('rgb000', 'rgb123', 'rgb321'),
                        ('rgb000', 'rgb444', 'rgb555'),
                        ('rgb000', 'rgb666', 'rgb999')]

# Generated at 2022-06-23 13:46:05.889476
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert parsecolor('red') == u'31'
        assert parsecolor('green') == u'32'
        assert parsecolor('yellow') == u'33'
        assert parsecolor('blue') == u'34'
        assert parsecolor('magenta') == u'35'
        assert parsecolor('cyan') == u'36'
        assert parsecolor('white') == u'0'
        assert parsecolor('black') == u'30'
        assert parsecolor('on_red') == u'41'
        assert parsecolor('on_green') == u'42'
        assert parsecolor('on_yellow') == u'43'
        assert parsecolor('on_blue') == u'44'

# Generated at 2022-06-23 13:46:16.113207
# Unit test for function hostcolor
def test_hostcolor():
    ''' hostcolor returns strings that are colored depending on status '''
    all_zeros = dict(changed=0, failures=0, unreachable=0)
    all_nonzeros = dict(changed=1, failures=2, unreachable=3)
    a_failure = dict(changed=0, failures=1, unreachable=0)
    a_unreachable = dict(changed=0, failures=0, unreachable=1)
    a_change = dict(changed=1, failures=0, unreachable=0)

    assert hostcolor('localhost', all_zeros, False) == '%-26s' % 'localhost'
    assert hostcolor('localhost', all_zeros, True) == '%-37s' % 'localhost'


# Generated at 2022-06-23 13:46:23.659983
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(changed=2, failures=0), True) == u"\x1b[0;32mlocalhost                      \x1b[0m"
    assert hostcolor('localhost', dict(changed=0, failures=2), True) == u"\x1b[0;31mlocalhost                      \x1b[0m"
    assert hostcolor('localhost', dict(changed=2, failures=0), False) == u"localhost          "
    assert hostcolor('localhost', dict(changed=0, failures=2), False) == u"localhost          "



# Generated at 2022-06-23 13:46:31.382409
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foohost'
    stats = {
        'a': 1,
        'b': 2,
        'c': 3,
        'd': 4
    }
    # Color enabled, no failures or unreachable
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)
    # Color enabled, with failures or unreachable
    stats['failures'] = 1
    stats['unreachable'] = 1
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    # Color disabled
    assert hostcolor(host, stats, False) == u"%-26s" % host
    # Color enabled, with changed
    stats['failures'] = 0
    stats['unreachable'] = 0

# Generated at 2022-06-23 13:46:41.012157
# Unit test for function hostcolor
def test_hostcolor():
    ''' hostcolor returns the correct string '''
    class TestHost(object):
        def __init__(self, name):
            self.name = name
    h = TestHost('test')
    assert hostcolor('test', {'failures':0, 'unreachable': 0, 'changed': 0}) == 'test                 '
    assert hostcolor('test', {'failures':1, 'unreachable': 0, 'changed': 0}) == 'test                 '
    assert hostcolor('test', {'failures':0, 'unreachable': 1, 'changed': 0}) == 'test                 '
    assert hostcolor('test', {'failures':0, 'unreachable': 0, 'changed': 1}) == 'test                 '


# End "pretty" section
# ---

C.COLOR_OK = 'green'

# Generated at 2022-06-23 13:46:53.818700
# Unit test for function stringc
def test_stringc():
    class args:
        pass
    args.force_color = True
    args.nocolor = False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    assert stringc("test", "green") == u"\033[32mtest\033[0m"

    try:
        curses.setupterm()
        if curses.tigetnum('colors') < 0:
            ANSIBLE_COLOR = False
            assert stringc("test", "green") == u"test"
        curses.reset_shell_mode()
    except ImportError:
        # curses library was not found
        pass
    except curses.error:
        # curses returns an error (e.g. could not find terminal)
        ANSIBLE_COLOR = False
        assert stringc("test", "green") == u"test"

    AN

# Generated at 2022-06-23 13:47:02.101729
# Unit test for function hostcolor
def test_hostcolor():
    hostcolor_ok = hostcolor('www.example.com', dict(failures=0, unreachable=0, changed=0))
    assert hostcolor_ok == u"www.example.com                "

    hostcolor_changed = hostcolor('www.example.com', dict(failures=0, unreachable=0, changed=1))
    assert hostcolor_changed == u"\x1b[0;34mwww.example.com\x1b[0m"

    hostcolor_failed = hostcolor('www.example.com', dict(failures=1, unreachable=0, changed=0))
    assert hostcolor_failed == u"\x1b[0;31mwww.example.com\x1b[0m"


# --- end "pretty"

if __name__ == '__main__':
    test

# Generated at 2022-06-23 13:47:10.226444
# Unit test for function hostcolor
def test_hostcolor():
    host = u"testhost"

    # Host without color
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=False) == u"%-26s" % (host)

    # Host with no color
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u"%-37s" % (host)

    # Host with color ok
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
    assert hostcolor(host, stats, color=True).startswith("\x1b")



# Generated at 2022-06-23 13:47:22.860769
# Unit test for function stringc
def test_stringc():
    print("\x1b[31m%s\x1b[0m" % (stringc("Red", "red")))
    print(stringc("\x1b[31mRed\x1b[0m", "red"))
    print("\x1b[1;35m%s\x1b[0m" % (stringc("Bold pink", "1;35")))
    print("\x1b[38;5;197m%s\x1b[0m" % (stringc("Orange", "rgb3;5;3")))
    print("\x1b[38;5;197m%s\x1b[0m" % (stringc("Orange", "color197")))

# Generated at 2022-06-23 13:47:34.364994
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize('foo', 5, 'green') == u'\n'.join((
            u"\033[32mfoo=5   \033[0m",
            u"\033[32mfoo=5   \033[0m",
            u"\033[32mfoo=5   \033[0m",
            u"\033[32mfoo=5   \033[0m"
        ))

# Generated at 2022-06-23 13:47:40.513224
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == u'\x1b[94mtest\x1b[0m'
    assert stringc("test_2", "red") == u'\x1b[91mtest_2\x1b[0m'
    assert stringc("test_3", "green") == u'\x1b[92mtest_3\x1b[0m'
    assert stringc("test_4", "0;30") == u'\x1b[0;30mtest_4\x1b[0m'
    assert stringc("test_5", "0;34") == u'\x1b[0;34mtest_5\x1b[0m'

# --- end "pretty"

# --- begin "terminal"


# Generated at 2022-06-23 13:47:45.949321
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("white") == "38;5;15"
    assert parsecolor("black") == "38;5;16"
    assert parsecolor("0") == "38;5;16"
    assert parsecolor("1") == "38;5;17"
    assert parsecolor("rgb000") == "38;5;16"
    assert parsecolor("rgb123") == "38;5;18"
    assert parsecolor("rgb555") == "38;5;23"
    assert parsecolor("rgb555") == "38;5;23"
    assert parsecolor("rgb555") == "38;5;23"
    assert parsecolor("rgb333") == "38;5;59"

# Generated at 2022-06-23 13:47:48.666362
# Unit test for function stringc
def test_stringc():
    """Test function stringc()"""
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert (stringc("test", "blue", wrap_nonvisible_chars=True) ==
            '\001\033[34m\002test\001\033[0m\002')



# Generated at 2022-06-23 13:47:58.789020
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('green') == '32'
    assert parsecolor('rgb100') == '38;5;49'
    assert parsecolor('rgb332101') == '38;5;118'
    assert parsecolor('rgb552211') == '38;5;196'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color250') == '38;5;250'
    assert parsecolor('gray1') == '38;5;232'
    assert parsecolor('gray24') == '38;5;255'

# Generated at 2022-06-23 13:48:09.932363
# Unit test for function colorize
def test_colorize():
    '''
    ansible color module - colorize
    '''
    from ansible.module_utils._text import to_native
    class fake_color:
        COLOR_OK = 'ok'
        COLOR_SKIP = 'skip'
        COLOR_UNREACHABLE = 'unreachable'
        COLOR_CHANGED = 'changed'
        COLOR_ERROR = 'error'

    fake_sys = type('', (), dict(stdout=type('', (), dict(isatty=lambda *args: True)), version_info=(0,0,0)))()
    fake_curses = type('', (), dict(error=Exception))
    if 'curses' in sys.modules:
        del sys.modules['curses']
    sys.modules['curses'] = fake_curses
    save_stdout = sys

# Generated at 2022-06-23 13:48:15.381358
# Unit test for function hostcolor
def test_hostcolor():
    # hostcolor(hostname, stats)
    status = {}
    status['failures'] = 0
    status['unreachable'] = 0
    status['changed'] = 0
    status['ok'] = 0
    host = 'example.org'
    result = hostcolor(host, status)
    assert result == '%-26s' % host
    status['failures'] = 1
    result = hostcolor(host, status)
    assert '\033[31m%-37s\033[0m' % 'example.org' in result
    status['failures'] = 0
    status['unreachable'] = 1
    result = hostcolor(host, status)
    assert '\033[31m%-37s\033[0m' % 'example.org' in result
    status['unreachable'] = 0

# Generated at 2022-06-23 13:48:24.630272
# Unit test for function colorize
def test_colorize():
    from ansible.utils.color import colorize
    assert colorize('foo', '33', None)         == 'foo=33  '
    assert colorize('foo', '0', 'red')         == 'foo=0   '
    assert colorize('foo', '33', 'red')        == '\x1b[31mfoo=33 \x1b[0m'
    assert colorize('foo', '33', '33')         == '\x1b[33mfoo=33 \x1b[0m'
    assert colorize('foo', '33', 'rgb2552550') == u'\x1b[38;5;214mfoo=33 \x1b[0m'

# Generated at 2022-06-23 13:48:33.422663
# Unit test for function stringc
def test_stringc():
    import sys

    if sys.stdout.isatty():
        COLORS = ['black', 'red', 'green', 'yellow', 'blue', 'magenta', 'cyan', 'white', 'normal']
        TEST_STRING = u'This is a test string.'
        # Print a test string for each color
        for color in COLORS:
            if color == 'normal':
                print(stringc(TEST_STRING, color))
            else:
                print(stringc(TEST_STRING, u'color%d' % (COLORS.index(color) + 1)))


# --- end of "pretty"



# Generated at 2022-06-23 13:48:42.558115
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == u"\x1b[34mtest\x1b[0m"
    assert stringc("test", "color1") == u"\x1b[38;5;1mtest\x1b[0m"
    assert stringc("test", "color1") == u"\x1b[38;5;1mtest\x1b[0m"
    assert stringc("test", "rgb255255255") == u"\x1b[38;5;15mtest\x1b[0m"
    assert stringc("test", "rgb255255255") == u"\x1b[38;5;15mtest\x1b[0m"

# Generated at 2022-06-23 13:48:50.855804
# Unit test for function colorize
def test_colorize():
    for x in range(0, 2):
        for y in range(0, 2):
            for z in range(0, 2):
                print(colorize(u"ok", x, C.COLOR_OK), end=u" ")
                print(colorize(u"changed", y, C.COLOR_CHANGED), end=u" ")
                print(colorize(u"unreachable", z, C.COLOR_UNREACHABLE))

# --- end of "pretty" ---



# Generated at 2022-06-23 13:48:59.826516
# Unit test for function stringc
def test_stringc():
    assert stringc('text', 'red') == '\033[31mtext\033[0m'
    assert stringc('text', 'bright red') == '\033[31mtext\033[0m'
    assert stringc('text', 'red', wrap_nonvisible_chars=True) == '\001\033[31m\002text\001\033[0m\002'
    assert stringc('text', 'red\n', wrap_nonvisible_chars=True) == '\001\033[31m\002text\n\001\033[0m\002'
    assert stringc('text\nwow', 'red', wrap_nonvisible_chars=True) == '\001\033[31m\002text\nwow\001\033[0m\002'

# Generated at 2022-06-23 13:49:09.306369
# Unit test for function parsecolor
def test_parsecolor():
    print('Testing parsecolor() with data from: https://github.com/vifreefly/colortrans')

    assert parsecolor('black')   == '38;5;16'
    assert parsecolor('white')   == '38;5;231'
    assert parsecolor('red')     == '38;5;196'
    assert parsecolor('green')   == '38;5;40'
    assert parsecolor('yellow')  == '38;5;226'
    assert parsecolor('blue')    == '38;5;21'
    assert parsecolor('violet')  == '38;5;177'
    assert parsecolor('cyan')    == '38;5;51'
    assert parsecolor('grey')    == '38;5;245'

# Generated at 2022-06-23 13:49:18.158570
# Unit test for function parsecolor
def test_parsecolor():
    test_patterns = {
        'color0': u'38;5;0',
        'color1': u'38;5;1',
        'color233': u'38;5;233',
        'color255': u'38;5;255',
        'rgb': u'38;5;202',
        'color': u'38;5;11',
        'gray0': u'38;5;8',
        'gray23': u'38;5;231',
        'gray24': u'38;5;232',
        'gray32': u'38;5;233',
    }
    for pattern in test_patterns:
        yield parsecolor, pattern, test_patterns[pattern]

# --- end "pretty"

# Generated at 2022-06-23 13:49:30.201020
# Unit test for function colorize
def test_colorize():
    assert colorize(u'ok', u'1', C.COLOR_OK) == u"ok=1  "
    assert colorize(u'ok', u'1', C.COLOR_CHANGED) == u"ok=1  "
    assert colorize(u'ok', u'1', C.COLOR_ERROR) == u"ok=1  "
    assert colorize(u'ok', u'1', None) == u"ok=1  "
    ANSIBLE_COLOR = False
    assert colorize(u'ok', u'1', C.COLOR_OK) == u"ok=1  "
    assert colorize(u'ok', u'1', C.COLOR_CHANGED) == u"ok=1  "

# Generated at 2022-06-23 13:49:37.421805
# Unit test for function stringc
def test_stringc():
    for color in ["black", "red", "green", "yellow", "blue", "magenta", "cyan",
                  "white", "color1", "color2", "color3", "color4", "color5",
                  "color6", "color7", "color8", "color9", "color10", "color11",
                  "color12", "color13", "color14", "color15", "color16", "color17",
                  "color18", "color19", "color20", "color21", "color22", "color23",
                  "color24", "color25", "color26", "color27", "color28", "color29",
                  "color30", "color31", "color32"]:
        print(stringc(color, color, wrap_nonvisible_chars=True))

# Generated at 2022-06-23 13:49:45.942419
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == C.COLOR_CODES['red']
    assert parsecolor('31') == parsecolor('color31')
    assert parsecolor('rgb123') == parsecolor('rgb1 2 3')
    assert parsecolor('rgb123') == '38;5;33'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray99') == '38;5;231'


# end "pretty"

# Generated at 2022-06-23 13:49:56.089906
# Unit test for function stringc
def test_stringc():
    def _stringc(text, result, color):
        assert stringc(text, color) == result
    for color, code in C.COLOR_CODES.items():
        if color not in ('black', 'white'):
            for wrap_nonvisible_chars in [False, True]:
                _stringc('test', u'\033[%smtest\033[0m' % code, color)
                _stringc('test', u'\001\033[%sm\002test\001\033[0m\002' % code, color, wrap_nonvisible_chars)


# --- end "pretty"



# Generated at 2022-06-23 13:50:06.289473
# Unit test for function stringc

# Generated at 2022-06-23 13:50:10.652012
# Unit test for function colorize
def test_colorize():
    for i in range(0, 11):
        x = "X" * i
        print(colorize("test", x, "blue"))
    print(stringc("This is a test", "red"))


if __name__ == '__main__':
    test_colorize()
    # /end "pretty"

# Generated at 2022-06-23 13:50:21.338663
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
        assert stringc('foo', 'RED') == u'\033[31mfoo\033[0m'
        assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
        assert stringc('foo', 'GREEN') == u'\033[32mfoo\033[0m'
        assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
        assert stringc('foo', 'BLUE') == u'\033[34mfoo\033[0m'
    else:
        assert stringc('foo', 'red') == u'foo'

# Generated at 2022-06-23 13:50:26.372969
# Unit test for function colorize
def test_colorize():
    print(colorize(u"foo", 4, None))
    print(colorize(u"foo", 0, None))
    print(colorize(u"foo", 4, C.COLOR_SKIP))
    print(colorize(u"foo", 0, C.COLOR_CHANGED))


# Generated at 2022-06-23 13:50:37.852207
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures':0,'unreachable':0,'changed':0}

    assert hostcolor(host, stats, color=False) == u"%-26s" % host
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)

    stats['failures'] = 1
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats['failures'] = 0

    stats['unreachable'] = 1
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats['unreachable'] = 0

    stats['changed'] = 1

# Generated at 2022-06-23 13:50:43.248856
# Unit test for function colorize
def test_colorize():
    red = colorize('foo', 0, 'red')
    blue = colorize('foo', 1, 'blue')
    green = colorize('foo', 2, 'green')

    if not ANSIBLE_COLOR:
        assert red == blue
        assert green == blue
    else:
        assert red != blue
        assert red != green
        assert blue != green

# --- end "pretty"



# Generated at 2022-06-23 13:50:54.517690
# Unit test for function hostcolor
def test_hostcolor():
    """Unit test for hostcolor"""
    assert hostcolor("foo", dict(failures=0, unreachable=0, changed=0)) == u"foo                 "
    assert hostcolor("foo", dict(failures=1, unreachable=0, changed=0), color=False) == u"foo                 "
    assert hostcolor("foo", dict(failures=1, unreachable=0, changed=0), color=True) == u"\033[31mfoo\033[0m           "
    assert hostcolor("foo", dict(failures=0, unreachable=1, changed=0), color=True) == u"\033[31mfoo\033[0m           "

# Generated at 2022-06-23 13:51:06.415993
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(
        ok=2,
        changed=0,
        unreachable=0,
        failed=0)) == "localhost                 "
    assert hostcolor("localhost", dict(
        ok=0,
        changed=1,
        unreachable=0,
        failed=0)) == stringc("localhost                 ", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(
        ok=0,
        changed=0,
        unreachable=1,
        failed=0)) == stringc("localhost                 ", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(
        ok=0,
        changed=0,
        unreachable=0,
        failed=2)) == stringc("localhost                 ", C.COLOR_ERROR)

# Generated at 2022-06-23 13:51:13.376887
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test.example.org'
    stats = {'changed': 0, 'unreachable': 0, 'failures': 0}
    color = True
    colorhost = hostcolor(host, stats, color)
    assert colorhost == u"test.example.org                 "
    stats['changed'] = 1
    colorhost = hostcolor(host, stats, color)
    assert colorhost == u"\x1b[0;34;49mtest.example.org\x1b[0m           "
    stats['changed'] = 0
    stats['unreachable'] = 1
    colorhost = hostcolor(host, stats, color)
    assert colorhost == u"\x1b[0;31;49mtest.example.org\x1b[0m           "
    stats['unreachable'] = 0
   

# Generated at 2022-06-23 13:51:20.902292
# Unit test for function hostcolor
def test_hostcolor():
    host_name = u"test_hostname"
    stats_ok = dict(failures=0, unreachable=0, changed=0)
    stats_changed = dict(failures=0, unreachable=0, changed=1)
    stats_failed = dict(failures=1, unreachable=0, changed=1)
    stats_unreachable = dict(failures=0, unreachable=1, changed=1)

    ANSIBLE_COLOR = False
    s = u"%-26s" % host_name
    assert s == hostcolor(host_name, stats_ok)
    assert s == hostcolor(host_name, stats_changed)
    assert s == hostcolor(host_name, stats_failed)
    assert s == hostcolor(host_name, stats_unreachable)


# Generated at 2022-06-23 13:51:32.210424
# Unit test for function stringc
def test_stringc():
    import sys
    assert stringc(u"foo", u"blue") == u"\033[0;34mfoo\033[0m"
    assert stringc(u"foo", u"blink") == u"\033[5mfoo\033[0m"
    assert stringc(u"foo", u"blinkon") == u"\033[5mfoo\033[0m"
    assert stringc(u"foo", u"blinkoff") == u"\033[25mfoo\033[0m"
    assert stringc(u"foo", u"bggreen") == u"\033[42mfoo\033[0m"
    assert stringc(u"foo", u"bgdefault") == u"\033[49mfoo\033[0m"

# Generated at 2022-06-23 13:51:43.734543
# Unit test for function stringc

# Generated at 2022-06-23 13:51:50.343738
# Unit test for function stringc
def test_stringc():
    print(u"stringc test:")
    for c in ['black', 'red', 'green', 'yellow', 'blue', 'purple', 'cyan',
              'light_gray', 'light_red', 'light_green', 'light_yellow',
              'light_blue', 'light_purple', 'light_cyan', 'white']:
        print(stringc(c, c))
    print(stringc('bold', 'bold'))
    print(stringc('underline', 'underline'))
    print(stringc('reverse', 'reverse'))

    print(stringc('color16', 'color16'))
    print(stringc('color17', 'color17'))
    print(stringc('color18', 'color18'))
    print(stringc('color19', 'color19'))

# Generated at 2022-06-23 13:52:02.089154
# Unit test for function hostcolor

# Generated at 2022-06-23 13:52:13.033855
# Unit test for function stringc
def test_stringc():
    assert stringc(u'text', u'blue') == u'\033[34mtext\033[0m'
    assert stringc(u'text', u'rgb255255255') == u'\033[38;5;231mtext\033[0m'
    assert stringc(u'text', u'rgb000255000') == u'\033[38;5;34mtext\033[0m'
    assert stringc(u'text', u'rgb000255255') == u'\033[38;5;37mtext\033[0m'
    assert stringc(u'text', u'rgb255000255') == u'\033[38;5;213mtext\033[0m'

# Generated at 2022-06-23 13:52:22.174062
# Unit test for function colorize
def test_colorize():
    from ansible.playbook.play_context import PlayContext
    from ansible.utils.display import Display
    display = Display()
    display.verbosity = 3

    display.display(colorize("ok", 55, 'green'))
    display.display(colorize("changed", 0, 'yellow'))
    display.display(colorize("unreachable", 1, 'red'))
    display.display(colorize("skipped", 2, 'blue'))
    display.display(colorize("failed", 0, 'red'))



# Generated at 2022-06-23 13:52:31.595286
# Unit test for function colorize
def test_colorize():
    """test suite for colorize() function"""
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch

    def clear_color(text):
        """Strip SGR codes from a text."""
        return re.sub(r"\x1b\[\d+m", "", text)

    def clear_nonvisible_chars(text):
        """Strip non-visible characters from a text."""
        return re.sub(r"\001\x1b\[\d+m\002|\001\x1b\[0m\002", "", text)


# Generated at 2022-06-23 13:52:37.883353
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('skipping', 0, 'cyan') == 'skipping=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0   '
    assert colorize('failed', 0, None) == 'failed=0   '

# --- end "pretty"


# Generated at 2022-06-23 13:52:47.903499
# Unit test for function colorize
def test_colorize():
    assert colorize('test', 0, 'white')      == u'test=0   '
    assert colorize('test', 0, 'black')      == u'test=0   '
    assert colorize('test', 1, 'white')      == u'test=1   '
    assert colorize('test', 2, 'white')      == u'test=2   '
    assert colorize('test', 10, 'white')     == u'test=10  '
    assert colorize('test', 100, 'white')    == u'test=100 '
    assert colorize('test', 1000, 'white')   == u'test=1000'
    assert colorize('test', 10000, 'white')  == u'test=10000'
    assert colorize('test', 100000, 'white') == u'test=100000'

# --- end

# Generated at 2022-06-23 13:52:54.928384
# Unit test for function colorize
def test_colorize():
    """ ansible parse color test """
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('skipped', 0, 'blue') == 'skipped=0'
    assert colorize('failed', 0, 'red') == 'failed=0 '
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'


if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-23 13:53:04.329477
# Unit test for function colorize
def test_colorize():
    from ansible.compat.tests import unittest

    class TestColorize(unittest.TestCase):

        def test_colorize(self):
            self.assertEqual(u'ok=0', colorize(u'ok', 0, None))
            self.assertEqual(u'ok=2', colorize(u'ok', 2, None))
            self.assertEqual(u'ok=1', colorize(u'ok', 1, C.COLOR_OK))
            self.assertEqual(u'ok=1', colorize(u'ok', 1, C.COLOR_CHANGED))
            self.assertEqual(u'ok=1', colorize(u'ok', 1, C.COLOR_ERROR))

    unittest.main(TestColorize, verbosity=2)


# Generated at 2022-06-23 13:53:15.064361
# Unit test for function stringc
def test_stringc():
    """ Test function stringc """
    assert stringc("word", "red") == u'\033[31mword\033[0m'
    assert stringc("word", "green") == u'\033[32mword\033[0m'
    assert stringc("word", "blue") == u'\033[34mword\033[0m'
    assert stringc("word", "magenta") == u'\033[35mword\033[0m'
    assert stringc("word", "cyan") == u'\033[36mword\033[0m'
    assert stringc("word", "yellow") == u'\033[33mword\033[0m'
    assert stringc("word", "black") == u'\033[30mword\033[0m'

# Generated at 2022-06-23 13:53:26.922638
# Unit test for function parsecolor
def test_parsecolor():
    tests = [
        ('color1', '38;5;1'),
        ('color253', '38;5;253'),
        (u'rgb000', '38;5;16'),
        (u'rgb123', '38;5;54'),
        (u'rgb222', '38;5;100'),
        (u'rgb255', '38;5;231'),
        (u'rgb333', '38;5;188'),
        (u'gray0', '38;5;232'),
        (u'gray23', '38;5;250'),
        (u'gray42', '38;5;242'),
        (u'gray253', '38;5;255'),
        (u'badcolor', None),
        (u'badcolor_', None)]


# Generated at 2022-06-23 13:53:33.067298
# Unit test for function hostcolor
def test_hostcolor():
    hc = hostcolor('localhost', dict(failures=0, unreachable=0, changed=0, ok=1))
    assert hc == u"localhost                 "
    hc = hostcolor('localhost', dict(failures=1, unreachable=0, changed=0, ok=0))
    assert hc == u"\033[31m\nlocalhost             \033[0m\n"
    hc = hostcolor('localhost', dict(failures=0, unreachable=1, changed=0, ok=0))
    assert hc == u"\033[31m\nlocalhost             \033[0m\n"
    hc = hostcolor('localhost', dict(failures=0, unreachable=0, changed=1, ok=0))

# Generated at 2022-06-23 13:53:43.117696
# Unit test for function parsecolor
def test_parsecolor():
    def c(s):
        return int(parsecolor(s))
    assert 232 <= c('gray0') < 233
    assert 233 <= c('gray1') < 234
    assert 234 <= c('gray2') < 235
    assert 235 <= c('gray3') < 236
    assert 236 <= c('gray4') < 237
    assert 237 <= c('gray5') < 238
    assert 238 <= c('gray6') < 239
    assert 239 <= c('gray7') < 240
    assert 240 <= c('gray8') < 241
    assert 241 <= c('gray9') < 242
    assert 242 <= c('gray10') < 243
    assert 243 <= c('gray11') < 244
    assert 244 <= c('gray12') < 245
    assert 245 <= c('gray13') < 246
    assert 246 <= c('gray14') < 247
   