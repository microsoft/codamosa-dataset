

# Generated at 2022-06-23 13:43:36.386263
# Unit test for function stringc
def test_stringc():
    print(stringc(u"test text", "blue"))

# --- end "pretty"



# Generated at 2022-06-23 13:43:44.152556
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('black') == '30')
    assert(parsecolor('brightgray') == '37')
    assert(parsecolor('color8') == '38;5;8')
    assert(parsecolor('rgb255255255') == '38;5;15')
    assert(parsecolor('gray8') == '38;5;244')

# --- end "pretty"

# Generated at 2022-06-23 13:43:52.690259
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("color0") == "38;5;0"
    assert parsecolor("color1") == "38;5;1"
    assert parsecolor("color8") == "38;5;8"
    assert parsecolor("color230") == "38;5;230"
    assert parsecolor("color232") == "38;5;232"
    assert parsecolor("color255") == "38;5;255"
    assert parsecolor("rgb123") == "38;5;77"
    assert parsecolor("rgb600") == "38;5;172"
    assert parsecolor("rgb123232") == "38;5;250"
    assert parsecolor("rgb0000") == "38;5;16"

# Generated at 2022-06-23 13:43:59.091074
# Unit test for function colorize
def test_colorize():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == stringc('ok=0', 'green')
    assert colorize('changed', 0, 'yellow') == stringc('changed=0', 'yellow')
    assert colorize('unreachable', 0, 'red') == stringc('unreachable=0', 'red')
    assert colorize('failed', 0, 'red') == stringc('failed=0', 'red')
    assert colorize('skipped', 0, 'cyan') == stringc('skipped=0', 'cyan')
    ANSIBLE_COLOR = False
    assert colorize('ok', 0, 'green') == 'ok=0   '


# Generated at 2022-06-23 13:44:04.038692
# Unit test for function colorize
def test_colorize():
    """
    Perform some simple tests on the colorize function
    """
    assert colorize('foo', 'bar', 'green') == stringc('foo=bar', 'green')
    assert colorize('baz', 'qux', 'blue') != stringc('baz=qux', 'blue')



# Generated at 2022-06-23 13:44:10.827307
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("white") == u'37'
    assert parsecolor("red") == u'31'
    assert parsecolor("color252") == u'38;5;252'
    assert parsecolor("rgb123") == u'38;5;99'
    assert parsecolor("rgb1234") == u'38;5;110'
    assert parsecolor("gray4") == u'38;5;244'
    assert parsecolor("blue") == u'34'
    assert parsecolor("random") == u''
    assert parsecolor("random123") == u''

# Generated at 2022-06-23 13:44:22.520729
# Unit test for function hostcolor
def test_hostcolor():
    # Test hostcolor function
    hc = hostcolor

    # test host
    host = 'http://example.invalid'

    # test result
    stats = dict()
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0

    # case 1: check if all is ok
    print(hc(host, stats))
    # case 2: check if all is ok with False for color
    print(hc(host, stats, False))
    # case 3: check if host is changed
    stats['changed'] = 1
    print(hc(host, stats))
    # case 4: check if host is unreachable
    stats['unreachable'] = 1
    print(hc(host, stats))
    # case 5: check if host is failed

# Generated at 2022-06-23 13:44:27.347037
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == '31'
    assert parsecolor("RED") == '31'
    assert parsecolor("white") == '37'
    assert parsecolor("blue") == '34'
    assert parsecolor("yellow") == '33'
    assert parsecolor("cyan") == '36'



# Generated at 2022-06-23 13:44:37.423941
# Unit test for function hostcolor
def test_hostcolor():
    # stats with no failures or changes
    stats1 = dict(ok=10, skipped=5, failures=0, unreachable=0, changed=0)
    assert hostcolor(u"foo.bar", stats1, True) == u"%-37s" % stringc(u"foo.bar", C.COLOR_OK)
    assert hostcolor(u"foo.bar", stats1, False) == u"%-26s" % u"foo.bar"
    # stats with failures
    stats2 = dict(ok=10, skipped=5, failures=1, unreachable=1, changed=0)
    assert hostcolor(u"foo.bar", stats2, True) == u"%-37s" % stringc(u"foo.bar", C.COLOR_ERROR)

# Generated at 2022-06-23 13:44:48.369417
# Unit test for function colorize
def test_colorize():
    """colorize unit test"""
    good = u'ok      '
    bad = u'failure '
    if sys.version_info[0] > 2:
        good = good.encode('utf-8')
        bad = bad.encode('utf-8')
    if ANSIBLE_COLOR:
        nocolor = dict(changed=1, unreachable=0, failures=0, ok=7, skipped=0)
        nocolor['dark gray'] = stringc(colorize('ok', nocolor['ok'], 'dark gray'), 'dark gray')
        blue = dict(changed=1, unreachable=0, failures=0, ok=7, skipped=0)
        blue['blue'] = stringc(colorize('ok', blue['ok'], 'blue'), 'blue')

# Generated at 2022-06-23 13:44:56.412511
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    assert colorize('test', 0) == 'test=0   '
    assert colorize('test', 1) in [u'test=1   ', u'\033[0;32mtest=1   \033[0m']
    assert colorize('test', 1, 'normal') == 'test=1   '
    assert colorize('test', 0, 'normal') == 'test=0   '



# Generated at 2022-06-23 13:45:04.070893
# Unit test for function stringc
def test_stringc():
    def colour_name_for_id(rgb_id):
        # Return the standard name of a colour for a given RGB value
        # See http://www.w3.org/TR/css3-color/#svg-color
        if rgb_id < 16:
            if rgb_id == 0:
                return u'black'
            if rgb_id == 1:
                return u'navy'
            if rgb_id == 2:
                return u'green'
            if rgb_id == 3:
                return u'teal'
            if rgb_id == 4:
                return u'maroon'
            if rgb_id == 5:
                return u'purple'
            if rgb_id == 6:
                return u'olive'
            if rgb_id == 7:
                return u'silver'

# Generated at 2022-06-23 13:45:15.277522
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'localhost', {'failures': 0, 'unreachable': 0, 'ok': 1, 'changed': 0}) == u"%-37s" % stringc(u'localhost', C.COLOR_OK)
    assert hostcolor(u'localhost', {'failures': 1, 'unreachable': 2, 'ok': 0, 'changed': 0}) == u"%-37s" % stringc(u'localhost', C.COLOR_ERROR)
    assert hostcolor(u'localhost', {'failures': 0, 'unreachable': 0, 'ok': 0, 'changed': 1}) == u"%-37s" % stringc(u'localhost', C.COLOR_CHANGED)

# Generated at 2022-06-23 13:45:25.433860
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('white') == u'1'
    assert parsecolor('black') == u'30'
    assert parsecolor('green') == u'32'
    assert parsecolor('lightblue') == u'94'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color255') == u'38;5;255'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray23') == u'38;5;255'

# Generated at 2022-06-23 13:45:37.768018
# Unit test for function hostcolor
def test_hostcolor():
    host = u'localhost'
    stats = dict(
        ok=10,
        failures=0,
        changed=0,
        unreachable=0,
        skipped=0,
    )
    assert hostcolor(host, stats, True) == u'%-37s' % u'\n'.join(stringc(host, C.COLOR_OK))

    stats = dict(
        ok=0,
        failures=0,
        changed=10,
        unreachable=0,
        skipped=0,
    )
    assert hostcolor(host, stats, True) == u'%-37s' % u'\n'.join(stringc(host, C.COLOR_CHANGED))


# Generated at 2022-06-23 13:45:51.054427
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('dark gray') == '38;5;234'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color15') == '38;5;15'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color99') == '38;5;99'
    assert parsecolor('rgb000') == '38;5;0'
    assert parsecolor('rgb111') == '38;5;15'
    assert parsecolor('rgb555') == '38;5;59'

# Generated at 2022-06-23 13:46:00.931813
# Unit test for function parsecolor
def test_parsecolor():
    '''Return terminal string for color.'''

    assert parsecolor("default") == u'38;5;15'
    assert parsecolor("black") == u'38;5;16'
    assert parsecolor("red") == u'38;5;196'
    assert parsecolor("lightred") == u'38;5;9'
    assert parsecolor("green") == u'38;5;46'
    assert parsecolor("lightgreen") == u'38;5;154'
    assert parsecolor("yellow") == u'38;5;226'
    assert parsecolor("lightyellow") == u'38;5;11'
    assert parsecolor("blue") == u'38;5;21'
    assert parsecolor("lightblue") == u'38;5;51'
    assert parsec

# Generated at 2022-06-23 13:46:11.541114
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo\n", u"red") == u"\033[31mfoo\n\033[0m"
    assert stringc(u"foo", u"color9") == u"\033[38;5;9mfoo\033[0m"
    assert stringc(u"foo", u"rgb25533221") == u"\033[38;5;214mfoo\033[0m"
    assert stringc(u"foo", u"gray8") == u"\033[38;5;244mfoo\033[0m"

# Generated at 2022-06-23 13:46:22.289487
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        print("Warning: colorization is disabled on this system. Not running test_stringc()")
        return
    class tc:
        """Terminal control."""

        @staticmethod
        def handle_gui():
            """Disable colorization for GUI mode."""
            raise Exception("GUI mode not supported")

    tc.handle_gui = tc.handle_gui  # silence pyflakes

    def tassert(test):
        """Assert that colorization works."""
        try:
            assert test()
        except:
            print("test_stringc() failed: %r" % test)

    tassert(lambda: parsecolor('blue') == '34')
    tassert(lambda: parsecolor('rgb010') == '38;5;33')

# Generated at 2022-06-23 13:46:30.770618
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("somehost", dict(failures=0, unreachable=0, changed=0)) == u"%-26s" % "somehost"
    assert hostcolor("somehost", dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % \
                                                            stringc("somehost", C.COLOR_ERROR)
    assert hostcolor("somehost", dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % \
                                                            stringc("somehost", C.COLOR_ERROR)
    assert hostcolor("somehost", dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % \
                                                            stringc("somehost", C.COLOR_CHANGED)

# Generated at 2022-06-23 13:46:36.718875
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("blue") == "34"
    assert parsecolor("color7") == "38;5;7"
    assert parsecolor("rgb123") == "38;5;27"
    assert parsecolor("rgb555") == "38;5;231"
    assert parsecolor("rgb256") == "38;5;122"

# Generated at 2022-06-23 13:46:46.811924
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('bold red') == '1;31'
    assert parsecolor('on_red') == '41'
    assert parsecolor('bold on_red') == '1;41'
    assert parsecolor('underline on_red') == '4;41'
    assert parsecolor('underline bold on_red') == '4;1;41'
    assert parsecolor('black on_white') == '30;47'
    assert parsecolor('white on_black') == '37;40'
    assert parsecolor('default') == '39'
    assert parsecolor('blue') == '34'
    assert parsecolor('green') == '32'
    assert parsecolor('cyan') == '36'

# Generated at 2022-06-23 13:46:57.333440
# Unit test for function parsecolor
def test_parsecolor():

    # Test standard colors
    assert parsecolor('red') == '31'
    assert parsecolor('black') == '30'
    assert parsecolor('blue') == '34'

    # Test actual color numbers
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color232') == '38;5;232'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('color0') == '38;5;0'

    # Test grayscale
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('gray2') == '38;5;234'

# Generated at 2022-06-23 13:47:09.418672
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"localhost", {'failures': 0, 'changed': 0, 'ok': 3, 'skipped': 0, 'unreachable': 0}) == u"%-37s" % stringc(u"localhost", C.COLOR_OK)
    assert hostcolor(u"localhost", {'failures': 1, 'changed': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}) == u"%-37s" % stringc(u"localhost", C.COLOR_ERROR)
    assert hostcolor(u"localhost", {'failures': 0, 'changed': 1, 'ok': 2, 'skipped': 0, 'unreachable': 0}) == u"%-37s" % stringc(u"localhost", C.COLOR_CHANGED)

# Generated at 2022-06-23 13:47:12.309961
# Unit test for function hostcolor
def test_hostcolor():
    # Run tests for all three combinations of color and no color
    for color in (True, False):
        yield check_hostcolor, color


# Generated at 2022-06-23 13:47:24.009170
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", 'white') == u"\033[38;5;15mfoo\033[0m"
    assert stringc("foo", 'black', wrap_nonvisible_chars=True) == u"\001\033[38;5;0m\002foo\001\033[0m\002"
    assert stringc("foo", 'gray', wrap_nonvisible_chars=True) == u"\001\033[38;5;7m\002foo\001\033[0m\002"
    assert stringc("foo", 'rgb255', wrap_nonvisible_chars=True) == u"\001\033[38;5;15m\002foo\001\033[0m\002"

# Generated at 2022-06-23 13:47:34.986597
# Unit test for function stringc
def test_stringc():
    ''' stringc can be tested with `make color-test` '''
    # some basic checks
    assert "foo=bar" == stringc("foo=bar", "black")
    assert "foo=bar" == stringc("foo=bar", None)
    assert "foo=bar" == stringc("foo=bar", "")
    assert "foo=bar" == stringc("foo=bar", "NORMAL")
    assert "foo=bar" == stringc("foo=bar", "normal")
    assert "foo=bar" == stringc("foo=bar", "bLacK")

    # test foreground colors
    assert "foo=bar" == stringc("foo=bar", "default")
    assert "foo=bar" == stringc("foo=bar", "DEFAULT")

# Generated at 2022-06-23 13:47:45.234737
# Unit test for function colorize
def test_colorize():
    return
    print(colorize('ok', 0, 'green'))
    print(colorize('changed', 0, 'yellow'))
    print(colorize('unreachable', 0, 'red'))
    print(colorize('failed', 0, 'red'))
    print(colorize('ok', 1, 'green'))
    print(colorize('changed', 1, 'yellow'))
    print(colorize('unreachable', 1, 'red'))
    print(colorize('failed', 1, 'red'))

#
# --- end "pretty"

# -------------------------------
# --- begin "command runner" ---
# -------------------------------


# Generated at 2022-06-23 13:47:51.136393
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('darkgray') == u'38;5;242'
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('brightred') == u'38;5;9'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('brightgreen') == u'38;5;10'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('brightyellow') == u'38;5;11'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('brightblue') == u'38;5;12'

# Generated at 2022-06-23 13:48:01.906450
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('cyan') == u'38;5;14'
    assert parsecolor('blue') == u'38;5;12'
    assert parsecolor('black') == u'38;5;232'
    assert parsecolor('green') == u'38;5;34'
    assert parsecolor('gray1') == u'38;5;235'
    assert parsecolor('darkgray') == u'38;5;240'
    assert parsecolor('darkblue') == u'38;5;18'
    assert parsecolor('brightgreen') == u'38;5;2'
    assert parsecolor('white') == u'38;5;15'
    assert parsecolor('red') == u'38;5;9'

# Generated at 2022-06-23 13:48:11.786542
# Unit test for function hostcolor
def test_hostcolor():
    # test connection success, changed=1
    h = hostcolor('host1', dict(failures=0, unreachable=0, changed=1))
    assert h == stringc('host1', C.COLOR_CHANGED) + u' '

    # test connection success, changed=0
    h = hostcolor('host1', dict(failures=0, unreachable=0, changed=0))
    assert h == stringc('host1', C.COLOR_OK) + u' '

    # test connection failure (unreachable)
    h = hostcolor('host1', dict(failures=0, unreachable=1, changed=0))
    assert h == stringc('host1', C.COLOR_ERROR) + u' '

    # test connection failure (failed)

# Generated at 2022-06-23 13:48:22.377238
# Unit test for function colorize
def test_colorize():

    # ANSIBLE_COLOR is set to True, color is not None => should be colorized
    s = colorize(u'ok', 1, C.COLOR_OK)
    assert u"%s=%s" % (u'\033[32mok\033[0m', u'1   ') == s, "colorize returned wrong value: got %s instead of %s" % (s, u"%s=%s" % (u'\033[32mok\033[0m', u'1   '))

    # ANSIBLE_COLOR is set to True, color is None => should not be colorized
    s = colorize(u'ok', 1, None)

# Generated at 2022-06-23 13:48:33.473166
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(color='red') == '31'
    assert parsecolor(color='dark red') == '31'
    assert parsecolor(color='green') == '32'
    assert parsecolor(color='dark green') == '32'
    assert parsecolor(color='yellow') == '33'
    assert parsecolor(color='blue') == '34'
    assert parsecolor(color='dark blue') == '34'
    assert parsecolor(color='magenta') == '35'
    assert parsecolor(color='dark magenta') == '35'
    assert parsecolor(color='cyan') == '36'
    assert parsecolor(color='dark cyan') == '36'
    assert parsecolor(color='dark gray') == '30'
    assert parsecolor(color='black')

# Generated at 2022-06-23 13:48:42.591541
# Unit test for function parsecolor

# Generated at 2022-06-23 13:48:54.189384
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        print("No Ansi Color support detected, skipping test")
        return
    sys.stdout.write(stringc("This is green", "green"))
    sys.stdout.write(stringc("This is red", "red"))
    sys.stdout.write(stringc("This is blue", "blue"))
    sys.stdout.write(stringc("This is magenta", "magenta"))
    sys.stdout.write(stringc("This is cyan", "cyan"))
    sys.stdout.write(stringc("This is yellow", "yellow"))
    sys.stdout.write(stringc("This is bright white", "bright white"))
    sys.stdout.write(stringc("This is bright cyan", "bright cyan"))

# Generated at 2022-06-23 13:48:59.011674
# Unit test for function stringc
def test_stringc():
    assert stringc(u"text", u"red") == u"\033[31mtext\033[0m"
    assert stringc(u"text", u"gray5") == u"\033[38;5;247mtext\033[0m"
    assert stringc(u"text", u"rgb543") == u"\033[38;5;114mtext\033[0m"
    assert stringc(u"text", u"color1") == u"\033[38;5;1mtext\033[0m"
    assert stringc(u"text", u"color11") == u"\033[38;5;11mtext\033[0m"
    assert stringc(u"text", u"invalid") == u"text"

# Generated at 2022-06-23 13:49:08.782581
# Unit test for function colorize
def test_colorize():
    print(u"\nTest colorize()")
    print(u"%s" % colorize(u"ok", 0, C.COLOR_OK))
    print(u"%s" % colorize(u"changed", 0, C.COLOR_CHANGED))
    print(u"%s" % colorize(u"unreachable", 0, C.COLOR_UNREACHABLE))
    print(u"%s" % colorize(u"failed", 0, C.COLOR_ERROR))
    print(u"%s" % colorize(u"skipped", 0, C.COLOR_SKIP))
    print(u"%s" % colorize(u"ok", 1, C.COLOR_OK))
    print(u"%s" % colorize(u"changed", 1, C.COLOR_CHANGED))


# Generated at 2022-06-23 13:49:18.036229
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('server01.example.com', {}) == "%-26s" % u'server01.example.com'
    assert hostcolor('server01.example.com', {'changed': 1}) == u'%-37s' % u"\n".join([u"\033[0;36mserver01.example.com\033[0m"])
    assert hostcolor('server01.example.com', {'failures': 1}) == u'%-37s' % u"\n".join([u"\033[0;31mserver01.example.com\033[0m"])

# Generated at 2022-06-23 13:49:27.152697
# Unit test for function hostcolor
def test_hostcolor():
    s = 'hello'
    stats = {}
    assert hostcolor(s, stats) == u"%-37s" % s
    stats['failures'] = 1
    assert hostcolor(s, stats) == u"%-37s" % stringc(s, C.COLOR_ERROR)
    stats['failures'] = 0
    stats['changed'] = 1
    assert hostcolor(s, stats) == u"%-37s" % stringc(s, C.COLOR_CHANGED)
    stats['changed'] = 0
    assert hostcolor(s, stats) == u"%-37s" % stringc(s, C.COLOR_OK)
    stats['unreachable'] = 1
    assert hostcolor(s, stats) == u"%-37s" % stringc(s, C.COLOR_ERROR)

# Generated at 2022-06-23 13:49:35.377343
# Unit test for function stringc
def test_stringc():
    assert ANSIBLE_COLOR
    assert stringc(u'foo', u'black')
    assert stringc(u'foo', u'red')
    assert stringc(u'foo', u'green')
    assert stringc(u'foo', u'yellow')
    assert stringc(u'foo', u'blue')
    assert stringc(u'foo', u'purple')
    assert stringc(u'foo', u'cyan')
    assert stringc(u'foo', u'light_gray')
    assert stringc(u'foo', u'dark_gray')
    assert stringc(u'foo', u'light_red')
    assert stringc(u'foo', u'light_green')
    assert stringc(u'foo', u'light_yellow')

# Generated at 2022-06-23 13:49:45.644557
# Unit test for function colorize
def test_colorize():
    """Test API method colorize"""

    # These tests will only pass if run in a terminal that supports color
    # $  python -m ansible.utils.colorize
    # colorize(u'ok', 0, u'green')
    # colorize(u'changed', 1, u'red')
    # colorize(u'unreachable', 1, u'magenta')
    # colorize(u'failed', 1, u'white')
    # colorize(u'failed', 1, u'ligh red')
    # colorize(u'skipped', 1, u'cyan')
    # colorize(u'ok', 1, None)

    # Here are some test cases. They will only pass if run in a terminal that supports color
    print(u'colorize(u\"ok\", 0, u\"green\")')


# Generated at 2022-06-23 13:49:49.996302
# Unit test for function colorize
def test_colorize():
    # Ensure we can colorize strings
    s = colorize("test", 0, 'black')
    assert s == "test=0   ", "colorize() failed"



# Generated at 2022-06-23 13:49:58.917148
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize("test1", 1, C.COLOR_CHANGED) == "\033[0;36mtest1=1   \033[0m"
        assert colorize("test2", 0, C.COLOR_ERROR) == "\033[0;31mtest2=0   \033[0m"
        assert colorize("test3", 123, C.COLOR_OK) == "\033[0;32mtest3=123 \033[0m"
        assert colorize("test4", 0, C.COLOR_WARN) == "\033[0;33mtest4=0   \033[0m"
        assert colorize("test5", 0, "C.COLOR_SKIP") == "\033[0;37mtest5=0   \033[0m"


# Generated at 2022-06-23 13:50:04.194516
# Unit test for function stringc
def test_stringc():
    """Test the effects of coloring ansible output.

    >>> test_stringc()
    (u'\x1b[32mfoo\x1b[0m', u'\x1b[31mbar\x1b[0m')

    """
    return (stringc('foo', 'green'), stringc('bar', 'red'))

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# end "pretty"

# Generated at 2022-06-23 13:50:16.108799
# Unit test for function hostcolor
def test_hostcolor():
    host = 'host'
    stats = {'ok':1, 'changed':1, 'unreachable':0, 'failures':0, 'skipped':0}
    colorize_host = hostcolor(host, stats, color=True)
    # host is changed, should get bold yellow string.
    assert(colorize_host.split()[0] == stringc(host, 'yellow'))
    stats = {'ok':1, 'changed':0, 'unreachable':0, 'failures':1, 'skipped':0}
    colorize_host = hostcolor(host, stats, color=True)
    # host has failrue, should get bold red string
    assert(colorize_host.split()[0] == stringc(host, 'red'))

# Generated at 2022-06-23 13:50:24.845643
# Unit test for function hostcolor
def test_hostcolor():
    stats = {}
    host = 'localhost'
    color = True
    # no stat
    expected = '%-37s' % host
    result = hostcolor(host, stats, color)
    assert result == expected

    # no error
    stats = {'failures': 0,
             'unreachable': 0}
    expected = stringc('%-37s' % host, C.COLOR_OK)
    result = hostcolor(host, stats, color)
    assert result == expected

    # with changed
    stats = {'changed': 1,
             'failures': 0,
             'unreachable': 0}
    expected = stringc('%-37s' % host, C.COLOR_CHANGED)
    result = hostcolor(host, stats, color)
    assert result == expected

    # with failures

# Generated at 2022-06-23 13:50:36.527137
# Unit test for function hostcolor
def test_hostcolor():
    s = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(u"localhost", s) == u"%-37s" % u"localhost"
    s = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(u"localhost", s, True) == u"%-37s" % stringc(u"localhost", C.COLOR_ERROR)
    s = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor(u"localhost", s, True) == u"%-37s" % stringc(u"localhost", C.COLOR_ERROR)
    s = dict(failures=0, unreachable=0, changed=1)

# Generated at 2022-06-23 13:50:47.886798
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('cyan') == '36'
    assert parsecolor('magenta') == '35'
    assert parsecolor('yellow') == '33'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('color8') != '38;5;9'
    assert parsecolor('color232') == '38;5;232'
    assert parsecolor('color232') != '38;5;231'
    assert parsecolor('rgb123') == '38;5;123'

# Generated at 2022-06-23 13:50:56.042480
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color220') == '38;5;220'
    assert parsecolor('rgb222') == '38;5;60'
    assert parsecolor('rgb500') == '38;5;231'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray23') == '38;5;255'
    with pytest.raises(KeyError):
        assert parsecolor('color256')
    with pytest.raises(KeyError):
        assert parsecolor('color2565')



# Generated at 2022-06-23 13:51:00.309003
# Unit test for function parsecolor
def test_parsecolor():
    return parsecolor('purple') == '35' and parsecolor('color124') == '38;5;124' and parsecolor('rgb100') == '38;5;45' and parsecolor('gray1') == '38;5;233'

# Generated at 2022-06-23 13:51:09.984362
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.compat.tests import unittest

    class TestHostColor(unittest.TestCase):
        def test_hostcolor(self):
            global ANSIBLE_COLOR
            orig_ansible_color = ANSIBLE_COLOR
            ANSIBLE_COLOR = True

# Generated at 2022-06-23 13:51:18.702205
# Unit test for function parsecolor
def test_parsecolor():
    for color, color_code in C.COLOR_CODES.items():
        assert parsecolor(color) == color_code
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color171') == '38;5;171'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb100') == '38;5;66'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb123') == '38;5;87'
    assert parsecolor('rgb333') == '38;5;123'


# Generated at 2022-06-23 13:51:27.733223
# Unit test for function colorize
def test_colorize():
    # Disable color, positive numbers
    ANSIBLE_COLOR = False
    assert colorize('good', 1, 'green') == 'good=1  '
    assert colorize('bad', 1, 'red') == 'bad=1    '
    # Enable color, negative numbers
    ANSIBLE_COLOR = True
    assert colorize('good', -1, 'green') == 'good=-1 '
    assert colorize('bad', -1, 'red') == 'bad=-1   '

if __name__ == "__main__":
    test_colorize()

# Generated at 2022-06-23 13:51:38.930755
# Unit test for function colorize
def test_colorize():
    """ unit testing for colorize """

    class FakeTerm:
        def __init__(self):
            self.isatty = True

    # force color on
    sys.stdout = FakeTerm()
    C.ANSIBLE_NOCOLOR = False

    if not ANSIBLE_COLOR:
        print("\n * ansible.utils.color.ANSIBL_COLOR is False, skipping test")
        return False

    def fake_print(msg):
        sys.stdout.write(msg)

    null = u'\x1b[00;00m'

    # print null host string
    fake_print(hostcolor(u'localhost', {}))

    # print colorized 'localhost' for fail
    stats = {'failures': 1, 'unreachable': 0}

# Generated at 2022-06-23 13:51:45.719267
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'1') == u'38;5;1'
    assert parsecolor(u'rgb255000') == u'38;5;196'
    assert parsecolor(u'gray8') == u'38;5;250'
    assert parsecolor(u'something else') == u'30'

if __name__ == '__main__':
    test_parsecolor()

# Generated at 2022-06-23 13:51:56.145818
# Unit test for function colorize
def test_colorize():
    for c in ['red', 'green', 'yellow', 'blue', 'magenta', 'cyan',
              'white', 'black', 'darkred', 'darkgreen', 'darkyellow',
              'darkblue', 'darkmagenta', 'darkcyan', 'darkgray',
              'lightred', 'lightgreen', 'lightyellow', 'lightblue',
              'lightmagenta', 'lightcyan', 'lightgray', 'default']:
        print(u"%sCOLOR%s" % (stringc(c, c), stringc("-TEST-", c)))

# --- end "pretty"



# Generated at 2022-06-23 13:52:01.940976
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;16'
    assert parsecolor('bright black') == u'38;5;8'
    assert parsecolor('red') == u'38;5;196'
    assert parsecolor('bright red') == u'38;5;160'
    assert parsecolor('green') == u'38;5;70'
    assert parsecolor('bright green') == u'38;5;34'
    assert parsecolor('yellow') == u'38;5;227'
    assert parsecolor('bright yellow') == u'38;5;190'
    assert parsecolor('blue') == u'38;5;21'
    assert parsecolor('bright blue') == u'38;5;18'

# Generated at 2022-06-23 13:52:12.885349
# Unit test for function parsecolor
def test_parsecolor():
    # Test named colors
    for name in C.COLOR_CODES:
        if name != 'none':
            assert parsecolor(name) == C.COLOR_CODES[name]
    # Test numeric colors
    for i in range(0, 256):
        assert parsecolor('color%d' % i) == '38;5;%d' % i
    # Test gray
    for i in range(0, 24):
        assert parsecolor('gray%d' % i) == '38;5;%d' % (232 + i)
    # Test rgb

# Generated at 2022-06-23 13:52:25.487827
# Unit test for function hostcolor
def test_hostcolor():
    if not ANSIBLE_COLOR:
        return
    # Use a 512-wide terminal to accommodate wide colors
    curses.setupterm(term='xterm-256color', fd=1)
    reset = "\033[0m"
    def cleanup(s):
        return re.sub(r"\x1b\[\d+(;\d+)?m", "", s)
    hc = hostcolor
    assert cleanup(hc("localhost", {"changed": 0, "failures": 0, "ok": 1, "skipped": 0, "unreachable": 0})) == "localhost"
    assert cleanup(hc("localhost", {"changed": 1, "failures": 0, "ok": 1, "skipped": 0, "unreachable": 0})) == "localhost"

# Generated at 2022-06-23 13:52:35.387248
# Unit test for function colorize
def test_colorize():
    if not ANSIBLE_COLOR:
        print("(not supported in this terminal due to color desabling)")
        return
    print(colorize(u"ok", 0, C.COLOR_OK))
    print(colorize(u"changed", 0, C.COLOR_CHANGED))
    print(colorize(u"unreachable", 0, C.COLOR_UNREACHABLE))
    print(colorize(u"failed", 0, C.COLOR_ERROR))
    print(colorize(u"ok", 1, C.COLOR_OK))
    print(colorize(u"changed", 1, C.COLOR_CHANGED))
    print(colorize(u"unreachable", 1, C.COLOR_UNREACHABLE))
    print(colorize(u"failed", 1, C.COLOR_ERROR))

# Generated at 2022-06-23 13:52:41.346447
# Unit test for function colorize
def test_colorize():
    assert colorize("ok", 0, "green") == "ok=0   "
    assert colorize("changed", 0, "yellow") == "changed=0 "
    assert colorize("failed", 0, "red") == "failed=0  "
    assert colorize("unreachable", 0, "red") == "unreachable=0"

# --- end "pretty"



# Generated at 2022-06-23 13:52:46.845507
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test.example.com", dict(ok=1, failures=0, unreachable=0, changed=0)) == "test.example.com             "
    assert hostcolor("test.example.com", dict(ok=0, failures=1, unreachable=0, changed=0), color=True) == "\x1b[31mtest.example.com\x1b[0m   "
    assert hostcolor("test.example.com", dict(ok=0, failures=0, unreachable=0, changed=1), color=True) == "\x1b[33mtest.example.com\x1b[0m   "

# Generated at 2022-06-23 13:52:51.319098
# Unit test for function colorize
def test_colorize():
    lead = "test"
    num = 42
    color = "33"

    s = colorize(lead, num, color)
    print(s)

# test_colorize()
# --- end "pretty"



# Generated at 2022-06-23 13:53:01.614552
# Unit test for function colorize
def test_colorize():
    # No Color
    lead = u"ok"
    num = 10
    color = C.COLOR_OK
    assert colorize(lead, num, color) == u"ok=10  "

    # Color
    ANSIBLE_COLOR = True
    assert colorize(lead, num, color) == u"\033[32mok=10  \033[0m"

    lead = u"changed"
    num = 10
    color = C.COLOR_CHANGED
    assert colorize(lead, num, color) == u"\033[33mchanged=10\033[0m"

    lead = u"unreachable"
    num = 0
    color = C.COLOR_UNREACHABLE
    assert colorize(lead, num, color) == u"\033[31munreachable=0 \033[0m"

# Generated at 2022-06-23 13:53:06.017369
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(u'blue') == u'34'
    assert parsecolor(u'color246') == u'38;5;246'
    assert parsecolor(u'rgb253') == u'38;5;253'
    assert parsecolor(u'gray11') == u'38;5;243'
    assert parsecolor(u'notacolor') == u'31'


# Generated at 2022-06-23 13:53:16.616553
# Unit test for function hostcolor
def test_hostcolor():
    require_ansible_color = [
        (True, "%-37s" % "localhost", {}),
        (True, "%-37s" % stringc("localhost", C.COLOR_ERROR),
         dict(unreachable=1)),
        (True, "%-37s" % stringc("localhost", C.COLOR_CHANGED),
         dict(changed=1)),
        (True, "%-37s" % stringc("localhost", C.COLOR_OK),
         dict(changed=0))
    ]
    require_ansible_no_color = [
        (False, "%-26s" % "localhost", {})
    ]
    all_tests = require_ansible_color + require_ansible_no_color
    for ansible_color, result, stats in all_tests:
        global ANSIBLE_COLOR


# Generated at 2022-06-23 13:53:28.253640
# Unit test for function parsecolor
def test_parsecolor():
    """Test function parsecolor"""
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('blink') == u'5'
    assert parsecolor('underline') == u'4'
    assert parsecolor('bold') == u'1'
    assert parsecolor('darkgray') == u'30'
    assert parsecolor('color1') == u'38;5;1'

# Generated at 2022-06-23 13:53:36.752014
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("black") == '30'
    assert parsecolor("red") == '31'
    assert parsecolor("green") == '32'
    assert parsecolor("yellow") == '33'
    assert parsecolor("blue") == '34'
    assert parsecolor("magenta") == '35'
    assert parsecolor("cyan") == '36'
    assert parsecolor("light_gray") == '37'
    assert parsecolor("dark_gray") == '38;5;240'
    assert parsecolor("light_red") == '38;5;9'
    assert parsecolor("light_green") == '38;5;10'
    assert parsecolor("light_yellow") == '38;5;11'