

# Generated at 2022-06-23 13:43:44.604455
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('black') == '30')
    assert(parsecolor('red') == '31')
    assert(parsecolor('green') == '32')
    assert(parsecolor('yellow') == '33')
    assert(parsecolor('blue') == '34')
    assert(parsecolor('magenta') == '35')
    assert(parsecolor('cyan') == '36')
    assert(parsecolor('white') == '37')
    assert(parsecolor('default') == '39')
    assert(parsecolor('bg_black') == '40')
    assert(parsecolor('bg_red') == '41')
    assert(parsecolor('bg_green') == '42')
    assert(parsecolor('bg_yellow') == '43')

# Generated at 2022-06-23 13:43:52.907839
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('normal') == u'39'
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('light gray') == u'37'
    assert parsecolor('gray7') == u'38;5;7'
    assert parsecolor('gray47') == u'38;5;47'
    assert parsecolor('gray100') == u'38;5;232'

# Generated at 2022-06-23 13:43:59.649679
# Unit test for function parsecolor
def test_parsecolor():
    """Test the parsecolor function."""
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('color15') == u'38;5;15'

# Generated at 2022-06-23 13:44:08.907106
# Unit test for function stringc
def test_stringc():
    # Tests without colors
    old_env_var = os.environ.get('ANSIBLE_NOCOLORS', None)
    os.environ['ANSIBLE_NOCOLORS'] = "True"
    try:
        assert stringc("foo","red") == "foo"
    finally:
        if old_env_var is not None:
            os.environ['ANSIBLE_NOCOLORS'] = old_env_var
        else:
            del os.environ['ANSIBLE_NOCOLORS']

    # Tests with colors
    old_env_var = os.environ.get('ANSIBLE_NOCOLORS', None)
    if old_env_var is not None:
        del os.environ['ANSIBLE_NOCOLORS']

# Generated at 2022-06-23 13:44:10.944829
# Unit test for function stringc
def test_stringc():
    print(stringc("This is red text", "red"))



# Generated at 2022-06-23 13:44:22.641196
# Unit test for function parsecolor
def test_parsecolor():
    assert u'38;5;%d' % 0 == parsecolor('black')
    assert u'38;5;%d' % 7 == parsecolor('white')
    assert u'38;5;%d' % 3 == parsecolor('yellow')
    assert u'38;5;%d' % 8 == parsecolor('rgb000')
    assert u'38;5;%d' % 232 == parsecolor('rgb555')
    assert u'38;5;%d' % 246 == parsecolor('rgb555')
    assert u'38;5;%d' % 124 == parsecolor('gray0')
    assert u'38;5;%d' % 231 == parsecolor('gray23')
    assert u'38;5;%d' % 255 == parsecolor('gray24')
   

# Generated at 2022-06-23 13:44:27.442619
# Unit test for function hostcolor
def test_hostcolor():
    host = 'myhost'
    stats = {'ok': 1, 'changed': 0, 'dark': 0, 'skipped': 0, 'pending': 0, 'failures': 0, 'processed': 1, 'rescued': 0, 'ignored': 0, 'unreachable': 0}

    host_string = hostcolor(host, stats)
    assert host_string == u"%-26s" % host, host_string

# --- end "pretty"



# Generated at 2022-06-23 13:44:37.526368
# Unit test for function stringc

# Generated at 2022-06-23 13:44:48.455076
# Unit test for function stringc
def test_stringc():
    # Set up some test strings
    a = "Hello"
    b = "Hello World"
    c = "Hello\nWorld"
    d = "Hello\nWorld\nBig\nWorld"

    # Simple test, should just return the string
    assert stringc(a, "green", wrap_nonvisible_chars=False) == u"\033[32mHello\033[0m"
    assert stringc(a, "green", wrap_nonvisible_chars=True) == u"\001\033[32m\002Hello\001\033[0m\002"

    # Test newline handling
    assert stringc(b, "green", wrap_nonvisible_chars=False) == u"\033[32mHello World\033[0m"

# Generated at 2022-06-23 13:45:00.556102
# Unit test for function colorize
def test_colorize():
    # If there is no problem, the number should be printed in blue
    assert colorize(u'ok', 10, C.COLOR_OK) == u'ok=10  '

    # If there is a changed result, the number should be printed
    # in yellow/brown
    assert colorize(u'changed', 10, C.COLOR_CHANGED) == u'changed=10  '

    # If there is a problem, the number should be printed in red
    assert colorize(u'failed', 10, C.COLOR_ERROR) == u'failed=10 '

    # If ANSIBLE_COLOR is set to False at the top of
    # this module, no colors should be applied
    result = colorize(u'ok', 10, C.COLOR_OK)
    assert result == u'ok=10  '

# --- end of "pretty

# Generated at 2022-06-23 13:45:04.172899
# Unit test for function colorize
def test_colorize():
    print(colorize('foo', 42, 'green'), end='')
    print(colorize('bar', 0, 'yellow'), end='')


# --- end "pretty"


# Generated at 2022-06-23 13:45:12.710810
# Unit test for function stringc
def test_stringc():
    """Test function stringc"""

    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "yellow") == "\033[33mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"



# Generated at 2022-06-23 13:45:19.195398
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '


# Generated at 2022-06-23 13:45:26.497263
# Unit test for function colorize
def test_colorize():
    assert "ok=0 " == colorize(u'ok', 0, None)
    assert "ok=0 " == colorize(u'ok', 0, 'red')
    assert "ok=0 " == colorize(u'ok', 0, 'blue')
    assert "ok=0 " == colorize(u'ok', 0, 'yellow')
    assert "ok=0 " == colorize(u'ok', 0, 'green')
    assert "\x1b[0mok=1 \x1b[0m" == colorize(u'ok', 1, None)
    assert "\x1b[31mok=1 \x1b[0m" == colorize(u'ok', 1, 'red')

# Generated at 2022-06-23 13:45:29.882591
# Unit test for function colorize
def test_colorize():
    # Ligh Red
    color = 'Ligh Red'
    fail = colorize('failed', 1, color)
    assert fail == stringc('failed=1', color)


# Generated at 2022-06-23 13:45:40.771154
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("RED") == "31"
    assert parsecolor("red") == "31"
    assert parsecolor("31") == "31"

    # Test for 8-bit colors
    assert parsecolor("color8") == "38;5;8"
    assert parsecolor("color8") == "38;5;8"
    assert parsecolor("color226") == "38;5;226"

    # Test for rgb colors
    assert parsecolor("rgb000") == "38;5;16"
    assert parsecolor("rgb123") == "38;5;54"
    assert parsecolor("rgb222") == "38;5;100"

    # Test for grayscale
    assert parsecolor("gray0") == "38;5;232"

# Generated at 2022-06-23 13:45:53.106160
# Unit test for function parsecolor

# Generated at 2022-06-23 13:46:03.800296
# Unit test for function hostcolor

# Generated at 2022-06-23 13:46:14.914758
# Unit test for function hostcolor
def test_hostcolor():
    assert u"%-37s" % stringc(u"foo", C.COLOR_ERROR) is not None
    assert u"%-37s" % stringc(u"foo", C.COLOR_CHANGED) is not None
    assert u"%-37s" % stringc(u"foo", C.COLOR_OK) is not None
    assert hostcolor("foo", dict(failures=0, unreachable=0, changed=0), color=False) is not None
    assert hostcolor("foo", dict(failures=0, unreachable=0, changed=0), color=True) is not None
    unicode_str = u'\u00F6\u00E4\u00FC'
    assert hostcolor(unicode_str, dict(failures=0, unreachable=0, changed=0), color=False) is not None

# Generated at 2022-06-23 13:46:24.955502
# Unit test for function hostcolor
def test_hostcolor():
    # Test false condition (no color)
    result = hostcolor(u'localhost', {u'changed': 0, u'failures': 0, u'ok': 1, u'skipped': 0, u'unreachable': 0}, False)
    assert result == u'localhost               ', "Result : %s" % result

    # Test success condition
    result = hostcolor(u'localhost', {u'changed': 0, u'failures': 0, u'ok': 1, u'skipped': 0, u'unreachable': 0})
    print(repr(result))
    assert result == u'\x1b[0;32mlocalhost\x1b[0m            ', "Result : %s" % result

    # Test changed condition

# Generated at 2022-06-23 13:46:36.054543
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.color import hostcolor
    from ansible.utils.color import stringc
    a = u'localhost                  '
    b = u'host1                      '
    c = u'host2                      '
    assert hostcolor('localhost', {'failures':0, 'unreachable':0, 'changed':0}) == a
    assert hostcolor('host1', {'failures':1, 'unreachable':0, 'changed':0}) == stringc(b, C.COLOR_ERROR)
    assert hostcolor('host2', {'failures':0, 'unreachable':1, 'changed':0}) == stringc(c, C.COLOR_ERROR)

# Generated at 2022-06-23 13:46:46.282488
# Unit test for function hostcolor
def test_hostcolor():
    fakehost = "faketesthost"
    fakehost_changed = "faketesthost_changed"
    fakehost_unreachable = "faketesthost_unreachable"
    fakehost_failed = "faketesthost_failed"
    fakehost_ok = "faketesthost_ok"

    # Testing changed
    fake_stats = {
        'changed': 1,
        'failures': 0,
        'ok': 2,
        'skipped': 0,
        'unreachable': 0,
        'dark': 0
    }
    assert hostcolor(fakehost_changed, fake_stats) == u"\n".join([u"%-37s" % stringc(fakehost_changed, C.COLOR_CHANGED)])

    # Testing unreachable

# Generated at 2022-06-23 13:46:57.183592
# Unit test for function hostcolor
def test_hostcolor():
    myhost = 'hostname'
    mystats1 = {'failures': 0, 'unreachable': 0, 'changed': 0}
    mystats2 = {'failures': 1, 'unreachable': 0, 'changed': 0}
    mystats3 = {'failures': 0, 'unreachable': 1, 'changed': 0}
    mystats4 = {'failures': 0, 'unreachable': 0, 'changed': 1}
    mystats5 = {'failures': 1, 'unreachable': 1, 'changed': 1}
    if hostcolor(myhost,mystats1) != '%-37s' % stringc(myhost, C.COLOR_OK):
        raise Exception('hostcolor fail 1')

# Generated at 2022-06-23 13:47:07.041883
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test\nmultiline", "green") == u"\033[32mtest\033[0m\n\033[32mmultiline\033[0m"
    assert stringc("test", "color15") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;231mtest\033[0m"


# Generated at 2022-06-23 13:47:19.478333
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('default') == 39
    assert parsecolor('red') == 31
    assert parsecolor('green') == 32
    assert parsecolor('yellow') == 33
    assert parsecolor('blue') == 34
    assert parsecolor('cyan') == 36
    assert parsecolor('magenta') == 35
    assert parsecolor('white') == 37
    assert parsecolor('color16') == 38
    assert parsecolor('rgb333') == 38
    assert parsecolor('rgb444') == 38
    assert parsecolor('rgb555') == 38
    assert parsecolor('rgb123') == 38
    assert parsecolor('rgb000') == 38
    assert parsecolor('rgb666') == 38
    assert parsecolor('rgb333') == 38

# Generated at 2022-06-23 13:47:31.021282
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        assert colorize('ok', 0, 'green') == u"ok=0   "
        assert colorize('changed', 1, 'yellow') == u"\033[33mchanged=1  \033[0m"
        assert colorize('unreachable', 1, 'red') == u"\033[31munreachable=1\033[0m"
        assert colorize('failed', 1, 'red') == u"\033[31mfailed=1   \033[0m"
    else:
        assert colorize('ok', 0, 'green') == u"ok=0   "
        assert colorize('changed', 1, 'yellow') == u"changed=1  "
        assert colorize('unreachable', 1, 'red') == u"unreachable=1"
        assert colorize

# Generated at 2022-06-23 13:47:38.828451
# Unit test for function colorize
def test_colorize():
    for c in ('red', 'green', 'blue', 'cyan', 'yellow', 'magenta', 'white'):
        for n in (0, 1, 2, '0', '1', '2'):
            print(colorize('=>', n, c))
    for c in (None, 1, 'foo', '', ' ', 0):
        for n in (0, 1, 2, '0', '1', '2'):
            print(colorize('=>', n, c))

# Generated at 2022-06-23 13:47:47.826198
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {"failures": 0, "unreachable": 0, "changed": 0}
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc("localhost", C.COLOR_OK)
    stats['changed'] = 1
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)
    stats['changed'] = 0
    stats['unreachable'] = 1
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)

# --- end "pretty"



# Generated at 2022-06-23 13:48:00.044842
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u'\033[31mtest\033[0m'
    assert stringc("test", "rgb000") == u'\033[38;5;16mtest\033[0m'
    assert stringc("test", "rgb111") == u'\033[38;5;18mtest\033[0m'
    assert stringc("test", "rgb222") == u'\033[38;5;58mtest\033[0m'
    assert stringc("test", "rgb444") == u'\033[38;5;100mtest\033[0m'
    assert stringc("test", "rgb555") == u'\033[38;5;102mtest\033[0m'

# Generated at 2022-06-23 13:48:06.981103
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc("this is black", "black") == u"\033[0;30mthis is black\033[0m"
        assert stringc("this is black", "BLACK") == u"\033[0;30mthis is black\033[0m"
        assert stringc("this is red", "red") == u"\033[0;31mthis is red\033[0m"
        assert stringc("this is red", "RED") == u"\033[0;31mthis is red\033[0m"
        assert stringc("this is green", "green") == u"\033[0;32mthis is green\033[0m"

# Generated at 2022-06-23 13:48:19.978850
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == '30'
    assert parsecolor('white') == '37'
    assert parsecolor('blue') == '34'
    assert parsecolor('0') == '38;5;0'
    assert parsecolor('1') == '38;5;1'
    assert parsecolor('15') == '38;5;15'
    assert parsecolor('16') == '38;5;16'
    assert parsecolor('51') == '38;5;51'
    assert parsecolor('90') == '38;5;90'
    assert parsecolor('95') == '38;5;95'
    assert parsecolor('96') == '38;5;96'
    assert parsecolor('100') == '38;5;100'

# Generated at 2022-06-23 13:48:30.865402
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('0') == u'38;5;0'
    assert parsecolor('1') == u'38;5;1'
    assert parsecolor('255') == u'38;5;255'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('rgb000') == u'38;5;232'
    assert parsecolor('rgb555') == u'38;5;15'
    assert parsecolor('rgb234') == u'38;5;52'
    assert parsecolor('rgb321') == u'38;5;124'
    assert parsecolor('gray0') == u'38;5;232'

# Generated at 2022-06-23 13:48:36.783604
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 42
    color = 'red'
    s = colorize(lead, num, color)
    assert s == stringc(u"foo=42", color)
    s = colorize(lead, 0, None)
    assert s == u"foo=0   "

#
# end of pretty
# ---

# --- begin "constructed"



# Generated at 2022-06-23 13:48:39.246720
# Unit test for function colorize
def test_colorize():
    assert colorize('test', 10, 'blue') == u'test=10  '
    assert colorize('test', 0, 'yellow') == u'test=0   '

# Generated at 2022-06-23 13:48:47.663097
# Unit test for function colorize
def test_colorize():
    # TODO: make this work on Windows - write to a file, and compare with file contents
    old_stdout = sys.stdout
    sys.stdout = open('/dev/null', 'w')
    print(u"\n%-15s %-15s %-15s %-15s" %
          (colorize('-', 0, C.COLOR_ERROR), colorize('-', 0, C.COLOR_CHANGED),
           colorize('-', 0, C.COLOR_OK), colorize('-', 0, None)))

# Generated at 2022-06-23 13:48:53.372404
# Unit test for function colorize
def test_colorize():
    # Define the test values
    lead = "test_lead"
    num = 1
    color = "blue"
    # Define the expected colorized string
    test_expected_string = u"test_lead=1   "

    # Define the string to be tested
    test_string = colorize(lead, num, color)

    # Compare strings, should be equal
    assert test_string == test_expected_string, test_string



# Generated at 2022-06-23 13:48:59.292837
# Unit test for function hostcolor
def test_hostcolor():
    print(u"\nColorized Hosts, Green/Red/Normal:")
    print(hostcolor('green', dict(failures=0, unreachable=0, changed=123)))
    print(hostcolor('red', dict(failures=1, unreachable=0, changed=0)))
    print(hostcolor('normal', dict(failures=0, unreachable=0, changed=0)))



# Generated at 2022-06-23 13:49:08.585746
# Unit test for function colorize
def test_colorize():
    """ ansible module test suite """
    if ANSIBLE_COLOR:
        assert(colorize("foo", 4, None) == "foo=4   ")
        assert(colorize("foo", 0, None) == "foo=0   ")
        assert(colorize("foo", 0, C.COLOR_CHANGED) == "foo=0   ")
        assert(colorize("foo", 1, C.COLOR_ERROR) != "foo=1   ")
        assert(colorize("foo", 2, C.COLOR_OK) != "foo=2   ")
        assert(colorize("foo", 3, C.COLOR_SKIPPED) != "foo=3   ")
        assert(colorize("foo", 4, C.COLOR_UNREACHABLE) != "foo=4   ")

# Generated at 2022-06-23 13:49:13.117654
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, "green") == "foo=0   "
    assert colorize("foo", 0, "red")   == "foo=0   "
    assert colorize("foo", 2, "red")   == stringc("foo=2   ", "red")
    assert colorize("foo", 3, "red")   == stringc("foo=3   ", "red")


# Generated at 2022-06-23 13:49:23.298539
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "black") == u"\033[30mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "black", wrap_nonvisible_chars=True) == u"\001\033[30m\002foo\001\033[0m\002"
    assert stringc("foo\nbar", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\nbar\001\033[0m\002"

# Generated at 2022-06-23 13:49:32.186218
# Unit test for function colorize
def test_colorize():
    # Start with some known values
    assert u'ok    =0   ' == colorize(u'ok', 0, u'green')
    assert u'changed=1   ' == colorize(u'changed', 1, u'yellow')
    assert u'failed=2   ' == colorize(u'failed', 2, u'red')
    assert u'unreachable=3' == colorize(u'unreachable', 3, u'red')

    # Make sure no color is added when not supposed to
    ANSIBLE_COLOR = False
    assert u'ok    =4   ' == colorize(u'ok', 4, u'green')
    assert u'changed=5   ' == colorize(u'changed', 5, u'yellow')

# Generated at 2022-06-23 13:49:43.786879
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('brightred') == '31'
    assert parsecolor('brown') == '33'
    assert parsecolor('yellow') == '33'
    assert parsecolor('purple') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('darkgray') == '30'
    assert parsecolor('darkred') == '31'
    assert parsecolor('darkgreen') == '32'
    assert parsecolor('darkblue') == '34'
    assert parsecolor('darkcyan') == '36'
    assert parsecolor('darkpurple') == '35'

# Generated at 2022-06-23 13:49:48.445269
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc("test", "blue") == u"\033[34mtest\033[0m"
        assert stringc("test", "rgb000") == u"\033[38;5;232mtest\033[0m"
    else:
        assert stringc("test", "blue") == "test"
        assert stringc("test", "rgb000") == "test"

# Generated at 2022-06-23 13:49:59.356532
# Unit test for function colorize
def test_colorize():
    try:
        import curses
    except ImportError:
        return

    curses.setupterm()
    colors = curses.tigetnum("colors")
    if colors <= 0:
        return

    color_list = ['black', 'blue', 'cyan', 'green', 'magenta', 'red', 'white', 'yellow']
    for lead in ['changed', 'dark grey', 'failures', 'fast', 'green', 'ok', 'red', 'skipped', 'unreachable', 'yellow']:
        for num in [0, 1, 10, 100]:
            for color in color_list:
                print("%-37s" % colorize(lead, num, color))
    return


# --- end "pretty"

import ansible.utils.display


# Generated at 2022-06-23 13:50:07.757520
# Unit test for function parsecolor
def test_parsecolor():
    # tests for the various valid inputs
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('lightgray') == u'37'
    assert parsecolor('darkgray') == u'1;30'
    assert parsecolor('lightred') == u'1;31'
    assert parsecolor('lightgreen') == u'1;32'
    assert parsecolor('lightyellow') == u'1;33'

# Generated at 2022-06-23 13:50:09.972634
# Unit test for function colorize
def test_colorize():
    pass


# --- end "pretty"

# The following is taken from python-pygments with the license:
#
#  Copyright (c) 2006-2013 by the Pygments team, see AUTHORS.
#  BSD License, see LICENSE for details.
#
#
# Additional copyright below applies to modifications made to original version.
#



# Generated at 2022-06-23 13:50:18.003575
# Unit test for function colorize
def test_colorize():
    ''' colorize unit test '''
    assert "ok=0 " == colorize("ok", 0, C.COLOR_OK)
    assert "changed=0 " == colorize("changed", 0, C.COLOR_CHANGED)
    assert "failed=0 " == colorize("failed", 0, C.COLOR_ERROR)

    assert "ok=3 " == colorize("ok", 3, C.COLOR_OK)
    assert "changed=3 " == colorize("changed", 3, C.COLOR_CHANGED)
    assert "failed=3 " == colorize("failed", 3, C.COLOR_ERROR)

# --- end of pretty

# --- begin "human_log"



# Generated at 2022-06-23 13:50:25.984438
# Unit test for function colorize
def test_colorize():
    # this function is a bit hard to unit test as it relies on set env values
    # we will make them predictable
    import os

    # this function doesn't *do* anything unless the color variable is True
    color = True
    lead = 'a'
    num = '0'
    color = None
    result = colorize(lead, num, color)
    assert result == 'a=0   ', 'colorize did not return expected result'

    # the next result is where we depend on the ansible color variables
    os.environ['ANSIBLE_NOCOLOR'] = 'True'
    color = True
    lead = 'a'
    num = '0'
    color = C.COLOR_OK
    result = colorize(lead, num, color)

# Generated at 2022-06-23 13:50:36.526694
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == 'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == '\x1b[31mlocalhost\x1b[0m                   '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == '\x1b[31mlocalhost\x1b[0m                   '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == '\x1b[33mlocalhost\x1b[0m                   '

# Main function for standalone program

# Generated at 2022-06-23 13:50:47.886465
# Unit test for function stringc

# Generated at 2022-06-23 13:50:55.589976
# Unit test for function stringc
def test_stringc():
    """ Enforces the stringc function to print text with the color """
    print(u"\n--- stringc unit tests ---")
    txt = u"This is a test"

    for color in C.COLOR_CODES.keys():
        print(u"\nColor of %s:\n" % color)
        print(stringc(txt, color))
        print(u"\n")
    print(u"\n--- end of stringc unit tests ---\n")


# --- end "pretty"

__all__ = ['stringc', 'test_stringc', 'hostcolor', 'colorize', 'ANSIBLE_COLOR']

# Generated at 2022-06-23 13:51:07.070965
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('cyan') == '36'
    assert parsecolor('gray') == '37'
    assert parsecolor('magenta') == '35'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('rgb123') == '38;5;54'
    assert parsecolor('gray4') == '38;5;242'
    assert parsecolor('gray10') == '38;5;250'
    assert parsecolor('gray0') == '38;5;232'

# Generated at 2022-06-23 13:51:16.876653
# Unit test for function parsecolor
def test_parsecolor():
    color_codes = {'black': '0',
                   'red': '1',
                   'green': '2',
                   'yellow': '3',
                   'blue': '4',
                   'magenta': '5',
                   'cyan': '6',
                   'white': '7',
                   'default': '9'}

    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor

# Generated at 2022-06-23 13:51:23.530271
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test'
    stats = {'failures': 0, 'changed': 0, 'unreachable': 0}

    if hostcolor(host, stats) != u"%-26s":
        print("hostcolor() failed")

    stats['failures'] = 1
    if hostcolor(host, stats) != u"%-37s":
        print("hostcolor() failed")

    stats['failures'] = 0
    stats['unreachable'] = 1
    if hostcolor(host, stats) != u"%-37s":
        print("hostcolor() failed")

    stats['unreachable'] = 0
    stats['changed'] = 1
    if hostcolor(host, stats) != u"%-37s":
        print("hostcolor() failed")

    stats['changed'] = 0

# Generated at 2022-06-23 13:51:33.271198
# Unit test for function hostcolor
def test_hostcolor():
    early_paint_host = hostcolor("localhost", dict(failures=1, unreachable=0, changed=0, ok=1))
    assert early_paint_host == '\x1b[31m%-37s\x1b[0m' % 'localhost'

    paint_host = hostcolor("localhost", dict(failures=0, unreachable=0, changed=1, ok=1))
    assert paint_host == '\x1b[33m%-37s\x1b[0m' % 'localhost'

    no_change_host = hostcolor("localhost", dict(failures=0, unreachable=0, changed=0, ok=1))
    assert no_change_host == '\x1b[32m%-37s\x1b[0m' % 'localhost'

    global ANSIBLE_

# Generated at 2022-06-23 13:51:44.267463
# Unit test for function hostcolor
def test_hostcolor():
    h1 = hostcolor('localhost', {'ok': 1, 'changed': 1, 'failures': 1, 'skipped': 1, 'unreachable': 1})
    assert h1 == u'localhost                         '
    h2 = hostcolor('localhost', {'ok': 1, 'changed': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0})
    assert h2 == u'\x1b[0;32mlocalhost\x1b[0m                   '
    h3 = hostcolor('localhost', {'ok': 0, 'changed': 1, 'failures': 0, 'skipped': 0, 'unreachable': 0})
    assert h3 == u'\x1b[0;33mlocalhost\x1b[0m                   '

# Generated at 2022-06-23 13:51:47.547099
# Unit test for function colorize
def test_colorize():

    if not ANSIBLE_COLOR:
        return

    test_str = colorize("Test:", 3, "red")
    assert test_str == u"\n".join([u"\033[31mTest:=3   \033[0m"])



# Generated at 2022-06-23 13:51:58.017838
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u"localhost", {"failed": 0}, False) == u"localhost                  "
    assert hostcolor(u"localhost", {"failed": 1}, False) == u"localhost                  "
    assert hostcolor(u"localhost", {"failed": 0}, True) == u"localhost                  "
    assert hostcolor(u"localhost", {"failed": 1}, True) == u"localhost                  "

# --- end of "pretty"

# This dictionary is used to translate ANSIBLE_COLOR to ANSIBLE_FORCE_COLOR
SHELL_PLUGIN_COLORS = {'true': True, 'false': False, 'yes': True, 'no': False}



# Generated at 2022-06-23 13:52:07.031829
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, "blue") == "foo=0   "
    assert colorize("foo", 1, "blue") == "foo=1   "
    assert colorize("foo", 2, "blue") == "foo=2   "
    assert colorize("foo", 12, "blue") == "foo=12  "
    assert colorize("foo", 123, "blue") == "foo=123 "
    assert colorize("foo", 1234, "blue") == "foo=1234"
    assert colorize("foo", 12345, "blue") == "foo=12345"

    assert colorize("foo", 0, None) == "foo=0   "
    assert colorize("foo", 1, None) == "foo=1   "
    assert colorize("foo", 2, None) == "foo=2   "
   

# Generated at 2022-06-23 13:52:15.822328
# Unit test for function parsecolor
def test_parsecolor():
    # Color tests
    assert parsecolor(u"color1") == u"38;5;1"
    assert parsecolor(u"color11") == u"38;5;11"
    assert parsecolor(u"color111") == u"38;5;111"

    # RGB tests
    assert parsecolor(u"rgb000") == u"38;5;16"
    assert parsecolor(u"rgb123") == u"38;5;57"
    assert parsecolor(u"rgb213") == u"38;5;75"

    # Gray tests
    assert parsecolor(u"gray0") == u"38;5;232"
    assert parsecolor(u"gray1") == u"38;5;233"
    assert parsecolor(u"gray23") == u

# Generated at 2022-06-23 13:52:27.295740
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert parsecolor('red') == u'38;5;9'
        assert parsecolor('bold_red') == u'38;5;9'
        assert parsecolor('light_red') == u'38;5;9'
        assert parsecolor('green') == u'38;5;2'
        assert parsecolor('bold_green') == u'38;5;10'
        assert parsecolor('light_green') == u'38;5;10'
        assert parsecolor('blue') == u'38;5;4'
        assert parsecolor('light_blue') == u'38;5;12'
        assert parsecolor('bold_blue') == u'38;5;12'

# Generated at 2022-06-23 13:52:35.104750
# Unit test for function parsecolor

# Generated at 2022-06-23 13:52:46.196933
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('brown') == u'33'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('darkgray') == u'1;30'
    assert parsecolor('default') == u'39;49'
    assert parsecolor('bgdefault') == u'49'
    assert parsecolor('nocolor') == u''
    assert parsecolor('bold') == u'1'


# Generated at 2022-06-23 13:52:57.101234
# Unit test for function colorize
def test_colorize():
    nums = (0,1,2,3,4,5,6,7,8,9)
    for i in nums:
        for j in nums:
            for k in nums:
                num = "%d%d%d" % (i,j,k)
                lead = "lead"
                print("colorize(%s, %s, %s) = %s" % (lead, num, "red", colorize(lead, num, "red")))
    print("colorize(%s, %s, %s) = %s" % (lead, num, None, colorize(lead, num, None)))


# --- end "pretty"


# --- begin "prettytable"
#
# prettytable - A simple Python library for easily displaying tabular data in
#               a visually appealing ASCII table format
#


# Generated at 2022-06-23 13:53:05.519222
# Unit test for function stringc
def test_stringc():
    """Testing function stringc."""
    print("Testing function stringc.")
    try:
        import curses
    except ImportError:
        print("Cannot test function stringc: curses library not found.")
        return
    try:
        curses.setupterm()
    except curses.error:
        # Cannot test function stringc: curses returns an error
        # (e.g. could not find terminal)
        return

    if curses.tigetnum("colors") < 0:
        print("Cannot test function stringc: terminal does not support colors.")
        return

    print("Testing basic functionality")
    print("%s" % (stringc("basic functionality", "blue")))

    print("Testing color codes")
    print("%s" % (stringc("color codes", "color1")))

# Generated at 2022-06-23 13:53:12.567739
# Unit test for function stringc
def test_stringc():
    assert stringc('x', 'blue') == u'\033[34mx\033[0m'
    assert stringc('x', 'color3') == u'\033[38;5;3mx\033[0m'
    assert stringc('x', 'color003') == u'\033[38;5;3mx\033[0m'
    assert stringc('x', 'color83') == u'\033[38;5;83mx\033[0m'
    assert stringc('x', 'rgb125') == u'\033[38;5;21mx\033[0m'
    assert stringc('x', 'rgb521') == u'\033[38;5;99mx\033[0m'

# Generated at 2022-06-23 13:53:24.210102
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("192.168.0.1", dict(failures=0, unreachable=0, changed=0)) == u"192.168.0.1              "
    assert hostcolor("192.168.0.1", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31m192.168.0.1      \x1b[0m"
    assert hostcolor("192.168.0.1", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31m192.168.0.1      \x1b[0m"

# Generated at 2022-06-23 13:53:32.952206
# Unit test for function parsecolor
def test_parsecolor():
    import sys
    from textwrap import wrap

    def eq(a, b):
        return a == b

    # Test all colors
    for color in C.COLOR_LIST:
        print(u"%-12s %s" % (color, stringc(u"XXX", color)))
    print()

    # Test all grays
    for gray in range(0, 23):
        print(u"gray%-12d %s" % (gray, stringc(u"XXX", u"gray%d" % gray)))
    print()

    # Test all colors
    for color in range(0, 256):
        print(u"color%-12d %s" %
              (color, stringc(u"XXX", u"color%d" % color)))
    print()

    # Test all rgb colors