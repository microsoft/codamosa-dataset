

# Generated at 2022-06-25 12:50:15.179364
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo'
    stats = {'failures': 0, 'unreachable': 0}
    hostcolor(host, stats, color=True)
# --- end "pretty"



# Generated at 2022-06-25 12:50:17.370814
# Unit test for function hostcolor
def test_hostcolor():
    print("\n--- testing hostcolor()")
    bool_0 = False
    bool_1 = False
    var_0 = hostcolor(bool_0, bool_1)


# Generated at 2022-06-25 12:50:24.660613
# Unit test for function hostcolor
def test_hostcolor():
    assert '-37s' == hostcolor('', {'failures':0, 'unreachable':0, 'changed':0})
    assert '-37s' == hostcolor('', {'failures':0, 'unreachable':0, 'changed':0}, False)
    assert '-37s' == hostcolor('', {'failures':1, 'unreachable':0, 'changed':0})
    assert '-37s' == hostcolor('', {'failures':0, 'unreachable':1, 'changed':0})
    assert '-37s' == hostcolor('', {'failures':0, 'unreachable':0, 'changed':1})
    assert '-37s' == hostcolor('', {'failures':1, 'unreachable':1, 'changed':1})

# Generated at 2022-06-25 12:50:27.326405
# Unit test for function colorize
def test_colorize():
    bool_0 = True
    str_0 = 'Hello'
    int_0 = 0
    str_1 = None
    assert colorize(str_0, int_0, str_1) == 'Hello=0   '


# Generated at 2022-06-25 12:50:30.908092
# Unit test for function hostcolor
def test_hostcolor():
    color_0 = None
    bool_0 = False
    str_0 = u"192.168.1.100"
    dict_0 = {u"failures": 0, u"unreachable": 0}
    result = hostcolor(str_0, dict_0, color_0)
    assert result == u"%s=%-4s" % (bool_0, str(color_0))


# Generated at 2022-06-25 12:50:31.529385
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()

# Generated at 2022-06-25 12:50:34.433851
# Unit test for function parsecolor
def test_parsecolor():
    # Print the message to be shown when the test fails
    print("Test if the function returns the correct result")

    # Get the result of the function
    result = parsecolor("False")
    expected_result = u"38;5;0"
    # Check if the result obtained is equal to the expected result
    assert result == expected_result


# Generated at 2022-06-25 12:50:35.343568
# Unit test for function colorize
def test_colorize():
    assert colorize('c', 'a', 'b') is not None


# Generated at 2022-06-25 12:50:37.731478
# Unit test for function stringc
def test_stringc():
    bool_33 = False
    var_28 = stringc(bool_33, bool_33)
    bool_34 = False
    var_29 = stringc(bool_34, bool_34)


# Generated at 2022-06-25 12:50:40.606969
# Unit test for function colorize
def test_colorize():
    assert colorize("msg", 0, C.COLOR_CHANGED) == "msg=0   ", "Fails"
    assert colorize("msg", 0, None) == "msg=0   ", "Fails"

# vim: set expandtab ts=4 sw=4:

# Generated at 2022-06-25 12:50:51.162550
# Unit test for function hostcolor
def test_hostcolor():
    host = "example"
    stats = dict()
    color = True
    # Test with a known good value
    expected = "example                          "
    actual = hostcolor(host, stats, color)
    assert actual == expected, "expected: [%s], received: [%s]" % (expected, actual)

    # Test with a known good value
    expected = "example                          "
    actual = hostcolor(host, stats, color)
    assert actual == expected, "expected: [%s], received: [%s]" % (expected, actual)



# Generated at 2022-06-25 12:50:56.209837
# Unit test for function colorize
def test_colorize():
    assert colorize(u"lead", 0, u"color") == u"lead=0   "
    assert colorize(u"lead", 42, u"color") == u"lead=42  "

    # Colorize should not colorize when ANSIBLE_COLOR is False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize(u"lead", 42, None) == u"lead=42  "
    ANSIBLE_COLOR = True

    assert colorize(u"lead", 42, None) == u"lead=42  "


# Generated at 2022-06-25 12:50:57.376655
# Unit test for function parsecolor
def test_parsecolor():
    print("\n---  Testing function: parsecolor ---")
    test_case_0()


# Generated at 2022-06-25 12:51:00.018160
# Unit test for function colorize
def test_colorize():
    lead = "lead"
    num = 10
    color = "green"

    print(colorize(lead, num, color))
    assert (colorize(lead, num, color) == stringc(u'%-4s=%-4s' % (lead, str(num)), color))


# Generated at 2022-06-25 12:51:06.614524
# Unit test for function parsecolor
def test_parsecolor():
    print()
    print(u"Testing parsecolor")

    # Setup
    bool_0 = False
    var_0 = parsecolor(bool_0)

    # Testing parsecolor with False
    print(u"Testing parsecolor with False")
    if ((not var_0) != 0):
        raise Exception(u"parsecolor() did not return expected value")

    # Teardown

    # Setup
    bool_0 = None
    var_0 = parsecolor(bool_0)

    # Testing parsecolor with None
    print(u"Testing parsecolor with None")
    if ((not var_0) != 0):
        raise Exception(u"parsecolor() did not return expected value")

    # Teardown

    # Setup
    bool_0 = True

# Generated at 2022-06-25 12:51:13.016214
# Unit test for function stringc
def test_stringc():
    bool_0 = False
    str_0 = stringc(bool_0, bool_0)
    bool_1 = False
    str_1 = stringc(bool_1, bool_1)
    bool_2 = False
    str_2 = stringc(bool_2, bool_2)
    bool_3 = False
    str_3 = stringc(bool_3, bool_3)



# Generated at 2022-06-25 12:51:15.217900
# Unit test for function parsecolor
def test_parsecolor():
    tst = parsecolor('green')
    assert tst == '32'



# Generated at 2022-06-25 12:51:17.717799
# Unit test for function stringc
def test_stringc():
    text = ''
    color = ''
    wrap_nonvisible_chars = False
    stringc(text, color, wrap_nonvisible_chars)



# Generated at 2022-06-25 12:51:20.957673
# Unit test for function hostcolor
def test_hostcolor():
    # make sure we get the color strings for skipped and ok
    host_0 = stringc('localhost', C.COLOR_SKIP)
    host_1 = stringc('localhost', C.COLOR_OK)
    # foo is now colored correctly
    assert(host_0 != host_1)

# Generated at 2022-06-25 12:51:22.580804
# Unit test for function hostcolor
def test_hostcolor():
    result = hostcolor('host', stats)
    assert result == 'host'


# Generated at 2022-06-25 12:51:36.327153
# Unit test for function parsecolor
def test_parsecolor():
    color = parsecolor('black')
    assert color == '30'
    # print(color)
    color = parsecolor('rgb123')
    assert color == '38;5;1'
    # print(color)
    color = parsecolor('color01')
    assert color == '38;5;1'
    # print(color)
    color = parsecolor('gray01')
    assert color == '38;5;232'
    # print(color)
    color = parsecolor('red')
    assert color == '31'
    # print(color)
    color = parsecolor('green')
    assert color == '32'
    # print(color)
    color = parsecolor('yellow')
    assert color == '33'
    # print(color)

# Generated at 2022-06-25 12:51:40.231901
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u"31"
    assert parsecolor("GREEN") == u"32"
    assert parsecolor("color001") == u"38;5;1"
    assert parsecolor("rgb510") == u"38;5;17"


# Generated at 2022-06-25 12:51:44.159054
# Unit test for function colorize
def test_colorize():
    lead = 'aa'
    num = 'bb'
    color = 'cc'
    expect = 'aa=bb'
    assert colorize(lead, num, color) == expect


# Generated at 2022-06-25 12:51:49.886556
# Unit test for function colorize
def test_colorize():
    str_0 = 'localhost'
    stats_0 = {}
    stats_0['failures'] = 0
    stats_0['unreachable'] = 0
    stats_0['changed'] = 0

    s = hostcolor(str_0, stats_0, False)
    print(s)
    s = hostcolor(str_0, stats_0, True)
    print(s)


# Generated at 2022-06-25 12:51:54.739860
# Unit test for function stringc
def test_stringc():
    str_0 = 'foo'
    assert stringc(str_0, "red") == u'\033[31mfoo\033[0m'


# Generated at 2022-06-25 12:52:01.265203
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    assert hostcolor(host, stats, color) == stringc(host, C.COLOR_OK)

    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
    color = True
    assert hostcolor(host, stats, color) == stringc(host, C.COLOR_CHANGED)

    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    color = True
    assert hostcolor(host, stats, color) == stringc(host, C.COLOR_ERROR)

    host = 'localhost'

# Generated at 2022-06-25 12:52:04.419408
# Unit test for function hostcolor
def test_hostcolor():
    colorize('host', 14, 1)
    test_case_0()

if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-25 12:52:08.379256
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert u"\033[38;5;12m123" == stringc(u"123", "blue")
        assert u"\033[38;5;46m123" == stringc(u"123", "color3")



# Generated at 2022-06-25 12:52:11.227992
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'white'
    str_1 = parsecolor(str_0)
    assert str_1 == '38;5;15', 'parsecolor failed'


# Generated at 2022-06-25 12:52:12.414518
# Unit test for function parsecolor
def test_parsecolor():
    test_parsecolor_0()
    test_parsecolor_1()


# Generated at 2022-06-25 12:52:21.059245
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    dict_0 = {'failures': 0, 'changed': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    bool_0 = True
    str_1 = 'localhost'
    assert str(hostcolor(str_0, dict_0, bool_0)) == str_1


# Generated at 2022-06-25 12:52:23.376339
# Unit test for function colorize
def test_colorize():
    assert colorize(u'', 45, u'') == u'=45  '
    assert colorize(u'', 45, u'green') == u'=45  '


# Generated at 2022-06-25 12:52:24.996869
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures':0, 'unreachable':0, 'changed':0}
    host = 'localhost'
    print(hostcolor(host, stats, True))


# Generated at 2022-06-25 12:52:27.764316
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'ok': 1, 'unreachable': 0, 'skipped': 0, 'changed': 0, 'dark': 0, 'processed': 1}
    assert hostcolor("localhost", stats) == u"localhost                 "

# Generated at 2022-06-25 12:52:29.460952
# Unit test for function stringc
def test_stringc():
    assert stringc("test", C.COLOR_OK) == u"\033[32mtest\033[0m"

__all__ = ['stringc', 'colorize', 'hostcolor']
# --- end "pretty"

# Generated at 2022-06-25 12:52:33.262674
# Unit test for function hostcolor
def test_hostcolor():
    ansible_host = 'localhost'
    results_status = {'failures': 0, 'unreachable': 0, 'changed': 0}
    results = hostcolor(ansible_host, results_status)
    return results

if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:52:38.808525
# Unit test for function stringc
def test_stringc():
    str_0 = 'localhost'
    ret_val_0 = stringc(str_0, 'success')
    print(ret_val_0)
    str_1 = 'localhost'
    ret_val_1 = stringc(str_1, 'success')
    print(ret_val_1)


# Generated at 2022-06-25 12:52:47.212899
# Unit test for function stringc
def test_stringc():
    assert stringc('localhost', 'green') == '\n'.join([u'\033[38;5;40mlocalhost\033[0m'])
    assert stringc('localhost', 'red') == '\n'.join([u'\033[38;5;160mlocalhost\033[0m'])
    assert stringc('localhost', '0') == '\n'.join([u'\033[38;5;0mlocalhost\033[0m'])
    assert stringc('localhost', 'rgb222') == '\n'.join([u'\033[38;5;56mlocalhost\033[0m'])


# Generated at 2022-06-25 12:52:50.515116
# Unit test for function stringc
def test_stringc():
    test_str = '\n'.join(map(str, range(5)))
    for color in C.COLOR_CODES:
        str_1 = stringc(test_str, color)
        assert str_1 == test_str


# Generated at 2022-06-25 12:52:59.556326
# Unit test for function colorize

# Generated at 2022-06-25 12:53:11.986173
# Unit test for function stringc
def test_stringc():
    assert '\033[91mfoo\033[0m' == stringc('foo', 'red')
    assert '\001\033[91m\002foo\001\033[0m\002' \
        == stringc('foo', 'red', True)
    assert '\033[38;5;222mfoo\033[0m' == stringc('foo', 'gray10')
    assert '\033[38;5;179mfoo\033[0m' == stringc('foo', 'red3')
    assert '\033[38;5;208mfoo\033[0m' == stringc('foo', 'rgb125')
    assert '\001\033[38;5;208m\002foo\001\033[0m\002' \
        == stringc('foo', 'rgb125', True)




# Generated at 2022-06-25 12:53:20.061501
# Unit test for function colorize
def test_colorize():
    assert colorize(
        lead='FAILED',
        num=0,
        color=None
    ) == 'FAILED=0   '
    assert colorize(
        lead='FAILED',
        num=2,
        color='blue'
    ) == '\x1b[38;5;4mFAILED=2\x1b[0m '
    assert colorize(
        lead='ok=4    ',
        num=4,
        color='green'
    ) == '\x1b[38;5;2mok=4\x1b[0m    '
    assert colorize(
        lead='changed=1',
        num=1,
        color='yellow'
    ) == '\x1b[38;5;3mchanged=1\x1b[0m'

# Generated at 2022-06-25 12:53:31.698204
# Unit test for function hostcolor
def test_hostcolor():
    stats_0 = {'failures':1, 'changed':0, 'ok':0, 'skipped':0, 'unreachable':0}
    assert hostcolor('localhost', stats_0, True) == '\x1b[31m%-26s\x1b[0m'
    stats_1 = {'failures':0, 'changed':1, 'ok':0, 'skipped':0, 'unreachable':0}
    assert hostcolor('localhost', stats_1, True) == '\x1b[33m%-26s\x1b[0m'
    stats_2 = {'failures':0, 'changed':0, 'ok':1, 'skipped':0, 'unreachable':0}

# Generated at 2022-06-25 12:53:34.443731
# Unit test for function stringc
def test_stringc():
    str_0 = 'localhost'
    color_name = 'blue'
    ans_0 = stringc(str_0, color_name)
    assert ans_0 == u'\x1b[94mlocalhost\x1b[0m'


# Generated at 2022-06-25 12:53:36.077148
# Unit test for function hostcolor
def test_hostcolor():
    test_hostcolor_0()



# Generated at 2022-06-25 12:53:37.390974
# Unit test for function stringc
def test_stringc():
    print(stringc(str_0, 'red', True))


# Generated at 2022-06-25 12:53:40.852247
# Unit test for function colorize
def test_colorize():
    lead = "test"
    num = 5
    color = "green"
    s = "%s=%-4s" % (lead, str(num))
    if num != 0 and ANSIBLE_COLOR and color is not None:
        s = stringc(s, color)
    print(s)

# Generated at 2022-06-25 12:53:47.160462
# Unit test for function stringc
def test_stringc():
    assert stringc(str_0, 'red') == '\033[31mlocalhost\033[0m'
    assert stringc(str_0, 'rgb123') == '\033[38;5;177mlocalhost\033[0m'
    assert stringc(str_0, 'gray1') == '\033[38;5;233mlocalhost\033[0m'
    assert stringc(str_0, 'not_a_color') == '\033[39mlocalhost\033[0m'
    assert stringc(str_0, 'bold') == '\033[1mlocalhost\033[0m'
    assert stringc(str_0, 'blue,underline') == '\033[44;4mlocalhost\033[0m'

# Generated at 2022-06-25 12:53:57.985477
# Unit test for function colorize
def test_colorize():

    # Call function with arguments:
    # lead = string_0, num = 0, color = value of ansible.constants.COLOR_HIGHLIGHT
    print(colorize('lead', 0, C.COLOR_HIGHLIGHT))

    # Call function with arguments:
    # lead = string_0, num = 0, color = None
    print(colorize('lead', 0, None))

    # Call function with arguments:
    # lead = string_0, num = 1, color = value of ansible.constants.COLOR_HIGHLIGHT
    print(colorize('lead', 1, C.COLOR_HIGHLIGHT))

    # Call function with arguments:
    # lead = string_0, num = 1, color = None
    print(colorize('lead', 1, None))



# Generated at 2022-06-25 12:54:00.534847
# Unit test for function colorize
def test_colorize():

    lead = 'lead'
    num = 0
    color = 'color'

    # call the function with arguments
    result = colorize(lead, num, color)
    assert type(result) is str


# Generated at 2022-06-25 12:54:12.235639
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    dict_0 = {}
    dict_1 = {}
    dict_0['failures'] = 0
    dict_0['unreachable'] = 1
    dict_1['failures'] = 0
    dict_1['unreachable'] = 0
    assert hostcolor(str_0, dict_0) == hostcolor(str_0, dict_1)


# Generated at 2022-06-25 12:54:23.211879
# Unit test for function colorize
def test_colorize():
    stats = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    assert u"ok=1   " == colorize("ok", stats['ok'], C.COLOR_OK)
    stats = {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    assert u"changed=1" == colorize("changed", stats['changed'], C.COLOR_CHANGED)
    stats = {'changed': 0, 'failures': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    assert u"failed=1 " == colorize("failed", stats['failures'], C.COLOR_ERROR)

# Generated at 2022-06-25 12:54:25.980382
# Unit test for function stringc
def test_stringc():
    # Test for stringc
    str_0 = 'localhost'
    color_code = parsecolor('CHANGED')
    s = u"\033[%sm%s\033[0m" % (color_code, str_0)
    str_0 = stringc(str_0, 'CHANGED')
    assert str_0 == s, "stringc returned the wrong result"



# Generated at 2022-06-25 12:54:32.496730
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(str_0, dict_0, bool_0) == u'localhost             ', "Expected '%s' to equal '%s'" % (hostcolor(str_0, dict_0, bool_0), u'localhost             ')

dict_0 = {'_ansible_no_log': False, '_ansible_parsed': True}
bool_0 = True

test_hostcolor()

# Generated at 2022-06-25 12:54:43.538300
# Unit test for function hostcolor
def test_hostcolor():
    stats_0 = {'failures' : 0, 'skipped' : 0, 'unreachable' : 0, 'changed' : 0, 'ok' : 1, 'processed' : 1}
    assert(hostcolor('localhost', stats_0, True) == 'localhost                 ')
    stats_1 = {'failures' : 1, 'skipped' : 0, 'unreachable' : 0, 'changed' : 0, 'ok' : 0, 'processed' : 1}
    assert(hostcolor('localhost', stats_1, True) == '\x1b[31mlocalhost                 \x1b[0m')
    stats_2 = {'failures' : 0, 'skipped' : 0, 'unreachable' : 0, 'changed' : 1, 'ok' : 0, 'processed' : 1}

# Generated at 2022-06-25 12:54:51.218054
# Unit test for function stringc
def test_stringc():
    str_0 = stringc(str_0, 'RED_BOLD')
    str_1 = stringc(str_1, 'RED_BOLD')
    str_2 = stringc(str_2, 'RED_BOLD')
    str_3 = stringc(str_3, 'RED_BOLD')
    str_4 = stringc(str_4, 'RED_BOLD')
    str_5 = stringc(str_5, 'RED_BOLD')
    str_6 = stringc(str_6, 'RED_BOLD')
    str_7 = stringc(str_7, 'RED_BOLD')
    str_8 = stringc(str_8, 'RED_BOLD')
    str_9 = stringc(str_9, 'RED_BOLD')

# Generated at 2022-06-25 12:54:57.123312
# Unit test for function hostcolor
def test_hostcolor():
    str_1 = 'localhost'
    result = hostcolor(str_1, {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 0})

    assert(type(result) == str)
    assert(result ==  "localhost               ")

# --- end of "pretty"

if __name__ == "__main__":
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:55:05.239245
# Unit test for function stringc
def test_stringc():
    color = 'red'
    text = 'Hello'
    actual = stringc(text, color)
    assert isinstance(actual, str)
    assert actual.startswith('\x1b[')
    assert actual.endswith('\x1b[0m')
    print(actual)
    if __name__ == '__main__':
        import sys
        if len(sys.argv) > 1:
            for c in sys.argv[1:]:
                print(stringc('Test String', c))
        else:
            print('No colors specified.')
            sys.exit(1)

# Generated at 2022-06-25 12:55:13.744576
# Unit test for function stringc
def test_stringc():
    from ansible import utils
    from ansible.utils import listify_lookup_plugin_terms

    str_0 = 'localhost'
    str_1 = 'this is a test.'
    str_2 = '123'
    str_3 = 'abc'
    str_4 = 'color123'
    str_5 = 'color-1'
    str_6 = 'color256'
    str_7 = '1color30'

# Generated at 2022-06-25 12:55:19.208796
# Unit test for function hostcolor
def test_hostcolor():
    # assert hostcolor('localhost', {'changed': 1, 'failures': 1, 'successes': 1, 'unreachable': 1}, True) == hostcolor('localhost', {'changed': 1, 'failures': 1, 'successes': 1, 'unreachable': 1}, True)
    pass

# Generated at 2022-06-25 12:55:34.750969
# Unit test for function hostcolor
def test_hostcolor():
    t_host = 'hostname'
    t_stats = {'changed': 1,
               'dark': 0,
               'failures': 0,
               'ok': 0,
               'processed': 1,
               'skipped': 0,
               'unreachable': 0}
    t_result = u'hostname                                     '
    assert hostcolor(t_host, t_stats) == "%-37s" % t_result

    t_host = 'hostname'
    t_stats = {'changed': 0,
               'dark': 0,
               'failures': 0,
               'ok': 0,
               'processed': 1,
               'skipped': 0,
               'unreachable': 0}
    t_result = u'hostname                                     '

# Generated at 2022-06-25 12:55:36.117333
# Unit test for function colorize
def test_colorize():
    colorize('Lead_0', 1, 'color_0')


# Generated at 2022-06-25 12:55:45.233953
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'dark_green'
    dict_0 = {'skipped': 3, 'ok': 4, 'failures': 2, 'changed': 5, 'unreachable': 0}
    str_1 = 'dark_red'
    dict_1 = {'skipped': 2, 'ok': 1, 'failures': 1, 'changed': 2, 'unreachable': 1}
    str_2 = 'dark_green'
    dict_2 = {'skipped': 0, 'ok': 2, 'failures': 3, 'changed': 1, 'unreachable': 1}
    hostcolor(str_0, dict_0, False)
    hostcolor(str_1, dict_1, True)
    hostcolor(str_2, dict_2, True)

# Generated at 2022-06-25 12:55:52.682225
# Unit test for function hostcolor
def test_hostcolor():
    ansible_run_results = {
        "darkblue.example.com" : {
            "changed" : 3,
            "dark": 4,
            "failures": 1,
            "ok": 6,
            "skipped": 2,
            "unreachable": 0,
            "darkblue": 7,
            "changed": 28,
            "failures": 0
        }
    }

    for host, stats in ansible_run_results.items():
        s = hostcolor(host, stats)
        assert s.startswith('darkblue.example.com')

# Generated at 2022-06-25 12:55:54.232986
# Unit test for function stringc
def test_stringc():
    str_0 = 'blue'
    var_0 = stringc(str_0, 'blue')


# Generated at 2022-06-25 12:56:01.571826
# Unit test for function hostcolor
def test_hostcolor():
    host = u'myserver.example.com'
    stats = {'changed': 0, 'failures': 0, 'unreachable': 0}
    color = True
    var_3 = hostcolor(host, stats, color)
    assert var_3 == u'%-37s' % stringc(host, C.COLOR_OK), "Failed to compare '%s' with expected value '%-37s' and actual value '%s'" % (u'myserver.example.com' % stringc(host, C.COLOR_OK), u'myserver.example.com' % stringc(host, C.COLOR_OK), var_3)


# Generated at 2022-06-25 12:56:05.370802
# Unit test for function hostcolor
def test_hostcolor():
    # Run the function with all the arguments and verify that
    # the result matches the expected value
    data = {'changed':0, 'failures':0, 'unreachable':0}
    result = hostcolor('test', data, True)
    assert u"%-37s" == result



# Generated at 2022-06-25 12:56:06.928892
# Unit test for function colorize
def test_colorize():
    print(colorize(u"Changed", 0, None))


# Generated at 2022-06-25 12:56:10.501488
# Unit test for function stringc
def test_stringc():
    str0 = "test"
    color0 = "red"
    var0 = stringc(str0, color0)
    print(var0)


if __name__ == "__main__":
    test_stringc()
    test_case_0()

# Generated at 2022-06-25 12:56:19.716379
# Unit test for function stringc
def test_stringc():
    str_0 = 'Test stringc.'
    str_1 = 'red'
    str_2 = 'Test stringc.'
    str_3 = 'red'
    str_4 = 'Test stringc.'
    str_5 = 'red'
    str_6 = 'Test stringc.'
    str_7 = 'red'
    str_8 = 'Test stringc.'
    str_9 = 'red'
    str_10 = 'Test stringc.'
    str_11 = 'red'
    str_12 = 'Test stringc.'
    str_13 = 'red'
    str_14 = 'Test stringc.'


# Generated at 2022-06-25 12:56:34.902307
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'gree'
    var_0 = parsecolor(str_0)
    dict_0 = dict()
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    dict_0[''] = 0
    var_1 = hostcolor(str_0, dict_0)


# Generated at 2022-06-25 12:56:45.696858
# Unit test for function stringc
def test_stringc():
    str_0 = 'gree'
    str_1 = 'blue'
    str_2 = 'red'
    str_7 = 'white'
    str_8 = 'yello'
    str_9 = 'magenta'
    str_10 = 'cyan'
    str_11 = 'pacific blue'
    str_3 = 'blac'
    # msg when all is ok
    str_4 = 'ok=' + str(2)
    # msg when there is an error
    str_5 = 'err=' + str(2)
    # msg when there is an change in the system
    str_6 = 'chg=' + str(2)

    if ANSIBLE_COLOR:
        # Test msg when all is ok
        var_1 = stringc(str_4, str_7)
        assert var_

# Generated at 2022-06-25 12:56:48.430800
# Unit test for function stringc
def test_stringc():
    str_0 = 'gree'
    var_1 = stringc(str_0, 'gree', False)


# Generated at 2022-06-25 12:56:55.756410
# Unit test for function hostcolor
def test_hostcolor():
    host = 'myhost'
    stats = {'changed': 0, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    str_0 = hostcolor(host, stats, color=False)
    assert str_0 == u'%-26s' % host

    str_0 = hostcolor(host, stats)
    assert str_0 == u'%-26s' % stringc(host, C.COLOR_OK)

    stats = {'changed': 1, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    str_0 = hostcolor(host, stats, color=False)
    assert str_0 == u'%-26s' % host

    str_0 = hostcolor(host, stats)

# Generated at 2022-06-25 12:56:57.834609
# Unit test for function stringc
def test_stringc():
    print('Test stringc')
    str_0 = 'gree'
    text_0 = 'test string'
    test_stringc_0 = stringc(text_0, str_0)


# Generated at 2022-06-25 12:56:59.045131
# Unit test for function hostcolor
def test_hostcolor():
    # TODO: Write logic for hostcolor test case
    return


# Generated at 2022-06-25 12:57:03.815130
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()
    str_0 = hostcolor('public-1.example.com', {'changed': 0, 'failures': 1, 'ok': 2, 'skipped': 0, 'unreachable': 0})
    assert str_0 == 'public-1.example.com                            '


# Generated at 2022-06-25 12:57:08.063874
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'test_host'
    dict_0 = {'unreachable': 0, 'failures': 0, 'skipped': 0, 'changed': 0}
    var_0 = hostcolor(str_0, dict_0)


# Generated at 2022-06-25 12:57:13.052010
# Unit test for function hostcolor
def test_hostcolor():
    var_1 = u'127.0.0.1'
    var_2 = {'failures': 0, 'changed': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    var_3 = True
    var_4 = hostcolor(var_1, var_2, var_3)
    assert var_4 == '127.0.0.1                                       '


# Generated at 2022-06-25 12:57:17.810555
# Unit test for function colorize
def test_colorize():
    var_0 = colorize(u'OK', 2, u'green')
    var_1 = colorize(u'CHANGED', 1, u'red')
    var_2 = colorize(u'FAILED', 1, u'red')
    var_3 = colorize(u'UNREACHABLE', 1, u'red')
    var_4 = colorize(u'SKIPPED', 1, u'blue')



# Generated at 2022-06-25 12:57:30.594674
# Unit test for function stringc
def test_stringc():
    text = 'test'
    color = 'red'
    wrap_nonvisible_chars = True
    result = stringc(text, color, wrap_nonvisible_chars)
    print(result)
    assert result == u"\001\033[31m\002test\001\033[0m\002"


# Generated at 2022-06-25 12:57:34.851770
# Unit test for function stringc
def test_stringc():
    str_0 = 'gree'
    str_1 = 'gree'
    str_2 = 'gree'
    str_3 = 'gree'
    var_0 = stringc(str_0, str_1)
    var_1 = stringc(str_2, str_3, True)


# Generated at 2022-06-25 12:57:43.846824
# Unit test for function stringc
def test_stringc():
    str_0 = 'color0'
    str_1 = 'rgb555'
    str_2 = 'gray0'
    str_3 = 'red'
    str_4 = 'green'
    str_5 = 'blue'
    str_6 = 'reset'
    str_7 = 'bold'
    str_8 = 'underline'
    str_9 = 'yellow'
    str_10 = 'cyan'
    var_0 = stringc(str_0, str_0)
    var_1 = stringc(str_1, str_1)
    var_2 = stringc(str_2, str_2)
    var_3 = stringc(str_3, str_3)
    var_4 = stringc(str_4, str_4)

# Generated at 2022-06-25 12:57:55.291362
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'red'
    var_0 = parsecolor(str_0)
    str_1 = 'green'
    var_1 = parsecolor(str_1)
    str_2 = 'yellow'
    var_2 = parsecolor(str_2)
    str_3 = 'blue'
    var_3 = parsecolor(str_3)
    str_4 = 'cyan'
    var_4 = parsecolor(str_4)
    str_5 = 'magenta'
    var_5 = parsecolor(str_5)
    str_6 = 'white'
    var_6 = parsecolor(str_6)
    str_7 = 'gray'
    var_7 = parsecolor(str_7)
    str_8 = 'color0'
    var_

# Generated at 2022-06-25 12:58:03.746931
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost-------------------'
    assert hostcolor('example.com', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[31;01mexample.com\x1b[0m               '
    assert hostcolor('example.com', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[31;01mexample.com\x1b[0m               '
    assert hostcolor('example.com', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[33;01mexample.com\x1b[0m               '


# Generated at 2022-06-25 12:58:06.698257
# Unit test for function colorize
def test_colorize():
    assert colorize("lead", "0", "green") == stringc("lead=0", "green")
    assert colorize("lead", "1", "green") == stringc("lead=1", "green")



# Generated at 2022-06-25 12:58:12.506462
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    dict_0 = {
        'changed': 0,
        'failures': 0,
        'ok': 2,
        'skipped': 0,
        'unreachable': 0
    }
    if ANSIBLE_COLOR:
        assert hostcolor(str_0, dict_0) == u'%-37s' % stringc(str_0, C.COLOR_OK)
    else:
        assert hostcolor(str_0, dict_0) == u'%-26s' % str_0

# Generated at 2022-06-25 12:58:18.967063
# Unit test for function colorize
def test_colorize():
    print(u"@test_colorize")
    lead = u"lead"
    num = 1
    color = u"red"
    exp_result = u"\u001b[31mlead=1  \u001b[0m"
    result = colorize(lead, num, color)
    print(u"result: %s" % result)
    print(u"expected: %s" % exp_result)
    assert result == exp_result


# Generated at 2022-06-25 12:58:24.423480
# Unit test for function stringc
def test_stringc():
    str_0 = 'gree'
    str_1 = 'blac'
    str_2 = '\x1B[38;5;28m'
    str_3 = '\x1B[0m'
    str_4 = '\x1B[38;5;34m'
    str_5 = '\x1B[38;5;40m'
    str_6 = '\x1B[38;5;46m'
    str_7 = '\x1B[38;5;52m'
    my_str = 'hello'
    var_0 = stringc(my_str, str_0)

# Generated at 2022-06-25 12:58:28.958657
# Unit test for function stringc
def test_stringc():
    str_0 = 'gree'
    str_1 = 'gree'
    var_1 = parsecolor(str_0)
    str_2 = 'gree'
    str_3 = 'gree'
    str_4 = 'gree'
    str_5 = 'gree'
    var_2 = stringc(str_2, var_1)



# Generated at 2022-06-25 12:58:55.774787
# Unit test for function stringc
def test_stringc():
    str_0 = 'gree'
    str_1 = stringc(str_0, 'gree')
    str_2 = '0'
    str_3 = stringc(str_2, '0')
    str_4 = '5'
    str_5 = stringc(str_4, '5')
    str_6 = 'bgree'
    str_7 = stringc(str_6, 'bgree')
    str_8 = 'b0'
    str_9 = stringc(str_8, 'b0')
    str_10 = 'b5'
    str_11 = stringc(str_10, 'b5')
    str_12 = 'gray0'
    str_13 = stringc(str_12, 'gray0')



# Generated at 2022-06-25 12:58:56.909885
# Unit test for function colorize
def test_colorize():
    pass

# Generated at 2022-06-25 12:59:02.897490
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('ansible', {'failures': '0', 'unreachable': '0', 'ok': '16', 'changed': '9'}, True) == '\033[38;5;28mansible\033[0m'
    assert hostcolor('ansible', {'failures': '0', 'unreachable': '0', 'ok': '16', 'changed': '9'}, False) == 'ansible       '


# Generated at 2022-06-25 12:59:06.075849
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'example'
    dict_0 = {'failures': 0, 'changed': 0, 'unreachable': 0}
    var_0 = hostcolor(str_0, dict_0)


# Generated at 2022-06-25 12:59:06.733064
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('green', 'ok') == 'ok'

# Generated at 2022-06-25 12:59:09.522094
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {"failures":0, "unreachable":0, "changed":0}
    color = True
    result = hostcolor(host, stats, color)
    assert result == u"%-26s" % stringc(host, C.COLOR_OK)


# Generated at 2022-06-25 12:59:15.025867
# Unit test for function stringc
def test_stringc():
    #
    # Tested function
    #
    str_0 = stringc('Ziad', 'COLOR_OK')
    assert(str_0 == '\033[92mZiad\033[0m')

    if ANSIBLE_COLOR:
        str_0 = stringc('Ziad', 'COLOR_OK', wrap_nonvisible_chars=True)
        assert(str_0 == '\001\033[92m\002Ziad\001\033[0m\002')


# Generated at 2022-06-25 12:59:21.108094
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '10.66.6.176'
    dict_0 = {'skipped':0, 'ok':0, 'failures': 0, 'unreachable': 0, 'changed': 0, 'rescued': 0, 'ignored': 0}
    var_0 = hostcolor(str_0, dict_0)
    assert(var_0 == '10.66.6.176         ')


# Generated at 2022-06-25 12:59:29.105466
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'gree'
    str_1 = 'blu'
    list_0 = []
    dict_0 = dict()
    dict_0['failures'] = 0
    dict_0['failures'] = 0
    dict_0['failures'] = 0
    dict_0['unreachable'] = 0
    dict_0['unreachable'] = 0
    dict_0['unreachable'] = 0
    dict_0['failed'] = 0
    dict_0['failed'] = 0
    dict_0['failed'] = 0
    dict_0['dark'] = 0
    dict_0['dark'] = 0
    dict_0['dark'] = 0
    dict_0['changed'] = 0
    dict_0['changed'] = 0
    dict_0['changed'] = 0

# Generated at 2022-06-25 12:59:34.500192
# Unit test for function colorize
def test_colorize():
    test_values = [
        (u'ok', 9, 'green'),
        (u'changed', 9, 'yellow'),
        (u'failed', 9, 'red'),
        (u'skipped', 9, 'cyan'),
        (u'unreachable', 9, 'bright purple'),
    ]
    for i in test_values:
        colorize(*i)

# Generated at 2022-06-25 12:59:56.793660
# Unit test for function hostcolor
def test_hostcolor():
    host = "test host"
    stats = {}
    color = True
    hostcolor(host, stats, color)

if __name__ == '__main__':
    test_case_0()
    test_hostcolor()
    # --- end "pretty"

# Generated at 2022-06-25 13:00:03.542418
# Unit test for function stringc
def test_stringc():
    import sys
    import os
    ansible_stdout = sys.stdout.fileno()
    isatty = os.isatty(ansible_stdout)
    str_0 = 'gree'
    str_1 = 'red'
    if isatty:
        str_0 = os.getenv('C')
    var_0 = stringc('test', str_0)
    var_1 = stringc('test', str_1)


# Generated at 2022-06-25 13:00:12.809897
# Unit test for function hostcolor
def test_hostcolor():
    host = u"localhost"
    stats = {
        "changed": 1,
        "failures": 2,
        "dark": 3,
        "light": 4,
        "ok": 5,
        "processed": 6,
        "rescued": 7,
        "skipped": 8,
        "dark_failed": 9,
        "dark_ok": 10,
        "unreachable": 11,
        "dark_skipped": 12,
        "dark_unreachable": 13,
        "ignored": 14,
        "ansible_host": host
    }
    test_res = hostcolor(host, stats, True)
    assert test_res == u"%-37s" % stringc(host, C.COLOR_ERROR)
    