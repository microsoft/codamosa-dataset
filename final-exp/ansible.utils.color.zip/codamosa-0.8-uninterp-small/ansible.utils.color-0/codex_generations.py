

# Generated at 2022-06-25 12:50:20.033351
# Unit test for function stringc
def test_stringc():
    bytes_0 = b'color'
    bytes_1 = b'rgb'
    bytes_2 = b'gray'
    bytes_3 = b'color'
    var_0 = stringc(bytes_0, bytes_3)
    bytes_4 = b'color'
    bytes_5 = b'rgb'
    bytes_6 = b'gray'
    bytes_7 = b'color'
    var_1 = stringc(bytes_4, bytes_7)
    bytes_8 = b'color'
    bytes_9 = b'rgb'
    bytes_10 = b'gray'
    bytes_11 = b'color'
    var_2 = stringc(bytes_8, bytes_11)
    bytes_12 = b'color'
    bytes_13 = b'rgb'
    bytes_14

# Generated at 2022-06-25 12:50:28.216191
# Unit test for function parsecolor
def test_parsecolor():
    bytes_0 = b'color0'
    var_0 = parsecolor(bytes_0)
    assert var_0 == u'38;5;0'
    bytes_1 = b'color1'
    var_1 = parsecolor(bytes_1)
    assert var_1 == u'38;5;1'
    bytes_2 = b'color2'
    var_2 = parsecolor(bytes_2)
    assert var_2 == u'38;5;2'
    bytes_3 = b'color3'
    var_3 = parsecolor(bytes_3)
    assert var_3 == u'38;5;3'
    bytes_4 = b'color4'
    var_4 = parsecolor(bytes_4)
    assert var_4 == u'38;5;4'

# Generated at 2022-06-25 12:50:34.406075
# Unit test for function parsecolor
def test_parsecolor():
    var_1 = parsecolor(b'red')
    assert var_1 == u'31'
    var_2 = parsecolor(b'blue')
    assert var_2 == u'34'
    var_3 = parsecolor(b'green')
    assert var_3 == u'32'
    var_4 = parsecolor(b'yellow')
    assert var_4 == u'33'
    var_5 = parsecolor(b'purple')
    assert var_5 == u'35'
    var_6 = parsecolor(b'cyan')
    assert var_6 == u'36'
    var_7 = parsecolor(b'white')
    assert var_7 == u'37'
    var_8 = parsecolor(b'0')

# Generated at 2022-06-25 12:50:37.603970
# Unit test for function stringc
def test_stringc():
    # print(u'Testing function stringc')
    # bytes_0 = b''
    # var_0 = parsecolor(bytes_0)
    # var_1 = stringc(var_0, var_0)
    # print(u'Results for function stringc:')
    # print('{0}'.format(var_1))
    pass


# Generated at 2022-06-25 12:50:38.371583
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()


# Generated at 2022-06-25 12:50:39.278993
# Unit test for function stringc
def test_stringc():
    assert True


# Generated at 2022-06-25 12:50:41.134506
# Unit test for function hostcolor
def test_hostcolor():
    discover()


if __name__ == "__main__":
    test_case_0()
    test_hostcolor()

# --- end "pretty"
#


# Generated at 2022-06-25 12:50:45.734543
# Unit test for function hostcolor
def test_hostcolor():
    # 0
    var_0 = hostcolor(None, None)
    # 1
    var_1 = hostcolor('spam', 42)
    # 2
    var_2 = hostcolor(None, None, False)
    # 3
    var_3 = hostcolor(None, None, True)
    # 4
    var_4 = hostcolor(None, None, True)


# Generated at 2022-06-25 12:50:54.082569
# Unit test for function stringc
def test_stringc():
    """String in color."""
    # Testing var_0 = stringc(u'', None)
    var_0 = stringc(u'', None)
    assert var_0 is not None
    # Testing var_0 = stringc(u'', parsecolor(u'Default'))
    var_0 = stringc(u'', parsecolor(u'Default'))
    assert var_0 is not None
    # Testing var_0 = stringc(u'', parsecolor(u'Reset'))
    var_0 = stringc(u'', parsecolor(u'Reset'))
    assert var_0 is not None
    # Testing var_0 = stringc(u'', parsecolor(u'Bold'))

# Generated at 2022-06-25 12:50:57.876049
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = 'localhost'
    var_1 = {'changed': 0, 'unreachable': 0, 'failures': 0}
    var_2 = test_case_0()
    try:
        var_3 = hostcolor(var_0, var_1, var_2)
        assert type(var_3) == str
    except AssertionError as e:
        var_4 = e


# Generated at 2022-06-25 12:51:05.647289
# Unit test for function hostcolor
def test_hostcolor():
    host = u''
    stats = {}
    color = True
    var_0 = hostcolor(host, stats, color)
    var_1 = hostcolor(u'', {}, True)


# Generated at 2022-06-25 12:51:06.543739
# Unit test for function parsecolor
def test_parsecolor():
    pass


# Generated at 2022-06-25 12:51:19.453429
# Unit test for function stringc
def test_stringc():
    # Test case 0
    # Test case 0
    # Test case 0

    # Test case 0
    # Test case 0
    # Test case 0

    # Test case 0
    # Test case 0
    # Test case 0
    bytes_6 = b''
    var_6 = parsecolor(bytes_6)

    # Test case 0
    # Test case 0
    # Test case 0
    bytes_7 = b''
    var_7 = parsecolor(bytes_7)

    # Test case 0
    # Test case 0
    # Test case 0
    bytes_8 = b''
    var_8 = parsecolor(bytes_8)

    # Test case 0
    # Test case 0
    # Test case 0
    bytes_9 = b''
    var_9 = parsecolor(bytes_9)

    # Test

# Generated at 2022-06-25 12:51:29.560867
# Unit test for function colorize
def test_colorize():
    lead = 'lead'
    num = 200
    color = 'green'

    # testing lower bound
    assert colorize(lead, 0, color) == 'lead=0   '

    # testing upper bound
    assert colorize(lead, 2**16-1, color) == 'lead=65535'

    # testing middle bound
    assert colorize(lead, 200, color) == 'lead=200 '

    # testing float bound
    assert colorize(lead, 200.5, color) == 'lead=200.5'

    # testing str and int boundaries
    assert colorize(lead, '10', color) == 'lead=10  '

    # testing string color
    assert colorize('lead', 100, 'red') == 'lead=100 '


# Generated at 2022-06-25 12:51:37.922277
# Unit test for function hostcolor
def test_hostcolor():
    # TODO: check if host is from ansible, if not set color as error

    # input
    ansible_host = '192.168.0.1'
    ansible_stats = {
        'unreachable': 0,
        'changed': 0,
        'failures': 0
    }

    # expected output
    expected_output = u"%-26s" % stringc(ansible_host, C.COLOR_OK)
    # real output
    real_output = hostcolor(ansible_host, ansible_stats)
    assert expected_output == real_output

    # expected output
    expected_output = u"%-26s" % stringc(ansible_host, C.COLOR_ERROR)
    # real output
    ansible_stats['unreachable'] = 1

# Generated at 2022-06-25 12:51:40.791338
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'changed': 1, 'failures': 1, 'ok': 1, 'skipped': 1, 'unreachable': 1}
    color = True
    var_0 = hostcolor(host, stats, color)



# Generated at 2022-06-25 12:51:42.566033
# Unit test for function parsecolor
def test_parsecolor():
    assert True



# Generated at 2022-06-25 12:51:52.542969
# Unit test for function hostcolor
def test_hostcolor():

    assert(hostcolor('dummy_1', {
        'skipped': 0,
        'failed': 0,
        'changed': 0,
        'ok': 1,
        'dark': 0,
        'processed': 1,
        'rescued': 0,
        'ignored': 0,
        'unreachable': 0,
        'skipped_percent': 0.0,
        'failed_percent': 0.0,
        'dark_percent': 0.0,
        'ignored_percent': 0.0,
        'ok_percent': 100.0,
    }, color=ANSIBLE_COLOR) == u"%-37s")

# Generated at 2022-06-25 12:51:53.606851
# Unit test for function parsecolor
def test_parsecolor():
    # Tests for 1 arguments
    test_case_0()



# Generated at 2022-06-25 12:51:55.137279
# Unit test for function parsecolor
def test_parsecolor():
    # ansible.utils.color.py:parsecolor
    # (..., 0, 0, 0)
    test_case_0()



# Generated at 2022-06-25 12:51:59.662634
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()


# Generated at 2022-06-25 12:52:00.898152
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'h@'
    var_0 = parsecolor(str_0)
# --- end "pretty"

# Generated at 2022-06-25 12:52:07.413854
# Unit test for function stringc
def test_stringc():
    str_0 = 'y84D3GJktFV4Z:{(=\\hV'
    str_1 = '\x1b[38;5;195m%s\x1b[0m' % str_0
    var_0 = stringc(str_0, str_0)
    assert(var_0 == str_1)


# Generated at 2022-06-25 12:52:10.620581
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'y84D3GJktFV4Z:{(=\\hV'
    from ansible.utils.color import parsecolor
    var_0 = parsecolor(str_0)
    test_case_0()

# Generated at 2022-06-25 12:52:17.861953
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('test_string', {'changed': 1, 'skipped': 1, 'ok': 1, 'unreachable': 1, 'failures': 1}) == 'test_string                '
    assert hostcolor('test_string', {'changed': 1, 'skipped': 1, 'ok': 2, 'unreachable': 1, 'failures': 1}) == 'test_string                '
    assert hostcolor('test_string', {'changed': 1, 'skipped': 1, 'ok': 3, 'unreachable': 1, 'failures': 1}) == 'test_string                '
    assert hostcolor('test_string', {'changed': 1, 'skipped': 1, 'ok': 4, 'unreachable': 1, 'failures': 1}) == 'test_string                '

# Generated at 2022-06-25 12:52:19.970087
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()

# --- end "pretty"

if __name__ == "__main__":
    test_parsecolor()

# Generated at 2022-06-25 12:52:28.632406
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'y84D3GJktFV4Z:{(=\\hV'
    var_0 = parsecolor(str_0)
    str_1 = 'u0hn*lV7z'
    var_0 = parsecolor(str_1)
    str_2 = '\\6\\}RdH\\:8Zh'
    var_0 = parsecolor(str_2)
    str_3 = '\"\\uV7:f8\\'
    var_0 = parsecolor(str_3)
    str_4 = '\\5$[JE"5p'
    var_0 = parsecolor(str_4)
    str_5 = ']pJrOcq3'
    var_0 = parsecolor(str_5)

# Generated at 2022-06-25 12:52:30.824469
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'hv5BG6UW7Vu5i'
    var_0 = parsecolor(str_0)
    assert var_0 == u'38;5;111'


# Generated at 2022-06-25 12:52:32.165136
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()

# --- end "pretty"



# Generated at 2022-06-25 12:52:42.379822
# Unit test for function stringc
def test_stringc():
    # Test with a simple string and a yellow color
    assert stringc('This is a test', 'yellow') == u'\033[33mThis is a test\033[0m'
    # Test on a string containing \n and check that it's handled correctly
    assert stringc('This\nis a test', 'yellow') == u'\033[33mThis\nis a test\033[0m'
    # Test that the input string is returned if no color is specified
    assert stringc('This is a test', '') == u'This is a test'
# --- end "pretty"

# Generated at 2022-06-25 12:52:48.976738
# Unit test for function colorize
def test_colorize():
    str_0 = 'j>D'
    result_0 = colorize(str_0, 99, C.COLOR_CHANGED)
    assert result_0 == u"j>D=99  "


# Generated at 2022-06-25 12:52:58.355901
# Unit test for function stringc
def test_stringc():
    var_1 = '\x1b[2;41mG\x1b[0m\n'
    var_1 = stringc('G', 'white', False)
    var_2 = '\x1b[2;41mG\x1b[0m-\n'
    var_2 = stringc('G-', 'white', False)
    var_3 = '\x1b[2;41mG\x1b[0m--\n'
    var_3 = stringc('G--', 'white', False)
    var_4 = '\x1b[2;41mG\x1b[0m---\n'
    var_4 = stringc('G---', 'white', False)

# Generated at 2022-06-25 12:53:05.034849
# Unit test for function hostcolor
def test_hostcolor():

    # Case 0
    var_0 = 'host'
    var_1 = {}
    var_2 = True
    var_3 = hostcolor(var_0, var_1, var_2)

    # Case 1
    var_0 = 'host'
    var_1 = {}
    var_2 = False
    var_3 = hostcolor(var_0, var_1, var_2)

    # Case 2
    var_0 = 'host'
    var_1 = {}
    var_2 = True
    var_3 = hostcolor(var_0, var_1, var_2)

    # Case 3
    var_0 = 'host'
    var_1 = {}
    var_2 = False
    var_3 = hostcolor(var_0, var_1, var_2)

    # Case

# Generated at 2022-06-25 12:53:08.549920
# Unit test for function hostcolor
def test_hostcolor():
    host = 'ansible'
    stats = {'failures': 0, 'unreachable': 0}
    color = True
    actual = hostcolor(host, stats, color)
    assert actual == u"ansible                "


# Generated at 2022-06-25 12:53:11.608922
# Unit test for function colorize
def test_colorize():
    args = {}
    if True:  # just to indent the block
        args['lead'] = 'fgh'
        args['num'] = -2.5717794892
        args['color'] = 'fgD4'
    colorize(**args)


# Generated at 2022-06-25 12:53:12.208606
# Unit test for function parsecolor
def test_parsecolor():
    assert True



# Generated at 2022-06-25 12:53:20.183762
# Unit test for function parsecolor

# Generated at 2022-06-25 12:53:23.028045
# Unit test for function parsecolor
def test_parsecolor():
    try:
        test_case_0()
    except Exception as e:
        print(e)
        assert False, "unit test for parsecolor failed"

# --- end "pretty"



# Generated at 2022-06-25 12:53:34.040350
# Unit test for function hostcolor
def test_hostcolor():
    # No hostname supplied
    assert hostcolor(None, {"failures": 0, "unreachable": 0, "changed": 0}, True) == u"%-37s" % stringc(None, C.COLOR_OK)
    # No failures, unreachable, or changed
    assert hostcolor("test-host", {"failures": 0, "unreachable": 0, "changed": 0}, True) == u"%-37s" % stringc("test-host", C.COLOR_OK)
    # Only failures
    assert hostcolor("test-host", {"failures": 1, "unreachable": 0, "changed": 0}, True) == u"%-37s" % stringc("test-host", C.COLOR_ERROR)
    # Only unreachable

# Generated at 2022-06-25 12:53:37.735823
# Unit test for function stringc
def test_stringc():
    str_0 = 'NG85CNSBcNQyx$>8h'
    str_1 = 'cqfe4hGX0iDIj'
    var_0 = stringc(str_0, str_1)


# Generated at 2022-06-25 12:53:48.242405
# Unit test for function stringc
def test_stringc():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    # Test with 'None' as args
    test_stringc_0()
    # Test with 'True' as args
    test_stringc_1()
    # Test with 'False' as args
    test_stringc_2()
    ANSIBLE_COLOR = False
    # Test with 'None' as args
    test_stringc_0()
    # Test with 'True' as args
    test_stringc_1()
    # Test with 'False' as args
    test_stringc_2()


# Generated at 2022-06-25 12:53:59.033129
# Unit test for function hostcolor
def test_hostcolor():
    # Do case test 0
    str_0 = 'k00O7xQZ1Nl'
    dict_0 = dict({'unreachable': 7, 'changes': 4, 'ok': 7, 'failures': 7})
    bool_0 = TRUE
    call_fn = hostcolor(str_0, dict_0, bool_0)
    assert call_fn == '#TGRT#TGRT'

    # Do case test 1
    str_0 = 'x1zquI'
    dict_0 = dict({'unreachable': 9, 'changes': 1, 'ok': 2, 'failures': 9})
    bool_0 = TRUE
    call_fn = hostcolor(str_0, dict_0, bool_0)
    assert call_fn == '#TGRT#TGRT'

    #

# Generated at 2022-06-25 12:54:01.146426
# Unit test for function stringc
def test_stringc():
    str_1 = 't/Z@t.\'/I+z}|yRmQY'
    var_1 = stringc(str_1, 'color16')

# Generated at 2022-06-25 12:54:03.656551
# Unit test for function stringc
def test_stringc():
    assert stringc('', 'rgb255255255') != stringc('', 'rgb255255255')
    assert stringc('', 'rgb255255255') == stringc('', 'rgb255255255')

# Generated at 2022-06-25 12:54:10.392394
# Unit test for function stringc
def test_stringc():
    assert stringc('', 'blue') == '\n\033[38;5;4m\033[0m'
    assert stringc('', 'green') == '\n\033[38;5;2m\033[0m'
    assert stringc('', 'fuschia') == '\n\033[38;5;13m\033[0m'
    assert stringc('', 'rgb255') == '\n\033[38;5;231m\033[0m'
    assert stringc('', 'rgb550') == '\n\033[38;5;71m\033[0m'
    assert stringc('', 'rgb553') == '\n\033[38;5;74m\033[0m'

# Generated at 2022-06-25 12:54:21.324739
# Unit test for function colorize
def test_colorize():
    # Test 1
    lead = 'lead'
    num = 5
    color = 'blue'
    s = 'lead%s=%-4s' % (C.COLOR_CODES[color], num)
    ans = colorize(lead, num, color)
    print('string should be: %s' % s)
    print('string is: %s' % ans)
    assert s == ans
    print('-' * 50)

    # Test 2
    lead = 'lead'
    num = 5
    color = 'yellow'
    s = 'lead%s=%-4s' % (C.COLOR_CODES[color], num)
    ans = colorize(lead, num, color)
    print('string should be: %s' % s)
    print('string is: %s' % ans)

# Generated at 2022-06-25 12:54:29.097070
# Unit test for function stringc
def test_stringc():
    # There is no color or underline
    str_1 = 'y84D3GJktFV4Z:{(=\\hV'
    var_1 = stringc(str_1, 'color2', True)
    # There is no color or underline
    str_2 = 'g6h2:7Vzf6w3FxKi1S8'
    var_2 = stringc(str_2, 'color5', True)
    # There is no color or underline
    str_3 = 't9L9ql1:Ca'
    var_3 = stringc(str_3, 'color8', True)
    # There is no color or underline
    str_4 = 'PIFefs7m'
    var_4 = stringc(str_4, 'color11', True)
   

# Generated at 2022-06-25 12:54:40.598735
# Unit test for function hostcolor
def test_hostcolor():
    """hostcolor"""

    #
    # Test #0
    #
    host = 'hvdsx'
    stats = {
        'changed': 0,
        'dark': 0,
        'failures': 0,
        'ok': 0,
        'processed': 0,
        'rescued': 0,
        'skipped': 0,
        'unreachable': 0
    }
    color = True
    expected_0 = 'hvdsx                  '
    actual_0 = hostcolor(host, stats, color)
    assert actual_0 == expected_0, 'Test #0 failed'

    #
    # Test #1
    #
    host = 'Z7\njKi'

# Generated at 2022-06-25 12:54:48.564302
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'blue'
    var_0 = parsecolor(str_0)
    assert var_0 == u'34', 'global parsecolor, line: %s' % var_0
    str_0 = 'rgb255255255'
    var_0 = parsecolor(str_0)
    assert var_0 == u'38;5;231', 'global parsecolor, line: %s' % var_0
    str_0 = 'rgb0255000'
    var_0 = parsecolor(str_0)
    assert var_0 == u'38;5;46', 'global parsecolor, line: %s' % var_0
    str_0 = 'white'
    var_0 = parsecolor(str_0)

# Generated at 2022-06-25 12:54:54.912630
# Unit test for function hostcolor
def test_hostcolor():
    host = 'empty'
    stats = {}
    stats['changed'] = 100
    stats['failures'] = 50
    stats['unreachable'] = 10
    color = True
    out = hostcolor(host,stats,color)
    assert out == u"\x1b[0;31;40mempty\x1b[0m"
    stats['failures'] = 0
    out = hostcolor(host,stats,color)
    assert out == u"\x1b[0;33;40mempty\x1b[0m"
    stats['changed'] = 0
    out = hostcolor(host,stats,color)
    assert out == u"\x1b[0;32;40mempty\x1b[0m"


# Generated at 2022-06-25 12:55:04.054961
# Unit test for function hostcolor
def test_hostcolor():
    host = u'y84D3GJktFV4Z:{(=\\hV'
    num = u'y84D3GJktFV4Z:{(=\\hV'
    color = u'y84D3GJktFV4Z:{(=\\hV'
    var_0 = hostcolor(host, num, color)


# Generated at 2022-06-25 12:55:07.182195
# Unit test for function stringc
def test_stringc():
    # will wrap @test_case_0 when run from the command line
    from ansible.module_utils.common.ansible_test import test_module

    test_module(
        arguments={
            'string': 'Hello World!',
            'color': 'red',
            'wrap_nonvisible_chars': True,
        },
        from_commandline=False,
    )


# Generated at 2022-06-25 12:55:14.977332
# Unit test for function hostcolor
def test_hostcolor():
    host_0 = 'localhost'
    stats_0 = {'failures': 0, 'changed': 0, 'unreachable': 0}
    color_0 = True
    var_0 = hostcolor(host_0, stats_0, color_0)
    assert var_0 == u'localhost                 '
    host_1 = 'localhost'
    stats_1 = {'failures': 1, 'changed': 0, 'unreachable': 0}
    color_1 = True
    var_1 = hostcolor(host_1, stats_1, color_1)
    assert var_1 == u'\x1b[31mlocalhost                 \x1b[0m'
    host_2 = 'localhost'
    stats_2 = {'failures': 0, 'changed': 1, 'unreachable': 0}
    color_

# Generated at 2022-06-25 12:55:17.586254
# Unit test for function colorize
def test_colorize():
    # colorize(lead, num, color)
    assert colorize('>', 2, "38;5;1") == '>2   '


# Generated at 2022-06-25 12:55:25.498216
# Unit test for function stringc
def test_stringc():
    str_0 = 'color0'
    str_1 = stringc(str_0, str_0)
    str_2 = 'color1'
    str_3 = stringc(str_2, str_2)
    str_4 = 'color2'
    str_5 = stringc(str_4, str_4)
    str_6 = 'color3'
    str_7 = stringc(str_6, str_6)
    str_8 = 'color4'
    str_9 = stringc(str_8, str_8)
    str_10 = 'color5'
    str_11 = stringc(str_10, str_10)
    str_12 = 'color6'
    str_13 = stringc(str_12, str_12)
    str_14 = 'color7'


# Generated at 2022-06-25 12:55:37.098687
# Unit test for function stringc
def test_stringc():
    str_1 = 'y84D3GJktFV4Z:{(=\\hV'
    str_2 = 'EoZ:h8ZH'
    str_3 = 'egGk1aJdV5r5'
    str_4 = 'PW8:baiKjNWOL'
    str_5 = 'EoZ:h8ZH'
    str_6 = 'A8ciPcK9zt'
    str_7 = 'EoZ:h8ZH'
    str_8 = 'Oz{ncQDGHq'
    ret_1 = stringc(str_2, str_3, str_4)
    ret_1.split()
    ret_2 = stringc(str_5, str_6, str_7, str_8)
    ret

# Generated at 2022-06-25 12:55:40.814679
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'puppy', {u'ignored': 0, u'ok': 0, u'changed': 0, u'failures': 0, u'unreachable': 0}, ANSIBLE_COLOR) == u'puppy                             '



# Generated at 2022-06-25 12:55:54.311620
# Unit test for function stringc
def test_stringc():
    str_0 = 'y84D3GJktFV4Z:{(=\\hV'
    str_1 = 'Q'
    var_0 = stringc(str_0, str_1)
    str_2 = 'fV7a_49wJ=V*'
    str_3 = 'm'
    var_1 = stringc(str_2, str_3)
    str_4 = 'r,M-7_8225x`E9N$'
    str_5 = 's'
    var_2 = stringc(str_4, str_5)
    str_6 = '.'
    str_7 = 'd'
    var_3 = stringc(str_6, str_7)
    str_8 = ';<o'
    str_9 = 'v'
   

# Generated at 2022-06-25 12:55:58.701707
# Unit test for function hostcolor
def test_hostcolor():
    test_host = u'test_host'
    test_stats = {
        'changed': 2,
        'failures': 3,
        'ok': 0,
        'skipped': 2,
        'unreachable': 0
    }
    assert hostcolor(test_host, test_stats, False) == u"%-26s" % test_host



# Generated at 2022-06-25 12:56:01.253111
# Unit test for function colorize
def test_colorize():
    lead = 'o'
    num = -5
    color = 'red'
    result = colorize(lead, num, color)
    assert result == 'o=-5  '


# Generated at 2022-06-25 12:56:09.215490
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()


# Generated at 2022-06-25 12:56:13.515796
# Unit test for function hostcolor
def test_hostcolor():
    class var_0(object):
        count = 2
        skipped = 1
        ok = 1
        changed = 1
        unreachable = 1
        failed = 1
    var_1 = hostcolor(var_0, var_0, color=True)
    if not isinstance(var_1, str) :
        test_case_0()


# Generated at 2022-06-25 12:56:24.861893
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    dict_0 = {'dark_green': 0, 'blue': 0, 'dynamic': 0, 'pink': 0, 'yellow': 0, 'white': 0, 'green': 0, 'dark_gray': 0, 'light_gray': 0, 'red': 0, 'changed': 0, 'dark_red': 0, 'ok': 0, 'dark_pink': 0, 'unreachable': 0, 'dark_yellow': 0, 'dark_blue': 0, 'dark_white': 0, 'failures': 0}
    var_0 = hostcolor(str_0, dict_0, True)
    str_1 = 'x<Fo>Pt?2|gD'

# Generated at 2022-06-25 12:56:28.721797
# Unit test for function stringc
def test_stringc():
    str_0 = 'Z4Q4i'
    str_1 = 'U6Sbk'
    str_2 = 'W64eZ'
    str_3 = 'xHl8i'
    var_0 = stringc(str_0, str_1, str_2)
    var_1 = stringc(str_1, str_3, str_2)


# Generated at 2022-06-25 12:56:33.476063
# Unit test for function colorize
def test_colorize():
    # Input parameters
    lead = "A"
    num = 10
    color = "red"
    out_expected = "A=10  "
    out_actual = colorize(lead, num, color)
    print("Expected: %s" % out_expected)
    print("Actual: %s" % out_actual)
    print("\n-----\n")


# Generated at 2022-06-25 12:56:36.521232
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = {'skipped': 0, 'ok': 1, 'unreachable': 0, 'failures': 0, 'changed': 0}
    var_1 = hostcolor('TEST_DATA', var_0, True)


# Generated at 2022-06-25 12:56:48.079547
# Unit test for function hostcolor
def test_hostcolor():

    # color=True
    s = hostcolor('172.16.22.33', {'changed': 5, 'failures': 1, 'skipped': 2, 'ok': 7, 'unreachable': 3})
    assert u"%-37s" % stringc('172.16.22.33', C.COLOR_ERROR) == s

    s = hostcolor('172.16.22.33', {'changed': 1, 'failures': 0, 'skipped': 0, 'ok': 1, 'unreachable': 0})
    assert u"%-37s" % stringc('172.16.22.33', C.COLOR_CHANGED) == s


# Generated at 2022-06-25 12:56:55.524087
# Unit test for function stringc
def test_stringc():
    # Test variables
    str_0 = 'bri1 dot com'
    str_1 = 'rgb0000'
    str_2 = 'rgb2100'
    str_3 = 'rgb0310'
    str_4 = 'rgb0123'
    str_5 = 'rgb4200'
    str_6 = 'rgb4320'
    str_7 = 'rgb0200'
    str_8 = 'rgb1230'
    str_9 = 'rgb4321'
    str_10 = 'rgb5123'
    str_11 = 'rgb5342'
    str_12 = 'rgb2354'
    str_13 = 'rgb5432'
    str_14 = 'rgb3425'
    str_15 = 'rgb4325'
    str_

# Generated at 2022-06-25 12:57:00.744514
# Unit test for function parsecolor
def test_parsecolor():
    from nose.tools import assert_equals
    assert_equals(parsecolor('asdf'), None)
    assert_equals(parsecolor('red'), '31')
    assert_equals(parsecolor('gray'), '30')
    assert_equals(parsecolor('dark gray'), '1;30')
    assert_equals(parsecolor('blue'), '34')
    assert_equals(parsecolor('color1'), '38;5;1')
    assert_equals(parsecolor('rgb255'), '38;5;231')
    assert_equals(parsecolor('rgb000'), '38;5;16')
    assert_equals(parsecolor('rgb123'), '38;5;47')

# Generated at 2022-06-25 12:57:11.773220
# Unit test for function hostcolor
def test_hostcolor():
    '''Test unit for function hostcolor.'''
    # Tests:
    str_0 = 'y84D3GJktFV4Z:{(=\\hV'
    str_1 = 'EMwY7Iz2Q==6Ux0~=?e<0'
    str_2 = 'T8Tc}zw{,r+C]3q)jZa2'
    str_3 = '9=lN6P_FZlk`|UdIU6se'
    str_4 = 'K''w'
    str_5 = '$'
    str_6 = '3;'
    str_7 = 'B'
    str_8 = '86'
    str_9 = 'gO'
    str_10 = 'S*'
    str_11 = '3'

# Generated at 2022-06-25 12:57:35.508469
# Unit test for function parsecolor

# Generated at 2022-06-25 12:57:44.315943
# Unit test for function stringc
def test_stringc():
    func_name = 'test_stringc'
    str_0 = 'gPcGuZ'
    str_1 = '3qIyG'
    str_2 = 'tKzdP'
    str_3 = 'CdWG'
    str_4 = 'y84D3GJktFV4Z:{(=\\hV'
    str_5 = 'Fttvw'
    str_6 = '8mU6'
    str_7 = '^h9E'
    var_0 = stringc(str_0, str_1, str_2)
    var_1 = stringc(str_3, str_4)
    var_2 = stringc(str_5, str_6, str_7)
    pass_flag = True

# Generated at 2022-06-25 12:57:56.367448
# Unit test for function colorize
def test_colorize():
    str_0 = 'jK7s_bzA'
    var_0 = colorize(str_0, str_0, 'iJeOZl0v7')
    str_1 = 'wGih0Mx2g_Wj'
    var_1 = colorize(str_1, str_1, 'G5WB5eKjMD')
    str_2 = 'X!'
    var_2 = colorize(str_2, str_2, 'FNT0GtD@N')
    str_3 = 't2Qsn-'
    var_3 = colorize(str_3, str_3, 'bvAiwQUX')
    str_4 = '1rKv7Vu@'

# Generated at 2022-06-25 12:57:59.385430
# Unit test for function colorize
def test_colorize():
    # print colorize.__doc__

    var_0 = None
    var_1 = None
    var_2 = None
    assert colorize(var_0, var_1, var_2) is None


# Generated at 2022-06-25 12:58:08.980834
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('bRI1', {'failures': 1, 'changed': 0, 'unreachable': 0}, True) == u'\x1b[31;01mbRI1                 \x1b[0m'
    assert hostcolor('bRI1', {'failures': 0, 'changed': 1, 'unreachable': 0}, True) == u'\x1b[32;01mbRI1                 \x1b[0m'
    assert hostcolor('bRI1', {'failures': 0, 'changed': 0, 'unreachable': 0}, True) == u'\x1b[33;01mbRI1                 \x1b[0m'

# Generated at 2022-06-25 12:58:14.096940
# Unit test for function colorize
def test_colorize():
    # Arrange
    lead = 'lead'
    num = 2
    color = 'color'
    # Act
    s = colorize(lead, num, color)

    # Assert
    assert isinstance(s, unicode) or isinstance(s, str)
    assert s == "lead=2  "



# Generated at 2022-06-25 12:58:18.686623
# Unit test for function hostcolor
def test_hostcolor():
    var_1 = u'metal.cisco.com'
    var_2 = {u'changed': 0, u'failures': 0, u'unreachable': 0, u'skipped': 0, u'ok': 0}
    var_3 = test_hostcolor(var_1, var_2)


# Generated at 2022-06-25 12:58:21.511509
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == u'lead=num'


# Generated at 2022-06-25 12:58:24.143418
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()

# --- end "pretty"

if __name__ == '__main__':
    sys.exit(test_parsecolor())

# Generated at 2022-06-25 12:58:34.069301
# Unit test for function parsecolor
def test_parsecolor():
    # Test good input
    str_0 = 'default'
    str_1 = 'black'
    str_2 = 'red'
    str_3 = 'green'
    str_4 = 'yellow'
    str_5 = 'blue'
    str_6 = 'magenta'
    str_7 = 'cyan'
    str_8 = 'lightgray'
    str_9 = 'darkgray'
    str_10 = 'lightred'
    str_11 = 'lightgreen'
    str_12 = 'lightyellow'
    str_13 = 'lightblue'
    str_14 = 'lightmagenta'
    str_15 = 'lightcyan'
    str_16 = 'white'
    str_17 = 'color1'
    str_18 = 'color2'

# Generated at 2022-06-25 12:58:50.449045
# Unit test for function colorize
def test_colorize():
    lead = 'TEST'
    num = 0
    color = 'green'
    s = colorize(lead, num, color)


# Generated at 2022-06-25 12:58:54.501808
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'y84D3GJktFV4Z:{(=\\hV'
    var_0 = parsecolor(str_0)
    try:
        assert var_0 == '38;5;73'
    except AssertionError:
        raise


# Generated at 2022-06-25 12:58:57.583294
# Unit test for function stringc
def test_stringc():

    input_str = 'abc'
    color = 'red'
    assert stringc(input_str, color) == '\033[31mabc\033[0m'


# Generated at 2022-06-25 12:58:58.601980
# Unit test for function colorize
def test_colorize():
    assert True



# Generated at 2022-06-25 12:59:04.059194
# Unit test for function colorize
def test_colorize():
    assert colorize('test lead', 0, 'test color') == u"test lead=0   "
    assert colorize('test lead', 10, 'test color') == u"test lead=10  "
    assert colorize('test lead', 100, 'test color') == u"test lead=100 "
    assert colorize('test lead', 1000, 'test color') == u"test lead=1000"


# Generated at 2022-06-25 12:59:10.935712
# Unit test for function stringc
def test_stringc():
    # Testing stringc
    str_0 = 'z!D92s2sFzVL*3<'
    str_1 = 'R%yN*i0c%Oa'
    str_2 = 'O`"aU=FmU<'
    num_0 = 5
    # Testing the first overload
    stringc(str_0, str_1)
    stringc(str_0, str_1, num_0)
    # Testing the second overload
    stringc(str_0, str_1, str_2)
    stringc(str_0, str_1, str_2, num_0)

# Generated at 2022-06-25 12:59:20.981409
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'rgb2553542'
    str_1 = 'color255'
    str_2 = 'color0'
    str_3 = 'color1'
    str_4 = 'color2'
    str_5 = 'color11'
    str_6 = 'color14'
    var_0 = parsecolor(str_0)
    assert(var_0 == u'38;5;45'), "expected u'38;5;45'"
    var_1 = parsecolor(str_1)
    assert(var_1 == u'38;5;255'), "expected u'38;5;255'"
    var_2 = parsecolor(str_2)
    assert(var_2 == u'38;5;0'), "expected u'38;5;0'"
    var_3 = par

# Generated at 2022-06-25 12:59:25.813537
# Unit test for function hostcolor
def test_hostcolor():
    arg0 = ':yD4{ntV'
    arg1 = {'failures': 1, 'ok': 2, 'changed': 3, 'skipped': 4, 'unreachable': 5}
    arg2 = True
    ret = hostcolor(arg0, arg1, arg2)
    # Error: Type mismatch. Expected "string" but got "Nothing"
    # Error: Type mismatch. Expected "bool" but got "Nothing"


# Generated at 2022-06-25 12:59:27.773284
# Unit test for function hostcolor
def test_hostcolor():
    assert '%-37s' == hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}, True)

# Generated at 2022-06-25 12:59:30.451700
# Unit test for function stringc
def test_stringc():
    str_0 = 'y84D3GJktFV4Z:{(=\\hV'
    str_1 = 'y84D3GJktFV4Z:{(=\\hV'
    int_0 = stringc(str_0, str_1)


# Generated at 2022-06-25 12:59:53.622765
# Unit test for function hostcolor
def test_hostcolor():
    val_0 = u'B_0_0'
    val_1 = {'updates': 0, 'changed': 0, 'failures': 0, 'ok': 0, 'dark': 0, 'skipped': 0, 'unreachable': 0}
    val_2 = False

    test_0 = hostcolor(val_0, val_1, val_2)

    val_0 = u'B_0_0'
    val_1 = {'updates': 0, 'changed': 1, 'failures': 0, 'ok': 0, 'dark': 0, 'skipped': 0, 'unreachable': 0}
    val_2 = True

    test_1 = hostcolor(val_0, val_1, val_2)

    val_0 = u'B_0_0'

# Generated at 2022-06-25 12:59:59.492674
# Unit test for function stringc
def test_stringc():
    assert stringc('This is a test', 'dark gray') == u"\033[38;5;238mThis is a test\033[0m"
    assert stringc('This is a test', 'blue') == u"\033[34mThis is a test\033[0m"
    assert stringc('This is a test', 'rgb255255000') == u"\033[38;5;226mThis is a test\033[0m"


# Generated at 2022-06-25 13:00:08.709186
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils.six import StringIO
    import sys
    saved_stdout = sys.stdout
    try:
        out = StringIO()
        sys.stdout = out
        # Call function
        r = hostcolor('localhost', {'changed': None, 'failures': 5, 'ok': 2, 'skipped': None, 'unreachable': 10})
        # Check output
        assert r == 'localhost             '
        out.seek(0)
        assert out.read() == '\x1b[1;31mlocalhost\x1b[0m             '
    finally:
        sys.stdout = saved_stdout
