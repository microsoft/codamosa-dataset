

# Generated at 2022-06-25 12:50:24.662070
# Unit test for function parsecolor
def test_parsecolor():
    var_1 = 16
    var_1 += 36 * 4
    var_1 += 6 * 2
    var_1 += 3
    str_0 = 'color13'
    var_2 = parsecolor(str_0)
    str_1 = 'rgb423'
    var_3 = parsecolor(str_1)
    str_2 = 'rgb023'
    var_4 = parsecolor(str_2)
    var_5 = 232 + 2
    str_3 = 'gray2'
    var_6 = parsecolor(str_3)



# Generated at 2022-06-25 12:50:28.600325
# Unit test for function stringc
def test_stringc():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    str_1 = 'mU%&iOZS,3\x1b[0m'
    var_0 = stringc('mU%&iOZS,3', str_0)
    assert var_0 == str_1


# Generated at 2022-06-25 12:50:34.725735
# Unit test for function stringc
def test_stringc():
    # assert stringc('', 'C.COLOR_CHANGED') == u"\n"
    assert stringc('RTCPp0\n', 'C.COLOR_ERROR') == u"\n"
    assert stringc('\x03Ra,!y\x7f', 'C.COLOR_ERROR') == u"\n"
    assert stringc('=1\x1a[*w;T', 'C.COLOR_OK') == u"\n"
    assert stringc('<\x7fh3\x1a', 'C.COLOR_OK') == u"\n"
    assert stringc('Mt\x7f\x03\x7fw', 'C.COLOR_CHANGED') == u"\n"

# Generated at 2022-06-25 12:50:38.126585
# Unit test for function colorize
def test_colorize():
    num1 = 1

    # colorize()
    # colorize()

    # colorize()
    # colorize()

    # colorize()
    # colorize()

    # colorize()
    # colorize()

    # colorize()
    # colorize()

    # colorize()
    # colorize()



# Generated at 2022-06-25 12:50:40.975554
# Unit test for function hostcolor
def test_hostcolor():
    my_host = 'my-host'
    my_stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    res = hostcolor(my_host, my_stats)
    print('%s' % res)


# Generated at 2022-06-25 12:50:44.629925
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('green') == '32')
    assert(parsecolor('color8') == '38;5;8')
    assert(parsecolor('rgb205') == '38;5;11')
    assert(parsecolor('gray4') == '38;5;236')


# Generated at 2022-06-25 12:50:53.053222
# Unit test for function stringc
def test_stringc():
    try:
        str_0 = '}4\x0bh,y32}`U%&iOZS,3'
        str_1 = '}4\x0bh,y32}`U%&iOZS,3'
        var_0 = stringc(str_0, str_1, False)
        assert var_0 == '\x1b[38;5;137m}\x12\x0b\x08h,y32}\x07`U%&iOZS,3\x1b[0m'
    except AssertionError:
        var_1 = stringc(str_0, str_1, False)

# Generated at 2022-06-25 12:50:54.970158
# Unit test for function parsecolor
def test_parsecolor():
    print('Test #0: parsecolor')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()


# Generated at 2022-06-25 12:50:56.829619
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('a', {}) == u'a                 '
    assert hostcolor('ab', {}) == u'ab                '
    assert hostcolor('abc', {}) == u'abc               '


# Generated at 2022-06-25 12:50:57.932763
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == 'lead=num'


# Generated at 2022-06-25 12:51:09.002432
# Unit test for function hostcolor
def test_hostcolor():
    host = Params({'host': '192.168.1.1'})
    stats = Params({'failures': 0, 'unreachable': 0, 'changed': 0})
    color = True
    ansible.runner.hostcolor(host, stats, color)


# Generated at 2022-06-25 12:51:13.404076
# Unit test for function stringc
def test_stringc():
    """
    Test function stringc
    """
    global ANSIBLE_COLOR
    s = stringc("TEXT", "RED")
    if ANSIBLE_COLOR:
        assert s == "\\x1b[31mTEXT\\x1b[0m"
    else:
        assert s == "TEXT"
    ANSIBLE_COLOR = False
    s = stringc("TEXT", "RED")
    assert s == "TEXT"
    ANSIBLE_COLOR = True

# Generated at 2022-06-25 12:51:16.711095
# Unit test for function stringc
def test_stringc():
    int_0 = stringc("This is the text to colorize.", "blue")
    assert int_0 == "\033[34mThis is the text to colorize.\033[0m"


# Generated at 2022-06-25 12:51:18.706535
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 42
    color = None
    colorize(lead, num, color)


# Generated at 2022-06-25 12:51:20.318151
# Unit test for function stringc
def test_stringc():
    assert stringc("red", "red") == "[31mred[0m"


# Generated at 2022-06-25 12:51:31.479387
# Unit test for function parsecolor
def test_parsecolor():
    # Call function with arguments: 'color0'
    assert parsecolor('color0') == '38;5;0'

    # Call function with arguments: 'color1'
    assert parsecolor('color1') == '38;5;1'

    # Call function with arguments: 'color2'
    assert parsecolor('color2') == '38;5;2'

    # Call function with arguments: 'color3'
    assert parsecolor('color3') == '38;5;3'

    # Call function with arguments: 'color4'
    assert parsecolor('color4') == '38;5;4'

    # Call function with arguments: 'color5'
    assert parsecolor('color5') == '38;5;5'

    # Call function with arguments: 'color6'

# Generated at 2022-06-25 12:51:38.997075
# Unit test for function stringc
def test_stringc():
    print('- test stringc()')
    # disable color
    orig_ANSIBLE_COLOR = ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert stringc('xxx', 'white') == 'xxx'
    ANSIBLE_COLOR = orig_ANSIBLE_COLOR
    # enable color
    assert stringc('xxx', 'white') == '\033[0mxxx\033[0m'
    assert stringc('xxx', 'green') == '\033[32mxxx\033[0m'
    assert stringc('xxx', 'yellow') == '\033[33mxxx\033[0m'
    assert stringc('xxx', 'red') == '\033[31mxxx\033[0m'

# Generated at 2022-06-25 12:51:45.977304
# Unit test for function hostcolor
def test_hostcolor():
    host = '127.0.0.1'
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    result = hostcolor(host, stats)
    assert result == u"%-37s" % stringc(host, C.COLOR_ERROR), 'Expected %s, but got %s' % (result, u"%-37s" % stringc(host, C.COLOR_ERROR))

# Generated at 2022-06-25 12:51:49.608377
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test_host'
    stats = {'ok': 1, 'changed': 1, 'unreachable': 0, 'skipped': 0, 'failures': 0}

    print(hostcolor(host, stats, True))


# Generated at 2022-06-25 12:51:57.345817
# Unit test for function colorize
def test_colorize():
    assert colorize('', 1, '') == "=1   "
    assert colorize('', 0, '') == "=0   "
    assert colorize('', 2, '') == "=2   "
    assert colorize('', 99, '') == "=99  "
    assert colorize('', 999, '') == "=999 "
    assert colorize('', 9999, '') == "=9999"


# Generated at 2022-06-25 12:52:04.741726
# Unit test for function stringc
def test_stringc():
    print(stringc("test test test"))
    print(stringc("test test test", C.COLOR_ERROR))
    print(stringc("test test test", "red"))


# Generated at 2022-06-25 12:52:08.431237
# Unit test for function colorize
def test_colorize():
    # Test no changes
    print("Test 1")
    test_case_0()
    # Test one change
    print("Test 2")
    test_case_0()
    # Test all changes
    print("Test 3")
    test_case_0()

# Generated at 2022-06-25 12:52:12.257248
# Unit test for function stringc
def test_stringc():
    int_0 = 1
    int_1 = 1
    str_0 = stringc('test_stringc', 'test_stringc')
    assert isinstance(str_0, str)
    assert str_0 == '\033[1mtest_stringc\033[0m'


# Generated at 2022-06-25 12:52:14.852195
# Unit test for function stringc
def test_stringc():
    global int_0
    str_0 = "test"
    str_1 = stringc(str_0, C.COLOR_SKIP)
    assert(str_1 == u"\n\033[32mtest\033[0m")

# Generated at 2022-06-25 12:52:21.610359
# Unit test for function hostcolor
def test_hostcolor():
    # Run function hostcolor with arguments:
    #   host = "localhost"
    #   stats = {u'failures': 0, u'changed': 0, u'skipped': 0, u'ok': 1, u'unreachable': 0}
    #   color = True
    # Function should return 'localhost'
    res = hostcolor("localhost", {u'failures': 0, u'changed': 0, u'skipped': 0, u'ok': 1, u'unreachable': 0}, True)
    assert res == "localhost"
    # Run function hostcolor with arguments:
    #   host = "localhost"
    #   stats = {u'failures': 0, u'changed': 0, u'skipped': 0, u'ok': 1, u'unreachable': 0}
    #   color = False
    #

# Generated at 2022-06-25 12:52:25.177643
# Unit test for function hostcolor
def test_hostcolor():
    host = "127.0.0.1"
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True

    assert hostcolor(host,stats,color) == "\x1B[32m%-37s\x1B[0m"


# Generated at 2022-06-25 12:52:28.808095
# Unit test for function hostcolor
def test_hostcolor():
    # host = 'foo'
    # stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    # assert(host == 'foo')
    # assert(stats['failures'] == 0)
    # assert(stats['unreachable'] == 0)
    # assert(stats['changed'] == 0)
    pass

# Generated at 2022-06-25 12:52:34.713351
# Unit test for function colorize
def test_colorize():
    # Mocking function parsecolor
    def mocked_parsecolor(color):
        return u'38;5;%d' % int(color)

    # Mocking function stringc
    def mocked_stringc(text, color, wrap_nonvisible_chars=False):
        color_code = mocked_parsecolor(color)
        fmt = u"\033[%sm%s\033[0m"

# Generated at 2022-06-25 12:52:41.452203
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'changed': 0, 'unreachable': 0}
    expected_result = u'%-37s' % stringc('host', C.COLOR_CHANGED)
    stats['changed'] = 1
    assert hostcolor('host', stats) == expected_result, 'Unexpected result from hostcolor '+ str(hostcolor('host', stats))
    stats['failures'] = 1
    expected_result = u'%-37s' % stringc('host', C.COLOR_ERROR)
    assert hostcolor('host', stats) == expected_result, 'Unexpected result from hostcolor '+ str(hostcolor('host', stats))
    stats['unreachable'] = 1
    expected_result = u'%-37s' % stringc('host', C.COLOR_ERROR)
    assert hostcolor('host', stats)

# Generated at 2022-06-25 12:52:51.500908
# Unit test for function stringc
def test_stringc():
    # Fixed: wrong format variable int_0
    assert stringc('stringc', 'white') == '\033[37mstringc\033[0m'
    # Fixed: wrong format variable int_0
    assert stringc('stringc', 'blue') == '\033[34mstringc\033[0m'
    # Fixed: wrong format variable int_0
    assert stringc('stringc', 'default') == '\033[39mstringc\033[0m'
    # Fixed: wrong format variable int_0
    assert stringc('stringc', 'red') == '\033[31mstringc\033[0m'
    # Fixed: wrong format variable int_0
    assert stringc('stringc', 'yellow') == '\033[33mstringc\033[0m'
    # Fixed: wrong format variable int_

# Generated at 2022-06-25 12:53:01.061095
# Unit test for function stringc
def test_stringc():

    text = '4\x0bh,y32}`U%&iOZS,3'
    color = 'color'
    var_1 = stringc(text, color)
    var_2 = stringc(text, color)
    var_3 = stringc(text, color)
    var_4 = stringc(text, color)
    var_5 = stringc(text, color)
    var_6 = stringc(text, color)

    # Output writing using the value of var_5
    var_6 = var_4 + var_5
    var_7 = var_4 + var_5
    var_8 = var_4 + var_5



# Generated at 2022-06-25 12:53:08.854796
# Unit test for function stringc
def test_stringc():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    var_0 = stringc(str_0,'red',True)
    var_1 = stringc(str_0,'red',True)
    var_2 = stringc(str_0,'rgb35',True)
    var_3 = stringc(str_0,'rgb35',True)
    print("var_0 = %s"%var_0)
    print("var_1 = %s"%var_1)
    print("var_2 = %s"%var_2)
    print("var_3 = %s"%var_3)


# Generated at 2022-06-25 12:53:10.270628
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == u'lead=num '



# Generated at 2022-06-25 12:53:14.418627
# Unit test for function stringc
def test_stringc():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    str_1 = '{RZaDt!fI9/uL7V=XM\x7f7\'3'
    var_0 = stringc(str_0, str_1)


# Generated at 2022-06-25 12:53:15.767053
# Unit test for function colorize
def test_colorize():
    print("Testing colorize...")
    test_colorize_0()
    print("Done.")

# Function to test colorize

# Generated at 2022-06-25 12:53:22.023305
# Unit test for function stringc
def test_stringc():
    # Should return a string colored with the given color code
    assert stringc(u'foobar', u'blue', True) == u'\001\033[34m\002foobar\001\033[0m\002'

    # Should work with multi-line strings
    assert stringc(u'foo\nbar', u'blue', True) == u'\001\033[34m\002foo\nbar\001\033[0m\002'

    # Should return a string without color if ANSIBLE_COLOR is false
    assert stringc(u'foobar', u'blue', False) == u'foobar'



# Generated at 2022-06-25 12:53:26.066474
# Unit test for function colorize
def test_colorize():
    print(colorize(u'foo', 0, 'red'))
    print(colorize(u'foo', 10, 'yellow'))
    print(colorize(u'foo', 100, 'green'))


# Generated at 2022-06-25 12:53:34.334774
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\x12\x01\x15%c_\x1e\x17\x10\x0c\x0e\x18\x1d'
    var_0 = hostcolor(str_0, None)
    var_0 = hostcolor(str_0, None, False)


# Generated at 2022-06-25 12:53:39.000102
# Unit test for function parsecolor
def test_parsecolor():
    fptr = open(os.environ['OUTPUT_PATH'], 'w')
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    var_0 = parsecolor(str_0)
    fptr.write(var_0)
    fptr.close()



# Generated at 2022-06-25 12:53:42.596649
# Unit test for function stringc
def test_stringc():
    input = 'hello'
    expected_result = u'\n'.join([u"\033[38;5;%dm%s\033[0m" % (C.COLOR_CODES['green'], t) for t in input.split(u'\n')])
    assert stringc(input, u'green') == expected_result

# Generated at 2022-06-25 12:53:55.167953
# Unit test for function stringc
def test_stringc():
    str_0 = 'J}2Q?(M\x0bOjO\x0b\x7f;\x0bC(V0'
    str_1 = '\x0c\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r\r'
    var_0 = stringc(str_0, str_1)
    assert var_0 is not None


# Generated at 2022-06-25 12:54:03.882400
# Unit test for function stringc
def test_stringc():
    str_0 = '\x17\x7f\x1b\x7f\x10\x07\x0f\x04\x1c'
    str_1 = '\\'
    str_2 = 'J\x14\x19\x0f\x1b\x12\x10\x0f\x17\x1f'

# Generated at 2022-06-25 12:54:16.949709
# Unit test for function stringc
def test_stringc():
    str_0 = '{x}'
    str_1 = '!3qb%nw|TpE@8}v'
    str_2 = '$I]|W8Fv$l_f}'
    str_3 = '1\x0f'
    int_0 = 0
    int_1 = 1
    int_2 = 2
    func_var_0 = stringc(str_0, u'color7', True)
    func_var_1 = stringc(str_1, u'red', True)
    func_var_2 = stringc(str_2, u'white', True)
    func_var_3 = stringc(str_3, u'yellow', True)
    func_var_4 = stringc(str_0, u'color7', True)
    func_var

# Generated at 2022-06-25 12:54:22.112401
# Unit test for function colorize
def test_colorize():
    test_str = u"string"
    test_num = 3
    test_color = u"red"
    test_ans = u"string=3   "
    test_ans = stringc(test_ans, test_color)
    assert colorize(test_str, test_num, test_color) == test_ans

# Generated at 2022-06-25 12:54:25.828553
# Unit test for function stringc
def test_stringc():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    color = 'white'
    wrap_nonvisible_chars = True
    var_0 = stringc(str_0, color, wrap_nonvisible_chars)


# Generated at 2022-06-25 12:54:33.682984
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    num_0 = -1
    str_1 = '9>|20<6'
    str_2 = ';\x00&4\x02y.\x1c\x0e&\x19'
    str_3 = '=  4'
    var_0 = {u'retries': 0, u'ok': 0, u'failed': True, u'unreachable': 0, u'changed': 0}
    var_1 = hostcolor(str_0, var_0, color=False)
    var_2 = hostcolor(str_1, var_0, color=True)
    var_3 = hostcolor(str_2, var_0, color=True)
    var_4

# Generated at 2022-06-25 12:54:44.509929
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    var_0 = hostcolor('gqvL>]$JwHf+', {'failed': 0},
                      True)
    var_1 = hostcolor('n|r^]N1FwYH', {'failed': 1, 'changed': 1,
                      'unreachable': 1, 'skipped': 1}, True)
    var_2 = hostcolor('*P7QbvA8uR7V', {'failed': 0, 'changed': 0,
                      'unreachable': 0, 'skipped': 0}, False)

# Generated at 2022-06-25 12:54:45.608764
# Unit test for function colorize
def test_colorize():
    assert colorize(u'', 0, None) == u'=0   '



# Generated at 2022-06-25 12:54:52.042106
# Unit test for function stringc
def test_stringc():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    var_0 = stringc(str_0, 'color32')
    if '\x1b[38;5;32m}4\x0bh,y32}`U%&iOZS,3\x1b[0m' != var_0:
        print('FAIL: expected == actual')
    str_1 = '}4\x0bh,y32}`U%&iOZS,3'
    var_1 = stringc(str_1, 'color33')
    if '\x1b[38;5;33m}4\x0bh,y32}`U%&iOZS,3\x1b[0m' != var_1:
        print

# Generated at 2022-06-25 12:54:53.691907
# Unit test for function hostcolor
def test_hostcolor():
    assert colorize("testStr", 0, "testStr") == u"testStr=0   "


# Generated at 2022-06-25 12:55:02.163066
# Unit test for function stringc
def test_stringc():
    str_0 = 'invalid color'
    var_0 = stringc(str_0, 'dark green')
    assert var_0 == "\033[32minvalid color\033[0m"


# Generated at 2022-06-25 12:55:06.219878
# Unit test for function stringc
def test_stringc():
    str_0 = '\x1f\x0e\x18\x10\x0e\x15'
    str_1 = 'Y\x1f\x1c\x04\x19\x00\x18\x00\x1d'
    var_0 = stringc(str_0, str_1)


# Generated at 2022-06-25 12:55:09.119884
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'unreachable': 1, 'skipped': 1, 'ok': 1, 'changed': 1, 'failures': 1}) == u'host                                   '


# Generated at 2022-06-25 12:55:13.029343
# Unit test for function colorize
def test_colorize():
    host = 'host1'
    stats = {
        'failures': 1,
        'unreachable': 0,
        'ok': 0,
        'skipped': 0,
        'changed': 2,
        'processed': 2}
    res = colorize(host, stats['changed'], 'green')
    assert res == u'host1=2  '


# Generated at 2022-06-25 12:55:18.254502
# Unit test for function stringc
def test_stringc():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    str_1 = '\x7f\x1c\\\x1e\x1d+\x05\x1f\x06'
    str_2 = '\x1b[38;5;14m\x1c\\\x1e\x1d+\x05\x1f\x06\x1b[0m'
    var_0 = stringc(str_1, str_0)
    assert var_0 == str_2

if __name__ == '__main__':
    test_case_0()
    test_stringc()

# Generated at 2022-06-25 12:55:25.891676
# Unit test for function hostcolor
def test_hostcolor():
    # no color
    result = hostcolor(u"127.0.0.1", {'skipped': 3, 'ok': 0, 'failures': 0, 'changed': 0, 'unreachable': 0}, False)
    assert result == "127.0.0.1                 "
    # color
    result = hostcolor(u"127.0.0.1", {'skipped': 3, 'ok': 0, 'failures': 0, 'changed': 0, 'unreachable': 0}, True)
    assert result == "127.0.0.1                 "
    # color for error
    result = hostcolor(u"127.0.0.1", {'skipped': 0, 'ok': 0, 'failures': 2, 'changed': 0, 'unreachable': 1}, True)

# Generated at 2022-06-25 12:55:31.426912
# Unit test for function stringc
def test_stringc():
    var_0 = u'foo'
    str_0 = '\x14r`kJ\x0b&y'
    str_1 = parsecolor(str_0)
    var_1 = stringc(var_0, str_0)
    print(var_1)
    print(str_1)


# Generated at 2022-06-25 12:55:41.684438
# Unit test for function stringc
def test_stringc():
    try:
        # Test parameters
        str_0 = '\r'
        str_1 = '\x0c'
        # Test function
        assert stringc(str_0, str_1) == '\r'
    except AssertionError:
        str_0 = '\r'
        str_1 = '\r'
        # Test function
        assert stringc(str_0, str_1) == '\r'

# --- end "pretty"

# -------------

if __name__ == '__main__':
    ans = [
        stringc('ok: [localhost] => {', 'green'),
        stringc('    "changed": false, ', 'green'),
        stringc('    "msg": "Hello world!"', 'green'),
        stringc('}', 'green'),
    ]
   

# Generated at 2022-06-25 12:55:49.649451
# Unit test for function colorize
def test_colorize():

    # Initialize host_run_results
    host_run_results = {u'contacted': {u'127.0.0.1': {u'changed': 0, u'invocation': {u'module_args': u'echo "Hello World"'}, u'failures': 0, u'ok': 1, u'unreachable': 0}}, u'dark': {}}

    # Initialize dark
    dark = []

    # Initialize color
    color = None

    # Initialize termcodes
    termcodes = {}

    # Initialize sum
    sum = {}

    # Initialize colorize
    colorize = {}

    # Initialize color
    color = True

    # Initialize host_results

# Generated at 2022-06-25 12:55:53.664711
# Unit test for function hostcolor
def test_hostcolor():
    host = 'example.com'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    x = hostcolor(host, stats, color)
    assert x is not None


# Generated at 2022-06-25 12:56:04.845095
# Unit test for function colorize
def test_colorize():
    # TODO : create and test your own test cases.
    test_colorize_0()


# Generated at 2022-06-25 12:56:10.415529
# Unit test for function stringc
def test_stringc():
    output = False
    color = 'bold blue underline'
    text = u'foo'

    output = stringc(text, color)

    if ANSIBLE_COLOR:
        # Make sure the color was applied
        assert u'\033[1m\033[44m\033[4mfoo\033[0m' == output
    else:
        # Make sure the color was not applied
        assert u'foo' == output

# Generated at 2022-06-25 12:56:15.735034
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = u'p7f{\x00"\x7f|G\x0f\x1aG'
    var_1 = {u'failures': 0, u'unreachable': 0, u'changed': 0}
    var_2 = False
    var_3 = hostcolor(var_0, var_1, var_2)
    print(var_3)


# Generated at 2022-06-25 12:56:27.618127
# Unit test for function hostcolor
def test_hostcolor():
    # Tests for function hostcolor with arguments
    #     host = 'servername'
    #     stats = { 'changed' : 3, 'failures' : 1, 'ok' : 5, 'unreachable' : 0 }
    #     color = True
    #     expected_output = 'servername   '
    host = 'servername'
    stats = {
        'changed': 3,
        'failures': 1,
        'ok': 5,
        'unreachable': 0,
    }
    color = True
    obj = hostcolor(host, stats, color)
    assert obj.endswith('servername')
    # Tests for function hostcolor with arguments
    #     host = 'servername'
    #     stats = { 'changed' : 3, 'failures' : 0, 'ok' :

# Generated at 2022-06-25 12:56:30.680935
# Unit test for function stringc
def test_stringc():
    text = '\x0c9\x0f\x0e\x02\x0e\\\x05N\x0d'
    color = 'rgb545'
    wrap_nonvisible_chars = True
    res = stringc(text, color, wrap_nonvisible_chars)


# Generated at 2022-06-25 12:56:37.788282
# Unit test for function hostcolor
def test_hostcolor():
    host = '}4\x0bh,y32}`U%&iOZS,3'
    stats = {
        u'changed': 0,
        u'failures': 0,
        u'ok': 133,
        u'skipped': 0,
        u'unreachable': 1,
        u'failure_percentage': 0,
        u'changed_percentage': 0,
        u'skipped_percentage': 0,
        u'unreachable_percentage': 0
    }
    color = True
    var_0 = hostcolor(host, stats, color)


# Generated at 2022-06-25 12:56:44.572350
# Unit test for function stringc
def test_stringc():
    str_0 = '\x11\x1F\t\x17\x0E\x14\x0B\x17\x1B\x03\x1E'
    var_0 = stringc(str_0, '\x26\x0B\x02\x27\x1F\x1D\t\x0E\x00\x0C', '%z!\x1D')


# Generated at 2022-06-25 12:56:53.821859
# Unit test for function hostcolor
def test_hostcolor():
    var_1 = dict()
    var_1['changed'] = 0
    var_1['failures'] = 0
    var_1['unreachable'] = 0
    var_2 = 'localhost'
    var_3 = True
    var_4 = hostcolor(var_2, var_1, var_3)
    print(var_4)
    var_1['unreachable'] = 1
    var_4 = hostcolor(var_2, var_1, var_3)
    print(var_4)
    var_1['unreachable'] = 0
    var_1['changed'] = 1
    var_4 = hostcolor(var_2, var_1, var_3)
    print(var_4)
    var_1['changed'] = 0
    var_1['failures'] = 1


# Generated at 2022-06-25 12:57:02.919202
# Unit test for function parsecolor
def test_parsecolor():
    print('\nRunning unit tests for function parsecolor')
    print('\n**** Unit Test Case 0 ********')
    test_case_0()
    print('\n***********End of test***********')

# --- end "pretty"

#
# This code is public domain - there is no license except that you must leave this header.
#
#
# THIS CODE AND INFORMATION ARE PROVIDED "AS IS" WITHOUT WARRANTY OF ANY
# KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A
# PARTICULAR PURPOSE.
#
# This is a low level RFC5424 syslog message formatting module.
# Messages can be constructed format free or with the aid of a
# SyslogFormatter instance.  Message parsing is also

# Generated at 2022-06-25 12:57:12.213639
# Unit test for function stringc
def test_stringc():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    str_1 = '|^c\x12\x1a\x1d\x14\x12\x03s\x05\x06\x01'
    bool_0 = ANSIBLE_COLOR
    int_0 = parsecolor(str_0)
    str_2 = stringc(str_1, str_0, bool_0)
    str_3 = '\x1b[%sm%s\x1b[0m' % (int_0, str_1)
    if str_2 == str_3:
        return True
    else:
        return False

# Generated at 2022-06-25 12:57:34.355709
# Unit test for function hostcolor
def test_hostcolor():
    # hostcolor([string, string, boolean])
    assert test_hostcolor.__name__ == 'test_hostcolor'
    print('{0} PASSED: {1}'.format(sys.argv[0], test_hostcolor.__name__))


# Generated at 2022-06-25 12:57:43.486464
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('%YnVW/z5', 'red', False)
    str_1 = stringc('mRk{', 'blue', False)
    str_2 = stringc('qc%yB9H#', 'green', False)
    str_3 = stringc('TQo-', 'yellow', False)
    str_4 = stringc('>Jh#', 'magenta', False)
    str_5 = stringc('J"Q', 'cyan', False)
    str_6 = stringc('`', 'white', False)
    str_7 = stringc('x', 'black', False)
    str_8 = stringc('', 'color0', False)
    str_9 = stringc('', 'color1', False)

# Generated at 2022-06-25 12:57:54.964726
# Unit test for function stringc
def test_stringc():
    str = '\x1b[34m'
    str_1 = ""
    var_0 = stringc(str_1, str)
    var_1 = u'\x1b[34m'
    var_2 = assertEqual(var_0, var_1)
    str_2 = '\x1b[34m\x1b[34m'
    var_3 = stringc(str_2, str)
    var_4 = u'\x1b[34m\x1b[34m'
    var_5 = assertEqual(var_3, var_4)
    str_3 = '\x1b[34m'
    str_4 = '\x1b[34m'
    var_6 = stringc(str_4, str_3)

# Generated at 2022-06-25 12:58:03.601870
# Unit test for function stringc

# Generated at 2022-06-25 12:58:11.324701
# Unit test for function stringc
def test_stringc():
    str_1 = 'color0'
    var_1 = stringc(str_1, 'color0')
    assert var_1 == u"\033[38;5;0mcolor0\033[0m"
    str_2 = 'rgb111'
    var_2 = stringc(str_2, 'rgb111')
    assert var_2 == u"\033[38;5;2mrgb111\033[0m"
    str_3 = 'gray1'
    var_3 = stringc(str_3, 'gray1')
    assert var_3 == u"\033[38;5;238mgray1\033[0m"


# Generated at 2022-06-25 12:58:15.791773
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo'
    stats = {
        'changed': 0,
        'dark': 0,
        'failures': 0,
        'ok': 1,
        'processed': 1,
        'rescued': 0,
        'skipped': 0,
        'unreachable': 0,
        'failures': 0,
    }
    assert hostcolor(host, stats, True) == '\x1b[0;32m%-37s\x1b[0m' % host


# Generated at 2022-06-25 12:58:25.010619
# Unit test for function stringc
def test_stringc():
    # Test without colors
    str_0 = '#r\x1c|&\x0bV\x00'
    str_1 = stringc(str_0, None, True)
    # Test with colors
    str_2 = '0\x1d\x1b@0\x1d\x1b@'
    str_3 = stringc(str_2, None, True)


# Generated at 2022-06-25 12:58:34.417515
# Unit test for function stringc
def test_stringc():
    str_0 = '\x1c8\v`ZU'
    str_1 = 'G'
    str_2 = 'c'
    str_3 = 'E\x1a\x1a\x1c_\x0c\x19\x7f'
    str_4 = 'E\x1a\x1a\x1c_\x0c\x19\x7f'
    str_5 = 'E\x1a\x1a\x1c_\x0c\x19\x7f'
    str_6 = 'E\x1a\x1a\x1c_\x0c\x19\x7f'

# Generated at 2022-06-25 12:58:36.220557
# Unit test for function parsecolor
def test_parsecolor():
    #assert test_case_0() == C.COLOR_CODES['str_0']
    pass


# Generated at 2022-06-25 12:58:45.456499
# Unit test for function stringc
def test_stringc():
    assert 's' == stringc('s', 'l')
    assert '\r' == stringc('\r', 'black')
    assert ' ' == stringc(' ', 'black', True)
    assert ' ' == stringc(' ', 'black', False)
    assert '\001\033[' == stringc('', 'black', True)
    assert '\002\033[' == stringc('', 'black', True)
    assert '\001\033[' == stringc('', 'black', True)
    assert '\002\033[' == stringc('', 'black', True)
    assert '\001\033[38;5;232m\002\n\001\033[' == stringc('\n', 'black', True)

# Generated at 2022-06-25 12:59:11.797055
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    # Call parsecolor to test if str_0 is a valid color name.
    # If not, parsecolor will return an ANSI escape sequence for that color name
    # and assign it to var_0.
    # If so, parsecolor returns None and we print and error message.
    var_0 = parsecolor(str_0)
    if var_0 == None:
        print("Invalid color name test failed")
        return
    str_1 = 'blue'
    # Call parsecolor to test if str_1 is a valid color name.
    # If not, parsecolor will return an ANSI escape sequence for that color name
    # and assign it to var_1.
    # If so, parsecolor

# Generated at 2022-06-25 12:59:18.454216
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    str_1 = 'n'
    str_2 = ';/\x5czxS^$/25\x1d'
    str_3 = '[4\x1f'
    dict_0 = {str_1: str_2, str_3: str_3}
    var_0 = hostcolor(str_0, dict_0)



# Generated at 2022-06-25 12:59:22.223184
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\x1b[31mTEST_HOST\x1b[0m'
    var_0 = hostcolor('TEST_HOST', {'unreachable': 1, 'failures': 1}, True)
    assert var_0 == str_0


# Generated at 2022-06-25 12:59:26.077234
# Unit test for function hostcolor
def test_hostcolor():
    host = 'p5y5h'
    stats = {'changed': 0, 'failures': 0, 'skipped': 0, 'ok': 0, 'unreachable': 0}
    color = True
    retval = hostcolor(host, stats, color)
    assert(type(retval) == type(u""))


# Generated at 2022-06-25 12:59:36.029404
# Unit test for function stringc

# Generated at 2022-06-25 12:59:41.867540
# Unit test for function stringc
def test_stringc():
    str_1 = '}4\x0bh,y32}`U%&iOZS,3'
    str_2 = '\xfc\x93\xc5'
    var_1 = stringc(str_1, str_2)
    assert var_1 == u'\n'.join([u"\033[38;5;16m\xfc\x93\xc5\033[0m" for t in str_1.split(u'\n')])


# Generated at 2022-06-25 12:59:51.367022
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'a.example.com', dict(failures=1, unreachable=0, changed=0)) == u'a.example.com        '
    assert hostcolor(u'a.example.com', dict(failures=0, unreachable=1, changed=0)) == u'a.example.com        '
    assert hostcolor(u'a.example.com', dict(failures=0, unreachable=0, changed=1)) == u'a.example.com        '
    assert hostcolor(u'a.example.com', dict(failures=0, unreachable=0, changed=0)) == u'a.example.com        '
    assert hostcolor(u'a.example.com', dict(failures=1, unreachable=0, changed=1)) == u'a.example.com        '

# Generated at 2022-06-25 12:59:55.520335
# Unit test for function colorize
def test_colorize():
    str_0 = '}4\x0bh,y32}`U%&iOZS,3'
    var_0 = colorize('a', 'b', 'c')
    var_1 = colorize('d', 'e', 'f')
    var_2 = colorize('g', 'h', 'i')


# Generated at 2022-06-25 13:00:02.557045
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '}\x1f\x10\x19\x0cT\x00\x1d\x1d\x18\x0e\x05t'
    str_1 = 'n\x0c\x1f\x17\x0f\x13\x0b\x1dt\x1a\x1f\x1c\x0b\x1e'
    var_1 = hostcolor(str_0, str_1)


# Generated at 2022-06-25 13:00:12.099877
# Unit test for function hostcolor
def test_hostcolor():
    assert u'%-26s' == hostcolor('localhost', {'changed': 0, 'unreachable': 0, 'failures': 0}, True)
    assert u'%-26s' == hostcolor('localhost', {'changed': 0, 'unreachable': 0, 'failures': 0}, False)
    assert u'%-37s' == hostcolor('localhost', {'changed': 1, 'unreachable': 0, 'failures': 0}, True)
    assert u'%-37s' == hostcolor('localhost', {'changed': 1, 'unreachable': 0, 'failures': 0}, False)
    assert u'%-37s' == hostcolor('localhost', {'changed': 0, 'unreachable': 1, 'failures': 0}, True)