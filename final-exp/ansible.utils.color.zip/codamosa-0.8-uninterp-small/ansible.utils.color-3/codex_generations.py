

# Generated at 2022-06-25 12:50:23.252885
# Unit test for function hostcolor
def test_hostcolor():
    # Test 1
    host = 'localhost'
    stats = {'ok': 2, 'changed': 2, 'failures': 0, 'skipped': 0, 'unreachable': 0}
    color = True
    expected = u'localhost                           '.encode('utf-8')
    result = hostcolor(host, stats, color)
    assert result == expected


# Generated at 2022-06-25 12:50:29.474403
# Unit test for function hostcolor
def test_hostcolor():
    bool_0 = False
    param_0 = u"foo.example.com"
    # prepare the test environment
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    # call the function to be tested
    actual_0 = hostcolor(param_0,stats, bool_0)
    # We expect the output to be:
    expected_0 = u"foo.example.com"
    # Verify if the function worked as expected
    if actual_0 == expected_0:
        print("test_hostcolor: PASS")
        return True
    else:
        print("test_hostcolor: FAIL")
        return False


# Generated at 2022-06-25 12:50:32.118287
# Unit test for function stringc
def test_stringc():
    try:
        text = 'Text for Unit Test'
        color = 'cyan'
        wrap_nonvisible_chars = False
        result = stringc(text, color, wrap_nonvisible_chars)
    except:
        raise


# Generated at 2022-06-25 12:50:33.170553
# Unit test for function stringc
def test_stringc():
    print(stringc('Hello', 'blue'))



# Generated at 2022-06-25 12:50:35.429658
# Unit test for function stringc
def test_stringc():
    text = u"This is a test."
    color = C.COLOR_ERROR
    try:
        stringc(text, color)
    except:
        print(u"function stringc called with bad arguments")



# Generated at 2022-06-25 12:50:41.584347
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('localhost', {'failures': 0, 'changed': 0, 'unreachable': 0}, True))
    print(hostcolor('localhost', {'failures': 0, 'changed': 0, 'unreachable': 1}, True))
    print(hostcolor('localhost', {'failures': 0, 'changed': 1, 'unreachable': 0}, True))
    print(hostcolor('localhost', {'failures': 1, 'changed': 0, 'unreachable': 0}, True))
    print(hostcolor('localhost', {'failures': 1, 'changed': 0, 'unreachable': 0}, False))


# Generated at 2022-06-25 12:50:50.538703
# Unit test for function colorize
def test_colorize():
    print('Test colorize:')
    var_0 = colorize(0, 0, 0)
    print(var_0)
    var_1 = colorize(0.0, 0.0, 0.0)
    print(var_1)
    var_2 = colorize(0, 0, 0)
    print(var_2)
    var_3 = colorize(0.0, 0.0, 0.0)
    print(var_3)
    var_4 = colorize(0, 0, 0)
    print(var_4)
    var_5 = colorize(0.0, 0.0, 0.0)
    print(var_5)
    var_6 = colorize(0, 0, 0)
    print(var_6)

# Generated at 2022-06-25 12:50:53.409351
# Unit test for function parsecolor
def test_parsecolor():
    #if hasattr(ANSIBLE_COLOR, '__call__'):
    if callable(ANSIBLE_COLOR):
        try:
            parsecolor(ANSIBLE_COLOR())
        except TypeError:
            pass
        else:
            raise AssertionError



# Generated at 2022-06-25 12:50:55.854941
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    expected = u'localhost                     '
    actual = hostcolor(host, stats, color)
    assert actual == expected


# Generated at 2022-06-25 12:50:56.771454
# Unit test for function parsecolor
def test_parsecolor():
    print(u"Testing function parsecolor")
    test_case_0()



# Generated at 2022-06-25 12:51:15.982646
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'This is a test.'
    result_0 = parsecolor('yellow')
    result_1 = parsecolor('fuschia')
    result_2 = parsecolor('turquoise')
    result_3 = parsecolor('7')
    result_4 = parsecolor('rgb565')
    result_5 = parsecolor('rgb332')
    result_6 = parsecolor('rgb100')
    result_7 = parsecolor('gray0')
    result_8 = parsecolor('gray1')
    result_9 = parsecolor('gray2')
    result_10 = parsecolor('gray0')
    result_11 = parsecolor('gray1')
    result_12 = parsecolor('gray2')
    result_13 = parsecolor('gray10')

   

# Generated at 2022-06-25 12:51:19.094691
# Unit test for function parsecolor
def test_parsecolor():
    prg1 = parsecolor('color2')
    if prg1 != "38;5;2":
        print("returned: ", prg1, "expected:", "38;5;2" )


# Generated at 2022-06-25 12:51:29.916966
# Unit test for function hostcolor
def test_hostcolor():

    # assert the funciton works
    # assert stats['failures'] == 0 and stats['unreachable'] == 0, then the host should be in color
    # assert stats['failures'] != 0 or stats['unreachable'] != 0, then the host should be in color
    # assert stats['changed'] != 0, then the host should be in color
    # assert stats['changed'] == 0 and stats['failures'] == 0 and stats['unreachable'] == 0, then the host should be in color
    # assert ANSIBLE_COLOR is False, then the host should not be in color
    stats = dict()
    stats = dict()
    stats['failures'] = 0
    stats['unreachable'] = 0

# Generated at 2022-06-25 12:51:38.119184
# Unit test for function hostcolor
def test_hostcolor():
    host = 'a host'
    stats = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    color = True
    print(hostcolor(host, stats, color))

if __name__ == '__main__':
    from args import parser
    OPTIONS = parser.parse_args()
    if OPTIONS.color:
        if OPTIONS.color == 'on':
            ANSIBLE_COLOR = True
        elif OPTIONS.color == 'off':
            ANSIBLE_COLOR = False
        elif OPTIONS.color == 'tty':
            ANSIBLE_COLOR = not not hasattr(sys.stdout, 'isatty') and sys.stdout.isatty()
        elif OPTIONS.color == 'yes':
            ANSIBLE

# Generated at 2022-06-25 12:51:41.607188
# Unit test for function stringc
def test_stringc():
    print(stringc('This is a test.', 'red'))

# --- end "pretty.py"



# Generated at 2022-06-25 12:51:52.094901
# Unit test for function parsecolor

# Generated at 2022-06-25 12:51:55.075576
# Unit test for function stringc
def test_stringc():
    text_1 = 'test_stringc'
    color_1 = 'test_stringc'
    ansible_test_0 = stringc(text_1, color_1)


# Generated at 2022-06-25 12:51:59.561330
# Unit test for function colorize
def test_colorize():
    print('Start testing colorize')
    lead = '123'
    num = 0
    color = 'green'
    s = colorize(lead, num, color)
    print(s)
    num = 1
    s = colorize(lead, num, color)
    print(s)
    num = 2
    s = colorize(lead, num, color)
    print(s)


# Generated at 2022-06-25 12:52:02.009609
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'test_host'
    dict_0 = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(str_0, dict_0) == u'%-26s' % str_0


# Generated at 2022-06-25 12:52:06.868482
# Unit test for function hostcolor
def test_hostcolor():
    host = stringc('1234567890', C.COLOR_ERROR)
    stats = {'failures': 1, 'unreachable': 1, 'changed': 2, 'ok': 3}
    assert host == '1234567890'
    assert hostcolor(host, stats, color=False) == '%-26s' % host


# Generated at 2022-06-25 12:52:15.429733
# Unit test for function colorize
def test_colorize():
    str_0 = colorize(u'lead', 1, (u'color'))
    str_1 = colorize((u'lead'), 1, u'color')
    str_2 = colorize(u'lead', (1), (u'color'))
    str_3 = colorize(u'lead', 1, (u'color'))



# Generated at 2022-06-25 12:52:24.476453
# Unit test for function parsecolor
def test_parsecolor():
    err = 0

    if not parsecolor('red') == '31':
        err += 1
    if not parsecolor('bright red') == '31':
        err += 1
    if not parsecolor('blue') == '34':
        err += 1
    if not parsecolor('bright blue') == '94':
        err += 1
    if not parsecolor('white') == '37':
        err += 1
    if not parsecolor('bright white') == '97':
        err += 1
    if not parsecolor('color0') == '38;5;0':
        err += 1
    if not parsecolor('color12') == '38;5;12':
        err += 1
    if not parsecolor('color255') == '38;5;255':
        err += 1

# Generated at 2022-06-25 12:52:31.809951
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        stringc_0 = stringc('This is a test.', 'green')
        assert stringc_0 == '\x1b[32mThis is a test.\x1b[0m'
        stringc_1 = stringc('This is a test.', 'red', True)
        assert stringc_1 == '\x01\x1b[31m\x02This is a test.\x01\x1b[0m\x02'
    else:
        stringc_2 = stringc('This is a test.', 'green')
        assert stringc_2 == 'This is a test.'
        stringc_3 = stringc('This is a test.', 'red', True)
        assert stringc_3 == 'This is a test.'


# Generated at 2022-06-25 12:52:34.767560
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('This is a test.', 'green') == '\033[32mThis is a test.\033[0m'
    else:
        assert stringc('This is a test.', 'green') == 'This is a test.'


# Generated at 2022-06-25 12:52:41.451077
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'This is a test.'
    str_1 = 'This is a test.'
    str_2 = 'This is a test.'
    str_3 = 'This is a test.'
    str_4 = 'This is a test.'
    str_5 = 'This is a test.'
    str_6 = 'This is a test.'
    str_7 = 'This is a test.'
    str_8 = 'This is a test.'
    str_9 = 'This is a test.'
    str_10 = 'This is a test.'
    str_11 = 'This is a test.'
    str_12 = 'This is a test.'
    str_13 = 'This is a test.'
    str_14 = 'This is a test.'
    str_15 = 'This is a test.'

# Generated at 2022-06-25 12:52:51.459731
# Unit test for function hostcolor
def test_hostcolor():
    check_0 = u"%-37s" % stringc('test_0', C.COLOR_ERROR)
    check_1 = u"%-37s" % stringc('test_1', C.COLOR_CHANGED)
    check_2 = u"%-37s" % stringc('test_2', C.COLOR_OK)

    if hostcolor('test_0', {'failures': 1, 'unreachable': 1, 'changed': 1}):
        print(check_0)
    if hostcolor('test_1', {'failures': 0, 'unreachable': 0, 'changed': 1}):
        print(check_1)
    if hostcolor('test_2', {'failures': 0, 'unreachable': 0, 'changed': 0}):
        print(check_2)


# Generated at 2022-06-25 12:53:00.239804
# Unit test for function stringc
def test_stringc():
    assert stringc('This is a test.','blue')=='\x1b[34mThis is a test.\x1b[0m'
    print(stringc('This is a test.','blue'))
    print(stringc('This is a test.','blue',wrap_nonvisible_chars=True))
    print(stringc('This is a test.','color5'))
    print(stringc('This is a test.','rgb240'))
    print(stringc('This is a test.','rgb135'))
    print(stringc('This is a test.','rgb234'))
    print(stringc('This is a test.','rgb235'))
    print(stringc('This is a test.','rgb236'))

# Generated at 2022-06-25 12:53:03.102253
# Unit test for function stringc
def test_stringc():
    str_0 = u'\n'.join([u"\033[38;5;12m%s\033[0m" % t for t in u"This is a test.".split(u'\n')])
    assert stringc("This is a test.", 'color12', False) == str_0


# Generated at 2022-06-25 12:53:07.293762
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("color28") == "38;5;28"
    assert parsecolor("rgb123") == "38;5;37"
    assert parsecolor("gray8") == "38;5;240"
    assert parsecolor("black") == "30"


# Generated at 2022-06-25 12:53:13.472072
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    str_1 = stringc(str_0, 'blue')
    str_2 = stringc(str_0, 'rgb000')
    str_3 = stringc(str_0, 'color11')
    str_4 = stringc(str_0, 'gray1')
    str_5 = stringc(str_0, 'green')
    str_6 = stringc(str_0, 'red')
    str_7 = stringc(str_0, 'yellow')

    test_case_0()



# Generated at 2022-06-25 12:53:20.699583
# Unit test for function colorize
def test_colorize():
    assert(colorize('TEST', 42, 'blue') == 'TEST=42  \033[34m\033[0m ')

if __name__ == '__main__':
    test_case_0()
    test_colorize()

# Generated at 2022-06-25 12:53:23.505176
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    str_1 = stringc(str_0, 'green')
    assert str_1 == '\033[32mThis is a test.\033[0m'


# Generated at 2022-06-25 12:53:34.320561
# Unit test for function hostcolor
def test_hostcolor():
    """Test hostcolor with these inputs:
    arg1: 'test-server.example.com'
    arg2: {'failures': 0, 'changed': 0, 'ok': 4, 'dark': 2, 'skipped': 0, 'unreachable': 0}
    """
    assert hostcolor('test-server.example.com', {'failures': 0, 'changed': 0, 'ok': 4, 'dark': 2, 'skipped': 0, 'unreachable': 0}) == 'test-server.example.com'
    assert hostcolor('test-server.example.com', {'failures': 1, 'changed': 0, 'ok': 4, 'dark': 2, 'skipped': 0, 'unreachable': 0}) == 'test-server.example.com'


if __name__ == '__main__':
    test

# Generated at 2022-06-25 12:53:38.025184
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test'
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u'\033[31m-40s\033[0m'


# Generated at 2022-06-25 12:53:41.135834
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    str_1 = stringc(str_0)
    str_2 = stringc(str_0, 'red')
    assert str_2 == '\033[31mThis is a test.\033[0m'


# Generated at 2022-06-25 12:53:50.315560
# Unit test for function hostcolor
def test_hostcolor():

    color=True

    host = 'somehost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    string = hostcolor( host, stats, color)
    assert string =="%-37s" % stringc(host, C.COLOR_OK)

    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
    string = hostcolor( host, stats, color)
    assert string =="%-37s" % stringc(host, C.COLOR_CHANGED)

    stats = {'failures': 0, 'unreachable': 1, 'changed': 1}
    string = hostcolor( host, stats, color)
    assert string =="%-37s" % stringc(host, C.COLOR_ERROR)


# Generated at 2022-06-25 12:53:57.252846
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    result_0 = stringc(str_0, 'red')
    str_1 = 'This is a test.'
    result_1 = stringc(str_1, 'test')
    str_2 = 'This is a test.'
    result_2 = stringc(str_2, 'green')
    str_3 = 'This is a test.'
    result_3 = stringc(str_3, 'green')


# Generated at 2022-06-25 12:53:59.113607
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    assert stringc(str_0) == str_0


# Generated at 2022-06-25 12:54:01.228652
# Unit test for function stringc
def test_stringc():
    assert stringc('This is a test.', 'green') == '\x1b[32mThis is a test.\x1b[0m'


# Generated at 2022-06-25 12:54:08.846471
# Unit test for function hostcolor
def test_hostcolor():
    host = 'example'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == (u'%-37s' % u'example')
    assert hostcolor(host, stats, False) == (u'%-26s' % host)

    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == (u'%s' % stringc('example', C.COLOR_ERROR))

    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats) == (u'%s' % stringc('example', C.COLOR_ERROR))


# Generated at 2022-06-25 12:54:14.493817
# Unit test for function stringc
def test_stringc():
    assert 'This is a test.' == stringc('This is a test.', 'blue')


# Generated at 2022-06-25 12:54:21.040874
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    str_1 = str_0
    str_2 = stringc(str_0, 'lightyellow', True)
    str_3 = '\x01\x1b[93m\x02This is a test.\x01\x1b[0m\x02'
    return str_1 == str_2 and str_2 == str_3

# Generated at 2022-06-25 12:54:22.756547
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(str_0, "test_hostcolor") == "%-37s"


# Generated at 2022-06-25 12:54:27.695683
# Unit test for function hostcolor

# Generated at 2022-06-25 12:54:34.593288
# Unit test for function colorize
def test_colorize():

    # Test 0:
    # Test normal usage
    lead = 'test'
    num = 10
    color = 'test'

    assert colorize(lead, num, color) == 'test=10  '

    # Test 1:
    # Test normal usage, with num == 0 and color == None
    lead = 'test'
    num = 0
    color = None

    assert colorize(lead, num, color) == 'test=0   '



# Generated at 2022-06-25 12:54:44.053598
# Unit test for function stringc
def test_stringc():
    # Tests a default color
    assert stringc(str_0, 'black', False) == '\n'.join(['\033[38;5;0mThis is a test.\033[0m'])
    # Tests a custom color
    assert stringc(str_0, 'white', False) == '\n'.join(['\033[38;5;255mThis is a test.\033[0m'])
    # Tests wrapping non-visible characters
    assert stringc(str_0, 'black', True) == '\n'.join(['\001\033[38;5;0m\002This is a test.\001\033[0m\002'])


# Generated at 2022-06-25 12:54:51.803591
# Unit test for function hostcolor
def test_hostcolor():
    # Test case 0
    host_0 = 'localhost'
    stats_0 = {'changed': 0, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    color_0 = True
    assert hostcolor(host_0, stats_0, color_0) == 'localhost                         '
    # Test case 1
    host_1 = 'localhost'
    stats_1 = {'changed': 1, 'failures': 0, 'ok': 2, 'skipped': 0, 'unreachable': 0}
    color_1 = True
    assert hostcolor(host_1, stats_1, color_1) == 'localhost                         '
    # Test case 2
    host_2 = 'localhost'

# Generated at 2022-06-25 12:54:52.758209
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()

# Function for running unit tests

# Generated at 2022-06-25 12:55:04.016227
# Unit test for function stringc
def test_stringc():
    assert parsecolor('red') == u'31'
    assert parsecolor('RED') == u'31'
    assert parsecolor('rEd') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('BLUE') == u'34'
    assert parsecolor('blUe') == u'34'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('CYAN') == u'36'
    assert parsecolor('cYaN') == u'36'
    assert parsecolor('green') == u'32'
    assert parsecolor('GREEN') == u'32'
    assert parsecolor('gReEn') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor

# Generated at 2022-06-25 12:55:06.420885
# Unit test for function colorize
def test_colorize():
    lead = 'Test'
    num = 0
    color = None
    s = colorize(lead, num, color)
    print(s)
    num = 1
    color = None
    s = colorize(lead, num, color)
    print(s)


# Generated at 2022-06-25 12:55:16.670093
# Unit test for function colorize
def test_colorize():
    print(colorize('Test string: pass', 0, C.COLOR_OK))
    print(colorize('Test string: changed', 1, C.COLOR_CHANGED))
    print(colorize('Test string: unreachable', 1, C.COLOR_ERROR))
    print(hostcolor('localhost', {"unreachable": 0, "failures": 0, "ok": 2, "skipped": 0, "changed": 1}))
    print(hostcolor('localhost', {"unreachable": 1, "failures": 1, "ok": 2, "skipped": 0, "changed": 1}))
    print(hostcolor('localhost', {"unreachable": 1, "failures": 0, "ok": 2, "skipped": 0, "changed": 0}))


if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-25 12:55:19.896648
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    assert stringc(str_0, 'color0') == '\033[38;5;0mThis is a test.\033[0m'
    assert stringc(str_0, 'color0', True) == '\001\033[38;5;0m\002This is a test.\001\033[0m\002'


# Generated at 2022-06-25 12:55:24.179869
# Unit test for function hostcolor
def test_hostcolor():
    test_host = 'test_host'
    test_stats = {
        'ok'        : 0,
        'skipped'   : 0,
        'changed'   : 0,
        'unreachable': 0,
        'failures'  : 0,
    }

    str_1 = hostcolor(test_host, test_stats, True)
    return str_1


# Generated at 2022-06-25 12:55:35.736795
# Unit test for function colorize
def test_colorize():
    str_0 = 'This is a test'
    str_1 = 'This is a test.'
    str_2 = 'This is a test. '
    str_3 = 'This is a test.  '
    str_4 = 'This is a test.   '
    str_5 = 'This is a test.    '
    str_6 = 'This is a test.     '

    # Test 1
    print("Test 1-a")
    if len(str_0) == 14:
        print("Hooray!")
    else:
        print("Oops!")

    # Test 2
    print("Test 1-b")
    if len(str_1) == 15:
        print("Hooray!")
    else:
        print("Oops!")

    # Test 3

# Generated at 2022-06-25 12:55:37.820406
# Unit test for function colorize
def test_colorize():
    str_0 = 'This is a test.'
    str_colorize = colorize(str_0, 0, '000000')



# Generated at 2022-06-25 12:55:47.023617
# Unit test for function stringc
def test_stringc():
    print('Testing function stringc')
    str_0 = 'This is a test.'
    print(stringc(str_0, 'red'))
    print(stringc(str_0, 'rgb500005', True))
    print(stringc(str_0, 'rgb333005', True))
    print(stringc(str_0, 'rgb050335', True))
    print(stringc(str_0, 'rgb053033', True))
    print(stringc(str_0, 'rgb053333', True))
    print(stringc(str_0, 'rgb033305', True))
    print(stringc(str_0, 'rgb050003', True))
    print(stringc(str_0, 'rgb030300', True))

# Generated at 2022-06-25 12:55:53.162857
# Unit test for function hostcolor
def test_hostcolor():
    test_hosts = {'test.test':{'ok':1}, 'test.test.net':{'changed':1}, 'test.test.com':{'unreachable':1, 'failures':1}}
    for test_host in test_hosts:
        #print(hostcolor(test_host, test_hosts[test_host]))
        hostcolor(test_host, test_hosts[test_host])


# Generated at 2022-06-25 12:55:56.009730
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    str_1 = parsecolor('yellow')
    assert str_1 == u'38;5;11'
    str_2 = stringc(str_0, 'yellow')
    assert str_2 == u'\x1b[38;5;11mThis is a test.\x1b[0m'


# Generated at 2022-06-25 12:55:58.124346
# Unit test for function hostcolor
def test_hostcolor():
    test_str = 'localhost'
    color = C.COLOR_OK
    stats = {'changed':0, 'skipped':0, 'unreachable':0, 'failures':0}
    print(hostcolor(test_str, stats, color=True))


# Generated at 2022-06-25 12:56:00.457520
# Unit test for function colorize
def test_colorize():
    ret = colorize("TEST", 0, "TEST")
    if ret == u"TEST=0   ":
        print("OK")
    else:
        print("FAILED")
        print("Expected: %s" % "TEST=0   ")
        print("Recieved: %s" % ret)
        print("", file=sys.stderr)



# Generated at 2022-06-25 12:56:06.029032
# Unit test for function stringc
def test_stringc():
    stringc(str_0, 'green')


# Generated at 2022-06-25 12:56:10.670728
# Unit test for function stringc
def test_stringc():
    print()
    print(stringc("This is a test.", "yellow"))
    print(stringc("This is a test.", "32"))
    print(stringc("This is a test.", "rgb200"))
    print(stringc("This is a test.", "13"))
    print(stringc("This is a test.", "rgb321"))


# Generated at 2022-06-25 12:56:21.143390
# Unit test for function colorize
def test_colorize():
    list_0 = [True, 'red', 'blue', True, False, True, 'green', 'yellow']
    num_0 = 1
    list_1 = [True, 'red', 'blue', True, False, True, 'green', 'yellow']
    num_1 = 3
    list_2 = [True, 'red', 'blue', True, False, True, 'green', 'yellow']
    num_2 = 2
    list_3 = [True, 'red', 'blue', True, False, True, 'green', 'yellow']
    num_3 = 0

# Generated at 2022-06-25 12:56:28.995883
# Unit test for function stringc
def test_stringc():

    # Strings
    print()
    print(stringc('This is a test.', 'red', wrap_nonvisible_chars=True))
    print(stringc('This is a test.', 'red', wrap_nonvisible_chars=False))
    print(stringc('This is a test.', 'yellow', wrap_nonvisible_chars=True))
    print(stringc('This is a test.', 'yellow', wrap_nonvisible_chars=False))
    print(stringc('This is a test.', 'blue', wrap_nonvisible_chars=True))
    print(stringc('This is a test.', 'blue', wrap_nonvisible_chars=False))
    print(stringc('This is a test.', 'cyan', wrap_nonvisible_chars=True))

# Generated at 2022-06-25 12:56:31.273021
# Unit test for function stringc
def test_stringc():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'


# Generated at 2022-06-25 12:56:41.696652
# Unit test for function stringc
def test_stringc():
    # An "uncolored" message
    msg_uncolored = 'This is a test.'
    # A message with both the foreground and background color specified
    msg_color_foreground_background = 'Foreground_background test.'
    # A message with the foreground color specified
    msg_color_foreground = 'Foreground test'
    # A message that should be left uncolored
    msg_uncolored_again = 'Another test'
    # Message to test the wrapping of non-visible characters
    msg_nonvisible_chars_wrapped = 'wrap_nonvisible_chars test'

    # Make sure the message without color settings is left alone
    assert stringc(msg_uncolored, '') == msg_uncolored

    # Test the foreground_background color

# Generated at 2022-06-25 12:56:51.934315
# Unit test for function stringc
def test_stringc():
    global debug_mode
    debug_mode=True

    # Test 0 - basic test of getting the color code for red, green,
    # and blue.
    test_case_0()

    # Test 1 - basic test
    global str_1
    ret_1 = stringc("This is a test.", "red")
    str_1=str("\033[%sm%s\033[0m" % (C.COLOR_CODES['red'], "This is a test."))
    if (ret_1==str_1):
        str_rslt = "PASS"
    else:
        str_rslt = "FAIL"
    print("Test 1 - Basic Test - %s" % str_rslt)

    # Test 2 - Test that coloring a line that contains multiple lines
    # works.
    global str_2


# Generated at 2022-06-25 12:56:56.076316
# Unit test for function colorize
def test_colorize():
	str_0 = colorize('lead', 'num', 'color')
	assert str_0 == 'lead=num', "Error in assert 0.\n" 



# Generated at 2022-06-25 12:57:00.856829
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test.'
    str_1 = 'This is a test.'
    str_2 = 'This is a test.'
    str_3 = 'This is a test.'
    str_4 = 'This is a test.'
    str_5 = 'This is a test.'
    str_6 = 'This is a test.'
    str_7 = 'This is a test.'
    str_8 = 'This is a test.'

    assert(str_1 == stringc(str_0, 'black'))
    assert(str_2 == stringc(str_0, 'red'))
    assert(str_3 == stringc(str_0, 'green'))
    assert(str_4 == stringc(str_0, 'yellow'))

# Generated at 2022-06-25 12:57:05.592306
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils import hostcolor
    host = 'test_host'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color = True) == 'test_host               '


# Generated at 2022-06-25 12:57:11.640631
# Unit test for function stringc
def test_stringc():
    assert stringc('This is a test.', 'red') == u'\x1b[31mThis is a test.\x1b[0m'


# Generated at 2022-06-25 12:57:20.945366
# Unit test for function hostcolor
def test_hostcolor():
    host = "test_host"
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    assert hostcolor(host, stats, color) == u"test_host                 "
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    color = True
    assert hostcolor(host, stats, color) == u"\x1b[91mtest_host               \x1b[0m"
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    color = True
    assert hostcolor(host, stats, color) == u"\x1b[91mtest_host               \x1b[0m"

# Generated at 2022-06-25 12:57:28.369355
# Unit test for function colorize
def test_colorize():
    # Test case 0
    test_str = 'This is a test.'
    if stringc(test_str, 'normal') != stringc(test_str, 'normal'):
        print('Test case 0 failed.')
        return
    print('Test case 0 passed.')

    # Test case 1
    test_str = 'This is a test.'
    if stringc(test_str, 'red', True) != stringc(test_str, 'red', True):
        print('Test case 1 failed.')
        return
    print('Test case 1 passed.')



# Generated at 2022-06-25 12:57:33.467540
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('test', [0, 0, 0, 0, 0]) == 'test                          '
    assert hostcolor('test', [0, 1, 0, 0, 0]) == 'test                          '
    assert hostcolor('test', [1, 0, 0, 0, 0]) == 'test                          '
    assert hostcolor('test', [0, 0, 1, 0, 0]) == 'test                          '


# Generated at 2022-06-25 12:57:38.630185
# Unit test for function colorize
def test_colorize():
    lead = 'TEST'
    num = 0
    color = 'blue'
    expected = stringc(u"%s=%-4s" % (lead, str(num)), color)
    ret = colorize(lead, num, color)
    assert ret == expected, "Expected: %s\nGot: %s" % (expected, ret)


# Generated at 2022-06-25 12:57:40.473164
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'failures':0, 'unreachable':0, 'changed':0}) == 'host'


# Generated at 2022-06-25 12:57:41.967406
# Unit test for function hostcolor
def test_hostcolor():
    # test cases
    test_case_0()
    # check
    assert(True)


# --- end "pretty"

# Generated at 2022-06-25 12:57:44.571079
# Unit test for function hostcolor
def test_hostcolor():
    # This test passes.
    assert hostcolor('192.168.0.1', {'changed': 0, 'failures': 0, 'unreachable': 1}, True) == '\u001b[0;31m192.168.0.1\u001b[0m   '

# Generated at 2022-06-25 12:57:48.685761
# Unit test for function colorize
def test_colorize():
    print('-' * 60)
    print('Test case 0')
    print(colorize('This is a test.', 'red'))
    print('-' * 60)

if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-25 12:57:59.512230
# Unit test for function hostcolor
def test_hostcolor():
    b = u"host.example.com"
    stats = {
        "changed": 0,
        "failures": 0,
        "skipped": 0,
        "ok": 1,
        "processed": 1,
        "rescued": 0,
        "unreachable": 0,
        "warnings": 0
    }

    result = hostcolor(b, stats, True)
    assert result == u"host.example.com"

if __name__ == "__main__":
    args = sys.argv
    if len(args) == 2 and args[1] == "-t":
        test_case_0()
        test_hostcolor()
        sys.exit()

# This is a simple demo function for the pretty module. Note that the
# module itself does not print anything, it just returns a string.

# Generated at 2022-06-25 12:58:06.521911
# Unit test for function stringc
def test_stringc():
    # str_0 = 'This is a test.'
    # str_1 = 'This is a test.'
    # ret_2 = stringc(str_0, str_1)
    pass


# Generated at 2022-06-25 12:58:08.892908
# Unit test for function stringc
def test_stringc():
    assert(stringc('This is a test.', 'blue') == '\x1b[38;5;4mThis is a test.\x1b[0m')


# Generated at 2022-06-25 12:58:12.813679
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'test_host'
    str_1 = '[{changed=0, failures=0, unreachable=0, skipped=0, ok=1}]'
    assert hostcolor(str_0, str_1) == 'test_host[{changed=0, failures=0, unreachable=0, skipped=0, ok=1}]'


# Generated at 2022-06-25 12:58:20.252882
# Unit test for function colorize
def test_colorize():
    str_0 = 'This is a test'
    str_1 = 'This is a test'
    str_2 = 'This is a test'
    str_3 = 'This is a test'
    str_4 = 'This is a test'
    result = colorize(str_0, str_1, str_2)
    assert result == str_3
    print(result)
    result = colorize(str_0, str_1, str_2)
    assert result == str_4
    print(result)


# Generated at 2022-06-25 12:58:23.402566
# Unit test for function stringc
def test_stringc():
    assert stringc('This is a test.', 'lightgreen', False) == u"\n".join([u"\033[38;5;154mThis is a test.\033[0m"])

test_case_0()



# Generated at 2022-06-25 12:58:26.174137
# Unit test for function colorize
def test_colorize():
    l = 'test lead'
    num = 'test value'
    c = 'test color'
    # 1
    assert colorize(l,num,c) == u"test lead=test value"


# Generated at 2022-06-25 12:58:30.694459
# Unit test for function hostcolor
def test_hostcolor():
    str_hostcolor = "Random-host"
    stats = {'ok': 200, 'changed': 0, 'unreachable': 0, 'skipped': 0}
    str_ret = hostcolor(str_hostcolor, stats, True)
    print(str_ret)

# Generated at 2022-06-25 12:58:34.083223
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('10.1.1.1', 'stats', 'True') == '10.1.1.1'


# Generated at 2022-06-25 12:58:35.907151
# Unit test for function hostcolor
def test_hostcolor():
    print(test_case_0())
    hostcolor()

# Colorize failure message

# Generated at 2022-06-25 12:58:38.599134
# Unit test for function stringc
def test_stringc():

    assert(stringc('This is a test.', 'blue') == '\x1b[34mThis is a test.\x1b[0m')



# Generated at 2022-06-25 12:58:46.854842
# Unit test for function stringc
def test_stringc():
    assert stringc(bool_0, var_0) == u'\n'
    assert stringc(bool_0, var_0) == u'\n'

if __name__ == '__main__':
    if not test_case_0():
        print('0 failed')
    else:
        print('0 passed')
    # Unit test for function stringc
    test_stringc()

# Generated at 2022-06-25 12:58:58.215721
# Unit test for function colorize
def test_colorize():
    assert colorize('pcpc', 5, None) == 'pcpc=5   '
    assert colorize('pcpc', 5, 'dark gray') == 'pcpc=5   '
    assert colorize('pcpc', 5, 'dark grey') == 'pcpc=5   '
    #assert colorize('pcpc', 5, 'dark red') == 'pcpc=5   '
    #assert colorize('pcpc', 5, 'light green') == 'pcpc=5   '
    assert colorize('pcpc', 5, 'dark blue') == 'pcpc=5   '
    assert colorize('pcpc', 5, 'dark magenta') == 'pcpc=5   '

# Generated at 2022-06-25 12:59:01.343885
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'changed': 0, 'dark': 0, 'failures': 0, 'ok': 0, 'processed': 0}
    color = True
    test_case_0()



# Generated at 2022-06-25 12:59:10.378319
# Unit test for function colorize
def test_colorize():
    # Fix for case of 'message' will be null when a task fails but does
    # not have any stderr.
    #if not message:
    #    message = "<no output>"

    # Figure out if the task's output implies it has changed
    if 'changed' in results._result and results._result['changed']:
        color = C.COLOR_CHANGED
    # Try to figure out if a task has failed by checking the results
    # for signs of failure.
    elif 'failed' in results._result and results._result['failed']:
        color = C.COLOR_ERROR
        #TODO: check if stdout has some values
        if results._task.action in C.MODULE_NO_JSON:
            color = None
    # If the task hasn't failed yet, check to see if the task is
    # behaving

# Generated at 2022-06-25 12:59:11.629688
# Unit test for function colorize
def test_colorize():
    assert colorize(lead="lead", num="num", color="color") == "lead=num"


# Generated at 2022-06-25 12:59:15.670288
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = 'localhost'
    var_1 = {'failures': 1, 'changed': 0, 'unreachable': 0}
    var_2 = False
    var_3 = hostcolor(var_0, var_1, var_2)


# Generated at 2022-06-25 12:59:21.612598
# Unit test for function colorize
def test_colorize():
    assert colorize(u'', 0, u'') == u'=0   '
    assert colorize(u'', 1, u'ok') == u'=1   '
    assert colorize(u'', 2, u'changed') == u'=2   '
    assert colorize(u'', 3, u'failed') == u'=3   '
    assert colorize(u'', 4, u'unreachable') == u'=4   '


# Generated at 2022-06-25 12:59:22.462913
# Unit test for function stringc
def test_stringc():
    pass


# Generated at 2022-06-25 12:59:28.669461
# Unit test for function stringc
def test_stringc():
    assert stringc(text="Test", color="Red") == "\033[31mTest\033[0m"
    assert stringc(text="Test", color="Blue") == "\033[34mTest\033[0m"
    assert stringc(text="Test", color="Green") == "\033[32mTest\033[0m"
    assert stringc(text="Test", color="Yellow") == "\033[33mTest\033[0m"

    assert (
        stringc(text="TestT", color="Blue", wrap_nonvisible_chars=True) ==
        "\001\033[34m\002TestT\001\033[0m\002"
    )



# Generated at 2022-06-25 12:59:32.016802
# Unit test for function colorize
def test_colorize():
    print(colorize(u'TEST OK', 0, u'TEST'))
    print(colorize(u'TEST ERROR', 3, u'TEST'))
    print(colorize(u'TEST CHANGED', 3, u'TEST'))



# Generated at 2022-06-25 12:59:49.749541
# Unit test for function hostcolor
def test_hostcolor():
    host_0 = 'app1'
    stats_0 = dict({'skipped': 1, 'ok': 5, 'failures': 2, 'changed': 7, 'unreachable': 2})
    color_0 = True
    ret_0 = hostcolor(host_0, stats_0, color_0)
    assert ret_0 == 'app1                         '

    host_1 = 'app2'
    stats_1 = dict({'skipped': 1, 'ok': 5, 'failures': 2, 'changed': 7, 'unreachable': 2})
    color_1 = True
    ret_1 = hostcolor(host_1, stats_1, color_1)
    assert ret_1 == 'app2                         '



# Generated at 2022-06-25 12:59:50.733221
# Unit test for function hostcolor
def test_hostcolor():
    bool_0 = False
    var_0 = hostcolor(bool_0, bool_0, bool_0)


# Generated at 2022-06-25 12:59:56.320960
# Unit test for function stringc
def test_stringc():
    string = u"Test"
    color = u"red"
    res = stringc(string, color)
    inspect(string, color, res)
    color = u"blue"
    res = stringc(string, color)
    inspect(string, color, res)
    color = u"yellow"
    res = stringc(string, color)
    inspect(string, color, res)
    color = u"green"
    res = stringc(string, color)
    inspect(string, color, res)



# Generated at 2022-06-25 13:00:02.728164
# Unit test for function stringc
def test_stringc():
    text = u'foobar'
    color = u'green'
    ansible_color = True
    wrap_nonvisible_chars = False
    res = stringc(text, color, wrap_nonvisible_chars)

    expected_res = u'\x1b[32mfoobar\x1b[0m'
    print(expected_res)
    print(res)
    assert expected_res == res


# Generated at 2022-06-25 13:00:04.605903
# Unit test for function hostcolor
def test_hostcolor():
    bool_0 = True
    var_0 = hostcolor(bool_0)

# Generated at 2022-06-25 13:00:13.075625
# Unit test for function stringc
def test_stringc():
    text_0 = "color0"
    color_0 = "color0"
    result_0 = stringc(text_0, color_0)
    assert result_0 == "\x1b[38;5;0mcolor0\x1b[0m"

    text_1 = "color1"
    color_1 = "color1"
    result_1 = stringc(text_1, color_1)
    assert result_1 == "\x1b[38;5;1mcolor1\x1b[0m"

    text_2 = "color2"
    color_2 = "color2"
    result_2 = stringc(text_2, color_2)
    assert result_2 == "\x1b[38;5;2mcolor2\x1b[0m"

    text_3