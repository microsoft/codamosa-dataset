

# Generated at 2022-06-25 12:50:17.078539
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('0') == '38;5;0'
    assert parsecolor('rgb125') == '38;5;67'
    assert parsecolor('gray1') == '38;5;232'



# Generated at 2022-06-25 12:50:23.890404
# Unit test for function parsecolor
def test_parsecolor():
    int_0 = None
    int_1 = '3'
    int_1 = parsecolor(int_0)
    assert int_1 == 38 + 5 + 3
    int_1 = parsecolor(int_1)
    assert int_1 == 38 + 5 + 3
    int_0 = 'rgb123'
    int_1 = parsecolor(int_0)
    assert int_1 == 38 + 5 + 15
    int_0 = 'rgb312'
    int_1 = parsecolor(int_0)
    assert int_1 == 16 + 3 * 36 + 1 * 6 + 2
    int_0 = 'gray1'
    int_1 = parsecolor(int_0)
    assert int_1 == 38 + 5 + 233
    return True


# Generated at 2022-06-25 12:50:29.313640
# Unit test for function hostcolor
def test_hostcolor():
    for host in ['localhost', '127.0.0.1']:
        for stats in [{'failures': 0, 'unreachable': 0, 'changed': 0},
                      {'failures': 0, 'unreachable': 0, 'changed': 1},
                      {'failures': 0, 'unreachable': 1, 'changed': 0},
                      {'failures': 1, 'unreachable': 0, 'changed': 0}]:
            yield (host, stats, True)
            yield (host, stats, False)
    return


# Generated at 2022-06-25 12:50:33.615841
# Unit test for function stringc
def test_stringc():
    print("\nUnit-test for function 'stringc'")

    print("\nTest1: Testing on 'stringc'...", end='')
    try:
        test_case_0()
        print("PASS")
    except AssertionError:
        print("FAIL")

    print("Done with unit-test for function 'stringc'\n")

if __name__ == "__main__":
    test_stringc()

# Generated at 2022-06-25 12:50:37.004430
# Unit test for function stringc
def test_stringc():
    print ("Testing stringc")
    int_var = "Test string"
    int_var_1 = None
    ret = stringc(int_var, int_var_1)
    assert ret == u"\n".join([u"\001\033[0m\002Test string\001\033[0m\002" for t in u"\n".split(u'\n')])


# Generated at 2022-06-25 12:50:41.008416
# Unit test for function hostcolor
def test_hostcolor():
    host = ""
    stats = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    color = True

    if hostcolor(host, stats, color) == "------------------------------------":
        test_case_0()
    else:
        print('Failed test_hostcolor')



# Generated at 2022-06-25 12:50:43.468849
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = 'localhost'
    int_1 = None
    int_2 = 'localhost'
    var_0 = hostcolor(int_0, int_1, int_2)

# Generated at 2022-06-25 12:50:51.954325
# Unit test for function parsecolor
def test_parsecolor():
    int_0 = 'C.COLOR_ERROR'
    int_1 = 'color50'
    int_2 = 'rgb555'
    int_3 = 'gray10'
    int_4 = 'BLACK'
    int_5 = None
    int_6 = 'rgb011'
    int_7 = 'rgb010'
    int_8 = 'rgb001'
    int_9 = 'rgb111'
    int_10 = 'rgb000'
    int_11 = 'rgb100'
    int_12 = 'rgb101'
    int_13 = 'rgb110'
    int_14 = None
    int_15 = 'rgb100'
    int_16 = 'rgb010'
    int_17 = 'rgb001'
    int_18 = 'rgb110'

# Generated at 2022-06-25 12:50:58.377934
# Unit test for function stringc
def test_stringc():
    # no color - don't string
    var_0 = stringc('text', 'blue')
    assert var_0 == 'text'

    # color, don't wrap
    var_0 = stringc('text', 'blue', wrap_nonvisible_chars=False)
    assert var_0 == '\x1b[38;5;4mtext\x1b[0m'

    # color, wrap
    var_0 = stringc('text', 'blue', wrap_nonvisible_chars=True)
    assert var_0 == '\x01\x1b[38;5;4m\x02text\x01\x1b[0m\x02'

# --- end "pretty"

# ==============================================================
# ANSI COLORS

# ANSI color escape sequences

# Generated at 2022-06-25 12:51:04.969341
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("rgb255255255") == u'38;5;255'
    assert parsecolor("rgb12045255") == u'38;5;208'
    assert parsecolor("gray255") == u'38;5;255'
    assert parsecolor("color1") == u'38;5;1'
    assert ANSIBLE_COLOR == True
    assert stringc("texttest_case_0", None) == u'\n.\x1b[0m\n.\x1b[0m\n.\x1b[0m'

# Generated at 2022-06-25 12:51:12.709247
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = u"smb"
    dict_0 = {u'changed': 0, u'failures': 0, u'unreachable': 0}
    cli_0 = True
    ret_0 = hostcolor(int_0, dict_0, cli_0)
    assert ret_0 == u"smb                          "

# Generated at 2022-06-25 12:51:22.945015
# Unit test for function colorize
def test_colorize():
    # Gets the arguments of a function
    args, varargs, keywords, defaults = inspect.getargspec(func)
    args = inspect.getargspec(func)[0]
    print(args)
    arg_types = []
    def test_1():
        arg_types.append([str, int, (str)])
        assert arg_types[-1][0] == type(args[0]), "Variable type error: Expected %s but found %s" % (
            arg_types[-1][0], type(args[0]))
        assert arg_types[-1][1] == type(args[1]), "Variable type error: Expected %s but found %s" % (
            arg_types[-1][1], type(args[1]))

# Generated at 2022-06-25 12:51:23.700651
# Unit test for function stringc
def test_stringc():
    assert stringc(text='', color=None) == ''


# Generated at 2022-06-25 12:51:29.694993
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = None
    int_1 = { 'arg_0': 0, 'arg_1': 0, 'arg_2': 0 }
    var_0 = hostcolor(int_0, int_1)
    print(var_0)


if __name__ == '__main__':
#     test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:51:38.017724
# Unit test for function hostcolor
def test_hostcolor():
    global ANSIBLE_COLOR
    # ansible_color is false
    ANSIBLE_COLOR = False
    host = "test-host"
    stats = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    color = True
    expected = "%-26s" % host
    actual = hostcolor(host, stats, color)
    print("Expected: {}\nActual: {}".format(expected, actual))
    if expected == actual:
        print("Test case [0] pass!")
    else:
        print("Test case [0] failed!")
    # setting ansible_color to true
    ANSIBLE_COLOR = True
    # test case 1

# Generated at 2022-06-25 12:51:42.787272
# Unit test for function stringc
def test_stringc():
    assert stringc(text='stringc', color='gray123', wrap_nonvisible_chars=False) == 'stringc'
    assert stringc(text='stringc', color='red', wrap_nonvisible_chars=True) == '\001\033[31m\002stringc\001\033[0m\002'
    assert stringc(text='stringc', color='rgb123', wrap_nonvisible_chars=False) == '\033[38;5;45mstringc\033[0m'



# Generated at 2022-06-25 12:51:50.426846
# Unit test for function hostcolor
def test_hostcolor():
    host = 'ansible'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    host = hostcolor(host, stats, color)
    assert host == 'ansible'
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    color = True
    host = hostcolor(host, stats, color)
    assert host != 'ansible'

# Call test_case_0
# test_case_0()
# Unit test
# test_hostcolor()

# Generated at 2022-06-25 12:51:57.127746
# Unit test for function hostcolor
def test_hostcolor():
    host_0 = "5b5f5b5d6b5d636a"
    stats_0 = {'unreachable': -1263855514, 'changed': None, 'failures': 2086419099, 'skipped': -221688026}
    color_0 = None
    var_0 = hostcolor(host_0, stats_0, color_0)



# Generated at 2022-06-25 12:52:03.435864
# Unit test for function hostcolor
def test_hostcolor():
    print("\n=== test_hostcolor ===")
    str_0 = 'fox'
    int_0 = -1060
    int_1 = None
    int_2 = -252
    int_3 = -7
    int_4 = 0
    str_1 = 'wolf'
    int_5 = -1060
    int_6 = None
    int_7 = -1423
    int_8 = -9
    int_9 = 4
    str_2 = 'sheep'
    int_10 = -1060
    int_11 = None
    int_12 = -1423
    int_13 = -9
    int_14 = 0
    str_3 = 'antelope'
    int_15 = -1060
    int_16 = None
    int_17 = -2482
    int_18

# Generated at 2022-06-25 12:52:06.780727
# Unit test for function colorize
def test_colorize():
    int_0 = -1060
    int_1 = -8960
    string_0 = u'v4.4'
    var_0 = colorize(int_0, int_1, string_0)


# Generated at 2022-06-25 12:52:18.570448
# Unit test for function stringc
def test_stringc():
    assert stringc("0", "default") == "0"
    assert stringc("1", "blue", True) == "\x01\x1b[34m\x021\x01\x1b[0m\x02"
    assert stringc("2", "rgb(0,0,0)") == "\x1b[38;5;232m2\x1b[0m"
    assert stringc("3", "color1") == "\x1b[38;5;1m3\x1b[0m"
    assert stringc("4", "1") == "4"
    assert stringc("5", "enum") == "5"
    assert stringc("6", "rgb(13,13,13)") == "\x1b[38;5;105m6\x1b[0m"

# Generated at 2022-06-25 12:52:22.007704
# Unit test for function stringc
def test_stringc():
    int_0 = -1340
    int_1 = 1261
    var_0 = stringc(int_0, int_1)
    for var_1 in var_0:
        dummy = var_1

# Begin unit test

# Generated at 2022-06-25 12:52:30.052726
# Unit test for function stringc
def test_stringc():
    assert stringc(u"test", u"green") == u"\033[38;5;%smtest\033[0m" % (10)
    assert stringc(u"test", u"red") == u"\033[38;5;%smtest\033[0m" % (9)
    assert stringc(u"test", u"blue") == u"\033[38;5;%smtest\033[0m" % (12)
    assert stringc(u"test", u"gray") == u"\033[38;5;%smtest\033[0m" % (241)
    assert stringc(u"test", u"gray62") == u"\033[38;5;%smtest\033[0m" % (7)

# Generated at 2022-06-25 12:52:32.791361
# Unit test for function hostcolor
def test_hostcolor():
    print(u"%s\n" % (hostcolor(u"host", {'changed': 0, 'failures': 1,
                                          'skipped': 0, 'unreachable': 0},
                               True), ))


# Generated at 2022-06-25 12:52:38.232864
# Unit test for function stringc
def test_stringc():
    var_0 = stringc("value", "gray0")
    var_1 = "\033[38;5;232mvalue\033[0m"

    assert var_0 == var_1


# Generated at 2022-06-25 12:52:48.398442
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'failures':0, 'changed':0, 'unreachable':0,
                              'skipped':0, 'ok':0}) == u'host                     '
    assert hostcolor('host', {'failures':0, 'changed':0, 'unreachable':0,
                              'skipped':0, 'ok':0}, color=False) == u'host                     '
    assert hostcolor('host', {'failures':0, 'changed':1, 'unreachable':0,
                              'skipped':0, 'ok':0}) == u'host                     '
    assert hostcolor('host', {'failures':0, 'changed':0, 'unreachable':1,
                              'skipped':0, 'ok':0}) == u'host                     '

# Generated at 2022-06-25 12:52:58.013145
# Unit test for function stringc
def test_stringc():
    assert (stringc("", "", True) == u"")
    assert (stringc("", "nonexistent", True) is None)
    assert (stringc("", "red", True) == u"\033[38;5;9m\033[0m")
    assert (stringc("", "color1", True) == u"\033[38;5;1m\033[0m")
    assert (stringc("", "rgb123", True) == u"\033[38;5;18m\033[0m")
    assert (stringc("", "rgb333", True) == u"\033[38;5;252m\033[0m")
    assert (stringc("", "gray1", True) == u"\033[38;5;233m\033[0m")

# Generated at 2022-06-25 12:53:00.571210
# Unit test for function hostcolor
def test_hostcolor():
    host = "a"
    stats = {"failures": 0,
             "unreachable": 0,
             "changed": 0}

    assert(hostcolor(host, stats) == "%-26s")


# Generated at 2022-06-25 12:53:03.186845
# Unit test for function stringc
def test_stringc():
    message = "test"
    color = C.COLOR_ERROR
    wrap_nonvisible_chars = False

    assert stringc(message, color, wrap_nonvisible_chars) == '\033[31;1mtest\033[0m'



# Generated at 2022-06-25 12:53:11.616727
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == u"lead=num "
    assert colorize(int, int, str) == u"<type 'int'>=<type 'int'> "
    assert colorize(int, str, int) == u"<type 'int'>=<type 'str'> "
    assert colorize(int, int, int) == u"<type 'int'>=<type 'int'> "
    assert colorize(str, str, str) == u"<type 'str'>=<type 'str'> "
    assert colorize(str, int, str) == u"<type 'str'>=<type 'int'> "
    assert colorize(str, str, int) == u"<type 'str'>=<type 'str'> "


# Generated at 2022-06-25 12:53:17.124771
# Unit test for function stringc
def test_stringc():
    assert(stringc(255, 255) == '\033[38;5;255m255\033[0m')


# Generated at 2022-06-25 12:53:18.505921
# Unit test for function hostcolor
def test_hostcolor():
    # TODO: Write tests...
    assert False, 'No tests for hostcolor yet.'


# Generated at 2022-06-25 12:53:30.146654
# Unit test for function hostcolor
def test_hostcolor():
    assert(type(hostcolor(None,None)) == unicode )

    host = 'hostname'
    stats = {'ok':0, 'changed':0, 'unreachable':0, 'failures':0, 'skipped':0}
    assert(hostcolor(host, stats) == u"hostname                 ")
    assert(hostcolor(host, stats, False) == u"hostname                ")

    stats = {'ok':0, 'changed':1, 'unreachable':0, 'failures':0, 'skipped':0}
    assert(hostcolor(host, stats, True) == u"hostname               ")
    assert(hostcolor(host, stats, False) == u"hostname                ")
    assert(hostcolor(host, stats, True) == u"hostname               ")


# Generated at 2022-06-25 12:53:33.733283
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("foo", {'unreachable': 0, 'skipped': 0, 'changed': 0, 'failures': 0, 'ok': 0}, True) == u"foo                            "


# Generated at 2022-06-25 12:53:42.773835
# Unit test for function stringc
def test_stringc():
    var_0 = stringc(u"iY\ue4fe\u819aV\u0f59\ub5fa\u9f9d", u"color10", True)
    var_1 = "iY\ue4fe\u819aV\u0f59\ub5fa\u9f9d"
    var_2 = stringc(u"\ud14e\u8f6b\u6e29\u7edf\u8e6e\u6e1f\udf29\u9db9\ud6d0\u773b", u"rgb253", False)

# Generated at 2022-06-25 12:53:44.041786
# Unit test for function colorize
def test_colorize():
    """
    :return: str
    """
    pass



# Generated at 2022-06-25 12:53:46.022617
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = -1923
    var_0 = hostcolor(int_0, int_0)


# Generated at 2022-06-25 12:53:56.573884
# Unit test for function stringc
def test_stringc():
    from collections import OrderedDict
    from ansible.compat import StringIO
    from ansible.utils.color import stringc, strip_ansi
    from ansible.utils.unicode import to_unicode

    f_0 = StringIO()
    f_1 = StringIO()

    assert strip_ansi(stringc('a', 'b', False)) == 'a'
    assert strip_ansi(stringc('a', 'b', True)) == 'a'
    assert strip_ansi(stringc('a\nb', 'b', True)) == 'a\nb'
    assert stringc('a\nb', 'b', True) == '\x01\x1ba\x02\x01\x1bb\x02'

    # Test for undefined color

# Generated at 2022-06-25 12:54:04.797208
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict()
    stats['failed'] = 0
    stats['changed'] = 0
    stats['ignored'] = 0
    stats['ok'] = 0
    stats['unreachable'] = 0
    stats['skipped'] = 0
    stats['rescued'] = 0
    stats['ignored'] = 0
    stats['darker'] = 0
    stats['no_hosts'] = 0

    # Testing when 'failures' > 0
    stats['failures'] = 2
    assert hostcolor('test-host', stats) == u'\033[31mtest-host\033[0m'

    # Testing when 'unreachable' > 0
    stats['unreachable'] = 1
    stats['failures'] = 0

# Generated at 2022-06-25 12:54:08.694075
# Unit test for function hostcolor
def test_hostcolor():
    # Return the result of hostcolor()
    int_0 = -100
    str_0 = 'lkajsdf'
    dict_0 = {'test_key': {'test_key': {'test_key': 'test_value'}}}
    assert hostcolor(str_0, dict_0, int_0) == '%-26s' % stringc(str_0, int_0)


# Generated at 2022-06-25 12:54:21.885560
# Unit test for function colorize
def test_colorize():
    fail = stringc("FAIL", "red")
    assert colorize("use", 1, "green") == "use=1   "
    assert colorize("use", 0, "green") == "use=0   "
    assert colorize("use", 1, "red") == "use=1   "
    assert colorize("use", 0, "red") == "use=0   "
    assert colorize("use", 1, None) == "use=1   "
    assert colorize("use", 0, None) == "use=0   "
    assert colorize("use", "-1923", None) == "use=-1923"



# Generated at 2022-06-25 12:54:29.420932
# Unit test for function hostcolor
def test_hostcolor():
    # Test cases
    assert hostcolor('ansible-test', {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 0}) == 'ansible-test                 '
    assert hostcolor('ansible-test',
                     {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 0}, False) == 'ansible-test                 '
    assert hostcolor('ansible-test', {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 1}) == 'ansible-test                 '
    assert hostcolor('ansible-test',
                     {'ok': 0, 'changed': 0, 'unreachable': 0, 'failures': 1}, False) == 'ansible-test                 '

# Generated at 2022-06-25 12:54:38.368605
# Unit test for function colorize
def test_colorize():
    assert colorize("this", 11, "red") == u"this=11  "
    assert colorize("this", -11, "blue") == u"this=-11 "
    assert colorize("this", "that", "green") == u"this=that"
    assert colorize("this", 11, "red") == u"this=11  "
    assert colorize("this", 11, "red") == u"this=11  "
    assert colorize("this", -11, "blue") == u"this=-11 "
    assert colorize("this", -11, "blue") == u"this=-11 "

#Unit test for function hostcolor()

# Generated at 2022-06-25 12:54:42.957238
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = -924
    int_1 = -15
    int_2 = -235
    res = hostcolor(int_0, {'failures': int_1, 'unreachable': int_2, 'changed': int_2}, True)
    assert res == '%-26s'


# Generated at 2022-06-25 12:54:50.175080
# Unit test for function hostcolor
def test_hostcolor():

    # Host already colored
    assert(hostcolor("\x1b[31m192.168.0.1\x1b[0m", {'ok': 1}, True) == u"\x1b[31m192.168.0.1\x1b[0m       ")
    assert(hostcolor("\x1b[31m192.168.0.1\x1b[0m", {'ok': 1}, False) == u"\x1b[31m192.168.0.1\x1b[0m       ")
    assert(hostcolor("192.168.0.1", {'ok': 1}, False) == u"192.168.0.1                 ")

# Generated at 2022-06-25 12:54:53.613122
# Unit test for function stringc
def test_stringc():
    with open('stringc.txt', 'r') as content_file:
        content = content_file.read()
    out = stringc(content, 'red')
    print(out)
    with open('stringc.txt', 'w') as content_file:
        content_file.write(out)


# Generated at 2022-06-25 12:54:56.902492
# Unit test for function stringc
def test_stringc():
    test_case_0()

# Test ansible.module_utils.basic.py to test the module utils.
if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-25 12:54:59.498300
# Unit test for function colorize
def test_colorize():
    lead = 'testing'
    num = '200'
    color = 'COLOR_OK'
    assert colorize(lead, num, color) == 'testing=200'


# Generated at 2022-06-25 12:55:05.237941
# Unit test for function hostcolor
def test_hostcolor():
    host = 'ansible.test'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    assert hostcolor(host, stats, False) == u"%-26s" % host

test_case_0()
test_hostcolor()

# Generated at 2022-06-25 12:55:13.744609
# Unit test for function stringc
def test_stringc():
    with open('/dev/null', 'wb') as f:
        old_stdout = sys.stdout
        sys.stdout = f

        # Call function
        int_0 = -1923
        result = stringc(int_0, int_0)

        # Restore stdout
        sys.stdout = old_stdout

        # Check result
        assert type(result) == str

        # Call function
        int_0 = -1923
        result = stringc(int_0, int_0)

        # Check result
        assert type(result) == str

        # Call function
        int_0 = -1923
        result = stringc(int_0, int_0)

        # Check result
        assert type(result) == str

        # Call function
        int_0 = -1923
        result = string

# Generated at 2022-06-25 12:55:25.422518
# Unit test for function hostcolor
def test_hostcolor():
    var_1 = 'test_hostname'
    var_2 = {'skipped': 0, 'failures': 0, 'ok': 1, 'changed': 0, 'unreachable': 0}
    var_3 = True
    var_4 = hostcolor(var_1, var_2, var_3)
    print(u"hostcolor(): ", end="")
    print(var_4)


# Generated at 2022-06-25 12:55:32.945390
# Unit test for function colorize
def test_colorize():
    lead = 'ok'
    num = 2
    color = None
    colorize(lead, num, color)
    lead = 'changed'
    num = 3
    color = None
    colorize(lead, num, color)
    lead = 'unreachable'
    num = 1
    color = None
    colorize(lead, num, color)
    lead = 'failed'
    num = 0
    color = None
    colorize(lead, num, color)


# Generated at 2022-06-25 12:55:35.354838
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("test", [], False) == "test                 "
    assert hostcolor("test", [], True) == "test                 "



# Generated at 2022-06-25 12:55:44.911971
# Unit test for function hostcolor

# Generated at 2022-06-25 12:55:48.901708
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'myhost'
    dict_0 = {}
    dict_0['failures'] = 0
    dict_0['unreachable'] = 0
    dict_0['changed'] = 0
    var_0 = hostcolor(str_0, dict_0)
    assert var_0 == u'%-26s' % str_0

# Generated at 2022-06-25 12:55:54.269663
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'gray255'
    var_0 = parsecolor(str_0)
    str_1 = 'foobar'
    var_1 = { 'unreachable': 0, 'skipped': 0, 'changed': 0, 'ok': 0, 'failures': 0 }
    var_2 = hostcolor(str_1, var_1)


# Generated at 2022-06-25 12:55:56.394697
# Unit test for function colorize
def test_colorize():
    with pytest.raises(TypeError):
        colorize(1,1)
    p_0 = colorize('lead', 'num', 'color')


# Generated at 2022-06-25 12:56:04.950959
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    color = True
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    var_0 = hostcolor(host, stats, color)
    stats['changed'] = 1
    var_1 = hostcolor(host, stats, color)
    stats['changed'] = 0
    stats['failures'] = 1
    stats['unreachable'] = 1
    var_2 = hostcolor(host, stats, color)
    color = False
    var_3 = hostcolor(host, stats, color)
    return ((var_0, 38), (var_1, 38), (var_2, 38), (var_3, 30))


# Generated at 2022-06-25 12:56:09.132635
# Unit test for function hostcolor
def test_hostcolor():
    host = ""
    stats = {}
    color = True
    var_0 = hostcolor(host, stats, color)
    str_0 = "%-37s"
    var_1 = var_0 == str_0
    str_1 = "gray255"


# --- end "pretty"

# Generated at 2022-06-25 12:56:20.042785
# Unit test for function colorize
def test_colorize():
    assert(colorize('ok', 0, 'green')) == 'ok=0'
    assert(colorize('ok', 1, 'red')) == u'\x1b[31mok=1\x1b[0m'
    assert(colorize('ok', 1, 'yellow')) == u'\x1b[33mok=1\x1b[0m'
    assert(colorize('ok', 1, 'blue')) == u'\x1b[34mok=1\x1b[0m'
    assert(colorize('ok', 1, 'magenta')) == u'\x1b[35mok=1\x1b[0m'

# Generated at 2022-06-25 12:56:33.965824
# Unit test for function stringc
def test_stringc():
    str_0 = 'gray255'
    str_1 = u'\u001b[38;5;255m'
    var_0 = stringc(str_0, 'gray255')
    final1 = str_1 in var_0
    var_1 = stringc(str_0, 'gray255', False)
    final2 = str_1 in var_1
    var_2 = stringc(str_0, 'gray255', True)
    final3 = str_1 not in var_2
    var_3 = stringc(str_0, 'gray255', True)
    final4 = var_2 in var_3
    return final1 and final2 and final3 and final4


# Generated at 2022-06-25 12:56:41.894918
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'gray255'
    var_0 = parsecolor(str_0)
    str_1 = 'hostname'
    var_1 = {'changed': 0,
             'dark': 0,
             'failures': 0,
             'ok': 1,
             'processed': 0,
             'skipped': 0,
             'unreachable': 0,
             'rescued': 0,
             'ignored': 0}
    var_2 = hostcolor(str_1, var_1, False)
    assert var_2 == 'hostname               '



# Generated at 2022-06-25 12:56:52.088948
# Unit test for function colorize
def test_colorize():
    s = colorize('pippo', 0, C.COLOR_SKIP)
    assert s == 'pippo=0   '
    s = colorize('pippo', 0, None)
    assert s == 'pippo=0   '
    s = colorize('pippo', 0, C.COLOR_OK)
    assert s == 'pippo=0   '
    s = colorize('pippo', 1, C.COLOR_OK)
    assert s == 'pippo=1   '
    s = colorize('pippo', 1, C.COLOR_CHANGED)
    assert s == 'pippo=1   '
    s = colorize('pippo', 2, C.COLOR_CHANGED)
    assert s == 'pippo=2   '

# Generated at 2022-06-25 12:56:57.228645
# Unit test for function stringc
def test_stringc():
    test_0 = 'hello'
    var_1 = stringc(test_0, 'red', True)
    test_1 = 'hello'
    var_2 = stringc(test_1, 'red', False)



# Generated at 2022-06-25 12:56:59.808981
# Unit test for function stringc
def test_stringc():
    str_0 = 'gray255'
    str_1 = 'red'
    var_0 = stringc(str_0, str_1)
    print(u'TEST %s' % var_0)


# Generated at 2022-06-25 12:57:02.919769
# Unit test for function stringc
def test_stringc():
    assert stringc("Hello world!", "green") == u'\033[0;32mHello world!\033[0m'

test_case_0()
test_stringc()

# Generated at 2022-06-25 12:57:08.553277
# Unit test for function hostcolor
def test_hostcolor():
    # To print results of negative tests, set C.DEBUG to True
    host_0 = 'mars'
    stats_0 = {'failures': 0, 'ok': 6, 'changed': 0, 'skipped': 0, 'unreachable': 0}
    color_0 = True
    testcase_0 = hostcolor(host_0, stats_0, color_0)


# Generated at 2022-06-25 12:57:11.729223
# Unit test for function colorize
def test_colorize():
    # Default color should be None
    assert colorize('host', 1, None) == 'host=1   '

    # Check the default color
    assert colorize('host', 2, 'white') == 'host=2   '


# Generated at 2022-06-25 12:57:18.121354
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host'
    # The value of the first element of parameter 'stats' is not checked
    # in hostcolor.
    num_0 = 0
    num_1 = 0
    num_2 = 0
    num_3 = 0
    str_1 = 'color'
    num_4 = 1
    str_output = hostcolor(str_0, [num_0, num_1, num_2, num_3, str_1], num_4)
    assert str_output == u"%-37s" % stringc(str_0, C.COLOR_OK)



# Generated at 2022-06-25 12:57:19.767038
# Unit test for function colorize
def test_colorize():
    lead = 'lead'
    num = 1
    color = True
    var_0 = colorize(lead, num, color)


# Generated at 2022-06-25 12:57:33.258346
# Unit test for function stringc
def test_stringc():
    str_0 = 'red'
    str_1 = 'Default'
    var_0 = stringc(str_1, str_0)
    var_1 = unicode(u'\x1b[31mDefault\x1b[0m')
    assert var_0 == var_1, "stringc must return %s but got %s" % (repr(var_1), repr(var_0))


# Generated at 2022-06-25 12:57:42.658713
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor('test_host',{'failures': 0, 'ok': 10, 'skipped': 0, 'unreachable': 0, 'changed': 0}, True) == u'\u001b[38;5;254mtest_host\u001b[0m      ')
    assert(hostcolor(u'test_host',{'failures': 0, 'ok': 10, 'skipped': 0, 'unreachable': 0, 'changed': 0}, True) == u'\u001b[38;5;254mtest_host\u001b[0m      ')

text1 = "this is some text"
color1 = "blue"
expected1 = '\x1b[38;5;21mthis is some text\x1b[0m'

color2 = 'color1'
text2

# Generated at 2022-06-25 12:57:48.529607
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'magenta') == u"\033[35mtest\033[0m"
    assert stringc('test', 'gray255', True) == u"\001\033[38;5;255m\002test\001\033[0m\002"
    assert stringc('test', 'rgb255255255') == u"\033[38;5;15mtest\033[0m"

# Generated at 2022-06-25 12:57:50.042534
# Unit test for function stringc
def test_stringc():
    test_case_0()
# --- end "pretty"



# Generated at 2022-06-25 12:57:59.592858
# Unit test for function stringc
def test_stringc():
    print(stringc('foo', 'CYAN'))
    print(stringc('foo', 'yellow'))
    print(stringc('foo', 'purple'))
    print(stringc('foo', 'CYAN'))
    print(stringc('foo', 'yellow'))
    print(stringc('foo', 'purple'))
    print(stringc('foo', 'yellow'))
    print(stringc('foo', 'yellow'))
    print(stringc('foo', 'yellow'))
    print(stringc('foobar', 'yellow'))
    print(stringc('foo', 'yellow'))
    print(stringc('foo', 'yellow'))


# Generated at 2022-06-25 12:58:02.033202
# Unit test for function stringc
def test_stringc():
    str_0 = 'hello'
    str_1 = 'lightred'
    var_0 = stringc(str_0, str_1)


# Generated at 2022-06-25 12:58:10.414769
# Unit test for function stringc
def test_stringc():
    # Test for without optional parameter 'wrap_nonvisible_chars'
    str_0 = 'foo'
    str_1 = 'red'
    var_0 = stringc(str_0, str_1)
    assert var_0 == '\x1b[31mfoo\x1b[0m'

    # Test for with optional parameter 'wrap_nonvisible_chars'
    str_0 = 'foo'
    str_1 = 'blue'
    var_0 = stringc(str_0, str_1, True)
    assert var_0 == '\x01\x1b[34m\x02foo\x01\x1b[0m\x02'


# Generated at 2022-06-25 12:58:16.814326
# Unit test for function hostcolor
def test_hostcolor():
    host = '127.0.0.1'
    stats = {
        'changed': 0,
        'dark': 0,
        'failures': 0,
        'ok': 2,
        'skipped': 0,
        'unreachable': 0
    }
    var_0 = hostcolor(host, stats, color=True)


# Generated at 2022-06-25 12:58:21.933609
# Unit test for function stringc
def test_stringc():
    str_0 = 'test test'
    str_1 = 'test test'
    str_2 = 'test test'
    str_3 = 'test test'
    var_0 = stringc(str_0, 'black')
    var_1 = stringc(str_1, 'black')
    var_2 = stringc(str_2, 'black')
    var_3 = stringc(str_3, 'black')



# Generated at 2022-06-25 12:58:26.545622
# Unit test for function hostcolor
def test_hostcolor():
    stats = {
        'changed': 0,
        'dark': 0,
        'failures': 0,
        'ok': 0,
        'processed': 0,
        'skipped': 0,
        'unreachable': 0
    }
    color = True
    host = "host1"
    with pytest.raises(TypeError):
        hostcolor(host, stats, color)


# Generated at 2022-06-25 12:58:49.888780
# Unit test for function stringc
def test_stringc():
    str_0 = 'gray0'
    str_1 = '\n'
    str_2 = stringc(str_1, str_0)
    str_3 = 'color0'
    str_4 = stringc(str_2, str_3)
    str_5 = '\n'
    str_6 = stringc(str_4, str_5)
    str_7 = 'color1'
    str_8 = stringc(str_6, str_7)
    str_9 = '\n'
    str_10 = stringc(str_8, str_9)
    str_11 = 'color2'
    str_12 = stringc(str_10, str_11)
    str_13 = '\n'
    str_14 = stringc(str_12, str_13)


# Generated at 2022-06-25 12:58:55.774457
# Unit test for function hostcolor
def test_hostcolor():
    fd = open('./hostcolor.txt', 'r')
    testcase = fd.readlines()
    test_list = []
    for item in testcase:
        test_list.append(item.rstrip())

    test_host = test_list[0]
    test_stats = test_list[1]
    test_color = test_list[2]
    var_0 = hostcolor(test_host, test_stats, test_color)


# Generated at 2022-06-25 12:59:04.945275
# Unit test for function hostcolor
def test_hostcolor():
    host = 'appname5-qa.tibco.com'
    stats = {'changed': 6,
             'ok': 2,
             'failures': 2,
             'skipped': 0,
             'unreachable': 0,
             'rescued': 0,
             'ignored': 0}
    if ANSIBLE_COLOR:
        assert hostcolor(host, stats, color=True) == u'\033[31;01mappname5-qa.tibco.com\033[0m'
    else:
        assert hostcolor(host, stats, color=False) == u'appname5-qa.tibco.com'

# --- end "pretty"

# Generated at 2022-06-25 12:59:05.893989
# Unit test for function colorize
def test_colorize():
    test_case_0()


# Generated at 2022-06-25 12:59:13.476551
# Unit test for function hostcolor
def test_hostcolor():
    host = "test"
    stats = dict()
    stats["failures"] = 0
    stats["unreachable"] = 0
    stats["changed"] = 1
    stats["ok"] = 0
    color = True
    str_0 = hostcolor(host, stats, color)
    assert str_0 == 'test                        \033[0;32m\n'
    stats["failures"] = 0
    stats["unreachable"] = 0
    stats["changed"] = 0
    stats["ok"] = 1
    str_1 = hostcolor(host, stats, color)
    assert str_1 == 'test                        \033[0;34m\n'
    stats["failures"] = 1
    stats["unreachable"] = 0
    stats["changed"] = 0
    stats["ok"] = 0
    str_2 = host

# Generated at 2022-06-25 12:59:16.708977
# Unit test for function colorize
def test_colorize():
    lead = 'lead'
    num = 5
    color = 'blue'
    colorize(lead, num, color)
    return True

# End of colorize function


# Generated at 2022-06-25 12:59:18.366786
# Unit test for function colorize
def test_colorize():
    color = colorize('lead', 2 , 'blue')
    assert color == 'lead=2   '


# Generated at 2022-06-25 12:59:26.486224
# Unit test for function hostcolor
def test_hostcolor():
    # Edge cases
    host = 'test'
    # Generic case
    stats = {'failures' : 0,
             'unreachable': 0,
             'changed': 0}
    assert hostcolor(host, stats) == '%-37s' % host
    stats = {'failures' : 1,
             'unreachable': 0,
             'changed': 0}
    assert hostcolor(host, stats, color=False) == '%-26s' % host
    stats = {'failures' : 0,
             'unreachable': 1,
             'changed': 0}
    assert hostcolor(host, stats, color=False) == '%-26s' % host
    stats = {'failures' : 0,
             'unreachable': 0,
             'changed': 1}

# Generated at 2022-06-25 12:59:35.720301
# Unit test for function stringc
def test_stringc():
    # Test case 0:
    test_case_0()

ANSIBLE_NOCOLOR = C.ANSIBLE_NOCOLOR
ANSIBLE_FORCE_COLOR = C.ANSIBLE_FORCE_COLOR
COLOR_WARNING = C.COLOR_WARNING
COLOR_ERROR = C.COLOR_ERROR
COLOR_OK = C.COLOR_OK
COLOR_SKIP = C.COLOR_SKIP
COLOR_UNREACHABLE = C.COLOR_UNREACHABLE
COLOR_CHANGED = C.COLOR_CHANGED
COLOR_DEPRECATE = C.COLOR_DEPRECATE
COLOR_CODES = C.COLOR_CODES

#
# --- end "pretty"

if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-25 12:59:37.308859
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('my-server', {'failures': 1}) == 'my-server                           '



# Generated at 2022-06-25 12:59:57.276498
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor("localhost","stats"), u"%-37s" % stringc("localhost", C.COLOR_OK))


# Generated at 2022-06-25 13:00:00.628677
# Unit test for function stringc
def test_stringc():
    # ansible.utils.color.stringc()
    color = 'blue'
    text = 'The sky is blue'
    var_1 = stringc(text, color)


# Generated at 2022-06-25 13:00:10.917100
# Unit test for function hostcolor
def test_hostcolor():
    # Tests for usage with color enabled
    host = 'web01.foo.bar.com'
    stats = dict(
        failures=0,
        unreachable=0,
        changed=0
    )
    assert hostcolor(host, stats) == 'web01.foo.bar.com            '

    stats = dict(
        failures=1,
        unreachable=0,
        changed=0
    )
    assert hostcolor(host, stats) == '\x1b[91mweb01.foo.bar.com      ' + \
        '     \x1b[0m'

    stats = dict(
        failures=0,
        unreachable=1,
        changed=0
    )