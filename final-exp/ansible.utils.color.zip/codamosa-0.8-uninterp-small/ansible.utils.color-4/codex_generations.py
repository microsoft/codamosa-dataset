

# Generated at 2022-06-25 12:50:25.439087
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', num=1, color=None) == 'lead=1   '

# Generated at 2022-06-25 12:50:29.626352
# Unit test for function hostcolor
def test_hostcolor():
    """Return a hostname with color codes embedded."""
    # Example of using the 'assert_equal' test to compare a variable
    #   to a known value.
    assert_equal(hostcolor("localhost", {
                           u'changed': 0, u'unreachable': 0, u'failures': 0}, True), u'\x1b[0;32mlocalhost\x1b[0m')



# Generated at 2022-06-25 12:50:32.295752
# Unit test for function stringc
def test_stringc():
    line_0 = 'green'
    line_1 = '\x1b[32mgreen\x1b[0m'
    line_2 = stringc('green', 'green')
    assert line_2 == line_1


# Generated at 2022-06-25 12:50:38.817517
# Unit test for function parsecolor
def test_parsecolor():
    assert  parsecolor('color11') == u'38;5;11'
    assert  parsecolor('color0') == u'38;5;0'
    assert  parsecolor('color5') == u'38;5;5'
    assert  parsecolor('color0') == u'38;5;0'
    assert  parsecolor('color1') == u'38;5;1'
    assert  parsecolor('color2') == u'38;5;2'
    assert  parsecolor('color3') == u'38;5;3'
    assert  parsecolor('color4') == u'38;5;4'
    assert  parsecolor('color6') == u'38;5;6'
    assert  parsecolor('color7') == u'38;5;7'

# Generated at 2022-06-25 12:50:40.975081
# Unit test for function hostcolor
def test_hostcolor():
    bytes_0 = None
    var_0 = hostcolor(host=bytes_0, stats=None, color=True)
    #self.assertEqual(var_0, )


# Generated at 2022-06-25 12:50:49.843864
# Unit test for function parsecolor
def test_parsecolor():
    #testcase_0
    bytes_0 = None
    assert parsecolor(bytes_0) == 39
    #testcase_1
    bytes_0 = 'color1'
    assert parsecolor(bytes_0) == 38
    #testcase_2
    bytes_0 = 'color1'
    assert parsecolor(bytes_0) == 38
    #testcase_3
    bytes_0 = 'color2'
    assert parsecolor(bytes_0) == 38
    #testcase_4
    bytes_0 = 'color3'
    assert parsecolor(bytes_0) == 38
    #testcase_5
    bytes_0 = 'color4'
    assert parsecolor(bytes_0) == 38
    #testcase_6
    bytes_0 = 'color5'
    assert parsecolor

# Generated at 2022-06-25 12:50:51.560767
# Unit test for function stringc
def test_stringc():
    assert stringc(bytes_0, var_0, var_1) == "\033[\033[0m\033[0m"

# Generated at 2022-06-25 12:50:53.841190
# Unit test for function stringc
def test_stringc():
    text = "Test"
    color = "yellow bold"
    stringc(text, color, True)

# --- end "pretty"

# TODO: migrate the remaining color usage to this class.

# Generated at 2022-06-25 12:50:56.945300
# Unit test for function stringc
def test_stringc():
    # Test with a valid color code
    color = 'blue'
    text = 'This is a test'
    result = stringc(text, color)
    assert result == "\033[34mThis is a test\033[0m"

    # Test with an invalid color code
    color = 'foo'
    result = stringc(text, color)
    assert result == text



# Generated at 2022-06-25 12:50:57.822484
# Unit test for function parsecolor
def test_parsecolor():
    assert test_case_0() is None

# --- end "pretty"



# Generated at 2022-06-25 12:51:06.544012
# Unit test for function hostcolor
def test_hostcolor():
    bytes_0 = None
    var_1 = {}
    var_2 = True
    var_0 = hostcolor(bytes_0, var_1, var_2)


# Generated at 2022-06-25 12:51:10.231183
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()


# Generated at 2022-06-25 12:51:15.805207
# Unit test for function parsecolor
def test_parsecolor():
    try:
        test_case_0()
    except:
        print('FAILURE: parsecolor failed with exception %s' % (str(sys.exc_info()[0:2])))
        raise


if __name__ == "__main__":
    test_parsecolor()

# --- end "pretty"

# Generated at 2022-06-25 12:51:18.504119
# Unit test for function stringc
def test_stringc():
    bytes_0 = None
    var_0 = stringc(bytes_0, None)


test_suites = [test_case_0, test_stringc]

for ts in test_suites:
    ts()

# Generated at 2022-06-25 12:51:20.760519
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host='host1', stats={'failures': 0, 'unreachable': 0, 'changed': 0}, color=True) == 'host1                          '



# Generated at 2022-06-25 12:51:27.720652
# Unit test for function stringc
def test_stringc():
    print(stringc("hello world", "green"))
    print(stringc("hello world", "rgb123"))
    print(stringc("hello world", "rgb004"))
    print(stringc("hello world", "rgb000"))
    print(stringc("hello world", "rgb400"))
    print(stringc("hello world", "rgb111"))

if __name__ == "__main__":
    test_stringc()

# Generated at 2022-06-25 12:51:31.843625
# Unit test for function stringc
def test_stringc():
    bytes_0 = u'AAAAA'
    bytes_1 = u'BBBBB'
    bytes_2 = u'CCCCC'
    var_0 = stringc(bytes_0, bytes_1, bytes_2)
    var_1 = stringc(bytes_0, bytes_1)


# Generated at 2022-06-25 12:51:34.042581
# Unit test for function stringc
def test_stringc():
    bytes_0 = None
    int_0 = None
    int_1 = None
    bytes_1 = stringc(bytes_0, int_0, int_1)


# Generated at 2022-06-25 12:51:39.127245
# Unit test for function hostcolor
def test_hostcolor():
    # Input arguments
    host = 'www.example.com'
    stats = {'changed': 0, 'failures': 1, 'ok': 2, 'skipped': 0, 'unreachable': 0, 'total': 3}
    color = True
    
    # Function call
    # Output processing
    assert(host == 'www.example.com')
    assert(stats == {'changed': 0, 'failures': 1, 'ok': 2, 'skipped': 0, 'unreachable': 0, 'total': 3})
    assert(color == True)
    
    

# Generated at 2022-06-25 12:51:50.155892
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = hostcolor(
        u"\u0051\u0041\u0056\u0045\u006e\u0050\u0062\u0065\u0066\u0049\u0066\u0075\u0058\u0046\u0073\u0062\u0063\u0036\u0077\u0051\u0065\u0030\u004a\u0073\u0069\u0070\u0077\u006f\u0037\u0032\u0050\u0073",
        {u'changed': 37, u'failures': 100, u'ok': 58, u'unreachable': 97},
        49)

# Generated at 2022-06-25 12:52:03.962388
# Unit test for function parsecolor
def test_parsecolor():
    """
    This function tests parsecolor
    """
    test_case_0()

# ---- end "pretty"

# --- begin "pager"


# Generated at 2022-06-25 12:52:13.476603
# Unit test for function colorize
def test_colorize():
    if ANSIBLE_COLOR:
        print(colorize('ok', 0, C.COLOR_OK))
        print(colorize('changed', 0, C.COLOR_CHANGED))
        print(colorize('unreachable', 0, C.COLOR_UNREACHABLE))
        print(colorize('fatal', 0, C.COLOR_ERROR))
        print(colorize('skipped', 0, C.COLOR_SKIP))
        print(colorize('ok', 1, C.COLOR_OK))
        print(colorize('changed', 1, C.COLOR_CHANGED))
        print(colorize('unreachable', 1, C.COLOR_UNREACHABLE))
        print(colorize('fatal', 1, C.COLOR_ERROR))
        print(colorize('skipped', 1, C.COLOR_SKIP))


# Generated at 2022-06-25 12:52:16.329050
# Unit test for function hostcolor
def test_hostcolor():
    raw = u'zaibon.ansible.com'
    stats = {'ok': 0, u'failures': 0, u'changed': 0, u'unreachable': 0, u'skipped': 0}
    print(hostcolor(raw, stats, True))


# Generated at 2022-06-25 12:52:19.107625
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures':0,'unreachable':0,'changed':0}

# Generated at 2022-06-25 12:52:23.541812
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = 'hostname'
    var_1 = dict()
    var_1['changed'] = 0
    var_1['unreachable'] = 0
    var_1['failures'] = 0
    var_2 = True
    hostcolor(var_0,var_1,var_2)


# Generated at 2022-06-25 12:52:31.160731
# Unit test for function parsecolor
def test_parsecolor():
    var_1 = None
    bytes_0 = None
    var_0 = parsecolor(bytes_0)
    assert(var_0 == var_1)
    bytes_1 = 'color1'
    var_2 = parsecolor(bytes_1)
    assert(var_2 == 38)
    bytes_2 = 'color0'
    var_3 = parsecolor(bytes_2)
    assert(var_3 == 30)
    bytes_3 = 'color7'
    var_4 = parsecolor(bytes_3)
    assert(var_4 == 37)
    bytes_4 = 'color8'
    var_5 = parsecolor(bytes_4)
    assert(var_5 == 38)
    bytes_5 = 'color15'
    var_6 = parsecolor(bytes_5)

# Generated at 2022-06-25 12:52:37.588051
# Unit test for function stringc
def test_stringc():
    text_0 = None
    color_0 = None
    wrap_nonvisible_chars_0 = None
    ansible_str = stringc(text=text_0, color=color_0, wrap_nonvisible_chars=wrap_nonvisible_chars_0)
    c_str = u'\033[0m\n'
    assert ansible_str == c_str, "Actual: {0} but Expected: {1}".format(repr(ansible_str), repr(c_str))

    text_1 = None
    color_1 = None
    wrap_nonvisible_chars_1 = None
    ansible_str = stringc(text=text_1, color=color_1, wrap_nonvisible_chars=wrap_nonvisible_chars_1)
    c_str = u

# Generated at 2022-06-25 12:52:39.210726
# Unit test for function hostcolor
def test_hostcolor():
    hostname = "localhost"
    stats = {}
    hostcolor(hostname, stats)


# Generated at 2022-06-25 12:52:49.614574
# Unit test for function hostcolor
def test_hostcolor():

    # Define a function or method to which to pass the generated
    # string test data. The data must be in the form of a string
    # or list of strings.

    def test_function(data):
        print("%s" % data)
        return

    # Define a class instance to which to pass the generated
    # string test data. The data must be in the form of a string
    # or list of strings.

    class TestClass():
        def __init__(self):
            return
        def test_function(self, data):
            print("%s" % data)
            return

    # Define the dictionary of test data.

    test_data = {}
    test_data['strings'] = []
    test_data['strings'].append("")
    test_data['strings'].append("0")
    test_

# Generated at 2022-06-25 12:52:51.986220
# Unit test for function parsecolor
def test_parsecolor():
    print(">>> test_parsecolor()")

    try:
        test_case_0()
    except Exception as var_2:
        print(var_2)


# Generated at 2022-06-25 12:53:11.253798
# Unit test for function stringc
def test_stringc():
    print(stringc(u"This is normal.", u"green"))
    # \n that's an escape sequence, as far as %s interpreter is concerned
    print(stringc(u"This is normal.\n", u"green"))
    # print(stringc(u"This is normal.\n", u"green", wrap_nonvisible_chars=True))
    print(stringc(u"This is normal.\nwith newline\n", u"green"))
    print(stringc(u"\nThis is normal.\nwith newline\n", u"green"))
    print(stringc(u"\nThis is normal.\nwith newline\n\tindent\t\t", u"green"))

# Generated at 2022-06-25 12:53:13.895529
# Unit test for function colorize
def test_colorize():
    lead, num, color = ('lead', 0, 'red')
    output = colorize(lead, num, color)
    assert 'lead=0' in output


# Generated at 2022-06-25 12:53:21.127620
# Unit test for function parsecolor
def test_parsecolor():
    # print("Running test_parsecolor...")
    # Establish that parsecolor returns the same value for String and Unicode
    assert parsecolor('blue') == parsecolor(u'blue')
    # Check multiple valid inputs
    assert parsecolor('blue') == u'34'
    assert parsecolor('color34') == u'38;5;34'
    assert parsecolor('rgb222') == u'38;5;60'
    assert parsecolor('gray25') == u'38;5;250'
    assert parsecolor('rgb000') == u'38;5;16'
    # Check invalid inputs
    assert parsecolor('rgb2220') == C.COLOR_CODES['default']
    assert parsecolor('rgb220') == C.COLOR_CODES['default']
   

# Generated at 2022-06-25 12:53:32.598379
# Unit test for function parsecolor

# Generated at 2022-06-25 12:53:37.478162
# Unit test for function stringc
def test_stringc():
    a = stringc('', 'red')
    assert re.match(r'^\u001b\[31m\u001b\[0m$', a)
    a = stringc('', 'blue')
    assert re.match(r'^\u001b\[34m\u001b\[0m$', a)


# Generated at 2022-06-25 12:53:38.677671
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(color='red') == '31'


# Generated at 2022-06-25 12:53:42.035668
# Unit test for function colorize
def test_colorize():
    args = {}
    args['lead'] = 'lead'
    args['num'] = 1
    args['color'] = 'color'

    # Calling the function
    result = colorize(**args)
    print(result)

if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-25 12:53:51.996769
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = parsecolor('fg-red')
    str_1 = parsecolor('fg-cyan')
    str_2 = parsecolor('fg-white')
    str_3 = parsecolor('fg-bright-white')
    str_4 = parsecolor('fg-blue')
    str_5 = parsecolor('fg-bright-blue')
    str_6 = parsecolor('fg-yellow')
    str_7 = parsecolor('fg-bright-yellow')
    str_8 = parsecolor('fg-magenta')
    str_9 = parsecolor('fg-bright-magenta')
    str_10 = parsecolor('fg-green')
    str_11 = parsecolor('fg-bright-green')
    str_12 = parsecolor('bg-red')
    str_13

# Generated at 2022-06-25 12:54:01.491712
# Unit test for function parsecolor
def test_parsecolor():
    test_case_1 = 'color128'
    test_result_1 = parsecolor(test_case_1)
    assert test_result_1 == '38;5;128'
    test_case_2 = 'rgb555'
    test_result_2 = parsecolor(test_case_2)
    assert test_result_2 == '38;5;62'
    test_case_3 = 'gray45'
    test_result_3 = parsecolor(test_case_3)
    assert test_result_3 == '38;5;253'
    test_case_4 = 'red'
    test_result_4 = parsecolor(test_case_4)
    assert test_result_4 == '31'



# Generated at 2022-06-25 12:54:07.709636
# Unit test for function stringc
def test_stringc():
    try:
        from unittest import mock
        f = mock.mock_open(read_data="c%s" % C.COLOR_CODES[C.COLOR_ERROR])
        with mock.patch('builtins.open', f, create=True):
            assert stringc("ERROR",C.COLOR_ERROR) == '\033[%smERROR\033[0m' % C.COLOR_CODES[C.COLOR_ERROR]
    except:
        assert stringc("ERROR",C.COLOR_ERROR) == '\033[%smERROR\033[0m' % C.COLOR_CODES[C.COLOR_ERROR]


# Generated at 2022-06-25 12:54:27.296253
# Unit test for function stringc
def test_stringc():
    msg = u'Hello, world.\npython'
    print(stringc(msg, C.COLOR_ERROR))
    print(stringc(msg, C.COLOR_CHANGED))
    print(stringc(msg, C.COLOR_OK))
    print(stringc(msg, C.COLOR_SKIP))
    print(stringc(msg, C.COLOR_UNREACHABLE))
    print(stringc(msg, C.COLOR_WARN))
    print(stringc(msg, C.COLOR_DEBUG))
    print(stringc(msg, C.COLOR_VERBOSE))
    print(stringc(msg, C.COLOR_DEPRECATE))
    print(stringc(msg, C.COLOR_DEPRECATE_WARN))
    print(stringc(msg, C.COLOR_BOLD))



# Generated at 2022-06-25 12:54:32.788238
# Unit test for function hostcolor
def test_hostcolor():
    host_0 = 'ar1'
    stats_0 = {
        'unreachable': 0,
        'changed': 0,
        'failures': 0,
        'ok': 1,
        'skipped': 0}
    color_0 = True
    ans_0 = hostcolor(host_0, stats_0, color_0)
    print(ans_0)


# Generated at 2022-06-25 12:54:38.803765
# Unit test for function stringc
def test_stringc():
    # Unit test for stringc

    # Call function stringc with arguments 'test_string' and 'red'.
    # Expected return: '\x1b[38;5;196mtest_string\x1b[0m'
    assert stringc('test_string', 'red') == '\x1b[38;5;196mtest_string\x1b[0m'



# --- end "pretty"

# Generated at 2022-06-25 12:54:43.979012
# Unit test for function colorize
def test_colorize():
    assert (colorize('OK', 0, 'green') == stringc('OK=0   ', 'green'))

    assert (colorize('CHANGED', 12, 'yellow') == stringc('CHANGED=12 ', 'yellow'))

    assert (colorize('FAILED', 0, 'red') == stringc('FAILED=0  ', 'red'))


# Generated at 2022-06-25 12:54:45.960577
# Unit test for function stringc
def test_stringc():
    text = "text"
    color = "red"
    assert re.match(stringc(text, color), "\x1b\[37m")


# ---


# Generated at 2022-06-25 12:54:51.328080
# Unit test for function stringc
def test_stringc():
    global str_0
    str_0 = '%s'

    print(':::::::::::Testing function stringc')

    # Test 1
    print('\n---test 1---')
    actual_ans = stringc('testing', 'red', err_msg='test 1 failed')
    expected_ans = '\x1b[31mtesting\x1b[0m'
    if actual_ans != expected_ans:
        raise AssertionError(str_0 % ('actual output', actual_ans, 'does not match expected output', expected_ans))


# Generated at 2022-06-25 12:54:55.104829
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    ret = hostcolor(host, stats, color)
    assert 'localhost' in ret


# Generated at 2022-06-25 12:54:57.122741
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'red') == u'\033[31mtest\033[0m'


# Generated at 2022-06-25 12:55:01.380748
# Unit test for function hostcolor
def test_hostcolor():
    args = []
    if not test_case_0():
        return 'Failed test_case_0'

# Generated at 2022-06-25 12:55:06.538186
# Unit test for function hostcolor
def test_hostcolor():
    host = 'ansible'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    expected = '%-37s' % '\033[0;32mansible\033[0m'
    actual = hostcolor(host, stats, color)

    assert actual == expected, 'Expected: %s, Actual: %s' % (expected, actual)


# Generated at 2022-06-25 12:55:18.114464
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('abc', 'green')
    assert str_0 == u"\u001b[32mabc\u001b[0m"



# Generated at 2022-06-25 12:55:22.135296
# Unit test for function stringc
def test_stringc():
    log = open('test-results/test_stringc.log', 'w')
    str_0 = stringc('blank', 'red')
    log.write(str_0)
    str_1 = stringc('blank', 'green')
    log.write(str_1)
    str_2 = stringc('blank', 'blue')
    log.write(str_2)
    str_3 = stringc('blank', 'blue', True)
    log.write(str_3)
    log.close()

if __name__ == "__main__":
    test_stringc()

# Generated at 2022-06-25 12:55:24.949562
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('any string', 'blue')
    ans_0 = '\033[38;5;21m%s\033[0m'
    assert(str_0==ans_0)


# Generated at 2022-06-25 12:55:35.128458
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert(parsecolor('cyan') == u'38;5;6')
        assert(parsecolor('lightgray') == u'38;5;250')
        assert(parsecolor('rgb2315') == u'38;5;19')
        assert(parsecolor('rgb1221') == u'38;5;18')
        assert(parsecolor('rgb2052') == u'38;5;125')
        assert(parsecolor('gray7') == u'38;5;238')
        assert(parsecolor('gray0') == u'38;5;232')



# Generated at 2022-06-25 12:55:38.707355
# Unit test for function stringc
def test_stringc():
	print(stringc('test_stringc'))
	print(stringc('test_stringc','red'))
	print(stringc('test_stringc','red','test'))

if __name__ == '__main__':
	test_stringc()

# Generated at 2022-06-25 12:55:47.566481
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('', 'red')
    str_1 = stringc('', 'green', True)
    str_2 = stringc('', 'blue', True)
    str_3 = stringc('', 'cyan', True)
    str_4 = stringc('', 'magenta', True)
    str_5 = stringc('', 'yellow', True)
    str_6 = stringc('', 'brightred', True)
    str_7 = stringc('', 'brightgreen', True)
    str_8 = stringc('', 'brightblue', True)
    str_9 = stringc('', 'brightcyan', True)
    str_10 = stringc('', 'brightmagenta', True)
    str_11 = stringc('', 'brightyellow', True)

# Generated at 2022-06-25 12:55:54.228714
# Unit test for function colorize
def test_colorize():
    lead = 'key'
    num = 12
    color = 'green'
    print('Unit test for colorize:')
    print('lead = %s' % lead)
    print('num = %s' % num)
    print('color = %s' % color)
    answer = 'key=12'
    print('answer = %s' % answer)
    got = colorize(lead, num, color)
    print('got = %s' % got)
    assert(answer == got)

# Generated at 2022-06-25 12:55:58.252106
# Unit test for function hostcolor
def test_hostcolor():
    host = 'host'
    stats = {'skipped': 0, 'ok': 1, 'changed': 0, 'failures': 0, 'unreachable': 0, 'rescued': 0, 'ignored': 0}
    color = True
    result = hostcolor(host, stats, color)
    assert result == u'host                    '


# Generated at 2022-06-25 12:56:07.718138
# Unit test for function hostcolor
def test_hostcolor():
    # default args
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == 'localhost             '

    # color=True
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) != 'localhost             '

    # color=False, failures=changed=unreachable=0
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), False) == 'localhost             '

    # color=False, failures=unreachable=0, changed=1
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), False) == 'localhost             '

    # color=False, failures=changed=0, unreachable=1

# Generated at 2022-06-25 12:56:12.961876
# Unit test for function stringc
def test_stringc():
    # Check that actual == expected
    assert(stringc('hi', 'blue') == '\033[38;5;4mhi\033[0m')
    assert(stringc('hi', 'rgb000') == '\033[38;5;0mhi\033[0m')
    assert(stringc('hi', 'rgb001') == '\033[38;5;16mhi\033[0m')


# Generated at 2022-06-25 12:56:42.040302
# Unit test for function stringc
def test_stringc():
    assert type(stringc(str_0, 'explosion')) is str
    assert type(stringc(str_0, 'error')) is str
    assert type(stringc(str_0, 'failure')) is str
    assert type(stringc(str_0, 'success')) is str
    assert type(stringc(str_0, 'notice')) is str
    assert type(stringc(str_0, 'warning')) is str
    assert type(stringc(str_0, 'data')) is str
    assert type(stringc(str_0, 'changed')) is str
    assert type(stringc(str_0, 'blue')) is str
    assert type(stringc(str_0, 'green')) is str
    assert type(stringc(str_0, 'yellow')) is str

# Generated at 2022-06-25 12:56:47.582059
# Unit test for function hostcolor
def test_hostcolor():
    x = 'host0'
    y = dict(failed=0, unreachable=0, changed=1) # stats
    color = True
    assert re.match(r'^\x1b\[33m%-37s\x1b\[0m$', hostcolor(x,y,color)) is not None


# Generated at 2022-06-25 12:56:49.845341
# Unit test for function stringc
def test_stringc():
    text_0 = stringc(str_0, 'red', False)
    assert(text_0 == "\u001b[31m%s\u001b[0m")


# Generated at 2022-06-25 12:56:51.843355
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '%s'
    print(hostcolor(str_0, str_0))


# Generated at 2022-06-25 12:56:58.919076
# Unit test for function stringc
def test_stringc():
    try:
        assert stringc('test') == stringc('test', 'black')
        assert stringc('test', 'red') != stringc('test', 'black')
        assert stringc('test', 'red', True) != stringc('test', 'red')
    except Exception as e:
        print('Error: %s' % str(e))
        raise e
    else:
        print('stringc unit test successed')


# Generated at 2022-06-25 12:57:03.116299
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True

    expected = '%-37s'

    actual = hostcolor(host, stats, color)

    assert(expected == actual)


# Generated at 2022-06-25 12:57:06.088768
# Unit test for function stringc
def test_stringc():
    assert stringc(str_0,"color1") == u"\u001b[38;5;1m%s\u001b[0m"


# Generated at 2022-06-25 12:57:15.487055
# Unit test for function stringc
def test_stringc():
    assert stringc('OK', 'green') == '\033[32mOK\033[0m'
    assert stringc('OK', 'color32') == '\033[38;5;32mOK\033[0m'
    assert stringc('OK', 'rgb20000') == '\033[38;5;148mOK\033[0m'
    assert stringc('OK', 'rgb(20000)') == '\033[38;5;148mOK\033[0m'
    assert stringc('OK', 'grey0') == '\033[38;5;232mOK\033[0m'
    assert stringc('OK', 'grey1') == '\033[38;5;233mOK\033[0m'

# Generated at 2022-06-25 12:57:18.411480
# Unit test for function colorize
def test_colorize():
    print(u"Test colorize function")
    assert colorize(u'ok',4, u'blue') == u'ok=4  '
    assert colorize(u'ok',0, u'blue') == u'ok=0  '
    assert colorize(u'ok',3, u'blue') == u'ok=3  '

#Unit test for function hostcolor

# Generated at 2022-06-25 12:57:27.513529
# Unit test for function stringc
def test_stringc():
    assert '\033[%sm%s\033[0m' % (C.COLOR_CODES['black'], 'abc') == '\033[30mabc\033[0m'
    assert '\033[38;5;%dm%s\033[0m' % (16 + 36 * int(1) + 6 * int(2) + int(2), 'abc') == '\033[38;5;42mabc\033[0m'
    assert '\033[38;5;%dm%s\033[0m' % (232 + int(5), 'abc') == '\033[38;5;237mabc\033[0m'

# Generated at 2022-06-25 12:57:57.796993
# Unit test for function stringc
def test_stringc():
    str_1 = '%s'
    assert stringc(str_1, str_1, False) == stringc(str_1, str_1, False)
    str_1 = '%s'
    assert stringc(str_1, str_1, False) == stringc(str_1, str_1, False)
    str_1 = '%s'
    assert stringc(str_1, str_1, False) == stringc(str_1, str_1, False)
    str_1 = '%s'
    assert stringc(str_1, str_1, False) == stringc(str_1, str_1, False)
    str_1 = '%s'
    assert stringc(str_1, str_1, False) == stringc(str_1, str_1, False)

# Generated at 2022-06-25 12:58:07.442381
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', {'unreachable': 0, 'failures': 0, 'changed': 0}) == '%-37s'
    assert hostcolor('foo', {'unreachable': 0, 'failures': 1, 'changed': 0}) == '%-37s'
    assert hostcolor('foo', {'unreachable': 0, 'failures': 0, 'changed': 1}) == '%-37s'
    assert hostcolor('foo', {'unreachable': 1, 'failures': 0, 'changed': 0}) == '%-37s'
    assert hostcolor('foo', {'unreachable': 1, 'failures': 1, 'changed': 0}) == '%-37s'
    assert hostcolor('foo', {'unreachable': 1, 'failures': 0, 'changed': 1}) == '%-37s'
   

# Generated at 2022-06-25 12:58:11.630592
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'skipped': 0,
             'ok': 2,
             'failures': 2,
             'changed': 0,
             'unreachable': 2,
             'dark': 0,
             'processed': 6}
    assert('%-37s' % stringc(host, C.COLOR_ERROR)) == hostcolor(host, stats)


# Generated at 2022-06-25 12:58:14.893414
# Unit test for function stringc
def test_stringc():
    text_0 = 'string'
    color_0 = 'yellow'
    result_0 = stringc(text_0, color_0)


# Generated at 2022-06-25 12:58:17.467980
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == "\x1b[34mtest\x1b[0m"


# Generated at 2022-06-25 12:58:22.771492
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test'
    stats = {'changed': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0, 'ok': 0}

    hostcolor(host, stats)



# Generated at 2022-06-25 12:58:27.055671
# Unit test for function colorize
def test_colorize():
    # print(colorize('', 0,'black'))
    # print(colorize('', 1, 'black'))
    # print(colorize('', 2, 'black'))
    print(colorize('', 0, None))
    print(colorize('', 1, None))
    print(colorize('', 2, None))
    test_case_0()

# Generated at 2022-06-25 12:58:31.425934
# Unit test for function stringc
def test_stringc():
    assert stringc('%s', 'red') == '\001\033[31m\002%s\001\033[0m\002'

if __name__ == '__main__':
    test_case_0()
    test_stringc()

# Generated at 2022-06-25 12:58:42.293618
# Unit test for function stringc
def test_stringc():
    if C.ANSIBLE_FORCE_COLOR and C.ANSIBLE_NOCOLOR:
        return

    # cases
    str_0 = 'abc'

    # case
    global_var_0 = str_0
    global_var_1 = None
    global_var_2 = None
    global_var_3 = None
    global_var_4 = None
    global_var_4 = stringc(global_var_0, global_var_1, global_var_2)
    assert global_var_4 == u'\n'.join([u'\033[38;5;28mabc\033[0m'])

    # case
    global_var_0 = str_0
    global_var_1 = None
    global_var_2 = True
    global_var_3 = None
    global_

# Generated at 2022-06-25 12:58:46.272640
# Unit test for function hostcolor

# Generated at 2022-06-25 12:59:22.746749
# Unit test for function colorize
def test_colorize():
    assert colorize('abc', u'abc', 'abc') == 'abc=abc'


# Generated at 2022-06-25 12:59:30.305458
# Unit test for function stringc
def test_stringc():
    assert '\x1b[38;5;160mReached\x1b[0m' == stringc('Reached', 'RED')
    assert '\x1b[38;5;160mReached\x1b[0m\n\x1b[38;5;160mReached\x1b[0m' == stringc('Reached\nReached', 'RED')
    assert '\x1b[38;5;160m \x1b[0m' == stringc(' ', 'RED')
    assert '\x1b[38;5;7m \x1b[0m' == stringc(' ', 'LIGHTGRAY')

# Test case for function colorize

# Generated at 2022-06-25 12:59:40.684090
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('long text', 'bold red') == '\n'.join(['\033[1;31m%s\033[0m' % t for t in 'long text'.split(u'\n')])
    str_1 = stringc('long text', 'bold red', False)
    str_2 = stringc('short text', 'bold red', False)
    str_3 = stringc('long text', 'bold red', True)
    str_4 = stringc('short text', 'bold red', True)
    str_5 = stringc('long text', 'bold red', False)
    str_6 = stringc('short text', 'bold red', False)
    str_7 = stringc('long text', 'bold red', True)
    str_8 = stringc('short text', 'bold red', True)

# Generated at 2022-06-25 12:59:46.961110
# Unit test for function hostcolor
def test_hostcolor():
    host = '172.17.0.1'
    stats = {
        'unreachable': 0,
        'skipped': 0,
        'changed': 0,
        'failures': 0,
        'ok': 1
    }
    color = True
    expected = '172.17.0.1'
    result = hostcolor(host = host, stats = stats, color = color)
    assert result == expected, "Expected: "+ expected +", Actual: "+ result


# Generated at 2022-06-25 12:59:49.577059
# Unit test for function hostcolor
def test_hostcolor():
    stats = {u'changed': 1, u'failures': 1, u'ok': 1, u'unreachable': 1}
    assert hostcolor('localhost', stats) == '%-37s'


# Generated at 2022-06-25 12:59:52.432034
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    assert hostcolor(host, stats, color) == '%-26s' % stringc(host, C.COLOR_OK)


# Generated at 2022-06-25 12:59:58.367464
# Unit test for function hostcolor
def test_hostcolor():
    expected_result0 = u"%-37s" % stringc('test', u'1')
    expected_result1 = u"%-37s" % stringc('test', '0')
    expected_result2 = u"%-37s" % stringc('test', '2')
    expected_result3 = u"%-37s" % stringc('test', u'1')
    expected_result4 = u"%-37s" % stringc('test', '0')
    expected_result5 = u"%-37s" % stringc('test', '2')
    expected_result6 = u"%-37s" % stringc('test', u'1')
    expected_result7 = u"%-37s" % stringc('test', '0')

# Generated at 2022-06-25 13:00:09.205895
# Unit test for function hostcolor
def test_hostcolor():
    # Correct: hostcolor with stats and color
    test_stats = {'failures': 0, 'unreachable': 0, 'ok': 1, 'skipped': 1, 'changed': 1}
    test_host = '127.0.0.1'
    test_color = True

    assert re.match(r'^(.*)[\x1b]\[0;32m(.*)[\x1b]\[0m(.*)$', hostcolor(test_host, test_stats, test_color), re.M), "hostcolor with stats and color"

    # Correct: hostcolor with stats and no color
    test_stats = {'failures': 0, 'unreachable': 0, 'ok': 1, 'skipped': 1, 'changed': 1}
    test_host = '127.0.0.1'

# Generated at 2022-06-25 13:00:15.055913
# Unit test for function parsecolor
def test_parsecolor():
    parsecolor('black')
    parsecolor('black',)
    parsecolor('blink')
    parsecolor('blink',)
    parsecolor('blue')
    parsecolor('blue',)
    parsecolor('bold')
    parsecolor('bold',)
    parsecolor('cyan')
    parsecolor('cyan',)
    parsecolor('default')
    parsecolor('default',)
    parsecolor('dark_gray')
    parsecolor('dark_gray',)
    parsecolor('dark_grey')
    parsecolor('dark_grey',)
    parsecolor('gray')
    parsecolor('gray',)
    parsecolor('grey')
    parsecolor('grey',)
    parsecolor('green')
    parsecolor('green',)
