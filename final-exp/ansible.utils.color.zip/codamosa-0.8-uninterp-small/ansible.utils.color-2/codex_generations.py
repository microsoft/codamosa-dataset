

# Generated at 2022-06-25 12:50:26.812194
# Unit test for function stringc
def test_stringc():
    var_0 = stringc('', 'black')
    if var_0 != '\033[0m':
        print("String not match")
    var_0 = stringc('', 'red')
    if var_0 != '\033[0m':
        print("String not match")
    var_0 = stringc('', 'green')
    if var_0 != '\033[0m':
        print("String not match")
    var_0 = stringc('', 'yellow')
    if var_0 != '\033[0m':
        print("String not match")
    var_0 = stringc('', 'blue')
    if var_0 != '\033[0m':
        print("String not match")
    var_0 = stringc('', 'magenta')

# Generated at 2022-06-25 12:50:28.563448
# Unit test for function parsecolor
def test_parsecolor():
    color = 'color0'
    sgr = parsecolor(color)

    assert sgr == '38;5;0'



# Generated at 2022-06-25 12:50:34.695845
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        assert stringc('host', 'host_color') is not None
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color0').startswith('38')
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'

# Generated at 2022-06-25 12:50:40.470340
# Unit test for function colorize
def test_colorize():
    # Create some u_str
    lead = "lead"
    num = 5
    color = "red"
    # Expected outcome
    str_outcome = "\x1b[38;5;9mlead=5   \x1b[0m"
    float_outcome = -301.84
    # TODO:  This is just a test.  The colorize function itself
    # TODO:  should also be tested.

    # call function and compare with expected outcome
    result = colorize(lead, num, color)
    print(result)
    #assert result == str_outcome



# Generated at 2022-06-25 12:50:48.729900
# Unit test for function stringc

# Generated at 2022-06-25 12:50:52.980548
# Unit test for function colorize
def test_colorize():
    lead = 'testing string'
    num = 456
    color = 'red'

    expected = 'testing string=456'
    actual = colorize(lead, num, color)

    if actual != expected:
        raise Exception("test_colorize() failed, expected: " + str(expected) +
                        ", actual: " + str(actual))

# C.COLOR_ANSIBLE

# Generated at 2022-06-25 12:50:59.047701
# Unit test for function stringc
def test_stringc():
    assert stringc('bri1.com', 'green') == '\x1b[32mbri1.com\x1b[0m'
    assert stringc('bri1.com', 'color9') == '\x1b[38;5;9mbri1.com\x1b[0m'
    assert stringc('bri1.com', 'color11') == '\x1b[38;5;11mbri1.com\x1b[0m'
    assert stringc('bri1.com', 'rgb255255255') == '\x1b[38;5;15mbri1.com\x1b[0m'

# Generated at 2022-06-25 12:51:00.510751
# Unit test for function stringc
def test_stringc():
    print()
    test_case_0()

# --- end of "pretty"

# end of ansible/module_utils/color.py

# Generated at 2022-06-25 12:51:02.021966
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()

# --- end "pretty"

if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-25 12:51:06.132086
# Unit test for function colorize
def test_colorize():
    assert colorize("lupin", 20, "red") == "\x1b[38;5;1mlupin=20  \x1b[0m"
    assert colorize("lupin", 20, "blue") == "\x1b[38;5;21mlupin=20  \x1b[0m"
    assert colorize("lupin", 20, "green") == "\x1b[38;5;40mlupin=20  \x1b[0m"
    assert colorize("lupin", 20, "yellow") == "\x1b[38;5;136mlupin=20  \x1b[0m"

# Generated at 2022-06-25 12:51:15.766032
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("color1") == '38;5;1'
    assert parsecolor("rgb111") == '38;5;15'
    assert parsecolor("gray0") == '38;5;232'



# Generated at 2022-06-25 12:51:18.474921
# Unit test for function colorize
def test_colorize():
    print(colorize('lead', 0, None))  # expected to Print 'lead=0   '
    print(colorize('lead', 1, 'green'))  # expected to Print 'lead=1   '


# Generated at 2022-06-25 12:51:25.259140
# Unit test for function stringc
def test_stringc():
    with open("tests/color_tests_input.txt", "r") as file_in:
        with open("tests/color_tests_output.txt", "r") as file_out:
            for line in file_in:
                if line.strip():
                    (color, text) = line.strip().split(':', 1)
                    assert text == stringc(text, color)
            for line in file_out:
                if line.strip():
                    (color, text) = line.strip().split(':', 1)
                    assert text == stringc(text, color)


# Generated at 2022-06-25 12:51:35.832072
# Unit test for function stringc
def test_stringc():
    test_stringc_0()
    test_stringc_1()
    test_stringc_2()
    test_stringc_3()
    test_stringc_4()
    test_stringc_5()
    test_stringc_6()
    test_stringc_7()
    test_stringc_8()
    test_stringc_9()
    test_stringc_10()
    test_stringc_11()
    test_stringc_12()
    test_stringc_13()
    test_stringc_14()
    test_stringc_15()
    test_stringc_16()
    test_stringc_17()
    test_stringc_18()
    test_stringc_19()
    test_stringc_20()
    test_stringc_21()
   

# Generated at 2022-06-25 12:51:37.791903
# Unit test for function colorize
def test_colorize():
    colorize("lead" , "num", "color")


# Generated at 2022-06-25 12:51:44.029058
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo'
    stats = {'failures' : 0, 'unreachable' : 0, 'changed' : 0}

    var_1 = hostcolor(host, stats, True)
    assert var_1 == 'foo  '

    host = 'bar'
    stats = {'failures' : 0, 'unreachable' : 0, 'changed' : 0}

    var_2 = hostcolor(host, stats, False)
    assert var_2 == 'bar          '

    host = 'baz'
    stats = {'failures' : 1, 'unreachable' : 0, 'changed' : 0}

    var_3 = hostcolor(host, stats, True)
    assert var_3 == 'baz  '

    host = 'qux'

# Generated at 2022-06-25 12:51:45.577286
# Unit test for function colorize
def test_colorize():
    colorize('lead', 'num', 'color')



# Generated at 2022-06-25 12:51:48.055713
# Unit test for function colorize
def test_colorize():
    assert colorize("a", 1, "b") == "\033[38;5;196m=\033[0;00m"


# Generated at 2022-06-25 12:51:52.869987
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = dict()
    var_0['changed'] = 0
    var_0['unreachable'] = 0
    var_0['failures'] = 0
    var_1 = hostcolor('_the_host_', var_0)
    var_2 = test_case_0()
    assert var_1 == u"_the_host_                 "

test_hostcolor()


# Generated at 2022-06-25 12:51:59.385674
# Unit test for function colorize
def test_colorize():
    assert colorize(1, 2, 10) == '1=2   '
    assert colorize(1, '10', 10) == '1=10  '
    assert colorize(1, '100', 10) == '1=100 '
    assert colorize(1, '1000', 10) == '1=1000'
    assert colorize(1, '10000', 10) == '1=10000'


# Generated at 2022-06-25 12:52:11.886324
# Unit test for function stringc
def test_stringc():
    var_0 = stringc('foo', 'black')
    assert var_0 == '\x1b[30mfoo\x1b[0m'
    var_0 = stringc('foo', 'cyan')
    assert var_0 == '\x1b[36mfoo\x1b[0m'
    var_0 = stringc('foo', 'red')
    assert var_0 == '\x1b[31mfoo\x1b[0m'
    var_0 = stringc('foo', 'green')
    assert var_0 == '\x1b[32mfoo\x1b[0m'


# Generated at 2022-06-25 12:52:14.885329
# Unit test for function colorize
def test_colorize():
    print('Test function colorize')
    #
    # colorize(lead, num, color)
    #
    #
    lead = 'lead'
    num = 5
    color = None
    assert colorize(lead, num, color) == "lead=5   "


# Generated at 2022-06-25 12:52:18.925809
# Unit test for function hostcolor
def test_hostcolor():
    var_1 = {}
    var_1['failures'] = 0
    var_1['unreachable'] = 0
    var_1['changed'] = 0
    var_2 = hostcolor("127.0.0.1", var_1, False)
    assert var_2 == "%-26s"
    print("Test case 0 passed!")

test_case_0()
test_hostcolor()

# Generated at 2022-06-25 12:52:25.017153
# Unit test for function stringc
def test_stringc():
    # Check correct behavior for green text
    assert stringc("Example", "green") == u"\033[32mExample\033[0m"
    # Check correct behavior for gray text
    assert stringc("Example", "gray5") == u"\033[38;5;245mExample\033[0m"
    # Check correct behavior for red text
    assert stringc("Example", "rgb255111") == u"\033[38;5;196mExample\033[0m"


# Generated at 2022-06-25 12:52:27.764546
# Unit test for function stringc
def test_stringc():
    var_0 = stringc(text='Test text', color='green', wrap_nonvisible_chars=False)
    var_1 = stringc(text='Test text', color='red', wrap_nonvisible_chars=True)


# Generated at 2022-06-25 12:52:30.584716
# Unit test for function stringc
def test_stringc():
    var_0 = stringc("test", color="red", wrap_nonvisible_chars=True)
    var_1 = sgr_codec(u'\033[%sm%s\033[0m', var_color=color_code(color="red"))
    assert var_0 == var_1


# Generated at 2022-06-25 12:52:37.216662
# Unit test for function hostcolor
def test_hostcolor():
    stats = {"failures": 0, "changed": 0, "unreachable": 0}
    host = "Raspi"
    color = True

    assert(hostcolor(host, stats, color) == "%-37s" % stringc("Raspi", C.COLOR_OK))

    stats = {"failures": 1, "changed": 0, "unreachable": 0}
    assert(hostcolor(host, stats, color) == "%-37s" % stringc("Raspi", C.COLOR_ERROR))

    stats = {"failures": 0, "changed": 1, "unreachable": 0}
    assert(hostcolor(host, stats, color) == "%-37s" % stringc("Raspi", C.COLOR_CHANGED))


# Generated at 2022-06-25 12:52:40.549589
# Unit test for function hostcolor
def test_hostcolor():
    result1 = hostcolor("host", {"failures":0, "unreachable":0, "changed":0}, True)
    assert result1 == "%-37s" % stringc("host", C.COLOR_OK)


# Generated at 2022-06-25 12:52:44.011074
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("color2") == u"38;5;2"
    assert parsecolor("rgb212") == u"38;5;136"
    assert parsecolor("gray5") == u"38;5;237"


# Generated at 2022-06-25 12:52:48.387566
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {"failures": 0, "unreachable": 0, "changed": 0}
    color = True
    assert "%-37s" % host == hostcolor(host, stats, color), "Hostcolor test case 0 failed"
    var_0 = print()



# Generated at 2022-06-25 12:52:59.076066
# Unit test for function hostcolor
def test_hostcolor():
    # Run hostcolor on valid inputs
    try:
        # Test case 0
        host = u''
        stats = {}
        color = True
        expected_result = "%-26s" % host
        actual_result = hostcolor(host, stats, color)
        assert actual_result == expected_result
    except Exception as e:
        print('FAILED: test_hostcolor()')
        print(e)
        raise
    else:
        print('PASSED: test_hostcolor()')
# --- end "pretty"



# Generated at 2022-06-25 12:53:01.236464
# Unit test for function colorize
def test_colorize():
    assert colorize("lead", "4", color=None) == "lead=4   "
    print(colorize("lead", "4", color=None))



# Generated at 2022-06-25 12:53:03.079856
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost__123', {'changed': 1, 'failures': 1, 'unreachable': 1}, True) == u'localhost__123                 '

# Generated at 2022-06-25 12:53:07.645795
# Unit test for function colorize
def test_colorize():
    try:
        # If an exception is thrown, the test failed.
        test_case_0()
    except Exception:
        import traceback
        error = traceback.format_exc()
        print(error)
        assert False
    # If the test passed, the function returns nothing.
    else:
        assert True


# Generated at 2022-06-25 12:53:10.346090
# Unit test for function stringc
def test_stringc():
    data, str_expected = 'red', u"\033[31mred\033[0m"
    str_result = stringc(data, 'red')
    assert (str_result == str_expected)


# Generated at 2022-06-25 12:53:18.498776
# Unit test for function stringc
def test_stringc():
    assert stringc('no color', 'none') == u'no color'
    assert stringc('no color', 'none', True) == u'\x01\x1b[0m\x02no color\x01\x1b[0m\x02'
    assert stringc('no color', 'none', False) == u'no color'
    assert stringc('color', 'blue') == u'\x1b[94mcolor\x1b[0m'
    assert stringc('color', 'blue', True) == u'\x01\x1b[94m\x02color\x01\x1b[0m\x02'
    assert stringc('color', 'blue', False) == u'\x1b[94mcolor\x1b[0m'

# Generated at 2022-06-25 12:53:22.942676
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('ansible', {'failures':0,'unreachable':0,'changed':1},color=True))
    # ANSIBLE_COLOR=False
    hostcolor('ansible', {'failures':0,'unreachable':0,'changed':1})

if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:53:29.173294
# Unit test for function hostcolor
def test_hostcolor():
    h = 'localhost'
    stats = {'failures': 1, 'unreachable': 2, 'changed': 3, 'ok': 4}

    # Execute the function under test
    hostcolor(h, stats)

if __name__ == "__main__":
    test_hostcolor()

# Generated at 2022-06-25 12:53:31.117179
# Unit test for function colorize
def test_colorize():
    var_0 = colorize('test', 0, None)
    assert var_0 == "test=0   "


# Generated at 2022-06-25 12:53:32.804768
# Unit test for function stringc
def test_stringc():
    print(stringc('test string', 'red'))

# Generated at 2022-06-25 12:53:40.491915
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert parsecolor('RED') == '31'
        assert parsecolor('color21') == '38;5;21'
        assert parsecolor('rgb501') == '38;5;19'
        assert parsecolor('gray9') == '38;5;240'

# Generated at 2022-06-25 12:53:41.929290
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = test_case_0()
    print (hostcolor(var_0))



# Generated at 2022-06-25 12:53:51.861244
# Unit test for function stringc
def test_stringc():
    pass
    # '''
    # Tests for function stringc
    # '''
    # try:
    #     from unittest import mock
    # except ImportError:
    #     import mock

    # # -- begin: Unit test mock ------------------------------------------------
    # # mock param parsecolor
    # # mock param color_code
    # # mock param fmt
    # # mock param ansible_color
    # # mock param text
    # # mock param color
    # # mock param wrap_nonvisible_chars
    # # mock return parsecolor
    # def mock_ansible_parsecolor(text):
    #     call_str = 'ansible.utils.color.ansible_parsecolor(%s)' % ( text )
    #     return call_str

    # # mock return color_code
    # def mock_

# Generated at 2022-06-25 12:53:56.431392
# Unit test for function colorize
def test_colorize():
    print(colorize("a",20,"green"));
    print(colorize("b",20,"blue"));
    print(colorize("c",20,"yellow"));
    print(colorize("d",20,"red"));
    print(colorize("e",20,"magenta"));


# Generated at 2022-06-25 12:54:01.304798
# Unit test for function stringc
def test_stringc():
    print("Test stringc")
    text = 'Test\nString\n'
    color = 'red'
    expect = '\x1b[31mTest\nString\n\x1b[0m'
    res = stringc(text, color, False)
    if res == expect:
        print("Test passed")
    else:
        print("Test failed")


# Main method

# Generated at 2022-06-25 12:54:04.386839
# Unit test for function colorize
def test_colorize():
    #assert_true( colorize( 'test', '3' ), 'test=3   ' )
    #assert_true( colorize( 'test', '3', '/tmp/test' ), 'test=3   ' )
    test_case_0()


# Generated at 2022-06-25 12:54:09.699255
# Unit test for function colorize
def test_colorize():
    check_equal(u'failures=1  ', colorize(u'failures', 1, u'yellow'))
    check_equal(u'found=0     ', colorize(u'found', 0, u'cyan'))
    check_equal(u'changed=2   ', colorize(u'changed', 2, u'green'))
    check_equal(u'Unreachable=3', colorize(u'Unreachable', 3, u'red'))
    check_equal(u'ok=4        ', colorize(u'ok', 4, u'blue'))


# Generated at 2022-06-25 12:54:14.443926
# Unit test for function hostcolor
def test_hostcolor():
    var_1 = {
        'unreachable': 0,
        'failures': 0,
        'changed': 0,
        'ok': 2
    }

    var_2 = hostcolor('raspberrypi', var_1)
    assert(type(var_2) == str)
    assert(var_2 == 'raspberrypi                 ')


# Generated at 2022-06-25 12:54:25.353598
# Unit test for function hostcolor

# Generated at 2022-06-25 12:54:33.682714
# Unit test for function hostcolor

# Generated at 2022-06-25 12:54:43.538147
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 1, 'unreachable': 2, 'ok': 1, 'changed': 0}
    color = True
    result = hostcolor(host, stats, color)
    assert result == stringc(host, C.COLOR_ERROR)


if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:54:50.559568
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', stats={
        'failures': 0,
        'unreachable': 0,
        'changed': 0
    }) == u'foo                             '
    assert hostcolor('foo', stats={
        'failures': 0,
        'unreachable': 0,
        'changed': 1
    }) == u'\n'.join([
        u'\033[0;34mfoo                  \033[0m',
        u'\033[0;34m                 \033[0m'
    ])

# Generated at 2022-06-25 12:54:51.824561
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(str_0, var_0) == u'color0'


# Generated at 2022-06-25 12:55:03.448878
# Unit test for function hostcolor
def test_hostcolor():
    assert(ANSIBLE_COLOR == True)
    host_0 = 'localhost'
    stats_0 = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    var_0 = hostcolor(host_0, stats_0)
    assert(var_0 == u'localhost                    ')

    stats_1 = {'changed': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    var_1 = hostcolor(host_0, stats_1)
    assert(var_1 == u'\nlocalhost\033[32m                    \033[0m')


# Generated at 2022-06-25 12:55:06.961891
# Unit test for function stringc
def test_stringc():
    str_0 = 'color0'
    var_0 = stringc(str_0, 'good')
    if var_0 != u'\n\033[38;5;2mcolor0\033[0m':
        raise Exception('test_stringc_0 failed')



# Generated at 2022-06-25 12:55:09.571844
# Unit test for function stringc
def test_stringc():
    # Testing stringc function
    result_var_2 = stringc(str_0, var_0)
    assert result_var_2 == result_var_2


# Generated at 2022-06-25 12:55:11.962586
# Unit test for function hostcolor
def test_hostcolor():
    import random

    for i in range(100):
        stats = {
            'failures': random.randint(0, 1),
            'unreachable': random.randint(0, 1),
            'changed': random.randint(0, 1)
        }
        hostcolor(str(i), stats)

if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-25 12:55:13.044451
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo'
    stats = {'changed': 1}
    color = True
    s = hostcolor(host, stats, color)
    print(s)


# Generated at 2022-06-25 12:55:19.008693
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'str_0'
    dict_0 = dict()
    dict_0['failed'] = 0
    dict_0['skipped'] = 0
    dict_0['ok'] = 0
    dict_0['changed'] = 0
    output = hostcolor(str_0,dict_0,True)

    str_0 = 'str_0'
    dict_0 = dict()
    dict_0['failed'] = 0
    dict_0['skipped'] = 0
    dict_0['ok'] = 0
    dict_0['changed'] = 1
    output = hostcolor(str_0,dict_0,True)

    str_0 = 'str_0'
    dict_0 = dict()
    dict_0['failed'] = 0
    dict_0['skipped'] = 0

# Generated at 2022-06-25 12:55:20.174842
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(str_0, var_0) == var_0


# Generated at 2022-06-25 12:55:39.611946
# Unit test for function stringc
def test_stringc():
	str_0 = 'color0'
	str_1 = 'color99'
	str_2 = 'rgb123'
	str_3 = 'rgb45'
	str_4 = 'rgb11112'
	str_5 = 'rgb22212'
	str_6 = 'rgb333'
	str_7 = 'rgb444'
	str_8 = 'rgb555'
	str_9 = 'rgb666'
	str_10 = 'rgb777'
	str_11 = 'gray0'
	str_12 = 'gray8'
	bool_0 = ANSIBLE_COLOR
	var_0 = parsecolor(str_0)
	var_1 = parsecolor(str_1)
	var_2 = parsecolor(str_2)

# Generated at 2022-06-25 12:55:42.894539
# Unit test for function stringc
def test_stringc():
    # Expected result of the unit test
    expected_result = '\033[38;5;208mtest\033[0m'
    # Run the unit test
    result = stringc("test", "pink")
    # Test if the result is as expected
    assert result == expected_result

# Generated at 2022-06-25 12:55:54.387263
# Unit test for function hostcolor

# Generated at 2022-06-25 12:55:56.620418
# Unit test for function stringc
def test_stringc():
    str_0 = 'color1'
    str_1 = 'color2'
    var_0 = stringc(str_0, str_1)


# Generated at 2022-06-25 12:55:59.666272
# Unit test for function stringc
def test_stringc():
    var_1 = stringc('test case 1', 'red')
    print(var_1)
    var_2 = stringc('test case 2', 'green')
    print(var_2)



# Generated at 2022-06-25 12:56:01.491878
# Unit test for function colorize
def test_colorize():
    lead = 'a'
    num = 2
    color = None
    var_0 = colorize(lead, num, color)


# Generated at 2022-06-25 12:56:05.593009
# Unit test for function colorize
def test_colorize():
    str_0 = 'changed'
    var_0 = colorize('some_prefix', 1, str_0)
    x = stringc('some_prefix=1', 'changed')
    assert var_0 == 'some_prefix=1  '


# End of file
# vim:set et sts=4 ts=4 tw=80:

# Generated at 2022-06-25 12:56:10.028681
# Unit test for function stringc
def test_stringc():
    str_0 = 'color0'
    str_1 = 'rgb555'
    str_2 = 'gray9'
    str_3 = 'color0'
    var_0 = stringc(str_1, str_2, True)
    var_1 = stringc(str_3, str_2, False)


# --- end "pretty"

# Generated at 2022-06-25 12:56:15.358962
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo'
    stats = {'ignored': 0, 'skipped': 0, 'changed': 0, 'failures': 0, 'ok': 0, 'unreachable': 0}
    var_color = True
    var_0 = hostcolor(host, stats, var_color)

    var_color = False
    var_1 = hostcolor(host, stats, var_color)


# Generated at 2022-06-25 12:56:19.490127
# Unit test for function colorize
def test_colorize():
    lead = 'color'
    num = 0
    color = 'color'
    str_0 = colorize(lead, num, color)
    assert(str_0 == u'color=0   ')


# Generated at 2022-06-25 12:56:37.012543
# Unit test for function colorize

# Generated at 2022-06-25 12:56:42.348538
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    dict_0 = dict()
    dict_0['failures'] = 0
    dict_0['unreachable'] = 0
    dict_0['changed'] = 0
    var_0 = hostcolor(str_0, dict_0)
    print(var_0)


# Generated at 2022-06-25 12:56:51.335551
# Unit test for function colorize
def test_colorize():
    print(colorize(u'ok', 0, C.COLOR_OK))
    print(colorize(u'changed', 0, C.COLOR_CHANGED))
    print(colorize(u'unreachable', 0, C.COLOR_UNREACHABLE))
    print(colorize(u'failed', 0, C.COLOR_ERROR))
    print(colorize(u'ok', 5, C.COLOR_OK))
    print(colorize(u'changed', 5, C.COLOR_CHANGED))
    print(colorize(u'unreachable', 5, C.COLOR_UNREACHABLE))
    print(colorize(u'failed', 5, C.COLOR_ERROR))



# Generated at 2022-06-25 12:56:53.416810
# Unit test for function hostcolor
def test_hostcolor():
    assert isinstance(hostcolor("foo", dict(changed=0, skipped=0, unreachable=0, failures=0)), unicode)



# Generated at 2022-06-25 12:57:00.570798
# Unit test for function stringc
def test_stringc():
    str_0 = 'color38'
    str_1 = '1'
    str_2 = '2'
    str_3 = '3'
    var_0 = stringc(str_2, str_3)
    var_1 = stringc(str_1, str_0)
    var_2 = stringc(str_0, str_1)
    var_3 = stringc(str_2, str_1)
    var_4 = stringc(str_3, str_0)


# Generated at 2022-06-25 12:57:11.773238
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '127.0.0.1'
    dict_0 = {'unreachable': 0, 'ok': 0, 'skipped': 0, 'changed': 0, 'failures': 0}
    str_1 = hostcolor(str_0, dict_0)
    assert str_1 == u'127.0.0.1                     '

    str_2 = 'example.com'
    dict_1 = {'skipped': 0, 'unreachable': 0, 'ok': 0, 'failures': 0, 'changed': 1}
    str_3 = hostcolor(str_2, dict_1)

# Generated at 2022-06-25 12:57:15.010062
# Unit test for function hostcolor
def test_hostcolor():
    cmd = hostcolor('localhost', dict(changed=0, unreachable=0, failures=1))
    assert re.match('.*\x1b\[(\d*;){0,5}\d+mlocalhost\x1b\[0m', cmd)



# Generated at 2022-06-25 12:57:21.671586
# Unit test for function stringc
def test_stringc():
    str_0 = 'color0'
    # str_1 = 'color1'
    # str_2 = 'rgb255'
    # str_3 = 'rgb000'
    # str_4 = 'rgb555'
    # str_5 = 'rgb035'
    # str_6 = 'gray0'
    # str_7 = 'gray7'
    # str_8 = 'blah'
    b = stringc(str_0, str_0)
    # b = stringc(str_1, str_1)
    # b = stringc(str_2, str_2)
    # b = stringc(str_3, str_3)
    # b = stringc(str_4, str_4)
    # b = stringc(str_5, str_5)
    #

# Generated at 2022-06-25 12:57:23.501151
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', {'failures': 1, 'unreachable': 0, 'changed': 1, 'skipped': 0}, True) == ''



# Generated at 2022-06-25 12:57:33.958222
# Unit test for function colorize
def test_colorize():
    '''
    The function from file colorize.py can be used to print different colors
    in the console. To print a string, the syntax is:
        colorize.colorize(lead, number, color)
    The lead is the string that appears before the number. The number,
    is a string which can be converted to a number. The color is a string,
    which defines the color, or shade of color, that the number will be.
    The colors are defined in the colors.py file.
    
    The following test will generate a string that represents the
    string "failures = 1", but in Red. This is useful when printing an error,
    and you want the word "failures" and the number "1" to be printed in red
    '''
    return colorize("failures", str(1), C.COLOR_ERROR)



# Generated at 2022-06-25 12:57:53.603408
# Unit test for function colorize
def test_colorize():
    # Testing str_0
    test_str_0 = 'changed'
    test_num_0 = 0
    test_b_0 = True
    test_str_1 = 'changed'
    test_num_1 = 0
    test_b_1 = False
    test_str_2 = 'changed'
    test_num_2 = 1
    test_b_2 = False
    test_str_3 = 'changed'
    test_num_3 = 1
    test_b_3 = True
    test_str_4 = 'changed'
    test_num_4 = 26
    test_b_4 = False
    test_str_5 = 'changed'
    test_num_5 = 26
    test_b_5 = True
    test_str_6 = 'changed'

# Generated at 2022-06-25 12:57:57.710730
# Unit test for function stringc
def test_stringc():
    host = 'host'
    color = 'color'
    str_0 = 'str_0'
    wrap_nonvisible_chars = True
    var_0 = stringc(str_0, color, wrap_nonvisible_chars)


# Generated at 2022-06-25 12:58:02.898054
# Unit test for function stringc
def test_stringc():
    # test case
    str_0 = 'color0'
    var_0 = parsecolor(str_0)
    str_1 = 'Hello World!'
    var_1 = stringc(str_1, var_0)
    # assert_equal is a tool function
    assert_equal(var_1, u'\033[38;5;16mHello World!\033[0m', 'stringc() test case 0 failed')


# Generated at 2022-06-25 12:58:07.173520
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'color0'
    var_0 = parsecolor(str_0)
    host_0 = 'color0'
    stats_0 = dict(failures=0, unreachable=0, changed=0)
    var_1 = hostcolor(host_0, stats_0, color=var_0)

# Generated at 2022-06-25 12:58:14.718314
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test'
    stats1 = {'ok': 1, 'failures': 1, 'unreachable': 0, 'changed': 0}
    stats2 = {'ok': 1, 'failures': 0, 'unreachable': 1, 'changed': 0}
    stats3 = {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 1}
    stats4 = {'ok': 1, 'failures': 0, 'unreachable': 0, 'changed': 0}
    test_0 = hostcolor(host, stats1, True)
    test_1 = hostcolor(host, stats2, True)
    test_2 = hostcolor(host, stats3, True)
    test_3 = hostcolor(host, stats4, True)
    pass

# Generated at 2022-06-25 12:58:19.926424
# Unit test for function hostcolor
def test_hostcolor():
    # color=True
    str_0 = 'str_0'
    dict_0 = {'failures': 0, 'changed': 0, 'unreachable': 0}
    var_0 = hostcolor(str_0, dict_0)
    # color=False
    var_1 = hostcolor(str_0, dict_0, False)


# Generated at 2022-06-25 12:58:24.935085
# Unit test for function colorize
def test_colorize():
    str_0 = 'color0'
    int_0 = 0
    var_0 = colorize('lead', int_0, str_0)
    assert var_0 is not None
    assert str(var_0.__class__) == "<class 'ansible.utils.unicode.utf8'>"
    assert var_0 == 'lead=0   '


# Generated at 2022-06-25 12:58:32.691446
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'foo'
    dict_0 = {'unreachable': 0, 'failures': 0, 'skipped': 0, 'ok': 1, 'changed': 0, 'rescued': 0, 'ignored': 0, 'processed': 0}
    var_0 = hostcolor(str_0, dict_0)
    # assert var_0 == 'foo                          '
    var_1 = hostcolor(str_0, dict_0, color=False)
    assert var_1 == 'foo                         '

# Test function stringc

# Generated at 2022-06-25 12:58:42.964582
# Unit test for function hostcolor
def test_hostcolor():

    # When ANSIBLE_COLOR is True, hostcolor should be
    # prefixed with a color code and should return a
    # string with 27 characters
    ANSIBLE_COLOR = True
    host = 'example.com'
    stats = {
        'failures': 0,
        'changed': 0,
        'unreachable': 0,
    }
    color = True
    ref = u"%s%-37s" % ('\x1b[0;32m', host)
    s = hostcolor(host, stats, color)
    assert s == ref
    assert len(s) == 27
    s = hostcolor(host, stats, color)
    assert s == ref
    assert len(s) == 27

    # When ANSIBLE_COLOR is False, hostcolor should
    # return a string with 26 characters
    AN

# Generated at 2022-06-25 12:58:47.272618
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'ABCDEFG'
    dict_0 = {'unreachable': 0, 'failures': 0, 'ok': 0, 'skipped': 0,
              'changed': 0}
    int_0 = len(str_0)

    var_0 = hostcolor(str_0, dict_0)

    assert var_0 == "%-37s" % str_0


# Generated at 2022-06-25 12:59:06.236783
# Unit test for function stringc
def test_stringc():
    str_0 = 'color0'
    str_1 = stringc(str_0, 'color0')


# Generated at 2022-06-25 12:59:08.771835
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'test'
    var_0 = {'failures': 0, 'skipped': 0, 'ok': 1, 'unreachable': 1}
    var_1 = hostcolor(str_0, var_0)
    print(var_1)


# Generated at 2022-06-25 12:59:09.901741
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == u"lead=num "


# Generated at 2022-06-25 12:59:19.535411
# Unit test for function hostcolor
def test_hostcolor():
    # Set for testing
    args = {}
    args['host'] = u'node0'
    args['stats'] = {}
    args['stats']['failures'] = 0
    args['stats']['unreachable'] = 0
    args['stats']['changed'] = 0
    assert hostcolor(**args) == u'node0                 '

    args = {}
    args['host'] = u'node1'
    args['stats'] = {}
    args['stats']['failures'] = 1
    args['stats']['unreachable'] = 0
    args['stats']['changed'] = 0

# Generated at 2022-06-25 12:59:22.540620
# Unit test for function stringc
def test_stringc():
    str_0 = 'color0'
    str_1 = u'38;5;0'
    var_0 = stringc(str_0, 'color0')
    var_1 = stringc(str_0, str_1)


# Generated at 2022-06-25 12:59:27.933172
# Unit test for function hostcolor
def test_hostcolor():
    host, stats, color = '192.168.1.1', {}, True

    str_0 = hostcolor(host, stats, color)

    try:
        assert str_0 == u"%-37s" % stringc(host, C.COLOR_OK)
    except AssertionError:
        print("AssertionError: assert str_0 == u\"%-37s\" % stringc(host, C.COLOR_OK)")
        test_hostcolor()


# Generated at 2022-06-25 12:59:35.811007
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'color0'
    str_1 = 'color0'
    str_2 = 'color0'
    str_3 = 'color0'
    var_0 = parsecolor(str_0)
    var_1 = parsecolor(str_1)
    var_2 = parsecolor(str_2)
    str_4 = 'color0'
    var_3 = parsecolor(str_3)
    str_5 = 'color0'
    var_4 = parsecolor(str_4)
    var_5 = parsecolor(str_5)



# Generated at 2022-06-25 12:59:40.927722
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'changed'
    int_0 = 0
    str_1 = 'color0'
    var_0 = {
        str_0: int_0
    }
    str_2 = 'hostcolor'
    str_3 = 'host'
    var_1 = {
        'host': str_3
    }
    var_2 = hostcolor(str_3, var_0)


# Generated at 2022-06-25 12:59:50.577192
# Unit test for function colorize
def test_colorize():
    test_cases_0 = [
    0,
    1,
    2,
    3,
    ]
    test_cases_1 = [
    0,
    1,
    2,
    3,
    ]
    test_cases_2 = [
    'color0',
    'color0',
    'color0',
    'color0',
    ]
    
    # Test function
    test_0 = colorize('lead', 0, 'color0')
    test_1 = colorize('lead', 1, 'color0')
    test_2 = colorize('lead', 2, 'color0')
    test_3 = colorize('lead', 3, 'color0')
    
    # Assertions
    assert test_0 == u'lead=0   ', 'AssertionError'
    assert test_

# Generated at 2022-06-25 12:59:57.009717
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'color1'
    str_1 = 'color2'
    var_0 = parsecolor(str_0)
    var_1 = parsecolor(str_1)
    str_3 = 'color3'
    var_3 = parsecolor(str_3)
    str_4 = 'color4'
    var_4 = parsecolor(str_4)
    str_5 = 'color5'
    var_5 = parsecolor(str_5)
    str_6 = 'color6'
    var_6 = parsecolor(str_6)
    str_7 = 'color7'
    var_7 = parsecolor(str_7)
    str_8 = 'color8'
    var_8 = parsecolor(str_8)