

# Generated at 2022-06-25 12:50:22.578442
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    tuple_0 = (0, 0, 0)
    var_0 = hostcolor(str_0, tuple_0)
    str_1 = '\x1b[0m\x1b[0m\x1b[0m'
    str_2 = '\x1b[90m\x1b[90m\x1b[90m'
    str_3 = '\x1b[0m\x1b[0m\x1b[0m'
    str_4 = '\x1b[0m\x1b[0m\x1b[0m'
    var_1 = stringc(str_0, str_1)
    var_2 = stringc(str_1, str_2)

# Generated at 2022-06-25 12:50:25.736891
# Unit test for function stringc
def test_stringc():
    assert (stringc("Hello world", color="blue") == u"\x1b[94mHello world\x1b[0m")
    assert (stringc("Hello world", color="grey") == u"\x1b[38;5;238mHello world\x1b[0m")


# Generated at 2022-06-25 12:50:32.507205
# Unit test for function stringc
def test_stringc():
    str_a = 'color'
    str_b = 'red'
    str_c = 'light red'
    str_d = 'gr'
    str_e = 'blue'
    str_f = 'color10'
    str_g = 'color11'
    str_h = 'color107'
    str_i = 'color210'
    str_j = 'color256'
    str_k = 'rgb555'
    str_l = 'rgb444'
    str_m = 'rgb235'
    str_n = 'rgb200'
    str_o = 'rgb111'
    str_p = 'rgb555'
    str_q = 'rgb000'
    str_r = 'rgb111'
    str_s = 'color0'

# Generated at 2022-06-25 12:50:39.733606
# Unit test for function parsecolor
def test_parsecolor():
    str_1 = '\t'
    str_2 = '\x06\n'
    str_3 = '\x0c^\t'


# Generated at 2022-06-25 12:50:41.878783
# Unit test for function parsecolor
def test_parsecolor():
    try:
        test_case_0()
    except AssertionError as e:
        print('Testcase #0 failed:', e)

# --- end "pretty"

# --- begin "terminal"


# Generated at 2022-06-25 12:50:43.030753
# Unit test for function parsecolor
def test_parsecolor():
    pass


# Generated at 2022-06-25 12:50:44.516473
# Unit test for function hostcolor
def test_hostcolor():
    assert ANSIBLE_COLOR
    #self.assertTrue(hostcolor(host, stats, color))


# Generated at 2022-06-25 12:50:50.280247
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    str_1 = 'y'
    dict_0 = {'dark_gray': '\033[1;30m', 'light_green': '\033[1;32m', 'light_blue': '\033[1;34m', 'light_purple': '\033[1;35m', 'white': '\033[1;37m'}
    var_0 = hostcolor(str_0, str_1, dict_0)



# Generated at 2022-06-25 12:50:57.146991
# Unit test for function hostcolor
def test_hostcolor():
    assert_equals(hostcolor(host='host', stats={'failures': 0, 'unreachable': 0, 'changed': 0}, color=True),
                  'host                 ')
    assert_equals(hostcolor(host='host', stats={'failures': 1, 'unreachable': 0, 'changed': 0}, color=True),
                  'host                 ')
    assert_equals(hostcolor(host='host', stats={'failures': 0, 'unreachable': 1, 'changed': 0}, color=True),
                  'host                 ')
    assert_equals(hostcolor(host='host', stats={'failures': 0, 'unreachable': 0, 'changed': 1}, color=True),
                  'host                 ')

# Generated at 2022-06-25 12:51:02.176460
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'changed': 0,
             'dark': 0,
             'failures': 0,
             'ok': 0,
             'processed': 0,
             'rescued': 0,
             'skipped': 0,
             'unreachable': 0}
    color = True
    ansible_color = True

    # test 1
    # host = 'localhost'
    # stats = {'changed': 0, 'dark': 0, 'failures': 0, 'ok': 0, 'processed': 0, 'rescued': 0, 'skipped': 0, 'unreachable': 0}
    # color = True
    # ansible_color = True
    result_1 = hostcolor(host, stats, color)

# Generated at 2022-06-25 12:51:14.882909
# Unit test for function colorize
def test_colorize():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False

    colorize(u'\u001b[0m', u'0', None)
    colorize(u'\u001b[0m', '-9', 'warn')
    colorize(u'\u001b[31;01m', u'0', u'\u001b[31;01m')
    colorize(u'\u001b[31;01m', u'0', 'warn')
    colorize(u'\u001b[0m', u'0', 'warn')
    colorize(u'\u001b[0m', u'0', 'warn')
    colorize(u'\u001b[0m', u'0', 'warn')

# Generated at 2022-06-25 12:51:16.670527
# Unit test for function parsecolor
def test_parsecolor():
    color_0 = parsecolor("red")
    assert type(color_0) == unicode


# Generated at 2022-06-25 12:51:19.733526
# Unit test for function hostcolor
def test_hostcolor():
    # Setup
    str_0 = u'failed=0\nchanged=0\ndarkgreen\nok=3\n\n'

    # Invocation
    var_0 = hostcolor(str_0, 0)


# Generated at 2022-06-25 12:51:23.108460
# Unit test for function colorize
def test_colorize():
    var_1 = colorize('ok', 100, C.COLOR_OK)
    var_2 = colorize('change', 101, C.COLOR_CHANGED)
    var_3 = colorize('fail', 102, C.COLOR_ERROR)

# Generated at 2022-06-25 12:51:26.519086
# Unit test for function colorize
def test_colorize():
    str_1 = u'result'
    int_1 = 0
    str_2 = u'green'
    var_0 = colorize(str_1, int_1, str_2)


# Generated at 2022-06-25 12:51:36.184453
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'changed': 0,
            'failures': 0,
            'ok': 3,
            'skipped': 0,
            'unreachable': 0
            }
    color = True
    expected = u'%-37s' % stringc(host, C.COLOR_OK)
    actual = hostcolor(host, stats, color)
    assert(actual == expected)

    host = 'localhost'
    stats = {'changed': 1,
            'failures': 0,
            'ok': 2,
            'skipped': 0,
            'unreachable': 0
            }
    color = True
    expected = u'%-37s' % stringc(host, C.COLOR_CHANGED)
    actual = hostcolor(host, stats, color)
    assert(actual == expected)

# Generated at 2022-06-25 12:51:38.954032
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = '\t'
    var_0 = parsecolor(str_0)
    assert var_0 == u'38;5;236'



# Generated at 2022-06-25 12:51:44.253363
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'testHost'
    dict_0 = {'skipped':0,'ok':1,'failures':1,'changed':0,'unreachable':0}
    var_0 = hostcolor(str_0,dict_0)


# Generated at 2022-06-25 12:51:53.774646
# Unit test for function hostcolor
def test_hostcolor():
    print("Testing hostcolor")
    # Test 1
    host = "www.google.com"
    stats = {"failures": 0, "unreachable": 0, "changed": 0}
    color = True
    print(u"Returned: %s" % hostcolor(host, stats, color))
    print(u"Expected: www.google.com")
    assert(hostcolor(host, stats, color) == u"www.google.com")

    # Test 2
    host = "www.google.com"
    stats = {"failures": 2, "unreachable": 0, "changed": 0}
    color = True
    print(u"Returned: %s" % hostcolor(host, stats, color))
    print(u"Expected: www.google.com")

# Generated at 2022-06-25 12:51:54.649486
# Unit test for function stringc
def test_stringc():
    test_case_1()
    test_case_0()


# Generated at 2022-06-25 12:52:01.022749
# Unit test for function parsecolor
def test_parsecolor():
    print(u'Testing parsecolor')
    print(u'Test case 0:')
    test_case_0()

# --- end "pretty"


#####################################################################
# END OF FILE
#####################################################################

# Generated at 2022-06-25 12:52:12.085651
# Unit test for function colorize
def test_colorize():
    str_0 = '\x1b[38;5;11mfoo\x1b[0m'
    str_1 = None
    str_2 = None
    str_3 = None
    str_4 = None
    str_5 = None
    str_6 = None
    str_7 = None
    str_8 = None
    str_9 = None
    str_10 = None
    str_11 = None
    str_12 = None
    str_13 = None
    str_14 = None
    str_15 = None
    str_16 = None
    str_17 = None
    str_18 = None
    str_19 = None
    str_20 = None
    str_21 = None
    str_22 = None
    str_23 = None
    str_24 = None
    str_25

# Generated at 2022-06-25 12:52:15.159010
# Unit test for function parsecolor
def test_parsecolor():

    # Setup test suite
    global test_case_0

    # Execute test case 0
    try:
        test_case_0()
    except:
        print("Failed test case 0")
        raise
    else:
        print("Passed test case 0")
        return 0


# Generated at 2022-06-25 12:52:18.366621
# Unit test for function stringc
def test_stringc():
    s = u'abc'
    color = u'white'
    exp = u'\x1b[37mabc\x1b[0m'
    got = stringc(s, color)
    assert got == exp, "Expected %s but got %s" % (exp, got)
# --- end

# Generated at 2022-06-25 12:52:27.375818
# Unit test for function parsecolor
def test_parsecolor():
    global ANSIBLE_COLOR
    var_0 = C.COLOR.get('color5')
    str_0 = 'color5'
    str_1 = 'color5'
    str_2 = 'color5'
    str_3 = 'color5'
    ANSIBLE_COLOR = True
    var_1 = parsecolor(str_0)
    var_2 = parsecolor(str_1)
    ANSIBLE_COLOR = False
    var_3 = parsecolor(str_2)
    ANSIBLE_COLOR = True
    var_4 = parsecolor(str_3)
    var_5 = C.COLOR.get('color0')
    str_4 = 'color0'
    str_5 = 'color0'
    str_6 = 'color0'

# Generated at 2022-06-25 12:52:29.582644
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo'
    stats = {'changed': 1, 'failures': 1, 'ok': 1, 'rescued': 0, 'skipped': 0, 'unreachable': 1}
    str_0 = hostcolor(host, stats, True)


# Generated at 2022-06-25 12:52:31.341967
# Unit test for function stringc
def test_stringc():
    test_str0 = 'a'
    test_str0_color = 'bold'
    assert stringc(test_str0, test_str0_color) == '\x1b[1ma\x1b[0m'


# Generated at 2022-06-25 12:52:43.690795
# Unit test for function hostcolor
def test_hostcolor():

    assert hostcolor(u'127.0.0.1', {u'skipped': 0, u'changed': 0, u'ok': 0, u'failures': 0}, False) == u'%-26s'
    assert hostcolor(u'127.0.0.1', {u'skipped': 0, u'changed': 0, u'ok': 0, u'failures': 0}, True) == u'%-37s'
    assert hostcolor(u'localhost', {u'skipped': 0, u'changed': 0, u'ok': 0, u'failures': 0}, False) == u'%-26s'
    assert hostcolor(u'localhost', {u'skipped': 0, u'changed': 0, u'ok': 0, u'failures': 0}, True) == u'%-37s'


# Unit

# Generated at 2022-06-25 12:52:50.065434
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('hostname', stats=None) == 'hostname'
    assert hostcolor('hostname', stats={'failures': 1}, color=False) == 'hostname'
    assert hostcolor('hostname', stats={'failures': 1}, color=True) == '\nhostname\033[0m'
    assert hostcolor('hostname', stats={'failures': 1, 'unreachable': 0}) == '\nhostname\033[0m'


# Generated at 2022-06-25 12:52:59.224558
# Unit test for function hostcolor
def test_hostcolor():
    assert u'\033[32mX\033[0m=\033[31mY\033[0m' == hostcolor(u'X', {'failures': 0, 'ok': 0, 'skipped': 0, 'changed': 0, 'unreachable': 1})
    assert u'X=1' == hostcolor(u'X', {'failures': 0, 'ok': 1, 'skipped': 0, 'changed': 0, 'unreachable': 0})
    assert u'X=2' == hostcolor(u'X', {'failures': 0, 'ok': 2, 'skipped': 0, 'changed': 0, 'unreachable': 0})

# Generated at 2022-06-25 12:53:12.621019
# Unit test for function parsecolor
def test_parsecolor():
    # Test case  argument type
    str_0 = '\t'
    # Assigning a  argument type to the variable
    var_0 = parsecolor(str_0)
    # Assigning a  argument type to the variable
    var_1 = parsecolor('0')
    # Assigning a  argument type to the variable
    var_2 = parsecolor('rgb555')
    # Assigning a  argument type to the variable
    var_3 = parsecolor('gray2')
    # Assigning a  argument type to the variable
    var_4 = parsecolor('cyan')
    # unit testing...
    assert var_0 == '9'
    assert var_1 == '38;5;16'
    assert var_2 == '38;5;229'

# Generated at 2022-06-25 12:53:17.028193
# Unit test for function hostcolor
def test_hostcolor():
    # Setup
    host = 'Compute'
    stats = {'failures': 0, 'skipped': 0, 'ok': 0, 'changed': 0, 'unreachable': 0}
    color = True
    # The expected result
    expected_result = 'Compute'
    # Run the code and check the result
    assert hostcolor(host, stats, color) == expected_result


# Generated at 2022-06-25 12:53:18.656256
# Unit test for function stringc
def test_stringc():
    str_0 = '\t'
    var_0 = stringc(str_0, color='\t')


# Generated at 2022-06-25 12:53:21.233787
# Unit test for function parsecolor
def test_parsecolor():
    print('in test_parsecolor')
    # call the function
    test_case_0()

if __name__ == '__main__':
    test_parsecolor()
else:
    pass

# Generated at 2022-06-25 12:53:32.670636
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'red'
    str_1 = 'brightred'
    str_2 = 'black'
    str_3 = 'blue'
    str_4 = 'brightblue'
    str_5 = 'cyan'
    str_6 = 'brightcyan'
    str_7 = 'green'
    str_8 = 'brightgreen'
    str_9 = 'magenta'
    str_10 = 'brightmagenta'
    str_11 = 'white'
    str_12 = 'brightwhite'
    str_13 = 'yellow'
    str_14 = 'brightyellow'
    str_15 = 'darkgray'
    str_16 = 'lightgray'
    var_0 = parsecolor(str_0)
    var_1 = parsecolor(str_1)
    var_2

# Generated at 2022-06-25 12:53:33.774831
# Unit test for function colorize
def test_colorize():
    """ Test function colorize """
    pass



# Generated at 2022-06-25 12:53:37.820451
# Unit test for function stringc
def test_stringc():
    text = 'This is a red string'
    color = 'red'
    result = stringc(text, color, wrap_nonvisible_chars=False)
    assert result == "[31mThis is a red string[0m"


# Generated at 2022-06-25 12:53:45.146246
# Unit test for function stringc
def test_stringc():
    str_0 = '\t'
    str_1 = '\n'
    str_2 = '\t'
    str_3 = '\n'
    str_4 = '\t'
    str_5 = '\n'
    str_6 = '\t'
    str_7 = '\n'
    str_8 = '\t'
    str_9 = '\n'
    str_10 = '\t'
    str_11 = '\n'
    str_12 = '\t'
    str_13 = '\n'
    str_14 = '\t'
    str_15 = '\n'
    str_16 = '\t'
    str_17 = '\n'
    str_18 = '\t'
    str_19 = '\n'

# Generated at 2022-06-25 12:53:55.173792
# Unit test for function stringc
def test_stringc():
    txt1 = u"hi there"
    txt2 = u"hi\nthere"
    exp1 = u"\033[38;5;118mhi there\033[0m"
    exp2 = u"\033[38;5;118mhi\nthere\033[0m"
    exp3 = u"\001\033[38;5;118m\002hi\nthere\001\033[0m\002"

    assert stringc(txt1, 'green') == exp1
    assert stringc(txt2, 'green') == exp2
    assert stringc(txt2, 'green', wrap_nonvisible_chars=True) == exp3
    assert stringc(txt2, 'green', wrap_nonvisible_chars=False) == exp2



# Generated at 2022-06-25 12:54:03.882530
# Unit test for function stringc
def test_stringc():
    var_1 = stringc('STRING', 'color0')
    assert var_1 == u'\033[38;5;0mSTRING\033[0m'
    var_2 = stringc('STRING', 'color1')
    assert var_2 == u'\033[38;5;1mSTRING\033[0m'
    var_3 = stringc('STRING', 'color2')
    assert var_3 == u'\033[38;5;2mSTRING\033[0m'
    var_4 = stringc('STRING', 'color3')
    assert var_4 == u'\033[38;5;3mSTRING\033[0m'
    var_5 = stringc('STRING', 'color4')

# Generated at 2022-06-25 12:54:09.599701
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue', False) == '\033[94mfoo\033[0m'


# Generated at 2022-06-25 12:54:12.628299
# Unit test for function hostcolor
def test_hostcolor():
    from ansible import constants
    from ansible.utils.color import stringc
    from ansible.utils.color import colorize
    from ansible.utils.color import hostcolor

    assert hostcolor('test', {'ok': 1}, False) == u'%-37s' % 'test'

    assert hostcolor('test', {'changed': 2, 'ok': 1}, True) == u'%-37s' % stringc('test', constants.COLOR_CHANGED)



# Generated at 2022-06-25 12:54:16.906950
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host0'
    my_dict_0 = {'changed': 3, 'failures': 2, 'unreachable': 4}
    my_bool_0 = True
    var_0 = hostcolor(str_0, my_dict_0, my_bool_0)



# Generated at 2022-06-25 12:54:27.071560
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = '\t'
    var_0 = parsecolor(str_0)
    assert u'38;5;15' == var_0, 'Expected [38;5;15], got {0}'.format(var_0)
    str_0 = '\a'
    var_0 = parsecolor(str_0)
    assert u'38;5;130' == var_0, 'Expected [38;5;130], got {0}'.format(var_0)
    str_0 = '\b'
    var_0 = parsecolor(str_0)
    assert u'38;5;0' == var_0, 'Expected [38;5;0], got {0}'.format(var_0)
    str_0 = '\n'
    var_0 = par

# Generated at 2022-06-25 12:54:29.561142
# Unit test for function colorize
def test_colorize():
    var_0 = colorize('lead', 'num', ANSIBLE_COLOR)


# Generated at 2022-06-25 12:54:41.055558
# Unit test for function colorize
def test_colorize():
    # Check for function input parameter(s)
    assert 'lead' in globals() and 'num' in globals() and 'color' in globals(),\
        "Function colorize requires 3 input parameters"
    assert True
    # Check for function colorize(lead, num, color)
    assert parsecolor(stringc('stringc',
                        hostcolor('hostcolor', {'a': 'a'}), False)) == '\033[38;5;2mstringc',\
        "Function colorize failed: have: " + parsecolor(stringc('stringc',
                        hostcolor('hostcolor', {'a': 'a'}), False)) + ", expected: " + '\033[38;5;2mstringc'
    # Check for function colorize(lead, num, color)

# Generated at 2022-06-25 12:54:42.003100
# Unit test for function parsecolor
def test_parsecolor():
    pass


# Generated at 2022-06-25 12:54:42.957582
# Unit test for function colorize
def test_colorize():
    assert True == False


# Generated at 2022-06-25 12:54:43.884597
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('unknown') == '31'


# Generated at 2022-06-25 12:54:51.610071
# Unit test for function hostcolor
def test_hostcolor():
    # Testing for no host name
    str_0 = ''
    str_1 = '\t'
    str_2 = '\t'
    rt_0 = hostcolor(str_0, str_1, str_2)
    assert rt_0 == '%-37s'

    # Testing for host name with color
    str_3 = 'fake-host'
    str_4 = {'failures': 0, 'unreachable': 0, 'changed': 0}
    rt_1 = hostcolor(str_3, str_4)
    assert rt_1 == '%-37s'

    # Testing for host name with out color
    str_5 = 'fake-host'
    str_6 = {'failures': 0, 'unreachable': 0, 'changed': 0}
    rt_2 = host

# Generated at 2022-06-25 12:55:06.606868
# Unit test for function hostcolor
def test_hostcolor():
    str_1 = u'\u001b[38;5;208m\u001b[0m\n'
    str_2 = u'\u001b[38;5;208m\u001b[0m\u001b[38;5;208m\u001b[0m\n'
    str_3 = u'\u001b[38;5;208m\u001b[0m\u001b[38;5;208m\u001b[0m\u001b[38;5;208m\u001b[0m\n'
    str_4 = u'\u001b[38;5;208m\u001b[0m\u001b[38;5;208m\u001b[0m\n'

# Generated at 2022-06-25 12:55:09.531809
# Unit test for function parsecolor
def test_parsecolor():
    try:
        test_case_0()
    except Exception as err:
        print(err)
        assert False
    else:
        assert True

# Test code
#test_parsecolor()

# Generated at 2022-06-25 12:55:11.669670
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'127.0.0.1', u'127.0.0.1') == u'127.0.0.1'


# Generated at 2022-06-25 12:55:17.479512
# Unit test for function stringc
def test_stringc():
    a = u'This is test string'
    print(stringc(a, C.COLOR_CHANGED))
    print(u'Success: test_stringc')



# Generated at 2022-06-25 12:55:19.699824
# Unit test for function parsecolor
def test_parsecolor():
    o = parsecolor('black')
    assert o == '30', 'failed test_parsecolor()'


# Generated at 2022-06-25 12:55:26.423974
# Unit test for function parsecolor
def test_parsecolor():
    # This function tests function parsecolor in an automated way.
    # It will run the function with different inputs and compare the
    # returned values with the expected values.
    # This is a test case with inputs:
    str_0 = ''
    var_0 = parsecolor(str_0)
    # The expected output for this test case:
    str_1 = '39'
    # Compare the returned values with the expected values.
    var_2 = var_0 == str_1
    # If the two values are equal, var_3 is True
    var_3 = True
    # If the values are not equal, var_3 is False.
    assert var_3 == var_2, "parsecolor() did not return the expected value."
    # This is a test case with inputs:
    str_0 = '\x000d'

# Generated at 2022-06-25 12:55:37.775125
# Unit test for function stringc
def test_stringc():
    assert stringc('\t', '\t', False) == '\n1'
    assert stringc('-', '-', False) == '\n1'
    assert stringc(',', ',', False) == '\n1'
    assert stringc('\n', '\n', False) == '\n1'
    assert stringc(':', ':', False) == '\n1'
    assert stringc('\r', '\r', False) == '\n1'
    assert stringc('\x00', '\x00', False) == '\n1'
    assert stringc('\x01', '\x01', False) == '\n1'
    assert stringc('\x02', '\x02', False) == '\n1'

# Generated at 2022-06-25 12:55:46.987455
# Unit test for function parsecolor

# Generated at 2022-06-25 12:55:51.807822
# Unit test for function colorize
def test_colorize():
    check_1 = colorize('ok', 0, 'green')
    check_1 = colorize('changed', 10, 'yellow')
    check_1 = colorize('unreachable', 0, 'red')
    check_1 = colorize('failed', 0, 'red')
    check_1 = colorize('skipped', 0, 'cyan')


# Generated at 2022-06-25 12:55:56.237933
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = '\t'
    var_0 = parsecolor(str_0)
    assert var_0 == u'38;5;14'

    str_1 = '\t'
    var_1 = parsecolor(str_1)
    assert var_1 == u'38;5;14'


# Generated at 2022-06-25 12:56:10.200096
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('\t') == '0')
    assert(parsecolor('color1') == '38;5;1')
    assert(parsecolor('color255') == '38;5;255')
    assert(parsecolor('') == '0')
    assert(parsecolor('blah') == '0')
    assert(parsecolor('rgb255255255') == '38;5;255')
    assert(parsecolor('rgb000000') == '38;5;16')
    assert(parsecolor('rgb555555') == '38;5;231')
    assert(parsecolor('rgb666666') == '38;5;232')
    assert(parsecolor('rgb333') == '38;5;18')

# Generated at 2022-06-25 12:56:20.780675
# Unit test for function colorize
def test_colorize():
    ok = colorize("ok", 22, None)
    fail = colorize("fail", 1, None)
    unreachable = colorize("unreachable", 0, None)
    changed = colorize("changed", 1, None)
    skipped = colorize("skipped", 0, None)

    if ANSIBLE_COLOR:
        assert ok == "\033[38;5;2mok=22  \033[0m"
        assert fail == "\033[38;5;9mfail=1  \033[0m"
        assert unreachable == "\033[38;5;9munreachable=0\033[0m"
        assert changed == "\033[38;5;3mchanged=1 \033[0m"
        assert skipped == "\033[38;5;2mskipped=0 \033[0m"
   

# Generated at 2022-06-25 12:56:21.610615
# Unit test for function hostcolor
def test_hostcolor():
    assert True


# Generated at 2022-06-25 12:56:25.241529
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = '\t'
    str_1 = '\t'
    str_2 = '\t'
    var_0 = parsecolor(str_0)
    var_1 = parsecolor(str_1)
    var_2 = parsecolor(str_2)



# Generated at 2022-06-25 12:56:28.499716
# Unit test for function stringc
def test_stringc():
    str_0 = '\t'
    var_0 = stringc(str_0, 'blue')
    str_1 = '\t'
    var_1 = stringc(str_1, 'blue')


# Generated at 2022-06-25 12:56:30.534462
# Unit test for function colorize
def test_colorize():
    lead = '\t'
    num = 49
    color = '\x00'
    var_0 = colorize(lead, num, color)


# Generated at 2022-06-25 12:56:33.181995
# Unit test for function stringc
def test_stringc():
    _str_0 = '\t'
    _var_0 = ANSIBLE_COLOR
    _var_1 = stringc(_str_0, _var_0)


# Generated at 2022-06-25 12:56:39.264043
# Unit test for function stringc
def test_stringc():
    var_0 = u'\u001b[31m\n\u001b[0m'
    str_0 = '\n'
    var_1 = stringc(str_0, 'red', False)
    str_1 = 'test_colorize_0'
    var_2 = stringc(str_1, 'blue', True)
    str_2 = 'test_colorize_1'
    var_3 = stringc(str_2, 'blue', True)


# Generated at 2022-06-25 12:56:50.411241
# Unit test for function hostcolor
def test_hostcolor():
    var_2 = u'localhost'
    var_3 = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    var_4 = {'changed': 0, 'failures': 1, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    var_5 = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 1}
    var_6 = {'changed': 1, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    v1 = hostcolor(var_2, var_3)
    v2 = hostcolor(var_2, var_4)

# Generated at 2022-06-25 12:57:00.893671
# Unit test for function stringc
def test_stringc():
    out_1 = 'export ANSIBLE_NOCOLOR=1'
    assert True == ANSIBLE_COLOR
    # Black
    var_1 = 'black'
    var_2 = stringc(var_1, 'black')
    assert var_2 == '\x1b[30mblack\x1b[0m'
    out_2 = "\x1b[30mblack\x1b[0m"
    out_3 = "\x1b[1mblack\x1b[0m"
    assert var_2 == out_2
    assert var_2 != out_3
    # Red
    var_3 = 'red'
    var_4 = stringc(var_3, 'red')

# Generated at 2022-06-25 12:57:09.910770
# Unit test for function colorize
def test_colorize():
    num_0 = '\n'
    num_1 = '\t'
    var_0 = colorize(num_0,num_1,False)
    num_2 = '\n'
    num_3 = '\x00'
    var_1 = colorize(num_2,num_3,False)



# Generated at 2022-06-25 12:57:15.249300
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('red') == '38;5;9')
    assert(parsecolor('dark gray') == '38;5;8')
    assert(parsecolor('red') == '38;5;9')
    assert(parsecolor('rgb234') == '38;5;89')
    assert(parsecolor('gray30') == '38;5;244')
    assert(parsecolor('xyz') == '0')



# Generated at 2022-06-25 12:57:17.366061
# Unit test for function colorize
def test_colorize():
    print(u'Testing colorize...', end=u'')

    print(u'Testcase 0', end=u'')
    test_case_0()
    print('OK')

    print(u'All testcases OK')


# Generated at 2022-06-25 12:57:18.241738
# Unit test for function colorize
def test_colorize():
    return colorize('lead', 'num', 'color')


# Generated at 2022-06-25 12:57:27.225744
# Unit test for function stringc
def test_stringc():
    str_0 = 'rgb255'
    str_1 = 'rgb000'
    str_2 = 'rgb555'
    str_3 = 'rgb015'
    str_4 = 'rgb123'
    str_5 = 'rgb666'
    str_6 = '\t'
    str_7 = 'gray0'
    str_8 = 'gray1'
    str_9 = 'gray7'
    str_10 = 'gray8'
    str_11 = 'gray23'
    str_12 = 'gray24'
    str_13 = '\t'
    str_14 = '\t'
    var_0 = stringc(str_0, str_1)
    assert var_0 is not None
    var_1 = stringc(str_0, str_2)


# Generated at 2022-06-25 12:57:28.085094
# Unit test for function stringc
def test_stringc():
    test_case_0()


# Generated at 2022-06-25 12:57:28.949190
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()



# Generated at 2022-06-25 12:57:33.258664
# Unit test for function colorize
def test_colorize():
    assert colorize('key', 'val', 'red') == '\x1b[31mkey=val\x1b[0m'
    assert colorize('key', 0, 'red') == '\x1b[31mkey=0   \x1b[0m'

if __name__ == '__main__':
    test_case_0()
    test_colorize()

# Generated at 2022-06-25 12:57:35.291409
# Unit test for function parsecolor

# Generated at 2022-06-25 12:57:38.342482
# Unit test for function parsecolor
def test_parsecolor():
    print(u"\n--> parsecolor()")
    test_case_0()
#
# --- end "pretty"

# --- begin "accessories"


# Generated at 2022-06-25 12:57:44.910062
# Unit test for function stringc
def test_stringc():
    text = 'foo'
    color = 'blue'
    var_0 = stringc(text, color)


# Generated at 2022-06-25 12:57:53.336148
# Unit test for function hostcolor
def test_hostcolor():
    # host = 'test'
    # stats = {
    #     'failures': 0,
    #     'skipped': 0,
    #     'changed': 0,
    #     'unreachable': 0,
    #     'ok': 0,
    #     'dark': 0,
    #     'processed': 0,
    #     'rescued': 0,
    # }
    # color = True
    # var_0 = hostcolor(host, stats, color)
    # assert var_0 == None
    return

# Generated at 2022-06-25 12:57:58.834535
# Unit test for function hostcolor
def test_hostcolor():
    host = 'host'
    stats = {'changed' : 0, 'failures' : 0, 'skipped' : 0, 'ok' : 1, 'unreachable' : 0, 'rescued' : 0, 'ignored' : 0}
    color = True
    assert hostcolor(host, stats) == '\x1b[38;5;40mhost              \x1b[0m'



# Generated at 2022-06-25 12:58:00.384448
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("''", "''") == "''"


# Generated at 2022-06-25 12:58:09.899852
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host='host', stats={'changed': 0, 'unreachable': 0, 'failures': 0}) == u'host                 '
    assert hostcolor(host='host', stats={'changed': 0, 'unreachable': 0, 'failures': 0}, color=False) == u'host                 '
    assert hostcolor(host='host', stats={'changed': 1, 'unreachable': 0, 'failures': 0}) == u'host                 '
    assert hostcolor(host='host', stats={'changed': 1, 'unreachable': 0, 'failures': 0}, color=False) == u'host                 '
    assert hostcolor(host='host', stats={'changed': 0, 'unreachable': 1, 'failures': 0}) == u'host                 '

# Generated at 2022-06-25 12:58:16.809742
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == "lead=num "
    assert colorize('lead', 'num', None) == "lead=num "
    assert colorize('lead', 'num', "") == "lead=num "
    assert colorize('lead', 'num', "red") == "lead=num "
    assert colorize('lead', 'num', "rgb255") == "lead=num "
    assert colorize('lead', 'num', "color255") == "lead=num "
    assert colorize('lead', 'num', "gray0") == "lead=num "
    assert colorize('lead', 'num', "color1") == "lead=num "
    assert colorize('lead', 'num', "color0") == "lead=num "
    assert colorize('lead', 'num', "color-1")

# Generated at 2022-06-25 12:58:29.101432
# Unit test for function hostcolor
def test_hostcolor():
    # First test
    var_0 = 'host_0'
    var_1 = {'unreachable': 0, 'failures': 0, 'changed': 0}
    hc_0 = hostcolor(var_0, var_1)
    assert hc_0 == 'host_0                 '
    # Second test
    var_1 = {'unreachable': 0, 'failures': 0, 'changed': 1}
    hc_1 = hostcolor(var_0, var_1)
    assert hc_1 == '\x1b[0;32mhost_0\x1b[0m                  '
    # Third test
    var_1 = {'unreachable': 1, 'failures': 0, 'changed': 0}
    hc_2 = hostcolor(var_0, var_1)


# Generated at 2022-06-25 12:58:34.359752
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(sys.stdout, sys.stdout, False)

dirty_opts = {
    'diff': None
}

# --- end "pretty"

# Generated at 2022-06-25 12:58:35.811534
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = hostcolor(str_0, var_0)


# Generated at 2022-06-25 12:58:45.730240
# Unit test for function stringc
def test_stringc():
    try:
        str_0 = 'rgb0'
        assert (variable_2 == parsecolor(str_0))
    except AssertionError:
        raise Exception('Expected assertion error')
    else:
        print('Assertion Error Not Raised')
    try:
        str_1 = 'rgb1'
        assert (variable_2 == parsecolor(str_1))
    except AssertionError:
        raise Exception('Expected assertion error')
    else:
        print('Assertion Error Not Raised')
    try:
        str_2 = 'rgb2'
        assert (variable_2 == parsecolor(str_2))
    except AssertionError:
        raise Exception('Expected assertion error')
    else:
        print('Assertion Error Not Raised')

# Generated at 2022-06-25 12:59:00.336895
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    dict_0 = dict()

    dict_0['failures'] = 3
    dict_0['unreachable'] = 4
    dict_0['changed'] = 7

    var_0 = hostcolor(str_0, dict_0)

    dict_0['failures'] = 0
    dict_0['unreachable'] = 0
    dict_0['changed'] = 5

    var_0 = hostcolor(str_0, dict_0)

    dict_0['failures'] = 0
    dict_0['unreachable'] = 0
    dict_0['changed'] = 0

    var_0 = hostcolor(str_0, dict_0)

    dict_0['failures'] = 1
    dict_0['unreachable'] = 0
    dict_0['changed'] = 0

# Generated at 2022-06-25 12:59:09.837079
# Unit test for function hostcolor
def test_hostcolor():
    # ansible/ansible#10089 ansible/ansible#10758
    host = u'foo'
    stats = {'unreachable': 0, 'failures': 0, 'changed': 0}
    assert hostcolor(host, stats) == u'foo                        '
    stats = {'unreachable': 1, 'failures': 0, 'changed': 0}
    assert hostcolor(host, stats) != u'\033[92mfoo'
    assert hostcolor(host, stats) != u'foo                        '
    stats = {'unreachable': 0, 'failures': 1, 'changed': 0}
    assert hostcolor(host, stats) != u'\033[92mfoo'
    assert hostcolor(host, stats) != u'foo                        '

# Generated at 2022-06-25 12:59:14.044215
# Unit test for function hostcolor
def test_hostcolor():
    assert not hostcolor("foo", {"bar": 3}, color=False).startswith("\n")
    assert  hostcolor("foo", {"bar": 3}, color=False) == "%-26s" % "foo"
    assert hostcolor("foo", {"bar": 3}, color=True) == "%-37s" % stringc("foo", C.COLOR_OK)


# Generated at 2022-06-25 12:59:18.627561
# Unit test for function colorize
def test_colorize():
    mylead = 'test_lead'
    mynum = 2
    mycolor = 'test_color'
    colorized =  colorize(mylead, mynum, mycolor)
    colorized_expected = 'test_lead=2   '
    assert colorized == colorized_expected


# Generated at 2022-06-25 12:59:23.920984
# Unit test for function colorize
def test_colorize():
    print(u"ANSIBLE_COLOR=%s" % str(ANSIBLE_COLOR))
    for i in range(1, 7):
        print(colorize(u"ok", i, u"green"),
              colorize(u"changed", i, u"yellow"),
              colorize(u"unreachable", i, u"red"),
              colorize(u"failed", i, u"red"))


if __name__ == "__main__":
    test_colorize()

# Generated at 2022-06-25 12:59:24.718325
# Unit test for function stringc
def test_stringc():
    assert False # No implementation


# Generated at 2022-06-25 12:59:34.806163
# Unit test for function stringc
def test_stringc():
    str_0 = '\t'
    str_1 = stringc(str_0, C.COLOR_CHANGED, True)
    str_2 = '\t'
    str_3 = stringc(str_2, C.COLOR_OK, False)
    str_4 = '\t'
    str_5 = stringc(str_4, C.COLOR_ERROR, False)
    str_6 = '\t'
    str_7 = stringc(str_6, C.COLOR_CHANGED, False)
    str_8 = '\t'
    str_9 = stringc(str_8, C.COLOR_OK, True)
    str_10 = '\t'
    str_11 = stringc(str_10, C.COLOR_ERROR, True)
    str_12 = '\t'

# Generated at 2022-06-25 12:59:37.964071
# Unit test for function colorize
def test_colorize():
    # Initialize
    lead = '\t'
    num = 1
    color = '\033[0m'
    str_1 = colorize(lead, num, color)
    # Return
    return str_1



# Generated at 2022-06-25 12:59:40.724905
# Unit test for function stringc
def test_stringc():
    # TODO: why does stringc get the special treatment?
    str_0 = '\t'
    var_0 = stringc(str_0, parsecolor(str_0))



# Generated at 2022-06-25 12:59:50.385992
# Unit test for function colorize
def test_colorize():
    """
    Generated from the following ANSI-C code:

    #include <stdlib.h>
    #include <stdio.h>

    int main(void)
    {
        char *msg = "colorize";
        char *item[] = {
            "color0",
            "color1",
            "color2",
            "color3"
        };
        char **color[] = {
            &item[0],
            &item[1],
            &item[2],
            &item[3],
            NULL
        };
        return 0;
    }

    Output:
    colorize=color0=color1=color2=color3
    """
    msg = u'colorize'

# Generated at 2022-06-25 12:59:56.242918
# Unit test for function stringc
def test_stringc():
    str_0 = '\t'
    var_0 = stringc(str_0, 'WARNING')


# Generated at 2022-06-25 13:00:00.771766
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host'
    dict_0 = {u'changed': 0,
              u'unreachable': 0,
              u'failures': 0}
    expected = 'host'
    actual = hostcolor(str_0, dict_0)
    assert actual == expected


# Generated at 2022-06-25 13:00:11.028530
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'server01.example.com'