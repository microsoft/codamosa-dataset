

# Generated at 2022-06-25 12:50:25.704306
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host=u'var_1', stats={u'changed': 0, u'failures': 0, u'ok': 0, u'skipped': 0, u'unreachable': 0}, color=True) == u'var_1                  '
    assert hostcolor(host=u'var_1', stats={u'changed': 0, u'failures': 0, u'ok': 0, u'skipped': 0, u'unreachable': 0}, color=False) == u'var_1                  '
    assert hostcolor(host=u'var_2', stats={u'changed': 0, u'failures': 0, u'ok': 0, u'skipped': 0, u'unreachable': 0}, color=True) == u'var_2                  '

# Generated at 2022-06-25 12:50:28.253064
# Unit test for function colorize
def test_colorize():
    host = "host"
    stats = {'changed': 0, 'failures': 0, 'ok': 4, 'unreachable': 0}
    colorize(host, stats, color=True)


# Generated at 2022-06-25 12:50:31.312567
# Unit test for function parsecolor
def test_parsecolor():
    # Default color
    assert parsecolor('green') == '32'
    # Color number
    assert parsecolor('color12') == '38;5;12'
    # RGB code
    assert parsecolor('rgb255255255') == '38;5;231'
    # Gray code
    assert parsecolor('gray11') == '38;5;243'


# Generated at 2022-06-25 12:50:35.372324
# Unit test for function parsecolor
def test_parsecolor():
    test_cases = {
        ("rgb036", u"38;5;74"),
        ("rgb336", u"38;5;130"),
        ("rgb333", u"38;5;7"),
        ("color000", u"38;5;0"),
        ("color100", u"38;5;100"),
        ("color999", u"38;5;999"),
    }
    for (color, expect) in test_cases:
        assert parsecolor(color) == expect


# Generated at 2022-06-25 12:50:43.505119
# Unit test for function parsecolor
def test_parsecolor():

    # Strings that should fail
    test_string_0 = 'a'
    test_string_1 = 'colora'
    test_string_2 = 'colora0'
    test_string_3 = 'colora_'

    # Strings that should succeed
    test_string_4 = 'color0'
    test_string_5 = 'color8'
    test_string_6 = 'color9'
    test_string_7 = 'color10'
    test_string_8 = 'color16'
    test_string_9 = 'color255'
    test_string_10 = 'rgb000'
    test_string_11 = 'rgb001'
    test_string_12 = 'rgb555'
    test_string_13 = 'rgb123'

# Generated at 2022-06-25 12:50:44.627537
# Unit test for function stringc
def test_stringc():
    test_case_0()
# End of test for function stringc


# Generated at 2022-06-25 12:50:47.249248
# Unit test for function parsecolor
def test_parsecolor():
    if ANSIBLE_COLOR:
        assert parsecolor('red') == '31', "parsecolor('red') == '31'"
        assert parsecolor('bold') == '1', "parsecolor('bold') == '1'"


# Generated at 2022-06-25 12:50:48.545637
# Unit test for function stringc
def test_stringc():
    assert "Hello" == stringc("Hello", "dark gray")


# Generated at 2022-06-25 12:50:51.990089
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(parsecolor('red')) == '38;5;9'

test_parsecolor()
# --- end pretty

__all__ = [
    'stringc',
    'parsecolor',
    'colorize',
    'ANSIBLE_COLOR',
]

# Generated at 2022-06-25 12:50:54.473867
# Unit test for function hostcolor
def test_hostcolor():
    host = "23456"
    stats = {"failures": "66", "unreachable": "77", "changed": "88"}

    # replace "pass" statement with unit test
    return (hostcolor(host, stats, True))



# Generated at 2022-06-25 12:51:02.735359
# Unit test for function colorize
def test_colorize():
    my_lead = 'foo'
    my_num = 0
    my_colour = 'blue'
    result = colorize(my_lead, my_num, my_colour)

    # check what the function returned
    assert result is not None

    # check that the function returned a string
    assert isinstance(result, str)


# Generated at 2022-06-25 12:51:03.455850
# Unit test for function stringc
def test_stringc():
    test_case_0()


# Generated at 2022-06-25 12:51:09.558329
# Unit test for function hostcolor
def test_hostcolor():
    bool_0 = True
    bool_1 = False
    str_0 = ""
    list_0 = [str_0, "c", str_0, str_0, str_0]
    list_1 = [str_0, str_0, str_0, str_0, str_0]
    str_1 = ""
    result_0 = str_1
    result_1 = str_0
    result_2 = result_1
    result_3 = result_0
    result_4 = result_3
    result_5 = result_2
    result_6 = result_5
    result_7 = result_6
    result_8 = result_7
    result_9 = list_0
    result_10 = result_9
    result_11 = list_1
    result_12 = result_11
   

# Generated at 2022-06-25 12:51:11.180613
# Unit test for function stringc
def test_stringc():
    bool_0 = True
    var_0 = stringc(bool_0, bool_0)


# Generated at 2022-06-25 12:51:14.158489
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == u'lead=num '
    assert colorize('lead', 'num', None) == u'lead=num '


# Generated at 2022-06-25 12:51:24.141453
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host="host", stats={"failures": 1, "unreachable": 0, "changed": 0}) == "%-37s" % stringc("host", "lightred")
    assert hostcolor(host="host", stats={"failures": 0, "unreachable": 2, "changed": 0}) == "%-37s" % stringc("host", "lightred")
    assert hostcolor(host="host", stats={"failures": 0, "unreachable": 0, "changed": 3}) == "%-37s" % stringc("host", "yellow")
    assert hostcolor(host="host", stats={"failures": 0, "unreachable": 0, "changed": 0}) == "%-37s" % stringc("host", "green")

# Generated at 2022-06-25 12:51:34.850171
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('host1',
                    {'changed': 1,
                     'failures': 0,
                     'ok': 10,
                     'skipped': 0,
                     'unreachable': 0}))
    print(hostcolor('host2',
                    {'changed': 1,
                     'failures': 0,
                     'ok': 10,
                     'skipped': 0,
                     'unreachable': 0},
                    color=False))
    print(hostcolor('host3',
                    {'changed': 0,
                     'failures': 0,
                     'ok': 10,
                     'skipped': 0,
                     'unreachable': 0}))

# Generated at 2022-06-25 12:51:43.420858
# Unit test for function stringc
def test_stringc():
    assert(stringc(True, True) == u"\033[38;5;2mTrue\033[0m")

    assert(constants.COLOR_SKIP == u"36")
    assert(stringc(u"skip", u"skip") == u"\033[36mskip\033[0m")

    assert(constants.COLOR_ERROR == u"41")
    assert(stringc(u"error", u"error") == u"\033[41merror\033[0m")

    assert(constants.COLOR_OK == u"2")
    assert(stringc(u"ok", u"ok") == u"\033[38;5;2mok\033[0m")

    # Should return an error message

# Generated at 2022-06-25 12:51:45.250528
# Unit test for function colorize
def test_colorize():
    print(colorize(lead="a", num=0, color="a"))


# Generated at 2022-06-25 12:51:48.663509
# Unit test for function hostcolor
def test_hostcolor():
    host = u'localhost'
    stats = {'changed': 0, 'failures': 0, 'unreachable': 0}
    color = True
    ret = hostcolor(host, stats, color)


# Generated at 2022-06-25 12:51:58.450381
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = C.ANSIBLE_COLOR
    C.ANSIBLE_COLOR = True
    stats_0 = {'changed': 0, 'dark': 0, 'failures': 0, 'processed': 0, 'skipped': 0, 'ok': 0, 'stderr': 0, 'unreachable': 0}
    fail_0 = hostcolor('localhost', stats_0, stats_0['ok'])
    out_0 = u"localhost                 "
    assert fail_0 == out_0
    C.ANSIBLE_COLOR = var_0


# Generated at 2022-06-25 12:52:04.861651
# Unit test for function stringc
def test_stringc():
    # Python 2.6 and 2.7 use different random numbers so skip this test
    # if we're running under Python 2.6
    if sys.version_info[0:2] == (2, 6):
        return

    import random
    import string
    import shutil
    import os

    # Generate the random ASCII string to test
    length = random.randint(1, 10)
    test_string = ''.join(random.choice(string.letters + string.digits)
        for x in xrange(length))

    test_color = random.choice(list(C.COLOR_CODES))

    # Save the terminal width and height
    width = shutil.get_terminal_size()[0]


# Generated at 2022-06-25 12:52:08.503674
# Unit test for function colorize
def test_colorize():
    # Assume
    lead = 'lead'
    num = 'num'
    color = 'color'
    # Action
    r = colorize(lead, num, color)
    # Assert
    assert r == 'lead=num'


# Generated at 2022-06-25 12:52:10.664908
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host="host",stats={"failures":0,"unreachable":0},color=True) == "%-37s"


# Generated at 2022-06-25 12:52:13.784519
# Unit test for function stringc
def test_stringc():
    bool_0 = True
    assert bool_0 == True
    var_0 = stringc(bool_0, bool_0)
    bool_0 = False
    assert bool_0 == False
    var_0 = stringc(bool_0, bool_0)


# Generated at 2022-06-25 12:52:20.868071
# Unit test for function stringc
def test_stringc():
    var_0 = parsecolor("bright white")
    var_0 = parsecolor("blue")
    var_0 = parsecolor("bright red")
    var_0 = parsecolor("cyan")
    var_0 = parsecolor("bright cyan")
    var_0 = parsecolor("green")
    var_0 = parsecolor("bright green")
    var_0 = parsecolor("magenta")
    var_0 = parsecolor("bright magenta")
    var_0 = parsecolor("red")
    var_0 = parsecolor("bright white")
    var_0 = parsecolor("white")
    var_0 = parsecolor("yellow")
    var_1 = parsecolor("bright black")
    var_0 = parsecolor("bright blue")
    var_0 = parsecolor

# Generated at 2022-06-25 12:52:27.096258
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.callbacks import AggregateStats
    stats = AggregateStats()
    stats.compute(dict())
    assert hostcolor('localhost', stats) == u'localhost               '
    stats.failures = 1
    assert hostcolor('localhost', stats) == u'\x01\x1b[31m\x02localhost\x01\x1b[0m\x02'
    stats.changed = 1
    assert hostcolor('localhost', stats) == u'\x01\x1b[33m\x02localhost\x01\x1b[0m\x02'

# Generated at 2022-06-25 12:52:29.074588
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'foo', {u'failures':0, u'skipped':0, u'ok':0, u'changed':0, u'unreachable':0}, True) == u'foo                          '


# Generated at 2022-06-25 12:52:29.941214
# Unit test for function stringc
def test_stringc():
    print(stringc('stringc', C.COLOR_DEBUG))


# Generated at 2022-06-25 12:52:31.723311
# Unit test for function stringc
def test_stringc():
    var_0 = stringc('hello', 'green', False)
    assert '\033' in var_0



# Generated at 2022-06-25 12:52:38.905450
# Unit test for function colorize
def test_colorize():
    assert colorize('a', 0, None) == 'a=0   ', "test_colorize_0 failed"
    assert colorize('b', 10, 'blue') == 'b=10  ', "test_colorize_1 failed"
    assert colorize('c', 100, 'red') == 'c=100 ', "test_colorize_2 failed"
    assert colorize('d', 1000, 'yellow') == 'd=1000', "test_colorize_3 failed"
    assert colorize('e', 10000, 'gray') == 'e=10000', "test_colorize_4 failed"
    assert colorize('f', 100000, 'green') == 'f=100000', "test_colorize_5 failed"


# Generated at 2022-06-25 12:52:49.287760
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0),True) == u'host                          '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0),False) == u'host                  '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1),True) == u'host                          '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1),False) == u'host                  '
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0),True) == u'host                          '
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0),False) == u'host                  '
    assert hostcolor

# Generated at 2022-06-25 12:52:54.970218
# Unit test for function colorize
def test_colorize():
    # Test with color
    assert colorize('lead', 1, C.COLOR_CHANGED) == 'lead=1   '
    # Test without color
    global ANSIBLE_COLOR
    old_color = ANSIBLE_COLOR
    ANSIBLE_COLOR=False
    assert colorize('lead', 1, C.COLOR_CHANGED) == 'lead=1   '
    ANSIBLE_COLOR=old_color


# Generated at 2022-06-25 12:52:55.945458
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == u"lead=num      "



# Generated at 2022-06-25 12:53:01.858359
# Unit test for function stringc
def test_stringc():
    start_time = time.time()
    print('Starting function test:  test_stringc')
    str_0 = 'stringc'
    str_1 = 'stringc'
    str_2 = 'stringc'
    str_3 = 'stringc'
    str_4 = 'stringc'
    str_5 = 'stringc'
    str_6 = 'stringc'
    str_7 = 'stringc'
    str_8 = 'stringc'
    str_9 = 'stringc'
    start_time = time.time()
    print('Starting function test:  test_stringc')
    str_0 = 'stringc'
    str_1 = 'stringc'
    str_2 = 'stringc'
    str_3 = 'stringc'
    str_4 = 'stringc'
   

# Generated at 2022-06-25 12:53:06.399253
# Unit test for function stringc
def test_stringc():
    '''
    stringc
    '''
    str_0 = 'stringc'
    str_1 = ''
    returned_str_0 = stringc(str_0, str_1)
    if returned_str_0 != 'stringc':
        sys.exit(1)


# Generated at 2022-06-25 12:53:13.644144
# Unit test for function hostcolor
def test_hostcolor():
    # test cases
    host = 'test_host'
    stats = {
        'failures': 0,
        'unreachable': 0,
        'changed': 0
    }
    color = True
    result = hostcolor(host, stats, color)
    assert result == 'test_host                 ', \
        'test case 0 failed'

    stats['changed'] = 1
    result = hostcolor(host, stats, color)
    assert result == 'test_host                 ', \
        'test case 1 failed'

    stats['changed'] = 0
    stats['failures'] = 1
    result = hostcolor(host, stats, color)
    assert result == 'test_host                 ', \
        'test case 2 failed'

    stats['failures'] = 0
    stats['unreachable'] = 1

# Generated at 2022-06-25 12:53:15.164280
# Unit test for function colorize
def test_colorize():
    lead = '1'
    num = 2
    color = '3'
    assert colorize(lead, num, color) == '1=2   '


# Generated at 2022-06-25 12:53:18.390820
# Unit test for function stringc
def test_stringc():
    str_0 = 'stringc'
    str_1 = stringc(str_0, 'yellow')
    str_2 = stringc(str_0, 'black')
    str_3 = stringc(str_0, 'yellow')
    str_4 = stringc(str_0, 'black')


# Generated at 2022-06-25 12:53:21.475259
# Unit test for function hostcolor
def test_hostcolor():
    dummy_host = 'dummy_host'
    dummy_stats = {'failures': 0, 'changed': 1, 'unreachable': 0}
    assert hostcolor(dummy_host, dummy_stats) == 'dummy_host      '

if __name__ == '__main__':
    # test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:53:28.073094
# Unit test for function stringc
def test_stringc():
    test_case_0()


# Generated at 2022-06-25 12:53:33.491966
# Unit test for function hostcolor
def test_hostcolor():
    stats_0 = {'changed': 0, 'failures': 0, 'skipped': 0, 'ok': 0, 'unreachable': 0}
    assert hostcolor(host='host', stats=stats_0, color=True) == u'host'

# Generated at 2022-06-25 12:53:42.562889
# Unit test for function colorize
def test_colorize():
    lead_0 = 'lead'
    str_0 = 'color'
    num_0 = -48
    res_0 = 'lead=-48'
    assert colorize(lead_0, num_0, str_0) == res_0

    lead_1 = 'lead'
    num_1 = -228
    res_1 = 'lead=-228\n'
    assert colorize(lead_1, num_1, str_0) == res_1

    str_1 = 'color'
    lead_2 = 'lead'
    num_2 = -78
    res_2 = 'lead=-78\n'
    assert colorize(lead_2, num_2, str_1) == res_2

    str_2 = 'color'
    lead_3 = 'lead'
    num_3 = -40
   

# Generated at 2022-06-25 12:53:44.493541
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'unknown'
    color = parsecolor(str_0)
    assert color == C.COLOR_CODES['unknown']


# Generated at 2022-06-25 12:53:55.224568
# Unit test for function hostcolor
def test_hostcolor():
    host = 'host1'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 0}
    ans = u'%-26s' % host
    assert hostcolor(host, stats, True) == ans
    stats['changed'] = 1
    ans = u"%-37s" % stringc(host, C.COLOR_CHANGED)
    assert hostcolor(host, stats, True) == ans
    stats['changed'] = 0
    ans = u"%-37s" % stringc(host, C.COLOR_OK)
    assert hostcolor(host, stats, True) == ans
    stats['failures'] = 1
    ans = u"%-37s" % stringc(host, C.COLOR_ERROR)
    assert hostcolor(host, stats, True) == ans
    ans

# Generated at 2022-06-25 12:54:03.948135
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('dark red') == '31'
    assert parsecolor('light red') == '31'
    assert parsecolor('grey') == '30'
    assert parsecolor('dark grey') == '30'
    assert parsecolor('light grey') == '30'
    assert parsecolor('green') == '32'
    assert parsecolor('dark green') == '32'
    assert parsecolor('light green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('dark blue') == '34'
    assert parsecolor('light blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('dark yellow') == '33'

# Generated at 2022-06-25 12:54:06.546412
# Unit test for function stringc
def test_stringc():
    stringc('red', 'red')

# --- end "pretty"


# cache colorized output to avoid calling stringc multiple times for the same
# string when using verbosity > 0
_CACHE_COLORIZED = {}


# Generated at 2022-06-25 12:54:09.518205
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    test_hostcolor_result = 'local'
    assert hostcolor(host, stats, color)[0:5] == test_hostcolor_result

if __name__ == '__main__':
    test_case_0()
    print('All test cases passed')

# Generated at 2022-06-25 12:54:14.122579
# Unit test for function hostcolor

# Generated at 2022-06-25 12:54:25.064918
# Unit test for function colorize
def test_colorize():
    # Case 0
    lead = 'lead'
    num = 0
    color = 'RED'
    assert(colorize(lead, num, color) == u'\n'.join(
        [u"\033[38;5;1mlead=0  \033[0m"]))

    # Case 1
    lead = 'lead'
    num = 3
    color = 'RED'
    assert(colorize(lead, num, color) == u'\n'.join(
        [u"\033[38;5;1mlead=3  \033[0m"]))

    # Case 2
    lead = 'lead'
    num = 18
    color = 'RED'

# Generated at 2022-06-25 12:54:33.014651
# Unit test for function parsecolor
def test_parsecolor():
    expected_result = u'38;5;160'
    actual_result = parsecolor('blue')

    assert actual_result == expected_result, 'Expected: %s. Actual: %s' % (expected_result, actual_result)



# Generated at 2022-06-25 12:54:37.255949
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = parsecolor('on_red')
    str_1 = parsecolor('red')
    str_2 = parsecolor('blue')
    str_3 = parsecolor('green')
    str_4 = parsecolor('end')


# Generated at 2022-06-25 12:54:40.274403
# Unit test for function stringc
def test_stringc():
    assert_equal(stringc(text, color, wrap_nonvisible_chars = False), parsecolor(color))


# Generated at 2022-06-25 12:54:48.341049
# Unit test for function hostcolor
def test_hostcolor():
    # Provided example
    print(hostcolor("localhost", {"failures": 0, "changed": 0, "ok": 1, "skipped": 0, "unreachable": 0}))
    print(hostcolor("localhost", {"failures": 1, "changed": 0, "ok": 0, "skipped": 0, "unreachable": 0}))
    print(hostcolor("localhost", {"failures": 0, "changed": 1, "ok": 0, "skipped": 0, "unreachable": 0}))

    # Test with empty host name
    print(hostcolor("", {"failures": 0, "changed": 0, "ok": 1, "skipped": 0, "unreachable": 0}))

# Generated at 2022-06-25 12:54:53.349787
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test.domain.com'
    stats = \
        {
            "ok": 2,
            "unreachable": 0,
            "changed": 0,
            "failures": 1
        }
    assert hostcolor(host, stats, False) == u'%-37s' % 'test.domain.com'
    assert hostcolor(host, stats, True) == \
        u'\x1b[0;31m%-37s\x1b[0m' % 'test.domain.com'


# Generated at 2022-06-25 12:54:57.345157
# Unit test for function hostcolor
def test_hostcolor():
    host = 'host'
    stats = {'failures': 0, 'unreachable': 2, 'changed': 1}
    color = True
    assert hostcolor(host, stats, color) == 'host                  '


# Generated at 2022-06-25 12:55:02.483383
# Unit test for function colorize
def test_colorize():
    print(colorize('host', 123, C.COLOR_OK))
    print(colorize('host', 123, 'red'))
    print(colorize('host', 123, 'blue'))
    print(colorize('host', 123, 'yellow'))
    print('\n')


# Generated at 2022-06-25 12:55:04.367128
# Unit test for function stringc
def test_stringc():
    assert stringc('text', C.COLOR_OK) == '\x1b[32mtext\x1b[0m'


# Generated at 2022-06-25 12:55:05.163246
# Unit test for function stringc
def test_stringc():
    test_case_0()



# Generated at 2022-06-25 12:55:11.402245
# Unit test for function stringc
def test_stringc():
    # Test no arguments
    try:
        stringc()
    except TypeError as e:
        print('test_case_0 failed')
        print(e)

    # Test one argument
    try:
        stringc(0)
    except TypeError as e:
        print('test_case_1 failed')
        print(e)

    # Test two arguments
    try:
        stringc(0,0)
    except TypeError as e:
        print('test_case_2 failed')
        print(e)


# Generated at 2022-06-25 12:55:16.802914
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('case_0', C.COLOR_CODES['WARNING'])
    assert str_0 == u'\ncase_0'


# Generated at 2022-06-25 12:55:18.192186
# Unit test for function hostcolor
def test_hostcolor():
    print (hostcolor('host', 'stats'))

# if __name__ == "__main__":
#     test_hostcolor()

# Generated at 2022-06-25 12:55:22.176264
# Unit test for function hostcolor
def test_hostcolor():
    host = 'a'
    for color in ('lightgreen', 'lightgreen', 'lightgray'):
        stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
        assert hostcolor(host, stats, True) == '%-37s' % stringc(host, color)
    for color in ('red', 'red', 'red'):
        stats = {'failures': 1, 'unreachable': 1, 'changed': 1}
        assert hostcolor(host, stats, True) == '%-37s' % stringc(host, color)


# Generated at 2022-06-25 12:55:25.422087
# Unit test for function stringc
def test_stringc():
    global str_0
    
    # Call function with arguments str_0 and 'red'
    ret_0 = stringc(str_0, 'red')
    
    # Check the results
    assert ret_0 == '\x1b[31mstringc\x1b[0m'

# Generated at 2022-06-25 12:55:31.044561
# Unit test for function hostcolor
def test_hostcolor():
    host = 'host'
    stats = {'failures':0, 'unreachable':0, 'changed':0}
    color = True
    
    result = hostcolor(host, stats, color)
    assert result[5] == '-'
    assert result[8] == ' '
    assert result[-1] == 's'



# Generated at 2022-06-25 12:55:34.236327
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('test_stringc', 'green')

if __name__ == "__main__":
    test_case_0()
    test_stringc()

# Generated at 2022-06-25 12:55:43.551909
# Unit test for function hostcolor
def test_hostcolor():
    host = 'ansible.example.com'
    stats = {'skipped': 1, 'failures': 2, 'ok': 3, 'changed': 4, 'unreachable': 5}
    color = True
    # Colorize hostname to red if unreachable or failures more than zero
    if stats['failures'] != 0 or stats['unreachable'] != 0:
        assert hostcolor(host, stats, color) == stringc(host, C.COLOR_ERROR)
    # Colorize hostname to yellow if changed more than zero
    elif stats['changed'] != 0:
       assert hostcolor(host, stats, color) == stringc(host, C.COLOR_CHANGED)
    # Otherwise, colorize to green
    else:
       assert hostcolor(host, stats, color) == stringc(host, C.COLOR_OK)

# Generated at 2022-06-25 12:55:54.426791
# Unit test for function hostcolor
def test_hostcolor():
    stats_0 = {'failures': 0, 'changed': 0, 'unreachable': 0}
    host_0 = 'localhost'
    color_0 = True
    assert hostcolor(host_0, stats_0, color_0) == 'localhost            '

    stats_1 = {'failures': 1, 'changed': 0, 'unreachable': 0}
    host_1 = 'localhost'
    color_1 = False
    assert hostcolor(host_1, stats_1, color_1) == 'localhost            '

    stats_2 = {'failures': 0, 'changed': 1, 'unreachable': 0}
    host_2 = 'localhost'
    color_2 = False
    assert hostcolor(host_2, stats_2, color_2) == 'localhost            '


# Generated at 2022-06-25 12:55:58.133849
# Unit test for function stringc
def test_stringc():
    str = stringc(test_case_0(), 'none')
    assert str == u'\nstringc'
    str = stringc(test_case_0(), 'non-exist-color')
    assert str == u'\nstringc'

if __name__ == "__main__":
    test_stringc()

# Generated at 2022-06-25 12:56:01.010666
# Unit test for function colorize
def test_colorize():
    lead_0 = 'host'
    num_0 = 1
    color_0 = 'red'
    assert colorize(lead_0, num_0, color_0) == u'host=1'


# Generated at 2022-06-25 12:56:06.667690
# Unit test for function hostcolor
def test_hostcolor():
    test_hostcolor_0()

# Generated at 2022-06-25 12:56:17.821988
# Unit test for function colorize
def test_colorize():
    cases = [
        # Invalid case
        [None, None, None, u"%s=%-4s" % (None, str(None))],
        # Valid cases
        # Not colorized
        [None, 0, None, u"%s=%-4s" % (None, str(0))],
        # Colorized
        [None, 1, 'yellow', u"\n".join([u"\033[33m%s=%-4s\033[0m" % (None, str(1)) for t in "\n".split(u'\n')])],
    ]

# Generated at 2022-06-25 12:56:24.192011
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 1,
             'unreachable': 0,
             'changed': 0}
    host = 'ansible1'
    ans_0 = hostcolor(host, stats, color=True)
    ans_1 = stringc(host, 'red')
    print(ans_0)
    print(ans_1)
    print(ans_0 == ans_1)


# Generated at 2022-06-25 12:56:31.948415
# Unit test for function colorize
def test_colorize():
    print('\n--------------------------------------------------')
    print('Start unit test: test_gdc_role_facts.test_colorize')

    print(colorize('host', 1, C.COLOR_SKIP))
    print(colorize('host', 2, C.COLOR_SKIP))
    print(colorize('host', 3, C.COLOR_SKIP))
    print(colorize('host', 4, C.COLOR_ERROR))
    print(colorize('host', 5, C.COLOR_ERROR))
    print(colorize('host', 6, C.COLOR_ERROR))
    print(colorize('host', 7, C.COLOR_CHANGED))
    print(colorize('host', 8, C.COLOR_CHANGED))
    print(colorize('host', 9, C.COLOR_CHANGED))


# Generated at 2022-06-25 12:56:42.589082
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'red') == "\033[31mtest\033[0m"
    assert stringc('test', 'blue') == "\033[34mtest\033[0m"
    assert stringc('test', 'green') == "\033[32mtest\033[0m"
    assert stringc('test', 'yellow') == "\033[33mtest\033[0m"
    assert stringc('test', 'turquoise') == "\033[36mtest\033[0m"
    assert stringc('test', 'white') == "\033[37mtest\033[0m"
    assert stringc('test', 'black') == "\033[30mtest\033[0m"
    assert stringc('test', 'magenta') == "\033[35mtest\033[0m"
    assert stringc

# Generated at 2022-06-25 12:56:52.433304
# Unit test for function colorize
def test_colorize():
    # Test cases
    assert colorize('lead', 5, 'green') == 'lead=5   '
    assert colorize('lead', 5, 'blue') == 'lead=5   '
    assert colorize('lead', 5, 'red') == 'lead=5   '
    assert colorize('lead', 5, 'yellow') == 'lead=5   '
    assert colorize('lead', 5, 'cyan') == 'lead=5   '
    assert colorize('lead', 5, 'dgreen') == 'lead=5   '
    assert colorize('lead', 5, 'bold') == 'lead=5   '
    assert colorize('lead', 5, 'magenta') == 'lead=5   '
    assert colorize('lead', 5, 'bmagenta') == 'lead=5   '

# Generated at 2022-06-25 12:56:53.553801
# Unit test for function stringc
def test_stringc():
    str_0 = 'stringc'


# Generated at 2022-06-25 12:57:02.754300
# Unit test for function hostcolor
def test_hostcolor():
    print('Test hostcolor')
    # Tests are written in the following format:
    # assert <function>('args') == 'expected output'

    # A host that has failed
    assert hostcolor('host', {'failures': 1, 'changed': 0, 'ok': 0, 'unreachable': 0}) == u'\n'.join(['%-37s' % stringc('host', 'red')])
    # A host that has changed
    assert hostcolor('host', {'failures': 0, 'changed': 1, 'ok': 0, 'unreachable': 0}) == u'\n'.join(['%-37s' % stringc('host', 'yellow')])
    # A host that is ok
    assert hostcolor('host', {'failures': 0, 'changed': 0, 'ok': 1, 'unreachable': 0})

# Generated at 2022-06-25 12:57:05.377534
# Unit test for function stringc
def test_stringc():
    # Test case 0
    assert stringc('stringc', 'normal') == u'\033[0mstringc\033[0m'


# Generated at 2022-06-25 12:57:10.086606
# Unit test for function hostcolor
def test_hostcolor():
    host = 'hostname'
    stats = {'failures': 0,
             'unreachable': 0,
             'changed': 0,
             'ok': 0}
    color = True
    expected = u'%-26s' % host
    actual = hostcolor(host, stats, color)
    assert expected == actual


# Generated at 2022-06-25 12:57:14.987266
# Unit test for function hostcolor
def test_hostcolor():
    class Struct:
        pass
    result1 = hostcolor('myhost', Struct())
    result2 = hostcolor('myhost', Struct())

    assert result1 == result2


# Generated at 2022-06-25 12:57:16.436530
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('nodename', {}) == 'nodename               '


# Generated at 2022-06-25 12:57:18.233376
# Unit test for function stringc
def test_stringc():
    str_0 = 'stringc'
    str_1 = stringc('stringc', 'color5')
    print(str_1)


# Generated at 2022-06-25 12:57:21.242968
# Unit test for function stringc
def test_stringc():
    assert stringc(text=test_case_0, color=test_case_0, wrap_nonvisible_chars=test_case_0) == '\001\033[38;5;240m\002stringc\001\033[0m\002'

# Code from file pretty.py ends here

# Generated at 2022-06-25 12:57:26.941636
# Unit test for function stringc
def test_stringc():
    str_0 = 'stringc'
    str_1 = 'stringc'
    str_2 = 'stringc'
    str_3 = 'stringc'
    str_4 = 'stringc'
    ans_0 = stringc(str_0, 'RESET')
    ans_1 = stringc(str_1, 'YELLOW')
    ans_2 = stringc(str_2, 'RED')
    ans_3 = stringc(str_3, 'GREEN')
    ans_4 = stringc(str_4, 'BLUE')
    assert ans_0 == '\nstringc\n'
    assert ans_1 == '\033[33m\nstringc\n\033[0m'
    assert ans_2 == '\033[31m\nstringc\n\033[0m'


# Generated at 2022-06-25 12:57:35.117034
# Unit test for function stringc
def test_stringc():
    from ansible.utils.color import stringc
    from ansible.utils.color import parsecolor
    expected = u'\033[31mred\033[0m'
    assert(stringc('red', 'red') == expected)
    assert(parsecolor('red') == '31')
    expected = u'\033[31;1mred\033[0m'
    assert(stringc('red', 'lightred') == expected)

    expected = u'\033[38;5;196mred\033[0m'
    assert(stringc('red', 'rgb444') == expected)

# End of Unit test

if __name__ == "__main__":
    sys.exit(test_stringc())

# Generated at 2022-06-25 12:57:44.039816
# Unit test for function hostcolor
def test_hostcolor():
    '''
    Unit test for function hostcolor
    '''
    host = 'localhost'
    stats = {
        'failures': 0,
        'skipped': 0,
        'ok': 2,
        'dark': 0,
        'changed': 0,
        'exceptions': 0,
        'unreachable': 0,
        'failures_per_host': 0,
        'skipped_per_host': 0,
        'ok_per_host': 0,
        'dark_per_host': 0,
        'changed_per_host': 0,
        'exceptions_per_host': 0,
        'unreachable_per_host': 0,
    }
    color = True
    result = hostcolor(host, stats, color)

    assert result == u'localhost'


# Generated at 2022-06-25 12:57:47.573074
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == "lead=num "
    # TODO: add a test to check that the colorize function takes
    #         ANSIBLE_COLOR into account



# Generated at 2022-06-25 12:57:55.334554
# Unit test for function hostcolor
def test_hostcolor():
    h = 'localhost'
    s = {'changed': 0, 'dark': 0, 'failures': 0, 'ok': 1, 'processed': 1, 'rescued': 0, 'skipped': 0, 'unreachable': 0}
    a1 = hostcolor(h, s, color=True)
    a2 = hostcolor(h, s, color=False)
    assert a1 == u'\u001b[32m%-37s\u001b[0m'
    assert a2 == u'%-26s'


# Generated at 2022-06-25 12:58:01.650217
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('test', 'green', True)

# Generated at 2022-06-25 12:58:13.896150
# Unit test for function stringc
def test_stringc():
    function = stringc
    # Test standard case
    str_0 = 'stringc'
    str_1 = 'color'
    str_2 = 'stringc'
    str_3 = 'color'
    str_4 = 'stringc'
    str_5 = 'color'
    str_6 = 'stringc'
    # Test string parameter
    str_7 = 'stringc'
    str_8 = 'color1'
    str_9 = 'stringc'
    str_10 = 'color1'
    str_11 = 'stringc'
    str_12 = 'color1'
    str_13 = 'stringc'
    # Test numeric parameter
    str_14 = 'stringc'
    str_15 = '5'
    str_16 = 'stringc'
    str_17 = '5'


# Generated at 2022-06-25 12:58:20.414517
# Unit test for function stringc
def test_stringc():
    """
        :return:
    """
    assert stringc('stringc', 'red') == '\033[31mstringc\033[0m'
    assert stringc('stringc', 'red', wrap_nonvisible_chars=True) == '\001\033[31m\002stringc\001\033[0m\002'
    print(stringc('stringc', 'red'))
    print(stringc('stringc', 'red', wrap_nonvisible_chars=True))


# Generated at 2022-06-25 12:58:24.972694
# Unit test for function stringc
def test_stringc():
    str_0 = stringc('stringc', 'color1', False)
    if str_0 == '\033[38;5;1mstringc\033[0m' or str_0 == '\01\033[38;5;1m\002stringc\001\033[0m\002':
        return True
    return False



# Generated at 2022-06-25 12:58:27.867043
# Unit test for function hostcolor
def test_hostcolor():
    h1 = 'ansible_test'
    s1 = {'ok':1}
    c1 = True
    assert(hostcolor(h1, s1, c1) == u"ansible_test                      ")


# Generated at 2022-06-25 12:58:33.997776
# Unit test for function hostcolor
def test_hostcolor():
    host = 'hostname'
    stats = {
        'failures': 0,
        'unreachable': 0,
        'changed': 0
    }
    color = True
    out = hostcolor(host, stats, color)
    assert out == 'hostname                 '
    stats['unreachable'] = 1
    out = hostcolor(host, stats, color)
    assert out == 'hostname                 '


# Generated at 2022-06-25 12:58:44.249768
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('pink') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('darkgray') == u'90'
    assert parsecolor('lightgray') == u'37'
    # assert parsecolor('color8') == '38;5;8'
    # assert parsecolor('rgb444') == '38;5;123'
    # assert parsecolor('rgb355') == '38;5;58'
    # assert parsecolor('rgb012

# Generated at 2022-06-25 12:58:53.575073
# Unit test for function hostcolor
def test_hostcolor():

    # Test the normal case
    assert hostcolor('abc', {'failures': 0, 'unreachable': 0, 'changed': 0}, False) == '%-37s' % 'abc'

    # Test the first abnormal case
    assert hostcolor('abc', {'failures': 1, 'unreachable': 0, 'changed': 0}, True) == '%-37s' % stringc('abc', C.COLOR_ERROR)

    # Test the second abnormal case
    assert hostcolor('abc', {'failures': 0, 'unreachable': 0, 'changed': 1}, True) == '%-37s' % stringc('abc', C.COLOR_CHANGED)

    # Test the third abnormal case

# Generated at 2022-06-25 12:58:57.435668
# Unit test for function colorize
def test_colorize():
    print('%s.%s: %s' % (__name__, 'test_colorize', 'Running'))
    returnval = colorize('lead', 10, 'yellow')
    assert returnval == u'lead=10   '


# Generated at 2022-06-25 12:59:01.760451
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('white') == u'37'


# Generated at 2022-06-25 12:59:05.036801
# Unit test for function colorize
def test_colorize():
    str1 = colorize('a', 1, 'red')
    str2 = colorize('b', 0, 'cyan')
    assert(str1 != str2)
    assert('0' not in str2)


# Generated at 2022-06-25 12:59:18.031085
# Unit test for function hostcolor
def test_hostcolor():
    host = 'hostname_0'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    expected = 'hostname_0             '
    actual = hostcolor(host, stats, color)
    assert(expected == actual)

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:59:21.446103
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor() == "%-26s")
    assert(hostcolor() != "%-27s")

if __name__ == "__main__":
    test_case_0()
    test_hostcolor()

# --- end "pretty"

# Generated at 2022-06-25 12:59:29.525802
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'hostcolor'

    host = 'test'
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    stats['ok'] = 0
    color = True
    assert hostcolor(host, stats, color) == '%-26s' % 'test'

    host = 'test'
    stats = {}
    stats['failures'] = 1
    stats['unreachable'] = 0
    stats['changed'] = 0
    stats['ok'] = 0
    color = True
    assert hostcolor(host, stats, color) == '%-37s' % '\n'.join(['\001\033[38;5;9m\002test\001\033[0m\002'])

    host = 'test'
    stats = {}


# Generated at 2022-06-25 12:59:31.976699
# Unit test for function stringc
def test_stringc():
    print(stringc(u'hello world', u'blue'))
    print(stringc(u'hello world', u'lightblue'))


# Generated at 2022-06-25 12:59:42.058096
# Unit test for function hostcolor
def test_hostcolor():
    host_0 = '127.0.0.1'
    stats_0 = {'unreachable': 0, 'skipped': 0, 'changed': 0, 'failures': 0, 'ok': 0}
    color_0 = True
    hostcolor_0 = hostcolor(host_0, stats_0, color_0)
    assert hostcolor_0 == u"127.0.0.1                  ", hostcolor_0
    stats_1 = {'unreachable': 0, 'skipped': 0, 'changed': 0, 'failures': 0, 'ok': 0}
    color_1 = False
    hostcolor_1 = hostcolor(host_0, stats_1, color_1)
    assert hostcolor_1 == u"127.0.0.1                  ", hostcolor_1


# Tests for function stringc


# Generated at 2022-06-25 12:59:52.708472
# Unit test for function hostcolor
def test_hostcolor():
    host_0 = 'host'
    stats_0 = {'unreachable': 0, 'failures': 1, 'ok': 0, 'skipped': 0, 'changed': 0}
    host_1 = 'host'
    stats_1 = {'unreachable': 1, 'failures': 0, 'ok': 0, 'skipped': 0, 'changed': 0}
    host_2 = 'host'
    stats_2 = {'unreachable': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'changed': 1}
    host_3 = 'host'
    stats_3 = {'unreachable': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'changed': 0}
    hostcolor(host_0, stats_0)

# Generated at 2022-06-25 12:59:56.603563
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {
        'failures': 0,
        'unreachable': 0,
        'changed': 0
    }
    result = hostcolor(host, stats, True)
    assert result == "%-37s" % stringc(host, C.COLOR_OK), 'Test Failed'


# Generated at 2022-06-25 13:00:01.435197
# Unit test for function stringc
def test_stringc():
    # stringc(text, color)

    text_0 = 'stringc'
    color_0 = 'red'
    assert stringc(text_0, color_0) == u"\n".join([u"\033[31m%s\033[0m" % t for t in text_0.split(u'\n')])



# Generated at 2022-06-25 13:00:07.000682
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test_host'
    stats = {'skipped':0, 'ok':0, 'changed':1, 'unreachable':0, 'failures':1}
    hostcolor(host, stats, color=False)
    hostcolor(host, stats, color=True)


if __name__ == '__main__':
	test_case_0()

# Generated at 2022-06-25 13:00:12.296702
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'skipped': 0, 'failures': 1, 'unreachable': 0, 'ok': 3, 'changed': 3, 'rescued': 0, 'ignored': 0}
    hostcolor(host, stats)
