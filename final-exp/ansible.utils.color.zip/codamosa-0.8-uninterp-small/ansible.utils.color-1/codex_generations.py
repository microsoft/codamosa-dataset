

# Generated at 2022-06-25 12:50:16.936394
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()

# --- end "pretty"



# Generated at 2022-06-25 12:50:19.801746
# Unit test for function hostcolor
def test_hostcolor():
    dict_0 = {}
    if ANSIBLE_COLOR:
        assert hostcolor('KE\\lC%Z', dict_0) == u'%-37s'
    else:
        assert hostcolor('KE\\lC%Z', dict_0) == u'%-26s'


# Generated at 2022-06-25 12:50:27.941137
# Unit test for function stringc
def test_stringc():
    str_0 = 'KE\\lC%Z'
    dict_0 = {}
    var_0 = stringc(str_0, C.COLOR_ERROR, dict_0)
    str_1 = 'p[~?Y\\}f'
    dict_1 = {}
    var_1 = stringc(str_1, C.COLOR_ERROR, dict_1)
    str_2 = 'Mj?ClA'
    dict_2 = {}
    var_2 = stringc(str_2, C.COLOR_ERROR, dict_2)
    str_3 = '{<v'
    dict_3 = {}
    var_3 = stringc(str_3, C.COLOR_ERROR, dict_3)
    str_4 = '}u{wU?|'
    dict_4 = {}
    var_

# Generated at 2022-06-25 12:50:34.453058
# Unit test for function hostcolor
def test_hostcolor():
    assert u'%-37s' == hostcolor(u'KE\\lC%Z', {})
    assert u'%s' == hostcolor(u'', {u'failures': 0, u'unreachable': 0, u'changed': 1})
    assert u'%s' == hostcolor(u'', {u'failures': 1, u'unreachable': 0, u'changed': 0})
    assert u'%s' == hostcolor(u'', {u'failures': 0, u'unreachable': 1, u'changed': 0})
    assert u'%s' == hostcolor(u'', {u'failures': 0, u'unreachable': 0, u'changed': 0})


# Generated at 2022-06-25 12:50:35.373637
# Unit test for function colorize
def test_colorize():
    assert colorize('lead',0,'color') == u"lead=0   "


# Generated at 2022-06-25 12:50:36.529284
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('KE\\lC%Z', {}) == 'KE\\lC%Z                 '


# Generated at 2022-06-25 12:50:44.883061
# Unit test for function hostcolor
def test_hostcolor():
    assert '%-37s' == hostcolor('KE\\lC%Z', {})
    assert '%-37s' == hostcolor('O%+w', {'skipped': 5})
    assert '%-37s' == hostcolor('McGd\\', {'skipped': 5})
    assert '%-37s' == hostcolor('\\%m^', {})
    assert '%-37s' == hostcolor('Ar', {})
    assert '%-37s' == hostcolor('#', {})
    assert '%-37s' == hostcolor('R', {'skipped': 5})
    assert '%-37s' == hostcolor('>_\\p;\\', {'skipped': 5})
    assert '%-37s' == hostcolor('xm', {})

# Generated at 2022-06-25 12:50:45.661710
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()


# Generated at 2022-06-25 12:50:52.873070
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('cyan') == '38;5;14'
    assert parsecolor('nocolor') == '0'
    assert parsecolor('bold') == '1'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('rgb222') == '38;5;60'
    assert parsecolor('rgb123') == '38;5;33'
    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb333') == '38;5;59'


# Generated at 2022-06-25 12:50:55.443679
# Unit test for function parsecolor
def test_parsecolor():
    color = 'red'
    expected_value = '31'
    actual_value = parsecolor(color)
    assert actual_value == expected_value, 'Actual: %s, Expected: %s' % (actual_value, expected_value)


# Generated at 2022-06-25 12:51:04.430728
# Unit test for function stringc
def test_stringc():
    list_0 = None
    var_0 = stringc(list_0)


# Generated at 2022-06-25 12:51:04.878285
# Unit test for function colorize
def test_colorize():
    pass

# Generated at 2022-06-25 12:51:14.037123
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "bold") == u"\033[1mtext\033[0m"
    assert stringc("text", "fg=yellow") == u"\033[33mtext\033[0m"
    assert stringc("text", "fg=yellow,bg=blue") == u"\033[33;44mtext\033[0m"
    assert stringc("text", "fg=yellow,bg=blue", True) == u"\001\033[33m\002text\001\033[0m\002"


# Generated at 2022-06-25 12:51:20.277944
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host="localhost", stats={'failures': 0, 'unreachable': 0, 'changed': 0}, color=True) == u"localhost                                                            "
    assert hostcolor(host="localhost", stats={'failures': 1, 'unreachable': 0, 'changed': 1}, color=True) == u"\n\033[31m\033[1mlocalhost\033[0m\n\033[0m                                                            "


# Generated at 2022-06-25 12:51:23.313936
# Unit test for function stringc
def test_stringc():
    test_cases = [0]
    for i in test_cases:
        # unit tests
        globals()[f'test_case_{i}']()
        print(f'Test case {i} OK')

# Generated at 2022-06-25 12:51:25.215137
# Unit test for function colorize
def test_colorize():
    list_0 = None
    var_0 = colorize(list_0, list_0, list_0)


# Generated at 2022-06-25 12:51:35.794018
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('good', {'changed': 0, 'ok': 1, 'failures': 0, 'skipped': 0, 'unreachable': 0}) == u'good                   '
    assert hostcolor('good', {'changed': 1, 'ok': 0, 'failures': 0, 'skipped': 0, 'unreachable': 0}) == u'good                   '

# Generated at 2022-06-25 12:51:43.535863
# Unit test for function stringc
def test_stringc():
    assert stringc(text=u'ok',
                   color=u'ok',
                   wrap_nonvisible_chars=False) == u"\n".join([u"\033[92mok\033[0m"])
    assert stringc(text=u'ok',
                   color=u'ok',
                   wrap_nonvisible_chars=True) == u"\n".join([u"\001\033[92m\002ok\001\033[0m\002"])

    assert stringc(text=u'changed',
                   color=u'changed',
                   wrap_nonvisible_chars=False) == u"\n".join([u"\033[93mchanged\033[0m"])

# Generated at 2022-06-25 12:51:53.315748
# Unit test for function stringc
def test_stringc():
    # Assert enables debugging mode
    assert stringc("color_error", C.COLOR_ERROR) == u"\n33[31mcolor_error\033[0m"
    assert stringc("color_warn", C.COLOR_WARN) == u"\n33[33mcolor_warn\033[0m"
    assert stringc("color_changed", C.COLOR_CHANGED) == u"\n33[36mcolor_changed\033[0m"
    assert stringc("color_ok", C.COLOR_OK) == u"\n33[32mcolor_ok\033[0m"
    assert stringc("color_dark", C.COLOR_DARK) == u"\n33[34mcolor_dark\033[0m"
    list_0 = None

# Generated at 2022-06-25 12:52:00.457896
# Unit test for function parsecolor
def test_parsecolor():
    function_name = 'parsecolor'
    list_0 = None
    var_0 = parsecolor(list_0)
    assert var_0 == '93', 'Test Failed: %s did not return expected value. Got: %s - Expected: %s' % (function_name, var_0, '93')
    list_0 = 'bright white'
    var_0 = parsecolor(list_0)
    assert var_0 == '97', 'Test Failed: %s did not return expected value. Got: %s - Expected: %s' % (function_name, var_0, '97')
    list_0 = 'color12'
    var_0 = parsecolor(list_0)

# Generated at 2022-06-25 12:52:08.026688
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor(str, dict, True) == "%-37s")
    assert(hostcolor(str, dict, False) == "%-26s")

# Generated at 2022-06-25 12:52:16.578866
# Unit test for function parsecolor

# Generated at 2022-06-25 12:52:20.647564
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = colorize(str_0, 10, str_0)
    assert var_0
    assert var_0 == u'tag:yaml.org,2002:python/dict=10   '


# Generated at 2022-06-25 12:52:29.119752
# Unit test for function stringc

# Generated at 2022-06-25 12:52:30.918320
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = parsecolor(str_0)


# Generated at 2022-06-25 12:52:34.406889
# Unit test for function stringc
def test_stringc():
    s = stringc('Hi', 'blue')
    assert s == u'\033[94mHi\033[0m'
    s = stringc('Hi', 'purple', wrap_nonvisible_chars=True)
    assert s == u'\001\033[35m\002Hi\001\033[0m\002'



# Generated at 2022-06-25 12:52:37.630993
# Unit test for function hostcolor
def test_hostcolor():
    test_hostcolor_0()
    test_hostcolor_1()
    test_hostcolor_2()


# Generated at 2022-06-25 12:52:45.415215
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test_host'
    stats = dict(
        ok=0,
        failures=0,
        skipped=0,
        unreachable=0,
        changed=0,
        dark=0,
        processed=0,
        rescued=0,
        ignored=0,
        ignored_to_total=0,
    )

    ret = hostcolor(host, stats)
    assert ret == u'%-26s' % host

    stats['failures'] = 1
    ret = hostcolor(host, stats)
    assert ret == u'%-37s' % stringc(host, C.COLOR_ERROR)

# Generated at 2022-06-25 12:52:47.617873
# Unit test for function stringc
def test_stringc():
    str_1 = 'red'
    str_2 = 'test'
    var_1 = stringc(str_2, str_1)


# Generated at 2022-06-25 12:52:57.345828
# Unit test for function stringc
def test_stringc():
    # test 0
    str_0 = 'tag:yaml.org,2002:python/dict'
    str_1 = '38;5;161'
    var_0 = stringc(str_0, str_1)
    assert var_0 == '\033[38;5;161mtag:yaml.org,2002:python/dict\033[0m'
    # test 1
    str_0 = 'tag:yaml.org,2002:python/dict'
    str_1 = 'green'
    var_0 = stringc(str_0, str_1, True)
    assert var_0 == '\001\033[32m\002tag:yaml.org,2002:python/dict\001\033[0m\002'
    # test 2

# Generated at 2022-06-25 12:53:07.856096
# Unit test for function stringc
def test_stringc():
    result = stringc('foo', 'red')
    assert isinstance(result, unicode), "stringc returns unicode"
    assert ANSIBLE_COLOR == True, "test only valid when ANSIBLE_COLOR is True"
    assert result == u"\x1b[31mfoo\x1b[0m", "stringc doesn't format in proper SGR sequence"

if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-25 12:53:09.390891
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 'bar', 'baz') == 'foo=bar'


# Generated at 2022-06-25 12:53:13.471427
# Unit test for function colorize
def test_colorize():
    def __init__(self):
        self.__name__ = 'test_colorize'

    def test_colorize_0():
        str_0 = 'tag:yaml.org,2002:python/dict'
        int_0 = 10
        str_1 = colorize(str_0, int_0, True)


# Generated at 2022-06-25 12:53:15.283971
# Unit test for function stringc
def test_stringc():
    for color in C.COLOR_CODES.keys():
        print(stringc('I have a cannon by my side.', color))


# Generated at 2022-06-25 12:53:17.969514
# Unit test for function stringc
def test_stringc():
    stringc('tag:yaml.org,2002:python/dict', 'rgb555')
    stringc('tag:yaml.org,2002:python/dict', 'rgb555')
    stringc('tag:yaml.org,2002:python/dict', 'rgb555')



# Generated at 2022-06-25 12:53:21.937458
# Unit test for function hostcolor
def test_hostcolor():
    var_1 = '1.1.1.1'
    var_2 = {'unreachable': 0, 'skipped': 2, 'ok': 3, 'failures': 6, 'changed': 2}
    var_3 = test_hostcolor_0(var_1, var_2)
    print(var_3)


# Generated at 2022-06-25 12:53:22.985273
# Unit test for function hostcolor
def test_hostcolor():
    print("Testing function hostcolor")


# Generated at 2022-06-25 12:53:27.279470
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'test_hostcolor'
    int_0 = 0
    var_0 = hostcolor(str_0, int_0, True)


# Generated at 2022-06-25 12:53:36.198650
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'test_host_0'
    test_value_0 = {}
    test_value_0['failures'] = 0
    test_value_0['unreachable'] = 0
    test_value_0['changed'] = 1
    test_value_1 = hostcolor(str_0, test_value_0, True)
    assert test_value_1 == 'test_host_0                 '


# Generated at 2022-06-25 12:53:37.820362
# Unit test for function stringc
def test_stringc():
    str_0 = 'str_0'
    test_stringc_0(str_0)


# Generated at 2022-06-25 12:53:47.739613
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'gray7'
    var_0 = parsecolor(str_0)
    str_1 = 'rgb3333'
    var_1 = parsecolor(str_1)
    str_2 = 'color6'
    var_2 = parsecolor(str_2)
    str_3 = 'purple'
    var_3 = parsecolor(str_3)



# Generated at 2022-06-25 12:53:58.568913
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'k4jfy'
    str_1 = 'yam8j'
    str_2 = 'q1qxj'
    str_3 = '6nj77'
    str_4 = '6g9k0'
    var_0 = {str_0: 1, str_1: 0, str_2: 1, str_3: 0, str_4: 0}
    str_5 = 'e2b'
    var_1 = hostcolor(str_5, var_0)
    str_6 = 'b2a'
    var_2 = hostcolor(str_6, var_0)
    str_7 = 'a5a'
    var_3 = hostcolor(str_7, var_0)
    str_8 = 'c9a'

# Generated at 2022-06-25 12:54:00.382384
# Unit test for function parsecolor
def test_parsecolor():

    # Test case 0
    test_case_0()


# --- end of "pretty" module code.



# Generated at 2022-06-25 12:54:01.896354
# Unit test for function colorize
def test_colorize():
    var_1 = colorize('lead', 1, 'red')
    return var_1


# Generated at 2022-06-25 12:54:03.405138
# Unit test for function colorize
def test_colorize():
    # Test with no options
    var_0 = colorize("lead", 45, None)


# Generated at 2022-06-25 12:54:05.392392
# Unit test for function colorize
def test_colorize():
    lead = "foo"
    num = 0
    color = "red"
    assert colorize(lead, num, color) == u"foo=0  "



# Generated at 2022-06-25 12:54:07.910904
# Unit test for function colorize
def test_colorize():
    lead = 'DIFF'
    num = 1
    color = 'cyan'
    assert colorize(lead, num, color) == stringc(lead+'=1   ', color, wrap_nonvisible_chars=False)



# Generated at 2022-06-25 12:54:08.689400
# Unit test for function hostcolor
def test_hostcolor():
    test_hostcolor_0()


# Generated at 2022-06-25 12:54:18.071421
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = parsecolor(str_0)
    var_1 = parsecolor('red')
    var_2 = parsecolor('yellow')
    var_3 = parsecolor('blue')
    var_4 = parsecolor('green')
    var_5 = parsecolor('white')
    var_6 = parsecolor('black')
    print(var_0)
    print(var_1)
    print(var_2)
    print(var_3)
    print(var_4)
    print(var_5)
    print(var_6)


# Generated at 2022-06-25 12:54:21.556612
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(u'host', dict(changed=u'1'), color=True) == u'host'


if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:54:29.482840
# Unit test for function hostcolor
def test_hostcolor():
    var_1 = hostcolor(str_0, var_0, var_1)



# Generated at 2022-06-25 12:54:32.633441
# Unit test for function colorize
def test_colorize():

    test_str = 'lead'
    test_num = 3
    test_color = 'cyan'
    var_1 = colorize(test_str, test_num, test_color)



# Generated at 2022-06-25 12:54:42.588439
# Unit test for function stringc
def test_stringc():
    assert stringc('some text', 'some_color')
    assert not re.search('\x1b\[[0-9]+m', stringc('some text', 'some_color'))
    assert re.search('\x1b\[[0-9]+m', stringc('some text', 'some_color', wrap_nonvisible_chars=True))
    assert not re.search('\x1b\[[0-9]+m', stringc('some text', 'some_color', wrap_nonvisible_chars=False))
    assert re.search('\x1b\[[0-9]+m', stringc('some text\nsome text', 'some_color', wrap_nonvisible_chars=True))

# Generated at 2022-06-25 12:54:49.940700
# Unit test for function stringc
def test_stringc():
    """ Test stringc() """

# Generated at 2022-06-25 12:54:51.674262
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'unreachable'
    var_0 = hostcolor(str_0, str_0)


# Generated at 2022-06-25 12:54:52.881928
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', 'localhost', True) == hostcolor('localhost', 'localhost', True)


# Generated at 2022-06-25 12:54:55.913828
# Unit test for function hostcolor
def test_hostcolor():
    print(stringc(u"test", u"blue"))
    print(test_case_0())


test_hostcolor()

# --- end "pretty"

# Generated at 2022-06-25 12:54:59.054069
# Unit test for function hostcolor
def test_hostcolor():

    # Check the function was able to handle the default parameter case
    assert callable(hostcolor)

    # Check the function was able to handle the basic case
    assert callable(hostcolor)


# Generated at 2022-06-25 12:55:09.287495
# Unit test for function stringc
def test_stringc():
    str_0 = 'tag:yaml.org,2002:python/dict'
    str_1 = 'tag:yaml.org,2002:python/list'
    str_2 = 'tag:yaml.org,2002:python/unicode'
    str_3 = 'tag:yaml.org,2002:python/int'
    str_4 = 'tag:yaml.org,2002:python/float'
    str_5 = 'tag:yaml.org,2002:str'
    str_6 = 'tag:yaml.org,2002:timestamp#ymd'
    str_7 = 'tag:yaml.org,2002:python/long'
    str_8 = 'tag:yaml.org,2002:null'
    str_9 = 'tag:yaml.org,2002:python/complex'


# Generated at 2022-06-25 12:55:10.126794
# Unit test for function stringc
def test_stringc():
    pass



# Generated at 2022-06-25 12:55:16.095868
# Unit test for function colorize
def test_colorize():
    lead = 'lead'
    num = -267650164
    color = 'color'
    var_0 = colorize(lead, num, color)


# Generated at 2022-06-25 12:55:22.596927
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'CHANGED'
    str_1 = '1.1.1.1'
    str_2 = 'test_hostcolor_0'
    dict_0 = {'changed': int_0, 'failures': int_0, 'unreachable': int_0}
    int_0 = 1
    var_0 = hostcolor(str_1, dict_0)
    str_0 = '\x1b[0m\x1b[0m'
    var_0 = stringc(str_2, str_0)


# Generated at 2022-06-25 12:55:24.263678
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', C.COLOR_WARN) == '\033[33mfoo\033[0m'



# Generated at 2022-06-25 12:55:29.541939
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    dict_0 = {'changed': 0, 'failures': 0, 'unreachable': 0}
    assert hostcolor(str_0, dict_0) == 'localhost              '

# Function hostcolor did not return a value in a test case.
# Function parsecolor did not return a value in a test case.

# Generated at 2022-06-25 12:55:34.084997
# Unit test for function hostcolor
def test_hostcolor():
    hc_0 = hostcolor('foo.example.org', {'failures': 0, 'unreachable': 0, 'changed': 1})
    assert hc_0 == 'foo.example.org                  '


# Generated at 2022-06-25 12:55:35.788678
# Unit test for function colorize
def test_colorize():
    assert colorize(u"abc", 1, u"abc") == u'abc=1   '


# Generated at 2022-06-25 12:55:37.864543
# Unit test for function stringc
def test_stringc():
    str_0 = 'color4'
    var_0 = stringc(str_0, 'yellow', True)


# Generated at 2022-06-25 12:55:47.061040
# Unit test for function stringc
def test_stringc():
    str_0 = u'VdjR8XjWHPSV'
    str_1 = u'p8P6o27iKwz1'
    str_2 = u'f9iexKiIl6Uu'
    var_0 = stringc(str_0, str_1, str_2)
    print(var_0)
    str_3 = u'u5KEVw5Q2uE7'
    str_4 = u'cJZk3N7c8pD1'
    str_5 = u'sq7CJp9XGkxC'
    var_1 = stringc(str_3, str_4, str_5)
    print(var_1)
    str_6 = u'jK8TlBh1nvwJ'
    str_

# Generated at 2022-06-25 12:55:49.762596
# Unit test for function stringc
def test_stringc():
    str_0 = 'tag:yaml.org,2002:python/unicode'
    var_0 = stringc(str_0, 'tag:yaml.org,2002:python/dict', True)


# Generated at 2022-06-25 12:55:59.967904
# Unit test for function stringc
def test_stringc():
    str_1 = 'tag:yaml.org,2002:python/dict'
    str_2 = 'tag:yaml.org,2002:python/dict'
    str_3 = 'tag:yaml.org,2002:python/int'
    str_4 = 'tag:yaml.org,2002:python/int'
    str_5 = 'tag:yaml.org,2002:python/int'
    str_6 = 'tag:yaml.org,2002:python/str'
    str_7 = 'tag:yaml.org,2002:python/float'
    str_8 = 'tag:yaml.org,2002:python/float'
    str_9 = 'tag:yaml.org,2002:python/float'
    var_1 = stringc(str_1, str_2)
    var

# Generated at 2022-06-25 12:56:20.279669
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'tag:yaml.org,2002:python/dict'
    dict_0 = {'dark_gray': 'dark_gray', 'light_gray': 'light_gray', 'green': 'green', 'black': 'black', 'cyan': 'cyan', 'red': 'red', 'yellow': 'yellow', 'white': 'white', 'magenta': 'magenta', 'blue': 'blue'}
    dict_1 = dict_0
    dict_2 = {'dark_gray': 'dark_gray', 'light_gray': 'light_gray', 'green': 'green', 'black': 'black', 'cyan': 'cyan', 'red': 'red', 'yellow': 'yellow', 'white': 'white', 'magenta': 'magenta', 'blue': 'blue'}

# Generated at 2022-06-25 12:56:21.984986
# Unit test for function colorize
def test_colorize():
    assert colorize("lead", "num", True) == "lead=num"


# Generated at 2022-06-25 12:56:25.573174
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'changes': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    ret = hostcolor(host, stats, ANSIBLE_COLOR)
    assert ret == u'localhost                '



# Generated at 2022-06-25 12:56:28.239344
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = parsecolor(str_0)
# --- end "pretty"

# Generated at 2022-06-25 12:56:37.052814
# Unit test for function hostcolor
def test_hostcolor():
    # Host 'jumper' changed
    host = 'jumper'
    stats = {'failures': 0, 'changed': 1, 'ok': 3, 'skipped': 0, 'unreachable': 0}
    color = True
    expected = "jumper                 "
    actual = hostcolor(host, stats, color)
    assert expected == actual, 'Expected: %r, Actual: %r' % (expected, actual)
    # Host 'jumper' unreachable
    host = 'jumper'
    stats = {'failures': 0, 'changed': 0, 'ok': 3, 'skipped': 0, 'unreachable': 1}
    color = True
    expected = "jumper                 "
    actual = hostcolor(host, stats, color)

# Generated at 2022-06-25 12:56:46.131283
# Unit test for function hostcolor
def test_hostcolor():

    # This is a hack to test the function without being too strict
    # on the exact formatting returned by the function.
    with open('hostcolor.txt', 'w') as f:
        f.write(hostcolor('localhost', {'changed': 0,
                                        'failures': 0,
                                        'ok': 0,
                                        'skipped': 0,
                                        'unreachable': 0},
                          True))
    with open('hostcolor.txt', 'r') as f:
        assert f.read() == '\x1b[0;32mlocalhost\x1b[0;0m'


# Generated at 2022-06-25 12:56:52.088733
# Unit test for function stringc
def test_stringc():
    str_0 = 'test'
    str_1 = 'color'
    str_2 = 'W'
    var_2 = parsecolor(str_1)
    var_1 = stringc(str_0, str_2, var_2)
    assert var_1 == '\n'.join(['\033[%sm%s\033[0m' % (var_2, t) for t in str_0.split(u'\n')])


# Generated at 2022-06-25 12:56:58.271375
# Unit test for function parsecolor

# Generated at 2022-06-25 12:57:00.219521
# Unit test for function colorize
def test_colorize():
    assert colorize(*test_case_0()) == 'tag:yaml.org,2002:python/dict'


# Generated at 2022-06-25 12:57:06.987084
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'tag:yaml.org,2002:python/dict'
    host_0 = 'localhost'
    stats_0 = {'skipped': 1, 'ok': 2, 'failed': 3, 'changed': 4, 'unreachable': 5}
    color_0 = False
    var_0 = hostcolor(host_0, stats_0, color_0)
    assert var_0 == u'localhost                  '


# Generated at 2022-06-25 12:57:33.516557
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'tag:yaml.org,2002:python/dict' #tag:yaml.org,2002:python/dict
    var_0 = parsecolor(str_0)
    dict_1 = {'skipped': '0', 'unreachable': '0', 'changed': '0', 'failures': '0', 'ok': '1'}
    str_1 = '1.1.1.1'
    var_1 = hostcolor(str_1, dict_1, True)
    assert var_1 == '1.1.1.1                                   '


# Generated at 2022-06-25 12:57:42.844817
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host'
    dic_0 = {'skipped': 0, 'ok': 1, 'failures': 0, 'changed': 0, 'unreachable': 0}
    var_1 = hostcolor(str_0, dic_0, True)
    str_1 = 'host'
    dic_1 = {'skipped': 0, 'ok': 1, 'failures': 1, 'changed': 0, 'unreachable': 0}
    var_2 = hostcolor(str_1, dic_1, True)
    str_2 = 'host'
    dic_2 = {'skipped': 0, 'ok': 1, 'failures': 0, 'changed': 1, 'unreachable': 0}
    var_3 = hostcolor(str_2, dic_2, True)
   

# Generated at 2022-06-25 12:57:44.909000
# Unit test for function colorize
def test_colorize():
    assert stringc("foo", "red") == "\001\033[31m\002foo\001\033[0m\002", "Should be 'foo'"

# Generated at 2022-06-25 12:57:56.904936
# Unit test for function colorize
def test_colorize():
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = {'changed': 0, 'skipped': 0, 'ok': 1, 'failures': 0, 'dark': 40, 'unreachable': 0}
    str_1 = 'PLAY'
    str_2 = '0'
    bool_0 = ANSIBLE_COLOR
    str_3 = '9'
    bool_1 = bool_0
    str_4 = '2'
    bool_2 = bool_1
    str_5 = '1'
    bool_3 = bool_2
    str_6 = '4'
    bool_4 = bool_3
    str_7 = '11'
    bool_5 = bool_4
    str_8 = '7'
    bool_6 = bool_5
   

# Generated at 2022-06-25 12:58:04.432747
# Unit test for function hostcolor
def test_hostcolor():
    def test_1():
        str_0 = '127.0.0.1'
        int_0 = 12
        int_1 = 1
        int_2 = 0
        int_3 = 1
        var_0 = {
            u'ok': int_0,
            u'changed': int_1,
            u'unreachable': int_2,
            u'failures': int_3
        }
        var_1 = hostcolor(str_0, var_0, False)
        assert(var_1 == u'127.0.0.1              ')

    def test_2():
        str_0 = '127.0.0.1'
        int_0 = 12
        int_1 = 1
        int_2 = 0
        int_3 = 1

# Generated at 2022-06-25 12:58:09.193250
# Unit test for function hostcolor
def test_hostcolor():
    host = ''
    stats = dict(
        failures=0,
        unreachable=0,
        changed=0,
    )
    test_1 = hostcolor(host, stats)
    test_2 = hostcolor(host, stats, color=False)
    if test_1 == test_2:
        return 0
    else:
        return 1


# Generated at 2022-06-25 12:58:11.352649
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'unreachable':0}
    color = True
    ansible_hostcolor(host, stats, color)



# Generated at 2022-06-25 12:58:16.860529
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'changed': 0, 'unreachable': 0}
    host = 'hostname.local'
    color = True
    # Test with host, stats and color
    hostcolor(host, stats, color)

test_case_0()
# --- end "pretty"



# Generated at 2022-06-25 12:58:17.737783
# Unit test for function hostcolor
def test_hostcolor():
    assert str(hostcolor("host", {})) == 'host'

# Generated at 2022-06-25 12:58:23.115202
# Unit test for function hostcolor
def test_hostcolor():
    retval = {}

    host = 'testhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    retval = hostcolor(host, stats, True)


# Generated at 2022-06-25 12:58:46.888029
# Unit test for function hostcolor
def test_hostcolor():
    # pylint: disable=missing-docstring
    text = u'127.0.0.1'
    stats = {u'failures': 0, u'unreachable': 0, u'changed': 0}
    result = hostcolor(text, stats)
    assert result == u'127.0.0.1                '

if __name__ == '__main__':
    test_hostcolor()
    test_case_0()

# Generated at 2022-06-25 12:58:58.262324
# Unit test for function parsecolor
def test_parsecolor():
    assert callable(parsecolor)

    # Case 0
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = parsecolor(str_0)

    assert var_0 == '38;5;135'

    # Case 1
    str_0 = 'magenta_an'
    var_0 = parsecolor(str_0)

    assert var_0 == '35'

    # Case 2
    str_0 = 'violet_ol'
    var_0 = parsecolor(str_0)

    assert var_0 == '35'

    # Case 3
    str_0 = 'green_ol'
    var_0 = parsecolor(str_0)

    assert var_0 == '32'

    # Case 4

# Generated at 2022-06-25 12:59:01.396762
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', stats={
        'failures': 0,
        'unreachable': 0,
        'changed': 0
    }, color=True) == u'host'


# Generated at 2022-06-25 12:59:02.462894
# Unit test for function colorize
def test_colorize():
    """Test for the colorize function."""
    assert colorize("OK", 0, C.COLOR_OK) == u"OK=0   "


# Generated at 2022-06-25 12:59:09.989639
# Unit test for function hostcolor
def test_hostcolor():
    # Test with only one parameter.
    host = 'foo.bar'
    hostcolor(host, stats=None)
    # Test with two parameters.
    host = 'foo.bar'
    stats = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    hostcolor(host, stats)
    # Test with three parameters.
    host = 'foo.bar'
    stats = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    color = True
    hostcolor(host, stats, color)



# Generated at 2022-06-25 12:59:11.206969
# Unit test for function stringc
def test_stringc():
    var_1 = stringc(str_0, var_0, 1)


# Generated at 2022-06-25 12:59:14.471744
# Unit test for function stringc
def test_stringc():
    for str_0 in range(0, 10):
        for int_0 in range(0, 10):
            var_2 = parsecolor(str_0)
            var_3 = stringc(int_0, str_0)


# Generated at 2022-06-25 12:59:22.223372
# Unit test for function stringc
def test_stringc():
    try:
        str_0 = 'tag:yaml.org,2002:python/dict'
        str_1 = 'tag:yaml.org,2002:python/dict'
        str_2 = parsecolor(str_1)
        var_0 = stringc(str_0, str_2)
        assert var_0 == '\n\033[38;5;28mtag:yaml.org,2002:python/dict\033[0m'
    except AssertionError as e:
        raise(e)
    except Exception as e:
        raise(e)
        

# Generated at 2022-06-25 12:59:28.219179
# Unit test for function stringc
def test_stringc():
    str_0 = '7'
    var_0 = stringc(str_0, 'green')
    str_1 = '7'
    str_2 = '7'
    var_1 = stringc(str_1, str_2)
    str_3 = '5'
    var_2 = stringc(str_0, str_3)
    str_4 = '1'
    var_3 = stringc(str_4, str_0)
    str_5 = '7'
    str_6 = '7'
    str_7 = '7'
    var_4 = stringc(str_5, str_6, str_7)


# Generated at 2022-06-25 12:59:30.861561
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    var_0 = hostcolor(str_0, {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0})
    str_0 = 'tag:yaml.org,2002:python/dict'


# Generated at 2022-06-25 12:59:54.857643
# Unit test for function stringc
def test_stringc():
    str_0 = 'tag:yaml.org,2002:python/unicode'
    var_0 = stringc(str_0, C.COLOR_SKIP)
    assert var_0 == u'\x1b[93mtag:yaml.org,2002:python/unicode\x1b[0m'


# Generated at 2022-06-25 13:00:05.749893
# Unit test for function stringc
def test_stringc():
    # Testing result of parsecolor call
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = parsecolor(str_0)

    # Testing function type
    assert callable(stringc), \
        '`stringc` is not a function.'
    # Testing function type with arguments
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = parsecolor(str_0)

    assert callable(stringc), \
        '`stringc` is not a function.'
    # Testing function return type
    str_0 = 'tag:yaml.org,2002:python/dict'
    var_0 = parsecolor(str_0)


# Generated at 2022-06-25 13:00:12.077542
# Unit test for function stringc
def test_stringc():
    str_0 = 'tag:yaml.org,2002:python/str'
    str_1 = 'tag:yaml.org,2002:python/str'
    var_0 = stringc(str_0, str_1)
