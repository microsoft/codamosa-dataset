

# Generated at 2022-06-25 12:50:19.808345
# Unit test for function hostcolor
def test_hostcolor():
    test_host = 'host'
    test_stats = {'failures' : 0,
                  'unreachable' : 0,
                  'changed' : 0}
    test_color = True
    output = hostcolor(test_host, test_stats, test_color)


# Generated at 2022-06-25 12:50:27.942780
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'changed'
    str_1 = 'ok'
    str_2 = 'failed'
    str_3 = 'unreachable'
    str_4 = 'ok'
    dict_0 = dict()
    dict_0['changed'] = 1
    dict_0['ok'] = 1
    dict_0['failures'] = 0
    dict_0['unreachable'] = 0
    dict_1 = dict_0
    dict_1['changed'] = 0
    dict_2 = dict_0
    dict_2['failed'] = 1
    dict_3 = dict_0
    dict_3['unreachable'] = 1
    var_0 = hostcolor(str_0, dict_0)
    var_1 = hostcolor(str_1, dict_1)

# Generated at 2022-06-25 12:50:32.013494
# Unit test for function stringc
def test_stringc():
    str_0 = "color red"
    var_0 = stringc(str_0, 'red')

    str_1 = "color blue"
    var_1 = stringc(str_1, 'blue')

    str_2 = "color cyan"
    var_2 = stringc(str_2, 'cyan')

    str_3 = "color cyan"
    var_3 = stringc(str_3, 'cyan')


# Generated at 2022-06-25 12:50:34.900077
# Unit test for function parsecolor
def test_parsecolor():
    assert(parsecolor('blue') == '34')
    assert(parsecolor('color2') == '38;5;2')
    assert(parsecolor('gray1') == '38;5;232')
    assert(parsecolor('rgb255') == '38;5;255')


# Generated at 2022-06-25 12:50:36.051391
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'q`"'
    var_0 = parsecolor(str_0)


# Generated at 2022-06-25 12:50:37.731258
# Unit test for function parsecolor
def test_parsecolor():
    '''
    Unit test for function parsecolor
    '''
    test_case_0()



# Generated at 2022-06-25 12:50:45.808318
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'q`"'
    var_0 = parsecolor(str_0)
    str_1 = 'red'
    var_1 = parsecolor(str_1)
    str_2 = 'rgb000'
    var_2 = parsecolor(str_2)
    str_3 = 'rgb555'
    var_3 = parsecolor(str_3)
    str_4 = 'rgb111'
    var_4 = parsecolor(str_4)
    str_5 = 'rgb001'
    var_5 = parsecolor(str_5)
    str_6 = 'rgb010'
    var_6 = parsecolor(str_6)
    str_7 = 'rgb100'
    var_7 = parsecolor(str_7)
    str

# Generated at 2022-06-25 12:50:54.104430
# Unit test for function stringc
def test_stringc():
    # Test case 1
    # String: 'q`"'
    # Result: print 'q`"', 'red'
    str_0 = 'q`"'
    color_0 = 'red'
    result_0 = stringc(str_0, color_0, False)
    assert type(result_0) == str
    assert result_0 == '\x1b[31mq`"\x1b[0m'

    # Test case 2
    # String: 'q`"'
    # Result: print 'q`"', 'red'
    str_0 = 'q`"'
    color_0 = 'red'
    result_0 = stringc(str_0, color_0, True)
    assert type(result_0) == str

# Generated at 2022-06-25 12:50:55.057403
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {}) == u'host                     '



# Generated at 2022-06-25 12:50:58.985095
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'q`"'
    str_1 = 'q`"'
    dict_0 = dict()
    dict_0['failures'] = 3
    dict_0['unreachable'] = -1
    dict_0['changed'] = -1
    dict_0['failed'] = 1
    var_0 = hostcolor(str_0, dict_0)
    var_1 = hostcolor(str_1, dict_0, False)


# Generated at 2022-06-25 12:51:15.257573
# Unit test for function stringc
def test_stringc():
    str_1 = '[1]+  Done                    echo \x1b[31m\x1b[0m'
    str_1_out = '[1]+  Done                    echo \033[31m\033[0m'
    assert stringc(str_1, 'red') == str_1_out
    assert stringc(str_1, 'RED') == str_1_out

    str_2 = '''[1]+  Done                    echo \x1b[31mr\x1b[0m'''
    str_2_out = '''[1]+  Done                    echo \033[31mr\033[0m'''
    assert stringc(str_2, 'red') == str_2_out
    assert stringc(str_2, 'RED') == str_2_out


# Generated at 2022-06-25 12:51:20.221174
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'ok': 0, 'changed': 0, 'unreachable': 0, 'failed': 0}) == 'localhost                 '
    assert hostcolor('localhost', {'ok': 0, 'changed': 1, 'unreachable': 0, 'failed': 0}) == '\033[0;34;49mlocalhost                 \033[0m'
    assert hostcolor('localhost', {'ok': 0, 'changed': 0, 'unreachable': 1, 'failed': 0}) == '\033[0;33;49mlocalhost                 \033[0m'
    assert hostcolor('localhost', {'ok': 0, 'changed': 1, 'unreachable': 0, 'failed': 1}) == '\033[0;31;49mlocalhost                 \033[0m'


# Generated at 2022-06-25 12:51:28.223953
# Unit test for function stringc
def test_stringc():
    data = {'a':'1', 'b':'2', 'c':'4', 'd':'8'}
    for k, v in data.iteritems():
        stringc(k, v)

# AnsibleRunner class
#
# This class is intended to be used as an object that holds the state of
# an ansible run, including the host list, and the list of variables to
# be applied to each host.  It also contains methods used to execute the
# play, including running handlers and cleaning up after the run is done.


# Generated at 2022-06-25 12:51:32.661058
# Unit test for function hostcolor
def test_hostcolor():
    print('\n    Unit test for function hostcolor\n    ')

    result = hostcolor('abc', {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0})
    print(u'result:', result)


if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-25 12:51:39.606327
# Unit test for function hostcolor
def test_hostcolor():
    for color in C.COLOR_CODES:
        str_0 = hostcolor("host", {"failures": 0, "unreachable": 0, "changed": 1}, color)
        str_1 = hostcolor("host", {"failures": 1, "unreachable": 0, "changed": 1}, color)
        str_2 = hostcolor("host", {"failures": 0, "unreachable": 1, "changed": 1}, color)
        str_3 = hostcolor("host", {"failures": 0, "unreachable": 0, "changed": 0}, color)

    str_0 = hostcolor("host", {"failures": 0, "unreachable": 0, "changed": 0})
    str_1 = hostcolor("host", {"failures": 0, "unreachable": 0, "changed": 0}, False)

    str

# Generated at 2022-06-25 12:51:50.955145
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    str_1 = '\n    Case 0 :\n    '
    str_2 = '\n    Case 1 :\n    '
    str_3 = '\n    Case 2 :\n    '
    str_4 = '\n    Case 3 :\n    '
    str_5 = '\n    Case 4 :\n    '
    str_6 = '\n    Case 5 :\n    '
    str_7 = '\n    Case 6 :\n    '
    str_8 = '\n    Case 7 :\n    '
    str_9 = '\n    Case 8 :\n    '
    str_10 = '\n    Case 9 :\n    '

# Generated at 2022-06-25 12:51:56.098387
# Unit test for function stringc
def test_stringc():
    assert '\033[31mtext\033[0m' == stringc('text', 'RED'), "test failed"
    assert '\033[34mtext\033[0m' == stringc('text', 'BLUE'), "test failed"
    assert '\033[0mtext\033[0m' == stringc('text', 'NOCOLOR'), "test failed"
    assert '\033[41mtext\033[0m' == stringc('text', 'background red'), "test failed"
    assert '\033[44mtext\033[0m' == stringc('text', 'background blue'), "test failed"
    assert '\033[49mtext\033[0m' == stringc('text', 'background default'), "test failed"

    assert '\033[91mtext\033[0m' == stringc

# Generated at 2022-06-25 12:51:57.607707
# Unit test for function colorize
def test_colorize():
    assert colorize('a', 1, True) == 'a=1   '


# Generated at 2022-06-25 12:51:59.028401
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    return
    

# Generated at 2022-06-25 12:52:09.425563
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}

    result = hostcolor(host, stats, color=True)
    assert result == '%-37s' % '\033[0;32mlocalhost\x1b[0m'

    stats = {'failures': 2, 'unreachable': 0, 'changed': 0}

    result = hostcolor(host, stats, color=True)
    assert result == '%-37s' % '\033[0;31mlocalhost\x1b[0m'

    stats = {'failures': 0, 'unreachable': 2, 'changed': 0}

    result = hostcolor(host, stats, color=True)

# Generated at 2022-06-25 12:52:16.881801
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '
    print(str_0, end='')
    result = hostcolor('macbook!', {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0})
    assert result == 'macbook!                  '


# Generated at 2022-06-25 12:52:21.284491
# Unit test for function stringc
def test_stringc():
    for color in C.COLOR_CODES:
        text = 'This is %s text.' % color
        if C.ANSIBLE_NOCOLOR:
            assert text == stringc(text, color)
        else:
            assert text != stringc(text, color)


# Generated at 2022-06-25 12:52:22.917782
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '



# Generated at 2022-06-25 12:52:30.698189
# Unit test for function stringc
def test_stringc():
    sep = u"-" * 76
    print(sep)
    print(stringc(u"String in color", "green"))
    print(stringc(u"Another string in color", "purple"))
    print(sep)
    print(stringc(u"String in colors", "purple:green"))
    print(stringc(u"String in colors", "blue:white:pink:black"))
    print(stringc(u"String in colors", "rgb100100100:rgb100100100"))
    print(stringc(u"String in colors", "rgb100100100:italic"))
    print(stringc(u"String in colors", "rgb100100100", True), end=" ")
    print(stringc(u"(with non-visible chars wrapped)", "rgb100100100", True))


# Generated at 2022-06-25 12:52:33.226992
# Unit test for function stringc
def test_stringc():
    # Test case 0
    str_0 = 'Ran 0 tests in 0.000s'
    print(str_0)
    assert str_0 == 'Ran 0 tests in 0.000s'


# Generated at 2022-06-25 12:52:41.411313
# Unit test for function colorize
def test_colorize():
    """
    Unit test for function colorize
    """
    str_out_1 = 'failures=0  '
    str_out_2 = '\x1b[0;32mchanged=2  \x1b[0m'
    str_out_3 = '\x1b[0;31mfailures=1  \x1b[0m'
    str_out_4 = '\x1b[0;31mfailures=1  \x1b[0m'

    assert colorize('failures', 0, None) == str_out_1

    assert colorize('changed', 2, C.COLOR_CHANGED) == str_out_2

    assert colorize('failures', 1, C.COLOR_ERROR) == str_out_3

    assert colorize('failures', 1, None)

# Generated at 2022-06-25 12:52:51.469131
# Unit test for function stringc
def test_stringc():
    print('\n    Unit test for function stringc\n    ')
    result = stringc('stringc', 'blue')
    assert result == '\033[1;34mstringc\033[0m', 'Expected: \033[1;34mstringc\033[0m. Got: %s'%result
    result = stringc('stringc', 'blue',  wrap_nonvisible_chars=True)
    assert result == '\001\033[1;34m\002stringc\001\033[0m\002', 'Expected: \001\033[1;34m\002stringc\001\033[0m\002. Got: %s'%result
    result = stringc('stringc', 'bold')

# Generated at 2022-06-25 12:52:54.611001
# Unit test for function hostcolor
def test_hostcolor():
    result = hostcolor('my-host', {'ok': 1, 'failed': 0, 'dark': 0, 'changed': 0})
    assert(result == '%-37s' % 'my-host')


# Generated at 2022-06-25 12:52:55.557196
# Unit test for function stringc
def test_stringc():
    stringc('hello', 'ok')


# Generated at 2022-06-25 12:53:00.145236
# Unit test for function colorize
def test_colorize():
    str_1 = '    Unit test for function colorize\n    '
    str_2 = u"%-4s=%s   " % ('foo', 'bar')

    assert str_1 == '\n    Unit test for function colorize\n    ', "The unit test string 'str_1' is not equal to the result of '\n    Unit test for function colorize\n    '"
    assert str_2 == u"%-4s=%s   ", "The unit test string 'str_2' is not equal to the result of u'%-4s=%s   '"


# Generated at 2022-06-25 12:53:12.989416
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    str_1 = '\n    Formatting a string:\n    '
    str_2 = '\n    Formatting a string with escape characters (`wrap_nonvisible_chars=True`):\n    '
    str_3 = '\n    Formatting a string with an invalid color name should fail:\n    '
    str_4 = '\n    Formatting a string with color `off` should not change anything:\n    '
    str_5 = '\n    Formatting a string involving multiple line breaks:\n    '
    str_6 = '\n    Formatting a string with multiple colors:\n    '
    test_string = 'Hello World'

# Generated at 2022-06-25 12:53:19.520170
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '
    stats_0 = {'changed': 0, 'failures': 0, 'unreachable': 0, 'skipped': 0, 'ok': 0}
    host_0 = 'localhost.localdomain'
    try:
        assert u'%-37s' == hostcolor(host_0, stats_0, True), "the values should be equals"
        str_1 = '%-37s' % stringc(host_0, C.COLOR_OK)
        assert str_1 == hostcolor(host_0, stats_0, True), "the values should be equals"
    except AssertionError as e:
        print(str_0 + str(e))
        raise
    else:
        print(str_0 + 'the values are equals')


# Generated at 2022-06-25 12:53:22.066144
# Unit test for function stringc
def test_stringc():
    test_str = 'test_stringc'
    print(stringc(test_str, 'blue'))
    print(stringc(test_str, 'blue', True))



# Generated at 2022-06-25 12:53:29.336523
# Unit test for function colorize
def test_colorize():
    print('\n    Unit test for function colorize\n    ')
    print(colorize('ok', 4, 'green'))
    print(colorize('changed', 0, 'red'))
    print(colorize('unreachable', 9, 'red'))
    print(colorize('failures', 1, 'red'))
    print(colorize('skipped', 3, 'green'))


# Generated at 2022-06-25 12:53:34.170001
# Unit test for function stringc
def test_stringc():
    assert stringc('Some text', 'red') == u'\033[31mSome text\033[0m'
    assert stringc('Some text', 'red', wrap_nonvisible_chars=True) == u'\001\033[31m\002Some text\001\033[0m\002'


# Generated at 2022-06-25 12:53:36.449729
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '


# Generated at 2022-06-25 12:53:39.042550
# Unit test for function colorize
def test_colorize():
    print("\n    Unit test for function colorize\n    ")
    print(colorize("HOST", 9, "red"))
    print(colorize("FAIL", 0, "green"))


# Generated at 2022-06-25 12:53:42.557618
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '
    host = '10.0.0.1'
    stats = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}

    result = hostcolor(host, stats)
    print(result)


# Generated at 2022-06-25 12:53:45.879409
# Unit test for function colorize
def test_colorize():
    print('\n    Unit test for function colorize\n    ')
    # test case #0
    str_0 = colorize('name', 'num', 'color')
    str_1 = '\033[38;5;2mname=num \033[0m'
    print(str_0)
    print(str_1)
    assert str_0 == str_1


# Generated at 2022-06-25 12:53:56.387530
# Unit test for function colorize
def test_colorize():
    print('\n    Unit test for function colorize\n    ')
    print('Test 1: Colorizing a string')
    print('    ' + colorize('foo', 'baz', 'green'))
    print()
    print('Colorizing a string (nocolor)')
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    print('    ' + colorize('foo', 'baz', 'green'))
    print()
    ANSIBLE_COLOR = True
    print('Colorizing a string (default value)')
    print('    ' + colorize('foo', 'baz'))
    print()
    print('Colorizing a string (color=False)')
    print('    ' + colorize('foo', 'baz', color=False))
    print()


# Generated at 2022-06-25 12:54:08.756035
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    list_0 = [u'\033[1m', 'YELLOW']
    list_1 = [u'\033[38;5;3m', 'color3']
    list_2 = [u'\033[38;5;21m', 'rgb100']
    list_3 = [u'\033[38;5;235m', 'gray1']
    list_4 = [u'\033[0m', 'reset']
    list_5 = [u'\033[0m', None]
    list_6 = [u'\033[31m', 'red']
    list_7 = [u'\033[31m', 'RED']

# Generated at 2022-06-25 12:54:13.847179
# Unit test for function hostcolor
def test_hostcolor():
    host = 'Debian-75-wheezy-64-minimal'
    stats = {'changed': 0, 'failures': 0, 'skipped': 0, 'ok': 2, 'unreachable': 0}
    color = True
    assert hostcolor(host, stats, color) == u'%-37s' % stringc(host, 'green')


# Generated at 2022-06-25 12:54:15.390176
# Unit test for function colorize
def test_colorize():
    s = colorize('ok', 0, None)



# Generated at 2022-06-25 12:54:19.419944
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test'
    stats = {'failures':0, 'unreachable':0,'changed':0}
    return hostcolor(host, stats) == 'test                        '


# Generated at 2022-06-25 12:54:25.594576
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '
    host_0 = 'ABC'
    stats_0 = {'skipped': 0, 'failures': 0, 'ok': 1, 'dark': 0, 'changed': 0, 'processed': 1, 'rescued': 0, 'ignored': 0, 'unreachable': 0}
    color_0 = True
    str_1 = hostcolor(host_0, stats_0, color_0)


# Generated at 2022-06-25 12:54:32.831361
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    str_1 = '\n        color: %s'
    str_2 = '\n        color: %s'
    str_3 = '\n        color: %s'
    print (str_0)
    print (str_1 % stringc('hello world', 'green'))

if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-25 12:54:35.317100
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 123
    color = None
    assert colorize(lead, num, color) == u'foo=123 '


# Generated at 2022-06-25 12:54:42.632243
# Unit test for function stringc
def test_stringc():
    # Test for str, color as string
    assert str(stringc('foo', 'changed')) == u"\033[32mfoo\033[0m"

    # Test for str, color as tuple
    assert str(stringc('foo', ('red', 'green'))) == u"\033[31;32mfoo\033[0m"

    # Test for unicode
    assert stringc(u'foo', 'changed') == u"\033[32mfoo\033[0m"


# Generated at 2022-06-25 12:54:49.996599
# Unit test for function colorize
def test_colorize():
    str_0_0 = 'Changed'
    str_0_1 = 1
    str_0_2 = 'green'
    print(colorize(str_0_0, str_0_1, str_0_2))
    str_1_0 = 'Ok'
    str_1_1 = 0
    str_1_2 = 'green'
    print(colorize(str_1_0, str_1_1, str_1_2))
    str_2_0 = 'Changed'
    str_2_1 = 2
    str_2_2 = 'yellow'
    print(colorize(str_2_0, str_2_1, str_2_2))
    str_3_0 = 'Changed'
    str_3_1 = -1
    str_3_2 = 'red'

# Generated at 2022-06-25 12:54:59.849746
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        assert hostcolor("192.168.1.1", {'changed': 1}) == u"192.168.1.1                \033[0;34m\033[0m"
        assert hostcolor("192.168.1.1", {'failures': 1}) == u"192.168.1.1                \033[0;31m\033[0m"
        assert hostcolor("192.168.1.1", {'unreachable': 1}) == u"192.168.1.1                \033[0;31m\033[0m"
        assert hostcolor("192.168.1.1", {'changed': 1, 'failures': 1}) == u"192.168.1.1                \033[0;31m\033[0m"

# Generated at 2022-06-25 12:55:06.368169
# Unit test for function stringc
def test_stringc():
    str_0 = 'stringc() passed test_case_0'
    test_case_0()
    return str_0


# Generated at 2022-06-25 12:55:12.701048
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    This should print yellow: '
    host = 'testhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
    str_1 = '\n    This should print red: '
    stats = {'failures': 1, 'unreachable': 0, 'changed': 1}
    str_2 = '\n    This should print normal: '
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}


# Generated at 2022-06-25 12:55:16.811868
# Unit test for function hostcolor
def test_hostcolor():
    host = 'host'
    stats = {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    color = True
    assert hostcolor(host,stats,color) == 'host                    '

    stats['changed'] = 10
    assert hostcolor(host, stats, color) == 'host                    '

    stats['failures'] = 5
    assert hostcolor(host, stats, color) == 'host                    '

    stats['unreachable'] = 1
    assert hostcolor(host, stats, color) == 'host                    '

# Generated at 2022-06-25 12:55:19.376590
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    str_1 = 'This is a block of text printed in color'
    print_0 = stringc(str_1, C.COLOR_WARN)
    print_1 = stringc(str_1, 'color3')



# Generated at 2022-06-25 12:55:24.716119
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '
    host_0 = 'test_host_0'
    stats_0 = {
        'skipped': 0,
        'failures': 0,
        'ok': 0,
        'unreachable': 0,
        'changed': 0,
        'processed': 1,
        'dark': 0
        }
    color_0 = True
    # assert str_0 == hostcolor(host_0, stats_0, color_0)


# Generated at 2022-06-25 12:55:30.684872
# Unit test for function hostcolor
def test_hostcolor():
    host_0 = 'hello'
    stats_0 = {'failures': '0', 'ok': '1', 'unreachable': '0', 'changed': '0'}
    color_0 = True
    hostcolor_0 = 'hello'
    assert hostcolor(host_0, stats_0, color_0) == hostcolor_0



# Generated at 2022-06-25 12:55:41.107599
# Unit test for function stringc
def test_stringc():
    """Test for function stringc."""
    str_1 = '\n    Unit test for function stringc\n    '
    str_2 = '\n    The first result should be a color.\n    '
    str_3 = '\n    The second result should be a different color.\n    '
    str_4 = '\n    Test 1 of 2 passed.\n    '
    str_5 = '\n    Test 2 of 2 passed.\n    '
    str_6 = '\n    Test passed.\n    '
    str_7 = '\n    Test failed.\n    '

    # Test with a valid color
    output = stringc('The quick brown fox jumped over the lazy dogs.', 'green')

# Generated at 2022-06-25 12:55:42.647021
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '


# Generated at 2022-06-25 12:55:50.281590
# Unit test for function hostcolor
def test_hostcolor():
    print('\n Unit test for function hostcolor \n')
    color = True
    host = 'localhost'
    stats = {}
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    print(hostcolor(host, stats, color))
    assert hostcolor(host, stats, color) == '-37s'
    stats['failures'] = 1
    print(hostcolor(host, stats, color))
    assert hostcolor(host, stats, color) == '-37s'
    stats['failures'] = 0
    stats['unreachable'] = 1
    print(hostcolor(host, stats, color))
    assert hostcolor(host, stats, color) == '-37s'
    stats['unreachable'] = 0
    stats['changed'] = 1
   

# Generated at 2022-06-25 12:56:00.409259
# Unit test for function stringc
def test_stringc():
    str_1 = '\n    Unit test for function stringc\n    '
    print(str_1)

    print(stringc('normal', 'default'))
    print(stringc('black', 'default'))
    print(stringc('red', 'default'))
    print(stringc('green', 'default'))
    print(stringc('yellow', 'default'))
    print(stringc('blue', 'default'))
    print(stringc('magenta', 'default'))
    print(stringc('cyan', 'default'))
    print(stringc('white', 'default'))
    print(stringc('gray', 'default'))
    print(stringc('grey', 'default'))
    print(stringc('bright', 'default'))
    print(stringc('color6', 'default'))

# Generated at 2022-06-25 12:56:07.935574
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '
    

#
# END OF PRETTY
#

# simple get info function

# Generated at 2022-06-25 12:56:19.189005
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '

    print(stringc('Hello, world!', 'green'))
    print(stringc('Hello, world!', 'red'))
    print(stringc('Hello, world!', 'blue'))
    print(stringc('Hello, world!', 'reset'))
    print(stringc('Hello, world!', 'bold'))
    print(stringc('Hello, world!', 'bright'))
    print(stringc('Hello, world!', 'dim'))
    print(stringc('Hello, world!', 'underscore'))
    print(stringc('Hello, world!', 'blink'))
    print(stringc('Hello, world!', 'reverse'))
    print(stringc('Hello, world!', 'hidden'))
   

# Generated at 2022-06-25 12:56:25.203473
# Unit test for function hostcolor
def test_hostcolor():
    line = 'Hello world'
    num = '12'
    color = 'Color'
    len_line = len(line)
    if color:
        print(stringc(line, C.COLOR_CHANGED), stringc((num), C.COLOR_CHANGED))
    else:
        print(line, stringc(num, C.COLOR_CHANGED))

if __name__ == '__main__':
    # test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:56:33.139525
# Unit test for function hostcolor

# Generated at 2022-06-25 12:56:36.852390
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 0}
    color = True
    dut_hostcolor = hostcolor(host, stats, color)
    assert  dut_hostcolor == 'localhost                  '


# Generated at 2022-06-25 12:56:45.328933
# Unit test for function colorize
def test_colorize():
    print('\n    Unit test for function colorize\n    ')
    tests = [
        (u'WARNING:', 1234),
        (u'SKIPPED:', 3),
        (u'CHANGED:', 10),
        (u'FAILED:', 8),
        (u'SUCCESS:', 0),
    ]
    colortest = u'%s: %s'
    for (lead, num) in tests:
        fmt = colorize(lead, num, u'yellow')
        msg = colortest % (fmt, num)
        print(msg)


# Generated at 2022-06-25 12:56:53.565090
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    str_1 = stringc('stringc', 'blue', True)
    str_2 = stringc('stringc', 'blue', False)
    str_3 = stringc('rgb123', 'rgb123', False)
    str_4 = stringc('rgb123', 'rgb123', True)
    str_5 = stringc('color233', 'color233', True)
    str_6 = stringc('color233', 'color233', False)
    str_7 = stringc('gray5', 'gray5', True)
    str_8 = stringc('gray5', 'gray5', False)


# Generated at 2022-06-25 12:57:02.755086
# Unit test for function stringc
def test_stringc():
    print('\n    Unit test for function stringc\n')
    str_0 = '\n    Unit test for function stringc\n    '
    str_0 = str_0.rstrip(' ')
    str_0 = str_0.rstrip('\r\n')
    print('%c[0;7m%s\033[0m%c[0;7m%s\033[0m\n' % (27, str_0, 27, str_0))
    str_2 = 'Test stringc function '
    str_3 = 'This is a test string\n'
    str_4 = '\033[1;39m%s\033[0m' % str_3

# Generated at 2022-06-25 12:57:13.051226
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    str_1 = '\n        If the value of ANSIBLE_COLOR is ' + \
            'False, the original string is returned\n    '
    str_2 = '\n        If the value of ANSIBLE_COLOR is ' + \
            'True, the ANSI code is applied to the string\n    '
    str_3 = '\n        The color "black" is valid\n    '
    str_4 = '\n        The color "red" is valid\n    '
    str_5 = '\n        The color "green" is valid\n    '
    str_6 = '\n        The color "yellow" is valid\n    '

# Generated at 2022-06-25 12:57:17.153027
# Unit test for function colorize
def test_colorize():
    print('\n    Unit test for function colorize')
    assert colorize('leads', 10, 'yellow') == stringc('leads=10', 'yellow')
    assert colorize('leads', 0, 'yellow') == 'leads=0   '
    assert colorize('leads', 0, None) == 'leads=0   '
    print('        passed.')

# Generated at 2022-06-25 12:57:31.634081
# Unit test for function hostcolor

# Generated at 2022-06-25 12:57:33.869568
# Unit test for function colorize
def test_colorize():
    str_0 = '\n    Unit test for function colorize\n    '
    print (str_0)


# Generated at 2022-06-25 12:57:43.120185
# Unit test for function stringc
def test_stringc():
    str_1 = '\n    Unit test for function stringc\n    '
    str_2 = 'Courier in default color'
    str_3 = 'Courier in color red'
    str_4 = 'Courier in color green'
    str_5 = 'Courier in color gray2'
    str_6 = 'Courier in color rgb005'
    str_7 = 'Courier in color rgb555'
    str_8 = 'Courier in color rgb155'
    str_9 = 'Courier in color rgb515'
    str_10 = 'Courier in color rgb551'
    str_11 = 'Courier in color rgb111'
    # Test for ANSIBLE_COLOR enabled
    # In addition to checking the output of stringc, also check
    # that the color codes

# Generated at 2022-06-25 12:57:54.558942
# Unit test for function hostcolor
def test_hostcolor():

    print('\n\n    Unit test for function hostcolor\n    ')

    # test case 0

    # pass
    stats_0 = {'skipped': 6, 'no_hosts': 7, 'ignored': 8, 'unreachable': 0, 'skipped_hosts': 10,
               'ok_hosts': [], 'failures': 0, 'ok': 0, 'changed': 2}
    host_0 = 'unit-test-host'
    str_0 = 'Unit test for function hostcolor'
    str_1 = 'unit-test-host                              '
    color_0 = True
    str_2 = hostcolor(host_0, stats_0, color_0)
    if not(str_1 == str_2):
        print('\n test case 0 failed\n')

# Generated at 2022-06-25 12:58:02.565105
# Unit test for function hostcolor
def test_hostcolor():
    class _mock_stats(object):
        def __init__(self):
            self.failures = 0
            self.unreachable = 0
            self.changed = 0
    class _mock_host(object):
        def __init__(self):
            self.name = ' ' * 37
    str_1 = '\n    Unit test for function hostcolor\n    '
    str_2 = hostcolor(_mock_host().name, _mock_stats(), color=False)
    str_3 = u'                                 '
    str_4 = hostcolor(_mock_host().name, _mock_stats(), color=False)
    str_5 = u'                 '


# Generated at 2022-06-25 12:58:06.431246
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '
    assert hostcolor('test', {'failures': 0, 'changed': 1}) == u'\x1b[0;33;49mtest                \x1b[0m', str_0


# Generated at 2022-06-25 12:58:14.466072
# Unit test for function colorize
def test_colorize():
    # This function tests if colorize function works correctly with
    # different lead and num variables.
    #
    # The test cases are:
    # case_0 -- Correct lead and num variable.
    # case_1 -- Wrong lead variable.
    # case_2 -- Wrong num variable.
    # case_3 -- Wrong lead and num variable.

    # case_0
    lead = 'changed'
    num = 1
    c = colorize(lead, num, C.COLOR_CHANGED)
    assert c == stringc(lead + '=' + str(num), C.COLOR_CHANGED)

    # case_1
    lead = '1'
    num = 1
    c = colorize(lead, num, C.COLOR_CHANGED)
    assert c == lead + '=' + str(num)

    # case_2

# Generated at 2022-06-25 12:58:23.535025
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'unreachable': 1, 'failures': 2, 'changed': 0}
    print(hostcolor('host1', stats))
    if ANSIBLE_COLOR:
        print(stringc('host1', C.COLOR_ERROR))
    stats = {'unreachable': 0, 'failures': 2, 'changed': 0}
    print(hostcolor('host2', stats))
    if ANSIBLE_COLOR:
        print(stringc('host2', C.COLOR_ERROR))
    stats = {'unreachable': 0, 'failures': 0, 'changed': 1}
    print(hostcolor('host3', stats))
    if ANSIBLE_COLOR:
        print(stringc('host3', C.COLOR_CHANGED))

# Generated at 2022-06-25 12:58:31.329441
# Unit test for function stringc
def test_stringc():
    ansible_color = True
    str_0 = '\n    Unit test for function stringc\n    '    
    if ansible_color:
        color_code = '\033[38;5;22m'
        fmt = '\033[' + color_code + '%sm' + '%s' + '\033[0m'
        s = '\n'.join([fmt % (color_code, t) for t in str_0.split('\n')])
        print(s)
    else:
        print(str_0)     


# Generated at 2022-06-25 12:58:42.234884
# Unit test for function colorize
def test_colorize():
    """Return a string with color codes based on kwargs."""
    assert colorize('ok', '123', color='green') == 'ok=123'
    assert colorize('ok', 0, color='green') == 'ok=0'
    assert colorize('ok', 123, color=None) == 'ok=123'
    assert colorize('ok', 0, color=None) == 'ok=0'
    assert colorize('changed', '123', color='yellow') == 'changed=123'
    assert colorize('changed', 0, color='yellow') == 'changed=0'
    assert colorize('failed', '123', color='red') == 'failed=123'
    assert colorize('failed', 0, color='red') == 'failed=0'

# Generated at 2022-06-25 12:58:53.309526
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '


# Generated at 2022-06-25 12:58:56.470259
# Unit test for function colorize
def test_colorize():
    print('\n    Unit test for function colorize\n    ')
    print(colorize('foo', 1, 'blue'))
    print(colorize('foo', 0, 'blue'))


# Generated at 2022-06-25 12:59:00.073589
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.utils.color import hostcolor
    from ansible.constants import COLOR_SKIP, COLOR_OK, COLOR_CHANGED, COLOR_ERROR
    str0 = 'localhost'
    dict0 = {'failures': 0, 'unreachable': 0, 'skipped': 0, 'ok': 1, 'changed': 0}
    returncode_0 = hostcolor(str0, dict0, True)
    str1 = 'localhost'
    dict1 = {'failures': 1, 'unreachable': 0, 'skipped': 0, 'ok': 0, 'changed': 0}
    returncode_1 = hostcolor(str1, dict1, True)
    str2 = 'localhost'

# Generated at 2022-06-25 12:59:06.294829
# Unit test for function stringc
def test_stringc():
    str_0 = '\n\n    Unit test for function stringc\n\n    '
    if ANSIBLE_COLOR:
        assert stringc(str_0, 'blue') == u'\033[34m\n\n    Unit test for function stringc\n\n    \033[0m'
    else:
        assert stringc(str_0, 'blue') == u'\n\n    Unit test for function stringc\n\n    '


# Generated at 2022-06-25 12:59:08.600854
# Unit test for function colorize
def test_colorize():
    colorize(lead='\n    Unit test for function colorize\n    ', num=0, color='foo')
    colorize(lead='\n    Unit test for function colorize\n  ', num=0, color='foo')


# Generated at 2022-06-25 12:59:17.639586
# Unit test for function stringc
def test_stringc():
    print("\n    Unit test for function stringc")
    str_0 = "stringc: ansible-playbook!"
    str_1 = "ansible-playbook!"
    str_2 = "stringc: ansible-playbook!"
    str_3 = "stringc: ansible-playbook!"
    str_4 = "stringc: ansible-playbook!"
    str_5 = "stringc: ansible-playbook!"
    str_6 = "stringc: ansible-playbook!"
    str_7 = "stringc: ansible-playbook!"
    str_8 = "stringc: ansible-playbook!"
    str_9 = "stringc: ansible-playbook!"
    str_10 = "stringc: ansible-playbook!"

# Generated at 2022-06-25 12:59:25.983535
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = '\n    Unit test for function hostcolor\n    '
    str_1 = str_0 + 'test for hostcolor with color\n    '
    dict_2 = { }
    dict_2['changed'] = 0
    dict_2['failures'] = 0
    dict_2['unreachable'] = 0
    if(hostcolor('test', dict_2, True) == u'\u001b[38;5;46mtest\u001b[0m\u0020'):
        print('test 1 pass')
    else:
        print('test 1 fail')
    dict_2['changed'] = 0
    dict_2['failures'] = 0
    dict_2['unreachable'] = 1

# Generated at 2022-06-25 12:59:27.608805
# Unit test for function colorize
def test_colorize():
    str_1 = '\n    Unit test for function colorize\n    '
    

# Generated at 2022-06-25 12:59:32.204810
# Unit test for function stringc
def test_stringc():
    str_0 = '\n    Unit test for function stringc\n    '
    print(stringc(str_0, 'black'))
    print(stringc(str_0, 'blue'))
    print(stringc(str_0, 'cyan'))
    print(stringc(str_0, 'green'))
    print(stringc(str_0, 'magenta'))
    print(stringc(str_0, 'red'))
    print(stringc(str_0, 'white'))
    print(stringc(str_0, 'yellow'))


# Generated at 2022-06-25 12:59:37.720299
# Unit test for function hostcolor
def test_hostcolor():
    host = 'testhost'
    stats = {'failures': 1, 'unreachable': 1, 'skipped': 1, 'changed': 0, 'ok': 0, 'dark': 0}
    # function to test with hardcoded answer
    assert hostcolor(host, stats) == u'\x1b[31mtesthost              \x1b[0m'


# Generated at 2022-06-25 12:59:52.068029
# Unit test for function colorize
def test_colorize():
    results_0 = colorize('foo', 1, 'blue')
    results_1 = colorize('foo', 0, 'red')
    results_2 = colorize('foo', 0, None)
    results_3 = colorize('foo', 1, None)
    print(results_0)
    print(results_1)
    print(results_2)
    print(results_3)


# Generated at 2022-06-25 13:00:02.210794
# Unit test for function stringc
def test_stringc():

    str_1 = '\n    Unit test for function stringc\n    '
    str_2 = '\n        Case 0: parsecolor function test\n        '
    str_3 = "parsecolor('color234')\n        "
    str_4 = "parsecolor('rgb444')\n        "
    str_5 = "parsecolor('gray12')\n        "
    str_6 = '\n        Case 1: stringc function test\n        '
    str_7 = 'stringc("abcdefg", "red")\n        '
    str_8 = 'stringc("abcdefg", "rgb234")\n        '
    str_9 = 'stringc("abcdefg", "color33")\n        '

    # Case 0: parsecolor function test

# Generated at 2022-06-25 13:00:11.827129
# Unit test for function stringc
def test_stringc():
    # test 1
    str_1 = '\nUnit test for function stringc\n'

    # test 2
    str_2 = '%s=%-4s' % ('changed', str(0))
    str_2_0 = stringc(str_2, 'normal')
    str_2_1 = stringc(str_2, 'normal', True)
    str_result_2 = '\nTest 2: Function call stringc(normal)\nExpected result:      changed=0\nFunction result:      %s\n' % str_2_0
    str_result_2_1 = '\nTest 2.1: Function call stringc(normal, True)\nExpected result:      changed=0\nFunction result:      %s\n' % str_2_1

    # test 3