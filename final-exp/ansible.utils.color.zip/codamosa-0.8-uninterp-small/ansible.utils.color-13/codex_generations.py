

# Generated at 2022-06-25 12:50:18.113880
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()



# Generated at 2022-06-25 12:50:19.975495
# Unit test for function parsecolor
def test_parsecolor():
    try:
        assert(parsecolor(False) == C.COLOR_CODES['DEFAULT'])
    except AssertionError as e:
        print(e)
        test_case_0()


# Generated at 2022-06-25 12:50:26.333605
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = '8[R'
    bool_0 = False
    var_1 = parsecolor('red')
    var_2 = parsecolor('color9')
    var_3 = parsecolor('rgb223')
    var_4 = parsecolor('gray10')
    var_5 = parsecolor('color99')
    var_6 = parsecolor(bool_0)
    assert var_1 is not None
    assert var_2 is not None
    assert var_3 is not None
    assert var_4 is not None
    assert var_5 is not None
    assert var_6 is not None


# Generated at 2022-06-25 12:50:30.129799
# Unit test for function colorize
def test_colorize():
    lead = u'a'
    num = 2
    color = u'b'
    actual = colorize(lead, num, color)
    exp = u'a=2  '
    assert actual == exp, "Expected {}, got {}".format(exp, actual)


if __name__ == "__main__":
    test_case_0()
    test_colorize()

# Generated at 2022-06-25 12:50:31.652316
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == 'lead=num'


# Generated at 2022-06-25 12:50:32.157446
# Unit test for function parsecolor
def test_parsecolor():
    assert True



# Generated at 2022-06-25 12:50:36.050863
# Unit test for function stringc
def test_stringc():
    print(C.COLOR_CODES)
    # type: (str, str, bool) -> unicode
    # """String in color."""
    # if ANSIBLE_COLOR:
    #     return u"\n".join([u"\033[%sm%s\033[0m" % (parsecolor(color), t) for t in text.split(u'\n')])
    # else:
    #     return text



# Generated at 2022-06-25 12:50:36.878992
# Unit test for function colorize
def test_colorize():
    assert 1 == 1


# Generated at 2022-06-25 12:50:43.394052
# Unit test for function colorize
def test_colorize():
    print(stringc('foo', 'RED'))
    print(stringc('bar', 'green', wrap_nonvisible_chars=True))
    print(colorize('foo', 3, 'RED'))
    print(hostcolor('foo', {'changed' : 1, 'failures' : 0, 'ok' : 0, 'skipped' : 0, 'unreachable' : 0}, color=True))

if __name__ == '__main__':

#     # Unit test for function parsecolor
#     test_parsecolor()
    
    
    
    test_colorize()

# Generated at 2022-06-25 12:50:47.795292
# Unit test for function colorize
def test_colorize():
    num = 1
    lead = "a"
    color = "red"
    colorize(lead,num,color)
    # Expect to be colored
    num = 0
    lead = "a"
    color = "red"
    colorize(lead,num,color)
    # Expect not to be colored
    num = 1
    lead = "a"
    color = 'lime'
    colorize(lead,num,color)


# Generated at 2022-06-25 12:50:59.389096
# Unit test for function hostcolor
def test_hostcolor():
    """
    Function: hostcolor("host", stats, color=True)
    """
    # Test 1: No change to stats
    stats = {
        "ok": 10,
        "failures": 0,
        "unreachable": 0,
        "skipped": 5,
        "changed": 0
    }
    print(u"Testing hostcolor with no change")
    print(u"--------------------------------")
    print(u"Input: hostcolor(\"TEST\", stats, True)")
    print(u"Expected:\t%-37s" % stringc(u"TEST", C.COLOR_OK))
    result = hostcolor(u"TEST", stats, True)
    print(u"Received:\t%s" % result)

# Generated at 2022-06-25 12:51:01.925995
# Unit test for function colorize
def test_colorize():
    assert colorize("a", 16, "red") == "\033[31ma=16  \033[00m"
    assert colorize("a", 0, "red") == "a=0   "

if __name__ == '__main__':
    test_colorize()

# Generated at 2022-06-25 12:51:04.480244
# Unit test for function stringc
def test_stringc():
    # stringc(text, color, wrap_nonvisible_chars=False)
    text = "text"
    color = "color"
    wrap_nonvisible_chars = False
    stringc(text, color, wrap_nonvisible_chars)


# Generated at 2022-06-25 12:51:06.212762
# Unit test for function stringc
def test_stringc():
    assert stringc('Hello World!', 'green') == u'\033[32mHello World!\033[0m'


# Generated at 2022-06-25 12:51:16.272379
# Unit test for function colorize
def test_colorize():
    ret_3 = colorize(0, 0, 'blue')
    assert isinstance(ret_3, str)
    ret_4 = colorize(0, 0, 'red')
    assert isinstance(ret_4, str)
    ret_5 = colorize(0, 0, 'cyan')
    assert isinstance(ret_5, str)
    assert ret_3 == '0=0   '
    assert ret_4 == '0=0   '
    assert ret_5 == '0=0   '


# Generated at 2022-06-25 12:51:24.140462
# Unit test for function hostcolor
def test_hostcolor():
    float_0 = 1571.0
    float_1 = 1664.0
    float_2 = 1537.06611
    float_3 = 1907.0
    float_4 = 1663.0
    float_5 = 1477.0
    str_0 = hostcolor(float_0, float_1)
    assert str_0 == u"%-37s"
    str_1 = hostcolor(float_2, float_3, float_4)
    assert str_1 == u"%-37s"
    str_2 = hostcolor(float_5, float_5)
    assert str_2 == u"%-37s"


# Generated at 2022-06-25 12:51:27.939568
# Unit test for function colorize
def test_colorize():
    lead = 5
    num = 2
    color = 'red'
    var_0 = colorize(lead, num, color)
    return var_0


# Generated at 2022-06-25 12:51:31.702743
# Unit test for function hostcolor
def test_hostcolor():
    float_0 = 879.7
    float_1 = float_0
    var_0 = hostcolor(float_1, float_0)
    assert var_0 == u'%.15f=%.4f' % (float_1, float_0)


# Generated at 2022-06-25 12:51:36.929086
# Unit test for function hostcolor
def test_hostcolor():
    from ansible.module_utils import basic

    # Compute the call function
    float_0 = 1537.06611
    var_0 = hostcolor(float_0, float_0)

    try:
        assert var_0 == u"1537.066110000=1537.066110 "
    except AssertionError as e:
        basic._log.debug("AssertionError caught in function hostcolor: " + str(e))
        return -1

    return 0


# Generated at 2022-06-25 12:51:40.058551
# Unit test for function hostcolor
def test_hostcolor():

    # Errors
    assert hostcolor(u"", {}) == u"                          "
    assert hostcolor(u"", { "foo" : "bar"}) == u"                          "

    # Successes
    assert hostcolor(u"localhost", { "failed" : 0 }) == u"localhost            "

    # Failures
    assert hostcolor(u"localhost", { "failed" : 1 }) == u"localhost            "

# END OF GENERATED CODE

# Generated at 2022-06-25 12:51:54.097375
# Unit test for function hostcolor
def test_hostcolor():
    print(stringc(u'hello', u'green', True))
    print(stringc(u'hello', u'green', False))
    print(stringc(u'hello', u'blue', True))
    print(stringc(u'hello', u'blue', False))
    print(stringc(u'hello', u'255', True))
    print(stringc(u'hello', u'255', False))


# --- end "pretty"

# --- begin ANSIBLE_STRINGS


# Generated at 2022-06-25 12:51:59.482081
# Unit test for function stringc
def test_stringc():
    assert parsecolor("red") == '38;5;160'
    assert stringc("string", "red") == "\033[38;5;160mstring\033[0m"
    assert stringc("string", "red", wrap_nonvisible_chars=True) == "\001\033[38;5;160m\002string\001\033[0m\002"


# Generated at 2022-06-25 12:52:00.470346
# Unit test for function stringc
def test_stringc():
    pass


# vim: ai et sts=4 ts=4 sw=4 ft=python

# Generated at 2022-06-25 12:52:02.311277
# Unit test for function hostcolor
def test_hostcolor():
    float_0 = 94.967725
    var_0 = hostcolor(float_0, float_0, float_0)
    assert var_0 == '94.967725                  '


# Generated at 2022-06-25 12:52:04.459003
# Unit test for function hostcolor
def test_hostcolor():
    imp.reload(ansible.utils.color)
    assert(test_case_0())
# --- end "pretty"



# Generated at 2022-06-25 12:52:08.421309
# Unit test for function colorize
def test_colorize():
    test_case_0()


# --- end of "pretty"

# --- begin "show"

# show
#
# This function is a generic way to spit out key/value pairs from a dict
# as well as key/value/child items from a list of dicts.


# Generated at 2022-06-25 12:52:09.335210
# Unit test for function colorize
def test_colorize():
    test_case_0()


# Generated at 2022-06-25 12:52:11.476242
# Unit test for function hostcolor
def test_hostcolor():
    float_0 = 1537.06611
    var_0 = hostcolor(float_0, float_0)


# Generated at 2022-06-25 12:52:19.149114
# Unit test for function hostcolor
def test_hostcolor():
    float_0 = 1537.06611
    var_0 = hostcolor(float_0, float_0)
    var_1 = hostcolor(float_0, float_0)
    var_2 = hostcolor(float_0, float_0)

    # Test 0
    if (not var_0):
        print(u"Test 0 test_hostcolor failed, output: " + var_0)
    else:
        print(u"Test 0 test_hostcolor successful")

    # Test 1
    if (not var_1):
        print(u"Test 1 test_hostcolor failed, output: " + var_1)
    else:
        print(u"Test 1 test_hostcolor successful")

    # Test 2

# Generated at 2022-06-25 12:52:28.114598
# Unit test for function hostcolor
def test_hostcolor():
    string_0 = "Xe44s %s %s %s %s"
    float_0 = 8.753378
    string_1 = "Z9z1g"
    string_2 = "b8yVu"
    string_3 = "b1lBg1d5h5"
    string_4 = "x276bV7"
    string_5 = "H5eD8h83"
    string_6 = "k55u6"
    string_7 = "f1p6"
    string_8 = "E9Ps6"
    string_9 = "D8g0yA3"
    string_10 = "Q2s8"
    string_11 = "xBb4"
    string_12 = "a4h4a4f4"

# Generated at 2022-06-25 12:52:45.945713
# Unit test for function hostcolor
def test_hostcolor():

    # Simple test of the hostcolor method with a fully changed,
    # unreachable, failed and ok host.

    # Check that a fully ok host is colored green.
    assert hostcolor("localhost", {'changed': 0, 'failures': 0, 'ok': 10, 'skipped': 0, 'unreachable': 0}) == u'localhost                   '

    # Check that a host with unreachable hosts is colored red.
    assert hostcolor("localhost", {'changed': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 1}) == u'\x1b[31m\x1b[1mlocalhost\x1b[0m             '

    # Check that a host with failed hosts is colored red.

# Generated at 2022-06-25 12:52:55.959257
# Unit test for function stringc
def test_stringc():
    print(stringc(u"test", u"red"))
    assert stringc(u"test", u"red") == u"\x1b[31mtest\x1b[0m"
    print(stringc(u"test", u"green"))
    assert stringc(u"test", u"green") == u"\x1b[32mtest\x1b[0m"
    print(stringc(u"test", u"yellow"))
    assert stringc(u"test", u"yellow") == u"\x1b[33mtest\x1b[0m"
    print(stringc(u"test", u"blue"))
    assert stringc(u"test", u"blue") == u"\x1b[34mtest\x1b[0m"

# Generated at 2022-06-25 12:52:56.909953
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == 'lead=num'

# Generated at 2022-06-25 12:53:04.467137
# Unit test for function stringc
def test_stringc():
    assert stringc("message", "black") == "\033[30mmessage\033[0m"
    assert stringc("message", "black", wrap_nonvisible_chars=True) == "\001\033[30m\002message\001\033[0m\002"
    assert stringc("message", "blue") == "\033[34mmessage\033[0m"
    assert stringc("message", "green") == "\033[32mmessage\033[0m"
    assert stringc("message", "pink") == "\033[35mmessage\033[0m"
    assert stringc("message", "red") == "\033[31mmessage\033[0m"
    assert stringc("message", "white") == "\033[37mmessage\033[0m"

# Generated at 2022-06-25 12:53:09.517411
# Unit test for function stringc
def test_stringc():
    assert stringc('Sample text', 'red', wrap_nonvisible_chars=False) \
        == u'\033[31mSample text\033[0m\n'
    assert stringc('Sample text', 'red', wrap_nonvisible_chars=True) \
        == u'\001\033[31m\002Sample text\001\033[0m\002\n'


# Generated at 2022-06-25 12:53:10.907513
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()
    return 0

#
# pretty - End
# ---



# Generated at 2022-06-25 12:53:19.229278
# Unit test for function hostcolor
def test_hostcolor():
    # :: str.strip(str)[source]
    # Return a copy of the string with leading and trailing
    # characters removed. The chars argument is a string specifying
    # the set of characters to be removed. If omitted or None,
    # the chars argument defaults to removing whitespace. The chars
    # argument is not a prefix or suffix; rather, all combinations of
    # its values are stripped:
    # >>> '   spacious   '.strip()
    # 'spacious'
    # >>> 'www.example.com'.strip('cmowz.')
    # 'example'

    assert hostcolor("callsign", 9) == 'callsign    '
    assert hostcolor("callsign", '9') == 'callsign    '

    x = 7
    y = x + 9

# Generated at 2022-06-25 12:53:19.964140
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()


# Generated at 2022-06-25 12:53:20.893059
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()



# Generated at 2022-06-25 12:53:23.027468
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'blue') == '\n\033[94mtest\033[0m'


# Generated at 2022-06-25 12:53:32.942299
# Unit test for function stringc
def test_stringc():
    assert stringc('ansible', 'green') == '\n'.join([u'\033[32m' + t + u'\033[0m' for t in 'ansible'.split('\n')])

# Generated at 2022-06-25 12:53:34.955321
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = "host"
    str_1 = str_0
    str_2 = str_0
    var_0 = hostcolor(str_0, str_1, str_2)


# Generated at 2022-06-25 12:53:42.102519
# Unit test for function stringc
def test_stringc():
    var_0 = stringc('test', 'test', False)
    var_1 = stringc('test', 'test', True)
    var_1 = None
    var_2 = stringc('test', 'test', False)
    var_3 = stringc('test', 'test', True)
    var_3 = None
    var_4 = stringc('test', 'test', False)
    var_5 = stringc('test', 'test', True)
    var_5 = None
    var_6 = stringc('test', 'test', False)
    var_7 = stringc('test', 'test', True)
    var_7 = None
    var_8 = stringc('test', 'test', False)
    var_9 = stringc('test', 'test', True)
    var_9 = None
    var_10

# Generated at 2022-06-25 12:53:46.450739
# Unit test for function colorize
def test_colorize():
    assert "lead=lead" in colorize('lead', 'lead', 'black')
    assert "\033[" in colorize('lead', 'lead', 'black')
    assert "m" in colorize('lead', 'lead', 'black')
    assert "\033[0m" in colorize('lead', 'lead', 'black')


# Generated at 2022-06-25 12:53:53.758492
# Unit test for function hostcolor
def test_hostcolor():
    host = u'localhost'
    stats = dict(ok=1, failures=0, unreachable=0, changed=0, skipped=0)
    var_0 = hostcolor(host, stats, ANSIBLE_COLOR)
    assert(host)
    assert(stats['ok'] == 1)
    assert(stats['failures'] == 0)
    assert(stats['unreachable'] == 0)
    assert(stats['changed'] == 0)
    assert(stats['skipped'] == 0)
    assert(ANSIBLE_COLOR)


# Generated at 2022-06-25 12:53:57.205842
# Unit test for function stringc
def test_stringc():
    text = 'text'
    color = 'color'
    wrap_nonvisible_chars = 'wrap_nonvisible_chars'
    var = stringc(text, color, wrap_nonvisible_chars)



# Generated at 2022-06-25 12:54:01.597908
# Unit test for function hostcolor
def test_hostcolor():
    assert isinstance(hostcolor("foo", {
        'changed': 0,
        'dark': 0,
        'failures': 0,
        'ignored': 0,
        'ok': 0,
        'processed': 0,
        'rescued': 0,
        'skipped': 0,
        'unreachable': 0
    }), str)



# Generated at 2022-06-25 12:54:04.571279
# Unit test for function stringc
def test_stringc():
    str_0 = 'lead'
    str_1 = 'lead'
    try:
        var_0 = stringc(str_0, str_1)
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise


# Generated at 2022-06-25 12:54:08.206713
# Unit test for function colorize
def test_colorize():
    # Testing empty strings
    var_0 = colorize("", "", "")
    # Testing equality
    var_0 = (colorize("", "", "") == "")
    # Testing whitespace
    var_0 = (colorize("", "", "") == "")
    # Testing empty string
    var_0 = (colorize("", "", "") == "")

# Generated at 2022-06-25 12:54:13.260570
# Unit test for function stringc
def test_stringc():
    str_1 = '1 2 3'
    var_1 = stringc(str_1, 'color0')
    print("var_1: %s" % var_1)
    str_2 = '\n'
    var_2 = stringc(str_2, 'color1')
    print("var_2: %s" % var_2)
    str_3 = 'Lead3'
    var_3 = stringc(str_3, 'color2')
    print("var_3: %s" % var_3)
    str_4 = 'lead'
    var_4 = stringc(str_4, 'color3')
    print("var_4: %s" % var_4)
    str_5 = 'Lead5'
    var_5 = stringc(str_5, 'rgb44')

# Generated at 2022-06-25 12:54:22.902191
# Unit test for function hostcolor
def test_hostcolor():
    host = "TestHost"
    stats = {"failures": 0, "unreachable": 0, "changed": 0}
    color = True
    expected_result = "\033[32mTestHost\033[0m"
    actual_result = hostcolor(host, stats, color)
    assert actual_result == expected_result



# Generated at 2022-06-25 12:54:25.264609
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'\n'.join([u'\033[34mfoo=0   \033[0m'])


# Generated at 2022-06-25 12:54:29.483315
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'



# Generated at 2022-06-25 12:54:32.628745
# Unit test for function hostcolor
def test_hostcolor():
    host = stringc('testHost', 'testHost')
    stats = {'failures': 0, 'changed': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == host

# Generated at 2022-06-25 12:54:35.061301
# Unit test for function stringc
def test_stringc():
    test_case_0()


# --- end pretty

ANSI_BOLD = u"\033[1m"



# Generated at 2022-06-25 12:54:40.183469
# Unit test for function colorize
def test_colorize():
    print("Testing colorize...")
    try:
        test_case_0()
        print("Testcase 0: PASS")
    except AssertionError as e:
        print("Testcase 0: FAIL")
        print("Description: " + str(e))
    print("Testing complete!")


# Generated at 2022-06-25 12:54:47.236619
# Unit test for function colorize
def test_colorize():
    def func0(arg0, arg1, arg2):
        return colorize(arg0, arg1, arg2)
    test_cases = [('YaA_pfo_', 0, None), ('I', 1, 'red'), ('3f', 0, 'blue'), ('', 0, 'blue'), ('ZqJ_8hT', 1, 'green'), ('', 0, 'cyan'), ('', 1, 'cyan'), ('', 1, 'red')]
    for test_case in test_cases:
        if test_case == test_cases[len(test_cases) - 1]:
            break
        print(func0(*test_case))


# Generated at 2022-06-25 12:54:54.324452
# Unit test for function stringc
def test_stringc():
    str_0 = 'LZ6#<UQ7nZF8JLkH:v'
    str_1 = 'TJWc7VUv1eUO7NU9e8k'
    var_0 = stringc(str_0, str_1)
    assert var_0 == '\x1b[TJWc7VUv1eUO7NU9e8km\x1b[0m', 'Wrong result'
    str_0 = 'wzYumQk{[898PA'
    str_1 = 'Pmt9ZOrp>M:|~G'
    var_0 = stringc(str_0, str_1, False)

# Generated at 2022-06-25 12:54:55.830218
# Unit test for function colorize
def test_colorize():
    colorize(None, None, None)


# Generated at 2022-06-25 12:55:02.942526
# Unit test for function hostcolor
def test_hostcolor():
    import random
    for i in range(1000):
        host = random.choice(list(C.COLOR_ERRORS))
        stats = {'failures':random.randint(0, 100),
                 'unreachable':random.randint(0, 100),
                 'changed':random.randint(0, 100)}
        color = random.choice([True, False])
        assert(hostcolor(host, stats, color) is not None)


# Generated at 2022-06-25 12:55:08.917370
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost') == 'localhost                '


# Generated at 2022-06-25 12:55:11.669681
# Unit test for function hostcolor
def test_hostcolor():
    host = "test_host"
    stats = {
             "failures":0,
             "unreachable":0,
             "changed":0,
            }
    print(hostcolor(host, stats, True))


# Generated at 2022-06-25 12:55:16.881678
# Unit test for function hostcolor
def test_hostcolor():
    try:
        test_case_0
    except:
        pass


# --- end of "pretty"



# Generated at 2022-06-25 12:55:18.260559
# Unit test for function colorize
def test_colorize():
    assert (colorize('lead', 1, 'green') == stringc('lead=1', 'green'))



# Generated at 2022-06-25 12:55:23.715880
# Unit test for function stringc
def test_stringc():
    str_0 = 'JLXYqpG{HJKyAp\r%!s#6'
    str_1 = 'JLXYqpG{HJKyAp\r%!s#6'
    str_2 = 'JLXYqpG{HJKyAp\r%!s#6'
    var_0 = stringc(str_0, str_1)
    var_1 = stringc(str_2, str_2, False)


# Generated at 2022-06-25 12:55:35.175167
# Unit test for function hostcolor
def test_hostcolor():
    host = 'asdf'
    stats = {'changed': 0,
             'dark': 0,
             'failures': 0,
             'ok': 0,
             'processed': 0,
             'rescued': 0,
             'skipped': 0,
             'unreachable': 0}

    hostcolor(host, stats, False)

    stats = {'changed': 5,
             'dark': 10,
             'failures': 0,
             'ok': 15,
             'processed': 0,
             'rescued': 0,
             'skipped': 0,
             'unreachable': 0}
    hostcolor(host, stats, False)


# Generated at 2022-06-25 12:55:39.699274
# Unit test for function stringc
def test_stringc():
    assert False
    # assert len(stringc("Some Text", "red")) > 0
    # assert stringc("Some Text", "red").startswith("\033[" + parsecolor("red"))
    # assert stringc("Some Text", "red").endswith("\033[0m")


test_case_0()
# --- end "pretty"

# Generated at 2022-06-25 12:55:48.215315
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test_host'
    stats = {'failures' : 0, 'unreachable' : 0, 'changed' : 0}
    # hostcolor(host, stats)
    host = 'test_host'
    stats = {'failures' : 0, 'unreachable' : 1, 'changed' : 0}
    # hostcolor(host, stats)
    host = 'test_host'
    stats = {'failures' : 1, 'unreachable' : 0, 'changed' : 0}
    # hostcolor(host, stats)
    host = 'test_host'
    stats = {'failures' : 0, 'unreachable' : 0, 'changed' : 1}
    # hostcolor(host, stats)
    host = 'test_host'

# Generated at 2022-06-25 12:55:53.393763
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('www.example.com', {'changed': 0, 'skipped': 0, 'failures': 1, 'ok': 1, 'rescued': 0, 'ignored': 0, 'unreachable': 0}, True) == '\x1b[1;91mwww.example.com\x1b[0m'
    assert hostcolor('www.example.com', {'changed': 0, 'skipped': 0, 'failures': 0, 'ok': 1, 'rescued': 0, 'ignored': 0, 'unreachable': 0}, True) == '\x1b[1;92mwww.example.com\x1b[0m'

# Generated at 2022-06-25 12:55:56.620851
# Unit test for function hostcolor
def test_hostcolor():
    var_8 = '127.0.0.1'
    var_12 = {'skipped': 0, 'ok': 2, 'changed': 0, 'dark': 0, 'failures': 0, 'processed': 2, 'unreachable': 0}
    assert u"%-37s" % hostcolor(var_8, var_12) == u"127.0.0.1                  ", "Test failed"


# Generated at 2022-06-25 12:56:08.021055
# Unit test for function stringc
def test_stringc():
    assert stringc('/usr/bin/foo', 'blue') == u"\033[34m/usr/bin/foo\033[0m"



# Generated at 2022-06-25 12:56:14.235057
# Unit test for function stringc
def test_stringc():
    var_0 = u'Hello, world!'
    assert stringc(var_0, u'red') == u'\033[31mHello, world!\033[0m'
    assert stringc(var_0, u'blue') == u'\033[34mHello, world!\033[0m'
    assert stringc(var_0, u'yellow') == u'\033[33mHello, world!\033[0m'
    assert stringc(var_0, u'green') == u'\033[32mHello, world!\033[0m'
    assert stringc(var_0, u'cyan') == u'\033[36mHello, world!\033[0m'

# Generated at 2022-06-25 12:56:22.306345
# Unit test for function colorize
def test_colorize():
    str_0 = 'JLXYqpG{HJKyAp\r%!s#6'
    str_1 = 'JLXYqpG{HJKyAp\r%!s#6'
    var_0 = colorize(str_0, str_1, str_1)
    str_0 = 'JLXYqpG{HJKyAp\r%!s#6'
    str_1 = 'JLXYqpG{HJKyAp\r%!s#6'
    var_1 = colorize(str_0, str_1, str_1)
    assert (var_1 == var_0)



# Generated at 2022-06-25 12:56:25.010942
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures':0, 'unreachable':0, 'changed':0}
    host = 'test'
    colorize = hostcolor(host,stats)
    print(colorize)


# Generated at 2022-06-25 12:56:28.123355
# Unit test for function stringc
def test_stringc():
    str_0 = 'JLXYqpG{HJKyAp\r%!s#6'
    var_0 = stringc(str_0, str_0)


if __name__ == '__main__':
    test_stringc()

# Generated at 2022-06-25 12:56:36.934175
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = dict()
    stats['failures'] = 0
    stats['unreachable'] = 0
    stats['changed'] = 0
    # First, test with color printing
    ANSIBLE_COLOR = True
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats['changed'] = 1
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_CHANGED)
    stats['unreachable'] = 1
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats['unreachable'] = 0
    stats['failures'] = 1

# Generated at 2022-06-25 12:56:44.349684
# Unit test for function stringc
def test_stringc():
    stringc(
        'a6j\r6=8\r<r\r',
        'rgb555',
        False
    )
    stringc(
        'jWEp$#7',
        'rgb555'
    )
    stringc(
        '\rQt7\n',
        'rgb555'
    )
    stringc(
        'M|\rY4\n=twB\r',
        'rgb555'
    )



# Generated at 2022-06-25 12:56:45.285578
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()

# Generated at 2022-06-25 12:56:51.540215
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'JLXYqpG{HJKyAp\r%!s#6'
    list_0 = [52, 1225]
    var_0 = hostcolor(str_0, list_0)
    assert var_0 == 'JLXYqpG{HJKyAp\r%!s#6=5200'

if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:57:01.135584
# Unit test for function stringc
def test_stringc():
    str_0 = 'JLXYqpG{HJKyAp\r%!s#6'
    str_1 = 'q\x1b[0m'
    str_2 = '\x1b[m\x1b[0m'
    str_3 = '\x1b[m\x1b[0m'
    str_4 = 'q\x1b[0m'
    assert stringc(str_0, str_0) == str_1
    assert stringc(str_0, str_0, False) == str_2
    assert stringc(str_0, str_0, True) == str_3
    assert stringc(str_0, str_0, 0) == str_4


# Generated at 2022-06-25 12:57:19.579915
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('fake_host', {'failures': 0, 'unreachable': 0, 'ok': 1, 'skipped': 0, 'changed': 0}) == 'fake_host                    '
    assert hostcolor('fake_host', {'failures': 0, 'unreachable': 0, 'ok': 0, 'skipped': 0, 'changed': 1}) == '\x1b[0;34mfake_host\x1b[0m                   '
    assert hostcolor('fake_host', {'failures': 0, 'unreachable': 1, 'ok': 0, 'skipped': 0, 'changed': 0}) == '\x1b[0;31mfake_host\x1b[0m                   '

# Generated at 2022-06-25 12:57:20.684190
# Unit test for function colorize
def test_colorize():
    # Call function
    result_0 = colorize('lead', 'num', 'color')


# Generated at 2022-06-25 12:57:23.153135
# Unit test for function hostcolor
def test_hostcolor():
    arg0 = '_z'
    arg1 = (None, None, None, None, None, None)
    arg2 = True
    expected_result = '_z                 '
    result = hostcolor(arg0, arg1, arg2)
    assert(result == expected_result)

# Generated at 2022-06-25 12:57:24.126870
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(str, dict, bool) == "%-26s"


# Generated at 2022-06-25 12:57:26.484974
# Unit test for function stringc
def test_stringc():
    assert True


# Generated at 2022-06-25 12:57:35.291842
# Unit test for function stringc
def test_stringc():
    assert ANSIBLE_COLOR
    # stringc(text, color, wrap_nonvisible_chars=False)
    assert stringc('abcd', 'red') == '\x1b[31mabcd\x1b[0m'
    assert stringc('abcd', 'blue') == '\x1b[34mabcd\x1b[0m'
    assert stringc('abcd', 'yellow', True) == '\x01\x1b[33m\x02abcd\x01\x1b[0m\x02'
    assert stringc('abcd', 'green', True) == '\x01\x1b[32m\x02abcd\x01\x1b[0m\x02'


# Generated at 2022-06-25 12:57:44.166695
# Unit test for function colorize
def test_colorize():
    print('Testing colorize...', end='')
    SGR_REGEX = re.compile(r'\033\[([0-9]+;)*[0-9]+m')

    # Test cases
    test_cases = [
        # (lead, num, color, must_have_sgr, must_not_have_sgr)
        ('lead', 123, 'red', ['31'], []),
        ('lead', 123, 'blue', ['34'], []),
        ('lead', 123, 'green', ['32'], []),
        ('lead', 123, None, [], ['32', '34', '31']),
        ('lead', 0, 'green', [], ['32']),
        ('lead', 0, None, [], ['32', '34', '31']),
    ]

    # Check test cases


# Generated at 2022-06-25 12:57:46.887831
# Unit test for function hostcolor
def test_hostcolor():
    host = ''
    stats = {}
    color = True
    assert hostcolor(host, stats, color) == u"%-37s"


# Generated at 2022-06-25 12:57:58.191245
# Unit test for function hostcolor
def test_hostcolor():
    # Check exception for unsupported color name
    try:
        # Get hostcolor for 'not-a-color' color
        hostcolor('test', {'changed': 1}, 'not-a-color')
    except KeyError:
        pass

    # Check support for standard color names
    for key, value in C.COLOR_CODES.items():
        assert(hostcolor('test', {'changed': 1}, key) == 'test')

        # Check support for rgb colors
        assert (hostcolor('test', {'changed': 1}, 'rgb' + ''.join(['0'] * 3)) == 'test')
        assert (hostcolor('test', {'changed': 1}, 'rgb' + ''.join(['5'] * 3)) == 'test')

# Generated at 2022-06-25 12:58:01.073580
# Unit test for function colorize
def test_colorize():
    val_0 = 'green'
    val_1 = colorize('foo', 0, val_0)
    val_2 = colorize('foo', 1, val_0)


# Generated at 2022-06-25 12:58:21.353826
# Unit test for function hostcolor
def test_hostcolor():
    not_in_the_same_directory = False
    if not_in_the_same_directory:
        import sys
        sys.path.insert(0, '..')

    from ansible.compat.tests.mock import patch

    stats = {
        'changed': 0,
        'failures': 0,
        'ok': 1,
        ' skipped': 0,
        'unreachable': 0,
        'dark': 1,
    }

    # Assert that we default to color

# Generated at 2022-06-25 12:58:23.987396
# Unit test for function stringc
def test_stringc():
    str_0 = 'green'
    str_1 = 'hello world'
    var_0 = stringc(str_1, str_0)


# Generated at 2022-06-25 12:58:34.021804
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = u''
    var_1 = {}
    var_2 = 'host'
    var_3 = 'host'
    var_4 = {'host': {}}
    var_5 = 'host'
    var_6 = 'host'
    var_7 = 'host'
    var_8 = 'host'
    var_9 = {'host': {}}
    var_10 = 'host'
    var_11 = 'host'
    var_12 = 'host'
    var_13 = 'host'
    var_14 = {'host': {}}
    var_15 = 'host'
    var_16 = 'host'
    var_17 = 'host'
    var_18 = 'host'
    var_19 = {'host': {}}
    var_20 = 'host'
   

# Generated at 2022-06-25 12:58:38.650872
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {}) == u'host                 '
    assert hostcolor('host', {'changed': 2}, color=False) == u'host               '
    assert hostcolor('host', {'changed': 2}, color=True) == u'host\x1b[38;5;11m               \x1b[0m'


# Generated at 2022-06-25 12:58:47.615309
# Unit test for function hostcolor
def test_hostcolor():
    expected = "%-37s"
    color_true_inputs = [(u"localhost                  ", {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}, True)]
    color_true_expected = [expected]
    color_false_inputs = [(u"localhost                  ", {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}, False)]
    color_false_expected = [expected]
    error_inputs = [(u"localhost                  ", {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}, True)]
    error_expected = [expected]

# Generated at 2022-06-25 12:58:55.097276
# Unit test for function colorize
def test_colorize():
    assert colorize("failed", "0", C.COLOR_ERROR)=='\x1b[31mfailed=0\x1b[0m'
    assert colorize("changed", "0", C.COLOR_CHANGED) == '\x1b[33mchanged=0\x1b[0m'
    assert colorize("ok", "0", C.COLOR_OK) == '\x1b[32mok=0\x1b[0m'


# --- end of "pretty"



# Generated at 2022-06-25 12:59:05.716158
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = dict(changed=0, failures=0, unreachable=0)
    text = hostcolor(host, stats)
    assert(text == u'localhost                 \033[0m')
    stats = dict(changed=1, failures=0, unreachable=0)
    text = hostcolor(host, stats)
    assert(text == u'localhost                 \033[0m')
    stats = dict(changed=0, failures=1, unreachable=0)
    text = hostcolor(host, stats)
    assert(text == u'localhost                 \033[0m')
    stats = dict(changed=0, failures=0, unreachable=1)
    text = hostcolor(host, stats)
    assert(text == u'localhost                 \033[0m')

# Generated at 2022-06-25 12:59:07.671338
# Unit test for function stringc
def test_stringc():
    var_1 = [u'38;5;234']
    var_2 = stringc(u'', u'gray10')


# Generated at 2022-06-25 12:59:11.513901
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'ok'
    str_1 = 'localhost'
    copi_0 = {'skipped': 0, 'failures': 0, 'changed': 0, 'ok': 1, 'unreachable': 0, 'rescued': 0, 'ignored': 0}
    var_0 = hostcolor(str_1, copi_0, str_0)


# Generated at 2022-06-25 12:59:19.920661
# Unit test for function hostcolor
def test_hostcolor():
    host = u'127.0.0.1'
    stats = {
        "changed": 2,
        "dark": None,
        "failures": 3,
        "failures": 0,
        "ok": 5,
        "processed": 5,
        "rescued": 0,
        "restarted": 0,
        "skipped": 0,
        "unreachable": 0
    }
    result = hostcolor(host, stats)

    assert result == "127.0.0.1                 ", 'Expected different result, got "%s" and expected "%s"' % (result, "127.0.0.1                 ")


# Generated at 2022-06-25 12:59:43.541970
# Unit test for function hostcolor
def test_hostcolor():
    # Given parameters
    host = 'www.example.com'
    stats = {'changed': 0, 'unreachable': 0, 'failures': 0}
    color = True

    # Returned value
    returned1 = hostcolor(host, stats, color)

    # Expected value
    expected1 = u"%-37s" % stringc(host, C.COLOR_OK)

    # Unit test assertion
    assert returned1 == expected1, 'Expected "%s", but received "%s"' % (expected1, returned1)



# Generated at 2022-06-25 12:59:53.098644
# Unit test for function colorize
def test_colorize():
    lead = 'lead'
    num = '10'
    color = 'blue'
    # expected result: u'\001\033[38;5;39m\002lead=10  \001\033[0m\002'
    result = colorize(lead, num, color)
    assert result == u'\001\033[38;5;39m\002lead=10  \001\033[0m\002'
    lead = 'lead'
    num = '0'
    color = 'blue'
    # expected result: u'lead=0   '
    result = colorize(lead, num, color)
    assert result == u'lead=0   '

    num = '1'
    color = 'blue'
    # expected result: u'lead=1   '

# Generated at 2022-06-25 13:00:03.054780
# Unit test for function hostcolor
def test_hostcolor():
    #assert(hostcolor((u'127.0.0.1'), {'failures': 0, 'changed': 0, 'skipped': 0, 'ok': 3, 'unreachable': 0}) == "127.0.0.1                 ")
    assert(hostcolor((u'127.0.0.1'), {'failures': 1, 'changed': 0, 'skipped': 0, 'ok': 3, 'unreachable': 0}) == "127.0.0.1                 ")
    assert(hostcolor((u'127.0.0.1'), {'failures': 0, 'changed': 1, 'skipped': 0, 'ok': 3, 'unreachable': 0}) == "127.0.0.1                 ")

# Generated at 2022-06-25 13:00:12.456990
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host0'
    dict_0 = {'pending':0, 'dark':'#000000', 'skipped':0, 'ok':0, 'failures':0, 'changed':0, 'unreachable':0, 'light':'#ffffff', 'light_failed':'#880000', 'dark_ok':'#008800', 'dark_changed':'#884400', 'dark_unreachable':'#888888', 'dark_pending':'#444444', 'dark_skipped':'#444444', 'light_ok':'#00ff00', 'light_changed':'#ffff00', 'light_unreachable':'#888888', 'light_pending':'#ffffff', 'light_skipped':'#888888', 'red':0}
   