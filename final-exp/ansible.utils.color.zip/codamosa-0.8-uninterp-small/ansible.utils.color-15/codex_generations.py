

# Generated at 2022-06-25 12:50:17.670965
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 1, None) == 'lead=1   '
    assert colorize('lead', -1, None) == 'lead=-1  '
    assert ANSIBLE_COLOR == True


# Generated at 2022-06-25 12:50:24.385513
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('yellow') == '33'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('rgb111') == '38;5;72'
    assert parsecolor('gray1') == '38;5;245'
    # assert parsecolor('blahblah') == None
    assert parsecolor('color256') == C.COLOR_CODES['color256']
    assert parsecolor('rgb555') == C.COLOR_CODES['rgb555']
    assert parsecolor('rgb12345') == C.COLOR_CODES['rgb12345']
    assert parsecolor('gray23') == C.COLOR_CODES['gray23']
    assert parsecolor('grape') == C.COLOR_CODES['grape']


# Generated at 2022-06-25 12:50:31.419629
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'color10'
    str_1 = 'rgb000'
    str_2 = 'rgb555'
    str_3 = 'rgb500'
    str_4 = 'rgb050'
    str_5 = 'rgb005'
    str_6 = 'rgb555'
    str_7 = 'rgb151'
    str_8 = 'rgb515'
    str_9 = 'rgb155'
    str_10 = 'rgb255'
    str_11 = 'rgb552'
    str_12 = 'rgb225'
    str_13 = 'gray0'
    str_14 = 'gray7'
    str_15 = 'gray23'
    str_16 = 'gray232'
    str_17 = 'gray255'
    str_18 = None


# Generated at 2022-06-25 12:50:38.232858
# Unit test for function stringc
def test_stringc():
    assert stringc("", "", False) == u'\033[0m\033[0m'
    assert stringc(" ", "", False) == u'\033[0m \033[0m'
    assert stringc("", "", True) == u'\001\033[0m\002\001\033[0m\002'
    assert stringc(" ", "", True) == u'\001\033[0m\002 \001\033[0m\002'
    assert stringc("", None, False) == u'\033[0m'
    assert stringc(" ", None, False) == u' \033[0m'
    assert stringc("", None, True) == u'\001\033[0m\002'

# Generated at 2022-06-25 12:50:41.074342
# Unit test for function hostcolor
def test_hostcolor():
    print(u'\n--- Testing hostcolor ---\n')
    host = u'localhost'
    stats = {u'failures': 0, u'unreachable': 0, u'changed': 0}
    color = True
    hostcolor(host, stats, color)


# Generated at 2022-06-25 12:50:43.542072
# Unit test for function colorize
def test_colorize():
    lead = u"lead"
    num = -944177414
    color = u"color"
    var_1 = colorize(lead, num, color)


# Generated at 2022-06-25 12:50:49.881667
# Unit test for function hostcolor
def test_hostcolor():
    assert (not ANSIBLE_COLOR) or \
        hostcolor(u'foo', dict(changed=0, unreachable=0, failures=0)) == u'foo                             '
    assert (not ANSIBLE_COLOR) or \
        hostcolor(u'foo', dict(changed=0, unreachable=0, failures=1)) == u'foo                             '
    assert (not ANSIBLE_COLOR) or \
        hostcolor(u'foo', dict(changed=1, unreachable=1, failures=1)) == u'foo                             '


# Generated at 2022-06-25 12:50:51.279134
# Unit test for function colorize
def test_colorize():
    lead = '-'
    num = 4
    color = 'red'
    ans = colorize(lead, num, color)
    assert ans == '=-4  '


# Generated at 2022-06-25 12:50:57.906377
# Unit test for function parsecolor
def test_parsecolor():
    # Set values equal to those of the fixture
    matches = re.match(r"color(?P<color>[0-9]+)"
                       r"|(?P<rgb>rgb(?P<red>[0-5])(?P<green>[0-5])(?P<blue>[0-5]))"
                       r"|gray(?P<gray>[0-9]+)", "magenta")
    color = matches.group('color')

# Generated at 2022-06-25 12:51:00.264817
# Unit test for function stringc
def test_stringc():
    bytes_0 = b'\xe8ng\x12s-\\\xa9\x10\xfav\x80\x06|M"\xfb@r'
    var_0 = stringc(bytes_0, bytes_0)
    assert var_0 == u"\u001b[r\u001b[0m"


# Generated at 2022-06-25 12:51:09.057777
# Unit test for function hostcolor
def test_hostcolor():
    host = Unicode()
    stats = Dict[str, Dict[str, int]]
    color = bool
    assert hostcolor(host, stats, color) == "%-26s"


# Generated at 2022-06-25 12:51:14.897939
# Unit test for function hostcolor
def test_hostcolor():
    host = 'ansible.cfg'

    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins

    backup = builtins.__dict__.get('__salt__', None)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

    builtins.__salt__ = {'config.option': lambda *args: True}
    assert hostcolor(host, stats, True) == u'\n'.join([u"\033[38;5;124m\033[1m%-37s\033[0m",
                                                       u"\033[38;5;124m\033[1m%-37s\033[0m"])

    builtins.__salt__ = {'config.option': lambda *args: False}

# Generated at 2022-06-25 12:51:24.386010
# Unit test for function stringc
def test_stringc():
    bytes_0 = b'\x9c\x9f\xc8\xbf\x87'
    assert stringc(bytes_0, bytes_0) == '\n'.join(['\x1b[38;5;83m\x9c\x9f\xc8\xbf\x87\x1b[0m'])
    # Test when function object is passed
    def function_0():
        return b'\xc1N\xf9\xdf\xda'
    assert stringc(function_0(), function_0()) == '\n'.join(['\x1b[38;5;118m\xc1N\xf9\xdf\xda\x1b[0m'])
    # Test when set object is passed

# Generated at 2022-06-25 12:51:32.104916
# Unit test for function stringc
def test_stringc():
    # Ansible tests
    bytes_0 = b'\xe8ng\x12s-\\\xa9\x10\xfav\x80\x06|M"\xfb@r'
    var_0 = stringc(bytes_0, bytes_0)
    assert var_0 == '\xe8ng\x12s-\\\xa9\x10\xfav\x80\x06|M"\xfb@r'
    # Additional tests
    test_case_0()


# Generated at 2022-06-25 12:51:40.197174
# Unit test for function hostcolor
def test_hostcolor():
    """
    >>> u'%-26s' % '127.0.0.1'
    u'127.0.0.1               '
    >>> u'%-37s' % '127.0.0.1'
    u'127.0.0.1                                     '
    >>> hostcolor('127.0.0.1', dict(failures=0, unreachable=0, changed=1))
    u'127.0.0.1                                     '
    """
    pass


# Generated at 2022-06-25 12:51:51.462201
# Unit test for function stringc
def test_stringc():
    func = stringc

    # test 1
    bytes_0 = b'\xe8ng\x12s-\\\xa9\x10\xfav\x80\x06|M"\xfb@r'
    var_0 = func(bytes_0, bytes_0)
    assert var_0 == b'\xe8ng\x12s-\\\xa9\x10\xfav\x80\x06|M"\xfb@r'

    # test 2
    bytes_0 = b'\xe8ng\x12s-\\\xa9\x10\xfav\x80\x06|M"\xfb@r'
    var_0 = func(bytes_0, bytes_0)

# Generated at 2022-06-25 12:52:00.070418
# Unit test for function hostcolor
def test_hostcolor():
    # Unit test for function hostcolor
    # Test for positive case
    if hostcolor('test_host', {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == 'test_host':
        pass # Good
    else:
        pass # Bad


# --- end "pretty"


# --- begin "ansible.constants"

# RFC 4648 base32 alphabet; see:
# https://tools.ietf.org/html/rfc4648#section-7
base32alphabet = b'abcdefghijklmnopqrstuvwxyz234567'

# --- end "ansible.constants"


# --- begin "ansible.utils.unicode"

# ---- unicode.py ---------------------------------------------------------------
#
# (c) 2012, Jan-Piet Mens <jpm

# Generated at 2022-06-25 12:52:06.355349
# Unit test for function stringc

# Generated at 2022-06-25 12:52:09.771387
# Unit test for function colorize
def test_colorize():
    num_0 = -36
    lead_0 = stringc('\x81', 'yellow')
    color_0 = 'cyan'
    var_0 = colorize(lead_0, num_0, color_0)


# Generated at 2022-06-25 12:52:12.086911
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == 'lead=num'
    assert colorize('lead', 'num', None) == 'lead=num'


# Generated at 2022-06-25 12:52:19.514464
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('lead', 0, 'blue')
    'lead=0    '
    >>> colorize('lead', 2, 'green')
    '\\x1b[32mlead=2   \\x1b[0m'
    """


# --- end "pretty"

if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-25 12:52:28.379672
# Unit test for function stringc
def test_stringc():
    assert "\x1b[30mOne\x1b[0m" == stringc("One", "black")
    assert "\x1b[31mTwo\x1b[0m" == stringc("Two", "red")
    assert "\x1b[32mThree\x1b[0m" == stringc("Three", "green")
    assert "\x1b[33mFour\x1b[0m" == stringc("Four", "yellow")
    assert "\x1b[34mFive\x1b[0m" == stringc("Five", "blue")
    assert "\x1b[35mSix\x1b[0m" == stringc("Six", "magenta")
    assert "\x1b[36mSeven\x1b[0m" == stringc("Seven", "cyan")
   

# Generated at 2022-06-25 12:52:35.542845
# Unit test for function stringc
def test_stringc():
    # Call function with arguments
    stringc(u"test", u"yellow")
    stringc(u"test", u"color5")
    stringc(u"test", u"rgb222")
    stringc(u"test", u"gray3")

    # Call function with arguments
    stringc(u"test", u"black")
    stringc(u"test", u"red")
    stringc(u"test", u"green")
    stringc(u"test", u"yellow")
    stringc(u"test", u"blue")
    stringc(u"test", u"purple")
    stringc(u"test", u"cyan")
    stringc(u"test", u"white")

    # Call function with arguments
    stringc(u"test", u"color0")
    string

# Generated at 2022-06-25 12:52:40.640400
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('hostcolor_host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'hostcolor_host                '
    assert hostcolor('hostcolor_host', {'failures': 1, 'unreachable': 0, 'changed': 0}, color=False) == u'hostcolor_host                '
    test_hostcolor_host = 'hostcolor_host'
    test_hostcolor_hostcolor_host_stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(test_hostcolor_host, test_hostcolor_hostcolor_host_stats) == "\x1b[31mhostcolor_host\x1b[0m"

# Generated at 2022-06-25 12:52:43.641913
# Unit test for function stringc
def test_stringc():
    try:
        stringc(None, None)
    except TypeError as err:
        assert str(err) == "unsupported operand type(s) for +: 'NoneType' and 'NoneType'"


# Generated at 2022-06-25 12:52:47.303718
# Unit test for function stringc
def test_stringc():
    print(stringc("test_stringc", "blue"))
    print(stringc("test_stringc", "yellow"))
    print(stringc("test_stringc", "red"))
    print(stringc("test_stringc", "green"))


# Generated at 2022-06-25 12:52:51.331013
# Unit test for function colorize
def test_colorize():
    from ansible.utils.color import colorize
    lead = 'bob'
    num = 0
    color = 'blue'
    assert colorize(lead, num, color) == u"bob=0   "

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-25 12:52:55.192768
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'normal') == '\033[0mfoo\033[0m'
    assert stringc('foo', 'green', wrap_nonvisible_chars=True) == '\001\033[32m\002foo\001\033[0m\002'


# Generated at 2022-06-25 12:52:57.140765
# Unit test for function hostcolor
def test_hostcolor():
    set_0 = None
    set_1 = None
    var_0 = hostcolor(set_0, set_1)



# Generated at 2022-06-25 12:53:01.980886
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = '127.0.0.1'
    var_1 = { 'changed': 1, 'failures': 2, 'unreachable': 3}
    var_2 = True
    var_3 = hostcolor(var_0, var_1, var_2)
    var_4 = '127.0.0.1'
    var_5 = { 'changed': 1, 'failures': 2, 'unreachable': 3}
    var_6 = False
    var_7 = hostcolor(var_4, var_5, var_6)


# Generated at 2022-06-25 12:53:12.960365
# Unit test for function stringc
def test_stringc():
    assert stringc(u'baz', u'red') == u"\033[31mbaz\033[0m"
    assert stringc(u'baz', u'rgb123') == u"\033[38;5;43mbaz\033[0m"
    assert stringc(u'baz', u'rgb255') == u"\033[38;5;231mbaz\033[0m"
    assert stringc(u'baz', u'rgb333') == u"\033[38;5;234mbaz\033[0m"
    assert stringc(u'baz', u'rgb555') == u"\033[38;5;239mbaz\033[0m"


# Generated at 2022-06-25 12:53:16.084521
# Unit test for function hostcolor
def test_hostcolor():
    set_0 = 'host'
    var_1 = {'failures': 0, 'changed': 0, 'unreachable': 0}
    var_0 = hostcolor(set_0, var_1)
    assert var_0 == 'host               '


# Generated at 2022-06-25 12:53:17.535369
# Unit test for function hostcolor
def test_hostcolor():
    host = None
    stats = None
    color = None
    var_0 = hostcolor(host, stats, color)


# Generated at 2022-06-25 12:53:20.628790
# Unit test for function hostcolor
def test_hostcolor():

    ''' Tests hostcolor function '''

    example_host = 'localhost'
    example_stats = {'failures': 0, 'unreachable': 0, 'changed': 0, 'ok': 5}
    expected_result = 'localhost                             '
    assert hostcolor(example_host, example_stats) == expected_result


# Generated at 2022-06-25 12:53:23.027158
# Unit test for function stringc
def test_stringc():
    var_0 = stringc("string", "white", False)
    assert var_0 == u'\033[37mstring\033[0m'


# Generated at 2022-06-25 12:53:33.768899
# Unit test for function stringc
def test_stringc():
    num_errors = 0
    try:
        assert stringc('test') == u"\n".join([u"\033[0mtest\033[0m" for t in 'test'.split(u'\n')])
        assert stringc('test', 'red') == u"\n".join([u"\033[31mtest\033[0m" for t in 'test'.split(u'\n')])
        assert stringc('test', 'red', True) == u"\n".join([u"\001\033[31m\002test\001\033[0m\002" for t in 'test'.split(u'\n')])
    except AssertionError:
        num_errors += 1
    return num_errors


# Generated at 2022-06-25 12:53:34.959035
# Unit test for function stringc
def test_stringc():
    stringc(u"good", u"green")


# Generated at 2022-06-25 12:53:43.685652
# Unit test for function colorize
def test_colorize():
    # Test for global parsecolor
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color11') == '38;5;11'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('rgb111') == '38;5;60'
    assert parsecolor('rgb222') == '38;5;104'
    assert parsecolor('rgb310') == '38;5;135'
    assert parsecolor('rgb321') == '38;5;142'
    assert parsecolor

# Generated at 2022-06-25 12:53:45.978673
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        pass

# vim: fileencoding=utf-8 et ts=4 sts=4 sw=4 tw=0

# Generated at 2022-06-25 12:53:47.651418
# Unit test for function stringc
def test_stringc():
    set_0 = None
    var_0 = stringc(set_0)


# Generated at 2022-06-25 12:54:01.381750
# Unit test for function hostcolor
def test_hostcolor():
    set_0 = "example.com"
    set_1 = 0
    set_2 = 1
    set_3 = 0
    set_4 = 0
    set_5 = True
    var_0 = hostcolor(set_0, 2, set_2)
    var_1 = hostcolor(set_0, 5, set_4)
    var_2 = hostcolor(set_0, 8, set_6)
    var_3 = hostcolor(set_0, 11, set_8)
    var_4 = hostcolor(set_0, 14, set_10)
    var_5 = hostcolor(set_0, 17, set_12)
    var_6 = hostcolor(set_0, 20, set_14)
    var_7 = hostcolor(set_0, 23, set_16)
   

# Generated at 2022-06-25 12:54:03.284292
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = hostcolor(None, None)
    var_1 = hostcolor(None, None, None)


# --- end "pretty"



# Generated at 2022-06-25 12:54:06.772396
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {"failures": 0, "changed": 0, "skipped": 0, "ok": 0, "unreachable": 0}
    color = True
    answer = '%-26s' % host
    string = hostcolor(host, stats, color)
    assert answer == string, "Test Failed"


# Generated at 2022-06-25 12:54:08.846228
# Unit test for function colorize
def test_colorize():
    colorize_0 = None
    colorize_1 = None
    colorize_2 = None
    var_0 = colorize(colorize_0, colorize_1, colorize_2)


# Generated at 2022-06-25 12:54:20.114475
# Unit test for function stringc
def test_stringc():
    assert '\033[31mRed\033[0m' == stringc(u"Red", "RED")
    assert '\033[35mPurple\033[0m' == stringc(u"Purple", "PURPLE")
    assert '\033[32mGreen\033[0m' == stringc(u"Green", "GREEN")
    assert '\033[33mYellow\033[0m' == stringc(u"Yellow", "YELLOW")
    assert '\033[34mBlue\033[0m' == stringc(u"Blue", "BLUE")
    assert '\033[36mCyan\033[0m' == stringc(u"Cyan", "CYAN")

# Generated at 2022-06-25 12:54:23.073186
# Unit test for function stringc
def test_stringc():
    text = None
    color = None
    wrap_nonvisible_chars = None
    result = stringc(text, color, wrap_nonvisible_chars)
    assert type(result) == unicode


# Generated at 2022-06-25 12:54:27.236037
# Unit test for function colorize
def test_colorize():
    # Test colorize() with this input set.
    #   set_0:  '' = '0'
    set_0 = None
    color_0 = None
    str_0 = colorize("", "0", color_0)
    print("\nTest Case 0:\n")
    print("   Expected output:", "0=0   ")
    print("   Actual output:", str_0)
    if str_0 != "0=0   ":
        print("   Test Case 0: FAIL")
    else:
        print("   Test Case 0: PASS")
        return 1
    return 0


# Generated at 2022-06-25 12:54:27.863801
# Unit test for function hostcolor
def test_hostcolor():
    assert True

# Generated at 2022-06-25 12:54:30.101888
# Unit test for function colorize
def test_colorize():
    expect_0 = u'a=0   '
    actual_0 = colorize(u'a', 0, None)
    assert expect_0 == actual_0


# Generated at 2022-06-25 12:54:41.374723
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = None
    var_1 = 'example.invalid'
    var_2 = dict()
    var_3 = True
    if var_0 == var_1 and var_2 == var_3:
        var_4 = u' '
    else:
        var_4 = u'0'
    if var_4 == None:
        var_5 = u' '
    else:
        var_5 = u'0'
    if var_4 == var_5:
        var_6 = True
    else:
        var_6 = True
    var_7 = hostcolor(var_0, var_1, var_2, var_3, var_4, var_5, var_6)
    return var_7

#########################
# main
#########################


# Generated at 2022-06-25 12:54:45.452582
# Unit test for function colorize
def test_colorize():
    pass # no assert



# Generated at 2022-06-25 12:54:49.478069
# Unit test for function stringc
def test_stringc():
    assert stringc(u'test', u'red') == u'\033[31mtest\033[0m'
    assert stringc(u'test', u'red', True) == u'\001\033[31m\002test\001\033[0m\002'
    assert stringc(u'test\ntest', u'red', True) == u'\001\033[31m\002test\n\001\033[0m\002test'
    assert stringc(u'test\ntest', u'red', False) == u'\033[31mtest\ntest\033[0m'



# Generated at 2022-06-25 12:54:54.758045
# Unit test for function colorize
def test_colorize():
    assert colorize('succeeded', 0, 'green') == 'succeeded=0   '
    assert colorize('succeeded', 0, 'red') == 'succeeded=0   '
    assert colorize('failed', 1, 'red') == 'failed=1      '
    assert colorize('failed', 2, 'red') == 'failed=2      '
    assert colorize('changed', 3, 'red') == 'changed=3     '
    assert colorize('changed', 4, 'red') == 'changed=4     '

if __name__ == '__main__':
    test_case_0()
    test_colorize()

# Generated at 2022-06-25 12:55:05.356975
# Unit test for function hostcolor
def test_hostcolor():
    print(stringc('stringc', 'blue'))
    assert hostcolor('test_0', {'ok':0, 'changed':0, 'unreachable':0, 'failed':0}) == 'test_0'
    assert hostcolor('test_1', {'ok':0, 'changed':0, 'unreachable':0, 'failed':1}) == 'test_1'
    assert hostcolor('test_2', {'ok':0, 'changed':1, 'unreachable':0, 'failed':0}) == 'test_2'
    assert hostcolor('test_3', {'ok':0, 'changed':1, 'unreachable':0, 'failed':1}) == 'test_3'

# Generated at 2022-06-25 12:55:10.694683
# Unit test for function hostcolor
def test_hostcolor():
    # Create an object of the class
    obj = null()
    # host from ansible.cfg
    host = C.DEFAULT_HOST_LIST

    # stats from ansible.cfg
    stats = C.DEFAULT_HOST_LIST

    # color from ansible.cfg
    color = C.DEFAULT_HOST_LIST

    # Perform hostcolor
    obj.hostcolor(host, stats, color)


# Generated at 2022-06-25 12:55:13.027835
# Unit test for function hostcolor
def test_hostcolor():
    set_0 = None
    set_1 = None
    set_2 = None
    assert hostcolor(set_0, set_1, set_2) == u"%-26s" % ''


# Generated at 2022-06-25 12:55:16.064283
# Unit test for function stringc
def test_stringc():
    try:
        # Test case 1
        set_0 = None
        set_1 = None
        set_2 = stringc(set_0, set_1)
    except SystemExit as exception:
        # Python code was run and called sys.exit()
        return True
    except Exception as exception:
        # Python code raised an exception but not a SystemExit exception
        return True



# Generated at 2022-06-25 12:55:24.484907
# Unit test for function stringc
def test_stringc():
    if not ANSIBLE_COLOR:
        assert True
        return
    with pytest.raises(TypeError):
        stringc()
    with pytest.raises(TypeError):
        stringc(u"a")
    with pytest.raises(TypeError):
        stringc(u"a", u"b")
    with pytest.raises(TypeError):
        stringc(u"a", u"b", u"c")
    with pytest.raises(TypeError):
        stringc(u"a", u"b", u"c", u"d")
    with pytest.raises(TypeError):
        stringc(u"a", u"b", u"c", u"d", u"e")

# Generated at 2022-06-25 12:55:27.020415
# Unit test for function stringc
def test_stringc():
    set_0 = None
    set_1 = None
    var_0 = stringc(set_0, set_1)


# Generated at 2022-06-25 12:55:38.147193
# Unit test for function hostcolor

# Generated at 2022-06-25 12:55:44.062753
# Unit test for function stringc
def test_stringc():
    var_0 = stringc(
        u'\ud801\udc1c',
        u'\ud801\udc0c',
        False)


# Generated at 2022-06-25 12:55:49.349486
# Unit test for function colorize
def test_colorize():
    host = 'localhost'
    stats = {'changed': 0, 'failures': 1, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    color_0 = colorize(host, stats, True)
    color_1 = colorize(host, stats, False)

    # Test color output
    assert(color_0 == "\001\033[31m\002localhost\001\033[0m\002")
    # Test non-color output
    assert(color_1 == "localhost=1    ")



# Generated at 2022-06-25 12:55:52.725413
# Unit test for function stringc
def test_stringc():
    # Test case 0
    set_0 = None
    set_1 = None
    var_0 = stringc(set_0, set_1)


# Generated at 2022-06-25 12:56:01.724086
# Unit test for function stringc
def test_stringc():
    tests = [
        [u'Hello world', 'red', u'\033[31mHello world\033[0m'],
        [u'Hello world', 'rgb255', u'\033[38;5;255mHello world\033[0m'],
        [u'Hello world', 'rgb2550', u'\033[38;5;2550mHello world\033[0m'],
        [u'Hello world', 'rgb25500', u'\033[38;5;25500mHello world\033[0m'],
        [u'Hello world', 'nonexistentcolor', u'\033[0mHello world\033[0m'],
    ]
    for t in tests:
        assert stringc(t[0], t[1]) == t[2]


# Generated at 2022-06-25 12:56:03.535237
# Unit test for function colorize
def test_colorize():
    assert colorize("test", "test", "test") == "test=test"


# Generated at 2022-06-25 12:56:04.679360
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {}) == u'localhost             '



# Generated at 2022-06-25 12:56:09.174257
# Unit test for function colorize
def test_colorize():
    fun = colorize
    set_0 = u'3'
    set_1 = 3
    set_2 = u'asdf'
    set_3 = None
    var_0 = fun(set_0, set_1, set_2)
    var_1 = fun(set_1, set_2, set_3)


# Generated at 2022-06-25 12:56:20.050303
# Unit test for function colorize
def test_colorize():

    if ANSIBLE_COLOR:

        # Arguments
        lead = u'foo'
        num = u'0'
        color = C.COLOR_OK

        # Return value
        retval = colorize(lead, num, color)
        if retval is None:
            pass
        else:
            print(retval)

        # Arguments
        lead = u'foo'
        num = u'1'
        color = C.COLOR_ERROR

        # Return value
        retval = colorize(lead, num, color)
        if retval is None:
            pass
        else:
            print(retval)

        # Arguments
        lead = u'foo'
        num = u'1'
        color = C.COLOR_CHANGED

        # Return value

# Generated at 2022-06-25 12:56:20.993001
# Unit test for function hostcolor
def test_hostcolor():
    assert 0 == hostcolor("test_0", "dict_0", 0)


# Generated at 2022-06-25 12:56:22.097153
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(None) == parsecolor(None)


# Generated at 2022-06-25 12:56:31.358314
# Unit test for function stringc
def test_stringc():
    set_0 = "test string"
    set_1 = "test string\n"
    set_2 = "test string\ntest string\n"
    var_2 = stringc(set_0, "red")
    print(var_2)
    var_1 = stringc(set_1, "red")
    print(var_1)
    var_0 = stringc(set_2, "red")
    print(var_0)



# Generated at 2022-06-25 12:56:41.798059
# Unit test for function stringc
def test_stringc():
    for color in C.COLOR_CODES:
        result = stringc('Color Test: %s' % color, color)
        result = stringc('Color Test: %s' % color, color)
        result = stringc('Color Test: %s' % color, color, True)
        result = stringc('Color Test: %s' % color, color, True)
        print(result)

    result = stringc('Test Reset', None)
    result = stringc('Test Reset', None)
    result = stringc('Test Reset', None, True)
    result = stringc('Test Reset', None, True)
    print(result)

    result = stringc('Test Reset', 'None')
    result = stringc('Test Reset', 'None')
    result = stringc('Test Reset', 'None', True)
    result = stringc

# Generated at 2022-06-25 12:56:43.932077
# Unit test for function hostcolor
def test_hostcolor():
    set_0 = None
    var_0 = hostcolor(set_0)


# Generated at 2022-06-25 12:56:47.627243
# Unit test for function colorize
def test_colorize():
    assert(colorize('lead', 'num', 'color') == u'lead=num')

if __name__ == "__main__":
    test_case_0()
    test_colorize()

# Generated at 2022-06-25 12:56:51.498440
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = '192.168.1.1'
    var_1 = False
    var_2 = False
    var_3 = hostcolor(var_0, var_1, var_2)
    assert var_3.endswith('192.168.1.1')
    assert var_3.startswith('0')


# Generated at 2022-06-25 12:56:57.125571
# Unit test for function hostcolor
def test_hostcolor():
    stats_0 = {
        'skipped': 0,
        'unreachable_var': 0,
        'failures': 0,
        'ok_var': 1,
        'ok': 1,
        'changed': 0,
        'unreachable': 0,
        'changed_var': 0,
        'dark': 0,
        'failures_var': 0,
        'skipped_var': 0,
    }
    host_0 = 'localhost'
    color_0 = False
    ret_0 = hostcolor(host_0, stats_0, color_0)
    set_0 = '%-26s' % host_0
    var_0 = ret_0 == set_0


# Generated at 2022-06-25 12:57:02.507691
# Unit test for function hostcolor
def test_hostcolor():
    host = '127.0.0.1'
    stats = dict(skipped=0,
                 ok=1,
                 failed=0,
                 unreachable=0,
                 changed=1)
    color = True

    res = hostcolor(host, stats, color)
    assert res == u'127.0.0.1                '
    assert res == u'127.0.0.1                '



# Generated at 2022-06-25 12:57:12.855673
# Unit test for function colorize
def test_colorize():
    """
    Test colorize function in pretty.py
    """
    # Fail Test Case
    set_1 = None
    set_2 = None
    set_3 = None

    var_1 = colorize(set_1, set_2, set_3)
    assert var_1.startswith('\001\033[38;5;')
    assert var_1.endswith('\001\033[0m\002')
    assert len(var_1) == 25

    # Success Test Case
    set_1 = 'thedude'
    set_2 = 5
    set_3 = 'green'

    var_1 = colorize(set_1, set_2, set_3)
    assert var_1.startswith('\001\033[38;5;')
    assert var_1.end

# Generated at 2022-06-25 12:57:16.027108
# Unit test for function colorize
def test_colorize():
    set_0 = None
    lead_0 = None
    num_0 = None
    color_0 = None
    var_0 = colorize(lead_0, num_0, color_0)
    assert var_0 == u"=None", 'Failed test'


# Generated at 2022-06-25 12:57:19.032759
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = "localhost"
    var_1 = {'failures': 0, 'changed': 0, 'unreachable': 0}
    var_2 = True
    hostcolor(var_0, var_1, var_2)


# Generated at 2022-06-25 12:57:32.845832
# Unit test for function hostcolor
def test_hostcolor():
    # Default parameter values
    stats = {'failures': None, 'changed': None, 'unreachable': None}
    color = None
    if ANSIBLE_COLOR:
        if stats['unreachable'] != 0 or stats['failures'] != 0:
            return u"%-37s" % stringc(host, C.COLOR_ERROR)
        elif stats['changed'] != 0:
            return u"%-37s" % stringc(host, C.COLOR_CHANGED)
        else:
            return u"%-37" % stringc(host, C.COLOR_OK)
    else:
        return u"%-26s" % host

if __name__ == '__main__':
    import doctest

    # Regular expression to match method names
    METHOD_RE = re.compile('^test_*')

# Generated at 2022-06-25 12:57:34.851083
# Unit test for function hostcolor
def test_hostcolor():
    set_1 = None
    var_1 = hostcolor(set_1)


# Generated at 2022-06-25 12:57:37.554057
# Unit test for function stringc
def test_stringc():
    st = stringc("blue text", "blue")
    assert st == "\033[34mblue text\033[0m"



# Generated at 2022-06-25 12:57:40.256585
# Unit test for function hostcolor
def test_hostcolor():
    set_1 = None
    set_2 = "foo"
    set_3 = "bar"
    set_4 = "random"
    var_1 = hostcolor(set_1, set_2, set_3)
    var_2 = hostcolor(set_4, set_2, set_3)


# Generated at 2022-06-25 12:57:50.042944
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", {"failures": 1, "unreachable": 0, "changed": 2}, True) == u"\033[31mlocalhost\033[0m"
    assert hostcolor("localhost", {"failures": 0, "unreachable": 3, "changed": 2}, True) == u"\033[31mlocalhost\033[0m"
    assert hostcolor("localhost", {"failures": 1, "unreachable": 1, "changed": 2}, True) == u"\033[31mlocalhost\033[0m"
    assert hostcolor("localhost", {"failures": 1, "unreachable": 0, "changed": 0}, True) == u"\033[31mlocalhost\033[0m"

# Generated at 2022-06-25 12:58:00.533632
# Unit test for function stringc
def test_stringc():
    x = 'Hello, World!'
    assert stringc('', 'green') == ''
    assert stringc('', 'green', wrap_nonvisible_chars=True) == ''
    assert stringc('Hello', 'green') == '\x1b[32mHello\x1b[0m'
    assert stringc('Hello', 'green', wrap_nonvisible_chars=True) == '\x01\x1b[32m\x02Hello\x01\x1b[0m\x02'

    assert stringc(x, 'green') == '\x1b[32m%s\x1b[0m' % x

# Generated at 2022-06-25 12:58:03.163778
# Unit test for function stringc
def test_stringc():
    correct_string = 'stringc'
    color = 'blue'
    string = stringc(correct_string, color)
    if string != correct_string:
        sys.exit(1)


# Generated at 2022-06-25 12:58:12.328686
# Unit test for function stringc
def test_stringc():
    if ANSIBLE_COLOR:
        # Testing the first branch of the if condition.
        test_string1 = 'test1'
        test_color1 = C.COLOR_CHANGED
        test_result1 = stringc(test_string1, test_color1)
        assert test_result1 == u"\n".join([u"\033[%sm%s\033[0m" % (C.COLOR_CODES[test_color1], t) for t in test_string1.split(u'\n')])

        # Testing the second branch of the if condition.
        test_string2 = 'test2'
        test_color2 = 'color5'
        test_result2 = stringc(test_string2, test_color2)

# Generated at 2022-06-25 12:58:22.274953
# Unit test for function hostcolor
def test_hostcolor():
    stats_0 = {'ok':0, 'changed':0, 'unreachable':0, 'failures':0}
    var_0 = hostcolor(u'foo',stats_0)
    assert var_0 == u'foo                 '
    if C.ANSIBLE_FORCE_COLOR:
        var_1 = hostcolor(u'bar',stats_0,color=False)
        assert var_1 == u'bar                 '
    else:
        var_1 = hostcolor(u'bar',stats_0,color=False)
        assert var_1 == u'bar                 '

    stats_1 = {'ok':0, 'changed':1, 'unreachable':0, 'failures':0}
    var_2 = hostcolor(u'baz',stats_1)

# Generated at 2022-06-25 12:58:25.010645
# Unit test for function colorize
def test_colorize():
    assert ANSIBLE_COLOR == test_colorize.ansible_color
    assert colorize(u'failed', 1, C.COLOR_ERROR) == u'failed=1   '


# Generated at 2022-06-25 12:58:35.149412
# Unit test for function colorize
def test_colorize():
    # Test case with the following set of parameters: lead='ok', num=0, color=None
    set_0 = None
    var_0 = colorize('ok', 0, set_0)


# Generated at 2022-06-25 12:58:45.299895
# Unit test for function stringc
def test_stringc():

    # Testing with valid inputs
    str_0 = 'stringc'
    color_0 = 'red'
    wrap_nonvisible_chars_0 = False
    str_1 = 'stringc'
    color_1 = 'cyan'
    wrap_nonvisible_chars_1 = False
    str_2 = 'stringc'
    color_2 = 'blue'
    wrap_nonvisible_chars_2 = False
    str_3 = 'stringc'
    color_3 = 'green'
    wrap_nonvisible_chars_3 = False
    str_4 = 'stringc'
    color_4 = 'yellow'
    wrap_nonvisible_chars_4 = False
    str_5 = 'stringc'
    color_5 = 'magenta'

# Generated at 2022-06-25 12:58:50.313237
# Unit test for function hostcolor
def test_hostcolor():
    # hostcolor() should display correct color if no color value is specified
    if ANSIBLE_COLOR:
        set_0 = 'localhost'
        var_1 = {'failures': 0, 'changed': 0, 'unreachable': 0}
        var_2 = False
        var_0 = hostcolor(set_0, var_1, var_2)


# Generated at 2022-06-25 12:58:54.366796
# Unit test for function colorize
def test_colorize():
    lead, num, color = None, None, None
    result = colorize(lead, num, color)
    assert result is not None, "colorize() failed with arguments: %s, %s, %s" % (
        repr(lead), repr(num), repr(color))


# Generated at 2022-06-25 12:59:01.551575
# Unit test for function stringc
def test_stringc():
    var_0 = parsecolor('cyan')
    var_1 = '\n'.join([u'\033[38;5;14m%s\033[0m' % t for t in u'text'.split(u'\n')])
    assert var_0 == 14
    assert var_1 == u'\n'.join([u'\033[38;5;14m%s\033[0m' % t for t in u'text'.split(u'\n')])


# Generated at 2022-06-25 12:59:03.369164
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'red') == u'\033[31mtest\033[0m'


# Generated at 2022-06-25 12:59:11.513823
# Unit test for function stringc
def test_stringc():
    print(stringc(u"Testing", u"black"))
    print(stringc(u"Testing", u"red"))
    print(stringc(u"Testing", u"green"))
    print(stringc(u"Testing", u"yellow"))
    print(stringc(u"Testing", u"blue"))
    print(stringc(u"Testing", u"purple"))
    print(stringc(u"Testing", u"cyan"))
    print(stringc(u"Testing", u"white"))
    print(stringc(u"Testing", u"default"))
    print(stringc(u"Testing", u"black,red"))
    print(stringc(u"Testing", u"black,bold"))
    print(stringc(u"Testing", u"black,underscore"))

# Generated at 2022-06-25 12:59:21.774617
# Unit test for function stringc
def test_stringc():
    ps = parsecolor
    assert stringc("a", "green") == "\033[32ma\033[0m"
    assert stringc("a", "red") == "\033[31ma\033[0m"
    assert stringc("a", "blue") == "\033[34ma\033[0m"
    assert stringc("a", "yellow") == "\033[33ma\033[0m"
    assert stringc("a", "gray") == "\033[38;5;242ma\033[0m"
    assert stringc("a", "white") == "\033[97ma\033[0m"

    # TODO: fix this..

    # assert stringc("a", "sunderlind") == "\033[38;5;145ma\033[0m"
    assert stringc("a", "orange")

# Generated at 2022-06-25 12:59:22.869080
# Unit test for function stringc
def test_stringc():
    set_0 = None
    var_0 = stringc(set_0, parsecolor(set_0))



# Generated at 2022-06-25 12:59:30.008300
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == "localhost                 "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == "\x1b[31mlocalhost\x1b[0m                "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == "\x1b[31mlocalhost\x1b[0m                "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == "\x1b[33mlocalhost\x1b[0m                "



# Generated at 2022-06-25 12:59:41.960244
# Unit test for function colorize
def test_colorize():
    set_1 = None
    set_2 = None
    assert colorize(u'lead', u'7', set_1) == stringc(u"lead=7", C.COLOR_OK)


# end "pretty"

# Generated at 2022-06-25 12:59:45.875051
# Unit test for function hostcolor
def test_hostcolor():
    #
    # Set up test data
    #
    set_1 = None
    set_2 = None

    #
    # Invoke the function
    #
    var_1 = hostcolor(set_1, set_2)



# Generated at 2022-06-25 12:59:48.153743
# Unit test for function colorize
def test_colorize():
    assert colorize(u"OK", 10, u"green") == u"\001\033[38;5;2m\002OK=10  \001\033[0m\002"



# Generated at 2022-06-25 12:59:50.346422
# Unit test for function colorize
def test_colorize():
    lead = u'a'
    num = u'1'
    color = u'cyan'
    var_0 = colorize(lead, num, color)


# Generated at 2022-06-25 12:59:53.623298
# Unit test for function hostcolor
def test_hostcolor():
    arg1 = u'foo'
    arg2 = {u'changed':0, u'skipped':0, u'failures':0, u'unreachable':0, u'ok':0}
    hostcolor(arg1, arg2)



# Generated at 2022-06-25 13:00:03.631236
# Unit test for function stringc
def test_stringc():
    text = u"test\nstring"
    color = u"color31"
    out = stringc(text, color)
    out = u'\u001b[38;5;9mtest\nstring\u001b[0m'
    assert out == u'\u001b[38;5;9mtest\nstring\u001b[0m'
    # Test with non-visible chars
    out2 = stringc(text, color, wrap_nonvisible_chars=True)
    out2 = u'\u0001\u001b[38;5;9m\u0002test\nstring\u0001\u001b[0m\u0002'

# Generated at 2022-06-25 13:00:07.717338
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host=u"10.0.2.59", stats={"skipped": 0, "ok": 1, "failures": 0, "unreachable": 0, "changed": 0}) == u"10.0.2.59                 "


# Generated at 2022-06-25 13:00:09.567966
# Unit test for function hostcolor
def test_hostcolor():
    result = hostcolor(host=None, stats=None, color=None)
