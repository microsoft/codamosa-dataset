

# Generated at 2022-06-25 12:50:22.868251
# Unit test for function hostcolor

# Generated at 2022-06-25 12:50:27.017772
# Unit test for function colorize
def test_colorize():
    # Generate test data
    lead_0 = 'Hello_world'
    num_0 = 3
    color_0 = 0.14

    # Perform colorize
    try:
        ansible_colorize_0 = colorize(lead_0, num_0, color_0)
    except Exception as exception:
        var_1 = exception.args
        sys.exit(1)



# Generated at 2022-06-25 12:50:33.537727
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == '\033[0;32mfoo\033[0m'
    assert stringc('foo', '0;32') == '\033[0;32mfoo\033[0m'
    assert stringc('foo', 'color32') == '\033[0;32mfoo\033[0m'
    assert stringc('foo', 'color1') == '\033[0;31mfoo\033[0m'

    output = stringc('foo', 'rgb111')
    assert output == '\033[0;38;5;125mfoo\033[0m'
    assert isinstance(output, unicode)

    output = stringc('foo', 'gray2')
    assert output == '\033[0;38;5;244mfoo\033[0m'
   

# Generated at 2022-06-25 12:50:40.743009
# Unit test for function parsecolor
def test_parsecolor():
    """
    Tests that parsecolor returns the correct SGR parameter string.
    """
    # Test color values
    assert parsecolor('color36') == u'38;5;36'
    assert parsecolor('color101') == u'38;5;101'
    assert parsecolor('color233') == u'38;5;233'
    assert parsecolor('color255') == u'38;5;255'

    # Test rgb value
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('rgb333') == u'38;5;95'
    assert parsecolor('rgb123') == u'38;5;35'
    assert parsecolor('rgb321')

# Generated at 2022-06-25 12:50:46.770486
# Unit test for function hostcolor
def test_hostcolor():
    dict_0 = {}
    dict_0['unreachable'] = 0
    dict_0['failures'] = 0
    dict_0['changed'] = 0
    float_0 = 0.1
    var_0 = hostcolor(dict_0, float_0)
    assert (var_0==u'{}=0.1')

# --- end "pretty"
# --- begin "deprecated"

#
# NOTE: this will disappear in some future release of this module.
#       This function is only kept here to maintain backwards
#       compatibility with old playbook roles.
#



# Generated at 2022-06-25 12:50:48.364505
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 'num', 'color') == u'lead=num'


# Generated at 2022-06-25 12:50:50.045121
# Unit test for function colorize
def test_colorize():
    assert colorize("server", 1, None) == 'server=1   '


# Generated at 2022-06-25 12:50:52.615931
# Unit test for function colorize
def test_colorize():
    print('Testing colorize')
    if not ANSIBLE_COLOR:
        print(u'test_case_0 skipped')
    else:
        print(u'test_case_0()')
        test_case_0()



# Generated at 2022-06-25 12:50:54.993524
# Unit test for function stringc
def test_stringc():
    import ansible.plugins.callback.default
    assert ansible.plugins.callback.default.stringc("Apple", "red") == u'\n'.join([u'\x1b[31mApple\x1b[0m'])


# Generated at 2022-06-25 12:50:55.703761
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(dict(), float()) == ""


# Generated at 2022-06-25 12:51:05.540639
# Unit test for function stringc
def test_stringc():
    # Test with float, float
    text = 'test_text'
    color = 10
    result = stringc(text, color)
    assert result == '\\033[10mtest_text\\033[0m'



# Generated at 2022-06-25 12:51:12.033622
# Unit test for function stringc
def test_stringc():
    assert stringc("test_text\n", C.COLOR_WARN, True) == u"\u001b[33mtest_text\n\u001b[0m"
    assert stringc("test_text", C.COLOR_WARN) == u"\u001b[33mtest_text\u001b[0m"


# Generated at 2022-06-25 12:51:13.958886
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello World", "white", False))


# Generated at 2022-06-25 12:51:18.745632
# Unit test for function stringc
def test_stringc():
    text = 'Hello'
    color = 'green'
    wrap_nonvisible_chars = False
    actual_output = stringc(text, color, wrap_nonvisible_chars)
    expected_output = '\033[32mHello\033[0m'
    assert actual_output == expected_output



# Generated at 2022-06-25 12:51:21.098207
# Unit test for function hostcolor
def test_hostcolor():

    # Test for method hostcolor
    dict_0 = {}
    float_0 = 0.1
    var_0 = hostcolor(dict_0, float_0)
    assert var_0 == u"%s=%-4s" % (u'', '0.1')



# Generated at 2022-06-25 12:51:23.192484
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()

if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-25 12:51:25.767904
# Unit test for function hostcolor
def test_hostcolor():
    assert "%-37s" == hostcolor(dict(), 0.1)
    assert "%-37s" == hostcolor(0.1, dict())


# Generated at 2022-06-25 12:51:31.612928
# Unit test for function hostcolor
def test_hostcolor():
    results = ''

    # set up test 1 environment
    dict_1 = {}
    float_1 = 0.1

    try:
        var_1 = hostcolor(dict_1, float_1)
        if var_1 != u"%-26s":
            raise Exception('fail test 1')
    except:
        raise Exception('fail test 1')



# Generated at 2022-06-25 12:51:33.526331
# Unit test for function stringc
def test_stringc():
    t = u'\ue6cc'
    print(stringc(t, C.COLOR_HIGHLIGHT, True))


# Generated at 2022-06-25 12:51:43.040726
# Unit test for function colorize
def test_colorize():
    dict_0 = {
        'changed': 0,
        'dark green': 0,
        'failures': 0,
        'ok': 0,
        'skipped': 0,
        'unreachable': 0,
    }
    var_0 = colorize('ok', dict_0['ok'], dict_0['dark green'])
    assert var_0 == 'ok=0', 'Expected var_0 to be 0, but got ''%s''' % var_0
    dict_1 = {
        'changed': 1,
        'dark green': 0,
        'failures': 0,
        'ok': 0,
        'skipped': 0,
        'unreachable': 0,
    }
    var_1 = colorize('changed', dict_1['changed'], dict_1['dark red'])


# Generated at 2022-06-25 12:51:53.543094
# Unit test for function stringc
def test_stringc():
    test_str_0 = '\ue6cc'
    test_str_1 = '\ue6cc'
    test_str_2 = '\ue6cc'
    # write your test code here
    assert ANSIBLE_COLOR == True
    assert test_str_0 == stringc('\ue6cc', 'blue', True)
    assert test_str_1 == stringc('\ue6cc', 'green', False)
    assert test_str_2 == stringc('\ue6cc', 'yellow', True)



# Generated at 2022-06-25 12:52:00.566690
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor('host', 'stats', True) == u"%-37s")
    assert(hostcolor('host', 'stats', True) == u"%-37s")
    assert(hostcolor('host', 'stats', True) == u"%-37s")
    assert(hostcolor('host', 'stats', True) == u"%-37s")
    assert(hostcolor('host', 'stats', True) == u"%-37s")
    assert(hostcolor('host', 'stats', True) == u"%-37s")
    assert(hostcolor('host', 'stats', True) == u"%-37s")
    assert(hostcolor('host', 'stats', True) == u"%-37s")
    assert(hostcolor('host', 'stats', True) == u"%-37s")

# Generated at 2022-06-25 12:52:11.887737
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {u'failures': 0, u'ok': 0,
                                   u'changed': 0, u'unreachable': 0}, True)
    assert hostcolor('localhost', {u'failures': 0, u'ok': 0, u'skipped': 0,
                                   u'changed': 0, u'unreachable': 0}, True)
    assert hostcolor('localhost', {u'failures': 0, u'ok': 0,
                                   u'changed': 1, u'unreachable': 0}, True)
    assert hostcolor('localhost', {u'failures': 3, u'ok': 0,
                                   u'changed': 0, u'unreachable': 0}, True)

# Generated at 2022-06-25 12:52:18.366571
# Unit test for function hostcolor
def test_hostcolor():
    str_1 = '\ue6cc'
    dict_1 = {'failures': 0, 'unreachable': 0, 'changed': 1}
    str_2 = '\u7613'
    dict_2 = {'failures': 0, 'unreachable': 0, 'changed': 1}
    assert hostcolor(str_1, dict_1, bool_0) == u'\ue6cc                                                 '
    assert hostcolor(str_2, dict_1, bool_0) == u'\u7613                                                 '
    assert hostcolor(str_2, dict_2, bool_0) == u'\u7613                                                 '



# Generated at 2022-06-25 12:52:21.414586
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'cyan'
    int_0 = parsecolor(str_0)
    bool_0 = 37 < int_0
    assert (bool_0) == True


# Generated at 2022-06-25 12:52:23.377667
# Unit test for function hostcolor
def test_hostcolor():
    # Testing if the type of the return value of hostcolor() is string
    assert isinstance(hostcolor(str, dict), str)
    pass



# Generated at 2022-06-25 12:52:31.043187
# Unit test for function hostcolor
def test_hostcolor():
    host_0 = '\u4e2d\u4e16\u4eba\u6c11\u653f\u5e9c'
    stats_0 = {
        'changed': '\u30df\u30e5\u30fc\u30b8\u30c3\u30af',
        'failures': '\u30d5\u30a1\u30a4\u30eb',
        'unreachable': '\u30a2\u30f3\u30ea\u30c6\u30a3\u30fc\u30c9\u30b2\u30fc\u30e0'
    }
    color_0 = True

# Generated at 2022-06-25 12:52:37.513948
# Unit test for function stringc
def test_stringc():
    str_0 = '\ue6cc'
    bool_0 = True
    bool_1 = False
    str_1 = u"\[K\x1b"

# Generated at 2022-06-25 12:52:38.488038
# Unit test for function stringc
def test_stringc():
    pass


# Generated at 2022-06-25 12:52:47.944496
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor('abc', {'failures': 0, 'unreachable': 0, 'changed': 0}, bool_0), '', sep='')
    print(hostcolor('abc', {'failures': 1, 'unreachable': 0, 'changed': 0}, bool_0), '', sep='')
    print(hostcolor('abc', {'failures': 0, 'unreachable': 1, 'changed': 0}, bool_0), '', sep='')
    print(hostcolor('abc', {'failures': 0, 'unreachable': 0, 'changed': 1}, bool_0), '', sep='')


if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:53:00.711285
# Unit test for function colorize
def test_colorize():
    assert(colorize(u'FAILED', u'changed=1', 'red') == u"\033[31mFAILED=changed=1\033[0m")
    assert(colorize(u'FAILED', u'unreachable=1', 'red') == u"\033[31mFAILED=unreachable=1\033[0m")
    assert(colorize(u'FAILED', u'failed=1', 'red') == u"\033[31mFAILED=failed=1\033[0m")
    assert(colorize(u'FAILED', u'changed=1', 'red') == u"\033[31mFAILED=changed=1\033[0m")

# Generated at 2022-06-25 12:53:02.315346
# Unit test for function hostcolor
def test_hostcolor():
    print('Test hostcolor')
    print('Test 1')
    stats = {}
    hostcolor('', stats, False)


# Generated at 2022-06-25 12:53:11.241823
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'color_default'
    int_0 = -874
    int_1 = 356
    int_2 = -816
    int_3 = -182
    str_1 = 'color_error'
    str_2 = 'color_changed'
    str_3 = 'color_ok'
    dict_0 = {'changed': int_2, 'failures': int_1, 'unreachable': int_3}
    str_4 = 'color_changed'
    dict_1 = {'changed': int_3, 'failures': int_2, 'unreachable': int_1}
    str_5 = 'color_default'
    str_6 = 'color_ok'
    str_7 = 'color_error'

# Generated at 2022-06-25 12:53:13.514239
# Unit test for function parsecolor
def test_parsecolor():
    int_0 = -599
    var_0 = parsecolor(int_0)
    bool_0 = False


# Generated at 2022-06-25 12:53:20.894009
# Unit test for function parsecolor
def test_parsecolor():
    print(stringc("color test", "color32"))
    # print "color test", color("color32")
    print(stringc("color test", "rgb332"))
    print(stringc("color test", "rgb122"))
    print(stringc("color test", "rgb551"))
    # print "color test", color("rgb332")
    # print "color test", color("rgb122")
    # print "color test", color("rgb551")
    print(stringc("color test", "gray99"))
    print(stringc("color test", "gray87"))
    print(stringc("color test", "red"))
    print(stringc("color test", "green"))
    print(stringc("color test", "yellow"))
    print(stringc("color test", "blue"))

# Generated at 2022-06-25 12:53:32.412666
# Unit test for function stringc
def test_stringc():
    color = 'cyan'
    text = 'good'
    res = stringc(text, color)
    ans = "\033[96mgood\033[0m"
    assert(res == ans), "stringc does not have expected value on simple input"

    color = 'blue'
    text = 'colorful '
    res = stringc(text, color)
    ans = "\033[94mcolorful \033[0m"
    assert(res == ans), "stringc does not have expected value on simple input"

    color = 'red'
    text = 'text '
    res = stringc(text, color)
    ans = "\033[91mtext \033[0m"
    assert(res == ans), "stringc does not have expected value on simple input"

    text = 'more colorful text'

# Generated at 2022-06-25 12:53:41.821278
# Unit test for function parsecolor
def test_parsecolor():
    try:
        assert callable(parsecolor)
    except AssertionError:
        raise AssertionError("function 'parsecolor' not callable")

    # Test using unittest framework
    import unittest
    class parsecolor_test_case(unittest.TestCase):
        def setUp(self):
            pass

        def test_case_0(self):
            int_0 = -599
            var_0 = parsecolor(int_0)
            bool_0 = False

        def test_case_1(self):
            int_1 = -636
            var_1 = parsecolor(int_1)
            bool_1 = False

        @classmethod
        def tearDownClass(self):
            pass


# Generated at 2022-06-25 12:53:47.810347
# Unit test for function stringc
def test_stringc():
    text = "brian"
    color = "rgb055"
    wrap_nonvisible_chars = True
    if ANSIBLE_COLOR:
        color_code = parsecolor(color)
        fmt = u"\033[%sm%s\033[0m"

# Generated at 2022-06-25 12:53:58.613160
# Unit test for function hostcolor
def test_hostcolor():
    string_0 = 'TESTSETTINGS'
    # Set passed_through to 0 if you don't want the values to be passed through
    # the following statements.
    passed_through = 1
    # These are the parameters that are required to run this unit test.
    var_0 = 'TESTHOST'
    var_1 = {'changed': 1, 'skipped': 1, 'failures': 1, 'ok': 1, 'unreachable': 1}
    var_2 = 0
    # Set set_color to 1 if you don't want to have colors on screen, the colors
    # will be turned off by changing ANSIBLE_COLOR to False.
    set_color = 1

    if not C.ANSIBLE_NOCOLOR:
        ANSIBLE_COLOR = True
    if set_color:
        ANSIBLE

# Generated at 2022-06-25 12:54:06.805924
# Unit test for function hostcolor
def test_hostcolor():
    test_hostname = "test_host_0"
    # Test with a changed host
    stats_0 = {
        'failures': 0,
        'changed' : 2,
        'ok'      : 0,
        'skipped' : 0,
        'unreachable': 0,
        }
    result = hostcolor(test_hostname, stats_0, color=True)
    assert "test_host_0" == result

    # Test with a failed host
    stats_0 = {
        'failures': 1,
        'changed' : 0,
        'ok'      : 0,
        'skipped' : 0,
        'unreachable': 0,
        }
    result = hostcolor(test_hostname, stats_0, color=True)
    assert "test_host_0" == result

# Generated at 2022-06-25 12:54:16.862883
# Unit test for function hostcolor
def test_hostcolor():
    # Set up
    int_0 = 0
    int_1 = 1
    int_2 = 0
    int_3 = 1
    stats = {
        'changed' : int_0,
        'failures' : int_1,
        'unreachable' : int_2,
    }
    var_0 = hostcolor('tacos', stats)



# --- end of "pretty" from http://github.com/thedude/pretty ---



# Generated at 2022-06-25 12:54:19.629035
# Unit test for function hostcolor
def test_hostcolor():
    # Ensure the error code is non-zero
    assert hostcolor(hostcolor, hostcolor) != 0


# Generated at 2022-06-25 12:54:21.465337
# Unit test for function stringc
def test_stringc():
    # Call function stringc with arguments
    stringc("foo", "blue", False)


# Generated at 2022-06-25 12:54:25.906844
# Unit test for function stringc
def test_stringc():
    var_0 = 'color13'
    expected = u"\u001b[38;5;162mcolor13\u001b[0m"

    output = stringc(var_0, var_0)
    if expected != output:
        raise AssertionError("Expected: {}\nActual:   {}".format(repr(expected), repr(output)))


# Generated at 2022-06-25 12:54:31.288091
# Unit test for function stringc
def test_stringc():
    assert stringc('\n', 'red') == u'\n'
    assert stringc(1, 'red') == u'1'
    assert stringc(u'\u0001', 'red') == u'\u0001'
    assert stringc(False, 'red') == u'False'


# Generated at 2022-06-25 12:54:33.381594
# Unit test for function hostcolor
def test_hostcolor():
    print("Test case 0")
    test_case_0()

# Testing part
if __name__ == '__main__':
    test_hostcolor()

# Generated at 2022-06-25 12:54:34.693699
# Unit test for function hostcolor
def test_hostcolor():
    test_case_0()

# Generated at 2022-06-25 12:54:43.171762
# Unit test for function stringc
def test_stringc():
    expect = '\x1b[91m31415\x1b[0m'
    actual = stringc(31415, 'red')
    assert expect == actual
    expect = '\x1b[91m3\x1b[0m\x1b[92m1\x1b[0m\x1b[94m4\x1b[0m\x1b[93m1\x1b[0m\x1b[95m5\x1b[0m'
    actual = stringc('31415', 'magenta', True)
    assert expect == actual



# Generated at 2022-06-25 12:54:50.316964
# Unit test for function stringc
def test_stringc():

    #Testing default value of optional argument
    #stringc (text, color, wrap_nonvisible_chars=False)

    color = 'red'
    text = 'Some random text'
    wrap_nonvisible_chars = False
    assert stringc(text,color) == '\n'.join(['\033[31m%s\033[0m' % t for t in text.split(u'\n')])

    #Test cases for wrap_nonvisible_chars = True
    wrap_nonvisible_chars = True

    #Testing when color is a number
    color = 'color8'

# Generated at 2022-06-25 12:55:00.395179
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('color9') == '38;5;9'
    assert parsecolor('color10') == '38;5;10'
   

# Generated at 2022-06-25 12:55:05.634015
# Unit test for function stringc
def test_stringc():
    assert stringc("hello", "red") == "\033[31mhello\033[0m"



# Generated at 2022-06-25 12:55:07.679967
# Unit test for function hostcolor
def test_hostcolor():
    print("Testing hostcolor")

    # Test case 0
    print("  Test case 0")
    test_case_0()



# Generated at 2022-06-25 12:55:09.621887
# Unit test for function parsecolor
def test_parsecolor():
    print ("Testing parsecolor()")
    for color_key, color_code in C.COLOR_CODES.items():
        f_color = parsecolor(color_key)
        assert f_color == C.COLOR_CODES[color_key]
    print ("Passed")


# Generated at 2022-06-25 12:55:16.274825
# Unit test for function colorize
def test_colorize():
    # In the following tests, num should be colorized
    assert colorize("OK", 0, "green") == \
        u"OK=0   "
    assert colorize("OK", 0, None) == \
        u"OK=0   "
    assert colorize("OK", 1, "blue") == \
        u"OK=1   "
    assert colorize("OK", 1, None) == \
        u"OK=1   "
    assert colorize("NOK", -1, "red") == \
        u"NOK=-1 "

    # In the following tests, num should not be colorized
    assert colorize("OK", 0, None) == \
        u"OK=0   "
    assert colorize("OK", 1, None) == \
        u"OK=1   "

# Generated at 2022-06-25 12:55:22.448482
# Unit test for function hostcolor
def test_hostcolor():
    from pytest import raises
    from io import StringIO
    from ansible.module_utils.six import PY2

    if PY2:
        from ansible.module_utils.six import BytesIO
        output = BytesIO()
    else:
        output = StringIO()

    with raises(TypeError):
        # test_case_0
        int_0 = -813
        var_0 = hostcolor(int_0, int_0)
        test_case_0()


# --- end "pretty"



# Generated at 2022-06-25 12:55:22.898072
# Unit test for function colorize
def test_colorize():
    pass


# Generated at 2022-06-25 12:55:34.433057
# Unit test for function stringc
def test_stringc():
    int_0 = -813
    var_0 = hostcolor(int_0, int_0)
    int_1 = -813
    var_1 = hostcolor(int_1, int_1)
    int_2 = -813
    var_2 = hostcolor(int_2, int_2)
    int_3 = -813
    var_3 = hostcolor(int_3, int_3)
    var_0 = stringc(var_3, var_2, var_1, var_0)
    int_4 = -813
    var_4 = hostcolor(int_4, int_4)
    int_5 = -813
    var_5 = hostcolor(int_5, int_5)
    int_6 = -813

# Generated at 2022-06-25 12:55:43.903673
# Unit test for function parsecolor
def test_parsecolor():
    int_1 = 1
    int_2 = 2
    int_3 = 3
    int_4 = 4
    int_0 = 0
    int_5 = 5
    float_1 = float(0.0)
    float_2 = float(1.0)
    float_3 = float(2.0)
    float_4 = float(3.0)
    float_5 = float(4.0)


# Generated at 2022-06-25 12:55:49.940513
# Unit test for function colorize
def test_colorize():
    # Test index in range [0...8]
    int_0 = -813
    # Test index in range [0...8]
    var_0 = colorize(int_0, int_0, int_0)
#
#
# --- end "pretty"


# global variables to hold state for the ANSIBALLZ format

# controls whether to skip over tasks that are run during rescue/always segments
skip_task_on_failed_rescue = False

# controls whether to display a task on success (changed)
display_skipped_hosts = True

_LAST_TASK_CACHE = {}



# Generated at 2022-06-25 12:55:52.355062
# Unit test for function stringc
def test_stringc():
    assert stringc(1, 1, 1) == u'\n.\n'



# Generated at 2022-06-25 12:56:01.492672
# Unit test for function hostcolor
def test_hostcolor():
    host = 'ansible.example.org'
    stats = {
        'changed': 0,
        'failures': 0,
        'ok': 0,
        'processed': 0,
        'rescued': 0,
        'skipped': 0,
        'unreachable': 0,
    }
    color = True
    var_0 = hostcolor(host, stats, color)


# Generated at 2022-06-25 12:56:04.291854
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('127.0.0.1', stats={
                     'failures': 0, 'unreachable': 0, 'changed': 0}, color=True) == u'127.0.0.1                 '


# Generated at 2022-06-25 12:56:07.902090
# Unit test for function stringc
def test_stringc():
    text = 'test'
    color = 'rgb055'
    # the stringc function is hard to test, and is largely superseded
    # by stringc at this point, so we will only exercise the code
    stringc(text, color)


# Generated at 2022-06-25 12:56:12.121138
# Unit test for function stringc
def test_stringc():
    # Should print "Hello World in red color"
    print(stringc("Hello World", C.COLOR_ERROR))
    # Should print "Hello World" in red color wrapped with ANSI nonvisable
    # chars.
    print(stringc("Hello World", C.COLOR_ERROR,
                        wrap_nonvisible_chars=True))



# Generated at 2022-06-25 12:56:17.871139
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = u"foo.bar.com"
    dict_0 = {'unreachable': 0, 'changed': 0, 'failures': 0}
    func_0 = hostcolor(str_0, dict_0, False)
    assert func_0 == "%-26s" % str_0

# Generated at 2022-06-25 12:56:27.681204
# Unit test for function stringc
def test_stringc():
    str_0 = 'Host127.0.0.1'
    str_1 = 'ok'
    var_0 = stringc(str_0, str_1)
    str_2 = 'Host127.0.0.1'
    str_3 = 'ok'
    var_1 = stringc(str_2, str_3)
    str_4 = 'rgb055'
    var_2 = parsecolor(str_4)
    str_5 = 'Host127.0.0.1'
    str_6 = 'ok'
    var_3 = stringc(str_5, str_6)
    str_7 = 'Host127.0.0.1'
    str_8 = 'ok'
    var_4 = stringc(str_7, str_8)

# Generated at 2022-06-25 12:56:29.265544
# Unit test for function hostcolor
def test_hostcolor():
    host = 'test_host'
    stats = {}
    color = True
    ret = hostcolor(host, stats, color)


# Generated at 2022-06-25 12:56:38.209612
# Unit test for function stringc
def test_stringc():
    str_0 = 'hello'
    color_0 = 'red'
    str_1 = 'world'
    color_1 = 'blue'
    str_2 = '!'
    color_2 = 'green'

    # This is an example of chaining
    # `stringc` calls together. Note that
    # we use a variable for the text each
    # time and could just as easily have
    # used a variable for the color as well.
    res = stringc(str_0, color_0) + \
        stringc(str_1, color_1) + \
        stringc(str_2, color_2)

    assert res is not None
    assert res is not ''

    assert 'red' in res
    assert 'blue' in res
    assert 'green' in res



# Generated at 2022-06-25 12:56:41.894670
# Unit test for function colorize
def test_colorize():
    lead = 'lead'
    num = -1
    color = 'color'
    var = colorize(lead, num, color)
    assert var == u"lead=-1  "


# Generated at 2022-06-25 12:56:48.167992
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host'
    dict_0 = {}
    dict_0['changed'] = 0
    dict_0['failed'] = 0
    dict_0['skipped'] = 0
    dict_0['unreachable'] = 0
    dict_0['failures'] = 0
    dict_0['ok'] = 0
    var_0 = hostcolor(str_0, dict_0)



# Generated at 2022-06-25 12:56:53.297083
# Unit test for function stringc
def test_stringc():
    pass



# Generated at 2022-06-25 12:56:59.936490
# Unit test for function hostcolor
def test_hostcolor():
    host = 'foo.example.com'
    stats = {'ok': 1, 'unreachable': 0, 'changed': 1}
    color = True
    var_0 = hostcolor(host, stats, color)
    print(var_0)
    assert str(var_0) == 'foo.example.com               '

if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:57:03.537758
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor(host=None, color=None, stats=None) == "%-37s"
    assert hostcolor(host=None, color=None, stats=None) == "%-37s"


# Generated at 2022-06-25 12:57:06.088092
# Unit test for function stringc
def test_stringc():
    str_0 = 'rgb555'
    str_1 = stringc(str_0, 'rgb555', False)


# Generated at 2022-06-25 12:57:13.173922
# Unit test for function stringc
def test_stringc():
    '''
    Unit test for stringc
    '''
    str_0 = 'rgb555'
    str_1 = '\033[38;5;45m\033[0m'
    result = ANSIBLE_COLOR and True and stringc(str_0, str_1) == str_1
    assert result


# --- end "pretty"

# ==============================================================
# string formatting
#
# a collection of utilities to take various datastructures
# and convert them to strings
# ==============================================================

# --- begin nested string formatting


# Generated at 2022-06-25 12:57:15.676463
# Unit test for function stringc
def test_stringc():
    # test_case_0
    str_0 = 'rgb055'
    var_0 = u'38;5;60'
    #
    test_case_0()



# Generated at 2022-06-25 12:57:19.324120
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', 0, 'stdout_ok') == u'lead=0   '
    if 'changed' in C.COLOR_CODES:
        assert colorize('lead', 2, 'changed') == u'\nlead=2   \n'
    if 'error' in C.COLOR_CODES:
        assert colorize('lead', 0, 'error') == u'lead=0   '

# Generated at 2022-06-25 12:57:25.564450
# Unit test for function hostcolor
def test_hostcolor():
    host = "localhost"
    stats = {'changed': 0, 'dark': 0, 'failures': 0, 'ignored': 0, 'ok': 2,
             'processed': 2, 'rescued': 0, 'skipped': 0, 'unreachable': 0,
             'failures': 0, 'changed': 0}
    color = True
    str_0 = hostcolor(host, stats, color)

    # Strings, single quotes, leading and trailing whitespace are stripped
    host = u"localhost"
    stats = {'changed': 0, 'dark': 0, 'failures': 0, 'ignored': 0, 'ok': 2,
             'processed': 2, 'rescued': 0, 'skipped': 0, 'unreachable': 0,
             'failures': 0, 'changed': 0}
    color

# Generated at 2022-06-25 12:57:28.124381
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('1.2.3.4', dict(), True) is not None


# Generated at 2022-06-25 12:57:30.274822
# Unit test for function hostcolor
def test_hostcolor():
    host = 'TEST_STRING'
    stats = {}
    color = True
    ret_value = hostcolor(host,stats,color)



# Generated at 2022-06-25 12:57:38.011932
# Unit test for function stringc
def test_stringc():
    str_0 = 'rgb055'
    text = str_0
    color = str_0
    var_0 = stringc(text, color)
    var_1 = stringc(text, color, True)


# Generated at 2022-06-25 12:57:45.666759
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host'
    str_1 = 'host'
    str_2 = 'host'
    str_3 = 'host'
    dict_0 = {'pending': 0, 'darkgray': 0, 'yellow': 0, 'unreachable': 0, 'changed': 0, 'cyan': 0, 'lightgray': 0, 'ignored': 0, 'red': 0, 'failures': 0, 'blue': 0, 'green': 0, 'ok': 0}
    var_0 = hostcolor(str_0, dict_0, False)
    var_1 = hostcolor(str_1, dict_0, True)

# Generated at 2022-06-25 12:57:52.675249
# Unit test for function hostcolor
def test_hostcolor():
    test_host = 'test_host'
    test_stats = {'ok': 1, 'changed': 0, 'unreachable': 0, 'skipped': 0,
                  'failed': 0}
    test_color = True
    var_1 = hostcolor(test_host, test_stats, test_color)
    assert type(var_1) is unicode
    assert len(var_1) == 37


# Generated at 2022-06-25 12:57:58.664002
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'ignored': 0, 'pending': 0, 'skipped': 0, 'ok': 1, 'dark': 0, 'failures': 0, 'processed': 1, 'changed': 0, 'rescued': 0, 'unreachable': 0}
    str_0 = 'testhost'
    var_0 = hostcolor(str_0, stats)
    assert var_0 == 'testhost                '


# Generated at 2022-06-25 12:58:08.452991
# Unit test for function stringc
def test_stringc():
    str_0 = 'rgb0111'
    str_1 = 'color234'
    str_2 = 'gray0'
    str_3 = 'gray15'
    str_4 = 'gray255'
    var_0 = parsecolor(str_0)
    var_1 = parsecolor(str_1)
    var_2 = parsecolor(str_2)
    var_3 = parsecolor(str_3)
    var_4 = parsecolor(str_2)
    str_5 = stringc(str_1, str_0)
    str_6 = stringc(str_1, str_1)
    str_7 = stringc(str_1, str_2)
    str_8 = stringc(str_1, str_3)

# Generated at 2022-06-25 12:58:10.241324
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host1'
    dict_0 = {
        'unreachable': 1,
        'failures': 1,
        'changed': 1
    }
    var_0 = hostcolor(str_0, dict_0)

# Generated at 2022-06-25 12:58:15.548731
# Unit test for function stringc
def test_stringc():
    str_0 = 'rgb055'
    str_1 = 'OK'
    str_2 = '\033[38;5;28mOK\033[0m'
    var_0 = stringc(str_1, str_0)
    assert var_0 == str_2


# Generated at 2022-06-25 12:58:24.063835
# Unit test for function colorize
def test_colorize():
    lead = 'something'
    num = 22
    color = 'blue'
    assert colorize(lead, num, color) == 'something=22  '
    num = 20
    assert colorize(lead, num, color) == 'something=20  '
    num = 5
    assert colorize(lead, num, color) == 'something=5   '
    num = 0
    assert colorize(lead, num, color) == 'something=0   '
    num = -30
    assert colorize(lead, num, color) == 'something=-30 '
    num = -300
    assert colorize(lead, num, color) == 'something=-300'
    num = 12
    assert colorize(lead, num, color) == 'something=12  '


# Generated at 2022-06-25 12:58:34.046870
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('test', {'failures': 1, 'unreachable': 2, 'changed': 3}, True) == '\033[91mtest\033[0m               '
    assert hostcolor('test', {'failures': 0, 'unreachable': 0, 'changed': 3}, True) == '\033[33mtest\033[0m               '
    assert hostcolor('test', {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == '\033[32mtest\033[0m               '
    assert hostcolor('test', {'failures': 1, 'unreachable': 2, 'changed': 3}, False) == 'test                    '
    assert hostcolor('test', {'failures': 0, 'unreachable': 0, 'changed': 3}, False) == 'test                    '

# Generated at 2022-06-25 12:58:44.293523
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'localhost'
    dict_0 = dict()
    dict_0['failures'] = 0
    dict_0['skipped'] = 0
    dict_0['unreachable'] = 0
    dict_0['changed'] = 0
    dict_0['ok'] = 1
    dict_0['dark_dark_gray'] = 0
    dict_0['dark_red'] = 0
    dict_0['dark_green'] = 0
    dict_0['dark_yellow'] = 0
    dict_0['dark_blue'] = 0
    dict_0['dark_magenta'] = 0
    dict_0['dark_cyan'] = 0
    dict_0['dark_white'] = 0
    dict_0['light_black'] = 0
    dict_0['light_red'] = 0
    dict_0

# Generated at 2022-06-25 12:58:59.417824
# Unit test for function stringc
def test_stringc():
    """Return color wrapped string."""
    str_0 = 'black'
    str_1 = 'white'
    var_0 = stringc(str_0, str_1)
    str_2 = '\033[37mblack\033[0m'
    assert var_0 == str_2
    str_3 = 'color22'
    var_1 = stringc(str_0, str_3)
    str_4 = '\033[38;5;22mblack\033[0m'
    assert var_1 == str_4
    str_5 = 'rgb050'
    var_2 = stringc(str_0, str_5)
    str_6 = '\033[38;5;22mblack\033[0m'
    assert var_2 == str_6

# Unit

# Generated at 2022-06-25 12:59:09.015352
# Unit test for function colorize
def test_colorize():
    # Tests the colorize function

    # str_0 and str_1 are values that are expected to be printed
    # without any colorization
    hostname = 'test'
    str_0 = colorize('ok:    ', 5, C.COLOR_OK)
    str_1 = colorize('changed:', 0, C.COLOR_CHANGED)
    str_2 = colorize('failed: ', 1, C.COLOR_ERROR)
    str_3 = colorize('skipped: ', 0, C.COLOR_SKIP)
    str_4 = colorize('unreachable:', 0, C.COLOR_UNREACHABLE)
    str_5 = colorize('rescued:   ', 0, C.COLOR_RESCUED)
    str_6 = colorize('ignored:   ', 0, C.COLOR_IGNORE)



# Generated at 2022-06-25 12:59:12.282795
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'skipped': 0, 'changed': 0, 'unreachable': 1, 'failures': 0}
    host = 'localhost'
    color = True
    actual_result = hostcolor(host, stats, color)
    expected_result = 'localhost                   '
    assert actual_result == expected_result, 'Test hostcolor failed!'

# Generated at 2022-06-25 12:59:19.619082
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('test', {'failures':0, 'unreachable':0, 'changed':0}) == 'test                 '
    assert hostcolor('test', {'failures':1, 'unreachable':0, 'changed':0}) == 'test\x1b[31m\x1b[0m               '
    assert hostcolor('test', {'failures':0, 'unreachable':0, 'changed':1}) == 'test\x1b[33m\x1b[0m               '


# Generated at 2022-06-25 12:59:23.259710
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'red') == 'ok=0   ', "colorize() failed with input: 'ok', 0, 'red'"
    assert colorize('ok', 1, 'green') == u"ok=1   ", "colorize() failed with input: 'ok', 1, 'green'"


# Generated at 2022-06-25 12:59:28.362036
# Unit test for function colorize
def test_colorize():
    str_0 = 'ok'
    var_0 = colorize('success', 0, str_0)
    expected_0 = 'success=0   '
    assert var_0 == expected_0
    str_1 = 'fail'
    var_1 = colorize('success', 1, str_1)
    expected_1 = colorize('success', 1, str_1)
    assert var_1 == expected_1


# Generated at 2022-06-25 12:59:38.290645
# Unit test for function stringc
def test_stringc():
    str_0 = 'rgb055'
    str_1 = 'rgb555'
    str_2 = 'rgb000'
    str_3 = 'gray0'
    str_4 = 'gray9'
    str_5 = 'color0'
    str_6 = 'color23'
    str_7 = 'color255'
    str_8 = 'rainbow'
    str_9 = 'red'
    str_10 = 'rainbow'
    str_11 = 'black'
    str_12 = 'rainbow'
    str_13 = 'red'
    str_14 = 'rainbow'
    str_15 = 'black'
    str_16 = "this is a red string"
    str_17 = 'rgb000'
    str_18 = 'rgb555'

# Generated at 2022-06-25 12:59:42.145248
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 10, None) == 'ok=10'
    assert colorize('changed', 8, None) == 'changed=8'
    assert colorize('skipped', 5, None) == 'skipped=5'
    assert colorize('ok', 0, None) == 'ok=0'



# Generated at 2022-06-25 12:59:47.417715
# Unit test for function stringc
def test_stringc():
    str_0 = 'rgb255'
    var_0 = stringc(str_0, u'color235', False)


# Generated at 2022-06-25 12:59:50.683439
# Unit test for function hostcolor
def test_hostcolor():
    target_host = 'all'
    stats = {'ok': 0, 'failures': 0, 'unreachable': 0, 'skipped': 0, 'changed': 0}
    result = hostcolor(target_host, stats)
    assert result == u"all                          "


# Generated at 2022-06-25 13:00:07.721421
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host'
    dict_0 = {'host': {}}
    test_hostcolor_1_0 = hostcolor(str_0, dict_0, True)
    test_hostcolor_1_1 = hostcolor(str_0, dict_0, False)
    test_hostcolor_2_0 = hostcolor(str_0, dict_0, True)
    test_hostcolor_2_1 = hostcolor(str_0, dict_0, False)
    test_hostcolor_3_0 = hostcolor(str_0, dict_0, True)
    test_hostcolor_3_1 = hostcolor(str_0, dict_0, False)


# Generated at 2022-06-25 13:00:09.525254
# Unit test for function stringc
def test_stringc():
    str_0 = 'rgb055'
    str_1 = 'This is a test'
    var_0 = stringc(str_1, str_0)

