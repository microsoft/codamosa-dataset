

# Generated at 2022-06-25 12:50:18.007281
# Unit test for function colorize
def test_colorize():
    assert colorize('', 0, None) == '=0    '
    assert colorize('', 1, 'error') == '=1    '
    assert colorize('', 2, 'error') == '=2    '


# Generated at 2022-06-25 12:50:19.801548
# Unit test for function colorize
def test_colorize():

    lead = 'foo'
    num = 100
    color = 'red'

    assert(colorize(lead, num, color) == u"foo=100")



# Generated at 2022-06-25 12:50:26.222197
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('web1', {'failures': 0, 'changed': 0, 'unreachable': 0}) == u'web1                           '
    assert hostcolor('web1', {'failures': 0, 'changed': 0, 'unreachable': 1}) == u'\x1b[31;01mweb1                           \x1b[0m'
    assert hostcolor('web1', {'failures': 0, 'changed': 1, 'unreachable': 0}) == u'\x1b[33;01mweb1                           \x1b[0m'
    assert hostcolor('web1', {'failures': 1, 'changed': 1, 'unreachable': 1}) == u'\x1b[31;01mweb1                           \x1b[0m'


# Generated at 2022-06-25 12:50:29.853069
# Unit test for function hostcolor
def test_hostcolor():
    assert(hostcolor("abcdefg", {"abcdefg": 1}) == "abcdefg                                 ")
    assert(hostcolor("abcdefg", {"abcdefg": 1}, False) == "abcdefg            ")
    assert(hostcolor("abcdefg", {"abcdefg": 1}, True) == "abcdefg            ")


# Generated at 2022-06-25 12:50:36.896597
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('', {}, False) == '                                                            '
    assert hostcolor('', {}, True) == '                                                            '
    assert hostcolor('', {'unreachable': 0, 'changed': 0, 'failures': 0}, True) == '                                                            '
    assert hostcolor('', {'unreachable': 1, 'changed': 0, 'failures': 0}, True) == '                                                            '
    assert hostcolor('', {'unreachable': 0, 'changed': 1, 'failures': 0}, True) == '                                                            '
    assert hostcolor('', {'unreachable': 0, 'changed': 0, 'failures': 1}, True) == '                                                            '

# Generated at 2022-06-25 12:50:38.548446
# Unit test for function parsecolor
def test_parsecolor():
    with pytest.raises(ValueError):
        test_case_0()


# Generated at 2022-06-25 12:50:42.149483
# Unit test for function stringc
def test_stringc():
    test_str = u'Test stringc'
    result = stringc(test_str, u'red')
    expected = u'\033[31mTest stringc\033[0m'
    assert (result == expected), \
    'String "%s" with color does not match expected value "%s".' % \
    (result, expected)


# Generated at 2022-06-25 12:50:45.661953
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor(1) == '38;5;1'
    assert parsecolor('yellow') == '33'
    assert parsecolor('rgb123') == '38;5;5'
    assert parsecolor('rgb333') == '38;5;232'



# Generated at 2022-06-25 12:50:46.780046
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('yellow') == '33'


# Generated at 2022-06-25 12:50:54.964099
# Unit test for function stringc
def test_stringc():
    str1 = '-203'
    color1 = 'red'
    wrap_nonvisible_chars1 = False
    result1 = stringc(str1, color1, wrap_nonvisible_chars1)

    str2 = '203'
    color2 = 'color20'
    wrap_nonvisible_chars2 = True
    result2 = stringc(str2, color2, wrap_nonvisible_chars2)

    str3 = 'rgb005500'
    color3 = 'rgb005500'
    wrap_nonvisible_chars3 = False
    result3 = stringc(str3, color3, wrap_nonvisible_chars3)

    str4 = 'green'
    color4 = 'green'
    wrap_nonvisible_chars4 = True

# Generated at 2022-06-25 12:51:03.234205
# Unit test for function parsecolor
def test_parsecolor():
    output = parsecolor('red')
    assert output == '31'
    output = parsecolor('blue')
    assert output == '34'
    output = parsecolor('bold')
    assert output == '01'
    output = parsecolor('on_red')
    assert output == '41'
    output = parsecolor(-203)
    assert output == '31'


# Generated at 2022-06-25 12:51:04.221074
# Unit test for function stringc
def test_stringc():
    test = 'test string in color'
    color = 'green'

    result = stringc(test, color)
    assert result != None


# Generated at 2022-06-25 12:51:06.584332
# Unit test for function parsecolor
def test_parsecolor():
    int_0 = -203
    var_0 = parsecolor(int_0)
    assert var_0 == C.COLOR_CODES[int_0]

# --- end "pretty"



# Generated at 2022-06-25 12:51:11.735412
# Unit test for function stringc
def test_stringc():
    text = "test_stringc"
    color = "test_stringc"
    wrap_nonvisible_chars = False
    test_stringc_0(text, color, wrap_nonvisible_chars)


# Generated at 2022-06-25 12:51:17.635716
# Unit test for function hostcolor
def test_hostcolor():
    dict_0 = {'unreachable': 2, 'failures': 5, 'skipped': 2, 'ok': 91, 'changed': 5, 'dark': 7, 'processed': 4}
    int_0 = hostcolor("192.168.0.0", dict_0)


if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

# Generated at 2022-06-25 12:51:28.365900
# Unit test for function stringc
def test_stringc():
    var_0 = u"color1\x1b[38;5;1m\x1b[0m"
    var_1 = u"\x1b[38;5;1mcolor1\x1b[0m"
    var_2 = u"color2\x1b[38;5;2m\x1b[0m"
    var_3 = u"\x1b[38;5;2mcolor2\x1b[0m"
    var_4 = u"color3\x1b[38;5;3m\x1b[0m"
    var_5 = u"\x1b[38;5;3mcolor3\x1b[0m"

# Generated at 2022-06-25 12:51:34.400715
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('bar', '001') == u'\033[38;5;1mbar\033[0m'
    assert stringc('baz', 'rgb323') == u'\033[38;5;103baz\033[0m'
    assert stringc('biz', 'gray1') == u'\033[38;5;233biz\033[0m'


# Generated at 2022-06-25 12:51:43.149725
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('10.123.123.123', {'changed': 0, 'dark': 0, 'failures': 0, 'ignored': 0, 'ok': 1, 'processed': 1, 'rescued': 0, 'skipped': 0, 'unreachable': 0}) == u'10.123.123.123             '
    assert hostcolor('10.123.123.123', {'changed': 1, 'dark': 0, 'failures': 0, 'ignored': 0, 'ok': 0, 'processed': 1, 'rescued': 0, 'skipped': 0, 'unreachable': 0}) == u'10.123.123.123             '

# Generated at 2022-06-25 12:51:48.566764
# Unit test for function stringc
def test_stringc():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    test_case_1(0, 0)
    test_case_1(1, 1)
    test_case_1(3, 2)
    test_case_1(4, 3)
    test_case_1(5, 4)
    ANSIBLE_COLOR = False



# Generated at 2022-06-25 12:51:59.952199
# Unit test for function hostcolor
def test_hostcolor():
    print(hostcolor(1, 2))
    print(hostcolor(1, 2, color=True))
    print(hostcolor(u'127.0.0.1', {'failures': 0, 'changed': 1, 'unreachable': 0}, color=True))
    print(hostcolor(u'127.0.0.1', {'failures': 1, 'changed': 0, 'unreachable': 0}, color=True))
    print(hostcolor(u'127.0.0.1', {'failures': 0, 'changed': 0, 'unreachable': 1}, color=True))

if __name__ == '__main__':
    test_case_0()
    test_hostcolor()

    print(u"%s" % stringc(u'Hello', u'blue'))


# Generated at 2022-06-25 12:52:08.334866
# Unit test for function hostcolor
def test_hostcolor():
    host = 'ws12'
    stats = {'ok': 0, 'failures': 0, 'unreachable': 1, 'changed': 0}
    color = True
    ansible_hostcolor = hostcolor(host, stats, color)
    print(ansible_hostcolor)


# Generated at 2022-06-25 12:52:10.083227
# Unit test for function parsecolor
def test_parsecolor():
    int_0 = -203
    var_0 = parsecolor(int_0)


# Generated at 2022-06-25 12:52:12.008038
# Unit test for function parsecolor
def test_parsecolor():
    print("Testing function parsecolor...", end="")
    test_case_0()
    print("done.")

# --- end "pretty"



# Generated at 2022-06-25 12:52:17.790071
# Unit test for function hostcolor
def test_hostcolor():
    print ("Testing hostcolor...")
    assert hostcolor("17936","50",True) == "17936"
    assert hostcolor("50","-9031",-0.00296319) != "23229"
    assert hostcolor("6518","1176","0033") != "9385"
    assert hostcolor("0.05","-1.74","1.7") != "-0.05"
    print ("...Test completed")
    return True
    
# Main
if __name__ == '__main__':
    test_hostcolor()
    test_case_0()

# Generated at 2022-06-25 12:52:23.252769
# Unit test for function hostcolor
def test_hostcolor():
    host = "test_value_0"
    stats = {"changed": test_case_0(),
             "unreachable": (test_case_0(),
                             None),
             "failures": test_case_0()}
    color = (test_case_0(),
             test_case_0())

    # Call function hostcolor with arguments host, stats, color
    hostcolor(host, stats, color)


# Generated at 2022-06-25 12:52:25.097424
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = -203
    var_0 = hostcolor(int_0, int_0)
    assert var_0 == -203


# Generated at 2022-06-25 12:52:27.567883
# Unit test for function stringc
def test_stringc():
    text = 'text'
    color = 'color'
    wrap_nonvisible_chars = False
    test_stringc_0(text, color, wrap_nonvisible_chars)


# Generated at 2022-06-25 12:52:30.020461
# Unit test for function parsecolor
def test_parsecolor():
    int_0 = 5
    var_0 = parsecolor(int_0)
    int_1 = 3
    var_1 = parsecolor(int_1)
    assert var_0 == var_1


# Generated at 2022-06-25 12:52:32.126370
# Unit test for function colorize
def test_colorize():
    # Call the function
    lead = u"test"
    num = 20
    color = u"red"
    colorize(lead, num, color)


# Generated at 2022-06-25 12:52:34.769526
# Unit test for function parsecolor
def test_parsecolor():
    print("Testing parsecolor")
    color = "green"
    print("Color is: " + color)
    try:
        print("Return is: " + parsecolor(color))
    except TypeError:
        print("TypeError raised")


# Generated at 2022-06-25 12:52:49.471935
# Unit test for function parsecolor
def test_parsecolor():
    print(stringc('This is a test', 'blue'))
    print(colorize('ok', 33, 'green'))
    print(colorize('changed', 44, 'yellow'))
    print(colorize('unreachable', 55, 'red'))
    print(colorize('failed', 66, 'lightred'))
    print(colorize('skipped', 77, None))
    print(hostcolor('www.ansible.com', dict(ok=1, failed=0, skipped=0, unreachable=0, changed=0)))
    print(hostcolor('localhost', dict(ok=0, failed=1, skipped=0, unreachable=0, changed=0)))
    print(hostcolor('127.0.0.1', dict(ok=0, failed=0, skipped=0, unreachable=0, changed=1)))

# Generated at 2022-06-25 12:52:57.221502
# Unit test for function colorize
def test_colorize():
    lead = "test_lead"
    num = 2
    color = True

    # Test str type for lead
    lead = str(lead)
    assert isinstance(lead, str)

    # Test str type for color
    color = str(color)
    assert isinstance(color, str)

    # Test if num is int
    assert isinstance(num, int)

    # Test if num is positive
    assert num > 0

    # Test if num is negative
    num = -num
    assert num < 0

    # Test new method call
    result = colorize(lead, num, color)
    assert result



# Generated at 2022-06-25 12:52:58.968434
# Unit test for function stringc
def test_stringc():
    import doctest
    doctest.testmod()


# Generated at 2022-06-25 12:53:01.100530
# Unit test for function stringc
def test_stringc():
    str_0 = 'foo'
    str_1 = 'text'
    f = stringc(str_0, str_1)
    assert f == 'foo'


# Generated at 2022-06-25 12:53:10.097995
# Unit test for function hostcolor
def test_hostcolor():

    function_name = sys._getframe().f_code.co_name
    function_name = function_name.replace("test_", "")

    host = "host"
    stats = {"failures": 0, "unreachable": 1, "changed": 0}
    color = None

    # Empty host
    try:
        host = ""
        r = hostcolor(host, stats, color)
        print("PASS", r)
    except:
        print("FAIL")

    # Empty host
    try:
        host = ""
        r = hostcolor(host, stats, color)
        print("PASS", r)
    except:
        print("FAIL")

    # Empty host

# Generated at 2022-06-25 12:53:18.533791
# Unit test for function hostcolor
def test_hostcolor():
    print("hostcolor: " +
          hostcolor(
    'test_host', {'changed': 0, 'skipped': 0, 'ok': 0, 'unreachable': 0,
                  'failures': 0}, True))

    print("hostcolor: " +
          hostcolor(
    'test_host', {'changed': 0, 'skipped': 0, 'ok': 0, 'unreachable': 0,
                  'failures': 1}, True))

    print("hostcolor: " +
          hostcolor(
    'test_host', {'changed': 0, 'skipped': 0, 'ok': 0, 'unreachable': 1,
                  'failures': 0}, True))


# Generated at 2022-06-25 12:53:23.746188
# Unit test for function stringc
def test_stringc():
    assert(stringc(u"foo", u"red") == u"\033[31mfoo\033[0m")
    assert(stringc(u"foo", u"rgb255000") == u"\033[38;5;196mfoo\033[0m")
    assert(stringc(u"foo", u"gray11") == u"\033[38;5;244mfoo\033[0m")
# --- end "pretty"

# Generated at 2022-06-25 12:53:28.499943
# Unit test for function stringc
def test_stringc():
    var_0 = u"/bin/false"
    var_1 = colorize(var_0, var_0, var_0)
    print(var_1)


# Generated at 2022-06-25 12:53:37.943357
# Unit test for function parsecolor
def test_parsecolor():

    # test with known values from module testing
    assert parsecolor("255") == u'38;5;255'
    assert parsecolor("003") == u'38;5;3'
    assert parsecolor("rgb255000") == u'38;5;196'
    assert parsecolor("gray34") == u'38;5;245'
    assert parsecolor("gray9") == u'38;5;235'

    # test with random values
    import random
    for _ in range(1000):
        arg = random.randint(-1000, 1000)
        parsecolor(arg)


# Generated at 2022-06-25 12:53:42.797527
# Unit test for function hostcolor
def test_hostcolor():
    var_0 = 'hostname'
    var_1 = {'changed': 0, 'failures': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0}
    var_2 = True
    var_3 = hostcolor(var_0, var_1, var_2)
    assert var_3 == 'hostname                          ', "Expected %s, got %s" % ('hostname                          ', var_3)


# Generated at 2022-06-25 12:53:51.218847
# Unit test for function stringc
def test_stringc():
    text = 'off'
    color = 'green'
    wrap_nonvisible_chars = False
    expected = u'\033[32moff\033[0m'
    actual = stringc(text, color, wrap_nonvisible_chars)
    assert expected == actual


# Generated at 2022-06-25 12:53:56.146741
# Unit test for function hostcolor
def test_hostcolor():
    for i in range(0, 10000):
        stats = {}
        stats['failures'] = i
        stats['unreachable'] = i
        stats['changed'] = i
        stats['ok'] = i
        stats['skipped'] = i

        host = "testHost"
        color = True

        hostcolor(host, stats, color)

# Generated at 2022-06-25 12:53:59.813995
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'changed': 0, 'dark': 0, 'failures': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    hostcolor(host, stats)
    hostcolor(host, stats, False)


# Generated at 2022-06-25 12:54:03.208457
# Unit test for function hostcolor
def test_hostcolor():
    param0 = "dummystr"
    param1 = {"failures": 0, "unreachable": 0, "skipped": 0, "ok": 0, "changed": 0}
    param2 = None
    obj = hostcolor(param0,param1,param2)
    return obj


# Generated at 2022-06-25 12:54:16.601499
# Unit test for function stringc
def test_stringc():
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    var_0 = stringc(dest="red_string")
    var_1 = stringc(u"yellow_string", "yellow")
    var_2 = stringc("color3_string", "color3")
    var_3 = stringc("color_red", "red")
    var_4 = stringc("color_orange", "orange")
    var_5 = stringc("color_yellow", "yellow")
    var_6 = stringc("color_green", "green")
    var_7 = stringc("color_blue", "blue")
    var_8 = stringc("color_purple", "purple")
    var_9 = stringc("color_gray", "gray", True)


# Generated at 2022-06-25 12:54:22.113184
# Unit test for function parsecolor
def test_parsecolor():
    print("Running test test_parsecolor")
    int_0 = -203
    var_0 = parsecolor(-203)
    print("expecting -38;5;203 got %s" % var_0)

# Generated at 2022-06-25 12:54:23.029656
# Unit test for function stringc
def test_stringc():
    int_0 = -1
    var_0 = stringc(int_0, int_0)


# Generated at 2022-06-25 12:54:30.083079
# Unit test for function colorize
def test_colorize():
    int_0 = -203
    int_1 = -203
    int_2 = -203
    int_3 = -203
    int_4 = -203
    int_5 = -203
    int_6 = -203
    int_7 = -203
    int_8 = -203
    int_9 = -203
    int_10 = -203
    int_11 = -203
    int_12 = -203
    int_13 = -203
    int_14 = -203
    int_15 = -203
    int_16 = -203
    int_17 = -203
    int_18 = -203
    int_19 = -203
    int_20 = -203
    int_21 = -203
    int_22 = -203
    int_23 = -203



# Generated at 2022-06-25 12:54:31.104209
# Unit test for function stringc
def test_stringc():
    stringc("abc", 0)


# Generated at 2022-06-25 12:54:38.708777
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '34'
    assert parsecolor('black') == '30'
    assert parsecolor('red') == '31'
    assert parsecolor('YELLOW') == '33'
    assert parsecolor('cyan') == '36'
    assert parsecolor('COLOR02') == '38;5;2'
    assert parsecolor('grAy1') == '38;5;244'
    assert parsecolor('rgb123') == '38;5;6'


# Generated at 2022-06-25 12:54:44.193704
# Unit test for function colorize
def test_colorize():
    assert True
    # call function
    result = colorize(lead="#", num="dummy", color="#")
    assert True


# Generated at 2022-06-25 12:54:51.930711
# Unit test for function stringc

# Generated at 2022-06-25 12:54:53.693764
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = '2-10'
    var_0 = hostcolor(int_0, )


# Generated at 2022-06-25 12:55:04.910969
# Unit test for function colorize
def test_colorize():
    assert colorize(u"", 1, C.COLOR_SKIP) == u"=1   "
    assert colorize(u"", 1, C.COLOR_OK) == u"=1   "
    assert colorize(u"", 1, C.COLOR_CHANGED) == u"=1   "
    assert colorize(u"", 1, C.COLOR_ERROR) == u"=1   "
    assert colorize(u"", 0, C.COLOR_SKIP) == u"=0   "
    assert colorize(u"", 0, C.COLOR_OK) == u"=0   "
    assert colorize(u"", 0, C.COLOR_CHANGED) == u"=0   "
    assert colorize(u"", 0, C.COLOR_ERROR) == u"=0   "
   

# Generated at 2022-06-25 12:55:07.444117
# Unit test for function colorize
def test_colorize():
    lead = 38
    num = 5
    color = 0
    res = colorize(lead, num, color)
    # assert_equal(res, 'lead=num')



# Generated at 2022-06-25 12:55:10.440580
# Unit test for function hostcolor
def test_hostcolor():
    for var_0 in range(50):
        var_1 = hostcolor(var_0, var_0)
        var_2 = hostcolor(var_0, var_0)
        print(var_1 + var_2)


# Generated at 2022-06-25 12:55:15.005609
# Unit test for function hostcolor
def test_hostcolor():
  assert hostcolor(host='root@asdf.asdf.com', stats={str('failures'): 2, str('unreachable'): 2}, color=True) == '\x1b[31mroot@asdf.asdf.com\x1b[0m       '
  assert hostcolor(host='root@asdf.asdf.com', stats={str('changed'): 1, str('ignored'): 3}, color=False) == 'root@asdf.asdf.com                '

# Generated at 2022-06-25 12:55:17.444577
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = 0
    str_0 = "clasp"
    var_0 = hostcolor(str_0, int_0)
    str_1 = "pyxis"
    var_1 = hostcolor(str_1, int_0, False)


# Generated at 2022-06-25 12:55:18.818040
# Unit test for function colorize
def test_colorize():
    run_test_case(test_case_0)

# end of pretty
# ---

# Generated at 2022-06-25 12:55:23.034507
# Unit test for function hostcolor
def test_hostcolor():

    # Assertions
    assert hostcolor("parsecolor", "parsecolor", "parsecolor") == "%-26s"
    assert hostcolor("parsecolor", "parsecolor", "parsecolor") == "%-26s"
    assert hostcolor("parsecolor", "parsecolor", "parsecolor") == "%-26s"


# Generated at 2022-06-25 12:55:29.490912
# Unit test for function parsecolor
def test_parsecolor():
    int_0 = 'rgb444'
    int_1 = parsecolor(int_0)
    print(int_1)



# Generated at 2022-06-25 12:55:32.358875
# Unit test for function stringc
def test_stringc():
    text = "Test me!"
    color = "yellow"
    result = stringc(text, color, False)
    assert result == text


# Generated at 2022-06-25 12:55:36.558359
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('1') == '38;5;1', 'Test Failed.'
    assert parsecolor('rgb555') == '38;5;229', 'Test Failed.'
    assert parsecolor('gray7') == '38;5;238', 'Test Failed.'


# Generated at 2022-06-25 12:55:42.647250
# Unit test for function stringc
def test_stringc():
    for color in C.COLOR_CODES:
        text = u'Test stringc'
        ansible_stdout = stringc(text, color)
        if color is 'none':
            py_stdout = u'Test stringc'
        else:
            py_stdout = u'\x1b[{0}mTest stringc\x1b[0m'.format(C.COLOR_CODES[color])
        assert ansible_stdout == py_stdout


# Generated at 2022-06-25 12:55:46.479742
# Unit test for function stringc
def test_stringc():
    assert stringc('stringc', 'white_on_red', True) == u'\001\033[41m\002stringc\001\033[0m\002'
    assert stringc('stringc', 'green', False) == u'\033[32mstringc\033[0m'


# Generated at 2022-06-25 12:55:48.311637
# Unit test for function colorize
def test_colorize():
    lead = "test"
    num = 10
    color = "test"
    result = colorize(lead, num, color)
    assert type(result) is str


# Generated at 2022-06-25 12:55:58.214269
# Unit test for function colorize
def test_colorize():
    # First parameter of colorize
    assert colorize('', '0', 'CYAN') == u'=0   '
    assert colorize('0', '1', 'MAGENTA') == u'0=1  '
    assert colorize('1', '2', 'WHITE') == u'1=2  '
    assert colorize('2', '3', 'BLUE') == u'2=3  '
    assert colorize('3', '4', 'GREEN') == u'3=4  '
    assert colorize('4', '5', 'RED') == u'4=5  '
    assert colorize('5', '6', 'YELLOW') == u'5=6  '
    assert colorize('6', '7', 'CYAN') == u'6=7  '

# Generated at 2022-06-25 12:56:02.612653
# Unit test for function colorize
def test_colorize():
    test_colorize_0(C.COLOR_SKIP)
    test_colorize_1(C.COLOR_ERROR)
    test_colorize_2(C.COLOR_OK)
    test_colorize_3(C.COLOR_CHANGED)
    test_colorize_4(C.COLOR_UNREACHABLE)


# Generated at 2022-06-25 12:56:07.936320
# Unit test for function stringc
def test_stringc():
    print("Testing stringc")

    var_0 = stringc("\000\001\002\003\004\005\006\007\000", None)
    print(var_0)

    var_1 = stringc(50, None)
    print(var_1)

    var_2 = stringc("\000\001\002\003\004\005\006\007\000", None)
    print(var_2)


# Generated at 2022-06-25 12:56:19.187508
# Unit test for function parsecolor
def test_parsecolor():
    int_0 = -203
    var_0 = parsecolor(int_0)
    int_1 = -204
    var_1 = parsecolor(int_1)
    int_2 = -205
    var_2 = parsecolor(int_2)
    int_3 = -206
    var_3 = parsecolor(int_3)
    int_4 = -207
    var_4 = parsecolor(int_4)
    int_5 = -208
    var_5 = parsecolor(int_5)
    int_6 = -209
    var_6 = parsecolor(int_6)
    int_7 = -210
    var_7 = parsecolor(int_7)
    int_8 = -211
    var_8 = parsecolor(int_8)
   

# Generated at 2022-06-25 12:56:24.973088
# Unit test for function hostcolor
def test_hostcolor():
    host = ''
    stats = {}
    color = True
    hostcolor(host, stats, color)


# Generated at 2022-06-25 12:56:32.898859
# Unit test for function hostcolor
def test_hostcolor():
    """Ensure we always print the host in color"""
    host = 'localhost'
    stats = dict(
            changed    = 0,
            unreachable= 0,
            failures   = 0,
        )
    # without color
    s = hostcolor(host, stats, color=False)
    assert s == u"%-26s" % host
    # with color
    s = hostcolor(host, stats, color=True)
    assert s == u"%-37s" % stringc(host, C.COLOR_OK)
    # with color and failed
    stats['changed'] = 1
    s = hostcolor(host, stats, color=True)
    assert s == u"%-37s" % stringc(host, C.COLOR_CHANGED)
    # with color and failed
    stats['changed'] = 0

# Generated at 2022-06-25 12:56:41.845973
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('', {'failures':0, 'unreachable':0, 'changed':0}, 0) == '                                 '
    assert hostcolor('', {'failures':0, 'unreachable':-213, 'changed':0}, 0) == '                                 '
    assert hostcolor('', {'failures':0, 'unreachable':0, 'changed':0}, 0) == '                                 '
    assert hostcolor('', {'failures':-413, 'unreachable':0, 'changed':0}, 0) == '                                 '
    assert hostcolor('', {'failures':0, 'unreachable':0, 'changed':0}, 0) == '                                 '


# Generated at 2022-06-25 12:56:45.416084
# Unit test for function stringc
def test_stringc():
    # Test parameters:
    #    text          - text string that is to be encoded
    #    color         - color name
    # Function call
    s = stringc('test string', 'green')
    # Output
    print(s)



# Generated at 2022-06-25 12:56:47.901708
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()

# --- end "pretty"

# Exceptions



# Generated at 2022-06-25 12:56:48.640060
# Unit test for function stringc
def test_stringc():
    stringc('stringc', 'blue', True)
    stringc('stringc', 'blue', False)



# Generated at 2022-06-25 12:56:49.523885
# Unit test for function hostcolor
def test_hostcolor():
    pass


# Generated at 2022-06-25 12:57:00.148944
# Unit test for function hostcolor
def test_hostcolor():
    int_0 = -203
    str_0 = 'changed'
    str_1 = 'dark_yellow'
    str_2 = 'unreachable'
    str_3 = 'non_zero_return'
    var_0 = parsecolor(int_0)
    var_1 = parsecolor(str_0)
    var_2 = parsecolor(str_1)
    var_3 = parsecolor(str_2)
    var_4 = parsecolor(str_3)
    var_5 = hostcolor(int_0, var_2, str_1)
    var_6 = hostcolor(int_0, var_0, var_1)
    var_7 = hostcolor(str_0, var_4, var_3)


# Generated at 2022-06-25 12:57:04.298985
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = u'localhost'
    dict_0 = {'unreachable':0,'changed':0,'failures':0,'ok':2}
    test_case_0(str_0, dict_0)


# Generated at 2022-06-25 12:57:07.441410
# Unit test for function hostcolor
def test_hostcolor():
    args = {"host": "host", "stats": {"failures":1, "unreachable":10, "changed":11}, "color": False}
    hostcolor(**args)


# Generated at 2022-06-25 12:57:15.153796
# Unit test for function parsecolor
def test_parsecolor():
    test_case_0()


# Generated at 2022-06-25 12:57:18.439869
# Unit test for function colorize
def test_colorize():
    print("Testing function colorize")
    host = '0.0.0.0'
    stats = {
        'changed': 1,
        'failures': 0,
        'skipped': 0,
        'ok': 0,
        'dark': 'dark green',
        'unreachable': 1,
    }
    color = True
    colorize(host, stats, color)


# Generated at 2022-06-25 12:57:21.029627
# Unit test for function stringc
def test_stringc():
    str_0 = 'This is a test'
    str_1 = 'white'
    str_2 = u'\033[37mThis is a test\033[0m'
    print(stringc(str_0, str_1))



# Generated at 2022-06-25 12:57:23.034544
# Unit test for function stringc
def test_stringc():
    var_1 = 'test'
    var_2 = 'green'
    var_3 = stringc(var_1, var_2)



# Generated at 2022-06-25 12:57:23.980091
# Unit test for function colorize
def test_colorize():
    assert colorize('lead', '2', 'red') == 'lead=2   '

# Generated at 2022-06-25 12:57:27.672726
# Unit test for function parsecolor
def test_parsecolor():
    var_0 = parsecolor('yellow')
    print(var_0)
    print(type(var_0))



# Generated at 2022-06-25 12:57:35.904261
# Unit test for function stringc
def test_stringc():
    str_0 = 'test'
    str_1 = 'yellow'
    str_2 = 'test'
    str_3 = 'yellow'
    var_0 = stringc(str_0, str_1)
    var_1 = stringc(str_2, str_3, True)
    assert var_0 == u"\n\033[33mtest\033[0m"
    var_0 = str(var_0)
    assert var_0 == u"\n\033[33mtest\033[0m"
    var_1 = str(var_1)
    assert var_1 == u"\n\001\033[33m\002test\001\033[0m\002"


# Generated at 2022-06-25 12:57:44.571399
# Unit test for function hostcolor
def test_hostcolor():
    str_0 = 'host'
    str_1 = 'host'
    str_2 = 'host'
    str_3 = 'host'
    str_4 = 'host'
    str_5 = 'host'
    str_6 = 'host'
    str_7 = 'host'
    str_8 = 'host'
    str_9 = 'host'
    str_10 = 'host'
    str_11 = 'host'
    str_12 = 'host'
    str_13 = 'host'
    str_14 = 'host'
    str_15 = 'host'
    str_16 = 'host'
    str_17 = 'host'
    str_18 = 'host'
    str_19 = 'host'


# Generated at 2022-06-25 12:57:52.347728
# Unit test for function stringc
def test_stringc():
    str_1 = 'blue'
    fmt_0 = u"\033[%sm%s\033[0m"
    _str_0 = stringc(str_1, str_1)
    _str_1 = fmt_0 % (C.COLOR_CODES[str_1], str_1)
    _str_2 = fmt_0 % (C.COLOR_CODES[str_1], str_1)
    assert(_str_0 == _str_1)
# --- end "pretty"

# Generated at 2022-06-25 12:57:56.728479
# Unit test for function stringc
def test_stringc():
    str_0 = 'yellow'
    str_1 = 'Hello World'
    str_2 = stringc(str_1, str_0)
    assert str_2 == u"\u001b[33mHello World\u001b[0m"


# Generated at 2022-06-25 12:58:02.771321
# Unit test for function stringc
def test_stringc():
    assert stringc("This is an example.", "blue") == '\n'.join(['\033[94mThis is an example.\033[0m'])


# Generated at 2022-06-25 12:58:12.009498
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'yellow'
    var_0 = parsecolor(str_0)
    assert var_0 == '33', '<%s != %s>' % (var_0, '33')

    str_0 = 'blue'
    var_0 = parsecolor(str_0)
    assert var_0 == '34', '<%s != %s>' % (var_0, '34')

    str_0 = 'white'
    var_0 = parsecolor(str_0)
    assert var_0 == '37', '<%s != %s>' % (var_0, '37')

    str_0 = 'rgb255'
    var_0 = parsecolor(str_0)

# Generated at 2022-06-25 12:58:15.375938
# Unit test for function hostcolor
def test_hostcolor():
    s = hostcolor('localhost', {'failures': 0, 'changed': 0, 'ok': 1, 'skipped': 0, 'unreachable': 0})
    print(s)



# Generated at 2022-06-25 12:58:17.936239
# Unit test for function colorize
def test_colorize():
    lead = 'foo'
    num = 1
    color = 'red'
    res = colorize(lead, num, color)


# Generated at 2022-06-25 12:58:23.343821
# Unit test for function parsecolor
def test_parsecolor():
    str_1 = 'yellow'
    var_1 = parsecolor(str_1)
    assert (var_1 == u'38;5;11')
    str_2 = 'rgb255000'
    var_2 = parsecolor(str_2)
    assert (var_2 == u'38;5;196')
    str_3 = 'gray8'
    var_3 = parsecolor(str_3)
    assert (var_3 == u'38;5;240')


# Generated at 2022-06-25 12:58:25.014856
# Unit test for function hostcolor
def test_hostcolor():
    if ANSIBLE_COLOR:
        print(">>> hostcolor(host, stats, color=True)")
        print("%s" % hostcolor("localhost", ""))


# Generated at 2022-06-25 12:58:27.609319
# Unit test for function stringc
def test_stringc():
    str_0 = 'yellow'
    str_1 = 'This is yellow text'
    var_0 = stringc(str_1, str_0)
    print(var_0)



# Generated at 2022-06-25 12:58:31.800540
# Unit test for function hostcolor
def test_hostcolor():
    arg_0 = 'localhost'
    arg_1 = {'failures': 0, 'unreachable': 0, 'changed': 0}
    var_1 = hostcolor(arg_0, arg_1)


# Generated at 2022-06-25 12:58:34.167009
# Unit test for function stringc
def test_stringc():
    str_0 = 'yellow'
    str_1 = stringc(b'\x00yes\x01', b'yes', True)


# Generated at 2022-06-25 12:58:36.771715
# Unit test for function stringc
def test_stringc():
    str_0 = '0'
    str_1 = 'yellow'
    var_0 = stringc(str_0, str_1)


# Generated at 2022-06-25 12:58:48.749204
# Unit test for function stringc
def test_stringc():
    # Tests function stringc gives correct output
    # for various ansible_color combinations
    # Unit test for function stringc
    str_1 = 'test_color'
    str_2 = 'test_nocolor'
    str_3 = 'test_forcecolor'

    # Case 0:
    # test prints of a string in color
    var_1 = ANSIBLE_COLOR
    var_2 = stringc(str_1, C.COLOR_OK)
    var_3 = stringc(str_1, C.COLOR_CHANGED)
    var_4 = stringc(str_1, C.COLOR_ERROR)
    assert var_2 == u"\n".join([u"\033[32m%s\033[0m" % t for t in str_1.split(u'\n')])

# Generated at 2022-06-25 12:58:52.579844
# Unit test for function parsecolor
def test_parsecolor():
    # print "Starting unit test for function parsecolor"
    # print "Printing test case 0"
    test_case_0()

# --- end "pretty"

# Backwards compat



# Generated at 2022-06-25 12:58:55.459055
# Unit test for function colorize
def test_colorize():
    host = "test"
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    colorize(host, stats, color)


# Generated at 2022-06-25 12:58:58.647253
# Unit test for function stringc
def test_stringc():
    str_0 = 'hi'
    str_1 = 'yellow'
    var_0 = stringc(str_0, str_1)




# Generated at 2022-06-25 12:59:08.335343
# Unit test for function parsecolor
def test_parsecolor():
    str_0 = 'black'
    var_0 = parsecolor(str_0)
    str_1 = 'red'
    var_1 = parsecolor(str_1)
    str_2 = 'green'
    var_2 = parsecolor(str_2)
    str_3 = 'blue'
    var_3 = parsecolor(str_3)
    str_4 = 'yellow'
    var_4 = parsecolor(str_4)
    str_5 = 'magenta'
    var_5 = parsecolor(str_5)
    str_6 = 'cyan'
    var_6 = parsecolor(str_6)
    str_7 = 'white'
    var_7 = parsecolor(str_7)
    str_8 = 'rgb255'
    var

# Generated at 2022-06-25 12:59:12.335286
# Unit test for function colorize
def test_colorize():
    str_0 = 'blue'
    num_0 = 10
    var_0 = colorize('change', num_0, None)
    str_1 = 'green'
    num_1 = 101
    var_1 = colorize('change', num_1, None)
    str_2 = 'green'
    num_2 = 101
    var_2 = colorize('change', num_2, str_2)


# Generated at 2022-06-25 12:59:14.599161
# Unit test for function colorize
def test_colorize():
    lead = 'lead'
    num = 0
    color = 'yellow'
    var_0 = colorize(lead, num, color)


# Generated at 2022-06-25 12:59:19.194821
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == 'localhost                 '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == '\033[0;33mlocalhost\033[0;0m         '

# Generated at 2022-06-25 12:59:21.898897
# Unit test for function stringc
def test_stringc():
    str_0 = '/tmp/ansible_test_dir'
    str_1 = 'green'
    var_0 = stringc(str_0, str_1)
    print(var_0)


# Generated at 2022-06-25 12:59:30.083920
# Unit test for function hostcolor
def test_hostcolor():
    # $ ansible all -m ping -a "data=blah"
    # 127.0.0.1 | SUCCESS => {
    #    "changed": false,
    #    "ping": "pong"
    # }
    case_0_host = u'127.0.0.1'
    # $ ansible turkey -m ping -a "data=blah"
    case_1_host = u'127.0.0.2'
    # $ ansible all -a "/bin/false"
    # 127.0.0.1 | FAILED | rc=1 >>
    case_2_host = u'127.0.0.3'
    # $ ansible turkey -a "/bin/false"
    case_3_host = u'127.0.0.4'

    case_0

# Generated at 2022-06-25 12:59:49.454232
# Unit test for function stringc
def test_stringc():
    str_0 = 'yellow'
    str_1 = 'red'
    str_2 = 'black'
    str_3 = 'blue'
    str_4 = 'cyan'
    str_5 = 'gray'
    str_6 = 'green'
    str_7 = 'magenta'
    str_8 = 'rgb150'
    str_9 = 'rgb020'
    var_0 = stringc(str_0, str_0)
    var_1 = stringc(str_1, str_0)
    var_2 = stringc(str_2, str_0)
    var_3 = stringc(str_3, str_0)
    var_4 = stringc(str_4, str_0)
    var_5 = stringc(str_5, str_0)
   

# Generated at 2022-06-25 12:59:54.568738
# Unit test for function hostcolor
def test_hostcolor():
    print('[Test case 0]')
    str_0 = '127.0.0.1'
    test_data_0 = {
        'skipped': 0,
        'failed': 0,
        'ok': 2,
        'changed': 1,
        'unreachable': 0,
        'processed': 2
    }
    var_0 = hostcolor(str_0, test_data_0, True)
    print(var_0)

if __name__ == '__main__':
    test_case_0()

    test_hostcolor()

# Generated at 2022-06-25 12:59:55.761067
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('green') == u'32'


# Generated at 2022-06-25 12:59:59.361056
# Unit test for function stringc
def test_stringc():
    # test case
    str_0 = "stringc"
    str_1 = "green"
    res_0 = stringc(str_0, str_1, True)
    assert res_0 is not None


# Generated at 2022-06-25 13:00:02.379273
# Unit test for function colorize
def test_colorize():
    str_0 = 'black'
    num_0 = 0
    var_0 = colorize('lead', num_0, str_0)


# Generated at 2022-06-25 13:00:07.512807
# Unit test for function colorize
def test_colorize():
    assert (u"0=0   " == colorize(u"0", u"0", u"green"))
    assert (u"Colorize=num%c" == colorize(u"Colorize", u"num%c", u"red"))
    assert (u"STRING=str%c" == colorize(u"STRING", u"str%c", u"red"))


# Generated at 2022-06-25 13:00:15.039102
# Unit test for function stringc
def test_stringc():
    str_0 = 'yellow'
    var_1 = stringc(str_0, str_0, False)
    str_1 = '\x1b[0mred\x1b[0m'
    var_2 = stringc(str_1, str_0, False)
    var_3 = stringc(str_0, 'rgb221', False)
    var_4 = stringc(str_0, 'rgb222', False)
    var_5 = stringc(str_0, 'rgb220', False)
    var_6 = stringc(str_0, 'gray2', False)
    var_7 = stringc(str_1, 'rgb221', False)