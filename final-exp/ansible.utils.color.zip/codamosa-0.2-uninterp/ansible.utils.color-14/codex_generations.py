

# Generated at 2022-06-17 14:53:47.901752
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:53:55.796255
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "yellow") == "\033[33mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"
    assert stringc("test", "cyan") == "\033[36mtest\033[0m"
    assert stringc("test", "white") == "\033[37mtest\033[0m"
    assert stringc("test", "color0") == "\033[38;5;0mtest\033[0m"


# Generated at 2022-06-17 14:54:05.581673
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == u"\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255255000") == u"\033[38;5;11mfoo\033[0m"
    assert stringc("foo", "rgb255000000") == u"\033[38;5;9mfoo\033[0m"

# Generated at 2022-06-17 14:54:14.357079
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    print(stringc("This is a test.", "red"))
    print(stringc("This is a test.", "blue"))
    print(stringc("This is a test.", "green"))
    print(stringc("This is a test.", "yellow"))
    print(stringc("This is a test.", "magenta"))
    print(stringc("This is a test.", "cyan"))
    print(stringc("This is a test.", "white"))
    print(stringc("This is a test.", "black"))
    print(stringc("This is a test.", "color1"))
    print(stringc("This is a test.", "color2"))
    print(stringc("This is a test.", "color3"))
    print(stringc("This is a test.", "color4"))
    print

# Generated at 2022-06-17 14:54:25.112804
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"test", u"blue") == u"\033[34mtest\033[0m"
    assert stringc(u"test", u"color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc(u"test", u"rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc(u"test", u"rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc(u"test", u"rgb255255000") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 14:54:35.494194
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('default') == u'39'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'

# Generated at 2022-06-17 14:54:40.349235
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u"foo=0   "
    assert colorize('foo', 1, 'blue') == u"foo=1   "
    assert colorize('foo', 10, 'blue') == u"foo=10  "
    assert colorize('foo', 100, 'blue') == u"foo=100 "
    assert colorize('foo', 1000, 'blue') == u"foo=1000"
    assert colorize('foo', 10000, 'blue') == u"foo=10000"
    assert colorize('foo', 100000, 'blue') == u"foo=100000"
    assert colorize('foo', 1000000, 'blue') == u"foo=1000000"
    assert colorize('foo', 10000000, 'blue') == u"foo=10000000"

# Generated at 2022-06-17 14:54:50.723727
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats) == u'localhost                  '
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('localhost', stats) == u'\x1b[31mlocalhost\x1b[0m          '
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('localhost', stats) == u'\x1b[31mlocalhost\x1b[0m          '
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor('localhost', stats) == u'\x1b[33mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:55:02.477798
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '

# --- end "pretty"

# --- begin "human_log"
#
# human_log - A miniature library that provides a Python print and stdout
# wrapper that makes colored terminal text easier to use (e.g. without
# having to mess around with ANSI escape sequences). This code is public
# domain - there is no license except that

# Generated at 2022-06-17 14:55:10.656451
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """
    pass

# --- end "pretty"

# --- begin "termcap"
#
# termcap - A tiny library

# Generated at 2022-06-17 14:55:25.514771
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# Generated at 2022-06-17 14:55:36.320227
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color99') == u'38;5;99'
    assert parsecolor('rgb123') == u'38;5;123'
    assert parsecolor('rgb321') == u'38;5;201'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('gray0') == u'38;5;232'

# Generated at 2022-06-17 14:55:41.394518
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'
    assert par

# Generated at 2022-06-17 14:55:50.840306
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('color16') == u'38;5;16'
    assert parsecolor('color255') == u'38;5;255'
    assert parsecolor('rgb123') == u'38;5;123'

# Generated at 2022-06-17 14:55:59.879536
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"black") == u"\033[30mfoo\033[0m"
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"

# Generated at 2022-06-17 14:56:08.599925
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'green') == u'\033[32mtest\033[0m'
    assert stringc('test', 'color3') == u'\033[38;5;3mtest\033[0m'
    assert stringc('test', 'rgb255') == u'\033[38;5;231mtest\033[0m'
    assert stringc('test', 'rgb123') == u'\033[38;5;33mtest\033[0m'
    assert stringc('test', 'gray7') == u'\033[38;5;249mtest\033[0m'
    assert stringc('test', 'gray0') == u'\033[38;5;232mtest\033[0m'

# Generated at 2022-06-17 14:56:13.745062
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 14:56:25.303249
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=0)) == u"localhost               "

# Generated at 2022-06-17 14:56:33.691410
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('color9') == '38;5;9'

# Generated at 2022-06-17 14:56:46.620676
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsec

# Generated at 2022-06-17 14:57:00.491670
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000111") == u"\033[38;5;9mtest\033[0m"

# Generated at 2022-06-17 14:57:12.140532
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb0255255") == u"\033[38;5;14mtest\033[0m"
    assert stringc("test", "rgb255255") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 14:57:22.366050
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == "\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == "\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == "\033[36mfoo\033[0m"
    assert stringc("foo", "white") == "\033[37mfoo\033[0m"
    assert stringc("foo", "black") == "\033[30mfoo\033[0m"

# Generated at 2022-06-17 14:57:28.370548
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '

# --- end "pretty"



# Generated at 2022-06-17 14:57:38.639324
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'%-37s' % stringc

# Generated at 2022-06-17 14:57:47.331448
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m             '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m             '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m             '

# Generated at 2022-06-17 14:57:56.812538
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# --- end "pretty"



# Generated at 2022-06-17 14:58:08.527045
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:58:15.087222
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\033[31mlocalhost\033[0m             "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\033[31mlocalhost\033[0m             "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\033[33mlocalhost\033[0m             "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"\033[32mlocalhost\033[0m             "

# Generated at 2022-06-17 14:58:24.570818
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:58:45.161715
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), False) == u"host                 "
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0), False) == u"host                 "

# Generated at 2022-06-17 14:58:52.152954
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('cyan') == '36'
    assert parsecolor('magenta') == '35'
    assert parsecolor('yellow') == '33'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb123') == '38;5;123'
    assert parsecolor('rgb222') == '38;5;222'
   

# Generated at 2022-06-17 14:58:59.799998
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# --- end "pretty"

# Generated at 2022-06-17 14:59:06.835442
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;11mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray1') == u'\033[38;5;234mfoo\033[0m'
    assert stringc('foo', 'gray9') == u'\033[38;5;242mfoo\033[0m'

# Generated at 2022-06-17 14:59:12.668458
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """
    pass


# Generated at 2022-06-17 14:59:21.620268
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"

# Generated at 2022-06-17 14:59:32.669976
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for terminals.
# Copyright

# Generated at 2022-06-17 14:59:46.353508
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                     '


# Generated at 2022-06-17 14:59:56.137008
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 15:00:07.323969
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 15:00:28.419176
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc(u"foo", u"rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc(u"foo", u"rgb000255000") == u"\033[38;5;2mfoo\033[0m"

# Generated at 2022-06-17 15:00:39.072230
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "green") == "\033[32mtext\033[0m"
    assert stringc("text", "color1") == "\033[38;5;1mtext\033[0m"
    assert stringc("text", "rgb255255255") == "\033[38;5;15mtext\033[0m"
    assert stringc("text", "rgb000255000") == "\033[38;5;2mtext\033[0m"
    assert stringc("text", "rgb255000000") == "\033[38;5;9mtext\033[0m"
    assert stringc("text", "rgb255255000") == "\033[38;5;11mtext\033[0m"

# Generated at 2022-06-17 15:00:46.698657
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;3mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'rgb333') == u'\033[38;5;59mfoo\033[0m'
    assert stringc('foo', 'rgb000') == u'\033[38;5;16mfoo\033[0m'

# Generated at 2022-06-17 15:00:57.078457
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), color=True) == u'%-37s' % stringc('host', C.COLOR_OK)
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1), color=True) == u'%-37s' % stringc('host', C.COLOR_CHANGED)
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0), color=True) == u'%-37s' % stringc('host', C.COLOR_ERROR)
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0), color=True) == u'%-37s' % stringc('host', C.COLOR_ERROR)

# Generated at 2022-06-17 15:01:03.914576
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'on_red') == u'\033[41mfoo\033[0m'
    assert stringc('foo', 'on_blue') == u'\033[44mfoo\033[0m'
    assert stringc('foo', 'red', wrap_nonvisible_chars=True) == u'\001\033[31m\002foo\001\033[0m\002'
    assert stringc('foo', 'blue', wrap_nonvisible_chars=True) == u'\001\033[34m\002foo\001\033[0m\002'
    assert string

# Generated at 2022-06-17 15:01:11.393080
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), color=False) == u"localhost                "


# Generated at 2022-06-17 15:01:19.864185
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"

# Generated at 2022-06-17 15:01:31.370542
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "black") == u"\033[30mtest\033[0m"
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"

# Generated at 2022-06-17 15:01:37.394612
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize("foo", 42, "blue")
    'foo=42  '
    >>> colorize("foo", 42, None)
    'foo=42  '
    >>> colorize("foo", 0, "blue")
    'foo=0   '
    >>> colorize("foo", 0, None)
    'foo=0   '
    """
    pass



# Generated at 2022-06-17 15:01:47.457719
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# --- end "pretty"

# --- begin "terminal"



# Generated at 2022-06-17 15:02:06.719984
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u"host                 "
    assert hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u"host                 "
    assert hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u"host                 "
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u"host                 "

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for terminals.
# Copyright (C) 2012  Brandon Invergo <brandon@invergo.net>
#
# This program is free software: you can redistribute

# Generated at 2022-06-17 15:02:15.833046
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('host1', stats, color=True) == u"\x1b[0;32m%-37s\x1b[0m" % 'host1'
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('host1', stats, color=True) == u"\x1b[0;31m%-37s\x1b[0m" % 'host1'
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('host1', stats, color=True) == u"\x1b[0;31m%-37s\x1b[0m" % 'host1'
    stats = dict

# Generated at 2022-06-17 15:02:24.785057
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'%-37s' % stringc

# Generated at 2022-06-17 15:02:35.240751
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:02:48.431090
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:02:57.170187
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 15:03:06.296271
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# Generated at 2022-06-17 15:03:17.816905
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:03:24.648501
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "rgb255255255") == "\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == "\033[38;5;34mtest\033[0m"
    assert stringc("test", "rgb255000255") == "\033[38;5;55mtest\033[0m"
    assert stringc("test", "rgb255000000") == "\033[38;5;9mtest\033[0m"
    assert stringc("test", "rgb000255255") == "\033[38;5;45mtest\033[0m"

# Generated at 2022-06-17 15:03:35.620841
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "color1") == "\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == "\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == "\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255000000") == "\033[38;5;9mfoo\033[0m"
    assert stringc("foo", "rgb000255255") == "\033[38;5;3mfoo\033[0m"