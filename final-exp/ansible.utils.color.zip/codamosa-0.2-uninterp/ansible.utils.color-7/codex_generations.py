

# Generated at 2022-06-17 14:53:47.381763
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert par

# Generated at 2022-06-17 14:53:55.406024
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                     '


# Generated at 2022-06-17 14:54:05.230042
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 14:54:14.092112
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                 '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                 '


# Generated at 2022-06-17 14:54:25.186857
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == '\x1b[34mfoo\x1b[0m'
    assert stringc('foo', 'blue', wrap_nonvisible_chars=True) == '\x01\x1b[34m\x02foo\x01\x1b[0m\x02'
    assert stringc('foo\nbar', 'blue') == '\x1b[34mfoo\nbar\x1b[0m'
    assert stringc('foo\nbar', 'blue', wrap_nonvisible_chars=True) == '\x01\x1b[34m\x02foo\nbar\x01\x1b[0m\x02'

# Generated at 2022-06-17 14:54:35.570849
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'
    assert par

# Generated at 2022-06-17 14:54:45.361110
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('on_red') == '41'
    assert parsecolor('on_green') == '42'
    assert parsecolor('on_blue') == '44'
    assert parsecolor('on_yellow') == '43'
    assert parsecolor('on_magenta') == '45'
    assert parsecolor('on_cyan') == '46'
   

# Generated at 2022-06-17 14:54:56.152809
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0, ok=1)) == u"localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1, ok=0)) == u"\x1b[0;34mlocalhost               \x1b[0m"
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0, ok=0)) == u"\x1b[0;31mlocalhost               \x1b[0m"
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0, ok=0)) == u"\x1b[0;31mlocalhost               \x1b[0m"

# Generated at 2022-06-17 14:55:06.889952
# Unit test for function stringc
def test_stringc():
    """Test function stringc()."""
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'red', wrap_nonvisible_chars=True) == '\001\033[31m\002foo\001\033[0m\002'
    assert stringc('foo', 'color1') == '\033[38;5;1mfoo\033[0m'
    assert stringc('foo', 'rgb255') == '\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == '\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray0') == '\033[38;5;232mfoo\033[0m'

# Generated at 2022-06-17 14:55:13.251754
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host                         '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host                         '
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host                         '
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host                         '
    assert hostcolor('host', dict(failures=1, unreachable=1, changed=1)) == u'host                         '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), color=False) == u'host               '

# Generated at 2022-06-17 14:55:27.377503
# Unit test for function colorize
def test_colorize():
    # Test colorize function
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0 '
    assert colorize('failed', 0, 'red') == 'failed=0    '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0   '

    assert colorize('ok', 1, 'green') == stringc('ok=1   ', 'green')
    assert colorize('changed', 2, 'yellow') == stringc('changed=2   ', 'yellow')
    assert colorize('unreachable', 3, 'red') == stringc('unreachable=3 ', 'red')

# Generated at 2022-06-17 14:55:37.496340
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
   

# Generated at 2022-06-17 14:55:49.056635
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 10, 'blue') == u'foo=10  '
    assert colorize('foo', 100, 'blue') == u'foo=100 '
    assert colorize('foo', 1000, 'blue') == u'foo=1000'
    assert colorize('foo', 10000, 'blue') == u'foo=10000'
    assert colorize('foo', 100000, 'blue') == u'foo=100000'
    assert colorize('foo', 1000000, 'blue') == u'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == u'foo=10000000'

# Generated at 2022-06-17 14:55:58.863042
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;11mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray7') == u'\033[38;5;239mfoo\033[0m'
    assert stringc('foo', 'gray0') == u'\033[38;5;232mfoo\033[0m'

# Generated at 2022-06-17 14:56:07.488463
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:56:16.267018
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 14:56:26.860457
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc('foo', 'rgb255255255') == u'\033[38;5;15mfoo\033[0m'
    assert stringc('foo', 'rgb000255000') == u'\033[38;5;2mfoo\033[0m'
    assert stringc('foo', 'rgb255000000') == u'\033[38;5;9mfoo\033[0m'

# Generated at 2022-06-17 14:56:34.928989
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;11mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'rgb333') == u'\033[38;5;59mfoo\033[0m'
    assert stringc('foo', 'rgb000') == u'\033[38;5;16mfoo\033[0m'

# Generated at 2022-06-17 14:56:47.974338
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('color16') == u'38;5;16'
    assert parsecolor('color255') == u'38;5;255'
    assert parsecolor('rgb123') == u'38;5;123'

# Generated at 2022-06-17 14:56:52.353319
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4')

# Generated at 2022-06-17 14:57:04.386555
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 14:57:13.406539
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'

# Generated at 2022-06-17 14:57:24.250460
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                    "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m            "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m            "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m            "

# Generated at 2022-06-17 14:57:33.315039
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray23') == u'38;5;255'
    assert parsecolor('gray24') == u'38;5;255'
    assert parsecolor('gray25') == u'38;5;255'
    assert parsecolor('gray26') == u'38;5;255'
    assert parsecolor('gray27') == u'38;5;255'
    assert parsecolor('gray28') == u'38;5;255'
    assert parsecolor('gray29') == u

# Generated at 2022-06-17 14:57:45.138024
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '

# --- end "pretty"



# Generated at 2022-06-17 14:57:56.261829
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:58:08.316764
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:58:14.175717
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 42, None)
    'foo=42  '
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-17 14:58:24.052721
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color9') == '38;5;9'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color11') == '38;5;11'
    assert parsecolor('color12') == '38;5;12'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color21') == '38;5;21'
    assert parsecolor('color22') == '38;5;22'
    assert parsecolor('color23') == '38;5;23'

# Generated at 2022-06-17 14:58:34.111072
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 14:58:48.526257
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 14:59:01.828828
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# --- end "pretty"



# Generated at 2022-06-17 14:59:12.871772
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:59:19.235850
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == 'host'
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1}) == 'host'
    assert hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0}) == 'host'
    assert hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0}) == 'host'



# Generated at 2022-06-17 14:59:31.214067
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:59:40.783468
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:59:47.415004
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "

# --- end "pretty"



# Generated at 2022-06-17 14:59:56.897775
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'

# Generated at 2022-06-17 15:00:07.824200
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m             '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m             '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m             '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'\x1b[32mlocalhost\x1b[0m             '

# Generated at 2022-06-17 15:00:16.801467
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u"%-26s" % 'foo'
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc('foo', C.COLOR_ERROR)
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc('foo', C.COLOR_CHANGED)

# Generated at 2022-06-17 15:00:31.240179
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:00:38.495791
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost               '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'localhost               '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'localhost               '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'localhost               '

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for terminals.
# Copyright (C) 2012  Jochen Skulj, jochen@jochenskulj.de
#
# This program is free software

# Generated at 2022-06-17 15:00:50.522123
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 15:00:59.722133
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u"%-37s" % 'localhost'
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)

# --- end "pretty"



# Generated at 2022-06-17 15:01:09.757233
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc

# Generated at 2022-06-17 15:01:19.374846
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:01:30.777226
# Unit test for function stringc
def test_stringc():
    """Test function stringc"""
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'blue', wrap_nonvisible_chars=True) == u'\001\033[34m\002foo\001\033[0m\002'
    assert stringc('foo', 'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'

# Generated at 2022-06-17 15:01:34.270395
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'

# --- end "pretty"

# Generated at 2022-06-17 15:01:44.173325
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:01:54.127409
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 15:02:19.900442
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=True) == u"%-37s" % stringc('localhost', C.COLOR_OK)
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('localhost', stats, color=True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor('localhost', stats, color=True) == u"%-37s"

# Generated at 2022-06-17 15:02:26.572736
# Unit test for function stringc
def test_stringc():
    """Test for function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"
    assert stringc(u"foo", u"white")

# Generated at 2022-06-17 15:02:36.043341
# Unit test for function stringc

# Generated at 2022-06-17 15:02:48.520964
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:02:54.577642
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'purple') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:03:04.802331
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "black") == "\033[30mfoo\033[0m"
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == "\033[33mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "magenta") == "\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == "\033[36mfoo\033[0m"
    assert stringc("foo", "white") == "\033[37mfoo\033[0m"

# Generated at 2022-06-17 15:03:13.483107
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 15:03:22.131803
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), color=True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), color=True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), color=True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 15:03:34.776315
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)