

# Generated at 2022-06-17 14:53:45.494360
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('rgb123') == '38;5;123'
    assert parsecolor('rgb321') == '38;5;201'
    assert parsecolor('rgb213') == '38;5;115'
    assert parsecolor('rgb111') == '38;5;16'

# Generated at 2022-06-17 14:53:53.915311
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:54:04.299078
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('default') == u'39'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'

# Generated at 2022-06-17 14:54:12.424767
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('default') == u'39'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'

# Generated at 2022-06-17 14:54:19.670931
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:54:27.771788
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('color15') == u'38;5;15'
    assert parsecolor('rgb555') == u'38;5;231'

# Generated at 2022-06-17 14:54:36.663538
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost                '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[33mlocalhost\x1b[0m         '

# --- end "pretty"



# Generated at 2022-06-17 14:54:47.189909
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:54:58.307417
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:55:08.673134
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == u"\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255000000") == u"\033[38;5;9mfoo\033[0m"

# Generated at 2022-06-17 14:55:24.141468
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m         '

# Generated at 2022-06-17 14:55:33.419325
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '

# Generated at 2022-06-17 14:55:41.605884
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002test\001\033[0m\002"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb123") == u"\033[38;5;33mtest\033[0m"

# Generated at 2022-06-17 14:55:50.988478
# Unit test for function stringc
def test_stringc():
    """Test stringc function"""
    assert stringc(u"test", u"red") == u"\033[31mtest\033[0m"
    assert stringc(u"test", u"blue") == u"\033[34mtest\033[0m"
    assert stringc(u"test", u"green") == u"\033[32mtest\033[0m"
    assert stringc(u"test", u"yellow") == u"\033[33mtest\033[0m"
    assert stringc(u"test", u"magenta") == u"\033[35mtest\033[0m"
    assert stringc(u"test", u"cyan") == u"\033[36mtest\033[0m"
    assert stringc(u"test", u"white") == u

# Generated at 2022-06-17 14:55:59.980392
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == '\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == '\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == '\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:56:04.762072
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 14:56:11.343798
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('blue') == '34'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color99') == '38;5;99'
    assert parsecolor('rgb123') == '38;5;123'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray23') == '38;5;255'
    assert parsecolor('gray24') == '38;5;255'
    assert parsecolor('gray99') == '38;5;255'

# --- end "pretty"



# Generated at 2022-06-17 14:56:23.719128
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 14:56:32.233699
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:56:45.944302
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 14:56:58.564044
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'host                 '
    assert hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'host                 '
    assert hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'host                 '
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'host                 '
    assert hostcolor('host', {'failures': 1, 'unreachable': 1, 'changed': 1}) == u'host                 '

# --- end "pretty"



# Generated at 2022-06-17 14:57:05.633001
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u'foo                          '
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mfoo\x1b[0m                    '
    assert hostcolor('foo', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mfoo\x1b[0m                    '
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mfoo\x1b[0m                    '

# Generated at 2022-06-17 14:57:14.570534
# Unit test for function stringc

# Generated at 2022-06-17 14:57:24.768506
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# --- end "pretty"



# Generated at 2022-06-17 14:57:29.714500
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'green') == u"\033[32mtest\033[0m"
    assert stringc('test', 'color3') == u"\033[38;5;3mtest\033[0m"
    assert stringc('test', 'rgb255') == u"\033[38;5;231mtest\033[0m"
    assert stringc('test', 'rgb333') == u"\033[38;5;59mtest\033[0m"
    assert stringc('test', 'rgb123') == u"\033[38;5;33mtest\033[0m"
    assert stringc('test', 'rgb321') == u"\033[38;5;94mtest\033[0m"
    assert stringc('test', 'rgb213') == u

# Generated at 2022-06-17 14:57:38.336128
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc("text", "red") == u"\033[31mtext\033[0m"
    assert stringc("text", "green") == u"\033[32mtext\033[0m"
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "color1") == u"\033[38;5;1mtext\033[0m"
    assert stringc("text", "color2") == u"\033[38;5;2mtext\033[0m"
    assert stringc("text", "color3") == u"\033[38;5;3mtext\033[0m"

# Generated at 2022-06-17 14:57:46.114280
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;34mtest\033[0m"
    assert stringc("test", "rgb255000255") == u"\033[38;5;55mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;39mtest\033[0m"
    assert stringc

# Generated at 2022-06-17 14:57:57.095549
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:58:08.564675
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""
    assert stringc(u'foo', u'blue') == u'\033[34mfoo\033[0m'
    assert stringc(u'foo', u'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc(u'foo', u'rgb255255255') == u'\033[38;5;15mfoo\033[0m'
    assert stringc(u'foo', u'rgb000255255') == u'\033[38;5;6mfoo\033[0m'
    assert stringc(u'foo', u'rgb255255000') == u'\033[38;5;11mfoo\033[0m'

# Generated at 2022-06-17 14:58:15.111234
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats) == u'localhost               '
    stats['failures'] = 1
    assert hostcolor('localhost', stats) == u'\x1b[31mlocalhost\x1b[0m         '
    stats['failures'] = 0
    stats['unreachable'] = 1
    assert hostcolor('localhost', stats) == u'\x1b[31mlocalhost\x1b[0m         '
    stats['unreachable'] = 0
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == u'\x1b[33mlocalhost\x1b[0m         '
    stats['changed'] = 0

# Generated at 2022-06-17 14:58:32.897657
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:58:46.107409
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'



# Generated at 2022-06-17 14:58:57.203373
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 12, 'blue') == 'foo=12  '
    assert colorize('foo', 123, 'blue') == 'foo=123 '
    assert colorize('foo', 1234, 'blue') == 'foo=1234'
    assert colorize('foo', 12345, 'blue') == 'foo=12345'
    assert colorize('foo', 123456, 'blue') == 'foo=123456'

# Generated at 2022-06-17 14:59:03.323599
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m         '

# Generated at 2022-06-17 14:59:14.229680
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:59:21.621018
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost               '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[0;32mlocalhost\x1b[0m'
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[0;31mlocalhost\x1b[0m'
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[0;31mlocalhost\x1b[0m'



# Generated at 2022-06-17 14:59:32.669968
# Unit test for function stringc
def test_stringc():
    print(stringc("test", "green"))
    print(stringc("test", "red"))
    print(stringc("test", "blue"))
    print(stringc("test", "yellow"))
    print(stringc("test", "magenta"))
    print(stringc("test", "cyan"))
    print(stringc("test", "white"))
    print(stringc("test", "black"))
    print(stringc("test", "color1"))
    print(stringc("test", "color2"))
    print(stringc("test", "color3"))
    print(stringc("test", "color4"))
    print(stringc("test", "color5"))
    print(stringc("test", "color6"))
    print(stringc("test", "color7"))

# Generated at 2022-06-17 14:59:46.354553
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 14:59:56.136726
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# Generated at 2022-06-17 15:00:07.324619
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# Generated at 2022-06-17 15:00:30.427249
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 15:00:40.273953
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# Generated at 2022-06-17 15:00:48.719337
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# Generated at 2022-06-17 15:00:58.145480
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m               '

# Generated at 2022-06-17 15:01:08.846434
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;11mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray7') == u'\033[38;5;250mfoo\033[0m'
    assert stringc('foo', 'gray0') == u'\033[38;5;232mfoo\033[0m'

# Generated at 2022-06-17 15:01:21.041459
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor(host, stats) == u'%-26s' % host
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_CHANGED)
    stats = dict

# Generated at 2022-06-17 15:01:31.977037
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 15:01:45.577562
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:01:55.252884
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 15:02:05.580342
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('cyan') == u'38;5;6'
    assert parsecolor('white') == u'38;5;7'
    assert parsecolor('bright_black') == u'38;5;8'
    assert parsecolor('bright_red') == u'38;5;9'

# Generated at 2022-06-17 15:02:23.225508
# Unit test for function colorize
def test_colorize():
    """
    >>> print(colorize('foo', 42, 'blue'))
    foo=42
    >>> print(colorize('foo', 0, 'blue'))
    foo=0
    """


# Generated at 2022-06-17 15:02:28.713805
# Unit test for function colorize
def test_colorize():
    print(colorize(u"foo", u"1", C.COLOR_CHANGED))
    print(colorize(u"foo", u"2", C.COLOR_ERROR))
    print(colorize(u"foo", u"3", C.COLOR_OK))
    print(colorize(u"foo", u"4", None))



# Generated at 2022-06-17 15:02:37.024610
# Unit test for function stringc

# Generated at 2022-06-17 15:02:47.856990
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'blue') == u"\033[34mfoo\033[0m"
    assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"
    assert stringc('foo', 'yellow') == u"\033[33mfoo\033[0m"
    assert stringc('foo', 'magenta') == u"\033[35mfoo\033[0m"
    assert stringc('foo', 'cyan') == u"\033[36mfoo\033[0m"
    assert stringc('foo', 'white') == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 15:02:58.076028
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"


# Generated at 2022-06-17 15:03:06.876653
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"Hello", u"blue") == u"\033[34mHello\033[0m"
    assert stringc(u"Hello", u"rgb255255255") == u"\033[38;5;15mHello\033[0m"
    assert stringc(u"Hello", u"rgb000255000") == u"\033[38;5;34mHello\033[0m"
    assert stringc(u"Hello", u"rgb000255255") == u"\033[38;5;39mHello\033[0m"
    assert stringc(u"Hello", u"rgb255000255") == u"\033[38;5;213mHello\033[0m"

# Generated at 2022-06-17 15:03:18.151421
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == '\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == '\033[36mfoo\033[0m'
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'white') == '\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:03:23.131986
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:03:35.129890
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"