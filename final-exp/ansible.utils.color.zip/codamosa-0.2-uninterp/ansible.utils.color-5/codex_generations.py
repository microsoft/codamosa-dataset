

# Generated at 2022-06-17 14:53:47.849015
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "yellow") == "\033[33mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"
    assert stringc("test", "cyan") == "\033[36mtest\033[0m"
    assert stringc("test", "white") == "\033[37mtest\033[0m"
    assert stringc("test", "black") == "\033[30mtest\033[0m"

# Generated at 2022-06-17 14:53:55.768127
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '

# Generated at 2022-06-17 14:54:05.581603
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('color16') == u'38;5;16'
    assert parsecolor('color255') == u'38;5;255'
    assert parsecolor('rgb123') == u'38;5;123'

# Generated at 2022-06-17 14:54:13.240260
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb000255255') == u'38;5;6'
    assert parsecolor('rgb255255000') == u'38;5;11'
    assert parsecolor('rgb255000255') == u'38;5;13'
    assert parsecolor('rgb000255000') == u'38;5;2'
    assert parsecolor('rgb255000000') == u'38;5;9'
    assert parsecolor('rgb000000000') == u'38;5;0'
    assert parsecolor('rgb255255255') == u

# Generated at 2022-06-17 14:54:20.146272
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "purple") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 14:54:25.775776
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '



# Generated at 2022-06-17 14:54:35.661613
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '

# --- end "pretty"

# --- begin "human_log"


# Generated at 2022-06-17 14:54:41.491995
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost                \x1b[0m"
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost                \x1b[0m"
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost                \x1b[0m"

# Generated at 2022-06-17 14:54:51.189900
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 2, 'blue') == u'foo=2   '
    assert colorize('foo', 100, 'blue') == u'foo=100 '
    assert colorize('foo', 1000, 'blue') == u'foo=1000'
    assert colorize('foo', 0, None) == u'foo=0   '
    assert colorize('foo', 1, None) == u'foo=1   '
    assert colorize('foo', 2, None) == u'foo=2   '
    assert colorize('foo', 100, None) == u'foo=100 '

# Generated at 2022-06-17 14:55:02.952525
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:55:20.335815
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 0, 'red') == 'foo=0   '
    assert colorize('foo', 1, 'red') == 'foo=1   '
    assert colorize('foo', 2, 'red') == 'foo=2   '
    assert colorize('foo', 3, 'red') == 'foo=3   '
    assert colorize('foo', 4, 'red') == 'foo=4   '
    assert colorize('foo', 5, 'red') == 'foo=5   '
    assert colorize('foo', 6, 'red') == 'foo=6   '
    assert colorize('foo', 7, 'red') == 'foo=7   '
    assert colorize('foo', 8, 'red') == 'foo=8   '

# Generated at 2022-06-17 14:55:30.297517
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:55:37.348888
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor('host', stats) == u"host                 "
    stats['failures'] = 1
    assert hostcolor('host', stats) == u"host                 "
    stats['failures'] = 0
    stats['unreachable'] = 1
    assert hostcolor('host', stats) == u"host                 "
    stats['unreachable'] = 0
    stats['changed'] = 1
    assert hostcolor('host', stats) == u"host                 "
    stats['changed'] = 0
    assert hostcolor('host', stats) == u"host                 "
    stats['failures'] = 1
    assert hostcolor('host', stats) == u"host                 "
    stats['failures'] = 0

# Generated at 2022-06-17 14:55:48.888451
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:55:58.587228
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:56:07.623198
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# --- end "pretty"

# Generated at 2022-06-17 14:56:16.375360
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:56:26.859157
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 14:56:35.199830
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 14:56:48.080671
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-17 14:57:07.787153
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:57:15.232065
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "color8") == u"\033[38;5;8mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == u"\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255000000") == u"\033[38;5;9mfoo\033[0m"
    assert stringc("foo", "rgb000255255") == u"\033[38;5;3mfoo\033[0m"

# Generated at 2022-06-17 14:57:25.980552
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "color1") == "\033[38;5;1mtest\033[0m"
    assert stringc("test", "color9") == "\033[38;5;9mtest\033[0m"
    assert stringc("test", "color10") == "\033[38;5;10mtest\033[0m"
    assert stringc("test", "color11") == "\033[38;5;11mtest\033[0m"
    assert stringc("test", "color12") == "\033[38;5;12mtest\033[0m"

# Generated at 2022-06-17 14:57:36.747416
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:57:47.273163
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:57:56.284161
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '

# --- end "pretty"



# Generated at 2022-06-17 14:58:08.318510
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 14:58:19.953086
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "color3") == "\033[38;5;3mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == "\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == "\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255255000") == "\033[38;5;11mfoo\033[0m"
    assert stringc("foo", "rgb255000000") == "\033[38;5;1mfoo\033[0m"

# Generated at 2022-06-17 14:58:28.177270
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'



# Generated at 2022-06-17 14:58:39.036665
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)



# Generated at 2022-06-17 14:59:04.163179
# Unit test for function colorize
def test_colorize():
    """
    >>> print(colorize('foo', 42, 'blue'))
    foo=42
    >>> print(colorize('foo', 0, 'blue'))
    foo=0
    >>> print(colorize('foo', 42, None))
    foo=42
    >>> print(colorize('foo', 0, None))
    foo=0
    """
    pass


# Generated at 2022-06-17 14:59:14.782499
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "yellow") == "\033[33mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"
    assert stringc("test", "cyan") == "\033[36mtest\033[0m"
    assert stringc("test", "white") == "\033[37mtest\033[0m"
    assert stringc("test", "color0") == "\033[38;5;0mtest\033[0m"


# Generated at 2022-06-17 14:59:20.772038
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    # Test foreground colors
    assert stringc('test', 'black') == u"\033[30mtest\033[0m"
    assert stringc('test', 'red') == u"\033[31mtest\033[0m"
    assert stringc('test', 'green') == u"\033[32mtest\033[0m"
    assert stringc('test', 'yellow') == u"\033[33mtest\033[0m"
    assert stringc('test', 'blue') == u"\033[34mtest\033[0m"
    assert stringc('test', 'magenta') == u"\033[35mtest\033[0m"

# Generated at 2022-06-17 14:59:32.922009
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                 "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;34mlocalhost             \x1b[0m"
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost             \x1b[0m"
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost             \x1b[0m"

# Generated at 2022-06-17 14:59:46.491432
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u"%-26s" % 'host'
    assert hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u"%-37s" % stringc('host', C.COLOR_ERROR)
    assert hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u"%-37s" % stringc('host', C.COLOR_ERROR)
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u"%-37s" % stringc('host', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:59:56.241576
# Unit test for function stringc

# Generated at 2022-06-17 15:00:07.414580
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color99') == u'38;5;99'
    assert parsecolor('rgb123') == u'38;5;123'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray23') == u'38;5;255'
    assert parsecolor('gray24') == u'38;5;255'

# Generated at 2022-06-17 15:00:19.212373
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 15:00:29.323875
# Unit test for function colorize
def test_colorize():
    # Test with ANSIBLE_COLOR=False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0   '

    # Test with ANSIBLE_COLOR=True
    ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '

# Generated at 2022-06-17 15:00:37.234146
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == u'31'
    assert parsecolor("blue") == u'34'
    assert parsecolor("color1") == u'38;5;1'
    assert parsecolor("rgb255") == u'38;5;231'
    assert parsecolor("rgb255255255") == u'38;5;15'
    assert parsecolor("rgb000") == u'38;5;16'
    assert parsecolor("rgb000111") == u'38;5;21'
    assert parsecolor("rgb000111222") == u'38;5;36'
    assert parsecolor("gray0") == u'38;5;232'
    assert parsecolor("gray23") == u'38;5;255'
    assert parsecolor("gray24")

# Generated at 2022-06-17 15:01:08.977620
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 15:01:18.944989
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:01:30.204954
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "color2") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "color3") == u"\033[38;5;3mtest\033[0m"

# Generated at 2022-06-17 15:01:39.626121
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 15:01:49.365964
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 15:01:58.911052
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '

# --- end "pretty"



# Generated at 2022-06-17 15:02:07.857254
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 15:02:13.041130
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:02:23.681788
# Unit test for function colorize
def test_colorize():
    # Test with ANSIBLE_COLOR = False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('foo', 0, 'red') == 'foo=0   '
    assert colorize('foo', 1, 'red') == 'foo=1   '
    assert colorize('foo', 10, 'red') == 'foo=10  '
    assert colorize('foo', 100, 'red') == 'foo=100 '
    assert colorize('foo', 1000, 'red') == 'foo=1000'
    assert colorize('foo', 10000, 'red') == 'foo=10000'
    assert colorize('foo', 100000, 'red') == 'foo=100000'
    assert colorize('foo', 1000000, 'red') == 'foo=1000000'

# Generated at 2022-06-17 15:02:34.624431
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u'foo', u'blue') == u'\033[34mfoo\033[0m'
    assert stringc(u'foo', u'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc(u'foo', u'rgb255255255') == u'\033[38;5;15mfoo\033[0m'
    assert stringc(u'foo', u'rgb000255000') == u'\033[38;5;2mfoo\033[0m'
    assert stringc(u'foo', u'rgb255255000') == u'\033[38;5;11mfoo\033[0m'
    assert stringc(u'foo', u'rgb255000000')

# Generated at 2022-06-17 15:03:20.656731
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u"localhost               "

# --- end "pretty"



# Generated at 2022-06-17 15:03:33.092496
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;3mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;1mtest\033[0m"