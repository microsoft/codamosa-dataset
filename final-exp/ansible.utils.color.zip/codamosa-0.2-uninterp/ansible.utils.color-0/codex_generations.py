

# Generated at 2022-06-17 14:53:46.779312
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color9') == u'38;5;9'
    assert parsecolor('color10') == u'38;5;10'
    assert parsecolor('color15') == u'38;5;15'
    assert parsecolor('color16') == u'38;5;16'
    assert parsecolor('color255') == u'38;5;255'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('rgb333') == u'38;5;63'

# Generated at 2022-06-17 14:53:55.104228
# Unit test for function hostcolor
def test_hostcolor():
    host = 'testhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 14:54:05.027923
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'
    assert par

# Generated at 2022-06-17 14:54:12.896977
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb000") == u"\033[38;5;16mtest\033[0m"
    assert stringc("test", "rgb123") == u"\033[38;5;33mtest\033[0m"
    assert stringc("test", "rgb333") == u"\033[38;5;59mtest\033[0m"

# Generated at 2022-06-17 14:54:24.103069
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color99') == u'38;5;99'
    assert parsecolor('rgb123') == u'38;5;123'
    assert parsecolor('rgb321') == u'38;5;201'
    assert parsecolor('rgb213') == u'38;5;173'
    assert parsecolor('rgb111') == u'38;5;232'
    assert parsecolor('rgb555') == u'38;5;255'
    assert parsecolor('gray0') == u'38;5;232'

# Generated at 2022-06-17 14:54:34.763943
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('cyan') == u'38;5;6'
    assert parsecolor('white') == u'38;5;7'
    assert parsecolor('brightblack') == u'38;5;8'
    assert parsecolor('brightred') == u'38;5;9'

# Generated at 2022-06-17 14:54:40.917674
# Unit test for function colorize
def test_colorize():
    # Test with color off
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0   '

    # Test with color on
    ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '

# Generated at 2022-06-17 14:54:50.857585
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:55:02.622817
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('blue') == '34'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('cyan') == '36'
    assert parsecolor('magenta') == '35'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:55:11.592246
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == 'host                 '
    assert hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0}) == 'host                 '
    assert hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0}) == 'host                 '
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1}) == 'host                 '
    assert hostcolor('host', {'failures': 1, 'unreachable': 1, 'changed': 1}) == 'host                 '
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}, False) == 'host                 '

# Generated at 2022-06-17 14:55:26.019882
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# --- end "pretty"



# Generated at 2022-06-17 14:55:36.790668
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;32mlocalhost          \x1b[0m"
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost          \x1b[0m"
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost          \x1b[0m"

# Generated at 2022-06-17 14:55:45.113980
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '



# Generated at 2022-06-17 14:55:53.735831
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:56:01.562514
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:56:09.420922
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:56:17.646411
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"


# Generated at 2022-06-17 14:56:27.901739
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                 '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# --- end "pretty"



# Generated at 2022-06-17 14:56:35.584556
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002test\001\033[0m\002"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb255255255", wrap_nonvisible_chars=True) == u"\001\033[38;5;15m\002test\001\033[0m\002"
    assert stringc("test", "rgb000255000") == u"\033[38;5;34mtest\033[0m"


# Generated at 2022-06-17 14:56:48.435322
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;3mtest\033[0m"

# Generated at 2022-06-17 14:57:06.396544
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 14:57:08.952840
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '



# Generated at 2022-06-17 14:57:20.258633
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "color3") == "\033[38;5;3mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == "\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == "\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255255000") == "\033[38;5;11mfoo\033[0m"
    assert stringc("foo", "rgb000255255") == "\033[38;5;4mfoo\033[0m"

# Generated at 2022-06-17 14:57:29.105415
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """
    pass

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for terminals.
# Copyright (C) 2012  Brandon McCaig
#
# This file is part of terminal.
#
# terminal is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 2 of the License, or
# (at your option

# Generated at 2022-06-17 14:57:38.884626
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;3mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray7') == u'\033[38;5;249mfoo\033[0m'

# Generated at 2022-06-17 14:57:46.509064
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m     '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m     '

# Generated at 2022-06-17 14:57:50.612845
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)

    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)

    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)

    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 14:58:00.786870
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "gray0") == u"\033[38;5;232mtest\033[0m"
    assert stringc("test", "gray23") == u"\033[38;5;255mtest\033[0m"
    assert stringc("test", "invalid") == u"\033[39mtest\033[0m"

# Generated at 2022-06-17 14:58:10.229682
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:58:22.223759
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'



# Generated at 2022-06-17 14:58:41.297850
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:58:50.737191
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:59:02.731953
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'on_red') == u'\033[41mfoo\033[0m'
    assert stringc('foo', 'on_blue') == u'\033[44mfoo\033[0m'
    assert stringc('foo', 'red', wrap_nonvisible_chars=True) == u'\001\033[31m\002foo\001\033[0m\002'

# Generated at 2022-06-17 14:59:10.839442
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "



# Generated at 2022-06-17 14:59:21.306409
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 14:59:32.670030
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m    '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m    '

# Generated at 2022-06-17 14:59:46.353573
# Unit test for function stringc

# Generated at 2022-06-17 14:59:56.137623
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mfoo\x1b[0m               '
    assert hostcolor('foo', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mfoo\x1b[0m               '
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mfoo\x1b[0m               '
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u'\x1b[32mfoo\x1b[0m               '

# Generated at 2022-06-17 15:00:07.324444
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 15:00:16.737705
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:00:32.071969
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# Generated at 2022-06-17 15:00:44.935981
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=0), True) == u'host1                          '
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=0), False) == u'host1                         '
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=1), True) == u'\x1b[0;34mhost1                          \x1b[0m'
    assert hostcolor('host1', dict(failures=0, unreachable=1, changed=0), True) == u'\x1b[0;31mhost1                          \x1b[0m'
    assert hostcolor('host1', dict(failures=1, unreachable=0, changed=0), True) == u

# Generated at 2022-06-17 15:00:55.944968
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 15:01:07.935067
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '

# --- end "pretty"



# Generated at 2022-06-17 15:01:21.008938
# Unit test for function stringc
def test_stringc():
    """Test for function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc('foo', 'rgb255255255') == u'\033[38;5;15mfoo\033[0m'
    assert stringc('foo', 'rgb000255255') == u'\033[38;5;6mfoo\033[0m'
    assert stringc('foo', 'rgb255255000') == u'\033[38;5;11mfoo\033[0m'
    assert stringc

# Generated at 2022-06-17 15:01:31.974142
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""
    # Test color names
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'


# Generated at 2022-06-17 15:01:45.577256
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), color=False) == u"localhost                "


# Generated at 2022-06-17 15:01:55.252796
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 15:02:05.579492
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'


# Generated at 2022-06-17 15:02:09.777672
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0'
    assert colorize('failed', 0, 'red') == 'failed=0    '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0   '



# Generated at 2022-06-17 15:02:36.330015
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '

# Generated at 2022-06-17 15:02:46.976573
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '

# --- end "pretty"



# Generated at 2022-06-17 15:02:54.231869
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 15:03:04.558650
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color off
    ANSIBLE_COLOR = False
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == '%-26s' % 'localhost'
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == '%-26s' % 'localhost'
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == '%-26s' % 'localhost'
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == '%-26s' % 'localhost'
    # Test with color on
    ANSIBLE_COLOR = True

# Generated at 2022-06-17 15:03:13.273699
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                     '


# Generated at 2022-06-17 15:03:19.787136
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "yellow") == "\033[33mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"
    assert stringc("test", "cyan") == "\033[36mtest\033[0m"
    assert stringc("test", "white") == "\033[37mtest\033[0m"
    assert stringc("test", "color1") == "\033[38;5;1mtest\033[0m"


# Generated at 2022-06-17 15:03:31.898155
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '

# --- end "pretty"

