

# Generated at 2022-06-17 14:53:46.346886
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"

# Generated at 2022-06-17 14:53:54.701570
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:54:04.909442
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('host', C.COLOR_OK)
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('host', C.COLOR_CHANGED)
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('host', C.COLOR_ERROR)
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('host', C.COLOR_ERROR)

# Generated at 2022-06-17 14:54:13.768030
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:54:24.953304
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('green') == u'32'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('rgb222') == u'38;5;58'

# Generated at 2022-06-17 14:54:35.353034
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:54:39.624747
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '



# Generated at 2022-06-17 14:54:49.507391
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# Generated at 2022-06-17 14:55:00.662992
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m    '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m    '

# Generated at 2022-06-17 14:55:09.492444
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'blue', wrap_nonvisible_chars=True) == u'\001\033[34m\002foo\001\033[0m\002'
    assert stringc('foo', 'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc('foo', 'color1', wrap_nonvisible_chars=True) == u'\001\033[38;5;1m\002foo\001\033[0m\002'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'

# Generated at 2022-06-17 14:55:24.823909
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"

# Generated at 2022-06-17 14:55:35.872535
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '

# Generated at 2022-06-17 14:55:41.055094
# Unit test for function colorize
def test_colorize():
    # Test with ANSIBLE_COLOR = True
    ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0 '
    assert colorize('failed', 0, 'red') == 'failed=0     '
    assert colorize('ok', 1, 'green') == '\x1b[32mok=1   \x1b[0m'
    assert colorize('changed', 2, 'yellow') == '\x1b[33mchanged=2   \x1b[0m'

# Generated at 2022-06-17 14:55:45.940881
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 14:55:54.120738
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                 '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '

# Generated at 2022-06-17 14:56:01.650424
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'30'
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('default') == u'39'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'

# Generated at 2022-06-17 14:56:06.914918
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:56:15.718093
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;3mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray7') == u'\033[38;5;249mfoo\033[0m'

# Generated at 2022-06-17 14:56:26.367940
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"test", u"blue") == u"\033[34mtest\033[0m"
    assert stringc(u"test", u"rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc(u"test", u"rgb000255000") == u"\033[38;5;10mtest\033[0m"
    assert stringc(u"test", u"rgb255000255") == u"\033[38;5;13mtest\033[0m"
    assert stringc(u"test", u"rgb255255000") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 14:56:34.604239
# Unit test for function stringc
def test_stringc():
    # Test foreground colors
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-17 14:56:43.363353
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello World", "red"))
    print(stringc("Hello World", "blue"))
    print(stringc("Hello World", "green"))
    print(stringc("Hello World", "yellow"))
    print(stringc("Hello World", "magenta"))
    print(stringc("Hello World", "cyan"))
    print(stringc("Hello World", "white"))
    print(stringc("Hello World", "black"))
    print(stringc("Hello World", "color1"))
    print(stringc("Hello World", "color2"))
    print(stringc("Hello World", "color3"))
    print(stringc("Hello World", "color4"))
    print(stringc("Hello World", "color5"))
    print(stringc("Hello World", "color6"))

# Generated at 2022-06-17 14:56:54.449383
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '

# --- end "pretty"

# Generated at 2022-06-17 14:57:03.483149
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:57:13.680925
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'\x1b[32mlocalhost               \x1b[0m'

# Generated at 2022-06-17 14:57:24.633847
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:57:33.644933
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                    "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;32mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m          "

# Generated at 2022-06-17 14:57:45.640823
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == '\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == '\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == '\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:57:56.562465
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host                 '
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host                 '
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host                 '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host                 '
    assert hostcolor('host', dict(failures=1, unreachable=1, changed=1)) == u'host                 '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), color=False) == u'host                 '

# Generated at 2022-06-17 14:58:06.525381
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '



# Generated at 2022-06-17 14:58:14.310671
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;3mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb255255255') == u'\033[38;5;15mfoo\033[0m'
    assert stringc('foo', 'rgb000') == u'\033[38;5;16mfoo\033[0m'
    assert stringc('foo', 'rgb000000') == u'\033[38;5;16mfoo\033[0m'

# Generated at 2022-06-17 14:58:34.110425
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=True) == u'\x1b[0;32mlocalhost\x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), color=True) == u'\x1b[0;33mlocalhost\x1b[0m'
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), color=True) == u'\x1b[0;31mlocalhost\x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), color=True) == u'\x1b[0;31mlocalhost\x1b[0m'

# Generated at 2022-06-17 14:58:42.908531
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'black') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 3, 'cyan') == 'foo=3   '
    assert colorize('foo', 4, 'green') == 'foo=4   '
    assert colorize('foo', 5, 'magenta') == 'foo=5   '
    assert colorize('foo', 6, 'red') == 'foo=6   '
    assert colorize('foo', 7, 'white') == 'foo=7   '

# Generated at 2022-06-17 14:58:51.148980
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc(u"foo", u"color2") == u"\033[38;5;2mfoo\033[0m"
    assert stringc(u"foo", u"color3") == u"\033[38;5;3mfoo\033[0m"

# Generated at 2022-06-17 14:59:02.853823
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:59:10.987527
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost               "



# Generated at 2022-06-17 14:59:17.751540
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 14:59:30.005291
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:59:40.613101
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 14:59:44.460832
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 42, None)
    'foo=42  '
    """



# Generated at 2022-06-17 14:59:54.359604
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:00:14.662593
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 15:00:21.477562
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), color=True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), color=True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), color=True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 15:00:30.480835
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u'foo                           '
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mfoo\x1b[0m                     '
    assert hostcolor('foo', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mfoo\x1b[0m                     '
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mfoo\x1b[0m                     '

# Generated at 2022-06-17 15:00:40.305636
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 15:00:50.259219
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == "\033[33mfoo\033[0m"
    assert stringc("foo", "black") == "\033[30mfoo\033[0m"
    assert stringc("foo", "white") == "\033[37mfoo\033[0m"
    assert stringc("foo", "color1") == "\033[38;5;1mfoo\033[0m"

# Generated at 2022-06-17 15:00:59.827213
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb255000') == u'38;5;196'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('gray8') == u'38;5;240'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray23') == u'38;5;255'
    assert parsecolor('gray24') == u'38;5;255'
    assert parsecolor('gray25') == u'38;5;255'

# Generated at 2022-06-17 15:01:05.797063
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;3mtest\033[0m"

# Generated at 2022-06-17 15:01:17.687099
# Unit test for function stringc
def test_stringc():
    # Test foreground colors
    assert stringc("black", "black") == u"\033[30mblack\033[0m"
    assert stringc("red", "red") == u"\033[31mred\033[0m"
    assert stringc("green", "green") == u"\033[32mgreen\033[0m"
    assert stringc("yellow", "yellow") == u"\033[33myellow\033[0m"
    assert stringc("blue", "blue") == u"\033[34mblue\033[0m"
    assert stringc("magenta", "magenta") == u"\033[35mmagenta\033[0m"
    assert stringc("cyan", "cyan") == u"\033[36mcyan\033[0m"
    assert string

# Generated at 2022-06-17 15:01:24.328631
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 15:01:34.270241
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"

# Generated at 2022-06-17 15:02:02.083019
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u'foo                           '
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mfoo\x1b[0m                    '
    assert hostcolor('foo', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mfoo\x1b[0m                    '
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mfoo\x1b[0m                    '
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0), color=False) == u'foo                           '
   

# Generated at 2022-06-17 15:02:08.974839
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '

# --- end "pretty"



# Generated at 2022-06-17 15:02:20.704106
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 15:02:26.868929
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 15:02:36.152326
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 15:02:47.507190
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'
    assert stringc

# Generated at 2022-06-17 15:02:54.313842
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 15:03:02.899408
# Unit test for function colorize
def test_colorize():
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0   '
    assert colorize('rescued', 0, 'magenta') == 'rescued=0   '
    assert colorize('ignored', 0, 'blue') == 'ignored=0   '



# Generated at 2022-06-17 15:03:08.743354
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(changed=0, failures=0, unreachable=0)) == u"localhost                "
    assert hostcolor('localhost', dict(changed=0, failures=0, unreachable=1)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(changed=1, failures=0, unreachable=0)) == u"\x1b[33mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(changed=0, failures=1, unreachable=0)) == u"\x1b[31mlocalhost\x1b[0m          "

# Generated at 2022-06-17 15:03:19.421511
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u'%-37s' % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
   