

# Generated at 2022-06-17 14:53:48.692278
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:53:55.949217
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-17 14:54:05.718450
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:54:14.470597
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('black') == '30'
    assert parsecolor('white') == '37'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color9') == '38;5;9'
    assert parsecolor('color10') == '38;5;10'
    assert parsecolor('color15') == '38;5;15'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb000') == '38;5;16'
    assert parsecolor('rgb001') == '38;5;17'

# Generated at 2022-06-17 14:54:22.457820
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "

# --- end "pretty"



# Generated at 2022-06-17 14:54:33.703779
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# Generated at 2022-06-17 14:54:40.301307
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:54:50.724265
# Unit test for function colorize
def test_colorize():
    # Test colorize function
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 10, 'blue') == u'foo=10  '
    assert colorize('foo', 100, 'blue') == u'foo=100 '
    assert colorize('foo', 1000, 'blue') == u'foo=1000'
    assert colorize('foo', 10000, 'blue') == u'foo=10000'
    assert colorize('foo', 100000, 'blue') == u'foo=100000'
    assert colorize('foo', 1000000, 'blue') == u'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == u'foo=10000000'
    assert color

# Generated at 2022-06-17 14:55:02.480386
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 42, None)
    'foo=42  '
    """

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for terminals.
# Copyright (C) 2012  Robey Pointer <robeypointer@gmail.com>
#
# This file is part of terminal.
#
# terminal is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# terminal is distributed in

# Generated at 2022-06-17 14:55:10.656911
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"

# Generated at 2022-06-17 14:55:24.042721
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '



# Generated at 2022-06-17 14:55:27.481915
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 42, None)
    'foo=42  '
    """


# Generated at 2022-06-17 14:55:35.044833
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '



# Generated at 2022-06-17 14:55:42.258528
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", True) == u"\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:55:51.450008
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}, True) == u"%-37s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}, True) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}, True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}, True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:56:00.279548
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"%-37s" % 'localhost'
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u"%-37s" % stringc

# Generated at 2022-06-17 14:56:08.657030
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor('localhost', stats) == 'localhost               '
    stats['failures'] = 1
    assert hostcolor('localhost', stats) == '\x1b[31mlocalhost\x1b[0m         '
    stats['failures'] = 0
    stats['unreachable'] = 1
    assert hostcolor('localhost', stats) == '\x1b[31mlocalhost\x1b[0m         '
    stats['unreachable'] = 0
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == '\x1b[33mlocalhost\x1b[0m         '
    stats['changed'] = 0

# Generated at 2022-06-17 14:56:17.245655
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:56:28.282060
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-17 14:56:35.685897
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:56:55.959234
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"

# Generated at 2022-06-17 14:57:05.548450
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert stringc("foo\nbar", "blue") == u"\033[34mfoo\nbar\033[0m"
    assert stringc("foo\nbar", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\nbar\001\033[0m\002"
    assert stringc("foo", "color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == u

# Generated at 2022-06-17 14:57:14.585030
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;3mtest\033[0m"

# Generated at 2022-06-17 14:57:25.525258
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'


# Generated at 2022-06-17 14:57:36.615689
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert par

# Generated at 2022-06-17 14:57:46.733831
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"


# Generated at 2022-06-17 14:57:57.753351
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:58:08.644322
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), True) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)

# Generated at 2022-06-17 14:58:16.418753
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host'

# --- end "pretty"



# Generated at 2022-06-17 14:58:25.483361
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 10, 'blue') == u'foo=10  '
    assert colorize('foo', 100, 'blue') == u'foo=100 '
    assert colorize('foo', 1000, 'blue') == u'foo=1000'
    assert colorize('foo', 10000, 'blue') == u'foo=10000'
    assert colorize('foo', 100000, 'blue') == u'foo=100000'
    assert colorize('foo', 1000000, 'blue') == u'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == u'foo=10000000'

# Generated at 2022-06-17 14:58:47.518515
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize("foo", 42, "blue")
    'foo=42  '
    >>> colorize("foo", 42, None)
    'foo=42  '
    >>> colorize("foo", 0, "blue")
    'foo=0   '
    >>> colorize("foo", 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 14:58:58.208755
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color on
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('localhost', stats, True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=0, changed=1)

# Generated at 2022-06-17 14:59:04.061944
# Unit test for function colorize
def test_colorize():
    assert colorize(u"foo", 0, u"blue") == u"foo=0   "
    assert colorize(u"foo", 1, u"blue") == u"\033[94mfoo=1   \033[0m"
    assert colorize(u"foo", 2, u"blue") == u"\033[94mfoo=2   \033[0m"
    assert colorize(u"foo", 3, u"blue") == u"\033[94mfoo=3   \033[0m"
    assert colorize(u"foo", 4, u"blue") == u"\033[94mfoo=4   \033[0m"
    assert colorize(u"foo", 5, u"blue") == u"\033[94mfoo=5   \033[0m"

# Generated at 2022-06-17 14:59:14.782552
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb000255000') == u'38;5;2'
    assert parsecolor('rgb255000000') == u'38;5;9'
    assert parsecolor('rgb000') == u'38;5;0'
    assert parsecolor('rgb255') == u'38;5;15'
    assert parsecolor('rgb000255') == u'38;5;2'
    assert parsecolor('rgb255000') == u'38;5;9'

# Generated at 2022-06-17 14:59:22.258267
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats) == u'localhost               '
    stats['failures'] = 1
    assert hostcolor('localhost', stats) == u'\033[31mlocalhost\033[0m         '
    stats['failures'] = 0
    stats['unreachable'] = 1
    assert hostcolor('localhost', stats) == u'\033[31mlocalhost\033[0m         '
    stats['unreachable'] = 0
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == u'\033[33mlocalhost\033[0m         '
    stats['changed'] = 0
    assert hostcolor('localhost', stats) == u'\033[32mlocalhost\033[0m         '
   

# Generated at 2022-06-17 14:59:32.953727
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host                 '
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host                 '
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host                 '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host                 '
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), color=False) == u'host                 '
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0), color=False) == u'host                 '

# Generated at 2022-06-17 14:59:46.490258
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 10, 'blue') == u'foo=10  '
    assert colorize('foo', 100, 'blue') == u'foo=100 '
    assert colorize('foo', 1000, 'blue') == u'foo=1000'
    assert colorize('foo', 10000, 'blue') == u'foo=10000'
    assert colorize('foo', 100000, 'blue') == u'foo=100000'
    assert colorize('foo', 1000000, 'blue') == u'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == u'foo=10000000'

# Generated at 2022-06-17 14:59:50.746814
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color on
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, True) == u"%-37s" % stringc('localhost', C.COLOR_OK)
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('localhost', stats, True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=0, changed=1)

# Generated at 2022-06-17 14:59:58.569418
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m           "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m           "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m           "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), color=False) == u"localhost                "


# Generated at 2022-06-17 15:00:08.254741
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002test\001\033[0m\002"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb123") == u"\033[38;5;33mtest\033[0m"

# Generated at 2022-06-17 15:00:34.007467
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'%-37s' % stringc

# Generated at 2022-06-17 15:00:45.542183
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == 'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == '\x1b[31mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == '\x1b[31mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == '\x1b[33mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == 'localhost                    '

# Generated at 2022-06-17 15:00:53.174802
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 12, 'blue') == u'foo=12  '
    assert colorize('foo', 123, 'blue') == u'foo=123 '
    assert colorize('foo', 1234, 'blue') == u'foo=1234'
    assert colorize('foo', 12345, 'blue') == u'foo=12345'



# Generated at 2022-06-17 15:01:01.570210
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 15:01:10.559439
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-17 15:01:19.174629
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                 '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '

# --- end "pretty"

# Generated at 2022-06-17 15:01:30.445452
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello", "red"))
    print(stringc("Hello", "blue"))
    print(stringc("Hello", "green"))
    print(stringc("Hello", "yellow"))
    print(stringc("Hello", "magenta"))
    print(stringc("Hello", "cyan"))
    print(stringc("Hello", "white"))
    print(stringc("Hello", "black"))
    print(stringc("Hello", "color1"))
    print(stringc("Hello", "color2"))
    print(stringc("Hello", "color3"))
    print(stringc("Hello", "color4"))
    print(stringc("Hello", "color5"))
    print(stringc("Hello", "color6"))
    print(stringc("Hello", "color7"))

# Generated at 2022-06-17 15:01:39.776168
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % host
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 15:01:49.433923
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'purple') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:01:59.843938
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    # Test foreground colors
    assert stringc('test', 'black') == u'\033[30mtest\033[0m'
    assert stringc('test', 'red') == u'\033[31mtest\033[0m'
    assert stringc('test', 'green') == u'\033[32mtest\033[0m'
    assert stringc('test', 'yellow') == u'\033[33mtest\033[0m'
    assert stringc('test', 'blue') == u'\033[34mtest\033[0m'
    assert stringc('test', 'magenta') == u'\033[35mtest\033[0m'
    assert stringc('test', 'cyan') == u'\033[36mtest\033[0m'


# Generated at 2022-06-17 15:02:46.375579
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;10mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"
    assert stringc("test", "rgb000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb111") == u"\033[38;5;7mtest\033[0m"

# Generated at 2022-06-17 15:02:53.983011
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"%-37s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for

# Generated at 2022-06-17 15:03:04.407303
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:03:09.424498
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "

# --- end "pretty"



# Generated at 2022-06-17 15:03:19.678925
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    # Test foreground colors
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'


# Generated at 2022-06-17 15:03:32.411965
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 15:03:39.981086
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize("foo", 42, "blue")
    'foo=42  '
    >>> colorize("foo", 42, None)
    'foo=42  '
    >>> colorize("foo", 0, "blue")
    'foo=0   '
    >>> colorize("foo", 0, None)
    'foo=0   '
    """
