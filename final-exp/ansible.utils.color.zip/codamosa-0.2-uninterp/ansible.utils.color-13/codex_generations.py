

# Generated at 2022-06-17 14:53:48.693006
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 14:53:55.353265
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('blue') == '34'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'

# --- end "pretty"

# Generated at 2022-06-17 14:54:05.191733
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:54:14.052712
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'blue') == u"\033[34mfoo\033[0m"
    assert stringc('foo', 'color1') == u"\033[38;5;1mfoo\033[0m"
    assert stringc('foo', 'rgb255') == u"\033[38;5;231mfoo\033[0m"
    assert stringc('foo', 'rgb255255255') == u"\033[38;5;231mfoo\033[0m"
    assert stringc('foo', 'rgb000') == u"\033[38;5;16mfoo\033[0m"

# Generated at 2022-06-17 14:54:25.068749
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == u"\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255255000") == u"\033[38;5;11mfoo\033[0m"
    assert stringc("foo", "rgb255000000") == u"\033[38;5;9mfoo\033[0m"

# Generated at 2022-06-17 14:54:35.460612
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color99') == u'38;5;99'
    assert parsecolor('rgb123') == u'38;5;123'
    assert parsecolor('rgb321') == u'38;5;201'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'

# Generated at 2022-06-17 14:54:41.367730
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u"\033[31mfoo\033[0m"
    assert stringc('foo', 'blue') == u"\033[34mfoo\033[0m"
    assert stringc('foo', 'green') == u"\033[32mfoo\033[0m"
    assert stringc('foo', 'yellow') == u"\033[33mfoo\033[0m"
    assert stringc('foo', 'magenta') == u"\033[35mfoo\033[0m"
    assert stringc('foo', 'cyan') == u"\033[36mfoo\033[0m"
    assert stringc('foo', 'white') == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 14:54:51.043997
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:55:02.768009
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost               '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[33mlocalhost\x1b[0m        '

# Generated at 2022-06-17 14:55:06.819343
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 14:55:22.629922
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:55:33.313196
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:55:41.550753
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 12, 'blue') == 'foo=12  '
    assert colorize('foo', 123, 'blue') == 'foo=123 '
    assert colorize('foo', 1234, 'blue') == 'foo=1234'
    assert colorize('foo', 12345, 'blue') == 'foo=12345'
    assert colorize('foo', 123456, 'blue') == 'foo=123456'
    assert colorize('foo', 1234567, 'blue') == 'foo=1234567'
    assert colorize('foo', 12345678, 'blue') == 'foo=12345678'

# Generated at 2022-06-17 14:55:50.953160
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 14:55:59.946851
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    stats = dict(failures=1, unreachable=0, changed=0)
    assert hostcolor('localhost', stats, color=True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=1, changed=0)
    assert hostcolor('localhost', stats, color=True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    stats = dict(failures=0, unreachable=0, changed=1)
    assert hostcolor('localhost', stats, color=True) == u'%-37s'

# Generated at 2022-06-17 14:56:08.599236
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:56:16.111997
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 12, 'blue') == 'foo=12  '
    assert colorize('foo', 123, 'blue') == 'foo=123 '
    assert colorize('foo', 1234, 'blue') == 'foo=1234'
    assert colorize('foo', 12345, 'blue') == 'foo=12345'


# Generated at 2022-06-17 14:56:26.732528
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:56:35.136952
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=0)) == u'foo                          '
    assert hostcolor('foo', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mfoo\x1b[0m                  '
    assert hostcolor('foo', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mfoo\x1b[0m                  '
    assert hostcolor('foo', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mfoo\x1b[0m                  '

# Generated at 2022-06-17 14:56:48.046797
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello World", "green"))
    print(stringc("Hello World", "red"))
    print(stringc("Hello World", "blue"))
    print(stringc("Hello World", "yellow"))
    print(stringc("Hello World", "magenta"))
    print(stringc("Hello World", "cyan"))
    print(stringc("Hello World", "white"))
    print(stringc("Hello World", "black"))
    print(stringc("Hello World", "color1"))
    print(stringc("Hello World", "color2"))
    print(stringc("Hello World", "color3"))
    print(stringc("Hello World", "color4"))
    print(stringc("Hello World", "color5"))
    print(stringc("Hello World", "color6"))

# Generated at 2022-06-17 14:57:01.969430
# Unit test for function colorize
def test_colorize():
    # Test colorize function
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0 '
    assert colorize('failed', 0, 'red') == 'failed=0     '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0    '

    # Test colorize function with color off
    ANSIBLE_COLOR = False
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0 '
    assert colorize

# Generated at 2022-06-17 14:57:12.664605
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;32mlocalhost          \x1b[0m"
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost          \x1b[0m"
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost          \x1b[0m"

# Generated at 2022-06-17 14:57:17.365472
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    """


# Generated at 2022-06-17 14:57:27.487300
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == "\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == "\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == "\033[36mfoo\033[0m"
    assert stringc("foo", "white") == "\033[37mfoo\033[0m"
    assert stringc("foo", "black") == "\033[30mfoo\033[0m"

# Generated at 2022-06-17 14:57:37.239784
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '

# --- end "pretty"

# --- begin "termcap"
#
# termcap - A tiny library that provides a Python interface to the


# Generated at 2022-06-17 14:57:46.925126
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=0)) == u'host1                 '
    assert hostcolor('host2', dict(failures=1, unreachable=0, changed=0)) == u'host2                 '
    assert hostcolor('host3', dict(failures=0, unreachable=1, changed=0)) == u'host3                 '
    assert hostcolor('host4', dict(failures=0, unreachable=0, changed=1)) == u'host4                 '
    assert hostcolor('host5', dict(failures=1, unreachable=1, changed=1)) == u'host5                 '
    assert hostcolor('host6', dict(failures=0, unreachable=0, changed=0), color=False) == u'host6                 '
    assert host

# Generated at 2022-06-17 14:57:53.440291
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """



# Generated at 2022-06-17 14:58:02.809278
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "purple") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 14:58:12.030894
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:58:20.855529
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'host                 '
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'host                 '
    assert hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'host                 '
    assert hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'host                 '

# --- end "pretty"



# Generated at 2022-06-17 14:58:30.629272
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"%-37s" % "localhost"
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)

# --- end "pretty"

# Generated at 2022-06-17 14:58:40.951453
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m       '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m       '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m       '

# --- end "pretty"

# --- begin "termcap"
#
# termcap - A simple library for accessing the termcap database.


# Generated at 2022-06-17 14:58:50.482813
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:59:02.731021
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc(u"foo", u"rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc(u"foo", u"rgb000255000") == u"\033[38;5;2mfoo\033[0m"
    assert stringc(u"foo", u"rgb255255000") == u"\033[38;5;3mfoo\033[0m"
    assert stringc(u"foo", u"rgb255000000")

# Generated at 2022-06-17 14:59:13.910659
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:59:19.807226
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc('foo', 'color1', wrap_nonvisible_chars=True) == u'\001\033[38;5;1m\002foo\001\033[0m\002'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb255', wrap_nonvisible_chars=True) == u'\001\033[38;5;231m\002foo\001\033[0m\002'

# Generated at 2022-06-17 14:59:32.840055
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:59:46.456652
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                  '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '

# Generated at 2022-06-17 14:59:56.207276
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 15:00:07.386122
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                    "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;34mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m          "

# Generated at 2022-06-17 15:00:20.996295
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'



# Generated at 2022-06-17 15:00:30.315846
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"


# Generated at 2022-06-17 15:00:40.272478
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"test", u"blue") == u"\033[34mtest\033[0m"
    assert stringc(u"test", u"color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc(u"test", u"rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc(u"test", u"rgb000") == u"\033[38;5;16mtest\033[0m"
    assert stringc(u"test", u"rgb123") == u"\033[38;5;36mtest\033[0m"

# Generated at 2022-06-17 15:00:48.687751
# Unit test for function colorize
def test_colorize():
    print(colorize(u"foo", 0, u'blue'))
    print(colorize(u"foo", 1, u'blue'))
    print(colorize(u"foo", 2, u'blue'))
    print(colorize(u"foo", 3, u'blue'))
    print(colorize(u"foo", 4, u'blue'))
    print(colorize(u"foo", 5, u'blue'))
    print(colorize(u"foo", 6, u'blue'))
    print(colorize(u"foo", 7, u'blue'))
    print(colorize(u"foo", 8, u'blue'))
    print(colorize(u"foo", 9, u'blue'))
    print(colorize(u"foo", 10, u'blue'))
   

# Generated at 2022-06-17 15:00:58.077167
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"

# Generated at 2022-06-17 15:01:08.813011
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "black") == "\033[30mfoo\033[0m"
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == "\033[33mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "magenta") == "\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == "\033[36mfoo\033[0m"

# Generated at 2022-06-17 15:01:18.866366
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "

# --- end "pretty"

# --- begin "terminal"

# terminal - A library for colorizing output for terminals
#
#   (C) 2005-2008  Igor Guerrero <igfgt1@gmail.com>
#
#   This program is free software; you can redistribute it and/or modify
#   it under the

# Generated at 2022-06-17 15:01:27.067280
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb000") == u"\033[38;5;16mtest\033[0m"
    assert stringc("test", "rgb123") == u"\033[38;5;21mtest\033[0m"
    assert stringc("test", "rgb333") == u"\033[38;5;59mtest\033[0m"
    assert stringc("test", "rgb555") == u"\033[38;5;95mtest\033[0m"
    assert stringc

# Generated at 2022-06-17 15:01:38.111104
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 15:01:48.120289
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "color1") == "\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == "\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == "\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255255000") == "\033[38;5;3mfoo\033[0m"
    assert stringc("foo", "rgb255000000") == "\033[38;5;1mfoo\033[0m"

# Generated at 2022-06-17 15:02:10.921696
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == '\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == '\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == '\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:02:22.380419
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# --- end "pretty"



# Generated at 2022-06-17 15:02:33.075886
# Unit test for function colorize
def test_colorize():
    # ANSIBLE_COLOR is True
    ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == u'ok=0   '
    assert colorize('changed', 0, 'yellow') == u'changed=0   '
    assert colorize('unreachable', 0, 'red') == u'unreachable=0   '
    assert colorize('failed', 0, 'red') == u'failed=0   '
    assert colorize('ok', 1, 'green') == u'\033[32mok=1   \033[0m'
    assert colorize('changed', 1, 'yellow') == u'\033[33mchanged=1   \033[0m'

# Generated at 2022-06-17 15:02:46.152479
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"



# Generated at 2022-06-17 15:02:56.987250
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 15:03:05.985055
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), color=False) == u"localhost                "


# Generated at 2022-06-17 15:03:17.486336
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:03:22.660647
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('rgb333') == u'38;5;231'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray8') == u'38;5;240'
    assert parsecolor('gray9') == u'38;5;241'
    assert parsecolor('gray10') == u'38;5;242'
    assert parsecolor('gray11') == u'38;5;243'
    assert parsecolor('gray12') == u'38;5;244'

# Generated at 2022-06-17 15:03:35.039870
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost               "

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for terminals
# Copyright (C) 2012  Daniele Varrazzo
#
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
