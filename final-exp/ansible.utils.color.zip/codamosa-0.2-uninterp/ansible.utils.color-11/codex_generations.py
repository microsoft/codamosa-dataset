

# Generated at 2022-06-17 14:53:47.805075
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor("red") == '31'
    assert parsecolor("green") == '32'
    assert parsecolor("blue") == '34'
    assert parsecolor("cyan") == '36'
    assert parsecolor("magenta") == '35'
    assert parsecolor("yellow") == '33'
    assert parsecolor("white") == '37'
    assert parsecolor("black") == '30'
    assert parsecolor("color1") == '38;5;1'
    assert parsecolor("color2") == '38;5;2'
    assert parsecolor("color3") == '38;5;3'
    assert parsecolor("color4") == '38;5;4'
    assert parsecolor("color5") == '38;5;5'
    assert par

# Generated at 2022-06-17 14:53:55.734967
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:54:00.041110
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 42, None)
    'foo=42  '
    """


# Generated at 2022-06-17 14:54:09.075021
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == u"%-26s" % host
    stats = {'failures': 1, 'changed': 0, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'changed': 1, 'ok': 0, 'skipped': 0, 'unreachable': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_CHANGED)

# Generated at 2022-06-17 14:54:17.378844
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb255000') == '38;5;196'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('gray23') == '38;5;255'
    assert parsecolor('gray24') == '38;5;255'
    assert parsecolor('gray25') == '38;5;255'
    assert parsecolor('gray26') == '38;5;255'
    assert parsecolor('gray27') == '38;5;255'
    assert parsecolor('gray28') == '38;5;255'
    assert parsec

# Generated at 2022-06-17 14:54:26.232297
# Unit test for function stringc
def test_stringc():
    assert stringc('test', 'red') == u'\033[31mtest\033[0m'
    assert stringc('test', 'blue') == u'\033[34mtest\033[0m'
    assert stringc('test', 'color1') == u'\033[38;5;1mtest\033[0m'
    assert stringc('test', 'color2') == u'\033[38;5;2mtest\033[0m'
    assert stringc('test', 'color3') == u'\033[38;5;3mtest\033[0m'
    assert stringc('test', 'color4') == u'\033[38;5;4mtest\033[0m'

# Generated at 2022-06-17 14:54:36.184908
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:54:41.716067
# Unit test for function colorize
def test_colorize():
    # Test with ANSIBLE_COLOR=False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize(u'ok', 0, C.COLOR_OK) == u'ok=0   '
    assert colorize(u'changed', 0, C.COLOR_CHANGED) == u'changed=0   '
    assert colorize(u'unreachable', 0, C.COLOR_UNREACHABLE) == u'unreachable=0   '
    assert colorize(u'failed', 0, C.COLOR_ERROR) == u'failed=0   '
    assert colorize(u'ok', 1, C.COLOR_OK) == u'ok=1   '
    assert colorize(u'changed', 2, C.COLOR_CHANGED) == u'changed=2   '
    assert color

# Generated at 2022-06-17 14:54:51.472419
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color10') == u'38;5;10'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('rgb333') == u'38;5;63'
    assert parsecolor('rgb555') == u'38;5;231'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('gray8') == u'38;5;239'

# Generated at 2022-06-17 14:55:03.236740
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', dict(failures=0, unreachable=0, changed=0)) == u'host1                 '
    assert hostcolor('host2', dict(failures=1, unreachable=0, changed=0)) == u'host2                 '
    assert hostcolor('host3', dict(failures=0, unreachable=1, changed=0)) == u'host3                 '
    assert hostcolor('host4', dict(failures=0, unreachable=0, changed=1)) == u'host4                 '
    assert hostcolor('host5', dict(failures=1, unreachable=1, changed=1)) == u'host5                 '

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for terminals.
# Copyright (C) 2012 

# Generated at 2022-06-17 14:55:13.334994
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:55:17.026071
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize("foo", 42, "blue")
    'foo=42  '
    >>> colorize("foo", 42, None)
    'foo=42  '
    """


# Generated at 2022-06-17 14:55:27.093478
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 14:55:37.457045
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '

# Generated at 2022-06-17 14:55:49.015669
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                 '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), False) == u'localhost                 '

# Generated at 2022-06-17 14:55:58.663353
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "green") == "\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == "\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == "\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == "\033[36mfoo\033[0m"
    assert stringc("foo", "white") == "\033[37mfoo\033[0m"
    assert stringc("foo", "black") == "\033[30mfoo\033[0m"

# Generated at 2022-06-17 14:56:07.306746
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u"host                          "
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u"host                          "
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u"host                          "
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u"host                          "
    assert hostcolor('host', dict(failures=1, unreachable=1, changed=1)) == u"host                          "

# --- end "pretty"



# Generated at 2022-06-17 14:56:16.073824
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"


# Generated at 2022-06-17 14:56:26.730976
# Unit test for function colorize
def test_colorize():
    # Test with ANSIBLE_COLOR=False
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 1, 'yellow') == 'changed=1 '
    assert colorize('unreachable', 2, 'red') == 'unreachable=2  '
    assert colorize('failed', 3, 'red') == 'failed=3  '
    ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 1, 'yellow') == '\x1b[33mchanged=1 \x1b[0m'

# Generated at 2022-06-17 14:56:31.035692
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('blue') == u'34'


# Generated at 2022-06-17 14:56:46.053302
# Unit test for function colorize
def test_colorize():
    """Unit test for function colorize"""
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0'
    assert colorize('failed', 0, 'red') == 'failed=0    '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0   '
    assert colorize('rescued', 0, 'magenta') == 'rescued=0   '
    assert colorize('ignored', 0, 'blue') == 'ignored=0   '



# Generated at 2022-06-17 14:56:56.024154
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 14:57:04.249567
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 14:57:14.141625
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 14:57:25.193701
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:57:35.279061
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    >>> colorize('foo', 1, 'blue')
    'foo=1   '
    >>> colorize('foo', 2, 'blue')
    'foo=2   '
    >>> colorize('foo', 12, 'blue')
    'foo=12  '
    >>> colorize('foo', 512, 'blue')
    'foo=512 '
    >>> colorize('foo', 4096, 'blue')
    'foo=4096'
    """
    pass

# --- end "pretty"



# Generated at 2022-06-17 14:57:46.240545
# Unit test for function colorize
def test_colorize():
    # Set ANSIBLE_COLOR to True for the test
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # Test colorize()
    assert colorize("foo", 0, "blue") == u"foo=0   "
    assert colorize("foo", 0, None) == u"foo=0   "
    assert colorize("foo", 1, "blue") == u"\033[94mfoo=1   \033[0m"
    assert colorize("foo", 2, "blue") == u"\033[94mfoo=2   \033[0m"
    assert colorize("foo", 3, "blue") == u"\033[94mfoo=3   \033[0m"

# Generated at 2022-06-17 14:57:57.174456
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                     '


# Generated at 2022-06-17 14:58:01.089515
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost                '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[0;32mlocalhost         \x1b[0m'
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[0;31mlocalhost         \x1b[0m'
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[0;31mlocalhost         \x1b[0m'

# Generated at 2022-06-17 14:58:09.014525
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=1, changed=1)) == u'host'

# --- end of "pretty"



# Generated at 2022-06-17 14:58:23.328933
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, "blue") == "foo=0   "
    assert colorize("foo", 0, None) == "foo=0   "
    assert colorize("foo", 1, "blue") == stringc("foo=1   ", "blue")
    assert colorize("foo", 2, "blue") == stringc("foo=2   ", "blue")
    assert colorize("foo", 3, "blue") == stringc("foo=3   ", "blue")
    assert colorize("foo", 4, "blue") == stringc("foo=4   ", "blue")
    assert colorize("foo", 5, "blue") == stringc("foo=5   ", "blue")
    assert colorize("foo", 6, "blue") == stringc("foo=6   ", "blue")

# Generated at 2022-06-17 14:58:32.184529
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'


# Generated at 2022-06-17 14:58:45.783404
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "color1") == u"\033[38;5;1mtext\033[0m"
    assert stringc("text", "rgb255255255") == u"\033[38;5;15mtext\033[0m"
    assert stringc("text", "rgb000255000") == u"\033[38;5;2mtext\033[0m"
    assert stringc("text", "rgb255000000") == u"\033[38;5;9mtext\033[0m"
    assert stringc("text", "rgb255255000") == u"\033[38;5;11mtext\033[0m"

# Generated at 2022-06-17 14:58:52.441392
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'

# Generated at 2022-06-17 14:59:00.639572
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u"host                 "
    assert hostcolor('host', dict(failures=1, unreachable=1, changed=1)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), color=False) == u"host                 "

# Generated at 2022-06-17 14:59:12.422943
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:59:21.600447
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;3mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray7') == u'\033[38;5;249mfoo\033[0m'

# Generated at 2022-06-17 14:59:32.501251
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '

# --- end "pretty"



# Generated at 2022-06-17 14:59:46.281398
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# --- end "pretty"

# --- begin "termcap"
#
# termcap - A tiny library that provides a termcap-like interface

# Generated at 2022-06-17 14:59:56.060215
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 15:00:09.713390
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"


# Generated at 2022-06-17 15:00:19.040335
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"

# Generated at 2022-06-17 15:00:29.288041
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("text", "red") == u"\033[31mtext\033[0m"
    assert stringc("text", "rgb255255255") == u"\033[38;5;15mtext\033[0m"
    assert stringc("text", "rgb000255000") == u"\033[38;5;2mtext\033[0m"
    assert stringc("text", "rgb255255000") == u"\033[38;5;11mtext\033[0m"
    assert stringc("text", "rgb255000000") == u"\033[38;5;1mtext\033[0m"

# Generated at 2022-06-17 15:00:40.130852
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"%-37s" % stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(failures=1, unreachable=1, changed=1)) == u

# Generated at 2022-06-17 15:00:48.639358
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:00:58.015999
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m    '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m    '

# Generated at 2022-06-17 15:01:08.777571
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert stringc("foo", "color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "color1", wrap_nonvisible_chars=True) == u"\001\033[38;5;1m\002foo\001\033[0m\002"
    assert stringc("foo", "rgb255") == u"\033[38;5;231mfoo\033[0m"

# Generated at 2022-06-17 15:01:18.830152
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '

# Generated at 2022-06-17 15:01:22.782742
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == '\x1b[34mfoo\x1b[0m'
    assert stringc('foo', 'blue', wrap_nonvisible_chars=True) == '\x01\x1b[34m\x02foo\x01\x1b[0m\x02'
    assert stringc('foo\nbar', 'blue') == '\x1b[34mfoo\nbar\x1b[0m'
    assert stringc('foo\nbar', 'blue', wrap_nonvisible_chars=True) == '\x01\x1b[34m\x02foo\nbar\x01\x1b[0m\x02'

# Generated at 2022-06-17 15:01:33.025668
# Unit test for function stringc

# Generated at 2022-06-17 15:01:59.027944
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost                '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[33mlocalhost\x1b[0m         '

# Generated at 2022-06-17 15:02:05.146375
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:02:12.314066
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('test', 'blue') == u'\033[34mtest\033[0m'
    assert stringc('test', 'color3') == u'\033[38;5;51mtest\033[0m'
    assert stringc('test', 'rgb255') == u'\033[38;5;231mtest\033[0m'
    assert stringc('test', 'rgb123') == u'\033[38;5;33mtest\033[0m'
    assert stringc('test', 'gray7') == u'\033[38;5;250mtest\033[0m'
    assert stringc('test', 'gray0') == u'\033[38;5;232mtest\033[0m'

# Generated at 2022-06-17 15:02:23.467895
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:02:34.413655
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=True) == u"%-37s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), color=True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), color=True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), color=True) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 15:02:46.752531
# Unit test for function stringc
def test_stringc():
    """Test function stringc"""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc(u"foo", u"rgb255") == u"\033[38;5;231mfoo\033[0m"
    assert stringc(u"foo", u"rgb111") == u"\033[38;5;18mfoo\033[0m"


# Generated at 2022-06-17 15:02:54.137467
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc(u"foo", u"rgb255") == u"\033[38;5;231mfoo\033[0m"
    assert stringc(u"foo", u"rgb123") == u"\033[38;5;33mfoo\033[0m"

# Generated at 2022-06-17 15:03:04.519681
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;3mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'rgb333') == u'\033[38;5;59mfoo\033[0m'
    assert stringc('foo', 'rgb000') == u'\033[38;5;16mfoo\033[0m'

# Generated at 2022-06-17 15:03:15.246017
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '

# --- end "pretty"

# Generated at 2022-06-17 15:03:22.219779
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                 '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '