

# Generated at 2022-06-17 14:53:47.473736
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"

# Generated at 2022-06-17 14:53:55.463483
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb255255255", wrap_nonvisible_chars=True) == u"\001\033[38;5;15m\002test\001\033[0m\002"
    assert stringc

# Generated at 2022-06-17 14:54:05.268565
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:54:14.130629
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;34mlocalhost\x1b[0m        "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m        "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m        "

# Generated at 2022-06-17 14:54:25.069456
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'black') == 'foo=0   '
    assert colorize('foo', 1, 'black') == 'foo=1   '
    assert colorize('foo', 10, 'black') == 'foo=10  '
    assert colorize('foo', 100, 'black') == 'foo=100 '
    assert colorize('foo', 1000, 'black') == 'foo=1000'
    assert colorize('foo', 0, 'red') == 'foo=0   '
    assert colorize('foo', 1, 'red') == 'foo=1   '
    assert colorize('foo', 10, 'red') == 'foo=10  '
    assert colorize('foo', 100, 'red') == 'foo=100 '
    assert colorize('foo', 1000, 'red') == 'foo=1000'
    assert color

# Generated at 2022-06-17 14:54:35.460723
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m        '

# Generated at 2022-06-17 14:54:39.559922
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:54:49.427074
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb000") == u"\033[38;5;16mtest\033[0m"
    assert stringc("test", "rgb123") == u"\033[38;5;21mtest\033[0m"
    assert stringc("test", "rgb333") == u"\033[38;5;59mtest\033[0m"
    assert stringc("test", "rgb555") == u"\033[38;5;95mtest\033[0m"
    assert stringc

# Generated at 2022-06-17 14:55:00.566424
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb123') == u'38;5;18'
    assert parsecolor('gray1') == u'38;5;233'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('rgb000') == u'38;5;16'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('rgb222') == u'38;5;58'

# Generated at 2022-06-17 14:55:09.390404
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'%-37s' % stringc

# Generated at 2022-06-17 14:55:24.717433
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 14:55:33.770610
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:55:41.686226
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == '\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == '\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == '\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:55:50.459752
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# --- end "pretty"



# Generated at 2022-06-17 14:55:59.773009
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('hello', 'blue') == u'\033[34mhello\033[0m'
    assert stringc('hello', '0') == u'\033[38;5;0mhello\033[0m'
    assert stringc('hello', 'rgb255255255') == u'\033[38;5;15mhello\033[0m'
    assert stringc('hello', 'rgb000255000') == u'\033[38;5;2mhello\033[0m'
    assert stringc('hello', 'rgb255000255') == u'\033[38;5;5mhello\033[0m'

# Generated at 2022-06-17 14:56:07.778174
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '

# --- end "pretty"

# Generated at 2022-06-17 14:56:16.520498
# Unit test for function colorize
def test_colorize():
    # ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0'
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0  '
    assert colorize('rescued', 0, 'magenta') == 'rescued=0  '
    assert colorize('ignored', 0, 'blue') == 'ignored=0  '

    # ANSIBLE_COLOR = False
    ANSIBLE_COLOR = False

# Generated at 2022-06-17 14:56:25.297998
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 12, 'blue') == 'foo=12  '
    assert colorize('foo', 123, 'blue') == 'foo=123 '
    assert colorize('foo', 1234, 'blue') == 'foo=1234'
    assert colorize('foo', 12345, 'blue') == 'foo=12345'


# Generated at 2022-06-17 14:56:33.692839
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), True) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)

# Generated at 2022-06-17 14:56:46.620588
# Unit test for function colorize
def test_colorize():
    print(colorize("foo", 0, "blue"))
    print(colorize("foo", 1, "blue"))
    print(colorize("foo", -1, "blue"))
    print(colorize("foo", 0, "red"))
    print(colorize("foo", 1, "red"))
    print(colorize("foo", -1, "red"))
    print(colorize("foo", 0, "green"))
    print(colorize("foo", 1, "green"))
    print(colorize("foo", -1, "green"))
    print(colorize("foo", 0, "yellow"))
    print(colorize("foo", 1, "yellow"))
    print(colorize("foo", -1, "yellow"))
    print(colorize("foo", 0, "magenta"))

# Generated at 2022-06-17 14:57:03.148234
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"


# Generated at 2022-06-17 14:57:13.433822
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:57:24.246010
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:57:31.249747
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 14:57:39.861571
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u"host                 "
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), color=False) == u"host                 "
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0), color=False) == u"host                 "

# Generated at 2022-06-17 14:57:47.122991
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:57:57.281140
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:58:08.604660
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "color1") == u"\033[38;5;1mtext\033[0m"
    assert stringc("text", "rgb255") == u"\033[38;5;231mtext\033[0m"
    assert stringc("text", "rgb000") == u"\033[38;5;16mtext\033[0m"
    assert stringc("text", "rgb123") == u"\033[38;5;36mtext\033[0m"
    assert stringc("text", "rgb333") == u"\033[38;5;60mtext\033[0m"

# Generated at 2022-06-17 14:58:12.324978
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb255000') == '38;5;196'
    assert parsecolor('gray8') == '38;5;240'
    assert parsecolor('blue') == '34'

# --- end "pretty"

# Generated at 2022-06-17 14:58:23.213999
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:58:33.500157
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '



# Generated at 2022-06-17 14:58:42.512448
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:58:50.923904
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:58:59.616775
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == '\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == '\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == '\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:59:06.576395
# Unit test for function hostcolor
def test_hostcolor():
    stats = dict(failures=0, unreachable=0, changed=0)
    assert hostcolor('localhost', stats) == u'%-37s' % 'localhost'
    stats['failures'] = 1
    assert hostcolor('localhost', stats) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    stats['failures'] = 0
    stats['unreachable'] = 1
    assert hostcolor('localhost', stats) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    stats['unreachable'] = 0
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# --- end "pretty"



# Generated at 2022-06-17 14:59:17.391009
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:59:22.730531
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:59:32.691359
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == '\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == '\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == '\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == '\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == '\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:59:41.654903
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# Generated at 2022-06-17 14:59:52.107914
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 15:00:18.890604
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost               '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[0;32mlocalhost\x1b[0m'
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[0;31mlocalhost\x1b[0m'
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[0;31mlocalhost\x1b[0m'

# Generated at 2022-06-17 15:00:29.289970
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# --- end "pretty"

# --- begin "termdebug"
#
# termdebug - A simple library that provides a Python print and stdout

# Generated at 2022-06-17 15:00:40.131742
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "yellow") == "\033[33mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"
    assert stringc("test", "cyan") == "\033[36mtest\033[0m"
    assert stringc("test", "white") == "\033[37mtest\033[0m"
    assert stringc("test", "color0") == "\033[38;5;0mtest\033[0m"


# Generated at 2022-06-17 15:00:50.181645
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '

# Generated at 2022-06-17 15:00:59.721574
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:01:09.757814
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'blue', wrap_nonvisible_chars=True) == u'\001\033[34m\002foo\001\033[0m\002'
    assert stringc('foo', 'color3') == u'\033[38;5;3mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'rgb333') == u'\033[38;5;59mfoo\033[0m'

# Generated at 2022-06-17 15:01:19.374843
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(changed=0, failures=0, unreachable=0)) == u'localhost               '
    assert hostcolor('localhost', dict(changed=1, failures=0, unreachable=0)) == u'localhost               '
    assert hostcolor('localhost', dict(changed=0, failures=1, unreachable=0)) == u'localhost               '
    assert hostcolor('localhost', dict(changed=0, failures=0, unreachable=1)) == u'localhost               '
    assert hostcolor('localhost', dict(changed=1, failures=1, unreachable=1)) == u'localhost               '
    assert hostcolor('localhost', dict(changed=0, failures=0, unreachable=0), color=False) == u'localhost               '

# Generated at 2022-06-17 15:01:30.777257
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# Generated at 2022-06-17 15:01:39.921201
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 15:01:45.927023
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 15:02:23.779733
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """
    pass


# Generated at 2022-06-17 15:02:34.744349
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;34mlocalhost\x1b[0m      "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m      "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m      "

# Generated at 2022-06-17 15:02:46.866915
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# Generated at 2022-06-17 15:02:54.184085
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), color=False) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0), color=False) == u'host'

# Generated at 2022-06-17 15:03:04.558131
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '

# Generated at 2022-06-17 15:03:16.553640
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 15:03:23.935670
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc('foo', 'rgb255255255') == u'\033[38;5;15mfoo\033[0m'
    assert stringc('foo', 'rgb000255000') == u'\033[38;5;2mfoo\033[0m'
    assert stringc('foo', 'rgb000255255') == u'\033[38;5;6mfoo\033[0m'
    assert stringc('foo', 'rgb255255000') == u'\033[38;5;11mfoo\033[0m'

# Generated at 2022-06-17 15:03:35.323831
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)