

# Generated at 2022-06-17 14:53:48.394189
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;34mlocalhost\x1b[0m        "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m        "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m        "

# Generated at 2022-06-17 14:53:56.007155
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert par

# Generated at 2022-06-17 14:54:05.807554
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'on_red') == u'\033[41mfoo\033[0m'
    assert stringc('foo', 'on_blue') == u'\033[44mfoo\033[0m'
    assert stringc('foo', 'red', wrap_nonvisible_chars=True) == u'\001\033[31m\002foo\001\033[0m\002'
    assert stringc('foo', 'blue', wrap_nonvisible_chars=True) == u'\001\033[34m\002foo\001\033[0m\002'
    assert string

# Generated at 2022-06-17 14:54:14.544926
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == u'foo=0   '
    assert colorize('foo', 1, 'blue') == u'foo=1   '
    assert colorize('foo', 10, 'blue') == u'foo=10  '
    assert colorize('foo', 100, 'blue') == u'foo=100 '
    assert colorize('foo', 1000, 'blue') == u'foo=1000'
    assert colorize('foo', 0, None) == u'foo=0   '
    assert colorize('foo', 1, None) == u'foo=1   '
    assert colorize('foo', 10, None) == u'foo=10  '
    assert colorize('foo', 100, None) == u'foo=100 '

# Generated at 2022-06-17 14:54:25.187047
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "rgb255000") == u"\033[38;5;196mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;34mtest\033[0m"

# Generated at 2022-06-17 14:54:35.562866
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "black") == u"\033[30mfoo\033[0m"
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 14:54:45.361094
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:54:56.203559
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "black") == u"\033[30mfoo\033[0m"
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"

# Generated at 2022-06-17 14:55:06.820500
# Unit test for function colorize
def test_colorize():
    assert colorize("foo", 0, "blue") == "foo=0   "
    assert colorize("foo", 1, "blue") == "foo=1   "
    assert colorize("foo", 10, "blue") == "foo=10  "
    assert colorize("foo", 100, "blue") == "foo=100 "
    assert colorize("foo", 1000, "blue") == "foo=1000"
    assert colorize("foo", 10000, "blue") == "foo=10000"
    assert colorize("foo", 100000, "blue") == "foo=100000"
    assert colorize("foo", 1000000, "blue") == "foo=1000000"
    assert colorize("foo", 10000000, "blue") == "foo=10000000"

# Generated at 2022-06-17 14:55:13.203317
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
   

# Generated at 2022-06-17 14:55:29.373835
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"


# Generated at 2022-06-17 14:55:38.761843
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-37s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'%-37s' % stringc

# Generated at 2022-06-17 14:55:49.716106
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "color1") == u"\033[38;5;1mtext\033[0m"
    assert stringc("text", "rgb255") == u"\033[38;5;231mtext\033[0m"
    assert stringc("text", "rgb123") == u"\033[38;5;33mtext\033[0m"
    assert stringc("text", "gray0") == u"\033[38;5;232mtext\033[0m"
    assert stringc("text", "gray8") == u"\033[38;5;240mtext\033[0m"

# Generated at 2022-06-17 14:55:54.822342
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 14:56:01.863959
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:56:07.072439
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for

# Generated at 2022-06-17 14:56:15.837311
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('test', 'red') == u'\033[31mtest\033[0m'
    assert stringc('test', 'blue') == u'\033[34mtest\033[0m'
    assert stringc('test', 'color1') == u'\033[38;5;1mtest\033[0m'
    assert stringc('test', 'color9') == u'\033[38;5;9mtest\033[0m'
    assert stringc('test', 'color10') == u'\033[38;5;10mtest\033[0m'
    assert stringc('test', 'color11') == u'\033[38;5;11mtest\033[0m'

# Generated at 2022-06-17 14:56:26.504750
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'purple') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:56:30.824184
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('blue') == '34'

# --- end "pretty"



# Generated at 2022-06-17 14:56:34.495120
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 14:56:45.823967
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('test', 'blue') == u'\033[34mtest\033[0m'
    assert stringc('test', 'color3') == u'\033[38;5;51mtest\033[0m'
    assert stringc('test', 'rgb255') == u'\033[38;5;231mtest\033[0m'
    assert stringc('test', 'rgb123') == u'\033[38;5;33mtest\033[0m'
    assert stringc('test', 'gray7') == u'\033[38;5;250mtest\033[0m'
    assert stringc('test', 'gray0') == u'\033[38;5;232mtest\033[0m'

# Generated at 2022-06-17 14:56:55.991587
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 14:57:05.590649
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'\x1b[32mlocalhost               \x1b[0m'

# Generated at 2022-06-17 14:57:14.585061
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'


# Generated at 2022-06-17 14:57:25.526485
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'%-37s' % stringc

# Generated at 2022-06-17 14:57:31.888548
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "color9") == u"\033[38;5;9mfoo\033[0m"
    assert stringc("foo", "color10") == u"\033[38;5;10mfoo\033[0m"
    assert stringc("foo", "color11") == u"\033[38;5;11mfoo\033[0m"

# Generated at 2022-06-17 14:57:45.382688
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '

# Generated at 2022-06-17 14:57:56.303842
# Unit test for function stringc

# Generated at 2022-06-17 14:58:08.360063
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost               '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[0;32mlocalhost\x1b[0m '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[0;31mlocalhost\x1b[0m '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[0;31mlocalhost\x1b[0m '

# Generated at 2022-06-17 14:58:20.056426
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u"%-37s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:58:35.827821
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), True) == u"%-37s" % stringc('host', C.COLOR_OK)
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0), True) == u"%-37s" % stringc('host', C.COLOR_ERROR)
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0), True) == u"%-37s" % stringc('host', C.COLOR_ERROR)
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1), True) == u"%-37s" % stringc('host', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:58:43.637255
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 14:58:54.076937
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m    '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m    '

# Generated at 2022-06-17 14:59:01.218607
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"

# Generated at 2022-06-17 14:59:07.596673
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;34mtest\033[0m"
    assert stringc("test", "rgb255000255") == u"\033[38;5;55mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;11mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;45mtest\033[0m"
    assert string

# Generated at 2022-06-17 14:59:17.656837
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'\x1b[32mlocalhost               \x1b[0m'

# Generated at 2022-06-17 14:59:23.806242
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:59:32.565609
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m      '

# Generated at 2022-06-17 14:59:46.317629
# Unit test for function stringc
def test_stringc():
    print(stringc("This is a test", "blue"))
    print(stringc("This is a test", "rgb255255255"))
    print(stringc("This is a test", "rgb000255000"))
    print(stringc("This is a test", "rgb255000000"))
    print(stringc("This is a test", "rgb255255000"))
    print(stringc("This is a test", "rgb000255255"))
    print(stringc("This is a test", "rgb255000255"))
    print(stringc("This is a test", "rgb255255255"))
    print(stringc("This is a test", "rgb000"))
    print(stringc("This is a test", "rgb111"))
    print(stringc("This is a test", "rgb222"))
   

# Generated at 2022-06-17 14:59:56.102386
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"

# Generated at 2022-06-17 15:00:15.992856
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'


# Generated at 2022-06-17 15:00:25.876761
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '

# --- end "pretty"



# Generated at 2022-06-17 15:00:32.313236
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 15:00:45.017441
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor('localhost', stats) == u"%-37s" % 'localhost'
    stats['failures'] = 1
    assert hostcolor('localhost', stats) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    stats['failures'] = 0
    stats['unreachable'] = 1
    assert hostcolor('localhost', stats) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    stats['unreachable'] = 0
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)
    stats['changed'] = 0

# Generated at 2022-06-17 15:00:51.889601
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host'



# Generated at 2022-06-17 15:01:00.693552
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for colorizing output for terminals.
# Copyright

# Generated at 2022-06-17 15:01:06.290282
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "blue", True) == u"\001\033[34m\002text\001\033[0m\002"
    assert stringc("text", "color10") == u"\033[38;5;10mtext\033[0m"
    assert stringc("text", "rgb255255255") == u"\033[38;5;15mtext\033[0m"
    assert stringc("text", "rgb000255255") == u"\033[38;5;6mtext\033[0m"

# Generated at 2022-06-17 15:01:17.770184
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost               \x1b[0m'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'\x1b[32mlocalhost               \x1b[0m'

# Generated at 2022-06-17 15:01:24.377897
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert stringc("foo", "color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == u"\033[38;5;2mfoo\033[0m"

# Generated at 2022-06-17 15:01:34.305003
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# Generated at 2022-06-17 15:01:57.757901
# Unit test for function stringc

# Generated at 2022-06-17 15:02:07.204126
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)

# Generated at 2022-06-17 15:02:11.868548
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:02:23.331541
# Unit test for function stringc

# Generated at 2022-06-17 15:02:34.283777
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5') == u'38;5;5'
    assert parsecolor('color6') == u'38;5;6'
    assert parsecolor('color7') == u'38;5;7'
    assert parsecolor('color8') == u'38;5;8'


# Generated at 2022-06-17 15:02:44.964403
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=1, changed=1)) == u'host'



# Generated at 2022-06-17 15:02:56.933418
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;10mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;11mtest\033[0m"

# Generated at 2022-06-17 15:02:58.368071
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    """


# Generated at 2022-06-17 15:03:07.010746
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'on_red') == u'\033[41mfoo\033[0m'
    assert stringc('foo', 'on_blue') == u'\033[44mfoo\033[0m'
    assert stringc('foo', 'red,bold') == u'\033[31;1mfoo\033[0m'
    assert stringc('foo', 'red,underline') == u'\033[31;4mfoo\033[0m'

# Generated at 2022-06-17 15:03:18.190661
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb255255255') == '38;5;15'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray23') == '38;5;255'
    assert parsecolor('gray24') == '38;5;255'
    assert parsecolor('gray25') == '38;5;255'
    assert parsecolor('gray26') == '38;5;255'
    assert parsecolor('gray27') == '38;5;255'
    assert parsecolor('gray28') == '38;5;255'
    assert parsecolor('gray29') == '38;5;255'
    assert par