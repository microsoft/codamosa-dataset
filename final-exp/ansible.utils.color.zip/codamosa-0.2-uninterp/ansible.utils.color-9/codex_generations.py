

# Generated at 2022-06-17 14:53:46.416315
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:53:54.770359
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor('localhost', stats, False) == 'localhost               '
    assert hostcolor('localhost', stats, True) == 'localhost               '
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor('localhost', stats, False) == 'localhost               '
    assert hostcolor('localhost', stats, True) == '\x1b[31mlocalhost\x1b[0m               '
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor('localhost', stats, False) == 'localhost               '

# Generated at 2022-06-17 14:54:04.909774
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=1)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=1, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=0, changed=0)) == u'host'
    assert hostcolor('host', dict(failures=1, unreachable=1, changed=1)) == u'host'
    assert hostcolor('host', dict(failures=0, unreachable=0, changed=0), color=False) == u'host'

# Generated at 2022-06-17 14:54:13.099508
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '

# --- end "pretty"



# Generated at 2022-06-17 14:54:20.040518
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=0)) == u'%-37s' % stringc

# Generated at 2022-06-17 14:54:27.995123
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "yellow") == u"\033[33mtest\033[0m"
    assert stringc("test", "magenta") == u"\033[35mtest\033[0m"
    assert stringc("test", "cyan") == u"\033[36mtest\033[0m"
    assert stringc("test", "white") == u"\033[37mtest\033[0m"

# Generated at 2022-06-17 14:54:37.697081
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('cyan') == '36'
    assert parsecolor('magenta') == '35'
    assert parsecolor('yellow') == '33'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('default') == '39'
    assert parsecolor('color8') == '38;5;8'
    assert parsecolor('color16') == '38;5;16'
    assert parsecolor('color255') == '38;5;255'
    assert parsecolor('rgb123') == '38;5;123'

# Generated at 2022-06-17 14:54:47.698907
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'



# Generated at 2022-06-17 14:54:55.108820
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=True) == u"%-37s" % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), color=True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), color=True) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), color=True) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:55:05.755033
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:55:17.653131
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """
    pass


# Generated at 2022-06-17 14:55:27.516459
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('blue') == u'34'
    assert parsecolor('on_blue') == u'44'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb0255255') == u'38;5;6'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsec

# Generated at 2022-06-17 14:55:34.257458
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'



# Generated at 2022-06-17 14:55:41.185121
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 14:55:50.655191
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('black') == u'38;5;0'
    assert parsecolor('red') == u'38;5;1'
    assert parsecolor('green') == u'38;5;2'
    assert parsecolor('yellow') == u'38;5;3'
    assert parsecolor('blue') == u'38;5;4'
    assert parsecolor('magenta') == u'38;5;5'
    assert parsecolor('cyan') == u'38;5;6'
    assert parsecolor('white') == u'38;5;7'
    assert parsecolor('bright_black') == u'38;5;8'
    assert parsecolor('bright_red') == u'38;5;9'

# Generated at 2022-06-17 14:55:59.808867
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:56:08.597360
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:56:17.214111
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:56:28.241147
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:56:35.791746
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:56:50.072717
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:57:00.106370
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    color = True
    assert hostcolor(host, stats, color) == u'%-37s' % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, color) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 14:57:12.116965
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"

# Generated at 2022-06-17 14:57:17.973337
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    """


# Generated at 2022-06-17 14:57:27.798844
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color0') == u'38;5;0'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4')

# Generated at 2022-06-17 14:57:37.387571
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'


# Generated at 2022-06-17 14:57:46.971089
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 14:57:57.921131
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    # Test color names
    assert stringc(u"test", u"red") == u"\033[31mtest\033[0m"
    assert stringc(u"test", u"green") == u"\033[32mtest\033[0m"
    assert stringc(u"test", u"yellow") == u"\033[33mtest\033[0m"
    assert stringc(u"test", u"blue") == u"\033[34mtest\033[0m"
    assert stringc(u"test", u"magenta") == u"\033[35mtest\033[0m"
    assert stringc(u"test", u"cyan") == u"\033[36mtest\033[0m"

# Generated at 2022-06-17 14:58:08.754617
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m           '

# Generated at 2022-06-17 14:58:20.520889
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:58:35.119213
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '

# --- end "pretty"



# Generated at 2022-06-17 14:58:43.370682
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc("foo", "rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc("foo", "rgb000255000") == u"\033[38;5;2mfoo\033[0m"
    assert stringc("foo", "rgb255000000") == u"\033[38;5;9mfoo\033[0m"
    assert stringc("foo", "rgb255255000") == u"\033[38;5;11mfoo\033[0m"

# Generated at 2022-06-17 14:58:51.404805
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:59:03.009018
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:59:14.087347
# Unit test for function stringc
def test_stringc():
    print(stringc("Hello World", "red"))
    print(stringc("Hello World", "rgb255255255"))
    print(stringc("Hello World", "rgb255255255", wrap_nonvisible_chars=True))
    print(stringc("Hello World", "rgb255255255", wrap_nonvisible_chars=False))
    print(stringc("Hello World", "rgb255255255", wrap_nonvisible_chars=True))
    print(stringc("Hello World", "rgb255255255", wrap_nonvisible_chars=False))
    print(stringc("Hello World", "rgb255255255", wrap_nonvisible_chars=True))
    print(stringc("Hello World", "rgb255255255", wrap_nonvisible_chars=False))

# Generated at 2022-06-17 14:59:18.501610
# Unit test for function colorize
def test_colorize():
    """
    >>> print(colorize('foo', 42, 'blue'))
    foo=42
    >>> print(colorize('foo', 0, 'blue'))
    foo=0
    >>> print(colorize('foo', 42, None))
    foo=42
    >>> print(colorize('foo', 0, None))
    foo=0
    """


# Generated at 2022-06-17 14:59:26.285145
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb255000') == '38;5;196'
    assert parsecolor('gray8') == '38;5;240'
    assert parsecolor('blue') == '34'
    assert parsecolor('invalid') == '39'


# Generated at 2022-06-17 14:59:30.992156
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """



# Generated at 2022-06-17 14:59:40.683667
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb123") == u"\033[38;5;33mtest\033[0m"
    assert stringc("test", "gray0") == u"\033[38;5;232mtest\033[0m"
    assert stringc("test", "gray1")

# Generated at 2022-06-17 14:59:50.928432
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color99') == '38;5;99'
    assert parsecolor('rgb123') == '38;5;123'
    assert parsecolor('rgb321') == '38;5;201'
    assert parsecolor('rgb555') == '38;5;231'
    assert parsecolor('gray0') == '38;5;232'
    assert parsecolor('gray1') == '38;5;233'
    assert parsecolor('gray99') == '38;5;231'


# Generated at 2022-06-17 15:00:06.988127
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u'%-37s' % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, color=True) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}
   

# Generated at 2022-06-17 15:00:16.512749
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc(u"foo", u"rgb255255255") == u"\033[38;5;15mfoo\033[0m"
    assert stringc(u"foo", u"rgb000255000") == u"\033[38;5;2mfoo\033[0m"
    assert stringc(u"foo", u"rgb255255000") == u"\033[38;5;3mfoo\033[0m"

# Generated at 2022-06-17 15:00:22.170333
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:00:32.163799
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:00:44.501615
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# --- end "pretty"



# Generated at 2022-06-17 15:00:55.663803
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 15:01:07.334395
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '

# --- end "pretty"



# Generated at 2022-06-17 15:01:21.008432
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;11mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray1') == u'\033[38;5;234mfoo\033[0m'
    assert stringc('foo', 'gray9') == u'\033[38;5;242mfoo\033[0m'

# Generated at 2022-06-17 15:01:31.972241
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;32mlocalhost          \x1b[0m"
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost          \x1b[0m"
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost          \x1b[0m"

# Generated at 2022-06-17 15:01:44.123330
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# --- end "pretty"



# Generated at 2022-06-17 15:02:01.873902
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'%-26s' % 'localhost'
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'%-37s' % stringc

# Generated at 2022-06-17 15:02:05.463035
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '



# Generated at 2022-06-17 15:02:12.492253
# Unit test for function colorize

# Generated at 2022-06-17 15:02:23.534639
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_OK)
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1), True) == u"%-37s" % stringc("localhost", C.COLOR_CHANGED)
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0), True) == u"%-37s" % stringc("localhost", C.COLOR_ERROR)

# Generated at 2022-06-17 15:02:33.759748
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor('host1', stats) == u"host1                 "
    stats['failures'] = 1
    assert hostcolor('host1', stats) == u"host1                 "
    stats['failures'] = 0
    stats['unreachable'] = 1
    assert hostcolor('host1', stats) == u"host1                 "
    stats['unreachable'] = 0
    stats['changed'] = 1
    assert hostcolor('host1', stats) == u"host1                 "
    stats['changed'] = 0
    assert hostcolor('host1', stats) == u"host1                 "

# --- end "pretty"



# Generated at 2022-06-17 15:02:46.667912
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 15:02:54.111293
# Unit test for function stringc

# Generated at 2022-06-17 15:03:04.530845
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m        '

# --- end "pretty"

# --- begin "termcap"
#
# termcap - A miniature library that provides a Python interface to the


# Generated at 2022-06-17 15:03:13.238882
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255000255") == u"\033[38;5;9mtest\033[0m"

# Generated at 2022-06-17 15:03:21.998657
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('hello', 'blue') == u'\033[34mhello\033[0m'
    assert stringc('hello', 'color3') == u'\033[38;5;11mhello\033[0m'
    assert stringc('hello', 'rgb255') == u'\033[38;5;231mhello\033[0m'
    assert stringc('hello', 'rgb123') == u'\033[38;5;33mhello\033[0m'
    assert stringc('hello', 'gray7') == u'\033[38;5;249mhello\033[0m'
    assert stringc('hello', 'gray0') == u'\033[38;5;232mhello\033[0m'