

# Generated at 2022-06-17 14:53:38.642618
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:53:48.813794
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:53:56.015491
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color0') == '38;5;0'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert par

# Generated at 2022-06-17 14:54:01.561237
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert parsecolor('color6') == '38;5;6'
    assert parsecolor('color7') == '38;5;7'
    assert parsecolor('color8') == '38;5;8'
    assert par

# Generated at 2022-06-17 14:54:07.761080
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "

# --- end "pretty"



# Generated at 2022-06-17 14:54:16.171423
# Unit test for function stringc
def test_stringc():
    """Test for function stringc."""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000255") == u"\033[38;5;5mtest\033[0m"

# Generated at 2022-06-17 14:54:25.915106
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m        '

# Generated at 2022-06-17 14:54:36.063534
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;34mtest\033[0m"
    assert stringc("test", "rgb255000255") == u"\033[38;5;55mtest\033[0m"
    assert stringc("test", "rgb255000000") == u"\033[38;5;9mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;39mtest\033[0m"
    assert stringc

# Generated at 2022-06-17 14:54:40.151662
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '



# Generated at 2022-06-17 14:54:50.674313
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:55:06.159673
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '

# --- end "pretty"



# Generated at 2022-06-17 14:55:11.197419
# Unit test for function colorize
def test_colorize():
    # Test the colorize function
    assert colorize("foo", 0, "blue") == "foo=0   "
    assert colorize("foo", 1, "blue") == stringc("foo=1   ", "blue")
    assert colorize("foo", 0, None) == "foo=0   "
    assert colorize("foo", 1, None) == "foo=1   "
    assert colorize("foo", 0, "") == "foo=0   "
    assert colorize("foo", 1, "") == "foo=1   "



# Generated at 2022-06-17 14:55:22.725024
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"Hello", u"red") == u"\033[31mHello\033[0m"
    assert stringc(u"Hello", u"rgb255255255") == u"\033[37mHello\033[0m"
    assert stringc(u"Hello", u"rgb000255000") == u"\033[32mHello\033[0m"
    assert stringc(u"Hello", u"rgb255000255") == u"\033[35mHello\033[0m"
    assert stringc(u"Hello", u"rgb255000000") == u"\033[31mHello\033[0m"

# Generated at 2022-06-17 14:55:32.795635
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# Generated at 2022-06-17 14:55:41.201343
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 14:55:50.692033
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc(u"foo", u"rgb255") == u"\033[38;5;231mfoo\033[0m"
    assert stringc(u"foo", u"rgb123") == u"\033[38;5;33mfoo\033[0m"

# Generated at 2022-06-17 14:55:56.428539
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:56:06.704306
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:56:15.638894
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('blue') == '34'
    assert parsecolor('yellow') == '33'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('rgb333') == '38;5;63'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('rgb123') == '38;5;18'

# Generated at 2022-06-17 14:56:20.949203
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize("foo", 42, "blue")
    'foo=42  '
    >>> colorize("foo", 0, "blue")
    'foo=0   '
    >>> colorize("foo", 42, None)
    'foo=42  '
    """

# --- end of "pretty"



# Generated at 2022-06-17 14:56:34.258430
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"
    assert stringc(u"foo", u"white")

# Generated at 2022-06-17 14:56:47.114548
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc(u"test", u"blue") == u"\033[34mtest\033[0m"
    assert stringc(u"test", u"color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc(u"test", u"rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc(u"test", u"rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc(u"test", u"rgb255000000") == u"\033[38;5;9mtest\033[0m"

# Generated at 2022-06-17 14:56:52.642422
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:57:03.364400
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host', dict(changed=0, failures=0, unreachable=0)) == u'host                 '
    assert hostcolor('host', dict(changed=1, failures=0, unreachable=0)) == u'host                 '
    assert hostcolor('host', dict(changed=0, failures=1, unreachable=0)) == u'host                 '
    assert hostcolor('host', dict(changed=0, failures=0, unreachable=1)) == u'host                 '
    assert hostcolor('host', dict(changed=0, failures=0, unreachable=0), color=False) == u'host                 '
    assert hostcolor('host', dict(changed=1, failures=0, unreachable=0), color=False) == u'host                 '

# Generated at 2022-06-17 14:57:13.612198
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('host1', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u"host1                 "
    assert hostcolor('host2', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u"host2                 "
    assert hostcolor('host3', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u"host3                 "
    assert hostcolor('host4', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u"host4                 "
    assert hostcolor('host5', {'failures': 1, 'unreachable': 1, 'changed': 1}) == u"host5                 "

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library

# Generated at 2022-06-17 14:57:24.539000
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=0)) == u'localhost               '

# Generated at 2022-06-17 14:57:31.415237
# Unit test for function stringc

# Generated at 2022-06-17 14:57:45.172432
# Unit test for function colorize
def test_colorize():
    # Set ANSIBLE_COLOR to True
    global ANSIBLE_COLOR
    ANSIBLE_COLOR = True

    # Test colorize with color=True
    assert colorize(u"test", 1, True) == u"test=1   "
    assert colorize(u"test", 0, True) == u"test=0   "

    # Test colorize with color=False
    assert colorize(u"test", 1, False) == u"test=1   "
    assert colorize(u"test", 0, False) == u"test=0   "

    # Test colorize with color=None
    assert colorize(u"test", 1, None) == u"test=1   "
    assert colorize(u"test", 0, None) == u"test=0   "

    # Set ANSIBLE_COLOR to

# Generated at 2022-06-17 14:57:56.260124
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "rgb255255255") == "\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == "\033[38;5;34mtest\033[0m"
    assert stringc("test", "rgb255255000") == "\033[38;5;226mtest\033[0m"
    assert stringc("test", "rgb255000255") == "\033[38;5;201mtest\033[0m"
    assert stringc("test", "rgb000255255") == "\033[38;5;51mtest\033[0m"

# Generated at 2022-06-17 14:58:08.316556
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "rgb255255255") == "\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == "\033[38;5;34mtest\033[0m"
    assert stringc("test", "rgb255000255") == "\033[38;5;93mtest\033[0m"
    assert stringc("test", "rgb255000000") == "\033[38;5;9mtest\033[0m"
    assert stringc("test", "rgb000255255") == "\033[38;5;39mtest\033[0m"

# Generated at 2022-06-17 14:58:26.389607
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('blue') == u'34'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color8') == u'38;5;8'
    assert parsecolor('color16') == u'38;5;16'
    assert parsecolor('color255') == u'38;5;255'
    assert parsecolor('rgb123') == u'38;5;123'

# Generated at 2022-06-17 14:58:37.730378
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 14:58:48.525465
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:59:02.603690
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:59:10.703067
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, 'bogus')
    'foo=42  '
    >>> colorize('foo', 0, 'bogus')
    'foo=0   '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 42, None)
    'foo=42  '
    """
    pass


# Generated at 2022-06-17 14:59:17.485273
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize("foo", 42, "blue")
    'foo=42  '
    >>> colorize("foo", 42, None)
    'foo=42  '
    >>> colorize("foo", 0, "blue")
    'foo=0   '
    >>> colorize("foo", 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 14:59:28.784210
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "yellow") == "\033[33mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"
    assert stringc("test", "cyan") == "\033[36mtest\033[0m"
    assert stringc("test", "white") == "\033[37mtest\033[0m"

# Generated at 2022-06-17 14:59:34.844324
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 14:59:45.024803
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc('foo', 'red') == '\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == '\033[34mfoo\033[0m'
    assert stringc('foo', 'on_red') == '\033[41mfoo\033[0m'
    assert stringc('foo', 'on_blue') == '\033[44mfoo\033[0m'
    assert stringc('foo', 'red', wrap_nonvisible_chars=True) == '\001\033[31m\002foo\001\033[0m\002'

# Generated at 2022-06-17 14:59:54.920120
# Unit test for function stringc

# Generated at 2022-06-17 15:00:14.741500
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost                 '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[0;32mlocalhost\x1b[0m       '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[0;31mlocalhost\x1b[0m       '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[0;31mlocalhost\x1b[0m       '

# Generated at 2022-06-17 15:00:21.477345
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u"%-37s" % 'localhost'
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u"%-37s" % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u"%-37s" % stringc('localhost', C.COLOR_CHANGED)

# --- end "pretty"

# --- begin "termcap"
#
# term

# Generated at 2022-06-17 15:00:30.480225
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'


# Generated at 2022-06-17 15:00:40.307009
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 15:00:47.109694
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# --- end "pretty"



# Generated at 2022-06-17 15:00:57.383467
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"color1") == u"\033[38;5;1mfoo\033[0m"
    assert stringc(u"foo", u"rgb255") == u"\033[38;5;231mfoo\033[0m"
    assert stringc(u"foo", u"rgb123") == u"\033[38;5;33mfoo\033[0m"

# Generated at 2022-06-17 15:01:08.636374
# Unit test for function stringc
def test_stringc():
    # Test foreground colors
    assert stringc('black', 'black') == u'\033[30mblack\033[0m'
    assert stringc('red', 'red') == u'\033[31mred\033[0m'
    assert stringc('green', 'green') == u'\033[32mgreen\033[0m'
    assert stringc('yellow', 'yellow') == u'\033[33myellow\033[0m'
    assert stringc('blue', 'blue') == u'\033[34mblue\033[0m'
    assert stringc('magenta', 'magenta') == u'\033[35mmagenta\033[0m'
    assert stringc('cyan', 'cyan') == u'\033[36mcyan\033[0m'
    assert string

# Generated at 2022-06-17 15:01:18.720741
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc("test", "green") == u"\033[32mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255000255") == u"\033[38;5;9mtest\033[0m"

# Generated at 2022-06-17 15:01:26.793070
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;3mtest\033[0m"

# Generated at 2022-06-17 15:01:37.211072
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '

# --- end "pretty"

# Generated at 2022-06-17 15:02:05.743900
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 12, 'blue') == 'foo=12  '
    assert colorize('foo', 123, 'blue') == 'foo=123 '
    assert colorize('foo', 1234, 'blue') == 'foo=1234'
    assert colorize('foo', 12345, 'blue') == 'foo=12345'
    assert colorize('foo', 123456, 'blue') == 'foo=123456'
    assert colorize('foo', 1234567, 'blue') == 'foo=1234567'
    assert colorize('foo', 12345678, 'blue') == 'foo=12345678'

# Generated at 2022-06-17 15:02:12.666548
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                    "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;32mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m          "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m          "

# Generated at 2022-06-17 15:02:23.564491
# Unit test for function stringc
def test_stringc():
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 15:02:34.539376
# Unit test for function hostcolor
def test_hostcolor():
    # Test for color off
    ANSIBLE_COLOR = False
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == 'localhost              '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == 'localhost              '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == 'localhost              '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == 'localhost              '
    assert hostcolor('localhost', dict(failures=1, unreachable=1, changed=1)) == 'localhost              '
    # Test for color on
    ANSIBLE_COLOR = True

# Generated at 2022-06-17 15:02:42.382238
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 42, None)
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 0, None)
    'foo=0   '
    """


# Generated at 2022-06-17 15:02:49.308845
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc."""
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"
    assert stringc("test", "cyan") == "\033[36mtest\033[0m"
    assert stringc("test", "white") == "\033[37mtest\033[0m"
    assert stringc("test", "black") == "\033[30mtest\033[0m"

# Generated at 2022-06-17 15:02:57.534128
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('blue') == '34'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('rgb123') == '38;5;18'
    assert parsecolor('rgb321') == '38;5;54'
    assert parsecolor('rgb213') == '38;5;33'
    assert parsecolor('rgb231') == '38;5;37'
    assert parsecolor('rgb312') == '38;5;46'
    assert parsecolor('rgb132') == '38;5;21'
    assert parsecolor('rgb321') == '38;5;54'
    assert parsecolor('rgb123') == '38;5;18'

# Generated at 2022-06-17 15:03:06.733413
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert stringc("foo\nbar", "blue") == u"\033[34mfoo\nbar\033[0m"
    assert stringc("foo\nbar", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\nbar\001\033[0m\002"
    assert stringc("foo", "rgb255000") == u"\033[38;5;196mfoo\033[0m"

# Generated at 2022-06-17 15:03:16.237774
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '



# Generated at 2022-06-17 15:03:23.767116
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)