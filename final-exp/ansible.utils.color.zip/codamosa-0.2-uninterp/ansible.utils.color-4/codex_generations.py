

# Generated at 2022-06-17 14:53:47.344482
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'on_red') == u'\033[41mfoo\033[0m'
    assert stringc('foo', 'on_blue') == u'\033[44mfoo\033[0m'
    assert stringc('foo', 'red', wrap_nonvisible_chars=True) == u'\001\033[31m\002foo\001\033[0m\002'

# Generated at 2022-06-17 14:53:55.347270
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:54:05.191411
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == '31'
    assert parsecolor('green') == '32'
    assert parsecolor('yellow') == '33'
    assert parsecolor('blue') == '34'
    assert parsecolor('magenta') == '35'
    assert parsecolor('cyan') == '36'
    assert parsecolor('white') == '37'
    assert parsecolor('black') == '30'
    assert parsecolor('color1') == '38;5;1'
    assert parsecolor('color2') == '38;5;2'
    assert parsecolor('color3') == '38;5;3'
    assert parsecolor('color4') == '38;5;4'
    assert parsecolor('color5') == '38;5;5'
    assert par

# Generated at 2022-06-17 14:54:14.052922
# Unit test for function colorize
def test_colorize():
    # ANSIBLE_COLOR is True
    ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 1, 'yellow') == 'changed=1 '
    assert colorize('unreachable', 2, 'red') == 'unreachable=2  '
    assert colorize('failed', 3, 'red') == 'failed=3   '
    assert colorize('skipped', 4, 'cyan') == 'skipped=4  '

    # ANSIBLE_COLOR is False
    ANSIBLE_COLOR = False
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 1, 'yellow') == 'changed=1 '

# Generated at 2022-06-17 14:54:25.067269
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"

# Generated at 2022-06-17 14:54:35.461787
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == "\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == "\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == "\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == "\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == "\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == "\001\033[34m\002foo\001\033[0m\002"

# Generated at 2022-06-17 14:54:40.327952
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('rgb255000') == u'38;5;196'
    assert parsecolor('rgb255255255') == u'38;5;15'
    assert parsecolor('gray0') == u'38;5;232'
    assert parsecolor('gray23') == u'38;5;255'
    assert parsecolor('gray24') == u'38;5;255'
    assert parsecolor('gray25') == u'38;5;255'
    assert parsecolor('gray26') == u'38;5;255'
    assert parsecolor('gray27') == u'38;5;255'
    assert parsecolor('gray28')

# Generated at 2022-06-17 14:54:50.724094
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc(u"foo", u"red") == u"\033[31mfoo\033[0m"
    assert stringc(u"foo", u"blue") == u"\033[34mfoo\033[0m"
    assert stringc(u"foo", u"green") == u"\033[32mfoo\033[0m"
    assert stringc(u"foo", u"yellow") == u"\033[33mfoo\033[0m"
    assert stringc(u"foo", u"magenta") == u"\033[35mfoo\033[0m"
    assert stringc(u"foo", u"cyan") == u"\033[36mfoo\033[0m"
    assert stringc(u"foo", u"white")

# Generated at 2022-06-17 14:55:02.477007
# Unit test for function parsecolor
def test_parsecolor():
    assert parsecolor('red') == u'31'
    assert parsecolor('green') == u'32'
    assert parsecolor('yellow') == u'33'
    assert parsecolor('blue') == u'34'
    assert parsecolor('magenta') == u'35'
    assert parsecolor('cyan') == u'36'
    assert parsecolor('white') == u'37'
    assert parsecolor('black') == u'30'
    assert parsecolor('color1') == u'38;5;1'
    assert parsecolor('color2') == u'38;5;2'
    assert parsecolor('color3') == u'38;5;3'
    assert parsecolor('color4') == u'38;5;4'
    assert parsecolor('color5')

# Generated at 2022-06-17 14:55:09.031764
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "

# --- end "pretty"



# Generated at 2022-06-17 14:55:24.814422
# Unit test for function stringc
def test_stringc():
    """Test stringc function."""
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000111") == u"\033[38;5;9mtest\033[0m"
    assert stringc("test", "gray0") == u"\033[38;5;232mtest\033[0m"

# Generated at 2022-06-17 14:55:35.825757
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost          '


# Generated at 2022-06-17 14:55:45.367514
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 10000, 'blue') == 'foo=10000'
    assert colorize('foo', 100000, 'blue') == 'foo=100000'
    assert colorize('foo', 1000000, 'blue') == 'foo=1000000'
    assert colorize('foo', 10000000, 'blue') == 'foo=10000000'

# Generated at 2022-06-17 14:55:53.842335
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "on_red") == u"\033[41mfoo\033[0m"
    assert stringc("foo", "on_blue") == u"\033[44mfoo\033[0m"
    assert stringc("foo", "red", wrap_nonvisible_chars=True) == u"\001\033[31m\002foo\001\033[0m\002"
    assert stringc("foo", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002foo\001\033[0m\002"
    assert string

# Generated at 2022-06-17 14:56:01.609258
# Unit test for function stringc
def test_stringc():
    print(stringc("This is a test", "blue"))
    print(stringc("This is a test", "rgb255255255"))
    print(stringc("This is a test", "rgb000255000"))
    print(stringc("This is a test", "rgb255000000"))
    print(stringc("This is a test", "rgb255255000"))
    print(stringc("This is a test", "rgb255000255"))
    print(stringc("This is a test", "rgb000255255"))
    print(stringc("This is a test", "rgb000255255"))
    print(stringc("This is a test", "rgb255000255"))
    print(stringc("This is a test", "rgb255255000"))

# Generated at 2022-06-17 14:56:06.871727
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "color1") == "\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == "\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255000") == "\033[38;5;2mtest\033[0m"
    assert stringc("test", "rgb255000255") == "\033[38;5;5mtest\033[0m"
    assert stringc("test", "rgb255000000") == "\033[38;5;1mtest\033[0m"

# Generated at 2022-06-17 14:56:15.640092
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;34mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 14:56:26.322745
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color
    host = 'testhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}


# Generated at 2022-06-17 14:56:32.272222
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"localhost               "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost               "

# --- end "pretty"



# Generated at 2022-06-17 14:56:45.944801
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 2, 'blue') == 'foo=2   '
    assert colorize('foo', 12, 'blue') == 'foo=12  '
    assert colorize('foo', 123, 'blue') == 'foo=123 '
    assert colorize('foo', 1234, 'blue') == 'foo=1234'
    assert colorize('foo', 12345, 'blue') == 'foo=12345'

# --- end "pretty"

# --- begin "terminal"
#
# terminal - A library for color, positioning, and styling in terminals.
# Copyright (C

# Generated at 2022-06-17 14:57:02.909583
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u"\x1b[31mlocalhost\x1b[0m          "
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u"\x1b[33mlocalhost\x1b[0m          "

# --- end "pretty"



# Generated at 2022-06-17 14:57:12.626146
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '

# --- end "pretty"



# Generated at 2022-06-17 14:57:24.082573
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=0)) == u"localhost                "
    assert hostcolor("localhost", dict(failures=0, unreachable=0, changed=1)) == u"\x1b[0;32mlocalhost\x1b[0m      "
    assert hostcolor("localhost", dict(failures=0, unreachable=1, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m      "
    assert hostcolor("localhost", dict(failures=1, unreachable=0, changed=0)) == u"\x1b[0;31mlocalhost\x1b[0m      "

# Generated at 2022-06-17 14:57:33.188010
# Unit test for function stringc
def test_stringc():
    """Test the stringc function."""
    assert stringc("test", "red") == "\033[31mtest\033[0m"
    assert stringc("test", "blue") == "\033[34mtest\033[0m"
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "yellow") == "\033[33mtest\033[0m"
    assert stringc("test", "magenta") == "\033[35mtest\033[0m"
    assert stringc("test", "cyan") == "\033[36mtest\033[0m"
    assert stringc("test", "white") == "\033[37mtest\033[0m"

# Generated at 2022-06-17 14:57:45.612329
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color3') == u'\033[38;5;11mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb123') == u'\033[38;5;33mfoo\033[0m'
    assert stringc('foo', 'gray1') == u'\033[38;5;234mfoo\033[0m'
    assert stringc('foo', 'gray9') == u'\033[38;5;242mfoo\033[0m'

# Generated at 2022-06-17 14:57:56.563602
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "blue", wrap_nonvisible_chars=True) == u"\001\033[34m\002test\001\033[0m\002"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255") == u"\033[38;5;231mtest\033[0m"
    assert stringc("test", "rgb123") == u"\033[38;5;33mtest\033[0m"
    assert stringc("test", "gray0") == u"\033[38;5;232mtest\033[0m"
    assert string

# Generated at 2022-06-17 14:58:05.898318
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '



# Generated at 2022-06-17 14:58:13.974202
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-17 14:58:18.507106
# Unit test for function colorize
def test_colorize():
    """
    >>> colorize('foo', 42, 'blue')
    'foo=42  '
    >>> colorize('foo', 0, 'blue')
    'foo=0   '
    >>> colorize('foo', 42, None)
    'foo=42  '
    """


# Generated at 2022-06-17 14:58:26.799535
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 14:58:43.580621
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)

# Generated at 2022-06-17 14:58:53.992814
# Unit test for function colorize
def test_colorize():
    # Test with ANSIBLE_COLOR
    ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == u'ok=0   '
    assert colorize('changed', 0, 'yellow') == u'changed=0   '
    assert colorize('unreachable', 0, 'red') == u'unreachable=0   '
    assert colorize('failed', 0, 'red') == u'failed=0   '
    assert colorize('skipped', 0, 'cyan') == u'skipped=0   '

    # Test without ANSIBLE_COLOR
    ANSIBLE_COLOR = False
    assert colorize('ok', 0, 'green') == u'ok=0   '
    assert colorize('changed', 0, 'yellow') == u'changed=0   '

# Generated at 2022-06-17 14:59:04.408950
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# Generated at 2022-06-17 14:59:10.494576
# Unit test for function colorize
def test_colorize():
    # ANSIBLE_COLOR = True
    assert colorize('ok', 0, 'green') == 'ok=0   '
    assert colorize('changed', 0, 'yellow') == 'changed=0   '
    assert colorize('unreachable', 0, 'red') == 'unreachable=0   '
    assert colorize('failed', 0, 'red') == 'failed=0   '
    assert colorize('skipped', 0, 'cyan') == 'skipped=0   '
    assert colorize('rescued', 0, 'magenta') == 'rescued=0   '
    assert colorize('ignored', 0, 'blue') == 'ignored=0   '
    assert colorize('ok', 1, 'green') == '\x1b[32mok=1   \x1b[0m'
   

# Generated at 2022-06-17 14:59:21.071395
# Unit test for function stringc
def test_stringc():
    """Unit test for function stringc"""
    assert stringc('foo', 'black') == u'\033[30mfoo\033[0m'
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'

# Generated at 2022-06-17 14:59:32.646869
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "color2") == u"\033[38;5;2mtest\033[0m"
    assert stringc("test", "color3") == u"\033[38;5;3mtest\033[0m"
    assert stringc("test", "color4") == u"\033[38;5;4mtest\033[0m"

# Generated at 2022-06-17 14:59:46.359916
# Unit test for function stringc
def test_stringc():
    assert stringc("text", "red") == u"\033[31mtext\033[0m"
    assert stringc("text", "blue") == u"\033[34mtext\033[0m"
    assert stringc("text", "color1") == u"\033[38;5;1mtext\033[0m"
    assert stringc("text", "color99") == u"\033[38;5;99mtext\033[0m"
    assert stringc("text", "rgb123") == u"\033[38;5;123mtext\033[0m"
    assert stringc("text", "rgb321") == u"\033[38;5;201mtext\033[0m"

# Generated at 2022-06-17 14:59:50.681473
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_OK)
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats, True) == u"%-37s" % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 14:59:58.543022
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                 '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[0;32mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[0;31mlocalhost\x1b[0m          '

# Generated at 2022-06-17 15:00:08.258205
# Unit test for function stringc
def test_stringc():
    """Test function stringc."""
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'green') == u'\033[32mfoo\033[0m'
    assert stringc('foo', 'yellow') == u'\033[33mfoo\033[0m'
    assert stringc('foo', 'magenta') == u'\033[35mfoo\033[0m'
    assert stringc('foo', 'cyan') == u'\033[36mfoo\033[0m'
    assert stringc('foo', 'white') == u'\033[37mfoo\033[0m'

# Generated at 2022-06-17 15:00:31.683989
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "red") == u"\033[31mtest\033[0m"
    assert stringc("test", "blue") == u"\033[34mtest\033[0m"
    assert stringc("test", "color1") == u"\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == u"\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == u"\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255255000") == u"\033[38;5;11mtest\033[0m"
    assert stringc("test", "rgb255000255")

# Generated at 2022-06-17 15:00:44.797592
# Unit test for function stringc
def test_stringc():
    assert stringc('foo', 'red') == u'\033[31mfoo\033[0m'
    assert stringc('foo', 'blue') == u'\033[34mfoo\033[0m'
    assert stringc('foo', 'color1') == u'\033[38;5;1mfoo\033[0m'
    assert stringc('foo', 'rgb255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb255255255') == u'\033[38;5;231mfoo\033[0m'
    assert stringc('foo', 'rgb000') == u'\033[38;5;16mfoo\033[0m'

# Generated at 2022-06-17 15:00:55.805600
# Unit test for function colorize
def test_colorize():
    assert colorize('foo', 0, 'blue') == 'foo=0   '
    assert colorize('foo', 1, 'blue') == 'foo=1   '
    assert colorize('foo', 10, 'blue') == 'foo=10  '
    assert colorize('foo', 100, 'blue') == 'foo=100 '
    assert colorize('foo', 1000, 'blue') == 'foo=1000'
    assert colorize('foo', 0, None) == 'foo=0   '
    assert colorize('foo', 1, None) == 'foo=1   '
    assert colorize('foo', 10, None) == 'foo=10  '
    assert colorize('foo', 100, None) == 'foo=100 '
    assert colorize('foo', 1000, None) == 'foo=1000'

# Generated at 2022-06-17 15:01:02.819104
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 0}) == u'localhost                 '
    assert hostcolor('localhost', {'failures': 1, 'unreachable': 0, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 1, 'changed': 0}) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', {'failures': 0, 'unreachable': 0, 'changed': 1}) == u'\x1b[33mlocalhost\x1b[0m          '

# --- end "pretty"



# Generated at 2022-06-17 15:01:11.100668
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                     '


# Generated at 2022-06-17 15:01:19.832654
# Unit test for function hostcolor
def test_hostcolor():
    host = 'localhost'
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u'%-37s' % host
    stats = {'failures': 1, 'unreachable': 0, 'changed': 0}
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 1, 'changed': 0}
    assert hostcolor(host, stats) == u'%-37s' % stringc(host, C.COLOR_ERROR)
    stats = {'failures': 0, 'unreachable': 0, 'changed': 1}

# Generated at 2022-06-17 15:01:31.368891
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m            '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 15:01:40.569056
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m         '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost               '


# Generated at 2022-06-17 15:01:51.943465
# Unit test for function hostcolor
def test_hostcolor():
    stats = {'failures': 0, 'unreachable': 0, 'changed': 0}
    assert hostcolor('localhost', stats) == u'localhost               '
    stats['failures'] = 1
    assert hostcolor('localhost', stats) == u'\x1b[31mlocalhost\x1b[0m          '
    stats['failures'] = 0
    stats['changed'] = 1
    assert hostcolor('localhost', stats) == u'\x1b[33mlocalhost\x1b[0m          '
    stats['changed'] = 0
    assert hostcolor('localhost', stats) == u'\x1b[32mlocalhost\x1b[0m          '



# Generated at 2022-06-17 15:01:57.764581
# Unit test for function hostcolor
def test_hostcolor():
    # Test with color off
    ANSIBLE_COLOR = False
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == 'host                  '
    assert hostcolor('host', {'failures': 1, 'unreachable': 0, 'changed': 0}) == 'host                  '
    assert hostcolor('host', {'failures': 0, 'unreachable': 1, 'changed': 0}) == 'host                  '
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 1}) == 'host                  '
    # Test with color on
    ANSIBLE_COLOR = True
    assert hostcolor('host', {'failures': 0, 'unreachable': 0, 'changed': 0}) == 'host                  '

# Generated at 2022-06-17 15:02:37.450285
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m          '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), color=False) == u'localhost                    '


# Generated at 2022-06-17 15:02:45.421873
# Unit test for function stringc
def test_stringc():
    assert stringc("foo", "red") == u"\033[31mfoo\033[0m"
    assert stringc("foo", "blue") == u"\033[34mfoo\033[0m"
    assert stringc("foo", "green") == u"\033[32mfoo\033[0m"
    assert stringc("foo", "yellow") == u"\033[33mfoo\033[0m"
    assert stringc("foo", "magenta") == u"\033[35mfoo\033[0m"
    assert stringc("foo", "cyan") == u"\033[36mfoo\033[0m"
    assert stringc("foo", "white") == u"\033[37mfoo\033[0m"

# Generated at 2022-06-17 15:02:56.202021
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                     '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m               '

# --- end "pretty"

# Generated at 2022-06-17 15:03:05.878509
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost                    '
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'\x1b[31mlocalhost\x1b[0m           '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'\x1b[33mlocalhost\x1b[0m           '

# --- end "pretty"

# --- begin "termcap"
#
# termcap - A simple termcap interface for Python.
#


# Generated at 2022-06-17 15:03:17.402963
# Unit test for function stringc
def test_stringc():
    assert stringc("test", "green") == "\033[32mtest\033[0m"
    assert stringc("test", "color1") == "\033[38;5;1mtest\033[0m"
    assert stringc("test", "rgb255255255") == "\033[38;5;15mtest\033[0m"
    assert stringc("test", "rgb000255255") == "\033[38;5;6mtest\033[0m"
    assert stringc("test", "rgb255255000") == "\033[38;5;11mtest\033[0m"
    assert stringc("test", "rgb255000255") == "\033[38;5;13mtest\033[0m"

# Generated at 2022-06-17 15:03:22.616903
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1)) == u'localhost               '
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0)) == u'localhost               '

# --- end "pretty"



# Generated at 2022-06-17 15:03:35.010854
# Unit test for function hostcolor
def test_hostcolor():
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_OK)
    assert hostcolor('localhost', dict(failures=1, unreachable=0, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=1, changed=0), True) == u'%-37s' % stringc('localhost', C.COLOR_ERROR)
    assert hostcolor('localhost', dict(failures=0, unreachable=0, changed=1), True) == u'%-37s' % stringc('localhost', C.COLOR_CHANGED)