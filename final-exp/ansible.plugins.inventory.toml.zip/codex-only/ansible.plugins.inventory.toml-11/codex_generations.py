

# Generated at 2022-06-23 10:57:18.253819
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert convert_yaml_objects_to_native([AnsibleUnsafeText('1')]) == ['1']
    assert convert_yaml_objects_to_native([1]) == [1]
    assert convert_yaml_objects_to_native({'a': AnsibleUnsafeText('1')}) == {'a': '1'}
    assert convert_yaml_objects_to_native({'a': 1}) == {'a': 1}
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('1')) == '1'
    assert convert_yaml_objects_to_native(1) == 1

# Generated at 2022-06-23 10:57:26.249931
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('.toml') is True
    assert inventory_module.verify_file('.yml') is False
    assert inventory_module.verify_file('/home/user/.toml') is True
    assert inventory_module.verify_file('/home/user/.yml') is False
    assert inventory_module.verify_file('/home/user/.txt') is False


# Generated at 2022-06-23 10:57:35.808638
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {
        'group1': {
            'vars': {
                'key1': 'value1'
            },
            'hosts': {
                'host1': {
                },
                'host2': {
                    'ansible_host': '127.0.0.1',
                    'ansible_port': 22
                }
            }
        }
    }
    toml_str = toml_dumps(data)
    assert (toml_str == "[group1]\n[group1.vars]\nkey1 = \"value1\"\n[group1.hosts]\nhost1 = {}\nhost2 = {\n    ansible_host = \"127.0.0.1\",\n    ansible_port = 22\n}\n")

# Generated at 2022-06-23 10:57:45.165394
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    assert convert_yaml_objects_to_native(AnsibleUnicode(u'foobar')) == u'foobar'
    assert convert_yaml_objects_to_native(AnsibleUnicode(u'foo\x00bar')) == u'foo\x00bar'
    assert convert_yaml_objects_to_native(AnsibleUnicode(u'foo\udcffbar')) == u'foo\udcffbar'
    assert convert_yaml_objects_to_native(AnsibleSequence([u'foo\x00bar'])) == [u'foo\x00bar']

# Generated at 2022-06-23 10:57:53.524480
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    test = text_type('testing')
    result = convert_yaml_objects_to_native(test)
    assert isinstance(result, text_type)
    test = AnsibleUnicode(u'testing')
    result = convert_yaml_objects_to_native(test)
    assert result == u'testing'
    test = {'testing': 'test'}
    result = convert_yaml_objects_to_native(test)
    assert isinstance(result, dict)
    ansible_vars = {'test': 'test'}
    group = "ungrouped"
    group = InventoryModule.Inventory(None).add_group(group)
    InventoryModule.Inventory(None).set_variable(group, 'test', 'test')

# Generated at 2022-06-23 10:57:59.171535
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    path_good = "/etc/ansible/hosts.toml"
    path_bad = "/etc/ansible/hosts"
    assert inventory.verify_file(path_good) == True
    assert inventory.verify_file(path_bad) == False

# Generated at 2022-06-23 10:58:00.529533
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None


# Generated at 2022-06-23 10:58:01.840390
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: Add needed unit tests
    pass


# Generated at 2022-06-23 10:58:09.799966
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    # Create a test inventory file.
    module.loader = type('MockLoader', (), {'path_dwim': lambda x, y: x})
    # Verification that the file is valid TOML.
    if not module.verify_file('sample.toml'):
        raise RuntimeError('Sample file not TOML Inventory')
    # Verification that the file is not empty
    if not module.parse(type('MockInventory', (), {}), module.loader, 'sample.toml', cache=True):
        raise RuntimeError('Empty inventory')
    # Verification that the file is not a TOML Plugin.
    if module.parse(type('MockInventory', (), {}), module.loader, 'sample.toml', cache=True):
        raise RuntimeError('TOML inventory is a Plugin')


# Generated at 2022-06-23 10:58:15.561673
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins.loader import inventory_loader

    i = InventoryModule()
    i.NAME = 'toml'
    inventory_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', '..'))

# Generated at 2022-06-23 10:58:27.189914
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # ...
    def _load_file(self, file_name):
        if not file_name or not isinstance(file_name, string_types):
            raise AnsibleParserError("Invalid filename: '%s'" % to_native(file_name))

        b_file_name = to_bytes(self.loader.path_dwim(file_name))
        if not self.loader.path_exists(b_file_name):
            raise AnsibleFileNotFound("Unable to retrieve file contents", file_name=file_name)


# Generated at 2022-06-23 10:58:35.304304
# Unit test for function toml_dumps

# Generated at 2022-06-23 10:58:45.965093
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['localhost,'])
    var_manager = VariableManager(loader=loader, inventory=inv)

    host = Host(name='localhost')
    inv.add_host(host)
    plugin = InventoryModule()
    plugin.parse(inv, loader, paths=['test/test_data/toml_inventory.toml'], cache=False)

    hosts = inv.get_hosts()
    assert len(hosts) == 3, "Number of hosts should be 3, found %d" % len(hosts)
    assert 'host1'

# Generated at 2022-06-23 10:58:50.196390
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {
        'a': 'aaa',
        'b': [{'x': 'xxx'}, {'y': 'yyy'}, {'z': 'zzz'}],
    }
    assert toml_dumps(data) == toml.dumps(data)

    class Foo(object):
        pass

    data = {'x': Foo()}
    assert toml_dumps(data) == toml.dumps(data)

# Generated at 2022-06-23 10:58:51.514813
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module


# Generated at 2022-06-23 10:58:53.043563
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: need to mock file_loader to avoid real file read / parsing
    pass

# Generated at 2022-06-23 10:59:01.868695
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = InventoryModule(loader=loader)
    inv_vars = VariableManager()
    inv.parse(inventory=inv, loader=loader, path=EXAMPLES, cache=True)


# Generated at 2022-06-23 10:59:14.582964
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class EmptyFileInventory(BaseFileInventoryPlugin):
        NAME = 'empty'

    class TestInventoryModule(InventoryModule):
        test_inventory = EmptyFileInventory()

    # Test exception handling
    # Test exception handling when file does not exist
    try:
        test_inventory = TestInventoryModule()
        test_inventory.parse(None, None,
                             None)
        assert False
    except AnsibleParserError as e:
        assert to_native(e) == 'Invalid filename: \'None\''

    # Test exception handling when base class raises exception
    class TestInventoryModule(InventoryModule):
        test_inventory = EmptyFileInventory()

        def _load_file(self, file_name):
            raise AnsibleParserError('test')


# Generated at 2022-06-23 10:59:23.655609
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():

    assert convert_yaml_objects_to_native(dict(
        a=AnsibleUnicode("text"),
        b=AnsibleUnsafeBytes("text"),
        c=AnsibleUnsafeText("text"),
        d=AnsibleSequence(["text", 2]),
        e=AnsibleSequence([AnsibleUnsafeBytes("text")]),
        f=AnsibleSequence([AnsibleUnicode("text"), AnsibleUnsafeText("text")]),
    )) == dict(
        a="text",
        b="text",
        c="text",
        d=["text", 2],
        e=["text"],
        f=["text", "text"],
    )

# Generated at 2022-06-23 10:59:26.496646
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native({u'list_object': AnsibleSequence([u'bar', u'baz', u'foo'])}) == {u'list_object': [u'bar', u'baz', u'foo']}

# Generated at 2022-06-23 10:59:38.730654
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.data import InventoryData
    i = InventoryData()
    im = InventoryModule()
    path = './tests/inventory_parser/toml/test.toml'
    im.parse(i, None, path, cache=False)
    assert 'ungrouped' in i.groups
    assert 'g1' in i.groups
    assert 'g2' in i.groups
    assert i.groups['g1'].get_host('localhost')
    assert i.groups['g2'].get_host('localhost')
    assert len(i.groups['g1'].get_host('localhost').vars) == 0
    assert len(i.groups['g2'].get_host('localhost').vars) == 0
    assert len(i.groups['g1'].hosts) == 1
    assert len

# Generated at 2022-06-23 10:59:41.936617
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file("test.ini") == False
    assert InventoryModule.verify_file("test.toml") == True
    assert InventoryModule.verify_file("test.yaml") == False
    assert InventoryModule.verify_file("test.yml") == False
    assert InventoryModule.verify_file("test.json") == False



# Generated at 2022-06-23 10:59:51.295501
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnsafeBytes, AnsibleUnsafeText, AnsibleUnicode

# Generated at 2022-06-23 11:00:02.185918
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    x = InventoryModule()
    assert (x.NAME == 'toml')
    y = x._load_file("../../inventory/toml/hosts")
    assert (y != None)
    y = x._parse_group("testgroup", None)
    assert (y == None)
    y = x._parse_group("testgroup", {'vars': None})
    assert (y == None)
    y = x._parse_group("testgroup", {'children': None})
    assert (y == None)
    y = x._parse_group("testgroup", {'hosts': None})
    assert (y == None)
    assert (isinstance(x.parse("inventory", "loader", "path"), NoneType))

# Generated at 2022-06-23 11:00:10.313286
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    data = AnsibleLoader(EXAMPLES).get_single_data()

    variable_manager = VariableManager()
    variable_manager.extra_vars = {'ansible_connection': 'local'}
    loader = DataLoader()
    inventory = InventoryManager(loader, variable_manager,
                                 host_list=[])

    inventory.add_group('all')
    inventory.add_group('ungrouped')

    inventory.add_host(host=u'host1')
    inventory.add_host(host=u'host2')

# Generated at 2022-06-23 11:00:16.627277
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    obj = {
        'k1': 1,
        'k2': 2,
        'k3': AnsibleSequence([1, 2, 3]),
        'k4': AnsibleUnicode(b'xyz'),
        'k5': AnsibleUnsafeText(b'abc'),
    }
    expected = {
        'k1': 1,
        'k2': 2,
        'k3': [1, 2, 3],
        'k4': 'xyz',
        'k5': 'abc',
    }

    converted = convert_yaml_objects_to_native(obj)

    assert expected == converted

# Generated at 2022-06-23 11:00:23.909223
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    i_toml = InventoryModule()
    loader = 'AnsibleLoader'
    path = 'ansible/plugins/inventory/test/inventory_files/test_toml_plugin.toml'
    cache = True
    # Test normal execution
    i_toml.parse(i_toml.inventory, loader, path, cache)
    # Test bad json file
    path = 'ansible/plugins/inventory/test/inventory_files/test_toml_plugin_bad.toml'
    i_toml.parse(i_toml.inventory, loader, path, cache)

# Generated at 2022-06-23 11:00:25.884311
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert isinstance(inv_mod, InventoryModule)


# Generated at 2022-06-23 11:00:30.634654
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """Unit test for constructor of class InventoryModule"""
    from ansible.plugins.loader import inventory_loader
    source_data = inventory_loader._create_source_data('toml', '', {})
    inv_module = InventoryModule(source_data)
    assert isinstance(inv_module, InventoryModule)
    assert inv_module.NAME == 'toml'

# Generated at 2022-06-23 11:00:37.130145
# Unit test for function toml_dumps
def test_toml_dumps():
    # Basic test, just check the output is correct using sample data
    assert toml_dumps({'title': 'TOML Example'}) == 'title = "TOML Example"\n'
    # Since we are using the same TOML library for load and dump, we expect
    # this to pass with only format differences. This serves as a smoke test
    # for our TOML dump function
    test_data = toml.loads(EXAMPLES)
    assert toml_dumps(test_data) == EXAMPLES

# Generated at 2022-06-23 11:00:48.740796
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    """Tests our convert_yaml_objects_to_native() function"""
    input_data = {
        'a': AnsibleUnsafeText('foo'),
        'b': AnsibleSequence(['bar', 'zar']),
        'c': AnsibleUnsafeBytes(b'baz'),
        'd': {
            'e': [
                AnsibleUnsafeText('e1'),
                AnsibleUnsafeText('e2'),
            ],
        },
    }

    expected_output = {
        'a': 'foo',
        'b': ['bar', 'zar'],
        'c': 'baz',
        'd': {
            'e': ['e1', 'e2'],
        },
    }

    test_output = convert_yaml_objects_to_native(input_data)
   

# Generated at 2022-06-23 11:00:56.066492
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    agent = InventoryModule()
    toml_string = '''
[group_1]
hosts = {host_1={},host_2={}}
vars = {http_port=8080}
children = [group_2]
'''
    toml_string_bad = '''
[group_1]
hosts = {host_1={},host_2={}}
vars = {http_port=8080}
children = [group_2]

[group_2]
vars = {foo={}}
'''

    class Inventory(object):
        def __init__(self):
            self.host_vars = {}

        def add_group(self, group):
            return group

        def add_child(self, group, subgroup):
            pass


# Generated at 2022-06-23 11:00:58.600814
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert isinstance(im.NAME, string_types)
    assert isinstance(im.display, Display)

# Generated at 2022-06-23 11:01:05.816450
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    if not hasattr(toml, 'TomlEncoder'):
        from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

        seq = AnsibleSequence(["test", "test2", "test3"])
        assert convert_yaml_objects_to_native(seq) == ["test", "test2", "test3"]

        d = AnsibleMapping({
            'k1': 'v1',
            'k2': 'v2',
            'k3': 'v3'
        })

# Generated at 2022-06-23 11:01:08.154892
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.NAME == 'toml'
    assert module._options == {}


# Generated at 2022-06-23 11:01:18.980986
# Unit test for function toml_dumps
def test_toml_dumps():

    # First, test with a vanilla python dict
    x = {
        'foo': 'bar',
        'bar': 'baz',
        'baz': 'qux'
    }
    # Should just return the dict as a string
    assert toml_dumps(x) == "{bar = \"baz\", baz = \"qux\", foo = \"bar\"}"

    # Next, test with custom AnsibleUnicode, AnsibleUnsafeText, and AnsibleUnsafeBytes objects
    y = {
        'foo': AnsibleUnicode('bar'),
        'bar': AnsibleUnsafeText('baz'),
        'baz': AnsibleUnsafeBytes('qux')
    }
    # Should return the strings as native strings

# Generated at 2022-06-23 11:01:28.825067
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    input_dict = {
        "all": {
            "vars": {
                "has_java": False
            },
            "hosts": {
                "host1": {},
                "host2": {
                    "ansible_port": "22"
                },
                "host3": {
                    "ansible_port": "22"
                }
            },
            "children": [
                "ungrouped",
                "g1",
                "g2"
            ]
        }
    }

    output_dict = convert_yaml_objects_to_native(input_dict)


# Generated at 2022-06-23 11:01:38.726087
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    assert(convert_yaml_objects_to_native(dict(foo=AnsibleUnicode("bar"))) == {"foo": "bar"})
    assert(convert_yaml_objects_to_native(dict(foo=AnsibleMapping({"bar": "foo"}))) == {"foo": {"bar": "foo"}})
    assert(convert_yaml_objects_to_native(dict(foo=AnsibleSequence([1,2,3]))) == {"foo": [1,2,3]})

# Generated at 2022-06-23 11:01:51.020520
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from collections import namedtuple
    from ansible.module_utils.six import PY3
    from ansible.plugins.inventory.toml import InventoryModule

    test_file_contents = '''\
    [group1]
    host1
    
    [group1:vars]
    var1=value1
    var2=value2
    '''
    test_file_name = 'test_file'
    
    FileContentsResult = namedtuple('FileContentsResult', ['contents', 'path'])
    def file_contents(path):
        return FileContentsResult(test_file_contents, path)

    # Note that this test also covers the code at the start of the method
    # which may raise an exception.
    module = InventoryModule()
    module.loader = MockLoader(file_contents)


# Generated at 2022-06-23 11:01:51.678750
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_module = InventoryModule()

# Generated at 2022-06-23 11:02:03.032317
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    mod = InventoryModule()
    path = '/tmp/test-file-does-not-exist.toml'
    assert mod.verify_file(path) == False, "verify_file should return False for path that does not exist"
    path = '/tmp/test-file-does-not-exist.yaml'
    assert mod.verify_file(path) == False, "verify_file should return False for path that does not exist"
    path = '/tmp/test-file-does-not-exist'
    assert mod.verify_file(path) == False, "verify_file should return False for path that does not exist"
    path = '/tmp/test-file-exists.toml'
    with open(path, 'w'):
        os.utime(path, None)
    assert mod.verify

# Generated at 2022-06-23 11:02:13.350363
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader
    data_loader = DataLoader()
    toml_data = EXAMPLES.strip()
    data_loader.set_basedir("/")
    inventory_mod = InventoryModule(loader=data_loader)
    inventory_mod.parse(toml_data, cache=True)
    assert len(inventory_mod.inventory.hosts) == 4
    assert len(inventory_mod.hosts) == 4
    assert len(inventory_mod.groups) == 5
    assert len(inventory_mod.inventory.groups) == 5
    assert len(inventory_mod.inventory.get_groups_dict("all")) == 3
    assert len(inventory_mod.inventory.get_groups_dict("all", vault_password=None)) == 3

# Generated at 2022-06-23 11:02:14.885368
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    path = 'path/to/file/inventory.toml'
    assert inventory.verify_file(path) == True

    path = 'path/to/file/inventory.yaml'
    assert inventory.verify_file(path) == False

# Generated at 2022-06-23 11:02:17.841609
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file('file_path') == False
    assert InventoryModule().verify_file('file_path.toml') == True


# Generated at 2022-06-23 11:02:29.925418
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import yaml
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.representer import AnsibleRepresenter

    # Create a yaml object mapping

# Generated at 2022-06-23 11:02:32.529539
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps(dict(foo='bar', a=(1, 2, 3))) == '[foo]\na = [1, 2, 3]\n'

# Generated at 2022-06-23 11:02:41.037707
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    loader = DummyLoader()
    parser = InventoryModule()
    print(parser.parse(None, loader, 'my_toml.toml'))

import unittest
from ansible.module_utils.six.moves import StringIO
from ansible.module_utils import basic

from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence
from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText


# Generated at 2022-06-23 11:02:44.435558
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file(path='./inventory/hosts.toml')
    assert not InventoryModule().verify_file(path='./inventory/hosts.yml')


# Generated at 2022-06-23 11:02:53.314304
# Unit test for function toml_dumps
def test_toml_dumps():
    data = [
        {'str': 'str'},
        {'int': 1},
        {'float': 1.0},
        {'bool': True},
        {'null': None},
        {'list': ['item']},
        {'dict': {'item': 'item'}},
        {'unsafe_bytes': AnsibleUnsafeBytes('unsafe_bytes')},
        {'unsafe_text': AnsibleUnsafeText('unsafe_text')}
    ]

    # Test data
    assert toml_dumps(data) == toml.dumps(data)

# Generated at 2022-06-23 11:02:57.505758
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    path = "/data/ansible/ansible/inventory/inventory_sources/ec2.ini"
    assert inventory_module.verify_file(path) is False


# Generated at 2022-06-23 11:03:08.764555
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    seq = AnsibleSequence([
        AnsibleUnicode('unicode'),
        AnsibleUnsafeBytes(b'bytes'),
        AnsibleUnsafeText(to_text(b'bytes', errors='surrogate_or_strict'))
    ])
    result = convert_yaml_objects_to_native(seq)
    assert isinstance(result, list)
    assert all(isinstance(i, text_type) for i in result)

    safe_text = convert_yaml_objects_to_native(AnsibleUnsafeText('foo'))
    assert isinstance(safe_text, text_type)

    safe_bytes = convert_yaml_objects_to_native(AnsibleUnsafeBytes('foo'))
    assert isinstance(safe_bytes, text_type)

# Generated at 2022-06-23 11:03:19.097809
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import ansible.parsing.yaml.objects
    ansible.parsing.yaml.objects.AnsibleBaseYAMLObject = str
    yaml_obj = {
        'AnsibleSequence': ansible.parsing.yaml.objects.AnsibleSequence([1, 2]),
        'AnsibleUnicode': ansible.parsing.yaml.objects.AnsibleUnicode('foo'),
        'AnsibleUnsafeBytes': ansible.parsing.yaml.objects.AnsibleUnsafeBytes(b'bar'),
        'AnsibleUnsafeText': ansible.parsing.yaml.objects.AnsibleUnsafeText('baz')
    }

# Generated at 2022-06-23 11:03:25.340071
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module_obj = InventoryModule()

# Generated at 2022-06-23 11:03:28.030845
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    obj = InventoryModule()
    success = False
    try:
        obj.verify_file('test.toml')
        success = True
    except AttributeError:
        pass
    assert success


# Generated at 2022-06-23 11:03:39.793031
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-23 11:03:44.203573
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_file = '''[ungrouped.hosts]
host1 = {}
host2 = { ansible_host = "127.0.0.1", ansible_port = 44 }
host3 = { ansible_host = "127.0.0.1", ansible_port = 45 }

[g1.hosts]
host4 = {}

[g2.hosts]
host4 = {}
'''

# Generated at 2022-06-23 11:03:49.775253
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventoryModule = InventoryModule()
    assert inventoryModule.verify_file('hosts.yml') == True
    assert inventoryModule.verify_file('hosts.toml') == True
    assert inventoryModule.verify_file('hosts.ini') == False
    assert inventoryModule.verify_file('hosts.py') == False

# Generated at 2022-06-23 11:03:53.866964
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    type(None)
    # Line added to silence pylint warning
    print("test_InventoryModule_parse")
    # TODO Write a unit test for method InvtoryModule_parse
    # assert False

# Generated at 2022-06-23 11:04:03.001694
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    c = InventoryModule()
    assert c.NAME == 'toml'
    dirname = os.path.dirname(os.path.realpath(__file__))
    ex = list(c.parse(None, None, os.path.join(dirname, 'data/test.toml')))

# Generated at 2022-06-23 11:04:15.376169
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    def get_inventory(file_name, host_pattern, hosts=None, port=None, group_name=None, vars=None):
        inventory = MockInventory()
        inventory.get_hosts.return_value = hosts or []
        inventory.expand_hostpattern.return_value = (hosts or [], port or [])
        inventory.add_group.return_value = group_name or 'dummy_group_name'
        inventory.set_variable.return_value = vars or {}
        inventory.add_child.return_value = True
        inventory.get_groups.return_value = [group_name or 'dummy_group_name']

        loader = MockLoader()
        loader.path_dwim.return_value = file_name
        loader.path_exists.return_value = True
       

# Generated at 2022-06-23 11:04:16.948618
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    invmod = InventoryModule()
    assert invmod

# Generated at 2022-06-23 11:04:26.912192
# Unit test for function toml_dumps
def test_toml_dumps():

    mydict = dict()
    mydict['foo'] = 'bar'
    mydict['baz'] = 'meh'
    mydict['empty'] = ''
    mydict['none'] = None
    mydict['unquoted_string_with_special_chars'] = '$@:+'
    mydict['true'] = True
    mydict['false'] = False
    mydict['integer'] = 1
    mydict['negative_integer'] = -5
    mydict['float'] = 1.3
    mydict['negative_float'] = -5.2

# Generated at 2022-06-23 11:04:38.169922
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    test = [
        {'ansibleseq1': AnsibleSequence([1, 2, 3])},
        {'ansibleseq2': AnsibleSequence([1, 2, AnsibleUnicode('3')])}
    ]
    assert test == convert_yaml_objects_to_native(test)

# Generated at 2022-06-23 11:04:48.851350
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.objects import AnsibleSequence

    a = toml_dumps({'a': 'b'})
    assert isinstance(a, str)
    assert 'a' in a
    assert 'b' in a
    assert '{' in a
    assert '}' in a

    b = toml_dumps({'a': AnsibleMapping(foo='bar')})
    assert isinstance(b, str)
    assert 'a' in b
    assert 'foo' in b
    assert 'bar' in b
    assert '{' in b
    assert '}' in b

    c = toml_dumps({'a': AnsibleSequence('b')})

# Generated at 2022-06-23 11:04:57.111030
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    for path, expected_valid in (
        ('/tmp/hosts', False),
        ('/tmp/hosts.txt', False),
        ('/tmp/hosts.toml', True),
    ):
        actual_valid = InventoryModule().verify_file(path)
        error_msg = "Expected %s to be %s, got %s" % (path, expected_valid, actual_valid)
        assert actual_valid == expected_valid, error_msg

# Generated at 2022-06-23 11:05:08.374173
# Unit test for function toml_dumps
def test_toml_dumps():
    # text
    assert 'foo = "bar"' in toml_dumps(dict(foo='bar'))
    # byte string
    assert 'foo = "bár"' in toml_dumps(dict(foo=b'b\xc3\xa1r'))
    # bool
    assert 'foo = true' in toml_dumps(dict(foo=True))
    # integer
    assert 'foo = 42' in toml_dumps(dict(foo=42))
    # float
    assert 'foo = 3.14' in toml_dumps(dict(foo=3.14))
    # date
    assert 'foo = 1987-07-05T17:45:00Z' in toml_dumps(dict(foo='1987-07-05T17:45:00Z'))
    # datetime
   

# Generated at 2022-06-23 11:05:19.764349
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    host_list = [u'host1', u'host2', u'host3']
    group_list = [u'g1', u'g2']
    child_list = [u'web', u'apache', u'nginx']
    hostvars = {
        u'host1': { u'http_port': 8080, u'has_java': False },
        u'host2': { u'ansible_port': 222, u'has_java': False },
        u'host3': { u'ansible_port': 222, u'has_java': False },
        u'host4': { u'has_java': False },
    }

# Generated at 2022-06-23 11:05:29.786391
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode

    # Test dict
    test_dict = {
        'a': 'a',
        'b': AnsibleUnsafeText('ulgymla3290fasdfasdf'),
        'c': ['a', 'b', AnsibleUnsafeText('adsfasdfasdf')],
        'd': {
            'e': AnsibleUnsafeText('asdfasdfasdf'),
            'f': ['a', AnsibleUnsafeText('asdfasdfasdf')]
        }
    }

    new_dict = convert_yaml_objects_to_native(test_dict)
    assert isinstance(new_dict['b'], text_type)
    assert new_dict['b'] == test_dict['b']


# Generated at 2022-06-23 11:05:41.637978
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText
    import yaml


# Generated at 2022-06-23 11:05:51.595196
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    from ansible.plugins.loader import inventory_loader

    inv_plugin = inventory_loader.get('toml')
    assert inv_plugin.verify_file('/dummy/path/to/inventory.toml')

    inv_plugin = inventory_loader.get('ini')
    assert not inv_plugin.verify_file('/dummy/path/to/inventory.toml')
    assert not inv_plugin.verify_file('/dummy/path/to/inventorytoml')
    assert not inv_plugin.verify_file('/dummy/path/to/inventory')

    inv_plugin = inventory_loader.get('auto')
    assert inv_plugin.verify_file('/dummy/path/to/inventory.toml')

# Generated at 2022-06-23 11:06:01.225682
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    loader = open('tests/inventory/inventory_toml_test.toml')
    path = os.path.realpath('tests/inventory/inventory_toml_test.toml')
    inventory.parse(inventory, loader, path, cache=True)

    assert inventory.parse(inventory, loader, path, cache=True)
    assert inventory._parse_group('group_name', {'a': 1})
    assert inventory._parse_group('group_name', {'a': 1, 'b': 2})
    assert inventory._parse_group('group_name', {'a': 1, 'b': 2, 'c': 3})
    assert inventory._parse_group('group_name', {'a': 1, 'b': 2, 'c': 3, 'd': 4})

# Generated at 2022-06-23 11:06:06.497852
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    print("Test: method verify_file of class InventoryModule")
    file_name, ext = os.path.splitext(path)
    if ext == '.toml':
        assert True
    else:
        assert False


# Generated at 2022-06-23 11:06:12.377219
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import sys
    import textwrap
    from unit.plugins.inventory.toml.test_toml_inventory import (
        MockVarsModule,
        MockOptionsModule,
        MockInventoryModule,
        MockAllModule,
    )
    from ansible.module_utils.six import PY3
    from ansible.module_utils.common._collections_compat import (
        MutableMapping,
    )
    from ansible.module_utils.six import string_types

    inventory = MockInventoryModule()

    inventory_path = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'test.toml'
    )

    # create a test inventory TOML file

# Generated at 2022-06-23 11:06:13.548733
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()


# Generated at 2022-06-23 11:06:14.973632
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    m = InventoryModule()
    assert isinstance(m, InventoryModule)

# Generated at 2022-06-23 11:06:18.370610
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule({}).verify_file('test.toml')

# Generated at 2022-06-23 11:06:20.344026
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    path = '/tmp/inventory.toml'
    return InventoryModule.verify_file(path)



# Generated at 2022-06-23 11:06:22.095553
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert verifier.verify_file('inventory.toml')


# Generated at 2022-06-23 11:06:23.232269
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    module = InventoryModule()

    assert module is not None


# Generated at 2022-06-23 11:06:30.927970
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleMapping
    assert convert_yaml_objects_to_native({'foo': 'bar'}) == {'foo': 'bar'}
    assert convert_yaml_objects_to_native({'foo': 'bar', 'baz': 3}) == {'foo': 'bar', 'baz': 3}
    assert convert_yaml_objects_to_native({'foo': 'bar', 'baz': [1, 2, 3]}) == {'foo': 'bar', 'baz': [1, 2, 3]}

# Generated at 2022-06-23 11:06:35.727601
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.vars.unsafe_proxy import AnsibleVaultUnsafeText

    assert convert_yaml_objects_to_native({'a': AnsibleUnicode('b')}) == {'a': 'b'}
    assert convert_yaml_objects_to_native({'a': AnsibleUnsafeBytes('b')}) == {'a': b'b'}
    assert convert_yaml_objects_to_native({'a': AnsibleUnsafeText('b')}) == {'a': 'b'}
    assert convert_yaml_objects_to_native([AnsibleUnicode('b')]) == ['b']

# Generated at 2022-06-23 11:06:46.703030
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native(1) == 1
    assert convert_yaml_objects_to_native(1.3) == 1.3
    assert convert_yaml_objects_to_native(True) is True
    assert convert_yaml_objects_to_native(None) is None
    assert convert_yaml_objects_to_native(u'test') == u'test'
    assert convert_yaml_objects_to_native(u'café') == u'café'
    assert convert_yaml_objects_to_native(u'café'.encode('utf-8')) == u'café'

# Generated at 2022-06-23 11:06:54.796325
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native({
        "a": {
            "b": {
                "c": [
                    1,
                    2,
                    3,
                    4
                ]
            }
        }
    }) == {
        "a": {
            "b": {
                "c": [
                    1,
                    2,
                    3,
                    4
                ]
            }
        }
    }

    assert convert_yaml_objects_to_native({
        "a": {
            "b": {
                "c": AnsibleSequence([1, 2, 3, 4])
            }
        }
    }) == {
        "a": {
            "b": {
                "c": [1, 2, 3, 4]
            }
        }
    }

    assert convert

# Generated at 2022-06-23 11:06:58.630959
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    m = InventoryModule()
    assert m.verify_file('/tmp/test.toml')
    assert not m.verify_file('/tmp/test.yml')
    assert not m.verify_file('/tmp/test')
    assert not m.verify_file('/tmp/test.yml.yml')
    assert not m.verify_file('/tmp/test.toml.toml')
    assert not m.verify_file('/tmp/test.yml.toml')


# Generated at 2022-06-23 11:07:05.365770
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_obj = InventoryModule()
    assert (inv_obj.verify_file("./test.wait") is False)
    assert (inv_obj.verify_file("./test.toml") is True)
    assert (inv_obj.verify_file(None) is False)
    assert (inv_obj.verify_file("./test.txt") is False)
    assert (inv_obj.verify_file("./test") is False)

# Generated at 2022-06-23 11:07:08.429011
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    a = InventoryModule()
    path = 'test/test.toml'
    res = a.verify_file(path)
    assert res == True
    path = 'test/test.ini'
    res = a.verify_file(path)
    assert res == False


# Generated at 2022-06-23 11:07:15.846430
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native(AnsibleSequence(['a', 'b'])) == ['a', 'b']
    assert convert_yaml_objects_to_native(AnsibleUnicode('abc')) == 'abc'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes(b'abc')) == 'abc'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('abc')) == 'abc'