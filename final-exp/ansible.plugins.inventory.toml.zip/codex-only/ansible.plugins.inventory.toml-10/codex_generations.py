

# Generated at 2022-06-23 10:57:21.096130
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import json
    import pytest

    from ansible.plugins.loader import toml_loader

    path = 'testdata/toml/test_InventoryModule_parse.toml'
    inventory = {}
    loader = toml_loader.TOMLDataLoader()
    toml_inv = InventoryModule(loader)

    toml_inv.parse(inventory, loader, path, cache=True)

    assert (os.path.expanduser("~/.ansible_toml") not in inventory)
    assert (inventory["all"] == {"vars": {"has_java": False}})
    assert (inventory["all"]["children"] == ["g1", "g2"])
    assert (inventory["all"]["hosts"] == ["localhost", "127.0.0.1"])

# Generated at 2022-06-23 10:57:29.214564
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    text = '''# group
[group]
hosts = ["host1", "host2"]
vars = {
  foo = "bar",
  baz = "bar",
}
children = ["subgroup1"]
'''
    _inventory = InventoryModule()
    _inventory.parse(text, None, None)
    assert _inventory.inventory.get_host('host1').vars['foo'] == 'bar'
    assert _inventory.inventory.get_group('group').vars['baz'] == 'bar'


# Generated at 2022-06-23 10:57:37.546841
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    input_obj = dict(
        type1=AnsibleSequence([AnsibleUnicode('123'), AnsibleUnicode('456'), AnsibleUnicode('789')]),
        type2=AnsibleUnsafeBytes('123'),
        type3=AnsibleUnsafeText('456'),
        type4=AnsibleUnicode('789')
    )

    expected_output = dict(
        type1=[text_type('123'), text_type('456'), text_type('789')],
        type2=text_type('123'),
        type3=text_type('456'),
        type4=text_type('789')
    )

    assert convert_

# Generated at 2022-06-23 10:57:47.542322
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import to_unsafe_text, to_unsafe_bytes

    data = {
        'a': to_unsafe_text('foo'),
        'b': to_unsafe_bytes('bar'),
        'c': AnsibleSequence([to_unsafe_text('foo'), to_unsafe_bytes('bar')]),
        'd': AnsibleUnicode(to_unsafe_text('foo')),
    }


# Generated at 2022-06-23 10:57:49.975195
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory.NAME == 'toml'


# Generated at 2022-06-23 10:57:58.285620
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing import vault
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # Unsafe text is one of our special types we treat as a string
    assert isinstance(convert_yaml_objects_to_native(AnsibleUnsafeText('foo')), text_type)
    assert not isinstance(convert_yaml_objects_to_native(AnsibleUnsafeText('foo')), AnsibleUnsafeText)

    # Make sure our function doesn't change native types
    assert isinstance(convert_yaml_objects_to_native('foo'), text_type)
    assert isinstance(convert_yaml_objects_to_native(['foo', 'bar']), list)

# Generated at 2022-06-23 10:58:06.997791
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import unittest
    try:
        from unittest.mock import patch, MagicMock
    except ImportError:
        from mock import patch, MagicMock
    from ansible.plugins.inventory.toml import InventoryModule

    class TestInventoryModuleVerifyFile(unittest.TestCase):
        @classmethod
        def setUpClass(cls):
            cls._patcher1 = patch('os.path.splitext', return_value=('test', '.toml'))
            cls._patcher1.start()
            cls._patcher2 = patch.object(InventoryModule, 'verify_file')
            cls._patcher3 = patch.object(InventoryModule, 'set_options')
            cls.mock_verify_file = cls._patcher2.start()
           

# Generated at 2022-06-23 10:58:09.275352
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file(path=__file__) == False
    assert InventoryModule().verify_file(path="../../docs/inventory/sample_static.toml") == True


# Generated at 2022-06-23 10:58:21.057073
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleDict, AnsibleSequence, AnsibleUnicode, AnsibleUnsafeText
    assert convert_yaml_objects_to_native(AnsibleDict({'key': 'value'})) == {'key': 'value'}
    assert convert_yaml_objects_to_native(AnsibleDict({'key': AnsibleUnicode('value')})) == {'key': 'value'}
    assert convert_yaml_objects_to_native(AnsibleDict({'key': AnsibleUnsafeText('value')})) == {'key': 'value'}
    assert convert_yaml_objects_to_native(AnsibleSequence(['value', AnsibleUnicode('value')])) == ['value', 'value']

# Generated at 2022-06-23 10:58:22.827583
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert isinstance(im, InventoryModule)


# Unit tests for method _parse_group

# Generated at 2022-06-23 10:58:34.133125
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # The only purpose of this test is to ensure that the types from
    # ``ansible.parsing.yaml.objects`` are correctly translated into their
    # native types, so that ``toml`` does not complain about it
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText
    assert convert_yaml_objects_to_native(['foo', 'bar']) == ['foo', 'bar']
    assert convert_yaml_objects_to_native(AnsibleSequence(['foo', 'bar'])) == ['foo', 'bar']
    assert convert_yaml_objects_to_native(AnsibleUnicode('foo')) == 'foo'

# Generated at 2022-06-23 10:58:36.385867
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    i = InventoryModule()
    # Testing constructor of InventoryModule
    assert isinstance(i, InventoryModule)

# Generated at 2022-06-23 10:58:41.517478
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Unit test for method parse of class InventoryModule
    """
    module = InventoryModule()
    # pylint: disable=protected-access
    method = module._get_method('parse')
    assert method
    assert method.__name__ == 'parse'
    assert method.__doc__


# Generated at 2022-06-23 10:58:45.154956
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {
        'foo': 'bar',
        'baz': [1, 2, 3],
        'answer': {
            'the': 42
        }
    }

    assert toml_dumps(data) == '''[answer]\nthe = 42

[baz]\n1\n2\n3

[foo]\nbar = ""
'''

# Generated at 2022-06-23 10:58:52.059902
# Unit test for function toml_dumps
def test_toml_dumps():
    """
    >>> import toml
    >>> toml.loads(toml_dumps({ 'lib': { 'version': '1.0.0' }, 'title': 'TOML Example', 'owner': { 'github': 'mojombo' } }))
    {
        'lib': { 'version': '1.0.0' },
        'title': 'TOML Example',
        'owner': { 'github': 'mojombo' }
    }
    """
    # Dummy test to allow test_toml_dumps to be removed from documentation

# Generated at 2022-06-23 10:58:57.634827
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'test': 'asdf'}) == 'test = "asdf"\n'
    assert toml_dumps({'test': {'asdf': 'fdsa'}}) == 'test = {}\n\n[test]\nasdf = "fdsa"\n'
    assert toml_dumps({'test': [1, 2]}) == 'test = [1, 2]\n'


# Generated at 2022-06-23 10:59:02.392407
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    if HAS_TOML:
        assert InventoryModule(MockInventory()).verify_file('/file/path/file.toml')
        assert not InventoryModule(MockInventory()).verify_file('/file/path/file.yaml')
        assert not InventoryModule(MockInventory()).verify_file('/file/path/file.json')
        assert not InventoryModule(MockInventory()).verify_file('')



# Generated at 2022-06-23 10:59:07.472847
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    assert convert_yaml_objects_to_native(AnsibleSequence()) == []
    assert convert_yaml_objects_to_native(AnsibleUnicode('foo')) == 'foo'
    assert convert_yaml_objects_to_native({'foo': {'bar': 'baz'}}) == {'foo': {'bar': 'baz'}}
    assert convert_yaml_objects_to_native([
        AnsibleSequence([
            AnsibleUnicode('foo'),
            AnsibleUnicode('bar')
        ])
    ]) == [
        ['foo', 'bar']
    ]

# Generated at 2022-06-23 10:59:17.722207
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    source = '''
[webservers]
    foo.example.org
    bar.example.org
[dbservers]
    one.example.org
    two.example.org
    three.example.org
'''
    loader = DataLoader()
    inv = InventoryModule(loader, variable_manager=VariableManager(), host_list=source)
    assert inv
    assert inv.loader
    assert inv.host_list  # source
    assert inv.groups.get('webservers')
    assert inv.groups.get('dbservers')
    assert inv.groups.get('webservers').get_hosts()[0].name == 'foo.example.org'

# Generated at 2022-06-23 10:59:21.220836
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import collections

    # Instantiate class
    test_instance = InventoryModule()

    # Verify isinstance
    assert isinstance(test_instance, collections.Callable)

    # __init__ should set loader attribute
    assert hasattr(test_instance, 'loader')

# Generated at 2022-06-23 10:59:29.729481
# Unit test for function toml_dumps

# Generated at 2022-06-23 10:59:36.183157
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()

    fake_path = os.path.join(os.path.dirname(__file__), 'foo', 'bar')

    assert inv.verify_file(fake_path) == False

    fake_path = os.path.join(os.path.dirname(__file__), 'foo', 'bar.toml')

    assert inv.verify_file(fake_path) == True

# Generated at 2022-06-23 10:59:43.110121
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {
        'a': {
            'b': ['c', 'd'],
            'e': {'f': 'g'},
        }
    }
    dumped = toml_dumps(data)
    assert dumped == '[a]\n' \
        'b = ["c", "d"]\n' \
        'e = {f = "g"}\n' \

    dumped2 = toml_dumps(data)
    assert dumped == dumped2

# Generated at 2022-06-23 10:59:52.317319
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-23 11:00:05.069000
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    plugin = InventoryModule()

    inv = AnsibleInventory(loader=None, variable_manager=None, host_list=None)
    inv.groups = {}
    inv.patterns = {}
    inv.hosts = {}

    # Normal group with hosts
    data = toml_dumps({
        'web': {
            'hosts': {
                'host1': {},
                'host2': {'ansible_port': 222},
            }
        }
    })

    plugin.parse('path', inv, data)
    assert inv.groups['web'].name == 'web'
    assert inv.groups['web'].vars == {}
    assert inv.groups['web'].children == []

# Generated at 2022-06-23 11:00:14.213475
# Unit test for function toml_dumps
def test_toml_dumps():
    # Ensure that TOML output is always bytes, not text
    assert isinstance(toml_dumps({'unicode': text_type('foo')}), bytes)
    assert isinstance(toml_dumps({'bytes': to_bytes('foo')}), bytes)
    # Ensure TOML output is actually valid TOML
    assert to_text(toml_dumps({'unicode': text_type('foo')}), encoding='utf-8') == text_type('''[unicode]\nunicode = "foo"\n''')
    assert to_text(toml_dumps({'bytes': to_bytes('foo')}), encoding='utf-8') == text_type('''[bytes]\nbytes = "foo"\n''')

# Generated at 2022-06-23 11:00:18.415340
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'foo': 'bar', 'list': ['one', 'two']}) == 'foo = "bar"\nlist = [\n  "one",\n  "two"\n]\n'

# Generated at 2022-06-23 11:00:30.426793
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Given
    context = {
        'sources': [''],
    }

# Generated at 2022-06-23 11:00:32.599821
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    loader = Display()
    inventory = Display()
    InventoryModule(loader,inventory,path = '/home/ansible/unittest_inventory.yml')

# Generated at 2022-06-23 11:00:40.519981
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # This is a dummy class for testing purpose
    class DummyInventoryModule(InventoryModule):
        def __init__(self):
            super(InventoryModule, self).__init__()
            self.PATH = ''
            self.loader = None
            self.parser = None
            self.host_pattern = None
            self.cache = False

    # Create new object of class DummyInventoryModule
    o = DummyInventoryModule()

    # Set PATH to a valid TOML file
    o.PATH = "test/test.toml" 
    result = o.verify_file(o.PATH)
    # Verify the result
    assert result == True


# Generated at 2022-06-23 11:00:50.746814
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    test_obj = {
        u'http_port': AnsibleUnicode(8080),
        u'myvar': 23,
        u'mysecret': AnsibleUnicode(u'03#pa33w0rd'),
        u'children': AnsibleSequence([u'apache', u'nginx'])
    }
    fd = BytesIO()
    toml_dumps(test_obj, stream=fd)

# Generated at 2022-06-23 11:01:01.097235
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule(None, None)._get_base_subclass() is BaseFileInventoryPlugin
    host_list = [
        'host1', 'host2', 'host4'
    ]
    group = 'all.vars'
    group_data = {
        'hosts': {
            'host1': {},
            'host2': {},
        },
        'children': [
            'g1',
            'g2'
        ]
    }
    child_group_data = {
        'hosts': {
            'host4': {},
        },
    }
    assert InventoryModule(None, None)._parse_group(group, group_data) == host_list

# Generated at 2022-06-23 11:01:02.557576
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins.loader import find_plugin
    assert find_plugin(InventoryModule.NAME, 'inventory') == InventoryModule

# Generated at 2022-06-23 11:01:14.178263
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''Unit test for method verify_file of class InventoryModule'''
    # Test with a path that ends with .toml
    path = 'path_to_my_file.toml'
    inventory_module = InventoryModule()
    assert inventory_module.verify_file(path)

    # Test with a path that ends with .toml.
    path = 'path_to_my_file.toml.'
    assert not inventory_module.verify_file(path)

    # Test with a path that ends with .
    path = 'path_to_my_file.'
    assert not inventory_module.verify_file(path)


# Generated at 2022-06-23 11:01:22.547962
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    data = {
        AnsibleUnicode("foo"): 1,
        "bar": AnsibleMapping({
            AnsibleUnicode("baz"): AnsibleUnicode("blah"),
            "blah": AnsibleUnicode("baz"),
        }),
        "biz": AnsibleSequence([
            AnsibleMapping({
                AnsibleUnicode("biz1"): 1,
                "biz2": 2,
            }),
            AnsibleMapping({
                AnsibleUnicode("biz3"): 3,
                "biz4": 4,
            }),
        ]),
    }

# Generated at 2022-06-23 11:01:28.572818
# Unit test for function toml_dumps
def test_toml_dumps():
    """Ensure toml_dumps encodes data as TOML"""
    import toml
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    data = loader.load_from_file(loader.path_dwim(__file__).replace('.py', '.toml'))

    try:
        assert toml.loads(toml_dumps(data)) == toml.loads(toml.dumps(data))
    except AssertionError:
        raise AssertionError('TOML dumps failed encoding')

# Generated at 2022-06-23 11:01:38.564298
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # initialize variables
    inv_module = InventoryModule()
    inv_module.loader = mock.MagicMock()
    inv_module.loader.path_exists.return_value = True
    inv_module.loader.path_dwim.return_value = '/tmp/inventory.toml'
    inv_module.loader.get_basedir.return_value = '/tmp'
    inv_module.loader._get_file_contents.return_value = (to_bytes(EXAMPLES), None)

    inventory = mock.Mock()
    inventory.add_group.side_effect = lambda x: x
    inventory.add_child.side_effect = lambda x, y: None
    inventory.set_variable.side_effect = lambda x, y, z: None

    inv_module.inventory = inventory
    inv_module

# Generated at 2022-06-23 11:01:50.132234
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Dictionary containing ``ansible.parsing.yaml.objects`` objects
    unsafe_dict = {
        'foo': AnsibleUnsafeText(u'bar\u00c3'),
        'baz': AnsibleUnsafeBytes(b'qux\xc3'),
        123: [AnsibleSequence([1, 2, 3]), u'abc'],
    }

    # Dictionary containing native types
    safe_dict = {
        'foo': u'bar\u00c3',
        'baz': u'qux\u00c3',
        123: [1, 2, 3, u'abc'],
    }

    assert convert_yaml_objects_to_native(unsafe_dict) == safe_dict

# Generated at 2022-06-23 11:02:02.594579
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    assert convert_yaml_objects_to_native("string") == "string"
    assert convert_yaml_objects_to_native(1) == 1
    assert convert_yaml_objects_to_native(1.5) == 1.5
    assert convert_yaml_objects_to_native(True) == True
    assert convert_yaml_objects_to_native(False) == False
    assert convert_yaml_objects_to_native(None) == None
    assert convert_yaml_objects_to_native(AnsibleSequence(name='list', value=["a", "b"])) == ["a", "b"]
    assert convert_yaml_objects

# Generated at 2022-06-23 11:02:08.588681
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventoryModule = InventoryModule()
    path = 'test.toml'
    inventoryModule.path_exists = lambda path: True
    inventoryModule.is_file = lambda path: True
    assert inventoryModule.verify_file(path) == True

    path = 'test.yml'
    inventoryModule.path_exists = lambda path: True
    inventoryModule.is_file = lambda path: True
    assert inventoryModule.verify_file(path) == False

    path = 'test.toml'
    inventoryModule.path_exists = lambda path: False
    inventoryModule.is_file = lambda path: True
    assert inventoryModule.verify_file(path) == False

    path = 'test.toml'
    inventoryModule.path_exists = lambda path: True

# Generated at 2022-06-23 11:02:10.110382
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert inventory_module.NAME == 'toml'
    assert inventory_module.verify_file('test.toml') == True


# Generated at 2022-06-23 11:02:12.281088
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  assert InventoryModule().verify_file(path='tests/inventory/test_InventoryModule.py') == False
  assert InventoryModule().verify_file(path='tests/inventory/test_InventoryModule.py.toml') == True

# Generated at 2022-06-23 11:02:19.764002
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file("test.toml")
    assert not InventoryModule().verify_file("test.yaml")
    assert not InventoryModule().verify_file("test.yml")
    assert not InventoryModule().verify_file("test.json")
    assert not InventoryModule().verify_file("test.cfg")
    assert not InventoryModule().verify_file("test")


# Generated at 2022-06-23 11:02:24.493787
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    data = {
        'bool': True,
        'int': 1,
        'float': 1.1,
        'string': 'string',
        'list': [1, 'two', True],
        'dict': {
            'bool': True,
            'int': 1,
            'float': 1.1,
            'string': 'string',
            'list': [1, 'two', True],
            'dict': {
                'number': 1,
                'string': 'test'
            }
        }
    }

    converted_data = convert_yaml_objects_to_native(data)

    assert converted_data == data
    assert all(isinstance(v, type(data[k])) for k, v in converted_data.items())

# Generated at 2022-06-23 11:02:27.088442
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    data = {}
    display = Display()
    inventory = BaseInventoryModule(data, display)
    assert inventory.data == data
    assert inventory.display == display
    assert inventory.loader == None
    assert inventory.cache == True
    assert inventory.path == None
    assert inventory.option_cache_unparseable_files == False
    assert inventory.option_cache_timeout == 3600


# Generated at 2022-06-23 11:02:30.150424
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert HAS_TOML
    inventory = InventoryModule()
    assert isinstance(inventory, InventoryModule)


# Generated at 2022-06-23 11:02:31.406791
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert im


# Generated at 2022-06-23 11:02:42.315523
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # GIVEN
    import collections
    import mock
    import ansible.plugins.loader
    from ansible.plugins.inventory import toml

    class MockHost(object):
        def __init__(self):
            self.variables = collections.defaultdict(collections.defaultdict)
            self.groups = collections.defaultdict(collections.defaultdict)
            self.name = ''
            self.vars = self.variables
            self.groups = self.groups
            self.port = 0
        def set_variable(
                self,
                var_name,
                value
        ):
            self.variables[self.name][var_name] = value
        def set_or_merge_variable(self, var_name, value):
            self.variables[self.name][var_name] = value
       

# Generated at 2022-06-23 11:02:49.963954
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # test without types
    assert convert_yaml_objects_to_native(dict(a=1, b=2)) == dict(a=1, b=2)
    assert convert_yaml_objects_to_native(list('abcd')) == list('abcd')
    assert convert_yaml_objects_to_native('unicode') == 'unicode'
    assert convert_yaml_objects_to_native(b'bytes') == b'bytes'

    # test with types
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes(b'bytes')) == b'bytes'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('unicode')) == 'unicode'

# Generated at 2022-06-23 11:02:55.307889
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.parsing.yaml.loader import AnsibleVaultLoader


# Generated at 2022-06-23 11:03:07.456796
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps([1, 2, 3]) == '[1, 2, 3]\n'
    assert toml_dumps({'1': 1, '2': 2, '3': 3}) == '"1" = 1\n"2" = 2\n"3" = 3\n'
    assert toml_dumps({'1': [1, 2, 3]}) == '"1" = [1, 2, 3]\n'
    assert toml_dumps({'1': {'a': 1, 'b': 2}}) == '"1" = {\n  "a" = 1\n  "b" = 2\n}\n'
    assert toml_dumps(AnsibleSequence([1, 2, 3])) == '[1, 2, 3]\n'
    assert toml_

# Generated at 2022-06-23 11:03:17.002116
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from tempfile import mkstemp
    import os
    import os.path
    import pytest

    tmpfile = ''
    with open(tmpfile, 'w') as fp:
        fp.write('[test]\n')
        fp.write('test = "example"')

    fd, tmpfile = mkstemp()
    os.write(fd, b'[test]\ntest = "example"')
    os.close(fd)

    file_name, ext = os.path.splitext(tmpfile)
    assert ext == '.toml'

    im = InventoryModule()
    im.verify_file(tmpfile)
    assert os.path.exists(tmpfile)
    os.unlink(tmpfile)

# Generated at 2022-06-23 11:03:27.993876
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.compat.tests import unittest
    from ansible.compat.tests.mock import patch
    from ansible.parsing.yaml.objects import AnsibleMapping

    class TestAnsibleSequence(AnsibleSequence):
        _yaml_base_class = list

    class TestAnsibleUnicode(AnsibleUnicode):
        _yaml_base_class = text_type

    class TestAnsibleUnsafeBytes(AnsibleUnsafeBytes):
        _yaml_base_class = to_bytes

    class TestAnsibleUnsafeText(AnsibleUnsafeText):
        _yaml_base_class = to_text

    class TestAnsibleMapping(AnsibleMapping):
        _yaml_base_class = dict


# Generated at 2022-06-23 11:03:29.483721
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule is not None

# Generated at 2022-06-23 11:03:40.680555
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-23 11:03:50.285131
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_module = InventoryModule()
    # Case 1
    # Test for file that has '.toml' extension
    path = "/etc/ansible/hosts"
    result = test_module.verify_file(path)
    assert result == True
    # Case 2
    # Test for file that does not have '.toml' extension
    path = "/etc/ansible/hosts.yml"
    result = test_module.verify_file(path)
    assert result == False


# Generated at 2022-06-23 11:03:59.598000
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    '''
    Unit test for method verify_file of class InventoryModule. This test case
    will add one inventory file of format toml and one inventory file of
    format not toml and checks if it returns the right file format
    '''
    import tempfile
    import shutil
    dir_path = tempfile.mkdtemp()
    toml_file = os.path.join(dir_path, "inv.toml")
    inv_file = os.path.join(dir_path, "inv.inv")
    print(dir_path)

    with open(toml_file, "w") as f:
        f.write(EXAMPLES)

    im = InventoryModule()
    toml_file_result = im.verify_file(toml_file)
    inv_file_result = im.verify_file

# Generated at 2022-06-23 11:04:01.420462
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """
    This is a constructor test for InventoryModule class
    """
    inventory = InventoryModule()
    inventory.NAME = 'toml'

# Generated at 2022-06-23 11:04:03.081641
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule



# Generated at 2022-06-23 11:04:15.470315
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Unit test for method parse of class InventoryModule"""

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Create the objects required for the plugin
    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=[])

    # Instantiate the InventoryModule
    im = InventoryModule()

    # Verify that a file not ending with .toml raises AnsibleFileNotFound
    # Assert the exception raised matches the expected exception
    path = 'non-existent-path.yaml'

# Generated at 2022-06-23 11:04:20.398411
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv_obj = InventoryModule()
    var_manager = VariableManager()

    # Set global options
    inv_obj.options = None

    inv_obj.loader = loader
    inv_obj.inventory = InventoryManager(loader=loader, sources=['/etc/ansible/hosts'])
    inv_obj.inventory.set_variable_manager(var_manager)

    # Create inventory from text

# Generated at 2022-06-23 11:04:23.418950
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = 'ansible/inventory/_sample.toml'
    assert InventoryModule.verify_file(path) == True


# Generated at 2022-06-23 11:04:35.331581
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os.path
    import unittest

    class TestInventoryModule(unittest.TestCase):
        def test_InventoryModule__verify_file_valid_toml_extension(self):
            path = 'group1.toml'
            self.assertTrue(InventoryModule().verify_file(path))
        def test_InventoryModule__verify_file_invalid_toml_extension(self):
            path = 'group1.yml'
            self.assertFalse(InventoryModule().verify_file(path))
        def test_InventoryModule__verify_file_valid_toml_extension_path(self):
            path = '/etc/ansible/group1.toml'
            self.assertTrue(InventoryModule().verify_file(path))

# Generated at 2022-06-23 11:04:46.084293
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.common.collections import ImmutableDict
    loader = DataLoader()
    sources = ','.join(
        [
            '{0}/test_InventoryModule.toml'.format(os.getcwd()),
            '{0}/test_InventoryModule.toml'.format(os.path.dirname(__file__))
        ]
    )
    manager = InventoryManager(loader=loader, sources=sources)

# Generated at 2022-06-23 11:04:49.311440
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''Function to test method parse of class InventoryModule'''
    inventory_module_obj = InventoryModule()
    parser_obj = inventory_module_obj.parse("", "", path=None)
    print("parser_obj: {}".format(parser_obj))


# Generated at 2022-06-23 11:05:01.402821
# Unit test for function toml_dumps
def test_toml_dumps():
    # Pass cases
    yaml_input = {
        'a': True,
        'b': {
            'c': 'd'
        },
        'e': [
            'f', 'g'
        ]
    }

    # input from ``ansible.parsing.yaml.objects``
    objects_input = {
        'a': True,
        'b': {
            'c': AnsibleUnicode('d')
        },
        'e': [
            AnsibleUnicode('f'), 'g'
        ]
    }

    assert toml_dumps(yaml_input) == toml_dumps(objects_input)
    # Fail cases

# Generated at 2022-06-23 11:05:10.241529
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file("/tmp/my/path/to/file.toml")
    assert not InventoryModule.verify_file("/tmp/my/path/to/file.json")
    assert not InventoryModule.verify_file("/tmp/my/path/to/file.yaml")
    assert not InventoryModule.verify_file("/tmp/my/path/to/file.yml")
    assert not InventoryModule.verify_file("/tmp/my/path/to/file.ini")


# Generated at 2022-06-23 11:05:21.566298
# Unit test for function toml_dumps
def test_toml_dumps():
    from collections import OrderedDict

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.utils import py3compat


# Generated at 2022-06-23 11:05:25.259209
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj.NAME == 'toml'
    assert obj.verify_file('inventory.toml') is True


# Generated at 2022-06-23 11:05:30.405765
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    b_path = to_bytes('/path/to/file.toml')
    assert inventory_module.verify_file(b_path)
    b_path = to_bytes('/path/to/file.json')
    assert not inventory_module.verify_file(b_path)


# Generated at 2022-06-23 11:05:34.629268
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    mod = InventoryModule()
    assert mod.NAME == 'toml'
    assert mod is not None
    assert mod.__doc__ is not None


# Generated at 2022-06-23 11:05:44.769803
# Unit test for function toml_dumps
def test_toml_dumps():
    # Single value test
    assert toml_dumps(3) == '3\n'
    # Single value test, ensure we handle unicode strings and Python 3
    assert toml_dumps(u'3') == '3\n'
    assert toml_dumps(u'3'.encode('utf-8')) == '3\n'
    # Ensure we handle newline and tab characters
    assert toml_dumps(u'3\n\t') == '3\\n\\t\n'
    # Test a dict
    assert toml_dumps({'a': 3}) == 'a = 3\n'
    # Test a dict with a unicode string value
    assert toml_dumps({'a': u'3'}) == 'a = 3\n'

# Generated at 2022-06-23 11:05:47.748854
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    result = inventory_module.verify_file('sample.toml')
    assert result == True, 'Verification of .toml file extention failed in test_InventoryModule_verify_file'

# Generated at 2022-06-23 11:05:57.541838
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import ansible.parsing.yaml.objects

    assert convert_yaml_objects_to_native([1, 2, 3]) == [1, 2, 3]
    assert convert_yaml_objects_to_native([ansible.parsing.yaml.objects.AnsibleSequence(1, 2, 3)]) == [1, 2, 3]
    assert convert_yaml_objects_to_native([1, ansible.parsing.yaml.objects.AnsibleSequence(2, 3), 4]) == [1, [2, 3], 4]

    assert convert_yaml_objects_to_native({'a': '1'}) == {'a': '1'}

# Generated at 2022-06-23 11:06:07.766551
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    class AnsibleUnicode(object):
        pass

    class AnsibleSequence(list):
        pass

    class AnsibleDict(dict):
        pass

    class AnsibleUnsafeBytes(object):
        pass

    class AnsibleUnsafeText(object):
        pass

    data = {
        b'c': AnsibleSequence([{
            b'a': AnsibleUnicode('foo'),
            b'b': AnsibleSequence([AnsibleUnsafeText('bar'), AnsibleUnsafeBytes('baz')]),
        }]),
        b'd': AnsibleDict({
            b'a': AnsibleUnicode('foo'),
            b'b': AnsibleSequence([AnsibleUnsafeText('bar'), AnsibleUnsafeBytes('baz')]),
        }),
    }

# Generated at 2022-06-23 11:06:10.940824
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('test.txt') == False
    assert inventory_module.verify_file('test.toml') == True

# Generated at 2022-06-23 11:06:15.959687
# Unit test for function toml_dumps
def test_toml_dumps():

    data = {
        'dictionary': {'this': 'that', 'answer': 42},
        'list': ['red', 'blue', 'white', 'yellow'],
        'string': 'The quick red fox jumped over the lazy sloth.',
        'unicode': u'The quick red fox jumped over the lazy sloth.'
    }

    assert toml_dumps(data) == \
r'''dictionary = {
  answer = 42
  this = "that"
}
list = [
  "red",
  "blue",
  "white",
  "yellow"
]
string = "The quick red fox jumped over the lazy sloth."
unicode = "The quick red fox jumped over the lazy sloth."
'''

# Generated at 2022-06-23 11:06:18.543084
# Unit test for function toml_dumps
def test_toml_dumps():
    u = u'foo'
    b = b'bar'
    assert toml_dumps(u) == '"foo"'
    assert toml_dumps(b) == '"bar"'

# Generated at 2022-06-23 11:06:28.301457
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import tempfile
    import shutil
    import os

    EXAMPLES_DIR = os.path.join(os.path.dirname(__file__), 'data', 'inventory_toml')
    EXAMPLE_1_PATH = os.path.join(EXAMPLES_DIR, 'example_1.toml')
    EXAMPLE_2_PATH = os.path.join(EXAMPLES_DIR, 'example_2.toml')
    EXAMPLE_3_PATH = os.path.join(EXAMPLES_DIR, 'example_3.toml')
    inventory = InventoryModule()
    loader = DictDataLoader()
    inventory_dir = tempfile.mkdtemp()


# Generated at 2022-06-23 11:06:32.543408
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule(get_loader_mock(), get_inventory_mock())

test_InventoryModule()


# Generated at 2022-06-23 11:06:43.564682
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import pytest

# Generated at 2022-06-23 11:06:53.153230
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # dict
    assert convert_yaml_objects_to_native({'a': 1, 'b': 'c', 'd': [2, 3, 4]}) == {'a': 1, 'b': 'c', 'd': [2, 3, 4]}
    assert convert_yaml_objects_to_native({u'a': 1, u'b': u'c', u'd': [2, 3, 4]}) == {'a': 1, 'b': 'c', 'd': [2, 3, 4]}
    assert convert_yaml_objects_to_native({'a': AnsibleUnsafeBytes(b'1'), 'b': AnsibleUnsafeText(u'c'), 'd': [2, 3, 4]}) == {'a': '1', 'b': 'c', 'd': [2, 3, 4]}

# Generated at 2022-06-23 11:06:58.177181
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Assert that InventoryModule's constructor does not raise any exceptions
    try:
        InventoryModule()
    except Exception as e:
        pytest.fail('Could not instantiate InventoryModule: %s' % e)

# Generated at 2022-06-23 11:07:07.948532
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # test for dictionary
    data = {
        "hosts": {
            "host1": {
                "ansible_host": "127.0.0.1"
            },
            "host2": {
                "ansible_port": 222
            },
            "host3": {
                "ansible_host": "127.0.0.1",
                "ansible_port": 222
            }
        },
        "vars": {
            "foo": "bar"
        }
    }

# Generated at 2022-06-23 11:07:08.651914
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj is not None


# Generated at 2022-06-23 11:07:20.289196
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText