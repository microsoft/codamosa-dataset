

# Generated at 2022-06-23 10:57:13.344523
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert im

# Generated at 2022-06-23 10:57:23.299514
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText


# Generated at 2022-06-23 10:57:34.594477
# Unit test for method verify_file of class InventoryModule

# Generated at 2022-06-23 10:57:44.761034
# Unit test for function toml_dumps
def test_toml_dumps():
    import toml
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode


# Generated at 2022-06-23 10:57:50.594173
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText
    from ansible.module_utils._text import to_bytes, to_native, to_text

    assert isinstance(convert_yaml_objects_to_native({
        "foo": AnsibleUnsafeBytes(b"bar")
    }), dict)
    assert isinstance(convert_yaml_objects_to_native({
        "foo": AnsibleUnsafeBytes(b"bar")
    })["foo"], bytes)
    assert isinstance(convert_yaml_objects_to_native({
        "foo": AnsibleUnsafeText(u"bar")
    }), dict)

# Generated at 2022-06-23 10:57:58.693681
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Example 1
    string = toml_dumps({
        'all': {'vars': {'has_java': False}},
        'web': {'children': ['apache', 'nginx'], 'vars': {'http_port': 8080, 'myvar': 23},
                'hosts': {'host1': {}, 'host2': {'ansible_port': 222}}},
        'apache': {'hosts': {'tomcat1': {}, 'tomcat2': {'myvar': 34},
                             'tomcat3': {'mysecret': '03#pa33w0rd'}}},
        'nginx': {'hosts': {'jenkins1': {}}, 'vars': {'has_java': True}}
    })

# Generated at 2022-06-23 10:58:01.527499
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    expected_result = True
    result = inventory_module.verify_file("test/test.toml")
    assert result == expected_result


# Generated at 2022-06-23 10:58:11.452812
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import os

    from ansible.inventory.manager import InventoryManager

    sample_filename = os.path.join(os.path.dirname(__file__), 'toml_sample.toml')
    im = InventoryManager(loader=None, sources=sample_filename)
    im._inventory.hosts = {}
    im.parse_sources()

    assert len(im._inventory.hosts) == 5

    # Create an inventory object with a hostname that has a ':' in it
    sample_filename = os.path.join(os.path.dirname(__file__), 'toml_sample_colon_host.toml')
    im = InventoryManager(loader=None, sources=sample_filename)
    im._inventory.hosts = {}
    im.parse_sources()


# Generated at 2022-06-23 10:58:18.149625
# Unit test for function toml_dumps
def test_toml_dumps():
    # fmt: off
    data = {
        'name': 'Ales',
        'age': None,
        'is_valid': True,
        'species': ['human', 'programmer'],
        'job': {
            'name': 'Software Engineer',
            'language': 'Python',
            'start': '2004'
        }
    }
    # fmt: on
    dumped_data = toml_dumps(data)
    assert(isinstance(dumped_data, str))
    expected_dumped_data = r'''name = "Ales"
age = null
is_valid = true
species = ["human", "programmer"]

[job]
  name = "Software Engineer"
  language = "Python"
  start = "2004"
'''

# Generated at 2022-06-23 10:58:29.964608
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    Unit test for method parse of class InventoryModule
    file1.toml
    [[group1.hosts]]
    host1 ansible_host=127.0.0.1

    [[group2.hosts]]
    host2 ansible_host=127.0.0.2

    return: data
    """

    file_name = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        'file1.toml'
    )
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader, sources=file_name)
    inventory.parse_sources()
    data = inventory.groups
    print(data, type(data))

# Generated at 2022-06-23 10:58:33.657996
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    msg = "TypeError: Can't instantiate abstract class InventoryModule with " \
          "abstract methods add_group, get_option, get_option_cache_key, " \
          "populate_cache_plugin, set_options"
    assert str(msg) == str(type(module))[-len(msg):]

# Generated at 2022-06-23 10:58:37.341645
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file('/tmp/foo.toml') == True
    assert InventoryModule.verify_file('/tmp/foo.bar') == False
    assert InventoryModule.verify_file('') == False

# Generated at 2022-06-23 10:58:47.972149
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    loader = lambda: None
    setattr(loader, 'path_exists', lambda path: True)
    setattr(loader, 'path_dwim', lambda path: path)
    setattr(loader, '_get_file_contents', lambda path: (EXAMPLES, False))
    inventory = lambda: None
    setattr(inventory, 'set_variable', lambda group, var, value: None)
    setattr(inventory, 'add_group', lambda group: group)
    setattr(inventory, 'add_child', lambda group, subgroup: None)

    try:
        inventory_module.parse(inventory, loader, path='file.toml')
        assert True
    except Exception as e:
        print(e)

# Generated at 2022-06-23 10:58:51.927842
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native(
                   dict(a=list(range(3)),
                        b=[AnsibleUnicode('1'), 2, 3],
                        c=[AnsibleUnsafeBytes(b'a'), AnsibleUnsafeText(u'b')])) ==\
           dict(a=[0, 1, 2], b=[u'1', 2, 3], c=[u'a', u'b'])

# Generated at 2022-06-23 10:59:01.018665
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText
    import unittest

    TestCase = unittest.TestCase
    TestSuite = unittest.TestSuite

    class UtilsTests(TestCase):
        def test_convert_yaml_objects_to_native(self):
            # Tests with ``AnsibleUnicode``
            self.assertEqual(
                convert_yaml_objects_to_native(AnsibleUnicode('test')),
                'test',
            )
            self.assertEqual(
                convert_yaml_objects_to_native({'a': AnsibleUnicode('test')}),
                {'a': 'test'},
            )

# Generated at 2022-06-23 10:59:13.629678
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from tempfile import NamedTemporaryFile

    # Prepare a temp TOML file
    f = NamedTemporaryFile(suffix='.toml', delete=False)
    f.write(EXAMPLES.encode('utf-8'))
    f.close()

    # Generate an inventory object
    inventory = InventoryModule()
    inventory.display = Display()

    # Load data from the temp file
    inventory.parse(inventory, None, f.name)

    # Check the results
    hostnames = ('host1', 'host2', 'host3', 'host4', 'tomcat1', 'tomcat2', 'tomcat3', 'jenkins1')
    for host in hostnames:
        assert host in inventory.hosts

    # Cleanup
    os.unlink(f.name)

# Generated at 2022-06-23 10:59:23.749293
# Unit test for function toml_dumps
def test_toml_dumps():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.hostvars import HostVars

    hv = HostVars(dict(), wrap_var(dict(foo='bar')))

# Generated at 2022-06-23 10:59:26.623943
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert inv.verify_file('/home/vagrant/test.yaml') is None
    assert inv.verify_file('/home/vagrant/test.toml') is True


# Generated at 2022-06-23 10:59:31.348651
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    file_name = './test/inventory_hosts'
    inventory = InventoryModule()
    data = inventory._load_file(file_name)
    assert isinstance(data, dict), 'Expected object of type dict, but got %s' % type(data)

# Generated at 2022-06-23 10:59:39.770596
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    file_name = 'test_file.txt'
    ext = '.txt'
    assert InventoryModule.verify_file(file_name) is False
    file_name, ext = os.path.splitext(file_name)
    assert ext == '.txt'
    file_name = 'test_file.toml'
    ext = '.toml'
    assert InventoryModule.verify_file(file_name) is True
    file_name, ext = os.path.splitext(file_name)
    assert ext == '.toml'



# Generated at 2022-06-23 10:59:50.182185
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    source = 'test'
    name = 'TOML'
    path = os.path.join(os.path.dirname(__file__), '../../..', 'test/units/inventory/parse/data/test.toml')
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[path])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    toml_inventory = InventoryModule()
    toml_inventory.vars_plugins = []
    toml_inventory.parse(inventory=inventory, loader=loader, path=path)
    assert isinstance(inventory, InventoryManager)

# Generated at 2022-06-23 10:59:53.425594
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module_instance = InventoryModule()
    path = "test_path"
    assert inventory_module_instance.verify_file(path) == False
    path = "test_path.toml"
    assert inventory_module_instance.verify_file(path) == True

# Generated at 2022-06-23 11:00:00.519386
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    fake_loader = FakeLoader()
    fake_inventory = FakeInventory()
    im = InventoryModule(display=Display(), loader=fake_loader, inventory=fake_inventory)
    path = "fake_path.yaml"
    assert im.verify_file(path) == False
    path = "fake_path.toml"
    assert im.verify_file(path) == True


# Generated at 2022-06-23 11:00:04.808903
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins.loader import find_plugin
    inv_mod = find_plugin("inventory").get_plugin("toml")
    inv_mod2 = InventoryModule()
    assert inv_mod.__class__.__name__ == inv_mod2.__class__.__name__



# Generated at 2022-06-23 11:00:14.550068
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.playbook.play import Play
    from ansible.executor.task_queue_manager import TaskQueueManager
    import json

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/hosts/hosts.toml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    play_source = dict(
        name="Ansible Play",
        hosts='localhost',
        gather_facts='no',
        tasks=[
            dict(action=dict(module='debug', args=dict(msg='Hello Ansible')))
        ]
    )


# Generated at 2022-06-23 11:00:18.421342
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'toml'


if __name__ == "__main__":
    test_InventoryModule()

# Generated at 2022-06-23 11:00:26.616793
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from collections import namedtuple

    Options = namedtuple('Options', ['inventory', 'listhosts', 'subset', 'graph'])
    options = Options(inventory=None, listhosts=None, subset=None, graph=None)

    # Create the inventory and pass to var manager
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['/tmp/inventory.toml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    inventory_plugin = InventoryModule()
    inventory_plugin.parse(inventory, loader, '/tmp/inventory.toml')

# Generated at 2022-06-23 11:00:36.700149
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.compat.tests.mock import patch
    from ansible.compat.tests import unittest

    class MockDisplay(object):
        def __init__(self):
            self.messages = []
        def warning(self, msg):
            self.messages.append(msg)

    class MockAnsibleUnsafeText(object):
        def __init__(self, txt):
            self.txt = txt
        def __str__(self):
            return self.txt
        def __unicode__(self):
            return self.txt

    class MockAnsibleUnsafeBytes(object):
        def __init__(self, txt):
            self.txt = txt
        def __str__(self):
            return self.txt
        def __unicode__(self):
            return self

# Generated at 2022-06-23 11:00:48.217745
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins import inventory
    from io import StringIO
    # init
    loader = inventory.Loader()
    path = 'test_ansible.toml'
    cache = True
    inv = inventory.Inventory(loader=loader, variable_manager=inventory.VariableManager(), host_list=[])
    inv.parse_source(path)
    # exec
    inv.parse(inv, loader, path, cache)
    # verify
    assert inv.groups['all']['vars']['has_java'] == False
    assert inv.groups['web']['vars']['http_port'] == 8080
    assert inv.groups['web']['hosts']['host2']['ansible_port'] == 222

# Generated at 2022-06-23 11:00:55.741220
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import json
    import os

    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    inventory_manager = InventoryManager(loader=loader, sources=[])

    groups = ['test_group1', 'test_group2']
    hosts = ['testhost1', 'testhost2']
    vars = {'testvar1': 'testvalue1', 'testvar2': 'testvalue2'}
    groupvars = {'test_group1': {'groupvar1': 'groupvalue1', 'groupvar2': 'groupvalue2'}}

# Generated at 2022-06-23 11:01:03.582033
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    toml_init_path = "test_toml_inventory.toml"
    yaml_init_path = "test_toml_inventory.yaml"
    group_init_path = "group_vars/test_toml_inventory.toml"
    empty_init_path = "empty_file.toml"
    with open(toml_init_path, 'w') as toml_file:
        toml_file.write(EXAMPLES)

    with open(yaml_init_path, 'w') as yaml_file:
        yaml_file.write(EXAMPLES)

    # test toml file type
    im = InventoryModule()
    assert im.verify_file(toml_init_path) is True
    os.remove(toml_init_path)

    #

# Generated at 2022-06-23 11:01:11.633239
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Make sure that the file extension is .toml
    inventoryModule = InventoryModule()
    assert inventoryModule.verify_file('/someinventorydir/somefile.toml') == True

    # Make sure that verify_file() is working correctly
    inventoryModule = InventoryModule()
    assert inventoryModule.verify_file('/someinventorydir/somefile.yaml') == False

# Generated at 2022-06-23 11:01:12.782129
# Unit test for function toml_dumps
def test_toml_dumps():
    # Placeholder for unit test
    assert True

# Generated at 2022-06-23 11:01:18.076777
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ansible_toml_config = '''
    [web]
    children = [
       "apache",
       "nginx"
    ]
    hosts = {
        host1 = {}
    }
    vars = {
        ansible_port = 8080,
        myvar = 23
    }
    '''

    ansible_toml_config_with_group_children = '''
    [web1]

    [web2]
    children = [
       "apache",
       "nginx"
    ]
    hosts = {
        host1 = {}
    }
    vars = {
        ansible_port = 8080,
        myvar = 23
    }
    '''


# Generated at 2022-06-23 11:01:23.322877
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    path = os.environ['DATA_DIR'] + "/hosts_test.toml"
    plugin = InventoryModule()
    plugin.parse(group='all', inventory=None, loader=None, path=path, cache=False)

# Generated at 2022-06-23 11:01:26.019119
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'toml'

# Generated at 2022-06-23 11:01:27.549046
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory is not None


# Generated at 2022-06-23 11:01:37.684451
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence
    assert convert_yaml_objects_to_native([1, AnsibleSequence([1, 2])]) == [1, [1, 2]]
    assert convert_yaml_objects_to_native({'b': 1, 'a': AnsibleSequence([1, 2])}) == {'b': 1, 'a': [1, 2]}
    assert convert_yaml_objects_to_native(AnsibleSequence([1, 2])) == [1, 2]
    d = dict(b=1, a=dict(c=3, d=AnsibleSequence([1, 2])))

# Generated at 2022-06-23 11:01:49.915957
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Setup
    input_obj = {
        'text': 'some',
        'unsafe_bytes': AnsibleUnsafeBytes('b\'\x04\xce\x9e\x03\x1a\xaf\xaa\x15\x88\x06\x0e'),
        'unsafe_text': AnsibleUnsafeText('\\x81\x8d\xb7\xe3\x99v'),
        'list': [1, '2', b'three'],
        'dict': { 'a': 'b', 'c': b'd' },
    }

# Generated at 2022-06-23 11:01:51.765305
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert type(InventoryModule.verify_file({}, '', 'foo.toml')) == bool
    #assert InventoryModule.verify_file({}, '', 'foo.toml') == True


# Generated at 2022-06-23 11:01:53.742572
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod



# Generated at 2022-06-23 11:02:02.453522
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # The method should not alter objects that aren't of type:
    # ``ansible.parsing.yaml.objects.AnsibleUnicode``,
    # ``ansible.parsing.yaml.objects.AnsibleSequence`` or
    # ``ansible.parsing.yaml.objects.AnsibleMapping``
    values_to_test = [
        "string",
        1,
        [1, 2, 3],
        dict(a=1),
    ]

    for value in values_to_test:
        assert value == convert_yaml_objects_to_native(value)

    # Converting a ``ansible.parsing.yaml.objects.AnsibleUnicode``
    # should return an unicode string
    value = AnsibleUnsafeText("string")
   

# Generated at 2022-06-23 11:02:13.154484
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    inventory = inventory_loader.get('toml', class_only=True)()
    example1 = text_type(EXAMPLES).splitlines()[2:-2]
    path = loader.path_dwim(loader.mkdtemp())
    loader.makedirs(path)
    inventory.parse(inventory, loader, path, cache=False)
    with open(os.path.join(path, 'example1.toml'), 'wb') as f:
        f.write(to_bytes('\n'.join(example1)))

    groups = inventory.get_groups()
    assert len(groups) == 4

    assert 'all' in groups
    all_vars

# Generated at 2022-06-23 11:02:25.158758
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    test_obj = { "key1" : "value1", "key2" : { "foo" : "bar", "numbers" : [1, 2, 3, 4] }, "key3" : [1, 2, 3, 4] }
    native_obj = convert_yaml_objects_to_native(test_obj)

    assert isinstance(native_obj, dict)
    assert isinstance(native_obj['key1'], str)
    assert isinstance(native_obj['key2'], dict)
    assert isinstance(native_obj['key2']['foo'], str)
    assert isinstance(native_obj['key2']['numbers'], list)

# Generated at 2022-06-23 11:02:35.791679
# Unit test for function toml_dumps
def test_toml_dumps():
    text = toml_dumps({'firstname': 'Tom', 'lastname': 'Preston-Werner'})
    assert text == 'firstname = "Tom"\nlastname = "Preston-Werner"\n'

    text = toml_dumps({'point': [1, 10]})
    assert text == 'point = [1, 10]\n'

    text = toml_dumps({'integer': 32})
    assert text == 'integer = 32\n'


# Generated at 2022-06-23 11:02:41.566008
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    loader = DictDataLoader({
        '/path/to/inventory': toml_dumps(toml.loads(EXAMPLES))
    })
    inventory = InventoryManager(loader=loader, sources=['/path/to/inventory'])
    module.parse(
        inventory, loader, '/path/to/inventory', cache=False
    )

# Generated at 2022-06-23 11:02:53.047828
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a dict of values that would be returned by toml.load
    data = {
        'all': {
            'vars': {
                'has_java': True
            }
        }
    }

    # Create a mock item for the AnsibleInventory class
    attributes = {}
    mock_item = type('MockItem', (object,), attributes)()

    # Create a mock inventory object with the mocked item
    attributes = {
        '_populate_host_vars.return_value': None,
        'add_child.return_value': None,
        'add_group.return_value': mock_item,
        'set_variable.return_value': None
    }
    mock_inventory = type('MockInventory', (object,), attributes)()

    # Create a mock loader object

# Generated at 2022-06-23 11:03:05.980436
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # create a basic inventory
    inventory = mock.MagicMock()

    # create instance of class InventoryModule
    inventoryModule = InventoryModule()

    # check if parse returns None
    # noinspection PyUnusedLocal
    @mock.patch('ansible.plugins.inventory.toml.AnsibleParserError', mock.Mock())
    def test_parse_no_return(*args, **kwargs):
        assert inventoryModule.parse(inventory, *args, **kwargs) is None
    test_parse_no_return()

    # check if parse raise AnsibleParserError
    # noinspection PyUnusedLocal

# Generated at 2022-06-23 11:03:15.145696
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test for following ansible/plugins/inventory/toml.py InventoryModule class method - parse()
    # Parsing should fail if file is not found or readable
    loader = None
    path = 'test.toml'
    inventory = None
    cache = True
    inv_parser_toml = InventoryModule(loader=loader, inventory=inventory)
    inv_parser_toml.parse(path=path, cache=cache)

    path = 'invalid.txt'
    inv_parser_toml.parse(path=path, cache=cache)


if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-23 11:03:19.866480
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    i = InventoryModule()
    path = 'test.toml'
    assert i.verify_file(path)
    path = 'test.json'
    assert not i.verify_file(path)
    path = '/test.toml'
    assert i.verify_file(path)


# Generated at 2022-06-23 11:03:22.089351
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory_toml.py:TestInventoryModule '''

    inv = InventoryModule()
    assert inv

# Generated at 2022-06-23 11:03:31.850391
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'foo': 'bar'}) == 'foo = "bar"\n'
    assert toml_dumps({'foo': 'bar', 'baz': 42}) == 'baz = 42\nfoo = "bar"\n'
    assert toml_dumps({'foo': ['bar', 'baz']}) == 'foo = [\n  "bar",\n  "baz"\n]\n'
    assert toml_dumps({'foo': {'bar': 'baz'}}) == '[[foo]]\nbar = "baz"\n'
    assert toml_dumps({'foo': {'bar': {'baz': 'quux'}}}) == '[[foo.bar]]\nbaz = "quux"\n'

# Generated at 2022-06-23 11:03:39.086710
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    AnsibleFileInventoryPlugin.parse() returns a dict
    containing the data from the toml string.
    '''
    file_data = to_bytes("[web]\n[web.hosts]\nhost=false")
    result = InventoryModule().parse(None, None, None, cache=True, source=file_data)
    expected_result = {'web': {'hosts': {'host': False}}}
    assert result == expected_result

# Generated at 2022-06-23 11:03:43.319785
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = None
    path = None
    cache = True

    plugin = InventoryModule()
    plugin.parse(inventory, loader, path, cache)


# Generated at 2022-06-23 11:03:45.697765
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # we test this manually in test/units/plugins/inventory/test_toml.py
    pass

# Generated at 2022-06-23 11:03:49.827499
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'inventory.toml')
    assert inv_mod.verify_file(path)



# Generated at 2022-06-23 11:04:00.556329
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    '''
    The ``toml`` library handles a subset of what is valid in the TOML spec. The
    library doesn't know how to handle strings that contain newlines {'\n'} and
    multi-line strings as well as some more advanced features of the TOML
    spec.

    This unit test may need updating if any of the below is updated in the
    upstream ``toml`` library.
    '''

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode

# Generated at 2022-06-23 11:04:12.620786
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText
    import pytest
    assert convert_yaml_objects_to_native(1) == 1
    assert convert_yaml_objects_to_native("testing") == "testing"
    assert convert_yaml_objects_to_native(["testing", "testing", "testing"]) == ["testing", "testing", "testing"]
    assert convert_yaml_objects_to_native({"nested": "dict", "nested_list": ["testing", "testing", "testing"]}) == {"nested": "dict", "nested_list": ["testing", "testing", "testing"]}

# Generated at 2022-06-23 11:04:24.573669
# Unit test for function toml_dumps
def test_toml_dumps():
    import sys
    import toml

    # Python 3 only
    if sys.version_info[0] != 3:
        return

    # Define some Python3-only data types
    if sys.version_info[1] < 6:
        ExampleMutableMapping = dict
        ExampleMutableSequence = list
    elif sys.version_info[1] < 7:
        from collections import UserDict
        ExampleMutableMapping = UserDict
        ExampleMutableSequence = list
    else:
        from collections.abc import MutableMapping
        from collections.abc import MutableSequence
        ExampleMutableMapping = MutableMapping
        ExampleMutableSequence = MutableSequence

    # Define a list of example data types to convert

# Generated at 2022-06-23 11:04:30.670156
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from datetime import datetime
    import time

    # Test the TOML encoder against loaded data
    test_data_file = os.path.join(os.path.dirname(__file__), 'test_data_toml.yml')
    with open(test_data_file) as f:
        test_data = AnsibleLoader(f, file_name=test_data_file).get_data()

    test_data_toml = toml_dumps(test_data)

# Generated at 2022-06-23 11:04:36.357711
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file("hosts") == False
    assert InventoryModule.verify_file("hosts.toml") == True
    assert InventoryModule.verify_file("hosts.tmpl") == False

if __name__ == '__main__':
    test_InventoryModule_verify_file()

# Generated at 2022-06-23 11:04:47.006645
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence
    from ansible.plugins.inventory.toml import convert_yaml_objects_to_native

    assert convert_yaml_objects_to_native({"key": "value"}) == {"key": "value"}
    assert convert_yaml_objects_to_native([1, 2, 3]) == [1, 2, 3]
    assert convert_yaml_objects_to_native(1) == 1

    assert convert_yaml_objects_to_native(AnsibleUnicode('unicode')) == 'unicode'
    assert convert_yaml_objects_to_native(AnsibleSequence([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-23 11:04:49.149580
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    assert inventory.verify_file('test.toml') == True
    assert inventory.verify_file('test') == False


# Generated at 2022-06-23 11:05:01.242331
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    from ansible.parsing.dataloader import DataLoader
    class InventoryModuleTest(InventoryModule):
        def __init__(self, loader, inventory, path):
            super(InventoryModuleTest, self).__init__(loader, inventory, path)

    loader = DataLoader()
    inventory = None
    path = 'plugins/inventory/test/test_data/test_toml.toml'
    test_obj = InventoryModuleTest(loader, inventory, path)
    test_obj._parse_group('all', {'vars': {'x': True}, 'children': ['apache'], 'hosts': {'host1': {}, 'host2': {'ansible_port': 222}}})

# Generated at 2022-06-23 11:05:13.101825
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    if PY3:
        assert convert_yaml_objects_to_native("hello") == "hello"
        assert convert_yaml_objects_to_native(b"hello") == "hello"
        assert convert_yaml_objects_to_native(AnsibleUnsafeBytes("hello")) == "hello"
    else:
        assert convert_yaml_objects_to_native("hello") == "hello"
        assert convert_yaml_objects_to_native(b"hello") == "hello"
        assert convert_yaml_objects_to_native(AnsibleUnsafeBytes("hello")) == b"hello"

# Generated at 2022-06-23 11:05:20.575995
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    loader = 'dummy_loader'
    path = 'dummy_path'
    data = ''
    self = InventoryModule(loader, path, data)
    assert self.verify_file('path/to/file.toml') is True
    assert self.verify_file('path/to/file.yaml') is False
    assert self.verify_file('path/to/file.ini') is False
    assert self.verify_file('path/to/file.json') is False


# Generated at 2022-06-23 11:05:27.558154
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnsafeText, AnsibleUnsafeBytes

    ansibleseq = AnsibleSequence([AnsibleUnsafeText('foo'), 2])
    ansibleseq2 = AnsibleSequence(ansibleseq)
    ansibleseq2.append(AnsibleUnsafeBytes('bar'))

    ansibledict = {
        'seq': ansibleseq,
        'seq2': ansibleseq2,
        'unsafe': AnsibleUnsafeText('foo'),
        'unsafe2': AnsibleUnsafeBytes('bar')
    }

    assert ansibleseq[0] == 'foo'
    assert ansibleseq[1] == 2
    assert ansibleseq2[2] == 'bar'

    ansibledict = convert_yaml_objects_

# Generated at 2022-06-23 11:05:39.008522
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    display = Display()
    i = InventoryModule()
    i.set_options()
    i.display = display
    i.parse(None, None, EXAMPLES)
    # import sys; print(i.inventory.to_data())
    # import pdb; pdb.set_trace()


# Generated at 2022-06-23 11:05:49.769672
# Unit test for function toml_dumps
def test_toml_dumps():
    import pytest
    from ansible.module_utils.six import string_types
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode

    assert toml_dumps([1,2,3]) == "[1,2,3]"
    assert toml_dumps(["1"]) == "[\"1\"]"
    assert toml_dumps(["1",2]) == "[\"1\",2]"

    assert toml_dumps({'key': 'value'}) == 'key = "value"'
    assert toml_dumps({'a': {'b': {'c': {'d': {'e': 'f'}}}}}) == '[a.b.c.d]\ne = "f"'


# Generated at 2022-06-23 11:05:58.815180
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    # Valid file
    assert inv_mod.verify_file('/path/to/file.toml') is True, "TOML File with extension '.toml' is not verified"
    # Non-existing file
    assert inv_mod.verify_file('/path/to/non-existing-file.toml') is False, "Non-existing file is verified"
    # File with wrong extension
    assert inv_mod.verify_file('/path/to/file.not-toml') is False, "File with extension '.not-toml' is verified"
    # Empty file
    assert inv_mod.verify_file('') is False, "Empty file is verified"
    # Wrong path

# Generated at 2022-06-23 11:06:01.232960
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    name = 'toml'
    inventory = BaseFileInventoryPlugin()
    loader = True
    path = True
    cache = True
    InventoryModule.parse(InventoryModule,inventory, loader, path, cache)


# Generated at 2022-06-23 11:06:04.463947
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    yaml_inv = '''plugin: toml
    groups:
      - name: testgroup
        hosts:
          - 10.20.30.40
          - 50.60.70.80
    '''
    inv = InventoryModule()
    assert inv.verify_file(yaml_inv) is True


# Generated at 2022-06-23 11:06:09.879034
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    path = './test_data/hosts.toml'
    assert module.verify_file(path)==True
    path = './test_data/hosts.yml'
    assert module.verify_file(path)==False



# Generated at 2022-06-23 11:06:19.935961
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    ''' test our function to ensure it works as expected '''
    import datetime
    import time

    assert convert_yaml_objects_to_native('hello') == 'hello'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes(b'bhello')) == b'bhello'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText(u'thello')) == u'thello'
    assert convert_yaml_objects_to_native(datetime.datetime.utcnow()) == datetime.datetime.utcnow()
    assert convert_yaml_objects_to_native(datetime.timedelta(0)) == datetime.timedelta(0)
    assert convert_yaml_objects_to_native(time.time()) == time.time()

# Generated at 2022-06-23 11:06:21.669676
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule(loader=None, paths=[''])



# Generated at 2022-06-23 11:06:26.781848
# Unit test for function toml_dumps
def test_toml_dumps():
    test_data = {
        'foo': {
            'bar': 'baz',
            'list': [
                {'key': 'string'},
                {'key': 123},
            ],
        },
    }
    assert toml_dumps(test_data) == '[foo]\nbar = "baz"\nlist = [{"key": "string"}, {"key": 123}]\n'


# Generated at 2022-06-23 11:06:29.314216
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    ''' verify_file should return True if path ends with .toml '''
    mock_obj = InventoryModule()
    path = 'inventory/hosts.toml'
    assert(mock_obj.verify_file(path) == True)


# Generated at 2022-06-23 11:06:37.724378
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'g1': {'hosts': {'host4': None}}}) == r'''[g1.hosts.host4]
'''
    assert toml_dumps({'g2': {'hosts': {'host5': {'ansible_port': 44}}}}) == r'''[g2.hosts.host5]
ansible_port = 44
'''



# Generated at 2022-06-23 11:06:41.950352
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    path = '/opt/ansible/hosts.yml'
    assert(inv.verify_file(path) == False)
    path = '/opt/ansible/hosts.toml'
    assert(inv.verify_file(path) == True)

# Generated at 2022-06-23 11:06:51.896141
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    # Test simple use cases
    assert convert_yaml_objects_to_native(AnsibleSequence([])) == []
    assert convert_yaml_objects_to_native(AnsibleUnicode('foo')) == 'foo'

    # Test more dificult scenarios
    assert convert_yaml_objects_to_native(AnsibleSequence([AnsibleUnicode('foo')])) == ['foo']
    assert convert_yaml_objects_to_native({
        AnsibleSequence([AnsibleUnicode('foo')]): AnsibleUnicode('bar')
    }) == {'foo': 'bar'}
    assert convert_yaml_

# Generated at 2022-06-23 11:06:52.666212
# Unit test for constructor of class InventoryModule

# Generated at 2022-06-23 11:06:58.070857
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file('/tmp/file.toml')
    assert InventoryModule().verify_file('/tmp/.ansible/test.toml')
    assert InventoryModule().verify_file('/tmp/file.notml') == False

# Generated at 2022-06-23 11:07:07.293490
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():

    data = {
        'k1': 'v1',
        'k2': AnsibleUnsafeText('v2'),
        'k3': [
            AnsibleUnsafeBytes(b'b3'),
            b'b4',
        ],
        'k4': None,
        'k5': 1,
        'k6': {
            'k6.1': AnsibleSequence([1,2,3]),
            'k6.2': AnsibleUnicode('u6.2'),
        }
    }


# Generated at 2022-06-23 11:07:19.812665
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import yaml
    yaml_literal = toml_dumps({
            "key1": "value1",
            "key2": {"key21": "value21", "key22": ["value221", "value222"]},
            "key3": [{"key31": "value31", "key32": "value32"}, "value3"],
            "key4": AnsibleUnsafeText("value4"),
            "key5": AnsibleUnsafeBytes("value5"),
            "key6": AnsibleUnsafeText(b"value6"),
            "key7": AnsibleUnsafeBytes(b"value7"),
            "key8": object
    })