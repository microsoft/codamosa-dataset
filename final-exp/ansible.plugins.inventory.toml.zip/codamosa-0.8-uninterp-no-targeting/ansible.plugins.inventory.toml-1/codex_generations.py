

# Generated at 2022-06-21 05:22:17.299723
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = 'test_path.toml'
    y = InventoryModule()
    assert y.verify_file(path)
    return True


# Generated at 2022-06-21 05:22:28.419384
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert sys.version_info >= (2, 7)
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.module_utils.six.moves import StringIO
    import json

    testargs = [
        "ansible-inventory",
        "--list",
        "--export",
        "--yaml",
        "--output",
        "-"
    ]
    if not PY3:
        testargs.append(u"--host=" + to_text(PYTOML_TEST_HOST, errors='surrogate_or_strict'))

    testargs.append(PYTOML_TEST_INVENTORY)

   

# Generated at 2022-06-21 05:22:34.559130
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    # Test inventory file
    path = '/tmp/test.toml'
    assert plugin.verify_file(path) == True
    # Test non-inventory file
    path = '/tmp/test.yml'
    assert plugin.verify_file(path) == False


# Generated at 2022-06-21 05:22:48.089849
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins import inventory
    from ansible.parsing.yaml.loader import AnsibleLoader

    loader = AnsibleLoader(None, True)
    inventory_instance = inventory.InventoryModule()
    path = '/path/to/inventory/file'

# Generated at 2022-06-21 05:23:00.685889
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    tomlinventory = InventoryModule()
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['test/inventory/test.toml'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    tomlinventory.parse(inventory, loader, 'test/inventory/test.toml')

    host = inventory.get_host(hostname="test")
    assert host.get_variables() == {}
    assert host.get_vars() == {'ansible_user': 'root', 'g1': True}
    assert host.get_groups() == ['ungrouped']
    assert inventory.get_groups_dict

# Generated at 2022-06-21 05:23:09.909952
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    path = "inventory_file"
    module.display = MagicMock()
    module.display.verbosity = 0
    module.loader = Mock()
    module.loader.path_exists = Mock(return_value=True)
    module.loader.path_dwim = Mock(return_value=True)
    with patch.object(os.path, 'splitext') as mock_splitext:
        mock_splitext.return_value = (path, '.toml')
        module.parse = Mock(return_value=True)
        assert module.verify_file(path) is True

        mock_splitext.return_value = (path, '.yaml')
        assert module.verify_file(path) is False


# Generated at 2022-06-21 05:23:15.970490
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_plugin = InventoryModule()

    res = test_plugin.verify_file('/tmp/test_ansible/hosts')
    assert res == False

    res = test_plugin.verify_file('/tmp/test_ansible/hosts.toml')
    assert res == True

# Generated at 2022-06-21 05:23:30.554334
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_file = 'sample.toml'
    try:
        # Initialise the InventoryModule class and assign to instance ivm
        ivm = InventoryModule()

        # Call the parse method of the class
        ivm.parse(inventory_file, loader=None, path=None)
        print("TOML inventory file parsing successful")
    except AnsibleParserError as e:
        # print(e)
        print("Ansible Parser Error:")
        print("Reason for Error:",e.message)
    except Exception as e:
        # print(e)
        print("Reason for Error:",e.message)

# Verify if the file sample.toml is a valid TOML file to be parsed
if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:23:40.782262
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Testing dict
    dict_unicode = {
        AnsibleUnicode(u'ansible'): AnsibleUnicode(u'python')
    }
    dict_unsafe_text = {
        AnsibleUnsafeText(u'ansible'): AnsibleUnsafeText(u'python')
    }
    dict_unsafe_bytes = {
        AnsibleUnsafeBytes(b'ansible'): AnsibleUnsafeBytes(b'python')
    }
    dict_ansible_sequence = {
        AnsibleSequence([u'ansible'], loader=None, fa=None, line=1, column=1, stream=None, name=None):
        AnsibleSequence([u'python'], loader=None, fa=None, line=1, column=1, stream=None, name=None)
    }

# Generated at 2022-06-21 05:23:45.742600
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_module = InventoryModule()
    assert inv_module.verify_file("/tmp/inventory.toml")
    assert not inv_module.verify_file("/tmp/inventory.yaml")


# Generated at 2022-06-21 05:24:00.050131
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    # Test with a filename that has wrong extension
    assert not plugin.verify_file('/tmp/hosts.sample')
    # Test with a filename that has correct extension
    assert plugin.verify_file('/tmp/hosts.toml')
    # Test with a filename that has correct extension with leading dot
    assert plugin.verify_file('./hosts.toml')

# Generated at 2022-06-21 05:24:15.575699
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    def MockedInventoryModule_verify_file(path, orig_method=None):
        if path == 'fake_file':
            return False
        else:
            if orig_method is None:
                orig_method = InventoryModule.verify_file
            return orig_method(path)

    # Patch method verify_file of class InventoryModule for the unit test
    with patch.object(InventoryModule, 'verify_file', side_effect=MockedInventoryModule_verify_file) as patched_method:
        inv = InventoryModule()
        assert not inv.verify_file('fake_file')

        assert inv.verify_file('fake_file.yaml')
        assert inv.verify_file('fake_file.yml')
        assert inv.verify_file('fake_file.ini')
        assert inv

# Generated at 2022-06-21 05:24:18.711279
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {'foobar': 'foobar'}
    output = toml_dumps(data)
    assert output == 'foobar = "foobar"\n'

# Generated at 2022-06-21 05:24:34.406970
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    data = "[servers]\nhost1={\n}\nhost2={\nansible_port=222\n}\nhost3={\nansible_host=127.0.0.1\nansible_port=33\n}\nhost4={\nansible_host=10.20.30.40\nansible_port=44\n}\nhost5={\nansible_host=99.88.77.66\nansible_port=55\n}"

    inv = InventoryModule()
    inv.parse(data, "my_file")
    host1 = inv.get_host("host1")
    host2 = inv.get_host("host2")
    host3 = inv.get_host("host3")
    host4 = inv.get_host("host4")
    host5 = inv

# Generated at 2022-06-21 05:24:38.135669
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    invModule = InventoryModule()
    invModule.parse('inventory', 'loader', 'path')
    # with the default TOML plugin code, verify_file will always return False
    assert invModule.verify_file('.') == False
    # TODO: test_InventoryModule: add actual test

# Generated at 2022-06-21 05:24:43.014815
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    InventoryModule._is_valid_file = lambda self, _: True
    inv = InventoryModule()
    assert inv.verify_file('/tmp/foo.toml')
    assert not inv.verify_file('/tmp/foo.yaml')
    assert not inv.verify_file('/tmp/foo.toml.swp')

# Generated at 2022-06-21 05:24:45.098206
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    mod = InventoryModule()
    assert mod.NAME == 'toml'

# Generated at 2022-06-21 05:24:52.394956
# Unit test for function toml_dumps
def test_toml_dumps():
    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader

    content = yaml.safe_load(EXAMPLES)
    data = AnsibleLoader(content).get_single_data()
    dumped = toml_dumps(data)
    if dumped != content:
        raise Exception('TOML dumped data does not match original.')

# Generated at 2022-06-21 05:25:00.360266
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Unit test for method parse of class InventoryModule"""
    # fmt: off

# Generated at 2022-06-21 05:25:16.143675
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_path = os.path.dirname(os.path.realpath(__file__))
    with open(os.path.join(inventory_path, "toml_test_inventory_parse.toml")) as example:
        data_input = example.readlines()
    test_data = "".join(data_input)
    data = InventoryModule()._load_file(test_data)
    assert data['all.vars'] == {'has_java': False}
    assert data['web']['children'] == ["apache", "nginx"]
    assert data['web']['vars'] == {'http_port': 8080, 'myvar': 23}
    assert data['web.hosts'] == {'host1': {}, 'host2': {'ansible_port': 222}}

# Generated at 2022-06-21 05:25:32.980964
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'toml'


# Generated at 2022-06-21 05:25:42.749893
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    d = { "foo": "bar", "baz": [1, 2] }
    r = convert_yaml_objects_to_native(d)
    assert type(r) == dict
    assert type(r["foo"]) == text_type
    assert type(r["baz"]) == list
    assert type(r["baz"][0]) == int
    assert type(r["baz"][1]) == int
    d = { "foo": "bar", "baz": [1, AnsibleUnsafeText("2")] }
    r = convert_yaml_objects_to_native(d)
    assert type(r) == dict
    assert type(r["foo"]) == text_type
    assert type(r["baz"]) == list
    assert type(r["baz"][0]) == int

# Generated at 2022-06-21 05:25:58.685409
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    class TestEncoder(object):
        def encode(self, obj):
            return obj
    import yaml
    yaml.SafeDumper.add_representer(AnsibleSequence, TestEncoder().encode)
    yaml.SafeDumper.add_representer(AnsibleUnicode, TestEncoder().encode)
    yaml.SafeDumper.add_representer(AnsibleUnsafeBytes, TestEncoder().encode)
    yaml.SafeDumper.add_representer(AnsibleUnsafeText, TestEncoder().encode)
    # Test for dict

# Generated at 2022-06-21 05:26:05.100365
# Unit test for function toml_dumps
def test_toml_dumps():
    import json
    import yaml

    data = {}
    data['foo'] = 'bar'
    data['baz'] = 123
    data['bar'] = AnsibleUnsafeText(b'test')
    data['nested'] = {
        'unicode': AnsibleUnicode('unicode test'),
        'unsafe_bytes': AnsibleUnsafeBytes(b'unsafe bytes test'),
    }
    data['list'] = [
        AnsibleUnicode('unicode test'),
        AnsibleUnsafeBytes(b'unsafe bytes test'),
        AnsibleUnsafeText(b'test'),
    ]
    data['sequence'] = AnsibleSequence(data['list'])
    test_data = json.loads(json.dumps(data))
    assert data == test_data


# Generated at 2022-06-21 05:26:08.449126
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    # Assert __init__ has defined the three default attributes
    assert im.NAME == 'toml'

# Generated at 2022-06-21 05:26:23.971667
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:26:35.006279
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:26:40.666576
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    path = 'file.toml'

    file_name = 'file'
    ext = '.toml'
    assert module.verify_file(path)


# Generated at 2022-06-21 05:26:55.933107
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert isinstance(convert_yaml_objects_to_native("hello world"), text_type)
    assert isinstance(convert_yaml_objects_to_native(u"hello world"), text_type)

    assert isinstance(convert_yaml_objects_to_native(AnsibleUnicode("hello world")), text_type)
    assert isinstance(convert_yaml_objects_to_native(AnsibleUnsafeBytes("hello world")), text_type)
    assert isinstance(convert_yaml_objects_to_native(AnsibleUnsafeText("hello world")), text_type)

    assert isinstance(convert_yaml_objects_to_native(u"hello world"  # pylint: disable=no-member
                                                     ), text_type)


# Generated at 2022-06-21 05:26:58.294502
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert isinstance(inv, InventoryModule)

# Generated at 2022-06-21 05:27:12.169080
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    filename = '~/ansible_devel/contrib/inventory/test/valid_toml_inventory.toml'
    inventory_module = InventoryModule()
    parser_error = inventory_module.parse(None, None, filename)
    assert parser_error is None
    """

    pass


# Generated at 2022-06-21 05:27:26.874520
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText
    assert convert_yaml_objects_to_native(AnsibleUnicode('foo')) == 'foo'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes(b'foo')) == 'foo'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('foo')) == 'foo'

# Generated at 2022-06-21 05:27:38.091511
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    data = [
        {'ansible_host': u'1.2.3.4'},
        {'ansible_host': '1.2.3.5'}
    ]
    converted_data = convert_yaml_objects_to_native(data)
    assert converted_data[0]['ansible_host'] == '1.2.3.4'

    data = AnsibleUnicode('123')
    data = convert_yaml_objects_to_native(data)
    assert data == '123'

    data = AnsibleUnsafeText(u'123')
    data = convert_yaml_objects_to_native(data)
    assert data == '123'

    data = AnsibleUnsafeBytes(b'123')
    data = convert_yaml_objects_to_native(data)
   

# Generated at 2022-06-21 05:27:52.986237
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native(None) is None
    assert convert_yaml_objects_to_native(True) is True
    assert convert_yaml_objects_to_native(1) == 1
    assert convert_yaml_objects_to_native('a') == 'a'
    assert convert_yaml_objects_to_native(AnsibleSequence([])) == []
    assert convert_yaml_objects_to_native(AnsibleUnicode('a')) == 'a'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('a')) == 'a'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes('a')) == 'a'

# Generated at 2022-06-21 05:28:01.588255
# Unit test for function toml_dumps
def test_toml_dumps():
    assert(toml_dumps({
        'cluster': {
            'server': '192.168.1.1'
        },
        'hosts': [
            'alpha',
            'omega'
        ]
    })) == r'''cluster = {
  server = "192.168.1.1"
}

hosts = ["alpha", "omega"]'''
    assert(toml_dumps([
        {'foo': 7},
        {'bar': 'baz'}
    ])) == r'[\n  {\n    foo = 7\n  },\n  {\n    bar = "baz"\n  }\n]'

# Generated at 2022-06-21 05:28:09.438532
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import ansible.parsing.yaml.objects
    objects = [
        (AnsibleSequence([1, 2, 3]), [1, 2, 3]),
        (AnsibleUnicode('Hello'), 'Hello'),
        (AnsibleUnsafeBytes(b'Secret'), 'Secret'),
        (AnsibleUnsafeText('Pass'), 'Pass'),
        (AnsibleUnicode('Hello'), 'Hello'),
    ]
    for obj in objects:
        assert obj[0] != convert_yaml_objects_to_native(obj[0])
        assert obj[1] == convert_yaml_objects_to_native(obj[0])

# Generated at 2022-06-21 05:28:17.615303
# Unit test for function toml_dumps
def test_toml_dumps():
    try:
        import yaml
    except:
        pass
    try:
        # https://raw.githubusercontent.com/toml-lang/toml/master/tests/regression.toml
        res = yaml.load(EXAMPLES)
        res2 = toml.loads(to_native(toml_dumps(res)))
        assert res == res2
    except:
        raise Exception("Cannot load TOML library")

# Generated at 2022-06-21 05:28:30.954124
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    # Simple conversion
    assert convert_yaml_objects_to_native(['foo']) == ['foo']
    assert convert_yaml_objects_to_native({'foo': 'bar'}) == {'foo': 'bar'}

    # Conversion with nested structures
    assert convert_yaml_objects_to_native({'foo': ['bar']}) == {'foo': ['bar']}
    assert convert_yaml_objects_to_native({'foo': [{'bar': 'baz'}]}) == {'foo': [{'bar': 'baz'}]}

    # Conversion with YAML object types

# Generated at 2022-06-21 05:28:42.064023
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    loader = MockDataLoader()
    inventory = MockInventory()
    path = "/path/to/toml"
    data = '''
    [ungrouped]
    foo ansible_host=127.0.0.1

    [g1]
    foo

    [g2]
    foo
    '''
    with patch('__builtin__.open', mock_open(read_data=data)):
        toml_inventory = InventoryModule()
        toml_inventory.parse(inventory=inventory, loader=loader, path=path, cache=False)


# Generated at 2022-06-21 05:28:54.894815
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {
        'all.vars': {
            'has_java': False
        },
        'web': {
            'children': [
                "apache",
                "nginx"
            ],
            'hosts': {
                'host1': {},
                'host2': {'ansible_port':222}
            }
        },
        'apache': {
            'hosts': {
                'tomcat1': {},
                'tomcat2': {'myvar':34},
                'tomcat3': {'mysecret':'03#pa33w0rd'}
            }
        },
        'nginx': {
            'hosts': {
                'jenkins1': {}
            }
        }
    }
    plugin = InventoryModule()

# Generated at 2022-06-21 05:29:04.580027
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None



# Generated at 2022-06-21 05:29:19.677546
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # load, parse and load cache
    inv = InventoryModule()
    toml_string1 = r"""
        # Example 1
        [all.vars]
        has_java = false

        [web]
        children = [
            "apache",
            "nginx"
        ]
        vars = { http_port = 8080, myvar = 23 }

        [web.hosts]
        host1 = {}
        host2 = { ansible_port = 222 }

        [apache.hosts]
        tomcat1 = {}
        tomcat2 = { myvar = 34 }
        tomcat3 = { mysecret = "03#pa33w0rd" }

        [nginx.hosts]
        jenkins1 = {}

        [nginx.vars]
        has_java = true
    """
   

# Generated at 2022-06-21 05:29:34.716768
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText
    from ansible.parsing.yaml import objects

    assert toml_dumps({'a': 1, 'b': {'c': [2, 3]}}) == text_type('a = 1\nb = {\n  c = [\n    2,\n    3\n  ]\n}\n')

    assert toml_dumps({'a': [1, 2, {'b': 3}]}) == text_type('a = [\n  1,\n  2,\n  {\n    b = 3\n  }\n]\n')

    assert toml_dumps({'a': [1, 2, {'b': {'c': 3}}]})

# Generated at 2022-06-21 05:29:40.071712
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """ Unit test for method parse of class InventoryModule """
    # Arrange
    inventory_module = InventoryModule()
    inventory_module.parse(inventory={}, loader={}, path='./Toml_inventory.toml')

    # Act/Assert
    # tests inside of the method

# Generated at 2022-06-21 05:29:55.118786
# Unit test for function toml_dumps
def test_toml_dumps():
    def dict_equals(a, b):
        for k, v in a.items():
            assert k in b
            assert v == b[k]

    def list_equals(a, b):
        assert len(a) == len(b)
        for v in a:
            assert v in b


# Generated at 2022-06-21 05:30:01.800250
# Unit test for function toml_dumps
def test_toml_dumps():
    class Test:
        def __repr__(self):
            return 'Test<1>'

    data = {
        'Test': Test(),
    }


# Generated at 2022-06-21 05:30:07.975766
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import tempfile
    import pytest
    import ansible.plugins.loader as plugins

    # Test using an invalid inventory
    invalid_inventory = """
    [group.vars]
    """
    plugins.clear_all_inventory_plugins()
    inventory_path = os.path.join(tempfile.mkdtemp(), 'test_inventory')
    with open(inventory_path,'w') as inventory_file:
        inventory_file.write(invalid_inventory)
    valid_inventory = {}

    # Test failure for non-existent file
    inventory_nonexistent_file = 'this_file_should_not_exist.toml'

# Generated at 2022-06-21 05:30:19.380409
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=[])
    myplugin = InventoryModule()

    # check if valid path is recognized as such
    path = 'test.toml'
    assert myplugin.verify_file(path)

    # check if non-toml files are recognized as non-toml
    path = 'test.yaml'
    assert not myplugin.verify_file(path)

    # check if TOML file is not recognized as yaml
    path = 'test.yaml'
    assert not myplugin.verify_file(path)

    # check if empty TOML is recognized as such

# Generated at 2022-06-21 05:30:26.794355
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """
    Test the method verify_file of the class InventoryModule.
    """
    inventory_module = InventoryModule()

    assert(inventory_module.verify_file("/path/to/playbook.yml") == False)
    assert(inventory_module.verify_file("/path/to/playbook.yaml") == False)
    assert(inventory_module.verify_file("/path/to/playbook") == False)
    assert(inventory_module.verify_file("/path/to/playbook.toml") == True)

# Generated at 2022-06-21 05:30:38.080243
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():

    class InheritsFromSequence(list):
        pass

    class InheritsFromText(str):
        pass

    example_dict = {
        'k1': 'v1',
        'k2': [1, 2, 3, {'k22': [1,2, 3]}],
        'k3': {
            'k31': 'v31',
            'k32': {
                'k321': 'v321',
                'k322': [1, 2, 3],
                'k323': {
                    'k3231': 'v3231',
                    'k3232': [1, 2, 3]
                }
            }
        }
    }


# Generated at 2022-06-21 05:30:46.849247
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()

# Generated at 2022-06-21 05:30:49.214808
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    path = '/tmp/some_file'
    assert InventoryModule(path)

# Generated at 2022-06-21 05:30:54.903742
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    path = 'my_path.toml'
    result = inv_mod.verify_file(path)
    assert result == True

    path = 'my_path.yml'
    result = inv_mod.verify_file(path)
    assert result == False

# Generated at 2022-06-21 05:30:57.396334
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' inventory module construct test'''
    assert InventoryModule(loader=None, groups=None)

# Generated at 2022-06-21 05:31:09.551732
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import unittest

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping

    class TestConvertYamlObjectsToNative(unittest.TestCase):
        def test_string(self):
            self.assertEqual(convert_yaml_objects_to_native('hello'), 'hello')
            self.assertEqual(convert_yaml_objects_to_native(AnsibleUnicode('hello')), 'hello')

        def test_dict(self):
            self.assertEqual(convert_yaml_objects_to_native(dict(a='b')), dict(a='b'))

# Generated at 2022-06-21 05:31:19.392122
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''Unit test for method parse of class InventoryModule'''
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.mod_args import ModuleArgsParser
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inv_data = loader.load_from_file('/Users/brianmullen/code/ansible/plugins/inventory/test_toml.toml')

    # create the inventory and get groups and hosts
    inventory = InventoryManager(loader=loader, sources=['/Users/brianmullen/code/ansible/plugins/inventory/test_toml.toml'])

# Generated at 2022-06-21 05:31:25.678606
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.representer import AnsibleSafeRepresenter

    data = [
        AnsibleSequence(['a', 'b']),
        AnsibleSequence([AnsibleMapping([('a', 'a')]), AnsibleMapping([('b', 'b')])]),
        AnsibleUnicode('a'),
        AnsibleUnsafeBytes('a'),
        AnsibleUnsafeText('a'),
    ]

# Generated at 2022-06-21 05:31:36.696365
# Unit test for function toml_dumps
def test_toml_dumps():
    if HAS_TOML and not hasattr(toml, 'TomlEncoder'):
        for obj in (
            AnsibleSequence([1, 2, 3]),
            AnsibleUnicode('foo'),
            AnsibleUnsafeBytes('bar'.encode('utf-8')),
            AnsibleUnsafeText('baz')):
            assert toml_dumps(obj) == toml.dumps(convert_yaml_objects_to_native(obj))
    else:
        assert True

# Generated at 2022-06-21 05:31:50.178110
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml import objects as y_objects
    # fmt: off
    data = {
        "name": "Tom Preston-Werner",
        "company": {
            "name": "GitHub",
            "location": "San Francisco"
        },
        "dot": {
            "hello": "world",
            "test": ["foo", "bar"]
        },
        "list": ["one", 2, b"3"],
        "single": y_objects.AnsibleUnicode('str'),
        "unsafe_text": y_objects.AnsibleUnsafeText('str'),
        "unsafe_bytes": y_objects.AnsibleUnsafeBytes(b'bytes')
    }
    # fmt: on


# Generated at 2022-06-21 05:32:02.033361
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.dumper import AnsibleDumper
