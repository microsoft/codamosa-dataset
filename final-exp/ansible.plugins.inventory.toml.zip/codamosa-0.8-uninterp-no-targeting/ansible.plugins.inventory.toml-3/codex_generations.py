

# Generated at 2022-06-21 05:22:21.181238
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Create an inventory module object
    inventory = InventoryModule()
    # If extension is .toml, then path is verified
    assert inventory.verify_file("test/test.toml")
    # If extension is not .toml, then path is verified
    assert not inventory.verify_file("test/test.yaml")
    # If path is not valid, then path is not verified
    assert not inventory.verify_file("test/test.txt")
    # If path does not exist, then path is not verified
    assert not inventory.verify_file("test/test.tt")


# Generated at 2022-06-21 05:22:29.689925
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import sys


# Generated at 2022-06-21 05:22:39.502169
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class Plugin(BaseFileInventoryPlugin):
        NAME = 'toml'
        def verify_file(self, path):
            pass

# Generated at 2022-06-21 05:22:44.446364
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Test with a source that is not a file
    source = 'http://example.com/example.toml'
    inventory_module = InventoryModule()
    try:
        inventory_module.parse(None, None, source)
        assert False
    except AnsibleParserError:
        assert True

    # Test with a source that is the path to a existing file
    source = 'test.toml'
    with open(source, 'w') as f:
        f.write('')
    inventory_module = InventoryModule()
    try:
        inventory_module.parse(None, None, source)
        assert True
    except AnsibleParserError:
        assert False
    os.remove(source)

    # Test with a source that is the path to a non-existent file
    source = 'test.toml'
    inventory_module

# Generated at 2022-06-21 05:22:56.115469
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # NOTE: The YAML objects are already created by the test system.
    #       We need to grab them and pass them through the
    #       convert_yaml_objects_to_native function to make sure
    #       it works as expected
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.test.test_vault import test_vault_text

    test_data = {'vault_test': test_vault_text}

# Generated at 2022-06-21 05:23:00.891985
# Unit test for function toml_dumps
def test_toml_dumps():
    expected = '''
[foo]
bar = "baz"
'''.strip()

    assert expected == toml_dumps(dict(foo=dict(bar='baz')))


# Generated at 2022-06-21 05:23:02.852204
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod is not None

# Generated at 2022-06-21 05:23:09.984954
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file('/etc/ansible/hosts')
    assert not module.verify_file('/etc/ansible/hosts.yml')
    assert module.verify_file('/etc/ansible/hosts.toml')
    assert not module.verify_file('/etc/ansible/hosts.yaml')

# Generated at 2022-06-21 05:23:11.944991
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Constructor test
    module = InventoryModule()
    assert module


# Generated at 2022-06-21 05:23:21.055822
# Unit test for function toml_dumps
def test_toml_dumps():
    d = {'a': 1, 'b': 2, 'c': 3}
    expected = 'a = 1\nb = 2\nc = 3\n'
    assert toml_dumps(d) == expected

    d = {'a': {'b': {'c': {'d': 'e'}}}}
    expected = 'a.b.c.d = "e"\n'
    assert toml_dumps(d) == expected

    d = [{'a': 'b'}, {'b': 'c'}]
    expected = '[[a]]\na = "b"\n\n[[b]]\nb = "c"\n'
    assert toml_dumps(d) == expected

    d = [{'a': 'b'}, {'b': 'c'}]

# Generated at 2022-06-21 05:23:32.042080
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.NAME == 'toml'


# Generated at 2022-06-21 05:23:41.241328
# Unit test for function toml_dumps
def test_toml_dumps():
    from types import DictType

    # These are (subclasses of) the types in ansible.parsing.yaml.objects
    assert type(toml_dumps(AnsibleUnicode(u'\u2014'))) == toml.TomlString
    assert type(toml_dumps(AnsibleUnsafeText(u'\u2014'))) == toml.TomlString
    assert type(toml_dumps(AnsibleUnsafeBytes(u'\u2014'))) == toml.TomlString

    assert type(toml_dumps(AnsibleSequence([u'\u2014']))) == list
    assert type(toml_dumps(AnsibleSequence([AnsibleUnicode(u'\u2014')]))) == list

# Generated at 2022-06-21 05:23:52.071936
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:24:02.736442
# Unit test for function toml_dumps
def test_toml_dumps():
    import six


# Generated at 2022-06-21 05:24:06.914647
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    im = InventoryModule()
    assert im.verify_file("./tests/data/toml_inventory.toml")
    assert not im.verify_file("./tests/data/inventory.ini")

# Generated at 2022-06-21 05:24:14.312663
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText
    dict_obj = {
        'a': AnsibleUnicode('a unicode strinG'),
        'b': AnsibleUnsafeText('an unsafe Text'),
        'c': AnsibleUnsafeBytes('an unsafe bYtes string'),
        'd': AnsibleSequence([1, 2, 3]),
        'e': { 1: 'this nested' },
        'f': [
            [
                'a list with sub list'
            ],
            {
                'a': 'a dict object in list'
            }
        ]
    }
    result = convert_yaml_objects_to_native(dict_obj)

# Generated at 2022-06-21 05:24:15.215029
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None


# Generated at 2022-06-21 05:24:23.608035
# Unit test for function toml_dumps
def test_toml_dumps():
    test_data = {
        "hosts": {
            "host1": {
                "ansible_host": "127.0.0.1",
                "ansible_port": 2222,
                "ansible_user": "testuser",
                "ansible_ssh_pass": "testpass",
            },
        },
    }
    expected_return = "[hosts.host1]\nansible_host = \"127.0.0.1\"\nansible_port = 2222\nansible_user = \"testuser\"\n" \
                      "ansible_ssh_pass = \"testpass\"\n"
    assert expected_return == toml_dumps(test_data)

# Generated at 2022-06-21 05:24:26.252810
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    INVENTORY_PATH = './tests/test_data/inventory/test.toml'
    display = Display()
    display.verbosity = 2

    inventory_module.parse(None, None, INVENTORY_PATH, cache=True)


# Generated at 2022-06-21 05:24:28.302557
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: create unit test
    assert False


# Generated at 2022-06-21 05:24:54.948948
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native([0, 1]) == [0, 1]
    assert convert_yaml_objects_to_native([{'a': u'A'}]) == [{'a': text_type(u'A')}]
    assert convert_yaml_objects_to_native({'a': u'A'}) == {'a': text_type(u'A')}
    assert convert_yaml_objects_to_native({'a': {'a': u'A'}}) == {'a': {'a': text_type(u'A')}}

# Generated at 2022-06-21 05:25:00.582123
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:25:16.378498
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    string_type = "string"
    int_type = 444
    float_type = 44.44
    bool_type = True
    list_type = [string_type, int_type]
    dict_type = {'key1': string_type, 'key2': int_type, 'key3': float_type}
    ansible_unicode_type = AnsibleUnicode(string_type)
    ansible_bytes_type = AnsibleUnsafeBytes(string_type)
    ansible_text_type = AnsibleUnsafeText(string_type)
    ansible_list_type = AnsibleSequence(list_type)

    assert string_type == convert_yaml_objects_to_native(string_type)
    assert int_type == convert_yaml_objects_to_native(int_type)
   

# Generated at 2022-06-21 05:25:22.228338
# Unit test for function toml_dumps
def test_toml_dumps():
    test_data = {
        'a': 1,
        'b': 2,
        'c': [1,2,3],
        'd': {
             'a': 1,
             'b': 2,
             'c': [1,2,3],
        },
    }
    toml_data = toml_dumps(test_data)
    assert toml_data == '[a]\n1\n\n[b]\n2\n\n[c]\n[1, 2, 3]\n\n[d]\n[a]\n1\n\n[b]\n2\n\n[c]\n[1, 2, 3]\n\n'

# Generated at 2022-06-21 05:25:29.850843
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'a': 1, 'b': 2}) == 'a = 1\nb = 2\n'
    assert toml_dumps({'a': 1, 'b': [1, 2, 3]}) == 'a = 1\nb = [1, 2, 3]\n'
    assert toml_dumps({'a': 1, 'b': {'c': 1}}) == 'a = 1\n[b]\nc = 1\n'
    # Testing for custom types

# Generated at 2022-06-21 05:25:41.563910
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeText

    assert convert_yaml_objects_to_native(AnsibleUnsafeText(u'text')) == u'text'
    assert convert_yaml_objects_to_native(AnsibleUnicode(u'unicode')) == u'unicode'
    assert convert_yaml_objects_to_native(AnsibleSequence([u'foo', u'bar'], loader=None)) == [u'foo', u'bar']
    assert convert_yaml_objects_to_native({u'foo': 1, u'bar': 2}) == {'foo': 1, 'bar': 2}
    assert convert_yaml_objects_to_native(1) == 1


# Generated at 2022-06-21 05:25:53.661265
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    ### Mapping
    # Emtpy
    assert convert_yaml_objects_to_native({}) == {}
    # No need to convert
    assert convert_yaml_objects_to_native({'foo': 'bar'}) == {'foo': 'bar'}
    # Must convert keys
    assert convert_yaml_objects_to_native({AnsibleUnicode('foo'): 'bar'}) == {'foo': 'bar'}
    # Must convert keys
    assert convert_yaml_objects_to_native({AnsibleUnsafeText('foo'): 'bar'}) == {'foo': 'bar'}
    # Must convert keys
    assert convert_y

# Generated at 2022-06-21 05:25:59.456062
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    result = InventoryModule.verify_file(None, "/tmp/test.toml")
    assert result == True, "Failed to verify toml file"
    result = InventoryModule.verify_file(None, "/tmp/test.yml")
    assert result == False, "Failed to verify yaml file"

# Generated at 2022-06-21 05:26:03.203090
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Create plugin object
    plugin = InventoryModule()
    # Verify TOML file
    assert plugin.verify_file("foo.toml") == True


# Generated at 2022-06-21 05:26:04.468070
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # TODO: test on valid and invalid file types
    pass

# Generated at 2022-06-21 05:26:26.260630
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert inv.verify_file('/tmp/test.toml') == True
    assert inv.verify_file('/tmp/test.ini') == False



# Generated at 2022-06-21 05:26:35.482823
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnsafeText, AnsibleUnsafeBytes, AnsibleUnicode, AnsibleSequence


# Generated at 2022-06-21 05:26:46.973573
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars import VariableManager
    from ansible.inventory import Inventory
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inventory = Inventory(loader=loader, variable_manager=VariableManager(), host_list=[])
    test_module = InventoryModule()

    # The test data is a TOML file with three groups: ungrouped, g1, and g2. The ungrouped group
    # contains three hosts: host1, host2, and host3; host2 and host3 have the ansible_host and
    # the ansible_port variables set. The groups g1 and g2 both contain a single host named host4.
    # In addition, g2 has the ansible_host and the ansible_port variables set.
   

# Generated at 2022-06-21 05:26:48.912888
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    mod = InventoryModule()
    assert mod.NAME == 'toml'


# Generated at 2022-06-21 05:26:57.167361
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import tempfile
    import unittest

    from ansible.plugins.loader import inventory_loader

    class InventoryModuleTests(unittest.TestCase):
        def setUp(self):
            self.tmpdir = tempfile.mkdtemp()

        def tearDown(self):
            # Remove temporary directory
            os.rmdir(self.tmpdir)


# Generated at 2022-06-21 05:27:06.634131
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    test_input = toml_dumps({1: 'a', 2: {'b': [1, 2, 3]}})
    assert test_input == '1 = "a"\n\n[2]\n  b = [1, 2, 3]\n'

    test_input = toml_dumps({1: {'a': {'b': 1}}})
    assert test_input == '[1]\n  a = {b = 1}\n'

    test_input = toml_dumps({1: [1, 2, AnsibleUnsafeText('####')]})
    assert test_input == '1 = [1, 2, "####"]\n'

# Generated at 2022-06-21 05:27:10.369870
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    path = ':memory:'
    loader = None
    inventory = None
    data = InventoryModule().parse(inventory, loader, path)
    assert data is not None

# Generated at 2022-06-21 05:27:13.466497
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    loader = DataLoader()
    inventory = InventoryManager(loader, sources='')
    InventoryModule.parse(inventory, loader, path='hosts.toml', cache=True)

# Generated at 2022-06-21 05:27:27.182141
# Unit test for function toml_dumps
def test_toml_dumps():
    try:
        from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    except ImportError:
        return
    assert toml_dumps({'test': ['a', 'b']}) == 'test = [ "a", "b" ]\n'
    assert toml_dumps({'test': {'a': 'b'}}) == 'test = { a = "b" }\n'
    assert toml_dumps({'test': AnsibleSequence()}) == 'test = []\n'
    assert toml_dumps({'test': AnsibleSequence((1, 2, 3))}) == 'test = [ 1, 2, 3, ]\n'
    assert toml_dumps({'test': 'test'}) == 'test = "test"\n'
   

# Generated at 2022-06-21 05:27:32.830695
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file('/tmp/test_file.toml') == True
    assert InventoryModule().verify_file('/tmp/test_file.yaml') == False
    assert InventoryModule().verify_file('/tmp/test_file.json') == False
    assert InventoryModule().verify_file('/tmp/test_file') == False

# Generated at 2022-06-21 05:28:19.784233
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    from .mock_loader import DictDataLoader
    from .mock_inventory import TestInventoryPlugin

    from ansible.parsing.dataloader import DataLoader

    plugin = InventoryModule()

    plugin.display = Display()

    data = """
    [all]
    foo:
        hosts:
            foo:
                ansible_host: 127.0.0.1
    """

    data_loader = DataLoader()
    data_loader.set_basedir('/etc/ansible')
    plugin.loader = DictDataLoader({
        '/etc/ansible/hosts': data
    })

    inventory = TestInventoryPlugin()
    inventory.host_list = []

    fun = partial(plugin.parse, inventory=inventory, loader=plugin.loader, path='/etc/ansible/hosts')

   

# Generated at 2022-06-21 05:28:22.758459
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins.inventory import InventoryModule
    inv = InventoryModule()
    assert inv is not None

# Generated at 2022-06-21 05:28:29.988051
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = {}
    loader = None
    path = "/home/vagrant/ansible/plugins/inventory/toml/test.toml"

    # Init an instance of InventoryModule class
    im = InventoryModule()

    # Call method parse of class InventoryModule with given params
    im.parse(inventory, loader, path)

    # Print the result
    print(inventory)


# Generated at 2022-06-21 05:28:41.702805
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Test 1
    yaml_file = '''# Inventory file data
    [all.vars]
    has_java = false

    [web]
    children = [
        "apache",
        "nginx"
    ]
    vars = { http_port = 8080, myvar = 23 }

    [web.hosts]
    host1 = {}
    host2 = { ansible_port = 222 }

    [apache.hosts]
    tomcat1 = {}
    tomcat2 = { myvar = 34 }
    tomcat3 = { mysecret = "03#pa33w0rd" }

    [nginx.hosts]
    jenkins1 = {}

    [nginx.vars]
    has_java = true'''
    # Test if the file is properly read, and if the data is

# Generated at 2022-06-21 05:28:44.472331
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Unit test for constructor of class InventoryModule
    # TODO
    pass



# Generated at 2022-06-21 05:28:46.980617
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module_class = type(InventoryModule)
    assert module_class._name == "toml"

# Generated at 2022-06-21 05:28:58.556456
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    input_dict = {
        'yaml_unsafe_bytes': AnsibleUnsafeBytes(b'unsafe_bytes'),
        'yaml_unsafe_text': AnsibleUnsafeText(u'text.py', True),
        'yaml_sequence': AnsibleSequence(['a', 1], sort=True)
    }
    expected_dict = {
        'yaml_unsafe_bytes': 'unsafe_bytes',
        'yaml_unsafe_text': u'text.py',
        'yaml_sequence': ['a', 1]
    }
    assert expected_dict == convert_yaml_objects_to_native(input_dict)

# Generated at 2022-06-21 05:29:03.967755
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule(None, None).verify_file('something.toml') == True
    assert InventoryModule(None, None).verify_file('something.other') == False
    assert InventoryModule(None, None).verify_file(None) == False
    assert InventoryModule(None, None).verify_file('') == False

# Generated at 2022-06-21 05:29:19.404908
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.module_utils.common._collections_compat import MutableSequence, MutableMapping
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.module_utils.six import text_type


# Generated at 2022-06-21 05:29:21.318379
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    m = InventoryModule()
    assert m.NAME == 'toml'

# Generated at 2022-06-21 05:30:04.055551
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible import context
    from ansible.module_utils.common.collections import ImmutableDict
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    inv = InventoryModule()
    dataloader = DataLoader()
    variable_manager = VariableManager(loader=dataloader)
    inv.parse('hosts', dataloader, "toml-inventory/test.toml", cache=False)

    inv_data = inv.inventory.get_host('host1').get_vars()
    assert inv_data['http_port'] == 8080
    assert inv_data['http_host'] == 'host1'

# Generated at 2022-06-21 05:30:18.086612
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native('test') == 'test'
    assert convert_yaml_objects_to_native(Foo('test')) == 'test'
    assert convert_yaml_objects_to_native({'foo': 'test'}) == {'foo': 'test'}
    assert convert_yaml_objects_to_native({'foo': Foo('test')}) == {'foo': 'test'}
    assert convert_yaml_objects_to_native([1, 2, 3]) == [1, 2, 3]
    assert convert_yaml_objects_to_native([1, 2, Foo('3')]) == [1, 2, '3']

# Generated at 2022-06-21 05:30:19.284973
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # This function is only for unit test
    # There is no automatic testing of this function
    # pass
    pass

# Generated at 2022-06-21 05:30:31.866574
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader
    import toml


# Generated at 2022-06-21 05:30:35.074211
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file("/tmp/inventory.toml")==True
    assert module.verify_file("/tmp/inventory.yml")==False

# Generated at 2022-06-21 05:30:43.075253
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()

    # default function argument
    assert (
        inventory_module.verify_file('/tmp/file.toml') is True
    ), 'This test should return True'
    assert (
        inventory_module.verify_file('/tmp/file.yml') is False
    ), 'This test should return False'

# Generated at 2022-06-21 05:30:45.127608
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    module = InventoryModule()
    module.parse(None, None, None, cache=True)

# Generated at 2022-06-21 05:30:57.325801
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.utils.unsafe_proxy import AnsibleUnsafeBytes, AnsibleUnsafeText

    assert convert_yaml_objects_to_native(AnsibleUnicode(u"foo")) == u"foo"
    assert convert_yaml_objects_to_native(AnsibleUnsafeText(u"foo")) == u"foo"
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes(b"foo")) == b"foo"
    assert convert_yaml_objects_to_native(AnsibleSequence([1, 2, 3])) == [1, 2, 3]

# Generated at 2022-06-21 05:31:09.526067
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    assert not InventoryModule().verify_file(__file__)
    assert InventoryModule().verify_file('example.toml')

    data = InventoryModule()._load_file('example.toml')
    assert 'all' in data
    assert 'web' in data
    assert 'apache' in data
    assert 'nginx' in data
    assert 'g1' in data
    assert 'g2' in data
    assert 'ungrouped' in data

    assert 'vars' in data['all']
    assert not isinstance(data['all']['vars'], text_type)
    assert not isinstance(data['all']['vars'], binary_type)
    assert 'has_java' in data['all']['vars']
    assert data['all']['vars']['has_java']

# Generated at 2022-06-21 05:31:19.391945
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_module = InventoryModule()
    data = inventory_module._load_file('../../../../test/units/plugins/inventory/test_inventory.toml')
    assert data['all']
    assert data['all']['vars']
    assert data['all']['vars']['has_java'] is False
    assert data['web']
    assert data['web']['children']
    assert data['web']['children'][0] == 'apache'
    assert data['web']['children'][1] == 'nginx'
    assert data['web']['vars']
    assert data['web']['vars']['http_port'] == '8080'
    assert data['web']['hosts']['host1']

# Generated at 2022-06-21 05:31:59.698320
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule(loader=None)

    assert obj.NAME == 'toml'
    assert obj.VERIFY_FILE is not None
    assert obj.loader is None
    assert obj.display is not None
    assert obj.inventory is None
    assert obj.options is None
    assert obj._options is None



# Generated at 2022-06-21 05:32:11.369811
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping, AnsibleSequence, AnsibleUnicode
    import yaml
    yaml.load = AnsibleBaseYAMLObject.load
    yaml.load_all = AnsibleBaseYAMLObject.load_all
    yaml.safe_load = AnsibleBaseYAMLObject.safe_load
    yaml.safe_load_all = AnsibleBaseYAMLObject.safe_load_all
    yaml.RoundTripLoader = AnsibleBaseYAMLObject

    data = {
        'a': {'b': {'c': 'd'}},
        'e': ['f', 'g'],
        'h': 'i',
    }
