

# Generated at 2022-06-21 05:22:19.722968
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import pytest

    test_cases = [
        pytest.param(
            AnsibleSequence(["a", "b", "c"]),
            [u"a", u"b", u"c"],
            id='AnsibleSequence'
        ),
        pytest.param(
            AnsibleUnicode(u"ü"),
            u"ü",
            id='AnsibleUnicode'
        ),
        pytest.param(
            AnsibleUnsafeBytes(b"\xfc"),
            u"\xfc",
            id='AnsibleUnsafeBytes'
        ),
        pytest.param(
            AnsibleUnsafeText(u"\xfc"),
            u"\xfc",
            id='AnsibleUnsafeText'
        ),
    ]

# Generated at 2022-06-21 05:22:21.769046
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_mod = InventoryModule()
    assert inv_mod is not None

# Generated at 2022-06-21 05:22:24.338310
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = 'tests/unit/plugins/inventory/inventory_toml_test_file.toml'
    obj = InventoryModule()
    assert InventoryModule.verify_file(obj, path)

# Generated at 2022-06-21 05:22:26.913862
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.verify_file

# Generated at 2022-06-21 05:22:27.839673
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    InventoryModule()

# Generated at 2022-06-21 05:22:38.784719
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.plugins.loader import toml_loader


# Generated at 2022-06-21 05:22:49.855937
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import io
    from io import StringIO
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.dumper import AnsibleDumper

    # START CODE FROM InventoryModule
    class InventoryModule(object):
        NAME = 'toml'

        def _parse_group(self, group, group_data):
            if group_data is not None and not isinstance(group_data, MutableMapping):
                self.display.warning("Skipping '%s' as this is not a valid group definition" % group)
                return

            group = self.inventory.add_group(group)
            if group_data is None:
                return


# Generated at 2022-06-21 05:23:01.064210
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    def assertConversion(obj_before, obj_after):
        result = convert_yaml_objects_to_native(obj_before)
        assert(result == obj_after)


# Generated at 2022-06-21 05:23:10.683569
# Unit test for function toml_dumps
def test_toml_dumps():
    # Simple dict
    assert b'''[foo]\nbar = "baz"\n''' == toml_dumps({'foo': {'bar': 'baz'}})
    # List
    assert b'''[foo]\nbar = [1, 2, 3]\n''' == toml_dumps({'foo': {'bar': [1, 2, 3]}})
    # List with dicts
    assert b'''[foo]\nbar = [{"key": "value"}, {"key2": "value2"}]\n''' == toml_dumps({'foo': {'bar': [{'key': 'value'}, {'key2': 'value2'}]}})
    # With YAML object types

# Generated at 2022-06-21 05:23:20.622907
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader

    # without 'plugin'
    inventory = inventory_loader.get('toml', os.getcwd())
    data = inventory._load_file('./plugins/inventory/test/unit/inventory/toml/test_example_1.toml')
    for k, v in data.items():
        inventory._parse_group(k, v)

# Generated at 2022-06-21 05:23:28.898593
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule

# Generated at 2022-06-21 05:23:39.421269
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    m = InventoryModule()

    # Test empty inventory
    m.parse(inventory = None, loader = None, path = "")

    # Test invalid filename
    try:
        m.parse(inventory = None, loader = None, path = None)
    except AnsibleParserError as e:
        assert("Invalid filename" in str(e))

    # Test parsing valid toml file
    path = os.path.join(os.path.dirname(__file__), 'toml.toml')
    data = m._load_file(path)
    m.parse(inventory = None, loader = None, path = path)

# Generated at 2022-06-21 05:23:50.505646
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # create instance of InventoryModule
    im = InventoryModule()

    # Test to see if 'display' is an instance of Display
    if not isinstance(im.display, Display):
        raise AssertionError()

    # Test to see if 'inventory' is an instance of Inventory
    if not isinstance(im.inventory, Inventory):
        raise AssertionError()

    # Test to see if 'loader' is an instance of DataLoader
    if not isinstance(im.loader, DataLoader):
        raise AssertionError()

    # Test to see if '_options' is an instance of dict
    if not isinstance(im._options, dict):
        raise AssertionError()


# Generated at 2022-06-21 05:23:52.028558
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None

# Generated at 2022-06-21 05:23:59.333822
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file('/some/path/inventory.toml')
    assert not module.verify_file('/some/path/inventory.yaml')
    assert not module.verify_file('/some/path/inventory.yml')
    assert not module.verify_file('/some/path/inventory')
    assert not module.verify_file(None)

# Generated at 2022-06-21 05:24:04.179146
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module.verify_file('') == False
    assert module.verify_file('.txt') == False
    assert module.verify_file('.toml') == True

# Generated at 2022-06-21 05:24:09.940221
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Dummy variables
    inventory = object
    loader = object
    path = object

    # Creating instance of class InventoryModule
    test_instance = InventoryModule()

    # Testing method parse of class InventoryModule
    test_instance.parse(inventory, loader, path)


# Generated at 2022-06-21 05:24:20.622289
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native({'x': "a"}) == {'x': "a"}
    assert convert_yaml_objects_to_native(["x"]) == ["x"]
    assert convert_yaml_objects_to_native("x") == "x"
    assert convert_yaml_objects_to_native(AnsibleUnsafeText("x")) == "x"
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes("x")) == "x"
    assert convert_yaml_objects_to_native(AnsibleSequence(["x"])) == ["x"]
    assert convert_yaml_objects_to_native(AnsibleUnicode("x")) == "x"

# Generated at 2022-06-21 05:24:36.409475
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    assert convert_yaml_objects_to_native({'a': 'b', 'c': AnsibleUnicode('1')}) == {'a': 'b', 'c': '1'}
    assert convert_yaml_objects_to_native(AnsibleUnicode('1')) == '1'
    assert convert_yaml_objects_to_native(AnsibleSequence(['a', 'b'])) == ['a', 'b']
    assert convert_yaml_objects_to_native(['a', 'b']) == ['a', 'b']

# Generated at 2022-06-21 05:24:38.226315
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module

# Generated at 2022-06-21 05:24:57.754247
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a file named 'test_inventory.toml' under /tmp directory
    f = open('/tmp/test_inventory.toml','w')
    f.write(EXAMPLES)
    f.close()
    inventory = ''
    loader = ''
    path = '/tmp/test_inventory.toml'

    # call InventoryModule._parse_group method to parse examples
    inv_mod = InventoryModule()
    inv_mod._parse_group(inventory, loader, path)
    print(inv_mod)

test_InventoryModule_parse()

# Generated at 2022-06-21 05:25:05.436843
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os

    # Create a fake file named 'inventory.toml'
    (handle, filepath) = tempfile.mkstemp(prefix='ansible_toml_inventory_unittest_',
                                          suffix='.toml')
    os.close(handle)
    handle = None
    try:
        InventoryModule.verify_file(filepath)
    finally:
        if handle is not None:
            os.close(handle)
        if os.path.exists(filepath):
            os.unlink(filepath)


# Generated at 2022-06-21 05:25:09.842850
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    path_verify_file = "./test_data/inventory.toml"
    assert inv.verify_file(path_verify_file) == True, "Error in method verify_file"

# Generated at 2022-06-21 05:25:16.246274
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    assert(convert_yaml_objects_to_native(AnsibleBaseYAMLObject()) is None)
    assert(convert_yaml_objects_to_native(AnsibleBaseYAMLObject("foo")) == "foo")
    assert(convert_yaml_objects_to_native(AnsibleUnicode("foo")) == "foo")
    assert(convert_yaml_objects_to_native(AnsibleUnsafeBytes("foo")) == b"foo")
    assert(convert_yaml_objects_to_native(AnsibleUnsafeText("foo")) == "foo")

# Generated at 2022-06-21 05:25:25.339457
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:25:35.230043
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = r"""
    foo:
      - name: foo1
      - name: foo2
        age: 22
      - name: foo3
      - name: foo4
        age: 33

    bar:
      - name: bar1
      - name: bar2
        age: 22
      - name: bar3
      - name: bar4
        age: 33
    """
    yaml = AnsibleLoader(data, cls=AnsibleConstructor, typ='safe').get_single

# Generated at 2022-06-21 05:25:40.311289
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.loader import AnsibleLoader
    ansible_yaml = AnsibleLoader(None, None).load(EXAMPLES)
    assert ansible_yaml == toml.loads(toml_dumps(ansible_yaml))

# Generated at 2022-06-21 05:25:49.502898
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import pdb
    pdb.set_trace()
    inv = InventoryModule()
    inv._load_file('/home/fral/Documents/mysite/tomlinventory.toml')
    inv.parse(inv, '', '/home/fral/Documents/mysite/tomlinventory.toml')
    # inv.verify_file('/home/fral/Documents/mysite/tomlinventory.toml')

# test_InventoryModule()

# Generated at 2022-06-21 05:26:01.992549
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import ansible.parsing.yaml.objects
    my_dict = {
      "a": {
          "b": [
              "a",
              "b",
              123,
              "d"
          ]
      },
      "c": [
          "a",
          "b",
          "c",
          "d"
      ]
    }
    assert convert_yaml_objects_to_native(my_dict) == my_dict

    for v in my_dict["a"]["b"]:
        if isinstance(v, string_types):
            assert isinstance(convert_yaml_objects_to_native(ansible.parsing.yaml.objects.AnsibleUnicode(v)), str)

# Generated at 2022-06-21 05:26:11.851866
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:26:35.508249
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode
    # This data is the result of parsing TOML with older versions of toml
    # and will have YAML object types

# Generated at 2022-06-21 05:26:46.973274
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import tempfile
    import shutil

    '''
    Assert that the TOML plugin can parse valid TOML data, and sets the correct
    group/host variables.
    '''

    from ansible.parsing.utils.jsonify import jsonify
    from ansible.plugins.inventory import BaseInventoryPlugin

    class DummyInventory(object):
        def __init__(self):
            self.hosts = {}
            self.groups = {}

        def add_group(self, group):
            if group not in self.groups:
                self.groups[group] = BaseInventoryPlugin.Group(group)
            return self.groups[group]

        def add_host(self, host):
            if host not in self.hosts:
                self.hosts[host] = BaseInventoryPlugin.Host

# Generated at 2022-06-21 05:26:56.454297
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """Unit test for InventoryModule."""
    inv_mod = InventoryModule()

    # test parse method

# Generated at 2022-06-21 05:26:58.932666
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_mod = InventoryModule()
    assert inventory_mod.NAME == 'toml'


# Generated at 2022-06-21 05:27:01.484485
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file("/path/to/inventory/file.toml")



# Generated at 2022-06-21 05:27:16.967173
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps(dict(all=dict(children=['g1', 'g2']))) == \
        '''[all]
children = ["g1", "g2"]

'''

    assert toml_dumps(dict(g1=dict(hosts=dict(host4=None)))) == \
        '''[g1]
hosts = {\n    "host4": {}\n}

'''


# Generated at 2022-06-21 05:27:30.083277
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleUnsafeBytes
    assert convert_yaml_objects_to_native('string') == 'string'
    assert convert_yaml_objects_to_native(['string', 'string2']) == ['string', 'string2']
    assert convert_yaml_objects_to_native({'dict': 'string'}) == {'dict': 'string'}
    assert convert_yaml_objects_to_native({'dict': ['string', 'string2']}) == {'dict': ['string', 'string2']}
    assert convert_yaml_objects_to_native({'dict': {'dict2': 'string'}}) == {'dict': {'dict2': 'string'}}

# Generated at 2022-06-21 05:27:38.603245
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    v_obj = InventoryModule()

    # 1st test case:
    # filepath is not ending in extension '.toml'
    assert v_obj.verify_file('/root/ans_inventory/hosts') == False

    # 2nd test case:
    # filepath is empty
    assert v_obj.verify_file('') == False

    # 3rd test case:
    # filepath is ending with '.toml'
    assert v_obj.verify_file('/root/amansivel/ans_inventory/hosts/hosts.toml') == True

# Generated at 2022-06-21 05:27:53.755142
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Built-in types
    assert convert_yaml_objects_to_native(True) is True
    assert convert_yaml_objects_to_native(False) is False
    assert convert_yaml_objects_to_native(42) == 42
    assert convert_yaml_objects_to_native(42.0) == 42.0
    assert convert_yaml_objects_to_native('foo') == 'foo'

    # Native types
    assert convert_yaml_objects_to_native([1, 2, 3]) == [1, 2, 3]
    assert convert_yaml_objects_to_native({'foo': 'bar', 'zoo': 'baz'}) == {'foo': 'bar', 'zoo': 'baz'}

    # ansible.parsing.yaml.objects
    assert convert

# Generated at 2022-06-21 05:28:02.058781
# Unit test for function toml_dumps
def test_toml_dumps():
    from collections import OrderedDict

    # Make sure we're using a clean toml.dumps
    old_dumps = toml.dumps

    def cleanup():
        toml.dumps = old_dumps
    toml.dumps = old_dumps

    toml.dumps = toml_dumps

    testdata = OrderedDict()
    testdata['str_key'] = 'str_value'
    testdata['int_key'] = 25
    testdata['float_key'] = 25.25
    testdata['bool_key'] = True
    testdata['list_key'] = [1, 2, 3]
    testdata['a_unicode_str'] = '\u00a9'
    testdata['a_bytes_str'] = b'\xc2\xa9'
    testdata

# Generated at 2022-06-21 05:28:41.370948
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import tempfile

    im_instance = InventoryModule()

    # The instance should have self._strip_tokens, _strip_domain, _strip_port, _expand_hostpattern, _populate_host_vars, _parse_group, _load_file, parse, verify_file
    assert not im_instance._strip_tokens is None
    assert not im_instance._strip_domain is None
    assert not im_instance._strip_port is None
    assert not im_instance._expand_hostpattern is None
    assert not im_instance._populate_host_vars is None
    assert not im_instance._parse_group is None
    assert not im_instance._load_file is None
    assert not im_instance.parse is None
    assert not im_instance.verify_file is None

# Generated at 2022-06-21 05:28:54.644990
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Test basic list
    assert convert_yaml_objects_to_native([]) == []
    assert convert_yaml_objects_to_native([1]) == [1]
    assert convert_yaml_objects_to_native([1, 2, 3]) == [1, 2, 3]
    # Test basic dict
    assert convert_yaml_objects_to_native({}) == {}
    assert convert_yaml_objects_to_native({'key1': 'value1'}) == {'key1': 'value1'}
    assert convert_yaml_objects_to_native({'key1': 'value1', 'key2': 'value2'}) == {'key1': 'value1', 'key2': 'value2'}
    # Test list of AnsibleSequence
    assert convert_yaml_objects_to_

# Generated at 2022-06-21 05:29:04.630982
# Unit test for function toml_dumps
def test_toml_dumps():
    class TestObject(object):
        def __init__(self, data):
            self.data = data
    import datetime
    obj = {
        'foo': AnsibleUnicode('Hällö\nWörld'),
        'bar': {'baz': AnsibleSequence([1, 2, 3]),
                'qux': AnsibleUnsafeBytes(b'\xe2\x9b\x94')},
        'boo': TestObject('qux'),
        'datetime': datetime.datetime(2023, 1, 1),
    }

# Generated at 2022-06-21 05:29:17.921172
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    toml_string = """
[ungrouped.hosts]
host1 = {}
host2 = { ansible_host = "127.0.0.1", ansible_port = 44 }
host3 = { ansible_host = "127.0.0.1", ansible_port = 45 }
[g1.hosts]
host4 = {}

[g2.hosts]
host4 = {}
"""
    inventory = InventoryModule()
    loader = AnsibleFileLoader()
    inventory.parse(inventory, loader, toml_string)
    print (inventory.hosts.__dict__)
    
    

# Generated at 2022-06-21 05:29:22.045576
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse(None, None, './test/inventory')
    # TODO: Checking groups and hosts after parsing


# Generated at 2022-06-21 05:29:24.081615
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv._options is not None

# Generated at 2022-06-21 05:29:38.854179
# Unit test for function toml_dumps
def test_toml_dumps():
    # Single key
    assert toml_dumps({'key': 'value'}) == 'key = "value"\n'

    # Single key followed by a sub-key with value
    assert toml_dumps({'key': {'subkey': 'value'}}) == 'key = { subkey = "value" }\n'

    # Single key followed by a sub-key with value representing a boolean
    assert toml_dumps({'key': {'subkey': True}}) == 'key = { subkey = true }\n'

    # Single key followed by a sub-key with value representing a negative integer
    assert toml_dumps({'key': {'subkey': -42}}) == 'key = { subkey = -42 }\n'

    # Single key followed by a sub-key with value representing a float
   

# Generated at 2022-06-21 05:29:45.970960
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping
    assert convert_yaml_objects_to_native(
        AnsibleMapping(
            {
                "foo": AnsibleSequence([
                    AnsibleUnicode("foo"),
                    AnsibleUnsafeText("bar"),
                    AnsibleUnsafeBytes(b"baz")
                ])
            }
        )
    ) == {
        "foo": [
            "foo",
            "bar",
            "baz"
        ]
    }

# Generated at 2022-06-21 05:29:54.190553
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_instance = InventoryModule()
    # with invalid path
    invalid_path = '../../../my_path/inventory.ini'
    result = test_instance.verify_file(invalid_path)
    assert result == False

    # with valid path
    valid_path = '../../../my_path/inventory.toml'
    result = test_instance.verify_file(valid_path)
    assert result == True

# Generated at 2022-06-21 05:30:06.102365
# Unit test for function toml_dumps
def test_toml_dumps():
    assert 'key = 42' == toml_dumps({'key': 42})

    assert '' == toml_dumps({})

    assert '''
[test]
k1 = true
''' == toml_dumps({'test': {'k1': True}})

    assert '''
[test]
k1 = [1,2,3]
''' == toml_dumps({'test': {'k1': [1, 2, 3]}})

    assert '''
[test]
k1 = [
    [1,2,3],
    [4,5,6]
]
''' == toml_dumps({'test': {'k1': [[1, 2, 3], [4, 5, 6]]}})


# Generated at 2022-06-21 05:31:02.335060
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO Write unit test
    pass



# Generated at 2022-06-21 05:31:09.813695
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    def null_function(*args, **kwargs):
        pass

    class MockInventoryModule(InventoryModule):
        def __init__(self, *args, **kwargs):
            super(MockInventoryModule, self).__init__(*args, **kwargs)
            self.set_options = null_function
    assert MockInventoryModule(loader=null_function, inventory=null_function).verify_file(
        'test.toml') is True
    assert MockInventoryModule(loader=null_function, inventory=null_function).verify_file(
        'test.yml') is False

# Generated at 2022-06-21 05:31:13.604547
# Unit test for function toml_dumps
def test_toml_dumps():
    # TODO: fix this
    #data = toml.loads(EXAMPLES)
    #assert toml_dumps(data) == EXAMPLES
    pass

# Generated at 2022-06-21 05:31:21.992422
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    class Args(object):
        connection = 'local'
        verbosity = 0
        module_path = None
        forks = 100
        become = None
        become_method = None
        become_user = None
        check = False
        diff = False

    args = Args()

    toml_plugin = InventoryModule()
    loader = DataLoader()
    inventory = InventoryManager(loader, sources='localhost,')
    toml_plugin.parse(inventory, loader, EXAMPLES.split('\n')[1], cache=False)

# Generated at 2022-06-21 05:31:29.147492
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    test_case = [
        # Data, Expected
        ('string', 'string'),
        (1, 1),
        (['a', 'b'], ['a', 'b']),
        ((1, 2), (1, 2)),
        ({'a': 1}, {'a': 1}),
        (AnsibleMapping({'a': 1}), {'a': 1}),
        (AnsibleSequence([1, 2]), [1, 2]),
    ]

    for data, expected in test_case:
        assert convert_yaml_objects_to_native(data) == expected

# Generated at 2022-06-21 05:31:39.128295
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    paths = [
        ('file1.toml', True),
        ('file1.inventory', False),
    ]
    InventoryModule.verify_file = BaseFileInventoryPlugin.verify_file
    inventory = InventoryModule()
    for path in paths:
        res = inventory.verify_file(path[0])
        print('Expect: %s, got: %s' % (path[1], res))
        assert(res == path[1])

if __name__ == '__main__':
    test_InventoryModule_verify_file()

# Generated at 2022-06-21 05:31:50.815337
# Unit test for function toml_dumps
def test_toml_dumps():
    import json
    import yaml
    data = {'a': {'b': [1,2], 'c': {'d': 3}}}
    assert json.loads(toml_dumps(data)) == data
    data = yaml.safe_load(b'''
a: &a
  b: [1, 2]
  c:
    d: 3
b:
  <<: *a
    b: [1, 2, 3]
''')
    rdata = json.loads(toml_dumps(data))
    assert rdata['a'] == {'b': [1, 2], 'c': {'d': 3}}
    assert rdata['b'] == {'b': [1, 2, 3], 'c': {'d': 3}}

# Generated at 2022-06-21 05:32:02.223827
# Unit test for function toml_dumps
def test_toml_dumps():
    import os

    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    assert _toml_dumps == toml_dumps

    # Test AnsibleUnicode
    source = [{
        'ansible.parsing.yaml.objects.AnsibleUnicode': AnsibleUnicode(u"\u00e9")
    }]
    result = _toml_dumps(source).decode('utf-8')
    assert result == u"ansible.parsing.yaml.objects.AnsibleUnicode = \"\\u00e9\"\n"

    # Test AnsibleSequence