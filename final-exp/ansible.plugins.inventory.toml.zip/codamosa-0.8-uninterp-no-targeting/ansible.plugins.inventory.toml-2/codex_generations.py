

# Generated at 2022-06-21 05:22:28.925095
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:22:39.213667
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # pylint: disable=too-many-locals

    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    from ansible.inventory.group import Group
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from six import PY3, string_types
    from textwrap import dedent

    loader = DataLoader()
    variable_manager = VariableManager()

    # Test simple group

# Generated at 2022-06-21 05:22:42.432109
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'foo': 'bar'}) == 'foo = "bar"\n'

# Generated at 2022-06-21 05:22:47.323552
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps(dict(foo='bar')) == 'foo = "bar"\n'
    assert toml_dumps(list(range(10))) == '- 0\n- 1\n- 2\n- 3\n- 4\n- 5\n- 6\n- 7\n- 8\n- 9\n'

# Generated at 2022-06-21 05:22:56.807572
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager

    inv_man = InventoryManager('localhost,')
    inv_man._vault = None

    def _load_file(*args, **kwargs):
        return {'g1':
                    {
                        'vars': {'myvar': 'hi'},
                        'hosts': {'h1': {'myvar2': 'hi2'}},
                        'children': ['g2']
                    },
                'g2':
                    {
                        'vars': {'myvar': 'hello'},
                        'hosts': {'h2': {'myvar3': 'hello3'}}
                    }
        }
    InventoryModule._load_file = _load_file
    toml_inv = InventoryModule()

# Generated at 2022-06-21 05:23:11.583463
# Unit test for function toml_dumps
def test_toml_dumps():
    # fmt: off

    # Generic examples
    assert toml_dumps({
        'a': 1,
        'b': '2',
        'c': True,
        'd': None,
    }) == u"""a = 1
b = "2"
c = true
d = null
"""

# Generated at 2022-06-21 05:23:20.945957
# Unit test for function toml_dumps
def test_toml_dumps():
    import yaml
    encoded = toml_dumps(yaml.safe_load(EXAMPLES))

# Generated at 2022-06-21 05:23:35.997639
# Unit test for function toml_dumps
def test_toml_dumps():
    # Ensure that we can encode our YAML object types
    yaml_types = {
        AnsibleSequence([23]): '[23]',
        AnsibleUnicode('bar'): '"bar"',
        AnsibleUnsafeBytes(b'foo'): '"foo"',
        AnsibleUnsafeText(u'bar', True): '"bar"',
    }
    for yam, tom in yaml_types.items():
        assert toml_dumps(yam) == tom

    # Ensure we can encode all of the TOML types

# Generated at 2022-06-21 05:23:48.091696
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # version_added: "2.8"
    if not hasattr(InventoryModule, 'verify_file'):
        return

    module = InventoryModule()

    # Verify the method verify_file return True when the file extension is .toml
    assert module.verify_file('/tmp/test.toml') is True
    # Verify the method verify_file return False when the file extension is not .toml
    assert module.verify_file('/tmp/test') is False
    # Verify the method verify_file return False when the file does not exists
    assert module.verify_file('/tmp/test.toml') is False

# Generated at 2022-06-21 05:24:01.025904
# Unit test for function toml_dumps
def test_toml_dumps():
    """Create a simple TOML and convert to dictionary"""
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    data = {
        "has_java": False,
        "web": {
            "children": [
                "apache",
                "nginx"
            ],
            "vars": {
                "http_port": 8080,
                "myvar": 23
            },
            "hosts": {
                "host1": {},
                "host2": {
                    "ansible_port": 222
                }
            }
        },
        "apache": {
            "hosts": {
                "host3": {
                    "ansible_user": AnsibleUnsafeText("root")
                }
            }
        }
    }

# Generated at 2022-06-21 05:24:35.503781
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ini = toml_dumps({
        'ungrouped': {
            'hosts': {
                'host1': {},
                'host2': {
                    'ansible_host': '127.0.0.1',
                    'ansible_port': '44'
                },
                'host3': {
                    'ansible_host': '127.0.0.1',
                    'ansible_port': '45'
                }
            }
        },
        'g1': {
            'hosts': {
                'host4': {}
            }
        },
        'g2': {
            'hosts': {
                'host4': {}
            }
        }
    })
    open('temp.toml', 'w').write(ini)

    im = InventoryModule()

# Generated at 2022-06-21 05:24:41.729941
# Unit test for function toml_dumps
def test_toml_dumps():
    """This function is only used when ``toml<0.10.0`` is present"""
    data = {
        'a_string': 'CamelCase',
        'a_bool': 'yes',
        'some_int': 42,
        'a_null': None,
        'a_dict': {
            'a_number': 123,
        },
        'an_array': [
            'A',
            'B',
            'C',
            AnsibleUnsafeText(b'\xfc'),
            '\n',
            AnsibleUnsafeText(u'\xe4'),
            123,
        ],
        'an_object': AnsibleSequence((1, 2, 3)),
    }

# Generated at 2022-06-21 05:24:49.623598
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    class Foo(object):
        pass

    foo = Foo()
    try:
        orig = {'k1': 'v1', 'k2': [foo]}
        new = convert_yaml_objects_to_native(orig)
        assert orig == new
        assert new['k2'][0] is foo
    except Exception as e:
        raise AssertionError("Could not convert object, %s" % e)

# Generated at 2022-06-21 05:24:57.581821
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Test all different types
    assert convert_yaml_objects_to_native({'dict': {'a': 1}, 'list': [1,2,3]}) == {'dict': {'a': 1}, 'list': [1,2,3]}
    assert convert_yaml_objects_to_native('a') == 'a'
    assert convert_yaml_objects_to_native(1) == 1
    # Test YAML objects are converted to native types
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('a')) == 'a'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes('a')) == 'a'
    assert convert_yaml_objects_to_native(AnsibleUnicode('a')) == 'a'

# Generated at 2022-06-21 05:25:06.130702
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import io
    import unittest
    import unittest.mock

    try:
        from ansible.parsing.yaml.__init__ import AnsibleUnicode, AnsibleSequence
    except ImportError:
        AnsibleUnicode = text_type
        AnsibleSequence = list

    class MockedInventoryModule(object):
        def __init__(self, mocked_output):
            self.mocked_output = mocked_output

        def _load_file(self, path):
            return self.mocked_output

        def parse(self, inventory, loader, path, cache=True):
            pass

        def _parse_group(self, group, group_data):
            pass

        def verify_file(self, path):
            return True


# Generated at 2022-06-21 05:25:19.658409
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from copy import deepcopy
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.utils.unsafe_proxy import wrap_var

    tomldict = {'string': 'foo',
                'unicode': AnsibleUnicode('foo'),
                'unsafe': AnsibleUnsafeText(wrap_var('foo')),
                'unsafebytes': AnsibleUnsafeBytes(wrap_var(b'foo')),
                'list': [1, 'foo', AnsibleUnicode('foo'), AnsibleUnsafeText(wrap_var('bar'))],
                'dict': AnsibleMapping(a='foo',
                                       b=AnsibleUnicode('foo'),
                                       c=AnsibleUnsafeText(wrap_var('bar')))}

    # Make a copy of tomld

# Generated at 2022-06-21 05:25:26.863906
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Unit test for method verify_file of class InventoryModule without arguments
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('test') == False

    # Unit test for method verify_file of class InventoryModule with arguments
    inventory_module = InventoryModule()
    assert inventory_module.verify_file('test.toml') == True

# Generated at 2022-06-21 05:25:35.818838
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    import pytest
    # Both types should be an AnsibleSequence
    assert(isinstance(AnsibleSequence(['a', 'b', 'c']), AnsibleSequence))
    assert(isinstance(AnsibleSequence((1, 2, 3)), AnsibleSequence))
    # Both types should be an AnsibleUnicode
    assert(isinstance(AnsibleUnicode('a'), AnsibleUnicode))
    assert(isinstance(AnsibleUnicode(u'a'), AnsibleUnicode))
    # test_data is the data structure we are testing

# Generated at 2022-06-21 05:25:43.633862
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # fixture: create an instance of class InventoryModule
    im = InventoryModule()

    # case: file exists with .toml extension
    # expected: file is identified as a TOML inventory
    path = '/path/to/file.toml'
    assert(im.verify_file(path) == True)

    # case: file exists but with an extension different than .toml
    # expected: file is not identified as TOML inventory
    path = '/path/to/file.yml'
    assert(im.verify_file(path) == False)

    # case: file does not exists
    # expected: file is not identified as TOML inventory
    path = '/path/to/file.toml'
    assert(im.verify_file(path) == False)

# Generated at 2022-06-21 05:25:48.132710
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    m = InventoryModule()
    assert hasattr(m, '_populate_host_vars')
    assert hasattr(m, '_parse_group')
    assert hasattr(m, 'parse')

# Generated at 2022-06-21 05:26:30.142600
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    loader = None
    path = './test/test.toml'
    inventory = None
    obj = InventoryModule()
    assert obj.verify_file(path)

# Generated at 2022-06-21 05:26:37.602181
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'toml'
    assert hasattr(inv, '_parse_group')
    assert hasattr(inv, '_load_file')
    assert hasattr(inv, 'parse')
    assert hasattr(inv, 'verify_file')


# Generated at 2022-06-21 05:26:48.497308
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleUnsafeText

    class AnsibleFakeYAMLObject(AnsibleBaseYAMLObject):
        yaml_loader = None
        yaml_dumper = None
        yaml_tag = u'!AnsibleFakeYAMLObject'


    assert convert_yaml_objects_to_native({'foo': AnsibleFakeYAMLObject('bar')}) == {'foo': 'bar'}
    assert convert_yaml_objects_to_native({'foo': AnsibleUnsafeText('bar')}) == {'foo': 'bar'}
    assert convert_yaml_objects_to_native(['bar']) == ['bar']

# Generated at 2022-06-21 05:26:50.398309
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule(filename='myfile', loader=None, inventory=None)

# Generated at 2022-06-21 05:26:57.676178
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    assert convert_yaml_objects_to_native({'key': 'value'}) == {'key': 'value'}
    assert convert_yaml_objects_to_native([ 'value1', 'value2', AnsibleSequence([ 'value3', AnsibleUnicode('value4')])]) == [ 'value1', 'value2', [ 'value3', 'value4']]
    assert convert_yaml_objects_to_native( 'value') == 'value'
    assert convert_yaml_objects_to_native( 12) == 12
    assert convert_yaml_objects_to_native( AnsibleUnicode('value')) == 'value'
    assert convert_

# Generated at 2022-06-21 05:27:07.010595
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:27:12.212846
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    assert inventory.verify_file('/some/path/to/sample.toml')
    assert not inventory.verify_file('/some/path/to/sample.txt')


# Generated at 2022-06-21 05:27:25.453690
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert (InventoryModule.NAME == 'toml'), "InventoryModule.NAME field is not set properly"
    assert (callable(getattr(InventoryModule, 'parse') is True)), "InventoryModule.parse method is not callable"
    assert (callable(getattr(InventoryModule, '_parse_group') is True)), "InventoryModule._parse_group method is not callable"
    assert (callable(getattr(InventoryModule, '_load_file') is True)), "InventoryModule._load_file method is not callable"
    assert (callable(getattr(InventoryModule, 'parse') is True)), "InventoryModule.parse method is not callable"

# Generated at 2022-06-21 05:27:36.623306
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import os
    import tempfile

    fd, path = tempfile.mkstemp()

# Generated at 2022-06-21 05:27:47.971750
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    For test all method parse in class InventoryModule
    '''
    from ansible.plugins.loader import InventoryLoader
    loader = InventoryLoader()
    if loader:
        inventory = loader.inventory
        module = InventoryModule()
        path = "./test/files/test.toml"
        module.parse(inventory, loader, path)
        assert inventory.groups['all'].vars['has_java'] == True
        assert inventory.groups['g1'].get_hosts()[0].vars['myvar'] == 23
        assert inventory.groups['web'].get_hosts()[0].name == "host1"
        assert inventory.groups['apache'].get_hosts()[0].name == "tomcat1"

# Generated at 2022-06-21 05:28:38.676011
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    s = 'value'
    assert convert_yaml_objects_to_native(AnsibleUnicode(s)) == s
    l = [AnsibleUnicode(s), AnsibleUnicode(s)]
    assert convert_yaml_objects_to_native(AnsibleSequence(l)) == l
    d = {AnsibleUnicode(s): AnsibleUnicode(s)}
    assert convert_yaml_objects_to_native(AnsibleMapping(d)) == d

# Generated at 2022-06-21 05:28:44.660706
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:28:47.790251
# Unit test for function toml_dumps
def test_toml_dumps():
    import doctest
    return doctest.testmod(toml)

# Generated at 2022-06-21 05:28:56.543949
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import inventory_loader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    groups = ['all', 'ungrouped', 'web', 'apache', 'nginx', 'g1', 'g2']
    hosts = ['host1', 'host2', 'host3', 'host4', 'tomcat1', 'tomcat2', 'tomcat3', 'jenkins1']
    test_dir = os.path.dirname(__file__)
    loader = DataLoader()
    variable_manager = VariableManager()

# Generated at 2022-06-21 05:29:03.405521
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {
        "hello world": {"foo": [1, 2, 3], "bar": AnsibleUnicode("baz")},
        "hello foo": AnsibleUnsafeText("foo"),
        "hello bar": AnsibleUnsafeBytes(to_bytes("bar"))
    }
    assert toml_dumps(data) == '''
[hello world]
foo = [1, 2, 3]
bar = "baz"

[hello foo]
hello foo = "foo"

[hello bar]
hello bar = "bar"
'''

# Generated at 2022-06-21 05:29:13.972820
# Unit test for function toml_dumps
def test_toml_dumps():
    import toml
    from ansible.parsing.dataloader import DataLoader

    loader = DataLoader()
    input = '''fruits = [
      ["Banana", 3000],
      ["Apple",   5000, "Good to eat"],
      ["Cherry",  7500],
    ]
    '''
    data = loader.load(input)
    output = toml_dumps(data)
    # TODO: This needs to be updated for new versions of toml but is sufficient for now

# Generated at 2022-06-21 05:29:26.626341
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inventory = InventoryManager(loader=DataLoader(), sources='localhost,')
    variable_manager = VariableManager()

    custom_plugin = InventoryModule()

    # Test with invalid files
    no_extension_file = u'hosts'
    yml_extension_file = u'/home/test/hosts.yml'
    invalid_extension_file = u'/home/test/hosts.test'
    no_extension_file_bytes = to_bytes(no_extension_file, errors='surrogate_or_strict')

# Generated at 2022-06-21 05:29:37.150143
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import ansible.parsing.yaml.objects
    # Create a bunch of these custom yaml object types
    o1 = ansible.parsing.yaml.objects.AnsibleSequence(['a', 'b', 'c'])
    o2 = ansible.parsing.yaml.objects.AnsibleMapping(k='v')
    o3 = ansible.parsing.yaml.objects.AnsibleUnicode('testing')
    o4 = ansible.parsing.yaml.objects.AnsibleUnsafeText('unsafe testing')
    o5 = ansible.parsing.yaml.objects.AnsibleUnsafeBytes('unsafe bytes testing')


# Generated at 2022-06-21 05:29:47.047774
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Test for dict
    assert convert_yaml_objects_to_native({"a": "Hello"}) == {"a": "Hello"}
    assert convert_yaml_objects_to_native({"a": AnsibleUnsafeText("Hello")}) == {"a": "Hello"}
    assert convert_yaml_objects_to_native({"a": AnsibleUnsafebBytes("Hello")}) == {"a": "Hello"}
    assert convert_yaml_objects_to_native({"a": AnsibleUnicode("Hello")}) == {"a": "Hello"}
    assert convert_yaml_objects_to_native({AnsibleUnsafeText("a"): "Hello"}) == {"a": "Hello"}

# Generated at 2022-06-21 05:29:58.042778
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    variable_manager = VariableManager()
    variable_manager.set_inventory(InventoryManager(loader=loader, sources='localhost,'))

    host_list = [
        {
            'ansible_host': '127.0.0.1',
        },
        {
            'ansible_host': '127.0.0.2',
        },
    ]

    inventory = InventoryManager(loader=loader, sources=EXAMPLES)
    inventory.add_host(host='test', group='test')
    inventory.add_host(host='test2', group='test')
    inventory.get_host('test').set_

# Generated at 2022-06-21 05:30:43.229861
# Unit test for function toml_dumps
def test_toml_dumps():
    # Expect that a native yaml element comes back as what it came in as
    assert toml_dumps({'a': 'b'}) == 'a = "b"\n'

    # Expect that a custom yaml element gets converted back to toml
    assert toml_dumps({'a': AnsibleUnicode('b')}) == 'a = "b"\n'

# Generated at 2022-06-21 05:30:47.006125
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  # Parameters
  path = './test_path'

  # Setup
  inventory_module_obj = InventoryModule()

  # Exercise SUT
  result = inventory_module_obj.verify_file(path)

  # Verify
  assert False == result



# Generated at 2022-06-21 05:30:58.195861
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    # custom test class to mock the inventory class
    class Inventory(object):
        def __init__(self):
            self.groups = {}
            self.hosts = {}

        def add_group(self, group):
            self.groups[group] = group

        def add_child(self, group, subgroup):
            self.groups[group].append(subgroup)

        def set_variable(self, group, var, value):
            self.groups[group][var] = value

        def add_host(self, host, group=None):
            self.hosts[host] = host

    inventory = Inventory()

    # test for base file inventory plugin and base inventory plugin

    # create object for class InventoryModule
    obj = InventoryModule(inventory, None)

    # verify object of class InventoryModule is created successfully

# Generated at 2022-06-21 05:31:04.508070
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file('./test/unit/ansible_collections/ansible/community/plugins/inventory/test_toml.py') == True
    assert InventoryModule.verify_file('./test/unit/ansible_collections/ansible/community/plugins/inventory/test_toml.toml') == True
    assert InventoryModule.verify_file('./test/unit/ansible_collections/ansible/community/plugins/inventory/test_toml.yaml') == False
    assert InventoryModule.verify_file('./test/unit/ansible_collections/ansible/community/plugins/inventory/test_hosts.yaml') == False


# Generated at 2022-06-21 05:31:18.377090
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.utils.addict import Dict
    from ansible.utils.collection_loader import AnsibleCollectionLoader
    loader = AnsibleCollectionLoader(None)
    my_plugin = InventoryModule()
    my_plugin.display = Display()
    my_plugin.loader = loader
    my_plugin.parse(None, loader, './test/units/plugins/inventory/test_data/test_toml.toml')
    my_host = my_plugin.inventory.get_host('tomcat3')
    my_host_vars = my_host.get_vars()

    assert 'g1' in my_plugin.inventory.groups
    assert 'g2' in my_plugin.inventory.groups
    assert 'apache' in my_plugin.inventory.groups

# Generated at 2022-06-21 05:31:28.217682
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeText, AnsibleUnsafeBytes

# Generated at 2022-06-21 05:31:33.016183
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    if isinstance(inv, InventoryModule):
        print('Test InventoryModule - PASS')
    else:
        print('Test InventoryModule - FAIL')


# Generated at 2022-06-21 05:31:42.009066
# Unit test for function toml_dumps
def test_toml_dumps():
    # Test regular dicts
    test_input = {
        'hello': 'world',
        'answer': 42,
    }
    # Test results should be the same as TOML file
    test_result = r"""answer = 42
hello = "world"

"""
    assert toml_dumps(test_input) == test_result

    # Test that custom Python objects are converted to native objects
    class TestObject(object):
        def __init__(self, value):
            self.value = value

    test_input = {
        'test_object': TestObject('value'),
    }
    # Should dump the test object to a string representation
    test_result = r"""test_object = "value"

"""
    assert toml_dumps(test_input) == test_result

# Generated at 2022-06-21 05:31:46.014374
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    path = '/etc/ansible/hosts.toml'
    assert inventory.verify_file(path) == True
    

# Generated at 2022-06-21 05:31:54.997649
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ''' Unit test for method parse of class InventoryModule '''
    from ansible.plugins.loader import InventoryLoader
    import tempfile
    import shutil
    import sys
