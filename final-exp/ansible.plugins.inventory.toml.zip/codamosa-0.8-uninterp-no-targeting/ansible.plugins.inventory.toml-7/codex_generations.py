

# Generated at 2022-06-21 05:22:20.290774
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native(AnsibleUnicode(text_type('test'))) == 'test'
    assert convert_yaml_objects_to_native(AnsibleSequence([1, 2, 3, 4])) == [1, 2, 3, 4]

# Generated at 2022-06-21 05:22:28.021856
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert hasattr(obj, 'NAME')
    assert isinstance(obj.NAME, string_types)

    assert hasattr(obj, '_parse_group')
    assert callable(obj._parse_group)

    assert hasattr(obj, 'verify_file')
    assert callable(obj.verify_file)

    assert hasattr(obj, '_load_file')
    assert callable(obj._load_file)

    assert hasattr(obj, 'parse')
    assert callable(obj.parse)


# Generated at 2022-06-21 05:22:36.979772
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import ansible.parsing.yaml.objects as ayaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.utils.vars import combine_vars
    from ansible.module_utils.six import with_metaclass

    class AnsibleFakeUnicode(object):
        """AnsibleUnicode is a subclass of Unicode, but we have to mock it
        to test it
        """
        def __init__(self, *args):
            self.args = args

        def __repr__(self):
            return '{0}{1}'.format(self.__class__.__name__, self.args)



# Generated at 2022-06-21 05:22:49.352002
# Unit test for function toml_dumps
def test_toml_dumps():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping, AnsibleSequence
    from ansible.utils.unsafe_proxy import wrap_var

    # List of (obj, expected)

# Generated at 2022-06-21 05:23:00.940524
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:23:10.521575
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # dict and list of dict to convert
    sample_dict = {
        u'a': {
            u'b':[
                {
                    u'c':{
                        u'd': u'e'
                    }
                }
            ]
        }
    }
    expected_dict = {
        u'a': {
            u'b':[
                {
                    u'c':{
                        u'd': u'e'
                    }
                }
            ]
        }
    }
    expected_dict2 = {
        'a': {
            'b':[
                {
                    'c':{
                        'd': 'e'
                    }
                }
            ]
        }
    }
    # compile a list for expected output

# Generated at 2022-06-21 05:23:12.515507
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = InventoryModule()
    assert inventory is not None


# Generated at 2022-06-21 05:23:17.780238
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.module_utils.six import text_type

    assert convert_yaml_objects_to_native(AnsibleUnsafeText('hello')) == 'hello'
    assert isinstance(convert_yaml_objects_to_native('hello'), text_type)

# Generated at 2022-06-21 05:23:30.408678
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    obj = {'test': 123}
    converted_obj = convert_yaml_objects_to_native(obj)
    assert converted_obj == {'test': 123}

    obj = {'test': AnsibleVaultEncryptedUnicode('secret')}
    converted_obj = convert_yaml_objects_to_native(obj)
    assert converted_obj == {'test': 'secret'}

    obj = [123, 234]
    converted_obj = convert_yaml_objects_to_native(obj)
    assert converted_obj == [123, 234]

    obj = [123, AnsibleVaultEncryptedUnicode('secret')]
    converted_obj = convert_yaml_objects_to_native(obj)

# Generated at 2022-06-21 05:23:40.725720
# Unit test for function toml_dumps
def test_toml_dumps():
    if not HAS_TOML:
        raise AssertionError(
            'The TOML inventory plugin requires the python "toml" library'
        )

    import yaml
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleDict

    loader = AnsibleLoader(EXAMPLES)
    data = loader.get_single_data()


# Generated at 2022-06-21 05:24:01.363090
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Ensure the verify_file method works as expected
    import unittest.mock as mock
    from ansible.plugins.inventory.toml import InventoryModule
    from ansible.module_utils import six

    path = 'foo/bar/baz.toml'
    # Verify a valid path and extension
    assert InventoryModule.verify_file(mock.Mock(path=path)) is True

    # Verify a valid path but invalid extension
    assert InventoryModule.verify_file(mock.Mock(path='foo/bar/baz.txt')) is False

    # Verify verify_file false positive is not thrown
    assert InventoryModule.verify_file(mock.Mock(path='foo/bar/baz.toml.txt')) is False

    # Verify verify_file false positive is not thrown
    assert InventoryModule

# Generated at 2022-06-21 05:24:11.940588
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins.loader import InventoryLoader
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv_loader = InventoryLoader(loader)
    variable_manager = VariableManager()
    inventory = InventoryManager(loader=loader, variable_manager=variable_manager, sources=None)
    tomldir = 'tests/inventory'
    filename = 'test_toml_plugin.toml'
    path = os.path.join(tomldir, filename)
    test_obj_inventory_module = InventoryModule(inventory=inventory, loader=loader, filename=path, cache=True)

    assert test_obj_inventory_module.parse(inventory, loader, path, cache=True) is None

# Generated at 2022-06-21 05:24:19.716486
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'test': 'data'}) == r'''test = "data"

'''
    assert toml_dumps({'test': {'test2': 'data'}}) == r'''[test]
test2 = "data"

'''
    assert toml_dumps({'test': ['yes', 'data']}) == r'''[[test]]
  [test.0]
  value = "yes"

  [test.1]
  value = "data"

'''

# Generated at 2022-06-21 05:24:31.140604
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {
        u'hello': u'world',
        u'foo': u'bar',
        u'cow': u'cow',
        u'integer': 1,
        u'float': 1.234,
        u'list': [1, 2, 3],
        u'dict': {
            u'cow': u'cow',
            u'list': [4, 5, 6],
        }
    }
    print(toml_dumps(data))


if __name__ == '__main__':
    test_toml_dumps()

# Generated at 2022-06-21 05:24:33.622400
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Test function for class InventoryModule"""
    inv = InventoryModule()

# Generated at 2022-06-21 05:24:37.614160
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    InventoryManager(
        loader=DataLoader(),
        sources='/tmp/toml.toml'
    )


# Generated at 2022-06-21 05:24:42.483272
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert inv.verify_file(path='/tmp/hosts') == False
    assert inv.verify_file(path='/tmp/hosts.toml') == True
    assert inv.verify_file(path='/tmp/hosts.yml') == False



# Generated at 2022-06-21 05:24:55.238463
# Unit test for function toml_dumps
def test_toml_dumps():
    '''
    Tests for function toml_dumps()
    '''
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.module_utils.common._collections_compat import MutableMapping, MutableSequence


# Generated at 2022-06-21 05:24:59.253405
# Unit test for function toml_dumps
def test_toml_dumps():
    x = {'a': {'b': [1, 2, 3]}}
    assert toml_dumps(x) == r'''a = {b = [1, 2, 3]}
'''

# Generated at 2022-06-21 05:25:05.968764
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    ''' test return value of method verify_file of class InventoryModule
    '''
    from ansible.plugins.inventory.toml import InventoryModule

    inv_obj = InventoryModule()
    path = 'sample_inventory.toml'
    result = inv_obj.verify_file(path)

    assert result == True

# Generated at 2022-06-21 05:25:23.107325
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file('/path/to/file.toml') is True
    assert InventoryModule.verify_file('/path/to/file.ini') is False


# Generated at 2022-06-21 05:25:26.917451
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    current_dir = os.path.dirname(__file__)
    inventory_path = os.path.join(current_dir, 'test_inventory.toml')

    assert(inventory_module.verify_file(inventory_path))

# Unit tests for method _load_file of class InventoryModule

# Generated at 2022-06-21 05:25:33.563131
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native(
        {
            'a': AnsibleUnicode('foo'),
            'b': AnsibleSequence([1, AnsibleUnsafeBytes('2'), 3]),
            b'd': {
                'e': AnsibleUnsafeText('bar'),
            },
        }
    ) == {
        'a': 'foo',
        'b': [1, '2', 3],
        'd': {
            'e': 'bar',
        },
    }

# Generated at 2022-06-21 05:25:43.001570
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:25:58.932552
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    test_data = dict(
        a={'a': 1, 'b': 2, 'c': [{'a': 1}, {'b': 2}], 'd': 'hello'},
        b={'a': 1, 'b': [{'a': 1}, {'b': 2}], 'c': 'hello', 'd': AnsibleUnsafeText('hello')},
        c={'a': AnsibleUnsafeText(1)},
        d=[1, 2, 3, AnsibleUnsafeText(4)],
        e=[{'a': 1}, AnsibleUnsafeText(3)],
        f=AnsibleUnsafeText(['a', {'b': 1}]),
    )
    assert convert_yaml_objects_to_

# Generated at 2022-06-21 05:26:05.529307
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native([]) == []
    assert convert_yaml_objects_to_native({}) == {}
    assert convert_yaml_objects_to_native(AnsibleSequence([])) == []
    assert convert_yaml_objects_to_native(AnsibleUnicode('')) == ''


# Generated at 2022-06-21 05:26:06.308592
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module

# Generated at 2022-06-21 05:26:20.139471
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    value = { 'key': 'value' }
    assert convert_yaml_objects_to_native(value) == value

    value = [ 'value' ]
    assert convert_yaml_objects_to_native(value) == value

    value = u'value'
    assert convert_yaml_objects_to_native(value) == value

    value = AnsibleUnsafeText(u'value')
    assert convert_yaml_objects_to_native(value) == value

    value = b'value'
    assert convert_yaml_objects_to_native(value) == value

    value = AnsibleUnsafeBytes(b'value')
    assert convert_yaml_objects_to_native(value) == value

    value = [u'value', b'value']

# Generated at 2022-06-21 05:26:28.175541
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.dumper import AnsibleDumper
    examples = YAML().load(EXAMPLES)
    for example in examples:
        assert toml_dumps(example) == YAML(typ='safe', pure=True).dump(example, Dumper=AnsibleDumper)

# Generated at 2022-06-21 05:26:40.884046
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

# Generated at 2022-06-21 05:27:16.277178
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager
    from ansible.inventory.host import Host
    import os

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=os.getcwd())
    var_manager = VariableManager()
    host = Host('localhost')
    print("Test methods parse of Inventory Module")

    # Load file and parse
    inv.clear_pattern_cache()
    inv.set_variable_manager(var_manager)
    groups = inv._get_groups_from_source('test/inventory/toml_tests/group_vars/all.toml')
    assert (groups[0].name == 'all')

# Generated at 2022-06-21 05:27:19.091291
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    """
    Constructor for class InventoryModule
    """
    module = InventoryModule()
    assert module

# Generated at 2022-06-21 05:27:31.218243
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader

    def _load_file(file_name):
        try:
            (b_data, private) = loader._get_file_contents(file_name)
            return toml.loads(to_text(b_data, errors='surrogate_or_strict'))
        except toml.TomlDecodeError as e:
            raise AnsibleParserError(
                'TOML file (%s) is invalid: %s' % (file_name, to_native(e)),
                orig_exc=e
            )

# Generated at 2022-06-21 05:27:38.095197
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Test creation of object
    inv_mod = InventoryModule()

    # Test __init__ method
    inv_mod.__init__()

    # Test _load_file method
    inv_mod._load_file("/no/such/file.toml")

    # Parse the example toml files
    for state_name, data in [("example_1", EXAMPLES)[2],
                             ("example_2", EXAMPLES)[4],
                             ("example_3", EXAMPLES)[6]]:
        # Test parse method
        inv_mod.parse(data, state_name)

# Generated at 2022-06-21 05:27:39.460223
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """Unit test for constructor of class InventoryModule"""
    # Check with correct path of file
    obj = InventoryModule()
    assert obj._options is not None


# Generated at 2022-06-21 05:27:54.643212
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml import objects

    obj = objects.AnsibleMapping()
    assert isinstance(convert_yaml_objects_to_native(obj), dict)

    obj = objects.AnsibleUnsafeText('hello')
    assert isinstance(convert_yaml_objects_to_native(obj), text_type)

    obj = objects.AnsibleUnsafeBytes(b'hello')
    assert isinstance(convert_yaml_objects_to_native(obj), text_type)

    obj = objects.AnsibleSequence()
    assert isinstance(convert_yaml_objects_to_native(obj), list)

    obj = {'text': objects.AnsibleUnsafeText('hello'), 'bytes': objects.AnsibleUnsafeBytes(b'hello')}
   

# Generated at 2022-06-21 05:27:55.530037
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert True

# Generated at 2022-06-21 05:28:00.064571
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    assert convert_yaml_objects_to_native(AnsibleSequence(1,2,3)) == [1,2,3]
    assert convert_yaml_objects_to_native(AnsibleUnicode("foo")) == "foo"

# Generated at 2022-06-21 05:28:02.003257
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    pass

if __name__ == "__main__":
    test_InventoryModule()

# Generated at 2022-06-21 05:28:10.549994
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    from ansible.parsing.yaml.safe_dump import SafeDumper

    data = {
            'foo': 'unformatted string',
            'bar': ['item 1', 'item 2', 'item 3'],
            'baz': {
                'inner bar': ['item 1', 'item 2', 'item 3'],
                'dict': {
                    'nested': 'foo'
                }
            }
    }


# Generated at 2022-06-21 05:29:15.885289
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native(None) is None
    assert convert_yaml_objects_to_native(123) == 123
    assert convert_yaml_objects_to_native('abc') == 'abc'
    assert convert_yaml_objects_to_native(u'abc') == u'abc'

    assert convert_yaml_objects_to_native(['a', 2]) == ['a', 2]
    assert convert_yaml_objects_to_native({'a': 'b', 'c': 3}) == {'a': 'b', 'c': 3}
    assert convert_yaml_objects_to_native(AnsibleUnicode('abc')) == u'abc'
    # Python 3: `assert convert_yaml_objects_to_native(b'abc') == b'abc'`

# Generated at 2022-06-21 05:29:27.960252
# Unit test for function toml_dumps
def test_toml_dumps():
    # Test a basic dict
    data = {
        'vars': {
            'var1': 'foo',
            'var2': 1,
            'var3': 2.25,
            'var4': True,
        },
    }
    expected = r'''vars = {
  var1 = "foo"
  var2 = 1
  var3 = 2.25
  var4 = true
}
'''
    loaded = toml.loads(toml_dumps(data))
    assert loaded == data

    # Test a basic dict with arrays

# Generated at 2022-06-21 05:29:38.184756
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.parsing.mod_args import ModuleArgsParser

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources='localhost,')
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    # Create a new instance of a subclass of the specified class,
    # and return this new instance.
    # The class on which this operation is called is the rester and the
    # arguments are the arguments for the new subslass.
    # This is essentially equivalent to:
    #         return cls(*args, **kwargs)
    module = InventoryModule.__new__(InventoryModule)

# Generated at 2022-06-21 05:29:39.853445
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    pass

# Generated at 2022-06-21 05:29:41.890689
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    im = InventoryModule()
    assert im.NAME == 'toml'

# Generated at 2022-06-21 05:29:57.069300
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import unittest
    import mock

    class TestInventoryModule(unittest.TestCase):
        def setUp(self):
            self.name = 'toml'
            self.path = '/etc/ansible/hosts'

        def test_path_extension_toml(self):
            with mock.patch("os.path.splitext", return_value=('/etc/ansible/hosts', '.toml')):
                assert InventoryModule(self.name, self.path).verify_file(self.path)


# Generated at 2022-06-21 05:30:03.974916
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test with a toml file
    plugin = InventoryModule()
    assert plugin.verify_file('test.toml') == True
    # Test with missing file
    assert plugin.verify_file('missing.toml') == False
    # Test with a non-toml file
    assert plugin.verify_file('test.yml') == False


# Generated at 2022-06-21 05:30:18.054253
# Unit test for function toml_dumps
def test_toml_dumps():
    yaml_obj = {
        'g1': {
            'vars': {
                'var1': 'val1',
                'var2': 'val2',
            }
        }
    }
    toml_obj = {
        'g1': {
            'vars': {
                'var1': 'val1',
                'var2': 'val2',
            }
        }
    }
    assert toml_dumps(yaml_obj) == toml.dumps(toml_obj)
    yaml_obj = {
        'g1': {
            'vars': [
                'var1',
                'val1',
                'var2',
                'val2',
            ]
        }
    }

# Generated at 2022-06-21 05:30:21.479398
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''
    inventory = InventoryModule()
    result = inventory.verify_file('inventory.toml')
    assert result == True
    '''
    pass

# Generated at 2022-06-21 05:30:25.577217
# Unit test for function toml_dumps
def test_toml_dumps():
    # More tests should be added if the ``toml`` library can be extended
    assert toml_dumps(AnsibleSequence()) == '[]'
    assert toml_dumps(AnsibleUnicode('foo')) == '"foo"'
    assert toml_dumps(AnsibleUnsafeBytes('foo')) == '"foo"'
    assert toml_dumps(AnsibleUnsafeText('foo')) == '"foo"'

