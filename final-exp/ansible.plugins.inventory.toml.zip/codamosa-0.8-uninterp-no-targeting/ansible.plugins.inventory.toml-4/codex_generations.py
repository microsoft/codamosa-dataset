

# Generated at 2022-06-21 05:22:28.266388
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert(InventoryModule.NAME == 'toml')
    assert(InventoryModule.VERBOSE_ERRORS is False)

    # Verify defaults
    assert(InventoryModule.__name__ == 'ansible.plugins.inventory.toml.InventoryModule')
    assert(InventoryModule.__doc__ == '\n    name: toml\n    version_added: "2.8"\n    short_description: Uses a specific TOML file as an inventory source.\n    description: \n        - TOML based inventory format\n        - File MUST have a valid \'.toml\' file extension\n    notes: \n        - Requires the \'toml\' python library\n    ')
    assert(InventoryModule.__module__ == 'ansible.plugins.inventory.toml')

# Generated at 2022-06-21 05:22:35.673845
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'one': [1, 'two'], 'three': {'four': 4}}) == '''one = [1, "two"]
three = {four = 4}
'''
    assert toml_dumps({'one': [1, 'two'], 'three': {'four': 4, 'five': [5.5, 5.6]}}) == '''one = [1, "two"]
three = {four = 4, five = [5.5, 5.6]}
'''

# Generated at 2022-06-21 05:22:39.456443
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = './inventory_src.toml'

    im = InventoryModule()
    result = im.verify_file(path)

    assert result

# Generated at 2022-06-21 05:22:49.126966
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    current_path = os.path.dirname(os.path.abspath(__file__))
    # Test 1: Call the method verify_file with a valid file path and check the output
    test_path = os.path.join(current_path, '../../contrib/inventory/test_inventory.toml')
    assert InventoryModule.verify_file(test_path)
    # Test 2: Call the method verify_file with an invalid file path and check the output
    test_path = os.path.join(current_path, '../../contrib/inventory/test_inventory.yaml')
    assert not InventoryModule.verify_file(test_path)



# Generated at 2022-06-21 05:22:55.689981
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    b_file_name = to_bytes(__file__)
    path = os.path.join(os.path.dirname(b_file_name), 'test', 'test.toml')
    inventoryModule = InventoryModule({}, {}, {}, {})
    assert inventoryModule.verify_file(path) == True

# Generated at 2022-06-21 05:22:58.107187
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    toml_instance = InventoryModule()
    assert toml_instance is not None

# Generated at 2022-06-21 05:23:08.279430
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """Unit test for method verify_file of class InventoryModule"""
    # This is a test, we do not care about pycodestyle
    # pylint: disable=C0103, C0111, C0112
    plugin = InventoryModule()
    path = '/Users/matt/test.toml'

    ret = plugin.verify_file(path)
    assert ret

    path = '/Users/matt/test.yaml'
    ret = plugin.verify_file(path)
    assert not ret



# Generated at 2022-06-21 05:23:10.363870
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: Unit test
    pass


# Generated at 2022-06-21 05:23:20.515904
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.module_utils._text import to_text
    from ansible.module_utils.six import ensure_text
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes, AnsibleUnsafeText, AnsibleSequence, AnsibleUnicode

    original_data = '''
        {
            string: ANSIBLE_UNICODE,
            unsafe_text: "ANSIBLE_UNSAFE_TEXT",
            unsafe_bytes: "ANSIBLE_UNSAFE_BYTES",
            sequence: [ "ANSIBLE_SEQUENCE" ]
        }
        '''

    yaml_data = AnsibleLoader(original_data, '<string>').get_single_data()

    toml_data = convert_yaml

# Generated at 2022-06-21 05:23:35.788682
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({"test": 1}) == 'test = 1\n'
    assert toml_dumps({"test": [1, 2]}) == 'test = [ 1, 2 ]\n'
    assert toml_dumps({"test": True}) == 'test = true\n'
    assert toml_dumps({"test": "str"}) == 'test = "str"\n'
    assert '\n' not in toml_dumps({"test": 1})
    assert '\n' not in toml_dumps({"test": [1, 2]})
    assert '\n' not in toml_dumps({"test": True})
    assert '\n' not in toml_dumps({"test": "str"})

# Generated at 2022-06-21 05:23:48.341970
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Verify_file returns true when file extension is .toml
    result = InventoryModule({}).verify_file('test.toml')
    assert result == True

    # Verify_file returns false when file extension is not .toml
    result = InventoryModule({}).verify_file('test.yml')
    assert result == False


# Generated at 2022-06-21 05:23:49.828073
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: Implement
    pass


# Generated at 2022-06-21 05:23:51.352382
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file(None, None)

# Generated at 2022-06-21 05:24:02.443731
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleSequence, AnsibleUnsafeText, AnsibleUnsafeBytes
    from io import BytesIO
    from toml import loads

    # Test that toml_dumps behaves like toml.dumps with native objects
    assert toml_dumps({'test': u'string'}) == toml.dumps({'test': u'string'})
    assert toml_dumps({'test': b'bytes'}) == toml.dumps({'test': b'bytes'})
    assert toml_dumps({'test': [u'string', b'bytes']}) == toml.dumps({'test': [u'string', b'bytes']})

    # Test that toml_dumps works when given an AnsibleUnic

# Generated at 2022-06-21 05:24:12.046887
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    data = toml.loads(EXAMPLES.strip())
    i = InventoryModule()
    i._parse_group('ungrouped', data['ungrouped'])
    i._parse_group('g1', data['g1'])
    i._parse_group('g2', data['g2'])
    assert len(i.inventory.groups) == 3
    assert len(i.inventory.get_groups_dict()) == 3
    assert len(i.inventory.get_hosts_dict()) == 3
    assert len(i.inventory.list_hosts('g1')) == 1
    assert len(i.inventory.list_hosts('g2')) == 1
    assert len(i.inventory.list_hosts('ungrouped')) == 1


# Generated at 2022-06-21 05:24:15.036294
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins.loader import inventory_loader

    m = inventory_loader.get('toml')
    assert isinstance(m, InventoryModule)

# Generated at 2022-06-21 05:24:23.609063
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # dictionaries
    input_data = {
        AnsibleUnicode('key'): AnsibleUnicode('value'),
        AnsibleSequence([]): AnsibleSequence([]),
        AnsibleUnsafeBytes(b'unsafe'): AnsibleUnsafeBytes(b'unsafe'),
        AnsibleUnsafeText(u'unsafe'): AnsibleUnsafeText(u'unsafe'),
        {'key2': 'value2'}: {'key2': 'value2'},
    }
    expected = {
        'key': 'value',
        'key2': 'value2',
        'unsafe': 'unsafe',
    }
    assert convert_yaml_objects_to_native(input_data) == expected

    # lists

# Generated at 2022-06-21 05:24:24.580778
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_module = InventoryModule()
    assert inv_module is not None

# Generated at 2022-06-21 05:24:28.451384
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'toml'
    assert inv.VERIFY_FILE == 'toml'


# Generated at 2022-06-21 05:24:39.489604
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    _dict = {
        'key1': 'value1',
        'key2': [
            AnsibleUnicode("key2value1"),
            AnsibleUnicode("key2value2"),
        ],
        'key3': {
            'key3key1': 'key3key1value',
            'key3key2': {
                'key3key2key1': AnsibleUnicode("key3key2key1value"),
                'key3key2key2': {
                    'key3key2key2key1': AnsibleUnsafeBytes("key3key2key2key1value".encode('utf-8')),
                }
            }
        }
    }

# Generated at 2022-06-21 05:24:53.564640
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    assert inventory.verify_file("some_file.toml")
    assert inventory.verify_file("some_file_with_toml_extension.toml")
    assert not inventory.verify_file("some_file_without_toml_extension.yaml")
    assert not inventory.verify_file("some_file_without_toml_extension")


# Generated at 2022-06-21 05:24:59.760284
# Unit test for function toml_dumps
def test_toml_dumps():

    # Using 'toml' version 0.10.1:

    # type_obj is used to verify that the method works regardless of
    # which version of 'toml' is installed.
    class type_obj(str):
        pass

    # Using TOML dictionary with keys that are strings,
    # values that are strings, dicts and lists.
    # Note that this dictionary can be passed directly to 'toml.loads()'.
    data = {
        'key1': 'value1',
        'key2': {'subkey1': 'subvalue1', 'subkey2': 'subvalue2'},
        'key3': ['subvalue1', 'subvalue2', type_obj('subvalue3')]
    }

    # Call toml_dumps() with dictionary.
    dumped = toml_dumps(data)
    print

# Generated at 2022-06-21 05:25:01.828523
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create inventory object
    # Parse TOML file
    pass

# Generated at 2022-06-21 05:25:17.779042
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:25:25.994894
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    test_data = AnsibleSequence()
    test_data.append(AnsibleUnsafeBytes('bytes_object'))
    test_data.append(AnsibleUnsafeText('text_object'))
    test_data.append(AnsibleUnicode('unicode_object'))
    test_data.append(text_type('text_type_object'))
    test_data.append('str_object')
    test_data.append(42)

    result = toml_dumps(test_data)

    # First line of result should be "[["
    first_line, _ = result.splitlines()[0], result.splitlines()[1:]


# Generated at 2022-06-21 05:25:28.832659
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj.NAME == 'toml'

if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:25:36.600824
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping, AnsibleUnicode
    data = {
        'test1': AnsibleUnicode('foo'),
        'test2': AnsibleVaultEncryptedUnicode('foo'),
        'test3': [u'foo', 'bar', 1, 2, dict(foo='bar')],
        'test4': AnsibleMapping(dict(foo='bar')),
        'test5': [AnsibleUnicode('foo'), u'foo']
    }

# Generated at 2022-06-21 05:25:39.688725
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module._populate_host_vars([], {}, 'test') is None


# Generated at 2022-06-21 05:25:55.184794
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.host import Host
    from ansible.inventory.manager import InventoryManager

    inv_manager = InventoryManager(loader=None, sources=['test/units/plugins/inventory/toml/test_inventory1.toml'])
    inventory = inv_manager.get_inventory()

    assert inventory.get_group('web').vars['http_port'] == 8080
    assert inventory.get_group('web').vars['myvar'] == 23
    assert inventory.get_group('web').vars['has_java'] is False
    assert len(inventory.get_group('web').get_hosts()) == 2
    assert len(inventory.get_group('apache').get_hosts()) == 3
    assert len(inventory.get_group('nginx').get_hosts()) == 1

    tomlcat1 = inventory

# Generated at 2022-06-21 05:26:09.395102
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import tempfile

    # Create temporary file
    temp_file = tempfile.NamedTemporaryFile()
    temp_file.write(EXAMPLES)
    temp_file.flush()

    # Create class
    path = temp_file.name
    im = InventoryModule()
    im.parse(path, 'host_list')

    # Verify group g1
    group = im.inventory.groups['g1']
    assert group.name == 'g1'
    assert group.vars == {}
    assert group.priority == 0
    assert group.depth == 1
    assert isinstance(group.get_vars(), dict)
    assert isinstance(group.get_hosts(), list)
    assert len(group.get_hosts()) == 1
    assert group.get_host('host4') == {}

# Generated at 2022-06-21 05:26:18.656770
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule(Display()).NAME == 'toml'


# Generated at 2022-06-21 05:26:21.059334
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_plug = InventoryModule()
    inv_plug.parse(None, None, 'test', False)


# Generated at 2022-06-21 05:26:36.667783
# Unit test for function toml_dumps
def test_toml_dumps():
    # tom version 0.10.0 and above
    if HAS_TOML and hasattr(toml, 'TomlEncoder'):
        # test AnsibleUnicode to str
        assert toml_dumps(AnsibleUnicode(u"hellø")) == u'hellø'
        # test AnsibleUnsafeText to str
        assert toml_dumps(AnsibleUnsafeText(u"hellø")) == u'hellø'
        # test AnsibleUnsafeBytes to str
        assert toml_dumps(AnsibleUnsafeBytes(u"hellø")) == u'hellø'
        # test AnsibleSequence to dict
        assert toml_dumps(AnsibleSequence(["hellø"])) == u'[\n  "hellø",\n]'

    # tom version less than 0

# Generated at 2022-06-21 05:26:48.256905
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import pytest

    assert convert_yaml_objects_to_native({}) == {}
    assert convert_yaml_objects_to_native("blah") == "blah"
    assert convert_yaml_objects_to_native([]) == []
    assert convert_yaml_objects_to_native({
        "a": {
            "b": [
                "1",
                2,
                3
            ]
        }
    }) == {
        "a": {
            "b": [
                "1",
                2,
                3
            ]
        }
    }

    assert convert_yaml_objects_to_native({
        "a": AnsibleUnsafeText("blah")
    }) == {
        "a": u"blah"
    }

    assert convert_yaml_objects_to

# Generated at 2022-06-21 05:26:56.542906
# Unit test for function toml_dumps
def test_toml_dumps():
    test_obj = {
        'name1': 'val1',
        'name2': {
            'name21': 'val21',
            'name22': 'val22'
        },
        'name3': [
            'val31',
            'val32'
        ]
    }
    expected_toml_str = '''name1 = "val1"
name2 = {}

[name2.name21]
name21 = "val21"
name22 = "val22"

[name3]
name3 = ["val31", "val32"]
'''
    actual_toml_str = toml_dumps(test_obj)
    assert actual_toml_str == expected_toml_str


# Generated at 2022-06-21 05:27:06.605912
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.compat.tests import unittest
    from ansible.parsing.yaml import loader

    from ansible.inventory.manager import InventoryManager
    from ansible.plugins.loader import inventory_loader

    class TestInventoryModule(unittest.TestCase):
        def setUp(self):
            self.inventory = InventoryManager(loader=loader, sources=['localhost,'])

        def to_dict(self, value):
            if isinstance(value, string_types):
                return toml_dumps(value)
            return value

        def test_empty(self):
            with self.assertRaises(AnsibleParserError):
                module = inventory_loader.get('toml')
                module.parse(self.inventory, loader, None)


# Generated at 2022-06-21 05:27:10.326663
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {'key': AnsibleUnsafeText(u'value')}
    assert toml_dumps(data) == 'key = "value"\n'

# Generated at 2022-06-21 05:27:13.199162
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert inv.verify_file('file.toml') is True
    assert inv.verify_file('file.yml') is False
    assert inv.verify_file('file.json') is False
    assert inv.verify_file(True) is False

# Generated at 2022-06-21 05:27:27.139266
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleMapping, to_yaml
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, to_yaml

    # Test that a dict containing custom Ansible yaml object types
    # can be serialized to json
    yaml_data = {
        'key': to_text(u"bob"),
        'list': [
            to_yaml(to_text(u"bob")),
            to_yaml(to_text(u"alice")),
        ],
        'subdict': {
            'subkey': {
                'subsubkey': to_text(u"bob"),
            }
        }
    }

# Generated at 2022-06-21 05:27:36.373162
# Unit test for function toml_dumps
def test_toml_dumps():

    test_obj = {
        'test_dict': {
            'test_int': 1,
            'test_float': 2.0,
            'test_string': '3',
            'test_bool': False,
            'test_list': [4, 5.0, '6', True]
        }
    }

    test_str = '''[test_dict]\ntest_int = 1\ntest_float = 2.0\ntest_string = "3"\ntest_bool = false\ntest_list = [4, 5.0, \"6\", true]\n'''

    assert test_str == toml_dumps(test_obj)

# Generated at 2022-06-21 05:27:50.317959
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode
    assert convert_yaml_objects_to_native(
        [AnsibleSequence([AnsibleUnicode('foo'), AnsibleUnicode('bar')])]
    ) == ['foo', 'bar']

    assert convert_yaml_objects_to_native(AnsibleUnicode('foo')) == 'foo'
    assert convert_yaml_objects_to_native('foo') == 'foo'


# Generated at 2022-06-21 05:27:51.412183
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("my_valid_file.toml")


# Generated at 2022-06-21 05:28:00.992926
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import mock
    ansible_file_not_found = AnsibleFileNotFound("Unable to retrieve file contents")
    ansible_parser_error = AnsibleParserError(
        "Invalid filename: 'myfile.yml'"
    )
    ansible_unsafe_proxy_error = AnsibleParserError(
        "The TOML inventory plugin requires the python 'toml' library"
    )
    yaml_unsafe_proxy_error = AnsibleParserError(
        "An error occurred while trying to read the file 'myfile.yml': 'myfile.yml'"
    )

    class FakeLoader(object):
        def __init__(self):
            self.path_exists = mock.Mock(return_value=True)

# Generated at 2022-06-21 05:28:04.330023
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    mod = InventoryModule()
    assert mod.__class__.__name__ == 'InventoryModule', "Class InventoryModule is not initialized"



# Generated at 2022-06-21 05:28:11.204344
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:28:13.023881
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
  t = InventoryModule()
  assert t is not None

# Generated at 2022-06-21 05:28:16.570363
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_file = 'test.toml'
    inv_mod = InventoryModule()
    assert inv_mod.verify_file(inventory_file) == True



# Generated at 2022-06-21 05:28:18.977321
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    mock_path = '/path/to/file.toml'
    mock_inv = InventoryModule()
    assert mock_inv.verify_file(mock_path) == True


# Generated at 2022-06-21 05:28:31.525595
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # create object
    inventory_module = InventoryModule()

    # create inventory object
    class Inventory():
        def __init__(self):
            self.groups = []

        def add_group(self, group):
            group_object = Group()
            group_object.name = group
            self.groups.append(group_object)
            return group_object

        def add_child(self, group, subgroup):
            group_object = None
            for g in self.groups:
                if g.name == group:
                    group_object = g
                    break
            if group_object is not None:
                sub_group_object = None
                for g in self.groups:
                    if g.name == subgroup:
                        sub_group_object = g
                        break

# Generated at 2022-06-21 05:28:41.981116
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ansible_module = globals()['AnsibleModule']
    module_name = 'InventoryModule'
    module = ansible_module._load_module_source(module_name, True)
    module_tmp_path = ansible_module._get_module_path(module, module_name)
    sys.path.append(os.path.dirname(module_tmp_path))
    module = __import__(module_name)
    inst = module.InventoryModule('my inventory')
    inst.set_options()
    inst.parse(inst.inventory, inst.loader, './test.toml')
    assert inst.inventory.groups['group1'] is not None
    assert inst.inventory.groups['group1']['hosts'] == ['host2']

# Generated at 2022-06-21 05:28:58.060284
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()

    assert module is not None

# Generated at 2022-06-21 05:29:10.639401
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory = InventoryModule()
    inventory.parse(EXAMPLES, '/path/to/toml_file')
    assert inventory.inventory.get_groups() == ['all', 'web', 'apache', 'nginx', 'ungrouped', 'g1', 'g2']
    assert inventory.inventory.get_hosts() == ['tomcat1', 'tomcat2', 'tomcat3', 'jenkins1', 'host1', 'host2', 'host3', 'host4']
    assert inventory.inventory.get_group_variables('all') == {'has_java': False}
    assert inventory.inventory.get_group_variables('web') == {'http_port': 8080, 'myvar': 23}
    assert inventory.inventory.get_group_variables('nginx') == {'has_java': True}
   

# Generated at 2022-06-21 05:29:11.804521
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule(
        display=Display()
    )

# Generated at 2022-06-21 05:29:13.833661
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    x = InventoryModule()
    assert x.verify_file
    assert x.parse

# Generated at 2022-06-21 05:29:26.573790
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleSequence, AnsibleMapping
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    # Load a snippet of YAML directly into the correct types

# Generated at 2022-06-21 05:29:30.376057
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({"foo": {"bar": "baz"}}) == r'''foo = { bar = "baz" }'''


# Generated at 2022-06-21 05:29:39.042436
# Unit test for function toml_dumps
def test_toml_dumps():

    class Mapping(MutableMapping):
        def __init__(self, *args, **kwargs):
            self._dict = dict(*args, **kwargs)

        def __getitem__(self, key):
            return self._dict[key]

        def __setitem__(self, key, value):
            self._dict[key] = value

        def __delitem__(self, key):
            del self._dict[key]

        def __iter__(self):
            return iter(self._dict)

        def __len__(self):
            return len(self._dict)

    data = Mapping({'myvar': 'hello world', 'mysecret': AnsibleUnsafeText(text_type('t0ps3cr3t'))})

    data_dumped = toml_dumps(data)


# Generated at 2022-06-21 05:29:47.606427
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class TestInventoryModule(InventoryModule):
        def __init__(self, *args, **kwargs):
            super(TestInventoryModule, self).__init__(*args, **kwargs)
            self._groups = []
            self._hosts = []
            self._group_vars = []

            self._group_vars_files = []
            self._host_vars_files = []

        def add_group(self, group_name):
            self._groups.append(group_name)
            return super(TestInventoryModule, self).add_group(group_name)

        def get_group(self, group_name):
            return self.groups.get(group_name, {})


# Generated at 2022-06-21 05:29:58.280865
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.wrapper import AnsibleDumper
    from ansible.parsing.yaml.dumper import AnsibleDumper
    # make a fake yaml object to use in our tests
    class MyYAMLObject(AnsibleBaseYAMLObject):
        yaml_loader = AnsibleDumper
        yaml_tag = u'test_toml.example.net,2002:myyamlobject'

        def __init__(self, value):
            self.value = value


# Generated at 2022-06-21 05:30:06.959384
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    in_data = {
        'a': AnsibleUnsafeText(u'AnsibleUnsafeText'),
        'b': AnsibleUnsafeBytes(b'AnsibleUnsafeBytes'),
        'c': AnsibleUnicode(u'AnsibleUnicode'),
        'd': u'plain unicode',
        'e': b'plain bytes',
        'f': to_text(b'utf-8 bytes', encoding='utf-8')
    }

    out_data = convert_yaml_objects_to_native(in_data)
    assert out_data['a'] == str(in_data['a'])
    assert out_data['b'] == str(in_data['b'])
    assert out_data['c'] == str(in_data['c'])
    assert out_data['d']

# Generated at 2022-06-21 05:30:29.041401
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    m = InventoryModule()
    assert m.verify_file(path='file.toml') == True
    assert m.verify_file(path='file.YML') == False
    assert m.verify_file(path='file.yaml') == False
    assert m.verify_file(path='file.txt') == False

# Generated at 2022-06-21 05:30:29.933171
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    pass

# Generated at 2022-06-21 05:30:38.663855
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    class TestType(AnsibleUnicode):
        pass
    obj = {
        'a': 'string',
        'b': [1, 2, 3],
        'c': {
            'd': [4, 5, 6, 7],
            'e': {
                'f': 'g'
            }
        },
        'h': TestType('test'),
    }
    assert convert_yaml_objects_to_native(obj) == {
        'a': 'string',
        'b': [1, 2, 3],
        'c': {
            'd': [4, 5, 6, 7],
            'e': {
                'f': 'g'
            }
        },
        'h': 'test',
    }

# Generated at 2022-06-21 05:30:49.961294
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    expected_result_1 = False
    expected_result_2 = True
    expected_result_3 = False

    inventory_module = InventoryModule()
    test_file_1 = '/usr/local/bin/not_toml'
    test_file_2 = 'usr/local/bin/file.toml'
    test_file_3 = 'usr/local/bin/file.txt'

    actual_result_1 = inventory_module.verify_file(test_file_1)
    actual_result_2 = inventory_module.verify_file(test_file_2)
    actual_result_3 = inventory_module.verify_file(test_file_3)

    assert expected_result_1 == actual_result_1
    assert expected_result_2 == actual_result_2
    assert expected_result_3

# Generated at 2022-06-21 05:30:54.696302
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText
    assert convert_yaml_objects_to_native(
        {'k': AnsibleUnsafeText('v')}
    ) == {'k': 'v'}

# Generated at 2022-06-21 05:30:56.952257
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
   # get a test class
   obj = InventoryModule()
   # compare the result with the expectation
   assert obj.NAME == 'toml'
   assert obj.cache_key == "toml_file"


# Generated at 2022-06-21 05:31:09.369152
# Unit test for function toml_dumps
def test_toml_dumps():
    # test normal dict
    assert toml_dumps(dict(foo='bar', bop=42)) == "bop = 42\nfoo = \"bar\"\n"
    # test taking a sequence
    assert toml_dumps(dict(ip_addresses=["127.0.0.1", "192.0.2.42"])) == "ip_addresses = [\"127.0.0.1\", \"192.0.2.42\"]\n"
    # test nested dict
    assert toml_dumps(dict(foo='bar', bop=dict(bop2=[1, 2, 3]))) == \
        "bop = {bop2 = [1, 2, 3]}\nfoo = \"bar\"\n"
    # test empty list

# Generated at 2022-06-21 05:31:19.097190
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Complex TOML structure
    data = toml.loads(EXAMPLES)
    # Create a test inventory object
    inventory = mock.Mock()
    # Create a test inventory plugin
    plugin = InventoryModule()
    # Execute inventory plugin parse method for test inventory object
    plugin.parse(inventory, None, None, data)
    # Assert that inventory plugin parse method for test inventory object was
    # executed
    assert inventory.add_group.called
    assert inventory.add_child.called
    assert inventory.set_variable.called
    assert inventory.add_host.called

    # Ungrouped hosts TOML structure
    data = toml.loads(EXAMPLES.split('\n#')[2])
    # Create a test inventory object
    inventory = mock.Mock()
    # Create a test inventory plugin
    plugin

# Generated at 2022-06-21 05:31:28.655299
# Unit test for function toml_dumps
def test_toml_dumps():
    import ansible.parsing.yaml.objects
    example = {'str': 'str', 'int': 1, 'float': 1.0, 'list': ['a', 'b', 'c'], 'dict': {'a': 'b'},
               'dict_with_list': {'list': [1, 2, 3], 'a': 'b'},
               'ansible_list': ansible.parsing.yaml.objects.AnsibleSequence(['a', 'b', 'c']), 'ansible_dict': {'a': ansible.parsing.yaml.objects.AnsibleUnicode('b')}}

# Generated at 2022-06-21 05:31:35.363030
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    data = {'path': 'some_path', 'ext': 'some_ext'}
    m = InventoryModule()
    result = m.verify_file(data)
    assert not result

    data['ext'] = '.toml'
    result = m.verify_file(data)
    assert result