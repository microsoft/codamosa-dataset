

# Generated at 2022-06-21 05:22:24.810234
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import unittest
    from ansible.parsing.yaml.objects import AnsibleUnsafeText, AnsibleSequence, AnsibleUnicode
    from ansible.module_utils.six import PY3

    class TestTypedTomlInventory(unittest.TestCase):
        def test_basic(self):
            input_data = {
                "foo": b"bar"
            }
            actual = convert_yaml_objects_to_native(input_data)
            self.assertDictEqual(actual, {
                "foo": "bar"
            })

        def test_dict(self):
            input_data = {
                "foo": {
                    b"bar": b"baz"
                }
            }
            actual = convert_yaml_objects_to_native(input_data)


# Generated at 2022-06-21 05:22:37.542814
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText
    assert convert_yaml_objects_to_native(AnsibleSequence([1, 2, 3])) == [1, 2, 3]
    assert convert_yaml_objects_to_native(AnsibleUnicode('abc123')) == 'abc123'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes(b'abc123')) == b'abc123'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('abc123')) == 'abc123'

# Generated at 2022-06-21 05:22:42.022110
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert inv.verify_file('file.toml') == True
    assert inv.verify_file('file.yaml') == False

# Generated at 2022-06-21 05:22:48.809777
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    # Dummy class for test
    class DummyClass:
        inventory = None
        loader = None
        path = None
        cache = None

    # Required to set these attributes
    dummy_obj = DummyClass()
    dummy_obj.inventory = "dummy"
    dummy_obj.loader = "dummy"
    dummy_obj.path = "dummy"
    dummy_obj.cache = "dummy"

    assert(dummy_obj.inventory == "dummy")
    assert(dummy_obj.loader == "dummy")
    assert(dummy_obj.path == "dummy")
    assert(dummy_obj.cache == "dummy")

# Generated at 2022-06-21 05:23:00.751231
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import tempfile
    import toml

    tmpdir = tempfile.gettempdir()

    i = AnsibleUnsafeText('k')
    j = {
        i: [AnsibleSequence([3,4]), AnsibleUnicode(u'hi'), AnsibleUnsafeBytes(b'foo')],
        'list': [1, 2, 3],
        'dict': {
            'bar': u'baz',
        },
    }

    i2 = text_type(i)

# Generated at 2022-06-21 05:23:13.638317
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:23:16.509943
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Test initialization of class InventoryModule
    inv_mod = InventoryModule()
    assert inv_mod is not None


# Generated at 2022-06-21 05:23:26.566382
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'toml', "The InventoryModule has NAME='%s' instead of 'toml'" % inv.NAME
    assert inv.verify_file('hosts') == False, "The InventoryModule.verify_file() returned True on file without 'toml' extension"
    assert inv.verify_file('hosts.toml') == True, "The InventoryModule.verify_file() returned False on file with 'toml' extension"

# Generated at 2022-06-21 05:23:39.041737
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    plugin = InventoryModule()
    inventory = {'_meta': {'hostvars': {}}}
    loader = None
    plugin.parse(inventory, loader, os.path.join(os.path.dirname(__file__), "toml_test_1.toml"))
    assert(inventory['all']['vars'] == {'has_java': False})
    assert(inventory['web']['children'] == ['apache', 'nginx'])
    assert(inventory['web']['vars'] == {'http_port': 8080, 'myvar': 23})
    assert(inventory['web']['hosts'] == ['host1', 'host2'])
    assert(inventory['web']['vars'] == {'http_port': 8080, 'myvar': 23})

# Generated at 2022-06-21 05:23:43.191415
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Test constructor (setup)
    module = InventoryModule()
    assert module.NAME == 'toml'
    assert module._options == {}



# Generated at 2022-06-21 05:24:12.497935
# Unit test for function toml_dumps
def test_toml_dumps():
    # YAML objects are distinct types, we need to convert them to native types
    # before we can use them with the toml library
    data = {
        'key': AnsibleUnsafeText('value'),
        'key2': AnsibleUnsafeBytes('value2'),
        'key3': AnsibleSequence(['value3']),
    }

    if HAS_TOML and hasattr(toml, 'TomlEncoder'):
        # toml 0.10.0+ is able to encode Ansible specific types that we use
        # to test with, if the toml library we have installed is not recent
        # enough we need to cast the data to native types
        test_data = data
    else:
        test_data = convert_yaml_objects_to_native(data)


# Generated at 2022-06-21 05:24:18.257280
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create object
    im = InventoryModule()
    # Create a dict to store the inventory data
    example = {}
    # Create a dict to store the group and hosts data
    group = {}
    # Add group names and group variables to the dict example
    example['all'] = {'vars': {'has_java': 'false'}}
    # Add hosts and host variables to the dict group
    group['host1'] = {}
    group['host2'] = {'ansible_port': '222'}
    # Add the dict group to the dict example
    example['web'] = {'hosts': group, 'children': ['apache','nginx'], 'vars': {'http_port': '8080', 'myvar': '23'}}
    # Add other hosts and host variables to the dict example

# Generated at 2022-06-21 05:24:31.634039
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-21 05:24:38.077474
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    path = '/home/user/path/to/file.toml'
    assert module.verify_file(path)
    path = '/home/user/path/to/file.other'
    assert not module.verify_file(path)


# Generated at 2022-06-21 05:24:45.993263
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.loader import AnsibleLoader


# Generated at 2022-06-21 05:24:54.022159
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    inventory_module.loader = FakeLoader()
    print(inventory_module.verify_file('/test/fake/path/.toml'))
    print(inventory_module.verify_file('/test/fake/path/.json'))
    print(inventory_module.verify_file('/test/fake/path/.py'))
    print(inventory_module.verify_file('/test/fake/path/.yaml'))


# Generated at 2022-06-21 05:24:56.958679
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.plugins.loader import InventoryLoader

    loader = InventoryLoader()
    i = InventoryModule()

    assert len(i.verify_file(loader, 'foo.yml')) == 0
    assert i.verify_file(loader, 'foo.toml')



# Generated at 2022-06-21 05:25:09.774083
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:25:20.101472
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert hasattr(InventoryModule, 'verify_file')
    assert callable(InventoryModule.verify_file)
    assert hasattr(InventoryModule, 'parse')
    assert callable(InventoryModule.parse)
    assert hasattr(InventoryModule, '_populate_host_vars')
    assert callable(InventoryModule._populate_host_vars)
    assert hasattr(InventoryModule, '_parse_group')
    assert callable(InventoryModule._parse_group)
    assert hasattr(InventoryModule, '_load_file')
    assert callable(InventoryModule._load_file)

if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:25:31.088151
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode

    assert convert_yaml_objects_to_native(AnsibleUnicode('str')) == 'str'
    assert convert_yaml_objects_to_native(AnsibleUnicode(5)) == 5
    assert convert_yaml_objects_to_native(AnsibleSequence([1, 2, AnsibleUnicode('3')])) == [1, 2, '3']
    assert convert_yaml_objects_to_native(AnsibleMapping({1: 2, AnsibleUnicode(3): 4})) == {1: 2, 3: 4}

# Generated at 2022-06-21 05:25:53.661306
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import io
    import mock
    import toml

    # Setup dummy file contents
    file_contents = """
[test]
localhost ansible_connection=local
localhost2 ansible_connection=local
[test.vars]
foo = "bar"
[test2]
localhost ansible_connection=local
localhost2 ansible_connection=local
[test2.vars]
foo = "bar"
    """.strip()

    with mock.patch('ansible.plugins.inventory.toml.open', mock.mock_open(read_data=file_contents)):
        inv_mod = InventoryModule()
        inv_mod.loader = mock.Mock()
        inventory = mock.Mock()
        inv_mod.parse(inventory, inv_mod.loader, 'test_InventoryModule_verify_file')



# Generated at 2022-06-21 05:26:08.363847
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create an object of class InventoryModule
    inventoryModule = InventoryModule()

    # Test invalid filename
    invalid_filename = None
    try:
        inventoryModule._load_file(invalid_filename)
    except Exception as e:
        assert isinstance(e, AnsibleParserError)
        assert e.message == "Invalid filename: 'None'"
    assert True

    # Test missing file
    invalid_filename = 'nofile.toml'
    try:
        inventoryModule._load_file(invalid_filename)
    except Exception as e:
        assert isinstance(e, AnsibleFileNotFound)
        assert e.message == "Unable to retrieve file contents"
        assert e.file_name == invalid_filename
    assert True

    # Test missing file
    invalid_filename = '/nofile.toml'

# Generated at 2022-06-21 05:26:23.971356
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native(['a', 'b']) == ['a', 'b']
    assert convert_yaml_objects_to_native({'test': 'c2'}) == {'test': 'c2'}
    assert convert_yaml_objects_to_native(AnsibleSequence(['a', 'b'])) == ['a', 'b']
    assert convert_yaml_objects_to_native(AnsibleUnicode(u'unicode')) == u'unicode'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes(b'\xFF')) == b'\xFF'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText(u'\xFF')) == u'\xFF'

# Generated at 2022-06-21 05:26:35.005882
# Unit test for function toml_dumps
def test_toml_dumps():
    """
    Unit test for function toml_dumps

    :return:
    """
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    data = {
        'var1': 1,
        'var2': 2.2,
        'var3': [1, 2, 3],
        'var4': "val",
        'var5': AnsibleUnicode('val'),
        'var6': AnsibleUnsafeText('val'),
        'var7': AnsibleUnsafeBytes('val'),
    }

    output = toml_dumps(data)

# Generated at 2022-06-21 05:26:46.794970
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps(dict(
        a=1,
        b='xyz',
        c=[3, 4, 5],
        d=['x', 'y', 'z'],
        e=dict(
            aa=11,
            bb=22,
        ),
        f=['xx', 'yy', 'zz'],
    )) == (
        "a = 1\n"
        "b = \"xyz\"\n"
        "c = [ 3, 4, 5 ]\n"
        "d = [ \"x\", \"y\", \"z\" ]\n"
        "e = { aa = 11, bb = 22 }\n"
        "f = [ \"xx\", \"yy\", \"zz\" ]\n"
    )


# Generated at 2022-06-21 05:26:48.120094
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    InventoryModule()

# Generated at 2022-06-21 05:26:50.605347
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.plugins.loader import InventoryPluginLoader
    print('testing InventoryModule class')
    loader = InventoryPluginLoader()

# Generated at 2022-06-21 05:27:02.201785
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert toml_dumps({'a': 'b'}) == r'''a = "b"'''
    assert toml_dumps({'a': {'b': 'c'}}) == r'''[a]
b = "c"'''
    assert toml_dumps({'a': [{'b': 'c'}]}) == r'''[[a]]
  [a.0]
  b = "c"'''
    assert toml_dumps({'a': [1, 2, 3]}) == r'''a = [1, 2, 3]'''
    assert toml_dumps({1: 2}) == r'''1 = 2'''

# Generated at 2022-06-21 05:27:17.733728
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.parsing.yaml.wrapper import AnsibleUnsafeText


# Generated at 2022-06-21 05:27:28.326178
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    # Test for file path with .toml extension.
    path = './test/group_vars/all.toml'
    result = InventoryModule.verify_file(InventoryModule(),path)
    assert result == True
    
    # Test for file path with .yml extension.
    path = './test/group_vars/all.yml'
    result = InventoryModule.verify_file(InventoryModule(),path)
    assert result == False

    # Test for file path with not supported extension.
    path = './test/group_vars/all.xml'
    result = InventoryModule.verify_file(InventoryModule(),path)
    assert result == False


# Generated at 2022-06-21 05:27:50.046235
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:28:00.461244
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.module_utils.common._collections_compat import Mapping
    from ansible.module_utils.six import integer_types, binary_type, text_type
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, \
        AnsibleUnsafeText, AnsibleUnsafeBytes
    assert isinstance(convert_yaml_objects_to_native('foo'), text_type)
    assert isinstance(convert_yaml_objects_to_native(b'foo'), binary_type)
    assert isinstance(convert_yaml_objects_to_native(42), integer_types)
    assert isinstance(convert_yaml_objects_to_native([]), list)

# Generated at 2022-06-21 05:28:04.292809
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_plugin = InventoryModule()

    assert inventory_plugin.verify_file('test.toml')
    assert not inventory_plugin.verify_file('test.txt')

# Generated at 2022-06-21 05:28:18.667847
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """ Return true if path ends with .toml extension, otherwise return False """
    file_name_with_toml_extension_1="/path/to/somefile.toml"
    file_name_with_toml_extension_2="somefile.toml"
    file_name_with_not_toml_extension_1="/path/to/somefile.tom.l"
    file_name_with_not_toml_extension_2="/path/to/somefile"
    file_name_with_not_toml_extension_3=".toml"
    file_name_with_not_toml_extension_4="somefile.toml."

    invmod=InventoryModule()
    assert invmod.verify_file(file_name_with_toml_extension_1)

# Generated at 2022-06-21 05:28:28.817535
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Create an instance of class InventoryModule
    o = InventoryModule()
    # Test the function with valid file
    assert(o.verify_file('./inventory/sample.toml'))
    # Test the function with invalid file
    assert(not o.verify_file('./inventory/sample.yml'))
    # Test the function with invalid file
    assert(not o.verify_file('./inventory/sample.not_a_toml'))


# Generated at 2022-06-21 05:28:32.891159
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import pytest


# Generated at 2022-06-21 05:28:41.617541
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    '''
    InventoryModule.parse is the function which parses the toml file of the plugin
    '''
    class DummyOpts(object):
        def __init__(self):
            self.hostfile = ''

    class DummyPlugin():
        def __init__(self):
            self.inventory = InventoryModule(loader=None, groups={}, sources=[])
            self.args = ''
            self.parser = None

        def set_options(self):
            self.options = DummyOpts()

    plugin = DummyPlugin()
    plugin.parse(plugin.inventory, plugin.loader, plugin.filename)



# Generated at 2022-06-21 05:28:54.707881
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    assert convert_yaml_objects_to_native(u'unicode') == u'unicode'
    assert convert_yaml_objects_to_native(u'unicode'.encode('utf-8')) == u'unicode'

    assert convert_yaml_objects_to_native(AnsibleUnicode(u'unicode')) == u'unicode'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes(b'unicode')) == u'unicode'

# Generated at 2022-06-21 05:29:04.656670
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import get_all_plugin_loaders
    from ansible.plugins.inventory import InventoryModule as im
    import os
    
    currentdir = os.path.dirname(__file__)
    parentdir = os.path.dirname(currentdir)
    sys.path.insert(0, parentdir)
    
    module_loader = get_all_plugin_loaders()['inventory']
    module_cls = module_loader.get('toml')
    
    inventory_module = module_cls()
    
    parser = InventoryModule()
    parser.parse(inventory_module, None, './unittests/inventory_module_test_data.toml', cache=True)

    # verify all the hosts have been pulled
    assert 'host1' in inventory_module.hosts

# Generated at 2022-06-21 05:29:14.391495
# Unit test for function toml_dumps
def test_toml_dumps():
    # Create a dict with Ansible safe text, bytes and sequences
    mapped_data = {
        "this": {
            "is": {
                "unicode": AnsibleUnsafeText("unicode"),
                "safe": AnsibleUnsafeBytes("safe"),
            },
            "a": {
                "sequence": AnsibleSequence(["one", "two"]),
            },
            "mutable": {
                "mapping": AnsibleUnicode({
                    "one": "two",
                    "three": "four"
                }),
            }
        }
    }

# Generated at 2022-06-21 05:29:44.792054
# Unit test for function toml_dumps
def test_toml_dumps():
    data = convert_yaml_objects_to_native(toml.loads(EXAMPLES))
    generated = toml_dumps(data)
    assert generated == EXAMPLES

# Generated at 2022-06-21 05:29:50.453876
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Note: This test is not executed when running ansible-test units --module
    plugin = InventoryModule()
    plugin.set_options()
    if plugin.verify_file("/path/to/file.toml"):
        assert True
    else:
        assert False

# Generated at 2022-06-21 05:29:59.139737
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_inventory_file = '''# fmt: toml
[all.vars]
has_java = false

[web]
children = ["apache", "nginx"]

[web.vars]
http_port = 8080
myvar = 23

[web.hosts.host1]
[web.hosts.host2]
ansible_port = 222

[apache.hosts.tomcat1]

[apache.hosts.tomcat2]
myvar = 34

[apache.hosts.tomcat3]
mysecret = "03#pa33w0rd"

[nginx.hosts.jenkins1]

[nginx.vars]
has_java = true
'''
    # Parse example TOML inventory file

# Generated at 2022-06-21 05:30:02.832956
# Unit test for function toml_dumps
def test_toml_dumps():

    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject

    assert toml_dumps(AnsibleBaseYAMLObject()) == u''

# Generated at 2022-06-21 05:30:10.447695
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'test': 'to_text'}) == b'test = "to_text"\n'
    assert toml_dumps({'test': 'to_native'}) == b'test = "to_native"\n'
    assert toml_dumps({'test': 'to_bytes'}) == b'test = "to_bytes"\n'
    assert toml_dumps({'test': 'to_text'}) == b'test = "to_text"\n'
    assert toml_dumps({'test': AnsibleUnsafeText('unsafe_text')}) == b'test = "unsafe_text"\n'

# Generated at 2022-06-21 05:30:20.246752
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """Unit test for method parse of class InventoryModule."""
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    from test.unit.plugins.modules.test_invoke_module import TestInventoryModule
    from test.unit.plugins.modules.test_yaml_plugin import TestYAMLPlugin

    # Create a TestInventoryModule
    inventory_module = TestInventoryModule()

    # Create a TestYAMLPlugin
    yaml_plugin = TestYAMLPlugin()
    yaml_plugin.set_options()

    # Create a list with the test data
    data = yaml_plugin.load_file(EXAMPLES)

    # Test with data
    inventory_module.parse(data)

    # Test if all hosts are listed
    hosts = inventory

# Generated at 2022-06-21 05:30:33.754564
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:30:36.536473
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    pass

if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:30:46.419305
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import os
    import shutil

    module = InventoryModule()

    try:
        os.mkdir('tests')
        with open('tests/test_toml', 'w') as f:
            f.write(EXAMPLES)

        assert module.verify_file(path='tests/test_toml')
        assert module.verify_file(path='tests/test_toml.not_toml')
    finally:
        shutil.rmtree('tests')


# Generated at 2022-06-21 05:30:57.932428
# Unit test for function toml_dumps
def test_toml_dumps():
    """
    this function is used to unit test the function toml_dumps.
    It returns true if the unit test passes.
    It returns false if the unit test fails
    """
    data = {'variable': 'value',
            'variable2': [1, 2, 3],
            'variable3': {'subkey': 'subvalue'}}

    data_native = {'variable': 'value',
            'variable2': [1, 2, 3],
            'variable3': {'subkey': 'subvalue'}}

    data_yaml = {'variable': AnsibleUnsafeText('value'),
            'variable2': AnsibleSequence([1, 2, 3]),
            'variable3': {'subkey': AnsibleUnsafeText('subvalue')}}

    dumped_data = toml_dumps(data)

# Generated at 2022-06-21 05:31:40.094819
# Unit test for function toml_dumps
def test_toml_dumps():
    # fmt: off
    expected = r'''[all.vars]
has_java = false

[web]
children = ["apache", "nginx"]
vars = {http_port = 8080, myvar = 23}

[web.hosts]
host1 = {}
host2 = {ansible_port = 222}

[apache.hosts]
tomcat1 = {}
tomcat2 = {myvar = 34}
tomcat3 = {mysecret = "03#pa33w0rd"}

[nginx.hosts]
jenkins1 = {}

[nginx.vars]
has_java = true

'''
    # fmt: on

# Generated at 2022-06-21 05:31:51.551388
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native({}) == {}
    assert convert_yaml_objects_to_native(dict({1: 2})) == dict({1: 2})
    assert convert_yaml_objects_to_native(dict({'a': 2})) == dict({'a': 2})
    assert convert_yaml_objects_to_native(dict({'a': [1, 2]})) == dict({'a': [1, 2]})
    assert convert_yaml_objects_to_native(dict({'a': AnsibleUnicode(1)})) == dict({'a': 1})
    assert convert_yaml_objects_to_native(dict({'b': 2, 'a': [1, 2]})) == dict({'b': 2, 'a': [1, 2]})
    assert convert_

# Generated at 2022-06-21 05:32:02.464378
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    """
    This test verifies that convert_yaml_objects_to_native() works as expected
    """
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeText, AnsibleUnsafeBytes
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import yaml