

# Generated at 2022-06-21 05:22:25.748881
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    data = {
        AnsibleUnsafeText('test'): AnsibleUnsafeText('value'),
        'test2': 10,
        'test3': {
            'test': [
                AnsibleUnsafeText('test'),
                AnsibleUnsafeText('test2')
            ]
        }
    }

    actual_str = toml_dumps(data)

    assert actual_str == '[test3]\ntest = ["test", "test2"]\n\n[test]\nvalue = "value"\n\ntest2 = 10\n', 'Expected TOML output does not match'

# Generated at 2022-06-21 05:22:26.609200
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    InventoryModule()

# Generated at 2022-06-21 05:22:29.416797
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse(inventory=None, loader=None, path=None)

# Generated at 2022-06-21 05:22:39.418300
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:22:50.057418
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Create a sparse file_name (path) value
    file_name = 'myplaybook/inventory/hosts'
    # Create an InventoryModule
    inventory = InventoryModule()
    # Create a loader
    loader = None
    # Create a path
    path = 'myplaybook/inventory/hosts'
    # Call method parse
    inventory.parse(inventory, loader, path)
    # Call method verify_file
    inventory.verify_file(path)
    # Call method _load_file
    data = inventory._load_file(path)
    # Call method _parse_group
    inventory._parse_group('all', data)
    # Create a path
    path = 'myplaybook/inventory/hosts'
    # Create a loader
    loader = None
    # Create an InventoryModule
    inventory = InventoryModule()
   

# Generated at 2022-06-21 05:23:00.909134
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import pytest
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    assert convert_yaml_objects_to_native(AnsibleUnicode(b'test')) == 'test'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes('test')) == 'test'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('test')) == 'test'
    assert convert_yaml_objects_to_native(AnsibleSequence(['test'])) == ['test']
    assert convert_yaml_objects_to_native(AnsibleSequence([AnsibleUnsafeBytes('test')])) == ['test']

# Generated at 2022-06-21 05:23:03.246400
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = BaseFileInventoryPlugin()
    loader = BaseFileInventoryPlugin()
    path = ''
    cache = True
    test = InventoryModule(inventory, loader, path, cache)
    assert test

# Generated at 2022-06-21 05:23:13.151818
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible import context
    from ansible.cli.playbook import PlaybookCLI
    from ansible.parsing.dataloader import DataLoader
    from ansible.playbook.play import Play
    from ansible.plugins.loader import InventoryLoader
    context.CLIARGS = PlaybookCLI.base_parser(
        runas_opts=True,
        async_opts=True,
        output_opts=True
    ).parse_args('')
    loader = DataLoader()
    resource = './'
    inv = InventoryLoader(loader=loader, sources=resource)
    inv.parse()
    if os.path.exists('./examples'):
        resource = './examples'
    inv = InventoryLoader(loader=loader, sources=resource)
    inv.parse()
   

# Generated at 2022-06-21 05:23:19.245451
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    file_name, ext = os.path.splitext("/test/path/test_file.test")
    file_name_toml, ext_toml = os.path.splitext("/test/path/test_file.toml")
    plugin = InventoryModule()
    assert plugin.verify_file("/test/path/test_file.test") == False
    assert plugin.verify_file("/test/path/test_file.toml") == True

# Generated at 2022-06-21 05:23:30.580635
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    def test_inventory_instance():
        class Inventory:
            def __init__(self):
                self.hosts = {}
                self.groups = {}
                self.vars = {}
            def add_host(self, host, group=None):
                if group is None: group = 'ungrouped'
                if group not in self.groups: self.groups[group] = Group(group, [host])
                self.groups[group].hosts.append(host)
            def set_variable(self, host, var, value):
                if host not in self.hosts:
                    self.hosts[host] = Host(host)
                self.hosts[host].vars[var] = value
        class Group:
            def __init__(self, name, hosts):
                self.name = name
                self.host

# Generated at 2022-06-21 05:23:52.887358
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.module_utils.six import PY3
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    if PY3:
        native_str = "Hello World"
        unsafe_str = AnsibleUnsafeText(u"\u1234")
    else:
        # In Python 2, AnsibleUnsafeText is just str
        native_str = to_text("Hello World")
        unsafe_str = to_text(u"\u1234")

    data = {
        "key": {
            "subkey": native_str
        },
        "list": [
            native_str,
            unsafe_str,
        ]
    }

    dumped_data = toml_dumps(data)


# Generated at 2022-06-21 05:24:03.015296
# Unit test for function toml_dumps
def test_toml_dumps():
    """Unit test using pytest

    More details, see:

    - https://docs.pytest.org/en/latest/
    """
    import pytest

    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode

    from ansible.utils.unsafe_proxy import AnsibleUnsafeText


# Generated at 2022-06-21 05:24:15.575857
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    # File with '.toml' extension should return True
    path = 'pw_test.toml'
    assert inventory_module.verify_file(path)

    # File with '.yml' extension should return False
    path = 'pw_test.yml'
    assert not inventory_module.verify_file(path)

    # Empty path should return False
    path = ''
    assert not inventory_module.verify_file(path)

    # Path is None should return a False
    path = None
    assert not inventory_module.verify_file(path)


# Generated at 2022-06-21 05:24:20.904134
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    assert inv_mod.verify_file("./test_fixtures/inventory_valid.toml") is True
    assert inv_mod.verify_file("./test_fixtures/inventory_valid.yaml") is False
    assert inv_mod.verify_file("./test_fixtures/inventory_valid.ini") is False

test_InventoryModule_verify_file()

# Generated at 2022-06-21 05:24:36.624617
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps(None) == 'null\n'

    assert toml_dumps(1) == '1\n'
    assert toml_dumps(1.1) == '1.1\n'

    assert toml_dumps("string") == '"string"\n'

    assert toml_dumps([1, 2, 3]) == '[1, 2, 3]\n'

    assert toml_dumps({'a': 1, 'b': 2}) == 'a = 1\nb = 2\n'


# Generated at 2022-06-21 05:24:45.621541
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.module_utils.six import text_type

    assert convert_yaml_objects_to_native(None) is None
    assert convert_yaml_objects_to_native(3) == 3
    assert convert_yaml_objects_to_native(int) is int
    assert convert_yaml_objects_to_native(AnsibleUnicode('abc')) == 'abc'
    assert convert_yaml_objects_to_native(text_type('def')) == 'def'
    assert convert_yaml_objects_to_native(dict(a=1, b=2)) == {'a': 1, 'b': 2}

# Generated at 2022-06-21 05:24:48.239797
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'a': 'b'}) == "a = \"b\"\n"


# Generated at 2022-06-21 05:24:59.019168
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    data = {
        'foo': "bar",
        'bar': 23,
        'foobar': [1, 2, 3],
        'barfoo': {'foo': "bar", 'bar': 23, 'fizz': [1, 2, 3]},
        'fizz': {'foo': "bar", 'bar': 23, 'fizz': [1, 2, 3]},
        'fizzbuzz': {'barfoo': {'foo': "bar", 'bar': 23, 'fizz': [1, 2, 3]}},
    }

# Generated at 2022-06-21 05:25:01.119789
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.NAME == 'toml'



# Generated at 2022-06-21 05:25:17.012299
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import unittest.mock as mock
    import collections

    sample_data_v1 = {
        'hosts': {
            'host1': {
                'ansible_host': '127.0.0.1',
                'ansible_port': 22,
            },
        },
        'g1': {
            'hosts': {
                'host2': {
                    'ansible_host': '192.168.0.1',
                },
            },
            'children': [
                'g2',
            ],
        },
        'g2': {
            'vars': {
                'foo': 'bar',
            },
        },
    }

    test_data_v1 = convert_yaml_objects_to_native(sample_data_v1)


# Generated at 2022-06-21 05:25:32.777908
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert(False)

# Generated at 2022-06-21 05:25:42.673052
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Test both TOML and a TOML-in-Ansible-style list
    actual = convert_yaml_objects_to_native({
        "foo": [
            "bar",
            "baz"
        ],
        "bar": [
            "fasd",
            "fdsa"
        ]
    })
    expect = {
        "foo": [
            "bar",
            "baz"
        ],
        "bar": [
            "fasd",
            "fdsa"
        ]
    }
    assert actual == expect


# Generated at 2022-06-21 05:25:53.881249
# Unit test for method parse of class InventoryModule

# Generated at 2022-06-21 05:25:56.896947
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    display = Display()
    inventory = InventoryModule(display, loader)
    assert isinstance(inventory, InventoryModule)


# Generated at 2022-06-21 05:26:04.482650
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode

# Generated at 2022-06-21 05:26:14.122933
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    source = './tests/inventory/test_inventory_toml'
    inventory = InventoryModule()
    inventory.parse(source, None, source, cache=None)
    assert 'web' in inventory.get_groups_dict()
    assert 'apache' in inventory.get_groups_dict()
    assert 'g1' in inventory.get_groups_dict()
    assert 'host1' in inventory.get_groups_dict()['web']['hosts']
    assert 'has_java' in inventory.get_groups_dict()['web']['vars']
    assert 'apache' in inventory.get_groups_dict()['web']['children']


# Generated at 2022-06-21 05:26:18.953810
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():

    def assert_native_type(data):
        " Function to assert data is a native type "
        if HAS_TOML and hasattr(toml, 'TomlEncoder'):
            # if we have a new enough version of toml that has pluggable encoders, we should accept non-native types
            pass
        else:
            assert isinstance(data, (dict, list, str, int, float, bool, type(None)))

    def assert_equal(data, converted):
        " Function to assert data and converted are equal, handling native types "
        if not HAS_TOML and hasattr(toml, 'TomlEncoder'):
            assert data == converted
        else:
            assert toml.dumps(data) == toml.dumps(converted)


# Generated at 2022-06-21 05:26:20.848267
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    pass

if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:26:22.868538
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv is not None


# Generated at 2022-06-21 05:26:25.554597
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    result = InventoryModule()
    assert result.NAME == 'toml'

# Run test for toml_dumps

# Generated at 2022-06-21 05:27:05.891885
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.plugins.loader import find_plugin
    from ansible.plugins.inventory import BaseInventoryPlugin
    from ansible.utils.display import Display

    display = Display()
    inventory = BaseInventoryPlugin()
    loader = find_plugin('inventory') # This plugin is mandatory so it must be present
    inventoryFile = None
    cache = True
    group_name = 'test'
    group_data = AnsibleMapping()
    # Create a new inventory object
    inventoryModule = InventoryModule()
    # Create the first valid file to test
    extension = ".toml"
    path = "hosts" + extension
    file = open(path,'w')
    file.write("[test]")
    file.close()
    # Test the method verify

# Generated at 2022-06-21 05:27:07.356694
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    mod = InventoryModule()
    assert mod != None

# Generated at 2022-06-21 05:27:20.194806
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.module_utils.common._collections_compat import MutableSequence, Mapping

    # Test strings
    s = AnsibleUnicode('abcd')
    assert isinstance(convert_yaml_objects_to_native(s), text_type)

    s = to_text('abcd')
    assert isinstance(convert_yaml_objects_to_native(s), text_type)

    s = 'abcd'
    assert isinstance(convert_yaml_objects_to_native(s), text_type)

    # Test lists
    l = AnsibleSequence([AnsibleUnicode('abcd')])

# Generated at 2022-06-21 05:27:22.917823
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'key': 'value'}) == ('key = "value"\n')

# Generated at 2022-06-21 05:27:35.060618
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnicode, AnsibleSequence

    ansible_unicode = AnsibleUnicode(b'test')
    ansible_sequence = AnsibleSequence(b'test')
    ansible_mapping = AnsibleMapping(b'test')

    assert convert_yaml_objects_to_native(ansible_unicode) == 'test'
    assert convert_yaml_objects_to_native(ansible_sequence) == ['test']
    assert convert_yaml_objects_to_native(ansible_mapping) == {'test': None}

# Generated at 2022-06-21 05:27:47.614005
# Unit test for function toml_dumps
def test_toml_dumps():
    assert (
        toml_dumps({'key': 'value'}) ==
        'key = "value"\n'
    )
    assert (
        toml_dumps({'key': AnsibleUnsafeText('value')}) ==
        'key = "value"\n'
    )
    assert (
        toml_dumps({'key': AnsibleUnsafeBytes('value')}) ==
        'key = "value"\n'
    )
    assert (
        toml_dumps({'key': AnsibleUnicode('value')}) ==
        'key = "value"\n'
    )
    assert (
        toml_dumps({'key': [1, 2, 3]}) ==
        'key = [1, 2, 3]\n'
    )

# Generated at 2022-06-21 05:27:53.249729
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import copy
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    data = {
        'a': u'b',
        'c': [1, 2, 3],
        'd': [AnsibleUnicode('e'), u'f'],
        'g': AnsibleSequence([u'h', u'i']),
        'j': AnsibleUnicode(u'k'),
        'l': {
            'm': AnsibleSequence([
                AnsibleUnicode('n'),
                u'o',
                AnsibleUnicode(u'p')
            ])
        }
    }

# Generated at 2022-06-21 05:28:01.687235
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # see https://github.com/ansible/ansible/blob/devel/hacking/test-module
    from ansible.module_utils.six import BytesIO
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.plugins.inventory import BaseInventoryPlugin
    from ansible.inventory.host import Host

    class AnsibleInventory(BaseInventoryPlugin):
        NAME = 'inventory_module'

        def add_group(self, group):
            return group

        def add_child(self, group, subgroup):
            pass

        def add_host(self, host_name, group, port=None):
            return Host(name=host_name, port=port)

        def set_variable(self, host, varname, value):
            pass

# Generated at 2022-06-21 05:28:17.669807
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    try:
        import toml
        f = open("/tmp/test.toml", "w")
        f.write("[ungrouped.hosts]\nhost1 = {}\nhost2 = { ansible_host = \"127.0.0.1\", ansible_port = 44 }\nhost3 = { ansible_host = \"127.0.0.1\", ansible_port = 45 }\n[g1.hosts]\nhost4 = {}\n[g2.hosts]\nhost4 = {}")
        f.close()
        testInv = InventoryModule()
        testInv.parse(path="/tmp/test.toml")
    except Exception as e:
        print(e)

    f = open("/tmp/test.toml", "w")

# Generated at 2022-06-21 05:28:19.150902
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    m = InventoryModule()



# Generated at 2022-06-21 05:29:24.143569
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    invmod = InventoryModule()
    assert not invmod.verify_file('abcdefg')
    assert not invmod.verify_file('abcdefg.toml.txt')
    assert invmod.verify_file('abcdefg.toml')
    assert invmod.verify_file('abcdefg.TOML')

# Generated at 2022-06-21 05:29:28.429592
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule().verify_file("test.toml")
    assert not InventoryModule().verify_file("test.txt")



# Generated at 2022-06-21 05:29:38.368743
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native({}) == {}
    assert convert_yaml_objects_to_native([]) == []
    assert convert_yaml_objects_to_native('127.0.0.1') == '127.0.0.1'
    assert convert_yaml_objects_to_native(AnsibleUnicode('127.0.0.1')) == '127.0.0.1'
    assert convert_yaml_objects_to_native(AnsibleUnsafeBytes('127.0.0.1')) == '127.0.0.1'
    assert convert_yaml_objects_to_native(AnsibleUnsafeText('127.0.0.1')) == '127.0.0.1'

# Generated at 2022-06-21 05:29:47.423580
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from collections import namedtuple
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject, AnsibleDict
    from ansible.module_utils._text import to_text
    import sys

    # These types are used by the ansible.parsing.yaml.objects.* modules
    # ``convert_yaml_objects_to_native`` is used to cast its types to native
    # types so they can be easily serialized by the ``toml`` library
    # On ``toml<0.10.0`` there is no ``toml.TomlEncoder`` it is assumed that
    # the dump_funcs handles all types, so we just need to ensure we convert
    # ``AnsibleBaseYAMLObject`` and its subclasses to native types
    # On ``toml>=0.10

# Generated at 2022-06-21 05:29:58.196102
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import pytest
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources=['tests/unittests/inventory_parse/hosts.toml'])
    inv.parse_inventory(inventory=inv)
    groups = inv.get_groups()

    # Validate the first group 'all.vars'
    group = groups['all.vars']
    assert group.vars == {'has_java': 'false'}

    # Validate the second group 'web'
    group = groups['web']
    assert set(group.get_hosts()['host1'].vars.keys()) == set()

# Generated at 2022-06-21 05:30:04.686373
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.vars.manager import VariableManager

    loader = DataLoader()
    inv = InventoryManager(loader=loader, sources='localhost,')
    var_manager = VariableManager(loader=loader, inventory=inv)
    inv_source = InventoryModule()

    #Bogus test
    fpath = "tests/inventory/test_inventory_toml01.toml"

    assert(inv_source.verify_file(fpath) == True)
    return True


# Generated at 2022-06-21 05:30:18.373886
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    data = """
[all.vars]
has_java = false

[web]
children = [
    "apache",
    "nginx"
]
vars = { http_port = 8080, myvar = 23 }

[web.hosts]
host1 = {}
host2 = { ansible_port = 222 }

[apache.hosts]
tomcat1 = {}
tomcat2 = { myvar = 34 }
tomcat3 = { mysecret = "03#pa33w0rd" }

[nginx.hosts]
jenkins1 = {}

[nginx.vars]
has_java = true
"""

# Generated at 2022-06-21 05:30:26.204522
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.yaml.objects import AnsibleUnsafeText

    # Ensure that older versions of ``toml`` properly convert YAML object types
    # to native python types
    if not HAS_TOML or not hasattr(toml, 'TomlEncoder'):
        d = {'a': AnsibleUnsafeText(u'b')}
        assert toml_dumps(d) == 'a = "b"\n'

    # Example 1

# Generated at 2022-06-21 05:30:37.845890
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.module_utils.six import string_types, text_type
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText


# Generated at 2022-06-21 05:30:49.213534
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from collections import OrderedDict
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    # Empty dict
    assert convert_yaml_objects_to_native({}) == {}

    # Empty list
    assert convert_yaml_objects_to_native([]) == []

    # Empty OrderedDict
    assert convert_yaml_objects_to_native(OrderedDict()) == OrderedDict()

    # Simple text
    assert convert_yaml_objects_to_native('test') == 'test'

    # Text that is a subclass of text_type
    assert convert_yaml_objects_to_native(AnsibleVaultEncryptedUnicode('test')) == 'test'

    # Simple dict