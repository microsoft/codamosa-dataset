

# Generated at 2022-06-21 05:22:11.053835
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert inv.verify_file("testfile.toml")
    assert not inv.verify_file("testfile.yml")

# Generated at 2022-06-21 05:22:23.574807
# Unit test for function toml_dumps
def test_toml_dumps():
    # fmt: toml
    obj = {
        'a': 1,
        'b': ['b', 'c', 'd'],
        'c': {
            'c1': '2',
            'c2': '3',
            'c3': {
                'd1': '4'
            }
        },
        'd': '5'
    }
    assert toml_dumps(obj) == (
        'a = 1\n'
        'b = ["b", "c", "d"]\n'
        '[c]\n'
        'c1 = "2"\n'
        'c2 = "3"\n'
        '[c.c3]\n'
        'd1 = "4"\n'
        'd = "5"\n')


# Generated at 2022-06-21 05:22:35.829170
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins import InventoryModule
    from ansible.cli.playbook import CLIRunner
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    test_path="/tmp/test_InventoryModule_parse.toml"
    test_dir="/tmp/"
    test_string = EXAMPLES


# Generated at 2022-06-21 05:22:48.888851
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    ansible_str = to_text(b'unicode string: \xe9\xbb\x84\xe6\x8b\x89\xe5\xaf\xa6\xe8\x88\x89')
    ansible_byt = to_bytes(ansible_str)
    a_seq = AnsibleSequence([
        AnsibleUnicode(ansible_str),
        AnsibleUnsafeBytes(ansible_byt),
        AnsibleUnsafeText(ansible_str),
        ])

# Generated at 2022-06-21 05:22:55.152080
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  assert InventoryModule().verify_file("inventory_doml.txt") == True
  assert InventoryModule().verify_file("inventory_doml.toml") == True
  assert InventoryModule().verify_file("inventory_doml.yaml") == False


# Generated at 2022-06-21 05:23:08.375874
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    def _assert_conversion(test):
        assert convert_yaml_objects_to_native(test['before']) == test['after']


# Generated at 2022-06-21 05:23:17.904240
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    host = "127.0.0.1"
    port = 5000
    basedir = os.path.dirname(os.path.abspath(__file__))
    test_data_dir = os.path.join(basedir, 'test_data')

    # Create Inventory module
    inventory = InventoryModule()
    inventory.parse(inventory, loader, path=os.path.join(test_data_dir, "hosts.toml"))

    # Test inventory
    # Test non-existant host
    assert(not inventory.get_host("non-existant"))

    # Test single host
    host_info = inventory.get_host(host)
    assert(host_info.name == host)
    assert(host_info.vars["example_var"] == "some value")

    # Test single host port assignment
   

# Generated at 2022-06-21 05:23:23.043680
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Test simple case:
    data = {
        'key1': 'value1',
        'key2': [1, 2, 3],
        'key3': {
            'key4': {'key5': True},
        },
    }
    assert convert_yaml_objects_to_native(data) == data

    # Test all objects from ansible.parsing.yaml.objects
    data = {
        'AnsibleSequence': [1, 2, 3],
        'AnsibleUnicode': text_type('value'),
        'AnsibleUnsafeBytes': AnsibleUnsafeBytes(b'value'),
        'AnsibleUnsafeText': AnsibleUnsafeText(u'value'),
    }

# Generated at 2022-06-21 05:23:37.198742
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    import sys

    fake_env = {
        'HOME': '/Users/foo',
        'PATH': '/bin:/usr/bin:/usr/local/bin',
    }

    if sys.version_info[0] < 3:
        fake_env['PATH'] = '/bin:/usr/bin:/usr/local/bin'
    else:
        fake_env['PATH'] = '/bin:/usr/bin:/usr/local/bin'
        fake_env['HOME'] = '/Users/foo'
        fake_env['PWD'] = '/Users/foo/'

    # Test data uses types from ansible.parsing.yaml.objects

# Generated at 2022-06-21 05:23:44.693824
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv.verify_file('/path/to/file.toml') is True
    assert inv.verify_file('/path/to/file.yaml') is False
    assert inv.verify_file('/path/to/file.yml') is False
    assert inv.verify_file('/path/to/file') is False

# Generated at 2022-06-21 05:24:03.092902
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Create a dict with YAML objects
    obj = {
        'yamlobj': AnsibleUnicode('test'),
        'sub1': {
            'subsub1': AnsibleUnicode('test2')
        },
        'sub2': {
            'subsub2': [
                AnsibleUnicode('test3'),
                'bye'
            ]
        }
    }

    # Convert all objects to native
    converted = convert_yaml_objects_to_native(obj)

    # Check for native types
    assert isinstance(converted, dict)
    assert isinstance(converted['sub1'], dict)
    assert isinstance(converted['sub2'], dict)
    assert isinstance(converted['sub2']['subsub2'], list)

    # Check that the contents are correct

# Generated at 2022-06-21 05:24:14.392897
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    test_obj = {
        'test1': AnsibleUnsafeText('Test1Value'),
        'test2': [
            AnsibleSequence([1, 2]),
            'hello',
            AnsibleUnicode('goodbye'),
        ],
        'test3': [
            {
                'inner1': 'inner1',
                'inner2': AnsibleUnsafeBytes('inner2'),
            },
            {
                'inner3': 'inner3',
                'inner4': [
                    AnsibleUnicode('inner4'),
                    {
                        'inner5': AnsibleSequence([1, 2]),
                    },
                ],
            },
        ],
    }
    out = convert_yaml_objects_to_native(test_obj)
    assert type(out['test1']) is text_type
    assert type

# Generated at 2022-06-21 05:24:23.608064
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    test_data = {
        AnsibleSequence([1, 2, 3]): [1, 2, 3],
        'my_string': 'my_string',
        1: 1,
        2.0: 2.0,
        {
            AnsibleUnicode('key1'): 'value1',
            'key2': AnsibleUnsafeText('value2'),
            'key3': AnsibleUnsafeBytes('value3'),
        }: {
            'key1': 'value1',
            'key2': 'value2',
            'key3': 'value3',
        }
    }
    for test_input, output in test_data.items():
        assert output == convert_yaml_objects_to_native(test_input)

# Generated at 2022-06-21 05:24:29.287799
# Unit test for function toml_dumps
def test_toml_dumps():
    obj = {
        'k1': 'v',
        'k2': ['v1', 'v2'],
        'k3': {
            'k31': 'v',
            'k32': ['v1', 'v2'],
            'k33': {
                'k331': 'v',
            }
        },
    }
    assert toml_dumps(obj) == r'''k1 = "v"
k2 = ["v1", "v2"]

[k3]
  k31 = "v"
  k32 = ["v1", "v2"]

  [k3.k33]
    k331 = "v"
'''

# Generated at 2022-06-21 05:24:36.388723
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnsafeBytes, AnsibleUnsafeText, AnsibleUnicode
    data = {
        'list': ['test'],
        'test': 'test',
        'unsafebytes': AnsibleUnsafeBytes('test'),
        'unsafetext': AnsibleUnsafeText('test'),
        'unicode': AnsibleUnicode('test'),
        'unsafetextinlist': [AnsibleUnsafeText('test')],
        'unsafebytesinmapping': {
            'test': AnsibleUnsafeBytes('test')
        },
        'unicodeinmapping': {
            'test': AnsibleUnicode('test')
        },
        'ansiblesequence': AnsibleSequence(),
    }

# Generated at 2022-06-21 05:24:39.427550
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj is not None

# Generated at 2022-06-21 05:24:43.592827
# Unit test for function toml_dumps
def test_toml_dumps():
    try:
        assert toml_dumps({"a": "b"}) == "a = \"b\"\n"
        assert toml_dumps({"a": "b", "c": "d"}) == "a = \"b\"\nc = \"d\"\n"
        assert toml_dumps({"a": "b", "c": ["d", "e"]}) == "a = \"b\"\nc = [\"d\", \"e\"]\n"
        assert toml_dumps({"a": "b", "c": {"d": "e"}}) == "a = \"b\"\nc = {d = \"e\"}\n"
    except AssertionError:
        pass
    else:
        assert True

# Generated at 2022-06-21 05:24:45.682373
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert inventory_module is not None

# Generated at 2022-06-21 05:24:50.425832
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  file_path = 'hosts.toml'
  assert InventoryModule.verify_file(file_path)


# Generated at 2022-06-21 05:24:52.857235
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    module = InventoryModule()
    assert module is not None


# Generated at 2022-06-21 05:25:17.090524
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import json
    simple_dict = dict(a='a', b=1)
    simple_list = list(range(10))
    unicode_text = 'hello'
    unicode_data = dict(a=unicode_text)
    sequence = AnsibleSequence(simple_list)
    mapping = AnsibleUnicode(unicode_text)
    complex_data = dict(my_list=sequence, my_dict=dict(my_unicode=mapping))

    assert convert_yaml_objects_to_native(simple_dict) == simple_dict
    assert convert_yaml_objects_to_native(simple_list) == simple_list
    assert convert_yaml_objects_to_native(unicode_text) is unicode_text

# Generated at 2022-06-21 05:25:18.224455
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule is not None


# Generated at 2022-06-21 05:25:23.108119
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory = BaseFileInventoryPlugin()
    loader = None
    path = "127.0.0.1"
    cache = False
    im = InventoryModule()
    im.parse(inventory, loader, path, cache)
    assert inventory is not None
    assert loader is None
    assert path is not None
    assert type(path) is str
    assert cache is False
    assert im is not None
    assert im._options is not None

# Generated at 2022-06-21 05:25:34.196459
# Unit test for function toml_dumps
def test_toml_dumps():
    assert not toml_dumps(1)
    assert toml_dumps(0) == '0'
    assert toml_dumps(3.14) == '3.14'
    assert toml_dumps(True) == 'true'
    assert toml_dumps(False) == 'false'
    assert toml_dumps('hello') == "'hello'"
    assert toml_dumps('a\nb') == "'a\\nb'"
    assert toml_dumps('a\tb') == "'a\\tb'"
    assert toml_dumps('a\fb') == "'a\\fb'"
    assert toml_dumps('a\'b') == "'a''b'"
    assert toml_dumps('a\nb') == "'a\\nb'"

# Generated at 2022-06-21 05:25:38.878463
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = '/home/yasemin/ansible/inventory/plugins/inventories/toml/test_file.toml'
    im = InventoryModule()
    assert im.verify_file(path)


# Generated at 2022-06-21 05:25:44.911183
# Unit test for function toml_dumps
def test_toml_dumps():
    import copy
    import yaml
    legacy = []

# Generated at 2022-06-21 05:25:54.674398
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:25:58.491214
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.inventory.manager import InventoryManager
    from ansible.parsing.dataloader import DataLoader
    from ansible.parsing.vault import VaultLib

    inv_module = InventoryModule()

    loader = DataLoader()
    vault_pass = VaultLib(None, None, loader).new_password()

    inv = InventoryManager(loader=loader, sources=['127.0.0.1'], vault_password=vault_pass)
    inv_module.parse(inventory=inv, loader=loader, path='examples/inventory/hosts/hosts.toml')

    assert inv['ungrouped'] is not None

# Generated at 2022-06-21 05:26:01.482820
# Unit test for function toml_dumps
def test_toml_dumps():
    '''
    Assert that the toml_dumps functon will return a valid TOML document string.
    '''
    data = yaml.load(EXAMPLES)
    fd, path = tempfile.mkstemp()
    with open(path, 'w') as f:
        f.write(toml_dumps(data))
    assert filecmp.cmp(path, path + '2')

# Generated at 2022-06-21 05:26:11.141770
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence
    data = AnsibleMapping([
        ('key1', 'foo'),
        ('key2', AnsibleSequence(['bar', 'baz'])),
        ('key3', AnsibleMapping([
            ('key1', 23),
            ('key2', AnsibleSequence([1, 2])),
        ])),
    ])
    result = toml_dumps(data)
    assert result.strip() == '''
key1 = "foo"
key2 = ["bar", "baz"]

[key3]
  key1 = 23
  key2 = [1, 2]
'''.strip()

# Generated at 2022-06-21 05:26:34.253739
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager

    inv_m = InventoryManager(loader=DataLoader(),
                             sources=None)
    v_m = VariableManager()
    inv_m.add_plugin(plugin=InventoryModule(loader=DataLoader(),
                                            inventory=inv_m,
                                            variable_manager=v_m))
    assert inv_m.inventory_plugins[0].verify_file("tests/inventory/toml/test1.toml")
    assert inv_m.inventory_plugins[0].verify_file("tests/inventory/toml/test2.toml")

# Generated at 2022-06-21 05:26:46.466403
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    class Inventory(object):
        def __init__(self):
            self.groups = {}

        def add_group(self, group):
            self.groups[group] = {}
            return self.groups[group]

        def set_variable(self, group, var, value):
            self.groups[group][var] = value

    class Loader(object):
        def __init__(self):
            pass

        def path_dwim(self, path):
            return path

    toml_inventory = InventoryModule()
    toml_inventory.inventory = Inventory()
    toml_inventory.loader = Loader()

    data = toml_inventory.parse(None, None, './tests/inventory/test_inventory_toml_parse.toml')


# Generated at 2022-06-21 05:26:56.223245
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.plugins.loader import become_loader, inventory_loader, lookup_loader, module_loader, test_loader, vars_loader, filter_loader, callback_loader
    import ansible.constants
    import ansible.context
    import ansible.module_utils.common._collections_compat
    import ansible.playbook.play

    test_play = ansible.playbook.play.Play()
    test_play._ds = {"hosts": "localhost"}
    test_play._options = ansible.constants.Defaults()
    test_play._options.connection = 'local'
    test_play._options.become = False
    test_play._options.become_method = 'sudo'
    test_play._options.become_user = 'root'
    test_play._options.check = False

# Generated at 2022-06-21 05:27:05.523521
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
  data = '''
[all]
host1
host2'''
  from ansible.parsing.dataloader import DataLoader
  from ansible.vars.manager import VariableManager
  from ansible.inventory.manager import InventoryManager
  loader = DataLoader()
  inventory = InventoryManager(loader=loader, sources='localhost,')
  var_manager = VariableManager()

  plugin = InventoryModule()
  plugin.parse(inventory, loader, data, cache=True)
  assert list(inventory.get_groups_dict().keys()) == ['all']
  assert list(inventory.get_groups_dict()['all'].get_hosts()) == ['host1','host2']

# Generated at 2022-06-21 05:27:12.247155
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    fails = ['.yml', '.yaml', '.json', '.ini']
    success = ['.toml']

    plugin = InventoryModule()
    for i in fails:
        assert plugin.verify_file(None, to_text(os.path.basename(__file__)) + i) is False
    for i in success:
        assert plugin.verify_file(None, to_text(os.path.basename(__file__)) + i) is True

# Generated at 2022-06-21 05:27:26.569555
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    tomlinv = InventoryModule()
    tomlinv.loader = None
    tomlinv.loader = None
    tomlinv.inventory = None
    data = r'''
    [ungrouped.hosts]
    host1 = {}
    host2 = { ansible_host = "127.0.0.1", ansible_port = 44 }
    host3 = { ansible_host = "127.0.0.1", ansible_port = 45 }

    [g1.hosts]
    host4 = {}

    [g2.hosts]
    host4 = {}
    '''
    path = "test.toml"
    tomlinv.set_options()

    tomlinv.parse(None, None, path, False)
    print("test")

# Generated at 2022-06-21 05:27:37.067132
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    options = {'plugin': ['toml']}
    inventory = '''# fmt: toml
    [g1]
    [g2]
    [g3.vars]
    '''
    inventory_obj = InventoryModule(loader=None,
                                    groups={},
                                    filename=None,
                                    connection=None,
                                    play=None,
                                    private_key_file=None,
                                    runner_callbacks=None,
                                    options=options,
                                    passwords=None,
                                    source=inventory)

    toml_path = '/tmp/hosts.toml'
    with open(toml_path, 'w') as f:
        f.write(inventory)

    assert inventory_obj.verify_file(toml_path) == True


# Generated at 2022-06-21 05:27:48.138024
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from io import StringIO

    loader = DataLoader()
    inv_src = EXAMPLES
    inv_file = StringIO(inv_src)
    inventory_manager = InventoryManager(loader=loader)
    variable_manager = VariableManager(loader=loader, inventory=inventory_manager)

    plugin = InventoryModule()

    plugin.parse(inventory_manager, loader, inv_file)


# Generated at 2022-06-21 05:27:54.291193
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # InventoryModule.verify_file is not actually called by the plugin loader
    # so we run the test here
    verify_file = InventoryModule().verify_file
    path = '/path/to/inventory.toml'
    assert verify_file(path)



# Generated at 2022-06-21 05:27:55.171829
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule

# Generated at 2022-06-21 05:28:18.354102
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    assert convert_yaml_objects_to_native({'foo': 'bar'}) == {'foo': 'bar'}
    assert convert_yaml_objects_to_native(AnsibleMapping({'foo': 'bar'})) == {'foo': 'bar'}
    assert convert_yaml_objects_to_native(['foo', 'bar']) == ['foo', 'bar']
    assert convert_yaml_objects_to_native(AnsibleSequence(['foo', 'bar'])) == ['foo', 'bar']
    assert convert_yaml_objects_to_native('foo/bar') in ('foo/bar', u'foo/bar')
    assert convert_yaml_objects_to

# Generated at 2022-06-21 05:28:23.374760
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_plugin = InventoryModule()
    inventory_plugin.verify_file(path='/some/path/to/hosts.toml')


# Generated at 2022-06-21 05:28:31.039680
# Unit test for function toml_dumps
def test_toml_dumps():
    # Test old versions of `toml` where ``toml.TomlEncoder`` is missing
    original_toml_encoder = toml.TomlEncoder
    toml.TomlEncoder = None
    assert b"foo = 'bar'" == toml_dumps({'foo': 'bar'})
    toml.TomlEncoder = original_toml_encoder
    # Test new versions of ``toml`` where ``toml.TomlEncoder`` is present
    assert b"foo = 'bar'" == toml_dumps({'foo': 'bar'})

# Generated at 2022-06-21 05:28:36.394932
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.dataloader import DataLoader
    # This path is relative to my module location
    path = "/home/felipe/Documents/Projects/github/ansible-toml-inventory/tests/inventory.toml"
    loader = DataLoader()
    inv = {
        "all": {
            "hosts": ["127.0.0.1"],
            "vars": {
                "ansible_connection": "local"
            }
        },
        "ungrouped": {
            "hosts": ["127.0.0.1"]
        }
    }
    InventoryModule().parse(inv, loader, path)
    print(inv)


# Generated at 2022-06-21 05:28:39.806405
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv is not None

if HAS_TOML:
    assert toml_dumps(EXAMPLES) == to_text(EXAMPLES)


# Generated at 2022-06-21 05:28:42.384388
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    import doctest
    doctest.testmod(verbose=True)

# Generated at 2022-06-21 05:28:49.864905
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert hasattr(InventoryModule, 'NAME'), 'InventoryModule class is missing NAME attribute'
    assert hasattr(InventoryModule, 'verify_file'), 'InventoryModule class is missing verify_file method'
    assert hasattr(InventoryModule, 'parse'), 'InventoryModule class is missing parse method'



# Generated at 2022-06-21 05:28:51.913285
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule(loader=None, inventory=None, path=None).NAME == 'toml'

# Generated at 2022-06-21 05:29:01.667706
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleUnicode, AnsibleMapping, AnsibleSequence
    assert convert_yaml_objects_to_native(AnsibleUnicode('foo')) == 'foo'
    assert convert_yaml_objects_to_native(AnsibleMapping({u'foo': u'bar'})) == {'foo': 'bar'}
    assert convert_yaml_objects_to_native(AnsibleSequence([u'foo', u'bar'])) == ['foo', 'bar']

# Generated at 2022-06-21 05:29:06.199192
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_cases = [
        ('/etc/ansible/hosts', False),
        ('/etc/ansible/hosts.ini', False),
        ('/etc/ansible/hosts.yml', False),
        ('/etc/ansible/hosts.yaml', False),
        ('/etc/ansible/hosts.toml', True),
        ('/etc/ansible/hosts.example', False),
    ]

    for f, expected in test_cases:
        im = InventoryModule()
        result = im.verify_file(f)
        assert result == expected, "%s failed" % f

# Generated at 2022-06-21 05:29:27.679304
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:29:38.425625
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    from ansible.plugins.loader import inventory_loader

    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['localhost'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)

    inventory_loader.add_directory(os.path.join(os.path.dirname(__file__), '..', 'inventory'))
    module = inventory_loader._get_plugin_loader('toml').get('toml')

    module.parse(inventory, loader, os.path.join(os.path.dirname(__file__), '..', 'inventory', 'hosts.toml'), cache=False)


# Generated at 2022-06-21 05:29:42.827842
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode

    data = {
        'foo': 'bar',
        'baz': {
            'faz': 'bar',
            'faa': [1, 2, 3],
            'doo': {'goo': 'moo'}
        },
        'unicode_string': to_text(u'\u00e9'),
        'unicode_bytes': to_bytes(u'\u00e9'),
        'ansible_unicode': AnsibleUnicode(u'\u00e9'),
        'ansible_bytes': to_bytes(u'\u00e9'),
        'ansible_sequence': AnsibleSequence([1, 2, 3])
    }


# Generated at 2022-06-21 05:29:57.952790
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleDict


# Generated at 2022-06-21 05:30:00.774020
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert inventory_module.NAME == "toml"
    assert isinstance(inventory_module._parse_group, object)
    assert isinstance(inventory_module._load_file, object)


# Generated at 2022-06-21 05:30:01.958539
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    # Construct an instance of the plugin class
    plugin = InventoryModule()

# Generated at 2022-06-21 05:30:05.754162
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.inventory.manager import InventoryManager

    # Test class instantiation
    loader = DataLoader()
    inventory = InventoryManager(loader=loader, sources=['127.0.0.1'])
    plugin = InventoryModule()
    plugin.parse(inventory, loader, 'test_InventoryModule_parse')

# Generated at 2022-06-21 05:30:08.541040
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    global path
    path = './test.toml'
    obj = InventoryModule()
    assert(obj.verify_file(path))


# Generated at 2022-06-21 05:30:14.750175
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert not InventoryModule.verify_file('sample.ini')
    assert InventoryModule.verify_file('sample.toml')
    assert not InventoryModule.verify_file('sample.yaml')
    assert not InventoryModule.verify_file('sample.yml')
    assert not InventoryModule.verify_file('sample.json')

# Generated at 2022-06-21 05:30:25.153273
# Unit test for function toml_dumps
def test_toml_dumps():
    """Unit test for toml_dumps function

    :return: None
    """

    # pylint: disable=protected-access
    d = {'key': AnsibleUnsafeText('value')}
    assert toml_dumps(d) == 'key = "value"\n'

    d = {'key': AnsibleUnsafeBytes('value')}
    assert toml_dumps(d) == 'key = "value"\n'

    d = {'key': AnsibleUnicode('value')}
    assert toml_dumps(d) == 'key = "value"\n'

    d = {'k': AnsibleSequence([AnsibleUnsafeText('v')])}
    assert toml_dumps(d) == 'k = ["v"]\n'


# Generated at 2022-06-21 05:30:41.148604
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    from ansible.parsing.dataloader import DataLoader
    from ansible.plugins.loader import InventoryLoader
    from ansible.inventory.manager import InventoryManager
    from ansible.vars.manager import VariableManager
    loader = DataLoader()
    inventory = InventoryManager(loader, sources=['localhost,'])
    variable_manager = VariableManager(loader=loader, inventory=inventory)
    inventory_loader = InventoryLoader(loader=loader, inventory_manager=inventory, variable_manager=variable_manager)
    InventoryModule.parse(inventory_loader, loader=loader, path='.', cache=False)
    variable_manager.set_inventory(inventory)
    print(inventory.get_host('localhost').get_vars())

if __name__ == "__main__":
    test_InventoryModule_parse()

# Generated at 2022-06-21 05:30:50.745223
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    # python3 requires str, python2 requires basestring
    try:
        basestring
    except NameError:
        basestring = str
    assert isinstance(inv_mod.verify_file("test_file.yml"), bool)
    assert isinstance(inv_mod.verify_file("test_file.yaml"), bool)
    assert isinstance(inv_mod.verify_file("test_file.json"), bool)
    assert isinstance(inv_mod.verify_file("test_file.toml"), bool)

    assert isinstance(inv_mod.verify_file(""), bool)
    assert isinstance(inv_mod.verify_file("/"), bool)
    assert isinstance(inv_mod.verify_file("/dev/null"), bool)


# Generated at 2022-06-21 05:30:56.918775
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {'k1': 'v1', 'k2': ['v2', 'v3'], 'k3': {'k4': 'v4'}}
    assert toml_dumps(data) == u'k1 = "v1"\nk2 = [\n  "v2",\n  "v3",\n]\n\n[k3]\nk4 = "v4"\n'

# Generated at 2022-06-21 05:31:04.591835
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    path = os.path.join('tests', 'inventory_test.toml')
    path_modified = os.path.join('tests', 'inventory_test_modified.toml')
    obj = InventoryModule()
    assert obj.verify_file(path)
    assert not obj.verify_file(path_modified)

# Generated at 2022-06-21 05:31:07.869203
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inventory_module = InventoryModule()
    assert inventory_module.NAME == 'toml'



# Generated at 2022-06-21 05:31:19.430531
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode
    from ansible.utils.unsafe_proxy import wrap_var


# Generated at 2022-06-21 05:31:25.701752
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    data = {
        'string': 'foo',
        'integer': 1,
        'float': 1.1,
        'boolean': False,
        'list': [
            'foo',
            1,
            1.1,
            False,
        ],
        'dict': {
            'foo': 'foo',
            'bar': 1,
            'baz': 1.1,
            'qux': False,
        },
        'none': None,
    }

    expected = '''
[string]

[integer]

[float]

[boolean]

[list]

[dict]

[none]
'''

    result = toml_dumps(data)

# Generated at 2022-06-21 05:31:28.775159
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    invmod = InventoryModule()
    invmod.parse(None, None, None)


# Generated at 2022-06-21 05:31:40.904839
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleDict, AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    source = {
        'a': AnsibleUnicode("A"),
        'b': AnsibleUnsafeText("B"),
        'c': AnsibleUnsafeBytes("C"),
        'd': AnsibleSequence(["D1", "D2", "D3"]),
        'e': AnsibleDict({
            'e1': string_types("E1"),
            'e2': string_types("E2")
        })
    }


# Generated at 2022-06-21 05:31:51.428593
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    ansible_sequence = AnsibleSequence()
    ansible_sequence.append('item1')
    ansible_sequence.append('item2')
    ansible_unicode = AnsibleUnicode('unicode')
    ansible_unsafe = AnsibleUnsafeText('unsafe')
    ansible_dict = { 'key1': ansible_sequence, 'key2': ansible_unicode, 'key3': ansible_unsafe }
    native_dict = convert_yaml_objects_to_native(ansible_dict)
    assert isinstance(native_dict['key1'], list)
    assert isinstance(native_dict['key2'], text_type)
    assert isinstance(native_dict['key3'], text_type)