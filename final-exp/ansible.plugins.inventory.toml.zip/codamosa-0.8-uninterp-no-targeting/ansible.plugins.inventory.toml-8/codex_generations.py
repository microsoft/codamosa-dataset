

# Generated at 2022-06-21 05:22:25.868846
# Unit test for function toml_dumps
def test_toml_dumps():
    ansi_seq = AnsibleSequence(['abc', 'def', '1', '2'])
    ansi_text = AnsibleUnicode('abc')
    ansi_unsafe_bytes = AnsibleUnsafeBytes('abc')
    ansi_unsafe_text = AnsibleUnsafeText('abc')


# Generated at 2022-06-21 05:22:37.977529
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.loader import AnsibleLoader
    import yaml


# Generated at 2022-06-21 05:22:49.567036
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    data = {
        's': 'T',
        'l': ['T'],
        'u': AnsibleUnicode('T'),
        'sl': [AnsibleSequence(['T']), AnsibleSequence(['T'])],
        'su': [AnsibleUnicode('T'), AnsibleUnicode('T')],
        'us': [AnsibleUnicode('T'), 'T'],
    }

# Generated at 2022-06-21 05:22:54.940048
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedUnsafeText
    data = {
        'k1': 'v1',
        'k2': AnsibleVaultEncryptedUnicode(b'v2'),
        'k3': [
            'v3',
            AnsibleVaultEncryptedUnsafeText(b'v4'),
        ],
        'k4': {
            'kk1': 'v5',
            'kk2': AnsibleVaultEncryptedUnicode(b'v6'),
        },
        'k5': {
        },
    }
    data_copy = convert_yaml_objects_to_native(data)

# Generated at 2022-06-21 05:23:08.286237
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode, AnsibleVaultEncryptedBytes
    from ansible.parsing.yaml.data import AnsibleVaultEncryptedUnicode as av

    def _vs(s):
        return text_type(AnsibleVaultEncryptedUnicode(s))

    def _vb(b):
        return AnsibleVaultEncryptedBytes(b)


# Generated at 2022-06-21 05:23:10.934951
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    """
    Unit test for constructor of class InventoryModule
    """
    assert InventoryModule is not None

# Generated at 2022-06-21 05:23:16.951864
# Unit test for function toml_dumps
def test_toml_dumps():
    import unittest
    toml_string = toml_dumps({
        'key1': 'value1',
        'key2': {
            'a': True
        }
    })

    assert toml_string == b'key1 = "value1"\n\n[key2]\n  a = true\n'


# Generated at 2022-06-21 05:23:29.795757
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # prepare data
    host_data = """
    # This is a comment
    [group1]
    host1 ansible_host=1.1.1.1
      host2 ansible_host=2.2.2.2
      host3
      host4
    [group1:vars]
    a = 1
 
    [group2]
    host5 ansible_host=1.1.1.1
    """
    data = host_data.split('\n')

    # instantiate InventoryModule object
    inventory_module = InventoryModule()

    # execute the method parse of InventoryModule
    inventory_module.parse(data, None, None)

    # get the result
    result = inventory_module.inventory
    groups = result.groups
    host_vars = result.get_host("host1").get_

# Generated at 2022-06-21 05:23:40.459143
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import unittest

    # Test object definitions
    data_dict = { 'a': 1, 'b': AnsibleUnicode('c'), 'd': AnsibleUnsafeText('e') }
    data_list = [ 1, AnsibleUnsafeBytes('b'), [AnsibleUnsafeBytes('c'), 2], [AnsibleUnsafeText('d'), 3] ]
    data_string = AnsibleUnsafeText('b')

    # Test cast to native types
    assert isinstance(convert_yaml_objects_to_native(data_dict), dict)
    assert not isinstance(convert_yaml_objects_to_native(data_dict), type(data_dict))
    assert isinstance(convert_yaml_objects_to_native(data_list), list)

# Generated at 2022-06-21 05:23:47.810517
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # init inventory module
    test_path = 'D:\\Projects\\ansible_multi_inventory\\tests\\testfiles\\inventory_file.toml'
    inventory_mod = InventoryModule()
    inventory_mod.parse(None, None, test_path)
    print(inventory_mod)

if __name__ == '__main__':
    test_InventoryModule_parse()

# Generated at 2022-06-21 05:24:12.881773
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # create a fake file to parse:
    import tempfile
    fh, fakefile = tempfile.mkstemp()
    data = '''
        [all.vars]
        has_java = false

        [web]
        children = [
            "apache",
            "nginx"
        ]
        vars = { http_port = 8080 }

        [web.hosts]
        host1 = {}
        host2 = { ansible_port = 222 }

        [apache.hosts]
        tomcat1 = {}
        tomcat2 = { myvar = 34 }

        [nginx.hosts]
        jenkins1 = {}

        [nginx.vars]
        has_java = true
        '''

# Generated at 2022-06-21 05:24:21.558843
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({'a': True}) == 'a = true\n'
    assert toml_dumps({'a': False}) == 'a = false\n'
    assert toml_dumps({'a': 1}) == 'a = 1\n'
    assert toml_dumps({'a': 1.1}) == 'a = 1.1\n'
    assert toml_dumps({'a': "1.1"}) == 'a = "1.1"\n'
    assert toml_dumps({'a': 123456789123456789}) == 'a = 123456789123456789\n'

# Generated at 2022-06-21 05:24:30.656419
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    obj = dict(
        string_type=AnsibleUnsafeText(u'text'),
        bytes_type=AnsibleUnsafeBytes('bytes'),
        list_type=AnsibleSequence([AnsibleUnsafeText(u'text')])
    )
    assert convert_yaml_objects_to_native(obj) == dict(
        string_type=u'text',
        bytes_type='bytes',
        list_type=[u'text']
    )

# Generated at 2022-06-21 05:24:43.609858
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    ''' unit tests for methods of class InventoryModule '''
    import io

    # Test reading host file of valid format
    module = InventoryModule()

    # Test good TOML file parsing
    module.parse(None, None, 'test/formats/toml/good.toml')

    # Test bad TOML file parsing
    try:
        module.parse(None, None, 'test/formats/toml/bad.toml')
    except AnsibleParserError as e:
        assert(str(e) == 'TOML file (test/formats/toml/bad.toml) is invalid: Invalid toml file')
    else:
        assert(False)

    # Test missing TOML file parsing

# Generated at 2022-06-21 05:24:50.351514
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test for invalid file path
    assert InventoryModule('plugin').verify_file('/etc/passwd') is False
    # Test for invalid file extension
    assert InventoryModule('plugin').verify_file('/etc/hosts') is False
    # Test for valid file extension
    assert InventoryModule('plugin').verify_file('hosts.toml') is True

# Generated at 2022-06-21 05:24:58.511014
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    import mock

    class DummyInventoryModule(InventoryModule):
        pass

    d = DummyInventoryModule()
    d.path = 'something.txt'
    d.inventory = mock.MagicMock()
    d.loader = mock.MagicMock()
    
    assert d.verify_file('./something.txt') == True
    assert d.verify_file('./something.toml') == True
    assert d.verify_file('./') == False
    assert d.verify_file('../') == False
    assert d.verify_file('../something.toml') == False

# Generated at 2022-06-21 05:25:04.585003
# Unit test for function toml_dumps
def test_toml_dumps():
    output = toml_dumps(['foo', 'bar', 42])
    assert output == u'["foo", "bar", 42]'

    output = toml_dumps({'key': 'value', 'key2': 'value2'})
    assert output == u'key = "value"\nkey2 = "value2"'

# Generated at 2022-06-21 05:25:14.684331
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence

    data = {
        'some_key': 'some_value',
        'some_list': [
            'some_value',
            {
                'some_other_key': 'some_other_value',
                'some_list': [
                    'some_other_value',
                    {
                        'some_other_key': 'some_other_value',
                    },
                ],
            },
        ],
    }
    ansible_obj = convert_yaml_objects_to_native(data)

    assert isinstance(ansible_obj['some_key'], str)
    assert isinstance(ansible_obj['some_list'], list)
    assert isinstance(ansible_obj['some_list'], AnsibleSequence)

   

# Generated at 2022-06-21 05:25:23.322312
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert convert_yaml_objects_to_native({"a": "b"}) == {"a": "b"}
    assert convert_yaml_objects_to_native({"a": 1}) == {"a": 1}
    assert convert_yaml_objects_to_native((AnsibleUnicode("a"))) == "a"
    assert convert_yaml_objects_to_native((AnsibleUnsafeText("a"))) == "a"
    assert convert_yaml_objects_to_native((AnsibleUnsafeBytes("a"))) == "a"
    assert convert_yaml_objects_to_native(["a", "b"]) == ["a", "b"]

# Generated at 2022-06-21 05:25:34.299090
# Unit test for function toml_dumps

# Generated at 2022-06-21 05:25:50.300727
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    assert {'foo': 123} == convert_yaml_objects_to_native({
        AnsibleUnsafeText('foo'): AnsibleUnsafeText('123')
    })
    assert ['foo', 123] == convert_yaml_objects_to_native([
        AnsibleUnsafeText('foo'), AnsibleUnsafeText('123')
    ])
    assert 123 == convert_yaml_objects_to_native(AnsibleUnsafeText('123'))

# Generated at 2022-06-21 05:26:02.184745
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:26:08.491895
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file('../tests/units/plugins/inventory/sources/test.toml') is True
    assert InventoryModule.verify_file('../tests/units/plugins/inventory/sources/group_vars/host.toml') is False
    assert InventoryModule.verify_file('') is False

# Generated at 2022-06-21 05:26:16.866170
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    mock_loader = {}
    mock_display = {}
    inv_mod = InventoryModule()
    assert inv_mod.loader == "loader"
    assert inv_mod.display == "display"

    inv_mod = InventoryModule(mock_loader, mock_display)
    assert inv_mod.loader == mock_loader
    assert inv_mod.display == mock_display



# Generated at 2022-06-21 05:26:25.323621
# Unit test for function toml_dumps
def test_toml_dumps():
    assert toml_dumps({}) == '{}\n'
    assert toml_dumps(1) == '1\n'
    assert toml_dumps('foo') == '"foo"\n'
    assert toml_dumps(1.2) == '1.2\n'
    assert toml_dumps([1, 2]) == '[1, 2]\n'
    assert toml_dumps({'foo': 'bar'}) == 'foo = "bar"\n'
    assert toml_dumps({'foo': {'bar': 'baz'}}) == '[[foo]]\nbar = "baz"\n'

# Generated at 2022-06-21 05:26:32.567324
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    '''Constructor of class InventoryModule.'''

    mock_loader = 'Fake loader.'
    mock_groups = 'Fake groups.'
    mock_path = 'Fake path.'
    inventory_module = InventoryModule(loader=mock_loader, groups=mock_groups, path=mock_path)

    assert inventory_module.loader == mock_loader
    assert inventory_module.groups == mock_groups
    assert inventory_module.path == mock_path



# Generated at 2022-06-21 05:26:45.389940
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    import json

    # Test case 1, string
    data = AnsibleUnicode('test')
    assert json.dumps(convert_yaml_objects_to_native(data)) == '"test"'

    # Test case 2, list
    data = AnsibleSequence([AnsibleUnicode('test')], [AnsibleUnicode('test')])
    assert json.dumps(convert_yaml_objects_to_native(data)) == '["test", "test"]'

    # Test case 3, dict

# Generated at 2022-06-21 05:26:55.730457
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import mock
    import os
    # Test function
    plugin = InventoryModule()
    with mock.patch.object(AnsibleParserError, '__init__', side_effect=Exception()):
        with mock.patch('os.path.exists', side_effect=[True]):
            with mock.patch('os.path.isdir', side_effect=[False]):
                plugin.parse({}, None, None)
    # Test function
    inventory = {}
    loader = object
    path = "/test/path"
    with mock.patch('os.path.exists', side_effect=[False]):
        with mock.patch('ansible.plugins.inventory.toml.AnsibleParserError', side_effect=Exception()):
            plugin.parse(inventory, loader, path)
    # Test function

# Generated at 2022-06-21 05:27:06.267836
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    # Test valid file extensions
    paths_to_test = ['/path/to/files/valid.toml', 'valid.toml',
                     '/path/to/files/valid.TOML', 'valid.TOML',
                     '/path/to/files/valid.toml.new', 'valid.toml.new',
                     '/path/to/files/valid.TOML.new', 'valid.TOML.new',
                     '/path/to/files/valid.toml-backup', 'valid.toml-backup',
                     '/path/to/files/valid.TOML-backup', 'valid.TOML-backup']
    for path_to_test in paths_to_test:
        assert InventoryModule.verify_file(path_to_test) == True
    # Test invalid file

# Generated at 2022-06-21 05:27:15.184907
# Unit test for function toml_dumps
def test_toml_dumps():
    # Test 1: Test dump_funcs functionality on newer toml library
    if HAS_TOML and hasattr(toml, 'TomlEncoder'):
        assert toml_dumps(['a', 'b', 'c']) == "[\"a\", \"b\", \"c\"]\n"
        # Test 2: Test classes from ansible.parsing.yaml.objects.
        assert toml_dumps([AnsibleUnsafeBytes(b'a'), AnsibleUnsafeText('b'), 'c']) == "[\"a\", \"b\", \"c\"]\n"

# Generated at 2022-06-21 05:27:36.837218
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    # Test for string
    assert b'foobar' == toml_dumps('foobar')

    # Test for AnsibleUnicode
    assert b'foobar' == toml_dumps(AnsibleUnicode('foobar'))

    # Test for AnsibleUnsafeBytes
    assert b'foobar' == toml_dumps(AnsibleUnsafeBytes('foobar'))

    # Test for AnsibleUnsafeText
    assert b'foobar' == toml_dumps(AnsibleUnsafeText('foobar'))

    # Test for dict

# Generated at 2022-06-21 05:27:48.054810
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import json
    """Unit test for method parse of class InventoryModule"""
    groups = {}
    groups['all'] = {}
    groups['all']['vars'] = {}
    groups['all']['vars']['has_java'] = False

    groups['web'] = {}
    groups['web']['hosts'] = {}
    groups['web']['vars'] = {}
    groups['web']['vars']['http_port'] = 8080
    groups['web']['vars']['myvar'] = 23

    groups['web']['children'] = []
    groups['web']['children'].append("apache")
    groups['web']['children'].append("nginx")

    groups['web']['hosts']['host1'] = {}

# Generated at 2022-06-21 05:27:52.376290
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file('some_file.toml')
    assert not module.verify_file('some_file.txt')

# Generated at 2022-06-21 05:28:01.350446
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.parsing.yaml.loader import AnsibleLoader

    test_data = '''
---
# Example
all:
    vars:
        has_java: false
    hosts:
        apache: {}
        nginx:
            ansible_port: 56678
'''
    data = AnsibleLoader(test_data).get_single_data()
    assert isinstance(data, AnsibleMapping)
    converted_data = convert_yaml_objects_to_native(data)
    assert isinstance(converted_data, MutableMapping)
    assert converted_data['all']['vars']['has_java'] is False

# Generated at 2022-06-21 05:28:05.318666
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    print("Start testing")
    plugin = InventoryModule()
    print("End testing")

if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:28:18.991769
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    dir_path = os.path.dirname(os.path.realpath(__file__))
    inventory_instance = InventoryModule()
    assert inventory_instance.verify_file(dir_path + '/toml_inventory_examples/toml_inventory.toml')
    assert not inventory_instance.verify_file(dir_path + '/toml_inv_pt1.json')
    assert not inventory_instance.verify_file(dir_path + '/toml_inv_pt1.yml')
    assert not inventory_instance.verify_file(dir_path + '/toml_inventory_examples/toml_inventory_plugin_config.toml')

# Generated at 2022-06-21 05:28:25.624126
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert hasattr(InventoryModule, 'NAME')
    assert hasattr(InventoryModule, '_parse_group')
    assert hasattr(InventoryModule, 'parse')
    assert hasattr(InventoryModule, 'verify_file')


# Generated at 2022-06-21 05:28:29.336370
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    """Unit tests for InventoryModule.verify_file()"""
    assert InventoryModule(None).verify_file(__file__)
    assert not InventoryModule(None).verify_file('/tmp/this/is/a/non/existing/file.toml')

# Generated at 2022-06-21 05:28:41.527109
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode
    from ansible.parsing.yaml.reader import Reader
    from ansible.parsing.yaml.scanner import Scanner
    from ansible.parsing.yaml.scanner import RoundTripScanner

    base = InventoryModule()
    assert isinstance(base, BaseFileInventoryPlugin)
    assert base.NAME == 'toml'
    assert base.verify_file is not None
    assert base.parse is not None
    assert isinstance(base.loader, Reader)
    assert isinstance(base.loader.stream, AnsibleSequence)
    assert isinstance(base.loader.stream[0], AnsibleUnicode)

# Generated at 2022-06-21 05:28:52.872971
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    """ Verifies that convert_yaml_objects_to_native returns native types """
    ansible_types = (
        AnsibleUnicode('test'),
        AnsibleUnsafeBytes('test'),
        AnsibleUnsafeText('test'),
        AnsibleSequence(['test']),
    )
    for obj in ansible_types:
        converted = convert_yaml_objects_to_native(obj)
        if type(obj) != type(converted):
            raise Exception("Object of type '{}' did not convert to type '{}'".format(type(obj), type(converted)))

# Generated at 2022-06-21 05:29:22.730555
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    print("Checking if the file argument is checked.")
    if module.verify_file("filename"):
        print("File extension is checked")
    else:
        print("File extension is not checked")

#Unit test for function _parse_group of class InventoryModule

# Generated at 2022-06-21 05:29:28.247965
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file('/etc/hosts') == True
    assert module.verify_file('/etc/hosts.toml') == True
    assert module.verify_file('/etc/hosts.yaml') == False

# Generated at 2022-06-21 05:29:40.234474
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    test_data = {
        "k1": "v1",
        "k2": 1234,
        "k3": [1, 2, 3],
        "k4": {
            "k5": "v5",
            "k6": {
                "k7": "v7"
            }
        },
        "k8": AnsibleSequence(
            [
                AnsibleUnicode("v8.1"),
                AnsibleUnsafeText("v8.2"),
                AnsibleUnsafeBytes("v8.3")
            ]
        )
    }


# Generated at 2022-06-21 05:29:52.865136
# Unit test for function toml_dumps
def test_toml_dumps():
    test_data = {
        u'test1': {
            u'sub1': {
                u'var1': u'value1'
            }
        },
        u'test2': [u'value2', u'value3']
    }
    test_sep = u'\n'
    test_result = (u'[test1.sub1]\n'
                   u'var1="value1"\n\n'
                   u'[test2]\n'
                   u"value2='value2'\n"
                   u"value3='value3'\n")
    assert toml_dumps(test_data) == test_result

# Generated at 2022-06-21 05:29:59.804499
# Unit test for function toml_dumps
def test_toml_dumps():
    mylist = [1, 2, 3]
    mydict = dict(k='v')
    mystring = "my string"
    myunicode = "my unicode string"

    output = toml_dumps(mylist)
    assert output == '[1, 2, 3]\n'

    output = toml_dumps(mydict)
    assert output == 'k = "v"\n'

    output = toml_dumps(mystring)
    assert output == '"my string"\n'

    output = toml_dumps(myunicode)
    assert output == '"my unicode string"\n'

    # Ensure toml_dumps() can handle an ansible.parsing.yaml.objects.AnsibleUnicode object

# Generated at 2022-06-21 05:30:07.445765
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv_mod = InventoryModule()
    path = 'inventory.toml'
    assert(inv_mod.verify_file(path))
    path = 'inventory.txt'
    assert(not inv_mod.verify_file(path))
    path = 'inventory.yml'
    assert(not inv_mod.verify_file(path))
    path = 'inventory.yaml'
    assert(not inv_mod.verify_file(path))
    path = 'inventory.json'
    assert(not inv_mod.verify_file(path))
    path = 'inventory.ini'
    assert(not inv_mod.verify_file(path))
    path = 'inventory'
    assert(not inv_mod.verify_file(path))
    path = '.inventory'

# Generated at 2022-06-21 05:30:19.162418
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """
    For the following tests, we are going to
    - create a loader (temporarily, not a singleton, so we can change the loaded data between calls)
    - load a TOML file in it
    - create a new Inventory with it
    - create an instance of InventoryModule
    - call the parse method of InventoryModule with the inventory and the loader
    """
    import os
    import sys
    import tempfile

    # Change the current directory to a temporary location where we can create a temporary loader
    cwd = os.getcwd()
    tmp_dir = tempfile.mkdtemp()
    os.chdir(tmp_dir)


# Generated at 2022-06-21 05:30:20.124040
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule.__dict__['parse'].__func__ is InventoryModule.parse

# Generated at 2022-06-21 05:30:33.712589
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.module_utils.six import PY3
    # PY3 is True if is on Python 3
    assert PY3 == (convert_yaml_objects_to_native(3) is not 3)

    assert convert_yaml_objects_to_native(u'U') == u'U'
    assert convert_yaml_objects_to_native(u'U') == 'U'

    obj = {u'U': u'U'}
    assert convert_yaml_objects_to_native(obj) == {u'U': u'U'}
    assert convert_yaml_objects_to_native(obj) == {'U': 'U'}

    obj_ansible_unicode = AnsibleUnicode(u'U')

# Generated at 2022-06-21 05:30:47.951870
# Unit test for function toml_dumps
def test_toml_dumps():
    if not HAS_TOML:
        return True

    docs = [doc for doc in EXAMPLES.strip().split('\n#')]
    for doc in docs:
        parts = doc.strip().split('\n')
        format = parts[0].split('# ')[1]
        if format == 'fmt: toml':
            continue
        content = '\n'.join(parts[1:])

        if content == '':
            continue

        display.display(u"Test doc %d: %s..." % (docs.index(doc), format))

# Generated at 2022-06-21 05:31:40.918643
# Unit test for function toml_dumps
def test_toml_dumps():
    assert """some_string = "foo"
some_int = 1
some_float = 3.1415
some_bool = true
some_list = [1, 2, 3]
some_map = { other_key = "bar" }
""" == toml_dumps({
        'some_string': 'foo',
        'some_int': 1,
        'some_float': 3.1415,
        'some_bool': True,
        'some_list': [1, 2, 3],
        'some_map': {
            'other_key': 'bar',
        },
    })


# Generated at 2022-06-21 05:31:53.648057
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText


# Generated at 2022-06-21 05:32:00.405957
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Method parse of class InventoryModule
    print('Testing method parse of class InventoryModule')

    # Specify location of TOML file
    path = os.path.join(os.path.dirname(__file__), 'tomltest.toml')

    # Call method parse of class InventoryModule
    InventoryModule.parse(None, None, path)

if __name__ == '__main__':
    test_InventoryModule_parse()