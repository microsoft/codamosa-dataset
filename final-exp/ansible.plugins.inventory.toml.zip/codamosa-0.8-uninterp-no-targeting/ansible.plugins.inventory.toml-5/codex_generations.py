

# Generated at 2022-06-21 05:22:28.650983
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    display = Display()
    fake_loader = None
    fake_inventory = None
    fake_path = None
    fake_cache = False
    fake_parse = {}
    fake_parse['all'] = {}
    fake_parse['all']['children'] = ['web']
    fake_parse['web'] = {}
    fake_parse['web']['children'] = ['apache', 'nginx']
    fake_parse['web']['vars'] = {'myvar': 23}
    fake_parse['web']['hosts'] = {}
    fake_parse['web']['hosts']['host1'] = {}
    fake_parse['web']['hosts']['host2'] = {'ansible_port': 222}
    fake_parse['apache'] = {}

# Generated at 2022-06-21 05:22:35.006366
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    inventory_module = InventoryModule()

    # test a non-toml file
    assert inventory_module.verify_file('/path/to/non-toml-file.yml') == False

    # test a toml file
    assert inventory_module.verify_file('/path/to/toml-file.toml') == True


# Generated at 2022-06-21 05:22:42.921427
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    plugin = InventoryModule()
    test_data = [
        ['', False],
        ['test.not_toml', False],
        ['test.toml', True],
        ['test.inventory', False]
    ]

    for path, expected in test_data:
        assert plugin.verify_file(path) == expected



# Generated at 2022-06-21 05:22:50.750911
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory = InventoryModule()
    path = "test.toml"
    (file_name, ext) = os.path.splitext(path)
    assert ext == '.toml'
    assert inventory.verify_file(path) == True


# Generated at 2022-06-21 05:23:01.432091
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText


# Generated at 2022-06-21 05:23:05.046050
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inventory_module = InventoryModule()
    assert inventory_module.verify_file("/etc/ansible/hosts") == False
    assert inventory_module.verify_file("/etc/ansible/hosts.toml") == True


# Generated at 2022-06-21 05:23:06.224445
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv = InventoryModule()
    assert inv

# Generated at 2022-06-21 05:23:19.084599
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence, AnsibleUnicode, AnsibleUnsafeText
    from ansible.utils.unsafe_proxy import wrap_var, _UnsafeLoader


# Generated at 2022-06-21 05:23:27.073959
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    test_file = 'test_file'
    test_extension = '.toml'
    test_extension_2 = '.yml'
    test_path = test_file + test_extension
    test_path_2 = test_file + test_extension_2
    assert InventoryModule.verify_file(None, test_path)
    assert not InventoryModule.verify_file(None, test_path_2)

# Generated at 2022-06-21 05:23:39.271613
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping, AnsibleUnicode
    from ansible.module_utils._text import to_bytes, to_native

    # example 1: test custom object types
    test_data = {
        'ansible_hosts' : AnsibleSequence([
                AnsibleUnicode('127.0.0.1'),
                to_bytes('127.0.0.1')
            ]),
        'ansible_port' : AnsibleUnicode('44'),
        'ansible_group' : AnsibleSequence([
                AnsibleUnicode('g1'),
                to_bytes('g2')
            ])
    }

# Generated at 2022-06-21 05:24:01.177014
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """ Unit test for method parse of class InventoryModule
        Requires pytest to be installed
    """
    from pytest import approx
    plugin = InventoryModule()

    ## Test whether a file with a TOML extension is correctly loaded
    plugin.parser = True
    plugin.loader = True
    path = './tests/TOML_TEST_FILE'
    data = plugin.parse(None, None, path)
    assert data['all']['vars']['has_java'] == False
    assert data['web']['vars']['http_port'] == 8080
    assert data['web']['vars']['myvar'] == 23
    assert data['web']['children'][0] == "apache"
    assert data['web']['children'][1] == "nginx"

# Generated at 2022-06-21 05:24:02.022312
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert True

# Generated at 2022-06-21 05:24:10.791123
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
  im = InventoryModule()
  # Test for existing file
  assert(im.verify_file('/etc/ansible/hosts') == True)
  assert(im.verify_file('/etc/ansible/') == False)
  assert(im.verify_file('/etc/ansible/hosts.toml') == True)
  assert(im.verify_file('/etc/ansible/hosts.ini') == False)

# Generated at 2022-06-21 05:24:16.053180
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # Test without path. Result is the same as with empty string
    test_module = InventoryModule()
    assert test_module != None
    # Test with a valid path
    test_module = InventoryModule('/tmp/test.toml')
    assert test_module != None


# Generated at 2022-06-21 05:24:23.608109
# Unit test for function toml_dumps
def test_toml_dumps():
    # Module args
    module_args = dict(
        plugin=dict(
            name='toml.py',
            path='/dev/null',
        ),
    )
    # Inventory data
    inventory_data = dict(
        all=dict(
            children=['ungrouped'],
            vars=dict(
                foo='bar',
            ),
        ),
        ungrouped=dict(
            hosts=dict(
                localhost=dict(
                    ansible_connection='local',
                ),
            ),
        ),
    )
    # Expected output
    output = toml_dumps(inventory_data)

# Generated at 2022-06-21 05:24:29.287575
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # test file=None
    module = InventoryModule()
    try:
        module.parse(None, None, None)
    except AnsibleParserError as e:
        assert "Invalid filename: 'None'" in str(e)
    except Exception as e:
        assert False
    else:
        assert False  # Should not get this far

    # test file=''
    module = InventoryModule()
    try:
        module.parse(None, None, '')
    except AnsibleParserError as e:
        assert "Invalid filename: ''" in str(e)
    except Exception as e:
        assert False
    else:
        assert False  # Should not get this far

# Generated at 2022-06-21 05:24:31.023135
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # TODO: Improve the functionality of this unit test
    assert True

# Generated at 2022-06-21 05:24:43.792204
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import sys
    import tempfile
    import os
    import stat
    import unittest

    class FileLoader:
        def __init__(self, filepath):
            self.filepath = filepath
        def file_exists(self, path):
            return os.path.exists(self._path_dwim(path))
        def path_exists(self, path):
            return os.path.exists(self._path_dwim(path))
        def _path_dwim(self, path):
            return path.replace('%s' % os.sep, '', 1)

# Generated at 2022-06-21 05:24:55.878036
# Unit test for function toml_dumps
def test_toml_dumps():
    import unittest
    class TestTomlDumps(unittest.TestCase):
        def test_dict(self):
            input = {'test': 'value'}
            output = toml_dumps(input)
            self.assertEqual(output, 'test = "value"\n')

        def test_list(self):
            input = {'test': [1, 2, 3]}
            output = toml_dumps(input)
            self.assertEqual(output, 'test = [1, 2, 3]\n')

        def test_unicode(self):
            input = {'test': u'value'}
            output = toml_dumps(input)
            self.assertEqual(output, 'test = "value"\n')


# Generated at 2022-06-21 05:25:01.115007
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

    assert convert_yaml_objects_to_native({}) == {}
    assert convert_yaml_objects_to_native([]) == []


# Generated at 2022-06-21 05:25:20.486875
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    module = InventoryModule()
    assert module.verify_file("/foo/bar/baz.toml") == True
    assert module.verify_file("/foo/bar/baz.yaml") == False
    assert module.verify_file("/foo/bar/baz.yml") == False
    assert module.verify_file("/foo/bar/baz.json") == False
    assert module.verify_file("/foo/bar/baz") == False


# Generated at 2022-06-21 05:25:24.981234
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    """Ensure the function ``convert_yaml_objects_to_native`` converts
    ``dict``, ``list`` and ``str`` types found in ``ansible.parsing.yaml.objects``
    to their native type equivalents.
    """
    import ansible.parsing.yaml as test_yaml

    # Safe text type
    val = u"unicodey string"
    ansible_text = test_yaml.AnsibleUnicode(val)
    assert val is convert_yaml_objects_to_native(ansible_text)

    # Safe bytes type
    val = b"bytes string"
    ansible_bytes = test_yaml.AnsibleUnsafeBytes(val)
    assert val is convert_yaml_objects_to_native(ansible_bytes)

    # Safe text type

# Generated at 2022-06-21 05:25:33.765518
# Unit test for function toml_dumps
def test_toml_dumps():
    data = {
        "user": {
            "name": "Tina",
            "age": 27,
            "verified": True,
            "score": 9.5
        },
        "cities": [
            {"name": "New York"},
            {"name": "Munich"},
            {"name": "Tokyo"}
        ]
    }
    assert toml_dumps(data) == r'''[user]
name = "Tina"
age = 27
verified = true
score = 9.5

[cities]
name = "New York"
name = "Munich"
name = "Tokyo"

'''

# Generated at 2022-06-21 05:25:38.199903
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv_mock = type('Inventory', (), {'add_group': lambda self, b: print(f"Add group: {b}")})
    inv_mock = inv_mock()

    inv_plugin = InventoryModule()
    inv_plugin.inventory = inv_mock

    inv_plugin.parse(None, None, "./test/units/plugins/inventory/toml/test.toml")
    inv_plugin.parse(None, None, "./test/units/plugins/inventory/toml/test_nested.toml")
    inv_plugin.parse(None, None, "./test/units/plugins/inventory/toml/test_group_vars.toml")

# Generated at 2022-06-21 05:25:40.404530
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    inv = InventoryModule()
    assert inv.verify_file("test.toml") == True
    assert inv.verify_file("test.yaml") == False


# Generated at 2022-06-21 05:25:55.842392
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    """ Unit tests for InventoryModule.parse() """

    inventory_module = InventoryModule()
    inventory = inventory_module.inventory = Mock()
    loader = inventory_module.loader = Mock()
    path = None  # unimportant

    # Test invalid filename
    loader.path_dwim = Mock(side_effect=lambda path: path)
    loader.path_exists = Mock(return_value=True)
    inventory_module._load_file = Mock(return_value={})
    inventory.add_group = Mock()
    inventory.add_child = Mock()
    inventory.set_variable = Mock()
    inventory_module._expand_hostpattern = Mock(return_value=["host", None])
    inventory_module._populate_host_vars = Mock()
    inventory_module.parse(inventory, loader, path)

   

# Generated at 2022-06-21 05:26:09.618030
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText

# Generated at 2022-06-21 05:26:22.067789
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    test_path = "test_path"
    test_path2 = "test_path2"
    test_file_name = "test_file_name"
    test_group_name = "test_group_name"
    test_group_name2 = "test_group_name2"
    test_key = "test_key"
    test_value = "test_value"

    # Arrange
    class TestInventoryModule(InventoryModule):
        def _parse_group(self, group_name, group_data):
            self._parse_group_called.append({"group_name": group_name, "group_data": group_data})
        def _load_file(self, file_name):
            self._load_file_called.append({"file_name": file_name})

# Generated at 2022-06-21 05:26:34.419805
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    import sys
    import platform

    if sys.version_info[0] == 2:
        string_class = unicode
    elif sys.version_info[0] == 3:
        string_class = str

    class Simple(object):
        pass

    class Complex(string_class):
        pass

    class Other(dict):
        pass

    simple = Simple()
    complex = Complex()
    other = Other()

    if platform.python_implementation() != 'PyPy':
        # PyPy doesn't seem to support isinstance(obj, str) when obj is a unicode instance
        # https://bitbucket.org/pypy/pypy/issues/2307/isinstanceabc-fails-for-unicode-instances
        assert isinstance(simple, string_class) is False

# Generated at 2022-06-21 05:26:46.536154
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    display = Display()
    loader = Loader()
    path = './test/test.toml'
    data = test_load_file(path)
    inventory = Inventory()
    plugins = set()
    inventory_module = InventoryModule(display, loader, path, plugins)
    # This method is to parse inventory file
    inventory_module.parse(inventory, loader, path)

    for group_name in data:
        ansible_parser_error = AnsibleParserError
        if isinstance(group_name, list):
            raise ansible_parser_error("Invalid group name '%s'" % data[group_name])

# Generated at 2022-06-21 05:27:07.655977
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj

if __name__ == '__main__':
    test_InventoryModule()

# Generated at 2022-06-21 05:27:09.781827
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    inv_module = InventoryModule()
    assert inv_module.NAME == 'toml'

# Generated at 2022-06-21 05:27:16.084665
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleUnsafeText
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    def check_native(obj):
        return convert_yaml_objects_to_native(obj) == AnsibleLoader(None, object_pairs_hook=AnsibleMapping).get_single_data(obj)

    # Dict with a key that does not need to be converted
    assert check_native({u'key': u'value'})

    # Dict with a key that does need to be converted
    assert check_native({AnsibleUnsafeText(u'key'): u'value'})

    # Dict with AnsibleMapping as the value
   

# Generated at 2022-06-21 05:27:20.665372
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    test_data = {'a': AnsibleUnsafeText('foo'), 'b': [AnsibleUnsafeText('x')]}
    converted = convert_yaml_objects_to_native(test_data)
    assert (converted['a'] == 'foo')
    assert (isinstance(converted['b'], list))
    assert (isinstance(converted['b'][0], text_type))

# Generated at 2022-06-21 05:27:32.922866
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():

    import os
    import shutil
    from tempfile import mkdtemp

    from ansible.plugins.loader import inventory_loader

    tmp = mkdtemp()
    assert os.path.isdir(tmp)

    path = os.path.join(tmp, "test.toml")

    try:
        assert not os.path.isfile(path)
        open(path, 'a').close()
        assert os.path.isfile(path)

        inv = inventory_loader.get('toml')
        assert inv
        assert inv.verify_file(path)
    finally:
        shutil.rmtree(tmp)

# Generated at 2022-06-21 05:27:39.379545
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    # Test with a dict
    test_dict = {
        'a': 'b',
        'c': [
            1,
            2,
            3,
            {
                'e': 'f'
            }
        ],
        'g': {
            'h': 'i'
        }
    }
    converted_test_dict = convert_yaml_objects_to_native(test_dict)

    assert isinstance(converted_test_dict, dict)
    assert isinstance(converted_test_dict['a'], string_types)
    assert isinstance(converted_test_dict['c'], list)
    assert isinstance(converted_test_dict['c'][0], int)
    assert isinstance(converted_test_dict['c'][3], dict)

# Generated at 2022-06-21 05:27:54.582390
# Unit test for function toml_dumps
def test_toml_dumps():

    from collections import OrderedDict

    if HAS_TOML and hasattr(toml, 'TomlEncoder'):
        # This version of the library has `toml.TomlEncoder`, everything should work normally
        assert toml_dumps({'hosts': {'host1': {}, 'host2': {'ansible_port': 222}}, 'vars': {'foo': 'bar'}, 'children': {'child': {}}}) == '''[vars]
foo = "bar"

[children]
child = {}

[hosts]
host1 = {}
host2 = {ansible_port = 222}
'''


# Generated at 2022-06-21 05:27:56.627576
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inv = InventoryModule()
    inv.parse(inventory={}, loader={}, path="", cache=True)
    assert 0

# Generated at 2022-06-21 05:27:58.366855
# Unit test for function convert_yaml_objects_to_native

# Generated at 2022-06-21 05:28:12.377968
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    # Set up test
    test_obj = InventoryModule()
    test_obj.inventory = test_obj.get_empty_inventory()
    test_obj.set_options()
    test_obj.parse(test_obj.inventory, None, None)

    # Print results
    print("TOML inventory plugin:")
    print("    File located: " + os.path.join(os.path.dirname(__file__), 'test_InventoryModule.toml'))
    print("    Parsed data:  " + toml_dumps(test_obj.inventory.get_groups_dict()))


if __name__ == "__main__":
    test_InventoryModule_parse()

# Generated at 2022-06-21 05:28:57.148857
# Unit test for constructor of class InventoryModule
def test_InventoryModule():

    from ansible.plugins.loader import InventoryLoader

    inventory_module = InventoryModule()

    loader = InventoryLoader()
    path = 'test'
    cache = True

    # Test for parse function
    inventory = []
    loader = []
    path = []
    cache = []

    try:
        print(inventory_module.parse(inventory, loader, path, cache))
    except Exception as err:
        print('TEST: Unable to parse file, reason: %s' % str(err))

    # Test for verify_file function
    path = './ansible/inventory/toml.py'
    try:
        print(inventory_module.verify_file(path))
    except Exception as err:
        print('TEST: Unable to verify file %s, reason: %s' % (path, str(err)))



# Generated at 2022-06-21 05:28:58.034226
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    obj = InventoryModule()
    assert obj is not None

# Generated at 2022-06-21 05:28:59.738069
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    import doctest
    failure_count, test_count = doctest.testmod(InventoryModule)
    assert failure_count == 0

# Generated at 2022-06-21 05:29:03.405745
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    assert InventoryModule.verify_file('./unit_test/ansible_test_inventory')
    assert not InventoryModule.verify_file('./unit_test/ansible_test_inventory.yml')
    assert not InventoryModule.verify_file('./unit_test/ansible_test_inventory.txt')


# Generated at 2022-06-21 05:29:19.178111
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    ''' Return a parse result of TOML inventory file from a data. '''
    import tempfile
    from ansible.plugins.loader import inventory_loader

    inv = inventory_loader.get('toml')
    fd, path = tempfile.mkstemp()
    with os.fdopen(fd, 'wb') as fobj:
        fobj.write(to_bytes(EXAMPLES))
    inv.parse(path=path)
    os.remove(path)

    assert inv.inventory.groups['all'].vars['has_java'] == False

    assert inv.inventory.groups['web'].child_groups['apache'].vars == {'http_port': 8080, 'myvar': 23}


# Generated at 2022-06-21 05:29:34.122173
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():

    # Test for parsing error with file that does not exist
    inv = InventoryModule()
    loader = None
    path = "./data/inventories/not_exist.toml"
    try:
        inv.parse(loader, path)
    except AnsibleParserError:
        assert True
    else:
        assert False

    # Test for parsing without loader
    loader = None
    path = "./data/inventories/hosts.toml"
    try:
        inv.parse(loader, path)
    except AnsibleParserError:
        assert True
    else:
        assert False

    # Test for parsing with loader
    loader = Display()
    path = "./data/inventories/hosts.toml"

# Generated at 2022-06-21 05:29:39.467281
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    # ansible.utils.unsafe_proxy.AnsibleUnsafeText is not pickeable, so we can't pickle the pytest fixture.
    # If we try to pickle, the following error is raised:
    #   TypeError: can't pickle ansible.utils.unsafe_proxy.AnsibleUnsafeText objects
    pass

# Generated at 2022-06-21 05:29:47.720883
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence
    from ansible.parsing.yaml.objects import AnsibleUnicode
    from ansible.parsing.yaml.objects import AnsibleUnsafeBytes
    from ansible.parsing.yaml.objects import AnsibleUnsafeText


# Generated at 2022-06-21 05:29:54.843206
# Unit test for function convert_yaml_objects_to_native
def test_convert_yaml_objects_to_native():
    from ansible.parsing.yaml.objects import AnsibleSequence

    ans_seq = AnsibleSequence([
        'foo',
        'bar',
    ])

    ans_seq_result = ['foo', 'bar']

    assert convert_yaml_objects_to_native(ans_seq) == ans_seq_result

# Generated at 2022-06-21 05:29:56.876217
# Unit test for constructor of class InventoryModule
def test_InventoryModule():
    assert InventoryModule is not None


# Generated at 2022-06-21 05:31:26.082952
# Unit test for method verify_file of class InventoryModule
def test_InventoryModule_verify_file():
    fake_path = os.path.join(os.path.dirname(__file__), 'files', 'test_hosts.toml')
    actual = InventoryModule().verify_file(fake_path)
    assert actual == True

# Generated at 2022-06-21 05:31:39.931941
# Unit test for method parse of class InventoryModule
def test_InventoryModule_parse():
    inventory_file = '''[all.vars]
foo = true

[web.vars]
http_port = 8080
myvar = 23

[web.hosts.host1]
[web.hosts.host2]
ansible_port = 222

[apache.hosts.tomcat1]

[apache.hosts.tomcat2]
myvar = 34

[apache.hosts.tomcat3]
mysecret = "03#pa33w0rd"

[nginx.hosts.jenkins1]

[nginx.vars]
has_java = true
'''
    inventory_file_path = '/var/tmp/inventory.toml'
    with open(inventory_file_path, 'w') as f:
       f.write(inventory_file)


# Generated at 2022-06-21 05:31:51.492332
# Unit test for function toml_dumps
def test_toml_dumps():
    assert b'value = "value"' in toml_dumps({'key': 'value'})
    assert b'key = "value"' in toml_dumps({'key': AnsibleUnsafeText(b'value', encoding='utf-8')})
    assert b'key = "value"' in toml_dumps({'key': AnsibleUnsafeBytes(b'value')})
    assert b'key = "value"' in toml_dumps({'key': AnsibleUnicode(u'value')})
    assert b'key = [1, 2, 3]' in toml_dumps({'key': [1, 2, 3]})
    assert b'key = [1, 2, 3]' in toml_dumps({'key': AnsibleSequence([1, 2, 3])})

# Generated at 2022-06-21 05:32:02.437355
# Unit test for function toml_dumps
def test_toml_dumps():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleUnicode, AnsibleUnsafeBytes, AnsibleUnsafeText