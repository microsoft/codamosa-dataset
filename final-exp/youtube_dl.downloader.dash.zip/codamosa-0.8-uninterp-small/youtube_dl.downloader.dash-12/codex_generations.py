

# Generated at 2022-06-26 11:02:50.959027
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:02:53.778327
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = None
    int_0 = 1
    dash_segments_f_d_1 = DashSegmentsFD(dash_segments_f_d_0, int_0)

# Generated at 2022-06-26 11:02:58.334124
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(None, 0)
    filename = 'filename'
    info_dict = {}
    try:
        dash_segments_f_d_0.real_download(filename, info_dict)
    except:
        print('unexpected exception')



# Generated at 2022-06-26 11:02:59.210357
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:03:04.439195
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = None
    int_0 = 1519
    dash_segments_f_d_1 = DashSegmentsFD(dash_segments_f_d_0, int_0)
    print('Function - test_DashSegmentsFD Done')

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:09.273641
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = None
    int_0 = 4519
    float_0 = 3.0
    str_0 = 'vX9yizIH_Mk'
    bool_0 = False
    dash_segments_f_d_1 = DashSegmentsFD(dash_segments_f_d_0, int_0)
    dash_segments_f_d_1.real_download(str_0, float_0, bool_0)


# Generated at 2022-06-26 11:03:14.537161
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # object of class DashSegmentsFD
    dash_segments_f_d = DashSegmentsFD()
    # unit test for method real_download of class DashSegmentsFD
    dash_segments_f_d.real_download(False)

# Generated at 2022-06-26 11:03:26.636284
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Arrange
    dash_segments_f_d_0 = None
    int_0 = 1519
    dash_segments_f_d_1 = DashSegmentsFD(dash_segments_f_d_0, int_0)
    str_0 = 'filename'
    info_dict_0 = {
        'fragments': [
            {
                'duration': 10.0,
                'path': 'segment-1.ts',
            },
            {
                'duration': 20.0,
                'path': 'segment-2.ts',
            },
            {
                'duration': 30.0,
                'path': 'segment-3.ts',
            },
        ],
    }

    # Act

# Generated at 2022-06-26 11:03:28.000375
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:29.798857
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test case 0:
    test_case_0()

test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:37.278391
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_1 = DashSegmentsFD()

# Generated at 2022-06-26 11:03:40.218204
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d = DashSegmentsFD()
    dash_segments_f_d.real_download(filename, info_dict)
# ---- End of method real_download ----

# Generated at 2022-06-26 11:03:52.294944
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    dash_segments_f_d_1 = DashSegmentsFD()
    filename = 'file.mp4'
    info_dict = list()
    return_value = dash_segments_f_d_0.real_download(filename, info_dict)
    return_value = dash_segments_f_d_1.real_download(filename, info_dict)
    return_value = dash_segments_f_d_0.real_download(filename, info_dict)

# Generated at 2022-06-26 11:03:55.086091
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0.real_download

# Generated at 2022-06-26 11:03:56.285700
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    dash_segments_f_d_0.real_download('5.mp4', '5.mp4')

# Generated at 2022-06-26 11:04:00.684034
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d = DashSegmentsFD()
    return dash_segments_f_d.real_download()


# Generated at 2022-06-26 11:04:04.158225
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0.real_download(filename=5, info_dict=5) is False


# Generated at 2022-06-26 11:04:05.702586
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()


# Generated at 2022-06-26 11:04:09.312369
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d = DashSegmentsFD()
    assert(dash_segments_f_d.FD_NAME == 'dashsegments')

# Generated at 2022-06-26 11:04:20.114367
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d = DashSegmentsFD()
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0._progress_hooks == []
    assert dash_segments_f_d_0.params == {}
    assert dash_segments_f_d.handle is None
    assert dash_segments_f_d._progress_hooks == []
    assert dash_segments_f_d.params == {}
    assert dash_segments_f_d.handle is None

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:35.345812
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_fd = DashSegmentsFD()
    info_dict = {}
    filename = str()
    result = dash_segments_fd(filename, info_dict)
    assert result == True


# Generated at 2022-06-26 11:04:38.002450
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()


if __name__ == '__main__':
    # test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:46.387869
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_1 = DashSegmentsFD()
    dash_segments_filename_1 = 'filename'
    dash_segments_info_dict_1 = {}
    dash_segments_result_1 = dash_segments_f_d_1.real_download(dash_segments_filename_1, dash_segments_info_dict_1)

# Generated at 2022-06-26 11:04:49.575333
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test case0:
    dash_segments_f_d_0 = DashSegmentsFD()
    return


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:52.046660
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()
    pass

# Generated at 2022-06-26 11:05:02.960456
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    str_0 = 'video/mp4; codecs="avc1.4d001f"'
    str_1 = 'https://r6---sn-8xgp1vo-un5l.googlevideo.com/videoplayback?signature='
    str_2 = 'https://r1---sn-8xgp1vo-un5l.googlevideo.com/videoplayback?signature='

# Generated at 2022-06-26 11:05:06.253408
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print("Testing DashSegmentsFD()")

if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:15.657364
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    dash_segments_f_d_0.download = lambda filename, info_dict: True
    dash_segments_f_d_0.report_error = lambda msg: None
    dash_segments_f_d_0._download_fragment = lambda ctx, fragment_url, info_dict: (True, b"fragment_content")
    dash_segments_f_d_0._append_fragment = lambda ctx, frag_content: None
    dash_segments_f_d_0._prepare_and_start_frag_download = lambda ctx: None
    dash_segments_f_d_0._finish_frag_download = lambda ctx: None
    filename = ""

# Generated at 2022-06-26 11:05:17.910704
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()

# Generated at 2022-06-26 11:05:21.016525
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_about_real_download = DashSegmentsFD()
    pass




if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:05:45.530070
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    Test for real_download method of class DashSegmentsFD.
    """
    dash_segments_f_d_1 = DashSegmentsFD()
    dash_segments_f_d_1.real_download("test_filename", "test_info_dict")


# Generated at 2022-06-26 11:05:51.976423
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('start class DashSegmentsFD testing')
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0 != None
    print('end class DashSegmentsFD testing')
    return 0


# Generated at 2022-06-26 11:05:56.211409
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_1 = DashSegmentsFD()
    assert dash_segments_f_d_1.FD_NAME == 'dashsegments'


# Generated at 2022-06-26 11:05:59.049282
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Code to execute when running as a script
if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:06:01.845772
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d = DashSegmentsFD()
    assert dash_segments_f_d.FD_NAME == 'dashsegments'


# Generated at 2022-06-26 11:06:09.237841
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Create an instance of DashSegmentsFD
    dash_segments_fd_0 = DashSegmentsFD()
    # test DashSegmentsFD::real_download
    dash_segments_fd_0.real_download('/dev/null', {})


# Generated at 2022-06-26 11:06:15.913138
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    try:
        dash_segments_f_d_0.real_download("filename", {"fragment_base_url": "fragment_base_url", "fragments": [{"url": "url"}, {"path": "path"}]})
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise

test_case_0()
test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:23.630386
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    dash_segments_f_d_1 = DashSegmentsFD()
    dash_segments_f_d_2 = DashSegmentsFD()
    dash_segments_f_d_0.real_download("", "")
    dash_segments_f_d_1.real_download("", "")
    dash_segments_f_d_2.real_download("", "")


# Generated at 2022-06-26 11:06:25.890450
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_1 = DashSegmentsFD()


# Generated at 2022-06-26 11:06:36.818250
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import (
        YoutubePlaylistIE,
        YoutubePlaylistIndexIE,
        YoutubeIE,
        )
    from ..downloader import Downloader
    from ..downloader import (
        FileDownloader,
        )
    from ..compat import (
        compat_urllib_request,
        )
    from ..postprocessor import (
        YoutubeDlPostProcessor,
        )
    from ..utils import (
        encodeFilename,
        )

    dash_segments_f_d_1 = DashSegmentsFD()
    youtube_ie_0 = YoutubeIE()
    youtube_playlist_ie_0 = YoutubePlaylistIE()
    youtube_playlist_index_ie_0 = YoutubePlaylistIndexIE()

# Generated at 2022-06-26 11:06:56.196562
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == None

# Generated at 2022-06-26 11:06:57.750375
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:07:01.255896
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'mf>'
    str_1 = '\x7fK\x0c\xd8\x1d\x11\x92\xfe\x9f'
    bytes_0 = b'\x84\x8d\xfe\xb3&h\xba\x8e'
    dash_segments_f_d_0 = DashSegmentsFD(str_1, bytes_0)

# Generated at 2022-06-26 11:07:09.892481
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'k\x9e\x97\xbct]\xd8\xa0'
    bytes_0 = b"[\xeb\xa1\x13\xb2\x96"
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bytes_0)
    str_1 = 'c\x02\x0eo\x1b\xeb\x1ex\x1a'
    str_2 = '\xa7\x18\x1c\xd5\x95\x8f\x9bs\x9b\xb5'
    dash_segments_f_d_0.real_download(str_2, str_1)


# Generated at 2022-06-26 11:07:19.286687
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '\x0b-w\x93\x7f\x08'
    str_1 = '<b\xb9\x00\x97\xfd\x0f'
    bytes_0 = b"\xef\x82\xcc\xea\xfc\x03\x98\x89\xef\x83\xc7\xe6"
    dash_segments_f_d_0 = DashSegmentsFD(str_1, bytes_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, str_0)


# Generated at 2022-06-26 11:07:31.029442
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '7g.9\x1b6\x1c\x0f\x13\x1a0'

# Generated at 2022-06-26 11:07:41.503833
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'k\x0b\xeb\xbeSc'
    str_1 = '\x03\xaf\x00\x9a\xbd'
    bytes_0 = b'\r\x06\xab\x08\x0f\x9d\x18\x86'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bytes_0)
    dash_segments_f_d_0.real_download(str_1, str_1)
    str_2 = '\x0e\xac\x1b\x1a\xb0\x19\xde\xd9\x1d\x1d\x1c'

# Generated at 2022-06-26 11:07:42.421508
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:07:48.452572
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_0 = None
    var_1 = None
    try:
        test_case_0()
    except Exception:
        var_1 = sys.exc_info()[1]
        var_0 = var_1

    assert var_0 == None


# Generated at 2022-06-26 11:07:49.752073
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:08:36.512022
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-26 11:08:41.658682
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass # The constructor of class DashSegmentsFD is parameterized, it cannot be tested here

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:46.079701
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_c = '5{?:h'
    var_d = 'o\x0b9e\rg{]'
    str_0 = '\xb2\x92\xbe^\'\xa6\x80\xb8\xd8'
    dash_segments_f_d_0 = DashSegmentsFD(var_d, str_0)
    var_b = dash_segments_f_d_0.real_download(var_c, var_c)
    assert var_b == True

# Generated at 2022-06-26 11:08:55.697090
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '\x14,\xf7\x8d\x9aF\xad\xa1'
    str_1 = '\xef\xa5\x02\xc1\x9e\xccF'
    bytes_0 = b'w\xe7Vu\xac\xd7\x85\x9d'
    dash_segments_f_d_0 = DashSegmentsFD(str_1, bytes_0)
    print(var_0)
    print(str_0, str_1, bytes_0)

# Generated at 2022-06-26 11:08:56.798685
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    pass


# Generated at 2022-06-26 11:08:57.584588
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


# Generated at 2022-06-26 11:09:01.835744
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    d_seg_fd = DashSegmentsFD("hi", "hi")

if __name__ == '__main__':
    if True:
        test_case_0()
        # test_DashSegmentsFD()

# Generated at 2022-06-26 11:09:04.721011
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:09:06.602410
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:09:10.480220
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test for 0, [], or None args
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:24.256017
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:27.911808
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == True

test_cases = [
    test_DashSegmentsFD_real_download,
]



# Generated at 2022-06-26 11:10:30.903044
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == None

test_classes = [
    DashSegmentsFD
]



# Generated at 2022-06-26 11:10:35.571338
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '5{?:h'
    str_1 = 'o\x0b9e\rg{]'
    bytes_0 = b"\xb2\x92\xbe^'\xa6\x80\xb8\xd8"
    dash_segments_f_d_0 = DashSegmentsFD(str_1, bytes_0)


# Generated at 2022-06-26 11:10:36.397950
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass


# Generated at 2022-06-26 11:10:37.718276
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Base case where __init__ is called with three arguments.
    test_case_0()

# Generated at 2022-06-26 11:10:39.340667
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:42.318084
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:43.956789
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:49.626642
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '5{?:h'
    str_1 = 'o\x0b9e\rg{]'
    bytes_0 = b"\xb2\x92\xbe^'\xa6\x80\xb8\xd8"
    dash_segments_f_d_0 = DashSegmentsFD(str_1, bytes_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, str_0)

# Assignment for variable test_case_0