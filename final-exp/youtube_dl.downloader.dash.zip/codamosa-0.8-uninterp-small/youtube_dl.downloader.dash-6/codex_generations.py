

# Generated at 2022-06-26 11:03:01.098841
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bytes_0 = b'\xd36\x87\xe4\x98\x98\xc2:LX?\xd7\x99\xcc'
    float_0 = -3575.1348
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, float_0)
    dash_segments_f_d_0.real_download(None, None)

test_case_0()
test_DashSegmentsFD_real_download()

if __name__ == "__main__":
	import sys
	sys.exit(main())

# Generated at 2022-06-26 11:03:05.003469
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    with pytest.raises(TypeError):
        # dash_segments_f_d_1 = DashSegmentsFD()
        assert dash_segments_f_d_1 is not None

# test_case_0()

# Generated at 2022-06-26 11:03:06.669462
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:03:10.073705
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b'(\x18\x8c\x1bl\x98\x9dE\x8e\xb3\n\xb3\x1f\x8d'
    float_0 = -0.044558622
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, float_0)


test_case_0()

# Generated at 2022-06-26 11:03:15.950790
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b'\xd36\x87\xe4\x98\x98\xc2:LX?\xd7\x99\xcc'
    float_0 = -3575.1348
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, float_0)


# Generated at 2022-06-26 11:03:22.656994
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert callable(DashSegmentsFD)
    dash_segments_f_d_0 = DashSegmentsFD()
    print(dash_segments_f_d_0)
    dash_segments_f_d_1 = DashSegmentsFD('\xdb\xff\xc6\xde')
    assert float(dash_segments_f_d_1) == float('-5.3580')


# Generated at 2022-06-26 11:03:29.346033
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bytes_0 = b'\xd36\x87\xe4\x98\x98\xc2:LX?\xd7\x99\xcc'
    float_0 = -3575.1348
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, float_0)
    assert dash_segments_f_d_0.real_download("filename", "info_dict")


# Generated at 2022-06-26 11:03:36.613950
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0() == None

# Test cases are generated using this command:
#
#    import shlex
#    print('\n'.join(shlex.split("""
#    python -c '
#    from ytdl import test_DashSegmentsFD as t
#    print("test_cases = [\\")
#    for f in dir(t):
#        if f.startswith("test_case_"):
#            print("    t.%s," % f)
#    print("]")
#    '
#    """)),
#
# with this assignment:
#
#    test_DashSegmentsFD = type('test_DashSegmentsFD', (object,), {'test_case': None, 'test_cases': None})
#
# and this output:
#
#    test

# Generated at 2022-06-26 11:03:39.266395
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

if __name__ == '__main__':

    print(test_case_0())
    print(test_DashSegmentsFD())

# Generated at 2022-06-26 11:03:41.123339
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # TODO: Add test
    assert False, "Test not implemented"


# Generated at 2022-06-26 11:03:47.465894
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:48.215942
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:03:49.158403
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:52.236852
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-26 11:04:00.124856
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    float_0 = 917.07726
    bool_0 = True
    str_0 = '={-k'
    bool_1 = True
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bool_1)
    var_0 = dash_segments_f_d_0.real_download(float_0, bool_0)

# Generated at 2022-06-26 11:04:01.215872
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0()


# Generated at 2022-06-26 11:04:02.488505
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:04:05.072385
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == "__main__":
    # Run unit tests
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:07.009154
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

test_classes = [
    DashSegmentsFD
]



# Generated at 2022-06-26 11:04:09.308358
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:21.053113
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    return




# Generated at 2022-06-26 11:04:23.249006
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'ae'
    bool_0 = True
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bool_0)

# Generated at 2022-06-26 11:04:26.447562
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    float_0 = 917.07726
    bool_0 = True
    str_0 = '={-k'
    bool_1 = True
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bool_1)
    var_0 = dash_segments_f_d_0.real_download(float_0, bool_0)

# Generated at 2022-06-26 11:04:28.049576
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:04:29.271576
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:04:34.702884
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        test_case_0()
        print(">>>>>> Test DashSegmentsFD success")   
    except:
        print(">>>>>> Test DashSegmentsFD Fail")      
        

# Generated at 2022-06-26 11:04:38.182907
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    url_0 = 'cI7A,z%8u'
    dash_segments_f_d_0 = DashSegmentsFD(url_0, False)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:39.759728
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:04:47.914094
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    class_var = DashSegmentsFD('{|)$JOG', True)
    try:
        # Call the method
        class_var.real_download(0.7, True)
    except Exception as e:
        print(e)
        print("Unit test for constructor of class DashSegmentsFD fails")
        return False
    return True


# Generated at 2022-06-26 11:04:52.778790
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-26 11:05:21.439809
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    float_0 = 'l3q'
    bool_0 = True
    str_0 = ''
    bool_1 = True
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bool_1)
    var_0 = dash_segments_f_d_0.real_download(float_0, bool_0)
    assert_equal(var_0, False)


# Generated at 2022-06-26 11:05:23.009654
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:24.775712
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0() == 0

# Generated at 2022-06-26 11:05:25.190650
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:05:28.245821
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_1 = DashSegmentsFD('t', False)

# Generated at 2022-06-26 11:05:30.582567
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:33.333631
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

test_classes = [
    DashSegmentsFD,
]


# Generated at 2022-06-26 11:05:35.777868
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    print("Unit test for class DashSegmentsFD is finished.")

# Generated at 2022-06-26 11:05:45.490874
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # fragment_base_url = 'dGhpcyBpcyBhIHRlc3Q='
    # fragments = 'dGhpcyBpcyBhIHRlc3Q='
    # fragment_retries = 123
    # skip_unavailable_fragments = False
    # params = {'fragment_base_url':fragment_base_url,'fragments': fragments,'fragment_retries': fragment_retries,'skip_unavailable_fragments': skip_unavailable_fragments}
    # dash_segments_f_d_0 = DashSegmentsFD(params, True)
    # unit_test_result = dash_segments_f_d_0.real_download(fragment_base_url, fragments)
    pass

# Generated at 2022-06-26 11:05:56.539376
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    float_0 = 52.8092507
    bool_0 = True
    str_0 = 'r'
    bool_1 = True
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bool_1)
    var_0 = dash_segments_f_d_0.real_download(float_0, bool_0)
    return var_0

if __name__ == "__main__":
    float_0 = 2.182213
    bool_0 = True
    str_0 = 'Tj'
    bool_1 = True
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bool_1)
    var_0 = dash_segments_f_d_0.real_download(float_0, bool_0)
    print

# Generated at 2022-06-26 11:06:37.460968
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:06:38.094829
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:06:43.653560
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD('', True)

# Generated at 2022-06-26 11:06:51.043785
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    float_0 = 0.069
    bool_0 = False
    str_0 = '%o|q'
    bool_1 = False
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bool_1)

test_case_0()

# Generated at 2022-06-26 11:06:53.748869
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test = Test("-k")
    test.add_testcase(test_case_0)
    return test


# Generated at 2022-06-26 11:06:59.288982
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test for constructor in the case of valid value for the url and the params
    test_case_0()
    # Test for constructor in the case of valid value for the url and the params
    # test_case_1()
    # Test for constructor in the case of valid value for the url and the params
    # test_case_2()
    # Test for constructor in the case of valid value for the url and the params
    # test_case_3()
    # Test for constructor in the case of valid value for the url and the params
    # test_case_4()
    # Test for constructor in the case of valid value for the url and the params
    # test_case_5()

# Generated at 2022-06-26 11:07:02.217005
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:10.548481
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD('', True)
    print(str(dash_segments_f_d_0.params))
    print(str(dash_segments_f_d_0.fd_name))
    print(str(dash_segments_f_d_0.ctx))
    print(str(dash_segments_f_d_0.fd_id))
    print(str(dash_segments_f_d_0.url))
    print(str(dash_segments_f_d_0.resume_len))
    print(str(dash_segments_f_d_0.err_occurred))
    print(str(dash_segments_f_d_0.frag_info))

# Generated at 2022-06-26 11:07:15.849058
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '{-SGz'
    bool_0 = True
    dash_segments_f_d_0 = DashSegmentsFD(str_0, bool_0)

# Generated at 2022-06-26 11:07:18.653462
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Test cases for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:08:41.585049
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert(dash_segments_f_d_0.params == dict_0)
    assert(dash_segments_f_d_0.ydl_opts == dict_0)



# Generated at 2022-06-26 11:08:44.688844
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True == True


# Generated at 2022-06-26 11:08:49.400574
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass # stubbed out


if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:54.203545
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)

# Generated at 2022-06-26 11:08:56.779410
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-26 11:08:58.241323
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert callable(DashSegmentsFD)
    assert isinstance(DashSegmentsFD, type)



# Generated at 2022-06-26 11:08:59.558541
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0() == None

# Generated at 2022-06-26 11:09:12.160613
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    class TestClass_0:

        def __init__(self, param_0, param_1):
            self.test_dict_0 = param_0
            self.test_dict_1 = param_1

        def _prepare_and_start_frag_download(self, param_0):
            return None

        def _download_fragment(self, param_0, param_1, param_2):
            return (True, None)

        def _append_fragment(self, param_0, param_1):
            return None

        def _finish_frag_download(self, param_0):
            return None

        def report_skip_fragment(self, param_0):
            return None


# Generated at 2022-06-26 11:09:16.919046
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert dash_segments_f_d_0._dashsegments_fd == dict_0
    var_0 = dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)

if __name__ == '__main__':
    print('Applying utils.py script for testing')
    test_DashSegmentsFD()
    test_case_0()

# Generated at 2022-06-26 11:09:28.062617
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_1 = {}

# Generated at 2022-06-26 11:10:42.919243
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:10:47.550762
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_1 = {}
    dict_1[0] = None
    dict_1[1] = False
    dash_segments_f_d_1 = DashSegmentsFD(dict_1, dict_1)
    dash_segments_f_d_1.download(dash_segments_f_d_1)


# Generated at 2022-06-26 11:10:49.249792
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:10:56.422271
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Setup test data
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    # Run method to test
    dash_segments_f_d_0.real_download(dict_0, dict_0)


# Generated at 2022-06-26 11:10:58.604762
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if (__name__ == '__main__'):
    # Unit test for class DashSegmentsFD
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:11:00.134507
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:11:02.609510
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.FD_NAME == 'dashsegments'
    assert DashSegmentsFD({}, {}).params == {}

# Generated at 2022-06-26 11:11:11.076172
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)
    assert (var_0 == False)
    #assert (dash_segments_f_d_0.FD_NAME == 'dashsegments')



# Generated at 2022-06-26 11:11:13.999760
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:11:15.351683
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True == True
