

# Generated at 2022-06-26 11:03:01.860371
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        assert False
    except:
        pass
# test_case_0

# Generated at 2022-06-26 11:03:10.389687
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = None
    float_0 = 1686.12116545
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)
    float_0 = float('nan')
    float_1 = float('nan')
    float_2 = float('nan')
    float_3 = float('nan')
    float_4 = float('nan')
    float_5 = float('nan')
    float_6 = float('nan')
    float_7 = float('nan')
    float_8 = float('nan')
    float_9 = float('nan')
    float_10 = float('nan')
    float_11 = float('nan')
    float_12 = float('nan')
    float_13 = float('nan')
    float_14 = float('nan')
    float

# Generated at 2022-06-26 11:03:14.264880
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = None
    float_0 = 4257.97079
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)


# Generated at 2022-06-26 11:03:16.070482
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test for method real_download(filename, info_dict)
    # Test case 0
    tuple_0 = None
    float_0 = 4257.97079
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)

# Generated at 2022-06-26 11:03:21.822350
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = None
    float_0 = 4257.97079
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)
    print(dash_segments_f_d_0)

# Main is used to generate test data

# Generated at 2022-06-26 11:03:24.368179
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = None
    float_0 = 4257.97079
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)

# Generated at 2022-06-26 11:03:29.345955
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print("Testing real_download()")
    tuple_0 = None
    float_0 = 4257.97079
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)
    dash_segments_f_d_0.real_download()

# Generated at 2022-06-26 11:03:31.822964
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Prepare data for real_download
    dash_segments_f_d_0 = DashSegmentsFD()

    dash_segments_f_d_0.real_download()


# Generated at 2022-06-26 11:03:43.931201
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = dict()
    dict_0 = {'a': 'b'}
    dict_0 = {'a': 0, 'b': 1}
# Class DashSegmentsFD
    _None = None
    dash_segments_f_d_1 = DashSegmentsFD(_None, _None)
    dict_1 = {'a': 'b'}
    dash_segments_f_d_2 = DashSegmentsFD(dict_1, _None)
    list_1 = [1, 2, 3, 4]
    dict_1 = {'a': 'b', 'c': list_1}
    dash_segments_f_d_2 = DashSegmentsFD(dict_1, _None)

# Function real_download

# Generated at 2022-06-26 11:03:56.589223
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = None
    float_0 = 4257.97079
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)

    float_1 = float_0
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_1)

    float_0 = float_1
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)

    float_0 = float_1
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, float_0)

    float_1 = float_0
    dash_segments_f_d_0.real_download(float_1,float_1)
    assert dash_segments_f_d_0

# Generated at 2022-06-26 11:04:03.202417
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:07.103603
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
    except:
        assert False
        print("Test case 0 failed.")
        print("")
        return
    print("Test case 0 passed.")
    print("")


# Generated at 2022-06-26 11:04:11.806362
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:16.676780
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
        unit_test_result_0 = True
    except:
        unit_test_result_0 = False
    finally:
        assert unit_test_result_0 == True

# Unit test ending

# Generated at 2022-06-26 11:04:25.400217
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '!Dp'
    float_0 = 9739.8
    dash_segments_f_d_0 = DashSegmentsFD(str_0, float_0)
    str_1 = dash_segments_f_d_0.fd_name
    float_1 = dash_segments_f_d_0.params['noprogress']
    str_2 = dash_segments_f_d_0.params['logtostderr']
    str_3 = dash_segments_f_d_0.params['log_file_prefix']
    str_4 = dash_segments_f_d_0.params['logger_class']
    list_0 = dash_segments_f_d_0.params['progress_hooks']
    str_5 = dash_segments_

# Generated at 2022-06-26 11:04:28.428871
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:39.418829
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'r\xaa\x01\x14\xe8\x12>\x1b\x9d\x8d5Ai\x04\xa5\x99\xc1\x0f%\x81\x9c\xbe\x8a\x14\xe0\xce\x1b\xcb\x89'
    str_1 = '\x90\xed\x02\xd4\x14\xc4\x1d\x1f\x9c\xbf\xf8\xfd\x1d\xdc\x12\x86\x89\xab\x9c\xa8\xce\x1d\xec\x1d'

# Generated at 2022-06-26 11:04:40.925567
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:04:46.219882
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'lZ8F'
    float_0 = 567.525
    dash_segments_f_d_0 = DashSegmentsFD(str_0, float_0)


# Generated at 2022-06-26 11:04:52.631256
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD('A3q', -2086.17714)
    dash_segments_f_d_0.real_download('qD~H', ['qD~H', 'qD~H'])
    try:
        dash_segments_f_d_0.real_download('qD~H', ['qD~H', 'qD~H'])
    except Exception as exc_0:
        print('Expected error: %s' % exc_0)


# Generated at 2022-06-26 11:05:04.312215
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:05:05.715963
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:07.835988
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    test_case_1()



# Generated at 2022-06-26 11:05:09.129706
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:10.367258
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:05:19.645635
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True == test_case_0()

test_DashSegmentsFD_real_download()

dash_segments_f_d = DashSegmentsFD('', 0)
dash_segments_f_d_0 = dash_segments_f_d.real_download('', '')
dash_segments_f_d_0 = dash_segments_f_d.real_download(0, 0)

# Generated at 2022-06-26 11:05:33.144824
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('\nTesting DashSegmentsFD.real_download')
    str_0 = 'EoVz2'
    list_0 = [str_0, str_0]
    str_1 = 'R_R$'
    str_2 = '3qT7'
    float_0 = 4084.6849
    dash_segments_f_d_0 = DashSegmentsFD(str_1, float_0)
    boolean_0 = dash_segments_f_d_0.real_download(str_2, list_0)
    assert boolean_0
    str_3 = 'mF%a'
    float_1 = -2815.3964
    dash_segments_f_d_1 = DashSegmentsFD(str_3, float_1)
    boolean_1 = dash_segments

# Generated at 2022-06-26 11:05:41.733480
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'qD~H'
    list_0 = [str_0, str_0]
    str_1 = 'ZH$7l'
    float_0 = -2086.17714
    dash_segments_f_d_0 = DashSegmentsFD(str_1, float_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, list_0)

# Generated at 2022-06-26 11:05:44.994438
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()
    print('pass')

# Generated at 2022-06-26 11:05:49.013486
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()
    pass

# Generated at 2022-06-26 11:06:15.471892
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
  float_0 = float('NaN')
  dict_0 = {'7Vxh:2?': float_0}
  dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
  dash_segments_f_d_0.FD_NAME
  dash_segments_f_d_0.FD_NAME = dict_0
  dash_segments_f_d_0.FD_NAME
  dash_segments_f_d_0.FD_NAME = None

# Generated at 2022-06-26 11:06:16.878037
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:06:20.803343
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
  DashSegmentsFD(3199.7038873029364, {'test': {'test': 'test'}})


if __name__ == '__main__':
    test_DashSegmentsFD()
    test_case_0()

# Generated at 2022-06-26 11:06:22.504767
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:06:23.912326
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:06:31.037005
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {'test': True}
    dict_1 = {'test': True}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_1)
    dash_segments_f_d_0.to_screen = dict_1


# Generated at 2022-06-26 11:06:44.132462
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    float_1 = 3199.7038873029364
    dict_1 = {float_1: float_1}
    int_0 = 0
    dict_2 = {float_1: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(float_1, dict_1)
    dash_segments_f_d_1 = DashSegmentsFD(float_1, dict_1)
    dash_segments_f_d_2 = DashSegmentsFD(float_1, dict_1)
    dash_segments_f_d_3 = DashSegmentsFD(float_1, dict_1)
    dash_segments_f_d_4 = DashSegmentsFD(float_1, dict_1)

# Generated at 2022-06-26 11:06:57.264270
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    const_0 = 'http://frag1_url'
    float_0 = 3199.7038873029364
    list_0 = []
    float_1 = 0.3376509
    int_0 = 8
    tuple_0 = (float_0, int_0)
    bool_0 = False
    int_1 = 10
    long_0 = long(10)
    bool_1 = True
    unicode_0 = 'Cancel'
    str_0 = 'http://frag2_url'
    int_2 = 18
    float_2 = 0.84109044
    float_3 = 0.39432477
    float_4 = 0.5923532
    tuple_1 = (int_2, float_2, float_3, float_4)
    float_5 = 0.

# Generated at 2022-06-26 11:07:09.017986
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(15.0, {'user_agent': 'user_agent', 'geo_bypass': True, 'fragment_base_url': 'fragment_base_url', 'http_headers': {}})
    assert dash_segments_f_d_0.params['skip_unavailable_fragments'] == True
    assert dash_segments_f_d_0.params['retries'] == 10
    assert dash_segments_f_d_0.params['fragment_retries'] == 10
    assert dash_segments_f_d_0.params['geo_bypass'] == True
    assert dash_segments_f_d_0.params['user_agent'] == 'user_agent'
    assert dash_segments_f

# Generated at 2022-06-26 11:07:10.479278
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:07:52.357001
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dict_0[1] = 1
    dict_0[2] = 2
    dict_0[3] = 3
    dict_0[4] = 4
    dict_0[5] = 5
    dict_0[6] = 6
    dict_0[7] = 7
    dict_0[8] = 8
    dict_0[9] = 9
    dict_0[10] = 10
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 11:08:00.478965
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    float_0 = 1417.271304463075
    str_0 = 'dyua52v0dq'
    dict_0 = {str_0: str_0}
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    print('Unit test for DashSegmentsFD class has passed!')


# Generated at 2022-06-26 11:08:10.651051
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    float_0 = 4.083791451239218
    dict_0 = {4.940439263538017: 4.106208073292024}
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    dict_0 = {4.550675147344343: 4.940439263538017}
    dash_segments_f_d_0.real_download(dict_0, dict_0)

# Generated at 2022-06-26 11:08:14.333164
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    _ = DashSegmentsFD()
    test_case_0()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:08:21.230296
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_0 = 3199.7038873029364
    dict_0 = {var_0: var_0}
    dash_segments_f_d_0 = DashSegmentsFD(var_0, dict_0)
    dash_segments_f_d_0.real_download(dict_0, dict_0)

# Generated at 2022-06-26 11:08:29.794051
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Testing parameters:
    filename = None
    info_dict = None
    dash_segments_f_d_0 = DashSegmentsFD("", {})
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()


# Generated at 2022-06-26 11:08:35.837660
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    float_0 = 3199.7038873029364
    dict_0 = {float_0: float_0}
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)
    del dash_segments_f_d_0
    #assert var_0 == True
    print("Test Case 0 Passed")
    return True


# Generated at 2022-06-26 11:08:37.660269
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:08:46.904721
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('test_DashSegmentsFD')

    def test_case_1():
        str_0 = 'https://www.youtube.com/watch?v=1jU6MwUwz_o'
        dash_segments_f_d_0 = DashSegmentsFD(str_0, None)
        assert dash_segments_f_d_0.params == None
        assert dash_segments_f_d_0.filename == None
        assert dash_segments_f_d_0.fd_name == 'dashsegments', 'dashsegments'
        assert dash_segments_f_d_0.proto == 'https', 'https'
        assert dash_segments_f_d_0.n_tasks == 1, '1'
        assert dash_segments_f_d_0.total_

# Generated at 2022-06-26 11:08:55.287514
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    float_0 = 3199.7038873029364
    dict_0 = {float_0: float_0}
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    var_0 = dash_segments_f_d_0.download(dict_0)
    dash_segments_f_d_0.report_error("RealDownload")
    dash_segments_f_d_0.to_screen("download")


# Generated at 2022-06-26 11:09:38.540348
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD(None, None)



# Generated at 2022-06-26 11:09:44.203848
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(0, 0)
    assert dash_segments_f_d_0.total_frags == 0
    assert dash_segments_f_d_0.fd_name == 'dashsegments'

# Generated at 2022-06-26 11:09:47.137087
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:09:57.382787
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    float_0 = 7356.365880789285
    dict_0 = {0.0: 0.0}
    dict_1 = {float_0: float_0}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_1)
    dash_segments_f_d_0.real_download(dict_0, dict_1)
    assert_equal(dict_0, dict_1)

# Generated at 2022-06-26 11:10:00.480395
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(0.3986, {0.3986: 0.3986})
    var_0 = dash_segments_f_d_0.real_download({0.3986: 0.3986}, {0.3986: 0.3986})

# Generated at 2022-06-26 11:10:07.484692
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dict_0.update({})
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert isinstance(dash_segments_f_d_0, DashSegmentsFD)


# Generated at 2022-06-26 11:10:12.276367
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    float_0 = 2950.2918339610334
    dict_0 = {float_0: float_0}
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)

if __name__ == '__main__':
    test_DashSegmentsFD()
    test_case_0()

# Generated at 2022-06-26 11:10:14.928848
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD('DashSegmentsFD')


# Generated at 2022-06-26 11:10:20.112627
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {float: 3199.7038873029364}
    dash_segments_f_d_0 = DashSegmentsFD(3199.7038873029364, dict_0)


# Generated at 2022-06-26 11:10:20.913460
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:11:50.962641
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert(False)


# Generated at 2022-06-26 11:11:51.641806
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    return None


# Generated at 2022-06-26 11:12:02.579622
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD({'index': 1}, {})
    assert dash_segments_f_d_0.real_download('https://www.youtube.com/watch?v=9bZkp7q19f0', {'fragment_base_url': 'https://www.youtube.com/watch?v=9bZkp7q19f0', 'fragments': [{'duration': 4.0, 'path': '9bZkp7q19f0&type=track&frag=0&len=4000000'}]})

# Generated at 2022-06-26 11:12:08.296860
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {
        'filename': 'tmp.m4a',
        'skip_unavailable_fragments': True,
        'http_chunk_size': 0,
        'fragment_retries': int('200', 10),
        'test': False,
        'ratelimit': int('83', 10),
        'noprogress': True,
        'retries': int('10', 10),
        'http_headers': {str("DNT"): str("1")},
        'http_chunk_size_exceptions': {
            '': [
                int('0', 10),
            ],
        },
        'fragments': [{'url': str("tmp.m4a")}, {'path': str("foo")}],
    }
    dash_segments_f_d_0

# Generated at 2022-06-26 11:12:13.575843
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_1 = dash_segments_f_d_0.real_download(dict_0, dict_0)

# Generated at 2022-06-26 11:12:26.461600
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-26 11:12:36.348287
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert dash_segments_f_d_0.__class__.__name__ == 'DashSegmentsFD'
    assert dash_segments_f_d_0.__class__.__doc__ == '\n    Download segments in a DASH manifest\n    '
    assert dash_segments_f_d_0.__class__.FD_NAME == 'dashsegments'


# Generated at 2022-06-26 11:12:39.378926
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Testing method real_download of class DashSegmentsFD')
    test_case_0()

# Generated at 2022-06-26 11:12:44.368309
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test for class DashSegmentsFD
    # Create an object of class DashSegmentsFD
    # Invoke real_download method
    test_case_0()

# End of Test Cases for class DashSegmentsFD

# Generated at 2022-06-26 11:12:49.182795
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_0 = {}
    var_1 = {}
    dash_segments_f_d_0 = DashSegmentsFD(var_0, var_1)
    dash_segments_f_d_0.real_download(var_1, var_1)

# Procedure test for method real_download of class DashSegmentsFD