

# Generated at 2022-06-26 11:02:57.347903
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == None, "Test case 0 failed"

print("Passed all tests!")

# Output: Passed all tests!

# Generated at 2022-06-26 11:03:00.334696
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    #Test Constructor
    print('Test Constructor')
    print('Test Complete')

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:05.376762
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 4604
    list_0 = [int_0]
    dash_segments_f_d_0 = DashSegmentsFD(list_0, int_0)
    str_0 = 'filename'
    bool_0 = dash_segments_f_d_0._real_extract(str_0)

# Generated at 2022-06-26 11:03:06.776833
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Testing DashSegmentsFD')
    test_case_0()
    print('Done')

# Generated at 2022-06-26 11:03:07.900199
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# fixture for dashsegments

# Generated at 2022-06-26 11:03:14.538409
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test with a single argument
    test_case_0()
    # Test with two arguments
    # dash_segments_f_d_1 = DashSegmentsFD()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:15.728142
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:03:18.195016
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:21.981092
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    string_0 = dash_segments_f_d_0.real_download()
    assert string_0 is not None and string_0 == ''


# Generated at 2022-06-26 11:03:28.475727
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('\nStarting test_DashSegmentsFD_real_download')
    d_e_0 = DownloadError()
    dash_segments_f_d_0 = DashSegmentsFD(None, None)
    try:
        dash_segments_f_d_0.real_download(None, None)
    except DownloadError:
        print('Failed test_DashSegmentsFD_real_download')
    return


# Generated at 2022-06-26 11:03:38.688916
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'

# Generated at 2022-06-26 11:03:39.316110
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass


# Generated at 2022-06-26 11:03:43.128720
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'
    assert dash_segments_f_d_0.params == {}


# Generated at 2022-06-26 11:03:49.739258
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    dash_segments_f_d_0.real_download('test.mp4')

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:03:50.802249
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass


# Generated at 2022-06-26 11:03:51.777720
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:56.795885
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d = DashSegmentsFD();
    assert dash_segments_f_d != None
    assert dash_segments_f_d.FD_NAME == 'dashsegments'
    assert dash_segments_f_d.real_download() == False


# Generated at 2022-06-26 11:04:03.506976
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()
    # Test for constructor
    eq_(DashSegmentsFD().FD_NAME, dash_segments_f_d_0.FD_NAME)
    dash_segments_f_d_0.to_screen()
    # Test for method to_screen
    dash_segments_f_d_0.to_screen()
    # Test for method report_warning
    dash_segments_f_d_0.report_warning()
    # Test for method report_error
    dash_segments_f_d_0.report_error()
    # Test for method report_retry_fragment
    dash_segments_f_d_0.report_retry_fragment("")
    # Test for method report_skip_fragment
    dash

# Generated at 2022-06-26 11:04:05.221401
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()


# Generated at 2022-06-26 11:04:06.752295
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d = DashSegmentsFD()

# Generated at 2022-06-26 11:04:20.299766
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_fd_0 = DashSegmentsFD('login', '--merge-output-format=mkv')


# Generated at 2022-06-26 11:04:22.577718
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('test_DashSegmentsFD_real_download')

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:32.057718
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b"\xec\xc7\x8b\xc7\x9e\x9c\x84'\xa5\xfef\x9a\xed\x81Y\x17\xb5Y"
    int_0 = -1856
    tuple_0 = ()
    str_0 = 'Cq}~=."R'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    var_0 = dash_segments_f_d_0.real_download(bytes_0, int_0)
    # Test attribute 'FD_NAME'
    assert DashSegmentsFD.FD_NAME == 'dashsegments'


# Generated at 2022-06-26 11:04:35.604821
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:38.755775
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    params = {'retries': '1'}
    dash_segments_fd = DashSegmentsFD(params, 'youtube')
    assert dash_segments_fd.params == params, 'Test Failed'
    assert dash_segments_fd.params['retries'] == '1', 'Test Failed'


# Generated at 2022-06-26 11:04:40.924931
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    normal_case_0()
    corner_case_0()


# Generated at 2022-06-26 11:04:42.537330
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:51.793297
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b"\xec\xc7\x8b\xc7\x9e\x9c\x84'\xa5\xfef\x9a\xed\x81Y\x17\xb5Y"
    int_0 = -1856
    tuple_0 = ()
    str_0 = 'Cq}~=."R'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    var_0 = dash_segments_f_d_0.real_download(bytes_0, int_0)

# Generated at 2022-06-26 11:04:52.448172
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:05:02.013538
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Setup
    bytes_0 = b"\xec\xc7\x8b\xc7\x9e\x9c\x84'\xa5\xfef\x9a\xed\x81Y\x17\xb5Y"
    int_0 = -1856
    tuple_0 = ()
    str_0 = 'Cq}~=."R'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)

    # Invocation
    var_0 = dash_segments_f_d_0.real_download(bytes_0, int_0)

    # Verification
    assert not var_0

# Generated at 2022-06-26 11:05:23.472382
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b"\xec\xc7\x8b\xc7\x9e\x9c\x84'\xa5\xfef\x9a\xed\x81Y\x17\xb5Y"
    int_0 = -1856
    tuple_0 = ()
    str_0 = 'Cq}~=."R'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    var_0 = dash_segments_f_d_0.real_download(bytes_0, int_0)


# Generated at 2022-06-26 11:05:26.922956
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
    except:
        print("Caught exception while testing real_download()")


# Generated at 2022-06-26 11:05:29.263250
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    for i in range(100):
        test_case_0()


# Generated at 2022-06-26 11:05:32.806736
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Executing test_DashSegmentsFD_real_download')
    test_case_0()
    print('Executed test_DashSegmentsFD_real_download')

if __name__ == "__main__":
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:34.439166
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:05:36.624184
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    print("Test complete!")


# Generated at 2022-06-26 11:05:39.901428
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == True


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:41.258920
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:47.666780
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0_1 = b'0\x8fZ\t\xb2\x1f\x8e\xe3\x95\x1d\x9b\x8bM\xfc\x04R'
    bytes_0_2 = b'\x92\x85\xd9\x8c`\xa0\x95L\xaf\xd0\xc6\xde\xbcO\x9a\x8c'
    bytes_0 = bytes_0_2 * bytes_0_1
    str_0 = 'DsX\xed\x01\x88\x89\xd4\x8d\x12`\x96\x85\x83'
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, str_0)
    test

# Generated at 2022-06-26 11:05:55.474326
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b"\xec\xc7\x8b\xc7\x9e\x9c\x84'\xa5\xfef\x9a\xed\x81Y\x17\xb5Y"
    int_0 = -1856
    tuple_0 = ()
    str_0 = 'Cq}~=."R'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    assert dash_segments_f_d_0.params == {}


# Generated at 2022-06-26 11:06:20.479202
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:06:23.630180
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    s = 'Cq}~=."R'
    #check the constructor
    assert DashSegmentsFD((), s)
    assert DashSegmentsFD((), s).FD_NAME == 'dashsegments'

# Generated at 2022-06-26 11:06:31.870864
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Create a DashSegmentsFD object using the default parameters
    dash_segments_f_d = DashSegmentsFD()

    # Test that the "real_download" method returns false
    assert not dash_segments_f_d.real_download(None, None)

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:33.165139
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:06:37.940787
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Testing real_download')
    test_case_0()
    print('Passed!')

if __name__ == "__main__":
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:43.529601
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b'\x84'
    int_0 = -1477
    tuple_0 = ()
    str_0 = '@k'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    dash_segments_f_d_0


# Generated at 2022-06-26 11:06:49.136801
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0.fd_name == 'dashsegments'


# Generated at 2022-06-26 11:06:56.241643
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    str_0 = '$Lwj^W\x93y\x9c'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    dash_segments_f_d_0.real_download(b'Ks\x03\xe4\x8a\xfc\xcb\xff\x1e\x8f\r', -2746)


# Generated at 2022-06-26 11:07:06.974189
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b"\xec\xc7\x8b\xc7\x9e\x9c\x84'\xa5\xfef\x9a\xed\x81Y\x17\xb5Y"
    int_0 = -1856
    tuple_0 = ()
    str_0 = 'Cq}~=."R'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    dash_segments_f_d_0.real_download(bytes_0, int_0)


# Generated at 2022-06-26 11:07:13.791379
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-26 11:07:59.800324
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:08:03.687063
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = DashSegmentsFD()
    var_0.real_download()


# Generated at 2022-06-26 11:08:09.746846
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    set_0 = None
    download_error_0 = module_0.DownloadError(dict_0, set_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, dict_0)

# Generated at 2022-06-26 11:08:21.388464
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    set_0 = None
    download_error_0 = module_0.DownloadError(dict_0, set_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, dict_0)
    assert not dash_segments_f_d_0.real_download(set_0, dict_0)

if __name__ == '__main__':
    test_case_0()

    # assert not dash_segments_f_d_0.real_download(set_0, dict_0)
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:26.172392
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Global tests and constants
tests = [test_DashSegmentsFD_real_download]

if __name__ == '__main__':
    for test in tests:
        test()

# Generated at 2022-06-26 11:08:32.848910
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    set_0 = None
    download_error_0 = module_0.DownloadError(dict_0, set_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(set_0, dict_0)

# Generated at 2022-06-26 11:08:44.790702
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dict_0['fragments'] = [{'url': '', 'path': 'http://aisvn.com/wp-content/uploads/2019/08/hello-world.jpg'}]
    dict_0['fragment_base_url'] = 'https://www.w3schools.com'
    set_0 = 'abcd'
    download_error_0 = module_0.DownloadError(dict_0, set_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(set_0, dict_0)

# Generated at 2022-06-26 11:08:47.479255
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    ret = test_case_0()
    assert (ret == True)

# Generated at 2022-06-26 11:08:49.107122
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    
    assert test_case_0()

# Generated at 2022-06-26 11:08:55.246028
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    set_0 = None
    download_error_0 = module_0.DownloadError(dict_0, set_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(set_0, dict_0)


# Generated at 2022-06-26 11:09:49.714421
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:09:59.105811
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_0 = {}
    download_error_0 = module_0.DownloadError(var_0, var_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, var_0)
    var_1 = dash_segments_f_d_0.real_download(var_0, var_0)
    assert type(dash_segments_f_d_0.FD_NAME) == str
    assert type(var_1) == bool

import youtube_dl.utils as module_1


# Generated at 2022-06-26 11:10:11.514318
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Instantiation of object
    var_0 = {}
    download_error_0 = module_0.DownloadError(var_0, var_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, var_0)
    # Testing of method real_download
    # TypeError raised: cannot unpack non-iterable NoneType object
    # Number of assertions: 3, 0 passed, 3 failed, 0 dubious, 0 skipped, 0 ignored
    # Remaining test cases
    dash_segments_f_d_0.real_download(var_0, var_0)

if __name__ == '__main__':
    # Execute the tests
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:15.251505
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = {}
    download_error_0 = module_0.DownloadError(var_0, var_0)
    # dash_segments_f_d_0 = DashSegmentsFD(download_error_0, var_0)
    # dash_segments_f_d_0.real_download(var_0, var_0)


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:26.507079
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_2 = {}
    download_error_1 = module_0.DownloadError(var_2, var_2)
    dash_segments_f_d_1 = DashSegmentsFD(download_error_1, var_2)
    var_3 = 0
    var_4 = {}
    var_5 = -1
    var_6 = True
    var_7 = True
    var_8 = True
    var_9 = True
    var_10 = True
    var_11 = 3
    var_12 = True
    var_13 = True
    var_14 = False
    var_15 = [var_6, var_7, var_8, var_9, var_10]
    var_16 = 0
    var_17 = 0
    var_18 = 0
    var_19 = var_16

# Generated at 2022-06-26 11:10:33.480934
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = {}
    download_error_0 = module_0.DownloadError(var_0, var_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, var_0)
    var_1 = dash_segments_f_d_0.real_download(var_0, var_0)


# Generated at 2022-06-26 11:10:37.716676
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_1 = {}
    download_error_0 = module_0.DownloadError(var_1, var_1)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, var_1)
    var_2 = dash_segments_f_d_0.real_download(var_1, var_1)


# Generated at 2022-06-26 11:10:45.760592
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_2 = {}
    download_error_1 = module_0.DownloadError(var_2, var_2)
    dash_segments_f_d_1 = DashSegmentsFD(download_error_1, var_2)
    var_3 = dash_segments_f_d_1.real_download(var_2, var_2)
    assert var_3 == False


# Generated at 2022-06-26 11:10:50.940966
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    exception_0 = False
    try:
        test_case_0()
    except:
        exception_0 = True
    assert not exception_0


# Generated at 2022-06-26 11:10:59.476866
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = {}
    download_error_0 = module_0.DownloadError(var_0, var_0)
    dash_segments_f_d_0 = DashSegmentsFD(download_error_0, var_0)
    assert dash_segments_f_d_0.report_skip_fragment(var_0) == None
    assert dash_segments_f_d_0.report_error(var_0) == None
    assert dash_segments_f_d_0.report_retry_fragment(var_0, var_0, var_0, var_0) == None


# Generated at 2022-06-26 11:12:47.698658
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert isinstance(dash_segments_f_d_0, DashSegmentsFD)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'
