

# Generated at 2022-06-26 11:02:54.640143
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:02:55.672933
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD(tuple_0,str_0)



# Generated at 2022-06-26 11:03:06.196695
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ('test_case_0',)
    str_0 = 'test_case_0'
    str_1 = 'test_case_0'
    str_2 = 'test_case_0'
    str_3 = 'test_case_0'
    str_4 = 'test_case_0'
    str_5 = 'test_case_0'
    str_6 = 'test_case_0'
    str_7 = 'test_case_0'
    str_8 = 'test_case_0'
    str_9 = 'test_case_0'
    str_10 = 'test_case_0'
    str_11 = 'test_case_0'
    str_12 = 'test_case_0'
    str_13 = 'test_case_0'
    str_

# Generated at 2022-06-26 11:03:09.484597
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = ()
    str_0 = '2K2t/"&#];j-o#0U'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)

    # Invoke method
    result_0 = dash_segments_f_d_0.real_download()

# Generated at 2022-06-26 11:03:11.237601
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass



# Generated at 2022-06-26 11:03:15.168861
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    str_0 = '2K2t/"&#];j-o#0U'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)



# Generated at 2022-06-26 11:03:22.942487
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = ()
    str_0 = '2K2t/"&#];j-o#0U'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    str_1 = './temp/Test-FragmentFD-real_download'

    try:
        dash_segments_f_d_0.real_download(str_1, None)
    except:
        pass
    else:
        assert False


# Generated at 2022-06-26 11:03:26.949576
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    str_0 = '|^R;{e)`5rDxKG'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)

# Generated at 2022-06-26 11:03:33.216083
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = ()
    str_0 = '`"u"7F&$4U+'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, str_0)
    str_0 = '0m0'
    dict_0 = {'x': 68, 'fragment_base_url': '?'}
    dash_segments_f_d_0.real_download(str_0, dict_0)
    # Should throw an error

# Generated at 2022-06-26 11:03:41.018727
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = dict()
    str_0 = str()
    bool_0 = bool()
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, str_0, bool_0)
    unicode_0 = unicode()
    dict_0 = dict()
    bool_0 = bool()
    dash_segments_f_d_0.real_download(unicode_0, dict_0, bool_0)


# Generated at 2022-06-26 11:03:50.420961
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:51.777411
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print("test_DashSegmentsFD")


# Generated at 2022-06-26 11:03:52.936793
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:54.163188
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:02.076917
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, dict_0)


# Generated at 2022-06-26 11:04:03.106578
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:16.829711
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, dict_0)
    dict_1 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_1 = DashSegmentsFD(bool_0, dict_1)
    var_1 = dash_segments_f_d_1.real_download(bool_0, dict_1)
    dict_2 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_2 = Dash

# Generated at 2022-06-26 11:04:18.127672
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:20.811615
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # test case 0
    test_case_0()


if __name__ == '__main__':
    # Unit test #0
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:24.738302
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, dict_0)
    assert not var_0

# Generated at 2022-06-26 11:04:37.076588
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    return dash_segments_f_d_0


# Generated at 2022-06-26 11:04:50.820748
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    bool_1 = dash_segments_f_d_0.real_download(bool_0, dict_0) # change bool_0 to filename
    int_0 = dash_segments_f_d_0.__len__()
    str_0 = dash_segments_f_d_0.__str__()
    str_1 = dash_segments_f_d_0.__unicode__()
    str_2 = dash_segments_f_d_0.__repr__()
    dash_segments_f_d_0.close()
    bool_2 = dash_segments_f_d_0.closed
    hash_0

# Generated at 2022-06-26 11:04:53.204009
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:55.958513
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # test case that 'fragment_downloader' is initialized
    test_case_0()


# Generated at 2022-06-26 11:04:57.421315
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Possible cases
    test_case_0()

# Generated at 2022-06-26 11:05:04.640688
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = False
    string_0 = "&`s3`d"
    string_1 = "ln+Szm"
    string_2 = "J$p;{II-."
    array_0 = [string_1, string_2, string_0]
    array_1 = [string_0, string_1, string_0]
    array_2 = [string_1, string_0, string_2]
    array_3 = [string_2, string_1, string_1]
    array_4 = [string_0, string_0, string_0]
    array_5 = [array_0, array_1, array_2, array_3, array_4]
    array_6 = [string_0, string_2, string_1]

# Generated at 2022-06-26 11:05:07.310626
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:10.213953
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print (">>>")
    test_case_0()
    print ("<<<")

if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:14.364501
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:20.825654
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    assert dash_segments_f_d_0.real_download(bool_0, dict_0)


# Generated at 2022-06-26 11:05:34.930993
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:38.247874
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:42.249763
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    x_0 = True
    x_1 = {x_0: x_0, x_0: x_0}
    test_case_0()
if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:43.717661
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:05:49.014393
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(False, dict_0)
    assert dash_segments_f_d_0.params == dict_0

# Generated at 2022-06-26 11:05:52.808794
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        test_case_0()
        return False
    except AssertionError:
        return True

if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:55.405306
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:57.300401
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# add more test cases here...


# Generated at 2022-06-26 11:05:58.556334
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    ydl = YouTubeDL()


# Generated at 2022-06-26 11:06:01.856692
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_fd_0 = DashSegmentsFD(False, {False: False, False: False})
    dash_segments_fd_0.real_download(False, {False: False, False: False})

# Generated at 2022-06-26 11:06:35.972834
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = bool()
    bool_1 = bool()
    bool_2 = bool()
    bool_3 = bool()
    bool_4 = bool()
    bool_5 = bool()
    bool_6 = bool()
    bool_7 = bool()
    bool_8 = bool()
    bool_9 = bool()
    bool_10 = bool()
    bool_11 = bool()
    bool_12 = bool()
    bool_13 = bool()
    bool_14 = bool()
    bool_15 = bool()
    bool_16 = bool()
    bool_17 = bool()
    bool_18 = bool()
    bool_19 = bool()
    bool_20 = bool()
    bool_21 = bool()
    bool_22 = bool()
    bool_23 = bool()
    bool_24 = bool()

# Generated at 2022-06-26 11:06:41.568173
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Testing constructor of class DashSegmentsFD')
    test_case_0()
    print('Finished testing constructor of class DashSegmentsFD')

# Unit tests for DashSegmentsFD
if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:06:46.789669
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:49.770895
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    print("Unit test for method real_download of class DashSegmentsFD")

test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:56.278617
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print("Unit test for constructor of class DashSegmentsFD")
    bool_0 = True
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    bool_0 = False
    dash_segments_f_d_0.real_download(bool_0, dict_0)


# Generated at 2022-06-26 11:06:59.725874
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:07:01.990013
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD.__init__(bool_0, dict_0)

# Generated at 2022-06-26 11:07:05.245532
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_1 = True
    dash_segments_f_d_0 = DashSegmentsFD(bool_1, None)


# Generated at 2022-06-26 11:07:08.249480
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_dash_segments_fd_real_download_0()
    test_dash_segments_fd_real_download_1()


# Generated at 2022-06-26 11:07:10.838485
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:58.136904
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:01.711258
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .common import global_state_basic, playlist_result_basic
    state = global_state_basic
    playlist = playlist_result_basic['urls']
    true = True
    dash_segments_f_d = DashSegmentsFD(state, playlist)

# Generated at 2022-06-26 11:08:03.909122
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:08:08.883521
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    # Unit test for method real_download of class DashSegmentsFD
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:12.710933
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
    except:
        raise Exception("Test failed")
    else:
        pass

# Generated at 2022-06-26 11:08:22.582637
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = False
    dict_0 = {bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, dict_0)
    # assert var_0 == True
    if not var_0:
        test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:28.265355
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    dash_segments_f_d_1 = DashSegmentsFD(False, {True: True, True: True})
    var_1 = dash_segments_f_d_1.real_download(False, {True: True, True: True})

# Generated at 2022-06-26 11:08:30.746721
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # test 1 method
    print('Testing DashSegmentsFD, method real_download')
    test_case_0()

# Generated at 2022-06-26 11:08:38.381936
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_1 = True
    # {'ext': 'webm', 'protocol': 'm3u8_native',
    #   'fragment_base_url': 'https://manifest.googlevideo.com/api/manifest/hls_playlist/expire/1565272322/ei/cE9UXa2sLsjqyAPblaS4AQ/ip/2a00:1450:4014:80d::2004/aitags/133,134,135/source/yt_live_broadcast/requiressl/yes/ratebypass/yes/goi/160/sgoap/gir%3Dyes%3Bitag%3D137%3Blive%3D1%3Bratebypass%3Dyes%3Bcmbypass%3Dyes%3Bipbits

# Generated at 2022-06-26 11:08:39.901051
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:10:13.293540
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, bool_0)

# Generated at 2022-06-26 11:10:21.146775
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD
    from ..compat import compat_urllib_error
    from ..utils import (
        DownloadError,
        urljoin,
    )
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)
    dash_segments_f_d_0.real_download(bool_0, bool_0)


test_case_0()

# Generated at 2022-06-26 11:10:24.083290
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:27.683299
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)


# Generated at 2022-06-26 11:10:29.159341
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:10:30.113730
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    return

# Generated at 2022-06-26 11:10:33.037580
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:10:35.439134
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)
    # Test method DashSegmentsFD.real_download
    test_case_0()

# Generated at 2022-06-26 11:10:38.153187
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_fd_instance = DashSegmentsFD({})
    assert dash_segments_fd_instance is not None

# Generated at 2022-06-26 11:10:44.328325
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, bool_0)




# Generated at 2022-06-26 11:12:32.852523
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, bool_0)

# Generated at 2022-06-26 11:12:39.368538
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        str_0 = '''Downloading just video 
        format code: 141 ,ext: m4a, height: null, width: null, fps: null, vcodec: null, acodec: aac, abr: 128k, filesize: null, container: null
        '''
        dash_segments_f_d_0 = DashSegmentsFD(bool(str_0), bool(str_0))
    except Exception:
        pass
    try:
        dash_segments_f_d_0 = DashSegmentsFD(bool(), bool())
    except Exception:
        pass


# Generated at 2022-06-26 11:12:49.588856
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(var_0, var_0)
    dash_segments_f_d_0.stderr = var_0
    dash_segments_f_d_0.report_skip_fragment(0)

    var_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(var_0, var_0)
    dash_segments_f_d_0.stderr = var_0
    dash_segments_f_d_0.report_retry_fragment(0, 0, 0, 0)