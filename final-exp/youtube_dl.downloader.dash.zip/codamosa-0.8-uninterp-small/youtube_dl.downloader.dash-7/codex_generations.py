

# Generated at 2022-06-26 11:02:54.408021
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:02:59.730569
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 1477
    list_0 = [int_0, int_0]
    str_0 = "filename"
    dict_0 = {str_0: str_0}
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)
    dash_segments_f_d_0.real_download(str_0, dict_0)


# Generated at 2022-06-26 11:03:08.801291
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD
    from ..compat import compat_urllib_error
    from ..utils import (
        DownloadError,
        urljoin,
    )
    class MockInfoDict():
        def __init__(self):
            self.get = lambda *args: None
    class MockFragmentFD(FragmentFD):
        def __init__(self):
            self.params = {'fragment_retries': 0}
        def _download_fragment(self, *args):
            return [True, None]
        def _append_fragment(self, *args):
            pass
        def _prepare_and_start_frag_download(self, *args):
            pass
        def _finish_frag_download(self, *args):
            pass

# Generated at 2022-06-26 11:03:11.242341
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-26 11:03:23.096952
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    list_0 = [1, 2, 3, 4, 5]
    dict_0 = {
        "total_frags": 4,
        "filename": "/tmp/youtube_Ce8VVoX9z1c",
        "fragment_count": 1,
        "fragment_index": 1,
        "tmpfilename": "/tmp/youtube_Ce8VVoX9z1c.part"
    }
    fragment_base_url_0 = "www.youtube.com"

# Generated at 2022-06-26 11:03:24.971286
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Unit tests for test_case_0()

# Generated at 2022-06-26 11:03:29.301590
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD('', '')
    dash_segments_f_d_0.real_download('', '')
    dash_segments_f_d_0.report_skip_fragment(1)

# Generated at 2022-06-26 11:03:30.480041
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert callable(DashSegmentsFD)

# Generated at 2022-06-26 11:03:43.850574
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 1477
    list_0 = [int_0, int_0]
    string_0 = 'Km'
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)
    string_1 = "/XMLSchema-instance' xsi:noNamespaceSchemaLocation='urn:mpeg:dash:schema:mpd:2011' profiles='urn:mpeg:dash:profile:isoff-on-demand:2011'"
    string_2 = 'en-US'
    string_3 = 'dash_xml'
    string_4 = 'http://www.w3.org/2001/XMLSchema-instance'
    string_5 = 'http://dashif.org/guidelines/dash264'
    string_6 = 'dash264'

# Generated at 2022-06-26 11:03:50.959407
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print("")
    config = {
        'fragment_retries': 0,
        'skip_unavailable_fragments': True,
        'test': False,
    }
    int_0 = 1477
    list_0 = [int_0, int_0]
    str_0 = 'filename'
    int_1 = 1
    dict_0 = {'filepath': str_0, 'fragments': list_0, 'total_frags': int_1}
    # DashSegmentsFD(fragment_data, params)
    dash_segments_f_d_0 = DashSegmentsFD(list_0, config)

    # StreamFD.real_download(filename, info_dict)
    dash_segments_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:03:59.946371
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:04:04.857974
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '20180605'
    int_0 = 1323417600
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    # Test for real_download method
    test_case_0()


# Generated at 2022-06-26 11:04:11.236808
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_1 = '20180605'
    int_1 = 1323417600
    dict_1 = {}
    dash_segments_f_d_1 = DashSegmentsFD(int_1, dict_1)
#    print dash_segments_f_d_1
#test_DashSegmentsFD()


# Generated at 2022-06-26 11:04:12.444809
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:14.580439
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:17.253650
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_1 = {}
    int_1 = 0
    dash_segments_f_d_1 = DashSegmentsFD(int_1, dict_1)


# Generated at 2022-06-26 11:04:20.375566
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(0, dict_0)

test_DashSegmentsFD()
test_case_0()

# Generated at 2022-06-26 11:04:21.553979
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert dash_segments_f_d_0.real_download(str_0, str_0) == True

# Generated at 2022-06-26 11:04:22.409603
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:04:23.251455
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:04:40.967029
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'

    dict_1 = {}
    dash_segments_f_d_1 = DashSegmentsFD(dict_1, dict_1)
    assert dash_segments_f_d_1.FD_NAME == 'dashsegments'

    dict_2 = {}
    dash_segments_f_d_2 = DashSegmentsFD(dict_2, dict_2)
    assert dash_segments_f_d_2.FD_NAME == 'dashsegments'

    dict_3 = {}

# Generated at 2022-06-26 11:04:48.283751
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '20180605'
    int_0 = 1323417600
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:04:54.202705
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 1419344000
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)

test_case_0()
test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:01.153834
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert (
        DashSegmentsFD(
            int_0=TestRunner.int_0,
            str_0=TestRunner.str_0,
            bool_0=TestRunner.bool_0,
            list_0=TestRunner.list_0,
            dict_0=TestRunner.dict_0,
            tuple_0=TestRunner.tuple_0,
            none_0=TestRunner.none_0,
        ) == None
    )



# Generated at 2022-06-26 11:05:04.461067
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:05.866302
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:05:07.312781
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:05:08.804215
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:11.020538
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0)
    # Need to add assertion here


# Generated at 2022-06-26 11:05:13.247476
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:05:38.773014
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Testing for 0
    test_case_0()

# Generated at 2022-06-26 11:05:40.879565
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 0
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    str_0 = '20180605'
    var_0 = dash_segments_f_d_0.real_download(str_0, str_0)


# Generated at 2022-06-26 11:05:45.601770
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 596290080
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)

# Generated at 2022-06-26 11:05:49.644611
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:52.154678
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(0, {})


# Generated at 2022-06-26 11:05:53.473172
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:05:55.543226
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:05:56.921756
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:06:00.674033
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '20180605'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    test_case_0()

# Generated at 2022-06-26 11:06:05.922054
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        # Test method real_download
        test_case_0()

        return "Test succeeded"
    except AssertionError as err:
        return "Test failed: " + str(err)
    except Exception as e:
        return "Test failed from exception: " + str(e)


# Generated at 2022-06-26 11:07:00.930089
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Testing DashSegmentsFD::real_download')
    test_case_0()
    test_case_1()
    test_case_2()
    test_case_3()
    test_case_4()
    test_case_5()
    test_case_6()
    test_case_7()
    test_case_8()
    test_case_9()


# Generated at 2022-06-26 11:07:05.334706
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
    except:
        print('Exception:')


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:07:08.304162
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:07:19.797979
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 10760
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    int_0 = 19416
    dict_0 = {}
    dash_segments_f_d_1 = DashSegmentsFD(int_0, dict_0)
    int_0 = 10784
    dict_0 = {}
    dash_segments_f_d_2 = DashSegmentsFD(int_0, dict_0)
    int_0 = 20390
    dict_0 = {}
    dash_segments_f_d_3 = DashSegmentsFD(int_0, dict_0)
    int_0 = 5805
    dict_0 = {}

# Generated at 2022-06-26 11:07:22.605111
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:07:24.459692
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(1323417600, dict_0)


# Generated at 2022-06-26 11:07:25.868766
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:07:27.123996
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:07:36.815869
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    int_0 = 1323417600
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    str_0 = '20180605'
    var_0 = dash_segments_f_d_0.real_download(str_0,  str_0)
    assert var_0 == True
    return

test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:42.502301
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    info_dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(info_dict_0, info_dict_0)

test_case_0()

# Generated at 2022-06-26 11:09:28.701843
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '20180605'
    int_0 = 1323417600
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    assert dash_segments_f_d_0.fragment_index == 0
    assert dash_segments_f_d_0.state == None
    assert dash_segments_f_d_0.next_frag_index == 0
    assert dash_segments_f_d_0.out_fd == None
    assert dash_segments_f_d_0.frag_progress_hooks == []
    assert dash_segments_f_d_0.frag_downloaded == 0
    assert dash_segments_f_d_0.retries == 0

# Unit test

# Generated at 2022-06-26 11:09:31.821412
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Indirect test for constructor of class DashSegmentsFD

# Generated at 2022-06-26 11:09:33.871899
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print("Constructor of class DashSegmentsFD")
    test_case_0()

# Generated at 2022-06-26 11:09:36.600029
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = DashSegmentsFD(1, {})

    assert isinstance(var_0, DashSegmentsFD), "var_0 should be instance of DashSegmentsFD"

# Generated at 2022-06-26 11:09:42.923804
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    value = 'filename'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, value)
    var_0 = dash_segments_f_d_0.real_download(value, dict_0)


# Generated at 2022-06-26 11:09:47.137531
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:09:51.378815
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == True
    print("PASSED: " + "test_DashSegmentsFD_real_download")

# Generated at 2022-06-26 11:09:55.899038
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 60
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)


# Generated at 2022-06-26 11:10:01.083571
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(0, {})
    str_0 = '20180605'
    int_0 = 1323417600
    dict_0 = {}
    dash_segments_f_d_0.real_download(str_0, int_0)
    dash_segments_f_d_0.real_download(str_0, dict_0)


# Generated at 2022-06-26 11:10:02.174618
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()