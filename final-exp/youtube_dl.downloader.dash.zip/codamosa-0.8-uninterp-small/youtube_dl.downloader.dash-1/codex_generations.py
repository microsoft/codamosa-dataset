

# Generated at 2022-06-26 11:03:05.044836
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 187
    int_1 = 651
    bytes_0 = b'\x92\xb3\x7a'
    bytes_1 = b'\x05\xb7\x1c'
    bytes_2 = b'\x5a\x5d\x95'
    bytes_3 = b'\x00\x21\x6a'
    dict_0 = {'path': bytes_0, 'url': bytes_1, 'string': bytes_2, 'byte': bytes_3, 'expires': '\n'}

# Generated at 2022-06-26 11:03:11.668607
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 22
    bytes_1 = b'\x15\x18\xad'
    frag_url_0 = 'https://www.youtube.com/watch?v=0vxOhd4qlnA'
    dash_segments_f_d_1 = DashSegmentsFD(int_0, bytes_1)
    info_dict_0 = {
        'title': '',
        '_filename': 'Basshunter-Every-Morning.mp4',
        'fragments': [
            {
                'duration': 1,
                'path': '0vxOhd4qlnA_0.1.ts'
            }
        ]
    }
    assert dash_segments_f_d_1.real_download('Basshunter-Every-Morning.mp4', info_dict_0)

# Generated at 2022-06-26 11:03:13.643368
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:15.517376
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:20.863345
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    filename = 'fake.mp4'
    info_dict = {}
    dash_segments_f_d_0 = DashSegmentsFD(None, None)
    dash_segments_f_d_0.real_download(filename, info_dict)


# Generated at 2022-06-26 11:03:24.122409
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 378
    bytes_0 = b'\x07\x8c\xe7'
    dash_segments_f_d_0 = DashSegmentsFD(int_0, bytes_0)


# Generated at 2022-06-26 11:03:25.359940
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

test_case_0()

# Generated at 2022-06-26 11:03:28.430021
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()
    print('All unit cases of class DashSegmentsFD passed!')

# Generated at 2022-06-26 11:03:29.843356
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    global test_case_0
    test_case_0()

# Generated at 2022-06-26 11:03:36.823524
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_9 = 24
    int_10 = 4
    int_11 = 240
    int_12 = 240
    int_13 = 3
    
    if int_12 == int_13:
        dash_segments_f_d_5 = DashSegmentsFD(int_9, int_10)
        dash_segments_f_d_6 = DashSegmentsFD(int_9, int_10)
        int_14 = 21
        
        if int_11 == int_14:
            bytes_3 = b'\x1a'
            int_15 = 12
            float_0 = float_0
            
            if float_0 == float_0:
                dash_segments_f_d_7 = DashSegmentsFD(int_11, bytes_3)
                dash_segments_f_d_8

# Generated at 2022-06-26 11:03:53.522087
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    float_0 = 2427.41
    dash_segments_f_d_0 = None
    list_0 = [float_0, float_0, dash_segments_f_d_0, tuple_0]
    int_0 = 1459850243
    list_1 = [int_0, int_0, int_0]
    dash_segments_f_d_1 = DashSegmentsFD(int_0, list_1)
    dash_segments_f_d_1.real_download(tuple_0, list_0)


# Generated at 2022-06-26 11:04:08.259104
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    float_0 = 2427.41
    dash_segments_f_d_0 = None
    list_0 = [float_0, float_0, dash_segments_f_d_0, tuple_0]
    int_0 = 1459850243
    list_1 = [int_0, int_0, int_0]
    dash_segments_f_d_1 = DashSegmentsFD(int_0, list_1)
    tuple_1 = (int_0, )
    float_1 = 255.96875
    str_0 = 'PTi-1.frag'
    int_1 = 178
    float_2 = 155.9375
    tuple_2 = (int_1, str_0, float_2)

# Generated at 2022-06-26 11:04:11.807437
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(2427.41, 1459850243)
    assert (dash_segments_f_d_0.FD_NAME == 'dashsegments')

# Generated at 2022-06-26 11:04:19.287787
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    float_0 = 2427.41
    dash_segments_f_d_0 = None
    list_0 = [float_0, float_0, dash_segments_f_d_0, tuple_0]
    int_0 = 1459850243
    list_1 = [int_0, int_0, int_0]
    dash_segments_f_d_1 = DashSegmentsFD(int_0, list_1)
    tuple_1 = ()
    float_1 = 185.377
    dash_segments_f_d_2 = None
    list_2 = [float_1, float_1, dash_segments_f_d_2, tuple_1]
    int_1 = -7

# Generated at 2022-06-26 11:04:20.255439
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:21.182276
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:22.076499
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:04:27.742841
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    float_0 = 855.4906662139
    dash_segments_f_d_0 = None
    list_0 = [float_0, float_0, dash_segments_f_d_0, tuple_0]
    int_0 = -1369164242
    long_0 = -410565793545143488
    int_1 = -8727
    list_1 = [long_0, int_1, int_0]
    dash_segments_f_d_1 = DashSegmentsFD(int_0, list_1)
    var_0 = dash_segments_f_d_1.real_download(tuple_0, list_0)

# Generated at 2022-06-26 11:04:30.699415
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:33.421251
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    pass

# Generated at 2022-06-26 11:04:54.827061
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {'\x00': '\x00'}
    dict_1 = {'\x00': '\x00'}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_1)

    # test method real_download
    dict_0 = {'\x00': '\x00'}
    bool_0 = False
    dash_segments_f_d_0.real_download(bool_0, dict_0)



# Generated at 2022-06-26 11:04:58.070371
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)


# Generated at 2022-06-26 11:04:59.799105
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:00.631778
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:05:02.377128
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:04.314896
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:08.806196
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # test_case_0
    assert test_case_0() == None, "test_case_0()"

DashSegmentsFD.real_download = test_DashSegmentsFD_real_download


# Generated at 2022-06-26 11:05:09.750772
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0()

# Generated at 2022-06-26 11:05:23.242026
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:05:33.107847
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = False
    list_0 = [bool_0]
    dict_0 = {bool_0: bool_0, bool_0: list_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    #assert (dash_segments_f_d_0.FD_NAME == 'dashsegments')
    var_0 = dash_segments_f_d_0.real_download(bool_0, dict_0)
    #assert (var_0 == True)


# Generated at 2022-06-26 11:05:45.214297
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
  assert type(test_case_0()) == bool

# Generated at 2022-06-26 11:05:46.750427
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert callable(DashSegmentsFD.real_download)

# Generated at 2022-06-26 11:05:48.741208
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test exception in constructor if fragment_base_url is not set
    dict_0 = {}
    assert DashSegmentsFD(dict_0, dict_0)
    dict_0 = {'fragment_base_url': 'url'}
    assert DashSegmentsFD(dict_0, dict_0)


# Generated at 2022-06-26 11:05:50.341831
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:58.081267
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = False
    list_0 = [bool_0]
    dict_0 = {bool_0: bool_0, bool_0: list_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    dash_segments_f_d_0.to_screen(bool_0)
    dash_segments_f_d_0.report_error(bool_0)
    dash_segments_f_d_0.report_skip_fragment(bool_0)
    dash_segments_f_d_0.report_retry_fragment(bool_0, bool_0, bool_0, bool_0)

# Generated at 2022-06-26 11:06:08.716252
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    list_0 = [bool_0]
    dict_0 = {bool_0: bool_0, bool_0: list_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    str_0 = dash_segments_f_d_0.FD_NAME
    if str_0 != 'dashsegments':
        raise RuntimeError()
    bool_0 = False
    list_0 = [bool_0]
    dict_0 = {bool_0: bool_0, bool_0: list_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    int_0 = dash_segments_f

# Generated at 2022-06-26 11:06:12.232640
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:15.300425
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:21.730599
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {"all"}
    dict_1 = {tuple : "L", concat : (2, )}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_1)


print(__name__)
if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:06:23.999914
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Initialization
    test_case_0()

test_classes = [
    DashSegmentsFD
]


# Generated at 2022-06-26 11:06:48.323006
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:06:51.483112
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:54.471033
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Program test for module youtube_dl/downloader/fragment.py of function DashSegmentsFD

# Generated at 2022-06-26 11:06:58.569111
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    instance_of_class_name = DashSegmentsFD
    try:
        test_case_0()
    except:
        print('Expected:' + instance_of_class_name)

# Generated at 2022-06-26 11:07:02.292439
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    bool_1 = {bool_0: bool_0, bool_0: bool_0, bool_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bool_1, bool_1)
    var_0 = dash_segments_f_d_0.real_download(bool_0, bool_1)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:05.422524
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:07:08.302839
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # test cases
    test_case_0()

if __name__ == '__main__':
    import sys
    sys.exit(0)

# Generated at 2022-06-26 11:07:09.641335
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:07:13.491091
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:07:15.440868
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0()

# Generated at 2022-06-26 11:07:59.842929
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0() == None

# Generated at 2022-06-26 11:08:01.761838
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:08:04.059209
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:08:13.506266
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    url = 'http://example.com/dash.mpd'
    data = b'''<MPD>
<Period>
    <AdaptationSet>
        <Representation id="1" mimeType="video/mp4" codecs="avc1.42001E, mp4a.40.2">
            <SegmentTemplate media="seg-$RepresentationID$-$Number%05d$.m4s" initialization="init-$RepresentationID$.mp4" />
            <BaseURL>https://dash-segments.example.com/</BaseURL>
        </Representation>
    </AdaptationSet>
</Period>
</MPD>
'''
    with open('dash.mpd', 'wb') as f:
        f.write(data)

# Generated at 2022-06-26 11:08:15.313171
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:08:22.152103
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_1 = True
    var_2 = {var_1: var_1, var_1: var_1, var_1: var_1}
    dash_segments_f_d_1 = DashSegmentsFD(var_2, var_2)
    var_3 = dash_segments_f_d_1.real_download(var_1, var_2)


# Generated at 2022-06-26 11:08:25.181957
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:26.645981
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:08:28.262343
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:08:29.718070
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:09:59.896896
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass
    # Uncomment following line to test above function
    # test_case_0()
    # Uncomment following line to test above constructor
    # test_DashSegmentsFD()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:02.222344
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:10:03.855007
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:09.042805
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)
    bool_1 = dash_segments_f_d_0.real_download(bool_0, bool_0)
    assert bool_1 == True

# Generated at 2022-06-26 11:10:15.515004
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_fd = DashSegmentsFD({}, {})
    assert dash_segments_fd.FD_NAME == 'dashsegments'
    assert dash_segments_fd.real_download({}, {}) == True

# Generated at 2022-06-26 11:10:16.016160
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:10:17.732593
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:10:20.657493
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
    except NameError as err:
        pytest.fail(f"NameError: {err}")
    except UnboundLocalError as err:
        pytest.fail(f"UnboundLocalError: {err}")

# Generated at 2022-06-26 11:10:24.005462
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    return

# Generated at 2022-06-26 11:10:30.174641
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()
    pass

# Generated at 2022-06-26 11:12:06.171081
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    # Perform a real download but only of the first fragment
    test_case_0()

# Generated at 2022-06-26 11:12:07.591240
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:12:16.487452
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # creates an instance of DashSegmentsFD using params and ydl
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)

    bool_0 = {}
    dash_segments_f_d_1 = DashSegmentsFD(bool_0, bool_0)

    # tests if the instance created is of class DashSegmentsFD
    assert isinstance(dash_segments_f_d_0, DashSegmentsFD)
    assert isinstance(dash_segments_f_d_1, DashSegmentsFD)



# Generated at 2022-06-26 11:12:28.006548
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:12:36.494128
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    global bool_0
    global var_0
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, bool_0)
    if (var_0 == True):
        print('P0 is true')
    else:
        print('P0 is false')

test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:12:38.145241
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:12:39.885111
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:12:41.645986
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:12:45.016031
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, bool_0)
