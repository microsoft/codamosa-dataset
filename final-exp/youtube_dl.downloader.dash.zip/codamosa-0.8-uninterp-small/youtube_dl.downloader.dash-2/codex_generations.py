

# Generated at 2022-06-26 11:03:00.267896
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bytes_0 = b']\xb2\xcfq\xc5\xae_'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    info_dict_0 = {'fragments': [bytes_0, bytes_0, bytes_0, bytes_0], 'url': 'http://b0.ac-images.myspacecdn.com/images01/54/m_9a0f11fb4981e302097bdf45f46c2e3a.gif'}
    bool_0 = DashSegmentsFD(bytes_0, list_0).real_download('', info_dict_0)
    assert bool_0 == True


# Generated at 2022-06-26 11:03:01.593405
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0() == True


# Generated at 2022-06-26 11:03:06.121927
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bytes_0 = b'\xb7\xc3\xcd\xb9]\xc9\xa6'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, list_0)

# Generated at 2022-06-26 11:03:07.884209
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    return



# Generated at 2022-06-26 11:03:13.503912
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Testing constructor of class DashSegmentsFD')
    test_case_0()

# Testing with pytest

# Generated at 2022-06-26 11:03:15.727140
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:03:21.165611
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test for __init__(self, ie_key, fragments)
    # Test for __init__(self, ie_key, fragments, params)
    # Test for __init__(self, ie_key, fragments, params, desc)
    test_case_0()


# Generated at 2022-06-26 11:03:30.437643
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    dash_segments_f_d_0.real_download('\x00\x00\x00\x00\x00\x00\x00\x00', {'fragment_base_url': '', 'fragments': [{'path': '\x00', 'url': None}, {'path': '\x00', 'url': None}, {'path': '\x00', 'url': None}, {'path': '\x00', 'url': None}]})


# Generated at 2022-06-26 11:03:38.797879
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    ctx = {}
    fragments = []
    fragment = {'url': 'https://fragment-url.com/'}
    fragments.append(fragment)
    
    info_dict = {}
    dash_segments_f_d_0 = DashSegmentsFD('', fragments)
    assert(dash_segments_f_d_0.real_download(None, info_dict) == True)

# Generated at 2022-06-26 11:03:45.310928
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test case with arguments
    bytes_0 = b'\x04$\x1c\x0e\x10l\xb3'
    list_0 = [bytes_0, bytes_0, bytes_0, bytes_0]
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, list_0)
    assert not dash_segments_f_d_0 is None

# test case for method DashSegmentsFD._finish_frag_download

# Generated at 2022-06-26 11:03:59.158153
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

test_cases = [
    test_case_0,
]

# Generated at 2022-06-26 11:04:00.366161
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:10.327326
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 1395440416
    bytes_0 = b'\xb7\xc3\xcd\xb9]\xc9\xa6'
    bytes_1 = b'\x87\xf8\xab5[B\xfd\xb8\x7f\xd3'
    list_0 = [bytes_1, bytes_1, bytes_1, bytes_1]
    dash_segments_f_d_0 = DashSegmentsFD(bytes_1, list_0)
    var_0 = dash_segments_f_d_0.real_download(int_0, bytes_0)

# Generated at 2022-06-26 11:04:13.011440
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:14.624167
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:04:15.580315
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:16.638037
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:19.442848
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:21.433918
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:24.426033
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
    except Exception as err:
        print(err)
    else:
        print('OK!')

# Generated at 2022-06-26 11:04:35.794507
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD(bytes_0, list_0)


# Generated at 2022-06-26 11:04:36.865455
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:37.634660
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:39.038433
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:04:50.344686
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 1395440416
    bytes_0 = b'\xb7\xc3\xcd\xb9]\xc9\xa6'
    bytes_1 = b'\x87\xf8\xab5[B\xfd\xb8\x7f\xd3'
    list_0 = [bytes_1, bytes_1, bytes_1, bytes_1]
    dash_segments_f_d_0 = DashSegmentsFD(bytes_1, list_0)
    var_0 = dash_segments_f_d_0.real_download(int_0, bytes_0)
    return int_0

# Generated at 2022-06-26 11:04:55.809706
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(None, None)
    var_0 = dash_segments_f_d_0.real_download(None, None)



# Generated at 2022-06-26 11:04:56.347544
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:04:57.009868
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Unit tests for class DashSegmentsFD

# Generated at 2022-06-26 11:04:57.608508
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:04:58.940588
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:05:23.847218
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -273
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    int_0 = dash_segments_f_d_0.get_total_frags()
    str_0 = dash_segments_f_d_0.get_filename()
    int_1 = dash_segments_f_d_0.real_download(str_0, dict_0)


# Generated at 2022-06-26 11:05:25.378042
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    # Test case 0
    test_case_0()

# Generated at 2022-06-26 11:05:27.644058
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # test case 0
    test_case_0()


# Generated at 2022-06-26 11:05:33.841307
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    By default, the test plan matches the name of the test function.
    You can specify a test plan by adding a "plan" attribute.
    """
    # The __tracebackhide__ setting influences pytest showing of tracebacks:
    # the mbcs module traceback will be hidden.
    __tracebackhide__ = True

    # This test runs the first time it is run.
    # Just removing the timeout setting makes it pass.
    __timeout__ = 5
    test_case_0()

# Generated at 2022-06-26 11:05:44.976986
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = -979
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    str_0 = 'P..tbEGOH'

# Generated at 2022-06-26 11:05:46.428371
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0() == True

# Generated at 2022-06-26 11:05:49.252314
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(37, {})

# Generated at 2022-06-26 11:05:52.284685
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    # Test cases is not implemented

# Test cases for class DashSegmentsFD is not implemented

# Generated at 2022-06-26 11:05:53.082675
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass



# Generated at 2022-06-26 11:05:59.294241
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():

    int_0 = -584
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'

    test_case_0()

# Generated at 2022-06-26 11:06:39.792285
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -610
    dict_0 = {int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:06:43.156432
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 11:06:56.484608
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(1, {})
    try:
        dash_segments_f_d_0.params['skip_unavailable_fragments']
    except KeyError:
        pass
    else:
        raise Exception('DashSegmentsFD test #1 failed')
    try:
        dash_segments_f_d_0.params['test']
    except KeyError:
        pass
    else:
        raise Exception('DashSegmentsFD test #2 failed')
    try:
        dash_segments_f_d_0.params['fragment_retries']
    except KeyError:
        pass
    else:
        raise Exception('DashSegmentsFD test #3 failed')


# Generated at 2022-06-26 11:06:58.290018
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    test_case_0()


if __name__ == "__main__":
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:07:00.412967
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()


# Generated at 2022-06-26 11:07:02.599013
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d = DashSegmentsFD()


# Generated at 2022-06-26 11:07:08.633659
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()
    assert type(dash_segments_f_d_0) == DashSegmentsFD


# Generated at 2022-06-26 11:07:14.807558
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -606
    dict_0 = {int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)


# Generated at 2022-06-26 11:07:16.058374
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
  assert callable(DashSegmentsFD.real_download)


# Generated at 2022-06-26 11:07:17.507761
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:08:38.670437
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
	

# Generated at 2022-06-26 11:08:48.209756
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-26 11:08:52.312595
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Create an instance of DashSegmentsFD
    # Use non-empty dictionary in dash_segments_f_d_0
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    # Use non-empty dictionary in var_0
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)

# Generated at 2022-06-26 11:08:55.074115
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    res_0 = DashSegmentsFD.real_download(dict_0, dict_0)
    if type(res_0) is bool:
        assert res_0
    else:
        assert False

# Generated at 2022-06-26 11:08:58.004432
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    assert DashSegmentsFD(dict_0, dict_0).__init__(dict_0, dict_0)

# Generated at 2022-06-26 11:09:00.578342
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:09:05.757036
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    ydl_opts = {}
    dash_segments_fd = DashSegmentsFD(ydl_opts, ydl_opts)
    assert dash_segments_fd.params == ydl_opts
    assert dash_segments_fd.ydl_opts == ydl_opts
    assert dash_segments_fd.retries == 0
    assert dash_segments_fd.continuedl == False



# Generated at 2022-06-26 11:09:08.592805
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == True

test_cases = [
    test_case_0,
]


# Generated at 2022-06-26 11:09:11.787417
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)

# Generated at 2022-06-26 11:09:17.915940
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert isinstance(dash_segments_f_d_0, DashSegmentsFD)
    assert dash_segments_f_d_0.real_download({}, {})
    assert dash_segments_f_d_0.real_download({'fragments': []}, {})
    assert dash_segments_f_d_0.real_download({'fragments': [{}]}, {})
    assert dash_segments_f_d_0.real_download({'fragments': [{'url': '', 'path': ''}]}, {})

# Generated at 2022-06-26 11:10:45.075250
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_1 = DashSegmentsFD({}, {})
    var_1 = dash_segments_f_d_1.FD_NAME
    print(var_1)
    test_case_0()

# Calling the main function
if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:53.661772
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dict_1 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_1)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

__all__ = [
    'DashSegmentsFD'
]

# Generated at 2022-06-26 11:11:01.039245
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    def real_download(self, filename, info_dict):
        fragment_base_url = info_dict.get('fragment_base_url')
        fragments = info_dict['fragments'][:1] if self.params.get('test', False) else info_dict['fragments']

        ctx = {
            'filename': filename,
            'total_frags': len(fragments),
        }

        self._prepare_and_start_frag_download(ctx)

        fragment_retries = self.params.get('fragment_retries', 0)
        skip_unavailable_fragments = self.params.get('skip_unavailable_fragments', True)

        frag_index = 0
        for i, fragment in enumerate(fragments):
            frag_index += 1


# Generated at 2022-06-26 11:11:06.338472
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {
        'is_live': True
    }
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert dash_segments_f_d_0.real_download('', dict_0) == False


# Generated at 2022-06-26 11:11:15.895814
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..YoutubeDL import YoutubeDLHandler
    from ..YoutubeDL import YoutubeDLHttpErrorProcessor

    # test case 0
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)
    assert var_0 == True
    # test case 1
    dict_1 = {}
    dash_segments_f_d_1 = DashSegmentsFD(dict_1, dict_1)
    var_1 = dash_segments_f_d_1.real_download(dict_1, dict_1)
    assert var_1 == True
    # test case 2
    dict_2 = {}

# Generated at 2022-06-26 11:11:18.588714
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:11:21.469329
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)


# Generated at 2022-06-26 11:11:33.010907
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.params
    assert var_0 == dict_0, "Mismatch in params"

    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.ydl
    assert var_0 == dict_0, "Mismatch in ydl"

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:11:34.467257
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:11:36.277784
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)

    test_case_0()