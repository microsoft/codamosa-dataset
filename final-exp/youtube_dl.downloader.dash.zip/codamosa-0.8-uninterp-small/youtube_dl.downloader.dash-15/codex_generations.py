

# Generated at 2022-06-26 11:02:55.183254
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    filename = None
    info_dict = [None]
    dash_segments_fd = DashSegmentsFD(None, None)
    expected = False
    dash_segments_fd.real_download(filename, info_dict)
    assert expected == dash_segments_fd.real_download(filename, info_dict)


# Generated at 2022-06-26 11:03:04.096763
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test case data
    filename = ''
    info_dict = {}
    # Constructing object
    dash_segments_f_d_0 = DashSegmentsFD(False, '__typename')
    # Invoking method
    dash_segments_f_d_0.real_download(filename, info_dict)
    # Verifying return type
    assert None is not type(dash_segments_f_d_0.real_download(filename, info_dict))
    # Verifying return value
    assert False is dash_segments_f_d_0.real_download(filename, info_dict)


# Generated at 2022-06-26 11:03:04.930682
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:03:06.884185
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test case 0 from original C++ code:
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:07.726591
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:03:10.870627
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = True
    str_0 = '__typename'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)
    bool_0 = dash_segments_f_d_0.real_download('bestvideo[width<=1280]', '{}')
    assert bool_0 == True

# Generated at 2022-06-26 11:03:16.127462
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = True
    str_0 = '__typename'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)
    filename = None
    info_dict = None
    dash_segments_f_d_0.real_download(filename, info_dict)

# Generated at 2022-06-26 11:03:26.537577
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD, 'Could not find the DashSegmentsFD class'
    assert isinstance(DashSegmentsFD, object), \
           'DashSegmentsFD is not an object'
    assert len(DashSegmentsFD.__abstractmethods__) == 1, \
           'There should be 1 abstract methods, but there are %d' % \
           len(DashSegmentsFD.__abstractmethods__)
    for meth in DashSegmentsFD.__abstractmethods__:
        assert meth in ('real_download'), \
               ('There is an abstract method %s, but it is not in the list' % meth)
    test_case_0()


# Generated at 2022-06-26 11:03:29.107687
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


mock_object__DashSegmentsFD = {
    'test_case_0': test_case_0,
}


# Generated at 2022-06-26 11:03:31.899102
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    str_0 = '__typename'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)


# Generated at 2022-06-26 11:03:45.545643
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD
    from .generic import GenericFD
    from .http import HttpFD
    from ..compat import compat_urllib_error
    from ..downloader.external import ExternalFD
    from ..downloader.f4m import F4mFD
    from ..downloader.hls import HlsFD
    from ..downloader.http import HttpFD
    from ..downloader.rtmp import RtmpFD
    from ..downloader.smoothstreams import SmoothstreamsFD

    dash_segments_f_d_0 = DashSegmentsFD()
    dash_segments_f_d_0.real_download()
# TEST CASE 0

# Generated at 2022-06-26 11:03:54.577051
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    bool_1 = False
    bool_2 = False
    str_0 = '\tB;~?E=mqQz?!Vn:GR+^'
    dash_segments_f_d_0 = DashSegmentsFD(bool_2, str_0)
    assert dash_segments_f_d_0.use_proxy() == False, "Assertion failed"
    assert dash_segments_f_d_0._downloader.http_proxy == str_0, "Assertion failed"

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:09.309525
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    bool_1 = False
    bool_2 = False
    str_0 = 'SK_!=t#Lg&S%^~q3Oh1G'
    dash_segments_f_d_0 = DashSegmentsFD(bool_2, str_0)
    assert dash_segments_f_d_0.get_		() == str_0
    assert dash_segments_f_d_0.get_progress_hooks() == []
    assert dash_segments_f_d_0.get_total_frags() == 0
    assert dash_segments_f_d_0.get_skip_unavailable_fragments() == False
    assert dash_segments_f_d_0.get_filename() == None
    assert dash_segments_f_d

# Generated at 2022-06-26 11:04:11.807913
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:12.851085
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:04:14.579814
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:04:16.934686
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()
    print('done')

# Generated at 2022-06-26 11:04:24.036782
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    downloader = Downloader()
    downloader.params.update({
        'noplaylist': True,
        'format': '133',
    })

    url = 'https://www.youtube.com/watch?v=7VfzGjMls7E'
    ie = YoutubeIE(downloader)
    info = ie.extract(url)
    dash_segments_fd = DashSegmentsFD(downloader, ie)
    dash_segments_fd.real_download(info, info.get('formats')[-1])

    assert(True)

# Generated at 2022-06-26 11:04:27.359214
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 11:04:37.739741
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = True
    bool_1 = False
    bool_2 = False
    str_0 = '\tB;~?E=mqQz?!Vn:GR+^'
    dash_segments_f_d_0 = DashSegmentsFD(bool_2, str_0)
    var_0 = dash_segments_f_d_0.real_download(bool_0, bool_1)
    assert False

if __name__ == '__main__':
    # test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:50.008559
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('test_DashSegmentsFD_real_download...')
    test_case_0()


if __name__ == '__main__':
    # test_DashSegmentsFD_real_download()
    test_case_0()

# Generated at 2022-06-26 11:04:51.640116
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:04:55.042465
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Class cache
# DashSegmentsFD = DashSegmentsFD()

# Generated at 2022-06-26 11:05:00.648224
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'https://gns3.teachable.com/courses/gns3-certified-associate/lectures/6842364'
    dict_0 = {str_0: str_0}
    float_0 = None
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)

test_case_0()

# Generated at 2022-06-26 11:05:02.369044
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:05:06.107345
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    print('Real download unit test for method real_download of class DashSegmentsFD is passed.')


# Generated at 2022-06-26 11:05:07.983945
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'


# Generated at 2022-06-26 11:05:09.220995
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:10.429786
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:12.576172
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # TODO: Implement test function
    pass

# Generated at 2022-06-26 11:05:35.138941
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
#
# if __name__ == '__main__':
#     test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:38.396731
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:38.903946
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:40.670429
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert None != DashSegmentsFD


# Generated at 2022-06-26 11:05:41.530885
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:05:50.501400
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'https://gns3.teachable.com/courses/gns3-certified-associate/lectures/6842364'
    dict_0 = {str_0: str_0}
    float_0 = None
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    return dash_segments_f_d_0


# Generated at 2022-06-26 11:05:51.885438
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:05:53.351994
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:05:55.403805
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:05:58.313789
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    #test_DashSegmentsFD_real_download()
    pass

# Generated at 2022-06-26 11:06:39.301911
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    for i in range(100):
        test_case_0()

# Generated at 2022-06-26 11:06:45.341685
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'https://gns3.teachable.com/courses/gns3-certified-associate/lectures/6842364'
    dict_0 = {str_0: str_0}
    float_0 = None
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)
    # assert var_0 == True

# Generated at 2022-06-26 11:06:57.576686
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import inspect
    import os
    import sys
    import unittest

    class UnitTest(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_default_0(self):
            str_0 = 'https://gns3.teachable.com/courses/gns3-certified-associate/lectures/6842364'
            dict_0 = {str_0: str_0}
            float_0 = None
            dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
            self.assertTrue(isinstance(dash_segments_f_d_0, DashSegmentsFD))

            test_case_0()
            test_case_0()


# Generated at 2022-06-26 11:06:59.118786
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:07:00.854772
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:07:03.526372
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:08.164568
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'https://gns3.teachable.com/courses/gns3-certified-associate/lectures/6842364'
    dict_0 = {str_0: str_0}
    float_0 = None
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)


# Generated at 2022-06-26 11:07:15.804713
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'https://gns3.teachable.com/courses/gns3-certified-associate/lectures/6842364'
    dict_0 = {str_0: str_0}
    float_0 = None
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)

# Generated at 2022-06-26 11:07:29.353121
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD()
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'
    str_0 = 'https://gns3.teachable.com/courses/gns3-certified-associate/lectures/6842364'
    dict_0 = {str_0: str_0}
    float_0 = None
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'
    
test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:33.284531
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:18.835176
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # This is a unit test for method real_download of class DashSegmentsFD
    assert test_case_0() == True


# Generated at 2022-06-26 11:08:20.627382
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0()



# Generated at 2022-06-26 11:08:22.186117
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Test cases for class DashSegmentsFD

# Generated at 2022-06-26 11:08:30.246028
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_1 = {}
    dash_segments_f_d_1 = DashSegmentsFD(str_1, str_1)
    var_1 = dash_segments_f_d_1.real_download(str_1, str_1)


if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:31.646445
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == None

# Generated at 2022-06-26 11:08:33.963930
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Utility main program for manual testing

# Generated at 2022-06-26 11:08:37.662909
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)


# Generated at 2022-06-26 11:08:46.668490
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    s = DashSegmentsFD({}, {})
    #seg = SegmentFD({}, {})
    #s._download_fragment = lambda x,y,z: (False, 'abc')
    s.report_error = lambda x: None
    s.report_skip_fragment = lambda x: None
    assert (s.real_download('abc.mp4', {'fragment_base_url': 'http://example.com', 'fragments': [{'url': 'd', 'path': 'e'}]}) == True)
    assert (s.real_download('abc.mp4', {'fragment_base_url': 'http://example.com', 'fragments': [{'url': 'd'}]}) == True)

# Generated at 2022-06-26 11:08:56.229136
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    assert dash_segments_f_d_0._namer.format(100000) == '100000.mp4'
    assert dash_segments_f_d_0._namer.is_video and dash_segments_f_d_0._namer.is_dash
    assert dash_segments_f_d_0._namer.is_audio and not dash_segments_f_d_0._namer.is_fragmented


# Generated at 2022-06-26 11:09:06.039079
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD('A', 'B')
    print(dash_segments_f_d_0.dont_fragment)
    assert dash_segments_f_d_0.dont_fragment == False
    assert dash_segments_f_d_0.params == 'A'
    assert dash_segments_f_d_0.ydl == 'B'
    assert dash_segments_f_d_0.use_proxy == False
    assert dash_segments_f_d_0.header_fields == ['Accept-Encoding']
    assert dash_segments_f_d_0.continuedl == False
    assert dash_segments_f_d_0.retries == 10

# Generated at 2022-06-26 11:09:47.846437
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test case implementation

    # Test case verification
    pass


# Generated at 2022-06-26 11:10:00.243318
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = {}
    int_0 = 0
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, str_0)
    int_0 += 1
    var_1 = (int_0 < 1)

# Generated at 2022-06-26 11:10:03.416418
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    with pytest.raises(NotImplementedError):
        test_case_0()

# Generated at 2022-06-26 11:10:10.314465
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    for i in range(0, 100):
        # Test Case 0
        str_0 = {}
        dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
        var_0 = dash_segments_f_d_0.real_download(str_0, str_0)
        assert var_0 == False, "assert failed on line 43 in file test_DashSegmentsFD.py"

# Generated at 2022-06-26 11:10:11.397037
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:13.903214
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, str_0)

# Generated at 2022-06-26 11:10:18.030602
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD({}, {})
    assert (dash_segments_f_d_0.FD_NAME == 'dashsegments')

# Generated at 2022-06-26 11:10:23.077903
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD()
    dash_segments_f_d_0.params['skip_unavailable_fragments'] = bool()
    dash_segments_f_d_0.params['fragment_retries'] = int()
    dash_segments_f_d_0.params['test'] = bool()
    var_0 = dash_segments_f_d_0.real_download(str(), str())
    # Test to check if method real_download of class DashSegmentsFD handles an exception
    try:
        dash_segments_f_d_0.real_download(str(), str())
    except Exception:
        pass

# Generated at 2022-06-26 11:10:26.754236
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)


# Generated at 2022-06-26 11:10:34.857370
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # User-defined parameters
    try:
        DashSegmentsFD()
    except TypeError:
        return

    # Default parameters
    try:
        DashSegmentsFD(None, None)
    except TypeError:
        return

    # User-defined parameters
    try:
        DashSegmentsFD(1, None, 1)
    except TypeError:
        return

    # Default parameters
    try:
        DashSegmentsFD(1, None, None)
    except TypeError:
        return


# Generated at 2022-06-26 11:11:19.121801
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_1 = {}
    dash_segments_f_d_1 = DashSegmentsFD({}, {})
    var_1 = dash_segments_f_d_1.real_download(str_1, str_1)

# Generated at 2022-06-26 11:11:24.978403
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    real_download_.calls = [0]
    str_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, str_0)
    assert real_download_.calls[0] == 1

# Generated at 2022-06-26 11:11:29.934843
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    assert dash_segments_f_d_0 != None


# Generated at 2022-06-26 11:11:34.941340
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = DashSegmentsFD()
    test_case_0()
    test_case_0()
    var_0.add_extra_info_to_filename(str_0)
    var_0.temp_name_ext_len(str_0)

# Generated at 2022-06-26 11:11:46.886905
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    fragment_fd_0 = DashSegmentsFD({})
    print(fragment_fd_0.real_download('-', {'fragment_base_url': '^', 'fragments': [{}, {'path': '^', 'duration': 0, 'url': '^', 'endbyte': 5, 'startbyte': 1}, {'duration': 1, 'url': '^', 'startbyte': 5, 'endbyte': 7, 'path': '^'}]}))

# Generated at 2022-06-26 11:11:47.331117
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-26 11:11:48.196733
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD

# Unit tests for DashSegmentsFD

# Generated at 2022-06-26 11:11:48.665060
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
  pass

# Generated at 2022-06-26 11:11:50.991912
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_2 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_2, str_2)
    var_4 = dash_segments_f_d_0.real_download(str_2, str_2)
    test_case_0()

# Generated at 2022-06-26 11:11:56.305147
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    info_dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(info_dict_0, info_dict_0)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'
    # Test function real_download with dummy variables
    test_case_0()