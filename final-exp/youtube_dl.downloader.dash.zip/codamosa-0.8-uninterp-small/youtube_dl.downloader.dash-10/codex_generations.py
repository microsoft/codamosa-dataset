

# Generated at 2022-06-26 11:03:00.631595
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '?'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)


# Generated at 2022-06-26 11:03:04.889870
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '7a77e6a2-6d3c-4c29-b0ea-8d4e4c99861b'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)


# Generated at 2022-06-26 11:03:05.719095
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:03:12.108698
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '?'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    str_1 = 'pYFw0Ng-Lxw'

# Generated at 2022-06-26 11:03:13.502474
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = test_case_0()

# Generated at 2022-06-26 11:03:15.366577
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    test_case_0()


test_case_0()
test_case_0()

# Generated at 2022-06-26 11:03:18.195739
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Unit test contain all test cases and test functions

# Generated at 2022-06-26 11:03:24.869811
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '?'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    dash_segments_f_d_0.params['test'] = True
    str_1 = 'VZnC6uA7A9o_F'
    str_2 = '*'
    # No assertion. This method is tested indirectly by test_download.py
    dash_segments_f_d_0.real_download(str_1, str_2)

# Generated at 2022-06-26 11:03:34.329032
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '?'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    str_1 = '핡홻?'
    str_2 = '첬떈앹쳝홻왼홻첿뼸홻첲류'
    str_3 = '첬떈앹쳝홻왼홻첿뼸홻첲류'
    str_4 = '첬떈앹쳝홻왼홻첿뼸홻첲류'

# Generated at 2022-06-26 11:03:35.862293
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Basic class for errors



# Generated at 2022-06-26 11:03:46.859055
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    for i in range(0,0):
        test_case_0()

# Generated at 2022-06-26 11:03:50.714295
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '?'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    str_0 = '?'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)

# Generated at 2022-06-26 11:03:55.184309
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        test_case_0()
    except Exception as e:
        print("Unit test for constructor of class DashSegmentsFD Failed")
        print(e)
        assert False

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:55.595348
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-26 11:03:56.689386
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()



# Generated at 2022-06-26 11:04:06.647974
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fail_cases = [
        None,
        1,
        [],
        {},
        "t1",
        "t2"
    ]
    for i in fail_cases:
        str_1 = '?'
        str_2 = '?'
        dash_segments_f_d_0 = DashSegmentsFD(i, str_1)
        dash_segments_f_d_1 = DashSegmentsFD(str_2, i)

if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:18.594466
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    value_124 = 'test_value_124'
    value_120 = 'test_value_120'
    dash_segments_f_d_0 = DashSegmentsFD(value_124, value_120)
    assert_equals(dash_segments_f_d_0.params, {'dash_seg_second_url': value_124,})
    assert_equals(dash_segments_f_d_0.options, {'dash_seg_second_url': value_124,})
    assert_equals(dash_segments_f_d_0.info_dict, {'dash_seg_second_url': value_124,})

# Generated at 2022-06-26 11:04:20.158019
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert callable(DashSegmentsFD)
    test_case_0()

# Generated at 2022-06-26 11:04:21.443029
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_1 = DashSegmentsFD()

# Generated at 2022-06-26 11:04:27.931364
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = ''
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    str_0 = 'i'
    dash_segments_f_d_1 = DashSegmentsFD(str_0, str_0)
    dash_segments_f_d_2 = DashSegmentsFD(str_0, str_0)
    dash_segments_f_d_3 = DashSegmentsFD(str_0, str_0)
    str_0 = '?'
    dash_segments_f_d_4 = DashSegmentsFD(str_0, str_0)
    int_0 = -1
    dash_segments_f_d_5 = DashSegmentsFD(int_0, str_0)
    dash_segments_f_d_6

# Generated at 2022-06-26 11:04:35.732023
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:39.447257
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Void
    int_0 = -7023
    dict_0 = dict({int_0: int_0, int_0: int_0, int_0: int_0})
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)

test_case_0()

# Generated at 2022-06-26 11:04:48.151094
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = -2319
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)


# Generated at 2022-06-26 11:04:53.522373
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Testing real_download...')
    test_case_0()
    print('real_download passed unit test!')

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:54.740201
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    # Unit-testing
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:03.618433
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -6572
    dict_0 = {}
    dict_1 = {int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_1)
    dash_segments_f_d_0.real_download(dict_1, dict_0)
    dash_segments_f_d_0.report_error(dict_0)
    dash_segments_f_d_0.report_skip_fragment(int_0)
    dash_segments_f_d_0.to_screen(int_0)
    dash_segments_f_d_0.report_retry_fragment(dict_1, int_0, int_0, int_0)

# Generated at 2022-06-26 11:05:05.642765
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Run tests
test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:14.784599
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 24517
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD()
    assert (dash_segments_f_d_0.params == {'test': False})
    assert (dash_segments_f_d_0.FD_NAME == 'dashsegments')

    dash_segments_f_d_1 = DashSegmentsFD(int_0, dict_0)
    assert (dash_segments_f_d_1.params == {'test': False})
    assert (dash_segments_f_d_1.FD_NAME == 'dashsegments')


# Generated at 2022-06-26 11:05:17.008388
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:20.136538
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:41.052858
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -2319
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    assert dash_segments_f_d_0.params == dict_0
    assert dash_segments_f_d_0.ydl == int_0
    dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)

# Generated at 2022-06-26 11:05:42.727962
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    return None

# Generated at 2022-06-26 11:05:46.672627
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(0, {})
    assert dash_segments_f_d_0.real_download == None

# Generated at 2022-06-26 11:05:48.778212
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    _test_case_0()

# Generated at 2022-06-26 11:05:49.316347
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:50.901512
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:05:52.165184
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:59.993907
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -4327
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    # This will raise an exception if test fails
    assert isinstance(dash_segments_f_d_0, DashSegmentsFD)

# Generated at 2022-06-26 11:06:01.186443
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:06:02.833310
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:06:14.130878
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 11:06:18.478956
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Main function for unit test

# Generated at 2022-06-26 11:06:19.531719
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:06:20.688684
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Section

# Generated at 2022-06-26 11:06:21.598497
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # TODO
    return

# Generated at 2022-06-26 11:06:22.644915
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:06:24.062355
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0 == False

# Generated at 2022-06-26 11:06:25.598060
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:06:27.836270
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:06:31.372714
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:06:54.644550
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test case 0
    test_case_0()


if __name__ == '__main__':
    # Unit test for constructor of class DashSegmentsFD
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:06:58.720501
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_var_0 = DashSegmentsFD(23, 23)

test_case_0()
test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:00.176245
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:07:01.847078
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:07:10.914247
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_a = -1488220444
    arg_a = {int_a: int_a, int_a: int_a, int_a: int_a}
    dash_segments_f_d_a = DashSegmentsFD(int_a, arg_a)
    # Test constructor of class DashSegmentsFD
    assert dash_segments_f_d_a
    # Test attribute 'FD_NAME' of class DashSegmentsFD
    assert dash_segments_f_d_a.FD_NAME == 'dashsegments'

# Generated at 2022-06-26 11:07:12.737978
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test case 0:
    test_case_0()

# Generated at 2022-06-26 11:07:23.962197
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # case 1
    int_0 = -2319
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    assert dash_segments_f_d_0.fd_name == 'dashsegments'
    assert dash_segments_f_d_0.params == dict_0
    assert dash_segments_f_d_0.ydl == int_0
    assert dash_segments_f_d_0.exit_code == 0
    # case 2
    int_0 = -2319
    dash_segments_f_d_0 = DashSegmentsFD(int_0)
    assert dash_segments_f_d_

# Generated at 2022-06-26 11:07:28.602084
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_fd_0 = DashSegmentsFD(256, dict)
    if dash_segments_fd_0.FD_NAME == 'dashsegments':
        pass
    if dash_segments_fd_0.FD_NAME == 'dashsegments':
        pass


# Generated at 2022-06-26 11:07:32.049650
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    instance = DashSegmentsFD(0, 0)
    assert instance is not None


# Generated at 2022-06-26 11:07:35.216621
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_0 = DashSegmentsFD()
    var_1 = 'test_value_1'
    var_2 = 'test_value_2'
    var_3 = var_0.real_download(var_1, var_2)

# Generated at 2022-06-26 11:08:18.178689
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:24.312010
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -2
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)

# Functions tested by test_case_0

# Generated at 2022-06-26 11:08:25.536529
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    instance_0 = DashSegmentsFD(2, 3)
    assert isinstance(instance_0, DashSegmentsFD)


# Generated at 2022-06-26 11:08:34.170377
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(
        -2077,
        {
            -2077: -2077,
            -2077: -2077,
            -2077: -2077,
        },
    )
    assert int(-2077) == int(-2077)
    assert int(-2077) == int(-2077)
    assert int(-2077) == int(-2077)
    assert int(-2077) == int(-2077)
    assert int(-2077) == int(-2077)

# Generated at 2022-06-26 11:08:37.295189
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD(0, 0), 'Constructor failed'
    print('Constructor passed')



# Generated at 2022-06-26 11:08:42.949824
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_1 = DashSegmentsFD(0, {0: 0, 0: 0, 0: 0})
    assert isinstance(dash_segments_f_d_1, (FragmentFD, DashSegmentsFD)) == True


# Generated at 2022-06-26 11:08:55.196915
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Executing test_DashSegmentsFD_real_download')
    int_0 = -2319
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)
    print(var_0)


if __name__ == '__main__':
    # Test method real_download of class DashSegmentsFD
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:56.730877
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD(1, {1: 1, 1: 1, 1: 1})

# Generated at 2022-06-26 11:09:03.894455
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -2319
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)

# Generated at 2022-06-26 11:09:05.287095
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # test with test_case_0()
    return

# Generated at 2022-06-26 11:09:55.381849
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Test for method real_download of class DashSegmentsFD')
    print('Not implemented')
    # print('Var "var_0" is %s' % var_0)

if __name__ == '__main__':
    # test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:09:57.801588
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:04.307095
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -5219
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)


# Generated at 2022-06-26 11:10:05.779037
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:10:13.814275
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = -2319
    dict_1 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_1)
    var_1 = dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_1)
    int_1 = -2319
    dict_2 = {int_1: int_1, int_1: int_1, int_1: int_1}
    dash_segments_f_d_1 = DashSegmentsFD(int_1, dict_2)

# Generated at 2022-06-26 11:10:15.221271
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:16.613436
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:20.783481
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Not checking the return value of real_download because it depends on existing links
    test_case_0()


if __name__ == "__main__":
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:10:24.005907
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:25.801809
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:11:56.646934
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:11:57.659393
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:12:04.166667
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -3676
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    # Check whether the call to real_download is reasonable
    test_case_0()


# Generated at 2022-06-26 11:12:12.710072
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -2319
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    dash_segments_f_d_0.report_error(dash_segments_f_d_0, int_0)


# Generated at 2022-06-26 11:12:13.913352
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:12:22.719140
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -2319
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    # Check type of var_0
    assert isinstance(dash_segments_f_d_0, DashSegmentsFD)



# Generated at 2022-06-26 11:12:26.191693
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_val = 100
    dict_val = {int_val: int_val, int_val: int_val, int_val: int_val}
    dash_segments_f_d_val = DashSegmentsFD(int_val, dict_val)

# Generated at 2022-06-26 11:12:38.494693
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -2319
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    dict_0 = {'test': False, int_0: int_0, int_0: 'filename'}
    var_0 = dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)
    dict_0 = {int_0: int_0, int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)

# Generated at 2022-06-26 11:12:48.453964
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 21821
    dict_0 = {int_0: int_0, int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    assert dash_segments_f_d_0._dashsegments_fd__fd_name == 'dashsegments'
    assert dash_segments_f_d_0.real_download(dict_0, dict_0) == True


test_case_0()
test_DashSegmentsFD()