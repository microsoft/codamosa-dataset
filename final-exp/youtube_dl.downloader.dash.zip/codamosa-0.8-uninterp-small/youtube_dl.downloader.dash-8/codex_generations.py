

# Generated at 2022-06-26 11:03:01.204143
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    name_0 = 'dash_segments_f_d_0'
    dash_segments_f_d_0 = DashSegmentsFD()
    assert(dash_segments_f_d_0.name is name_0)


# Generated at 2022-06-26 11:03:05.125908
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    bytes_0 = b'\xd2\xc2\x02Dz\x8cs'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, bytes_0)


# Generated at 2022-06-26 11:03:08.284253
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    tuple_0 = ()
    bytes_0 = b'\xab\xf7r\xb3K\xed\x00\x00\x00\x00\x00'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, bytes_0)


# Generated at 2022-06-26 11:03:22.697298
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = ()
    bytes_0 = b'\x86\x11\xba\xb5\xec[\x99\xf7S\x8d\x97\x82\x05\x07\x8c\x01\xb3\x11\xd1W\x8fv\xd2\xa2\x7f\xd6\xa0\x1a\xa51\xaa\x8dv\x06'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, bytes_0)

# Generated at 2022-06-26 11:03:31.389486
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = ()
    bytes_0 = b'\xd2\xc2\x02Dz\x8cs'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, bytes_0)
    tuple_1 = ()
    bytes_1 = b'\xd2\xc2\x02Dz\x8cs'
    dash_segments_f_d_1 = DashSegmentsFD(tuple_1, bytes_1)
    dash_segments_f_d_0.real_download(bytes_0, dash_segments_f_d_1)

# Generated at 2022-06-26 11:03:43.888771
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = ()
    bytes_0 = b'\xd2\xc2\x02Dz\x8cs'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, bytes_0)

# Generated at 2022-06-26 11:03:46.082494
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()
    print('Everything looks all right!')

# Generated at 2022-06-26 11:03:46.861409
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True

# Generated at 2022-06-26 11:03:59.568146
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = ()
    bytes_0 = b'\xd2\xc2\x02Dz\x8cs'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, bytes_0)
    str_0 = '~\x1d\xfb\xf7\x80\xb8\x1c\xae\x89\xca\x8d'
    dict_0 = {
        'fragments': [],
    }
    # Call method
    dash_segments_f_d_0.real_download(str_0, dict_0)


if __name__ == '__main__':
    import sys
    import pytest
    sys.exit(pytest.main(['-v', __file__]))

# Generated at 2022-06-26 11:04:10.457200
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    tuple_0 = ()
    bytes_0 = b'\xd2\xc2\x02Dz\x8cs'
    dash_segments_f_d_0 = DashSegmentsFD(tuple_0, bytes_0)
    str_0 = '\x9e\\c\x9f\xdb\xc0\x1d\x91\x7fB\x8e#;\x9b\xb3\x0e\x06\x10\x0f\x97D\n\xb6\x9a'
    dict_0 = {}
    dash_segments_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:04:18.266427
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    exc = None
    try:
        test_case_0()
    except Exception as e:
        exc = e
    if exc:
        raise exc


# Generated at 2022-06-26 11:04:21.958483
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    string_0 = 'a'
    string_1 = 'b'
    assert DashSegmentsFD(string_0, string_1).url == string_0
    assert DashSegmentsFD(string_1, string_0).params == string_0


# Generated at 2022-06-26 11:04:23.439920
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        DashSegmentsFD()
    except Exception:
        return False
    return True


# Generated at 2022-06-26 11:04:25.558325
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD('pm^A>V+4', 131).id == 'dashsegments'


# Generated at 2022-06-26 11:04:28.261593
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:31.107870
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
    except:
        assert False

test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:34.300114
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# End of unit tests for DashSegmentsFD class

# Generated at 2022-06-26 11:04:36.579364
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    list_0 = []
    float_0 = 240.107
    str_0 = 'pm^A>V+4'
    int_0 = 131
    dash_segments_f_d_0 = DashSegmentsFD(str_0, int_0)
    var_0 = dash_segments_f_d_0.real_download(list_0, float_0)

test_case_0()

# Generated at 2022-06-26 11:04:37.490585
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Test case 0:')
    test_case_0()



# Generated at 2022-06-26 11:04:42.142033
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

############################################################
# END OF GENERATED TEST
############################################################

if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:59.104385
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    list_0 = []
    float_0 = 240.107
    str_0 = 'pm^A>V+4'
    int_0 = 131
    dash_segments_f_d_0 = DashSegmentsFD(str_0, int_0)
    assert dash_segments_f_d_0.real_download(list_0, float_0) == True

# Generated at 2022-06-26 11:05:07.762299
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    list_0 = []
    float_0 = 302.14
    str_0 = 'pm^A>V+4'
    int_0 = 131
    dash_segments_f_d_0 = DashSegmentsFD(str_0, int_0)
    assert dash_segments_f_d_0.real_download(list_0, float_0) == True


# Generated at 2022-06-26 11:05:10.499626
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print("Testing constructor of DashSegmentsFD")
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:19.750153
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    list_0 = []
    float_0 = 240.107
    str_0 = 'pm^A>V+4'
    int_0 = 131
    dash_segments_f_d_0 = DashSegmentsFD(str_0, int_0)
    var_0 = dash_segments_f_d_0.real_download(list_0, float_0)
    assert var_0 == False

# Generated at 2022-06-26 11:05:27.643687
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    list_0 = []
    float_0 = 240.107
    str_0 = 'pm^A>V+4'
    int_0 = 131
    dash_segments_f_d_0 = DashSegmentsFD(str_0, int_0)
    var_0 = dash_segments_f_d_0.real_download(list_0, float_0)

# Generated at 2022-06-26 11:05:28.102809
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
# Test case 0
    test_case_0()

# Generated at 2022-06-26 11:05:36.517429
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    list_0 = []
    float_0 = 240.107
    str_0 = 'pm^A>V+4'
    int_0 = 131
    dash_segments_f_d_0 = DashSegmentsFD(str_0, int_0)
    var_2 = dash_segments_f_d_0.real_download(list_0, float_0)
    return var_2


if __name__ == '__main__':
    import sys
    import timeit

    try:
        profile
    except NameError:
        def profile(arg):
            return arg

    test_1 = """
from __main__ import test_DashSegmentsFD
    """


# Generated at 2022-06-26 11:05:37.953337
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:05:42.432070
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    list_0 = []
    float_0 = 240.107
    str_0 = 'pm^A>V+4'
    int_0 = 131
    dash_segments_f_d_0 = DashSegmentsFD(str_0, int_0)


# Generated at 2022-06-26 11:05:48.287687
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # test 0
    try:
        test_case_0()
    except NameError as err0:
        assert False, str(err0)


if __name__ == "__main__":
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:13.037028
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'B$44@'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)
    assert (var_0 == True)

# Generated at 2022-06-26 11:06:17.622034
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'fzsXR'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)


# Generated at 2022-06-26 11:06:21.514529
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'B$44@'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    dash_segments_f_d_0.proto = 'https'


# Generated at 2022-06-26 11:06:23.064740
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test case 0
    test_case_0()


# Generated at 2022-06-26 11:06:25.069561
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0() == True

test_DashSegmentsFD()

# Generated at 2022-06-26 11:06:32.010930
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'B$44@'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:06:40.850694
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'B$44@'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:06:44.126899
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Testing constructor of class DashSegmentsFD')
    test_case_0()



# Generated at 2022-06-26 11:06:52.422851
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '@b1@'
    str_1 = 'A'
    str_2 = '@b0@'
    str_3 = '@b6@'
    str_4 = 'A'
    DashSegmentsFD(str_0, {str_1:str_2, str_3:str_4})


# Generated at 2022-06-26 11:06:53.439568
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:07:13.490970
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


# Generated at 2022-06-26 11:07:15.444104
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:07:16.626893
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:07:22.603988
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_1 = DashSegmentsFD('url', 'filename')
    var_2 = var_1.real_download('filename', 'info_dict')
    assert var_2 == True


# Generated at 2022-06-26 11:07:23.988185
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:07:27.737659
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '*tB'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)


# Generated at 2022-06-26 11:07:37.338687
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'gFw'
    dict_0 = {'a':'b', 'c':'d'}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)
    assert var_0 == False, "Expected assert to fail"


# Generated at 2022-06-26 11:07:40.197287
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print ('test_DashSegmentsFD')
    test_case_0()

# Generated at 2022-06-26 11:07:46.690691
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'j'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)


# Generated at 2022-06-26 11:07:50.740633
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'B$44@'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:08:31.919333
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:34.936365
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:42.658039
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'J%lX'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    str_1 = 'C|Jv'
    dash_segments_f_d_0.real_download(str_1, dict_0)


# Generated at 2022-06-26 11:08:49.473295
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    str_0 = '@dD(B'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    dash_segments_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:08:50.960473
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# End of file

# Generated at 2022-06-26 11:08:51.871129
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:08:52.496756
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_DashSegmentsFD_real_download_0()

# Generated at 2022-06-26 11:09:05.203519
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    string_0 = 'B-9'
    dict_0 = {
        'B-9': 'H-0',
    }
    dash_segments_f_d_0 = DashSegmentsFD(string_0, dict_0)
    bool_0 = dash_segments_f_d_0.real_download(string_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(string_0, dict_0)
    var_1 = dash_segments_f_d_0.real_download(string_0, dict_0)
    var_2 = dash_segments_f_d_0.real_download(string_0, dict_0)
    assert(bool_0)
    assert(var_0)
    assert(var_1)


# Generated at 2022-06-26 11:09:06.009067
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert callable(DashSegmentsFD)


# Generated at 2022-06-26 11:09:13.091633
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'B$44@'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)
    print(var_0)


# Generated at 2022-06-26 11:09:58.459125
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    return True

#test_DashSegmentsFD()

# Generated at 2022-06-26 11:09:59.912385
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:10.852286
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '1*8)s'
    dict_0 = var_0 = {'filename':str_0, 'total_frags':0}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, {'fragment_base_url': 'wWY;8', 'fragments' : [{'url':'8\x1d\x19', 'path':'5}Q8'}]})
    assert_equals(var_0, True)


# Generated at 2022-06-26 11:10:14.362913
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'fj"*>'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)
    assert var_0 == False


# Generated at 2022-06-26 11:10:17.881798
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test 0
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:23.404965
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'cgRr@'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    assert dash_segments_f_d_0.param_whitelist.__len__() == 1
    assert dash_segments_f_d_0.param_whitelist.__getitem__('nopart') == True
    assert dash_segments_f_d_0.param_whitelist.__getitem__('fragment_base_url') == True
    assert dash_segments_f_d_0.param_whitelist.__getitem__('fatal') == True
    assert dash_segments_f_d_0.param_whitelist.__getitem__('quiet') == True

# Generated at 2022-06-26 11:10:31.590083
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    class_declaration = 'class DashSegmentsFD(FragmentFD)'
    instance_creation = 'dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)'
    assert(class_declaration == DashSegmentsFD.declaration_code)
    assert(instance_creation == DashSegmentsFD.instantiation_code)


# Generated at 2022-06-26 11:10:33.127079
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    test_case_0()

# Generated at 2022-06-26 11:10:38.690637
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

test_classes = [
    DashSegmentsFD,
]

if __name__ == '__main__':
    for test_class in test_classes:
        for attr in dir(test_class):
            if attr.startswith('test_'):
                print(u'Running test for {0}.{1}'.format(test_class.__name__, attr))
                func = getattr(test_class, attr)
                func()

# Generated at 2022-06-26 11:10:40.141415
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert True


# Generated at 2022-06-26 11:11:24.742699
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:11:31.418055
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'B$44@'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(str_0, dict_0)

# Generated at 2022-06-26 11:11:35.922334
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    
    str_0 = '_oGZ5'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'


# Generated at 2022-06-26 11:11:47.037151
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor import YoutubeIE
    from ..utils import urljoin
    from .common import FakeYDL

    class FakeIE(YoutubeIE):
        _WORKING = True
        IE_DESC = 'FakeIE'

    ie = FakeIE()
    ydl = FakeYDL()
    ie._ydl = ydl

    ydl.params['fragment_retries']=0

    dsfd = DashSegmentsFD('', {})
    dsfd._downloader = ydl

    # No base URL, empty fragment URL
    ie._type = 'rtsp'
    ie._MANIFEST_URL = ''
    ie._MANIFEST_BASE_URL = ''
    ie._MANIFEST_FRAGMENT_BASE_URL = ''
    ie._MANIF

# Generated at 2022-06-26 11:11:47.939190
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == True

# End of Test cases for DashSegmentsFD

# Generated at 2022-06-26 11:11:56.872372
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = ')V*'
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(str_0, dict_0)
    assert(str_0 == dash_segments_f_d_0.url)
    assert(dict_0 == dash_segments_f_d_0.params)
    assert('dashsegments' == dash_segments_f_d_0.FD_NAME)
    assert(True == dash_segments_f_d_0.params.get('test', True))
    dash_segments_f_d_0.real_download(str_0, dict_0)
    dash_segments_f_d_0.report_skip_fragment(3)
    dash_segments_f_d_0.report_skip_

# Generated at 2022-06-26 11:11:58.914540
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print(test_case_0.__doc__)
    test_case_0()

# Generated at 2022-06-26 11:12:00.316639
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:12:04.619578
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # !!!!! Generated code !!!!!
    # !!!!! Do not alter !!!!!
    # -> Choose test_case_N for testing variable N
    # second parameter is used to load right module in unit_test_runner.run_all_tests
    test_case_0()

# Generated at 2022-06-26 11:12:10.264871
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Running unit tests for class DashSegmentsFD...')
    test_case_0()
    print('Unit tests for class DashSegmentsFD have been executed.')


if __name__ == '__main__':
    test_DashSegmentsFD()