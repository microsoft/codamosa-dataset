

# Generated at 2022-06-26 11:03:02.009760
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 0xE5
    float_0 = 0x11E
    dash_segments_f_d_0 = DashSegmentsFD(int_0, float_0)
    str_0 = ""
    dict_0 = {}
    bool_0 = dash_segments_f_d_0.real_download(str_0, dict_0)

test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:03:10.443904
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 14950
    float_0 = 1383.74
    string_0 = 'http://data.ntu.edu.sg/~u1004546b/data/samples/full-length-movies/others/' \
               'The.Good.Son.mkv?dl=1'

# Generated at 2022-06-26 11:03:15.166444
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Case 0: parameters in constructor are the same as defaults
    test_case_0()
    print('All tests passed!')

if __name__ == '__main__':
    # Unit test for constructor of class DashSegmentsFD
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:16.126289
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert callable(DashSegmentsFD)

# Generated at 2022-06-26 11:03:20.776363
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(291, 1504.08)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:21.740979
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:29.003264
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 1235
    float_0 = 37.8
    dash_segments_f_d_0 = DashSegmentsFD(int_0, float_0)
    str_0 = "123"
    str_1 = "123"
    dict_0 = {'fragment_base_url': str_0, 'fragments': str_1}
    str_2 = dash_segments_f_d_0.real_download(str_0, dict_0)
    print(str_2)

# Generated at 2022-06-26 11:03:31.191025
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:03:43.889419
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'nJvCp1nBjX'
    float_0 = 1504.08
    int_0 = 291
    str_1 = 'N6h5Y6f5D6'
    int_1 = 292
    float_1 = 1504.08
    str_2 = 'g7VXy6DfjV'
    str_3 = 'UTz1jf1fxV'
    int_2 = 293
    int_3 = 29
    int_4 = 294
    str_4 = 'Sz6G5b6FH5'
    float_2 = 1504.08
    int_5 = 295
    dash_segments_f_d_0 = DashSegmentsFD(int_0, float_0)
    dash_segments_f_d_0.urls

# Generated at 2022-06-26 11:03:49.502048
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    file_name_0 = 'x18'
    info_dict_0 = {'fragments': []}
    # dash_segments_f_d_0 is a instance of class DashSegmentsFD
    dash_segments_f_d_0 = DashSegmentsFD(None, None)
    dash_segments_f_d_0.real_download(file_name_0, info_dict_0)

if __name__ == '__main__':
    print('Running tests..')
    print('Passed')

# Generated at 2022-06-26 11:03:59.525211
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    obj = DashSegmentsFD
    assert obj != None
    assert callable(obj)
    assert obj('abc', 'abc', 'abc') != None


# Generated at 2022-06-26 11:04:02.171775
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_0 = DashSegmentsFD()
    var_0.real_download(None, None)


# End of teste cases


# Generated at 2022-06-26 11:04:05.173523
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Testing instance of class DashSegmentsFD')
    x_0 = DashSegmentsFD()
    print('Successfully instantiated class DashSegmentsFD')


# Generated at 2022-06-26 11:04:17.298259
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 5
    dashSegmentsFD_0 = DashSegmentsFD({
        'expected_warnings': '-Werror',
        'test': int_0,
        'verbose': int_0,
        'quiet': int_0,
        'extract_flat': True
    })
    int_1 = dashSegmentsFD_0._real_download('test_case_0_filename_0', {})
    print('Test passed!')
    return int_1

# Python entry point
if __name__ == '__main__':
    int_2 = test_case_0()
    # Test for DashSegmentsFD
    int_3 = test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:22.489669
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    obj_0 = DashSegmentsFD(params = {'ratelimit' : '0'}, ydl = None)
    var_0 = isinstance(obj_0, DashSegmentsFD)
    if var_0:
        test_case_0()
    else:
        print('Failed: object is not an instance of class DashSegmentsFD')
        

# Generated at 2022-06-26 11:04:23.326483
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:04:29.527437
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    case_0_arg_0 = 'filename'
    case_0_arg_1 = 'info_dict'
    obj_0 = DashSegmentsFD()
    ret_0 = obj_0.real_download(case_0_arg_0, case_0_arg_1)
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:38.397327
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    obj_0 = DashSegmentsFD()
    str_0 = 'test_filename'
    dict_0 = {
        'fragment_base_url': 'http://example.com',
        'fragments': [
            {
                'path': '/path1'
            }, {
                'path': '/path2'
            }
        ]
    }
    obj_0.real_download(str_0, dict_0)

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:44.181886
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    var_1 = DashSegmentsFD()
    var_2 = var_1.real_download("test_file_name", "test_info_dict")
    # AssertionError: 3 != 1
    #assert var_2 == True


# Generated at 2022-06-26 11:04:51.075047
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .mp4 import Mp4FD
    from .dash import DashFD
    from ..YoutubeDL import YoutubeDL
    import datetime
    import re
    import socket
    import ssl
    import time
    import urllib
    params = {
        'quiet': True,
        'fragment_retries': 0,
        'skip_unavailable_fragments': True,
        'skip_unavailable_fragments': True
    }
    ydl = YoutubeDL(params)
    url = 'https://www.youtube.com/watch?v=SNqC_OehVvc'
    ydl.params['simulate'] = True
    ydl.params['skip_download'] = True
    ie = ydl._get_info_extractor(url)
    ie.extract(url)
    #

# Generated at 2022-06-26 11:05:01.291515
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    my_DashSegmentsFD = DashSegmentsFD(None, None)

    # Call method real_download of class DashSegmentsFD, test case 0
    # Not implemented
    # assert my_DashSegmentsFD.real_download(str_0) == bool_0

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:04.022401
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    return


# Generated at 2022-06-26 11:05:11.885919
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test the case where the class is instantiated and method real_download is called
    test_class = DashSegmentsFD(None)
    test_class.real_download('./lib/youtube_dl/YoutubeDL/YoutubeDL/DashSegmentsFD/test_case_0',
                             'abc')

if __name__ == '__main__':
    # unittest.main()
    # Test the case where the class is instantiated and method real_download is called
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:15.458279
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

__all__ = ['DashSegmentsFD',
           'test_DashSegmentsFD_real_download',
]

# Generated at 2022-06-26 11:05:23.029470
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Compute the expected output
    str_0 = 'abc'

    # Call the function under test
    try:
        if test_case_0():
            pass
    except Exception as err:
        print(err)
        pass
    else:
        raise Exception("expected an exception")

    # Compare the results with the expected output
    str_1 = str_0
    assert str_1.upper() == str_0


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:25.998318
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Testing method real_download of class DashSegmentsFD')
    print('Not yet implemented')


# Generated at 2022-06-26 11:05:35.603335
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = DashSegmentsFD()
    str_1 = 'abc'
    str_2 = str_0.real_download(str_1)
    # Type test
    if(str_2.__class__.__name__ != 'bool'):
        console_0 = 'Test case 0: Type test failed'
        log_0 = open('log.txt', 'w')
        log_0.write(console_0)
        log_0.close()
        f_0 = open('flag.txt', 'w')
        f_0.write('1')
        f_0.close()
        print(console_0)
    # Range test
    if(str_2 == False or str_2 == True):
        console_0 = 'Test case 1: Range test failed'

# Generated at 2022-06-26 11:05:36.703692
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    test_case_1()




# Generated at 2022-06-26 11:05:38.517272
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Test of real_download method
# Test case 0
# Unconditional retry = False
# Skip unavailable = True
# Fragment retries = 0
# Force HTTP = True
# test = False
# Output = Success
test_case_0()

# Generated at 2022-06-26 11:05:41.176666
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Unit test for constructor of class DashSegmentsFD')
    test_case_0()


# Generated at 2022-06-26 11:06:01.615387
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:06:03.795203
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert(
        test_case_0() == 0
    )

# Generated at 2022-06-26 11:06:07.071729
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:06:10.593073
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    extractor = DashSegmentsFD()
    filename = str_0
    info_dict = ''
    extractor.real_download(filename, info_dict)

# Generated at 2022-06-26 11:06:13.616024
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test template case 0
    # 
    #
    # No traceback to display
    test_case_0()


# Generated at 2022-06-26 11:06:15.516185
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:06:18.570908
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = 'abc'
    str_1 = 'def'


# Generated at 2022-06-26 11:06:19.579538
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:06:20.721653
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    temp_DashSegmentsFD = DashSegmentsFD()

# Generated at 2022-06-26 11:06:24.637837
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_fd_0 = DashSegmentsFD()
    assert dash_segments_fd_0._fd.params == {}
    assert dash_segments_fd_0._fd.info_dict == {}


# Generated at 2022-06-26 11:06:44.592630
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    ctx = {
        'filename': 'test1.mp4',
        'total_frags': 2,
    }
    fragment_base_url = 'http://test.com'
    fragments = [{
        'path': 'test1.mp4'
    }, {
        'url': 'http://test.com/test2.mp4'
    }]
    info_dict = {
        'fragment_base_url': fragment_base_url,
        'fragments': fragments
    }
    dashsegment = DashSegmentsFD()
    fd = dashsegment.real_download(ctx['filename'], info_dict)
    assert fd == True


# Generated at 2022-06-26 11:06:56.484350
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Init args
    fd = DashSegmentsFD()
    filename = 'abc'
    info_dict = {
        'fragment_base_url': 'abc',
        'fragments': [
            {
                'url': 'abc',
                'path': 'abc',
            },
            {
                'url': 'abc',
                'path': 'abc',
            },
            {
                'url': 'abc',
                'path': 'abc',
            },
        ]
    }
    # Call the method
    result = fd.real_download(filename, info_dict)
    # Assert
    assert type(result) == bool


# Generated at 2022-06-26 11:07:02.246112
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    method_input_0 = DashSegmentsFD()
    method_input_1 = 'echo local-filename'
    method_input_2 = {'fragment_base_url': '', 'fragments': [{'path': '2176010-5.m4f', 'duration': 1.0, 'url': 'http://example.com/2176010-5.m4f', 'title': '2134874-5.m4f', 'http_headers': {'Content-Type': 'video/mp4'}}]}
    method_input_3 = True
    method_output = method_input_0.real_download(method_input_1, method_input_2, test=method_input_2)
    print(method_output)



# Generated at 2022-06-26 11:07:03.759594
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert(test_case_0())

# Generated at 2022-06-26 11:07:05.900871
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    temp_instance = DashSegmentsFD()


# Generated at 2022-06-26 11:07:07.114396
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass


# Generated at 2022-06-26 11:07:08.176717
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:07:10.767959
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    DashSegmentsFD_test = DashSegmentsFD()
    DashSegmentsFD_test.real_download()

# Generated at 2022-06-26 11:07:15.624089
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'abc'
    dashSegmentsFD_0 = DashSegmentsFD(str_0)
    assert dashSegmentsFD_0.FD_NAME == 'dashsegments'

# Generated at 2022-06-26 11:07:20.016615
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    ctx = {
        'filename': '',
        'total_frags': 0,
        'fragment_index': 0,
    }
    r = real_download(ctx)
    assert r == str_0

# Generated at 2022-06-26 11:07:33.052440
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:07:37.222442
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(None, None)
    dash_segments_f_d_0.real_download(None, None)

# Generated at 2022-06-26 11:07:44.684649
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    dash_segments_f_d_0.real_download(list_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:51.310457
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    list_0 = []
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD('', dict_0)
    dash_segments_f_d_0.report_error(list_0)
    dash_segments_f_d_0.report_retry_fragment(list_0, '', '', '')
    dash_segments_f_d_0.report_skip_fragment('')

# Generated at 2022-06-26 11:07:54.019753
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == True

# Generated at 2022-06-26 11:07:55.924966
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass



# Generated at 2022-06-26 11:08:05.054685
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    core0 = DashSegmentsFD(0, 0)
    data0 = {
        'fragments': [{
            'path': 'test0',
            'url': 'test1',
        }],
    }
    core0.download = lambda a, b: (True, 'test2')
    core0.arrival_time = lambda a, b: True
    core0.report_progress = lambda a, b, c: print(a, b, c)
    core0.report_skip_fragment = lambda a: print(a)
    core0.report_retry_fragment = lambda a, b, c, d: print(a, b, c, d)
    core0.report_restart = lambda: print('test3')
    core0.report_error = lambda a: print(a)


# Generated at 2022-06-26 11:08:10.585818
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # inputs
    filename = None
    info_dict = None

    # test
    dash_segments_f_d_0 = DashSegmentsFD(None, None)
    var_0 = dash_segments_f_d_0.real_download(filename, info_dict)

# Generated at 2022-06-26 11:08:14.845492
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    print('Running unit tests')
    print('==================')
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:21.464579
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = -25
    list_0 = []
    dict_0 = {int_0: list_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    assert dash_segments_f_d_0.real_download(list_0, dict_0) == False

# Generated at 2022-06-26 11:08:35.032197
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 590876
    list_0 = []
    dict_0 = {int_0: list_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(list_0, dict_0)
    test_case_0()

# Generated at 2022-06-26 11:08:43.760267
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 0
    list_0 = []
    dict_0 = {int_0: list_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(list_0, dict_0)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:45.944340
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()



# Generated at 2022-06-26 11:08:58.044746
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import random
    import string
    from .fragment import FragmentFD
    from ..compat import compat_urllib_error
    from ..utils import (
        DownloadError,
        urljoin,
    )
    filename = ''.join(random.choice(string.ascii_letters) for i in range(8))
    info_dict = {'fragments': [{'url': 'http://example.com/01', 'path': '/01', 'duration': 1}, {'url': 'http://example.com/02', 'path': '/02', 'duration': 2}], 'fragment_base_url': 'http://example.com/'}
    fragment_base_url = info_dict.get('fragment_base_url')

# Generated at 2022-06-26 11:08:59.542537
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:09:00.860581
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
  test_case_0()

if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:09:01.610287
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:09:02.952096
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == True

# Generated at 2022-06-26 11:09:09.808936
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = -189
    list_0 = []
    dict_0 = {int_0: list_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)

    # Call method real_download
    test_case_0()

# Generated at 2022-06-26 11:09:11.209626
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:09:26.398216
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -188
    list_0 = []
    list_0.append('Test string')
    dict_0 = {int_0: list_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)

    assert dash_segments_f_d_0.file_handle is None

# Generated at 2022-06-26 11:09:28.574745
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # First test case
    test_case_0()

# Generated at 2022-06-26 11:09:37.263993
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == "__main__":
    import sys
    import inspect
    import re

    test_cases = [v for k, v in locals().items() if re.match('test_case_[0-9]+$', k)]
    test_results = [test_case() for test_case in test_cases]

    failed_test_cases = [case for case in test_cases if test_results[test_cases.index(case)]]
    failed_test_results = [result for result in test_results if result]
    failed_test_case_names = [inspect.getsourcelines(case)[-1][:-1][0] for case in failed_test_cases]


# Generated at 2022-06-26 11:09:38.898103
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:09:42.258950
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:09:49.193028
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = -49
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, dict_0)


if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:09:54.157683
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = DashSegmentsFD(1, {1: []})
    var_0.real_download([""], {})
    test_case_0()

# Generated at 2022-06-26 11:09:58.734334
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Testing constructor of class DashSegmentsFD')
    try:
        test_case_0()
        print('test case 0: pass')
    except AssertionError as e:
        print('test case 0: fail')
        print(e)

test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:00.034512
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:01.774606
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


# Generated at 2022-06-26 11:10:23.564913
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    print("test_DashSegmentsFD() finished.")

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:10:25.432642
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    pass


# Generated at 2022-06-26 11:10:35.367611
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 0
    var_0 = {int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, var_0)
    int_0 = 0
    var_1 = {int_0: int_0}
    int_1 = 0
    var_2 = {int_1: int_1}
    var_3 = dash_segments_f_d_0.real_download(var_1, var_2)
    assert dash_segments_f_d_0.real_download(var_1, var_2) == True


# Generated at 2022-06-26 11:10:36.245531
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:10:37.680779
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:39.339080
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:10:45.595788
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    int_0 = 0
    var_0 = {int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, var_0)
    var_1 = dash_segments_f_d_0.real_download(var_0, var_0)

# Generated at 2022-06-26 11:10:47.471942
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:10:49.249478
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:10:52.515665
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Unit test to test class DashSegmentsFD
import unittest

# Generated at 2022-06-26 11:11:19.534394
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:11:31.707245
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = 0
    var_1 = {var_0: var_0}
    dash_segments_f_d_0 = DashSegmentsFD(var_0, var_1)
    assert dash_segments_f_d_0.params == {var_0: var_0}
    assert dash_segments_f_d_0.dashseg_params == {}

# Generated at 2022-06-26 11:11:33.156069
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_DashSegmentsFD_real_download_0()

# Generated at 2022-06-26 11:11:39.714794
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:11:42.656626
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

test_cases = [
    test_DashSegmentsFD_real_download,
]


# Generated at 2022-06-26 11:11:43.949702
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    real_download()



# Generated at 2022-06-26 11:11:56.188624
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    int_0 = 0
    var_0 = {int_0: int_0}
    dash_segments_f_d_0 = DashSegmentsFD(int_0, var_0)
    assert(dash_segments_f_d_0.params == var_0)
    assert(dash_segments_f_d_0.filename == var_0)
    assert(dash_segments_f_d_0.total_frags == int_0)
    assert(dash_segments_f_d_0.fragment_index == int_0)
    assert(dash_segments_f_d_0.progress_hooks == None)
    assert(dash_segments_f_d_0.tempfilename == None)
    assert(dash_segments_f_d_0.finished == False)

# Generated at 2022-06-26 11:12:01.255119
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Testing DashSegmentsFD.real_download')
    test_case_0()
    print('DashSegmentsFD.real_download is supported!')

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:12:02.800298
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(1, 1)

# Generated at 2022-06-26 11:12:03.825334
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()