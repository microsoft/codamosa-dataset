

# Generated at 2022-06-26 11:02:53.620880
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:02:55.673374
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(False, [False, False])
    dash_segments_f_d_0.real_download('', [])

# Generated at 2022-06-26 11:02:59.389049
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = False
    list_0 = [bool_0, bool_0]
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, list_0)

# Generated at 2022-06-26 11:03:01.522705
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(False, [False, False])
    dash_segments_f_d_0.real_download()

# Generated at 2022-06-26 11:03:03.606814
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:04.738806
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test for method real_download of class DashSegmentsFD
    return True

# Generated at 2022-06-26 11:03:11.454690
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = False
    list_0 = [bool_0, bool_0]
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, list_0)
    filename_0 = "KkWV_UQC6Rc"

# Generated at 2022-06-26 11:03:15.869511
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    file = open("test_file", 'r')
    file.write("This is test file")
    file.close()
    
    info_dict = {'filename': 'test_file', 'total_frags': len(fragments)}

    fragment_base_url = info_dict['fragment_base_url']
    fragments = info_dict['fragments']

    frag_index = 0
    exception_caught = False
    try:
        for i, fragment in enumerate(fragments):
            fragment_url = fragment.get('url')
            frag_index += 1
    except:
        exception_caught = True
    if exception_caught == True:
        print("Exception caught")
    else:
        print("No exception caught")

    # Test case where fragment has value and total_frags equal to

# Generated at 2022-06-26 11:03:24.286375
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Create instance for DashSegmentsFD
    dash_segments_f_d_0 = DashSegmentsFD(False, [False, False])
    # Unit test for real_download method of DashSegmentsFD
    try:
        dash_segments_f_d_0.real_download("", {"fragments": [], "total_frags": 0})
    except DownloadError as err:
        print(err)

if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:03:29.617262
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_f_d_0 = DashSegmentsFD(None, None)
    str_0 = dash_segments_f_d_0.real_download(None, None)

# Generated at 2022-06-26 11:03:41.381968
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Case 0
    dash_segments_fd = DashSegmentsFD()
    assert dash_segments_fd

    # Case 1
    dash_segments_fd = DashSegmentsFD({'name': 'test_name'})
    assert dash_segments_fd

# Generated at 2022-06-26 11:03:43.084773
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dashsegmentsfd = DashSegmentsFD()
    dashsegmentsfd.real_download('filename', {})
    pass

# Generated at 2022-06-26 11:03:56.537465
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    _params = {'n_prefer_free_formats': '0', 'n_skip_unavailable_fragments': '0', 
               'prefer_free_formats': 'False', 'skip_unavailable_fragments': 'False'}
    _accounts = {'n_prefer_free_formats': '0', 'n_skip_unavailable_fragments': '1'}
    _downloader = None

# Generated at 2022-06-26 11:04:02.089232
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    _downloader = None
    _params = None
    _progress_hooks = None
    dashsegmentsfd = DashSegmentsFD(_downloader, _params, _progress_hooks)


# Generated at 2022-06-26 11:04:15.625748
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():

    # Test for the constructor of class DashSegmentsFD function
    #
    # test case 0 (test_case_0)
    #

    test_DashSegmentsFD_instance_0 = DashSegmentsFD()
    assert test_DashSegmentsFD_instance_0.FD_NAME == 'dashsegments', 'DashSegmentsFD.FD_NAME is "dashsegments"'
    test_case_0()

    return True

# The following code block is not executed by the unit testing framework,
# but can be executed as standalone test program.
#
# The call tree of the tests:
#   test_case_0()
#       test_DashSegmentsFD()
#

if __name__ == '__main__':

    executed_ok = test_DashSegmentsFD()


# Generated at 2022-06-26 11:04:17.209535
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    Unit test for real_download
    """
    pass


# Generated at 2022-06-26 11:04:19.620770
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()
    test_obj = DashSegmentsFD()


# Generated at 2022-06-26 11:04:20.555286
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:04:25.543842
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
	
	# Create an instance of DashSegmentsFD class
	instance_DashSegmentsFD = DashSegmentsFD()
	
	# Create an instance of DownloadError class
	instance_DownloadError = DownloadError()
	
	
	try:
		instance_DashSegmentsFD.real_download()
		instance_DownloadError.raise_exception()
	except:
		
		# Checking whether the exception block is executed
		test_case_0()
		
test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:28.261834
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:34.829141
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:04:38.653767
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = True
    # bool_0 from above declared here
    test_case_0()

    if bool_0:
        bool_0 = False
        # bool_0 from above declared here
        test_case_0()

# Define function test_DashSegmentsFD_real_download
test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:43.786335
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = False
    if bool_0:
        test_case_0()
    else:
        dashsegments = DashSegmentsFD()
        print(dashsegments.FD_NAME)

# Generated at 2022-06-26 11:04:51.321352
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = False
    DashSegmentsFD_0 = DashSegmentsFD(None)
    DashSegmentsFD_0.fragment_filename = 'Config'
    DashSegmentsFD_0.fragment_index = 0
    DashSegmentsFD_0.test = False
    test_case_0()
    if (bool_0):
        dash_segments_fd_0 = DashSegmentsFD(None)
        dash_segments_fd_0.real_download(False, None)
        pass

# Generated at 2022-06-26 11:04:54.802904
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dashSegmentsFD = DashSegmentsFD()
    assert dashSegmentsFD != None


# Generated at 2022-06-26 11:04:55.283039
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


# Generated at 2022-06-26 11:05:00.174336
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    DashSegmentsFD().real_download('2.5.5.3', {'fragments': [(256, 'https://www.example.com/segment.m4f')], 'fragment_base_url': 'https://www.example.com/segment.m4f'})


# Generated at 2022-06-26 11:05:13.290056
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd_0 = DashSegmentsFD()
    url_0 = 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-26 11:05:24.367183
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # verify that DashSegmentsFD can correctly
    # download a DASH manifest
    from .dashfd import make_dash_manifest
    # use the real_download method to download a manifest
    manifest = make_dash_manifest()
    manifest = manifest[0]

    # set the parameters for the fragment downloader
    params = {
        'nopart': True,
        'test': True,
        'fragment_base_url': 'https://1.2.3.4.5/file_segment'
    }

    # create a new instance of the fragment downloader
    # with appropriate parameters
    dl = DashSegmentsFD(params)
    dl.real_download('/path/to/file', manifest)
    assert (not bool_0)

if __name__ == '__main__':
    test

# Generated at 2022-06-26 11:05:25.830710
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD()


# Generated at 2022-06-26 11:05:36.405277
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    set_0 = None
    list_0 = [6, 6]
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)


# Generated at 2022-06-26 11:05:39.675558
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:05:47.044265
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-26 11:05:53.242413
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    float_1 = 2076.529926
    list_1 = [float_1, float_1, float_1, float_1]
    dash_segments_f_d_0 = DashSegmentsFD(list_1, list_1)
    int_0 = dash_segments_f_d_0.test()


# Generated at 2022-06-26 11:05:55.264241
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    

# Generated at 2022-06-26 11:06:04.013068
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    set_0 = None
    float_0 = 1611.8432
    str_0 = 'c766310e51f4f7d34fa095f5db977f6d97978afc8a0951c7f1af3183f2e1c8ab'
    list_0 = [str_0, str_0, str_0, str_0]
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)
    var_0 = dash_segments_f_d_0.real_download(set_0, float_0)


test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:06:07.290428
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:06:17.117560
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_cases = [
        {
            "inputs": [
                None,
                1603.144976,
            ],
            "asserts": [
                False,
            ],
            "cleanup": [
            ]
        },
        {
            "inputs": [
                None,
                1603.144976,
            ],
            "asserts": [
                False,
            ],
            "cleanup": [
            ]
        },
    ]
    for i, test_case in enumerate(test_cases):
        print("Test Case {}:".format(i))
        print("Inputs:")
        pprint(test_case["inputs"])
        print("Expected Outputs:")
        pprint(test_case["asserts"])

# Generated at 2022-06-26 11:06:18.426073
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:06:19.480661
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == None

# Generated at 2022-06-26 11:06:40.566920
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    set_0 = None
    float_0 = 1603.144976
    str_0 = '07e3691a1bad77a36aba590c351180439a40baefc1c275356f40fc7082419a84'
    list_0 = [str_0, str_0, str_0, str_0]
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)
    assert dash_segments_f_d_0 is not None


# Generated at 2022-06-26 11:06:46.603950
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '%s/test'
    dash_segments_f_d_0 = DashSegmentsFD(str_0, str_0)
    float_0 = 1603.144976
    dict_0 = {
        'fragment_base_url': float_0,
        'fragments': float_0,
    }
    assert dash_segments_f_d_0.real_download(float_0, dict_0)

# Generated at 2022-06-26 11:06:53.637103
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    set_0 = None
    float_0 = 1603.144976
    str_0 = '07e3691a1bad77a36aba590c351180439a40baefc1c275356f40fc7082419a84'
    list_0 = [str_0, str_0, str_0, str_0]
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)
    var_0 = dash_segments_f_d_0.real_download(set_0, float_0)


# Generated at 2022-06-26 11:06:54.632435
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:07:06.784096
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = '9b110e6c3f636e8c43b18d55f369ef54c5a7a8da1a913b720154c02c2b0ac0bc'
    float_0 = 2754.594935
    set_0 = None
    list_0 = [str_0, str_0, str_0, str_0]
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)
    var_0 = dash_segments_f_d_0.real_download(set_0, float_0)

test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:07.880304
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test Case 44:
    test_case_0()

# Generated at 2022-06-26 11:07:18.109580
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    set_0 = set()
    float_0 = 1603.144976
    str_0 = '07e3691a1bad77a36aba590c351180439a40baefc1c275356f40fc7082419a84'
    list_0 = [str_0, str_0, str_0, str_0]
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)
    var_0 = dash_segments_f_d_0.real_download(set_0, float_0)


# Generated at 2022-06-26 11:07:26.910281
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('\n')
    print('|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||')
    print('|                          Unit test DashSegmentsFD.real_download           |')
    print('|||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||||')
    test_case_0()


# Generated at 2022-06-26 11:07:38.672949
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    set_0 = None
    float_0 = 1603.144976
    str_0 = '07e3691a1bad77a36aba590c351180439a40baefc1c275356f40fc7082419a84'
    list_0 = [str_0, str_0, str_0, str_0]
    dash_segments_f_d_0 = DashSegmentsFD(list_0, list_0)
    var_0 = dash_segments_f_d_0.real_download(set_0, float_0)


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:07:40.002221
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == None

# Generated at 2022-06-26 11:08:04.205058
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:08:06.023232
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Testing DashSegmentsFD')
    test_case_0()
    print('DashSegmentsFD passed the test')

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:09.093388
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:08:11.171890
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        test_case_0()
    except:
        assert False

# Generated at 2022-06-26 11:08:14.110356
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:08:25.401489
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    bytes_0 = b'\x88\xde\xaf\x815\xef\xaf\xfb\xa8'
    dict_0 = {bool_0: bool_0, bytes_0: bool_0, bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, dict_0)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'
    assert dash_segments_f_d_0.params == {bytes_0: bool_0, bytes_0: bytes_0, bytes_0: bool_0}

# Generated at 2022-06-26 11:08:36.313279
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {True: b'\x9f\x0b\xed\x00\x18\xb1\xbd\x00', bytes(False): True, False: True, b'\xac\xef\x1a\x96\xc6\x16': bytes, b'\x9f\x0b\xed\x00\x18\xb1\xbd\x00': True}
    dash_segments_f_d_0 = DashSegmentsFD(b'\x9f\x0b\xed\x00\x18\xb1\xbd\x00', dict_0)

# Generated at 2022-06-26 11:08:45.318665
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD(b'\x6f\x00\x7a', {b'\x7a\x00\x6f': b'\x00\x6f\x7a', b'\x00\x6f\x7a': b'\x00\x6f\x7a'})
    assert DashSegmentsFD(b'\x7a\x00\x6f', {b'\x6f\x00\x7a': b'\x00\x7a\x6f', b'\x00\x7a\x6f': b'\x00\x7a\x6f'})

# Generated at 2022-06-26 11:08:50.454791
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:08:56.084135
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    bytes_0 = b'\x00'
    dict_0 = {bytes_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, dict_0)
    # Test for constructor of class DashSegmentsFD
    assert isinstance(dash_segments_f_d_0, DashSegmentsFD)


# Generated at 2022-06-26 11:09:42.837918
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:09:47.546601
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert is_instance_of(DashSegmentsFD, FragmentFD)


# Generated at 2022-06-26 11:09:49.374403
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:09:51.220526
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test case 0
    test_case_0()

# Generated at 2022-06-26 11:09:55.753420
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    for _ in range(10):
        test_case_0()


if __name__ == '__main__':
    from unittest import main

    main()

# Generated at 2022-06-26 11:09:58.215470
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    test_case_1()


# Generated at 2022-06-26 11:10:04.151072
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(None, None)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'

# Unit test of class DashSegmentsFD

# Generated at 2022-06-26 11:10:11.491201
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    bytes_0 = b'\x88\xde\xaf\x815\xef\xaf\xfb\xa8'
    dict_0 = {bool_0: bool_0, bytes_0: bool_0, bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
    dash_segments_f_d_0 = DashSegmentsFD(bytes_0, dict_0)

# Unit test: real-download of class DashSegmentsFD

# Generated at 2022-06-26 11:10:12.203334
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:10:13.657582
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:11:52.657601
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:11:55.550241
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':

    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:11:57.563866
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 11:11:58.422016
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-26 11:12:01.740567
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:12:07.576372
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_f_d_0 = DashSegmentsFD(
        b'', {
            True: True,
            b'\x88\xde\xaf\x815\xef\xaf\xfb\xa8': True,
            True: b'\x88\xde\xaf\x815\xef\xaf\xfb\xa8',
            True: b'\x88\xde\xaf\x815\xef\xaf\xfb\xa8',
            b'\x88\xde\xaf\x815\xef\xaf\xfb\xa8': True
        }
    )



# Generated at 2022-06-26 11:12:09.757724
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()



# Generated at 2022-06-26 11:12:13.576322
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()
    print('Passed all test cases!')

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:12:19.471866
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    import unittest
    class TestDashSegmentsFD(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_test_case_0(self):
            bool_0 = True
            bytes_0 = b'\x88\xde\xaf\x815\xef\xaf\xfb\xa8'
            dict_0 = {bool_0: bool_0, bytes_0: bool_0, bool_0: bytes_0, bool_0: bytes_0, bytes_0: bool_0}
            dash_segments_f_d_0 = DashSegmentsFD(bytes_0, dict_0)

# Generated at 2022-06-26 11:12:21.039351
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()