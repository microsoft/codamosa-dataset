

# Generated at 2022-06-26 11:02:51.867459
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:02:54.271298
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:04.629932
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    set_0 = set()
    bool_0 = False
    dash_segments_f_d_0 = DashSegmentsFD(set_0, bool_0)
    filename_0 = 'test_filename'

# Generated at 2022-06-26 11:03:11.379841
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:03:13.349694
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    set_0 = set()
    bool_0 = False
    dash_segments_f_d_0 = DashSegmentsFD(set_0, bool_0)
    dash_segments_f_d_0 = DashSegmentsFD(set_0, bool_0)


# Generated at 2022-06-26 11:03:14.225213
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():

    test_case_0()

# Generated at 2022-06-26 11:03:14.914210
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
	pass


# Generated at 2022-06-26 11:03:24.074889
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    set_0 = set()
    bool_0 = False
    dash_segments_f_d_0 = DashSegmentsFD(set_0, bool_0)
    path_0 = 'hW)9|Tv'

# Generated at 2022-06-26 11:03:31.025568
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    set_0 = set()
    bool_0 = False
    dash_segments_f_d_0 = DashSegmentsFD(set_0, bool_0)
    assert dash_segments_f_d_0.downloader is not None

# main function
if __name__ == "__main__":
    print("Running unit test cases for class DashSegmentsFD ..")
    print()
    test_case_0()
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:03:34.589952
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == "__main__":
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:03:46.765172
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    str_0 = '\\=i\\l'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)
    assert dash_segments_f_d_0.params == {}
    assert dash_segments_f_d_0.thread_id == 0
    assert dash_segments_f_d_0.use_fragments == bool_0
    assert dash_segments_f_d_0.ytdl_options == str_0

# Generated at 2022-06-26 11:03:52.698644
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = True
    str_0 = 'j2>0x\tb6HVr]Hw<g\\s'
    dash_segments_fd_0 = DashSegmentsFD(bool_0, str_0)
    list_0 = [bool_0, dash_segments_fd_0]
    var_0 = dash_segments_fd_0.real_download(list_0, str_0)

# Generated at 2022-06-26 11:03:53.803346
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:03:55.184509
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()



# Generated at 2022-06-26 11:04:09.877102
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    str_0 = 'KRt\\'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)
    assert str_0 == dash_segments_f_d_0.params['outtmpl']
    assert True == dash_segments_f_d_0.params['keep_fragments']
    assert str_0 == dash_segments_f_d_0.params['outtmpl']
    assert True == dash_segments_f_d_0.params['keep_fragments']
    return dash_segments_f_d_0

if __name__ == "__main__":
    dash_segments_f_d_0 = test_DashSegmentsFD()
    test_case_0()

# Generated at 2022-06-26 11:04:18.498427
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    str_0 = 'j2>0x\tb6HVr]Hw<g\\s'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)
    list_0 = [bool_0, dash_segments_f_d_0]
    var_0 = dash_segments_f_d_0.real_download(list_0, str_0)
    assert test_case_0() == True


# Generated at 2022-06-26 11:04:21.795096
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    str_0 = 'hJ<g\\s'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)

test_case_0()
test_DashSegmentsFD()

# Generated at 2022-06-26 11:04:23.592548
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:04:24.983734
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:04:28.994666
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    str_0 = 'j2>0x\tb6HVr]Hw<g\\s'
    dash_segments_f_d_0 = DashSegmentsFD(True, str_0)


# Generated at 2022-06-26 11:04:42.063629
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert DashSegmentsFD.real_download and callable(DashSegmentsFD.real_download), \
        'No real_download'


# Generated at 2022-06-26 11:04:46.555356
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = False
    str_0 = '9'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)


# Generated at 2022-06-26 11:04:47.867579
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

# Generated at 2022-06-26 11:04:58.313072
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = True
    str_0 = 'j2>0x\tb6HVr]Hw<g\\s'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)
    list_0 = [bool_0, dash_segments_f_d_0]
    var_0 = dash_segments_f_d_0.real_download(list_0, str_0)
    assert var_0 == True

# Generated at 2022-06-26 11:05:00.793857
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD
    from ..compat import compat_urllib_error
    from ..utils import (
        DownloadError,
        urljoin,
    )

    test_case_0()

# Generated at 2022-06-26 11:05:04.164958
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:09.445579
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    str_0 = 'j2>0x\tb6HVr]Hw<g\\s'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)


# Generated at 2022-06-26 11:05:10.691254
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert test_case_0() == True

# Generated at 2022-06-26 11:05:22.623790
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    str_0 = 'j2>0x\tb6HVr]Hw<g\\s'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)

    assert(dash_segments_f_d_0.__class__.__name__ == 'DashSegmentsFD')
    assert(dash_segments_f_d_0.params == bool_0)
    assert(dash_segments_f_d_0.ydl == str_0)
    assert(isinstance(dash_segments_f_d_0.ydl, str))




# Generated at 2022-06-26 11:05:24.278472
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:53.855576
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    bool_0 = True
    str_0 = 'j2>0x\tb6HVr]Hw<g\\s'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)
    list_0 = [bool_0, dash_segments_f_d_0]
    var_0 = dash_segments_f_d_0.real_download(list_0, str_0)
    assert var_0 == False

if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 11:05:55.941794
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:05:58.313627
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:05:59.532157
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:06:02.717264
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_0 = True
    str_0 = ']`$j^g=3\x0f\x1a'
    dash_segments_f_d_0 = DashSegmentsFD(bool_0, str_0)


# Generated at 2022-06-26 11:06:13.138937
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    str_0 = '5QbS^d+;vCM8Wx1<f\nj'
    dash_segments_f_d_0 = DashSegmentsFD(True, str_0)
    list_0 = [True, dash_segments_f_d_0]
    var_0 = dash_segments_f_d_0.real_download(list_0, str_0)
    assert var_0 == False

# Generated at 2022-06-26 11:06:16.663593
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

test_cases = [
    test_DashSegmentsFD_real_download,
]


# Generated at 2022-06-26 11:06:18.126155
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:06:20.513009
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()
    print('finished')

# Generated at 2022-06-26 11:06:33.460370
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    bool_5 = True
    str_1 = 'u8#N3">#V{0Q4~lx'
    dash_segments_f_d_2 = DashSegmentsFD(bool_5, str_1)
    bool_6 = dash_segments_f_d_2.params['test']
    bool_7 = dash_segments_f_d_2.params['noprogress']
    bool_8 = dash_segments_f_d_2.params['progress_with_newline']
    # Assert custom params are loaded too
    bool_9 = dash_segments_f_d_2.params['hooks'] is not None
    # Assert minimal_test is True



test_case_0()
#test_DashSegmentsFD()

# Generated at 2022-06-26 11:07:15.488211
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:07:23.036484
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    float_0 = -131.9
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dash_segments_f_d_0, dict_0)

# Generated at 2022-06-26 11:07:27.537742
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segments_fd_0 = DashSegmentsFD(float_0, dict_0)
    assert dash_segments_fd_0.real_download(dash_segments_fd_0, dict_0) == False



# Generated at 2022-06-26 11:07:29.816875
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert test_case_0() == None


# Generated at 2022-06-26 11:07:35.225225
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    fd = DashSegmentsFD(None, None)
    fd.real_download(None, None)

if __name__ == "__main__":
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:07:36.742150
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()

# Generated at 2022-06-26 11:07:41.428571
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert isinstance(DashSegmentsFD(0, {}), FragmentFD)


# Generated at 2022-06-26 11:07:46.101223
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_1 = {}
    float_1 = -131.9
    dash_segments_f_d_1 = DashSegmentsFD(float_1, dict_1)
    assert dash_segments_f_d_1.real_download(dash_segments_f_d_1, dict_1)


# Generated at 2022-06-26 11:07:48.100240
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_case_0()


# Generated at 2022-06-26 11:07:52.391472
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    float_0 = 1.0
    dash_segments_f_d_0 = DashSegmentsFD(float_0, dict_0)
    float_1 = 2.0
    dict_1 = {}
    dict_2 = {}
    dash_segments_f_d_1 = DashSegmentsFD(float_1, dict_1, dict_2)
    assert float_1 == dash_segments_f_d_1.params["fragment_retries"]


# Generated at 2022-06-26 11:08:35.766426
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True # TODO: implement your test here



# Generated at 2022-06-26 11:08:46.205394
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .common import InfoExtractor
    from .http import HttpFD
    from .url import UrlFD

    params = {
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
    }

    extractor = InfoExtractor(params)

    # Test with youtube
    ie = extractor.suitable_ie(extractors={}, ie_key='Youtube')
    assert ie.FD_NAME == 'fragment'

    # Test with dash
    ie = extractor.suitable_ie(extractors={}, ie_key='Dash')
    assert ie.FD_NAME == 'dashsegments'

    # Test with http
    ie = extractor.suitable_ie(extractors={}, ie_key='Http')
    assert ie

# Generated at 2022-06-26 11:08:51.850667
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)

# Generated at 2022-06-26 11:08:55.902663
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    # AssertionError: Wanted return value <True>, got <False>
    assert dash_segments_f_d_0.real_download(dict_0, dict_0) == True

# Generated at 2022-06-26 11:08:56.689172
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-26 11:09:01.681154
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    dict_1 = {}
    dict_2 = {}
    var_0 = dash_segments_f_d_0.real_download(dict_1, dict_2)
    assert var_0 == False


if __name__ == '__main__':
    test_case_0()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-26 11:09:06.610730
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)

# Generated at 2022-06-26 11:09:06.978649
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-26 11:09:09.058646
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # TODO: test_case_0
    print("Not implemented")


# Generated at 2022-06-26 11:09:11.127472
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    with pytest.raises(NameError):
        test_case_0()

# Generated at 2022-06-26 11:10:01.776757
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {
        'url': 'https://www.youtube.com/watch?v=S5Sv0nEB5cY',
        'protocol': 'https',
    }
    dict_1 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_1)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_1)


# Generated at 2022-06-26 11:10:08.333397
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Assign values to variables to prevent a warning from pylint
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)

# Generated at 2022-06-26 11:10:12.362902
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 11:10:19.396988
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    var_0 = DashSegmentsFD({'retries': 2, 'numtries': 1, 'test': True}, {'noprogress': True, 'quiet': True, 'ratelimit': None, 'nooverwrites': True})
    assert var_0.params == {'retries': 2, 'numtries': 1, 'test': True}

# Generated at 2022-06-26 11:10:23.894229
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert dash_segments_f_d_0.FD_NAME == 'dashsegments'


# Generated at 2022-06-26 11:10:30.100413
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)

    assert var_0 == True

# Generated at 2022-06-26 11:10:33.687846
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    assert dash_segments_f_d_0


# Generated at 2022-06-26 11:10:40.540071
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-26 11:10:50.376705
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # set up test environment
    class DownloadError:
        pass
    class HTTPError:
        pass
    class compat_urllib_error:
        HTTPError = HTTPError
    class FragmentsFD:
        def _download_fragment(self, a, b, c, d, e):
            return False
    class DashSegmentsFD(FragmentsFD):
        DownloadError = DownloadError
        compat_urllib_error = compat_urllib_error
        pass
    import sys
    sys.modules['FragmentsFD'] = FragmentsFD
    sys.modules['DashSegmentsFD'] = DashSegmentsFD
    filename_0 = ''
    info_dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD({}, {}, {}, {})
    dash_segments_f_d

# Generated at 2022-06-26 11:10:52.902529
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    test_case_0()

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-26 11:12:35.388612
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_case_0()


# Generated at 2022-06-26 11:12:38.670458
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    try:
        dash_segments_f_d_0.real_download(dict_0, dict_0)
    except Exception as err:
        print("Caught exception: %s" % err)
    return

# Generated at 2022-06-26 11:12:44.296376
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dict_0 = {}
    dash_segments_f_d_0 = DashSegmentsFD(dict_0, dict_0)
    var_0 = dash_segments_f_d_0.real_download(dict_0, dict_0)