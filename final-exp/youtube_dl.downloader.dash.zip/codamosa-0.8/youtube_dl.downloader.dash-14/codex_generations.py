

# Generated at 2022-06-12 16:33:59.411102
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Not a real unit test, only to run doctest
    assert True

# Generated at 2022-06-12 16:34:00.774383
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD({'fragments':[]})
    assert fd.params['cookiefile'] == None
    assert fd.params['nopart'] == False
    assert fd.params['test'] == False


# Generated at 2022-06-12 16:34:09.213274
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE

    url = (
        "https://www.youtube.com/watch?v=BHErVv-8pdM&list=PL3XZNMGhpynMp4Q9oiLhffheHJtYhP2bp")
    ie = YoutubeIE(url=url)
    info_dict = ie.extract(url)
    assert len(info_dict['formats']) > 2
    dash_fd = DashSegmentsFD(ie.ydl)
    dash_fd.real_download(info_dict['title'], info_dict)

# Generated at 2022-06-12 16:34:18.865386
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..downloader import FileDownloader

    import tempfile
    import os
    import io

    class FakeIE(YoutubeIE):
        def _real_extract(self, url):
            return {
                'id': '24601',
                'title': '2011-12-31',
                'formats': [{'format_id': '1',
                             'url': 'http://example.com/video1',
                             'filesize': 100000},
                            {'format_id': '2',
                             'url': 'http://example.com/video2',
                             'filesize': 1000000}]}

    ie = FakeIE()

    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:34:26.904773
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Creating a DashSegmentsFD instance
    from ..extractor.youtube import YoutubeIE
    import os.path
    import json
    dash_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'dash_manifest.json')
    dash_manifest = json.loads(open(dash_file).read())
    fd = DashSegmentsFD(YoutubeIE()._downloader, {}, dash_manifest)
    assert 'dashsegments' == fd.FD_NAME

test_DashSegmentsFD()

# Generated at 2022-06-12 16:34:38.715138
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Imports needed for unit test
    import os
    import shutil
    import tempfile
    # Code to execute unit test
    tmp_dir = tempfile.mkdtemp(prefix='youtube-dl-test-DashSegmentsFD-run-')
    out_file = os.path.join(tmp_dir, 'output.mp4')

# Generated at 2022-06-12 16:34:50.453997
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    def test_download(fd, info_dict, params_str, expected_res, expected_fragment_index, expected_fragments_retried, expected_fragments_skipped):
        fd = DashSegmentsFD(fd.ydl, params_str)
        # We can't do fd.real_download(filename, info_dict) here because we
        # don't have a valid filename param and would prefer not to change that
        # so we must set the fragment index in the context manually here
        fd.downloader.context['fragment_index'] = 0
        res = fd.real_download('filename', info_dict)
        assert res == expected_res
        assert fd.downloader.context['fragment_index'] == expected_fragment_index
        assert fd.downloader.frag

# Generated at 2022-06-12 16:34:51.098258
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:35:00.433076
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import youtube_dl
    from ..utils import call_cmd
    from ..compat import compat_str
    import tempfile
    import os
    ydl = youtube_dl.YoutubeDL({
        'continuedl': True,
        'noprogress': True
    })
    with tempfile.TemporaryDirectory() as t:
        fn = os.path.join(t, 'f.mp4')
        f = open(fn, 'w')
        f.close()
        fd = DashSegmentsFD(ydl, fn, {'id': 'video_id'})
        assert fd.params['continuedl'] == True
        assert fd.params['noprogress'] == True
        assert not fd.finished

# Generated at 2022-06-12 16:35:05.607892
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # To test method real_download of class DashSegmentsFD
    # The test case comes from: https://github.com/ytdl-org/youtube-dl/issues/6935
    # Now there's still no real way to unit test it
    # Hopefully someone can create a test case
    return True


# Generated at 2022-06-12 16:35:22.203409
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    sys.path.append('../..')
    from YoutubeDL import YoutubeDL
    from FileDownloader import FileDownloader
    from FileDownloader import limit_length
    from FileDownloader import limit_rate
    from YoutubeDLHandler import YoutubeDLHandler
    from FileDownloader import FileDownloader
    from YoutubeDLHttpServer import YoutubeDLHttpServerFactory, YoutubeDLRequestHandler
    import json


# Generated at 2022-06-12 16:35:33.678289
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    from .downloader import FileDownloader
    from .dashsegments import DashSegmentsFD
    from .extractor import gen_extractors

# Generated at 2022-06-12 16:35:34.310741
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass


# Generated at 2022-06-12 16:35:35.040503
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD()

# Generated at 2022-06-12 16:35:44.150249
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dashsegments import DashSegmentsFD
    from ..utils import make_HTTPServer
    import random
    import threading
    import zlib


# Generated at 2022-06-12 16:35:55.140439
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    Test real_download method of class DashSegmentsFD.
    """

    import os.path

    import pytest
    from ytdl.YoutubeDL import YoutubeDL

    tmp_dir = pytest.ensuretemp(__name__)
    test_file_path = os.path.join(tmp_dir, 'test.mp4')

    # Create a test DashSegmentsFD
    class test_DashSegmentsFD(DashSegmentsFD):
        def _prepare_and_start_frag_download(self, ctx):
            ctx['fragment_index'] = 0
            ctx['filename'] = test_file_path
            ctx['tmpfilename'] = '%s.part' % ctx['filename']
            ctx['fragfh'] = open(ctx['tmpfilename'], 'wb')

# Generated at 2022-06-12 16:35:57.709472
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'verbose': True})

    # Test creation of fd and it's name
    dashsegments_fd = DashSegmentsFD('_', {}, ydl)
    assert dashsegments_fd.FD_NAME == "dashsegments"

# Generated at 2022-06-12 16:35:58.240287
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert 0

# Generated at 2022-06-12 16:35:59.765995
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashSegmentsFD_test
    DashSegmentsFD_test('test_dashsegments_real_download', 'dashsegments')


# Generated at 2022-06-12 16:36:12.181604
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import re
    import tempfile

    from .http import HttpFD
    from ..utils import (
        sanitize_open,
        sanitized_Request,
    )
    from .test import get_testdata_file

    # Find a valid DASH manifest from test files
    TEST_FILES_DIR = get_testdata_file('test_files')
    find_dash_manifest = re.compile(r'.*/manifest.mpd$')
    test_dash_file = next(iter(filter(find_dash_manifest.match, os.listdir(TEST_FILES_DIR))), None)

    assert test_dash_file is not None
    test_dash_file = os.path.join(TEST_FILES_DIR, test_dash_file)

    # Temporary file
   

# Generated at 2022-06-12 16:36:34.940538
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    from .http import HttpFD
    from .dash import parse_mpd_formats
    from .fragment import DashSegmentsFD
    from .youtube import YoutubeFD
    from ..utils import (
        compat_urlparse,
        sanitize_open,
    )

    def compile_downloader(path, fmt_select, fragment_retries):

        temp_xattr = os.path.join(path, 'temp_xattr')
        path = os.path.join(path, 'temp_dash')

        url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
        http_base = 'https://manifest.googlevideo.com/api/manifest/dash/'

# Generated at 2022-06-12 16:36:45.007325
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..utils import prepend_extension
    from .dash import DashFD
    from .fragment import FragmentFD
    from .http import HttpFD
    from .file import FileFD

    destfile = prepend_extension(__file__, 'mp4')
    url = 'https://www.youtube.com/watch?v=6Uip06J9XK4'
    dl = DashFD().download([url], destfile, {'quiet': True})
    info_dict = dl[url]['info_dict']
    info_dict['filename'] = destfile
    info_dict['frag_downloader'] = FragmentFD()
    info_dict['http_head_only'] = False
    info_dict['http_chunk_size'] = 1
    info_dict['http_fd'] = Http

# Generated at 2022-06-12 16:36:58.004771
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .http import HttpFD
    from .dash import DashFD

    url = 'https://github.com/ytdl-org/youtube-dl/blob/master/README.md#embedding-youtube-dl'
    fd = HttpFD(dict(), dict(url=url))
    info = fd.real_download(None, dict(url=url))
    dashfd = DashFD(dict(), dict(), dict(url=url))
    
    info_dict = dashfd.extract_info(dashfd.ydl, url, download=False)

    fragments = info_dict['fragments']
    fragments.insert(0, {'url': url})

    info_dict['fragments'] = fragments
    info_dict['fragment_base_url'] = url

# Generated at 2022-06-12 16:37:10.701006
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import re
    import shutil
    import tempfile
    import unittest
    import sys
    import youtube_dl.YoutubeDL
    from youtube_dl.extractor.youtube import YoutubeIE
    from youtube_dl.postprocessor.embedthumbnail import EmbedThumbnailPP
    from youtube_dl.utils import sanitize_open

    from . import test_utils

    class MyLogger(object):
        def debug(self, msg):
            print('debug: %s' % msg)
        def warning(self, msg):
            print('warning: %s' % msg)
        def error(self, msg):
            print('error: %s' % msg)

    class MyHook(object):
        def __init__(self, func):
            self.func = func

# Generated at 2022-06-12 16:37:22.524915
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    class Params:
        fragment_retries = 0
        skip_unavailable_fragments = True

    class InfoDict:
        fragment_base_url = 'http://example.com/1.m4s'
        fragments = [
            {
                'url': 'http://example.com/2.m4s',
                'path': '3.m4s',
            },
            {
                'path': '4.m4s',
            },
        ]
    class YDl:
        params = Params()
        info_dict = InfoDict()

    dashseg = DashSegmentsFD(YDl(), {}, {})
    assert(dashseg.params['fragment_retries'] == 0)
    assert(dashseg.params['skip_unavailable_fragments'] == True)

# Generated at 2022-06-12 16:37:23.118961
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-12 16:37:23.725497
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-12 16:37:30.566561
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    import platform
    import re
    import json
    import os
    import time

    # import the required modules
    import pytest

    # import the required modules
    import pytube
    from pytube import YouTube

    # creates a YouTube object given the video url
    url = 'https://www.youtube.com/watch?v=J0WbQ8qpgm0'
    yt = YouTube(url)

    # uses the first stream
    stream = yt.streams.filter(file_extension='mp4').first()

    def generate_random_string(string_length=10):
        random = str(time.time())
        random = random.replace(".", "")
        random = random.replace("-", "")
        random = random.replace(":", "")

# Generated at 2022-06-12 16:37:42.172518
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import io
    import os
    from .fragment import _get_fragment_retries
    from ..jsinterp import JSInterpreter
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..utils import (
        determine_ext,
        encodeFilename,
        sanitize_open,
    )
    test_filename = 'DASH-test_video'
    d = FileDownloader({
        'nopart': True,
        'test': True,
        'quiet': True,
        'format': 'worst',
        'skip_unavailable_fragments': False,
        'fragment_retries': 'infinite',
    } , test_filename)
    d.params['test'] = True
    d.report_destination = encodeFilename

# Generated at 2022-06-12 16:37:45.492474
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    YoutubeDL().test()

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-12 16:38:15.434999
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .dash import DashSegmentsFD
    '''
    Test dash segments downloader
    '''
    ydl = YoutubeDL({})

    dashsegments_example = {
        'fragment_base_url': 'http://example.com/video/segm/',
        'fragments': [
            { 'path': 'seg-001-v1-a1.ts' },
            { 'url': 'http://example.com/video/seg-002-v1-a1.ts' },
        ]
    }

    # Simulate previous download if available
    dashsegments_example['fragments'][1]['downloaded_content'] = b'content'

    dsf = DashSegmentsFD(ydl)
    dsf.real_download('test.mp4', dashsegments_example)

# Generated at 2022-06-12 16:38:28.078871
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD(None, None, {'fragment_base_url': 'http://frag-base-url',
                                'fragments':[
                                    {'url': 'http://frag-url-1', 'path': 'seg-path-1'},
                                    {'url': 'http://frag-url-2', 'path': 'seg-path-2'}
                                ]}, 0, 10)
    DashSegmentsFD(None, None, {'fragment_base_url': 'http://frag-base-url',
                                'fragments':[
                                    {'path': 'seg-path-1'},
                                    {'path': 'seg-path-2'}
                                ]}, 0, 10)

# Generated at 2022-06-12 16:38:31.916397
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # real_download: Download and concatenate segments in a DASH manifest.
    # Args:
    #     filename: The filename where the fragments will be concatenated to.
    #     info_dict: The extracted info_dict
    # Return:
    #     True if the download succeed
    #     False if the download failed
    pass

# Generated at 2022-06-12 16:38:36.600603
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    filename = "test.mp4"
    info_dict = {'upload_date': '20170912'}
    ds = DashSegmentsFD(filename, info_dict, {}, None)
    assert ds.total_frags == 0
    assert isinstance(ds, DashSegmentsFD)

# Generated at 2022-06-12 16:38:38.209637
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import youtube
    assert DashSegmentsFD.is_suitable(youtube.YoutubeIE.ie_key())

# Generated at 2022-06-12 16:38:42.488160
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    ydl.add_default_info_extractors()

    fd = DashSegmentsFD(ydl, {})
    assert fd.fd_name == 'dashsegments'

# Generated at 2022-06-12 16:38:45.532018
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dfd = DashSegmentsFD({})
    assert dfd.FD_NAME == 'dashsegments'

# unit test to check behavior of method DashSegmentsFD.real_download()

# Generated at 2022-06-12 16:38:55.660133
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .dashsegments import DashSegmentsFD
    from ..utils import sanitize_open


# Generated at 2022-06-12 16:39:06.854466
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():

    from youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL({'skip_download': True})
    # Test for DASH
    r = ydl._do_download({'fragment_base_url':'http://example.com/path/segments/',
                   'fragments': [{'path':'frag.mp4'}],
                   'protocol': 'dash',
                   'ext': 'mp4'})
    assert isinstance(r, DashSegmentsFD)

# Generated at 2022-06-12 16:39:16.616940
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        import json
        import itertools
        from ..utils import compat_urllib_request
        from ..utils import prepare_url
        from ..compat import compat_urlparse
        from ..compat import compat_urllib_error
        from .fragment import FragmentFD
        from .dashsegments import DashSegmentsFD
    except ImportError:
        return False

    class Dummy(object):
        pass

    class DummyYDL(object):
        def to_screen(self, message):
            print(message)

    class DummyFragmentFD(FragmentFD):
        def __init__(self):
            pass

        def _prepare_and_start_frag_download(self, ctx):
            pass


# Generated at 2022-06-12 16:39:59.769682
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import json
    import os
    import requests

# Generated at 2022-06-12 16:40:10.398367
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import YoutubeDL
    from ..extractor.common import InfoExtractor
    class FakeInfoExtractor(InfoExtractor):
        def _real_extract(self, url):
            return self.url_result(url, 'DashSegments', {
                'fragment_base_url': 'http://fragbase.com/',
                'fragments': [
                    {'path': 'frag1.ts'},
                    {'path': 'frag2.ts'},
                ],
            })

    class FakeYoutubeDL(YoutubeDL):
        def _download_webpage_handle(self, *args, **kwargs):
            raise YoutubeDLError('test')
        def _download_webpage_handle_test(self, *args, **kwargs):
            return compat_urllib_

# Generated at 2022-06-12 16:40:21.969840
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    try:
        import youtube_dl
    except ImportError:
        import sys
        sys.stderr.write('Error: Failed to load youtube_dl module, make sure that it is placed in python search path')
        sys.stderr.flush()
        return

    from .dash import is_dashsegments
    from .dash import parse_fragment_base_url
    from .dash import parse_fragment_url

    for i in range(1,3):
        if i == 1:
            fd_name = 'dashsegments'
        else:
            fd_name = 'dashmpd'
        print('\nTestcase %d: dash_manifest_type == %s' % (i, fd_name))


# Generated at 2022-06-12 16:40:24.055078
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_segment_fd = DashSegmentsFD()

# Generated at 2022-06-12 16:40:31.710305
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    import inspect
    from youtube_dl.downloader.fragment import FragmentFD
    from youtube_dl.downloader.dash import DashSegmentsFD
    if inspect.isclass(FragmentFD) and inspect.isclass(DashSegmentsFD):
        if issubclass(DashSegmentsFD,FragmentFD):
            return 0 # Passed
        else:
            return 1 # Failed
    return 2 # Error

if __name__ == '__main__':
    sys.exit(test_DashSegmentsFD())

# Generated at 2022-06-12 16:40:32.438073
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:40:34.422971
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    d = DashSegmentsFD(None, None, None, None)

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:40:36.906807
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    filename, forced_url, fd = DashSegmentsFD.test_download_returning_fd()
    assert fd is not None
    assert isinstance(fd, DashSegmentsFD)


# Generated at 2022-06-12 16:40:47.095304
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.youtube import YoutubeIE

    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    info = ydl.extract_info('https://www.youtube.com/watch?v=YiFG8-1D0Bg', download=False)
    ie = YoutubeIE()
    info = ie._parse_mpd_formats(info)
    assert info['formats'][0]['format_id'] == 'dashmpd-audio-low'
    assert info['formats'][1]['format_id'] == 'dashmpd-audio-high'
    assert info['formats'][2]['format_id'] == 'dashmpd-video-high'
    assert info['formats'][3]['format_id']

# Generated at 2022-06-12 16:40:56.197318
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """
    A unit test for the constructor of class DashSegmentsFD
    """
    from ..downloader import YoutubeDL

    # attempt to download a segmented dash video
    path = 'https://yt-dash-mse-test.commondatastorage.googleapis.com/media/oops-20120802-manifest.mpd'

    ydl = YoutubeDL().prepare_filename({})

    assert isinstance(ydl, YoutubeDL)

    fd = DashSegmentsFD(ydl, {'url': path})

    assert isinstance(fd, DashSegmentsFD)

# Generated at 2022-06-12 16:42:51.202783
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import logging
    from .http import HttpFD
    from .dash import DashFD
    from .ytdl_hook import ytdl_hook
    from .geturl import geturl
    from .downloader import Downloader
    from .converter import Converter
    import youtube_dl.FileDownloader
    #logging.basicConfig(level=logging.DEBUG)
    #fmt_str = '%(levelname)s:%(module)s:%(lineno)d:%(funcName)s:%(message)s'
    #logging.basicConfig(format=fmt_str)
    #dl = Downloader({'local_http_headers':{'User-Agent':'Mozilla/5.0 (X11; Linux x86_64; rv:10.0) Gecko/20150101

# Generated at 2022-06-12 16:43:01.987879
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    import sys
    import os

    sys_platform = sys.platform
    sys_argv = sys.argv
    sys.platform = 'linux'
    sys.argv = [sys.argv[0], 'https://example.com/dashsegments/1/2/3']
    test_file_path = 'test_dashsegments_fd.mp4'
    with open(test_file_path, 'wb') as test_file:
        test_fragment_base_url = 'https://example.com/test'
        params = {'dashsegments': True, 'writethumbnail': True, 'writeinfojson': True, 'fragment_retries': 1,
        'noprogress':True, 'quiet':True}

# Generated at 2022-06-12 16:43:12.065221
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import unittest
    import os
    import shutil
    from pytube import YouTube

    video_url = 'https://www.youtube.com/watch?v=5e2mbK-H9Fo'
    test_file_name = '5e2mbK-H9Fo.mp4'
    test_dir_path = os.path.dirname(os.path.realpath(__file__))

    class TestDashSegmentsFDMethods(unittest.TestCase):
        def test_get_file_name_to_download(self):
            yt = YouTube(video_url, on_progress_callback=lambda *args: None)
            self.assertEqual(yt.streams.filter(file_extension='mp4').first().title, '360p')
            video = yt.streams.filter

# Generated at 2022-06-12 16:43:16.789249
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.suitable(None)
    assert DashSegmentsFD.suitable({'protocol': 'dashsegments'})
    assert not DashSegmentsFD.suitable({'protocol': 'f4m'})

if __name__ == '__main__':
    # test constructor of class DashSegmentsFD
    test_DashSegmentsFD()
    print('ok')

# Generated at 2022-06-12 16:43:22.737228
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-12 16:43:26.127933
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    downloader = object()
    params = {}
    basic_info = {}
    assert DashSegmentsFD(downloader, params, basic_info).FD_NAME == 'dashsegments'

# Generated at 2022-06-12 16:43:27.682721
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    d = DashSegmentsFD()
    assert d.real_download(None, None) == True


# Generated at 2022-06-12 16:43:35.833845
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import gen_extractors
    import os
    import shutil
    import tempfile
    import pytest
    from ..compat import compat_urlparse

    # Create temporary download directory
    download_dir = tempfile.mkdtemp()
    ctx = {'params': {}, 'ytdl_hook': lambda: True, 'dir_temp': download_dir}
    tmp_dir = tempfile.mkdtemp()

    # Create temporary mpd file
    tmp_mpd = os.path.join(tmp_dir, 'manifest.mpd')

# Generated at 2022-06-12 16:43:45.019845
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():

    import os
    # this test works only with youtube-dl.org
    # because it uses a YT video id
    d = DashSegmentsFD(
            {
                'url': 'https://www.youtube.com/watch?v=UxxajLWwzqY',
                'format': '137+140',
                'writeinfojson': True,
                'outtmpl': os.path.join(os.path.dirname(__file__), '%(id)s.%(ext)s')
            },
            False,
            False)