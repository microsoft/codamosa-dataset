

# Generated at 2022-06-12 16:33:56.991301
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import urllib2
    from .test import (
        result_urls,
        TestFD,
    )
    from ..downloader import FileDownloader
    from ..extractor import (
        YoutubeIE,
        YoutubePlaylistIE,
    )
    from ..utils import (
        encodeFilename,
    )
    from ..compat import (
        compat_str,
    )

    # Test on a single video, and a playlist

    # Single video
    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-12 16:33:57.424108
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass


# Generated at 2022-06-12 16:34:03.302760
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .dash import DashFD
    from ..extractor import gen_extractors
    dash_segment_fd = None
    dash_ext = None

    for ie_key in gen_extractors():
        ie = gen_extractors()[ie_key]()
        if type(ie) == DashFD:
            dash_ext = ie
        if ie.IE_NAME == 'dashsegments':
            dash_segment_fd = ie
    # If DashSegmentsFD never got picked up then test will fail
    assert dash_ext and dash_segment_fd
    # If DashSegmentsFD is picked up then extractor name of DashFD
    # should be DashSegmentsFD
    assert dash_ext.IE_NAME == 'dashsegments'

# Generated at 2022-06-12 16:34:15.453492
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..utils import parse_codecs

# Generated at 2022-06-12 16:34:22.859517
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import pytest
    from .dash import DashSegmentsFD
    from ..compat import compat_urllib_error
    from ..utils import ExtractorError
    from ..extractor import YoutubeIE
    from ..downloader import YoutubeDL

    def _download(self, *args, **kwargs):
        try:
            self.report_failure('Unable to download video data: HTTP Error 403: Forbidden')
        except compat_urllib_error.HTTPError as err:
            pass
        return '', ''
    DashSegmentsFD._download_fragment = _download
    dash_fd = DashSegmentsFD(YoutubeDL(), {'fragments': [{'url': 'https://example.com/segment.mp4'}]})
    with pytest.raises(ExtractorError):
        dash_fd.real_

# Generated at 2022-06-12 16:34:28.185999
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .common import get_testdata_video_urls
    from ..extractor import YoutubeIE

    testdata_urls = get_testdata_video_urls(YoutubeIE)
    for video_id, video_url in testdata_urls.items():
        DashSegmentsFD(context=None, ie=None, video_id=video_id, params=None)


# Generated at 2022-06-12 16:34:40.190768
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print("entering test_DashSegmentsFD_real_download()")

    # Initialize module variables
    global arguments
    arguments = None

    import sys
    import time
    import traceback

    from ..extractor import YoutubeDL
    from ..utils import *

    # Enable printing stack traces in debugger (IDE)
    if arguments.traceback:
        sys.excepthook = traceback.print_exception

    # Set logging level
    if arguments.log != None:
        if arguments.log == 'error':
            arguments.log = logging.ERROR
        elif arguments.log == 'warning':
            arguments.log = logging.WARNING
        elif arguments.log == 'info':
            arguments.log = logging.INFO
        elif arguments.log == 'debug':
            arguments.log = logging.DEBUG

# Generated at 2022-06-12 16:34:51.984434
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-12 16:34:55.539876
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dashfd = DashSegmentsFD(params={'youtube_include_dash_manifest': True}, downloader=None)
    assert dashfd.params['youtube_include_dash_manifest'] == True

test_DashSegmentsFD()

# Generated at 2022-06-12 16:35:06.479095
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .fragment import FragmentFD
    from ..downloader.dash import DASHFD
    from ..YoutubeDL import YoutubeDL

    d = YoutubeDL(params={
        'skip_unavailable_fragments': False,
    })
    ydl_f = DASHFD(d, {}, 'http://foo.bar/')
    fd = DashSegmentsFD.get_suitable_downloader(ydl_f)

    # Test without any parameters
    assert fd.params.get('test', False) is False
    assert fd.params.get('skip_unavailable_fragments', False) is False

    # Test with 'test' parameter
    d = YoutubeDL(params={'test': True})
    ydl_f = DASHFD(d, {}, 'http://foo.bar/')
    f

# Generated at 2022-06-12 16:35:22.684041
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD
    import logging
    import os
    import sys
    import unittest
    from .dashsegments import DashSegmentsFD
    from .http import HttpFD
    from .dashmanifest import DashManifestFD
    from .utils import (
        create_cmd_line_parser,
        DateRange,
        encodeFilename,
        make_HTTPS_handler,
        parseOpts,
        prepare_cmd_line_parser,
        read_batch_urls,
        read_batch_file,
        setLogLevel,
        write_stringio,
    )
    from ..extractor import gen_extractors, list_extractors

# Generated at 2022-06-12 16:35:34.318977
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import random
    import shutil
    import unittest
    import tempfile
    from os.path import join
    from ..extractor.generic import GenericIE
    from ..extractor.youtube import YoutubeIE
    from ..utils import (
        fix_xml_ampersands,
        preferredencoding,
        xpath_text,
    )
    from .http import HttpFD
    from .http import _extract_mpd_formats


# Generated at 2022-06-12 16:35:43.604897
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    # Necessary for __main__ of this file
    from .fragment import FragmentFD
    from ..extractor import gen_extractors
    from ..downloader import FileDownloader

    class OldStyleClass:
        pass

    class MyFD(OldStyleClass, DashSegmentsFD):
        @staticmethod
        def suitable(manifest_url):
            return True

    fd_name = 'dashsegments'
    fd_cls = MyFD


# Generated at 2022-06-12 16:35:44.775855
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD('dash_manifest.mpd')

# Generated at 2022-06-12 16:35:49.917245
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    url='http://dash.edgesuite.net/envivio/EnvivioDash3/manifest.mpd'
    obj = DashSegmentsFD(url, {}, {})
    print (obj.FD_NAME)

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:35:58.868576
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    class TestInfoDict(dict):

        def __init__(self, fragments):
            dict.__init__(self)
            self.update({'fragments': fragments})

    class TestFragment(dict):

        def __init__(self, url):
            dict.__init__(self)
            self.update({'url': url})

    class TestSegmentsFD(DashSegmentsFD):

        def _download_fragment(self, ctx, fragment_url, info_dict):
            print('Downloading: %s' % fragment_url)
            return True, 'content'

    test_info_dict = TestInfoDict([TestFragment('http://example.com')])
    test_download_params = {'skip_unavailable_fragments': False}
    test_segmentsfd = TestSegments

# Generated at 2022-06-12 16:36:10.926593
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashSegmentsFD
    from .http import HttpFD
    from .http import HttpSegmentFD
    from .http import HttpVerboseFD
    from .http import HttpQuietFD
    from .http import HttpSlowFD
    from .http import HttpTestFD
    from .httpproxy import HttpProxyFD
    from .rtmpdump import RtmpdumpFD
    from .f4m import F4mFD
    from .hls import HlsFD
    from .hls import HlsNativeFD
    from .hls import HlssegmentFD
    from .hls import HlsAudioOnlyFD

    # Method _real_extract of class DashManifestFD

# Generated at 2022-06-12 16:36:20.347465
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-12 16:36:31.298411
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashSegmentsFD as dash_fd
    from .dash import DashFD as dash_fd2
    from .dash import multi_dash_manifest_url
    from .dash import dash_manifest_url

    if not dash_fd._available:
        return False

    fd = dash_fd()
    fd.params['fragment_base_url'] = dash_manifest_url
    fd.params['fragments'] = [
        {'path': 'video-2.m4f'},
        {'path': 'video-3.m4f'},
    ]

    fd.real_download('test.mp4', {})
    assert True


# Generated at 2022-06-12 16:36:40.047739
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD({
        'fragments': [
            {'path': 'seg-0-v1-a1.ts'},
            {'path': 'seg-1-v1-a1.ts'},
            {'path': 'seg-2-v1-a1.ts'},
            {'path': 'seg-3-v1-a1.ts'},
            {'path': 'seg-4-v1-a1.ts'},
        ],
        'fragment_base_url': 'https://example.org/media/',
    })

# Generated at 2022-06-12 16:36:55.606617
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import dashsegments
    if dashsegments:
        dashsegments.DashSegmentsFD._downloader = None
        dashsegments.DashSegmentsFD()
        dashsegments.DashSegmentsFD('foo')

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:37:04.569786
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import Downloader

    # Test downloading with skip_unavailable_fragments = False
    args = ['--skip-unavailable-fragments', 'False']
    ydl = Downloader(params={'noplaylist': True})
    ydl.params.update(ydl.parse_args(args))


# Generated at 2022-06-12 16:37:16.839332
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .http import HttpFD
    from .rtmp import RtmpFD
    from .smoothstreams import SmoothstreamsFD
    from .m3u8 import M3U8FD
    from .native import F4MFD
    dashsegments_fd_constructors = {
        'http': HttpFD,
        'https': HttpFD,
        'rtmp': RtmpFD,
        'smoothstreams': SmoothstreamsFD,
        'm3u8': M3U8FD,
        'f4m': F4MFD,
        'dashsegments': DashSegmentsFD,
    }

    assert dashsegments_fd_constructors['http'](None) == HttpFD(None)
    assert dashsegments_fd_constructors['https'](None) == HttpFD(None)
   

# Generated at 2022-06-12 16:37:17.491860
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:37:27.511069
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import sys
    import tempfile
    import shutil
    import subprocess
    from ..YoutubeDL import YoutubeDL
    from ..downloader import YoutubeDLHandler
    from ..utils import json_loads

    # Create temporary directory for video info file and testing files
    temp_dir = tempfile.mkdtemp(prefix='youtubedl_test_filefd')

    # Test video info file with one fragmented video and one non-fragmented video
    video_info_file = os.path.join(temp_dir, 'video_info.json')

# Generated at 2022-06-12 16:37:28.112758
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True

# Generated at 2022-06-12 16:37:39.438756
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_manifest_url = 'https://github.com/ytdl-org/youtube-dl/raw/master/test/test_data/dash/manifest.mpd'

# Generated at 2022-06-12 16:37:50.871884
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader.common import FileDownloader
    from ..utils import encodeFilename
    from .fragment import FragmentFD
    from .http import HttpFD
    from .rtmp import RtmpFD

    import os
    import random
    import re
    import shutil
    import tempfile

    class MockFD(FragmentFD):
        def __init__(self, downloader):
            FragmentFD.__init__(self, downloader)
            self.downloader = downloader

        # Method _prepare_and_start_frag_download
        def _prepare_and_start_frag_download(self, ctx):
            assert ctx['fragment_index'] == 0
            ctx['frag_data'] = []

        # Method _download_fragment

# Generated at 2022-06-12 16:38:04.072715
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({
        'outtmpl': '%(playlist)s/%(playlist_index)s - %(title)s.%(ext)s',
        'quiet': True,
        'skip_download': True,
    })


# Generated at 2022-06-12 16:38:15.327704
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import json
    import os
    import re
    import shutil
    import tempfile

    test_manifest_path_list = ['tests/data/dash_manifest_youtube.mpd',
                               'tests/data/dash_manifest_youtube_live.mpd']

    with tempfile.NamedTemporaryFile(delete=False) as tmp:
        with tempfile.TemporaryDirectory() as d:
            shutil.copy(test_manifest_path_list[0], d)
            test_manifest_path = os.path.join(d, os.path.basename(test_manifest_path_list[0]))


# Generated at 2022-06-12 16:38:41.924571
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import tempfile
    from ..extractor import get_info_extractor
    from ..downloader import get_suitable_downloader
    with tempfile.TemporaryDirectory() as temp_dir_name:
        # Test file download in DASH format
        ie = get_info_extractor("https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd")
        ie.download("https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd")
        info_dict = ie.extract("https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd")
        print("\nUsing extractor: %s" % (ie.IE_NAME))


# Generated at 2022-06-12 16:38:52.146463
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    import os.path
    import tempfile
    sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
    from ytdl_test import FakeYDL
    from youtube_dl.YoutubeDL import YoutubeDL
    tmp_dir = tempfile.mkdtemp(prefix='youtubedownloader-test-')
    ydl = FakeYDL(params={'outtmpl': os.path.join(tmp_dir, "out%(format_id)s.%(ext)s")})
    print("Test downloads in %s" % tmp_dir)
    dashsegments_fd = DashSegmentsFD("http://localhost/manifest", ydl)

# Generated at 2022-06-12 16:38:53.565298
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD(None, None, ['test_dash'])

# Generated at 2022-06-12 16:39:02.115546
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..utils import prepend_extension
    from .http import HttpFD
    from .dash import DASHIE
    from .http import HLSFD
    for FD in (HttpFD, HLSFD):
        test_result = FD._TEST_RESULTS.get(prepend_extension(DASHIE, 'webm'))

# Generated at 2022-06-12 16:39:05.770848
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """
    Test DashSegmentsFD
    """
    dashsegments = DashSegmentsFD()
    print(dir(dashsegments))

# Generated at 2022-06-12 16:39:11.197828
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Builtin_test.test_cmdline('https://www.youtube.com/watch?v=7fvc22DdYwc',
    #                           '--match-filter \'is_dashsegments\' -f 22 --merge-output-format mp4 --write-description --write-thumbnail --write-all-thumbnails')
    print("TODO: test_DashSegmentsFD_real_download")

# Generated at 2022-06-12 16:39:11.756466
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:39:13.660341
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    url = 'https://test.test/test.mpd'
    params = {'id': 'test'}
    DashSegmentsFD(url, params)

# Generated at 2022-06-12 16:39:21.876599
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    ydl = YoutubeDL()
    ydl.params['logger'] = YoutubeDLLogger()
    fd = DashSegmentsFD(ydl, ydl.params)
    fd.real_download('', {
        'title': 'test',
        'url': '',
        'ext': 'mp4',
        'fragment_base_url': 'http://test/',
        'fragments': [
            {'url': 'http://test/test', 'path': 'test/test'},
            {'url': 'http://test/test2', 'path': 'test/test2'}
        ]
    })

# Generated at 2022-06-12 16:39:22.993259
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD

# Generated at 2022-06-12 16:40:12.365868
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .dashsegments import DashSegmentsFD
    from .youtube_dl.YoutubeDL import YoutubeDL
    from .extractor.common import InfoExtractor


    # Dummy class for testing download_with_info_file
    class DummyYoutubeDL(YoutubeDL):
        def __init__(self):
            super(DummyYoutubeDL, self).__init__()
            self.cache = {}

        def to_screen(self, message, skip_eol=False, check_quiet=False):
            pass

        def to_stdout(self, message):
            pass

        def to_stderr(self, message):
            pass

        def fixed_template(self, *args):
            pass

        def trouble(self, message=None, tb=None):
            pass


# Generated at 2022-06-12 16:40:24.230460
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    fragment_base_url = 'http://example.com/test/DashSegmentsFD_real_download/'
    fragments = [
        {
            'url': 'dash_fragment_1.ts',
        },
        {
            'path': 'dash_fragment_2.ts',
        },
        {
            'url': 'dash_fragment_3.ts',
        },
        {
            'path': 'dash_fragment_4.ts',
        },
    ]
    info_dict = {
        'fragment_base_url': fragment_base_url,
        'fragments': fragments,
    }

    def fake_download_fragment(ctx, fragment_url, info_dict):
        assert fragment_url.startswith(fragment_base_url)


# Generated at 2022-06-12 16:40:35.318085
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    ydl = YoutubeDL()
    ydl.params['outtmpl'] = '%(id)s'
    ydl.params['keep_fragments'] = True
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True
    ydl.params['logger'] = DummyLogger()
    url = 'https://example.org/dash_manifest.mpd'

# Generated at 2022-06-12 16:40:36.210878
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD({}, {})

# Generated at 2022-06-12 16:40:36.797730
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:40:46.965881
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os.path
    import re
    from .test import get_testdata_dir, get_temp_dir, TestCase

    from youtube_dl.downloader.dash import dashsegments
    from youtube_dl.utils import sanitize_open

    class MyTestCase(TestCase):
        def setUp(self):
            self.test_dir = os.path.join(get_testdata_dir(), 'dashsegments')
            self.tmp_dir = get_temp_dir()

        def test_download(self):
            dashfd = dashsegments.DashSegmentsFD(dict(test=True), dict(fragment_base_url=None))

            def _test_download(testname):
                test_filename = os.path.join(self.test_dir, testname)
                tmp_filename = os.path

# Generated at 2022-06-12 16:40:58.587116
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    import os
    import pytest
    import youtube_dl.YoutubeDL
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_urllib_request
    from youtube_dl.downloader.dash import dash_manifest
    from youtube_dl.downloader.common import FileDownloader
    from youtube_dl.utils import encode_compat_str, prepend_extension
    import json
    import hashlib
    from io import BytesIO

    # Create the temporary directory
    directory = os.path.join(os.path.dirname(os.path.abspath(__file__)), ".tmp")
    if not os.path.isdir(directory):
        os.mkdir(directory)
        print("\nINFO: Created temporary directory")
    # Remove the

# Generated at 2022-06-12 16:40:59.985627
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Doesn't crash
    assert DashSegmentsFD() is not None

# Generated at 2022-06-12 16:41:10.302748
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader import factory_downloader
    from ..downloader import FakeYDL
    from ..downloader.common import FileDownloader

    # Error: the DASH manifest does not contain any fragment information
    url = 'https://www.youtube.com/watch?v=video_id&dash=1'
    test_set = {'fragments': []}
    result = youtube_init(url, test_set)
    assert result is False

    # Error: the DASH manifest contains fragment information, but
    # without 'url' and 'path' keys
    test_set = {'fragments': [{}]}
    result = youtube_init(url, test_set)
    assert result is False

    # Success

# Generated at 2022-06-12 16:41:19.049080
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import os
    import tempfile
    import shutil

    from ..extractor.common import InfoExtractor
    from ..downloader import DownloadContext
    from ..utils import DEFAULT_OUTTMPL

    # If we have an 'M4A'-like extension and we are not downloading a single file
    # (thus not cloning the file) and we are downloading segments, assume we are
    # downloading a DASH manifest
    ie = InfoExtractor('dashsegment', {'url': 'https://example.org/audio.m4a',
        'info_dict': {'fragments': [{'path': '/segment1.m4a'}], 'fragment_base_url': 'https://example.org'}
    })

    old_download_context = ie._download_context
    ie._download_context = DownloadContext()
   

# Generated at 2022-06-12 16:43:18.941305
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    x = DashSegmentsFD('_filename', '_info_dict', {}, {}, '_ydl_filename')
    assert x.fifo_filename == '_filename'
    assert x.info_dict == '_info_dict'
    assert x.params == {}
    assert x.add_extra_info == None
    assert x.ydl_filename == '_ydl_filename'
    assert x.out_fd == None
    assert x.fragment_index == 0
    assert x.total_frags == 0
    assert x.frags_filenames == None
    assert x.tmpfilename == None
    assert x.started == False
    assert x.finished == False
    assert x.download_started == False
    assert x.download_finished == False



# Generated at 2022-06-12 16:43:24.617167
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print(real_download(urls=['http://example.com/video.mpd'], format='21'))

if __name__ == '__main__':
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-12 16:43:33.991142
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .http import HttpFD
    from .dash import DASHIE
    from .smil import SMIL
    from .youtube import YoutubeIE
    from .common import InfoExtractor
    from .scte35 import Scte35IE
    from ..downloader.postprocessor import PostProcessor

    def _download(fd, url, ie, **extra):
        dl = fd.open(
            'https://fakeurl.com/video.mpd', {
                'id': 'fakeid',
                'title': 'faketitle',
                'formats': [{
                    'format_id': 'hls',
                    'url': url,
                    'protocol': 'm3u8_native',
                }],
            })
        return dl.read()


# Generated at 2022-06-12 16:43:43.450457
# Unit test for method real_download of class DashSegmentsFD