

# Generated at 2022-06-12 16:34:02.667131
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Test _real_download of class DashSegmentsFD when test param is True
    params = {'test': True}
    dashsegmentsfd = DashSegmentsFD(params)
    assert dashsegmentsfd._real_download(None, None) == True

    # Test _real_download of class DashSegmentsFD when test param is False
    params['test'] = False
    dashsegmentsfd = DashSegmentsFD(params)
    assert dashsegmentsfd._real_download(None, None) == True

    # Test _real_download of class DashSegmentsFD when test param is False and
    # fragment_base_url is None and fragment_url is None
    params['test'] = False

# Generated at 2022-06-12 16:34:12.879245
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """Test constructor of class DashSegmentsFD"""
    info = {'url': 'https://example.com/video.mp4', 'fragments': None, 'fragment_base_url': None}
    from ..downloader.common import FileDownloader
    fd = DashSegmentsFD(FileDownloader({'format': 'dashsegments'}), info, {'filenames': ['video.mp4']})
    assert fd.params.get('retries') == 10
    assert fd.params.get('fragment_retries') == 10


if __name__ == "__main__":
    testfunc()

# Generated at 2022-06-12 16:34:21.301925
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..downloader import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import parse_duration

    def test_1(url):
        ie = YoutubeIE()
        data = ie._get_info(url, ie.url_result(url))
        info = dict(data[0]['info'])
        print(info.keys())
        print(info['filepath'])
        print(info['fragment_base_url'])
        print(len(info['fragments']))
        print(info['fragments'][0])
        print(parse_duration(info['duration']))
        print(info['formats'][0])
        fd = DashSegmentsFD(YoutubeIE(), FileDownloader({}), info['filepath'], info)

# Generated at 2022-06-12 16:34:31.621412
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    from sys import stdout as _stdout
    from sys import stderr as _stderr
    from os import devnull as _devnull
    # open /dev/null and assign to stdout and stderr
    _stdout_fd = open(_devnull, 'w')
    _stderr_fd = open(_devnull, 'w')
    _stdout.flush(); _stderr.flush()
    _stdout.close(); _stderr.close()
    _stdout = _stdout_fd; _stderr = _stderr_fd
    ydl = YoutubeDL({'quiet': True, 'skip_download': True})
    ydl.add_default_info_extractors()

# Generated at 2022-06-12 16:34:44.030688
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .dash import DashSegmentsFD
    from .http import HttpFD
    from ..YtdlHttpRequest import YtdlHttpRequest
    class InfoDict():
        def __init__(self):
            self["entries"] = [{"url": "http://www.youtube.com"}]
        def get(self, option):
            return None
    def http_open(self):
        class Content():
            def __init__(self):
                self.status_code = 200
            def read(self):
                return "<html></html>"
        class Response():
            def __init__(self):
                self.content = Content()
        h = YtdlHttpRequest('http://www.youtube.com/')
        return Response()

    HttpFD.http_open = http_open

# Generated at 2022-06-12 16:34:55.452735
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # For more information on the parameters, please refer to
    # https://github.com/ytdl-org/youtube-dl/blob/master/youtube_dl/YoutubeDL.py
    ydl_opts = {
        'format': 'best',
        'quiet': True,
        'ignoreerrors': True,
        'skip_download': True,
    }

    def test_download(url):
        with YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            print('Downloading %s' % info['display_id'])
            dash_fragments = DashSegmentsFD(
                ydl, info['display_id'], info, ydl_opts)
            dash_fragments.download()
            print('Download finished')

# Generated at 2022-06-12 16:34:58.753344
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        DashSegmentsFD(None, None, {}, {}, None)
    except NotImplementedError:
        assert True
    except OSError:
        assert False


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:35:09.168117
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .http import HTTPFD
    from ..extractor import gen_extractors
    from ..extractor.common import InfoExtractor
    from ..compat import (
        compat_HTTPError,
        compat_urllib_request,
    )
    class FakeInfoExtractor(InfoExtractor):
        def _real_initialize(self):
            pass
        def _real_extract(self, url):
            raise NotImplementedError

    # Test open() exception in case of HTTP error
    fake_http_ie = FakeInfoExtractor({'ie_key': 'Fake'})
    fake_http_ie._downloader.http_fd = HTTPFD({'noprogress': True}, fake_http_ie)

# Generated at 2022-06-12 16:35:11.424871
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    x=DashSegmentsFD()
    assert isinstance(x,DashSegmentsFD)
    assert x.FD_NAME == 'dashsegments'

# Generated at 2022-06-12 16:35:22.544378
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..utils import urlopen

    urlopen_counter = 0
    urlopen_results = [compat_urllib_error.HTTPError(None, None, None, None, None)]
    def dummy_urlopen(*args, **kwargs):
        nonlocal urlopen_counter
        urlopen_counter += 1
        return urlopen_results[min(urlopen_counter-1, len(urlopen_results)-1)]

    from ..downloader import YoutubeDL
    from .segment import SegmentFD
    from .generic import FileDownloader
    from .http import HttpFD
    from .http import _HttpFD


# Generated at 2022-06-12 16:35:30.208955
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import youtube
    ie = youtube.YoutubeIE()
    info_dict = {}
    download = DashSegmentsFD(ie, info_dict)
    pass

# Generated at 2022-06-12 16:35:31.210082
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.FD_NAME == 'dashsegments'

# Generated at 2022-06-12 16:35:41.289041
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .common import FakeYDL
    from ..extractor import youtube
    from ..downloader.common import FileDownloader
    from ..JSInterpreter import JSInterpreter
    from ..utils import encode_data_uri

    video_id = 'zCBl1BLlH1I'
    dash = FileDownloader(FakeYDL({'skip_download': True, 'format': 'bestvideo+bestaudio/best'}))
    dash.add_info_extractor(youtube.YoutubeIE(dash))
    dash._setup_opener()
    dash.ydl.params['noplaylist'] = True

    ie = youtube.YoutubeIE(dash.ydl)
    info_dict = ie.extract(video_id)

    dash_manifest = info_dict['formats'][0]['manifest_url']

# Generated at 2022-06-12 16:35:48.089845
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    info_dict = {
        'fragments': [
            {
                'url': 'http://example.com/seg1.ts',
                'path': '/seg1.ts',
                'duration': 1,
                'title': 'Example segment'
            },
            {
                'url': 'http://example.com/seg2.ts',
                'path': 'seg2.ts',
                'duration': 1,
                'title': 'Example segment'
            },
        ],
        'fragment_base_url': 'http://example.com/',
    }
    fd = DashSegmentsFD(info_dict)
    print(fd)


if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:35:54.262602
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD(): 
    # This is commented out because I don't have access to a dashsegments link.
    #   dashsegments = 'https://example.com/dash/fragment.m4s'
    #   dsfd = DashSegmentsFD(dashsegments)
    #   print(dsfd.real_download('')) # should throw error
    #   assert isinstance(dsfd, DashSegmentsFD)
    assert 1 == 1

test_DashSegmentsFD()

# Generated at 2022-06-12 16:36:01.419289
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import dashsegments_manifest
    from .http import HTTPFD
    from .smoothstreaming import SmoothStreamingFD
    from ..downloader import Downloader
    import os
    import pickle

    # TODO: This test kinda sucks.

    dashsegments_manifest_local = os.path.join(os.path.dirname(__file__), 'dashsegments_manifest.pickle')
    dash_manifest_local = os.path.join(os.path.dirname(__file__), 'testid2_dash_manifest.pickle')
    smoothstreaming_manifest = os.path.join(os.path.dirname(__file__), 'smoothstreaming_manifest.pickle')


# Generated at 2022-06-12 16:36:10.283860
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import ytdl.YoutubeDL
    dl = ytdl.YoutubeDL({})
    info_dict = {
        'id': 'fakeid',
        'fragments': [{
            'url': 'segment1_url',
            'duration': 72.72
        }, {
            'url': 'segment2_url',
            'duration': 182.2
        }],
        'fragment_base_url': 'fake_url',
        'duration': 72.72 + 182.2,
    }
    DashSegmentsFD(dl, info_dict)

# Generated at 2022-06-12 16:36:18.182699
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import YoutubeDL
    test_dict = {
        'fragments': [{'path': '/123/1'}, {'path': '/234/2'}, {'path': '/345/3'}],
        'fragment_base_url': 'https://example.org',
    }
    with YoutubeDL(YoutubeDL.params) as ydl:
        DashSegmentsFD(ydl, test_dict).real_download('test.mp4', test_dict)
        assert ydl.fd.read('test.mp4') == b'1' + b'2' + b'3'

# Generated at 2022-06-12 16:36:30.811213
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-12 16:36:41.998378
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..compat import compat_str
    from ..downloader import FakeYDL
    from ..utils import parse_codecs
    from ..extractor.common import InfoExtractor

# Generated at 2022-06-12 16:36:47.479502
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD()

# Generated at 2022-06-12 16:36:48.164064
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass



# Generated at 2022-06-12 16:37:00.203796
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.youtube import YoutubeIE
    from ..utils import parse_iso8601

    youtubeIE = YoutubeIE()
    t1 = parse_iso8601('2013-07-25T20:12:20.000Z')
    fmt_streams = youtubeIE._parse_mpd_formats(json.loads(test_data[0]), t1)

    test_dict = {
        'id': 'test_id',
        'title': 'test_title',
        'is_live': False,
        'formats': fmt_streams,
    }

    dashSegmentsFD = DashSegmentsFD().download(test_dict)
    print(dashSegmentsFD)


# Generated at 2022-06-12 16:37:00.899525
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
	pass

# Generated at 2022-06-12 16:37:13.321930
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .http import HttpFD
    try:
        from ..downloader.http.dashsegments import download_dash_segments
    except ImportError:
        print('Skipping DashSegmentsFD test')

    NUMBER_OF_FRAGMENTS = 10

    # prepare class members of HttpFD class
    http_fd = HttpFD()
    http_fd.params = {
        'nopart': True,
        'nocheckcertificate': True,
        'retries': 0,
        'fragment_retries': 0,
    }
    http_fd.report_destination = http_fd.temp_name('.tmp')
    http_fd.to_screen = lambda *args, **kargs: None
    http_fd.to_stderr = lambda *args, **kargs: None

   

# Generated at 2022-06-12 16:37:24.269700
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    '''
    unit test for checking real_download method of class DashSegmentsFD
    '''
    import os

    import pytest

    from tests.helper import FakeYDL, unicode_representation
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.compat import compat_setenv
    from youtube_dl.downloader.http import HttpFD

    ydl_opts = {
        'dash_fragment_retries': 1,
        'format': '251/171/140/251',
        'simulate': True,
    }
    ydl = FakeYDL(ydl_opts)
    ydl.add_default_info_extractors()
    dl = YoutubeDL(ydl, ydl_opts)
    dl.prepare_filename('test')


# Generated at 2022-06-12 16:37:34.633785
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    for manifest_type in ['mpd', 'm3u8']:
        class TestInfoDict(dict):
            def __init__(self):
                super(TestInfoDict, self).__init__()
                self['ext'] = 'mp4'
                self['manifest_type'] = manifest_type
                self['fragment_base_url'] = 'http://example.com/'
                self['fragments'] = [{
                    'path': '0.m4s',
                    'url': 'http://example.net/0.m4s',
                }, {
                    'path': '1.m4s',
                    'url': 'http://example.net/1.m4s',
                }]

        ydl = YoutubeDL({})

# Generated at 2022-06-12 16:37:37.388255
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD('', { '_type': 'dash_segments' })
    DashSegmentsFD('', { '_type': 'DASH_SEGMENTS' })

# Generated at 2022-06-12 16:37:39.543772
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD("http://www.youtube.com/watch?v=mYmjXs1sI9E")

# Generated at 2022-06-12 16:37:45.956704
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # test without url_base (should be allowed)
    info = {
        'fragment_base_url': None,
        'fragments': [],
    }
    fd = DashSegmentsFD(info, None, None, 'mp4')
    assert fd

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:38:09.133944
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashFD
    def get_test_instance(params):
        params = params.copy()
        params['test'] = True
        params['max_fragments_buffer'] = 1
        params['max_filesize'] = 10
        params['skip_unavailable_fragments'] = False
        params['fragment_retries'] = 0
        return DashFD(params)

    def test_fragments(fragments):
        dash_fd = get_test_instance({
            'fragments': fragments,
        })
        return dash_fd.real_download('', {})

    def test_check_fragments(fragments, check_fragments):
        assert test_fragments(fragments) == check_fragments


# Generated at 2022-06-12 16:38:09.762155
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-12 16:38:13.098481
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import utils, downloader, extractor, gen_extractors
    for ie in gen_extractors.gen_extractors():
        if ie.IE_NAME in ('youtube', 'mtvservices'):
            return False
    return True

# Generated at 2022-06-12 16:38:16.415372
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD()
    assert fd.params['test'] == False
    assert fd.params['fragment_base_url'] == ''
    assert fd.params['fragment_retries'] == 0
    assert fd.params['skip_unavailable_fragments'] == True

# Generated at 2022-06-12 16:38:17.238365
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:38:29.488505
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ytdl.YoutubeDL import YoutubeDL
    ydl = YoutubeDL({
        'skip_download': True,
        'writeinfojson': True,
        'noplaylist': True,
        'format': '251'
    })
    ydl.process_ie_result({
        '_type': 'url',
        'ie_key': 'Dummy',
        'url': 'https://www.youtube.com/watch?v=BaW_jenozKc',
    }, download=False)
    ydl.process_ie_result(ydl.extract_info("https://www.youtube.com/watch?v=BaW_jenozKc", download=False), download=False)

# Generated at 2022-06-12 16:38:32.419740
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        DashSegmentsFD(
            'http://127.0.0.1:3128',
            {
                'fragments': [],
            }
        )
    except:
        print('test_DashSegmentsFD fail')

# Generated at 2022-06-12 16:38:40.951885
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    import os
    import pytest
    import re
    import subprocess
    from io import BytesIO
    from .utils import (
            extract_info
    )
    from ..compat import (
        compat_str,
        compat_urllib_error
    )
    from ..extractor.common import InfoExtractor
    from ..downloader import (
        retry_download,
    )
    from ..utils import (
        DownloadError,
    )

    ERROR_CODE_UNKNOWN_URL = 0

    if sys.version_info < (3, 0):
        test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'

# Generated at 2022-06-12 16:38:51.205097
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import re, tempfile, time
    from .common import InfoExtractor
    from ..utils import sanitize_open, sanitize_filename

    video_id = 'J---aiyznGQ'
    info = InfoExtractor().extract(video_id)

    frag_filename = tempfile.mktemp(prefix='ytdl-%s-' % video_id, suffix='.tmp')
    frag_info = info['formats'][-1]
    frag_url = 'http://127.0.0.1/' + video_id

    frag_info['url'] = frag_url
    frag_info['fragments'] = [{'path': '1.mp4'}, {'path': '2.mp4'}]
    frag_info['fragment_base_url'] = frag_url
   

# Generated at 2022-06-12 16:38:52.997906
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass
#    print("TODO")
#    import sys
#    sys.exit(0)

# Generated at 2022-06-12 16:39:21.793709
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..compat import compat_str
    from ..extractor.dash import DASHManifest
    from ..utils import (
        compat_str,
        encodeFilename,
    )
    from ..compat import (
        compat_urlparse,
    )

    video_id = 'HkMNOlYcpHg'
    url = 'https://www.youtube.com/watch?v=%s' % video_id
    info = YoutubeIE()._real_extract(url)
    downloader = FileDownloader(params={'format': info['format'], 'outtmpl': '%(id)s'})
    dash = DASHManifest(downloader.ydl, info['url'], info, downloader)

# Generated at 2022-06-12 16:39:29.339303
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ytdl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL({})

    url = 'https://dash.youtube.com/api/dash/'
    info_dict = {
        'id': 'test',
        'fragments': [
            {'path': 'path-A'}
        ],
        'fragment_base_url': url,
        'fragment_params': {},
    }

    fd = DashSegmentsFD(ydl, {})
    fd.real_download('test.mp4', info_dict)

# Generated at 2022-06-12 16:39:38.943306
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashFD
    from .fragment import _parse_fragment_base_url, _parse_mpd_formats
    from ..utils import (
        ExtractorError,
        encodeFilename,
        unescapeHTML,
        url_basename,
        urlget,
    )
    import json
    import os

    # Define test function that can be used with @parametrize in multiple tests
    def _test_real_download(test_url, params=None, manifest_test_func=None, mpd_base_url=None,
                            expected_fragment_base_url=None, expected_fragment_base_path=None,
                            expected_fragments=None, expected_filenames=None):
        # Prepare test data and params
        params = params or {}

       

# Generated at 2022-06-12 16:39:39.765743
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD(None, None, None)

# Generated at 2022-06-12 16:39:40.633819
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert(DashSegmentsFD is not None)

# Generated at 2022-06-12 16:39:52.127773
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..test import get_testcases
    d_test = get_testcases()
    for i in d_test:
        for j in d_test[i]:
            ydl = None
            try:
                ydl = j(i)
                ydl.add_default_info_extractors()
                ie = ydl.get_info_extractor(url=i, ie_key='Youtube')
                info_dict = ie._real_extract(i)
            except Exception as e:
                assert(0)

            if not info_dict.get('formats'):
                continue
            dash_fd = DashSegmentsFD(ydl, info_dict, {})
            dash_fd.real_download(info_dict['id'])

# Generated at 2022-06-12 16:39:59.847151
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..downloader import YoutubeDL
    from ..extractor.dash import DashManifest
    from ..compat import compat_urllib_request
    from ..utils import prepare_filename

    def extract_info(manifest_url, video_id, expected_fragments_num=None, expected_title=None):
        req = compat_urllib_request.Request(manifest_url)
        req.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/39.0.2171.95 Safari/537.36')
        dash_doc = compat_urllib_request.urlopen(req).read().decode('utf-8')

# Generated at 2022-06-12 16:40:00.602532
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD()

# Generated at 2022-06-12 16:40:10.804991
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .downloader import Downloader
    from .http import HttpFD
    from .http import HEADRequest
    from .iso8601 import parse_iso8601
    from .video import VideoInfo
    from .utils import (
        append_json_array,
        encodeFilename,
        encode_data_uri,
        parse_json,
        parse_iso8601,
    )

    class MyDashSegmentsFD(DashSegmentsFD):
        def _download_fragment(self, ctx, url, info_dict):
            assert url == info_dict['fragments'][ctx['fragment_index']]['url']
            if url.endswith('Seg1-Frag2'):
                return False, None

            return True, None


# Generated at 2022-06-12 16:40:14.419861
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    filename = 'DashSegmentsFD_real_download.mp4'
    info_dict = {}
    params = {}
    ret = DashSegmentsFD(params=params).real_download(filename, info_dict)
    assert not ret


# Generated at 2022-06-12 16:41:04.227169
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from unittest import TestCase, main
    from ..YtdlFD import YtdlFD
    from ..extractor import gen_extractors
    from ..utils import (
        file_size,
        download_json,
        prepend_extension,
        url_basename,
        url_filename,
    )

    test_urls = (
        # Test DASH video
        'https://www.youtube.com/watch?v=nfWlot6h_JM',
        # Test DASH audio
        'https://www.youtube.com/watch?v=hHW1oY26kxQ',
    )


# Generated at 2022-06-12 16:41:06.487526
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:41:14.312245
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Only run this test if the binary is available
    try:
        import dash_manifest
    except ImportError:
        return

    # The test works as follows:
    #
    # 1. Download an available fragment from a DASH manifest at https://tools.ietf.org/html/draft-pantos-http-live-streaming-23
    # 2. Write it multiple times, as if two segments of the same content were provided
    # 3. Write a last file, as if a second segment is provided
    # 4. Run DashSegmentsFD until the last file is generated

    data_path = os.path.join(os.path.dirname(__file__), 'data')
    manifest_file = os.path.join(data_path, 'dash-manifest.mpd')

# Generated at 2022-06-12 16:41:23.521186
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .tests import get_testdata_file

    fd = DashSegmentsFD('manifest.mpd', params={'itag': 37, 'noprogress': True})
    fd.download(get_testdata_file('manifest.mpd'), {
        'fragments': [
            {
                'duration': 3.0,
                'path': 'dash/segment1.ts',
            },
            {
                'duration': 2.8,
                'path': 'dash/segment2.ts',
            },
            {
                'duration': 2.0,
                'path': 'dash/segment3.ts',
            },
        ],
        'fragment_base_url': 'http://example.com/',
    })

# Generated at 2022-06-12 16:41:35.487454
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import os
    import sys
    import tempfile
    from ..downloader.common import FileDownloader

    dir = tempfile.mkdtemp(suffix=u'ダウンロード')

# Generated at 2022-06-12 16:41:42.097877
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import io
    import collections
    old_stdout = io.StringIO()
    ydl = collections.namedtuple('YoutubeDL', ['params'])(params={})
    frag_fd = DashSegmentsFD(ydl, {'fragments': [{'url': 'http://localhost/fragment.mp4', 'path': ''}, {'url': '', 'path': 'fragment.mp4'}], 'fragment_base_url': 'http://localhost/'})
    frag_fd.real_download('test.mp4', {})

# Generated at 2022-06-12 16:41:42.892424
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


# Generated at 2022-06-12 16:41:48.668345
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    from .fragment import FragmentFD
    assert issubclass(DashSegmentsFD, FragmentFD)
    assert YoutubeDL(dict(dash_segments_url=None)).add_default_info_extractors()
    assert YoutubeDL(dict(dash_segments_url=None)).add_info_extractor(DashSegmentsFD())

# Generated at 2022-06-12 16:41:49.751250
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    downloader = DashSegmentsFD(None, None)

# Generated at 2022-06-12 16:41:50.309175
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:43:40.796167
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import tempfile
    import threading
    from .http import HttpFD
    from .http import HEADRequest
    from ..YoutubeDL import YoutubeDL
    from ..utils import (
        encode_compat_str,
        decode_compat_str,
    )
    from ..downloader import FFmpegFD
    from ..extractor import CommonIE
    from ..extractor.youtube import YoutubeIE

    def _get_test_file_info(url, downloader):
        original_urlopen = compat_urllib_request.urlopen

# Generated at 2022-06-12 16:43:47.216320
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import json
    import os.path
    dashSegmentsFD = DashSegmentsFD({
        'fragment_base_url': 'http://test.test',
        'fragments': [
            {
                'duration': 1,
                'path': 'test/test.m4v',
            },
            {
                'duration': 2,
                'path': 'test/test2.m4v',
            }
        ]
    })

if __name__ == '__main__':
    test_DashSegmentsFD()