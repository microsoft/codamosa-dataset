

# Generated at 2022-06-12 16:33:56.134848
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        downloader = DashSegmentsFD(None, None)
    except NotImplementedError:
        pass

# vim:sw=4:ts=4:et:

# Generated at 2022-06-12 16:34:03.068978
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import json
    import os
    import tempfile
    import unittest
    import youtube_dl.extractor.youtube as youtube_dl_youtube

    class YoutubeIE(youtube_dl_youtube.YoutubeBaseInfoExtractor):
        def __init__(self, downloader):
            super(YoutubeIE, self).__init__(downloader)

        def _real_extract(self, url):
            return {}

    extractor = YoutubeIE(None)

    test_output_dir = tempfile.mkdtemp(prefix='youtubedl_test_output')

    def _generate_test_video_url_data():
        video_url = 'https://www.youtube.com/watch?v=_HSylqgVYQI'
        video_id = '_HSylqgVYQI'
       

# Generated at 2022-06-12 16:34:15.325891
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..downloader import Downloader
    from ..utils import match_filter_func
    from ..compat import compat_urllib_request

    ydl = Downloader()
    ydl.add_info_extractor(YoutubeIE())

    test_urls = [
        'http://www.youtube.com/watch?v=BaW_jenozKc',
    ]

    def _test_dashsegments_download(url, params):
        # Set retry to 1 since the test may fail (especially on Travis) even
        # though all fragments are downloaded successfully, see
        # https://github.com/rg3/youtube-dl/issues/8918
        params['retries'] = 1
        params['format'] = '160'

# Generated at 2022-06-12 16:34:22.779433
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD
    from unittest import TestCase

    import os
    import tempfile

    from ..compat import compat_urllib_request
    from ..utils import (
        compat_b64encode,
        compat_http_server,
        compat_urlparse,
    )

    # We need to mock _download_fragment since it uses urlretrieve()
    # which doesn't work well with our patching
    def mocked__download_fragment(dashsegmentsfd, url, info_dict):
        if url != 'http://127.0.0.1:%d/test.frag' % dashsegmentsfd._server.server_port:
            raise AssertionError('Unexpected URL: %r' % url)
        return (True, 'test fragment')

    # We need

# Generated at 2022-06-12 16:34:34.236919
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-12 16:34:45.796821
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.youtube import YoutubeIE

    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    ext = YoutubeIE()._real_extract(url)
    assert ext.get('title') == 'youtube-dl test video "\'/\\ä↭𝕐'

    filename = ext.get('_filename')
    assert filename == 'test video \'"/\\ä↭𝕐'

    dash_fd = DashSegmentsFD()._prepare_and_start_frag_download(filename)
    assert dash_fd.get('total_frags') == 1
    assert dash_fd.get('outstream') == None
    assert dash_fd.get('fatal') == False

    dash_fd._finish_frag_download()

# Generated at 2022-06-12 16:34:56.728880
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.youtube import YoutubeIE
    from ..urlinterpreter import UrlInterpreter
    from ..downloader.common import FileDownloader
    from ..utils import encodeFilename

    ydl = YoutubeDL()
    ydl.params['prefer_ffmpeg'] = False
    urlinterpreter = UrlInterpreter(ydl)
    info_dict = urlinterpreter.extract('https://www.youtube.com/watch?v=ePH65xJcQl8')
    info_dict = urlinterpreter.process_ie_result(info_dict, [YoutubeIE.ie_key()])['entries'][0]
    dl = FileDownloader(ydl, info_dict)

# Generated at 2022-06-12 16:35:06.585934
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..downloader import YoutubeDL
    from ..extractor import DummyExtractor
    ydl = YoutubeDL({'outtmpl': '%(id)s'})
    urls = [
        'http://www.example.com/manifest.mpd',
        'http://www.example.com/manifest.m3u8',
        'http://www.example.com/video.f4m',
    ]
    for url in urls:
        ie = DummyExtractor(ydl, {'ie_key': 'Dummy', 'url': url})
        assert DashSegmentsFD.suitable(ie)
        DashSegmentsFD(ydl, ie, {'url': url})

# Generated at 2022-06-12 16:35:16.423225
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.youtube import YoutubeIE
    from ..ytdl.extractor import gen_extractors

    youtube_ie = YoutubeIE()

    # Get some random YouTube video URL
    url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    info_dict = youtube_ie.extract(url)
    ext = gen_extractors(ctx=youtube_ie, info_dict=info_dict)

    file_data = DashSegmentsFD(ext, info_dict, 'mp4')
    file_data.real_download('test_dash.mp4', info_dict)
    file_data.finish()
    assert file_data.finished

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:35:27.956661
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # This test assumes that test_download.run() has been called
    # before to setup the test environment
    dash_fd = DashSegmentsFD({'noplaylist': True,
        'outtmpl': u'/dev/null'}, {'fragments': [], 'fulltitle': 'Video Title'})
    assert dash_fd.__class__.__name__ == 'DashSegmentsFD'
    assert dash_fd._out_file is None

    # No fragments, no out_file
    dash_fd.real_download('dummy.file', {'fragments': [], 'fulltitle': 'Video Title'})
    assert dash_fd._out_file is not None
    dash_fd._out_file.close()

    # Now create a fake test DASH file with one fragment
    import os

# Generated at 2022-06-12 16:35:43.221619
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..downloader import extract_info

    yt_ie = YoutubeIE({})
    yt_dl = yt_ie.ydl

    # dash_manifest = "http://yt-dash-mse-test.commondatastorage.googleapis.com/media/motion-20120802-manifest.mpd"
    dash_manifest = "http://dash.edgesuite.net/akamai/bbb_30fps/bbb_30fps.mpd"
    info_dict = extract_info(
        yt_dl, "dummy_url", download=False, process=False,
        extra_info={'manifest_url': dash_manifest})

# Generated at 2022-06-12 16:35:54.560727
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import common
    from ..extractor.youtube import YoutubeIE
    import os

    def _create_youtube_extractor(video_id, parse_dash_manifest, **kwargs):
        params = {
            'video_id': video_id,
            'dash_manifest_ok': False,
            'test': False,
            'simulate': False,
        }
        params.update(kwargs)
        ie = YoutubeIE(params)
        if parse_dash_manifest:
            res = ie._real_extract(params)
            ie._initialize_frag_download(res)
        return ie

    def _create_dash_manifest(video_id, **kwargs):
        ie = _create_youtube_extractor(video_id, True, **kwargs)
        # only extract

# Generated at 2022-06-12 16:35:59.785420
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.youtube import YoutubeIE
    from sys import argv
    for url in argv[1:]:
        dash_info = YoutubeIE._extract_dash_manifest(url, YoutubeIE.ie_key(), None, False)
        if 'fragments' in dash_info:
            fd = DashSegmentsFD(YoutubeIE, dash_info, {
                                'outtmpl': '%(id)s.mp4', 'quiet': False, 'writedescription': True}, {}, {})


# Call this function when executing this file to perform a unit test
if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:36:12.220082
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .http import HttpFD
    from .ffmpegmux import ffmpegmux
    from .m3u8 import m3u8_get_video_url

    # This is a short download made up of three short fragments
    # It is not downloaded fully but only the first fragment (for speed)

# Generated at 2022-06-12 16:36:21.462731
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    info_dict = InfoExtractor().extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    #info_dict = YoutubeIE()._real_extract('https://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-12 16:36:22.088819
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:36:34.160841
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..utils import ExtractorError
    from .dash import DashIE
    from .fragment import _dummy_write, _dummy_read

    # given
    fakefile = 'test_file'
    fakeurl = 'http://example.com/'
    fmt = 'DASH Manifest'

# Generated at 2022-06-12 16:36:42.463263
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    def test_valid_url(url):
        DashSegmentsFD(dict(url=url))
    test_valid_url('https://example.com/video.mpd')
    test_valid_url('dash://example.com/video.mpd')
    test_valid_url('dash-segments://example.com/video.mpd')
    # This is not a valid DASH URL but it shouldn't raise an exception
    test_valid_url('dash-segments://example.com/video.mp4')

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:36:48.665640
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os, sys, tempfile, unittest
    from ..YoutubeDL import YoutubeDL
    if sys.version_info >= (3, 0):
        from io import BytesIO as StringIO
    else:
        from StringIO import StringIO
    from . import MockHttpServer

    class TestDashSegmentsFD(unittest.TestCase):
        def setUp(self):
            self.server = MockHttpServer()
            self.server.start()
            self.ydl = YoutubeDL()

        def tearDown(self):
            self.server.stop()
            self.ydl.cleanup()

        def test_real_download(self):
            # Prepare test case
            fmt_url = self.server.get_url()
            output_file = tempfile.TemporaryFile()

# Generated at 2022-06-12 16:36:52.969062
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Test that constructor works with 'test' as True
    from .dashsegments import DashSegmentsFD
    dashsegments_fd = DashSegmentsFD({'test': True})
    assert dashsegments_fd.params.get('test') is True

# Generated at 2022-06-12 16:37:15.020648
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..compat import compat_urllib_request
    from ..utils import (
        encodeFilename,
        prepend_extension,
        sanitize_filename,
    )
    from .fragment import FragmentFD
    from .http import HttpFD

    filename_fmt = '%(playlist_index)s-%(id)s%(ext)s'

    def test_real_download(self, filename, info_dict):
        self.to_screen('[test] real_download called')

        self._check_params(info_dict)

        fragment_base_url = info_dict.get('fragment_base_url')
        fragments = info_dict['fragments']


# Generated at 2022-06-12 16:37:16.688161
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.FD_NAME == 'dashsegments'

# Generated at 2022-06-12 16:37:27.025993
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    expected = True

    class DummyDict(dict):
        def __init__(self, input_):
            dict.__init__(self, input_)
            DummyDict.inst = self

    # Create a dummy info_dict for class DashSegmentsFD
    info_dict = DummyDict(
        {
            'id':'test',
            'formats':[
                {
                    'url':'test',
                    'format_id':'test',
                    'ext':'test'
                }
            ],
            'format':'test',
            'http_headers':'test',
            'start_time':'test',
            'fragments':[
                'test'
            ],
            'title':'test',
            'manifest_url':'test'
        }
    )

   

# Generated at 2022-06-12 16:37:34.258756
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    class TestInfoDict(dict):
        def __missing__(self, key):
            return None

    info_dict = TestInfoDict()
    info_dict['fragments'] = []
    dash_fd = DashSegmentsFD(
        downloader=None,
        params=None,
        info_dict=info_dict,
    )
    assert dash_fd.FD_NAME == 'dashsegments'
    assert dash_fd.real_download(filename=None, info_dict=info_dict)

# Generated at 2022-06-12 16:37:41.151260
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import unittest
    class TestDashSegmentsFD_real_download(unittest.TestCase):
        def testDownload(self):
            self.assertTrue(1) #TODO: Implement real unit test
    print('Testing DashSegmentsFD.real_download')
    unittest.main()

if __name__ == '__main__':
    # Unit test DashSegmentsFD.real_download()
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-12 16:37:52.125258
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import YoutubeIE

    result = YoutubeIE()._real_extract('https://www.youtube.com/watch?v=JQbjWYZNOmg')


# Generated at 2022-06-12 16:38:05.490641
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import pytest
    from ..extractor.youtube import YoutubeIE
    from ..extractor.common import InfoExtractor
    from ..utils import ExtractorError
    from ytdl_test_data import YTDl_test_data
    test_data = YTDl_test_data()

    # Set the method of a YouTubeIE class object to the method real_download of a DashSegmentsFD class object
    YoutubeIE._real_extract = DashSegmentsFD.real_download

    # Prepare info_dict object for real_download method of DashSegmentsFD class object

# Generated at 2022-06-12 16:38:16.163180
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    expected = {
        'params': {
            'tbr': None,
            'format': None,
            'fragment_retries': '10'
        },
        'skip_download': True,
        'fragment_base_url': None,
        'fragments': [
            {'url': 'https://base_url/1.ts', 'path': '1.ts', 'duration': None},
            {'url': 'https://base_url/2.ts', 'path': '2.ts', 'duration': None},
            {'url': 'https://base_url/3.ts', 'path': '3.ts', 'duration': None},
            {'url': 'https://base_url/4.ts', 'path': '4.ts', 'duration': None},
        ],
    }
   

# Generated at 2022-06-12 16:38:18.223694
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD(dict(), {}, {}, True, {})

# Generated at 2022-06-12 16:38:19.127796
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-12 16:38:50.467323
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    Mon Dec 10 12:59:03 IST 2018
    class DashSegmentsFD 
    - test_DashSegmentsFD_real_download -
    {'_type': 'url', 'url': 'https://www.youtube.com/watch?v=cTpfjkyPnB8'}
    """
    from .common import FileDownloader
    ydl = FileDownloader({
        'format': 'bestaudio/best',
        'outtmpl': 'test.%(ext)s',
        'quiet': True,
        'no_warnings': True,
    })

# Generated at 2022-06-12 16:38:51.330228
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD(0,0)

# Generated at 2022-06-12 16:38:51.939801
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    return DashSegmentsFD

# Generated at 2022-06-12 16:38:53.366058
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print("\nTesting DashSegmentsFD_real_download ...")
    assert True

# Generated at 2022-06-12 16:39:01.949130
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DASHIE
    from .http import HTTPie
    from ..downloader.common import FileDownloader
    from ..downloader.http import HttpFD
    from ..compat import compat_urllib_error
    import os
    import tempfile
    import pytest
    import json

    # Generate the url to a test video
    url = 'http://www.youtube.com/watch?v=_HSylqgVYQI'
    ydl = FileDownloader(params={})
    ydl.add_info_extractor(DASHIE())
    ydl.add_info_extractor(HTTPie())
    info = json.loads(ydl.extract_info(url, download=False))
    assert 'formats' in info


# Generated at 2022-06-12 16:39:03.033059
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD(None, None)

# Generated at 2022-06-12 16:39:03.689692
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:39:15.157938
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import shutil
    import tempfile
    from ..extractor import gen_extractors, YoutubeIE
    from ..utils import prepend_extension
    #XXX: This test only works after the fix of the issue #16599
    url = 'https://github.com/rg3/youtube-dl/issues/16599'
    ie = gen_extractors(YoutubeIE.ie_key(), YoutubeIE.ie_key())[0]
    ie._downloader = type(__name__, (object,), {
        'params': {
            'noprogress': True,
            'quiet': True,
            'outtmpl': '-'
        }
    })()
    tmp_dir = tempfile.mkdtemp()

# Generated at 2022-06-12 16:39:25.369741
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DASHIE
    from .dash import DASHIF
    from .dash import DASHINGEST
    from .dash import DASH_HBBTV_DE_MW
    from .dash import DASH_YOUTUBE_F4M
    from .dash import DASH_YOUTUBE_F4M_HLS
    from .dash import DASH_YOUTUBE_F4M_KIDS
    from .dash import DASH_YOUTUBE_F4M_FORMATS
    from .dash import DASH_YOUTUBE_F4M_FORMATS_BETA
    from .dash import DASH_YOUTUBE_NEW_F4M
    from .dash import DASH_YOUTUBE_NEW_F4M_HLS
    from .fragment import FragmentFD

# Generated at 2022-06-12 16:39:35.799923
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    # test__download_fragment
    def _download_fragment(self, ctx, fragment_url, info_dict):
        return (True, '')
    # test_append_fragment
    def _append_fragment(self, ctx, frag_content):
        pass

    # test_report_retry_fragment
    def report_retry_fragment(self, error, frag_index, count, fragment_retries):
        print('retry_fragment')
        pass

    # test_report_skip_fragment
    def report_skip_fragment(self, frag_index):
        print('skip_fragment')
        pass

    # test_report_finish_frag_download

# Generated at 2022-06-12 16:40:31.064544
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..downloader.common import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import parse_filesize

    ydl = FileDownloader(params={
        'noplaylist': True,
        'outtmpl': '%(id)s%(ext)s',
    })
    ie = YoutubeIE()
    fd = DashSegmentsFD(ydl, ie, ie.url_result('7JbRiPpE944', {'fragments': list(), 'fragment_base_url': ''}))
    assert fd.get_media_data_length(None) == parse_filesize('0')

# Generated at 2022-06-12 16:40:36.199038
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import gen_extractors
    from .options import readOption, read_batch_urls
    for ie in gen_extractors():
        for url in ie.working_urls():
            info = ie.extract(url)
            DashSegmentsFD(read_batch_urls([url]), readOption(), info['formats'], {}, info['title'], None)

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:40:41.751091
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import io
    from .http import HttpFD
    from .generic import FileDownloader

    url = 'http://video-dev.github.io/streams/x36xhzz/x36xhzz.m3u8'
    ydl = FileDownloader({
        'skip_unavailable_fragments': False,
        'test': True,
    })

    class MockBuffer(io.BytesIO):
        def __init__(self, initial_bytes=''):
            super(MockBuffer, self).__init__()
            self.initial_bytes = initial_bytes
            self.buf = initial_bytes
        def read(self, size):
            ret = self.buf[:size]
            self.buf = self.buf[size:]

# Generated at 2022-06-12 16:40:52.021016
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
  from .fragment import FragmentFD
  from ..compat import compat_urllib_error
  from ..utils import parse_m3u8_attributes
  from ..extractor import get_info_extractor

  import os
  import sys
  import tempfile
  import urllib2
  import xattr

  class FormattedException(Exception):
      def __init__(self, message, error_code):
          super(FormattedException, self).__init__(message)
          self.error_code = error_code

  class MockYoutubeDl:
      params = {}
      def __init__(self):
          self.to_screen_lock = None
          self.tmpfilename = None
          self.tmpfilename_path = None
          self.fd = None
          self.report_error_count = 0


# Generated at 2022-06-12 16:40:57.551988
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import youtube_dl.downloader
    dashseg = youtube_dl.downloader.DashSegmentsFD()
    assert dashseg.FD_NAME == "dashsegments"

# Test to check whether the real_download method of class DashSegmentsFD
# returns the appropriate list of values and corresponding errors

# Generated at 2022-06-12 16:41:08.061981
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    import tempfile
    import mock
    import os.path
    from ..YoutubeDL import YoutubeDL

    filepath = 'tmp_file'
    filename = 'test_DashSegmentsFD_real_download'

    manifest = {
        'fragments': [
            {'url': 'http://test.com/0'},
            {'url': 'http://test.com/1'},
            {'url': 'http://test.com/2'},
            {'url': 'http://test.com/3'},
            {'url': 'http://test.com/4'}
        ]
    }

    # Test for retries

# Generated at 2022-06-12 16:41:09.018586
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    #TODO: add test
    pass

# Generated at 2022-06-12 16:41:15.868066
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))))
    from .dashsegments import DashSegmentsFD
    from .dash_manifest import DashManifestFD
    from .http import HttpFD
    from .http import HlsSegmentsFD

    dash_manifest_url = "http://rdmedia.bbc.co.uk/dash/ondemand/bbb/2/client_manifest-common_init.mpd"
    dash_manifest = DashManifestFD(dash_manifest_url)
    dash_manifest.download(dash_manifest_url, {}, {}, None)


# Generated at 2022-06-12 16:41:21.567788
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import io
    import pytest
    from ..downloader import apply_descramble_server_options
    from ..utils import (
        encodeFilename,
        fake_to_real_path,
        prepare_filename,
        )
    from .http import HttpFD
    from .dash import (
        _parse_dash_mpd_formats,
        )

    class FakeYtdlFile:
        pass


# Generated at 2022-06-12 16:41:33.374629
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .http import HttpFD
    info_dict = {'url': 'http://example.com/file.mpd',
                 'format_id': 'best',
                 'ext': 'mp4',
                 'fragments': [{'duration': 4.0,
                                'url': 'http://example.com/fileSeg1-Frag1'},
                               {'duration': 4.0,
                                'url': 'http://example.com/fileSeg1-Frag2'},
                               {'duration': 4.0,
                                'url': 'http://example.com/fileSeg1-Frag3'}],
                 'fragment_retries': 0,
                 'skip_unavailable_fragments': False}
    http_fd = HttpFD(params={'noprogress': 'yes'})