

# Generated at 2022-06-12 16:33:52.939807
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD(downloader=None, params=None)
    return fd

# Generated at 2022-06-12 16:34:01.064606
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    '''
    Passes if the real_download method of class DashSegmentsFD returns True.
    '''

# Generated at 2022-06-12 16:34:01.830956
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert DashSegmentsFD().test() == True

# Generated at 2022-06-12 16:34:02.401589
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass



# Generated at 2022-06-12 16:34:14.725644
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .http import HttpFD
    from ..extractor.common import InfoExtractor

# Generated at 2022-06-12 16:34:22.381353
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import re
    import unittest
    try:
        from urllib.parse import parse_qs
    except ImportError:
        from urlparse import parse_qs

    import RTMP

    from .dash import parse_dash_manifest

    from ..utils import (
        OnDemandPagedList,
    )

    from .fragment import (
        download_fragment_with_rtmpdump,
        limit_length,
    )

    from .http import (
        HttpFD,
    )

    from ..downloader import (
        DownloadContext,
        Downloader
    )


# Generated at 2022-06-12 16:34:27.747234
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({})
    segments = DashSegmentsFD(ydl)
    assert segments.downloader == ydl
    assert segments.num_downloads == 0
    assert segments.params == {}
    assert segments.frag_index == 0
    assert segments.frag_count == 0
    assert segments.downloaded_bytes == 0
    assert segments.total_bytes == 0

# Generated at 2022-06-12 16:34:39.690125
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HTTPDownloader

    class FakeIE(InfoExtractor):
        def __init__(self, info_dict):
            InfoExtractor.__init__(self, None)
            self._info_dict = info_dict

        def _real_extract(self, url):
            return self._info_dict

    ie = FakeIE({'fragment_base_url': 'http://example.com/fragments/',
        'fragments': [
            {'path': 'segment1.m4s'},
            {'path': 'segment2.m4s'},
        ]})

    d = HTTPDownloader(ie, {'test': True}, '-')

# Generated at 2022-06-12 16:34:40.344839
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:34:40.951865
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:34:56.771659
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import sys
    import time
    import pytest
    from posixpath import join as urljoin
    from .common import (
        FakeYDL,
        get_basic_test_cases,
        get_basic_test_opts,
        test_result_data_basic,
    )
    from ..utils import (
        encodeFilename,
        prepend_extension,
    )
    from ..extractor import (
        gen_extractors,
        get_info_extractor,
    )
    from ..downloader import (
        FragmentFD,
    )
    from ..postprocessor.ffmpeg import FFmpegPostProcessor

    def test(ydl, inputs, options, expected_data):
        res_filename = expected_data['_filename']

# Generated at 2022-06-12 16:35:07.698180
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD
    from ..extractor import YoutubeIE
    from ..utils import OnDemandPagedList
    import sys


# Generated at 2022-06-12 16:35:09.176899
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    i = DashSegmentsFD()
    assert isinstance(i, DashSegmentsFD)

# Generated at 2022-06-12 16:35:11.996901
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert DashSegmentsFD().real_download('output.mp4', {'fragments': [{'url': 'http://example.com/segment.mp4'}, {'url': 'http://example.com/segment.mp4'}]}) == True


# Generated at 2022-06-12 16:35:22.960672
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from . import FragmentFD
    from .dashsegments import DashSegmentsFD
    from .http import HttpFD
    from .rtmp import RtmpFD
    from .smoothstreaming import SmoothStreamingFD
    from .hls import HlsFD

    def download(fd_class, protocol=None, ext=None, **kwargs):
        info = {
            'protocol': protocol,
            'ext': ext,
        }
        # Set protocol and format
        if protocol == 'hls':
            info['fragment_base_url'] = 'http://example.com%2Fpath%2Fto%2F'
        else:
            info['fragment_base_url'] = 'http://example.com/path/to/'

# Generated at 2022-06-12 16:35:29.474936
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL()
    ydl.params['nooverwrites'] = True
    ydl.params['nopart'] = True
    ydl.params['continuedl'] = False
    ydl.params['noprogress'] = True
    ydl.params['forcetitle'] = True
    ydl.params['test'] = True
    ydl.add_default_info_extractors()
    res = ydl.extract_info(
        'https://www.youtube.com/watch?v=PLQaN0xHADI', download=True)
    import os
    assert os.path.exists(res['title'] + '.f137.1.mp4')

# Generated at 2022-06-12 16:35:32.289008
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashSegmentsFD_test, test_dash
    return DashSegmentsFD_test(DashSegmentsFD)(test_dash, 'DashSegmentsFD')

# Generated at 2022-06-12 16:35:33.474323
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD({}, None, None)

# Generated at 2022-06-12 16:35:43.010578
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    ie = YoutubeIE()

# Generated at 2022-06-12 16:35:54.436903
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader.common import FileDownloader
    from ..utils import encodeFilename
    from .http import HttpFD
    from .fragment import FragmentFD
    from .dashsegments import DashSegmentsFD

    info = {'url': 'http://dashsegments.url/file.mp4', 'ext': 'mp4'}
    dl = FileDownloader(params={
        'format': 'http',
        'http_chunk_size': 50000,
        'noprogress': True,
        'nopart': True,
        'test': True,
        'outtmpl': encodeFilename('test_DashSegmentsFD_real_download')
    }, info_dict=info)
    dashsegmentsFD = DashSegmentsFD(dl, dl.params)

# Generated at 2022-06-12 16:36:15.086443
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_url = 'http://www.youtube.com/api/manifest/dash/id/bf5bb2419360daf1/source/youtube?' \
               'as=fmp4_audio_clear,fmp4_sd_hd_clear&sparams=ip,ipbits,expire,source,id,as&ip=0.0.0.0&' \
               'ipbits=0&expire=19000000000&signature=255F6B3C07C753C88708C07EA31B7B1A10703C8D.' \
               '2D6A28B21F921D0B245CDCF36F7EB54A2B5ABFC2&key=ik0'
    test_result = DashSegmentsFD._extract_info(test_url)
    assert test_result

# Generated at 2022-06-12 16:36:16.506545
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    downloader = DashSegmentsFD()    # check if it can be instantiated

# Generated at 2022-06-12 16:36:21.067824
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    info_dict = {
        'id': 'a',
    }
    url = 'https://example.com/manifest.mpd'

    fd = DashSegmentsFD(url, info_dict)
    assert fd.params.get('test', False) == False
    assert fd.params.get('noprogress', False) == False

# Unit test to test downloading of a single fragment

# Generated at 2022-06-12 16:36:32.836872
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import _common_options, _encode_fragments, _write_fragments, _download_fragments
    from ..utils import encode_data_uri
    opts = _common_options()
    opts.noprogress = True
    info = {'fragments': _encode_fragments(opts, '1kb/1.ts', 10),
            'fragment_base_url': encode_data_uri(b'1kb/1.ts')}
    fd = DashSegmentsFD(opts, info)
    valid, info = fd.real_download("output", info)
    assert valid
    _write_fragments(opts, info)
    _download_fragments(opts, info)

# Generated at 2022-06-12 16:36:43.254489
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    import os
    import shutil

    ydl = YoutubeDL({'fragment_retries': 1, 'ignoreerrors': True, 'logger': None})

    # Successful case
    assert os.path.exists(ydl.dlfilepath('test_DashSegmentsFD_real_download'))
    os.remove(ydl.dlfilepath('test_DashSegmentsFD_real_download'))
    assert not os.path.exists(ydl.dlfilepath('test_DashSegmentsFD_real_download'))
    fragments = [
        {'path': 'x'},
        {'path': 'y'},
        {'path': 'z'},
    ]

# Generated at 2022-06-12 16:36:56.009793
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys, os, shutil
    from ..extractor.common import InfoExtractor
    from ..utils import encodeFilename
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_parse

    # Hack to save memory while testing
    class NoDictIE(InfoExtractor):
        def _real_extract(self, url):
            info_dict = super(NoDictIE, self)._real_extract(url)
            info_dict.pop('formats', None)
            info_dict.pop('thumbnails', None)
            info_dict.pop('description', None)
            if 'url' in info_dict:
                info_dict['url'] = self._match_id(info_dict['url'])
            return info_dict

    test_video_id

# Generated at 2022-06-12 16:36:57.915715
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    downloader = DashSegmentsFD({})
    assert downloader.params['test'] is False



# Generated at 2022-06-12 16:37:10.656110
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL

    mydl = YoutubeDL()
    mydl.params['hls_use_mpegts'] = True
    mydl.add_default_info_extractors()

    data_dict = {
        'ext': 'mp4',
        'fragments': [{
            'url': 'http://example.com/frag1'
        }, {
            'path': 'frag2',
            'base_url': 'fragment_base_url',
        }]
    }

    with mydl.prepare_filename(data_dict) as filename:
        fd = DashSegmentsFD(mydl, filename, data_dict)
        assert not fd.finished

        fd.download(filename, data_dict)
        assert fd.finished

# Generated at 2022-06-12 16:37:22.461701
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-12 16:37:25.242988
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    segments = FragmentFD('dashsegments')
    assert segments.FD_NAME == 'dashsegments'
    assert segments.is_needed('test') == 1

test_DashSegmentsFD()

# Generated at 2022-06-12 16:37:48.226323
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    isinstance(DashSegmentsFD(None, {}), dashsegmentsFD)


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 16:37:50.316817
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dashsegments_fd = DashSegmentsFD({})

    assert(dashsegments_fd.FD_NAME == 'dashsegments')

# Generated at 2022-06-12 16:37:56.226200
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    ydl = YoutubeDL()
    ydl.params['test'] = True
    from .extractor import YoutubeIE
    ie = YoutubeIE(ydl=ydl)
    info_dict = {
        'fragments': [],
        'fragment_base_url': 'https://example.com/dash/segments',
        'protocol': 'https',
        'fulltitle': 'foo',
        '_type': 'hls',
        'id': 'bar',
        'display_id': 'bar',
    }
    fd = DashSegmentsFD(ie, info_dict)
    assert fd.get_basename() == 'foo.mp4'
    assert fd.real_download('bar', info_dict) is True

# Generated at 2022-06-12 16:37:59.205310
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.get_supported_protocols(None)[0] == 'dashsegments'



# Generated at 2022-06-12 16:38:00.410172
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # stub
    return True

# Generated at 2022-06-12 16:38:01.737269
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD({})

# Generated at 2022-06-12 16:38:13.538867
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import re
    import sys
    import tempfile
    import unittest

    import youtube_dl.YoutubeDL as youtube_dl

    import youtube_dl.extractor.youtube as youtube
    # import youtube_dl.extractor.test_youtube
    import youtube_dl.extractor.common as common

    MP4_FRAGMENT_HEAD = b'\x00\x00\x00\x18moof\x00\x00\x00'

    class TestYouTubeDLSimple(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(TestYouTubeDLSimple, self).__init__(*args, **kwargs)
            self.to_stderr = self.to_screen = self.report_error = lambda *args, **kwargs: None

   

# Generated at 2022-06-12 16:38:26.529616
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import Downloader
    from ..extractor import get_info_extractor
    from ..YoutubeIE import YoutubeIE
    from ..YoutubePlaylistIE import YoutubePlaylistIE
    import sys
    d = Downloader()

    ie = get_info_extractor(YoutubeIE.ie_key())
    info = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    info_dict = ie._get_info(d, 'https://www.youtube.com/watch?v=BaW_jenozKc', download=False)
    fd = DashSegmentsFD()
    res = fd.real_download(sys.argv[1], info_dict)
    print("Test result: %s"%(res))

# Generated at 2022-06-12 16:38:27.747128
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    return DashSegmentsFD()

# Generated at 2022-06-12 16:38:28.310784
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:39:18.616913
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_ManifestFD = DashSegmentsFD({})
    assert dash_ManifestFD.params == {}
    print(dash_ManifestFD.FD_NAME)
    dash_ManifestFD = DashSegmentsFD({'fragment_retries': 10})
    assert dash_ManifestFD.params == {'fragment_retries': 10}
    dash_ManifestFD = DashSegmentsFD({'fragment_base_url': 'https://test.com'})
    assert dash_ManifestFD.params == {'fragment_base_url': 'https://test.com'}
    dash_ManifestFD = DashSegmentsFD({'size': 89.1e6})
    assert dash_ManifestFD.params == {'size': 89.1e6}

# Generated at 2022-06-12 16:39:27.835321
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    ydl = YoutubeDL({})
    info_dict = {}
    fragment_urls = [{
        'url': 'http://example.com/1.ts',
    }, {
        'path': '2.ts',
        'base_url': 'http://example.com/',
    }]
    info_dict['fragment_base_url'] = 'http://example.com/'
    info_dict['fragments'] = fragment_urls
    fd = DashSegmentsFD(ydl, info_dict)
    assert fd.uris == [
        'http://example.com/1.ts',
        'http://example.com/2.ts',
    ]

# Generated at 2022-06-12 16:39:37.910277
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    try:
        import youtube_dl
    except ImportError:
        # youtube-dl not installed
        return
    params = {
        'format': 'bestvideo+bestaudio',
        'noplaylist': 'True',
        'outtmpl': None,
        'nocheckcertificate': 'True',
    }
    with youtube_dl.YoutubeDL(params) as ydl:
        ydl.add_default_info_extractors()
        res = ydl.extract_info('http://www.youtube.com/watch?v=BaW_jenozKc', {'simulate': 'True'})
    if res.get('fragments'):
        assert len(res.get('fragments')) > 0
        m = DashSegmentsFD(ydl=ydl, params=params)


# Generated at 2022-06-12 16:39:48.985031
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-12 16:39:51.974441
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    url = 'http://youtube.com/watch?v=BaW_jenozKc'
    DashSegmentsFD().download(url)

# Generated at 2022-06-12 16:39:52.995733
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # test for init
    DashSegmentsFD()

# Generated at 2022-06-12 16:39:58.101503
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Basic test
    info_dict = {
        'id': 'test_id',
        'url': 'test_url',
        'ext': 'test_ext',
        'webpage_url': 'test_web',
        'title': 'test_title',
    }
    dummy_ydl = object()
    dsfd = DashSegmentsFD(dummy_ydl, info_dict)
    assert dsfd.info_dict == info_dict

# Generated at 2022-06-12 16:40:09.489213
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    ''' Force an exception in method _download_fragment to test code '''
    import sys
    import io
    from collections import namedtuple
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    from ..utils import encodeArgument

    class TestYoutubeDL(YoutubeDL):
        def to_screen(self, message, skip_eol=False):
            print(message.encode(sys.stdout.encoding or 'utf-8'), end='' if skip_eol else '\n')
        def trouble(self, message, tb=None):
            print('ERROR: ' + message)
            if tb is not None:
                print(''.join(traceback.format_tb(tb)))

# Generated at 2022-06-12 16:40:21.434593
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import os
    import sys
    import tester
    import youtube_dl

    try:
        youtube_dl.utils.compat_urllib_request.urlopen(
            "http://example.com/").read(1024)
    except (OSError, ValueError, compat_urllib_error.URLError):
        sys.exit(
            'You should connect to the Internet to run this test.\n'
            'Or if you are behind a firewall install CERTIFI '
            '(https://pypi.python.org/pypi/certifi) and set '
            'the HTTPS_PROXY environment variable to your proxy server.'
        )

    # Create the test output directory
    test_output_dir = os.path.join(os.path.dirname(__file__), 'test_output')
   

# Generated at 2022-06-12 16:40:33.224634
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    This unit test checks if DashSegmentsFD is able to tackle with
    different types of fragments.
    """

    from ..utils import (
        encodeFilename,
    )

    from .fragment import (
        FragmentFD,
    )

    from .http import (
        HttpFD,
    )

    from .dash import (
        DashFragmentsFD,
    )

    # Test case 1: test with fragmented MPD manifest
    test_case_name = 'TestDashSegmentsFD, test_case_1'

# Generated at 2022-06-12 16:42:21.823280
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:42:29.294948
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys,os
    old_sys_argv = sys.argv

# Generated at 2022-06-12 16:42:39.757094
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():                                           # pylint: disable=unused-variable
    import json
    import os
    from .http import HttpFD
    from . import YoutubeDL


# Generated at 2022-06-12 16:42:50.119456
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.common import InfoExtractor
    from ..extractor.dash import DASHIE

# Generated at 2022-06-12 16:42:55.025998
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .http import HttpFD
    import os
    fd = DashSegmentsFD(params={'outtmpl':os.path.expanduser('~/Desktop/%(stitle)s/%%(title)s.%%(ext)s')})
    fd.real_download('', {})

# Generated at 2022-06-12 16:43:04.821300
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    import os
    import tempfile
    from ..downloader.common import FileDownloader

    url = "https://www.youtube.com/watch?v=AaI6cHSCT6U&feature=player_embedded"
    fd, path = tempfile.mkstemp(suffix='.mp4')
    os.close(fd)
    # --write-auto-sub will cause crash (YoutubeDL should not crash, but
    # that's a separate issue)
    argv = ['--no-check-certificate', '--simulate', '--format=140', '--outtmpl', path, '--write-auto-sub']

# Generated at 2022-06-12 16:43:05.990581
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dashSegmentsFD = DashSegmentsFD({})

# Generated at 2022-06-12 16:43:15.810434
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .dash import DashSegmentsFD_test
    from .mpegts import MpegtsFD_test
    from .hls import HlsFD_test
    from .m3u8 import M3u8FD_test

    # Test DashSegmentsFD, MpegtsFD, HlsFD, and M3u8FD by calling download of DashSegmentsFD
    # test_DashSegmentsFD() calls test_MpegtsFD() 
    # test_MpegtsFD() calls test_HlsFD()
    # test_HlsFD() calls test_M3u8FD()

    DashSegmentsFD_test.test_DashSegmentsFD()
    MpegtsFD_test.test_MpegtsFD()
    HlsFD_test.test_HlsFD()
    M3u8FD_test.test_M3u

# Generated at 2022-06-12 16:43:22.316041
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    filename = "filename"

# Generated at 2022-06-12 16:43:27.085896
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dash_segments_fd = DashSegmentsFD()
    assert dash_segments_fd.real_download('filename', {'fragments': [{'url': 'http://www.example.com'}]}) == True

# vim: sw=4 ts=4 expandtab