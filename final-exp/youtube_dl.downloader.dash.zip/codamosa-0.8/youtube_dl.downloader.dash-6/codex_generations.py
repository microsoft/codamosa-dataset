

# Generated at 2022-06-12 16:33:52.123187
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Check default constructor of class DashSegmentsFD
    dash_segment_fd = DashSegmentsFD()
    assert dash_segment_fd.params == {'format': 'bestvideo+bestaudio'}

# Generated at 2022-06-12 16:34:00.383585
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    '''
    Test function test_DashSegmentsFD.
    
    Will create a new DashSegmentsFD object.
    '''
    test_DSFD = DashSegmentsFD()
    assert test_DSFD.params == {'quiet': False}
    assert test_DSFD.frag_downloader is None
    assert test_DSFD.fragment_progress_hook is None
    assert test_DSFD.to_stderr is None
    assert test_DSFD.simulate is False
    assert test_DSFD.format_note == '%(filename)s: %(format_note)s'
    assert test_DSFD.skip == False
    assert test_DSFD.total_frags == -1
    assert test_DSFD.retries == 10

# Generated at 2022-06-12 16:34:11.343330
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    ydl = YoutubeDL({})
    info_dict = {
        'id': 'foo',
        'ext': 'mp4',
        'title': 'foo video',
        'thumbnail': 'foo.jpg',
        'view_count': 42,
        'webpage_url': 'foo.com',
        'duration': 3,
        'fragment_base_url': 'https://example.com/dash/segments/',
        'fragments': [
            {'url': 'https://example.com/dash/segments/foo/bar.m4f', 'path': 'foo/bar.m4f'},
            {'url': 'https://example.com/dash/segments/foo/baz.m4f', 'path': 'foo/baz.m4f'}
        ]
    }

# Generated at 2022-06-12 16:34:17.252665
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # pylint: disable=redefined-outer-name
    from ..extractor import YoutubeIE
    url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    ydl = YoutubeIE(url)
    # test extraction from a youtube video
    info = ydl.extract()
    assert 'fragment_base_url' in info['formats'][0]
    return True
#test_DashSegmentsFD()

# Generated at 2022-06-12 16:34:23.719511
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import mock
    from ..common import FileDownloader
    from ..YoutubeDL import YoutubeDL
    downloader = FileDownloader(YoutubeDL())
    dashsegmentsfd = DashSegmentsFD(downloader)

    # Test normal operation (no error)
    dashsegmentsfd._prepare_and_start_frag_download = mock.Mock()
    dashsegmentsfd._append_fragment = mock.Mock()
    dashsegmentsfd._finish_frag_download = mock.Mock()
    dashsegmentsfd.real_download('filename', {'fragments': [{'url': 'url1'}, {'url': 'url2'}, {'url': 'url3'}]})
    assert dashsegmentsfd._append_fragment.call_count == 3
    assert dashsegmentsfd._fin

# Generated at 2022-06-12 16:34:35.019486
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..downloader import AvgBitrateEstimates
    from ..downloader.common import FileDownloader
    from ..extractor import YoutubeIE
    from ..utils import encodeFilename
    from .http import HttpFD
    # Skip test if dashsegments is not available
    try:
        DashSegmentsFD
    except NameError:
        return
    # Run test
    results = FileDownloader().process_ie_result(
        YoutubeIE(),
        {
            '_type': 'url',
            'url': 'https://www.youtube.com/watch?v=gE1BwOZbW8M',
            'ie_key': 'Youtube',
        },
        download=False,
        ie_key='Youtube',
        extra_info={'format': 'best'}
    )

# Generated at 2022-06-12 16:34:41.195577
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Execute real_download method of class DashSegmentsFD
    # test_DashSegmentsFD_real_download()

    #self.report_retry_fragment(Exception(), 1, 1, 10)
    #self.report_skip_fragment(1)
    #self.report_error('giving up after %s fragment retries' % 10)
    pass

# Execute test function
#test_DashSegmentsFD_real_download()

# Generated at 2022-06-12 16:34:52.667576
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    from .dash import DashFD
    assert DashSegmentsFD.suitable(None, {'protocol': 'dashsegments'})
    assert FragmentFD.can_download()
    assert DashFD.can_download()
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()
    ydl.add_info_extractor(DashSegmentsFD())
    ydl.add_info_extractor(DashFD())
    ydl.params['skip_download'] = True
    # info_dicts will be empty, the point here is to test if it crashes
    ydl.download(['http://example.com/dashsegments-test',
                  'http://example.com/dash-test'])

# Generated at 2022-06-12 16:35:01.497462
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor.dashsegments import DashSegmentsIE
    from ..downloader.common import FileDownloader
    from ..compat import compat_str
    import os

    dash_test_folder = os.path.join(
        os.path.dirname(os.path.abspath(__file__)), 'test', 'data', 'dash')
    video_file = os.path.join(dash_test_folder, 'video_file.ts')
    audio_file = os.path.join(dash_test_folder, 'audio_file.mp4')
    manifest_file = os.path.join(dash_test_folder, 'manifest.mpd')

    downloader = FileDownloader({'quiet': True})


# Generated at 2022-06-12 16:35:03.650166
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Create instance of class DashSegmentsFD
    dashsegmentsFD = DashSegmentsFD({}, {}, {}, {}, {}, None)
    pass

# Generated at 2022-06-12 16:35:11.233264
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD(None, {})

# Generated at 2022-06-12 16:35:12.316889
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True == False, "pytest unit test stub"

# Generated at 2022-06-12 16:35:23.473723
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from . import FileDownloader

# Generated at 2022-06-12 16:35:34.883833
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print('Testing DashSegmentsFD')

    import youtube_dl.YoutubeDL
    ydl = youtube_dl.YoutubeDL({'format': '251/251'})
    dashsegments_fd = DashSegmentsFD({'format': '251/251'}, ydl)

    #print(dashsegments_fd.params)
    assert(dashsegments_fd.params['format'] == '251/251')
    assert(dashsegments_fd.name == 'dashsegments')
    assert(dashsegments_fd.simulate is False)
    assert(dashsegments_fd.frag_index == 0)
    assert(dashsegments_fd.continued_dl is False)
    assert(dashsegments_fd.total_frags is None)

#test_DashSegmentsFD()

# Generated at 2022-06-12 16:35:44.007153
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import downloader
    import extractor
    import http.server
    import json
    import os
    import re
    import shutil
    import socket
    import socketserver
    import tempfile
    import threading
    from .common import FakeYDL

    # Start HTTP server
    testdata_dir = os.path.join(os.path.dirname(__file__), 'testdata')
    httpd = socketserver.TCPServer(
        ('127.0.0.1', 0), http.server.SimpleHTTPRequestHandler)
    httpd.socket.settimeout(30)
    threading.Thread(target=httpd.serve_forever).start()
    server_address = httpd.server_address


# Generated at 2022-06-12 16:35:50.530133
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.__name__ == 'DashSegmentsFD'
    assert DashSegmentsFD.get_protocol() == 'dashsegments'
    assert DashSegmentsFD.FD_NAME == 'dashsegments'
    assert DashSegmentsFD.__doc__ == '\n    Download segments in a DASH manifest\n    '
# test the above constructor by creating an instance of this class.
test_DashSegmentsFD()

# Generated at 2022-06-12 16:35:56.475126
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    class FakeInfoDict:
        fragment_base_url = "abc"

        fragments = [{'url': 'http://a.com/1.ts'},
                     {'url': 'http://b.com/2.ts'},
                     {'url': 'http://b.com/3.ts'}]

    dash_seg_fd = DashSegmentsFD(None, None, None)
    dash_seg_fd.real_download("123.ts", FakeInfoDict)
    pass

# Generated at 2022-06-12 16:36:02.653801
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import unittest
    import sys
    sys.path.append('../youtube_dl')
    import YoutubeDL
    class DashSegmentsFDTest(unittest.TestCase):
        def setUp(self):
            self.temp_path = 'test_video.mp4'
        def tearDown(self):
            #os.remove(self.temp_path)
            pass
        def test_real_download(self):
            # test real_download method of class DashSegmentsFD
            ydl = YoutubeDL.YoutubeDL()
            ydl.add_default_info_extractors()
            with open('dash_manifest_url.txt', 'r') as f:
                manifest_url = f.readline()

# Generated at 2022-06-12 16:36:04.431783
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    return FragmentFD._test_real_download(DashSegmentsFD)

# Generated at 2022-06-12 16:36:06.644739
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # TODO: add a unit test for this method
    raise NotImplementedError


# Generated at 2022-06-12 16:36:32.020913
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    ydl = FileDownloader({'outtmpl': 'test'})
    ie = YoutubeIE(ydl)

    # test available formats
    formats = ie._extract_formats('NA9r9nOL-fk', ie.url_result('http://www.youtube.com/watch?v=NA9r9nOL-fk'))
    dsfd_formats = [f for f in formats if f['protocol'] == 'dashsegments']
    assert len(dsfd_formats) > 0
    ff = dsfd_formats[-1]
    assert ff['ext'] == 'mp4'

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:36:34.100718
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import _test_real_download
    _test_real_download(DashSegmentsFD)

# Generated at 2022-06-12 16:36:44.343598
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    The real_download method of the DashSegmentsFD class should download all segments
    of a DASH manifest and merge them into one file.
    """

    # Import modules
    import os
    import sys

    # Code to test
    import ytdl

    # Download a DASH manifest with 5 segments and merge them into one file

# Generated at 2022-06-12 16:36:44.934580
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-12 16:36:50.129477
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Construct an object to test constructor of class DashSegmentsFD
    test_obj = DashSegmentsFD('rtsp://server/file.mpd', {'noplaylist': True}, {})
    return test_obj.noplaylist


# Generated at 2022-06-12 16:36:51.755295
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # TODO: Implement

    return True


# Generated at 2022-06-12 16:36:55.870036
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """Basic unit test for DashSegmentsFD"""

    dashfd = DashSegmentsFD()
    print(dashfd)

if __name__ == "__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:36:56.526600
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-12 16:36:57.614654
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    raise Exception("test not implemented")

# Generated at 2022-06-12 16:37:09.920707
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .test.test_downloader import FakeYdl
    from .test.test_downloader import TFragmentFD
    from .test.test_downloader import TFragmentFD_real_download
    from .test.test_downloader import TFragmentFD_real_download_test
    from .test import FakeSegment


# Generated at 2022-06-12 16:38:01.914021
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    import tempfile
    import os.path
    ydl = YoutubeDL()
    ydl.params['outtmpl'] = os.path.join(tempfile.gettempdir(), 'tmp%(id)s.mp4')
    ydl.params['skip_download'] = False
    ydl.params['download_archive'] = "tmp_archive.txt"
    #test_video: https://www.youtube.com/watch?v=Jk86yCxO7Jo

# Generated at 2022-06-12 16:38:13.672245
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    from ..downloader import FileDownloader
    from ..utils import get_cachedir
    fd = DashSegmentsFD()
    # Set up FileDownloader
    params = {}
    params['test'] = True
    params['cachedir'] = get_cachedir()
    params['retries'] = 1

    fd.params = params
    # Set up fake info dict
    info_dict = {'url': 'fake', 'playlist_index': 1}
    info_dict['fragment_base_url'] = 'fake'
    fragments = []
    fragments.append({'url': 'http://fake.org/1', 'path': '1'})
    fragments.append({'url': 'http://fake.org/2', 'path': '2'})

# Generated at 2022-06-12 16:38:14.631869
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:38:16.358263
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Testing constructor of class FragmentFD
    dashSegmentFD = DashSegmentsFD()

# Generated at 2022-06-12 16:38:17.171468
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:38:22.927813
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    class test:
        params = {'format': 'bestaudio/best', 'outtmpl': '%(id)s.%(ext)s'}
    class test2:
        ydl = test()
    DashSegmentsFD(test2(), None, {})

# Generated at 2022-06-12 16:38:23.889072
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:38:33.870029
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-12 16:38:41.004057
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import YoutubeDL
    ydl = YoutubeDL()
    ydl.add_info_extractor(YoutubeIE())
    res = ydl.extract_info(
        'http://www.youtube.com/watch?v=9bZkp7q19f0', download=False,
        process=False)
    ydl.process_info(res)
    ydl.params = {
        'test': True,
    }
    d = DashSegmentsFD()
    d.add_info_extractor(YoutubeIE())
    d.params = {
        'test': True,
    }
    assert d.real_download(
        'test.f4m', res['requested_formats'][-1])

# Generated at 2022-06-12 16:38:43.343517
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import test_FragmentFD_real_download_common
    test_FragmentFD_real_download_common(DashSegmentsFD)

# Generated at 2022-06-12 16:39:39.665206
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    from ..extractor import get_info_extractor

    ydl = YoutubeDL({})
    ie = get_info_extractor('youtube')
    ie.initialize()
    info = ie.extract('o_O')

    # Constructor from info_dict and simple downloader
    fd = DashSegmentsFD.from_info_dict(ydl, info)
    assert fd.downloader

    ydl = YoutubeDL({})
    # Constructor also works without downloader (for test purposes)
    # WARNING: this is not the intended way to call the constructor
    fd = DashSegmentsFD.from_info_dict(ydl, info)
    assert not fd.downloader

# Test downloading multiple fragments

# Generated at 2022-06-12 16:39:40.247082
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-12 16:39:42.244855
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:39:54.705301
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import io
    import json
    from ..utils import sanitize_open
    from ..downloader.common import FileDownloader

    def mock_http_downloader(ydl, url_or_request, filename, *args, **kwargs):
        assert url_or_request == 'http://example.com/fragment-1.m4s'
        return io.open(filename, 'wb')

    def mock_fragment_wrapper(self, name, obj, *args, **kwargs):
        assert name == 'http-download'
        assert isinstance(obj, compat_urllib_request.Request)
        assert obj.get_full_url() == 'http://example.com/fragment-1.m4s'
        assert obj.get_method() == 'GET'

# Generated at 2022-06-12 16:39:56.073202
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert DashSegmentsFD(None).real_download(None, None) is None


# Generated at 2022-06-12 16:40:08.059505
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    try:
        import youtube_dl
    except ImportError as e:
        error = True
    print('youtube-dl is imported')
    
    import os
    import shutil
    import sys
    try:
        if os.path.exists('test_dir'):
            shutil.rmtree('test_dir')
    except Exception as e:
        error = True
        
    test_dir = os.path.join(os.getcwd(), 'test_dir')
    
    error = False
    try:
        os.makedirs(os.path.join('test_dir', 'foo_video'))
        os.makedirs(os.path.join('test_dir', 'bar_video'))
    except Exception as e:
        error = True
        
    print('test directory created')
    

# Generated at 2022-06-12 16:40:08.930987
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # TODO: Replace with proper unit test
    return False

# Generated at 2022-06-12 16:40:12.342346
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Check if DashSegmentsFD is created with the given video
    dashsegmentsfd = DashSegmentsFD(params={})
    assert dashsegmentsfd.__class__.__name__ == "DashSegmentsFD"

# Generated at 2022-06-12 16:40:19.084011
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_args = {
        # FIXME: add a test case
    }
    run_test_main(test_args, __file__, [DashSegmentsFD])

if __name__ == '__main__':
    test_args = {
        # FIXME: add a test case
    }
    run_test_main(test_args, __file__, [DashSegmentsFD])

# Generated at 2022-06-12 16:40:21.636686
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """
    DashSegmentsFD(ydl, params)
    """
    assert DashSegmentsFD

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:42:36.081391
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.youtube import YoutubeIE
    ie = YoutubeIE()
    dash_manifest_url = 'http://www.youtube.com/api/manifest/dash/id/bf5bb2419360daf1/source/youtube?as=fmp4_audio_clear,fmp4_sd_hd_clear&sparams=ip,ipbits,expire,source,id,as&ip=0.0.0.0&ipbits=0&expire=19000000000&signature=255F6B3C07C753C88708C07EA31B7A1A10703C8D.04C88036EEE12565A1ED864A875A58F15D8B5300&key=ik0',
    manifest = ie._download_json(dash_manifest_url, video_id='')


# Generated at 2022-06-12 16:42:47.635205
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    deterministic = lambda: True
    import common_lib
    common_lib.set_deterministic(deterministic)

    from io import BytesIO
    from io import StringIO
    from os import remove
    from os.path import join
    from tempfile import TemporaryDirectory
    from test.testcommon import DummyYDL
    from unittest import TestCase
    from youtube_dl.downloader.dash import DashSegmentsFD
    from youtube_dl.postprocessor.common import FFmpegMergerPP

    ## DashSegmentsFD

    def test1():
        test_file = join('test', 'resources', 'dash_manifest.mpd')
        with open(test_file) as file:
            xml = file.read()
        ydl = DummyYDL()
        ydl.params = {'simulate': True}

# Generated at 2022-06-12 16:42:57.359473
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import tempfile
    import shutil
    import json
    from .dashsegments import DASHSegmentsFD
    from .ttml import TTMLFD

# Generated at 2022-06-12 16:42:58.097049
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-12 16:43:07.569649
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dashsegments import DashSegmentsFD
    from .common import FakeYTDLSource
    import sys
    import os
    import shutil
    import time
    import random

    temp_path = 'temp'
    temp_filename = temp_path + '/temp.mp4'
    if not os.path.exists(temp_path):
        os.makedirs(temp_path)
    ctx = {'params': {}}
    info_dict = {'fragment_base_url': '', 'fragments': []}
    dicts = {}
    dicts['params'] = ctx['params']
    dicts['info_dict'] = info_dict
    url = 'http://127.0.0.1:5000/dashsegments'

# Generated at 2022-06-12 16:43:10.486038
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    d = DashSegmentsFD("test_DashSegmentsFD", {})
    assert d != None

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-12 16:43:19.677788
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """
    Unit test for constructor of class DashSegmentsFD
    """

# Generated at 2022-06-12 16:43:31.815015
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # unit tests are run from pytest_youtube_dl/tests
    TEST_COMMON_ARGS = sorted(list(set(compat_urllib_error.URLError.__init__.__code__.co_varnames) &
                                    set(compat_urllib_error.HTTPError.__init__.__code__.co_varnames) &
                                    set(DownloadError.__init__.__code__.co_varnames)))

    from io import BytesIO
    from unittest import mock
    from ..utils import (
        encode_compat_str,
        encode_data_uri,
    )

    fragment_base_url = 'https://fragment.base.url/'
    fragment_path = 'fragment_path'

# Generated at 2022-06-12 16:43:40.914684
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import tempfile

    from ..utils import prepare_filename
    # Overwrite prepare_filename to generate a random filename (in order to avoid
    # overwriting an existing file)
    def rand_prepare_filename(info_dict):
        video_id = info_dict['id']
        video_filename = video_id + '.test'
        if info_dict.get('title'):
            video_filename = prepare_filename(info_dict['title']) + '-' + video_filename
        dir_filename = os.path.join(tempfile.gettempdir(), video_filename)
        return dir_filename
    from .fragment import FragmentFD
    FragmentFD._prepare_filename = rand_prepare_filename

    from youtube_dl.downloader.http import HttpFD
    from .dash import Dash