

# Generated at 2022-06-22 06:39:48.556458
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    '''
    Test the constructor of class DashSegmentsFD
    '''
    import sys
    import youtube_dl.YoutubeDL
    params = {'fragment_retries': 10}
    # Try constructing an object of class DashSegmentsFD with
    # (self, ydl, params)
    # url, playlist is not used in the constructor
    dash_segments_fd = DashSegmentsFD(youtube_dl.YoutubeDL(params), params)
    # Try constructing an object of class DashSegmentsFD with
    # (self, ydl, params)
    # url, playlist is not used in the constructor
    dash_segments_fd = DashSegmentsFD(youtube_dl.YoutubeDL(params), params)
    assert dash_segments_fd != None and 5 == 5
    # sys.exit(0)



# Generated at 2022-06-22 06:39:53.272756
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD(None, 0, None)
    assert fd.FD_NAME == 'dashsegments'
    assert fd.params == {}
    assert fd.frag_downloader is None
    assert fd.params.get('skip_unavailable_fragments', False) == True

# Generated at 2022-06-22 06:40:01.178680
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import tempfile
    import subprocess
    import shutil
    import unittest

    from ..extractor import android
    from ..downloader import progress
    from ..utils import (
        encode_data_uri,
        fake_http_headers,
        prepend_extension,
    )

    class InMemFD(object):
        def __init__(self):
            self._data = b''

        def write(self, data):
            self._data += data

        def read(self, count=-1):
            data, self._data = self._data[:count], self._data[count:]
            return data

        def close(self):
            pass

    class DashSegmentsFDTest(unittest.TestCase):
        maxDiff = None

# Generated at 2022-06-22 06:40:01.763452
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:40:11.996586
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import json
    import os
    import tempfile
    import unittest.mock
    from ..jsinterp import JSInterpreter
    from ..extractor.youtube import YoutubeIE

    class MockFD:
        def read(self):
            return b'{"fragments": [{"url": "http://example.com/file"}]}'

    class MockYoutubeIE(YoutubeIE):
        def _real_initialize(self):
            pass
        def _real_extract(self, url):
            pass


# Generated at 2022-06-22 06:40:24.961928
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .fragment import FragmentFD
    from .http import HttpFD
    from ..extractor.common import InfoExtractor
    from ..utils import parse_iso8601
    import random
    import string

    class DashSegmentsFDTestIE(InfoExtractor):
        IE_NAME = 'dashsegmentsfd'

        def _real_extract(self, url):
            date = '2013-01-31T19:00:00'
            fragment_url_template = 'http://example.com/segment{0:03d}.mp4'

# Generated at 2022-06-22 06:40:36.476129
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import tempfile
    from .dash import parse_mpd_formats, _parse_mpd_formats
    from .http import HttpFD
    from .common import FileDownloader
    from ..utils import (
        sanitize_open,
        sanitized_Request,
        urlopen,
    )


# Generated at 2022-06-22 06:40:38.039460
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    real_download_test_routine(DashSegmentsFD)

# Generated at 2022-06-22 06:40:50.775705
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DASHIE
    from .subtitles import get_subtitles
    from .dash import dashsegments_fatal_error

# Generated at 2022-06-22 06:40:53.799730
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .fragment import FragmentFD
    FragmentFD.download('dashsegments', 'abc', 'abc')

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:41:02.017286
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    Call method real_download of class DashSegmentsFD
    """
    #TODO: implement test
    pass

# Generated at 2022-06-22 06:41:14.211583
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    from ..compat import compat_str
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor

    import os
    import shutil
    import tempfile


# Generated at 2022-06-22 06:41:17.674088
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Checking whether the method real_download of class DashSegmentsFD fails when
    # called with invalid parameters
    assert not DashSegmentsFD().real_download(filename='some_filename', info_dict={})

# Generated at 2022-06-22 06:41:28.487566
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import determine_ytdl_file
    from .common import FakeYDL
    from .test_common import FakeFD

    # Test with fail=false and fail_content=True
    class TestDashSegmentsFD(DashSegmentsFD):
        def _download_fragment(self, ctx, url, info_dict):
            self.url = url
            self.info_dict = info_dict
            return True, b''

    fd = TestDashSegmentsFD({'noprogress': True}, FakeYDL())

# Generated at 2022-06-22 06:41:35.331861
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    Run unit test for method real_download of class DashSegmentsFD
    """
    from ..downloader.common import FileDownloader

    class Dummy_FileDownloader(FileDownloader):
        """
        Dummy object for testing
        """
        def __init__(self, ydl, params):
            """
            Initialize
            """
            FileDownloader.__init__(self, ydl, params)

        def prepare_filename(self, info_dict):
            """
            Dummy method that return filename
            """
            return 'test_filename'

    ydl = Dummy_FileDownloader(None, {})
    ydl.params = {
        'url': 'test_url',
        'fragment_retries': 1,
        'skip_unavailable_fragments': True
    }


# Generated at 2022-06-22 06:41:41.204043
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader

    url = 'https://www.youtube.com/watch?v=z1atBtVkkmw'

# Generated at 2022-06-22 06:41:44.209554
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Basic construction
    DashSegmentsFD()

    # Construction with URL
    DashSegmentsFD(url="http://example.com")

# vim:sw=4:ts=4:et:

# Generated at 2022-06-22 06:41:54.489864
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import dash_segments_with_sizes
    from ..utils import file_size, urlhandle

    test_video = 'https://github.com/ytdl-org/youtube-dl/archive/master.tar.gz'
    test_manifest = 'https://devimages-cdn.apple.com/samplecode/adDemo/ad.m3u8'
    test_dash_manifest = 'https://devimages.apple.com.edgekey.net/streaming/examples/bipbop_4x3/gear3/prog_index.m3u8'

    test_video_handle = urlhandle(test_video)
    test_manifest_handle = urlhandle(test_manifest)
    test_dash_manifest_handle = urlhandle(test_dash_manifest)


# Generated at 2022-06-22 06:41:56.432701
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD is not None

# Generated at 2022-06-22 06:42:02.183613
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..downloader import gen_extractors
    downer = gen_extractors(
        u'http://example.com/video/manifest.mpd',
        {'nopart':True}
    )
    assert len(downer) == 1
    downer = downer[0]
    assert downer.get_id() == "dashsegments"

__all__ = ['DashSegmentsFD']

# Generated at 2022-06-22 06:42:16.142474
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..utils import encodeFilename

    d = DashSegmentsFD(None)
    assert not d.params.get('continuedl')

# Generated at 2022-06-22 06:42:25.893422
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import unittest, sys, os
    from ..downloader import Downloader
    from ..formats import merge_formats, parse_resolution
    from ..utils import encode_basename
    
    class DashSegmentsFDTest(unittest.TestCase):
        def setUp(self):
            self.d = Downloader(params={
                'usenetrc': False,
                'username': 'test',
                'password': 'test',
                'verbose': True,
                'format': 'bestvideo+bestaudio/best',
                'nooverwrites': True,
                'outtmpl': '%(id)s.%(ext)s',
            }, progress_hooks=[])

# Generated at 2022-06-22 06:42:37.758048
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor import common as extractor
    from .test_utils import BasicExtractor

    def enqueue_download(filename, info_dict, *args, **kwargs):
        # _prepare_and_start_frag_download
        fd = DashSegmentsFD(YoutubeDL(), filename, info_dict, *args, **kwargs)
        fragments = info_dict['fragments']
        assert fd.total_frags == len(fragments), 'elements of fragments must be downloaded'
        fd.fragment_index = 0

        # _download_fragment
        segment = fragments[fd.fragment_index]
        assert segment['url'] == fragment_url, 'fragment url should equal to the url'
        fd.fragment_

# Generated at 2022-06-22 06:42:38.464521
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


# Generated at 2022-06-22 06:42:39.830407
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor.dashsegments import test_SegmentListFD_real_download
    assert test_SegmentListFD_real_download(DashSegmentsFD)

# Generated at 2022-06-22 06:42:48.631009
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import gen_extractors
    from ..extractor.common import FileDownloader
    import os
    import tempfile
    
    ext, ie = gen_extractors(u'https://www.youtube.com/watch?v=BaW_jenozKc')[0]

    info_dict = ie.extract(u'BaW_jenozKc')

    tmp_dir = tempfile.mkdtemp()

    # TODO: info_dict_modified = info_dict # TODO: modify metadata


# Generated at 2022-06-22 06:42:50.075825
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # DashSegmentsFD() have test case in dash.py
    pass



# Generated at 2022-06-22 06:42:56.772950
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.common import InfoExtractor

    # Create an InfoExtractor object
    ie = InfoExtractor(None, {}, downloader=None)

    # Call constructor of class DashSegmentsFD
    fd = ie._make_frag_downloader(DashSegmentsFD)
    assert fd.params == {
        'test': False,
        'format': 'bestaudio/best',
        'fragment_retries': 10,
    }, 'DashSegmentsFD constructor sets empty params'

# Generated at 2022-06-22 06:42:59.568597
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    real_download is a method of DashSegmentsFD class
    which is a derived class of FragmentFD.
    """
    assert DashSegmentsFD.real_download


# Generated at 2022-06-22 06:43:00.664910
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('No tests found for DashSegmentsFD_real_download')

# Generated at 2022-06-22 06:43:30.601192
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    import os
    import json
    import hashlib
    from ..utils import encode_compat_str
    from ..downloader import FFmpegPostProcessor
    from ..extractor import YoutubeIE
    filename = 'output.mp4'
    
    if os.path.exists(filename):
        os.remove(filename)
    
    ie = YoutubeIE()
    info = ie.extract(sys.argv[1])
    
    # We can't download a direct stream
    if info.get('is_live') or info.get('protocol') == 'm3u8':
        sys.exit()

    if ie.params.get('noplaylist', False) and info.get('_type', None) == 'multi_video':
        sys.exit()


# Generated at 2022-06-22 06:43:40.730161
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.youtube import YoutubeIE
    from ..ytdl import YoutubeDL

    ydl = YoutubeDL({
        'outtmpl': '%(id)s.%(ext)s',
        'quiet': True,
        'skip_download': True,
    })
    ie = YoutubeIE(ydl)
    assert ie.suitable('https://www.youtube.com/watch?v=BaW_jenozKc')
    info = ie.extract('https://www.youtube.com/watch?v=BaW_jenozKc')
    fd = DashSegmentsFD(ydl, ie.ydl, ie)
    fd.real_download(info['url'], info)
    return True

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:43:42.893271
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import pytest
    method = DashSegmentsFD.real_download
    with pytest.raises(AttributeError):
        method()

# Generated at 2022-06-22 06:43:54.671670
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import YoutubeIE, DashManifestIE
    from ..downloader import FileDownloader

    dash_manifest_url = 'https://manifest.googlevideo.com/api/manifest/dash/source/youtubei.googleapis.com/videoplayback/id/00000000000000000000000000000000/itag/0/source/yt_live_broadcast/requiressl/yes/ratebypass/yes/live/1/gcr/id/signature/7B8A84B61D7A373DF77DA1CAAF8A9CEDA7A48D25.A5A5E74ACB66F7F44A43E415A7B8B9BF65B3FE3A/dover/4/gir/yes/file/master.m3u8'


# Generated at 2022-06-22 06:44:05.348741
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import Downloader
    from ..YoutubeDL import YoutubeDL
    from .test_dash import test_dash_content
    class DashSegmentsFDTest(DashSegmentsFD):
        def report_retry_fragment(self, *args):
            self.retry_fragment_args.append(args)
        def report_skip_fragment(self, *args):
            self.skip_fragment_args.append(args)
        def report_error(self, *args):
            self.error_args.append(args)
        def _download_fragment(self, *args):
            return self.download_fragment_args.pop(0)
        def _prepare_and_start_frag_download(self, *args):
            pass

# Generated at 2022-06-22 06:44:07.438468
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD('/tmp/dummy.mp4')

# Generated at 2022-06-22 06:44:17.978205
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """
    Unit test for DashSegmentsFD
    """
    import os
    import shutil
    import tempfile
    import unittest

    from ..downloader import FileDownloader
    from ..extractor import gen_extractors
    from ..utils import sanitize_open

    EXTRACTORS_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'extractor'))
    sys.path.insert(0, EXTRACTORS_DIR)

    class FakeYoutubeDl():
        def mktmppath(self, filename):
            return tempfile.mkstemp(prefix=filename + '-', suffix='.tmp')[1]


# Generated at 2022-06-22 06:44:20.721974
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    input_file = open('tests/youtube/files/video-extractor.py')
    buf = input_file.read()
    assert DashSegmentsFD.real_download(None, 'video-extractor.py', buf)

# Generated at 2022-06-22 06:44:22.074538
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert False, "Not implemented"

# Generated at 2022-06-22 06:44:33.870464
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD as test_FragmentFD
    from .hls import HLSFD as test_HLSFD
    from .http import HTTPFD as test_HTTPFD
    from .smoothstreams import SmoothStreamsFD as test_SmoothStreamsFD
    from .utils import HEADRequest, Crc32

    import os

    import pytest

    from ..compat import (
        compat_HTTPError,
        compat_kwargs,
        compat_resource_filename,
        compat_urllib_error,
    )


# Generated at 2022-06-22 06:45:14.940302
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass



# Generated at 2022-06-22 06:45:25.126329
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os
    import sys
    # import pytest
    # import youtube_dl.extractor
    # import youtube_dl.utils
    # import youtube_dl.downloader.dash_segments
    # import youtube_dl.downloader.fragment
    # import youtube_dl.downloader.http
    # import youtube_dl.FileDownloader
    from .common import FakeYDL

    # @pytest.fixture
    def extractor(params=None):
        ydl = FakeYDL({'quiet': False})

        class DummyExtractor:
            def __init__(self, ydl, params):
                self.ydl = ydl
                self.params = params
        return DummyExtractor(ydl, params)

    # @pytest.fixture
    def get_info_dict():
        info_

# Generated at 2022-06-22 06:45:36.300225
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    """
    Unit test for method real_download of class DashSegmentsFD
    """

    import os
    import tempfile

    from . import (
        compat_urllib_error,
        compat_urllib_request,
        compat_urlparse,
        compat_xml_parse_error,
    )
    from .downloader import FakeHttpEchoServerHandler, FakeServerThreadingHTTPServer
    from .extractor.common import InfoExtractor
    from .utils import (
        encodeFilename,
        urlhandle_detect_ext,
    )

    tmp_files = []

    class _FakeYDict(dict):
        def __setitem__(self, key, value):
            return super(_FakeYDict, self).__setitem__(key, value)
        def __getitem__(self, key):
            return

# Generated at 2022-06-22 06:45:39.012920
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD(None, None, None)._downloader is None


# Generated at 2022-06-22 06:45:49.874359
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..utils import Dict
    assert isinstance(YoutubeIE._downloader, type(None))
    youtube = YoutubeIE(Dict())
    assert hasattr(youtube, '_downloader')
    from ..downloader import FileDownloader
    assert isinstance(youtube._downloader, FileDownloader)
    assert hasattr(youtube._downloader, 'params')
    assert youtube._downloader.params == {}

    # Test using one of the parameters to be passed to FileDownloader
    youtube = YoutubeIE(Dict({'noplaylist': True}))
    assert hasattr(youtube, '_downloader')
    assert hasattr(youtube._downloader, 'params')
    assert youtube._downloader.params == {'noplaylist': True}

# Generated at 2022-06-22 06:46:01.219619
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import YoutubeIE
    from ..utils import sanitize_open
    import sys

    download_class = YoutubeIE.get_info_extractor(
        {
            'url': 'http://www.youtube.com/watch?v=BaW_jenozKc'
        }
    ).params['downloader'][0]
    sys.stdout = compat_open(sys.stdout.fileno(), 'w', encoding='utf-8', closefd=False)
    
    test_url = 'http://www.youtube.com/watch?v=BaW_jenozKc'
    test_manifest =YoutubeIE.get_info_extractor(
        {
            'url': test_url
        }
    )._get_manifest()

# Generated at 2022-06-22 06:46:02.552537
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD([], {}, {})
    assert fd.FD_NAME == 'dashsegments'

# Generated at 2022-06-22 06:46:04.992428
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD({'fragments': [{'url': 'url'}]})
    assert fd.params is not None

# Generated at 2022-06-22 06:46:16.901207
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-22 06:46:28.577613
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    filename = "2017-05-04-164617.mp4"
    manifest = "2017-05-04-164617.mpd"
    info = {}
    info["fragments"] = []
    fragItem = {}
    fragItem["path"] = "2017-05-04-164617-fragment-0-init.mp4"
    info["fragments"].append(fragItem)
    fragItem = {}
    fragItem["path"] = "2017-05-04-164617-fragment-1.m4s"
    info["fragments"].append(fragItem)
    fragItem = {}
    fragItem["path"] = "2017-05-04-164617-fragment-2.m4s"

# Generated at 2022-06-22 06:48:05.761450
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Testing real_download method of class DashSegmentsFD
    # It is assumed that the method real_download of class DashManifestFD
    # works fine and so we don't need to test it.
    import os
    from ..extractor import YoutubeIE
    from ..utils import (
        check_executable,
        prepend_extension,
        rm_files,
        encodeFilename,
    )

    # Setup: we are creating a temporary directory here to download the test files
    # Set the path of directory for test files
    tmp_dir = encodeFilename('./test_data/temp/')
    # Create the directory
    if not os.path.exists(tmp_dir):
        os.makedirs(tmp_dir)

    # Create a temporary file name

# Generated at 2022-06-22 06:48:13.301431
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .smoothstreams import SmoothStreamsFD
    l = []
    SmoothStreamsFD.real_download = lambda self, filename, info_dict: l.append((filename, info_dict))
    DashSegmentsFD().real_download('foo', {'fragments': [1], 'info_dict': {'url': 'bar', 'http_headers': {'a': 1}}})
    assert len(l) == 1 and l[0][1]['fragments'] == [1]
test_DashSegmentsFD_real_download()

# Generated at 2022-06-22 06:48:24.575273
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..utils import prepare_filename

    ydl = FileDownloader({'nopart': True})
    ydl.add_info_extractor(YoutubeIE())
    ydl.params['format'] = '137+140/250'
    result = ydl.extract_info(
        'https://www.youtube.com/watch?v=BaW_jenozKc', download=False)
    url = result['formats'][-1]['url']
    fmt = result['formats'][-1]['format_id']
    name = prepare_filename(result['title'])
    dashseg = result['requested_formats'][-1]['format_note']

# Generated at 2022-06-22 06:48:35.338107
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from .http import HttpFD

    info = {'url': 'http://dash-mse-test.appspot.com/media.mpd', 'http_headers': None }

# Generated at 2022-06-22 06:48:36.437527
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True



# Generated at 2022-06-22 06:48:38.105795
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass


if __name__=="__main__":
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:48:38.762355
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:48:50.822118
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    name = "DashSegmentsFD"
    description = "Download segments in a DASH manifest"
    options = {'fragment_retries': 10, 'skip_unavailable_fragments': True}
    from ..YoutubeDL import YoutubeDL
    ydl = YoutubeDL({'keepvideo': True, 'noplaylist': True})

    dash_segments_fd = DashSegmentsFD(ydl, {'name': name, 'options': options, 'description': description})

    assert dash_segments_fd.FD_NAME == 'dashsegments'
    assert dash_segments_fd.options == options
    assert dash_segments_fd.extractor is None
    assert dash_segments_fd.ydl == ydl
    assert dash_segments_fd.name == name
    assert dash_segments_fd.description

# Generated at 2022-06-22 06:48:55.688367
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    manifest_file_name = './dash_manifest_test.xml'
    d = DashSegmentsFD()
    d.real_download(manifest_file_name, None)
    return True

if __name__ == "__main__":
    test_DashSegmentsFD_real_download()

# Generated at 2022-06-22 06:48:57.490718
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    c = DashSegmentsFD(None, None)
    assert c

if __name__ == '__main__':
    test_DashSegmentsFD()