

# Generated at 2022-06-22 06:39:37.766085
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
	pass

# Generated at 2022-06-22 06:39:47.594917
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # test_dashsegments_fd_real_download_from_manifest_file
    (manifest_file,
     manifest_url,
     segment_sizes,
     out_file) = download_from_manifest_data
    ydl = YoutubeDL(params)
    ie = ydl.extract_info(manifest_url, download=False)
    if 'fragments' not in ie or 'fragment_base_url' not in ie:
        raise Exception('No fragments and/or base_url in manifest')
    fragments = ie['fragments']
    base_url = ie['fragment_base_url']
    fd = DashSegmentsFD(ydl, ie)

# Generated at 2022-06-22 06:39:58.480978
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    import pytube

    # Assertion: it is possible to create an instance of class DashSegmentsFD
    # without defining default values for `params` and `ydl_options`
    dash_segments_fd = pytube.extract.DashSegmentsFD(params=None, ydl_options=None)

    # Assertion: the instance of class DashSegmentsFD is the subclass of
    # FragmentFD
    assert isinstance(dash_segments_fd, pytube.extract.FragmentFD)

    # Assertion: the instance of class DashSegmentsFD is the subclass of
    # Downloader
    assert isinstance(dash_segments_fd, pytube.downloader.Downloader)

    # Assertion: the instance of class DashSegmentsFD is the subclass of
    # PytubeFD

# Generated at 2022-06-22 06:39:59.147439
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:40:09.650377
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    import tempfile
    import http.cookiejar
    from ..YoutubeDL import YoutubeDL
    from ..extractor.dash import DashmanifestHandler, DASH_MANIFEST_URL_RE
    from .common import (
        FakeYDL,
        parseOpts,
    )

    cookieJar = http.cookiejar.CookieJar()
    ydl = FakeYDL({
        'cookiefile': None,
        'noplaylist': True,
        'simulate': True,
        'quiet': True,
    })
    dl = YoutubeDL(ydl)
    dl.add_default_info_extractors()
    dl.add_info_extractor(DashmanifestHandler())

    tmp = tempfile.mkstemp()

# Generated at 2022-06-22 06:40:16.134889
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import dash_test
    dash_manifest = dash_test.parse_manifest(dash_test.TEST_MANIFEST_CONTENT)
    dash_manifest['fragment_base_url'] = dash_test.TEST_MANIFEST_BASE
    from .dash import parse_mpd_formats
    dash_manifest['fragments'] = parse_mpd_formats(dash_manifest['formats'])[0]['fragments']
    from .http import HttpFD
    from .http import YoutubeDLHttpError
    d = DashSegmentsFD(downloader=None, params={'test': False, 'fragment_retries': 0})
    res = d.real_download('test.mp4', dash_manifest)
    assert res is True
    assert d._tmpfilename.end

# Generated at 2022-06-22 06:40:19.255778
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD("http://www.youtube.com/api/manifest/dash/",
                  {'fragments': []})

# Generated at 2022-06-22 06:40:19.949945
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert DashSegmentsFD.real_download

# Generated at 2022-06-22 06:40:29.047152
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    url = 'https://example.com'
    info_dict = {
        'id': '123',
        'title': 'title',
        'ext': 'mp4',
        'fragments': [
            {'url': 'fragment_A.m4s'},
            {'url': 'fragment_B.m4s'},
            {'url': 'fragment_C.m4s'},
            {'url': 'fragment_D.m4s'}
        ]
    }
    expected_frags = [
        'fragment_A.m4s',
        'fragment_B.m4s',
        'fragment_C.m4s',
        'fragment_D.m4s'
    ]

# Generated at 2022-06-22 06:40:38.719310
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import json
    import os
    import time
    from io import BytesIO
    from io import SEEK_CUR
    from ..jsinterp import JSInterpreter
    from ..downloader import FakeYDL
    from ..compat import compat_http_server
    from ..compat import compat_urllib_parse_urlencode
    from ..compat import compat_urllib_parse_unquote
    from ..compat import compat_urllib_parse_unquote_plus
    from ..compat import compat_urllib_parse_urlparse
    from ..compat import compat_urllib_request
    from ..compat import compat_urllib_request_HTTPSHandler

    class MockServer(compat_http_server.HTTPServer):
        daemon_threads = True
        allow_reuse_address

# Generated at 2022-06-22 06:40:56.350426
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # given
    from .http import HttpFD
    from ..YoutubeDL import YoutubeDL

    from ..extractor.common import InfoExtractor

    ie = InfoExtractor()
    ie._downloader = YoutubeDL(dict())
    ie.params = ie._downloader.params
    ie.params['noprogress'] = True
    ie.params['quiet'] = True
    ie.params['skip_unavailable_fragments'] = False
    ie.params['test'] = True
    ie.report_warning = lambda *args, **kargs: None
    ie.report_error = lambda msg, *args, **kwargs: None
    ie.to_screen = lambda *args, **kargs: None
    ie.params['fragment_retries'] = 0  # disable retries


# Generated at 2022-06-22 06:40:57.956555
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass # TODO


# Generated at 2022-06-22 06:41:09.438551
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import json
    import os.path
    import shutil
    import tempfile

    from .dash_manifest import DASHManifest

    def _read_file(file_path):
        with open(file_path, 'rb') as f:
            return f.read()

    def _write_file(file_path, content):
        with open(file_path, 'wb') as f:
            f.write(content)

    tmp_dir = tempfile.mkdtemp(prefix='youtube-dl-test-DashSegmentsFD_real_download-')

# Generated at 2022-06-22 06:41:16.660629
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..downloader.common import FileDownloader
    from ..extractor.common import InfoExtractor
    import os
    import shutil

    class MockFileDownloader(FileDownloader):
        def __init__(self, ydl, params):
            self.test_params = params
            self.params = params

    class MockInfoExtractor(InfoExtractor):
        def __init__(self, ydl, params):
            self.test_params = params
            pass
        def download_dash_fragments(self, *args, **kwargs):
            return DashSegmentsFD(ydl, MockFileDownloader(ydl, self.test_params), *args, **kwargs)

    ydl = MockYdl({})
    ydl.add_info_extractor(MockInfoExtractor(ydl, None))

   

# Generated at 2022-06-22 06:41:25.132319
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashFD
    from .http import HttpFD
    from .generic import FileDownloader
    from ..youtube_dl.YoutubeDL import YoutubeDL
    from ..extractor.dash import DashIE
    from ..extractor.youtube import YoutubeIE
    from ..utils import video_ext
    from ..compat import compat_urllib_request
    from ..compat import compat_http_cookiejar

    import shutil
    import os
    import tempfile

    # self.params.get('skip_unavailable_fragments', True)

# Generated at 2022-06-22 06:41:27.395575
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD(help_option='help_option_val', param_option='param_option_val')

# Generated at 2022-06-22 06:41:33.478325
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .http import HTTPFD
    from .native import F4MFD
    from .probes import is_dashsegments
    from .dash import DASHFD
    from .utils import get_filesystem_encoding
    import os
    files = []
    for fd_class in [DASHFD, HTTPFD, F4MFD]:
        test_files = [
            'ABC-20130404-AA',
            'cosmos-laundromat-1080p',
            'nfl-jaguars-at-patriots-2015-12-27-1080p-alternate',
            'bbb-full',
            'bbb-clear-audio-clear-video',
            #'bbb-clear-audio-encrypted-video',
        ]

# Generated at 2022-06-22 06:41:34.913646
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.FD_NAME == 'dashsegments'

# Generated at 2022-06-22 06:41:39.054701
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    d = DashSegmentsFD("http://example.com")
    assert d.FD_NAME == "dashsegments", d.FD_NAME
    assert d.params == {}

test_DashSegmentsFD()

# Generated at 2022-06-22 06:41:39.993952
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD('youtube')

# Generated at 2022-06-22 06:42:03.158626
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_url = 'https://example.com/manifest.mpd'
    dash_info = {
        'fragments': [
            {'path': 'something'},
            {'path': 'somethingelse'},
        ],
        'fragment_base_url': dash_url,
    }

    expected_video_single = {
        'url': 'https://example.com/something',
        'urlreferer': dash_url,
        'http_headers': {
            'Range': 'bytes=0-',
        },
    }
    expected_video_range = {
        'url': 'https://example.com/something',
        'urlreferer': dash_url,
        'http_headers': {
            'Range': 'bytes=0-5',
        },
    }

    dash_fd

# Generated at 2022-06-22 06:42:12.791267
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import os
    import sys
    import tempfile
    import unittest
    from collections import OrderedDict
    from youtube_dl.YoutubeDL import YoutubeDL
    from youtube_dl.downloader.dash import DashSegmentsFD

    class NullFD(object):
        def __init__(self, *args):
            pass

        def read(self, byte_count):
            return b''

        def close(self):
            pass

    class NullFDForTest(NullFD):
        def __init__(self, *args):
            super(NullFDForTest, self).__init__(args)

        def read(self, byte_count):
            return b'\x00' * byte_count


# Generated at 2022-06-22 06:42:22.230827
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .test_common import BaseTest
    from .test_download import TestDownload
    from ..compat import compat_tempfile
    from ..utils import (
        determine_ext,
        sanitize_filename,
    )
    import os
    import shutil
    import tempfile
    from .fragment import (
        DownloadContext,
        FragmentFD,
    )

    class DashSegmentsFDTest(TestDownload, BaseTest):
        """
        Subclass of TestDownload that contains helper method
        to create a partially downloaded fragment file.
        """
        def setUp(self):
            super(DashSegmentsFDTest, self).setUp()
            self.test_fragments_filename = '_test_fragments_filename.mp4'
            self.test_fragments_tempdir = tempfile.mkd

# Generated at 2022-06-22 06:42:33.720092
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import os.path
    import sys
    if sys.version_info[0] < 3:
        from io import BytesIO as DataIO
    else:
        from io import BytesIO as DataIO
    import json
    import tempfile
    td = tempfile.gettempdir()
    c = DashSegmentsFD({'fragment_base_url': 'http://test.com/', 'fragments': 'test.json'}, {}, {})
    assert c.params == {}
    assert c._downloader is None
    assert c.fd is None
    assert c._tmpfilename is None
    assert c._progress_hooks is None

# Generated at 2022-06-22 06:42:35.193302
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD('', '', '', None, None)
    assert repr(fd)

# Generated at 2022-06-22 06:42:45.189428
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    class DummyFD(FragmentFD):
        def _download_fragment(self, *args, **kwargs):
            return True, 'dummy fragment content'

        def _append_fragment(self, *args, **kwargs):
            pass

    class DummyYoutubeIE(object):
        def _prepare_and_start_frag_download(self, *args, **kwargs):
            pass

        def _finish_frag_download(self, *args, **kwargs):
            pass

        def to_screen(self, *args, **kwargs):
            pass

    fragments = [{'url': 'https://dummy.com/dummy/path/'}] * 3
    df = DummyFD('test')
    df.to_screen = DummyYoutubeIE().to_screen


# Generated at 2022-06-22 06:42:57.225960
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import random
    # not testing download() because it is a monkey patch of real_download()
    # patches.monkey_patch() is called in a wrong way in test_downloader_troubleshooting.py
    from ..downloader import _do_download
    from ..utils import encodeFilename

    # normal case
    output_template = '%(id)s.%(ext)s'
    video_id = 'QH2-TGUlwu4'

# Generated at 2022-06-22 06:42:57.840748
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    pass

# Generated at 2022-06-22 06:43:05.648587
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    url = 'http://manifest.googlevideo.com/api/manifest/dash/'
    url += 'source/yt_watch_vid'
    url += 'eos.google.com/api/manifest/dash/'
    url += 'src_no_ratelimit/yt_watch_vid'
    url += 'eos.google.com/api/manifest/dash/'
    url += 'id/yt_watch_vid'
    url += 'eos.google.com/api/manifest/dash/'
    url += 'signature/yt_watch_vid'
    url += 'eos.google.com/api/manifest/dash/'
    url += 'upn/yt_watch_vid'
    url += 'eos.google.com/api/manifest/dash/'

# Generated at 2022-06-22 06:43:10.613926
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    fragment_base_url = 'http://localhost:8080/'
    fragments = [
        {
            'path': 'f1'
        },
        {
            'path': 'f2'
        },
        {
            'path': 'f3'
        }
    ]

    downloader = DashSegmentsFD()

# Generated at 2022-06-22 06:43:36.697632
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # TODO: write when used

    assert False # implemented but untested

# Generated at 2022-06-22 06:43:37.340382
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:43:48.940351
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import os
    import json
    import sys
    import tempfile
    import shutil

    # This test creates a temporary directory under /tmp and creates some files in it
    # to simulate DASH segments download
    d = tempfile.mkdtemp()

    # First create a dash segments file in the temporary directory
    video_filename = os.path.join(d, 'a.dash')
    video_file = open(video_filename, 'wb')
    video_file.close()

    # Now create some DASH segments for the video file
    for i in range(6):
        segment_filename = os.path.join(d, 'a-%d.dash' % i)
        segment_file = open(segment_filename, 'wb')
        segment_file.write(b'%d' % i)

# Generated at 2022-06-22 06:43:54.311830
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import io
    import json
    import os
    import tempfile
    from .http import HttpFD
    from .utils import (
        HEADRequest,
        AttributesMixin,
    )
    from ..compat import (
        compat_http_client,
        compat_urllib_error,
    )
    from ..extractor.youtube import YoutubeIE
    from ..jsinterp import JSInterpreter
    from ..utils import (
        ExtractorError,
        HEADRequest,
        compat_str,
        compat_urlparse,
        encode_data_uri,
        encode_datetime,
        HEADRequest,
        parse_iso8601,
    )
    from ..downloader import (
        HttpFD,
    )
    from ..downloader.external import (
        FFmpegFD,
    )

# Generated at 2022-06-22 06:44:05.195997
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashManifestFD
    from ..extractor import YoutubeIE
    from ..downloader import DummyFD
    import os
    import json

    class DummyManifestFD(DummyFD, DashManifestFD):
        _downloader = True

        def _real_extract(self, url):
            class Dict(dict):
                def __init__(self, *args, **kwargs):
                    super(Dict, self).__init__(*args, **kwargs)
                    self.__dict__ = self
            dct = Dict()

            path = os.path.join(os.path.dirname(__file__), 'test', 'dashManifest.mpd')

# Generated at 2022-06-22 06:44:13.605701
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-22 06:44:14.384215
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:44:22.901544
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # init stub logger
    from ..downloader.YDL.loggerstub import LoggerStub

    # init stub info_dict
    from .mock_info_dict import MockInfoDict

    # init DashSegmentsFD with stub logger
    from ..downloader.YDL.fd_dashsegments import DashSegmentsFD
    dashsegments = DashSegmentsFD(LoggerStub())

    # init method real_download
    test_filename = 'test.mp4'
    test_info_dict = MockInfoDict()
    dashsegments.real_download(test_filename, test_info_dict)

# Generated at 2022-06-22 06:44:25.004429
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.__name__ == 'fragment'

# Generated at 2022-06-22 06:44:35.973091
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # Define fake values for testing
    tmp_file = tempfile.NamedTemporaryFile()
    filename = tmp_file.name
    tmp_file.close()

    info_dict = {
        'manifest_url': 'http://example.com/manifest.mpd',
        'fragment_base_url': 'http://example.com/foo/',
        'fragments': [
            {
                'path': 'bar/segment1.m4s',
            },
            {
                'path': 'bar/segment2.m4s',
            },
        ],
    }

    # Define fake fragments for testing
    fake_fragment_data = [b'bar', b'qux', b'quux']

    # Define a fake response for testing

# Generated at 2022-06-22 06:45:32.372936
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from .dash import (
        DASHFragmentsFD,
        DownloadContext,
    )

    # These tests are from YoutubeIE._prepare_and_start_download()
    # which no longer runs
    # These tests make sure fragments are not downloaded again
    # when the download is resumed

    # DASH fragments

# Generated at 2022-06-22 06:45:40.812696
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .tests import FakeYDL

    class MockDashSegmentsFD(DashSegmentsFD):
        def __init__(self, ydl, params):
            super(MockDashSegmentsFD, self).__init__(ydl, params)
            self.successes = []
            self.failures = []
            self.skips = []

        def _append_fragment(self, ctx, frag_content):
            self.successes.append(ctx['fragment_index'])

        def _finish_frag_download(self, ctx):
            pass

        def report_skip_fragment(self, frag_index):
            self.skips.append(frag_index)

        def report_error(self, msg):
            self.failures.append(ctx['fragment_index'])

# Generated at 2022-06-22 06:45:51.057741
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    info_dict = {
        'id': 'tN_2lVwWv5I',
        'extractor': 'youtube',
        'title': 'Video',
        'formats': [],
        'fragment_base_url': 'https://test.test/test/test/test',
        'fragments': [{'path': 'test'}, {'path': 'test2'}, {'path': 'test3'}]
    }
    info_dict['fragments'][0]['url'] = "https://test.test/test/test/test/test"

# Generated at 2022-06-22 06:46:02.205290
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import FakeDownloader
    from .dash import parse_mpd_formats
    from .common import mock_httpd

    video_id = "AQbLRJY8Dvs"
    format_id = 18
    content_type = 'video/mp4; codecs="avc1.42001E, mp4a.40.2"'
    mpd = """<?xml version="1.0" encoding="utf-8"?>
<MPD xmlns="urn:mpeg:DASH:schema:MPD:2011" minBufferTime="PT1.500S" type="static"
     mediaPresentationDuration="PT2M10.000S" maxSegmentDuration="PT2.000S"
     profiles="urn:mpeg:dash:profile:isoff-live:2011"/>"""
    mpd_formats = parse

# Generated at 2022-06-22 06:46:11.636399
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    import os
    import json
    #sys.path.append('.')
    from .fragment import FragmentFD
    from .dashsegments import DashSegmentsFD
    from .http import HttpFD
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL()
    ydl.add_default_info_extractors()

    # http://github.com/ytdl-org/youtube-dl/issues/598
    url = 'http://rdmedia.bbc.co.uk/dash/ondemand/bbb/2/client_manifest-common_init.mpd'
    with ydl:
        ie = ydl.extract_info(url, download=False)
    fragments = ie['fragments']

# Generated at 2022-06-22 06:46:20.638115
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE
    from ..utils import determine_ext

    import os
    import tempfile

    _, tmppath = tempfile.mkstemp(suffix='.mp4')

    ie = InfoExtractor()
    ie.add_info_extractor(YoutubeIE())

    url = 'http://www.youtube.com/watch?v=2eP-3-Yd7UM'
    info_dict = ie.extract(url)
    ie.download(info_dict)

    del info_dict['_type']
    del info_dict['id']
    del info_dict['url']
    del info_dict['title']

    info_dict['filename'] = tmppath

# Generated at 2022-06-22 06:46:31.396160
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """
    Constructor test

    This test is used to determine if we forget to add a new parameter in the DashSegmentsFD
    constructor.
    """
    import inspect

    import youtube_dl.YoutubeDL
    ydl_obj = youtube_dl.YoutubeDL({})
    # See https://bitbucket.org/techtonik/python-stdeb/issue/25
    args, varargs, varkw, defaults = inspect.getargspec(DashSegmentsFD.__init__)
    assert args == ['self', 'ydl', 'params', 'tmpfilename'], args

    # These are the params

# Generated at 2022-06-22 06:46:39.371993
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    from ..extractor import YoutubeIE
    import IPython

    info_dict = {
        'id': '8ej_PwBwz04',
    }

    config_spec = {
        'outtmpl': '%(id)s.%(ext)s',
        'format': 'mp4',
        'writedescription': False,
        'writeinfojson': False,
    }

    config = YoutubeIE.prepare_config(info_dict, config_spec)
    youtube_ie = YoutubeIE(config=config)

    IPython.embed()


# Utility functions for unit tests


# Generated at 2022-06-22 06:46:50.019467
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():

    from ..extractor import try_get
    from ..downloader import DummyFD
    from ..compat import compat_urllib_error
    from operator import attrgetter

    from .smuggle import smuggle_url

    import shutil
    import tempfile

    # Set up a temporary download directory
    tmpdir = tempfile.mkdtemp()

    # Set up a list of test fragments
    frag_ids = ['init-stream0', 'init-stream1', 'segment-1-1-av_hd.m4s', 'segment-1-1-av.m4s']

    # Set up an InfoExtractor to attempt to download the fragments
    class TestIE(object):
        def __init__(self, tmpdir):
            self._tmpdir = tmpdir
            self._ids = iter(frag_ids)

# Generated at 2022-06-22 06:47:00.427539
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import YoutubeDL
    from .dash import parse_mpd_formats
    from .http import HttpFD
    from .http import HttpAsyncFD
    from .fragment import FragmentFD
    from .fragment import HlsFragmentsFD
    from ..extractor import gen_extractors


# Generated at 2022-06-22 06:48:39.731856
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import json
    import os
    import subprocess
    if (not os.getenv('CI')):
        raise EnvironmentError(
            "Skipping DASH unit test because this is not a CI environment.")
    print("\n")
    with open('tests/youtubedl-test-data/dash_manifest.json') as dash_manifest_file:
        dash_manifest_json = json.loads(dash_manifest_file.read())
    dash_fragment_base_url = dash_manifest_json[0]['fragment_base_url']
    dash_fragments = dash_manifest_json[0]['fragments']

# Generated at 2022-06-22 06:48:51.664688
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..downloader.http import HttpFD
    yt_ie = YoutubeIE()
    http_fd = HttpFD()
    yt_ie._downloader = http_fd._downloader

# Generated at 2022-06-22 06:49:02.014122
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-22 06:49:14.116968
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..extractor.dash import parse_scte35_markers
    from ..utils import unescapeHTML
    # TODO: Use a proper testcase with muxed audio tracks
    info_dict = YoutubeIE._extract_info('https://youtu.be/BJFyzpBcaCY', False)
    stream_types = ['audio', 'audio_lenient', 'video', 'video_lenient']
    stream_type = stream_types[-1]
    ie = YoutubeIE()
    if stream_type == 'audio':
        fd = ie._make_sd_fragment_downloader(info_dict,
                                             ie._sort_formats(info_dict['formats']),
                                             ie.params)

# Generated at 2022-06-22 06:49:23.656890
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    ydl = FakeYDL()
    fd = DashSegmentsFD(ydl, {'fragments': [{'url': 'url_url', 'path': 'path_path'},
                                            {'path': 'path2_path2'},
                                            {'url': 'url3_url3'},
                                            {'url': 'url4_url4', 'path': 'path4_path4'}],
                               'info_dict': {'id': 'id_id'},
                               'params': {'keys': ['fragments', 'fragment_base_url']}})
    fragments, fragments_base_url = fd._get_fragments()

# Generated at 2022-06-22 06:49:34.877358
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor, SearchInfoExtractor
    from ..extractor.youtube import YoutubeIE
    from .mock_server import MockServer
    from .test_utils import FakeYDL

    class DummyIE(InfoExtractor):
        _VALID_URL = r'https?://.+'
        IE_NAME = 'Dummy'
        def _real_extract(self,url):
            return {'_type': 'url', 'url': url}
    class DummySearchIE(SearchInfoExtractor):
        _MAX_RESULTS = 10
        IE_NAME = 'DummySearch'
        _SEARCH_KEY = 'dummy'