

# Generated at 2022-06-22 06:39:47.665678
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import re
    import pytest
    from .dash import MpdFD
    from ..utils import unescapeHTML
    from ..extractor import YoutubeIE

    def get_description(context):
        return unescapeHTML(re.search(r'<div class="description">([^<]+)<', context).group(1))

    class MyYoutubeIE(YoutubeIE):
        def __init__(self, *args, **kwargs):
            super(MyYoutubeIE, self).__init__(*args, **kwargs)
            self._downloader.params['noprogress'] = True

    class DummyFD(object):
        def to_screen(self, s):
            print(s)

        def trouble(self, s, tb=None):
            pass


# Generated at 2022-06-22 06:39:58.480240
# Unit test for method real_download of class DashSegmentsFD

# Generated at 2022-06-22 06:40:09.836552
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # This function tests the method real_download of class DashSegmentsFD
    from .dash import DashFD
    from .http import HttpFD
    from .http import HlsFD
    from .f4m import F4mFD
    from .m3u8 import M3u8FD
    from .fragment import FragmentFD
    from ..extractor import get_info_extractor

    assert DashFD.can_download_dash('http://example.com/test.mpd')
    assert DashFD.can_download_dash('http://example.com/test.mpd?test=1')
    assert DashFD.can_download_dash('http://example.com/test.mpd#/test')
    assert DashFD.can_download_dash('http://example.com/test.mpd#/test?test=1')



# Generated at 2022-06-22 06:40:14.955493
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # This test is for https://github.com/ytdl-org/youtube-dl/issues/8382
    # (DASH video with encrypted fragments)
    url = "https://www.youtube.com/watch?v=u1ZB_rGFyeU"
    params = {
        'skip_download': True,
        'format': '0',
        'outtmpl': '%(id)s',
    }
    dl = YoutubeDL(params)
    dl.download([url])

# Generated at 2022-06-22 06:40:16.165556
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD()


# Generated at 2022-06-22 06:40:18.164887
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    return DashSegmentsFD

# Generated at 2022-06-22 06:40:28.285828
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    import io

    from .dash import DashIE
    from .http import HttpFD
    from ..utils import make_HTTPServer, FakeYDL
    from ..extractor.common import InfoExtractor

    def test_real_download(self, args, result):
        out_stream = io.BytesIO()
        ie = DashIE()
        ydl = FakeYDL(params={"verbose": True, "dump_intermediate_pages": True})
        ydl.add_default_info_extractors()
        with make_HTTPServer(content=result):
            server_config = {'source_address': ('127.0.0.1', 0)}

# Generated at 2022-06-22 06:40:40.028293
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    import os
    import tempfile
    url = 'http://example.com/manifest.mpd'
    ydl = YoutubeDL({
        'outtmpl': os.path.join(tempfile.gettempdir(), '%(id)s.%(ext)s'),
        'nooverwrites': True,
        'progress_hooks': [lambda d: d],
        'verbose': False,
    })
    dashSegmentsFD = DashSegmentsFD(ydl, {'url': url})

    assert dashSegmentsFD.name == 'dashsegments'
    assert dashSegmentsFD.ydl == ydl
    assert dashSegmentsFD.params == {}
    assert dashSegmentsFD.info['url'] == url
    assert dashSegmentsFD.info['protocol']

# Generated at 2022-06-22 06:40:52.359497
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..utils import encodeArgument
    from .dashsegments import DashSegmentsFD
    from .fragment import fmt_bytes
    import time

    class Proxy(object):
        def __init__(self):
            self.done = False
            self.died = False

        def report_progress(self, progress):
            print(fmt_time(progress["eta"]), fmt_bytes(progress["speed"]), fmt_bytes(progress["downloaded_bytes"]), fmt_compat_str(progress["downloaded_frags"]), fmt_compat_str(progress["total_frags"]), fmt_bytes(progress["frag_size"]), fmt_bytes(progress["frag_downloaded_bytes"]))
            if progress["downloaded_bytes"] >= 1000000:
                self.done

# Generated at 2022-06-22 06:41:00.770552
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    d = DashSegmentsFD({})
    d.real_download('hogehoge', {'fragment_base_url':'http://domain.com/', 'fragments': [{'url':'http://domain.com/fuga.ts'}, {'path':'hoge.ts', 'url':''}]})
    d.real_download('hogehoge', {'fragment_base_url':'http://domain.com/', 'fragments': [{'path':'hoge.ts', 'url':''}, {'path':'hoge.ts', 'url':''}]})


# Generated at 2022-06-22 06:41:22.843740
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    """
    Test DashSegmentsFD.real_download() for 2 fragments, first one returned 404
    """
    # pylint: disable=unused-argument

    class DashSegmentsFDTest(DashSegmentsFD):
        def _prepare_and_start_frag_download(self, ctx):
            ctx['fragment_index'] = 0
            ctx['frag_filename'] = 'test'

        def _finish_frag_download(self, ctx):
            pass

        def _download_fragment(self, ctx, fragment_url, video_info_dict):
            if fragment_url.endswith('2'):
                return True, 'stub'
            return False, None


# Generated at 2022-06-22 06:41:24.690382
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD("http://youtube.com/watch?v=123", {}, "", "")

# Generated at 2022-06-22 06:41:33.735847
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .f4m import F4mFD
    from .http import HttpFD
    from .hls import HlsFD
    from ..extractor import YoutubeIE
    from ..utils import sanitize_open
    import os.path
    import tempfile
    import time

    def test_real_download(ydl, dl_info, tmpdir):
        filename = dl_info['filename']

        # Creating FD from the testcase
        if dl_info['protocol'] == 'hls':
            FDClass = HlsFD
        elif dl_info['protocol'] == 'http':
            FDClass = HttpFD
        elif dl_info['protocol'] == 'f4m':
            FDClass = F4mFD

# Generated at 2022-06-22 06:41:35.037551
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    raise NotImplementedError


# Generated at 2022-06-22 06:41:45.732142
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    url = 'https://example.com'
    filenames = ['output.mp4', 'output.ts']

    def download_fragment(url, filename):
        print('Downloading ' + url)
        return True, url

    def write_fragment(filename, content):
        print('Writing ' + content + ' to file ' + filename)

    def merge_fragments(filename, filenames):
        print('Merging ' + ','.join(filenames) + ' to file ' + filename)

    for filename in filenames:
        fd = DashSegmentsFD()
        fd.params = {
            'test': True,
            'noprogress': True,
        }
        fd.add_progress_hook(lambda x: x)

# Generated at 2022-06-22 06:41:48.111971
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_filedownload_constructor(DashSegmentsFD)

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:41:50.567256
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # TODO
    pass


# Generated at 2022-06-22 06:42:01.721044
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.youtube import YoutubeIE
    from ..downloader import Downloader
    from ..utils import FakeYDL
    downloader = Downloader(FakeYDL())
    ied = YoutubeIE(downloader)
    dfd = DashSegmentsFD(downloader, dict(ied.extract('http://www.youtube.com/watch?v=BaW_jenozKc')))
    dfd.prepare()
    assert dfd.test('test.mp4', {'fragments': dfd.fragments, 'fragment_base_url': dfd.base_url, 'format_id': '251'})

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:42:13.695915
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print('Testing DashSegmentsFD.real_download')

    # Prepare expected input and output
    # See example of this kind of file in tests/files/test.mpd
    fragments = [
        {'duration': 1, 'path': 'seg1.ts'},
        {'duration': 1, 'path': 'seg2.ts'},
        {'duration': 1, 'path': 'seg3.ts'},
    ]
    info_dict = {'fragments': fragments}
    fragment_base_url = 'http://dl.example.com/'
    info_dict['fragment_base_url'] = fragment_base_url

# Generated at 2022-06-22 06:42:15.765960
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # some way to check that the class is constructed properly?
    assert DashSegmentsFD

# Generated at 2022-06-22 06:42:30.418279
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dl = DashSegmentsFD({})
    assert dl.FD_NAME == 'dashsegments'

# Generated at 2022-06-22 06:42:41.466083
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Testing for the constructor of the class DashSegmentsFD
    import ytdl.YoutubeDL
    import ytdl.extractor.fragment
    from .dash import DashFD
    import sys
    import os
    import shutil
    from .fragment import FragmentFD
    global path
    path = './testing/'
    if not os.path.exists(path):
        os.makedirs(path)
    info_dict = {}
    info_dict['fragments'] = []
    info_dict['fragment_base_url'] = 'http://test.com/test/'

# Generated at 2022-06-22 06:42:45.069866
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_class = DashSegmentsFD()
    # Just intialize class to be sure there are no exceptions
    DashSegmentsFD()
    print(str(test_class))

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:42:56.825874
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    print( "Unit test for method real_download of class DashSegmentsFD" )
    # Create the downloader
    downloader = YoutubeDL(params={})
    # Create the info_dict

# Generated at 2022-06-22 06:43:05.196381
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import YoutubePlaylistIE
    from ..downloader import FileDownloader
    from ..compat import compat_http_client
    class FakeHttpResponse(object):
        def __init__(self,data):
            self.data = data
        def read(self,nbytes):
            return self.data
    class FakeHttpConn(object):
        def __init__(self):
            self.counter = 0
        def request(self,method,url,*args,**kwargs):
            if self.counter == 0:
                self.counter += 1
                raise compat_http_client.IncompleteRead(b'', 1)
            elif self.counter == 1:
                self.counter += 1
                raise compat_urllib_error.HTTPError(url, 500, b'', {},None)

# Generated at 2022-06-22 06:43:14.639617
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    test_file_name = "test.mp4"
    test_file_size = 12345678
    test_fragment_base_url = "https://youtube.com/"
    test_fragment_url = urljoin(test_fragment_base_url, "fragment")
    test_fragment_size = 98765
    info_dict = {"_type": "dash", "fragments": [{"url": test_fragment_url, "path": "fragment", "duration": 1, "title": "Fragment"}], "fragment_base_url": test_fragment_base_url, "length": test_file_size}
    fragment_retries = 0
    fragment_size = test_fragment_size

# Generated at 2022-06-22 06:43:26.014472
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import re

    from collections import namedtuple
    from .dashsegments import DashSegmentsFD, _append_fragment

    from .fragment import _parse_fragment_param_attrs
    from .common import FileDownloader
    from .extractor import get_info_extractor

    from ..compat import compat_urllib_request, compat_urllib_error
    from ..utils import (
        ExtractorError,
        find_xpath_attr,
        get_element_by_attribute,
    )

    CONTENT_TYPE_FRAGMENT_MAP = {
        'video/mp4': '.mp4',
        'video/webm': '.webm',
    }
    MPD_NS = 'urn:mpeg:dash:schema:mpd:2011'

# Generated at 2022-06-22 06:43:37.481562
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FragmentFD
    from .http import HttpFD
    from .http import HLSFD
    from .utils import urlhandle
    from .utils import urlget
    from .utils import urlopen
    from .dash import parse_mpd_formats
    from .dash import _extract_mpd_formats
    from .dash import _extract_f4m_formats
    from .dash import _extract_ism_formats
    from .dash import _parse_mpd_formats
    from .dash import _parse_f4m_formats
    from .dash import _parse_ism_formats
    from .dash import _process_mpd_formats
    from .dash import _process_f4m_formats
    from .dash import _process_ism_formats

# Generated at 2022-06-22 06:43:49.074270
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """Test DashSegmentsFD class with "--test" option
    """
    from . import DashSegmentsFD

# Generated at 2022-06-22 06:44:00.993003
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .http import HttpFD
    from .dash import parse_mpd_formats, get_fragment_base_url
    from .utils import compat_urlparse, parse_query
    import re

    # For testing purpose

# Generated at 2022-06-22 06:44:31.232135
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from . import _download
    from .http import HttpFD
    url = "https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd"
    fd = HttpFD(_download, url)
    print("DashSegmentsFD test:")
    print("FD: ", fd)
    print("\n")

# Generated at 2022-06-22 06:44:38.102491
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .test import ytdl_test
    from .dashsegments import dashsegments

    real_test = ytdl_test(
        DashSegmentsFD,
        {
            'url': 'https://youtube.com/watch?v=tH0uJ1KmIZA',
            'playlistend': 1,
            'playliststart': 1,
            'format': '140',
            'progress_hooks': [dashsegments],
        },
        expected_status=0,
        expected_warning=None,
    )

    assert real_test() is True

# Generated at 2022-06-22 06:44:42.687963
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # This will raise an error if the class is not available
    dash_segments_fd = DashSegmentsFD(None, None, 'md5', {})
    # This will raise an error if the FD name is incorrect
    dash_segments_fd.FD_NAME == 'dashsegments'

# Generated at 2022-06-22 06:44:46.382793
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    d = DashSegmentsFD({})
    return d is not None

if __name__ == '__main__':
    import sys
    sys.exit(0 if test_DashSegmentsFD() else 1)

# Generated at 2022-06-22 06:44:58.394297
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import gen_extractors, YoutubeIE, YoutubePlaylistIE
    from .common import FakeYDL

    extractors = gen_extractors()

    youtube = FakeYDL()
    youtube.set_options(extract_flat=True)
    # Playlist
    youtube.params = {
        'playlistend': 10,
        'playliststart': 1,
        'playlistreverse': False
    }

    # shakiraVEVO
    url = 'PLFgquLnL59alCl_2TQvOiD5Vgm1hCaGSI'
    with youtube:
        ie = YoutubePlaylistIE(youtube)
        info_dict = ie.extract(url)

# Generated at 2022-06-22 06:45:09.002439
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import io
    import os
    import sys
    import tempfile

    from ..utils import (
        encode_base_n,
    )

    # Work-around Python 2.7 bug which causes it to crash in
    # os.unsetenv('HOME') when run in a thread.
    # https://bugs.python.org/issue9447
    if sys.version_info < (3, 0):
        import re
        import threading
        if re.search(r'^2\.7\.(\d+)', sys.version) is not None:
            original_os_unsetenv = os.unsetenv
            def patched_os_unsetenv(key):
                # We assume that 'HOME' is always set
                if key != 'HOME':
                    return original_os_unsetenv(key)
            import builtins


# Generated at 2022-06-22 06:45:20.016777
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..compat import compat_urllib_request
    from .http import HttpFD
    from .dash import parse_mpd_formats, parse_mpd_formats_from_stream
    from .fragment import _parse_mpd_formats as _parse_dash_formats
    from .fragment import _parse_mpd_formats_from_stream as _parse_dash_formats_from_stream
    from urllib.parse import urlparse, parse_qs

    # Find out if dashsegments extractor supports old or new
    # generated formatted which is typically:
    # new:
    #   https://manifest.googlevideo.com/api/manifest/dash/...
    #   https://manifest.googlevideo.com/api/manifest/hls_variant/...
    # old

# Generated at 2022-06-22 06:45:32.050733
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor.common import InfoExtractor
    from ..compat import compat_urlparse

    ie = InfoExtractor()
    ie.set_player_url('http://foo.com/player.swf')

    fd = DashSegmentsFD(ie, compat_urlparse.urlparse('http://foo.com/video.mp4'))

    assert not fd.params.get('test', False)
    assert fd.params.get('fragment_base_url', '') == ''
    assert fd.params.get('fragment_retries', -1) == -1
    assert fd.params.get('skip_unavailable_fragments', False) == False


# Generated at 2022-06-22 06:45:40.707377
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    dash_info_dict = {
        'fragment_base_url': '',
        'fragments': [{
            'path': 'fragment1.ts',
            'duration': 1,
            'title': 'fragment_1'
        }, {
            'path': 'fragment2.ts',
            'duration': 2,
            'title': 'fragment_2'
        }],
        'fragment_index_ratings': [],
        'fragment_index_rotation': 0
    }
    dash = DashSegmentsFD(dash_info_dict, {})
    assert(dash.name == 'dashsegments')
    assert(not dash._is_live)
    assert(dash._total_fragsize == 0)

# Generated at 2022-06-22 06:45:41.093280
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:46:32.009827
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    import os

    # Test for video with DASH manifest
    ie = YoutubeIE(params={'usenetrc': '1'})
    params = {'format': '251/140/251'}
    video_id = 'J---aiyznGQ'
    url = ie._make_url(video_id, params)
    params = ie._match_id(url)
    # Check that preprocessing succeeded
    assert params

    # Try to download with self.params.get('test', False) set to True
    # to download only 1 fragment (first) to speed up the test
    downloader = DashSegmentsFD(params, ie)
    _, info_dict = ie._extract_info(downloader.urlopen, video_id, downloader.params)
    # DashSegmentsFD

# Generated at 2022-06-22 06:46:42.281013
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    test_Downloader = None
    test_params = {}
    test_FD = DashSegmentsFD(test_Downloader, test_params)
    if not test_FD._do_download:
        return False
    if test_FD.FD_NAME != "dashsegments":
        return False
    if not test_FD._prepare_and_start_frag_download:
        return False
    if not test_FD._download_fragment:
        return False
    if not test_FD._append_fragment:
        return False
    if not test_FD._finish_frag_download:
        return False
    if not test_FD.report_skip_fragment:
        return False
    if not test_FD.report_retry_fragment:
        return False

# Generated at 2022-06-22 06:46:53.308589
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    import os
    import tempfile
    import json
    import subprocess
    from ..extractor.common import FileDownloader,youtube_dl
    from ..extractor.youtube import YoutubeIE
    from ..utils import get_exe_version
    from ..jsinterp import JSInterpreter
    from ..downloader import FileDownloader
    from ..extractor.youtube import YoutubeIE
    from ..compat import (
        compat_urllib_request,
    )
    def extract_info(self, *args, **kwargs):
        return YoutubeIE()._real_extract(self, *args, **kwargs)
    ydl = youtube_dl()
    ydl.add_info_extractor(YoutubeIE())
    ydl.params['quiet'] = True
    ydl.params['skip_download'] = True

# Generated at 2022-06-22 06:47:03.336373
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import os

    if os.environ.get('TRAVIS', None) == 'true':
        raise RuntimeError('Running unit tests on Travis is forbidden.')

    from .dashsegments import DashSegmentsFD
    from ..YoutubeDL import YoutubeDL

    ydl = YoutubeDL({'quiet': True})
    fd = DashSegmentsFD(ydl, {'format': '140'})
    assert fd.real_download('dummy_filename', {
        'id': 'ABCDEFG',
        'title': 'Dummy Title',
        'ext': 'mp4',
        'fragment_base_url': 'https://some_address.com/',
        'fragments': [{'path': 'some_name.mp4', 'duration': 0.0}]
    })

# Generated at 2022-06-22 06:47:11.777626
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..constants import is_py2
    o = DashSegmentsFD(0,1,2,{})
    assert o.fd_name=='dashsegments'
    assert o.progress_hooks==[o._downloader.hooks.apply('download_fragment', o._progress_hooks)]
    assert o.params=={}
    assert o.context=={}
    assert isinstance(o.downloaded_bytes, (int,long if is_py2 else int))
    assert o.total_frags==0
    assert o.fragment_index==0

# Generated at 2022-06-22 06:47:24.049806
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .fragment import FileFragmentFD
    from ..YtdlFileDownloader import YtdlFileDownloader

    # Get test data
    d = YtdlFileDownloader({'noplaylist': True, 'extract_flat': 'in_directory',
                            'youtube_include_dash_manifest': True, 'nocheckcertificate': True,
                            'match_filter': {'age_limit': 18}, 'socket_timeout': 10})
    d.params['outtmpl'] = '%(id)s.%(ext)s'
    d.params['writedescription'] = True
    d.params['writeinfojson'] = True
    d.params['infoname'] = True
    d.params['format'] = '140/m4a/webm'

# Generated at 2022-06-22 06:47:34.629616
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .dashmanifest import MockDashManifestFD
    segment_manifest = {
        "media": [],
        "base_uri": "",
        "segments": [
            {"ts": "1.ts"},
            {"ts": "2.ts"},
            {"ts": "3.ts"},
        ],
    }

    ydl = MockDashManifestFD(
        {}, downloader=None, params={'skip_unavailable_fragments': True})

    def _download_fragment(ctx, fragment_base_url, fragment):  # pylint: disable=unused-argument
        fragment_url = urljoin(fragment_base_url, fragment['ts'])
        success = fragment_url.endswith('1.ts') or fragment_url.endswith('2.ts')
        return

# Generated at 2022-06-22 06:47:38.034903
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    e = DashSegmentsFD()
    assert e.FD_NAME == 'dashsegments'


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:47:49.676546
# Unit test for constructor of class DashSegmentsFD

# Generated at 2022-06-22 06:47:54.914130
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD.create_downloader({
        "protocol": "dashsegments",
        "manifest_url": "http://www.testcase.org/dashtestsuite/testcases/2a-multi-period-init-seg/02.mpd",
        "format": "3",
        "skip_unavailable_fragments": True,
    })
    return fd

# Generated at 2022-06-22 06:49:11.643442
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..ytdl import YoutubeDL
    ydl = YoutubeDL({'outtmpl': '%(id)s%(ext)s'})
    fd = DashSegmentsFD(ydl, {})
    assert fd.params == {}


# Generated at 2022-06-22 06:49:23.038782
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.generic import GenericIE

    d = YoutubeDL({
        'quiet': True,
        'skip_download': True,
        'simulate': True,
    })
    ext = GenericIE(d)

    d.add_info_extractor(ext)
    ext.add_info_extractor(DashSegmentsFD.ie_key())

    result = d.extract_info(
        'https://example.org/manifest.mpd', download=True)
    assert result['url'] == 'https://example.org/manifest.mpd'
    assert result['http_headers'] == {'Foo': 'Bar'}

# Generated at 2022-06-22 06:49:32.394353
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import sys
    import os
    import glob
    import re
    import shutil

    for root, dirs, files in os.walk(os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'test', 'dash')):
        for dirname in dirs:
            input_base = os.path.join(root, dirname)
            print("Testing %s" % input_base)
            input_manifest = glob.glob(os.path.join(input_base, '*.mpd'))[0]
            cwd = os.getcwd()
            os.chdir(os.path.dirname(__file__))