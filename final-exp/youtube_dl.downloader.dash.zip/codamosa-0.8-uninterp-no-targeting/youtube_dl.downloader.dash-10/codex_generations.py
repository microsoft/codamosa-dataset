

# Generated at 2022-06-22 06:39:49.202107
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .http import HttpFD
    from . import HlsFD
    from ..extractor import gen_extractors
    fd = DashSegmentsFD({'fragment_base_url': 'https://vod.liverail.com/video/mp4:sample_vod/Manifest.mpd', 'fragments': [0,1], 'ext': 'mp4'}, {}, {}, {}, {})
    if not type(fd) == HttpFD:
        raise TypeError()
    fd = DashSegmentsFD({'fragment_base_url': 'https://vod.liverail.com/video/mp4:sample_vod/Manifest.mpd', 'fragments': [0,1], 'ext': 'm3u8'}, {}, {}, {}, {})

# Generated at 2022-06-22 06:39:59.158319
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..downloader.common import FileDownloader
    from ..compat import urlparse
    from ..utils import prepend_extension
    import sys

    youtube_ie = YoutubeIE()
    yt_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    yt_url = 'https://www.youtube.com/watch?v=nEKWcNDvMRU'
    #yt_url = 'https://www.youtube.com/watch?v=JGwWNGJdvx8'
    #yt_url = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    #yt_url = 'https://www.youtube.com/watch?v=VuNIsY6JdU

# Generated at 2022-06-22 06:40:09.651531
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from .dash import DashFD
    from .fragment import FragmentFD
    from .hls import HlsFD
    from .smil import SmilFD


# Generated at 2022-06-22 06:40:18.617585
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    with youtube_dl.YoutubeDL(youtube_dl.YoutubeDL.params) as ydl:
        ydl.params.update({
            'continue_dl': False,
            'format': 'm3u8',
            'outtmpl': '%(id)s.%(ext)s',
            'quiet': True,
        })

    class MockYoutubeDL(youtube_dl.YoutubeDL):
        def __init__(self, *args, **kwargs):
            super(MockYoutubeDL, self).__init__(*args, **kwargs)
            self.cachedir = '/dev/null'

        def process_info(self, *args, **kwargs):
            return {
                'id': '12345',
                'title': 'test',
            }


# Generated at 2022-06-22 06:40:28.716132
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .test import FakeYDL
    from ..extractor.common import InfoExtractor

    class FakeIE(InfoExtractor):
        def _download_webpage(self, url, video_id, note, errnote, fatal):
            vid_data = '<MPD>Fake Video Data</MPD>'
            url_data = '{"Name": "test_real_download",' \
                       ' "Subtitles":{}, "formats": [ {"format_id": "Dash", "url": "url"} ]}'
            if url == 'http://test.com/test.mpd':
                return vid_data, None
            elif url == 'http://test.com/info.json':
                return url_data, None


# Generated at 2022-06-22 06:40:34.952873
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    url = 'https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd'
    info_dict = {
        'format_id': 'dash',
        'fragment_base_url': url,
        'fragments': [{'url': url}, {'url': url}]
    }
    DashSegmentsFD().download([], info_dict)

# Generated at 2022-06-22 06:40:38.395307
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    #--start-time 10 --end-time 15

    d = DashSegmentsFD()


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:40:39.757608
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass # TODO


# Generated at 2022-06-22 06:40:46.849486
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """
    Unit test for DashSegmentsFD
    """
    test_data = {
        'protocol': 'dashsegments+http',
        'fragments': [
            {'url': 'http://example.com/segment1.ts'},
            {'url': 'http://example.com/segment2.ts'},
            {'url': 'http://example.com/segment3.ts'},
        ],
    }
    fd = DashSegmentsFD(test_data, None, None)
    assert 'http://example.com/segment1.ts' == fd.test_urls[0]
    assert 'http://example.com/segment2.ts' == fd.test_urls[1]
    assert 'http://example.com/segment3.ts' == fd

# Generated at 2022-06-22 06:40:57.359480
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import io
    import json
    import os
    import sys
    import tempfile

    from ..utils import (
        PostProcessingError,
        match_filter_func,
        prepend_extension,
    )

    from .fragment import (
        FragmentFD,
    )

    DASH_MANIFEST_FILE = os.path.join(os.path.dirname(__file__), 'test', 'fixtures', 'dash_manifest.json')
    with io.open(DASH_MANIFEST_FILE, encoding='utf-8') as f:
        dash_manifest = json.load(f)


# Generated at 2022-06-22 06:41:04.603766
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    raise NotImplementedError

# Generated at 2022-06-22 06:41:16.946683
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor.common import InfoExtractor
    from ..downloader.http import HttpFD
    from .rtmp import RtmpFD

    class DummyIE(InfoExtractor):
        IE_NAME = 'dummy'
        IE_DESC = 'Dummy description'
        _VALID_URL = r'(.+)'

    ie = DummyIE([u'http://test/test.mpd'], 'DASH', VideoInfo(None, None, None, []))
    assert ie.suitable(DummyIE.dl(ie.urls[0]))
    info = ie._real_extract(ie.suitable(DummyIE.dl(ie.urls[0])))
    assert info['protocol'] == 'dash'


# Generated at 2022-06-22 06:41:22.843497
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Assert that DashSegmentsFD is type of FragmentFD
    dashFD = DashSegmentsFD()
    assert isinstance(dashFD, FragmentFD)
    assert dashFD != None
    # Assert that DashSegmentsFD instance has name of DashSegmentsFD
    # assert downloader.params.get('name', '') == DashSegmentsFD.FD_NAME
    print('test_DashSegmentsFD URL JSON: ' + str(dashFD))

if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:41:24.647522
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    print(DashSegmentsFD.__name__)


if __name__ == '__main__':
    test_DashSegmentsFD()

# Generated at 2022-06-22 06:41:33.735799
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    # The file contains 7 segments
    youtube_id = 'vlhBpzE9e7s'
    # The test-case requires the following command
    #     youtube-dl --cookies /tmp/cookies.txt --no-check-certificate -o - https://www.youtube.com/watch?v=vlhBpzE9e7s
    # to be run beforehand to obtain the necessary cookies

    # Verify that exactly 7 fragments can be successfully downloaded
    import pickle
    import os
    import youtube_dl.YoutubeDL as youtube_dl
    with open('/tmp/cookies.txt', 'rb') as f:
        cookies = pickle.load(f)

# Generated at 2022-06-22 06:41:44.981521
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import youtube_dl
    import datetime

    url = 'https://youtu.be/imJd18jqYWI'
    outtmpl = "test_DashSegmentsFD_real_download_%(ext)s"
    ydl = youtube_dl.YoutubeDL({'outtmpl': outtmpl, 'quiet': True, 'noplaylist':True})
    info_dict = ydl.extract_info(url, download=False)

    assert 'requested_formats' in info_dict
    assert len(info_dict['requested_formats']) > 0
    req_formats = [
        f for f in info_dict['requested_formats']
        if f['ext'] == 'mp4' and f['format_id'].startswith('137')]

# Generated at 2022-06-22 06:41:54.705835
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    def my_hook(d):
        if d['status'] == 'finished':
            raise Exception('finished!')
    ydl = YoutubeDL({'fragment_retries': 3, 'progress_hooks': [my_hook]})
    from .dash import DashIE
    dash_ie = DashIE()
    ydl.add_info_extractor(dash_ie)
    ydl.params['test'] = True
    with ydl:
        dash_ie._real_initialize()
        dash_ie._downloader.params['test'] = True
        # Test that all fragments are downloaded successfully
        dash_ie.info['fragments'][9]['url'] = 'http://nonexistent.com/'

# Generated at 2022-06-22 06:42:05.121308
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.common import InfoExtractor
    from ..extractor.youtube import YoutubeIE

    ie = InfoExtractor()
    ie.add_info_extractor(YoutubeIE())
    ydl = YoutubeDL(ie)

    def urlopen_mock(request):
        class MockResponse:
            def __init__(self, code):
                self.code = code
        # A list of responses for each of the fragments.
        responses = [
            MockResponse(200),  # OK
            MockResponse(404),  # File not found
            MockResponse(200),  # OK
        ]
        # Return responses in the order of requests
        self.requests.append(request)

# Generated at 2022-06-22 06:42:05.565481
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:42:17.214531
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import DashFD
    from .http import HttpFD
    from .http import _sort_formats
    from .Extractor import YoutubeIE
    from .common import FileDownloader
    from .extractor import gen_extractors
    ydl = FileDownloader({})
    ydl.add_info_extractor(YoutubeIE())
    ydl.add_info_extractor(gen_extractors())
    ydl.params['nopart'] = True
    ydl.params['skip_unavailable_fragments'] = True
    ydl.params['retries'] = 10
    ydl.params['fragment_retries'] = 10
    ydl.params['test'] = True
    ydl.params['quiet'] = True

    # Test YoutubeIE
    info = ydl.extract_info

# Generated at 2022-06-22 06:42:38.195101
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .dash import (
        DASHIE,
        __main__ as dash_main,
        download,
    )
    from ..extractor import gen_extractors
    ydl = YoutubeDL({
        'noplaylist': True,
        'skip_download': True,
        'nocheckcertificate': True,
    })
    for ie in gen_extractors():
        if ie.IE_NAME == DASHIE:
            dash_ie = ie
            break
    dash_ie.set_downloader(ydl)
    dash_ie._downloader = ydl

# Generated at 2022-06-22 06:42:47.358162
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..extractor import fake_extractor
    from ..downloader.common import DownloadContext
    from .fragment import FragmentFD
    with DownloadContext() as ctx:
        ie = fake_extractor()
        fragments = [
            {
                'url': 'http://dash_segment_url',
                'fragment_base_url': 'http://fragment_base_url',
                'fragments': [
                    {'path': 'fragment_1.mp4'},
                    {'path': 'fragment_2.mp4'}
                ]
            }
        ]
        fragment_fd = DashSegmentsFD()
        fragment_fd._downloader = ctx.ydl
        fragment_fd._prepare_and_start_frag_download = FragmentFD._prepare_and_

# Generated at 2022-06-22 06:42:58.622190
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import youtube_dl
    # Create and initialize the instance of class DashSegmentsFD
    ydl_opts = {'outtmpl': 'test_DashSegmentsFD_real_download-%(format)s.%(ext)s'}
    ydl = youtube_dl.YoutubeDL(ydl_opts)
    d = DashSegmentsFD(ydl, ydl_opts)
    # Create tempfile for testing
    import tempfile
    file = tempfile.NamedTemporaryFile(delete=False)
    # Prepare info dict for testing
    info_dict = dict()
    info_dict['fragment_base_url'] = 'http://www.youtube.com/api/manifest/dash/'
    fragment1 = dict()

# Generated at 2022-06-22 06:43:06.116907
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .internal_fd import InternalFD
    from ..downloader import Downloader
    from ..extractor import YoutubeIE
    from ..utils import sanitize_open, mask_password

    dl = Downloader(params={'usenetrc': True})
    ie = YoutubeIE()
    url = 'https://www.youtube.com/watch?v=_HSylqgVYQI'
    info_dict = ie.extract(url)
    print('Running unit test on %s' % ie.IE_NAME)
    print(info_dict)
    urlh = dl.urlopen(url)
    assert urlh.status == 200
    dash_manifest = dl.cache.load('test_DashSegmentsFD_real_download', urlh.read)
    assert dash_manifest

# Generated at 2022-06-22 06:43:11.045444
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():

    from .http import HttpFD

    dash_fd = DashSegmentsFD(HttpFD(), None, {})
    assert dash_fd.FD_NAME == 'dashsegments'

    assert dash_fd.real_download() == True

    print('Test passed!')


if __name__ == '__main__':

    test_DashSegmentsFD()

# Generated at 2022-06-22 06:43:19.919036
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import sys
    from ..extractor.youtube import YoutubeIE
    from ..utils import strip_jsonp, parse_duration
    from .. import YoutubeDL
    from .tddownload import TDDownload

    class FakeYDL(YoutubeDL):
        def __init__(self, *args, **kwargs):
            assert 'logger' not in kwargs
            super(FakeYDL, self).__init__(*args, **kwargs)

        def _match_entry(self, ie_key, url):
            ie = self._ies[ie_key]
            ie.extract(url)
            return ie.url, ie.title, ie.thumbnail

    def doit(ydl, url):
        m = ydl.extract_info(url, download=True)
        assert m is not None

# Generated at 2022-06-22 06:43:23.156117
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    fd = DashSegmentsFD(params={}, ydl=None)
    assert fd.FD_NAME == 'dashsegments'
    assert fd.params == {}
    assert fd.ydl == None

# Generated at 2022-06-22 06:43:35.303565
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # download in test mode
    ydl = YoutubeDL({'quiet': True, 'test': True})
    dash_fd = DashSegmentsFD(ydl,
                             {
                                 'fragment_base_url': 'https://example.org/',
                                 'fragments': [{'path': 'foo.mp4', 'duration': 10},
                                               {'path': 'bar.mp4', 'duration': 20},
                                               {'path': 'baz.mp4', 'duration': 15}],
                                 'protocol': 'dash',
                                 'title': 'foobar',
                                 'ext': 'mp4',
                                 'duration': 45,
                             })

# Generated at 2022-06-22 06:43:36.502221
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:43:37.168070
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    DashSegmentsFD()

# Generated at 2022-06-22 06:44:02.522273
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .http import HttpFD
    from .hls import HlsFD
    from .fragment import FragmentFD
    from .f4m import F4mFD
    from .smoothstreams import SmoothstreamsFD

    # Test all classes, that can generate a segments list
    for test_class in (F4mFD, HlsFD, SmoothstreamsFD):
        test_class(params={'format': 'bestvideo[protocol^=http]', 'skip_unavailable_fragments': False, 'fragment_retries': 3})

# Generated at 2022-06-22 06:44:06.759652
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():                  
    ydl = YoutubeDL({}).add_default_info_extractors()
    ydl.params['skip_download'] = True
    d = ydl.prepare_download_entry('http://www.example.com/video.mpd')
    assert isinstance(d, DashSegmentsFD)
    assert d.params['skip_unavailable_fragments'] == True

# Generated at 2022-06-22 06:44:15.040873
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from .simulator import TestDownloader
    from .simulator import FakeYDL
    from .simulator import FakeHttpServer
    from .simulator import FakeInfoExtractor
    from .simulator import FakeFragmentFD
    from .simulator import DummyFD
    from .simulator import assertRegexCount
    import re

    def fake_download(self, filename, info_dict):
        # Download first two fragments and then fail
        if self.params['test'] == False:
            self.params['test'] = True
        return FakeFragmentFD.real_download(self, filename, info_dict)

    simfd = FakeFragmentFD.__bases__[0]
    simfd.real_download = fake_download
    ie = FakeInfoExtractor()
    # Build an MPD file

# Generated at 2022-06-22 06:44:27.011884
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..YoutubeDL import YoutubeDL
    from ..extractor.youtube import YoutubeBaseInfoExtractor
    from .test_extractors import FakeYDL
    from ..extractor.common import InfoExtractor, SearchInfoExtractor, OnDemandPagedList
    from ..extractor.brightcove import BrightcoveLegacyIE
    from ..utils import orderedSet, compute_code, sanitize_open

# Generated at 2022-06-22 06:44:38.148580
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import pytest
    from ..Extractor import gen_extractors

    json_data = {
        '_type': 'url',
        'url': 'https://dev.youtube.com/playlists/1',
        'ie_key': 'YoutubePlaylist',
        'title': 'test-youtube-playlist',
    }
    extractors = gen_extractors()
    for ie in extractors:
        if ie.ie_key() == 'YoutubePlaylist':
            info_dict = ie.extract({'url': 'https://dev.youtube.com/playlists/1'})
            segments_fd = DashSegmentsFD(info_dict, json_data)
            assert segments_fd.get_name() == "Dash segments of test-youtube-playlist"

# Generated at 2022-06-22 06:44:50.051181
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from .common import FakeYDL, FakeInfoExtractor, FakeDownloader
    from ..compat import compat_urllib_request

    def test_download_fragment(ctx, fragment_url, info_dict):
        # Set the content of the fragment that will be downloaded
        f = open(ctx['filename'], 'w')
        f.write(fragment_url)
        f.close()
        compat_urllib_request.urlretrieve = test_urlretrieve_set_content
        return True, True

    def test_urlretrieve_set_content(url, filename):
        f = open(filename, 'w')
        f.write(url)
        f.close()

    downloader = FakeDownloader()
    ie = FakeInfoExtractor(downloader)
    ie.real_download = test_

# Generated at 2022-06-22 06:44:51.541382
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    assert DashSegmentsFD.FD_NAME == 'dashsegments'

# Generated at 2022-06-22 06:45:00.238972
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from .dash import DashFD
    # Manually construct DashFD to avoid complex dependencies
    dashFD = DashFD()
    dashFD.params = {}
    dashFD.report_error = lambda msg: None
    dashFD.report_warning = lambda msg: None
    dashFD.to_screen = lambda msg: None
    dashFD.query_info(manifest_url="http://127.0.0.1/index.mpd", url_referer=None,
                      extra_info={'format':'dash-flv'}, download=True)

# Generated at 2022-06-22 06:45:10.678950
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    import youtube_dl
    import re

    ydl = youtube_dl.YoutubeDL()
    ydl.params['format'] = 'dashsegments'
    ydl.params['skip_unavailable_fragments'] = True
    ydl.params['min_frag_cnt'] = 1
    ydl.params['max_frag_cnt'] = 1
    ydl.params['keep_fragments'] = True
    dashseg_mem = {}
    ydl.add_info_extractor(utils.get_info_extractor('generic'))
    res = {}
    def dl(url, params):
        if url not in res:
            with open('test/test_data/dash-manifest.mpd') as f:
                res[url] = f.read()

# Generated at 2022-06-22 06:45:21.698599
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    class TestDashSegmentsFD(DashSegmentsFD):
        def __init__(self, ydl, *args, **kwargs):
            super(TestDashSegmentsFD, self).__init__(*args, **kwargs)
            self.ydl = ydl
            # these are used by the unit test
            self.info_dict = None
            self.manifest_url = None

        def _prepare_and_start_frag_download(self, ctx):
            ctx['total_bytes'] = 0
            ctx['fragment_index'] = 0
            ctx['tmpfilename'] = self.ydl.prepare_filename(self.info_dict)
            ctx['stream_fp'] = open(ctx['tmpfilename'], 'wb')


# Generated at 2022-06-22 06:46:07.712311
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    """
    Create a DashSegmentsFD object and see if it is in a
    consistent state.
    """
    ydl = YoutubeDL(params={'skip_download': True})
    info = {
        'id': 'testid',
        'title': 'testtitle',
        'url': 'http://example.org/',
        'fragments': [{'url': 'http://example.org/1'},
                      {'url': 'http://example.org/2'}],
    }
    dashsegmentsfd = DashSegmentsFD(ydl=ydl, info_dict=info)
    assert dashsegmentsfd.ydl == ydl
    assert dashsegmentsfd.info_dict == info
    assert dashsegmentsfd.filename == 'testtitle.mp4'
    assert dashsegmentsfd.total_fr

# Generated at 2022-06-22 06:46:19.593789
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # constructor 1
    dash_segment_down = DashSegmentsFD(
                                params={
                                    'fragment_base_url': 'https://example.com',
                                    'fragments': [
                                        {'path': '/foo', 'duration': '1.42'},
                                        {'path': '/bar', 'duration': '2.84'},
                                    ],
                                },
                             )
    # constructor 2
    dash_segment_down = DashSegmentsFD(
                                params={
                                    'fragments': [
                                        {'url': 'https://example.com/foo', 'duration': '1.42'},
                                        {'url': 'https://example.com/bar', 'duration': '2.84'},
                                    ],
                                },
                             )
    #

# Generated at 2022-06-22 06:46:30.660662
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..extractor import YoutubeIE
    from ..compat import get_hexdigest

# Generated at 2022-06-22 06:46:40.745449
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    class FakeInfoDict():
        def __init__(self, fragment_url, path, total_frags):
            self.fragment_url = fragment_url
            self.path = path
            self.fragments = []
            i = 0
            while i < total_frags:
                self.fragments.append({'url': self.fragment_url +
                      str(i), 'path': self.path + str(i)})
                i += 1

    class FakeParams():
        def __init__(self, skip_unavailable_fragments, test, fragment_retries):
            self.skip_unavailable_fragments = skip_unavailable_fragments
            self.test = test
            self.fragment_retries = fragment_retries


# Generated at 2022-06-22 06:46:41.349746
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    assert True

# Generated at 2022-06-22 06:46:46.989604
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    url = "http://localhost/file.mpd"
    info_dict = {
        "fragment_base_url": "http://localhost/video.mp4",
        "fragments": [{"path": "0.m4s"}, {"path": "0.m4s"}]
    }
    dl = DashSegmentsFD(url, None, info_dict)
    dl.real_download("file.mp4", info_dict)

# Generated at 2022-06-22 06:46:58.016751
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    import re
    import os.path

    # Needed to run unit test
    # msftsmctrl = ctypes.windll.LoadLibrary("C:\\Windows\\System32\\msftsmctrl.dll")
    # msftsmctrl.ConnectToSharedResource.argtypes = [ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p]
    # msftsmctrl.ConnectToSharedResource.restype = ctypes.c_uint

    # if msftsmctrl.ConnectToSharedResource(None, "

# Generated at 2022-06-22 06:47:07.800508
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    #pylint: disable=W0612
    class InfoDict(object):
        def get(self, key, default=None):
            return default

    info_dict = InfoDict()

# Generated at 2022-06-22 06:47:08.451157
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:47:09.517876
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    return DashSegmentsFD(None)

# Generated at 2022-06-22 06:48:47.836168
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..downloader import YoutubeDL
    from .http import HttpFD
    from .hls import HlsSegmentsFD
    youtubedl = YoutubeDL()
    youtubeurl = 'https://www.youtube.com/watch?v=BaW_jenozKc'
    d = youtubedl.extract_info(youtubeurl, download=False)
    ext = d['ext']
    formats = d['formats']
    format = formats[0]
    fmt_url = format['url']
    ext_no_dash = ext[:-4]
    dash_seg_d = DashSegmentsFD(youtubedl, {'format': format, 'nopart': True, 'continuedl': True})

# Generated at 2022-06-22 06:48:48.296079
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    pass

# Generated at 2022-06-22 06:48:58.589279
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    from ..downloader import Downloader
    from ..YoutubeDL import YoutubeDL
    import os
    os.environ["YOUTUBE_DL_DASH_TEST"] = "True"
    test = Downloader(YoutubeDL(), {
        'fragment_base_url': 'http://s3.amazonaws.com/',
        'fragments': [
            {'path': 'test1.ts'},
            {'path': 'test2.ts'},
            {'path': 'test3.ts'},
            {'path': 'test4.ts'},
        ]
    })
    #os.environ["YOUTUBE_DL_DASH_TEST"] = "True"

# Generated at 2022-06-22 06:49:01.056254
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # It should return an instance
    assert DashSegmentsFD is not None
# end test_DashSegmentsFD


# Generated at 2022-06-22 06:49:09.816758
# Unit test for method real_download of class DashSegmentsFD
def test_DashSegmentsFD_real_download():
    dashSegmentsFD = DashSegmentsFD()
    info_dict = {
        'fragment_base_url': 'https://127.0.0.1/',
        'fragments': [
            { 'url': 'https://127.0.0.1/video.mp4' },
            { 'path': 'video2.mp4', 'duration': 10.0 },
            { 'path': 'video3.mp4', 'duration': 10.0 },
        ],
        'duration': 30.0
    }
    dashSegmentsFD.real_download('video.mp4', info_dict)

# Generated at 2022-06-22 06:49:14.393212
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # Just test that the constructor does not raise any exception
    DashSegmentsFD()

if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-22 06:49:24.951849
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    from ..YoutubeDL import YoutubeDL
    from .fragment import available
    import tempfile

    ydl = YoutubeDL()
    ydl.params['skip_download'] = True
    ydl.params['dump_single_json'] = True
    ydl.params['file_id'] = 'test'
    ydl.params['outtmpl'] = '%(file_id)s.%(ext)s'


# Generated at 2022-06-22 06:49:27.298949
# Unit test for constructor of class DashSegmentsFD
def test_DashSegmentsFD():
    # check that we can create an instance of DashSegmentsFD
    fd = DashSegmentsFD()