

# Generated at 2022-06-12 13:31:09.917219
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"


# Generated at 2022-06-12 13:31:17.273788
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import threading
    condition = Condition()
    n = N = 10
    def main():
        def yes(condition):
            condition.acquire()
            condition.wait()
            nonlocal n
            n -= 1
            condition.release()
        def no(condition):
            condition.acquire()
            condition.wait()
            nonlocal n
            n += 1
        threads = [threading.Thread(target=yes, args=(condition,)) for _ in range(N)]
        threads += [threading.Thread(target=no, args=(condition,)) for _ in range(N)]
        for thread in threads:
            thread.start()
        condition.acquire()
        condition.release()
        condition.notify_all()
        for thread in threads:
            thread.join()
    main()
    assert n == 0



# Generated at 2022-06-12 13:31:20.077410
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    """Test case for method Condition.__repr__ of class Condition

    """
    object1 = Condition()
    # object1.__repr__()


# Generated at 2022-06-12 13:31:21.232300
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Lock.__aenter__(lock)
    assert True # TODO: implement your test here



# Generated at 2022-06-12 13:31:22.093212
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    with lock:
        pass



# Generated at 2022-06-12 13:31:23.578545
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)
    print(sem.acquire().result())


# Generated at 2022-06-12 13:31:27.868104
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    print("Test begin", "Condition.__repr__", sep="\n")
    cond = Condition()
    print(cond)
    print("Test end", "Condition.__repr__", sep="\n")

test_Condition___repr__()


# Generated at 2022-06-12 13:31:30.573895
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado.locks import Lock

    lock = Lock()
    lock.__aenter__()



# Generated at 2022-06-12 13:31:37.668078
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    import asyncio
    from tornado.ioloop import IOLoop
    fut = Future()
    IOLoop.current().add_callback(lambda: fut.set_result(None))
    async def t():
        s = Semaphore(0)
        async with s:
            assert s._value == 0

        async with s:
            assert s._value == 0

        async with s:
            assert s._value == 0

        await fut
        IOLoop.current().stop()

    IOLoop.current().run_sync(t)


Lock = Semaphore



# Generated at 2022-06-12 13:31:41.891455
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    test = Semaphore(1)
    assert test._value == 1 # release has not been called
    test.release()
    assert test._value == 0 # release has been called but still no waiters
    assert len(test._waiters) == 0 # no waiters
    test.release()
    assert test._value == 0 # release has been called and a waiter has been awoken


# Generated at 2022-06-12 13:31:53.969642
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    import unittest


# Generated at 2022-06-12 13:31:55.211473
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    foo = Condition()
    assert repr(foo) == "<Condition>"


# Generated at 2022-06-12 13:32:07.186533
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    self = Lock()
    self._block = BoundedSemaphore(value=1)
    self._block._value = 1

    # A call to __aexit__ without any exception should release the semaphore.
    repr_before = repr(self._block)
    await self.__aexit__(None, None, None)
    repr_after = repr(self._block)
    assert repr_after == "<BoundedSemaphore _value=2,_initial_value=1>"

    # A call to __aexit__ with an exception should raise that exception too.
    def f():
        self._block._value = 1
        self.__aexit__(ValueError, ValueError(''), None)

    with pytest.raises(ValueError, match=''):
        gen.convert_yielded(f())

# Generated at 2022-06-12 13:32:10.834668
# Unit test for method notify of class Condition
def test_Condition_notify():
    async def test():
        condition = Condition()

        async def waiter():
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")
            return True

        async def notifier():
            await gen.sleep(1)
            print("About to notify")
            condition.notify()
            print("Done notifying")

        def run():
            # Wait for waiter() and notifier() in parallel
            yield gen.multi([waiter(), notifier()])

        IOLoop.current().run_sync(run())



# Generated at 2022-06-12 13:32:14.862027
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    with pytest.raises(RuntimeError) as wrapper:
        with (locks.Lock()):
            pass
    assert str(wrapper.value) == "Use `async with` instead of `with` for Lock"


# Generated at 2022-06-12 13:32:17.051053
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set()


# Generated at 2022-06-12 13:32:18.450214
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(1)
    assert sem._value == 1
    sem._value = 1
    sem.release()
    assert sem._value == 2



# Generated at 2022-06-12 13:32:25.580906
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    a = BoundedSemaphore(value = 10)
    b = BoundedSemaphore(value = 2)
    a.release()
    assert a._value == 10, "Failed to release once"
    a.release()
    assert a._value == 10, "Failed to release twice"
    b.release()
    assert b._value == 2, "Failed to release once"
    b.release()
    assert b._value == 2, "Failed to release twice"
    b.release()
    assert True, "Failed to raise error when release too many times"
test_BoundedSemaphore_release()


# Generated at 2022-06-12 13:32:28.389161
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition=Condition()
    @gen.coroutine
    def wait_handle():
        yield condition.wait()
        print('i go here ')
    @gen.coroutine
    def notify_handle():
        condition.notify_all()
    ioloop.IOLoop.current().run_sync(lambda:gen.multi([wait_handle(),notify_handle()]))

# Generated at 2022-06-12 13:32:32.675464
# Unit test for method wait of class Condition
def test_Condition_wait():
    c = Condition()
    print(c)

    async def waiter():
        print('I will wait right here')
        await c.wait(timeout=datetime.timedelta(seconds=1))
        print('I am done waiting')

    async def notifier():
        print('About to notify')
        c.notify()
        print('Done notifying')

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(runner)


# Generated at 2022-06-12 13:32:52.897058
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    def __init__(self, value: int = 1) -> None:
        super().__init__()
        if value < 0:
            raise ValueError("semaphore initial value must be >= 0")

        self._value = value
    value=2
    if value < 0:
        raise ValueError("semaphore initial value must be >= 0")

    self._value = value
    waiter = Future()  # type: Future[_ReleasingContextManager]
    value=value-1
    if self._value > 0:
        self._value -= 1
        waiter.set_result(_ReleasingContextManager(self))
    else:
        self._waiters.append(waiter)
        if timeout:

            def on_timeout() -> None:
                if not waiter.done():
                    waiter.set_exception(gen.TimeoutError())


# Generated at 2022-06-12 13:33:04.632212
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import threading
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from tornado import gen
    import time

    condition3 = Condition()
    waiters3 = []
    num_waiters = 5

    def waiter():
        print("I'll wait right here")
        f = Future()
        waiters3.append(f)
        condition3.wait(timeout=time.time()+1)
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition3.notify_all()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        gen.multi([waiter() for _ in range(num_waiters)])
        notifier()


# Generated at 2022-06-12 13:33:07.906649
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock._block._value=False
    lock._block._waiters=[]
    try:
        lock.__aenter__()
        print("test_Lock___aenter__() passed")
    except:
        print("test_Lock___aenter__() failed")



# Generated at 2022-06-12 13:33:12.466380
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    task=[{"Method": {"TestCase": "test_Condition___repr__",
                      "expectation": "<Condition>",
                      "actual": [Condition.__repr__(Condition)],
                      "result": ""
    }}]
    return task


# Generated at 2022-06-12 13:33:15.907090
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    """
    This function will be used to test the Condition.__repr__() function
    """
    for _ in range(10):
        obj = Condition()
        assert repr(obj) == "<Condition waiters[0]>"

# Generated at 2022-06-12 13:33:19.143407
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock.__new__(Lock)
    lock.__init__()
    with pytest.raises(RuntimeError, match="Use 'async with' instead of 'with' for Lock"):
        lock.__enter__()

# Generated at 2022-06-12 13:33:27.810060
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:33:35.699330
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import asyncio
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await asyncio.gather(waiter(), notifier())

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:33:37.284538
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado.locks import Lock
    lck = Lock()
    return lck.__aenter__()


# Generated at 2022-06-12 13:33:46.824255
# Unit test for method notify of class Condition
def test_Condition_notify():
    """
    test notify of class Condition
    :return:
    """

    # Initialize the Condition object
    my_condition = Condition()
    my_waiters = []  # Waiters we plan to run right now
    # Test the notify method
    def notify(n):
        if n % 5 == 0:
            my_waiters.append(n)
            return my_condition.notify(n)
        else:
            return my_condition.notify(n)
    # Test the notify_all method
    def notify_all(self):
        return my_condition.notify_all()


    for i in range(0, 10):
        notify(i)
    notify_all(my_condition)
    print(my_waiters)


# Generated at 2022-06-12 13:34:13.257366
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    obj = Semaphore(2)
    # __repr__ doesn't work well with parallel loops
    assert repr(obj) == '<Semaphore [unlocked,value:2]>'
    with pytest.raises(ValueError):
        Semaphore(value=-1)


# Generated at 2022-06-12 13:34:18.874571
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    l = [0, 0]
    def f1():
        l[0] = 3
    def f2():
        l[1] = 6
    c = Condition()
    l1 = c.wait()
    l2 = c.wait()
    l1.add_done_callback(f1)
    l2.add_done_callback(f2)
    assert l == [0, 0]
    c.notify_all()
    assert l == [3, 6]

# Generated at 2022-06-12 13:34:24.310729
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
  from tornado import gen
  from tornado.ioloop import IOLoop
  from tornado.locks import Semaphore

  sem = Semaphore(2)

  async def worker(worker_id):
      async with sem:
          print("Worker %d is working" % worker_id)
          await use_some_resource()

      # Now the semaphore has been released.
      print("Worker %d is done" % worker_id)

  async def runner():
      # Join all workers.
      await gen.multi([worker(i) for i in range(3)])

  IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:34:27.914861
# Unit test for method set of class Event
def test_Event_set():
    """Test function for the method set of class Event"""
    event = Event()
    assert event._value == False
    event.set()
    assert event._value == True


# Generated at 2022-06-12 13:34:35.926669
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await sem.acquire()
            print("Worker %d is working" % worker_id)
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(runner)
    print('='*18)
    test_Semaphore_acquire()

        

# Generated at 2022-06-12 13:34:38.991718
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    flg = event.is_set()
    waiter = event.wait()
    if flg:
        print("Not waiting this time")
    else:
        print("Waiting for event")
    fut = Future()
    event.set()
    if not fut.done():
        fut.set_result(None)
        print("Not waiting this time")


# Generated at 2022-06-12 13:34:41.998693
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
  tk = Tk()
  btn = Button(tk, text="Btn1")
  tk.mainloop()

# Test for class Semaphore

# Generated at 2022-06-12 13:34:45.210069
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    sem._value
    sem.release()
    

# Generated at 2022-06-12 13:34:52.083026
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    waiter_count = 50
    waiter_async_list = []
    cond = Condition()
    for i in range(waiter_count):
        waiter_async_list.append(cond.wait())

    cond.notify_all()
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(lambda : gen.multi(waiter_async_list))
    count = 0
    for w in waiter_async_list:
        if w.result():
            count += 1
    assert(count == waiter_count)


# Generated at 2022-06-12 13:34:56.066404
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    if gen.is_coroutine_function(condition.__repr__):
        gen.convert_yielded(condition.__repr__())
    else:
        condition.__repr__()


# Generated at 2022-06-12 13:35:45.321850
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()
    async def waiter():
        yield condition.wait()
        print("I'm done waiting")
    async def notifier():
        await gen.sleep(0.5)
        condition.notify()
    async def runner():
        await gen.multi([waiter(), notifier()])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:35:46.856725
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c1 = Condition()
    # assert isinstance(c1.__repr__(), str)
    print(c1.__repr__())



# Generated at 2022-06-12 13:35:53.721903
# Unit test for method notify of class Condition
def test_Condition_notify():
    # test-unit-lock-Condition.html

    # Test notify.
    condition = Condition()

    @gen.coroutine
    def f():
        for i in range(3):
            yield condition.wait()
            time.sleep(0)

    @gen.coroutine
    def g():
        yield condition.notify(3)

    runners = [f(), g()]
    ioloop.IOLoop.current().run_sync(lambda: gen.multi(runners))

# Unit Test for method wait of class Condition

# Generated at 2022-06-12 13:36:01.463355
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")
    async def setter():
        print("About to set the event")
        event.set()
    async def runner():
        await gen.multi([waiter(), setter()])
    ioloop.IOLoop.current().run_sync(runner)
#test_Event_wait()


# Generated at 2022-06-12 13:36:02.841008
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    future = event.wait()
    assert future.result() is None

# 



# Generated at 2022-06-12 13:36:10.139485
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(0)
    sem._waiters = deque()
    t0 = asyncio.get_event_loop().time()
    async def acquire():
        return await sem.acquire(t0-1)
    cb = acquire()
    time_out = asyncio.get_event_loop().run_until_complete(cb)
    if time_out==None:
        print("Test_Semaphore_acquire pass")
    else:
        print("Test_Semaphore_acquire fail")

# Generated at 2022-06-12 13:36:13.526462
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    print("Inside test_Semaphore___aenter__()")
    assert Semaphore().__aenter__() == None

    print("Done executing test_Semaphore___aenter__()")



# Generated at 2022-06-12 13:36:18.736373
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    # Test with a timeout
    timeout1 = 10
    result_aenter_with_timeout = lock.__aenter__(timeout1)
    assert result_aenter_with_timeout is None
    assert lock.__aenter__ is Lock.__aenter__
    # Test with no timeout
    result_aenter_without_timeout = lock.__aenter__()
    assert result_aenter_without_timeout is None
    assert lock.__aenter__ is Lock.__aenter__

# Generated at 2022-06-12 13:36:23.864924
# Unit test for method wait of class Event
def test_Event_wait():
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    event = Event()
    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:36:29.054514
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import asyncio
    value = 1
    sem = Semaphore(value)
    print(sem)
    async def test():
        async with sem:
            # print(threading.current_thread())
            print("acquire semaphre success")
        print("release semaphre")
    loop = asyncio.get_event_loop()
    loop.run_until_complete(test())

# Generated at 2022-06-12 13:37:16.671289
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():  # type: ignore
    sem = Semaphore()
    await sem.__aenter__()

# Generated at 2022-06-12 13:37:19.492750
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore()
    sem.release()
    assert sem._value == 1
    sem.release()
    assert sem._value == 2

# Generated at 2022-06-12 13:37:21.596364
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    async def _aenter__():
        sem = Semaphore()
        await sem.acquire()

    _aenter__()

# Generated at 2022-06-12 13:37:27.415973
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:37:31.083331
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    value = 1
    sem = Semaphore(value)
    waiter = Future()
    if sem._value > 0:
        sem._value -= 1
        waiter.set_result(_ReleasingContextManager(sem))
    else:
        sem._waiters.append(waiter)
    return waiter

# Generated at 2022-06-12 13:37:34.770320
# Unit test for method wait of class Condition
def test_Condition_wait():
    cond = Condition()
    async def f():
        await cond.wait(datetime.timedelta(seconds=1))
        print('wait after 1 second')
    async def g():
        cond.notify(1)

    sleep = gen.sleep(2)
    loop = IOLoop.current()
    loop.run_sync(lambda: gen.multi([g(), f(), sleep]))


# Generated at 2022-06-12 13:37:43.993262
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    assert len(condition.io_loop._callbacks) == 0 
    condition.notify()
    assert len(condition.io_loop._callbacks) == 1 
    condition.notify(2)
    assert len(condition.io_loop._callbacks) == 3 
    assert type(condition.io_loop._callbacks[0][0]) is list 
    assert len(condition.io_loop._callbacks[0][0]) == 1 
    assert len(condition.io_loop._callbacks[1][0]) == 1 
    assert len(condition.io_loop._callbacks[2][0]) == 1 


#Unit test for method notify_all of class Condition

# Generated at 2022-06-12 13:37:48.933906
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:37:58.984587
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from asyncio import get_event_loop
    import time
    import sys

    def test_worker(sem):
        sem.acquire()
        print('Worker:', str(sem._waiters))

    # create a semaphore
    sem = Semaphore(1)
    # create a list to hold our pending futures
    to_do = []
    # create a list to hold our workers
    workers = []
    # create a list to hold our results
    results = []
    # create a list to hold our workers
    workers = []

    # create a class that can represent a worker
    class Worker:
        # define the constructor
        def __init__(self, sem):
            self.sem = sem

        # define the function that the threads will execute
        async def work_func(self):
            sem = self.sem


# Generated at 2022-06-12 13:38:02.059192
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    waiters = []
    while len(self._waiters) > 0:
        waiter = condition._waiters.popleft()
        if not waiter.done():
            waiters.append(waiter)
    if len(waiters) == 0:
        return True
    else:
        return False


# Generated at 2022-06-12 13:38:56.784921
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    print('start test')
    sem = Semaphore(2)
    print('semaphore created')
    async def worker(worker_id):
        async with sem:
            await gen.sleep(0)
            print("Worker %d is working" % worker_id)
        print("Worker %d is done" % worker_id)

    async def runner():
        await gen.multi([worker(i) for i in range(3)])

    ioloop.IOLoop.current().run_sync(runner)
    print('end test')

if __name__ == '__main__':
    test_Semaphore___aenter__()

# Generated at 2022-06-12 13:39:01.978419
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.locks import Semaphore
    class TestSemaphore___aenter__(AsyncTestCase):
        @gen_test
        def test_Semaphore___aenter__(self):
            sem = Semaphore(2)
            async with sem:
                pass
    test_Semaphore___aenter__().test_Semaphore___aenter__()



# Generated at 2022-06-12 13:39:03.262105
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    try:
        BoundedSemaphore(value=1).release()
    except ValueError:
        print('Exception handled')

# Generated at 2022-06-12 13:39:04.267088
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    await lock.__aenter__()
    pass

# Generated at 2022-06-12 13:39:09.485785
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():

    def test_Condition___repr__Nominal1():
        cond = Condition()
        result = cond.__repr__()
        expected = "<Condition>"
        assert result == expected

    def test_Condition___repr__Nominal2():
        cond = Condition()
        result = cond.__repr__()
        expected = "<Condition>"
        assert result == expected






# Generated at 2022-06-12 13:39:12.091317
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    b = BoundedSemaphore(value = 2)
    b.release()
    b.release()
    res = b.release()
    assert res == None



# Generated at 2022-06-12 13:39:13.546865
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Lock.__aenter__() -> None
    ...



# Generated at 2022-06-12 13:39:16.305683
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(3)
    async def foo():
        await sem.__aenter__()
        print('in __aenter__ of Semaphore')
    return foo

# Generated at 2022-06-12 13:39:25.973652
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore(1)
    #base case
    assert(s.acquire() == _ReleasingContextManager(s))
    #mutate
    s.value = 2
    assert(s.acquire() == _ReleasingContextManager(s))
    #mutate
    s.value = 4
    assert(s.acquire() == _ReleasingContextManager(s))
    #mutate
    s.value = 3
    assert(s.acquire() == _ReleasingContextManager(s))
    #mutate
    s.value = 5
    assert(s.acquire() == _ReleasingContextManager(s))
    #mutate
    s.value = 1
    assert(s.acquire() == _ReleasingContextManager(s))
    #mutate
    s.value = -2

# Generated at 2022-06-12 13:39:26.808501
# Unit test for method notify of class Condition
def test_Condition_notify():
    Condition.notify()
