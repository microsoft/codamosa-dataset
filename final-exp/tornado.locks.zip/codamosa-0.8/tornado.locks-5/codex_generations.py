

# Generated at 2022-06-12 13:31:13.628052
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
  cond = Condition()
  async def wait():
    print("I'll wait right here")
    await cond.wait()
    print("I'm done waiting")

  async def notify():
    print("About to notify")
    cond.notify_all()
    print("Done notifying")

  async def runner():
    # Wait for waiter() and notifier() in parallel
    await gen.multi([wait(), notify()])

  gen.convert_yielded(runner())

test_Condition_notify_all()


# Generated at 2022-06-12 13:31:19.853646
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado import gen
    from time import sleep

    class SemaphoreTestCase(AsyncTestCase):

        def set_up(self):
            self.semaphore = Semaphore(0)
            self.finished_waiting = False

        @gen_test
        def test_release(self):
            f = Future()
            self.semaphore.release()
            IOLoop.current().spawn_callback(self.wait_on_semaphore, f)
            yield f

            self.assertTrue(self.finished_waiting)


# Generated at 2022-06-12 13:31:22.098164
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore()

    with expect_exception(RuntimeError):
        with sem:
            pass


# Generated at 2022-06-12 13:31:33.185216
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from collections import deque
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))

    def use_some_resource():
        return futures_q.popleft()
    
    sem = Semaphore(2)

    async def worker(worker_id):
        await sem.acquire()

# Generated at 2022-06-12 13:31:36.596819
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    a = True
    b = True
    # Some code that I want to run
    # But it is not a generator

    if a and b:
        condition.notify_all()
        print('notify_all')


# Generated at 2022-06-12 13:31:44.367312
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    # test case for Semaphore.__repr__
    import tornado
    import datetime
    import inspect
    import math
    import os
    import random
    import shutil
    import string
    import threading
    import time
    import unittest
    import uuid
    import weakref
    from concurrent.futures import Future
    from tornado.gen import sleep, TimeoutError
    from tornado.httputil import HTTPHeaders, ResponseStartLine
    from tornado.http1connection import HTTP1ServerConnection
    from tornado.httpserver import HTTPServer
    from tornado.ioloop import IOLoop
    from tornado.log import gen_log
    from tornado.platform.asyncio import AsyncIOMainLoop, to_asyncio_future
    from tornado.platform.auto import Waker

# Generated at 2022-06-12 13:31:50.500052
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # User code
    import time
    import tornado.ioloop
    import asyncio
    asyncio.set_event_loop_policy(tornado.platform.asyncio.AnyThreadEventLoopPolicy())
    async def test():
        sem = Semaphore(1)
        # Note(Kris): set a string s as the lock's value
        s = 'lock'
        a = await sem.acquire()
        sem._value = s
        sem.release()
        print('After release:', sem._value)
        await gen.sleep(0)
    tornado.ioloop.IOLoop.current().run_sync(test)



# Generated at 2022-06-12 13:31:51.982971
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    a = Semaphore()
    a.release()
    assert a._value == 2

# Generated at 2022-06-12 13:32:01.967151
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    from tornado.concurrent import Future
    from typing import Any

    ioloop = IOLoop.current()

    @gen.coroutine
    def callback() -> Any:
        pass

    sem = Semaphore(1)
    assert sem.__aenter__() is None
    assert sem._value == 0

    sem._waiters.append(Future())
    assert sem.__aenter__() is None
    assert len(sem._waiters) == 0
    assert sem._value == 0

    sem = Semaphore(1)
    sem._value = 1

    assert sem.__aenter__() is None
    assert sem._value == 0

    IOLoop.current().run_sync(callback)
    return


# Generated at 2022-06-12 13:32:09.017659
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(1)
    assert sem._waiters == deque()
    sem.release()
    assert sem._value == 2
    assert sem._waiters == deque()
    fut = Future()
    sem._waiters.append(fut)
    sem.release()
    assert sem._value == 1
    assert sem._waiters == deque()
    assert fut.done()

# Generated at 2022-06-12 13:32:26.545567
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:32:37.577548
# Unit test for method notify of class Condition
def test_Condition_notify():
    # Test notify method of class Condition
    from tornado.locks import Condition, Event
    from tornado.ioloop import IOLoop

    def test_1(): # test notify
        condition = Condition()
        event = Event()
        def waiter():
            print("I'll wait right here")
            yield condition.wait()
            print("I'm done waiting")
            event.set()
        IOLoop.current().spawn_callback(waiter)
        condition.notify()
    test_1()
    IOLoop.current().run_sync(lambda : event.wait())

    def test_2(): # test notify all
        condition = Condition()
        event = Event()
        def waiter():
            print("I'll wait right here")
            yield condition.wait()
            print("I'm done waiting")
            event.set()
        IOLoop

# Generated at 2022-06-12 13:32:42.044782
# Unit test for method wait of class Event
def test_Event_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    # Create an event
    e = Event()

    # Create a future
    f = Future()

    # Set the event
    e.set()

    # Mark the future as done
    f.set_result(True)

    # Get the result of the future
    res = f.result()

    # Get the current event state
    res = e.is_set()

    # Create an event
    e = Event()

    # Create a future
    f = Future()

    # Create a future
    f1 = Future()

    # Set the event
    e.set()

    # Mark the future as done
    f.set_result(True)

    # Get the result of the future
    res = f.result()

   

# Generated at 2022-06-12 13:32:51.469325
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event._value == False
    assert event._waiters == set()
    assert event.is_set() == False
    assert isinstance(event, Event) == True
    assert isinstance(event.wait(), Awaitable) == True
    assert isinstance(event.wait(0.1), typing.Awaitable) == True
    event.set()
    assert event.is_set() == True
    assert isinstance(event.wait(), Awaitable) == True
    assert isinstance(event.wait(0.1), typing.Awaitable) == True
    event.clear()
    assert event.is_set() == False
    assert isinstance(event.wait(), Awaitable) == True
    assert isinstance(event.wait(0.1), typing.Awaitable) == True

# Unit test

# Generated at 2022-06-12 13:32:54.194247
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test for method __repr__ (Conditional) ...
    condition = Condition()
    assert condition.__repr__() == "<Condition>"
    waiter = Future()
    condition._waiters.append(waiter)
    assert condition.__repr__() == "<Condition waiters[1]>"


# Generated at 2022-06-12 13:32:59.664867
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import time
    import threading

    c = Condition()
    n = 0
    f1 = threading.Thread(target=lambda : c.wait(), name="f1")
    f2 = threading.Thread(target=lambda : c.wait(), name="f2")
    f3 = threading.Thread(target=lambda : c.wait(), name="f3")
    f4 = threading.Thread(target=lambda : c.wait(), name="f4")

    def get_n():
        nonlocal n
        n = n + 1

    f1.start()
    f2.start()
    f3.start()
    f4.start()
    time.sleep(0.1)
    c.notify_all()
    time.sleep(0.1)

    f1.join()

# Generated at 2022-06-12 13:33:03.993044
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    @gen.coroutine
    def f():
        async with lock:
            pass
    with pytest.raises(RuntimeError):
        lock.__aenter__()
    IOLoop.current().run_sync(f)


# Generated at 2022-06-12 13:33:10.332921
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    f1 = Future()
    f2 = Future()
    f3 = Future()
    cl = Condition()
    cl._waiters.appendleft(f1)
    cl._waiters.appendleft(f2)
    cl._waiters.appendleft(f3)
    assert len(cl._waiters) == 3
    # print(cl.notify_all())
    cl.notify_all()
    assert len(cl._waiters) == 0
test_Condition_notify_all()



# Generated at 2022-06-12 13:33:15.550543
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado import testing, gen
    from tornado.locks import Semaphore
    from tornado.queues import Queue
    from tornado.ioloop import IOLoop
    import time

    def _run_with_timeout(timeout, func, *args, **kwargs):
        with testing.gen_test(timeout=timeout) as test_case:
            test_case.stop()
            IOLoop.current().add_callback(lambda: func(*args, **kwargs))
            test_case.wait()

    def func():
        #count = 0
        result = []
        q = Queue()
        s = Semaphore()
        @gen.coroutine
        def inner_function(q, s, result):
            async with s:
                # Acquired.
                result.append(1)
                #print("Acquired.")

# Generated at 2022-06-12 13:33:18.314505
# Unit test for method wait of class Condition
def test_Condition_wait():
    cond = Condition()
    def on_wait():
        print("Wait started")
        cond.notify()
        print("Wait finished")
    cond.wait().add_done_callback(on_wait)



# Generated at 2022-06-12 13:33:44.205274
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    value = 1
    sem = Semaphore(value)

    assert(sem is not None)
    assert(sem.is_set() == True)

    sem.release()
    assert(sem.is_set() == True)

    sem.clear()
    assert(sem.is_set() == False)



# Generated at 2022-06-12 13:33:45.838454
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert lock.__aenter__() == None

# Generated at 2022-06-12 13:33:47.599604
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    test_condition = Condition()
    test_condition.notify_all()


# Generated at 2022-06-12 13:33:54.812124
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:33:56.290563
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert isinstance(lock, Lock)
    assert not lock.__aenter__()



# Generated at 2022-06-12 13:33:57.520454
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    a = Semaphore()
    yield a.__aenter__()
    a.release()


# Generated at 2022-06-12 13:34:01.334993
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    def waiter() -> None:
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    def setter() -> None:
        print("About to set the event")
        event.set()

    async def runner() -> None:
        await gen.multi([waiter(), setter()])

    runner()

# Generated at 2022-06-12 13:34:10.721214
# Unit test for method notify of class Condition
def test_Condition_notify():
    import asyncio
    from concurrent.futures import CancelledError
    async def notifier():
        print("About to notify")
        await asyncio.sleep(0.5)
        condition.notify()
        print("Done notifying")
        return True

    async def waiter():
        print("I'll wait right here")
        # timeout for test timeout
        await condition.wait(timeout=time.time()+0.5)
        print("I'm done waiting")
        return False

    # test timeout
    async def waiter_timeout():
        print("I'll wait right here")
        # timeout for test timeout
        await condition.wait()
        print("I'm done waiting")
        return False

    # test cancel
    async def waiter_cancel():
        waiter = condition.wait(timeout=time.time()+0.5)

# Generated at 2022-06-12 13:34:17.883787
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()
    async def wait():
        return await cond.wait()

    async def f1():
        flag1 = await wait()
        print('f1')
        return flag1

    async def f2():
        flag2 = await wait()
        print('f2')
        return flag2

    loop = ioloop.IOLoop.current()
    loop.run_sync(lambda: (gen.multi([f1(), f2()])))
    print('________________________')
    cond.notify_all()
    loop.run_sync(lambda: (gen.multi([f1(), f2()])))

if __name__ == '__main__':
    test_Condition_notify_all()



# Generated at 2022-06-12 13:34:24.557676
# Unit test for method wait of class Event
def test_Event_wait():
    # testing @timeout<=0, _value=False, _value=True
    event = Event()
    event._value = False
    event.clear()
    fut = event.wait(timeout = None)
    assert isinstance(fut, Future) is True
    fut2 = event.wait(timeout = 0)
    assert isinstance(fut2, Future) is True


    event._value = True
    fut3 = event.wait(timeout = None)
    assert isinstance(fut3, Future) is True
    fut4 = event.wait(timeout = 0)
    assert isinstance(fut4, Future) is True


    # testing @timeout>0, _value=False
    event._value = True
    event.clear()
    fut5 = event.wait(timeout = 0.5)

# Generated at 2022-06-12 13:35:24.215222
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    admask = 0o777
    # Iterate over all permission variations
    for permission in range(2**9):
        # Get permission values for user, group and other
        for i in range(3):
            if permission & (2**i):
                exec("u_rwx = 0o7%d00" % i)
                exec("g_rwx = 0o70%d0" % i)
                exec("o_rwx = 0o700%d" % i)
                # Set permission values for user, group and other
                admask = admask ^ u_rwx
                admask = admask ^ g_rwx
                admask = admask ^ o_rwx
                # Create Semaphore object
                obj = Semaphore()
                # Check the value of obj.__aenter__(), should be None
                assert obj

# Generated at 2022-06-12 13:35:35.845215
# Unit test for method notify of class Condition
def test_Condition_notify():
    from ..testing import AsyncTestCase
    from ..testing import bind_unused_port
    from ..web import RequestHandler, Application
    from ..httpclient import AsyncHTTPClient
    from tornado.ioloop import IOLoop
    from tornado.httpserver import HTTPServer
    from tornado.locks import Condition, Event, Lock
    import time
    import socket
    import tornado
    import threading
    
    
    server_condition = Condition()
    client_condition = Condition()


    class IndexHandler(RequestHandler):
        def initialize(self):
            print("server: initializing...")
        
        async def get(self):
            print("server: getting...")
            await server_condition.wait()
            print("server: done!")
            time.sleep(15)
            self.write("finished!")



# Generated at 2022-06-12 13:35:37.604226
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.wait()
    condition.notify()
    condition.notify_all()


# Generated at 2022-06-12 13:35:44.322244
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)
    return

# Generated at 2022-06-12 13:35:47.922309
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    def waiter():
        print("Waiting for event")
        print(event.wait())
        print("Not waiting this time")
        await event.wait()
        print("Done")
    waiter()

# Generated at 2022-06-12 13:35:54.002226
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(0)
    sem.release()
    
    try:
        sem.release()
        assert False, "Semaphore released too many times"
    except ValueError:
        pass
    try:
        assert False, "Semaphore released too many times"
    except ValueError:
        sem.release()
    try:
        assert False, "Semaphore released too many times"
    except ValueError:
        sem.release()
    



# Generated at 2022-06-12 13:36:04.316851
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    _value = 1
    ioloop = ioloop.IOLoop.current()
    def _use_some_resource():
        return Future()
    async def worker(worker_id):
        sem = Semaphore(_value)
        async with sem:
            print("Worker %d is working" % worker_id)
            await _use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    ioloop.run_sync(runner)
    assert None


# Generated at 2022-06-12 13:36:13.173269
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    @gen.coroutine
    def wait():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [wait(), notifier()]

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:36:14.751060
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-12 13:36:16.483070
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    s = Semaphore(2)
    assert (s._value == 2)
    s.release()
    assert (s._value == 3)


# Generated at 2022-06-12 13:38:10.940977
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()
    c.notify()


# Generated at 2022-06-12 13:38:20.110386
# Unit test for method wait of class Event
def test_Event_wait():
    import asyncio
    event = Event()
    @asyncio.coroutine
    def waiter():
        print("Waiting for event")
        yield from event.wait()
        assert isinstance(event.wait(), Future)
        assert isinstance(event.wait(10), Future)
        print("Not waiting this time")
        yield from event.wait()
        print("Done")

    @asyncio.coroutine
    def setter():
        print("About to set the event")
        event.set()

    @asyncio.coroutine
    def runner():
        yield from asyncio.gather(waiter(), setter())

    loop = asyncio.get_event_loop()
    loop.run_until_complete(runner())

test_Event_wait()



# Generated at 2022-06-12 13:38:28.685414
# Unit test for method wait of class Condition

# Generated at 2022-06-12 13:38:30.229557
# Unit test for method release of class Lock
def test_Lock_release():
    try:
        lock = Lock()
        lock.release()
    except RuntimeError:
        assert True
    else:
        assert False



# Generated at 2022-06-12 13:38:34.458549
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")


    waiter()
    notifier()
    return condition

# Generated at 2022-06-12 13:38:36.643385
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    s = Semaphore()
    with pytest.raises(RuntimeError):
        with s:
            pass

    s = Semaphore()
    with pytest.raises(RuntimeError):
        async with s:
            pass


# Generated at 2022-06-12 13:38:40.604584
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    import pytest
    from tornado.ioloop import IOLoop
    from tornado.locks import BoundedSemaphore

    sm = BoundedSemaphore()
    sm.release()  # should not raise ValueError

    sm = BoundedSemaphore()
    IOLoop.current().run_sync(sm.acquire)
    sm.release()

    sm = BoundedSemaphore()
    IOLoop.current().run_sync(sm.acquire)
    sm.release()
    IOLoop.current().run_sync(sm.acquire)
    sm.release()

    sm = BoundedSemaphore()
    IOLoop.current().run_sync(sm.acquire)
    sm.release()
    with pytest.raises(ValueError):
        sm.release()

# Generated at 2022-06-12 13:38:45.148159
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # Initialise an object lock of class Semaphore
    lock = Semaphore()
    # Check if the value is 0 when every method release is called.
    assert lock.release() == None
    assert lock.release() == None

# Generated at 2022-06-12 13:38:55.886290
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # test_release, 1
    async def test_release():
        sem = Semaphore(2)
        sem._value = 1
        waiter0 = Future()
        waiter1 = Future()
        self._waiters.append(waiter0)
        self._waiters.append(waiter1)
        sem.release()
        assert sem._value == 0

        # Unit test for method release of class Semaphore
    def test_Semaphore_release():
        # 1
        async def test_release():
            sem = Semaphore(2)
            sem._value = 1
            waiter0 = Future()
            waiter1 = Future()
            self._waiters.append(waiter0)
            self._waiters.append(waiter1)
            sem.release()
            assert sem._value == 0

# Generated at 2022-06-12 13:38:58.856326
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond = Condition()
    def func1():
        cond.notify()
        cond.notify(2)
        cond.notify_all()