

# Generated at 2022-06-12 13:31:01.147193
# Unit test for method wait of class Condition
def test_Condition_wait():
    Condition.wait


# Generated at 2022-06-12 13:31:03.440283
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore()
    assert sem._value == 1
    sem.release()
    assert sem._value == 2



# Generated at 2022-06-12 13:31:07.149872
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:31:12.937529
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()
    io_loop = IOLoop.current()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        await gen.multi([waiter(), notifier()])

    io_loop.run_sync(runner)


# Generated at 2022-06-12 13:31:14.501368
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore()
    # Wait for one second
    assert s.acquire(1)
    # Wait for half a second
    assert s.acquire(0.5)

# Generated at 2022-06-12 13:31:15.406048
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert lock.__aenter__() is None

# Generated at 2022-06-12 13:31:16.702416
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    s = Semaphore()
    assert s.__repr__() == "<_TimeoutGarbageCollector waiters[0]>"


# Generated at 2022-06-12 13:31:20.036296
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert c.__repr__() == '<Condition>'
    c._waiters = [Future()]
    assert c.__repr__() == '<Condition waiters[1]>'

# Generated at 2022-06-12 13:31:24.359014
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    """Test __aenter__ of Lock"""
    import tornado.locks
    lk = tornado.locks.Lock()
    async def f():
        try:
            async with lk:
                pass
        except Exception as e:
            raise e
    loop = tornado.ioloop.IOLoop.current()
    loop.run_sync(f)
    loop.run_sync(lk.release)
# Testing of method __aenter__ of class Lock

# Generated at 2022-06-12 13:31:31.006041
# Unit test for method wait of class Condition
def test_Condition_wait():
    # unit test for class Condition's method wait
    import asyncio
    from tornado.ioloop import IOLoop
    import time
    import threading

    async def async_wait(condition: Condition, timeout: Optional[Union[float, datetime.timedelta]] = None) -> bool:
        # print("start wait")
        f = condition.wait(timeout)
        # print("got wait future")
        t = await f
        # print("got future result")
        return t

    cond = Condition()
    print("start")
    t0 = time.time()
    print("start async")

    def cb(future):
        global t0
        print("got future", time.time() - t0)
    # async def async_test_wait():
    #     t = async_wait(cond, time.time() + 1

# Generated at 2022-06-12 13:31:40.342318
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    return Condition()

# Generated at 2022-06-12 13:31:41.447288
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    b = Condition()
    print(b.__repr__())

# Generated at 2022-06-12 13:31:42.018458
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    pass

# Generated at 2022-06-12 13:31:43.226265
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-12 13:31:49.606390
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
        return 'waiter'
    async def notifier():
        await ioloop.IOLoop.current().add_callback(condition.notify_all)
        return 'notifier'
    async def runner():
        cond = await gen.multi([waiter(), notifier()])
        return cond
    result = ioloop.IOLoop.current().run_sync(runner)
    assert result == ['notifier', 'waiter'], "method notify_all of class Condition failed"



# Generated at 2022-06-12 13:31:53.249803
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado.ioloop import IOLoop

    from tornado import gen
    from tornado.locks import Semaphore

    sem = Semaphore(1)


    async def worker():
        await sem.acquire()


    @gen.coroutine
    def runner():
        yield [worker() for _ in range(2)]
    IOLoop.current().run_sync(runner)

#Unit test for method acquire of class Semaphore

# Generated at 2022-06-12 13:32:00.724873
# Unit test for method wait of class Event
def test_Event_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    event = Event()

    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:32:04.365990
# Unit test for method notify of class Condition
def test_Condition_notify():
    #test = lock_test.test_Condition_notify(Condition(), len(Condition()._waiters))
    test = lock_test.test_Condition_notify(Condition(), 0)
    if(test):
        print("test_Condition_notify success")
    else:
        print("test_Condition_notify failure")


# Generated at 2022-06-12 13:32:13.452621
# Unit test for method wait of class Event
def test_Event_wait():
    # create a new instance
    event = Event()
    # set a flag
    event._value = True

    # Create a new future
    astest = Future()
    astest.set_result(None)
    # Add it to the waiters list
    event._waiters.add(astest)
    # Make sure the event is still set
    assert (event._value)
    # Make sure the event is still not waited
    assert (not event._waiters.get())

    # Create a new future
    astest2 = Future()
    # Add it to the waiters list
    event._waiters.add(astest2)
    # Make sure the event is still set
    assert (event._value)
    # Make sure the event is still not waited
    assert (not event._waiters.get())

    # Create a new future

# Generated at 2022-06-12 13:32:17.818076
# Unit test for method wait of class Event
def test_Event_wait():
    timeout_fut = Event().wait(timeout=datetime.timedelta(1))
    if timeout_fut is not None:
        isinstance(timeout_fut, Future)
        isinstance(timeout_fut, types.GeneratorType)



# Generated at 2022-06-12 13:32:30.259148
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == '<Condition>'
    c._waiters.append(Future())
    assert repr(c) == '<Condition waiters[1]>'


# Generated at 2022-06-12 13:32:33.455021
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    f = c.wait()
    assert (f.done() == False)
    c.notify_all()
    assert(f.done() == True)


# Generated at 2022-06-12 13:32:40.235545
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2, io_loop=IOLoop.current())
    sem.release()
    assert sem._value == 3

    sem = Semaphore(0, io_loop=IOLoop.current())
    waiter = Future()
    sem._waiters.append(waiter)
    sem.release()

    assert sem._value == 0
    assert len(sem._waiters) == 0
    assert waiter.result() == _ReleasingContextManager(sem)

# Generated at 2022-06-12 13:32:50.045219
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    import asyncio
    import random
    import time
    # This class is used just for counting how many time acquire is called
    class CountingSemaphore(Semaphore):
        def __init__(self, value: int = 1):
            super().__init__(value)
            self.count = 0
        def acquire(self, timeout: Optional[Union[float, datetime.timedelta]] = None):
            self.count += 1
            return super().acquire(timeout)
    # This function launches n_threads threads and each thread performs m_acquire times acquire
    def launch_threads(n_threads: int, m_acquires: int):
        loop = asyncio.get_event_loop()
        # Create semaphore
        semaphore = CountingSemaphore()
        # Create the coroutines


# Generated at 2022-06-12 13:32:56.770408
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    print('Test for method __aenter__ of class Semaphore')
    print('compare with Semaphore.acquire()')
    tasks = []
    async def worker(sem, id):
        print('worker %d: acquire semaphore' % id)
        await sem.acquire()
        print('worker %d: got it' % id)
        await asyncio.sleep(3)
        print('worker %d: release semaphore' % id)
        sem.release()
        print('worker %d: released' % id)
    async def runner(sem, id):
        print('runner %d: acquire semaphore' % id)
        async with sem:
            print('runner %d: got it' % id)
            await asyncio.sleep(3)

# Generated at 2022-06-12 13:33:05.051689
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    from tornado.testing import AsyncTestCase, gen_test

    condition = Condition()

    class Test(AsyncTestCase):
        @gen_test
        async def test_condition(self):
            future = condition.wait()
            await gen.sleep(0.1)
            condition.notify()
            await gen.sleep(0.1)
            self.assertTrue(future.result())
    Test().test_condition()



# Generated at 2022-06-12 13:33:07.351259
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.locks import Condition
    cond = Condition()
    assert repr(cond)=='<Condition>'



# Generated at 2022-06-12 13:33:18.092923
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import asyncio
    sem = Semaphore(1)
    # num=0
    async def release(num):
        await sem.acquire()
        #await asyncio.sleep(0.1) # if this is present, then it should work as expected
        num = num + 1
        sem.release()
    # num=2
    async def release_two(num):
        await sem.acquire()
        await sem.acquire()
        #await asyncio.sleep(0.1) # if this is present, then it should work as expected
        sem.release()
        num = num + 1
        await sem.release()
        num = num + 1
    loop = asyncio.get_event_loop()
    num = 0
    loop.create_task(release(num))

# Generated at 2022-06-12 13:33:22.294551
# Unit test for method set of class Event
def test_Event_set():
    #Create a mock object for the Event class.
    Event_mock = Event()
    #Make a call to the Event_mock object's set method.
    Event_mock.set()
    #If the Event_mock object's internal flag is True, the test case passes.
    assert Event_mock._value == True


# Generated at 2022-06-12 13:33:23.222854
# Unit test for method set of class Event
def test_Event_set():
    Event().set()

# Generated at 2022-06-12 13:33:33.625783
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()  # type: Event
    event.wait()



# Generated at 2022-06-12 13:33:39.983403
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:33:41.459408
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # __aenter__()
    # self.test_Lock___aenter__()
    pass


# Generated at 2022-06-12 13:33:43.607359
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore = Semaphore()
    if (semaphore._value == 0):
        semaphore.release()
        return True
    else:
        raise ValueError("semaphore initial value must be >= 0")
assert test_Semaphore_release()



# Generated at 2022-06-12 13:33:53.806349
# Unit test for method wait of class Condition
def test_Condition_wait():
    # output:
    # I'll wait right here
    # About to notify
    # Done notifying
    # I'm done waiting
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:33:58.521999
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:34:01.569999
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()


# Generated at 2022-06-12 13:34:08.882675
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:34:12.548135
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    print()
    # Create an instance of class Semaphore
    sem = Semaphore()
    # Call method __repr__ of class Semaphore
    print(sem.__repr__())

test_Semaphore___repr__()

# Generated at 2022-06-12 13:34:15.910538
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock=Lock()
    loop=ioloop.IOLoop.current()
    t=threading.Thread(target=loop.start)
    t.start()
    lock.__aenter__()
    assert lock._block._value == 0
    loop.stop()
    t.join()


# Generated at 2022-06-12 13:34:39.697389
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    #
    # 通过 Condition 实现等待和通知
    #
    condition = Condition()
    #
    # 等待唤醒
    #
    async def waiter():
        print("I'll wait right here")
        # 等待通知
        await condition.wait()
        print("I'm done waiting")
    #
    # 通知
    #
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    #
    # 开始等待唤醒并开

# Generated at 2022-06-12 13:34:42.775058
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    # Test whether the repr is correct
    test_semaphore = Semaphore()
    assert repr(test_semaphore) == "<Semaphore [unlocked,value:1]>"



# Generated at 2022-06-12 13:34:53.004949
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    sem = Semaphore(2)

    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            # await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:34:54.791792
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    obj = Semaphore(0)
    assert "<Semaphore [locked]>" == repr(obj)


# Generated at 2022-06-12 13:35:02.968564
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from unittest.mock import MagicMock
    from tornado import locks
    lock = locks.Lock()
    
    # __aenter__ being called
    def mock_acquire(a0: str="") -> str:
        return ""
    lock.acquire = mock_acquire
    
    try:
        lock.__aenter__()
    except Exception:
        assert True
    else:
        assert False
    
    try:
        lock.__aenter__(a0="a0")
    except Exception:
        assert True
    else:
        assert False

test_Lock___aenter__()

# Generated at 2022-06-12 13:35:06.494214
# Unit test for method wait of class Condition
def test_Condition_wait():
    async def worker(condition):
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    condition = Condition()
    ioloop.IOLoop.current().run_sync(worker, condition)

# Unit test main function

# Generated at 2022-06-12 13:35:13.474511
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore(2)
    print("Initial value of s is %s" % (s._value))
    results = [s.acquire(), s.acquire(), s.acquire()]
    print("Final value of s is %s" % (s._value))
    print("results is %s" % (results))
    print("Final value of s._waiters is %s" % (s._waiters))
test_Semaphore_acquire()



# Generated at 2022-06-12 13:35:20.730333
# Unit test for method notify of class Condition
def test_Condition_notify():
    import asyncio
    loop = asyncio.get_event_loop()
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await asyncio.gather(waiter(), notifier())
    loop.run_until_complete(runner())

# Generated at 2022-06-12 13:35:26.141981
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()




# Generated at 2022-06-12 13:35:27.806491
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Test of acquire method of class Semaphore
    loop = asyncio.get_event_loop()
    value = 1
    with Semaphore(value=value) as sem:
        if sem == None:
            assert sem == None




# Generated at 2022-06-12 13:36:07.987628
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from datetime import timedelta
    from tornado.ioloop import IOLoop
    # 1
    condition = Condition()
    assert str(condition) == "<Condition>"
    future = condition.wait(timeout=timedelta(seconds=1))
    future = condition.wait(timeout=timedelta(seconds=1))
    assert str(condition) == "<Condition waiters[2]>"

# Generated at 2022-06-12 13:36:11.018887
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"

    # _waiters
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-12 13:36:15.439795
# Unit test for method wait of class Event
def test_Event_wait():
    e1 = Event()
    print(e1)
    print(e1.is_set())
    
    @gen.coroutine
    def waiter():
        print("Waiting for event")
        yield e1.wait()
        print("Not waiting this time")
        yield e1.wait()
        print("Done")

    @gen.coroutine
    def setter():
        print("About to set the event")
        e1.set()

    @gen.coroutine
    def runner():
        yield [waiter(), setter()]

    ioloop.IOLoop.current().run_sync(runner)

# Generated at 2022-06-12 13:36:18.716025
# Unit test for method notify of class Condition
def test_Condition_notify():
    iol = ioloop.IOLoop.current()
    cond = Condition()
    assert len(cond._waiters) == 0
    assert cond.wait(timeout=iol.time() + 1) not in cond._waiters
    print(cond)
    cond.notify(n=3)
    print(cond)
    assert len(cond._waiters) == 0


# Generated at 2022-06-12 13:36:22.285491
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()



# Generated at 2022-06-12 13:36:25.001280
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.acquire = CoroutineMock(return_value=CoroutineMock(return_value=None))
    with pytest.raises(NotImplementedError):
        lock.__aenter__()



# Generated at 2022-06-12 13:36:29.618430
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    async def async_testing_coro():
        lock = locks.Lock()

        # __aenter__ returns None
        assert (await lock.__aenter__()) is None

        # In a with block:
        async with lock:
            assert (await lock.acquire()) is None



# Generated at 2022-06-12 13:36:40.616890
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # Tests for method release (self: Semaphore) -> None
    # Unit test for method release of class Semaphore
    from collections import deque

    from tornado.concurrent import Future

    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])

    sem = Semaphore(2)
    await sem.acquire()


    sem.release()

    await sem.acquire()


    sem.release()


    assert sem._value == 1

    sem = Semaphore(0)
    await sem.acquire()


    await sem.acquire()

    await sem.acquire()

    sem.release()

    assert sem._value == -1

    sem = Semaphore(2)
    await sem.acquire()




# Generated at 2022-06-12 13:36:44.293304
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
  assert repr(Semaphore()) == "<Semaphore unlocked,value:1>"
  assert repr(Semaphore(value=0)) == "<Semaphore locked>"
  assert repr(Semaphore(value=2, waiters={1})) == "<Semaphore unlocked,value:2,waiters:1>"


# Generated at 2022-06-12 13:36:52.656764
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)

test_Condition_wait()



# Generated at 2022-06-12 13:38:04.916388
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"



# Generated at 2022-06-12 13:38:06.214337
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    assert True



# Generated at 2022-06-12 13:38:08.833727
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    l = Lock()
    with pytest.raises(RuntimeError, match="Use `async with` instead of `with` for Lock"):
        l.__enter__()


# Generated at 2022-06-12 13:38:14.202817
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # 1. setup
    sem = Semaphore(2)
    waiter1 = Future()
    waiter2 = Future()
    waiter3 = Future()
    waiter1.set_result(_ReleasingContextManager(sem))
    waiter2.set_result(_ReleasingContextManager(sem))
    waiter3.set_result(_ReleasingContextManager(sem))
    sem._waiters.append(waiter1)
    sem._waiters.append(waiter2)
    sem._waiters.append(waiter3)
    # 2. execution
    sem.release()
    # 3. verification
    assert sem._value == 1
    assert len(sem._waiters) == 2


# Generated at 2022-06-12 13:38:18.366747
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:38:20.189984
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    assert lock.release() is None
    with pytest.raises(RuntimeError):
        lock.release()



# Generated at 2022-06-12 13:38:21.460461
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    wait = event.wait()



# Generated at 2022-06-12 13:38:28.047475
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    
    condition = Condition()

    # Wait for waiter() and notifier() in parallel
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    IOLoop.current().run_sync(lambda: gen.multi([waiter(), notifier()]))


# Generated at 2022-06-12 13:38:32.225392
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.concurrent import Future
    from tornado.locks import Semaphore
    from tornado.testing import AsyncTestCase, gen_test

    fut = Future()
    sem = Semaphore(1)
    sem.acquire = lambda: fut


    class MyTestCase(AsyncTestCase):
        @gen_test
        async def test_something(self):
            fut.set_result(None)
            await sem

    test = MyTestCase()
    test.test_something()


# Generated at 2022-06-12 13:38:39.341089
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    # define a waiter function
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    # define a notifier function
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    # define a runner function
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    print("running test_Condition_wait")
    IOLoop.current().run_sync(runner)

