

# Generated at 2022-06-12 13:31:03.245575
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado.locks import Lock
    lock = Lock()
    async with lock:
        pass

# Generated at 2022-06-12 13:31:04.249757
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    BoundedSemaphore(value=1).release()

# Generated at 2022-06-12 13:31:09.917606
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:31:12.102359
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    """
    This function tests the  acquire method of class Semaphore
    """
    sem_obj = Semaphore(5)
    assert sem_obj.acquire() == None

# Generated at 2022-06-12 13:31:17.766999
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado import ioloop
    from tornado.gen import coroutine, Return
    from tornado.locks import Semaphore
    # successful case
    try:
        loop = ioloop.IOLoop.current()
        async def async_test_Semaphore___aenter__():
            # __aenter__
            sem = Semaphore(value=0)
            # acquire
            await sem.acquire()
            # release
            sem.release()
            raise Return(sem)
        res = loop.run_sync(async_test_Semaphore___aenter__)
        assert res is not None, "__aenter__"
        assert isinstance(res, Semaphore), "__aenter__"
    except Exception as e:
        print("Error in test_Semaphore___aenter__: " + str(e))

# Generated at 2022-06-12 13:31:20.026145
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # from tornado.locks import Lock
    # lock = Lock()
    # result = lock.__aenter__()
    print(Lock.__aenter__.__doc__)
    assert True

# Generated at 2022-06-12 13:31:24.693513
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), waiter()])

    ioloop.IOLoop.current().run_sync(runner)
    condition.notify_all()



# Generated at 2022-06-12 13:31:25.817182
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore()
    print(s.acquire())


# Generated at 2022-06-12 13:31:36.685877
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore

    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        print("Worker %d is working" % worker_id)
        sem.release()
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)

    # output: Worker 0 is working
    #         Worker 0 is done
    #         Worker 1 is working
    #         Worker 1 is done
    #         Worker 2 is working
    #         Worker 2 is done


# Generated at 2022-06-12 13:31:37.968223
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    pass  # Don't want to run this


# Generated at 2022-06-12 13:31:51.690731
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    value = 1
    sem = BoundedSemaphore(value)
    sem._value = sem._initial_value
    try:
        sem.release()
    except ValueError:
        pass
    else:
        assert False, "not catch Exception"



# Generated at 2022-06-12 13:31:54.185632
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():

    def test_release():
        with pytest.raises(ValueError):
            s = BoundedSemaphore(0)
            s.release()
            s.release()
    test_release()

# Generated at 2022-06-12 13:31:59.126183
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from typing import Any, Callable, Optional, Union
    from typing import Type
    from types import TracebackType
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop
    from ..locks import Semaphore
    from ..concurrent import TracebackFuture
    from ..concurrent import future_set_result_unless_cancelled

    value = 0
    waiter = TracebackFuture()  # type: Future[None]
    waiter2 = TracebackFuture()  # type: Future[None]
    waiter3 = TracebackFuture()  # type: Future[None]
    sem = Semaphore(value)
    sem._value = 1
    sem._waiters = [waiter, waiter2, waiter3]
    result = sem.__aenter__()
    waiter.set_exception(RuntimeError("test"))
   

# Generated at 2022-06-12 13:32:05.871340
# Unit test for method wait of class Event
def test_Event_wait():
    import time
    import datetime
    event = Event()
    async def waiter():
        print("Waiting for event")
        end = time.time() + 2 # block for 2 seconds
        await event.wait()
        print(time.time() - end)
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop = ioloop.IOLoop.current()
    ioloop.run_sync(runner)


# Generated at 2022-06-12 13:32:08.482519
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    l = Lock()
    with pytest.raises(RuntimeError):
        l.__aenter__()


# Generated at 2022-06-12 13:32:10.586778
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    obj = Semaphore()
    mock_acquire = MagicMock()
    r = await obj.__aenter__(mock_acquire)
    assert r is None



# Generated at 2022-06-12 13:32:13.058417
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert not event.is_set()


# Generated at 2022-06-12 13:32:22.568697
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    """Unit test for method __aenter__ of class Semaphore"""
    print("Testing test_Semaphore___aenter__")
    sem = Semaphore(2)
    async def worker(worker_id):
        sem.__aenter__()
        try:
            print("Worker %d is working" % worker_id)
            # await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:32:23.638509
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert c.__repr__() == "<Condition>"



# Generated at 2022-06-12 13:32:27.672588
# Unit test for method wait of class Event
def test_Event_wait():
    # Declare an event variable
    event = Event()
    # Declare a boolean variable
    flag = False
    # For loop
    for i in range(3):
        if event.is_set()==False:
            # Wait until the event is set
            await event.wait()
        else:
            print('Missed the event the first time')
        # Set the event
        event.set()
        # Wait for 3 seconds
        await gen.sleep(3)
        # Cancel the event
        event.clear()
    # Exit the loop
    print("Done")


# Generated at 2022-06-12 13:32:48.019331
# Unit test for method notify of class Condition
def test_Condition_notify():
    import time
    def print_time(s):
        print("Task %s sleeps %s second" % (s, s))  
        time.sleep(int(s))  
        print("Task %s runs %s second" % (s, s))
    condition = Condition()
    print("Start")
    condition.notify()
    print("Finish")
    # process 1
    async def test():
        print("Start")
        await condition.wait()
        print("Finish")
        
    # process 2
    async def test2():
        print("Start")
        await condition.wait()
        print("Finish")
    # process 3
    async def test3():
        print("Start")
        await condition.wait()
        print("Finish")
        
    async def runner(test):
        test()
        process1 = test

# Generated at 2022-06-12 13:32:49.574983
# Unit test for method wait of class Condition
def test_Condition_wait():
    def f():
        pass
    condition = Condition()
    condition.wait(timeout=0)



# Generated at 2022-06-12 13:32:50.735096
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(0)
    sem.release()



# Generated at 2022-06-12 13:32:57.276093
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
	counter = 0
	def test_function(waiter, timeout):
		nonlocal counter
		if counter >= 5:
			return
		counter += 1
		if counter == 4:
			waiter.set_result(5)
		else:
			waiter.set_exception(Exception())

	def test_function_timeout():
		return

	lock = Semaphore()

	lock._value = 3
	lock._waiters = deque()
	lock._TimeoutGarbageCollector__garbage_collect = lambda : None
	lock._TimeoutGarbageCollector__on_timeout = test_function_timeout

# Generated at 2022-06-12 13:32:59.383288
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    value = 1
    semaphore = Semaphore(value)
    # __aenter__ returns None
    assert semaphore.__aenter__() is None
    # value of semaphore is 0
    assert semaphore._value == 0
    # number of waiters is 0
    assert len(semaphore._waiters) == 0


# Generated at 2022-06-12 13:33:03.184469
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    import sys
    condition = Condition()
    assert repr(condition) == "<Condition>"
    assert condition._waiters == collections.deque()
    assert 0 == condition._timeouts
    print(condition)

# Generated at 2022-06-12 13:33:10.237521
# Unit test for method notify of class Condition
def test_Condition_notify():
    import random
    import time
    import asyncio
    async def p1():
        global result
        while True:
            await asyncio.sleep(0.1)
            await lock.acquire()
            if random.randint(0,10)>=5:
                result+=0.1
                print('P1: ',result)
                cond.notify()
            lock.release()
            if result>=2.0:
                break
    async def p2():
        global result
        while True:
            await asyncio.sleep(0.1)
            await lock.acquire()
            if random.randint(0,10)>=5:
                result+=1.0
                print('P2: ',result)
                cond.notify()
            lock.release()

# Generated at 2022-06-12 13:33:13.403052
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    pass

# Generated at 2022-06-12 13:33:16.635950
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore = Semaphore()
    assert semaphore._value == 0
    semaphore.release()
    assert semaphore._value == 0
    semaphore.release()
    assert semaphore._value == 0


# Generated at 2022-06-12 13:33:17.956074
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
	condition = Condition()
	assert repr(condition) == "<Condition>"


# Generated at 2022-06-12 13:33:28.971041
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    global _value
    global _waiters
    try:
        Semaphore.release()
    except Exception as e:
        print(e)
        print('True')


# Generated at 2022-06-12 13:33:32.872649
# Unit test for method wait of class Event
def test_Event_wait():
    import asyncio
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_asyncio_future
    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    event = Event()
    test_loop = asyncio.get_event_loop()
    event.set()
    event.wait()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")
    test_loop.run_until_complete(to_asyncio_future(waiter()))
    event.clear()
    event.wait()

# Generated at 2022-06-12 13:33:35.243168
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    future=condition.wait()
    answer=condition.__repr__()
    print(answer)
test_Condition___repr__()



# Generated at 2022-06-12 13:33:40.121513
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")


# Generated at 2022-06-12 13:33:40.706134
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    pass


# Generated at 2022-06-12 13:33:44.420280
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    print("\n")
    logging.info("Testing method release of class BoundedSemaphore")
    sem = BoundedSemaphore(value=1)
    # release 1st time
    sem.release()
    assert sem._value == 2
    # release 2nd time
    sem.release()
    assert sem._value == 3
    # release again more than allowed times
    try:
        sem.release()
        assert False
    except ValueError as e:
        logging.info("ValueError: " + str(e))



# Generated at 2022-06-12 13:33:52.868018
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    tmp = Condition()
    a = threading.Thread(target=test_Condition_notify_all_thread, args=(tmp,))
    a.start()
    time.sleep(0.1)
    b = threading.Thread(target=test_Condition_notify_all_thread2, args=(tmp,))
    b.start()
    time.sleep(1)
    print("call notify all")
    tmp.notify_all()
    time.sleep(1)
    print("end of main")

# Generated at 2022-06-12 13:33:59.196764
# Unit test for method wait of class Condition

# Generated at 2022-06-12 13:34:00.070902
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == '<Condition>'

# Generated at 2022-06-12 13:34:03.138032
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():

    set_as_global(Semaphore, '__aenter__')
    set_as_global(Semaphore, 'release')

    f = Semaphore.__aenter__()

    Semaphore.release()

# Generated at 2022-06-12 13:34:18.639099
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:34:19.766640
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    event.set()


# Generated at 2022-06-12 13:34:30.822022
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():

    condition = Condition()

    result = []

    async def waiter():
        await condition.wait()
        result.append('I\'m done waiting')

    async def notifier():
        condition.notify()
        result.append('Done notifying')

    async def waiter2():
        await condition.wait()
        result.append('I\'m done waiting 2')

    async def notifier2():
        condition.notify_all()
        result.append('Done notifying 2')
    
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(lambda: gen.multi([waiter(), notifier(), waiter2(), notifier2()]))

    assert result[0] == 'I\'m done waiting'
    assert result[1] == 'Done notifying'

# Generated at 2022-06-12 13:34:32.271244
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # Currently, the unit test for release method of Semaphore is not written.
    # The following code is to show the usage of release.
    sem = Semaphore(2)
    

# Generated at 2022-06-12 13:34:35.649813
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.locks import Condition
    from tornado import gen

    c = Condition()
    assert repr(c) == '<Condition>'
    # Make a waiter to show up in the repr.
    c.wait()
    assert repr(c) == '<Condition waiters[1]>'
    # Avoid a memory leak by ending the wait.
    gen.moment


# Generated at 2022-06-12 13:34:47.367009
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    print(f'\nsemaphore.release()')
    sem.release()
    print(f'release: sem={sem}')
    sem.release()
    print(f'release: sem={sem}')
    sem.release()
    print(f'release: sem={sem}')
    sem.release()
    print(f'release: sem={sem}')
    if 1:
        async def waiter(worker_id):
            await sem.acquire()
            try:
                print(f'Worker {worker_id} is working')
                # await use_some_resource()
            finally:
                print(f'Worker {worker_id} is done')
                sem.release()

# Generated at 2022-06-12 13:34:51.337186
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    async def func():
        async with Semaphore(10) as sem:
            value = await sem.acquire()
            assert value is True
            assert sem._value == 10

    loop = ioloop.IOLoop.current()
    loop.run_sync(func)


# Generated at 2022-06-12 13:34:59.552552
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:35:09.118668
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    s = Semaphore(1)
    IOLoop.current().run_sync(lambda: s.__aenter__())
    t = IOLoop.current().time()
    IOLoop.current().run_sync(lambda: s.__aenter__())
    t2 = IOLoop.current().time()
    assert t2 - t >= 0.5
    IOLoop.current().run_sync(lambda: s.__aexit__(None, None, None))
    IOLoop.current().run_sync(lambda: s.__aexit__(None, None, None))



# Generated at 2022-06-12 13:35:14.188429
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado.locks import Semaphore
    async def hello():
        async with sem:
            print("hello")

    async def hi():
        for i in range(5):
            async with sem:
                print("hi")

    sem = Semaphore(2)
    tornado.ioloop.IOLoop.current().run_sync(hello)
    

# Generated at 2022-06-12 13:35:39.466681
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():

    # Test for method __aexit__( self )
    io_loop = IOLoop()
    io_loop.make_current()
    l = Lock()

    async def test():
        await l.acquire()
        try:
            await l.acquire()
            raise RuntimeError("__aexit__ didn't release the lock")
        except RuntimeError:
            pass
        finally:
            l.release()

    io_loop.run_sync(test)



# Generated at 2022-06-12 13:35:46.434632
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    test_value = []
    def acquire_test_coroutine(timeout: Optional[Union[float, datetime.timedelta]] = None) -> Awaitable[_ReleasingContextManager]:
        test_value.append(timeout)
        return _ReleasingContextManager(None)

    sem = Semaphore(2)
    sem.acquire = acquire_test_coroutine
    timeout_value = 'timeout_value'
    ret = sem.acquire(timeout_value)
    assert test_value[0] == timeout_value


# Generated at 2022-06-12 13:35:53.109849
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    @gen.coroutine
    def worker(worker_id):
        with (yield semaphore.acquire()):
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    semaphore = Semaphore(2)
    semaphore.acquire()

    return(semaphore.acquire())


# Generated at 2022-06-12 13:35:54.341030
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    # Release a Semaphore
    pass



# Generated at 2022-06-12 13:35:56.090510
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    manhole_ = Manhole()
    pass



# Generated at 2022-06-12 13:36:07.596543
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # this function tests __repr__ of class Condition
    c = Condition()
    # AssertionError: <Condition waiters[0]> != <Condition>
    assert c.__repr__() != "<Condition waiters[0]>"

    # AssertionError: <Condition waiters[0]> != <Condition waiters[1]>
    assert c.__repr__() != "<Condition waiters[1]>"

    # AssertionError: <Condition waiters[0]> != <Condition waiters[2]>
    assert c.__repr__() != "<Condition waiters[2]>"

    # AssertionError: <Condition waiters[0]> != <Condition waiters[3]>
    assert c.__repr__() != "<Condition waiters[3]>"

    # AssertionError: <Condition

# Generated at 2022-06-12 13:36:11.377462
# Unit test for method notify of class Condition
def test_Condition_notify():
    async def run():
        cv = Condition()
        res = await gen.multi([cv.wait(), cv.wait()])
        assert res == [True, True]

    ioloop.IOLoop.current().run_sync(run)


# Generated at 2022-06-12 13:36:17.023007
# Unit test for method notify of class Condition
def test_Condition_notify():
    import asyncio
    async def test():
        cond = Condition()
        print('A')
        await cond.wait()
        print('B')
    async def test2():
        cond = Condition()
        print('C')
        cond.notify()
        print('D')
    loop = asyncio.get_event_loop()
    loop.run_until_complete(asyncio.gather(test(),test2()))
# test_Condition_notify()


# Generated at 2022-06-12 13:36:20.080724
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    import time 
    def test(n):
        sem = Semaphore(n)
        for i in range(n):
            fut = sem.acquire()
            try:
                time.sleep(1)
                assert(i < n)
            finally:
                sem.release()
        print("test_Semaphore_acquire: finished")
    test(5)


# Generated at 2022-06-12 13:36:20.532684
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    pass

# Generated at 2022-06-12 13:36:42.316880
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()


# Generated at 2022-06-12 13:36:45.740962
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    with pytest.raises(ValueError) as excinfo:
        bounded_semaphore = BoundedSemaphore(value=2)
        bounded_semaphore.release()
        bounded_semaphore.release()
        bounded_semaphore.release()
    assert 'Semaphore released too many times' in str(excinfo.value)



# Generated at 2022-06-12 13:36:54.494216
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)
    assert True

# Generated at 2022-06-12 13:37:02.788269
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from collections import deque
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))


# Generated at 2022-06-12 13:37:05.221154
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # Initial value of BoundedSemaphore
    value = 1
    boundedSemaphore = BoundedSemaphore(value)
    workers = [Future(), Future(), Future()]
    # First time call release method
    boundedSemaphore.release()
    for worker in workers:
        boundedSemaphore.acquire()
        worker.set_result(None)
    # Second time call release method
    boundedSemaphore.release()



# Generated at 2022-06-12 13:37:07.650274
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    semaphore = Semaphore(value=1)
    res = semaphore.__repr__()
    assert res == "<tornado.locks.Semaphore [unlocked,value:1]>"


# Generated at 2022-06-12 13:37:16.188231
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    from tornado.locks import Condition
    from tornado.ioloop import IOLoop
    from tornado import gen

    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        flag = await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:37:19.643624
# Unit test for method notify of class Condition
def test_Condition_notify():
    def test_notify(condition: Condition, n: int):
        from tornado import gen
        from tornado.ioloop import IOLoop
        async def runner():
            # Wait for waiter() and notifier() in parallel
            await gen.multi([waiter(), notifier(n)])

        IOLoop.current().run_sync(runner)

    def waiter():
        print("I'll wait right here")
        waitresult= condition.wait()
        print("I'm done waiting")

    def notifier(n):
        print("About to notify %s", n)
        condition.notify(n)
        print("Done notifying")

    condition = Condition()
    test_notify(condition, 3)

# Generated at 2022-06-12 13:37:21.380652
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    """
    Semaphore.__aenter__
    """
    pass


# Generated at 2022-06-12 13:37:24.904195
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(5)
    sem.release()
    assert sem._value==6
    sem.release()
    assert sem._value==7
    try:
        sem.release()
    except Exception as e:
        assert type(e)==ValueError
