

# Generated at 2022-06-12 13:31:07.374165
# Unit test for method set of class Event
def test_Event_set():
    event = Event()

    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)

# Generated at 2022-06-12 13:31:09.232376
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event._value == True


# Generated at 2022-06-12 13:31:14.588757
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import asyncio

    try:
        from unittest import mock
    except ImportError:
        import mock

    @asyncio.coroutine
    def acquire_patched(a_self):
        a_self._waiters.pop()
        return

    with mock.patch.object(Semaphore, 'acquire', side_effect=acquire_patched) as mock_acquire:
        # ARRANGE #
        semaphore = Semaphore()

        # ACT & ASSERT #
        assert len(semaphore._waiters) == 0
        async with semaphore:
            assert len(semaphore._waiters) == 0
            mock_acquire.assert_called_once()


# Generated at 2022-06-12 13:31:23.738772
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import math
    import random
    import typing
    import itertools
    import functools
    import funcy as fy
    import pytest
    import datetime

    @gen.coroutine
    def wait(condition, timeout=None):
        r = yield condition.wait(timeout)
        raise gen.Return(r)

    def check_notify_all(condition, n, timeout=None):
        # type: (Condition, int, bool) -> None
        results = yield [wait(condition, timeout) for i in range(n)]
        assert results == [True] * n

    # Just for fun.
    def identity(x):
        return x

    def is_prime():
        n = 0
        while True:
            n += 1

# Generated at 2022-06-12 13:31:30.140411
# Unit test for method wait of class Event
def test_Event_wait():
    # Test the wait method of the class Event
    import time
    import tornado.ioloop
    import tornado.locks
    class Test_Event(object):
        def __init__(self):
            self.e = tornado.locks.Event()
            self.i = 0
        async def waiter(self):
            await self.e.wait()
            if self.i == 0:
                print("Waiting for event")
            if self.i == 1:
                print("Not waiting this time")
            if self.i == 2:
                print("Done")
        async def setter(self):
            print("About to set the event")
            self.e.set()
            self.i = self.i + 1
    test = Test_Event()
    loop = tornado.ioloop.IOLoop.current()

# Generated at 2022-06-12 13:31:39.406676
# Unit test for method wait of class Condition
def test_Condition_wait():
    import asyncio
    async def main():
        condition = Condition()
        # function waiter
        async def waiter():
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")

        # function notifier
        async def notifier():
            print("About to notify")
            condition.notify()
            print("Done notifying")

        # function runner
        async def runner():
            # Wait for waiter() and notifier() in parallel
            await gen.multi([waiter(), notifier()])
        await runner()
        # call
        await main()
        # output
        # I'll wait right here
        # About to notify
        # Done notifying
        # I'm done waiting
    # test
    asyncio.run(main())


# Generated at 2022-06-12 13:31:42.587560
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(0)
    fn = sem.release
    sem.release()
    assert sem._value == 1


# Generated at 2022-06-12 13:31:50.426740
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():

    class Semaphore():
        '''
        Simulate the Semaphore class in tornado.locks
        '''
        def __init__(self, n_res):
            self._n_res = n_res
            self._T = []
            self._N = 0

        def acquire(self, timeout = None):
            if self._n_res > 0:
                self._n_res -= 1
                return True
            else:
                if timeout is not None:
                    if self.checkTimeout(timeout):
                        return False
                # Insert
                self._T.append(timeout)
                self._N += 1
                return True

        def release(self):
            # pop and return the first timeout
            if self._N == 0:
                self._n_res += 1
                return None

# Generated at 2022-06-12 13:31:55.132589
# Unit test for method notify of class Condition
def test_Condition_notify():
    c=Condition()
    c.notify()
    c.notify(2)
    c.notify(3)
    c.notify(4)
    c.notify(5)
    c.notify(6)
    c.notify(7)
    c.notify(8)
    c.notify(9)
    c.notify(10)



# Generated at 2022-06-12 13:31:56.998221
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():

    # Setup
    condition = Condition()


    # Verify
    return condition.__repr__()
    # Verify


# Generated at 2022-06-12 13:32:14.410794
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)
    
    

# Generated at 2022-06-12 13:32:20.351256
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Condition
    condition = Condition()

    # str
    condition___repr__ = condition.__repr__()

    # Variable _condition___repr__ of type str
    _condition___repr__ = "Condition"

    try:
        assert condition___repr__ == _condition___repr__
    except AssertionError:
        raise AssertionError(condition___repr__)


# Generated at 2022-06-12 13:32:25.833126
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:32:32.844681
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify(1)
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop = ioloop.IOLoop.current()
    ioloop.run_sync(runner)

# Generated at 2022-06-12 13:32:34.319623
# Unit test for method set of class Event
def test_Event_set():
    e = Event()
    e.set()


# Generated at 2022-06-12 13:32:38.796391
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # create a lock instance
    sem = Semaphore(5)
    # assert that value of lock is equal to 5
    assert sem._value == 5
    # release the lock
    sem.release()
    # assert that value of lock is equal to 6
    assert sem._value == 6


# Generated at 2022-06-12 13:32:41.206740
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())



# Generated at 2022-06-12 13:32:45.781167
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    with pytest.raises(RuntimeError) as err:
        sem.__enter__()
    assert err.value.args[0] == "Use 'async with' instead of 'with' for Semaphore"
    assert sem.__aenter__() == coroutine



# Generated at 2022-06-12 13:32:53.779617
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()

    l = [] #[[False for _ in range(10)] for _ in range(10)]
    async def waiter(i):
        print("waiter" + str(i) + " I'll wait right here")
        await condition.wait()
        print("waiter" + str(i) + " I'm done waiting")
        l[i][0] = True
    async def notifier(i):
        print("notifier" + str(i) + " About to notify")
        condition.notify()
        print("notifier" + str(i) + " Done notifying")
        l[i][1] = True
    async def runner(i):
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(i), notifier(i)])

# Generated at 2022-06-12 13:32:56.905093
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Function Condition.__repr__ must return an instance of str.
    ret = Condition().__repr__()
    assert isinstance(ret, str)


# Generated at 2022-06-12 13:33:06.909236
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # value = int(input())
    timeout = 1
    sem = Semaphore(2)
    print(sem.acquire(timeout))
    print(sem.release())


# Generated at 2022-06-12 13:33:17.498201
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # self = Semaphore(value = 1)
    waiter = Future()
    # == [waiter]
    # == self._waiters = deque([waiter])
    # == self._value = 0
    # == self._value = 1
    if self._value > 0:
        self._value -= 1
        waiter.set_result(_ReleasingContextManager(self))
    else:
        self._waiters.append(waiter)
        if timeout:

            def on_timeout() -> None:
                if not waiter.done():
                    waiter.set_exception(gen.TimeoutError())
                self._garbage_collect()

            io_loop = ioloop.IOLoop.current()
            timeout_handle = io_loop.add_timeout(timeout, on_timeout)

# Generated at 2022-06-12 13:33:26.218116
# Unit test for method wait of class Condition
def test_Condition_wait():
    pass
    # condition = Condition()
    # async def waiter():
    #     print("I'll wait right here")
    #     await condition.wait()
    #     print("I'm done waiting")
    #
    # async def notifier():
    #     print("About to notify")
    #     condition.notify()
    #     print("Done notifying")
    #
    # async def runner():
    #     await gen.multi([waiter(), notifier()])
    #
    # ioloop.IOLoop.current().run_sync(runner)
    # #
    # # I'll wait right here
    # # About to notify
    # # Done notifying
    # # I'm done waiting



# Generated at 2022-06-12 13:33:33.445966
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    ioloop.IOLoop.current().run_sync(runner)
    

# Generated at 2022-06-12 13:33:35.216025
# Unit test for method notify of class Condition
def test_Condition_notify():
    print("notify")
    cond = Condition()
    cond.notify(2)
    cond.wait()
    cond.wait()


# Generated at 2022-06-12 13:33:44.588075
# Unit test for method __repr__ of class Condition

# Generated at 2022-06-12 13:33:47.735521
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition.wait()
    assert repr(condition) == "<Condition waiters[1]>"

# Generated at 2022-06-12 13:33:55.746761
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:33:59.962197
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    # Lock.__aexit__(self, type, value, tb)
    # test for method __aexit__
    return True



# Generated at 2022-06-12 13:34:09.094000
# Unit test for method notify of class Condition
def test_Condition_notify():
    # coroutine - test pattern for notify function of class Condition
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")
    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]
    IOLoop.current().run_sync(runner)

# Test - notify function of Condition
test_Condition_notify()




# Generated at 2022-06-12 13:34:20.332092
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"

    # If there are waiters, __repr__ includes the number of waiters
    c.wait()
    assert repr(c) == "<Condition waiters[1]>"

    # ... but not after they've been notified
    c.notify()
    assert repr(c) == "<Condition>"



# Generated at 2022-06-12 13:34:23.435667
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    import asyncio
    from tornado.locks import Semaphore

    loop = asyncio.get_event_loop()
    sem = Semaphore(1)
    loop.run_until_complete(sem.__aexit__(None, None, None))
    sem.release()
    loop.close()

# Generated at 2022-06-12 13:34:25.801114
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # test code
    Semaphore.release();
    assert True

# Generated at 2022-06-12 13:34:29.061973
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    async def main():
        lock = Lock()
        await lock
        print(repr(lock))
    ioloop.IOLoop.current().run_sync(main)


# Generated at 2022-06-12 13:34:30.611225
# Unit test for method set of class Event
def test_Event_set():
    x = Event()
    x.set()
    assert x.is_set()
    

# Generated at 2022-06-12 13:34:33.709635
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    expected = "<Condition>"
    actual = repr(condition)
    assert actual == expected, "Actual: %s; Expected: %s" % (actual, expected)
# Test with no waiters registered.

# Generated at 2022-06-12 13:34:36.479558
# Unit test for method set of class Event
def test_Event_set():
    import asyncio
    async def f():
        event.set()
    event = Event()
    asyncio.run(f())
    assert event.is_set() == True


# Generated at 2022-06-12 13:34:48.278738
# Unit test for method wait of class Condition
def test_Condition_wait():
    '''
    # test 1
    await gen.multi([waiter(), notifier()])
    I'll wait right here
    About to notify
    Done notifying
    I'm done waiting
    # test 2
    await gen.multi([waiter()])
    I'll wait right here
    # test3
    await gen.multi([waiter(), notifier()])
    I'll wait right here
    '''
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")


# Generated at 2022-06-12 13:34:52.849803
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    # Init __aexit__
    try:
        lock = Lock()
    except Exception as e:
        raise e
    flag = False
    try:
        lock.release()
        flag = True
    except Exception:
        flag = True
    assert flag
    lock.__aexit__(None, None, None)
    assert True
    lock.__del__()
    assert True

# Generated at 2022-06-12 13:34:55.490271
# Unit test for method set of class Event
def test_Event_set():
    event1 = Event()
    print(event1.is_set()) # False
    event1.set()
    print(event1.is_set()) # True

# Generated at 2022-06-12 13:35:12.032344
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    pass

# Generated at 2022-06-12 13:35:21.646750
# Unit test for method notify of class Condition
def test_Condition_notify():
    """
    Test method notify of class Condition.
    """

    class MyFuture(Future):
        """
        Future class
        """
        def __init__(self, value, result):
            super().__init__()
            self.value = value
            self.result = result

        def result(self):
            return self.result

        def input_value(self, value):
            self.value = value

    cond = Condition()
    future_1 = MyFuture(1, True)
    future_2 = MyFuture(2, False)
    cond._waiters.append(future_1)
    cond._waiters.append(future_2)

    assert len(cond._waiters) == 2

    cond.notify(1)
    assert future_1.result() == True
    assert future_2.result() == False

# Generated at 2022-06-12 13:35:26.088685
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
	condition = Condition()

	print('condition', condition)
	print('condition.__repr__()', condition.__repr__())
	condition_repr_result = condition.__repr__()
	assert condition_repr_result == '<Condition>'


# Generated at 2022-06-12 13:35:30.937225
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from functools import partial
    from collections import namedtuple
    import pytest
    from .locks import Semaphore

    TestCase = namedtuple("TestCase", "sem_value timeout")
    TESTCASES = [
        TestCase(sem_value=1, timeout=None),
        TestCase(sem_value=0, timeout=None),
        TestCase(sem_value=1, timeout=1),
        TestCase(sem_value=0, timeout=1)
    ]

    @pytest.mark.parametrize("testcase", TESTCASES)
    def test_acquire(testcase: TestCase, ioloop: IOLoop):
        sem = Semaphore(testcase.sem_value)
        assert sem._value == testcase.sem_value


# Generated at 2022-06-12 13:35:38.935293
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    str_condition = str(condition)
    print('{}'.format(type(condition)))
    print(type(condition).__module__)
    print('{}'.format(condition.__class__.__name__))
    print('{}'.format(condition.__doc__))
    print('{}'.format(condition.__module__))
    print('{}'.format(condition.__dict__))
    print('{}'.format(str_condition))
    print('{}'.format(condition))
    print(dir(condition))

# Generated at 2022-06-12 13:35:45.602074
# Unit test for method wait of class Condition
def test_Condition_wait():
    '''
    async def waiter():
        print("I'll wait right here")
        await c.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        c.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    c = Condition()
    loop.run_sync(runner)
    '''


# Generated at 2022-06-12 13:35:48.009969
# Unit test for method wait of class Condition
def test_Condition_wait():
    Condition().wait("timeout=None")
    Condition().wait("timeout=Optional[Union[float, datetime.timedelta]]")


# Generated at 2022-06-12 13:35:53.398313
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()

    async def inner():
        await c.wait()
        print('notified')

    async def outer():
        await gen.sleep(0.001)
        # Should wake up the waiter.
        c.notify(1)
        assert await c.wait() == False, "wait after notify should return False"

    ioloop.IOLoop.current().run_sync(outer)



# Generated at 2022-06-12 13:36:04.819143
# Unit test for method wait of class Event
def test_Event_wait():
    from tornado.ioloop import IOLoop
    import time


    def test_Event(e):
        async def _test_Event():
            nonlocal e
            print("Waiting for event")
            await e.wait()
            print("Not waiting this time")
            await e.wait()
            print("Done")

        return _test_Event


    def test_set_Event(e):
        async def _test_set_Event():
            nonlocal e
            print("About to set the event")
            e.set()

        return _test_set_Event


    def main(e):
        async def _main():
            from tornado.gen import multi
            await multi([test_Event(e)(), test_set_Event(e)()])

        return _main



# Generated at 2022-06-12 13:36:07.841638
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    token = lock.__aexit__(Exception, Exception(), None)
    assert token is None, 'Token equals to ' + str(token)

# Generated at 2022-06-12 13:36:28.089360
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(2)
    sem.release()
    sem.release()
    try:
        sem.release()
    except ValueError as e:
        print(e)


# Generated at 2022-06-12 13:36:37.403964
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    import threading
    condition = threading.Condition()
    print(condition.__repr__())
    # <Condition(<unlocked _Condition(<locked _Condition([], False)>), 0>)>
    with condition:
        print(condition.__repr__())
        # <Condition(<locked _Condition([], False)>, 0)>
        condition.notify()
        print(condition.__repr__())
        # <Condition(<locked _Condition([], True)>, 1)>
        print(condition.__repr__())
        # <Condition(<locked _Condition([], True)>, 1)>


# Generated at 2022-06-12 13:36:45.652272
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    # no waiters to block
    event._value = True
    fut = event.wait()
    # Waiter was not blocked and made a Future
    assert(isinstance(fut, Future))
    # Waiting completed, the Future must be done.
    assert(fut.done())
    # Now the value of the event is reset and there will be one waiting future.
    event.clear()
    fut = event.wait()
    event.set()
    # Now the event was set and the waiting Future was unblocked
    assert(fut.done())
    # Set up a case where the caller is to be blocked
    event.clear()
    io_loop = ioloop.IOLoop.current()

# Generated at 2022-06-12 13:36:50.346245
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    async def f():
        await lock.acquire()
        result = lock.locked()
        lock.release()
        return(result)
    result = ioloop.IOLoop.current().run_sync(f)
    assert result == True

# Generated at 2022-06-12 13:36:50.979672
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    pass

# Generated at 2022-06-12 13:36:59.122962
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:37:02.138201
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # __repr__ of class Condition
    condition = Condition()
    result = condition.__repr__()
    assert result is not None
    assert isinstance(result, str)
    print(result)


# Generated at 2022-06-12 13:37:03.727363
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(1)

    assert sem.__aenter__() == None


# Generated at 2022-06-12 13:37:05.349715
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    print(repr(Semaphore()))
    print(repr(Semaphore(2)))


# Generated at 2022-06-12 13:37:08.987322
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    waiters = [condition.wait()]
    for _ in range(4):
        waiters.append(condition.wait())
    # Notify all waiters
    condition.notify_all()
    for waiter in waiters:
        assert waiter.result()


# Generated at 2022-06-12 13:37:45.941713
# Unit test for method notify of class Condition
def test_Condition_notify():
    # Implementation of testcase 1
    condition = Condition()
    print("condition.notify()")
    condition.notify()
    print("condition.notify(2)")
    condition.notify(2)
    
test_Condition_notify()

Event = Condition



# Generated at 2022-06-12 13:37:49.545395
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    """
    This test is for method acquire of class Semaphore
    """
    sem = Semaphore(1)
    sem.__repr__()
    sem.acquire()
    sem.__repr__()


# Generated at 2022-06-12 13:37:55.348606
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    f1 = condition.wait()
    f2 = condition.wait()
    f3 = condition.wait()
    condition.notify_all()
    assert f1.result() == True, 'f1 is not true'
    assert f2.result() == True, 'f2 is not true'
    assert f3.result() == True, 'f3 is not true'


# Generated at 2022-06-12 13:37:59.718739
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(1)
    sem.release()
    assert sem._value == 2
    assert sem._waiters == []
    sem._value = 0
    waiter = Semaphore(1)
    sem._waiters.append(waiter)
    sem.release()
    assert sem._value == 0
    assert sem._waiters == []


# Generated at 2022-06-12 13:38:05.300013
# Unit test for method notify of class Condition
def test_Condition_notify():
    """
    Verify the notify function of class Condition
    """
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    def timer_callback(condition):
        try:
            condition.notify(5)
        except Exception:
            print("Exception occured while notifying the condition")
        return
    aCondition = Condition()
    @gen.coroutine
    def waiter(i):
        print("%d waits right here" % i)
        if i == 5:
            IOLoop.current().add_callback(timer_callback, aCondition)
        res = yield aCondition.wait()
        print("%d I'm done waiting %s" % (i, res))
    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield

# Generated at 2022-06-12 13:38:07.310008
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore()
    obj = sem.__aenter__()
    assert isinstance(obj, None)



# Generated at 2022-06-12 13:38:10.207974
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import pytest
    async def test_function():
        sem = Semaphore(2)
        sem.release()
        assert sem._value == 3
    pytest.run_asyncio_test(test_function())

# Generated at 2022-06-12 13:38:17.210839
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    async def test():
        l = Lock()

    IOLoop.current().run_sync(test)


__all__ = [
    "Condition",
    "Event",
    "Future",
    "Lock",
    "Queue",
    "RLock",
    "Semaphore",
    "_ReleasingContextManager",
    "BoundedSemaphore",
    "as_future",
    "chain_future",
    "FutureError",
    "FutureTimeoutError",
    "TracebackFuture",
    "wrap_future",
    "with_timeout",
]

# Generated at 2022-06-12 13:38:26.189048
# Unit test for method wait of class Event
def test_Event_wait():
    assert not issubclass(Event, _TimeoutGarbageCollector)
    from time import time as time_now
    from time import sleep as time_sleep
    from types import FunctionType
    from datetime import timedelta as timedelta
    from tornado import gen
    from tornado.locks import Event
    event = Event()
    assert isinstance(event, Event)
    assert len(event.__dict__) == 3
    assert not event.is_set()
    assert isinstance(event.__repr__(), str)
    assert isinstance(event.is_set, types.MethodType)
    assert isinstance(event.set, types.MethodType)
    assert isinstance(event.clear, types.MethodType)
    assert isinstance(event.wait, FunctionType)
    assert event._value == False

# Generated at 2022-06-12 13:38:27.047725
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    assert repr(Condition()) == "<Condition>"

# Generated at 2022-06-12 13:39:46.275480
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False

    event.set()
    assert event.is_set() == True

    event.clear()
    assert event.is_set() == False


# Generated at 2022-06-12 13:39:51.738469
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    lock = Semaphore(0)
    if lock._value != 0:
        print('Semaphore.release() fail.')
        return 1
    lock.release()
    if lock._value != 1:
        print('Semaphore.release() fail.')
        return 1
    print('Semaphore.release() success.')
    return 0

# Generated at 2022-06-12 13:39:53.883016
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    cm = Semaphore(2)
    print(cm)
    with (await cm.acquire()):
        cm.release()


# Generated at 2022-06-12 13:39:59.367963
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)
test_Condition_wait()


# Generated at 2022-06-12 13:40:06.637380
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    @gen.coroutine
    def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")
    
    @gen.coroutine
    def setter():
        print("About to set the event")
        event.set()

    @gen.coroutine
    def runner():
        yield [waiter(), setter()]

    ioloop.IOLoop.current().run_sync(runner)

test_Event_wait()



# Generated at 2022-06-12 13:40:12.935538
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    s = BoundedSemaphore(value = 1)
    assert s._value == 1
    assert s._initial_value == 1
    assert s._waiters == deque()
    s.release()
    assert s._value == 2
    s.release()
    assert s._value == 3
    s.release()
    s.release()
    s.release()
    s.release()
    assert s._value == 8
    with pytest.raises(ValueError):
        s.release()

# Generated at 2022-06-12 13:40:14.121893
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    obj = Condition()
    return repr(obj)

# Generated at 2022-06-12 13:40:16.258479
# Unit test for method wait of class Event
def test_Event_wait():
    e = Event()
    assert e.is_set() == False
    IOLoop.current().call_later(0.001, e.set)
    return e.wait()


# Generated at 2022-06-12 13:40:20.360495
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    waiter = Future()
    waiter.add_done_callback(lambda _: print("I'm done waiting"))
    condition._waiters = collections.deque([waiter])
    condition.notify_all()



# Generated at 2022-06-12 13:40:21.754152
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    value = 1
    semaphore = Semaphore(value)
    assert(semaphore._value == value)

