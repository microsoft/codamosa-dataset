

# Generated at 2022-06-12 13:31:17.584678
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.acquire()
    assert lock._block is not None



# Generated at 2022-06-12 13:31:19.785588
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.locks import Condition
    condition = Condition()
    print(condition.__repr__())

# Generated at 2022-06-12 13:31:24.049857
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import BoundedSemaphore

    @gen.coroutine
    def test():
        sem = BoundedSemaphore(1)
        sem.release()
        sem.release()
    try:
        IOLoop.current().run_sync(test)
    except ValueError as e:
        print(e)
    # Semaphore released too many times


# Generated at 2022-06-12 13:31:30.416866
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from collections import deque
    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))

    def use_some_resource():
        return futures_q.popleft()

    sem = Semaphore(2)

    async def worker(worker_id):
        await sem.acquire()

# Generated at 2022-06-12 13:31:33.036375
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore()
    async def run():
        async with sem:
            pass
    ioloop.IOLoop.current().run_sync(run)


# Generated at 2022-06-12 13:31:34.968718
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert c.__repr__() == "<Condition>"


# Generated at 2022-06-12 13:31:42.217436
# Unit test for method wait of class Condition
def test_Condition_wait():
    import asyncio
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
        await asyncio.sleep(0.001)

    async def notifier():
        await asyncio.sleep(0.001)
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    condition = Condition()
    loop = asyncio.get_event_loop()
    loop.run_until_complete(runner())
    loop.close()


# Generated at 2022-06-12 13:31:43.434709
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    print("test_Event_set OK")


# Generated at 2022-06-12 13:31:44.774992
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    r = "<Condition waiters[0]>"
    assert r == condition.__repr__()


# Generated at 2022-06-12 13:31:45.555389
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    print("repr(cond):", repr(cond))



# Generated at 2022-06-12 13:32:00.081655
# Unit test for method set of class Event
def test_Event_set():
    assert Event().set() == None


# Generated at 2022-06-12 13:32:00.853793
# Unit test for method wait of class Event
def test_Event_wait():
    Event()
    return


# Generated at 2022-06-12 13:32:07.524614
# Unit test for method wait of class Event
def test_Event_wait():
    # type: () -> None
    import pytest
    from tornado import gen

    event = Event()

    @gen.coroutine
    def waiter():
        # type: () -> Future
        print("Waiting for event")
        yield event.wait()
        print("Not waiting this time")
        yield event.wait()
        print("Done")

    @gen.coroutine
    def setter():
        # type: () -> Future
        print("About to set the event")
        event.set()

    io_loop = ioloop.IOLoop.current()

    io_loop.run_sync(
        gen.multi([waiter(), setter()]),
        timeout=0.01,
    )



# Generated at 2022-06-12 13:32:13.921508
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:32:22.779342
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore

    def __aenter__(semaphore):
        # type: (Semaphore) -> Awaitable[None]
        return semaphore.acquire()
    try:
        from unittest import mock
    except ImportError:
        import mock

    with mock.patch.object(
        Semaphore, "acquire", autospec=True
    ) as acquire_mock:
        type(Semaphore()).__aenter__ = __aenter__
        with Semaphore() as result:
            assert result == acquire_mock.return_value
            assert acquire_mock.call_count == 1



# Generated at 2022-06-12 13:32:23.882663
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore = Semaphore()
    semaphore.acquire()


# Generated at 2022-06-12 13:32:28.586563
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # Test case 1
    sem = Semaphore(2)
    assert sem._value == 2

    # Test case 2
    sem.release()
    assert sem._value == 3

    # Test case 3
    sem._waiters = deque([1,2])
    sem._value += 1
    sem.release()
    assert sem._value == 4

    # Test case 4
    sem._value = 5
    sem._waiters = deque([1,2])
    sem.release()
    assert sem._value == 5


# Generated at 2022-06-12 13:32:36.822364
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    if value < 0:
        raise ValueError("semaphore initial value must be >= 0")

    self._value += 1
    while self._waiters:
            waiter = self._waiters.popleft()
            self._value -= 1

            # If the waiter is a coroutine paused at
            #
            #     with (yield semaphore.acquire()):
            #
            # then the context manager's __exit__ calls release() at the end
            # of the "with" block.
            waiter.set_result(_ReleasingContextManager(self))
            break
    return

# Generated at 2022-06-12 13:32:42.008767
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado.gen import sleep
    sem = Semaphore(value=1)
    async def test():
        for i in range(2):
            async with sem:
                print(sem)
                await sleep(1)
    IOLoop.current().run_sync(test)

# Generated at 2022-06-12 13:32:43.651673
# Unit test for method wait of class Condition
def test_Condition_wait():
    Condition().wait()


# Generated at 2022-06-12 13:33:05.698025
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()

    @gen.coroutine
    def waiter():
        print("Waiting for event")
        yield event.wait()
        print("Not waiting this time")
        yield event.wait()
        print("Done")

    @gen.coroutine
    def setter():
        print("About to set the event")
        event.set()

    @gen.coroutine
    def runner():
        yield gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:33:07.584495
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    result = condition.__repr__()
    assert result == "<Condition waiters[0]>"


# Generated at 2022-06-12 13:33:09.345137
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    res = condition.__repr__()
    print(res)



# Generated at 2022-06-12 13:33:17.365433
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)

# test_Condition_wait()



# Generated at 2022-06-12 13:33:26.129023
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    logger.info("test_Semaphore_acquire")
    sem = Semaphore(value = 1)
    waiter = sem.acquire()
    waiter = asyncio.ensure_future(waiter)
    # waiter = asyncio.async(waiter, loop = ioloop.IOLoop.current())
    ioloop.IOLoop.current().call_later(.1, sem.release)
    ioloop.IOLoop.current().run_sync(waiter)
    logger.info("end of test_Semaphore_acquire")

if __name__ == "__main__":
    logging.basicConfig(level = logging.INFO)
    test_Semaphore_acquire()

# Generated at 2022-06-12 13:33:30.909072
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test with default arguments
    condition = Condition()
    # Test with optional arguments
    condition = Condition()
    # Test with unnamed arguments
    condition = Condition()
    # Test with positional arguments
    condition = Condition()
    # Test with combination of named and unnamed arguments
    condition = Condition()

# Generated at 2022-06-12 13:33:38.520788
# Unit test for method wait of class Condition
def test_Condition_wait():
    print('\n\n### Unit test for method wait of class Condition')
    import asyncio
    async def waiter(condition):
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier(condition):
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner(condition):
        # Wait for waiter() and notifier() in parallel
        await asyncio.gather(waiter(condition),notifier(condition))
    condition = Condition()
    asyncio.run(runner(condition))
    
    
    
    
    
    

# Generated at 2022-06-12 13:33:42.451775
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore()
    assert sem.acquire.__name__ == "acquire"
    assert sem.release.__name__ == "release"
    assert isinstance(sem, Semaphore)
    assert sem._value == 1
    assert sem.__class__.__name__ == "Semaphore"
    async def waiter():
        await sem.acquire()
        try:
            assert True
        finally:
            sem.release()
    async def setter():
        assert sem._value == 1
    async def runner():
        await gen.multi([waiter(), setter()])
    IOLoop.current().run_sync(runner)
    assert sem._value == 1



# Generated at 2022-06-12 13:33:44.419260
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    _value = 1
    _waiters = []
    ret_value = None
    s = Semaphore(_value)
    await s.acquire()
    return (s, _value, _waiters, ret_value)



# Generated at 2022-06-12 13:33:54.182049
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    import time 
    condition = Condition()
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")
    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])
    IOLoop.current().run_sync(runner)

# Generated at 2022-06-12 13:34:34.714201
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    for i in range(1,4):
        if event.is_set():
            print('Event.set: True')
            print('Event.value before cleared:',event.is_set())
            event.clear()
            print('Event.value after cleared:',event.is_set())
        else:
            print('Event.set: False')
            print('Event.value before set:',event.is_set())
            event.set()
            print('Event.value after set:',event.is_set())

# Generated at 2022-06-12 13:34:46.567805
# Unit test for method wait of class Condition
def test_Condition_wait():
    def test_Condition_wait1_line_3():
        """Test the print statement of line 3."""
        condition = Condition()
        print("I'll wait right here")
    def test_Condition_wait1_line_4():
        """Test the print statement of line 4."""
        condition = Condition()
        print("I'm done waiting")

    def test_Condition_wait2_line_3():
        """Test the print statement of line 3."""
        condition = Condition()
        print("I'll wait right here")

    def test_Condition_wait2_line_4():
        """Test the print statement of line 4."""
        condition = Condition()
        print("I'm done waiting")

    def test_Condition_wait3_line_3():
        """Test the print statement of line 3."""
        condition = Condition()
       

# Generated at 2022-06-12 13:34:48.370349
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    with pytest.raises(RuntimeError):
        Semaphore().__aenter__()


# Generated at 2022-06-12 13:34:50.894218
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()
    with cond:
        cond.notify_all()
        cond.notify()
        cond.notify(9)


# Generated at 2022-06-12 13:34:59.772026
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    
    # Test wait
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")
    
    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    
    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])
    
    # Run
    ioloop.IOLoop.current().run_sync(runner)
test_Condition_wait()


# Generated at 2022-06-12 13:35:01.753910
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    instance = Lock()
    result = instance.__aenter__()
    assert result is None


# Generated at 2022-06-12 13:35:03.342130
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    print(condition)




# Generated at 2022-06-12 13:35:06.109439
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    try:
        if (Semaphore(1).acquire()):
            pass
        else:
            raise AssertionError
    except:
        raise AssertionError


# Generated at 2022-06-12 13:35:17.548209
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    print("Condition: ", condition)
    # print(condition.__class__)
    # condition.notify_all()
    async def waiter():
        print("I'll wait right here")
        awa=await condition.wait()
        # awa = await condition.wait(timeout=condition.io_loop.time() + 1)
        # awa = await condition.wait(timeout=datetime.timedelta(seconds=1))
        print(awa)
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_

# Generated at 2022-06-12 13:35:21.324951
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem._value = 0
    sem._waiters = deque(["wait_1", "wait_2", "wait_3"])
    sem.release()
    assert sem._value == 1
    assert sem._waiters == deque(["wait_2", "wait_3"])


# Generated at 2022-06-12 13:35:52.820777
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert str(condition) == "<Condition>"


# Generated at 2022-06-12 13:36:04.082473
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import inspect
    from io import StringIO
    from unittest.mock import patch

    from tornado.locks import Semaphore
    from tornado.testing import AsyncTestCase, get_async_test_timeout
    from tornado.test.util import unittest

    class SemaphoreTestCase(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.sem = Semaphore()

        async def async_callback(self, value, callback):
            getattr(self.sem, callback)()
            return value

        def _test_release(self, callback, result, monkeypatch_release=None):
            monkeypatch_release = monkeypatch_release or self.async_callback
            test_value = object()

# Generated at 2022-06-12 13:36:06.849076
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.concurrent import Future
    from tornado import gen
    from tornado.locks import Condition

    condition = Condition()
    future = Future()

    async def waiter():
        await condition.wait()
        future_set_result_unless_cancelled(future, True)

    AsyncTestCase().ioloop.run_sync(lambda: gen.multi([waiter(), waiter()]))
    condition.notify_all()
    assert future.result() == True



# Generated at 2022-06-12 13:36:16.649520
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    import asyncio
    loop = asyncio.get_event_loop()

    lock = Lock()

    def test_fun():
        lock.release()

    async def test_fun_async():
        lock.release()

    # test: lock.release()
    try:
        # on of the arguments type is not allowed
        lock.__aexit__(1,2,3)
    except TypeError:
        assert True
    except:
        assert False

    # test: lock.release()
    loop.run_until_complete(test_fun_async())

    # test: lock.release()
    loop.run_until_complete(test_fun_async())

    # test: RuntimeError: release unlocked lock

# Generated at 2022-06-12 13:36:18.108943
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    await sem.__aexit__(None,None,None)


# Generated at 2022-06-12 13:36:23.435722
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def notify_all():
        # Wait for notifier() in parallel
        # await gen.multi([waiter(), notifier()])
        await gen.sleep(1)
        print("About to notify")
        condition.notify()
        print("Done notifying")
        await gen.sleep(1)
        print("About to notify all")
        condition.notify_all()
        print("Done notifying all")

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(lambda:gen.multi([waiter(),notify_all()]))

# test_Condition_notify()


# Generated at 2022-06-12 13:36:25.154831
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore = Semaphore(0)
    while not semaphore._waiters:
        semaphore.release()

# Generated at 2022-06-12 13:36:36.574009
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(value=20)
    print(sem._value)
    import time
    import multiprocessing
    result = []
    def acquire_one(semaphore, timeout=None):
        import time
        import random
        print('I am process {:>4}'.format(multiprocessing.current_process().name))
        print('Current count value of semaphore is {:>4}'.format(semaphore._value))
        time.sleep(random.random() * 3)
        ret = semaphore.acquire(timeout=timeout)
        print('I am process {:>4}'.format(multiprocessing.current_process().name))
        print('Current count value of semaphore is {:>4}'.format(semaphore._value))

# Generated at 2022-06-12 13:36:38.132444
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    print(semaphore.Semaphore().__aexit__(None,None,None))
    pass

# Generated at 2022-06-12 13:36:40.925680
# Unit test for method set of class Event
def test_Event_set():
    init_value = False
    event = Event()
    assert init_value == event.is_set()
    event.set()
    assert True == event.is_set()


# Generated at 2022-06-12 13:37:44.079897
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert isinstance(event.wait(), Future)



# Generated at 2022-06-12 13:37:54.125792
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    io_loop = ioloop.IOLoop.current()
    sem = Semaphore(1)
    evt = Event()
    def worker(wid):
        print("Worker {0} is working".format(wid))
        async def do_something():
            evt.set()
            async with sem:
                pass
        return do_something()
    async def runner():
        async def do_task(fut):
            await gen.sleep(0)
            await gen.sleep(0)
            fut.set_result(None)
            return fut
        tasks = [worker(i) for i in range(3)]
        await gen.multi([do_task(i) for i in tasks])
    io_loop.run_sync(runner)



# Generated at 2022-06-12 13:37:55.614112
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set()
    assert not event._value
    assert not event._waiters


# Generated at 2022-06-12 13:37:57.148922
# Unit test for method release of class Lock
def test_Lock_release():
    l = Lock()
    l.release()



# Generated at 2022-06-12 13:38:00.118361
# Unit test for method wait of class Event
def test_Event_wait():
    """Test that the method wait of class Event returns the expected Future"""
    event = Event()
    fut = event.wait()
    assert fut == Future, 'Wrong returned Future'
    assert fut._state == 'PENDING', 'Wrong Future state'
    return True


# Generated at 2022-06-12 13:38:03.385343
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    value = 1
    self._value = value
    self._waiters = deque()
    waiter = Future()
    self._value -= 1
    waiter.set_result(_ReleasingContextManager(self))
    return None

# Generated at 2022-06-12 13:38:04.958057
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    f = Lock()
    assert await f.__aenter__() is None



# Generated at 2022-06-12 13:38:08.664320
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    """
    This is an autogenerated unit test for the method __aenter__ in
    class Lock
    """
    lock = Lock.__new__(Lock)
    lock.__init__()
    with pytest.raises(NotImplementedError):
        lock.__aenter__()



# Generated at 2022-06-12 13:38:09.553216
# Unit test for method wait of class Event
def test_Event_wait():
    Event.wait()

# Generated at 2022-06-12 13:38:19.094653
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    s = Semaphore(10)

    # unit_test
    assert s._value == 10

    s.release()
    # unit_test
    assert s._value == 11
    assert s._waiters == deque()

    s.acquire(None)
    # unit_test
    assert s._value == 10

    s.release()
    # unit_test
    assert s._value == 11

    s.acquire(None)
    # unit_test
    assert s._value == 10

    s.release()
    # unit_test
    assert s._value == 11
    assert s._waiters == deque()

    s.acquire(None)
    # unit_test
    assert s._value == 10
    assert s._waiters == deque()

    s.release()
    # unit_test
   

# Generated at 2022-06-12 13:40:34.604139
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())

# Generated at 2022-06-12 13:40:41.628067
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond = Condition()
    @gen.coroutine
    def notifier():
        yield gen.sleep(0.5)
        cond.notify()
    @gen.coroutine
    def waiter():
        yield cond.wait()
        print('notify() has been called')
    io_loop = ioloop.IOLoop.current()
    t1 = notifier()
    t2 = waiter()
    io_loop.run_sync(lambda : gen.multi([t1, t2]))