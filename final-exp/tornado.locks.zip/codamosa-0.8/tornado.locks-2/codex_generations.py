

# Generated at 2022-06-12 13:31:15.277268
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_instance = Condition()
    # Verify that repr(condition_instance) works
    assert repr(condition_instance) == "<Condition waiters[0]>"



# Generated at 2022-06-12 13:31:22.663813
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    # test run
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:31:26.667525
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        success = await condition.wait()
        print("I'm done waiting")
        return success
    
    io_loop = ioloop.IOLoop.current()
    test_future = io_loop.run_sync(waiter)
    print(test_future)
    print()
    return test_future




# Generated at 2022-06-12 13:31:28.693934
# Unit test for method wait of class Event
def test_Event_wait():
    e = Event()
    fut = e.wait()
    assert fut.done() is False


# Generated at 2022-06-12 13:31:33.052370
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    futures = [c.wait() for i in range(10)]
    assert len(futures) == len(c._waiters)
    c.notify_all()
    for f in futures:
        assert f.result()


# Generated at 2022-06-12 13:31:40.698350
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import asyncio
    async def test_release(case_num: int, value: int):
        s = Semaphore(value)
        for i in range(value):
            s.release()
        print("Case #{0}:".format(case_num) + s._value)

    async def main():
        cases = [
            (1, 0),
            (2, 1),
        ]
        for case_num, value in cases:
            await asyncio.wait_for(test_release(case_num, value), 0)

    try:
        asyncio.run(main())
    except:
        pass



# Generated at 2022-06-12 13:31:46.971403
# Unit test for method wait of class Condition
def test_Condition_wait():
    io_loop = ioloop.IOLoop.current()
    condition = Condition()
    print("Start to test condition.wait")
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        await gen.multi([waiter(), notifier()])

    io_loop.run_sync(runner)


# Generated at 2022-06-12 13:31:50.354680
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import asyncio
    async def worker(worker_id):
        sem.release()

    async def runner():
        # Join all workers.
        await asyncio.gather(*[worker(i) for i in range(3)])

    sem = Semaphore(2)
    asyncio.run(runner())
    assert(sem.is_set())

# Generated at 2022-06-12 13:31:52.314619
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    cond_funcs = [] 
    cond_funcs.insert(0,condition.notify(1))
    cond_funcs.insert(1,condition.notify_all)




# Generated at 2022-06-12 13:32:02.180354
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore()
    # test when there is no waiters
    assert sem._value == 1
    assert len(sem._waiters) == 0
    fut = sem.acquire()
    assert sem._value == 0
    assert len(sem._waiters) == 0
    fut.set_result(None)
    assert sem._value == 0
    assert len(sem._waiters) == 0
    sem.release()
    assert sem._value == 1
    assert len(sem._waiters) == 0
    # test when there is waiters
    fut = sem.acquire()
    fut.set_result(None)
    assert sem._value == 0
    assert len(sem._waiters) == 0
    fut1 = sem.acquire()
    fut2 = sem.acquire()
    fut3 = sem.acquire

# Generated at 2022-06-12 13:32:25.556532
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore(2)
    o = s.acquire()


# Generated at 2022-06-12 13:32:29.586201
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore()
    with mock.patch('tornado.locks.Semaphore.acquire') as mock_acquire:
        with mock.patch('asyncio.iscoroutine') as mock_iscoroutine:
            mock_iscoroutine.return_value = True
            mock_acquire.return_value = None
            sem.__aenter__()
            mock_acquire.assert_called_once_with()
            mock_iscoroutine.assert_called_once_with(None)


# Generated at 2022-06-12 13:32:31.852034
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado.locks import Lock
    lock = Lock()
    lock.acquire()
    lock.release()


# Generated at 2022-06-12 13:32:38.450357
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        asyncio.run(condition.wait())
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await asyncio.gather(waiter(), notifier())

    asyncio.run(runner())



# Generated at 2022-06-12 13:32:41.008495
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Lock.__aenter__()
    x = Lock()
    return isinstance(x.__aenter__(), Awaitable)

# Generated at 2022-06-12 13:32:50.623923
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # Tests for method __aenter__ of class Semaphore
    from tornado import gen, httpclient, ioloop, locks
    from tornado.testing import AsyncHTTPTestCase, gen_test

    class TestSemaphore(locks.Semaphore):
        _count = 0

        def __init__(self, max_count: int = 1) -> None:
            super().__init__(max_count)
            self._count = 0

        async def __aenter__(self) -> None:
            await super().__aenter__()
            self._count += 1


# Generated at 2022-06-12 13:32:52.817699
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    cond.wait()
    cond.wait()
    assert repr(cond) == "<Condition waiters[2]>"



# Generated at 2022-06-12 13:32:58.711091
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    """
    Lock.__aexit__(RuntimeError, None, None)

    Not raising and releasing lock
    """
    lock = Lock()
    lock._block = BoundedSemaphore(value=1)
    lock._block._waiters = deque([
        Future(),
        Future(),
        Future(),
        Future(),
        Future()
    ])

    # __aexit__(RuntimeError, None, None)
    lock.__aexit__(RuntimeError, None, None)

    assert lock._block._value == 1
    assert not lock._block._waiters[0].done()
    assert not lock._block._waiters[1].done()
    assert not lock._block._waiters[2].done()
    assert not lock._block._waiters[3].done()

# Generated at 2022-06-12 13:33:00.839516
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(3)
    condition = Condition()
    import concurrent.futures
    with ThreadPoolExecutor(4) as executor:
        results = [executor.submit(condition.acquire, timeout=None) for _ in range(4)]
        for future in concurrent.futures.as_completed(results):
            print(future.result())


# Generated at 2022-06-12 13:33:02.478983
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-12 13:33:17.000913
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    Condition()

# Generated at 2022-06-12 13:33:21.942328
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore()
    s.release()
    s.release()
    s.release()
    print(s._value)
    print(s._waiters)
    print(s._timeout_waiters)
    with (yield s.acquire()):
        print(s._value)
        print(s._waiters)
        print(s._timeout_waiters)


# Generated at 2022-06-12 13:33:25.995125
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    value = 1
    waiters = deque() 
    waiters = deque() 
    waiter = Future()  # type: Future[_ReleasingContextManager]
    waiter.set_result(_ReleasingContextManager(self))
    self._value -= 1
    return

# Generated at 2022-06-12 13:33:28.539266
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    result = sem.__aenter__()
    assert result is None


# Generated at 2022-06-12 13:33:30.654809
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    # TODO: Fix the unit test
    assert lock.acquire() == None


# Generated at 2022-06-12 13:33:35.828159
# Unit test for method wait of class Event
def test_Event_wait():
    def main():
        event = Event()
        _o = event.wait()
        assert isinstance(_o, Future)
        assert not _o.done()
        event.set()
        assert _o.done()
        assert _o.result() is None
    # create an instance of the current TestCase.
    _self = TestEvent(main)
    # Call the unit test.
    _self.main()



# Generated at 2022-06-12 13:33:36.958137
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    assert lock.release() == None




# Generated at 2022-06-12 13:33:37.885954
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    pass


# Generated at 2022-06-12 13:33:40.124657
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    lock = locks.Lock()
    assert isinstance(lock.__aenter__(), locks._ReleasingContextManager)

# Generated at 2022-06-12 13:33:50.589782
# Unit test for method wait of class Condition
def test_Condition_wait():
    # test_lock.py
    # test condition
    from tornado.locks import Condition
    ioloop.install()
    from tornado.ioloop import IOLoop
    from tornado import gen
    condition = Condition()

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait();
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)

if __name__ == "__main__":
    test_Condition_wait()

# Generated at 2022-06-12 13:34:13.739733
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()
    result_list = []

    async def waiter(i):
        print("waiter",i,"will wait")
        await condition.wait()
        t = i
        print("waiter",t,"will write")
        result_list.append(t)

    async def notifier():
        print("notifier will notify")
        condition.notify_all()
        print("notifier done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(i) for i in range(10)]+[notifier()])

    IOLoop.current().run_sync(runner)

    print(result_list)


# Generated at 2022-06-12 13:34:15.169451
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    obj = Condition()
    obj.notify_all()
    assert repr(obj) == "<Condition waiters[0]>"

# Generated at 2022-06-12 13:34:21.648433
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    # Test for notify(1)
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify(1)
        print("Done notifying")

    async def runner():

        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:34:30.954616
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    test_bool = False
    @gen.coroutine
    def waiter():
        nonlocal test_bool
        await condition.wait()
        test_bool = True
    @gen.coroutine
    def notifier():
        condition.notify_all()
    @gen.coroutine
    def runner():
        await gen.multi([waiter(), notifier()])
    loop = ioloop.IOLoop.current()
    loop.run_sync(runner)
    assert test_bool == True

# Generated at 2022-06-12 13:34:38.346460
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    def test_func(tf):
        print("timeout!")
    def test_func1(fut):
        fut.cancel()
        print("notify!")
        event.set()
    # set event to be true
    event.set()
    # test event.wait()
    fut = event.wait()
    fut.add_done_callback(test_func)
    fut.add_done_callback(test_func1)
    # test event.wait(timeout)
    timeout_fut = event.wait(timeout=3)
    timeout_fut.add_done_callback(test_func)
    timeout_fut.add_done_callback(test_func1)
    timeout_fut = event.wait(timeout=1)
    timeout_fut.add_done_callback

# Generated at 2022-06-12 13:34:40.689195
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    a = BoundedSemaphore(1)
    a.release()
    a.release()


# Generated at 2022-06-12 13:34:44.679062
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"
    waiter = Future()
    c._waiters.append(waiter)
    assert repr(c) == "<Condition waiters[1]>"

# Generated at 2022-06-12 13:34:46.431967
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    assert Lock.__aenter__(Lock()) is not None


# Generated at 2022-06-12 13:34:51.180036
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Set up variables
    # s is a Semaphore object initialized with a value of 1
    s = Semaphore(1)
    # Get the result of acquire on s
    res = s.acquire()
    # Check that the type of res is a Future
    assert type(res) == Future
    # Check that the value of res is 0
    assert res.result() == 0

# Generated at 2022-06-12 13:34:54.569576
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore = Semaphore()
    semaphore.release()
    assert semaphore._value == 1
    assert len(semaphore._waiters) == 0


# Generated at 2022-06-12 13:35:26.037776
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from . import locks
    from . import gen
    import tornado

    with tornado._stack_context_handle_exception():
        try:
            locks.Semaphore().__aenter__()
        except Exception:
            raise tornado.gen.Return()
        assert False

# Generated at 2022-06-12 13:35:37.267855
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # We can't construct an instance of Condition because it has abstract methods.
    # So we construct a subclass and test __repr__ on that.
    class _ConditionImpl(Condition):
        def wait(
            self, timeout: Optional[Union[float, datetime.timedelta]] = None
        ) -> Awaitable[bool]:
            pass
        def notify(self, n: int = 1) -> None:
            pass
        def notify_all(self) -> None:
            pass

    # Test for no waiter
    condition1 = _ConditionImpl()
    repr(condition1)
    assert condition1.__repr__() == "<_ConditionImpl>"

    # Test for one waiter
    condition2 = _ConditionImpl()
    condition2._waiters = collections.deque();
    condition2._waiters.append(None)
    repr

# Generated at 2022-06-12 13:35:40.373365
# Unit test for method set of class Event
def test_Event_set():
    e = Event()
    assert e.is_set() == False

    e.set()
    assert e.is_set() == True

    e.clear()
    assert e.is_set() == False


# Generated at 2022-06-12 13:35:43.887920
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    async def test():
        sem = Semaphore(1)
        async with sem:
            print("Worker 0 is working")
        print("Worker 0 is done")
        return True
    assert run_until_complete(test())



# Generated at 2022-06-12 13:35:45.321181
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c)=="<Condition>"

# Generated at 2022-06-12 13:35:46.184210
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()


# Generated at 2022-06-12 13:35:49.754835
# Unit test for method set of class Event
def test_Event_set():
    print("Running Event.set() Unit Test")
    event = Event()
    event.set()
    assert event.is_set(), "Event.is_set() failed."
    print("Unit Test Successful.")


# Generated at 2022-06-12 13:35:56.455698
# Unit test for method release of class Lock
def test_Lock_release():
    def test_Lock_release0():
        l = Lock()
        l.release()
    test_Lock_release0()

    def test_Lock_release1():
        l = Lock()
        l.acquire()
        l.release()
    test_Lock_release1()
    # TestRuntimeError: RuntimeError: release unlocked lock
    # def test_Lock_release2():
    #     l = Lock()
    #     # TestRuntimeError: RuntimeError: release unlocked lock
    #     l.release()
    #     l.acquire()
    # test_Lock_release2()


# Generated at 2022-06-12 13:36:06.325045
# Unit test for method wait of class Condition
def test_Condition_wait():
    import unittest
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop = IOLoop.current()
    ioloop.run_sync(runner)
    unittest.TestCase().assertEqual(True, True)   # All test cases must have this line, otherwise the test case will not be counted.


# Generated at 2022-06-12 13:36:16.260347
# Unit test for method wait of class Event
def test_Event_wait():

    def setUp(self):
        self.event = Event()
        self.event.set()
        self.assertFalse(self.event._waiters)

    def tearDown(self):
        self.event = None

    def test_wait_with_timeout(self):
        awaitable = self.event.wait(timeout=0.1)
        self.assertFalse(awaitable.done())
        self.assertIsInstance(awaitable, Future)
        self.assertTrue(self.event._waiters)
        # Scheduling an event loop will run the timer and set the future.
        self.event.io_loop.call_later(0.2, self.event.io_loop.stop)
        self.event.io_loop.start()
        self.assertEqual(self.event._waiters, set())
       

# Generated at 2022-06-12 13:37:21.986305
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:37:23.927532
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():

    lock = Lock()
    future = lock.__aenter__()
    assert isinstance(future, Awaitable)
    return future



# Generated at 2022-06-12 13:37:30.338890
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition=Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:37:31.498003
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    assert repr(cond) == "<Condition>"
    assert repr(Condition()) == "<Condition>"

# Generated at 2022-06-12 13:37:35.462712
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition, Future
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-12 13:37:41.002756
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bs = BoundedSemaphore(2)
    bs.release()
    bs.release()
    with pytest.raises(ValueError):
        bs.release()
    with pytest.raises(ValueError):
        bs.release()
test_BoundedSemaphore_release()

test_BoundedSemaphore_release()

# Test module: tornado.locks
# Test file: locks.py
# Test class: ThreadedResolver
# Test method: close
# Test description: Close the resolver.
# Test assertions:
# 1. Test description: Close the resolver.
# 2. Test description: Test type of a returned result.
# 3. Test description: The number of threads after closing must be 0.
# 4. Test description: The number of threads after closing must be 0.
# 5. Test

# Generated at 2022-06-12 13:37:47.247859
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()

    @gen.coroutine
    def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    @gen.coroutine
    def setter():
        print("About to set the event")
        event.set()

    @gen.coroutine
    def runner():
        yield [waiter(), setter()]

    ioloop.IOLoop.current().run_sync(runner)
test_Event_wait()


# Generated at 2022-06-12 13:37:54.089413
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    runner()


# Generated at 2022-06-12 13:37:58.533903
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore()
    assert sem.is_set()
    sem.release()
    assert sem.is_set()
    sem.clear()
    assert not sem.is_set()
    sem.release()
    assert sem.is_set()
    sem.clear()
    sem.clear()
    assert not sem.is_set()


# Generated at 2022-06-12 13:37:59.882256
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    print(sem)
    sem.release()
    print(sem)

# Generated at 2022-06-12 13:39:56.628634
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore()
    assert s.acquire().result() == None

# Generated at 2022-06-12 13:40:00.712393
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lk = Lock()
    # Test that __aenter__ raises an exception if the lock is already acquired.
    lk.acquire()
    with pytest.raises(RuntimeError):
        async with lk:
            pass

# Generated at 2022-06-12 13:40:02.710510
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond = Condition()
    cond.notify()
    cond.notify(2)
    cond.notify_all()


# Generated at 2022-06-12 13:40:12.452103
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    # wait等待3秒
    def waiter():
        print("I'll wait right here")
        await condition.wait(timeout=io_loop.time() + 3)
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    # 运行起来，等待10秒
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.wait([waiter(), notifier()], io_loop, timeout=10)

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(runner)
    if __name__ =="__main__":
        test_

# Generated at 2022-06-12 13:40:17.083056
# Unit test for method release of class Lock
def test_Lock_release():
    # Check if Lock initializes properly
    lock = Lock()
    assert type(lock) == Lock
    assert lock._block == BoundedSemaphore(value=1)
    # Check if Lock can be acquired
    lock.acquire()
    # Check if Lock can be released
    lock.release()
    # Check if Lock can't be released twice
    with pytest.raises(RuntimeError):
        lock.release()

# Generated at 2022-06-12 13:40:22.029466
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition() # condition = <Condition>

    condition._waiters = [] # add field "_waiters"
    assert repr(condition) == "<Condition>" # condition = <Condition>

    condition._waiters = [1] # add field "_waiters"
    assert repr(condition) == "<Condition waiters[1]>" # condition = <Condition waiters[1]>

    condition._waiters = [1, 2, 3] # add field "_waiters"
    assert repr(condition) == "<Condition waiters[3]>" # condition = <Condition waiters[3]>

    return True


# Generated at 2022-06-12 13:40:28.547110
# Unit test for method wait of class Condition
def test_Condition_wait():

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-12 13:40:36.859461
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    if __name__ == 'builtins':
        import pytest
        pytest.skip('Semaphore not yet defined')
    _aenter_coro = Semaphore().__aenter__()
    assert hasattr(_aenter_coro, '__await__')
    awaitable = _aenter_coro.__await__()
    try:
        awaitable.send(None)
    except StopIteration as e:
        r = e.value
    else:
        assert False, 'expected StopIteration'
    assert r is None
    awaitable = Semaphore().__aexit__(None, None, None).__await__()
    try:
        awaitable.send(None)
    except StopIteration as e:
        r = e.value

# Generated at 2022-06-12 13:40:40.526226
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    print(condition)
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)
test_Condition_wait()


# Generated at 2022-06-12 13:40:42.120042
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    assert repr(cond) == "<Condition>"
    cond._waiters.append(1)
    assert repr(cond) == "<Condition waiters[1]>"
