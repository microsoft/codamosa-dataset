

# Generated at 2022-06-26 08:15:03.488879
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    semaphore_0.acquire()


# Generated at 2022-06-26 08:15:06.376583
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    val = 1
    semaphore = Semaphore(val)
    result = semaphore.__repr__()
    print(result)


# Generated at 2022-06-26 08:15:09.095554
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    condition_1 = Condition()
    assert condition_0.__repr__() == condition_1.__repr__()
    assert condition_0 == condition_1


# Generated at 2022-06-26 08:15:12.096912
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    future = condition.wait()
    assert not future.done()
    return


# Generated at 2022-06-26 08:15:17.009481
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # Init a condition variable
    semaphore_0 = Semaphore(int())
    assert_raises(RuntimeError, semaphore_0.__enter__)
    assert_raises(RuntimeError, semaphore_0.acquire)

# Generated at 2022-06-26 08:15:18.528343
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    f = Future()
    t = Condition()
    t.wait()


# Generated at 2022-06-26 08:15:19.900807
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.acquire()


# Generated at 2022-06-26 08:15:22.737741
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    assert_equal(condition_0, condition_0)
    condition_0.notify_all()


# Generated at 2022-06-26 08:15:26.095448
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    awaitable_0 = semaphore_0.__aenter__()
    # The following assert fails
    assert awaitable_0 is None


# Generated at 2022-06-26 08:15:33.662978
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test with non-empty waiters list
    condition = Condition()
    waiter = Future()
    condition._waiters.append(waiter)
    assert (condition.__repr__() == "<Condition waiters[1]>")

    # Test with empty waiters list
    condition = Condition()
    assert (condition.__repr__() == "<Condition>")


# Generated at 2022-06-26 08:15:51.471831
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Preconditions
    semaphore_0 = Semaphore(0)

    # Test
    semaphore_0.acquire(None)

    # Postconditions


# Generated at 2022-06-26 08:16:00.670471
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    io_loop = ioloop.IOLoop.current()
    semaphore_0 = Semaphore()
    waiter_0 = Future()
    # The _TimeoutGarbageCollector object does not implement
    # the __call__ method
    callback_0 = _TimeoutGarbageCollector()
    waiter_0.add_done_callback(callback_0)
    waiter_0 = Future()
    # The _TimeoutGarbageCollector object does not implement
    # the __call__ method
    callback_0 = _TimeoutGarbageCollector()
    waiter_0.add_done_callback(callback_0)


# Generated at 2022-06-26 08:16:02.276458
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.set()
    assert(event_0.wait() == None)


# Generated at 2022-06-26 08:16:06.508524
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    future_0 = condition_0.wait(datetime.timedelta(seconds=1))
    future_0.done()
    future_0.result()


# Generated at 2022-06-26 08:16:08.629663
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem_0 = Semaphore(1)

    assert sem_0.__repr__() == "<Semaphore [unlocked,value:1]>"

# Generated at 2022-06-26 08:16:13.709605
# Unit test for method set of class Event
def test_Event_set():
    a = Event()
    assert(a.is_set() == False)
    a.set()
    assert(a.is_set() == True)


# Generated at 2022-06-26 08:16:16.948511
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    r = condition_0.__repr__()
    assert r == "<Condition"


# Generated at 2022-06-26 08:16:20.381673
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # input
    sem_0 = Semaphore()
    # call
    sem_0.release()
    # check
    result = sem_0._value
    print(result)
    assert result == 1


# Generated at 2022-06-26 08:16:21.048743
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    pass


# Generated at 2022-06-26 08:16:24.737253
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    __tracebackhide__ = True
    condition_0 = Condition()
    condition_0.notify_all()


# Generated at 2022-06-26 08:16:40.254218
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    condition_0 = Condition()
    semaphore_0 = Semaphore(1)
    semaphore_0.acquire()
    await semaphore_0.__aenter__()


# Generated at 2022-06-26 08:16:42.355625
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(1)
    condition_0.notify(1)



# Generated at 2022-06-26 08:16:46.787424
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    assert condition_0.__repr__() == "<Condition"
    condition_0._waiters = collections.deque()  # type: Deque[Future]
    assert condition_0.__repr__() == "<Condition>"



# Generated at 2022-06-26 08:16:50.986870
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    condition_0 = Condition()
    semaphore_0 = BoundedSemaphore()
    with pytest.raises(ValueError):
        semaphore_0.release()


# Generated at 2022-06-26 08:16:57.505474
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # Create an instance of class Semaphore
    condition_0 = Semaphore()

    # Call method __aenter__ of condition_0
    __aenter___return_value = condition_0.__aenter__()

    # Check the type of __aenter___return_value is None
    if not (__aenter___return_value is None):
        raise Exception("Expected None, but got %s" % type(__aenter___return_value))


# Generated at 2022-06-26 08:17:03.248035
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    condition_0 = Condition()
    semaphore_0 = Semaphore()
    semaphore_0._value = 0
    semaphore_0._waiters.append(condition_0)
    semaphore_0.release()
    assert condition_0._done_callbacks.__len__() == 0
    assert semaphore_0._value == 1



# Generated at 2022-06-26 08:17:12.281758
# Unit test for method wait of class Event
def test_Event_wait():
    def waiter():
        print("Waiting for event")
        condition_0.wait()
        print("Not waiting this time")
        condition_0.wait()
        print("Done")

    def setter():
        print("About to set the event")
        condition_0.notify()

    def runner():
        waiter()
        setter()

    runner()


# Generated at 2022-06-26 08:17:15.705950
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    t_lock = Lock()
    t_future_0 = t_lock.__aenter__()
    t_future_0.result()
    t_lock.__aexit__(Exception, None, None)


# Generated at 2022-06-26 08:17:17.866362
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    try:
        lock.__aenter__()
        assert True
    except ValueError:
        assert False


# Generated at 2022-06-26 08:17:21.098030
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:17:52.467565
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    condition_0 = Condition()
    semaphore_0 = BoundedSemaphore()
    assert Exception


# Generated at 2022-06-26 08:17:57.117781
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    __repr___ret_0 = condition_0.__repr__()
    assert __repr___ret_0 == '<Condition waiters[0]>'


# Generated at 2022-06-26 08:17:58.589325
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond = Condition()
    cond.notify(1)


# Generated at 2022-06-26 08:18:09.547382
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    print("wait for condition")
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:18:12.712688
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    # test whether the provided method of class Condition could be invoked correctly
    try:
        condition_0.notify_all()
    except:
        print(f'Invoke condition_0.notify_all() exception')


# Generated at 2022-06-26 08:18:20.744954
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Initialize inputs
    sem = Semaphore()

    # Run the function under test
    result = sem.acquire()

    # Check the result
    assert result is not None
    assert type(result) is Future
    assert result.result() is not None
    assert type(result.result()) is _ReleasingContextManager


# Generated at 2022-06-26 08:18:24.107352
# Unit test for method wait of class Event
def test_Event_wait():
    evt = Event()
    evt.clear()
    fut = evt.wait()
    if fut.done():
        return 1
    evt.set()
    evt.clear()
    fut = evt.wait()
    if fut.done():
        return 1
    return 0


# Generated at 2022-06-26 08:18:36.190846
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Input:
    val_0 = 0
    # Expected Output:

# Generated at 2022-06-26 08:18:41.257560
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    assert condition_0 is not None
    condition_0.notify_all()

    # This is a test for cover hole in py3's dict_wrapper


lock_0 = None

# Generated at 2022-06-26 08:18:43.691118
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    try:
        condition = Condition()
        print(condition)
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 08:19:58.239102
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # create condition variable
    condition_0 = Condition()

    # create a Semaphore object with initial value 1
    semaphore_0 = Semaphore(1)

    # call method acquire() of object semaphore_0
    semaphore_0.acquire()

    # create a Semaphore object with an invalid initial value -2
    try:
        semaphore_1 = Semaphore(-2)
    except ValueError as e:
        print('ValueError:', e)


# Generated at 2022-06-26 08:20:01.558706
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    case_0 = Condition()
    assert case_0.__repr__() == "<Condition"
    case_1 = Condition()
    case_1._waiters.append(Future())
    assert case_1.__repr__() == "<Condition waiters[1]>"


# Generated at 2022-06-26 08:20:08.065006
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)

    async def worker_0(worker_id):
        with (yield sem.acquire()):
            pass

    IOLoop.current().run_sync(worker_0, 0)


# Generated at 2022-06-26 08:20:09.555701
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()


# Generated at 2022-06-26 08:20:17.882860
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    s = Semaphore()
    status = 999 # Default initial status

    def test_case_0():
        if s.__aexit__(None, None, None) == None:
            status = 0
    test_case_0()

    if status == 0:
        print("Unit test for method __aexit__ of class Semaphore is successful!")
    else:
        print("Unit test for method __aexit__ of class Semaphore is not successful!")


# Generated at 2022-06-26 08:20:19.434896
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    condition_0 = Condition()


# Generated at 2022-06-26 08:20:28.224632
# Unit test for method wait of class Condition
def test_Condition_wait():
    print("Running unit test for wait function of class Condition.")

    condition_0 = Condition()

    # Case 0
    print("Case 0: timeout is not set")
    wait_future_0 = condition_0.wait()
    condition_0.notify()
    ioloop.IOLoop.current().run_sync(wait_future_0)
    print("Testing successful!")
    print()

    # Case 1
    print("Case 1: timeout is set")
    wait_future_1 = condition_0.wait(timeout=0.5)
    print("Testing successful!")
    print()
    ioloop.IOLoop.current().run_sync(wait_future_1)



# Generated at 2022-06-26 08:20:31.958097
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    condition_0.notify()
    condition_0.wait()
    return condition_0.__repr__()


# Generated at 2022-06-26 08:20:45.199149
# Unit test for method set of class Event
def test_Event_set():
    flag_0 = 0
    event_0 = Event()
    
    def callback_0():
        print ('in callback_0')
        nonlocal flag_0
        flag_0 = flag_0 + 1
        print ('flag is ', flag_0)
        return
    
    event_0.set()
    print ('is flag 1', event_0.is_set())
    event_0.clear()
    print ('is flag 2', event_0.is_set())

    event_0.set()
    f1 = event_0.wait()
    f2 = event_0.wait()
    f3 = event_0.wait()
    print ('before callback')
    f1.add_done_callback(callback_0)
    f2.add_done_callback(callback_0)
    f3.add_

# Generated at 2022-06-26 08:20:52.610777
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()

    @gen.coroutine
    def f():
        result = yield condition_0.wait()
        return result

    future_0 = f()
    value = future_0.result()
    assert False == value

    condition_0.notify()
    value = future_0.result()
    assert True == value



# Generated at 2022-06-26 08:22:48.060671
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()
    assert True == event_0.is_set()


# Generated at 2022-06-26 08:22:55.340585
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(1)
    waiters = []  # Waiters we plan to run right now.
    while waiters and condition_0._waiters:
        waiter = condition_0._waiters.popleft()
        if not waiter.done():  # Might have timed out.
            waiters.append(waiter)
    for waiter in waiters:
        future_set_result_unless_cancelled(waiter, True)


# Generated at 2022-06-26 08:22:59.309245
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    with pytest.raises(RuntimeError):
        lock.__aenter__()


# Generated at 2022-06-26 08:23:04.545527
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(0)
    sem.release()
    if sem._value == 1:
        print("Test test_Semaphore_release() Success!")
        return True
    else:
        print("Test test_Semaphore_release() Fail!")
        return False


# Generated at 2022-06-26 08:23:18.287878
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    import unittest
    import types
    import tornado.concurrent
    import asyncio
    import sys
    import tornado
    class __main__TestCase(unittest.TestCase):
        def test_case_0(self):
            # No context manager
            cond = Semaphore()
            self.assertIs(cond._waiters, None)
            self.assertEqual(cond.__dict__['_Semaphore__value'], 1)
            def test_case_0_lambda_0():
                # Using a semaphore twice is an error
                cond = Semaphore()
                cond._waiters = []
                self.assertEqual(cond._value, 1)
                with cond:
                    with cond:
                        pass

# Generated at 2022-06-26 08:23:21.394168
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()
    event_0.set()


# Generated at 2022-06-26 08:23:26.185655
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)

    print("Worker %d is working" % 0)
    sem.release()
    print("Worker %d is done" % 0)



# Generated at 2022-06-26 08:23:32.813138
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    condition_0 = Condition()
    awaitable_0 = condition_0.acquire()
    future_0 = Future()
    future_0.set_result(None)
    future_0.exception()
    object_0 = object()
    object_0.__aenter__()
    object_0.__aenter__(object_0)
    object_0.__aenter__(object_0)
    object_0.__aenter__(object_0)
    object_0.__aexit__(object_0, None, None)
    object_0.__aexit__(object_0, None, None)
    object_0.__aexit__(object_0, None, None)
    object_0.__aexit__(object_0, None, None)
    object_0.__aexit

# Generated at 2022-06-26 08:23:36.469937
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(1)
    condition_0.notify_all()


# Generated at 2022-06-26 08:23:42.033150
# Unit test for method notify of class Condition
def test_Condition_notify():
    io_loop = ioloop.IOLoop.current()
    condition_0 = Condition()
    def waiter_0():
        #print("I'll wait right here")
        await condition_0.wait()
        #print("I'm done waiting")

    def notifier_0():
        #print("About to notify")
        condition_0.notify()
        #print("Done notifying")

    def runner_0():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter_0(), notifier_0()])

    io_loop.run_sync(runner_0())
    return
