

# Generated at 2022-06-26 08:14:50.113756
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    assert cond.__repr__() == "<Condition>"


# Generated at 2022-06-26 08:14:56.782158
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    with pytest.raises(RuntimeError) as e:
        lock_0.__enter__()


# Generated at 2022-06-26 08:14:59.435351
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    lock_0 = BoundedSemaphore()
    lock_0.release()


# Generated at 2022-06-26 08:15:06.992825
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    waiters = []
    i = 0
    while i < 10:
        waiter = Future()
        condition._waiters.append(waiter)
        waiters.append(waiter)
        i += 1
    condition.notify_all()
    for waiter in waiters:
        assert waiter.done()
        assert waiter.result()


# Generated at 2022-06-26 08:15:14.265566
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(1)

    print("Start to await sem.acquire()")
    print(type(sem.acquire()))
    print("End of the call to sem.acquire()")

    print("Start to await sem.__aenter__()")
    await sem.__aenter__()
    print("End of the call to sem.__aenter__()")

    print("Start to await sem.release()")
    sem.release()
    print("End of the call to sem.release()")


# Generated at 2022-06-26 08:15:22.442865
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    # try to release but sem is not acquired
    sem.release()
    assert sem._value == 2
    async def worker(worker_id):
        await sem.acquire()
        print("Worker %d is working" % worker_id)
        await use_some_resource()
        print("Worker %d is done" % worker_id)
        sem.release()
        
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:15:26.142184
# Unit test for method wait of class Condition
def test_Condition_wait():
    lock_0 = Lock()

    # Create the condition variable
    condition_0: Condition = Condition()

    # Wait on the condition variable
    event_0: Event = condition_0.wait(0.1)



# Generated at 2022-06-26 08:15:29.614264
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    # Test case data
    value_0 = None

    # Call the test function
    Semaphore___repr__(value_0)


# Generated at 2022-06-26 08:15:31.095064
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    assert lock._block._value == 1


# Generated at 2022-06-26 08:15:39.784527
# Unit test for method wait of class Event
def test_Event_wait():
    global lock_0
    import asyncio

    async def coro(e):
        lock_0.acquire()
        try:
            await e.wait()
            print("[w] Wait finished")
        finally:
            lock_0.release()
        print("[w] Done")

    async def main():
        e1 = Event()
        e2 = Event()

        t1 = asyncio.create_task(coro(e1))
        t2 = asyncio.create_task(coro(e1))
        t3 = asyncio.create_task(coro(e2))

        await asyncio.sleep(1)
        print("[m] Set 1")
        e1.set()

        await asyncio.sleep(1)
        print("[m] Clear")
        e1.clear()

       

# Generated at 2022-06-26 08:15:49.825059
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond = Condition()
    cond.notify()


# Generated at 2022-06-26 08:15:51.374124
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():

    lock_0 = Semaphore()
    print(lock_0)


# Generated at 2022-06-26 08:16:00.855082
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait(timeout=datetime.timedelta(seconds=1))
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:16:01.894265
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    print(c)


# Generated at 2022-06-26 08:16:06.968979
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    fut = event.wait()
    assert (fut.done() == False)
    event.set()
    assert (fut.done() == True)

    event = Event()
    fut = event.wait()
    assert (fut.done() == False)
    event.set()
    assert (fut.done() == True)


# Generated at 2022-06-26 08:16:20.330185
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    print('Function: notify_all of class Condition...')
    cond_0 = Condition()

    # Test case 1: cond_0._waiters is empty.
    cond_0.notify()
    
    # Test case 2: cond_0._waiters is not empty. 
    async def async_wait_0(cond: Condition) -> None:
        result_0 = await cond.wait()
        print('result_0 = {}'.format(result_0))

    async def async_notify_0(cond: Condition) -> None:
        await gen.sleep(1)
        cond.notify()
    
    async def async_wait_1(cond: Condition) -> None:
        result_1 = await cond.wait()
        print('result_1 = {}'.format(result_1))


# Generated at 2022-06-26 08:16:31.886236
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    loop = ioloop.IOLoop.current()
    condition = Condition()
    count = 0
    lock = Lock()

    async def waiter():
        nonlocal count
        await condition.wait()
        lock.acquire()
        count += 1
        lock.release()

    async def runner():
        await condition.wait()
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), waiter(), waiter()])
        condition.notify_all()
        lock.acquire()
        assert count == 3
        lock.release()

    loop.run_sync(runner)
    print("Test case pass!")



# Generated at 2022-06-26 08:16:34.379014
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.wait()


# Generated at 2022-06-26 08:16:43.603815
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond_0 = Condition()
    first_waiter = Future()
    second_waiter = Future()

    def first() -> None:
        first_waiter.set_result(cond_0.wait())
    def second() -> None:
        second_waiter.set_result(cond_0.wait())

    future_1 = gen.coroutine(first)()
    future_2 = gen.coroutine(second)()

    cond_0.notify_all()

    first_waiter.result()
    second_waiter.result()



# Generated at 2022-06-26 08:16:46.542325
# Unit test for method wait of class Condition
def test_Condition_wait():
    # Test case 0
    test_case_0()



# Generated at 2022-06-26 08:16:58.624211
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    lock_0 = Semaphore(1)
    str_0 = repr(lock_0)
    print(str_0)

# Generated at 2022-06-26 08:17:02.953740
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    future = condition.wait()
    future.result()
    condition.notify()
    print(future.result())


# Generated at 2022-06-26 08:17:07.897434
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    print("\n---Testcase:" + test_Condition___repr__.__name__)
    string = Condition()
    string.__repr__()



# Generated at 2022-06-26 08:17:17.776739
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    lock = Lock()
    # lock.acquire()

    async def waiter(lock):
        print("I'll wait right here")
        await lock.acquire()
        await condition.wait()
        lock.release()
        print("I'm done waiting")
        return True

    async def notifier(lock):
        print("About to notify")
        await lock.acquire()
        condition.notify()
        lock.release()
        print("Done notifying")

    async def runner(lock):
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(lock), notifier(lock)])

    ioloop.IOLoop.current().run_sync(lambda: runner(lock))



# Generated at 2022-06-26 08:17:20.953398
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    lock_0 = Semaphore()
    lock_0.__aenter__()



# Generated at 2022-06-26 08:17:25.246552
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore(1)
    assert s._value == 1
    assert not s._waiters
    s.acquire()
    assert s._value == 0
    assert not s._waiters


# Generated at 2022-06-26 08:17:28.058522
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    lock_0 = Semaphore()
    lock_0.__aenter__()
    # uncomment next line to generate assertion error
    # assert False



# Generated at 2022-06-26 08:17:29.630021
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    assert True


# Generated at 2022-06-26 08:17:32.958030
# Unit test for method set of class Event
def test_Event_set():
    ev_0 = Event()
    ev_0.set()
    assert ev_0.is_set()


# Generated at 2022-06-26 08:17:36.220873
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    future = event.wait()
    assert future.done() == True


# Generated at 2022-06-26 08:17:50.439912
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(0)
    # Test case 0
    # Test when lock is available
    sem.release()
    sem._value = 0
    result_0 = sem.acquire()
    assert result_0 == _ReleasingContextManager(sem)


# Generated at 2022-06-26 08:17:54.815902
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    lock_0 = Lock()
    lock_0.acquire()
    lock_0.release()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:17:59.550537
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(value=1)
    def wrapper():
        sem.__aenter__()
    try:
        wrapper()
    except:
        pass
    result = sem._value
    assert result == 0


# Generated at 2022-06-26 08:18:12.914814
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    lock_1 = Semaphore(5)
    assert lock_1._value == 5
    assert len(lock_1._waiters) == 0
    assert lock_1.acquire().done() == False
    assert lock_1._value == 4
    assert lock_1.acquire().done() == False
    assert lock_1._value == 3
    assert lock_1.acquire(timeout=2).done() == False
    assert lock_1._value == 2
    assert lock_1.acquire(timeout=datetime.timedelta(seconds=2)).done() == False
    assert lock_1._value == 1
    assert lock_1.acquire().done() == False
    assert lock_1._value == 0
    assert lock_1.acquire().done() == False
    assert lock_1._value == 0


#

# Generated at 2022-06-26 08:18:19.166138
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    with pytest.raises(RuntimeError) as e_info:
        test_case_0()
    assert "Use `async with` instead of `with` for Lock" in str(e_info.value)


# Generated at 2022-06-26 08:18:22.053870
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()

    event.set()
    assert True == event.is_set()

    result = event.wait()
    print(result)



# Generated at 2022-06-26 08:18:24.202716
# Unit test for method set of class Event
def test_Event_set():
    pass


# Generated at 2022-06-26 08:18:25.383782
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set()


# Generated at 2022-06-26 08:18:29.408972
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.instance().run_sync(runner)


# Generated at 2022-06-26 08:18:37.174564
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    waiter_0 = Future()
    waiter_1 = Future()
    condition_0._waiters.append(waiter_0)
    condition_0._waiters.append(waiter_1)
    condition_0.notify()
    waiter_2 = Future()
    condition_0._waiters.append(waiter_2)
    condition_0.notify()
    waiter_3 = Future()
    condition_0._waiters.append(waiter_3)
    condition_0.notify()
    waiter_4 = Future()
    condition_0._waiters.append(waiter_4)
    condition_0.notify(2)


# Generated at 2022-06-26 08:18:49.239796
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    lock_1 = BoundedSemaphore()
    lock_1.release()



# Generated at 2022-06-26 08:18:51.422690
# Unit test for method notify of class Condition
def test_Condition_notify():
    lock_0 = Condition()
    lock_0.notify()


# Generated at 2022-06-26 08:18:54.215969
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    if not event.is_set():
        event.set()
        return True
    else:
        return False


# Generated at 2022-06-26 08:19:04.653325
# Unit test for method wait of class Condition
def test_Condition_wait():
    lock_0 = Lock()
    test_f = Future()
    def test_func_0():
        test_f.set_result(0)
    def test_func_1():
        test_f.set_result(1)
    test_f = Condition().wait(timeout=None)
    assert test_f.done() == False
    assert test_f.cancelled() == False
    assert test_f.running() == False
    assert test_f.result() == None
    assert test_f.exception() == None


# Generated at 2022-06-26 08:19:06.468229
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()


# Generated at 2022-06-26 08:19:08.814120
# Unit test for method wait of class Event
def test_Event_wait():
    evt_0 = Event()
    evt_1 = Event()


# Generated at 2022-06-26 08:19:13.443022
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    result_0 = repr(condition_0)
    print("result_0: ", result_0)
    return result_0



# Generated at 2022-06-26 08:19:15.295754
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    lock_0 = Semaphore()
    lock_0.release()


# Generated at 2022-06-26 08:19:20.168749
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    lock_0 = Condition()
    result = lock_0.__repr__()
    print(result)
    assert(result == "<Condition>")


# Generated at 2022-06-26 08:19:26.640141
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(0)

    # Test with correct arguments
    assert sem.__aenter__() == None

    # Test with incorrect arguments
    # TypeError: __aenter__() takes 1 positional argument but 2 were given
    # sem.__aenter__(None)



# Generated at 2022-06-26 08:19:40.641410
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    lock_0 = BoundedSemaphore()
    lock_0.release()
    # if the following statement is uncommented, there is an exception
    #lock_0.release()


# Generated at 2022-06-26 08:19:44.225015
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    try:
        lock_0.__aenter__()
    except:
        assert False
   

# Generated at 2022-06-26 08:19:58.387795
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop

    # 1. create a Condition object
    condition = Condition()

    # 2. define a function
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-26 08:19:59.822734
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    lock_0 = Semaphore()
    lock_0.release()


# Generated at 2022-06-26 08:20:06.246144
# Unit test for method notify of class Condition
def test_Condition_notify():
    lock_0 = Lock()
    condition_0 = Condition()
    condition_0.notify()
    condition_1 = Condition()
    condition_1.notify(7)
    condition_2 = Condition()


# Generated at 2022-06-26 08:20:09.113186
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bs = BoundedSemaphore()
    bs.release() # raise ValueError


# Generated at 2022-06-26 08:20:10.562249
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    s = Semaphore()
    s.release()


# Generated at 2022-06-26 08:20:14.290303
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    obj = Semaphore(3)
    obj.acquire()
    obj.acquire()
    obj.acquire()
    obj.acquire()


# Generated at 2022-06-26 08:20:20.070488
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    try:
        with Condition() as condition_1:
            condition_0 = condition_1
    except:
        pass
    with Condition() as condition_1:
        condition_1 = condition_0
    ioloop_0 = ioloop.IOLoop.current()
    # Wait up to 1 second.
    condition_0.wait(timeout=datetime.timedelta(seconds=1))
    # Wait up to 1 second for a notification.
    condition_0.wait(timeout=ioloop_0.time() + 1)
    # Wait up to 1 second for a notification.
    condition_0.wait(timeout=1)


# Generated at 2022-06-26 08:20:28.473377
# Unit test for method wait of class Event
def test_Event_wait():
    # First test case: wait for more than 0 seconds
    try:
        event = Event()
        future = event.wait(timeout = 1)
    except TypeError:
        print("test_Event_wait: type error")
    except KeyError:
        print("test_Event_wait: key error")
    except ValueError:
        print("test_Event_wait: value error")
    except AttributeError:
        print("test_Event_wait: attribute error")
    except TimeoutError:
        print("test_Event_wait: timeout error")
    except:
        print("test_Event_wait: other error")
    else:
        print("test_Event_wait: event wait successfully")

# Generated at 2022-06-26 08:20:41.032948
# Unit test for method wait of class Event
def test_Event_wait():
    ev = Event()
    ev.set()

    f = ev.wait()
    assert f.result() == None



# Generated at 2022-06-26 08:20:44.573020
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    lock_0 = Lock()
    lock_0.acquire()
    lock_0.release()
    # test for code coverage
    lock_0.acquire()
    lock_0.release()
    lock_0.acquire()
    lock_0.release()



# Generated at 2022-06-26 08:20:54.433857
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    assert not event_0.is_set()
    event_0.set()
    assert event_0.is_set()
    event_0.clear()
    assert not event_0.is_set()
    event_0.set()
    event_0.set()
    assert event_0.is_set()
    event_0.clear()
    event_0.clear()
    assert not event_0.is_set()


# Generated at 2022-06-26 08:20:57.489672
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado.ioloop import IOLoop
    condition = Condition()
    future0 = condition.wait()
    IOLoop.current().start()
    future0.done()
    print(future0.result())
    # Check that the result is True
    assert future0.result() == True, "wait() of condition failed"


# Generated at 2022-06-26 08:21:08.468590
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # create the object with its initializer
    lock_0 = Lock()
    # start the logging of method call
    lock_0._logger.start()
    # method entry
    lock_0.__aenter__()
    # method exit
    lock_0._logger.stop()
    # verify the results
    assert lock_0._logger.result[0].method == '__aenter__', \
        f"Method name mismatch: method name is {lock_0._logger.result[0].method} and should be __aenter__"
    # verify the results
    assert lock_0._logger.result[0].args == (), \
        f"Method args mismatch: args is {lock_0._logger.result[0].args} and should be ()"
    # verify the results
    assert lock_0._logger

# Generated at 2022-06-26 08:21:09.592006
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    lock_0 = Semaphore()
    lock_0.__enter__()


# Generated at 2022-06-26 08:21:12.265023
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    lock_0 = Semaphore()
    loc_0 = lock_0.__repr__()


# Generated at 2022-06-26 08:21:15.796702
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    pass
    # Test: Create Semaphore
    s = Semaphore()
    # Test: Acquire the Semaphore
    s.acquire()
    assert s._value == 0, "_value != 0"


# Generated at 2022-06-26 08:21:24.703550
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    waiters = []  # Waiters we plan to run right now.
    while self._waiters:
        waiter = self._waiters.popleft()
        if not waiter.done():  # Might have timed out.
            waiters.append(waiter)

    for waiter in waiters:
        future_set_result_unless_cancelled(waiter, True)


# Generated at 2022-06-26 08:21:29.459343
# Unit test for method wait of class Condition
def test_Condition_wait():
    lock_0 = Lock()
    condition_0 = Condition()
    assert condition_0 is not None
    assert condition_0.wait() is not None


if __name__ == "__main__":
    test_Condition_wait()
    print("Method wait of class Condition is complete")


# vim: set ts=4 sw=4 sts=4 expandtab:

# Generated at 2022-06-26 08:21:41.405547
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    assert isinstance(lock, Lock)
    lock.release()


# Generated at 2022-06-26 08:21:52.007913
# Unit test for method wait of class Event
def test_Event_wait():
    lock_0 = Event()  # Type: Event

    assert lock_0.wait() is None
    #assert lock_0.wait.__name__ == 'wait'
    #assert lock_0.wait.__doc__ == '\n    Block until the internal flag is true.\n\n    Returns an awaitable, which raises `tornado.util.TimeoutError` after a\n    timeout.\n    '
    assert lock_0.is_set() is False
    #assert lock_0.is_set.__name__ == 'is_set'
    #assert lock_0.is_set.__doc__ == '\n    Return ``True`` if the internal flag is true.\n    '
    assert lock_0.set() is None
    #assert lock_0.set.__name__ == 'set'
    #assert

# Generated at 2022-06-26 08:22:05.351511
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    lock_0 = Lock()

    async def f1():
        await condition_0.wait(None)
        await condition_0.wait(None)
        return

    async def f2():
        await lock_0.acquire()
        condition_0.notify()
        await lock_0.acquire()
        lock_0.release()
        return

    async def f3():
        await lock_0.acquire()
        condition_0.notify()
        await lock_0.acquire()
        await lock_0.release()
        return

    async def f4():
        await lock_0.acquire()
        condition_0.notify()
        await lock_0.acquire()
        lock_0.release()
        return

    async def f5():
        return

# Generated at 2022-06-26 08:22:10.912405
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()
    assert event_0.is_set() == True


# Generated at 2022-06-26 08:22:14.535346
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    lock_0 = Condition()
    print(lock_0.__repr__())


# Generated at 2022-06-26 08:22:16.599243
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore()
    sem.release()



# Generated at 2022-06-26 08:22:22.744798
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore = Semaphore(1)
    async def func0():
        await semaphore.acquire()
        print("acquire")
    t = threading.Thread(target=IOLoop.current().run_sync, args=(func0,))
    t.start()
    time.sleep(1)
    semaphore.release()
    t.join()


# Generated at 2022-06-26 08:22:32.973310
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from tornado.testing import AsyncTestCase, gen_test
    class ExampleTestCase(AsyncTestCase):
        def test_0(self):
           sem = Semaphore(value=1) 
           self.assertEqual(sem._value, 1)
           sem.release()
           self.assertEqual(sem._value, 2)

        @gen_test
        def test_1(self):
            sem = Semaphore(value=0) 
            self.assertEqual(sem._value, 0)
            sem.release()
            await gen.sleep(0)
            self.assertEqual(sem._value, 1)

        @gen_test
        def test_2(self):
            sem = Semaphore(value=2) 
            self.assertEqual(sem._value, 2)
            sem.release

# Generated at 2022-06-26 08:22:44.772690
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    # Test when self._waiters is empty
    lock_0 = Lock()
    cond_0 = Condition()

    cond_0._waiters = collections.deque()

    assert not cond_0._waiters

    cond_0.notify_all()
    
    assert not cond_0._waiters
    
    # Test when self._waiters is not empty
    waiter = Future()
    cond_0._waiters.append(waiter)
    cond_0.notify_all()
    assert waiter.done()
    assert waiter.result()
    
    
    # Test for n > len(self._waiters)
    cond_0._waiters.append(waiter)
    cond_0.notify_all()
    cond_0.notify_all()
    assert waiter.done()
    assert waiter.result

# Generated at 2022-06-26 08:22:49.717760
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    worker_0 = Semaphore()
    worker_0.__aenter__()
    worker_0.__aexit__(None, None, None)


# Generated at 2022-06-26 08:23:14.432957
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    notify_future = condition.notify() # result = None
    assert notify_future == None


# Generated at 2022-06-26 08:23:20.388826
# Unit test for method wait of class Condition
def test_Condition_wait():

    condition = Condition()

    @gen.coroutine
    def waiter():
        gen.sleep(1)
        print("I'll wait right here")
        yield condition.wait()
        print("I'll be notified")

    @gen.coroutine
    def notifier():
        gen.sleep(5)
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)



# Generated at 2022-06-26 08:23:24.294337
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # Tests the functionality of the release method of the BoundedSemaphore class.
    bounded_semaphore_0 = BoundedSemaphore(10)
    bounded_semaphore_0.release()
    # AssertionError: Semaphore released too many times
    # assert bounded_semaphore_0.value(1) == 1
    # assert bounded_semaphore_0.waiter_count() == 0


# Generated at 2022-06-26 08:23:27.819294
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()

    # Testing the return type of method __aenter__ of class Lock
    assert isinstance(lock_0.__aenter__(), Awaitable[None])


# Generated at 2022-06-26 08:23:31.298287
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    lock_0 = Semaphore()

    lock_0.release()
    #assert lock_0.locked()==False


# Generated at 2022-06-26 08:23:33.926084
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()

    with condition_0.notify_all():
        None

    condition_0.notify_all()

    None



# Generated at 2022-06-26 08:23:40.980154
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()

    future_0 = condition_0.wait(timeout=0.2)

    try:
        future_0.set_exception(Exception())
    except AttributeError as exc:
        raise Exception('AttributeError exception was ' + ('raised' if isinstance(exc, AttributeError) else 'not raised'))
    else:
        raise Exception('AttributeError exception was ' + ('raised' if isinstance(AttributeError(), AttributeError) else 'not raised'))
    # attribute_error exception was raised


# Generated at 2022-06-26 08:23:47.232459
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    io_loop_0 = ioloop.IOLoop.current()
    timeout_0 = io_loop_0.time() + 1
    future_0 = condition_0.wait(timeout_0)


# Generated at 2022-06-26 08:23:48.664192
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    assert str(cond) == "<Condition>"


# Generated at 2022-06-26 08:23:56.045321
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    lock_0 = Semaphore(1)
    str_0 = lock_0.__repr__()
    assert str_0 == "<Semaphore [unlocked,value:1]>", 'Expect <Semaphore [unlocked,value:1]>, but get <%s>' % str_0
