

# Generated at 2022-06-26 08:15:08.960717
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    lock_0 = Semaphore("test")
    try:
        lock_1 = lock_0.__aenter__()
        assert False
    except UnsupportedOperation:
        pass


# Generated at 2022-06-26 08:15:11.944987
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    lock = Condition()
    assert lock.__repr__() == "<Condition"



# Generated at 2022-06-26 08:15:15.778859
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:15:17.826463
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem.acquire()
    assert sem.acquire()
    assert sem.acquire()


# Generated at 2022-06-26 08:15:22.180786
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    lock_0 = Lock()
    lock_0.acquire()
    cond_0 = Condition()
    cond_0.notify_all()
    lock_0.release()


# Generated at 2022-06-26 08:15:26.672872
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    future_0 = Future()
    future_0 = future_0.add_done_callback(lambda _: None)
    future_0 = condition_0.wait(timeout=None)
    future_0 = future_0.add_done_callback(lambda _: None)


# Generated at 2022-06-26 08:15:36.318946
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")


    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")


    @gen.coroutine
    def runner():
        yield gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-26 08:15:39.152679
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()


# Generated at 2022-06-26 08:15:46.151007
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    assert condition.__repr__() == "<Condition waiters[0]>"
    condition.notify_all()
    assert condition.__repr__() == "<Condition waiters[0]>"
    ioloop.IOLoop.current().run_sync(test_Condition_notify_all_0)


# Generated at 2022-06-26 08:16:00.024879
# Unit test for method wait of class Condition
def test_Condition_wait():
    import time
    import datetime
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        flag = yield condition.wait(timeout=datetime.timedelta(seconds=1))
        if flag == False:
            print("I'm timed out")
        else:
            print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]

    condition = Condition()
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:16:13.875447
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    lock_0 = Semaphore()
    lock_0.release()


# Generated at 2022-06-26 08:16:22.562224
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    waiter_0 = gen.Task(event_0.wait, timeout=None) # type: Awaitable[None]
    event_1 = Event()
    waiter_1 = Future()
    if not waiter_1.done():
        waiter_1.set_result(None)
    event_2 = Event()
    waiter_2 = Future()
    if not waiter_2.done():
        waiter_2.set_result(None)
    event_3 = Event()
    waiter_3 = Future()
    if not waiter_3.done():
        waiter_3.set_result(None)
    event_4 = Event()
    waiter_4 = Future()
    if not waiter_4.done():
        waiter_4.set_result(None)
    event_5 = Event()
    waiter

# Generated at 2022-06-26 08:16:25.948847
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()
    lock_0 = Lock()
    with lock_0:
        with (yield semaphore_0.acquire()):
            pass
        pass
    pass
    lock_1 = Lock()
    with lock_1:
        with (yield semaphore_0.acquire()):
            pass
        pass
    pass


# Generated at 2022-06-26 08:16:33.891364
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore

    sem = Semaphore(2)

    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)

# Generated at 2022-06-26 08:16:38.221226
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    for l in range(0,10):
        ioloop.IOLoop.current().add_callback(c.notify_all)


# Generated at 2022-06-26 08:16:40.377468
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()


# Generated at 2022-06-26 08:16:45.649401
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    test_semaphore = Semaphore(1)
    test_semaphore.release()
    lock_info = test_semaphore.release()
    assert lock_info == None


# Generated at 2022-06-26 08:16:54.248446
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    """
    Semaphore(value=0, maxsize=1)
    :return:
    """
    sem = Semaphore(value=0, maxsize=1)
    sem.release()
    assert sem.locked() == False
    assert sem.acquire(timeout=0.0) == True
    assert sem.locked() == True
    sem.release()
    assert sem.locked() == False
    assert sem.acquire(timeout=0.0) == True
    assert sem.locked() == True



# Generated at 2022-06-26 08:16:58.333837
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()
    condition_0.notify(2)
    condition_0.notify_all()


# Generated at 2022-06-26 08:17:07.556203
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()
    # let's wait for a notification
    loop = ioloop.IOLoop.current()
    s = loop.time()
    # let's wait for the notification for up to 1 second
    ret = loop.run_sync(
        lambda: cond.wait(timeout=loop.time() + 1)
    )
    e = loop.time()
    ret = e - s
    assert (ret <= 1)
    # let's simulate a notify_all
    # since we are in the current loop and we are not waiting, there will be no effect
    cond.notify_all()
    # let's simulate a notify_all
    # this time we will wait for it
    loop.run_sync(
        lambda: cond.wait(timeout=loop.time() + 1)
    )
    cond.notify_all

# Generated at 2022-06-26 08:17:36.053005
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()


# Generated at 2022-06-26 08:17:38.387534
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()


# Generated at 2022-06-26 08:17:40.142157
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()
    semaphore_0.acquire()

# Generated at 2022-06-26 08:17:43.250463
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    lock_0 = Semaphore()
    lock_1 = lock_0
    lock_1.acquire()


# Generated at 2022-06-26 08:17:51.690326
# Unit test for method wait of class Condition
def test_Condition_wait():
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]

    condition = Condition()
    ioloop.IOLoop.current().run_sync(runner)



# Generated at 2022-06-26 08:18:01.277101
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    test_cases = [
        {"value": 100, "timeout": 3.0},
        {"value": 50, "timeout": None},
    ]

    for test_case in test_cases:
        print (f"\nTest case: {test_case}")
        sem = Semaphore(test_case['value'])
        print (f"\tsemaphore: {sem}")
        print (f"\tsem.acquire: {sem.acquire(test_case['timeout'])}")
        print (f"\tsemaphore: {sem}")
    

# Generated at 2022-06-26 08:18:10.678894
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()

    fut = event.wait()
    print("fut.done", fut.done())
    assert fut.done() == True
    assert fut.result() == None

    event.clear()
    fut_0 = event.wait()
    print("fut_0.done", fut_0.done())
    assert fut_0.done() == False

    event.set()
    assert fut_0.done() == True


# Generated at 2022-06-26 08:18:24.002964
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    async def dummy_ctx_mgr(s: Semaphore) -> None:
        pass

    test_cases = [
        {
            "name": "Semaphore exists",
            "input": {"init_kwargs": {}, "acquire_kwargs": {}},
            "expected_result": {"acquire_result_cls": Future, "acquire_result_obj": True, "waiters": 0},
        },
    ]


# Generated at 2022-06-26 08:18:26.394737
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond = Condition()
    cond.notify(1)


# Generated at 2022-06-26 08:18:29.192484
# Unit test for method wait of class Event
def test_Event_wait():
    """
    event = Event()
    event.wait()
    """


# Generated at 2022-06-26 08:19:01.165648
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    async def test_Lock___aenter___0():
        async with lock:
            print('in test_Lock___aenter___0')
    IOLoop.current().run_sync(test_Lock___aenter___0)


# Generated at 2022-06-26 08:19:03.327005
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    print(cond)


# Generated at 2022-06-26 08:19:04.236052
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()

# Generated at 2022-06-26 08:19:07.873653
# Unit test for method release of class Lock
def test_Lock_release():
    lock_0 = Lock()
    lock_0.release()
    assert True # dummy assertion to mark the end of this test


# Generated at 2022-06-26 08:19:13.884451
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    assert condition_0.__repr__() == "<Condition>"
    condition_0._waiters.append(True)
    assert condition_0.__repr__() == "<Condition waiters[1]>"


# Generated at 2022-06-26 08:19:18.127493
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    waiters = []  # Waiters we plan to run right now.
    while n and self._waiters:
        waiter = self._waiters.popleft()
        if not waiter.done():  # Might have timed out.
            n -= 1
            waiters.append(waiter)

    for waiter in waiters:
        future_set_result_unless_cancelled(waiter, True)


# Generated at 2022-06-26 08:19:23.718032
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    lock_0 = Semaphore()
    str_0 = lock_0.__repr__()
    assert_(not (str_0 != '<Semaphore unlocked,value:1>'))


# Generated at 2022-06-26 08:19:26.995636
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert isinstance(event, Event)
    assert not event.is_set()

    event.set()
    assert event.is_set()


# Generated at 2022-06-26 08:19:34.368713
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    lock = Lock()
    cond = Condition()
    
    async def waiter0():
        await lock.acquire()
        print("I am waiter 0")
        await cond.wait()
        print("I am waiter 0, I am notified")
        await lock.release()

    async def waiter1():
        await lock.acquire()
        print("I am waiter 1")
        await cond.wait()
        print("I am waiter 1, I am notified")
        await lock.release()

    async def waiter2():
        await lock.acquire()
        print("I am waiter 2")
        await cond.wait()
        print("I am waiter 2, I am notified")
        await lock.release()

    async def notifier():
        await lock.acquire()
        print("About to notify all waiter")
        cond.notify_all

# Generated at 2022-06-26 08:19:43.757792
# Unit test for method set of class Event
def test_Event_set():
    lock_0 = Lock()
    event_lock = Event()
    event_lock_0 = Event()
    
    # Test set when event set is False and no waiters
    event_lock.set()
    assert event_lock._value is True
    # Test set when event set is True and no waiters
    event_lock.set()
    assert event_lock._value is True
    # Test set when event set is False, set to True and no waiters
    event_lock.clear()
    event_lock.set()
    assert event_lock._value is True
    # Test set when event set is True, set to True and no waiters
    event_lock.set()
    event_lock.set()
    assert event_lock._value is True

    # Test set when event set is False and waiters
    asyc_wait

# Generated at 2022-06-26 08:20:12.402495
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():

    sem_0 = BoundedSemaphore()

    try:
        sem_0.release()
        assert False
    except ValueError as e_0:
        print(str(e_0))


# Generated at 2022-06-26 08:20:18.100625
# Unit test for method release of class Lock
def test_Lock_release():
    # Creating the lock object
    lock_1 = Lock()
    # Testing if it is locked
    assert lock_1._block.is_set() != True, "Lock not locked when it should be"
    # Attempting an unlock
    lock_1.release()


# Generated at 2022-06-26 08:20:21.085393
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.clear()
    event_0.wait()


# Generated at 2022-06-26 08:20:25.698469
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    flag = False
    @gen.coroutine
    def waiter():
        yield condition.wait()
        nonlocal flag
        flag = True

    waiter()
    @gen.coroutine
    def notifier():
        condition.notify()

    notifier()
    ioloop.IOLoop.current().run_sync(lambda: gen.sleep(1))
    assert flag


# Generated at 2022-06-26 08:20:28.854571
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    lock_0.__aexit__(None, None, None)




# Generated at 2022-06-26 08:20:31.529568
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:20:39.162113
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(value=1)
    waiters = deque([])
    sem._value = 0
    sem._waiters = waiters
    waiter0 = Future()
    waiter0.set_result(_ReleasingContextManager(sem))
    waiters.append(waiter0)
    waiter1 = Future()
    waiters.append(waiter1)
    waiter2 = Future()
    waiters.append(waiter2)
    try:
        sem.release()
    except Exception as ex:
        print(ex.args)
    # Check that waiter0 is expected
    exp_waiters = deque([])
    exp_waiters.append(waiter1)
    exp_waiters.append(waiter2)

# Generated at 2022-06-26 08:20:46.687166
# Unit test for method wait of class Condition
def test_Condition_wait():
    # Create an instance of Condition
    condition_0 = Condition()

    def print_1():
        print("About to notify")

    def print_2():
        print("Done notifying")

    # Wait for waiter() and notifier() in parallel
    runner_0 = gen.multi([condition_0.wait(), gen.multi([print_1(), print_2()])])
    runner_1 = condition_0.wait()
    runner_1.add_done_callback(lambda _: condition_0.notify())
    ioloop_0 = ioloop.IOLoop.current()
    ioloop_0.run_sync(runner_0)




# Generated at 2022-06-26 08:20:47.537499
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()


# Generated at 2022-06-26 08:20:53.434918
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    # specify the return type manually
    __repr__ = condition_0.__repr__()
    assert isinstance(__repr__, str)
    assert __repr__ == '<Condition waiters[0]>'


# Generated at 2022-06-26 08:21:21.667092
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Create a lock
    lock_0 = Lock()

    # Try to lock the lock
    lock_0.acquire()


# Generated at 2022-06-26 08:21:25.774746
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c_0 = Condition()
    c_0.waiters = [[]]
    assert c_0.__repr__() == '<Condition waiters[1]>'


# Generated at 2022-06-26 08:21:29.081545
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    lock_0 = Condition()
    assert lock_0.__repr__() == '<Condition>'


# Generated at 2022-06-26 08:21:33.451761
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() is False
    event.set()
    assert event.is_set() is True
    event.wait()
    return 1



# Generated at 2022-06-26 08:21:42.093859
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore(1)
    release_obj_0 = Semaphore(1)
    release_obj_0._value = 0
    release_obj_0._waiters = collections.deque((Future(), Future(), Future()))
    release_obj_0._waiters[0]._state = gen.TimeoutError()

    waiter_0 = Future()  # type: Future[_ReleasingContextManager]
    waiter_0._state = _TimeoutGarbageCollector()
    waiter_0._state._waiters = collections.deque()
    waiter_0._state._waiters.appendleft(Future())
    waiter_0._state._waiters.appendleft(Future())
    waiter_0._state._waiters.appendleft(Future())


# Generated at 2022-06-26 08:21:52.377600
# Unit test for method wait of class Condition
def test_Condition_wait():
    # Test for condition.wait() without timeout
    def test1():
        # Prepare environment
        from tornado import gen
        from tornado.ioloop import IOLoop
        from tornado.locks import Condition

        condition = Condition()

        async def waiter():
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")

        async def notifier():
            print("About to notify")
            condition.notify()
            print("Done notifying")

        async def runner():
            # Wait for waiter() and notifier() in parallel
            await gen.multi([waiter(), notifier()])

        IOLoop.current().run_sync(runner)
    test1()

    # Test for condition.wait() with timeout
    def test2():
        from tornado import gen
        from tornado.ioloop import IOL

# Generated at 2022-06-26 08:21:56.670483
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # @test {"skip": true}
    lock_0 = Semaphore()
    lock_0.release()
    print("Test of method release of class Semaphore passed")

# Generated at 2022-06-26 08:21:59.316226
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()


# Generated at 2022-06-26 08:22:00.733754
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    test_case_0()

# Generated at 2022-06-26 08:22:12.580599
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    # Test case when the internal flag is True
    event.set()
    assert(event.is_set() == True)
    assert(event.wait() is not None)

    # Test case when the internal flag is False
    event.clear()
    assert(event.wait() is not None)

    # Test case when timeout is not None, and timeout is an absolute timestamp
    io_loop = ioloop.IOLoop.current()
    timeout = io_loop.time() + 1
    event.clear()
    assert(event.wait(timeout) is not None)

    # Test case when timeout is not None, and timeout is a timedelta
    timeout = datetime.timedelta(seconds=1)
    event.clear()
    assert(event.wait(timeout) is not None)



# Generated at 2022-06-26 08:23:10.664323
# Unit test for method notify of class Condition
def test_Condition_notify():
    lock_0 = Lock()
    res_0 = type(lock_0) is Lock
    assert res_0



# Generated at 2022-06-26 08:23:13.210020
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()


# Generated at 2022-06-26 08:23:15.698883
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:23:22.962809
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    print("Testing method Lock.__aenter__...")
    lock_0 = Lock()
    try:
        lock_0.__aenter__()
    except Exception as exp:
        print("Exception happened:")
        print(exp)
    print("Method Lock.__aenter__ passed test.")


# Generated at 2022-06-26 08:23:25.165476
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    print(condition.__repr__())


# Generated at 2022-06-26 08:23:27.224906
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    #TODO: to be implemented
    print('Method acquire in class Semaphore not yet implemented')


# Generated at 2022-06-26 08:23:32.898406
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    lock_0 = Semaphore()

    try:
        lock_0.__aenter__()
    except Exception as e:
        if 'async with' not in str(e):
            raise Exception(e)

# Test for method __aexit__ of class Semaphore

# Generated at 2022-06-26 08:23:36.602832
# Unit test for method wait of class Condition
def test_Condition_wait():
    cond = Condition()
    print("Test wait...")
    cond.wait()
    print("Wait test done!")


# Generated at 2022-06-26 08:23:38.959112
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    lock = Semaphore()
    print(lock.__repr__())
    lock.release()
    print(lock.__repr__())


# Generated at 2022-06-26 08:23:43.220759
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    try:
        gen.wait_for(event, timeout=0.01)
    except gen.TimeoutError:
        print("Is_timeout")

