

# Generated at 2022-06-26 08:14:50.923057
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond_0 = Condition()
    task_0 = gen.Task(cond_0.wait)
    cond_0.notify()
    task_0.result()


# Generated at 2022-06-26 08:14:53.247793
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    
    # Init an object of Semaphore
    sem = Semaphore()
    print(sem.__repr__())

    # Init an object of Semaphore
    sem = Semaphore(10)
    print(sem.__repr__())


# Generated at 2022-06-26 08:14:54.977285
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    future_0 = condition.wait()
    future_1 = condition.wait()
    assert not future_0.done()
    assert not future_1.done()
    condition.notify_all()
    assert future_0.result() == True
    assert future_1.result() == True
    return True


# Generated at 2022-06-26 08:14:59.736250
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    try:
        lock_0.__aexit__(None, None, None)
    except RuntimeError:
        pass
    except:
        print("Unexpected error:", sys.exc_info()[0])


# Generated at 2022-06-26 08:15:02.625945
# Unit test for method release of class Lock
def test_Lock_release():
    test_case_0()


# Generated at 2022-06-26 08:15:05.160503
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore(1)
    assert s.acquire() == True
    assert s.acquire() == False


# Generated at 2022-06-26 08:15:08.909844
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # __aenter__: Acquires the semaphore when used with async with
    sem = Semaphore()
    assert(sem.is_set() == False)
    sem.__aenter__()
    assert(sem.is_set() == True)



# Generated at 2022-06-26 08:15:12.653170
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    event_0 = Event()
    semaphore_0 = Semaphore(0)
    semaphore_1 = Semaphore(4)
    semaphore_0.acquire()

# Generated at 2022-06-26 08:15:16.503995
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()



# Generated at 2022-06-26 08:15:22.284563
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # Initialize a BoundedSemaphore object with value 1
    boundedSemaphore = BoundedSemaphore(1)
    # It is OK to call release() once
    boundedSemaphore.release()
    # It is NOT OK to call release() twice
    try:
        boundedSemaphore.release()
    except:
        print("It is NOT OK to call release() twice")


# Generated at 2022-06-26 08:15:31.094796
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    event_0 = Event()
    lock_1 = Lock()
    lock_1.__aenter__()
    lock_1.release()
    event_0.set()


# Generated at 2022-06-26 08:15:41.313794
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(0)
    assert sem._value == 0
    waiter = Future()
    sem._waiters.append(waiter)
    assert sem._value == 0

    # call acquire
    result = sem.acquire(timeout=None)
    assert sem._value == -1
    assert waiter.set_result(_ReleasingContextManager(sem))
    assert waiter.done()
    assert sem._waiters.popleft() == waiter
    assert sem._value == -1


# Generated at 2022-06-26 08:15:42.220953
# Unit test for method wait of class Condition
def test_Condition_wait():
    c = Condition()
    c.wait()


# Generated at 2022-06-26 08:15:47.140561
# Unit test for method wait of class Condition
def test_Condition_wait():
    event_0 = Event()
    event_0.set()
    assert event_0.is_set()
    # assert event_0.wait()
    # assert event_0.wait(timeout=1)
    # assert event_0.wait(timeout=datetime.timedelta(seconds=1))


# Generated at 2022-06-26 08:15:54.317293
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    waiter = Future()  # type: Future[bool]
    condition_0._waiters.append(waiter)
    if not bool(condition_0._waiters):
        waiter.done()
        waiter.add_done_callback((lambda _: ioloop.IOLoop.current().remove_timeout(timeout_handle)))
    return waiter


# Generated at 2022-06-26 08:16:00.504702
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    event_0 = Event()
    semaphore_0 = Semaphore()
    try:
        semaphore_0.__aexit__(TypeError, None, None)
        semaphore_0.__aexit__(TypeError, TypeError(), TypeError())
        event_0.set()
    except:
        event_0.set()
    event_0.wait()


# Generated at 2022-06-26 08:16:03.066774
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.wait(1)


# Generated at 2022-06-26 08:16:09.046159
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.wait(timeout=None)
    assert isinstance(event_0.wait(),gen.Awaitable)
    event_1 = Event()
    event_1.wait(timeout=2.0)
    assert isinstance(event_1.wait(),gen.Awaitable)
    event_2 = Event()
    event_2.wait(datetime.datetime.now())
    assert isinstance(event_2.wait(),gen.Awaitable)


# Generated at 2022-06-26 08:16:11.292781
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_1 = Lock()
    lock_0.release()
    lock_1.release()


# Generated at 2022-06-26 08:16:14.488650
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    semaphore_0=Semaphore()
    if semaphore_0._value == 1:
        semaphore_0._value = 0
    if semaphore_0._value == 0:
        semaphore_0.release


# Generated at 2022-06-26 08:16:25.749711
# Unit test for method notify of class Condition
def test_Condition_notify():
    event_0 = Event()
    event_0.set()
    event_0.wait()
    event_0.is_set()
    event_0.clear()



# Generated at 2022-06-26 08:16:30.618964
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():

    semaphore_0 = Semaphore()
    print(repr(semaphore_0))
    #print(semaphore_0.acquire(1))
    print(repr(semaphore_0))
    print(semaphore_0._value)


# Generated at 2022-06-26 08:16:40.895739
# Unit test for method notify of class Condition
def test_Condition_notify():
    ioloop.IOLoop.current().stop()
    event_0 = Event()
    event_0.set()
    event_0.clear()
    event_0.is_set()
    event_0.wait()
    event_0.clear()
    cond_0 = Condition()
    cond_0.notify_all()
    cond_0.wait()
    cond_0.notify()
    cond_0.notify(5)


# Generated at 2022-06-26 08:16:52.638257
# Unit test for method notify of class Condition
def test_Condition_notify():
    event_0 = Event()

    async def waiter_0():
        print("I'll wait right here")
        await event_0.wait()
        print("I'm done waiting")

    async def notifier_0():
        print("About to notify")
        event_0.notify()
        print("Done notifying")

    async def runner_0():
        await gen.multi([waiter_0(), notifier_0()])
        print("Runner is done")

    ioloop.IOLoop.current().run_sync(runner_0)
    print("Test finished")


# Generated at 2022-06-26 08:16:55.395999
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    assert isinstance(event_0, Event)
    event_0.set()
    assert event_0.is_set()

# # Unit test for method clear of class Event

# Generated at 2022-06-26 08:16:58.695003
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    event_0 = Event()
    assert isinstance(event_0, Condition) == True
    assert repr(Condition()) == "<Condition>"


# Generated at 2022-06-26 08:17:06.479347
# Unit test for method wait of class Condition
def test_Condition_wait():
    io_loop = ioloop.IOLoop.current()
    condition = Condition()
    waiters_0 = []
    timeout_0 = io_loop.time() + 1
    n_0 = 1
    condition.wait(timeout=timeout_0)
    waiters_0.append(waiter)
    while n_0 and self._waiters:
        waiter = self._waiters.popleft()
        if not waiter.done():
            n_0 -= 1
            waiters_0.append(waiter)

    for waiter in waiters_0:
        future_set_result_unless_cancelled(waiter, True)



# Generated at 2022-06-26 08:17:09.522499
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()


# Generated at 2022-06-26 08:17:18.613008
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore()

    a = [True, True, True]
    counter = 0
    async def worker(worker_id):
        fut = sem.acquire()
        result = await fut
        if result._obj != sem:
            a[worker_id] = False
        nonlocal counter
        counter += 1
        print("Worker {} is working".format(worker_id))

        await gen.sleep(0)
        sem.release()
        print("Worker {} is done".format(worker_id))

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
        while counter < 3:
            await gen.sleep(0)

    ioloop.IOLoop.current().run_sync(runner)
    assert all(a) == True

# Generated at 2022-06-26 08:17:20.194388
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    print('test_Semaphore___repr__()')
    obj = Semaphore()
    print('obj = {}'.format(obj))


# Generated at 2022-06-26 08:17:36.271738
# Unit test for method set of class Event
def test_Event_set():
    # Case 0
    test_case_0()



# Generated at 2022-06-26 08:17:40.061015
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond_0 = Condition()
    print(cond_0.__repr__())
    cond_0.notify()
    print(cond_0.__repr__())



# Generated at 2022-06-26 08:17:41.624686
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    pass


# Generated at 2022-06-26 08:17:46.289154
# Unit test for method notify of class Condition
def test_Condition_notify():
    # Create Condition object
    condition_0 = Condition() # Create Condition object
    # Call function condition.notify with argument n: 0
    condition_0.notify()


# Generated at 2022-06-26 08:17:54.262452
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem_0 = Semaphore()
    sem_1 = Semaphore(0)
    sem_2 = Semaphore(3)
    # Call sem_0.acquire() and reject it
    try:
        sem_0.acquire(4)
    except gen.TimeoutError:
        print("Semaphore acquire is reject by set timeout")
    else:
        raise "sem_0.acquire() should raise gen.TimeoutError"
    # Call sem_0.acquire() and accept it
    try:
        sem_0.acquire()
    except gen.TimeoutError:
        raise "sem_0.acquire() should not raise gen.TimeoutError"
    else:
        print("Semaphore acquire is accepted")
    # Call sem_1.acquire() and reject it

# Generated at 2022-06-26 08:17:58.761741
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert not event.is_set()

    event.set()
    assert event.is_set()

    event.clear()
    assert not event.is_set()



# Generated at 2022-06-26 08:18:12.461685
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond = Condition()
    event = Event()

    async def coro_func_0():
        await event.wait()
        cond.notify()
        return 1

    async def coro_func_1():
        await event.wait()
        cond.notify()
        return 2

    async def coro_func_2():
        await event.wait()
        cond.notify()
        return 3
        
    async def test():
        c_0, c_1, c_2 = await gen.multi([coro_func_0(), coro_func_1(), coro_func_2()])
        print(c_0)
        print(c_1)
        print(c_2)

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(test)

# Generated at 2022-06-26 08:18:17.350522
# Unit test for method notify of class Condition
def test_Condition_notify():
    test_Condition_notify_0()
    test_Condition_notify_1()
    test_Condition_notify_2()
    test_Condition_notify_3()


# Generated at 2022-06-26 08:18:24.284232
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Initialize a semaphore with a value equal to 1
    semaphore_0 = Semaphore(1)
    # Use acquire() to acquire the lock of semaphore_0
    # The call to acquire is expected to return a Future[None]
    future_0 = semaphore_0.acquire()
    # Check if future_0 is an awaitable
    try:
        future_0.__await__()
        # The future_0 is an awaitable
    except:
        # future_0 is not an awaitable
        # This is an error condition.
        raise AssertionError('Unexpected behavior')
    # Check if the value of the semaphore is 0
    if semaphore_0._value != 0:
        raise AssertionError('semaphore_0._value != 0')
    # Release the

# Generated at 2022-06-26 08:18:26.690907
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()


# Generated at 2022-06-26 08:18:45.743711
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()
    Future_0 = semaphore_0.acquire()


# Generated at 2022-06-26 08:18:49.392194
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    """Test method __aenter__ of class Semaphore"""

    test_case_0()


# Generated at 2022-06-26 08:18:56.701056
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    try:
        lock_0.__aenter__()
    except Exception as e:
        print(e)

async def test_case_1():
    # test_Semaphore_1 namespace begin
    semaphore_0 = Semaphore()

    async def worker(worker_id: int) -> None:
        await semaphore_0.acquire()
        try:
            pass
        finally:
            semaphore_0.release()
    # test_Semaphore_1 namespace end



# Generated at 2022-06-26 08:18:58.286338
# Unit test for method set of class Event
def test_Event_set():
    event = Event()


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 08:19:03.897329
# Unit test for method wait of class Condition
def test_Condition_wait():
    io_loop = ioloop.IOLoop.current()
    condition = Condition()
    #
    waiter = condition.wait(timeout=io_loop.time() + 1)
    #
    # should not block here, since no one have notified condition!
    #

# Generated at 2022-06-26 08:19:07.500540
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(1)
    condition_0.notify_all()


# Generated at 2022-06-26 08:19:18.547094
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    # test case 0:
    print(condition_0._timeouts)
    condition_0._timeouts += 1
    print(condition_0._timeouts)
    condition_0._timeouts = 0
    print(condition_0._timeouts)

    # test case 1:
    waiter_0 = Future()
    waiter_1 = Future()
    waiter_2 = Future()
    waiter_3 = Future()
    waiter_4 = Future()
    waiter_5 = Future()
    waiter_6 = Future()
    waiter_7 = Future()
    waiter_8 = Future()

    condition_0._waiters.append(waiter_0)
    condition_0._waiters.append(waiter_1)
    condition_0._waiters.append(waiter_2)
    condition_0

# Generated at 2022-06-26 08:19:30.100780
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    from tornado.gen import convert_yielded
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.locks import Condition

    condition = Condition()

    @gen.coroutine
    def waiter_0():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def waiter_1():
        print("I'll wait right here too")
        yield condition.wait()
        print("I'm done waiting too")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")


# Generated at 2022-06-26 08:19:35.224826
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore = Semaphore()
    x = Future()
    semaphore.acquire().add_done_callback(test_Semaphore_acquire_callback)


# Generated at 2022-06-26 08:19:40.851025
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    instance_0 = Semaphore()
    str_0 = instance_0.__repr__()
    assert str_0 == "<tornado.locks.Semaphore [unlocked,value:1]>"


# Generated at 2022-06-26 08:19:57.808219
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    pass


# Generated at 2022-06-26 08:20:01.783707
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test Case 0:
    condition_0 = Condition()
    # Test Case 1:
    condition_1 = Condition()
    condition_1._waiters.append(Future())
    condition_1._waiters.append(Future())
    condition_1._waiters.append(Future())
    condition_1._waiters.append(Future())



# Generated at 2022-06-26 08:20:11.962297
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()

    # Test for method notify, of class Condition.
    # test for notify signal 1 waiter
    def waiter_0():
        print("I'll wait right here")
        yield condition_0.wait()
        print("I'm done waiting")

    print("About to notify")
    condition_0.notify()
    print("Done notifying")
    ioloop.IOLoop.current().run_sync(waiter_0)


# Generated at 2022-06-26 08:20:16.482105
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    semaphore_0 = Semaphore()
    assert semaphore_0.__repr__() == "<Semaphore waiters[0]>"
    return "pass"


# Generated at 2022-06-26 08:20:27.845626
# Unit test for method wait of class Condition
def test_Condition_wait():
    import random

    @gen.coroutine
    def _():
        condition = Condition()
        yield condition.wait()
        # yield condition.wait(1)

    @gen.coroutine
    def notify():
        print("notify")
        condition.notify()

    @gen.coroutine
    def wait():
        print("wait")
        yield condition.wait()
        # yield condition.wait(1)

    @gen.coroutine
    def wait_multi():
        print("wait_multi")
        yield gen.multi([wait(), wait()])

    @gen.coroutine
    def test():
        yield wait_multi()
        yield notify()
        yield notify()
        yield notify()
        yield wait()

    ioloop.IOLoop.current().run_sync(test)


# Generated at 2022-06-26 08:20:34.728555
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:20:40.385504
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from typing import Awaitable

    semaphore = Semaphore()

    future = semaphore.__aenter__()  # type: Awaitable
    print("future:")
    print(future)


# Generated at 2022-06-26 08:20:42.904617
# Unit test for method set of class Event
def test_Event_set():
    e = Event()
    e.set()
    assert e.is_set()


# Generated at 2022-06-26 08:20:46.839716
# Unit test for method release of class Lock
def test_Lock_release():
    lock_0 = Lock()
    lock_0.release()
    assert isinstance(lock_0, Lock)


# Generated at 2022-06-26 08:20:50.617594
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    future = event.wait()
    # event.set()
    print(future)

test_Event_wait()

# Generated at 2022-06-26 08:21:24.703153
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    print("in test_Semaphore___aexit__")
    print("---")


# Generated at 2022-06-26 08:21:30.825959
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from mock import Mock
    from mock import call
    from mock import patch

    # get the value of parameter _waiters
    _waiters = mock_Semaphore.return_value._waiters


    # mock the object
    mock_Semaphore.return_value.release()


    # release the lock
    mock_Semaphore.return_value.release()


    # The Lock is released and will be available for the next waiter
    lock_status = mock_Semaphore.return_value.release()

    lock_status
    # mock_Semaphore.return_value.release.assert_called_with()




# Generated at 2022-06-26 08:21:34.077628
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    print(condition_0)

## Unit test for method wait of class Condition

# Generated at 2022-06-26 08:21:38.381603
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Create an instance of _ReleasingContextManager
    lock_0 = Lock()
    awaitables = [lock_0.acquire()]
    awaitable = awaitables[0]
    print(awaitable)
    

# Generated at 2022-06-26 08:21:43.699583
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    lock_0.__aexit__(None, None, None)
    print('test case lock_0.__aexit__(None, None, None) executed')
    print('')



# Generated at 2022-06-26 08:21:49.733273
# Unit test for method wait of class Condition
def test_Condition_wait():
    cond = Condition()
    async def foo():
        # cond.wait()
        # cond.wait(timeout = 1)
        # cond.wait(timeout = datetime.timedelta(1))
        cond.wait(timeout = datetime.timedelta(seconds=1))
    IOLoop.current().run_sync(foo)


# Generated at 2022-06-26 08:21:54.597110
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.set()
    future_0 = event_0.wait()
    future_0.add_done_callback(lambda f: print(f.result()))



# Generated at 2022-06-26 08:22:00.890912
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore_0 = Semaphore()
    semaphore_0.release()

test_case_0()
test_Semaphore_release()
#
# Semaphore
#
# ======================================================================================================================
# ======================================================================================================================
# ======================================================================================================================

# Generated at 2022-06-26 08:22:05.170480
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:22:12.257975
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    lock_0.__aexit__(RuntimeError, RuntimeError(), None)
    lock_0.__aexit__(None, None, None)
    lock_0.__aexit__(RuntimeError, TimeoutError(), None)


# Generated at 2022-06-26 08:23:24.392417
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    test_case_0()

if __name__ == "__main__":
    print("Testing Semaphore.acquire()")
    print("===========================")
    test_Semaphore_acquire()

# Generated at 2022-06-26 08:23:26.539707
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    pass

# Generated at 2022-06-26 08:23:28.063747
# Unit test for method wait of class Event
def test_Event_wait():
    my_event = Event()
    my_event.set()
    my_event.wait()


# Generated at 2022-06-26 08:23:36.604284
# Unit test for method wait of class Event
def test_Event_wait():
    ev = Event()
    print("event has set:",ev.is_set())
    ev.clear()
    print("event has cleared:",not ev.is_set())
    ev.set()
    print("event has set:", ev.is_set())
    print("event wait...")
    ev.wait()
    print("event 's set has been set:", ev.is_set())


# Generated at 2022-06-26 08:23:40.458285
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    try:
        assert condition_0.__repr__() == '<Condition waiters[0]>'
    except:
        raise


# Generated at 2022-06-26 08:23:43.004461
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    obj = Condition()
    obj.__repr__()



# Generated at 2022-06-26 08:23:48.095897
# Unit test for method release of class Lock
def test_Lock_release():
    semaphore_lock = Lock()
    semaphore_lock.release()

if __name__ == "__main__":
    test_case_0()
    test_Lock_release()

# Generated at 2022-06-26 08:23:51.273336
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    semaphore_0 = Semaphore()
    test_case_0()


# Generated at 2022-06-26 08:24:02.500244
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    print("\nTest Semaphore Release()")
    # Create Semaphore
    semaphore_0 = Semaphore()
    print("semaphore_0 = Semaphore()")
    print("semaphore_0._value = {0}".format(semaphore_0._value))
    print("semaphore_0._waiters = {0}".format(semaphore_0._waiters))

    # Create Semaphore
    semaphore_1 = Semaphore(2)
    print("semaphore_1 = Semaphore(2)")
    print("semaphore_1._value = {0}".format(semaphore_1._value))
    print("semaphore_1._waiters = {0}".format(semaphore_1._waiters))

    # Create Semaphore

# Generated at 2022-06-26 08:24:07.171844
# Unit test for method set of class Event
def test_Event_set():
    ev = Event()
    assert ev.is_set() == False

    new_ev = ev.set()
    assert new_ev == None

    assert ev.is_set() == True
