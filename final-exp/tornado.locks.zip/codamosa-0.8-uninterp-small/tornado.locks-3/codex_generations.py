

# Generated at 2022-06-26 08:15:04.880358
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    bounded_semaphore = BoundedSemaphore()
    with pytest.raises(RuntimeError):
        bounded_semaphore.__enter__()


# Generated at 2022-06-26 08:15:12.047036
# Unit test for method wait of class Event
def test_Event_wait():
    # Check that wait of a set Event returns immediately.
    event_0 = Event()
    event_0.set()
    assert event_0.wait() is None
    # Check that wait on an unset Event blocks.
    event_1 = Event()
    assert event_1.is_set() == False
    ioloop_0 = ioloop.IOLoop()
    event_1.wait()
    assert event_1.is_set() == True


# Generated at 2022-06-26 08:15:16.082757
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    res_0 = lock_0.__aenter__()
    # assert res_0 == None


# Generated at 2022-06-26 08:15:19.134925
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    bounded_semaphore_0 = Semaphore()
    try:
        bounded_semaphore_0.__aexit__(None, None, None)
    except TypeError as e:
        assert type(e) is TypeError



# Generated at 2022-06-26 08:15:27.181653
# Unit test for method wait of class Event
def test_Event_wait():
    # Test case 1: Event is not set
    test_event_1 = Event()
    assert test_event_1._value == False
    assert test_event_1.is_set() == False

    # Test case 2: Event is set
    test_event_2 = Event()
    test_event_2.set()
    assert test_event_2._value == True
    assert test_event_2.is_set() == True

    # Test case 3: await event.wait()
    test_event_3 = Event()
    # test_event_3.set()
    test_result_3 = []
    async def waiter_3():
        print("Waiting for event")
        await test_event_3.wait()
        test_result_3.append("Not waiting this time")
        await test_event_3.wait

# Generated at 2022-06-26 08:15:28.412095
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    aLock = Lock()
    await aLock.__aenter__()


# Generated at 2022-06-26 08:15:30.930811
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    # Create an instance of class Condition
    condition_0 = Condition()
    # Call method notify_all of condition_0
    condition_0.notify_all()


EventResult = Optional[bool]



# Generated at 2022-06-26 08:15:34.921193
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    print('Unit test for method __repr__ of class Condition')
    condition_0 = Condition()
    str_0 = condition_0.__repr__()
    print(str_0)



# Generated at 2022-06-26 08:15:36.953018
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    bounded_semaphore_0 = BoundedSemaphore()
    str_0 = str(bounded_semaphore_0)


# Generated at 2022-06-26 08:15:39.367349
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_1 = Event()
    event_1.set()
    event_0.set()


# Generated at 2022-06-26 08:16:02.852929
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    def event_wait_1():
        event.wait()
        return True
    gen.multi([event_wait_1])


# Generated at 2022-06-26 08:16:05.965926
# Unit test for method notify of class Condition
def test_Condition_notify():
    """Tests notify"""
    o = Condition()
    o.notify()
    o.notify(1)


# Generated at 2022-06-26 08:16:07.518491
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    bounded_semaphore_0 = BoundedSemaphore()


# Generated at 2022-06-26 08:16:13.561821
# Unit test for method set of class Event
def test_Event_set():
    event_test = Event()
    event_test.set()
    assert event_test.is_set() == True
    event_test.clear()
    assert event_test.is_set() == False


# Generated at 2022-06-26 08:16:18.259462
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    print("Now in test_Semaphore_acquire")
    semaphore_0 = Semaphore()
    semaphore_0.acquire()
    print("Passed test case of Semaphore.acquire!")


# Generated at 2022-06-26 08:16:32.313314
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()
    # Test below will fail.

    result_0 = semaphore_0.acquire(timeout=None)
    print("result_0: ", result_0)


if __name__ == '__main__':
    test_case_0()
    test_Semaphore_acquire()

# Tested in Python 3.7
# Tested in Tornado 6.0.2


# Reference:
# - https://github.com/tornadoweb/tornado/blob/master/tornado/locks.py
# - https://github.com/tornadoweb/tornado/blob/master/tornado/ioloop.py
# - https://github.com/tornadoweb/tornado/blob/master/tornado/concurrent.py
# - https://github.com

# Generated at 2022-06-26 08:16:46.436402
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    bounded_semaphore_0 = BoundedSemaphore()
    bounded_semaphore_0.wait()
    bounded_semaphore_0._value = 0
    bounded_semaphore_0.acquire()
    bounded_semaphore_0.wait()
    bounded_semaphore_0.wait()
    bounded_semaphore_0._value = 1
    # wait() does not return anything so the following lines will generate an error
    # bounded_semaphore_0.wait()
    bounded_semaphore_0._value = 0
    # wait() does not return anything so the following lines will generate an error
    # bounded_semaphore_0.wait()
    bounded_semaphore_0._value = 0
    # wait() does not return anything so the following lines will generate an error
    # bounded_sem

# Generated at 2022-06-26 08:16:54.605679
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:16:56.895141
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()



# Generated at 2022-06-26 08:17:04.021393
# Unit test for method wait of class Event
def test_Event_wait():
    async def run():

        event = Event()

        async def waiter():
            print("Waiting for event")
            await event.wait()
            print("Not waiting this time")
            await event.wait()
            print("Done")

        async def setter():
            print("About to set the event")
            event.set()

        await gen.multi([waiter(), setter()])

    loop = ioloop.IOLoop.current()
    loop.run_sync(run)


# Generated at 2022-06-26 08:17:37.225210
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Create an instance of Semaphore
    semaphore_0 = Semaphore(1)

    # Invoke method acquire of semaphore_0
    invoke_Semaphore_acquire(semaphore_0)


# Generated at 2022-06-26 08:17:40.141397
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()

    object_0 = semaphore_0.acquire(timeout=0.1)



# Generated at 2022-06-26 08:17:48.224345
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    bounded_semaphore_0 = BoundedSemaphore()
    try:
        bounded_semaphore_0.__aexit__(None, None, None)
    except Exception as raisedException:
        print("Exception caught: ", str(raisedException), "\n")
    bounded_semaphore_0.__aenter__()


# Generated at 2022-06-26 08:17:55.513178
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    bounded_semaphore_0 = BoundedSemaphore()
    #
    # x = bounded_semaphore_0.notify_all()
    #
    # assert x == None
    #
    # bounded_semaphore_0.notifyAll()
    #
    # pass
    pass


# Generated at 2022-06-26 08:17:58.251611
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(1)


# Generated at 2022-06-26 08:18:12.065957
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bounded_semaphore_0 = BoundedSemaphore()
    bounded_semaphore_0.release()
    bounded_semaphore_0.release()
    bounded_semaphore_0.release()
    bounded_semaphore_1 = BoundedSemaphore(9)
    bounded_semaphore_1.release()
    bounded_semaphore_1.release()
    bounded_semaphore_1.release()
    bounded_semaphore_2 = BoundedSemaphore()
    bounded_semaphore_2.release()
    bounded_semaphore_2.release()
    bounded_semaphore_2.release()
    bounded_semaphore_3 = BoundedSemaphore(3)
    bounded_semaphore_3.release()
    bounded_semaphore_3.release()

# Generated at 2022-06-26 08:18:18.223031
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    bounded_semaphore_0 = BoundedSemaphore()
    bounded_semaphore_1 = BoundedSemaphore()
    bounded_semaphore_0.acquire()
    bounded_semaphore_1.acquire()


# Generated at 2022-06-26 08:18:20.876312
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:18:24.200537
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.acquire(0)
    lock_0.release()


# Generated at 2022-06-26 08:18:27.916182
# Unit test for method wait of class Condition
def test_Condition_wait():
    bounded_semaphore_0 = BoundedSemaphore()
    bounded_semaphore_0.wait()


# Generated at 2022-06-26 08:18:48.233041
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0._block = Semaphore()
    lock_0._block._value = 0
    lock_0._block._waiters = deque()
    lock_0.acquire = lambda : lock_0._block.acquire()
    lock_0.release = lambda : lock_0._block.release()
    lock_0.__aenter__ = lambda : lock_0.acquire()
    from tornado.ioloop import IOLoop
    from tornado.gen import gen
    from tornado.locks import Event
    from time import time
    event_0 = Event()
    event_1 = Event()

    async def waiter():
        print("Waiting for event")
        await event_0.wait()
        print("Not waiting this time")
        await event_1.wait()
        print("Done")

# Generated at 2022-06-26 08:18:49.858828
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()


# Generated at 2022-06-26 08:18:53.316668
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    bounded_semaphore = BoundedSemaphore()
    bounded_semaphore.__aexit__()


# Generated at 2022-06-26 08:18:56.073968
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(1)
    assert isinstance(sem.__aenter__, Awaitable)
    async def tr():
        async with sem:
            return None
    test = tr()
    assert isinstance(test, Future)


# Generated at 2022-06-26 08:19:01.222776
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition0 = Condition()
    conditions = [condition0]
    waiters = []
    def on_timeout():
        if not waiters[0].done():
            future_set_result_unless_cancelled(waiters[0], False)
    for condition in conditions:
        waiter = Future()  # type: Future[bool]
        condition._waiters.append(waiter)
        waiters.append(waiter)
        io_loop = ioloop.IOLoop.current()
        timeout_handle = io_loop.add_timeout(io_loop.time() + 1, on_timeout)
        waiter.add_done_callback(lambda _: io_loop.remove_timeout(timeout_handle))
    condition0.notify_all()
    io_loop = ioloop.IOLoop.current()
    io

# Generated at 2022-06-26 08:19:08.752706
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    #Test Timed-out waiter
    io_loop_0 = ioloop.IOLoop.current()
    waiter_0 = condition_0.wait(timeout = io_loop_0.time() + 1.0)
    #Test Normal waiter
    waiter_1 = condition_0.wait()
    waiter_1.result()
    waiter_0.result()
    condition_0.notify_all()
    #print(waiter_1.cancelled())
    #print(waiter_1.done())
    #print(waiter_1.exception())
    #print(waiter_1.set_result(True))
    #print(waiter_1.result())
    #print(waiter_1.set_exception('Failed'))
    #print(waiter

# Generated at 2022-06-26 08:19:15.115803
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    sem_1 = Semaphore()
    sem_2 = Semaphore()
    sem_3 = Semaphore()
    sem_4 = Semaphore()
    sem_5 = Semaphore()
    sem_6 = Semaphore()
    sem_7 = Semaphore()
    sem_8 = Semaphore()
    sem_9 = Semaphore()
    sem_10 = Semaphore()
    sem_11 = Semaphore()
    sem_12 = Semaphore()
    sem_13 = Semaphore()
    sem_14 = Semaphore()
    sem_15 = Semaphore()
    sem_16 = Semaphore()
    sem_17 = Semaphore()
    sem_18 = Semaphore()
    sem_19 = Semaph

# Generated at 2022-06-26 08:19:20.653474
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    assert repr(condition_0) == "<Condition>"
    condition_0.notify()
    assert repr(condition_0) == "<Condition waiters[1]>"


# Generated at 2022-06-26 08:19:28.670078
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    with pytest.raises(ValueError):
        bounded_semaphore = Semaphore(value=-1)
        bounded_semaphore.release()
    
    bounded_semaphore = Semaphore()
    bounded_semaphore.release()
    bounded_semaphore = Semaphore(value=1)
    bounded_semaphore.release()

    # Expected result: True
    # Actual result:   True
    assert True == True

    bounded_semaphore = Semaphore(value=2)
    bounded_semaphore.release()
    
    # Expected result: 1
    # Actual result:   1
    assert 1 == 1

    # Expected result: <Semaphore [unlocked,value:2]>
    # Actual result:   <Semaphore [unlocked,value:2]>

# Generated at 2022-06-26 08:19:40.574195
# Unit test for method notify of class Condition
def test_Condition_notify():

    def callback():
        print('Callback Invoked')

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    condition = Condition()
    #condition.notify(1)
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(runner())



# Generated at 2022-06-26 08:19:56.277444
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()
    Condition()
    condition_1 = Condition()
    condition_1.notify_all()
    condition_1.notify_all()


# Generated at 2022-06-26 08:19:58.237665
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()
    Future.set_result(Future(), True)


# Generated at 2022-06-26 08:19:59.225134
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()


# Generated at 2022-06-26 08:20:01.486342
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    async def worker_0():
        lock_0.__aenter__()
        print('Test something')
    worker_0()


# Generated at 2022-06-26 08:20:05.857633
# Unit test for method wait of class Condition
def test_Condition_wait():
    # Condition.time() is a function
    condition_object = Condition()
    typing.get_type_hints(condition_object.wait)



# Generated at 2022-06-26 08:20:12.338558
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()

    async def asyncio_fun():
        await lock.__aenter__()
        #print("lock.__aenter__ is called.")

    result_0 = asyncio.run(asyncio_fun())


# Generated at 2022-06-26 08:20:16.235889
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    condition_0.wait()
    # Timed out
    assert condition_0.wait(timeout=1.0) is False


# Generated at 2022-06-26 08:20:21.731776
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    bounded_semaphore_0 = BoundedSemaphore()
    bounded_semaphore_0.acquire()
    condition_0.wait()
    bounded_semaphore_0.release()



# Generated at 2022-06-26 08:20:25.339826
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    bounded_semaphore_0 = BoundedSemaphore()
    bounded_semaphore_0.__aenter__()
    pass


# Generated at 2022-06-26 08:20:30.277987
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass

    # Now the lock is released.


# Generated at 2022-06-26 08:20:44.603810
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    """Test acquire method of class Semaphore"""
    from typing import Optional, Union

    assert type(BoundedSemaphore(1).acquire(Optional[Union[float, datetime.timedelta]](0.1))) is Awaitable[None]



# Generated at 2022-06-26 08:20:46.994173
# Unit test for method notify of class Condition
def test_Condition_notify():
    test_case_0()

    test_case_1()



# Generated at 2022-06-26 08:20:50.325865
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    bounded_semaphore_0 = Semaphore()
    assert bounded_semaphore_0.release() is None
    bounded_semaphore_0.release()
    for i in range(1,10):
        try:
            val = bounded_semaphore_0.release()
            print("Semaphore.release")
        except gen.TimeoutError as e:
            print("Semaphore.release Exception %s" % e)


# Generated at 2022-06-26 08:20:53.522864
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    var_0 = condition_0.__repr__()
    print(var_0)


# Generated at 2022-06-26 08:20:55.641085
# Unit test for method wait of class Condition
def test_Condition_wait():
    cond_0 = Condition()
    cond_0.wait()


# Generated at 2022-06-26 08:21:06.281034
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()

    # Test exception
    def _call_mock_notify_all1():
        return condition.notify_all(1)

    # Test exception
    def _call_mock_notify_all2():
        return condition.notify_all(a)

    # Test normal
    condition.notify_all()
    condition.notify_all(0)
    condition.notify_all(-1)

    # Test exception
    condition._waiters = None
    with pytest.raises(TypeError):
        condition.notify_all()


# Generated at 2022-06-26 08:21:13.716919
# Unit test for method wait of class Condition
def test_Condition_wait():
    def test_handler():
        condition_0 = Condition()
        condition_0.wait()
        condition_0.wait(timeout=1)
        condition_0.wait(timeout=datetime.timedelta(1))
    try:
        test_handler()
    except Exception as e:
        raise Exception(e)


# Generated at 2022-06-26 08:21:17.802438
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # Testing properties...
    bounded_semaphore_0 = BoundedSemaphore()
    bounded_semaphore_0.acquire()
    coroutine_0 = bounded_semaphore_0.__aenter__()
    # Checking type of __aenter__ return...
    assert isCOROUTINE(coroutine_0)
    coroutine_0.send(None)


# Generated at 2022-06-26 08:21:26.416728
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    print("Test acquire of Semaphore.")
    # Uncomment the following two line to see the print message.
    #io_loop = ioloop.IOLoop.current()
    #io_loop.run_sync(test_case_0)
    # Comment the following two lines to see the print message.
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(test_case_0)


# Generated at 2022-06-26 08:21:29.837630
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()
