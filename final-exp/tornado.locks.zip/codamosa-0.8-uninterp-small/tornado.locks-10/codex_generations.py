

# Generated at 2022-06-26 08:15:12.360081
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from os.path import abspath
    from os import sys, path
    abspath(__file__)
    sys.path.append(path.dirname(path.dirname(path.dirname(path.abspath(__file__)))) + "/tornado/concurrent")
    from concurrent import Future

    import unittest

    class TestLock(unittest.TestCase):
        def test_Lock___aenter__(self):
            lock_0 = Lock()

            future = Future()

            self.assertIs(lock_0.__aenter__(), future)

    suite = unittest.TestLoader().loadTestsFromTestCase(TestLock)
    unittest.TextTestRunner(verbosity=2).run(suite)


# Generated at 2022-06-26 08:15:15.676282
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test with one waiter
    expected = "<Condition waiters[1]>"
    condition = Condition()
    waiter = Future()
    condition._waiters.append(waiter)
    assert condition.__repr__() == expected

    # Test with zero waiters
    expected = "<Condition>"
    condition = Condition()
    assert condition.__repr__() == expected


# Generated at 2022-06-26 08:15:18.012796
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Local variables
    condition_0 = None
    # Test code
    condition_0 = Condition()
    # Tested method __repr__
    assert True



# Generated at 2022-06-26 08:15:19.413886
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    print(condition_0.__repr__())


# Generated at 2022-06-26 08:15:29.983089
# Unit test for method notify of class Condition
def test_Condition_notify():
    print('Running unit test for method notify of class Condition')
    semaphore_0 = Semaphore()
    Lock()
    semaphore_0._initialize_waiters()
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_0._waiters.append(Lock())
    semaphore_

# Generated at 2022-06-26 08:15:30.805077
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    return None


# Generated at 2022-06-26 08:15:36.643164
# Unit test for method set of class Event
def test_Event_set():
    evt = Event()
    assert(not evt.is_set())
    evt.set()
    assert(evt.is_set())


# Generated at 2022-06-26 08:15:40.217253
# Unit test for method release of class Lock
def test_Lock_release():
    lock_0 = Lock()
    with pytest.raises(RuntimeError):
        lock_0.release()


# Generated at 2022-06-26 08:15:50.781315
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    waiter_0 = Future()
    waiter_1 = Future()
    waiter_2 = Future()
    waiter_3 = Future()
    waiter_4 = Future()
    waiter_5 = Future()
    waiter_6 = Future()
    waiter_7 = Future()
    waiter_8 = Future()
    waiter_9 = Future()

    condition_0._waiters.append(waiter_0)
    condition_0._waiters.append(waiter_1)
    condition_0._waiters.append(waiter_2)
    condition_0._waiters.append(waiter_3)
    condition_0._waiters.append(waiter_4)
    condition_0._waiters.append(waiter_5)
    condition_0._waiters.append(waiter_6)

# Generated at 2022-06-26 08:15:58.452118
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    # Create an instance of class Lock
    l = Lock()
    # Call method __aexit__ of l
    l.__aexit__(None, None, None)
    # Check if l is unlocked
    try:
        l.acquire()
        l.release()
    except RuntimeError:
        print('l is locked')
    else:
        print('l is unlocked')


# Generated at 2022-06-26 08:16:14.633214
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    try:
        test_Semaphore_acquire_with_valid_arg()
    except:
        print("Unable to execute test_Semaphore_acquire_with_valid_arg")


# Generated at 2022-06-26 08:16:18.954973
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()
    condition_0.notify_all()
    condition_0.wait()
    condition_0.wait(timeout = None)
    condition_0.wait(timeout = 0)


# Generated at 2022-06-26 08:16:29.037934
# Unit test for method set of class Event
def test_Event_set():
    async def waiter():
        event.set()
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        await event.wait()
        event.set()

    event = Event()
    ioloop.IOLoop.current().run_sync(lambda: gen.multi([waiter(), setter()]))


# Generated at 2022-06-26 08:16:32.168398
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    waiter_0 = Future()
    waiter_0.done()

    condition_0._waiters.append(waiter_0)
    waiter_0.done()
    waiter_0.result()
    waiter_0.exc_info()
    waiter_0.traceback()
    waiter_0.set_result(True)
    waiter_0.set_exception(Exception())
    condition_0.notify(1)
    condition_0.notify()



# Generated at 2022-06-26 08:16:39.571673
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    '''
    Semaphore() -> semaphore
    
    '''
    # pass
    semaphore_0 = Semaphore()

    assert (semaphore_0._value == 1)

    assert (semaphore_0._waiters == collections.deque())



# Generated at 2022-06-26 08:16:48.972894
# Unit test for method wait of class Condition
def test_Condition_wait():
    class MyCondition(Condition):
        def __init__(self) -> None:
            Condition.__init__(self)
            self.t = 0

        async def waiter(self):
            print("I'll wait right here")
            print(type(self.wait()))
            await self.wait()
            print("I'm done waiting")

        async def notifier(self):
            print("About to notify")
            Condition.notify(self)
            print("Done notifying")

        def run(self):
            # Wait for waiter() and notifier() in parallel
            self.io_loop.run_sync(self.notifier())
            self.io_loop.run_sync(self.waiter())

    m = MyCondition()
    m.run()


# Generated at 2022-06-26 08:16:52.683212
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore()
    result = sem.acquire()
    # The above line fails with "Semaphore object is not awaitable"
    # It should return an awaitable.


# Generated at 2022-06-26 08:17:03.536934
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_1 = Condition()
    condition_2 = Condition()
    condition_3 = Condition()

    # Add the future to the list _waiters
    waiter = Future()
    condition_1._waiters.append(waiter)
    # The result is like this: <Condition waiters[1]>
    print(condition_1)

    # Add the future to the list _waiters
    waiter = Future()
    condition_2._waiters.append(waiter)
    # The result is like this: <Condition waiters[2]>
    print(condition_2)

    # The result is like this: <Condition>
    print(condition_3)


# Generated at 2022-06-26 08:17:12.081125
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    print('Testing __aexit__...', end='')
    semaphore_0 = Semaphore()
    try:
        semaphore_0.release()
        print('Passed.')
    except Exception as e:
        print('Failed: unexpected exception thrown: {0}'.format(e))


# Generated at 2022-06-26 08:17:19.030745
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    # Locks the lock, exits the context and releases the lock.
    called = [0]
    async def f():
        nonlocal called
        called[0] += 1
        await asyncio.sleep(0)
        await asyncio.sleep(0)
        called[0] += 1

    lock = asyncio.Lock()

    async def g():
        nonlocal called
        async with lock:
            await f()
        called[0] += 1

    loop = asyncio.get_event_loop()
    loop.run_until_complete(g())
    assert called == [1, 2, 3], called


# Generated at 2022-06-26 08:17:35.406539
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0_0 = Semaphore()
    future_0_0 = semaphore_0_0.acquire()
    future_0_0.result()
    semaphore_0_0.release()


# Generated at 2022-06-26 08:17:38.846623
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore_0 = Semaphore()
    semaphore_0.release()


# Generated at 2022-06-26 08:17:41.314226
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    semaphore_0 = Semaphore()
    assert (semaphore_0.__repr__() == '<Semaphore unlocked,value:1>')



# Generated at 2022-06-26 08:17:52.987008
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    futures_q = deque([Future() for _ in range(3)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))

    def use_some_resource():
        return futures_q.popleft()

    async def worker(worker_id):
        async with semaphore_0:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.

# Generated at 2022-06-26 08:17:58.836313
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()
    result_future_0 = Future()

    semaphore_0.acquire(timeout=None)
    semaphore_0.release()
    result_future_0.set_result(None)


# Generated at 2022-06-26 08:18:08.678066
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    waiters = condition._waiters
    # First test case, condition has no waiters
    condition.notify()
    assert waiters == condition._waiters
    # Second test case, condition has one waiter, assert it is notified
    waiter = Future()
    waiters.append(waiter)
    condition.notify()
    assert len(waiters) == 0
    assert waiter.done()
    assert waiter.result() == True


# Generated at 2022-06-26 08:18:14.797102
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    try:
        # State pre-conditions:
        #   - [semaphore_0._value := 1]
        assert semaphore_0._value == 1

        # Call the tested method:
        await semaphore_0.__aenter__()

        # State post-conditions:
        #   - [semaphore_0._value := 0]
        assert semaphore_0._value == 0
    except Exception as e:
        raise Exception("An exception was raised during the test: " + str(e)) from e


# Generated at 2022-06-26 08:18:18.456257
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition).startswith("<Condition")


# Generated at 2022-06-26 08:18:21.649053
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test with argument 0
    condition_0 = Condition()
    result = condition_0.__repr__()
    assert result == "<Condition waiters[0]>"


# Generated at 2022-06-26 08:18:35.450474
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():

    print("\nStarting unit test for Semaphore.acquire()\n")

    # Test Case 0
    try:
        print("Starting test case 0 for Semaphore.acquire()\n")
        semaphore_0 = Semaphore()
        print("Successfully creating semaphore_0 = Semaphore()\n")
    except Exception as e:
        print("Error while executing test case 0 - while creating semaphore_0\n")
        print("Exception: " + str(e))
    try:
        awaitable_0 = semaphore_0.acquire()
        print("Successfully created semaphore_0.acquire()\n")
    except Exception as e:
        print("Error while executing test case 0 - while creating semaphore_0.acquire()\n")

# Generated at 2022-06-26 08:18:52.116234
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():

    lock_0 = Lock()

    # Test 1: Verify the number of arguments
    try:
        lock_0.__aenter__()
    except TypeError:
        print("TypeError raised in method __aenter__ of class Lock")



# Generated at 2022-06-26 08:18:54.243536
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # __aenter__ and __aexit__ are not implemented yet.
    pass


# Generated at 2022-06-26 08:19:00.584921
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    future_0 = Future()
    lock_0.__aenter__(io_loop = IOLoop.current()).add_done_callback(future_0.set_result)
    future_0.result()


# Generated at 2022-06-26 08:19:04.832343
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    try:
        future_0 = semaphore_0.__aenter__()
    except TimeoutError:
        future_0 = Future()
        print('TimeoutError')


# Generated at 2022-06-26 08:19:11.789811
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    result = semaphore_0.__aenter__()
    assert result is None, 'Method Semaphore.__aenter__ did not return the expected result. Actual result: {!s}'.format(result)


# Generated at 2022-06-26 08:19:16.027016
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():

    lock_0 = Lock()
    lock_0.__aexit__(None, None, None)
    try:
        lock_0.__aexit__(None, None, None)
    
        # verify the results of the test
        assert (True), "Unreachable code!"
    except RuntimeError:
        pass
    except Exception:
        # unexpected exception
        assertion_flag = False
        raise



# Generated at 2022-06-26 08:19:20.095383
# Unit test for method wait of class Event
def test_Event_wait():
    # wait for event without timeout
    event_0 = Event()
    event_0.wait()
    event_0.set()


# Generated at 2022-06-26 08:19:30.423381
# Unit test for method wait of class Event
def test_Event_wait():
    print("start of test_Event_wait")
    event_0 = Event()
    def event_wait_task():
        print("event_wait_task before waiting")
        event_0.wait()
        print("event_wait_task after waiting")
    
    def event_waiter():
        print("event_waiter before waiting")
        event_0.wait()
        print("event_waiter after waiting")
    
    gen.sleep(0.01)
    print("here")
    print(type(event_wait_task))
    gen.Task(event_waiter())
    gen.Task(event_wait_task())
    event_0.wait()
    event_0.set()
    gen.sleep(1)
    print("end of test_Event_wait")


# Generated at 2022-06-26 08:19:36.110998
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    future_0 = condition_0.wait()
    test_result = False
    if future_0.done():
        test_result = True
    assert test_result



# Generated at 2022-06-26 08:19:41.757426
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    print("\n**************************** Semaphore.release ****************************")
    semaphore_0 = Semaphore(10)
    print("semaphore_0:", semaphore_0)
    semaphore_0.release()
    print("semaphore_0:", semaphore_0)
    semaphore_0.release()
    print("semaphore_0:", semaphore_0)


# Generated at 2022-06-26 08:20:02.165521
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()

    async def waiter(i):
        print("waiter", i, "is waiting")
        s = await condition.wait()
        print("waiter", i, "got notified")
        print("waiter", i, "is leaving")

    async def notifier():
        print("notifier is waiting for a random time")
        await gen.sleep(2)
        print("notifier has finished waiting")
        print("notifier is notifying")
        condition.notify_all()
        print("notifier has finished notifying")

    async def runner():
        await gen.multi([waiter(i) for i in range(10)])
        await notifier()

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(runner)


# Generated at 2022-06-26 08:20:06.395412
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    str_Repr = repr(condition_0)
    assert(str_Repr == "<Condition>")



# Generated at 2022-06-26 08:20:11.597102
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    io_loop_0 = ioloop.IOLoop.current()
    io_loop_0.run_sync(lambda: condition_0.wait(timeout=io_loop_0.time() + 1))


# Generated at 2022-06-26 08:20:17.435071
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    semaphore_0 = Semaphore()
    print(semaphore_0)
    for i in range(5):
        semaphore_0.__aexit__(None, None, None)
        print(semaphore_0)


# Generated at 2022-06-26 08:20:19.508786
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()


# Generated at 2022-06-26 08:20:21.931493
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()



# Generated at 2022-06-26 08:20:24.746747
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    assert not event_0.is_set()


# Generated at 2022-06-26 08:20:35.311274
# Unit test for method notify of class Condition
def test_Condition_notify():
    import asyncio

    async def waiter(condition: Condition):
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier(condition: Condition):
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        # await gen.multi([waiter(), notifier()])
        condition_0 = Condition()
        await asyncio.gather(waiter(condition_0), notifier(condition_0))

    loop = asyncio.get_event_loop()
    loop.run_until_complete(runner())
    loop.close()



# Generated at 2022-06-26 08:20:37.446375
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-26 08:20:41.105571
# Unit test for method wait of class Condition
def test_Condition_wait():
    cond = Condition()

    def callback():
        print("I'm done waiting")

    cond.wait().add_callback(callback)



# Generated at 2022-06-26 08:21:04.736357
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    raise NotImplementedError



# Generated at 2022-06-26 08:21:15.193211
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    semaphore_1 = Semaphore(value=1)
    assert semaphore_1.__repr__() == '<Semaphore at 0x20988e8a128 [unlocked,value:1]>'
    semaphore_2 = Semaphore(value=0)
    assert semaphore_2.__repr__() == '<Semaphore at 0x20988e8a128 [locked]>'
    pass


# Generated at 2022-06-26 08:21:21.970757
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    result = event_0.wait()
    print("result in test_Event_wait() is {}".format(result))
    event_0.set()
    result = event_0.wait()
    print("result in test_Event_wait() is {}".format(result))


# Generated at 2022-06-26 08:21:24.771630
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore_0 = Semaphore()
    semaphore_0_release = semaphore_0.release()
    return

test_Semaphore_release()


# Generated at 2022-06-26 08:21:26.098059
# Unit test for method wait of class Event
def test_Event_wait():
    ev = Event()
    assert not ev.is_set()
    ev_wait = ev.wait()
    assert ev_wait is not None


# Generated at 2022-06-26 08:21:39.961980
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from typing import List
    from concurrent.futures import ThreadPoolExecutor
    import asyncio
    import random

    print("Testing: Semaphore.release()\n")
    num_0 = 0 # amount of numbers in the list of random numbers
    num_1 = 5 # number of random numbers to be generated on each thread
    num_2 = 4 # number of threads used
    num_3 = 1 # amount of numbers in the list of unique numbers
    num_4 = 5 # number of unique numbers to be generated on each thread
    num_5 = 4 # number of threads used
    num_6 = 10 # number of items generated

    # Generates a number of random numbers
    def generate(num: int = 1) -> List[int]:
        r_list: List[int] = []
        for _ in range(num):
            r_

# Generated at 2022-06-26 08:21:42.847228
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_1 = Semaphore()
    semaphore_1.__aenter__()


# Generated at 2022-06-26 08:21:46.276476
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore_0 = Semaphore()
    semaphore_0.release()


# Generated at 2022-06-26 08:21:48.572730
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:21:51.214918
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()


# Generated at 2022-06-26 08:22:18.471113
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    print(lock)
    try:
        lock.__aenter__()
    except Exception as ex:
        print(ex)


# Generated at 2022-06-26 08:22:26.232053
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    import coroutines
    import locks
    import _futures
    import types

    #release
    async def async_main()->None:
        semaphore_0 = locks.Semaphore(1)
        semaphore_0.release()
        f = semaphore_0.acquire()
        if (not (isinstance(f, _futures.Future))):
            raise AssertionError
        await f._wait()
        if (not (semaphore_0.is_set())):
            raise AssertionError
        if (semaphore_0.is_set()):
            semaphore_0.release()
        async with semaphore_0:
            pass
        if (not (semaphore_0.is_set())):
            raise AssertionError

# Generated at 2022-06-26 08:22:29.525726
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # import asyncio
    # loop = asyncio.get_event_loop()
    # loop.run_until_complete(semaphore_0.acquire())
    semaphore_0.release()


# Generated at 2022-06-26 08:22:35.945132
# Unit test for method notify of class Condition
def test_Condition_notify():
    import asyncio
    ioloop_0 = ioloop.IOLoop.current()
    condition_0 = Condition()
    cnt = 0
    def waiter():
        nonlocal cnt
        print("I'll wait right here")
        yield from condition_0.wait()
        cnt += 1
        print("I'm done waiting")
    def notifier():
        print("About to notify")
        condition_0.notify()
        print("Done notifying")
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield from asyncio.gather(waiter(), notifier())
    ioloop_0.run_sync(runner)
    assert cnt == 1


# Generated at 2022-06-26 08:22:38.835095
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    print("BoundedSemaphore.release():")
    # Try to release the semaphore twice
    semaphore_0 = BoundedSemaphore()

    if semaphore_0.is_set():
        semaphore_0.release()
    else:
        print("AssertionError:")
        print("ValueError: Semaphore released too many times")
        print("\n")

if __name__ == "__main__":
    test_BoundedSemaphore_release()
    test_case_0()

# Generated at 2022-06-26 08:22:46.018110
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
	# create an object of class Condition
    condition_0 = Condition()
    condition_0.io_loop.start()
    # assert_equals(expected, actual)
    # assert_equals(expected, actual, message)
    # assert_equals(expected, actual, message=None)
    return


# Generated at 2022-06-26 08:22:50.718746
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    print(event_0.is_set())

    event_0.set()
    print(event_0.is_set())


# Generated at 2022-06-26 08:22:57.374948
# Unit test for method wait of class Condition
def test_Condition_wait():
    io_loop = ioloop.IOLoop.current()

    waiter = Future()
    io_loop = ioloop.IOLoop.current()
    io_loop.add_future(waiter, lambda f: f.result())
    condition = Condition()
    # timeout=None
    waiter1 = condition.wait(timeout=None)
    io_loop.add_future(waiter1, lambda f: f.result())

    # timeout is a float type
    waiter2 = condition.wait(timeout=float(0.5))
    io_loop.add_future(waiter2, lambda f: f.result())

    # timeout is a time monotonic float
    waiter3 = condition.wait(timeout=io_loop.time() + 1.0)

# Generated at 2022-06-26 08:23:06.998122
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    import unittest
    import inspect

    # Build Semaphore
    semaphore_0 = Semaphore()

    # Build args
    args_0 = (None, None, None)

    # Test the path where an exception is raised
    def _check_path(func_name, args, line_no, e_type_expected):
        try:
            if func_name == "__aexit__":
                semaphore_0.__aexit__(*args)
            else:
                raise RuntimeError("Invalid function name {}".format(func_name))
        except e_type_expected:
            cur_tb = sys.exc_info()[2]
            found = False
            while cur_tb.tb_next is not None:
                cur_tb = cur_tb.tb_next

# Generated at 2022-06-26 08:23:14.899779
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    print("Testing Semaphore_acquire:")
    semaphore = Semaphore()
    try:
        print(semaphore.acquire(timeout=0.5))
    except gen.TimeoutError:
        print("TimeoutError caught!")
    else:
        print("Acquired!")
    print("Done!")


# Generated at 2022-06-26 08:24:05.798493
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # Test whether exception is thrown if release is called
    # after acquire() without calling release() in between
    try:
        semaphore_0 = BoundedSemaphore()
        semaphore_0.acquire()
        semaphore_0.release()
        semaphore_0.release()
    except ValueError as e:
        pass


# Generated at 2022-06-26 08:24:12.736434
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)

if __name__ == "__main__":
    test_case_0()
    test_Condition_notify()


# Generated at 2022-06-26 08:24:16.326183
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.wait()
    timeout_0 = 1
    event_0.wait(timeout_0)


# Generated at 2022-06-26 08:24:18.817117
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    semaphore_0.__aenter__()


# Generated at 2022-06-26 08:24:24.033703
# Unit test for method wait of class Condition
def test_Condition_wait():
    # initialize
    condition_0 = Condition()
    condition_0_wait_result = condition_0.wait(None)
    if isinstance(condition_0_wait_result, Future):
        condition_0_wait_result.result()


# Generated at 2022-06-26 08:24:29.325875
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    semaphore_0 = BoundedSemaphore()
    semaphore_0.acquire()
    semaphore_0.release()
    semaphore_0.release()

# Generated at 2022-06-26 08:24:31.859439
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    assert lock._block._value == 1
    lock.release()
    assert lock._block._value == 1


# Generated at 2022-06-26 08:24:37.019826
# Unit test for method notify of class Condition
def test_Condition_notify():
    print("====Test for method notify of class Condition====")
    condition_0 = Condition()
    condition_0.notify()
    print("====Test for method notify of class Condition is finished====")
