

# Generated at 2022-06-26 08:14:57.168045
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    assert len(condition_0._waiters) == 0
    f_0 = Future()
    f_1 = Future()
    condition_0._waiters.append(f_0)
    condition_0._waiters.append(f_1)
    condition_0.notify_all()
    assert f_0.done()
    assert f_1.done()
    assert f_0.result() == True
    assert f_1.result() == True
    assert len(condition_0._waiters) == 0


# Generated at 2022-06-26 08:15:01.923826
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():

    @gen.coroutine
    def real_test():
        condition = Condition()
        str_type = str
        result = condition.__repr__() # type: str
        assert isinstance(result, str_type)
        return

    return real_test


# Generated at 2022-06-26 08:15:07.034965
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    assert(cond.__repr__() == "<Condition>")
    cond.wait(timeout=0.100000)
    assert(cond.__repr__() == "<Condition waiters[1]>")
    cond.notify_all()
    assert(cond.__repr__() == "<Condition>")


# Generated at 2022-06-26 08:15:12.193810
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    waiter()
    notifier()



# Generated at 2022-06-26 08:15:13.350597
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()



# Generated at 2022-06-26 08:15:16.353660
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    assert condition.wait() is not None


# Generated at 2022-06-26 08:15:18.790427
# Unit test for method release of class Lock
def test_Lock_release():
    lock_0 = Lock()
    try:
        lock_0.release()
        raise AssertionError("Not raised")
    except RuntimeError:
        pass


# Generated at 2022-06-26 08:15:22.536948
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore_0 = Semaphore()
    semaphore_1 = Semaphore()
    result = semaphore_0.release()
    assert result == None


# Generated at 2022-06-26 08:15:31.714413
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    import time
    import threading
    import random
    import logging

    # basic unit testing for Semaphore.acquire()
    def worker(num, semaphore):
        logging.debug('Worker: %s acquiring semaphore', num)
        with (yield from semaphore.acquire()):
            logging.debug('Worker: %s has semaphore', num)
            time.sleep(random.randint(1, 5))
            logging.debug('Worker: %s releasing semaphore', num)
        logging.debug('Worker: %s done', num)

    logging.basicConfig(
        level=logging.DEBUG,
        format='(%(threadName)-10s) %(message)s',
    )

    semaphore = Semaphore()


# Generated at 2022-06-26 08:15:37.143432
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()
    semaphore_0.acquire()


# Generated at 2022-06-26 08:16:00.536676
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    result_fut = event_0.wait()

    # Test whether the result Future is done, and if so, whether it is
    # actually the expected result
    result_fut_type = type(result_fut)
    if result_fut_type is not Future:
        print("The type of result Future is incorrect. Expected type: 'Future'. Actual type: "
              + result_fut_type + ".")
    else:
        result_fut_done = result_fut.done()
        if result_fut_done:
            if result_fut.result() == None:
                print("wait method of Event class is correct.")

# Generated at 2022-06-26 08:16:01.954133
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    lock_0.__aexit__(None, None, None)


# Generated at 2022-06-26 08:16:05.121905
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    asyncio.run(semaphore_0.__aenter__())


# Generated at 2022-06-26 08:16:06.756961
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(1)


# Generated at 2022-06-26 08:16:20.270130
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    from tornado.locks import BoundedSemaphore

    value = 1
    bound_semaphore_0 = BoundedSemaphore(value)
    bound_semaphore_0.release()
    bound_semaphore_1 = BoundedSemaphore(value)
    bound_semaphore_1.release()
    bound_semaphore_2 = BoundedSemaphore(value)
    bound_semaphore_2.release()
    bound_semaphore_3 = BoundedSemaphore(value)
    bound_semaphore_3.release()
    return (
        #bound_semaphore_0,
        #bound_semaphore_1,
        #bound_semaphore_2,
        bound_semaphore_3,
    )


# Generated at 2022-06-26 08:16:33.032268
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    # It is possible that the first call to __aexit__ is before the semaphore
    # has been released.
    async def func_1():
        lock = Lock()
        await lock.acquire()
        await lock.acquire()

    # It is possible that the first call to __aexit__ is after the semaphore
    # has been released.
    async def func_2():
        lock = Lock()
        await lock.acquire()
        lock._block._value = 0
        await lock.release()
        await lock.acquire()

    # It is possible that the first call to __aenter__ is after the 
    # semaphore has been released.
    async def func_3():
        lock = Lock()
        lock._block._value = 0
        await lock.release()
        await lock.acquire()



# Generated at 2022-06-26 08:16:36.871839
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(1)
    condition_0.notify_all()


# Generated at 2022-06-26 08:16:40.848310
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    print('Here')
    c.notify_all()
    print('Here')
    c.notify_all()
    print('Here')


# Generated at 2022-06-26 08:16:45.424319
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()
    future = c.wait()
    future.add_done_callback(lambda f: print(f.result()))
    c.notify()


# Generated at 2022-06-26 08:16:48.236642
# Unit test for method wait of class Event
def test_Event_wait():
    ev = Event()
    # wait the event
    ev.wait()

# test Semaphore()

# Generated at 2022-06-26 08:17:12.206053
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    str_0 = condition_0.__repr__()
    assert str_0 == '<Condition>'


# Generated at 2022-06-26 08:17:20.041578
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    timeout_0 = None
    temp_0: Awaitable[bool] = condition_0.wait(timeout=timeout_0)
    temp_1: typing.Any = None
    temp_2: bool = temp_1 is not None
    if temp_2:
        util = typing.cast(typing.Any, temp_1)
        temp_4: float = util[0]
        timestamp = temp_4
        temp_5: typing.Any = condition_0.wait(timeout=timestamp)
        temp_6: typing.Any = None
        temp_7: bool = temp_6 is not None
        if temp_7:
            util = typing.cast(typing.Any, temp_6)
            temp_9: typing.Any = util[1]
            delta = temp_9


# Generated at 2022-06-26 08:17:20.828380
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()

# Generated at 2022-06-26 08:17:29.530428
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    d = Condition()
    l = []
    # Client 1
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        result = yield d.wait()
        l.append(result)
        print("I'm done waiting")

    # Client 2
    @gen.coroutine
    def notifier():
        print("About to notify")
        d.notify_all()
        print("Done notifying")
    # Client 3
    @gen.coroutine
    def notifier_2():
        print("About to notify 2")
        d.notify_all()
        print("Done notifying 2")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier(), notifier_2()])

   

# Generated at 2022-06-26 08:17:34.829890
# Unit test for method wait of class Condition
def test_Condition_wait():
    import tornado.gen
    import tornado.ioloop

    from tornado.locks import Condition

    def test_condition(condition: Condition, timeout: float) -> None:
        IOLoop.current().add_callback(condition.wait, timeout)
    
    

# Generated at 2022-06-26 08:17:37.373478
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    try:
        semaphore_0.__aenter__()
    except:
        pass


# Generated at 2022-06-26 08:17:40.878566
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    def test():
        lock_0 = Lock()
        lock_0.__aenter__()

    test()





# Generated at 2022-06-26 08:17:51.322702
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    #  call notify with 1 as a parameter
    condition_0.notify(1)
    #  call notify with 1 as a parameter
    condition_0.notify(1)
    #  call notify with 1 as a parameter
    condition_0.notify(1)
    #  call notify with 1 as a parameter
    condition_0.notify(1)
    #  call notify with 1 as a parameter
    condition_0.notify(1)
    #  call notify with 1 as a parameter
    condition_0.notify(1)
    

# Generated at 2022-06-26 08:17:56.721339
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond_0 = Condition()
    cond_0.notify_all()

    cond_1 = Condition()
    cond_1.notify(1)

    cond_2 = Condition()
    cond_2.notify(2)



# Generated at 2022-06-26 08:18:05.500099
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    try:
        val_0 = BoundedSemaphore()
        val_0.release()
        val_0.release()
        val_0.release()
        val_0.release()
        val_0.release()
        val_0.release()
        val_0.release()
        val_0.release()
        val_0.release()
        print("Duke Nukem says: This is too easy!")
    except ValueError:
        print("This is not free!")



# Generated at 2022-06-26 08:18:46.800676
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    # Invoke method
    # lock_0.__aenter__()
    pass


# Generated at 2022-06-26 08:18:52.640734
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    future = condition.wait()
    print(future)
    future.add_done_callback(lambda f: print(f.result()))
    condition.notify()
    gen.sleep(0.5)


# Generated at 2022-06-26 08:18:54.785800
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    result = condition.wait()
    print("Test result: " + str(result))


# Generated at 2022-06-26 08:19:06.912990
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    ev = event.wait()
    
    print('ev = ', ev)
    print('ev = ', ev.__class__)
    print('ev = ', ev.__class__.__name__)
    print('ev = ', ev.__class__.__module__)

    coroutine = types.coroutine
    print('coroutine = ', coroutine)
    print('coroutine = ', coroutine.__class__)
    print('coroutine = ', coroutine.__class__.__name__)
    print('coroutine = ', coroutine.__class__.__module__)
    print('coroutine = ', coroutine.__class__.__bases__)
    print('coroutine = ', coroutine.__class__.__mro__)

# Generated at 2022-06-26 08:19:11.170435
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    if not event.is_set():
        raise Exception("Test Event set failed!")


# Generated at 2022-06-26 08:19:15.373150
# Unit test for method release of class Lock
def test_Lock_release():
    lock0 = Lock()
    lock0.release()
    print("Test for method release of class Lock passed")

if __name__ == "__main__":
    test_case_0()
    test_Lock_release()

# Generated at 2022-06-26 08:19:18.303161
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    lock_0.__aexit__()

    # Assert


# Generated at 2022-06-26 08:19:21.740065
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()

    IOLoop.current().run_sync(event_0.wait)


# Generated at 2022-06-26 08:19:27.327432
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    io_loop_0 = ioloop.IOLoop.current()
    condition_0 = Condition()
    condition_0.__repr__()
    while True:
        io_loop_0.stop()
        break
    return io_loop_0, condition_0



# Generated at 2022-06-26 08:19:35.528201
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    semaphore_0 = Semaphore(1)
    assert semaphore_0.__repr__() == "<Semaphore [unlocked,value:1]>"
    semaphore_0.acquire(10)
    assert semaphore_0.__repr__() == "<Semaphore [locked]>"


# Generated at 2022-06-26 08:20:54.854612
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    waiter = condition.wait()

    waiter.add_done_callback(lambda x: print('Future result:', x.result()))



# Generated at 2022-06-26 08:20:58.037742
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    semaphore_1 = Semaphore()
    semaphore_1.__aexit__(None, None, None)


# Generated at 2022-06-26 08:21:01.949118
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    try:
        lock_0 = Lock()
        lock_0.__aenter__()
    except:
        pass


# Generated at 2022-06-26 08:21:08.097545
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond_0 = Condition()
    awaitable_0 = cond_0.wait()
    cond_0.notify()
    # test :
    cond_0.notify(1)
    # test :
    Future_0 = Future()
    cond_0._waiters.append(Future_0)
    cond_0.notify(2)
    # test :
    Future_0 = Future()
    cond_0._waiters.append(Future_0)
    cond_0.notify_all()


# Generated at 2022-06-26 08:21:16.290723
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()

    # before notify, the waiters queue is empty
    assert [] == condition._waiters

    waiter = Future()
    condition._waiters.append(waiter)

    # before notify, there is one waiter
    assert 1 == len(condition._waiters)

    condition.notify()

    # after notify, the waiters queue is empty
    assert [] == condition._waiters
    assert True == waiter.result()


# Generated at 2022-06-26 08:21:27.235571
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    assert type(condition_0) == Condition
    assert isinstance(condition_0, _TimeoutGarbageCollector)
    assert condition_0._timeouts == 0
    condition_0.notify()
    assert condition_0._timeouts == 0
    #assert condition_0._notifiers == 0
    condition_0.notify(0)
    assert condition_0._timeouts == 0
    condition_0.notify(1)
    assert condition_0._timeouts == 0
    condition_0.notify(3)
    assert condition_0._timeouts == 0

# Generated at 2022-06-26 08:21:40.246364
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Test the case when the internal counter is greater than 0
    semaphore = Semaphore(3)
    f = semaphore.acquire()
    assert f.done()
    assert semaphore._value == 2
    # Test the case when the internal counter is 0
    semaphore = Semaphore(0)
    f = semaphore.acquire()
    assert not f.done()
    semaphore.release()
    assert f.done()
    assert semaphore._value == 0
    # Test the case when semaphore has already been released
    semaphore = Semaphore(1)
    f = semaphore.acquire()
    semaphore.release()
    assert f.done()
    assert semaphore._value == 0


# Generated at 2022-06-26 08:21:46.912434
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:21:47.704061
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait_()


# Generated at 2022-06-26 08:21:50.785275
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    assert condition._waiters == deque([]), 'Initialize waiters error'

    waiter = Future()
    condition._waiters.append(waiter)

    condition.notify(1)
    assert condition._waiters == deque([]), 'Notify waiters error'

