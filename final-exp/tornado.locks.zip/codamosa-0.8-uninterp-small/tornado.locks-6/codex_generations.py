

# Generated at 2022-06-26 08:15:06.833988
# Unit test for method wait of class Condition
def test_Condition_wait():
    k = 3
    condition = Condition()

    async def run_and_print(*args, **kwargs):
        print(" * Start run_and_print() * ")
        lock_1 = Lock()
        async with lock_1:
            print("Start lock_1")
            await gen.sleep(2)
            print("End lock_1")

        # async with condition:
        await condition.wait()
        print(" * End run_and_print() * ")

    def notify():
        print(" * Start notify() * ")
        condition.notify()
        print(" * End notify() * ")

    # RUN
    runner = [run_and_print() for i in range(k)]
    runner.append(notify())
    io_loop = ioloop.IOLoop.current()
    io_loop

# Generated at 2022-06-26 08:15:10.338234
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c0 = Condition()
    if c0.__repr__() == "<Condition waiters[0]>":
        print('Pass')
    else:
        print('Test Failed')



# Generated at 2022-06-26 08:15:16.265340
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():

    release_semaphore = BoundedSemaphore()
    assert release_semaphore._value == 1

    # Call release() when semaphore value is smaller than initial value
    release_semaphore.release()
    assert release_semaphore._value == 2

    # Call release() when semaphore value is equal to initial value
    for i in range(0, 2):
        with pytest.raises(ValueError):
            release_semaphore.release()

    # Call release() when semaphore value is larger than initial value
    with pytest.raises(ValueError):
        release_semaphore.release()


# Generated at 2022-06-26 08:15:24.142598
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    # Init a Semaphore
    i = 0
    sem = Semaphore(i)
    # Call __aexit__
    sem.__aexit__(None, None, None)
    print("Expected result:")
    print("1")
    print("Actual result:")
    print(sem._value)

if __name__ == '__main__':
    test_case_0()
    test_Semaphore___aexit__()

# Generated at 2022-06-26 08:15:26.715668
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem_0 = Semaphore()
    sem_0.release()
    print("unit test for method release of class Semaphore in module locks")


# Generated at 2022-06-26 08:15:30.047329
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.wait()
    event_0.wait()
    event_0.wait()


# Generated at 2022-06-26 08:15:33.880896
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem_0 = BoundedSemaphore(1)
    sem_0.release()
    assert True # TODO: may fail, use your own assert.


# Generated at 2022-06-26 08:15:48.147138
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    lock_0 = Semaphore(1)
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_0.release()
    lock_

# Generated at 2022-06-26 08:15:51.342566
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    assert condition_0.__repr__() == "<Condition waiters[0]>"


# Generated at 2022-06-26 08:15:55.730925
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    test_lock_0 = BoundedSemaphore()
    try:
        test_lock_0.release()
    except ValueError as error_0:
        asserterror = str(error_0)
        assert(asserterror == 'Semaphore released too many times')
        lock_0 = Lock()


# Generated at 2022-06-26 08:16:14.311873
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    print('\nTesting Semaphore.release')
    lock_1 = Semaphore(1)
    lock_1.release()
    print('Semaphore.release')


# Generated at 2022-06-26 08:16:20.692365
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    lock_0.__aexit__()
    lock_0.release()
    lock_0.release()
    assert lock_0._block._value == 0
    assert lock_0.__repr__() == '<Lock _block=<BoundedSemaphore [unlocked,value:1]>>'
    lock_0.acquire()
    assert lock_0._block._value == 0


# Generated at 2022-06-26 08:16:29.348476
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    semaphore_0 = Semaphore(0)
    semaphore_0_1 = Semaphore(0)
    assert_raises(
        AssertionError, assert_equal, semaphore_0, semaphore_0_1
    )
    semaphore_0_1.release()
    assert_equal(semaphore_0, semaphore_0_1)


# Generated at 2022-06-26 08:16:32.591040
# Unit test for method notify of class Condition
def test_Condition_notify():
    # Test case
    lock_0 = Lock()
    cond_0 = Condition()
    lock_0.acquire()
    cond_0.notify()

    lock_1 = Lock()
    cond_1 = Condition()
    lock_1.acquire()
    cond_1.notify(1)

    try:
        lock_2 = Lock()
        cond_2 = Condition()
        lock_2.acquire()
        cond_2.notify(None)
    except TypeError as ex:
        print(ex)



# Generated at 2022-06-26 08:16:35.801521
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    pass

if __name__ == '__main__':
    print(Lock)
    test_case_0()

# Generated at 2022-06-26 08:16:38.853453
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    lock_0 = Lock()
    condition_0 = Condition()
    condition_0.notify_all()



# Generated at 2022-06-26 08:16:43.808669
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    lock_0 = Lock()
    assert lock_0._value
    lock_0.release()
    # This assert fails
    assert not lock_0._value

if __name__ == "__main__":
    lock_0 = Lock()
    assert lock_0._value
    lock_0.release()
    # This assert fails
    assert not lock_0._value

# Generated at 2022-06-26 08:16:49.711747
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    # Create an instance of Condition
    condition_0 = Condition()

    print("Before notify_all")

    # Invoke method notify_all of class Condition
    condition_0.notify_all()

    print("After notify_all")


# Generated at 2022-06-26 08:16:54.688714
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()

    # line:       is_set()
    # expected:   False
    if event_0.is_set():
        assert False

    # line:       set()
    event_0.set()
    # expected:   True
    if not event_0.is_set():
        assert False


# Generated at 2022-06-26 08:16:59.907880
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    # Test case 0
    test_case_0()
    lock = Lock()
    return lock.__repr__()

if __name__ == "__main__":
    print(test_Semaphore___repr__())

# Generated at 2022-06-26 08:17:20.208107
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    lock_0 = Semaphore()
    lock_0.release()
    # Verify object lock_0 is of the type Semaphore
    assert isinstance(lock_0, Semaphore)
    # Verify value of member _value of object lock_0 with expected value
    assert lock_0._value == 1
    # Verify value of member _waiters of object lock_0 with expected value
    assert lock_0._waiters == deque()
    # Verify value of member _value of object lock_0 with expected value
    assert lock_0._value == 1
    # Verify value of member _waiters of object lock_0 with expected value
    assert lock_0._waiters == deque()
    lock_0.release()
    # Verify object lock_0 is of the type Semaphore
    assert isinstance(lock_0, Semaphore)

# Generated at 2022-06-26 08:17:24.630964
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    try:
        lock_0.__aenter__()
    except AssertionError:
        assert True
    except:
        assert False


# Generated at 2022-06-26 08:17:27.033314
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    obj = Semaphore()
    obj.acquire()


# Generated at 2022-06-26 08:17:29.859527
# Unit test for method release of class Lock
def test_Lock_release():
    lock_0 = Lock()
    lock_0.release()


# Generated at 2022-06-26 08:17:35.895284
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    lock_0 = Lock()
    # Assert that ValueError is raised by method release of class BoundedSemaphore
    try:
        lock_0.release()
    except ValueError:
        assert True
    else:
        assert False




# Generated at 2022-06-26 08:17:44.692602
# Unit test for method notify of class Condition
def test_Condition_notify():
    lock_5 = Lock()
    condition_5 = Condition()
    # @gen.coroutine
    async def func_0():
        await lock_5.acquire()
        print("Get lock  5")
        await lock_5.acquire()
        print("Get lock  5")
        await lock_5.acquire()
        print("Get lock  5")
        await lock_5.acquire()
        print("Get lock  5")
        await lock_5.acquire()
        print("Get lock  5")
        await lock_5.acquire()
        print("Get lock  5")
        await lock_5.acquire()
        print("Get lock  5")
        await lock_5.acquire()
        print("Get lock  5")
        await lock_5.acquire()

# Generated at 2022-06-26 08:17:53.268953
# Unit test for method wait of class Condition
def test_Condition_wait():
    c = Condition()
    f = c.wait(timeout=3)
    print ("f.done() =", f.done())
    print ("f.cancelled() =", f.cancelled())
    print ("f.running() =", f.running())
    print ("f.result() =", f.result())
    # Need to call notify for wait to return.
    result = c.notify()
    print ("c.notify() =", result)
    print ("f.result() =", f.result())
    print ("f.done() =", f.done())


if __name__ == '__main__':
    ioloop.run_sync(test_Condition_wait)

# Generated at 2022-06-26 08:17:55.117825
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()        
    result = c.__repr__()
    assert result == "<Condition>"


# Generated at 2022-06-26 08:17:56.370891
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    __repr__result = Condition()
    print(__repr__result)


# Generated at 2022-06-26 08:17:57.837676
# Unit test for method notify of class Condition
def test_Condition_notify():
    # create object of type Condition
    cond_0 = Condition()


# Generated at 2022-06-26 08:18:26.906805
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    lock_0.__aexit__()


# Generated at 2022-06-26 08:18:37.025384
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import random
    import threading
    import time
    from tornado import gen
    from tornado.ioloop import IOLoop

    class sync_barrier(object):
        def __init__(self, num):
            self.num = num
            self.count = 0
            self.lock = threading.Lock()
            self.cv = threading.Condition(self.lock)

        def wait(self):
            with self.cv:
                self.count += 1
                if self.count == self.num:
                    self.cv.notify_all()
                    return
                while self.count != self.num:
                    self.cv.wait()

    class Semaphore_Checker(object):
        def __init__(self, Semaphore_checker_num, barrier):
            self.Semaphore_checker_num

# Generated at 2022-06-26 08:18:40.391464
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)

test_Condition_notify()



# Generated at 2022-06-26 08:18:43.579990
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    runner = Semaphore_acquire(sem)
    IOLoop.current().add_callback(runner)


# Generated at 2022-06-26 08:18:55.985644
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore(0)

    def worker_0():
        with (yield s.acquire()):
            print("Worker 0 is working")
        print("Worker 0 is done")

    def worker_1():
        with (yield s.acquire()):
            print("Worker 1 is working")
        print("Worker 1 is done")

    def worker_2():
        with (yield s.acquire()):
            print("Worker 2 is working")
        print("Worker 2 is done")

    def main():
        IOLoop().instance().run_sync(lambda: gen.multi([worker_0(), worker_1(), worker_2()]))

    main()

"""
----------------------------------------------------------
"""

# Generated at 2022-06-26 08:18:58.445343
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    lock_0 = Condition()
    print(lock_0)

# Generated at 2022-06-26 08:19:06.470990
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    lock = Semaphore()
    # The test requires that we run asyncio using `tornado.platform.asyncio.AsyncIOMainLoop`
    # and since this is the first test that runs we need to set it up
    # AsyncIOMainLoop().install()
    # Creating a synchronous loop
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(lock.acquire())
    assert lock._value == 0
    lock.release()
    assert lock._value == 1



# Generated at 2022-06-26 08:19:08.814357
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    test_case_0()


# Generated at 2022-06-26 08:19:10.785261
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    try:
        lock_0.__aexit__('a', 'a', 'a')
    except RuntimeError as error_0:
        print(error_0)


# Generated at 2022-06-26 08:19:13.517679
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-26 08:20:09.747703
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    
    run_coroutine(test_case_0())

# Generated at 2022-06-26 08:20:18.101253
# Unit test for method wait of class Event
def test_Event_wait():
    # Necessary setup for the test
    event_0 = Event()
    event_0.lock = Lock()
    event_0._value = True
    # Timeout finite
    timeout_0 = 0.0
    # Expected result for the test
    result_0 = None
    # Execute test
    result_1 = event_0.wait(timeout_0)
    # Compare result to expected resul
    assert result_1 == result_0


# Generated at 2022-06-26 08:20:19.181993
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    test_case_0()

test_Semaphore_release()

# Generated at 2022-06-26 08:20:23.779496
# Unit test for method release of class Lock
def test_Lock_release():
    lock_0 = Lock()
    try:
        lock_0.release()
    except ValueError as error:
        print('exception raised: ', error)
    except (TypeError, RuntimeError) as error:
        print('exception raised: ', error)


# Generated at 2022-06-26 08:20:28.391009
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem_0 = Semaphore()
    async with sem_0:
        assert sem_0.is_set()
    assert sem_0.is_set()


# Generated at 2022-06-26 08:20:30.986247
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.clear()
    event_0.set()
    event_0.wait()
    event_0.wait()
    event_0.wait()
    gen.sleep(0.5)
    event_0.wait()


# Generated at 2022-06-26 08:20:32.753616
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    assert repr(condition_0) == "<Condition>"



# Generated at 2022-06-26 08:20:36.187454
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    lock_0 = Condition()
    assert lock_0.__repr__() == "<Condition>"


# Generated at 2022-06-26 08:20:40.097330
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    lock_0 = Semaphore()
    lock_0.acquire()
    lock_0.acquire()
    lock_0.acquire()


# Generated at 2022-06-26 08:20:42.747970
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(value=1)
    fut = sem.acquire()



# Generated at 2022-06-26 08:23:39.087382
# Unit test for method wait of class Event
def test_Event_wait():
    lock = Lock()
    condition = Condition()

if __name__ == "__main__":
    test_case_0()
    test_Event_wait()

# Generated at 2022-06-26 08:23:41.749503
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem_0 = Semaphore()
    sem_0.acquire()


# Generated at 2022-06-26 08:23:48.361825
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    io_loop = ioloop.IOLoop.current()
    io_loop.add_callback(setter)
    fut = event.wait()
    io_loop.add_future(fut, callback)
    io_loop.start()


# Generated at 2022-06-26 08:23:53.217276
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond_0 = Condition()
    cond_1 = Condition(1)
    cond_0.notify_all()
    cond_1.notify_all()


# Generated at 2022-06-26 08:24:02.307566
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    try:
        lock_0 = Semaphore(0, 4)
        lock_0.__aenter__()
    except TypeError:
        raise AssertionError("TypeError was raised in method __aenter__")
    except AttributeError:
        raise AssertionError("AttributeError was raised in method __aenter__")
    except RuntimeError:
        return
    except AssertionError:
        raise AssertionError("AssertionError was raised in method __aenter__")
    except Exception:
        raise AssertionError("Wrong exception was raised in method __aenter__")
    raise AssertionError("Method __aenter__ did not raise an exception")


# Generated at 2022-06-26 08:24:07.435930
# Unit test for method set of class Event
def test_Event_set():
    evt = Event()
    # Test whether the lock is set
    if evt.is_set():
        print("Unit test for method set of class Event passed")
    else:
        print("Unit test for method set of class Event failed")


# Generated at 2022-06-26 08:24:10.752332
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # Setup test fixture
    sem0 = Semaphore(1)

    # The code to be tested
    timeout = None
    with pytest.raises(gen.TimeoutError):
        with gen.with_timeout(timeout, sem0.acquire()):
            pass



# Generated at 2022-06-26 08:24:14.446731
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()
    assert lock_0._block._value == 0


# Generated at 2022-06-26 08:24:16.452429
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    result = condition.notify(2)



# Generated at 2022-06-26 08:24:18.973301
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    future_0 = lock_0.__aenter__()

