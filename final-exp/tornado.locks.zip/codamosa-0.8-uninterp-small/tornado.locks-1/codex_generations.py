

# Generated at 2022-06-26 08:14:56.181612
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1) # create a Semaphore
    sem.acquire() # acquire the Semaphore
    assert(sem._value == 0) # the value should be zero now


# Generated at 2022-06-26 08:15:04.857823
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    semaphore_0 = Semaphore(3)
    assert repr(semaphore_0) == "<Semaphore [unlocked,value:3]>"
    semaphore_0.release()
    assert repr(semaphore_0) == "<Semaphore [unlocked,value:4]>"
    semaphore_0.release()
    assert repr(semaphore_0) == "<Semaphore [unlocked,value:5]>"
    semaphore_0.release()
    assert repr(semaphore_0) == "<Semaphore [unlocked,value:6]>"


# Generated at 2022-06-26 08:15:13.884452
# Unit test for method wait of class Condition
def test_Condition_wait():
    ev = Condition()
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield gen.sleep(100)
        yield ev.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        yield gen.sleep(10)
        ev.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:15:20.512805
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    print("runnning test_Semaphore_acquire")
    semaphore_0 = Semaphore()
    semaphore_0.acquire()
    semaphore_0.release()
    print("finished running test_Semaphore_acquire")


# Generated at 2022-06-26 08:15:24.361713
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test with input:
    condition = Condition()
    assert repr(condition) == '<Condition>'
    condition._waiters.append(1)
    assert repr(condition) == '<Condition waiters[1]>'



# Generated at 2022-06-26 08:15:34.807881
# Unit test for method wait of class Condition
def test_Condition_wait():
    cond_0 = Condition()
    # Call method notify of class Condition.
    # Check for the type of the method and its outcome.
    result_type_bool = isinstance(cond_0.notify(), bool)
    assert result_type_bool == True, "Function test_Condition_wait() failed - The result should be of type <class 'bool'>"
    assert result_type_bool == True, "Function test_Condition_wait() failed - The outcome should be true."



# Generated at 2022-06-26 08:15:38.597690
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    print('started')
    lock_0 = Lock()
    # The following call to method __aenter__ of lock_0 executes __enter__() method of class _ReleasingContextManager
    # which calls method release of class BoundedSemaphore with no parameters
    lock_0.__aenter__()
    # The following call to method __aexit__ of lock_0 executes __exit__() method of class _ReleasingContextManager
    # which calls method release of class BoundedSemaphore with no parameters
    lock_0.__aexit__(None, None, None)
    print('done')


# Generated at 2022-06-26 08:15:40.369292
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    event_0 = Event()
    event_0.notify_all()


# Generated at 2022-06-26 08:15:42.405740
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond_0 = Condition()
    cond_0.notify()
    cond_0.notify(2)


# Generated at 2022-06-26 08:15:45.804665
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    async with sem:
        pass
    # Now the semaphore has been released.


# Generated at 2022-06-26 08:15:59.777647
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore_0 = Semaphore()
    semaphore_0.release()
    semaphore_0.release()

# Generated at 2022-06-26 08:16:03.562808
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()
    assert_equals(lock_0, Lock())


# Generated at 2022-06-26 08:16:10.944249
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Create a test Semaphore
    semaphore_0 = Semaphore()

    # Test acquire, acquire_nowait
    # acquire return a Future object, which uses to control the waiting process

    # Start worker_0 and it will acquire the Semaphore
    worker_0 = worker(semaphore_0, False)

    # Start worker_1 to acquire the semaphore
    worker_1 = worker(semaphore_0, False)

    # Test acquire_nowait, it should return false since semaphore is fully taken by worker_0
    # If semaphore.acquire_nowait == True, print "acquire semaphore by worker_2 now"
    # If semaphore.acquire_nowait == False, print "worker_2 not getting semaphore"

# Generated at 2022-06-26 08:16:13.866472
# Unit test for method wait of class Condition
def test_Condition_wait():
    # Create a condition object
    c = Condition()

    # Call method wait
    f = c.wait()

    # Check the type of the return value
    assert isinstance(f, Future)


# Generated at 2022-06-26 08:16:22.002948
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    condition_0.wait()
    event_0 = Event()
    condition_0.wait(event_0)
    condition_0.wait(event_0, timeout=1)
    condition_0.wait(event_0, timeout=condition_0)
    condition_0.wait(timeout=1)
    condition_0.wait(timeout=condition_0)
    event_0.wait()
    event_0.wait(timeout=1)
    event_0.wait(timeout=condition_0)
    event_0.wait()
    event_0.wait(timeout=1)
    event_0.wait(timeout=condition_0)


# Generated at 2022-06-26 08:16:25.170891
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    event_0 = Event()
    event_0.clear()
    flag_0 = True
    try:
        try:
            lock_0 = Lock()
            with pytest.raises(RuntimeError) as exception_0:
                lock_0.__aenter__()
                flag_0 = False
        except:
            flag_0 = False
    finally:
        if flag_0:
            event_0.set()


# Generated at 2022-06-26 08:16:30.662484
# Unit test for method release of class Lock
def test_Lock_release():
    lock_0 = Lock()
    assert lock_0._block._value == 1
    try:
        lock_0.release()
    except:
        assert True
    lock_0._block._value = 0
    try:
        lock_0.release()
    except:
        assert False


# Generated at 2022-06-26 08:16:42.053564
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    # test for branch if self.is_set()
    event_0.set()
    assert event_0.wait()
    # test for branch if self._value
    event_0.clear()
    assert not event_0.wait()
    # test for branch if not self._value
    assert not event_0.wait()
    # test for branch if timeout is None
    assert not event_0.wait(None)
    # test for branch if timeout is not None
    assert not event_0.wait(10)


# Generated at 2022-06-26 08:16:49.935398
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = test_case_0()
    timeout = None  # type: Optional[Union[float, datetime.timedelta]]
    timeout_1 = None  # type: Optional[Union[float, datetime.timedelta]]
    fut_0 = event_0.wait(timeout=timeout_1)
    return fut_0



# Generated at 2022-06-26 08:17:02.955278
# Unit test for method wait of class Condition
def test_Condition_wait():
    # All the conditions are init to false
    condition_0 = Condition()
    condition_1 = Condition()
    condition_2 = Condition()
    condition_3 = Condition()
    condition_4 = Condition()
    condition_5 = Condition()
    condition_6 = Condition()
    condition_7 = Condition()

    # The result of testing function
    result = condition_0.wait()
    result = condition_0.wait()
    result = condition_1.wait()
    result = condition_2.wait()
    result = condition_3.wait()
    result = condition_4.wait()
    result = condition_5.wait()
    # The result of testing function
    result = condition_7.wait()
    result = condition_6.wait()
    result = condition_0.wait()
    result = condition_0.wait()

# Generated at 2022-06-26 08:17:25.210943
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)



# Generated at 2022-06-26 08:17:37.667787
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    # Test condition
    condition_1 = Condition()
    # Test waiter
    waiter_0 = condition_1.wait()
    # Test waiter
    waiter_1 = condition_1.wait()
    # Test waiter
    waiter_2 = condition_1.wait()
    # Test notify_all of condition
    condition_1.notify_all()
    assert(waiter_0 == True)
    assert(waiter_1 == True)
    assert(waiter_2 == True)
    assert(condition_1.__repr__() == "<Condition>")
    # Test wait of condition
    waiter_3 = condition_1.wait()
    assert(waiter_3 == False)
    
    

# Generated at 2022-06-26 08:17:40.708809
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    event_0 = Condition()
    str_arg_0 = event_0.__repr__()
    assert str_arg_0 == "<Condition>"


# Generated at 2022-06-26 08:17:50.681915
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Create object of class Semaphore with parameter value=3
    sem = Semaphore(3)

    print("Before calling acquire() value of sem : ", sem._value)
    # Calling method acquire()
    sem.acquire()
    print("After calling acquire() value of sem : ", sem._value)
    # Check value of sem._value
    if sem._value == 2:
        print("test_Semaphore_acquire SUCCESS")
        return
    else:
        print("test_Semaphore_acquire FAIL")
        return


# Generated at 2022-06-26 08:18:02.480711
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    fs = []
    def f1():
        print("wait")
        c.wait()
        print("notify")
    def f2():
        print("wait")
        c.wait()
        print("notify")
    for i in range(5): 
        fs.append(f1)
        fs.append(f2)
    
    def run():
        for f in fs:
            f()

    for th in [Thread(target=run) for _ in range(2)]:
        th.start()

    sleep(5)
    c.notify_all()

if __name__ == "__main__":
    test_Condition_notify_all()

# Generated at 2022-06-26 08:18:07.529320
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.locks import Condition
    from tornado.platform.asyncio import to_asyncio_future

    condition_0 = Condition()
    assert condition_0.__repr__() == "<Condition>"



# Generated at 2022-06-26 08:18:14.166525
# Unit test for method notify of class Condition
def test_Condition_notify():
    import time
    import datetime

    cond = Condition()

    @gen.coroutine
    def waiter():
        print("About to wait")
        yield cond.wait(timeout=time.time() + 5)
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        cond.notify()
        print("Done notifying")

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(waiter)
    io_loop.run_sync(notifier)


# Generated at 2022-06-26 08:18:17.987618
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    assert condition_0.__repr__() == "<Condition>"


# Generated at 2022-06-26 08:18:20.168796
# Unit test for method notify of class Condition
def test_Condition_notify():
    event_0 = Event()
    event_0.notify()


# Generated at 2022-06-26 08:18:21.607265
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    obj = Condition()
    obj.__repr__()



# Generated at 2022-06-26 08:18:45.209566
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    event_0 = Event()
    event_0.set()
    event_0.clear()


# Generated at 2022-06-26 08:18:48.765713
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    event_0 = Event()
    assert repr(event_0) == "<Event>"


# Generated at 2022-06-26 08:18:55.006313
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore(1)
    assert_equals(semaphore_0._value, 1)

    #
    #Wait here
    #
    assert_equals(semaphore_0._value, 0)

    #
    #Wait here
    #
    assert_equals(semaphore_0._value, 1)


# Generated at 2022-06-26 08:18:59.334390
# Unit test for method wait of class Event
def test_Event_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    event = Event()

    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-26 08:19:04.182404
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    logging.info("\nUnit test for method acquire of class Semaphore")
    event_0 = Event()

if __name__ == '__main__':
    test_case_0()
    test_Semaphore_acquire()

# Generated at 2022-06-26 08:19:16.578307
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait(timeout=datetime.timedelta(seconds=1))
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)

# test_Condition_wait()



# Generated at 2022-06-26 08:19:23.492087
# Unit test for method notify of class Condition
def test_Condition_notify():
    event_1 = Event()
    event_1.set()
    condition_1 = Condition()
    print(condition_1.notify(2))
    print(condition_1.notify())
    print(condition_1.notify())


# Generated at 2022-06-26 08:19:26.232309
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    aio_condition = Condition()
    aio_condition.notify_all()


# Generated at 2022-06-26 08:19:29.433248
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    print("Unit test for method release of class Semaphore successfully!")

# Generated at 2022-06-26 08:19:31.196374
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()


# Generated at 2022-06-26 08:20:01.461703
# Unit test for method wait of class Condition
def test_Condition_wait():
    # wait until event is set
    condition = Condition()
    event_1 = Event()

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        # async wait until condition is notified
        yield condition.wait()
        print("I'm done waiting")
        event_1.set()

    # notify the condition
    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    IOLoop.current().run_sync(waiter)
    IOLoop.current().run_sync(notifier)
    event_1.wait()


# Generated at 2022-06-26 08:20:04.828970
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    assert isinstance(condition_0.wait(), types.CoroutineType)


# Generated at 2022-06-26 08:20:15.116336
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)
    async def worker_0(worker_id_0):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id_0)
            await test_Semaphore_acquire_resource()
        finally:
            print("Worker %d is done" % worker_id_0)
            sem.release()

    async with sem.acquire():
        print("Worker_0 is working")
        await test_Semaphore_acquire_resource()
        print("Worker_0 is done")

    # Now the semaphore has been released.
    async def test_Semaphore_acquire_resource():
        print("test_Semaphore_acquire_resource")

    async def runner_0():
        await worker_0(0)

# Generated at 2022-06-26 08:20:21.782659
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    result = await sem.__aenter__()
    if result is None:
        print("test for method __aenter__ of class Semaphore finished")
    else:
        print("test for method __aenter__ of class Semaphore failed")


# Generated at 2022-06-26 08:20:23.267336
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()


# Generated at 2022-06-26 08:20:35.545052
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)

    @gen.coroutine
    def worker(worker_id):
        with (yield sem.acquire()):
            print("Worker %d is working" % worker_id)
            yield use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def worker_a(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        print("Worker %d is done" % worker_id)

    def runner():
        ioloop.IOLoop.current().run_sync(lambda : gen.multi([worker(i) for i in range(3)]))

    def runner_a():
        iol

# Generated at 2022-06-26 08:20:42.067132
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()
    lock_1 = Lock()
    # verification expression for the call lock_1.__aenter__()
    try:
        assert lock_1.__aenter__() == None
    except:
        raise AssertionError()


# Generated at 2022-06-26 08:20:44.542320
# Unit test for method release of class Lock
def test_Lock_release():
    lock_0 = Lock()
    try:
        lock_0.release()
    except ValueError:
        pass
    except:
        raise AssertionError('Expected ValueError')


# Generated at 2022-06-26 08:20:48.398352
# Unit test for method wait of class Event
def test_Event_wait():
    # Initialize an event and wait for it using asyncio.
    event_0 = Event()
    event_0.wait()


# Generated at 2022-06-26 08:20:54.699263
# Unit test for method notify of class Condition
def test_Condition_notify():
    # Initialize a condition object
    cond = Condition()

    # A flag to keep track if a notification is received
    cond_event = Event()

    # A waiter to wait for cond
    waiter = cond.wait()

    # Notify cond
    cond.notify()

    # Set cond_event if cond is notified
    def _set_flag(cond) -> None:
        cond_event.set()

    waiter.add_done_callback(_set_flag)

    # Make sure cond_event is set
    cond_event.wait()

    assert cond_event.is_set()



# Generated at 2022-06-26 08:21:36.666034
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_0.set()
    fut_0 = event_0.wait()
    assert None == fut_0.result()


# Generated at 2022-06-26 08:21:42.318959
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    # TODO: Add tests for __repr__ in class Semaphore to exercise the following:
    # - Check the return being a str
    # - TODO: Check the if self._waiters: code in the if
    # - TODO: Check the res = super().__repr__() return value
    # - TODO: Check the while self._waiters: code in the while
    # - TODO: Check the semaphore.release() call
    event_ = Event()
    semaphore = Semaphore(2)
    semaphore._waiters.append(event_)
    res = semaphore.__repr__()
    # print(res)
    assert type(res) == str


# Generated at 2022-06-26 08:21:46.991402
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    obj = Semaphore(2)
    # Test method __aenter__ of class Semaphore
    assert obj.__aenter__() is None


# Generated at 2022-06-26 08:21:50.161475
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    x = Semaphore()
    try:
        x.__aenter__()
        assert False
    except gen.TimeoutError:
      assert True


# Generated at 2022-06-26 08:21:51.654461
# Unit test for method wait of class Event
def test_Event_wait():
    test_case_0()


# Generated at 2022-06-26 08:21:56.742340
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()

    # Invoke method
    result = condition_0.__repr__()

    # Check result
    assert(isinstance(result, str))


# Generated at 2022-06-26 08:21:59.370333
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    sem.acquire()


# Generated at 2022-06-26 08:22:07.919276
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # If there have not been any releases to semaphore, acquire() should
    # return a future and wait for semaphore to release a unit
    sem_0_in = Semaphore(0)
    assert (not sem_0_in._value)
    assert (sem_0_in._waiters)

    sem_0_out = sem_0_in.acquire()
    assert (sem_0_out)
    assert (isinstance(sem_0_out, Future))
    assert (sem_0_out.done())

    # If there is more than one unit release to semaphore, acquire() should
    # return a future which is set to _ReleasingContextManager immediately
    sem_1_in = Semaphore(1)
    assert (sem_1_in._value)

# Generated at 2022-06-26 08:22:11.853427
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    event = Event()
    assert event.__repr__() == "<Event pending[0]>"
    event.set()
    assert event.__repr__() == "<Event pending[0]>"


# Generated at 2022-06-26 08:22:18.627723
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # I do not understand how to do this unit test yet
    # I have to learn how to build a unit test for a function with just a print function
    sem = Semaphore(1)
    sem.release()

# Test for declaration of the Semaphore class

# Generated at 2022-06-26 08:23:03.971901
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()


# Generated at 2022-06-26 08:23:06.051879
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    test_case_0()


# Generated at 2022-06-26 08:23:09.125834
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()
    test_case_0()


# Generated at 2022-06-26 08:23:13.634780
# Unit test for method release of class Lock
def test_Lock_release():
    event_1 = Lock()
    check_5 = True
    try:
        event_1.release()
    except(RuntimeError):
        check_5 = False
    if check_5 != False:
        print("unit test for method release of class Lock failed!")
        print("returned value is not false")
        print("returned value is :")
        print(check_5)
        return False
    return True


# Generated at 2022-06-26 08:23:17.156891
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    event_0 = Event()
    mutex = Lock()
    cond = Condition(mutex)
    cond.notify(0)
    cond.notify_all()
    cond.wait(event_0)


# Generated at 2022-06-26 08:23:30.093791
# Unit test for method notify of class Condition
def test_Condition_notify():
    '''
    测试如下代码：
        condition = Condition()
        await condition.wait()
        condition.notify()
    '''
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield event_0.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        event_0.set()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:23:37.165008
# Unit test for method release of class Lock
def test_Lock_release():
    lck0 = Lock()
    lck0.release()

    lck0 = Lock()
    lck0.__aenter__()
    lck0.release()
    
    lck0 = Lock()
    lck0.__aexit__(None, None, None)
    #lck0.release()



# Generated at 2022-06-26 08:23:40.814666
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    try:
        lock.__aexit__()
    except:
        lock.release()


# Generated at 2022-06-26 08:23:49.416594
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    # __aexit__ is analog to __exit__ with some differences:
    # 1) __aexit__ is not error handling method
    # 2) __aenter__ is not error throwing method
    # 3) __aenter__ is not blocking (and __aexit__ too)
    # => method __aexit__ does not need to be tested in detail
    test_case = Semaphore(1)
    test_case.__aexit__(None, None, None)


# Generated at 2022-06-26 08:23:50.702277
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    a = c.wait()
    b = c.wait()
    c.notify_all()

