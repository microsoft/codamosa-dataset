

# Generated at 2022-06-26 08:15:01.133114
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    assert event_0.is_set() == False
    event_0.set()
    assert event_0.is_set() == True
    print("Unit test for method set of class Event: pass")


# Generated at 2022-06-26 08:15:09.100147
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # The next line raises a "NameError: name 'value' is not defined"
    # because value is an undefined local variable
    # bs = BoundedSemaphore(value)
    bs = BoundedSemaphore(1)
    bs.release()
    # TODO: Add some test



# Generated at 2022-06-26 08:15:14.202120
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Tested method: __repr__
    condition_0 = Condition()
    str_0 = condition_0.__repr__() # __repr__
    str_1 = "<Condition>"
    assert str_0 == str_1, "Expected: {0}. Actually: {1}".format(str_0, str_1)


# Generated at 2022-06-26 08:15:17.567392
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify(1)



# Generated at 2022-06-26 08:15:25.049380
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    waiter_0 = Future()
    waiter_0.cancel()
    waiter_1 = Future()
    waiter_1.cancel()
    condition_0._waiters = [waiter_0, waiter_1]
    waiter_2 = Future()
    waiter_3 = Future()
    waiter_3.cancel()
    condition_0._waiters = [waiter_2, waiter_3]
    condition_0.notify_all()


# Generated at 2022-06-26 08:15:31.210530
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    # Test method notify_all of class Condition
    # self.assertEqual(condition_0.notify_all(), None)

    # Test case for bug #2765
    future_0 = Future()
    future_1 = Future()

    task_0 = [future_0, future_1]
    future_0.set_result(True)
    future_1.set_result(True)
    # Test method notify_all of class Condition
    # self.assertEqual(condition_0.notify_all(), None)



# Generated at 2022-06-26 08:15:37.018899
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()
    future_0 = semaphore_0.acquire()
    future_0


# Generated at 2022-06-26 08:15:44.694919
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_0 = Lock()
    from tornado.concurrent import Future
    Future()
    from tornado.ioloop import IOLoop
    IOLoop.current()
    lock_0.acquire(1)
    lock_0.release()
    lock_0.__aexit__(RuntimeError, None, None)


# Generated at 2022-06-26 08:15:45.955464
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    aenter = Lock()


# Generated at 2022-06-26 08:15:49.753939
# Unit test for method set of class Event
def test_Event_set():

    timeout_garbage_collector_0 = _TimeoutGarbageCollector()
    event_0 = Event()

    event_0.set()





# Generated at 2022-06-26 08:16:08.092948
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    semaphore_0 = Semaphore(1)
    assert semaphore_0.__repr__() == "<Semaphore [unlocked,value:1]>"
    assert Semaphore(0).__repr__() == "<Semaphore [locked]>"
    assert Semaphore().__repr__() == "<Semaphore [unlocked,value:1]>"


# Generated at 2022-06-26 08:16:13.490566
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()
    condition_0.notify_all()
    condition_0.notify_all()

# Generated at 2022-06-26 08:16:15.611240
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()


# Generated at 2022-06-26 08:16:18.946706
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    timeout = 100
    timeout_fut = event.wait(timeout)
    print(timeout_fut)


# Generated at 2022-06-26 08:16:23.987360
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.clear()
    event_0.set()
    assert (event_0.is_set() is True), "method test_Event_set failed"


# Generated at 2022-06-26 08:16:29.216968
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    try:
        sem.__aenter__()
    except RuntimeError as re:
        assert (str(re) == "Use 'async with' instead of 'with' for Semaphore")


# Generated at 2022-06-26 08:16:31.163392
# Unit test for method set of class Event
def test_Event_set():
    timeout_garbage_collector_1 = _TimeoutGarbageCollector()

    event = Event()
    event.set()


# Generated at 2022-06-26 08:16:37.114732
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Input parameters
    condition_0 = Condition()

    # Output parameters

    # Call method
    result_0 = condition_0.__repr__()

    # Assertions
    assert isinstance(result_0, str)


# Generated at 2022-06-26 08:16:48.416761
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    value = 2
    semaphore_0 = Semaphore(value)

    # Try to acquire the lock. This should return immediately when the lock is
    # available.

    semaphore_0.acquire()

    # Start a coroutine that is blocked on the lock.
    # def worker(worker_id):
    #     with (yield semaphore.acquire()):
    #         print("Worker %d is working" % worker_id)
    #         yield use_some_resource()
    #
    #     # Now the semaphore has been released.
    #     print("Worker %d is done" % worker_id)

    # class Worker(object):
    #     def __init__(self, worker_id):
    #         self.worker_id = worker_id
    #
    #     async

# Generated at 2022-06-26 08:16:57.848171
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()
    f1 = c.wait(datetime.timedelta(seconds=1))
    f2 = c.wait(datetime.timedelta(seconds=1))
    gen.sleep(0.1)
    c.notify()
    assert f1.result()
    assert not f2.done()
    gen.sleep(0.1)
    assert not f2.done()
    c.notify(1)
    assert f2.result()
    future_set_result_unless_cancelled(f1, False)
    future_set_result_unless_cancelled(f2, False)


# Generated at 2022-06-26 08:17:14.326779
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    try:
        condition_0.notify()
    except:
        assert False
    assert True


# Generated at 2022-06-26 08:17:20.082047
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()

    async def __aenter__():
        await lock.acquire()
    
    async def __aexit__(typ, value, tb):
        lock.release()
    

# Generated at 2022-06-26 08:17:23.329024
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    condition_1 = Condition()
    assertTrue(condition_1 is condition_0)


# Generated at 2022-06-26 08:17:30.351854
# Unit test for method notify of class Condition
def test_Condition_notify():
    timeout_garbage_collector_0 = _TimeoutGarbageCollector()
    condition_0 = Condition()
    waiter_0 = Future()
    condition_0._waiters.append(waiter_0)
    # waiter_0 is not done
    # waiter_0 was appended to the list of waiters.
    waiter_1 = Future()
    condition_0._waiters.append(waiter_1)
    # waiter_1 is not done
    # waiter_1 was appended to the list of waiters.
    waiter_2 = Future()
    condition_0._waiters.append(waiter_2)
    # waiter_2 is not done
    # waiter_2 was appended to the list of waiters.
    n_0 = 3
    waiters_0 = []

# Generated at 2022-06-26 08:17:34.492046
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    value_1 = 1
    semaphore_0 = Semaphore(value_1)
    semaphore_0.__aenter__()


# Generated at 2022-06-26 08:17:35.366383
# Unit test for method set of class Event
def test_Event_set():
    e = Event()
    e.set()
    e.set()


# Generated at 2022-06-26 08:17:39.801743
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():

    # Arrange
    lock_0 = Lock()

    # Act
    lock_0.__aexit__(None, None, None)



# Generated at 2022-06-26 08:17:43.399557
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    # Method call - event_0.set()
    event_0.set()


# Generated at 2022-06-26 08:17:47.263801
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)

    # Join all workers.
    GenMulti([worker(i) for i in range(3)])

# Generated at 2022-06-26 08:18:02.482242
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_1 = Condition()
    waiter_0 = Future()
    waiter_1 = Future()
    waiter_2 = Future()
    waiter_3 = Future()
    waiter_4 = Future()
    waiter_5 = Future()
    waiter_6 = Future()
    waiter_7 = Future()
    waiter_8 = Future()
    waiter_9 = Future()
    # assert waiters is empty
    assert condition_0._waiters == collections.deque()
    assert condition_1._waiters == collections.deque()
    condition_0._waiters = collections.deque([waiter_0])
    # assert waiters is not empty
    assert condition_0._waiters != collections.deque()
    assert condition_0._waiters == collections.deque([waiter_0])
    condition

# Generated at 2022-06-26 08:18:21.568719
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test case data
    condition_0 = Condition()
    result = condition_0.__repr__()
    # Test assertions
    # assert result == True

if __name__ == "__main__":
    test_case_0()
    test_Condition___repr__()

# Generated at 2022-06-26 08:18:26.978855
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(i=1)
    condition_0.notify(i=0)
    condition_0.notify_all()


# Generated at 2022-06-26 08:18:33.698061
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    async def coroutine0() -> None:
        await condition_0.wait()
    gen.coroutine(coroutine0)()
    async def coroutine1() -> None:
        await condition_0.wait()
    gen.coroutine(coroutine1)()
    condition_0.notify_all()
    pass


# Generated at 2022-06-26 08:18:39.174930
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_1 = lock_0
    # START OF TEST

    # Check that the method __aenter__ of class Lock can acquire.
    assert lock_0 is lock_1


# Generated at 2022-06-26 08:18:45.454762
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    n = 1
    # Unit test for Exception raise by Condition.notify
    # Python 3.8+
    def test_additional_test_cases() -> None:
        condition_0.notify(n = 1)
    test_additional_test_cases()
    # Unit test for proper return types of Condition.notify
    # Method notify returns None
    # assert condition_0.notify() is None


# Generated at 2022-06-26 08:18:48.446514
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.acquire()


# Generated at 2022-06-26 08:18:54.616051
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore()

if __name__ == "__main__":
    import unittest

    class TestCases(unittest.TestCase):
        # Test case for method acquire of class Semaphore
        def test_Semaphore_acquire(self):
            test_Semaphore_acquire()

    unittest.main()

# Generated at 2022-06-26 08:19:03.897827
# Unit test for method wait of class Condition
def test_Condition_wait():
    '''
    def wait(self, timeout=None) -> Awaitable[bool]
    Wait for `.notify`.
    Returns a `.Future` that resolves ``True`` if the condition is notified,
    or ``False`` after a timeout.
    '''
    #pass
    c = Condition()
    f = c.wait()
    print(f)
    c.notify()
    print(c)


# Generated at 2022-06-26 08:19:08.305010
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()

    try:
        lock_0.__aenter__()
        assert True
    except:
        assert False
    assert True


# Generated at 2022-06-26 08:19:11.170959
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_1 = Condition()
    condition_1.notify()



# Generated at 2022-06-26 08:19:28.414303
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    gen.coroutine(condition_0.wait)


# Generated at 2022-06-26 08:19:34.756080
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    async def async_fut_event_wait():
        ret = await event_0.wait()
        return ret
    fut = async_fut_event_wait()
    print(fut)


# Generated at 2022-06-26 08:19:43.898277
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    # TODO:
    import typing
    import asyncio
    # timeout_garbage_collector_0 = _TimeoutGarbageCollector()
    # instance_0 = Semaphore()
    # Future_0 = asyncio.Future()
    # Future_1 = gen.Future()
    # coroutine_0 = instance_0.__aexit__()
    # instance_0.release()
    # value = coroutine_0
    # value = Future_0
    # value = instance_0
    # value = instance_0
    # value = typing.Any
    # value = None
    # value = coroutine_0
    # value = None
    # value = Future_1
    # value = None
    # value = None
    # value = None
    # value = timeout_garbage_collector_0
    pass

# Generated at 2022-06-26 08:19:50.439769
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    semaphore_0.acquire()
    __aenter__() # Need to add implementations for seminarore.acquire


# Generated at 2022-06-26 08:19:54.193180
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    timeout_0 = 1
    # test_case_0
    result = event_0.wait(timeout_0)
    print(result)



# Generated at 2022-06-26 08:20:04.741804
# Unit test for method wait of class Condition
def test_Condition_wait():
    # Create instance of class Condition
    condition_0 = Condition()
    # Create variable with type Future
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool
    # Create variable with type bool

# Generated at 2022-06-26 08:20:09.335834
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    try:
        lock_0.__aenter__()
        assert(False)
    except:
        pass


# Generated at 2022-06-26 08:20:12.768546
# Unit test for method release of class Lock
def test_Lock_release():
    lock0 = Lock()
    release0 = lock0.release()

if __name__ == '__main__':
    test_case_0()
    test_Lock_release()

# Generated at 2022-06-26 08:20:18.469439
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    t0 = ioloop.IOLoop.time()
    t1 = ioloop.IOLoop.time()
    condition_0.wait(timeout=datetime.timedelta(seconds=1))



# Generated at 2022-06-26 08:20:28.786348
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.acquire()
    print(lock_0)
    print(bool(lock_0))
    print(str(lock_0))
    print(repr(lock_0))
    # Unit test for method __aenter__ of class Lock

    def test_Lock___aenter__():
        lock_0 = Lock()
        lock_0.acquire()
        print(lock_0)
        print(bool(lock_0))
        print(str(lock_0))
        print(repr(lock_0))
    # Unit test for method __aenter__ of class Lock

    def test_Lock___aenter__():
        lock_0 = Lock()
        lock_0.acquire()
        print(lock_0)
        print(bool(lock_0))
        print

# Generated at 2022-06-26 08:20:46.914388
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()

    lock_0.__aenter__()


# Generated at 2022-06-26 08:20:47.942748
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(int_0=1)


# Generated at 2022-06-26 08:20:56.574822
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()

    # Test the method on an empty Condition
    condition_0.notify()

    # Test the method on an Condition with waiters
    waiter_0 = Future()  # type: Future[bool]
    condition_0._waiters.append(waiter_0)
    future_set_result_unless_cancelled(waiter_0, True)

    # Test the method on an Condition with a waiter that is already done
    condition_0._waiters.append(waiter_0)
    condition_0.notify()


# Generated at 2022-06-26 08:21:06.170016
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    future_0 = Future()
    condition_0 = Condition()
    integer_0 = 0
    for integer_1 in list((True, False, False, False, False, True)):
        future_0.set_result(integer_1)
        integer_0 += 1
        if integer_0 >= 10:
            break
    
    if future_0.done():
        condition_0.notify(1)
        condition_0.notify_all()
    else:
        future_0.set_result(False)


# Generated at 2022-06-26 08:21:11.812915
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()
    cond.wait()
    cond._garbage_collect()
    cond._waiters
    cond.notify_all()
    cond.wait()
    cond.wait()
    cond.notify(n=2)


# Generated at 2022-06-26 08:21:15.232927
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0__aenter__var_0 = lock_0.__aenter__()


# Generated at 2022-06-26 08:21:23.359547
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():

    async def async_func(condition, loop):

        await condition.wait()
        print('I am here!')

    cond = Condition()
    loop = ioloop.IOLoop.current()
    loop.run_sync(lambda: async_func(cond, loop))

    cond.notify_all()
    assert cond._waiters == deque()


# Generated at 2022-06-26 08:21:25.623392
# Unit test for method wait of class Event
def test_Event_wait():
    # Event
    event = Event()
    event.wait()


# Generated at 2022-06-26 08:21:29.619090
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore()
    semaphore_0.acquire()
    # Do something here


# Generated at 2022-06-26 08:21:38.269445
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # Initialize class Semaphore
    semaphore_0 = Semaphore()
    semaphore_1 = Semaphore()
    # Invoke method release of class Semaphore
    semaphore_0.release()
    semaphore_1.release()
    # Unit test: AssertionError reported
    try:
        assert False, "Unit test failed"
    except:
        print("Exception caught")


# Generated at 2022-06-26 08:22:09.328828
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    assert repr(condition_0) == "<Condition waiters[0]>"

# Generated at 2022-06-26 08:22:13.970573
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # Test case 1
    semaphore_0 = BoundedSemaphore(1)
    semaphore_0.release()
    # Test case 2
    semaphore_0 = BoundedSemaphore(1)
    semaphore_0.release()
    # Test case 3
    semaphore_0 = BoundedSemaphore(1)
    semaphore_0.release()


# Generated at 2022-06-26 08:22:17.018299
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    timeout_event = None  # type: Optional[Union[float, datetime.timedelta]]
    timeout_event = None
    event_0.wait(timeout_event)


# Generated at 2022-06-26 08:22:19.053491
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    condition_0.wait()


# Generated at 2022-06-26 08:22:21.241470
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()


# Generated at 2022-06-26 08:22:31.525909
# Unit test for method wait of class Event
def test_Event_wait():
    e = Event()
    f = e.wait()
    print(f)
    f2 = e.wait()
    e.set()
    print(f2)
    e.unset()
    f3 = e.wait()
    e.set()
    print(f3)

if __name__ == "__main__":
    test_case_0()
    test_Event_wait()

# Generated at 2022-06-26 08:22:34.864819
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    assert condition_0.notify_all() is None


# Generated at 2022-06-26 08:22:39.382942
# Unit test for method wait of class Event
def test_Event_wait():
    print("Testing wait...")
    event_0 = Event()
    event_wait_0 = event_0.wait()
    print(event_wait_0)


# Generated at 2022-06-26 08:22:44.574815
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado.locks import Lock
    from tornado.ioloop import IOLoop
    from tornado.gen import Return
    from tornado.testing import AsyncTestCase
    from tornado.gen import coroutine

    def f():
        lock = Lock()

        @coroutine
        def func():
            try:
                yield lock.acquire()
            finally:
                lock.release()
        IOLoop.current().run_sync(func)

    test_case_0()


# Generated at 2022-06-26 08:22:47.444671
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()


# Generated at 2022-06-26 08:23:52.257714
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond0 = Condition()
    assert repr(cond0) == "<Condition>"


# Generated at 2022-06-26 08:24:01.035178
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    future_0 = condition_0.wait()
    future_1 = condition_0.wait()
    future_2 = condition_0.wait()
    future_3 = condition_0.wait()
    future_4 = condition_0.wait(timeout=datetime.timedelta(seconds=1))
    future_5 = condition_0.wait(timeout=datetime.timedelta(seconds=1))
    future_6 = condition_0.wait(timeout=datetime.timedelta(seconds=1))


# Generated at 2022-06-26 08:24:03.981539
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore_0_0 = Semaphore()
    semaphore_0_0.release()


# Generated at 2022-06-26 08:24:06.815785
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()


# Generated at 2022-06-26 08:24:19.286285
# Unit test for method wait of class Condition
def test_Condition_wait():
    # Object of type _TimeoutGarbageCollector
    timeout_garbage_collector_1 = Condition()
    # Bool representing whether we should wait for a condition
    b_0 = True
    # Instance of class Condition
    condition_0 = Condition()
    # Timeout in seconds
    float_0 = 0.5
    # Instance of class IOLoop
    ioloop_0 = ioloop.IOLoop.current()
    # Absolute timeout in seconds
    float_1 = ioloop_0.time() + float_0
    # Bool representing whether we should wait for a condition

    if (b_0):
        b_0 = condition_0.wait(float_1)
        # Bool representing whether we should wait for a condition
        b_0 = condition_0.wait()


# Generated at 2022-06-26 08:24:22.173131
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify()


# Generated at 2022-06-26 08:24:24.890777
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    assert repr(condition_0) == "<Condition>"


# Generated at 2022-06-26 08:24:29.825382
# Unit test for method wait of class Condition
def test_Condition_wait():
    event_0 = Condition()
    event_0.wait(datetime.timedelta(days = 10))
    print("End of test_Condition_wait")



# Generated at 2022-06-26 08:24:32.640594
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore()
    print(sem.acquire(timeout=1))


if __name__ == '__main__':
    test_case_0()
    # test_Semaphore_acquire()