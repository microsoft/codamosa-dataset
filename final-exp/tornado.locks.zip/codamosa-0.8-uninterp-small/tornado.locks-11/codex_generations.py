

# Generated at 2022-06-26 08:14:59.772437
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()


# Generated at 2022-06-26 08:15:04.576523
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    future = condition.wait()

    # Unit test for method notify
    condition.notify()
    assert future.done()  # type: ignore


# Generated at 2022-06-26 08:15:07.241225
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    """Method __aexit__ of class Semaphore"""
    semaphore_0 = Semaphore(2)
    semaphore_0.release()


# Generated at 2022-06-26 08:15:08.515385
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()



# Generated at 2022-06-26 08:15:11.250638
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    str_0 = condition_0.__repr__()


# Generated at 2022-06-26 08:15:15.385553
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()


# Generated at 2022-06-26 08:15:24.992940
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.concurrent import return_future
    from tornado.gen import coroutine
    from tornado.ioloop import IOLoop
    @coroutine
    def some_coroutine():
        pass

    @return_future
    def future_handler(future):
        async def async_some_coroutine():
            return await some_coroutine()
        result = IOLoop.current().run_sync(async_some_coroutine)
        future.set_result(result)

    semaphore_0 = Semaphore()
    future_handler(semaphore_0.acquire())


# Generated at 2022-06-26 08:15:28.259872
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    print(condition.__repr__())


# Generated at 2022-06-26 08:15:38.855821
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    # State of condition_0 has changed, but its value is not used in current scope.
    # So its state after changing is unknown.
    # (The type of the state of condition_0 is int, the value is unknown)
    # State of condition_0 has changed, but its value is not used in current scope.
    # So its state after changing is unknown.
    # (The type of the state of condition_0 is int, the value is unknown)
    # State of condition_0 has changed, but its value is not used in current scope.
    # So its state after changing is unknown.
    # (The type of the state of condition_0 is int, the value is unknown)
    # State of condition_0 has changed, but its value is not used in current scope.
    # So its state after changing is unknown.


# Generated at 2022-06-26 08:15:45.685716
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    #The Configuration of test_Condition___repr__
    condition = Condition()
    condition._waiters = [0,2]

    #Invoke the API
    result = condition.__repr__()

    #Verify the result
    assert result == "<Condition waiters[2]>"



# Generated at 2022-06-26 08:15:59.624898
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    test_case_0()


# Generated at 2022-06-26 08:16:06.707961
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
  semaphore_0 = Semaphore(0)
  f_0 = semaphore_0.acquire(10)
  semaphore_0.release()
  f_0.result()

if __name__ == "__main__":
    #test_case_0()
    test_Semaphore_acquire()

# Generated at 2022-06-26 08:16:08.172064
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    print(c)


# Generated at 2022-06-26 08:16:12.968534
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    async def worker():
        async with lock:
            # do something
            pass
    worker()


# Generated at 2022-06-26 08:16:21.782301
# Unit test for method wait of class Event
def test_Event_wait():
    """
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    IOLoop.current().run_sync(runner)
    """
    event_0 = Event()

    def waiter():
        print("Waiting for event")
        event_0.wait()
        print("Not waiting this time")
        event_0.wait()
        print("Done")

    def setter():
        print("About to set the event")
        event_0.set()

    waiter()
    setter()
    return event_0


# Generated at 2022-06-26 08:16:26.132607
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    try:
        import Semaphore
    except ImportError:
        return

    obj = Semaphore()
    #obj.__aenter__()
    return


# Generated at 2022-06-26 08:16:27.336037
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    test_lock = Lock()
    test_lock.release()


# Generated at 2022-06-26 08:16:34.390460
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem1 = Semaphore()
    fut1 = sem1.acquire(timeout=2)
    fut2 = sem1.acquire(timeout=2)
    fut3 = fut1
    fut4 = fut1
    print(fut1)
    print(fut2)
    print(fut3)
    print(fut4)



# Generated at 2022-06-26 08:16:40.995606
# Unit test for method wait of class Condition
def test_Condition_wait():
    event_0 = Event()
    event_0.set()
    condition_0 = Condition()
    condition_0.wait(event_0)
    #assert condition_0.wait(event_0) == True
    print("One")
    condition_0.wait(event_0)
    print("Two")


# Generated at 2022-06-26 08:16:51.278133
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")
    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    ioloop.IOLoop.current().run_sync(lambda: gen.multi([waiter(), notifier()]))


# Generated at 2022-06-26 08:17:06.142415
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore()
    sem.release()
    print(sem)


# Generated at 2022-06-26 08:17:14.497417
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    try:
        test_case_0()
        return True
    except Exception as e:
        print(e)
        return False

if __name__ == "__main__":
    passed = test_BoundedSemaphore_release()
    if passed:
        print("passed all test")
    else:
        print("failed one or more test")

# Generated at 2022-06-26 08:17:27.566764
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    
    condition = Condition()
    
    assert condition.notify() is None
    
    assert condition.notify(n=2) is None
    
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    
    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    
    @gen.coroutine  
    def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    
    IOLoop.current().run_sync(runner)

#

# Generated at 2022-06-26 08:17:31.159143
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    event_0 = Event()
    assert_equal(event_0.__repr__(), "<Event waiters[0]>")


# Generated at 2022-06-26 08:17:38.895690
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    scheduler = Scheduler(ioloop_timeout=10)
    def cb_on_completion(ret):
        assert ret == None

    def task_0(semaphore_0, event_0=event_0):
        semaphore_0.acquire()
        event_0.set()

    semaphore_0 = Semaphore()
    scheduler.add_task(task_0, semaphore_0=semaphore_0, cb_on_completion=cb_on_completion)
    scheduler.run()


# Generated at 2022-06-26 08:17:45.530183
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():

    condition_0 = Condition()
    # Test for method Condition.notify_all
    # Constructor test
    assert_equals(condition_0._TimeoutGarbageCollector__timeouts, 0)
    assert_equals(condition_0._TimeoutGarbageCollector__waiters, [])

    # No waiters
    condition_0.notify()
    # No waiters
    condition_0.notify_all()
    # Test for method Condition.notify_all
    # No waiters
    assert_equals(condition_0.notify_all(), None)
    assert_equals(condition_0._TimeoutGarbageCollector__timeouts, 0)
    waiter_0 = Future()
    condition_0._TimeoutGarbageCollector__waiters.append(waiter_0)
    # One waiter
    assert_equ

# Generated at 2022-06-26 08:17:47.106047
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    assert 0 == 1

# Generated at 2022-06-26 08:18:00.029750
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    print(condition)
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:18:02.684167
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition_0 = Condition()
    condition_0.notify(0)



# Generated at 2022-06-26 08:18:06.701483
# Unit test for method notify of class Condition
def test_Condition_notify():
    print("Testing function notify(Condition)")
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        await gen.sleep(5)
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    condition = Condition()
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(runner)

    

# Generated at 2022-06-26 08:18:25.238622
# Unit test for method wait of class Condition
def test_Condition_wait():

    condition = Condition()

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        tmp = yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        tmp = yield [waiter(), notifier()]

    ioloop.IOLoop.current().run_sync(runner)



# Generated at 2022-06-26 08:18:27.011083
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()
    event_0.clear()


# Generated at 2022-06-26 08:18:28.334623
# Unit test for method wait of class Event
def test_Event_wait():
    # Setup
    t_0 = Event()
    # Test
    result_0 = t_0.wait()
    # Verification
    assert result_0 is not None


# Generated at 2022-06-26 08:18:29.951887
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    condition_0.wait()
    condition_0.wait(timeout=100)
    condition_0.wait(timeout=datetime.timedelta(minutes=100))




# Generated at 2022-06-26 08:18:31.152866
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition_0 = Condition()
    condition_0.notify_all()


# Generated at 2022-06-26 08:18:35.834084
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    # Create an instance of class `Semaphore`
    sem_0 = Semaphore(0)

    # Call method `__aexit__` on the instance
    result_0 = sem_0.__aexit__(None, None, None)

    # Call function `release` on the instance
    result_1 = sem_0.release()
    assert result_1 is None



# Generated at 2022-06-26 08:18:39.162745
# Unit test for method wait of class Event
def test_Event_wait():
    # case 1
    condition_1 = Condition()
    flag_1 = condition_1.wait()


# Generated at 2022-06-26 08:18:40.915980
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():

    test_semaphore = Semaphore()
    test_semaphore.__aexit__(object(), object(), object())



# Generated at 2022-06-26 08:18:43.838517
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_wait = Condition()

    # critical region, only one coroutine can enter it
    with (yield condition_wait.lock):
        print(condition_wait)



# Generated at 2022-06-26 08:18:51.199569
# Unit test for method wait of class Event
def test_Event_wait():
    event_0 = Event()
    event_1 = Event()
    assert event_1.is_set() == False
    event_1.set()
    assert event_1.is_set() == True
    event_0.wait()
    assert event_1.is_set() == True


# Generated at 2022-06-26 08:19:21.504738
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore = Semaphore()
    semaphore.acquire()
    print("Semaphore.acquire succeded.")

if __name__ == '__main__':
    test_Semaphore_acquire()

# Generated at 2022-06-26 08:19:23.335619
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)


# Generated at 2022-06-26 08:19:30.584621
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Initial value of semaphore is 2.
    # Acquire one.
    sem = Semaphore()
    sem.acquire()
    assert sem._value == 1
    # Decrement value by 1.
    sem.acquire()
    assert sem._value == 0
    # Can't decrement no further; value remains unchanged.
    sem.acquire()
    assert sem._value == 0
    # Wait list has one waiter.
    assert len(sem._waiters) == 1
    sem.release()
    # Wait list is now empty.
    assert len(sem._waiters) == 0
    # Value is back to 1.
    assert sem._value == 1


# Generated at 2022-06-26 08:19:42.839831
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    # Test case of a condition object, with no waiter
    condition.notify()
    # Test case of a condition object, with one waiter
    waiter_0 = condition.wait()
    condition.notify()
    # Test case of a condition object, with more than one waiters
    waiter_1 = condition.wait()
    waiter_2 = condition.wait()
    waiter_3 = condition.wait()
    # Test case of a condition object, with a waiter that is already done
    waiter_4 = condition.wait()
    waiter_4.set_result('success')
    condition.notify()
    # Test case of a condition object, with the waiter that is already done
    waiter_5 = condition.wait()
    waiter_5.set_result('success')

# Generated at 2022-06-26 08:19:59.433034
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore()
    # Test the function Semaphore.acquire
    try:
        result_0 = semaphore_0.acquire()
    except:
        result_0 = None

    # Test the function Semaphore.acquire
    try:
        result_1 = semaphore_0.acquire(None)
    except:
        result_1 = None

    # Test the function Semaphore.acquire
    try:
        result_2 = semaphore_0.acquire(timeout=0.0)
    except:
        result_2 = None

    # Test the function Semaphore.acquire
    try:
        result_3 = semaphore_0.acquire(timeout=datetime.timedelta(0, 0, 0))
    except:
        result_

# Generated at 2022-06-26 08:20:01.659692
# Unit test for method set of class Event
def test_Event_set():
    print("------test_Event_set------")
    Event_0 = Event()
    Event_0.set()
    Event_0.clear()


# Generated at 2022-06-26 08:20:06.782188
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # create a Semaphore object
    semaphore_0 = Semaphore()
    # call method release
    semaphore_0.release()


# Generated at 2022-06-26 08:20:13.460749
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Initialize Semaphore
    sem = Semaphore(1)

    # Acquire the semaphore with a timeout of 10 seconds
    time.sleep(10)

    # Acquire the semaphore
    sem.acquire()

    # Increment the semaphore counter and wake up a waiter
    sem.release()
    sem.release()

    # Check if the counter is zero and wait for the semaphore to become
    # available
    sem.acquire()


# Generated at 2022-06-26 08:20:25.583027
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)

    # Request two resources (semaphore.release() has not been called)
    fut_0 = sem.acquire()
    fut_1 = sem.acquire()

    res_0 = fut_0.result()
    assert(res_0._obj == sem)

    # Now the semaphore has no resource
    res_1 = fut_1.result()
    assert(res_1._obj == sem)

    # Now the semaphore has no resource, so the next await call will block
    # IO loop run until the semaphore resources are released
    fut_2 = sem.acquire()
    fut_2.wait_for(0.1)
    assert(fut_2.done())

# Generated at 2022-06-26 08:20:28.779355
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:21:21.969998
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    condition_0 = Condition()
    condition_0.notify(1)
    with pytest.raises(ValueError):
        condition_0.notify(1)


if __name__ == "__main__":
    import pytest
    pytest.main()

# Generated at 2022-06-26 08:21:25.538541
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    semaphore_0 = Semaphore()
    assert type(semaphore_0.__repr__()) is str


# Generated at 2022-06-26 08:21:28.758713
# Unit test for method set of class Event
def test_Event_set():

    event_0 = Event()
    print(event_0.is_set())
    event_0.set()
    print(event_0.is_set())
    event_0.clear()
    print(event_0.is_set())
    event_0.set()
    print(event_0.is_set())

# Generated at 2022-06-26 08:21:34.532049
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem._value = 0
    sem._waiters = [1, 2, 3]
    sem.release()
    assert sem._value == 1
    assert sem._waiters == []




# Generated at 2022-06-26 08:21:39.179543
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_1 = Condition()

    # Call member function wait
    future_1 = condition_1.wait()

    # Wait for the result of the future
    result_1 = future_1.result()
    print("result_1 = %s" % result_1)

    assert result_1 == True
    return


# Generated at 2022-06-26 08:21:43.277309
# Unit test for method wait of class Event
def test_Event_wait():
    try:
        event_0 = Event()
        event_0.wait()
        print('Waited successfuly')
    except:
        print('Failed')



# Generated at 2022-06-26 08:21:50.773961
# Unit test for method wait of class Event
def test_Event_wait():
    def runner() -> None:
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])

    event = Event()

    async def waiter() -> None:
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")

    async def notifier() -> None:
        print("About to set the event")
        event.set()

    # ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-26 08:21:53.626434
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock_0 = Lock()
    lock_0.__aenter__()


# Generated at 2022-06-26 08:22:02.912397
# Unit test for method notify of class Condition
def test_Condition_notify():
    # Create condition
    condition = Condition()

    # Create waiter
    asyc_waiter = asyncio.ensure_future(condition.wait())
    asyncio.get_event_loop().run_until_complete(asyc_waiter)

    condition.notify()

    ref_notify = sys.intern("notify")
    ref_notify_all = sys.intern("notify_all")

    # Verify result
    assert ref_notify == condition.notify.__name__
    assert ref_notify_all == condition.notify_all.__name__



# Generated at 2022-06-26 08:22:11.376778
# Unit test for method wait of class Event
def test_Event_wait():

    event = Event()
    # condition_0.wait()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)



# Generated at 2022-06-26 08:23:56.584929
# Unit test for method notify of class Condition
def test_Condition_notify():
    '''
    Unit test for method notify of class Condition
    '''
    # Create an instance of class Condition
    condition_0 = Condition()
    # Call method notify of condition_0
    condition_0.notify(1)


# Generated at 2022-06-26 08:24:00.470267
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore_0 = Semaphore(1)
    try:
        with (yield semaphore_0):
            pass
    except Exception as e:
        print(repr(e))
        raise gen.Return()


# Generated at 2022-06-26 08:24:03.982221
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition_0 = Condition()
    ret_0 = condition_0.__repr__()
    print(ret_0)



# Generated at 2022-06-26 08:24:06.952947
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    condition_0 = Condition()
    semaphore_0 = Semaphore(0)
    Semaphore.acquire(semaphore_0)
    Semaphore.__aenter__(semaphore_0)
    Semaphore.release(semaphore_0)
    Semaphore.acquire(semaphore_0)
    Semaphore.__aenter__(semaphore_0)
    Semaphore.release(semaphore_0)


# Generated at 2022-06-26 08:24:08.957303
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    Semaphore_0 = Semaphore()
    Semaphore_0.release()


# Generated at 2022-06-26 08:24:10.942304
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    semaphore_0 = Semaphore(5)
    semaphore_0.release()
    assert semaphore_0._value == 6


# Generated at 2022-06-26 08:24:21.475068
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    value = 2
    sem = Semaphore(value)
    max_timeout = 30
    timeout_set = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10}
    timeout_set = {_ for _ in timeout_set if _ < value}
    timeout_set.add(max_timeout)
    for timeout in timeout_set:
        if timeout > value:
            with pytest.raises(gen.TimeoutError):
                with pytest.warns(RuntimeWarning):
                    assert not sem.acquire(timeout).done()
        else:
            assert sem.acquire(timeout).done()
    assert sem.acquire().done()
    assert sem.acquire().done()


# Generated at 2022-06-26 08:24:26.930209
# Unit test for method set of class Event
def test_Event_set():
    event_0 = Event()
    event_0.set()
    event_1 = Event()
    event_1.set()
    assert event_0.is_set() == True


# Generated at 2022-06-26 08:24:31.399897
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition_0 = Condition()
    async def async_func():
        await condition_0.wait()
        pass

if __name__ == '__main__':
    test_Condition_wait()

# Generated at 2022-06-26 08:24:38.266807
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    semaphore_0 = Semaphore(1)
    assert semaphore_0._value == 1
    semaphore_0.acquire()
    assert semaphore_0._value == 0
    semaphore_0.release()
    assert semaphore_0._value == 1
