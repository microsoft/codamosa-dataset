

# Generated at 2022-06-24 08:43:29.261706
# Unit test for constructor of class Lock
def test_Lock():

    async def main():
        lock = Lock()
        print(str(lock))

    loop = ioloop.IOLoop.current()
    loop.run_sync(main)

# test this file
if __name__ == "__main__":
    test_Lock()

# Generated at 2022-06-24 08:43:33.346799
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    cm = _ReleasingContextManager(Semaphore(1))
    cm.__enter__()
    cm.__exit__(TypeError, Exception, 'ss')

if __name__ == "__main__":
    test__ReleasingContextManager()

# Generated at 2022-06-24 08:43:38.823859
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    def __repr__(self) -> str:
        res = super().__repr__()
        extra = (
            "locked" if self._value == 0 else "unlocked,value:{0}".format(self._value)
        )
        if self._waiters:
            extra = "{0},waiters:{1}".format(extra, len(self._waiters))
        return "<{0} [{1}]>".format(res[1:-1], extra)



# Generated at 2022-06-24 08:43:42.123413
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")

    condition.notify_all()



# Generated at 2022-06-24 08:43:44.017882
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(3)
    return sem.__aexit__(None, None, None)



# Generated at 2022-06-24 08:43:45.732808
# Unit test for method release of class Lock
def test_Lock_release():
    l = Lock()
    with pytest.raises(RuntimeError):
        l.release()



# Generated at 2022-06-24 08:43:46.382477
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    pass

# Generated at 2022-06-24 08:43:53.953987
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        # await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        # condition.notify()
        print("Done notifying")
    async def runner():
        # Wait for waiter() and notifier() in parallel
        # await gen.multi([waiter(), notifier()])
        condition.wait(timeout=1)
    IOLoop.current().run_sync(runner)
# test_Condition_wait()


# Generated at 2022-06-24 08:43:57.662336
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    """
    The method ``__repr__`` is a built-in function of class Lock in module
    ```tornado.locks```.
    """
    pass



# Generated at 2022-06-24 08:43:59.055562
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    assert '<Condition' in repr(Condition()), 'repr() failed'

# Generated at 2022-06-24 08:44:02.303155
# Unit test for constructor of class Condition
def test_Condition():
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    condition = Condition()
    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-24 08:44:05.176129
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(1)
    expected = [None]
    with mock.patch.object(
        Semaphore,
        "release",
        new=lambda self: expected.pop(0)
    ):
        async with sem:
            assert sem.is_set()
    assert not expected



# Generated at 2022-06-24 08:44:05.741932
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    pass



# Generated at 2022-06-24 08:44:07.189065
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    print(event.wait())


# Generated at 2022-06-24 08:44:16.068949
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Create a semaphore object with value of 1
    semaphore = locks.Semaphore(1)

    # Create a Future object named fut
    fut = concurrent.Future()
    
    # Set fut's result value to None
    fut.set_result(None)
    
    # Create an IOLoop object named io_loop
    io_loop = ioloop.IOLoop()
    
    # Set semaphore's _waiters attribute to an empty deque object
    semaphore._waiters = deque()
    
    # Set semaphore's _value attribute to 1
    semaphore._value = 1
    
    # Call the acquire method with timeout of none
    semaphore.acquire()
    
    # Check if the _waiters attribute of semaphore contains fut

# Generated at 2022-06-24 08:44:18.208413
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    assert isinstance(lock._block, BoundedSemaphore)

# Generated at 2022-06-24 08:44:27.190589
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    obj = Lock()
    repr = obj.__repr__()
    repr_ = repr

    # __repr__ of class Lock is used in method __str__ of class Lock
    # Label: '__str__'
    # Label: '__str__.is_used_in_method_test_Lock___repr__'
    # Label: '__str__.is_used_in_method_test_Lock___repr__.test_Lock___repr__'
    # Label: 'test_Lock___repr__'
    # Label: 'test_Lock___repr__.is_used_in_method_test_Lock___repr__.test_Lock___repr__'
    # Label: 'test_Lock___repr__.is_used_in_method_test_Lock___repr__.test_Lock___re

# Generated at 2022-06-24 08:44:29.968556
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    """
    A fake test to check the behavior of Semaphore.__aenter__()
    """
    assert Semaphore().__aenter__() == None

# Generated at 2022-06-24 08:44:31.781251
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    bs = BoundedSemaphore(5)
    assert bs._initial_value == 5

# Generated at 2022-06-24 08:44:37.959094
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    ## semaphore.acquire
    #
    # Decrement the counter. Returns an awaitable.
    #
    # Block if the counter is zero and wait for a `.release`. The awaitable
    # raises `.TimeoutError` after the deadline.

    #
    ## semaphore.acquire
    #
    # Decrement the counter. Returns an awaitable.
    #
    # Block if the counter is zero and wait for a `.release`. The awaitable
    # raises `.TimeoutError` after the deadline.
    #
    semaphore = Semaphore()
    timeout = None
    #result = semaphore.acquire(timeout=timeout)
    #assert result is None



# Generated at 2022-06-24 08:44:39.452129
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    assert repr( lock ) == '<Lock _block=<BoundedSemaphore [unlocked,value:1]>>'

# Generated at 2022-06-24 08:44:49.137891
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    from tornado.concurrent import Future
    from tornado.locks import Lock, _ReleasingContextManager
    from tornado.testing import gen_test

    @gen_test
    async def test_Lock___exit__(self):
        lock = Lock()
        try:
            async with lock:              # type: ignore
                assert isinstance(lock._block._waiters[0].result(), _ReleasingContextManager)
        except RuntimeError:
            self.fail("Failed to acquire the lock")

    test_Lock___exit__()

# Generated at 2022-06-24 08:44:59.867198
# Unit test for method release of class Lock
def test_Lock_release():
    import types
    import tornado
    import tornado.concurrent
    import tornado.gen
    import tornado.ioloop
    import tornado.locks
    import tornado.testing
    import unittest

    class LockReleaseTest(tornado.testing.AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.lock = tornado.locks.Lock()

        async def async_op(self):
            pass

        async def test_release(self):
            with self.assertRaisesRegex(RuntimeError, r"^release unlocked lock$"):
                self.lock.release()

        async def test_release_unlocked(self):
            await self.lock.acquire()
            await self.async_op()
            self.lock.release()
            await self.async_op()

# Generated at 2022-06-24 08:45:00.806501
# Unit test for constructor of class Semaphore
def test_Semaphore():
    obj = Semaphore()


# Generated at 2022-06-24 08:45:02.772413
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    event.clear()
    print(event.is_set())


# Generated at 2022-06-24 08:45:05.406757
# Unit test for method __repr__ of class Event
def test_Event___repr__(): 
    event = Event()
    assert event.__repr__() == "<Event clear>"


# Generated at 2022-06-24 08:45:09.072994
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    """
    def test_Semaphore___exit__(self):
        sem = Semaphore()

        with self.assertRaisesRegex(RuntimeError,
                                    "'with' is not supported for Semaphore"):
            with sem:
                pass
        sem.release()
        with self.assertRaisesRegex(RuntimeError,
                                    "'with' is not supported for Semaphore"):
            with sem:
                pass
    """
    pass

# Generated at 2022-06-24 08:45:10.453328
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    assert True



# Generated at 2022-06-24 08:45:12.387147
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    Lock().__enter__()

# Generated at 2022-06-24 08:45:16.385367
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    print(sem.__repr__())
    print(sem._value)

    sem.release()
    print(sem.__repr__())
    print(sem._value)

# Generated at 2022-06-24 08:45:19.152903
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    # Test ReleasingContextManager exit function
    x = _ReleasingContextManager(object())
    x.__exit__(None, None, None)


# Generated at 2022-06-24 08:45:20.756712
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    lock = Lock()
    lock.__enter__()



# Generated at 2022-06-24 08:45:22.760737
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    bound_sem = BoundedSemaphore(3)
    bound_sem._initial_value
    bound_sem._value

# Generated at 2022-06-24 08:45:23.435094
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    pass



# Generated at 2022-06-24 08:45:31.871512
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore

    sem = Semaphore(2)

    async def worker(worker_id):
        try:
            async with sem:
                print("Worker %d is working" % worker_id)
                await gen.sleep(1)
            print("Worker %d is done" % worker_id)
        except Exception as e:
            print(e)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-24 08:45:36.108630
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():

    cond = Condition()
    assert repr(cond) == '<Condition>'

    cond._waiters.append(Future())
    cond._garbage_collect()

    assert repr(cond) == '<Condition waiters[1]>'



# Generated at 2022-06-24 08:45:38.181017
# Unit test for constructor of class Condition
def test_Condition():
    def runner():
        yield Condition()

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-24 08:45:42.456755
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    event_testing = Event()
    event_testing.set()
    assert repr(event_testing) == "<Event set>"
    event_testing.clear()
    assert repr(event_testing) == "<Event clear>"


# Generated at 2022-06-24 08:45:47.002530
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    bounded_sem = BoundedSemaphore(2)
    bounded_sem.release()
    bounded_sem.release()
    try:
        bounded_sem.release()
    except ValueError:
        print("BoundedSemaphore(2) released 3 times throws ValueError")
    else:
        print("BoundedSemaphore(2) released 3 times does not throw ValueError")



# Generated at 2022-06-24 08:45:48.014173
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    from tornado import locks
    lock = locks.Lock()
    try:
        with lock:
            pass
        assert False
    except RuntimeError:
        pass

# Generated at 2022-06-24 08:45:59.361818
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from collections import deque
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])
    
    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)
    
    IOLoop.current().add_callback(simulator, list(futures_q))
    
    def use_some_resource():
        return futures_q.popleft()
    
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.ac

# Generated at 2022-06-24 08:46:01.848477
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado.locks import Lock
    lock = Lock()
    class Error(Exception): pass
    lock.release()
    try:
        with pytest.raises(RuntimeError) as e:
            with lock:
                raise Error()
            assert str(e.value) == "release unlocked lock"
    except Error:
        pass


# Generated at 2022-06-24 08:46:10.854394
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
  from tornado.locks import Lock
  class TestLock(Lock):
    def __init__(self) -> None:
      return super().__init__()
    def release(self) -> None:
      return self
    def acquire(self, callback: Optional[Callable[[None], None]] = None,
                deadline: Optional[float] = None) -> Optional["Future[None]"]:
      return self
  # call __init__ to check test data
  assert _ReleasingContextManager(TestLock())
  return True



# Generated at 2022-06-24 08:46:12.318262
# Unit test for method set of class Event
def test_Event_set():
    e = Event()
    e.set()
    assert(e.is_set())


# Generated at 2022-06-24 08:46:15.263241
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    coro = Lock.__aenter__(lock)
    try:
        res = coro.send(None)
    except StopIteration:
        res = None
    assert res is None

# Generated at 2022-06-24 08:46:22.640978
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    import pytest
    from tornado.concurrent import Future
    from tornado.locks import Condition
    from tornado.locks import Event
    from tornado.locks import Lock
    from tornado.locks import Semaphore
    from tornado.locks import RLock

    #from tornado import gen
    #from tornado.ioloop import IOLoop

    #from tornado.testing import AsyncTestCase
    #from tornado.testing import gen_test
    #from tornado.testing import main

    coroutines = [
        Condition().acquire,
        Event().wait,
        Lock().acquire,
        RLock().acquire,
        Semaphore(value=1).acquire,
    ]

    for c in coroutines:
        f = Future()  # type: Future[None]
        c()  # type: ignore

# Generated at 2022-06-24 08:46:23.809463
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado.locks import Condition
    condition = Condition()
    print(condition.notify())
    print(condition.notify(4))

# Generated at 2022-06-24 08:46:27.253249
# Unit test for method release of class Semaphore
def test_Semaphore_release():

    with pytest.raises(ValueError):
        sem = Semaphore(-2)
    with pytest.raises(ValueError):
        sem = Semaphore(0)
    sem = Semaphore()
    sem.release()
    sem = Semaphore(2)
    sem.release()


# Generated at 2022-06-24 08:46:33.523536
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    # Test that calling notify_all() wakes all waiters
    condition = Condition()
    io_loop = ioloop.IOLoop.current()

    @gen.coroutine
    def f():
        yield condition.wait()
        print("f")

    @gen.coroutine
    def g():
        yield condition.wait()
        print("g")

    @gen.coroutine
    def notify_all():
        condition.notify_all()
        print("notify_all")

    io_loop.run_sync(lambda: gen.multi([f(), g(), notify_all()]))



# Generated at 2022-06-24 08:46:35.990590
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    with pytest.raises(ValueError):
        sem = BoundedSemaphore(4).release()
        sem.release()
        sem.release()
        sem.release()
        sem.release()



# Generated at 2022-06-24 08:46:42.088952
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    from random import seed
    from random import randint
    print('Testing method release of class BoundedSemaphore...')
    run_count = randint(1,10)
    success_count = 0
    for i in range(run_count):
        test_fail = False
        try:
            semaphore = Semaphore(1)
            semaphore._value = 0
            semaphore._initial_value = 0
            semaphore.release()
        except:
            test_fail = True
        success_count = success_count + (1-test_fail)
    print('{0}/{1} tests successful'.format(success_count, run_count))


# Generated at 2022-06-24 08:46:51.959174
# Unit test for method release of class Lock
def test_Lock_release():
    # The Lock begins unlocked, and acquire locks it immediately. While it is locked, a coroutine that yields acquire waits until another coroutine calls release.
    lock = Lock()
    assert lock._block._value == 1
    lock.acquire().result()
    assert lock._block._value == 0
    try:
        lock.release()
    except RuntimeError:
        # Releasing an unlocked lock raises RuntimeError.
        assert True
    else:
        assert False
    lock = Lock()
    lock.release()
    try:
        lock.release()
    except ValueError:
        # Releasing an unlocked lock raises ValueError.
        assert True
    else:
        assert False


# Generated at 2022-06-24 08:46:55.512354
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    a = BoundedSemaphore(value = 1)
    a.release()
    try:
        a.release()
        assert False
    except ValueError:
        assert True

# Generated at 2022-06-24 08:46:58.957874
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    t = Semaphore(1)
    print("-------------------------")
    t.release()

# unit test for method acquire of class Semaphore

# Generated at 2022-06-24 08:47:04.672725
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    # test for class Event
    obj = Event()
    assert "Event" ==  obj.__class__.__name__
    assert obj.is_set() is False
    assert obj._value is False

    # test for the case that is_set() returns True
    obj._value = True
    assert obj.__repr__()=="<Event set>"


# Generated at 2022-06-24 08:47:05.907746
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    _aexit_ret = Semaphore().__aexit__(None, None, None)
    assert _aexit_ret is None



# Generated at 2022-06-24 08:47:11.409640
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release(): 
    b_sem = BoundedSemaphore(3)
    # release once
    print('---------release once--------')
    b_sem.release()
    # try to release twice
    print('---------try to release twice---------')
    try :
        b_sem.release()
    except ValueError as v:
        print('ValueError: %s'%(v))
        pass

# Generated at 2022-06-24 08:47:16.085186
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    mySemaphore = BoundedSemaphore(1)
    mySemaphore._value = 0
    mySemaphore._initial_value = 1
    try:
        mySemaphore.release()
    except ValueError:
        assert True
    except:
        assert False
    else:
        assert False


_LOCAL = threading.local()



# Generated at 2022-06-24 08:47:27.262298
# Unit test for method wait of class Condition
def test_Condition_wait():

    condition = Condition()

    # make timer to test condition
    def timer_callback(func):
        def call():
            # run asynchronously
            ioloop.IOLoop.current().spawn_callback(lambda: func())
        return call

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop = ioloop.IOLoop.current()
    ioloop.add_callback(timer_callback(runner))
    ioloop.start()

test_Condition_

# Generated at 2022-06-24 08:47:33.226056
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    async def worker(worker_id):
        async with lock:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        # Now the lock is released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-24 08:47:41.608437
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    try:
        obj = _ReleasingContextManager()
        # State assertion
        assert(obj.__enter__() is None), "Expected: obj.__enter__() is None, Actual: obj.__enter__() is " + str(obj.__enter__())
    except Exception as e:
        raise Exception("An error occurred in the unit test named 'test__ReleasingContextManager___enter__'. The following is the error message: " + str(e))

# Generated at 2022-06-24 08:47:45.844792
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    p = Lock()
    assert p.__aenter__() == p.acquire()


# Generated at 2022-06-24 08:47:47.952635
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    # test __repr__ function
    result = "<Condition"
    assert str(condition) == result, "Received unexpected result"



# Generated at 2022-06-24 08:47:48.864968
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    del condition


# Generated at 2022-06-24 08:47:52.871331
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    with pytest.raises(AssertionError):
        sem = Semaphore(1)
        with (sem):
            raise AssertionError("Use 'async with' instead of 'with' for Semaphore")



# Generated at 2022-06-24 08:47:56.222626
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    '''Unit test for method __enter__ of class Lock.'''
    lock = Lock()
    try:
        with lock:
            pass
    except RuntimeError:
        return
    assert False, 'lock.__enter__() did not raise RuntimeError.'



# Generated at 2022-06-24 08:47:58.453073
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    print("Lock() completed")


# Generated at 2022-06-24 08:48:11.161097
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import asyncio
    from unittest import TestCase
    from tornado import testing

    async def func():
        from tornado.locks import Semaphore
        sem = Semaphore(2)
        waiters = set([Future() for _ in range(3)])
        if len(sem._waiters) == 0:
            sem.release()
        waiters.add(sem._waiters.popleft())
        return waiters

    async def main():
        res = await func()
        assert len(res) == 1
        assert isinstance(res, set)
        assert isinstance(res.pop(), Future)
        
    print('Unit test for method release of class Semaphore: ', end='')
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())

# Generated at 2022-06-24 08:48:14.487868
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    from tornado.locks import _ReleasingContextManager
    _ReleasingContextManager(None).__enter__()

# Generated at 2022-06-24 08:48:17.736642
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    e = Event()
    e.set()
    repr_str = repr(e)
    assert repr_str == "<Event set>", "Expected <class 'Event'>, but got "+ repr_str

# Generated at 2022-06-24 08:48:25.845141
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)
    # try:
    #     Condition.wait
    # except AttributeError:
    #     assert True
    # else:
    #     assert False



# Generated at 2022-06-24 08:48:30.001275
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    lock = Lock()

    async def f():
        with (yield lock.acquire()):
            # Do something holding the lock.
            pass

        # Now the lock is released.

    IOLoop.current().run_sync(f)

# Generated at 2022-06-24 08:48:31.038185
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    # Test for method __aexit__ (classmethod) of class Lock

    lock = Lock()
    with lock:
        lock.release()

# Generated at 2022-06-24 08:48:40.163410
# Unit test for method is_set of class Event
def test_Event_is_set():
    # Tests whether the method is_set() can correctly tell whether the event has been set
    # And whether it can correctly identify the state of the event after it has been set
    set_event = Event()
    clear_event = Event()
    assert(not set_event.is_set())
    assert(not clear_event.is_set())
    set_event.set()
    clear_event.set()
    assert(set_event.is_set())
    assert(clear_event.is_set())
    set_event.clear()
    clear_event.clear()
    assert(not set_event.is_set())
    assert(not clear_event.is_set())


# Generated at 2022-06-24 08:48:44.343927
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    def worker(worker_id):
        sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    runner()

# Generated at 2022-06-24 08:48:47.189648
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    pass
    #a = _ReleasingContextManager()
    #print(a)



# Generated at 2022-06-24 08:48:51.514210
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()

    assert event.is_set() == False

    event.set()
    assert event.is_set() == True

    event.clear()
    assert event.is_set() == False


# Generated at 2022-06-24 08:48:53.406254
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    t = Lock()
    f = asyncio.Future()
    assert t.__aenter__() == f
    assert f.result() is None

# Generated at 2022-06-24 08:48:55.516800
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    print("Event set")
    event.set()


# Generated at 2022-06-24 08:48:57.394477
# Unit test for constructor of class Condition
def test_Condition():
    c = Condition()
    return c


# Generated at 2022-06-24 08:48:58.992669
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    #value=1(default)
    bs = BoundedSemaphore()
    assert bs._value == 1
    #value=2
    bs = BoundedSemaphore(2)
    assert bs._value == 2


# Generated at 2022-06-24 08:49:02.046351
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    with pytest.raises(Exception):
        sem = BoundedSemaphore(-1)
        assert sem._value == 0
        assert sem._initial_value == 0


# Generated at 2022-06-24 08:49:05.259579
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    a = Condition()
    b = Condition()
    c = Condition()
    c._waiters.append(a)
    c._waiters.append(b)
    c.notify_all()
    print(c._waiters)


# Generated at 2022-06-24 08:49:11.530900
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    s = Semaphore(1)
    
    def foo():
        s.acquire().result()
        s.acquire().result()
    
    try:
        foo()
    except BaseException as err:
        assert type(err) == RuntimeError
        assert str(err) == 'Use \'async with\' instead of \'with\' for Semaphore'
    else:
        assert False
    s.acquire().result()
    assert s.acquire().result() == _ReleasingContextManager(s)
    s.acquire().result()
    
    try:
        s.acquire(timeout=datetime.datetime.now() + datetime.timedelta(seconds=2)).result()
    except BaseException as err:
        assert isinstance(err, gen.TimeoutError)

# Generated at 2022-06-24 08:49:14.386497
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    l = Lock()
    try:
        l.__aexit__()
        assert False, "expected exception"
    except RuntimeError as e:
        pass



# Generated at 2022-06-24 08:49:15.724235
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    lock = Lock()


# Generated at 2022-06-24 08:49:23.393527
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():

    from asyncio.locks import Event

    event = Event()

    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    IOLoop.current().run_sync(runner)

# Generated at 2022-06-24 08:49:26.401424
# Unit test for constructor of class Semaphore
def test_Semaphore():
    # test constructor with negative value
    try:
        Semaphore(value = -1)
    except ValueError:
        print("test_Semaphore: Pass")
    else:
        print("test_Semaphore: Fail")



# Generated at 2022-06-24 08:49:27.112535
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore()
    sem.release()
    assert sem._value == 1

# Generated at 2022-06-24 08:49:28.257024
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert type(event.is_set()) == bool

# Generated at 2022-06-24 08:49:29.549977
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    return
test_Event___repr__()

# Generated at 2022-06-24 08:49:35.978542
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    print("\ntest_Event___repr__")
    test_Event=Event()
    test_Event.set()
    test_Event_str=test_Event.__repr__()
    print(test_Event_str)
    print(type(test_Event_str))


# Generated at 2022-06-24 08:49:36.750028
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    lock = Lock()
    lock.__enter__()

# Generated at 2022-06-24 08:49:46.979918
# Unit test for constructor of class Semaphore
def test_Semaphore():
    import asyncio
    from .task import Task
    from .pool import Pool
    from .concurrent import Future
    from .ioloop import IOLoop

    async def caller(arg):
        await asyncio.sleep(0.2)
        return arg

    async def worker(semaphore):
        with (await semaphore.acquire()):
            print("Worker is working")
            await asyncio.sleep(1)

        # Now the semaphore has been released.
        print("Worker is done")

    print("semaphore with value 0:")
    semaphore = Semaphore(0)
    result = IOLoop.current().run_sync(
        lambda: Pool(max_workers=2).map(lambda _: worker(semaphore), range(2))
    )
    print("\n")

# Generated at 2022-06-24 08:49:54.260455
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    io_loop = ioloop.IOLoop.current()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    io_loop.run_sync(runner)


# Generated at 2022-06-24 08:49:56.392563
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    collector = _TimeoutGarbageCollector()
    t = ioloop.IOLoop.current()
    t.run_sync(lambda: collector._garbage_collect())


# Generated at 2022-06-24 08:50:01.121880
# Unit test for method set of class Event
def test_Event_set():
    async def _test(data):
        print("test_Event_set")
        event = Event()
        assert not event.is_set()
        await event.wait()
        assert event.is_set()
    ioloop.IOLoop.current().run_sync(_test, None)


# Generated at 2022-06-24 08:50:06.732132
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    test_obj = _TimeoutGarbageCollector()
    assert isinstance(test_obj, _TimeoutGarbageCollector)
    assert len(test_obj._waiters) == 0
    assert test_obj._timeouts == 0
    test_obj._garbage_collect()
    assert len(test_obj._waiters) == 0
    assert test_obj._timeouts == 0


# Generated at 2022-06-24 08:50:10.230446
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    future1 = Future()
    future2 = Future()
    lock = Lock()
    future1.set_result(lock)
    future1.set_exception(RuntimeError())

    future2.set_exception(RuntimeError())


# Generated at 2022-06-24 08:50:17.913920
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    import tornado
    import asyncio
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from tornado.platform.asyncio import to_tornado_future
    from computer_vision_utils.lib_image_processing.asyncio_utils import any_asyncio_future

    asyncio.set_event_loop_policy(AnyThreadEventLoopPolicy())
    asyncio.get_event_loop().set_debug(True)
    ioloop = IOLoop.current()
    # Test with the Tornado Future class and with the asyncio Future class
    futures = [tornado.concurrent.Future(), any_asyncio_future()]
    results = []

    def finish():
        ioloop.stop()


# Generated at 2022-06-24 08:50:29.433820
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    BS = BoundedSemaphore(3)

    # Test if the number of releases is less than the initial value of the semaphore
    assert BS._value == 3
    print("Semaphore has no releases yet")
    BS.release()
    assert BS._value == 4
    print("Semaphore released once")
    BS.release()
    assert BS._value == 5
    print("Semaphore released twice")
    BS.release()
    assert BS._value == 6
    print("Semaphore released thrice")
    print("")

    # Test if the number of releases is equal to the initial value of the semaphore
    print("Semaphore released till the limit")
    BS.release()
    assert BS._value == 7
    print("Semaphore released by one more than limit")
    print("")

    # Test if

# Generated at 2022-06-24 08:50:33.546562
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from tornado.locks import _ReleasingContextManager
    obj = object()
    rc = _ReleasingContextManager(obj)
    exc_type, exc_val, exc_tb = None, None, None
    rc.__exit__(exc_type, exc_val, exc_tb)
    assert True



# Generated at 2022-06-24 08:50:37.404185
# Unit test for method notify of class Condition
def test_Condition_notify():
    def testSelect():
        c = Condition()
        t = c.wait()
        c.notify()
        t.result()
    testSelect()


# Generated at 2022-06-24 08:50:41.740449
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    global semaphore
    # Create a Semaphore with one slot.
    semaphore = Semaphore(1)
    # Create an async context.
    async def computation():
        # Acquire the Semaphore.
        await semaphore.acquire()
        # Release the Semaphore.
        semaphore.release()
    # Get the event looper instance.
    ioloop = IOLoop.current()
    ioloop.run_sync(computation)


# Generated at 2022-06-24 08:50:45.059086
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bsem = BoundedSemaphore(1)
    bsem.release()
    try:
        bsem.release()
    except ValueError:
        return True
    return False
test_BoundedSemaphore_release()


# Generated at 2022-06-24 08:50:46.970073
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    try:
        with lock:
            pass
    except RuntimeError:
        pass

# Generated at 2022-06-24 08:50:53.653751
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    llist = []
    c = Condition() 
    def f(x):
        llist.append(x)
    def g():
        for i in range(4):
            f(i)
            c.notify_all()
    async def h():
        for i in range(4):
            llist.append(i)
            await c.wait()
    async def t():
        await gen.multi([g(),h()])
    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(t)
    assert llist == [0,1,2,3,0,1,2,3]



# Generated at 2022-06-24 08:50:58.131593
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    s = Semaphore(1)
    print(s.current)
    print("started")
    with (_ReleasingContextManager(s)) as __with0:
        pass
    print("finished")
    print(s.current)

test__ReleasingContextManager___exit__()



# Generated at 2022-06-24 08:50:59.577692
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    print(Semaphore().__enter__())


# Generated at 2022-06-24 08:51:02.123376
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    value = 1
    sem = Semaphore(value)
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"


# Generated at 2022-06-24 08:51:07.110689
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from typing import Deque
    from collections import deque
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(4)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))

    def use_some_resource():
        return futures_q.popleft()

    sem = Semaphore(2)

    async def worker(worker_id):
        await sem.acquire()

# Generated at 2022-06-24 08:51:10.259119
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    lock = Lock()
    try:
        lock.__enter__()
    except RuntimeError as e:
        print(e)


# Generated at 2022-06-24 08:51:12.128343
# Unit test for method release of class Lock
def test_Lock_release():
    """Test if method release of class Lock works properly"""
    lock = Lock()
    lock.release()


# Generated at 2022-06-24 08:51:17.295035
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    import _helper_primitives
    obj = _helper_primitives.Semaphore(1)
    _helper_primitives._ReleasingContextManager(obj).__exit__(None,None,None)
    print("test__ReleasingContextManager___exit__ passed")
    
    
    


# Generated at 2022-06-24 08:51:21.608780
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():

    # create an instance of the class
    sem = Semaphore(2)

    # Attempting to use a semaphore as a context manager will raise an
    # error, use async with instead:
    with pytest.raises(RuntimeError):
        sem.__enter__()


# Generated at 2022-06-24 08:51:25.033813
# Unit test for method set of class Event
def test_Event_set():
    event = Event()            
    assert event._value == False
    assert event.is_set() == False
    event.set()
    assert event._value == True
    assert event.is_set() == True



# Generated at 2022-06-24 08:51:25.633838
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    pass

# Generated at 2022-06-24 08:51:29.165456
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore()
    res = repr(sem)
    extra = "unlocked,value:1"
    if sem._waiters:
        extra = "{0},waiters:{1}".format(extra, len(sem._waiters))
    assert "<{0} [{1}]>".format("Semaphore", extra) == res

# Generated at 2022-06-24 08:51:35.113932
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    from tornado import testing
    from tornado import gen
    from tornado.ioloop import IOLoop

    lock = locks.Lock()

    async def work_while_locked():
        with await lock:
            await gen.sleep(0.01)
            assert lock._block.is_set() is True

    async def acquire_after_work():
        await work_while_locked()
        assert await lock.acquire()

    IOLoop().run_sync(lambda : acquire_after_work())


# Generated at 2022-06-24 08:51:36.790523
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    # event.set()
    assert event.is_set() == False


# Generated at 2022-06-24 08:51:37.633511
# Unit test for constructor of class Event
def test_Event():
	e = Event()
	return e


# Generated at 2022-06-24 08:51:39.753190
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(1)
    sem.release()
    assert sem._value == 2
    assert sem._waiters == deque()

# Generated at 2022-06-24 08:51:41.227134
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert lock.acquire() == None
    lock.release()

# Generated at 2022-06-24 08:51:42.561097
# Unit test for constructor of class Condition
def test_Condition():
	yield Condition()



# Generated at 2022-06-24 08:51:46.303992
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    semaphore = BoundedSemaphore()
    for i in range(2):
        semaphore.release()
    try:
        semaphore.release()
    except ValueError as e:
        return True
    return False


# Generated at 2022-06-24 08:51:49.930555
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()
    
    def waiter():
        print('waiter')
    
    def notifier():
        print('notifier')
        cond.notify_all()

    gen.multi([waiter(), notifier()])
    
    
test_Condition_notify_all()



# Generated at 2022-06-24 08:52:01.891318
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import unittest, logging
    from pandas.util.testing import assert_frame_equal
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.testing import bind_unused_port

    condition = Condition()
    async def wait_then_print():
        await condition.wait()
        print("Hello")
    async def wait_then_print2():
        await condition.wait()
        print("Hell")
    async def wait_then_print3():
        await condition.wait()
        print("Helloo")
    async def notify_all_then_print():
        condition.notify_all()
        print("Done")

    async def runner():
        await gen.multi([wait_then_print(), wait_then_print2(), wait_then_print3(), notify_all_then_print()])

   

# Generated at 2022-06-24 08:52:05.005157
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from tornado.locks import Semaphore
    semaphore = Semaphore(0)
    with _ReleasingContextManager(semaphore) as _:
        pass
    assert semaphore.value == 0



# Generated at 2022-06-24 08:52:12.194528
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    import unittest
    from io import StringIO
    from unittest import mock

    class LockTestCase(unittest.TestCase):
        '''Lock class.'''

        def test___exit__(self):
            '''Test method __exit__ of class Lock.'''
            self.assertEqual(
                # The code below would run without error.
                True,
                True
            )
    unittest.main()



# Generated at 2022-06-24 08:52:15.199566
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert not event.is_set()
    event.set()
    assert event.is_set()
    event.clear()
    assert not event.is_set()

# Generated at 2022-06-24 08:52:23.920355
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    import unittest
    
    class TestSemaphore___exit__(unittest.TestCase):
        
        def test_case_1(self):
            semaphore = Semaphore()
            semaphore.__enter__()
            semaphore.__exit__(None, None, None)
            
            try:
                semaphore.__exit__(None, None, None)
            except:
                self.fail("Expected that last call to __exit__ does not raise exepction")
    unittest.main()


# Generated at 2022-06-24 08:52:36.077654
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    import asyncio
    import datetime
    import time
    sem = Semaphore(5)

    async def worker(worker_id):
        print(datetime.datetime.now())
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await asyncio.sleep(6)
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        # Join all workers.
        await asyncio.gather(
            *(worker(i) for i in range(10))
        )
    print(datetime.datetime.now())

# Generated at 2022-06-24 08:52:37.534997
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    if lock.release():
        assert True
    else:
        assert False

# Generated at 2022-06-24 08:52:42.900727
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()

    def waiter():
        assert condition.wait()
        assert not condition.wait(timeout=datetime.timedelta(seconds=0))
        assert not condition.wait(timeout=datetime.timedelta(seconds=-1))

    def notifier():
        condition.notify()

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(lambda: gen.multi([waiter(), notifier()]))


# Generated at 2022-06-24 08:52:44.023297
# Unit test for constructor of class Semaphore
def test_Semaphore():
    a = Semaphore(5)
    assert a._value == 5


# Generated at 2022-06-24 08:52:45.567158
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    bs = BoundedSemaphore(1)
    assert bs._initial_value == 1



# Generated at 2022-06-24 08:52:48.008133
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from tornado.locks import Lock
    l = Lock()
    l.acquire()
    lock = l
    del l
    with lock.acquire():
        pass
    assert lock._locked == False



# Generated at 2022-06-24 08:52:51.620989
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    semaphore = Semaphore()
    __aexit__ = semaphore.__aexit__
    __aexit__(None, None, None)

# Generated at 2022-06-24 08:53:02.996441
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    import unittest
    from io import StringIO
    import sys
    class __ReleasingContextManagerTestCase(unittest.TestCase):
        def setUp(self):
            self.held_obj = ""
            class TestObj:
                def __init__(self, target):
                    self._target = target
                def release(self):
                    self._target.held_obj += "released"

            self.test_obj = TestObj(self)
            self.test_target = _ReleasingContextManager(self.test_obj)

        def test_cmp(self):
            self.assertEqual(self.test_target, self.test_target)

        def test_enter_and_exit(self):
            with self.test_target:
                self.assertEqual(self.held_obj, "")

# Generated at 2022-06-24 08:53:07.460008
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    '''
    def __exit__(self, type, value, traceback):
        raise RuntimeError('Use `async with` instead of `with` for Lock')
    '''
    l = Lock()
    with pytest.raises(RuntimeError):
        l.__exit__(None, None, None)



# Generated at 2022-06-24 08:53:09.295439
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
	# semaphore.__exit__ -> None
	return True


# Generated at 2022-06-24 08:53:22.531901
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    a = 0
    condition = Condition()
    async def waiter():
        global a
        a += 1
        print(f"Before wait, a is {a}")
        await condition.wait()
        print(f"After wait, a is {a}")
        a += 1
        print(f"After first queue wait, a is {a}")
        await condition.wait()
        print(f"After second queue wait, a is {a}")
        a += 1
        print(f"After third queue wait, a is {a}")

    def notifier():
        print("notifier begin")
        condition.notify_all()
        print("notifier end")

    @gen.coroutine
    def runner():
        tasks = [waiter(), waiter(), waiter(), waiter(), waiter(), waiter()]