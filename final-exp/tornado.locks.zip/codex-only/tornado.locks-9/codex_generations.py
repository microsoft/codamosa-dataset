

# Generated at 2022-06-24 08:43:29.049269
# Unit test for method release of class Lock
def test_Lock_release():
    l= Lock()
    l.release()
    l.acquire()
    l.release()
    #l.release()
    l.acquire()
    l.release()

# Generated at 2022-06-24 08:43:37.367085
# Unit test for method clear of class Event
def test_Event_clear():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado import gen
    from tornado.locks import Event
    class EventCase(AsyncTestCase):
        @gen_test
        async def test_Event_clear(self):
            ev = Event()
            f = gen.Future()
            async def wait():
                await ev.wait()
                f.set_result(ev.is_set()==True)
            self.io_loop.add_callback(wait)
            await gen.sleep(0.001)
            ev.clear()
            self.assertEqual((await f),False)
    cases = EventCase()
    cases.timeout=3
    cases.test_Event_clear()



# Generated at 2022-06-24 08:43:44.330867
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)

# Generated at 2022-06-24 08:43:45.688637
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert lock.acquire() == lock._block.acquire()

# Generated at 2022-06-24 08:43:47.902986
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    print(condition.__repr__())



# Generated at 2022-06-24 08:43:50.161015
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    lock = Lock()
    lock.acquire()
    try:
        lock.release()
    except RuntimeError as e:
        print(e)


# Generated at 2022-06-24 08:43:51.353292
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    l = Lock()
    print(l.__repr__())


# Generated at 2022-06-24 08:44:00.893957
# Unit test for method set of class Event
def test_Event_set():
    ''' 测试 event 中 set 方法 '''
    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    event = Event()
    async def setter():
        print("About to set the event")
        event.set()

    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    IOLoop.current().run_sync(setter)
    IOLoop.current().run_sync(waiter)



# Generated at 2022-06-24 08:44:04.442286
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Setup
    test = Condition()
    test.wait()
    # Exercise
    expected = "<Condition waiters[1]>"
    # Verify
    assert __repr__(test) == expected



# Generated at 2022-06-24 08:44:15.066109
# Unit test for method release of class Semaphore
def test_Semaphore_release():

    import time
    import random
    import logging


    def init():
        logging.basicConfig(level=logging.DEBUG)

    def test_Semaphore_release_func(semaphore, test_func_name):
        test_releaser_func_name = "test_%s" % test_func_name
        funcDict = dict(locals()) # finctionary of functions from locals()
        test_releaser_func = funcDict[test_releaser_func_name]  # type: ignore
        try:
            for i in range(10):
                test_releaser_func(semaphore)
                time.sleep(0.1 + random.random())
        except Exception as e:
            logging.exception(e)


# Generated at 2022-06-24 08:44:24.587818
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado import gen
    from tornado.ioloop import IOLoop
    
    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))

    def use_some_resource():
        return futures_q.popleft()

    sem = Semaphore(2)

    async def worker(worker_id):
        await sem.acquire()

# Generated at 2022-06-24 08:44:27.141442
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    assert isinstance(condition, _TimeoutGarbageCollector)


# Generated at 2022-06-24 08:44:32.418052
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    # Test that an exception is raised if the lock is acquired but not released.
    with raises(RuntimeError):
        lock = Lock()
        with lock:
            pass
    # Test that an exception is raised if the lock is not acquired.
    with raises(RuntimeError):
        lock = Lock()
        with lock:
            pass
        lock.release()


# Generated at 2022-06-24 08:44:33.797304
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    print(lock)


# Generated at 2022-06-24 08:44:38.748487
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    event = Event()
    assert repr(event) == "<{} clear>".format(event.__class__.__name__)
    assert event.is_set() == False
    event.set()
    assert repr(event) == "<{} set>".format(event.__class__.__name__)
    assert event.is_set() == True


# Generated at 2022-06-24 08:44:44.631621
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    value = 0
    semaphore = Semaphore(value=value)
    res = semaphore.__repr__()
    assert res == "<Semaphore [locked]>"


# Generated at 2022-06-24 08:44:55.561017
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    # the method __aexit__ to be tested
    def __aexit__(self, typ, value, tb):
        self.release()
    from tornado.locks import Lock
    from pytest import raises
    # define a Lock object to be tested
    lock = Lock()
    # call the method __aexit__ with some arguments
    __aexit__(lock, typ, value, tb)
    # check that the Lock object is released
    __aexit__(lock, typ, value, tb)

    # define a Lock object to be tested
    lock = Lock()
    # call the method __aexit__ with some arguments
    __aexit__(lock, typ, value, tb)
    from pytest import raises
    with raises(RuntimeError):
        # check that the Lock object raised a RuntimeError exception
        __aexit__

# Generated at 2022-06-24 08:44:58.655078
# Unit test for method release of class Semaphore
def test_Semaphore_release():

    sem1 = Semaphore()

    sem1._value = 0
    sem1.release()
    assert sem1._value == 1

    sem1._value = -1
    sem1.release()
    assert sem1._value == 0


# Generated at 2022-06-24 08:45:06.462351
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    import asyncio
    from collections import deque

    from tornado import locks
    from tornado.gen import coroutine

    @coroutine
    def f():
        async with lock:
            # Do something holding the lock.
            pass

        # Now the lock is released.

    @coroutine
    def f2():
        with (yield lock.acquire()):
            # Do something holding the lock.
            pass

        # Now the lock is released.

    # Below is just a test with a real lock and sleep
    #
    # This methods tests __aenter__, which locks the lock and then __aexit__,
    # which releases it.
    #
    # The method will be executed by several coroutines and we expect that
    # only one is executing it at a time.
    #
    # We run them all and then let them

# Generated at 2022-06-24 08:45:15.166501
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    """
    Tests for class Semaphore
    """
    # Check the __aenter__ method of the lock
    import pytest
    import inspect
    import Semaphore

    signature = inspect.signature(Semaphore.__aenter__)

    # Check the return type
    assert signature.return_annotation == inspect.Signature.empty

    # Check the number of parameters
    assert len(signature.parameters) == 1
    assert list(signature.parameters.keys()) == ['self']

    # Check the parameter types
    assert signature.parameters['self'].annotation == Semaphore



# Generated at 2022-06-24 08:45:18.826786
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():

    assert repr(Semaphore()) == '<Semaphore unlocked,value:1>'
    assert repr(Semaphore().acquire()) == '<_ReleasingContextManager>'




# Generated at 2022-06-24 08:45:22.222830
# Unit test for constructor of class Event
def test_Event():
    e = Event()
    assert e.is_set() == False
    e.set()
    assert e.is_set() == True
    e.clear()
    assert e.is_set() == False



# Generated at 2022-06-24 08:45:25.687693
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()
    try:
        c.notify(2)
        assert c._waiters == []
    except Exception as e:
        print(e)
    

# Generated at 2022-06-24 08:45:28.110500
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():

    @gen_test
    def test_Lock___aexit___1(self):
        lock = Lock()
        await lock.acquire()
        lock.release()


# Generated at 2022-06-24 08:45:29.412005
# Unit test for constructor of class Semaphore
def test_Semaphore():
    m = Semaphore(10)
    assert m._value == 10

# Generated at 2022-06-24 08:45:32.086698
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    from tornado import locks
    lock = locks.Lock()
    exc = None

    #
    try:
        with lock:
            raise RuntimeError()
    except RuntimeError as e:
        exc = e

    assert exc is not None, "Expected an exception"



# Generated at 2022-06-24 08:45:34.072695
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    """Unit test for constructor of class _TimeoutGarbageCollector"""
    c = _TimeoutGarbageCollector() 
    assert c._waiters == collections.deque()
    assert c._timeouts == 0



# Generated at 2022-06-24 08:45:45.998530
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    def runner():
            condition = Condition()
            @gen.coroutine
            def waiter1():
                await condition.wait(timeout=datetime.timedelta())
                print("I'm done waiting1")

            @gen.coroutine
            def waiter2():
                await condition.wait(timeout=datetime.timedelta())
                print("I'm done waiting2")

            @gen.coroutine
            def notifier():
                print("About to notify")
                condition.notify(n=1)
                print("Done notifying")

            # Wait for waiter() and notifier() in parallel
            yield [waiter1(), waiter2(), notifier()]

    IOLoop.current().run_sync(runner)
# Unit test

# Generated at 2022-06-24 08:45:48.163809
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    obj = Condition()
    assert obj


# Generated at 2022-06-24 08:45:50.742022
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    import tornado.gen
    import pytest
    import tornado.locks
    pass


# Generated at 2022-06-24 08:45:54.735630
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Lock.__aenter__(self)
    # Attempt to lock. Returns an awaitable.
    # Returns an awaitable, which raises tornado.util.TimeoutError after a timeout.

    # self.__aenter__()
    pass



# Generated at 2022-06-24 08:45:57.321232
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    assert condition._waiters == []
    assert condition._timeouts == 0
    assert condition._garbage_collect() == None


# Generated at 2022-06-24 08:45:59.483976
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    """
    Test the method `__repr__` of class Event
    """
    event = Event()
    assert event.__repr__() == "<Event clear>"
    event.set()
    assert event.__repr__() == "<Event set>"
test_Event___repr__()

# Generated at 2022-06-24 08:46:12.653773
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    value = 2
    m = Semaphore(value)
    assert m._value == value
    assert m._waiters == deque()
    waiter = Future()
    m._value = 0
    m._waiters.append(waiter)
    m.release()
    assert m._value == 1
    assert m._waiters == deque()
    m._value = 1
    waiter = Future()
    m._waiters.append(waiter)
    m.release()
    assert m._value == 0
    assert m._waiters == deque([waiter])
    m._value = 0
    waiter1 = Future()
    waiter2 = Future()
    waiter3 = Future()
    m._waiters.append(waiter1)
    m._waiters.append(waiter2)

# Generated at 2022-06-24 08:46:15.511560
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    import asyncio
    from tornado.ioloop import IOLoop
    from tornado.locks import Lock

    async def runner(loop):
        lock = Lock()

        async def acquire():
            async with lock:
                pass

        await acquire()

    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        loop.run_sync(runner, loop)
    finally:
        loop.close()

# Generated at 2022-06-24 08:46:19.275119
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    print(sem)
    sem.__aexit__(None, None, None)
    print(sem)
    try:
        sem.__aexit__(None, None, None)
    except RuntimeError as e:
        print(e)



# Generated at 2022-06-24 08:46:22.338060
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    obj=_ReleasingContextManager('a')
    print(obj._obj)
test__ReleasingContextManager___exit__()



# Generated at 2022-06-24 08:46:24.382335
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    event.clear()


# Generated at 2022-06-24 08:46:25.851439
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"


# Generated at 2022-06-24 08:46:29.001631
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()
    cond.notify_all()
    cond._garbage_collect()
    cond._waiters.append(Future())
    cond.notify_all()

# Generated at 2022-06-24 08:46:35.737486
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    """
    def acquire(self, timeout=None) -> Awaitable[ReleasingContextManager]:
        return self._block.acquire(timeout)
    """
    lock = Lock()
    # await lock.acquire()
    # lock.release()

    async with lock:
        pass

test_Lock___aenter__()


# Generated at 2022-06-24 08:46:42.080572
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    import unittest
    import contextlib
    class Test_ReleasingContextManager(unittest.TestCase):
        def setUp(self):
            pass
        def tearDown(self):
            pass
        def test_constructor(self):
            lock = Lock()
            with contextlib.suppress(TypeError):
                releasingContextManager = _ReleasingContextManager(lock)
            self.assertIsNotNone(releasingContextManager)

    unittest.main()



# Generated at 2022-06-24 08:46:45.809593
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    assert not event._value
    assert not event._waiters
    event.set()
    event.clear()
    assert not event._value
    assert not event._waiters



# Generated at 2022-06-24 08:46:46.293802
# Unit test for constructor of class Condition
def test_Condition():
    Condition()
    return True


# Generated at 2022-06-24 08:46:55.783832
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    sem = Semaphore()
    try:
        with (sem):
            pass
    except RuntimeError:
        pass
    else:
        raise AssertionError
    try:
        with (sem):
            raise StopIteration
    except StopIteration:
        pass
    else:
        raise AssertionError
    try:
        with (sem):
            raise RuntimeError
    except RuntimeError:
        pass
    else:
        raise AssertionError
    try:
        with (sem):
            try:
                raise RuntimeError
            except RuntimeError:
                pass
    except RuntimeError:
        pass
    else:
        raise AssertionError

# Generated at 2022-06-24 08:47:00.262888
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    #print("in test_Semaphore___aenter__")
    from tornado.locks import Semaphore
    semaphore = Semaphore()
    assert(semaphore.aenter() is None )


# Generated at 2022-06-24 08:47:03.690720
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    assert not event.is_set() 
    event.set()
    assert event.is_set()
    event.clear()
    assert not event.is_set()

# Generated at 2022-06-24 08:47:12.762588
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    
    condition = Condition()
    
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    
    IOLoop.current().run_sync(runner)
# testing code
#test_Condition_notify()


# Generated at 2022-06-24 08:47:19.834731
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    """
    Unit test for method __enter__ of class Lock
    """

    # Case 1:
    print("- Case 1:")
    lock = Lock()
    with lock:
        pass

    # Case 2:
    print("- Case 2:")
    lock = Lock()
    try:
        with lock:
            pass
    except RuntimeError as e:
        print(e)


# Generated at 2022-06-24 08:47:27.016575
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    c.notify_all()
    print("I'm done waiting")

# Generated at 2022-06-24 08:47:29.212619
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    with pytest.raises(RuntimeError):
        semaphore = Semaphore()
        with semaphore:
            pass

# Generated at 2022-06-24 08:47:30.636803
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    e = Event()
    ref = '<Event clear>'
    assert e.__repr__() == ref


# Generated at 2022-06-24 08:47:32.790270
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    x = Condition()
    x.notify_all()

# Generated at 2022-06-24 08:47:39.460470
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    import pytest
    from tornado.locks import _TimeoutGarbageCollector, Semaphore

    with pytest.raises(RuntimeError) as e:
        with Semaphore() as s:
            pass
    assert str(e.value) == "Use 'async with' instead of 'with' for Semaphore"


# Generated at 2022-06-24 08:47:40.138780
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():

    Condition(object)
    assert True # TODO: implement your test here


# Generated at 2022-06-24 08:47:43.491065
# Unit test for constructor of class Event
def test_Event():
    testEvent = Event()
    print(testEvent.is_set())
    testEvent.set()
    print(testEvent.is_set())
    print(testEvent.wait())



# Generated at 2022-06-24 08:47:53.925332
# Unit test for method clear of class Event
def test_Event_clear():

    import time, sys
    import unittest2 as unittest

    import tornado.gen
    import tornado.testing
    import tornado.test.util

    class EventTest(tornado.testing.AsyncTestCase):
        def test_event(self):
            event = Event()        

            async def waiter():
                await event.wait()
                await event.wait()
                self.stop()
            self.wait()

            async def setter():
                event.set()
                event.clear()
                event.set()
            tornado.gen.multi([waiter(), setter()])


    class EventTestCase(unittest.TestCase):
        def test_event_clear(self):
            unittest.main()

    def main():
        test_Event_clear()


# Generated at 2022-06-24 08:48:04.019022
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
  try:
    from tornado.locks import Semaphore
  except ImportError:
    print("Skipping test for " + __file__)
    return
  import unittest
  assert isinstance(Semaphore(), Semaphore)
  class Tester(unittest.TestCase):
    def test_Semaphore___enter__(self):
      with unittest.mock.patch("sys.stdout", new=io.StringIO()) as fake_stdout:
        Semaphore().__enter__()
        self.assertEqual("", fake_stdout.getvalue())
  unittest.main(argv=["first-arg-is-ignored"], exit=False)

# Generated at 2022-06-24 08:48:06.241940
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(0)
    print(sem)
    sem.release()


# Generated at 2022-06-24 08:48:08.734098
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    obj0 = Lock()
    str0 = obj0.__repr__()
    assert str0 != None


# Generated at 2022-06-24 08:48:13.890920
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()

    async def f1():
        await gen.sleep(.5)
        await c.notify()

    async def f2():
        await c.wait()
        # I should wake up

    ioloop.IOLoop.current().run_sync(lambda: gen.multi([f1(), f2()]))



# Generated at 2022-06-24 08:48:16.849659
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    # Initialize a Semaphore with value (10)
    obj = Semaphore(10)
    # Check if the returned value from __repr__ is correct
    assert obj.__repr__() == "<Semaphore [unlocked,value:10]>"

# Generated at 2022-06-24 08:48:18.522251
# Unit test for method clear of class Event
def test_Event_clear():
    e = Event()
    e.set()
    e.clear()
    assert e._value == False


# Generated at 2022-06-24 08:48:19.973536
# Unit test for method is_set of class Event
def test_Event_is_set():
    e = Event

    assert e.is_set() == False
    assert e.is_set() == True


# Generated at 2022-06-24 08:48:22.702040
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    """test_Lock___aexit__(self)"""
    lock = Lock()

    async def test_release():
        await lock.acquire()
        lock.release()
        await lock.__aexit__(None, None, None)
        assert lock._block._value == 1

    IOLoop.current().run_sync(test_release)

# Generated at 2022-06-24 08:48:25.562227
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    with pytest.raises(RuntimeError):
        Semaphore().__aexit__(RuntimeError, RuntimeError(), RuntimeError())


# Generated at 2022-06-24 08:48:28.386604
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    assert lock.__repr__() == "<Lock _block=<_TimeoutGarbageCollector [unlocked,value:1]>>"

# Generated at 2022-06-24 08:48:29.517308
# Unit test for constructor of class Event
def test_Event():
    event = Event()


# Generated at 2022-06-24 08:48:31.022850
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    assert repr(cond)=="<Condition>"

# Generated at 2022-06-24 08:48:32.730216
# Unit test for method release of class Lock
def test_Lock_release():
    """Test case for release."""
    # Case 1:
    l = Lock()
    try:
        l.release()
    except RuntimeError:
        pass
    # Case 3:
    l.acquire()
    l.release()


# Generated at 2022-06-24 08:48:35.289503
# Unit test for method wait of class Condition
def test_Condition_wait():
    # 1. test None
    # 2. test
    # 3. test
    # 4. test
    pass


# Generated at 2022-06-24 08:48:41.902661
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    import sys
    import time
    import unittest
    from tornado.locks import Lock

    lock = Lock()
    fut = lock.acquire()

    async def func():
        async with lock:
            await asyncio.sleep(1)
            print('Locked')
        print('Unlocked')

    asyncio.run(func())

    lock.release()

    # run the future
    async def run_future():
        await fut

    asyncio.run(run_future())


    # run the future



# Generated at 2022-06-24 08:48:50.395337
# Unit test for method wait of class Condition
def test_Condition_wait():
    c = Condition()
    class A:
        @gen.coroutine
        def test_wait(self):
            yield c.wait()

        @gen.coroutine
        def test_notify(self):
            yield gen.sleep(1)
            c.notify()

    a = A()
    ioloop.IOLoop.current().run_sync(lambda: gen.multi([a.test_wait(),
                                                        a.test_notify()]))



# Generated at 2022-06-24 08:48:54.426738
# Unit test for method is_set of class Event
def test_Event_is_set():
    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    print("Test for method is_set of class Event")
    event = Event()
    print("event.is_set() = %s" % str(event.is_set()))
    event.set()
    print("event.is_set() = %s" % str(event.is_set()))
    event.clear()
    print("event.is_set() = %s" % str(event.is_set()))


# Generated at 2022-06-24 08:49:03.768745
# Unit test for method __repr__ of class Event
def test_Event___repr__():
	from tornado.concurrent import Future
	from tornado.locks import Event
	from tornado.ioloop import IOLoop
	from tornado import gen 
	from weakref import ref 
	event = Event()
	event_ref = ref(event)
	assert event._value == False
	assert event._waiters == set()
	result = event.__repr__()
	assert result == "<Event clear>"
	event.set()
	result = event.__repr__()
	assert result == "<Event set>" 
	event_ref = None
test_Event___repr__()

# Generated at 2022-06-24 08:49:05.492308
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    a = Semaphore()
    assert (a.acquire().done() == False), "a.__aenter__() failed."
    pass


# Generated at 2022-06-24 08:49:16.891029
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    # Test the correct number of arguments
    try:
        Lock().__aexit__()
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        Lock().__aexit__(None)
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        Lock().__aexit__(None, None)
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        Lock().__aexit__(None, None, None)
    except TypeError:
        pass
    else:
        raise AssertionError

    try:
        Lock().__aexit__(None, None, None, None)
    except TypeError:
        pass
    else:
        raise AssertionError



# Generated at 2022-06-24 08:49:22.777155
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    print(__file__)
    print(inspect.currentframe().f_code.co_name)
    import asyncio
    async def run():
        sem = Semaphore(1)
        async with sem:
            assert sem._value == 0
        assert sem._value == 1
        sem.release()
        assert sem._value == 2
        async with sem:
            assert sem._value == 1
        assert sem._value == 2
        sem.release()
    asyncio.run(run())


# Generated at 2022-06-24 08:49:30.788986
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    """Unit test for method __exit__ of class Lock in module tornado.locks.

    Test the following functions of class Lock:

        def __exit__(self, typ, value, tb) -> None:
            """

# Generated at 2022-06-24 08:49:35.439001
# Unit test for method clear of class Event
def test_Event_clear():
    # test_event_clear tests that clear() method of Event class works correctly
    event = Event()
    event.set()
    assert event.is_set()
    event.clear()
    assert not event.is_set()


# Generated at 2022-06-24 08:49:37.216514
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()

    print(condition)


# Generated at 2022-06-24 08:49:41.188904
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    # Setup
    sem = Semaphore()
    awaitable = gen.sleep(0.1)

    # Test
    assert isinstance(sem.__aexit__(), Awaitable)

    # Teardown
    sem.release()



# Generated at 2022-06-24 08:49:47.263288
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado import locks

    lock = locks.Lock()

    async def f():
        async with lock:
            # Do something holding the lock.
            pass

        # Now the lock is released.

    # For compatibility with older versions of Python, the .acquire
    # method asynchronously returns a regular context manager:

    async def f2():
        with (await lock.acquire()):
            # Do something holding the lock.
            pass

        # Now the lock is released.

    assert True



# Generated at 2022-06-24 08:49:52.181568
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    test_Semaphore = Semaphore()
    test_Semaphore._value = 1
    test_Semaphore._waiters = deque()
    test_Semaphore.release()
    assert test_Semaphore._value == 2
    assert test_Semaphore._waiters == deque()



# Generated at 2022-06-24 08:49:56.874101
# Unit test for method wait of class Condition
def test_Condition_wait():
    import sys
    print("FOR UNIT TESTING: Condition.wait method")
    if sys.version_info >= (3, 5):
        import asyncio

        @gen.coroutine
        def f():
            yield asyncio.sleep(0.001)


        @gen.coroutine
        def test(timeout):
            yield f()
            print('test')


        asyncio.run(test(timeout=1))



# Generated at 2022-06-24 08:50:02.846046
# Unit test for method clear of class Event
def test_Event_clear():
    # type: () -> None
    event = Event()
    test_value1 = event.is_set()
    event.set()
    test_value2 = event.is_set()
    event.clear()
    test_value3 = event.is_set()
    assert test_value1 == False and test_value2 == True and test_value3 == False


# Generated at 2022-06-24 08:50:12.882146
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock1 = Lock()                                          # Create a instance of Lock
    print(lock1)
test_Lock___repr__()

async def test_Lock_acquire():
    lock2 = Lock()
    async with await lock2.acquire():                       # try to acquire a lock
        print("Acquired by 1st coroutine")
        await gen.sleep(0)
        print("Sleeped by 1st coroutine")
        await gen.sleep(0)
    print("Released by 1st coroutine")

    async with await lock2.acquire():
        print("Acquired by 2nd coroutine")
        await gen.sleep(0)
        print("Sleeped by 2nd coroutine")
        await gen.sleep(0)
    print("Released by 2nd coroutine")


# Generated at 2022-06-24 08:50:15.456393
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    async def f():
        await lock.acquire()
        async with lock:
            pass
        lock.release()

# Generated at 2022-06-24 08:50:16.745240
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    event = Event()
    assert repr(event) == "<Event clear>"


# Generated at 2022-06-24 08:50:18.578458
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert event.is_set() == False


# Generated at 2022-06-24 08:50:21.129362
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    # Test method of Semaphore object
    obj=Semaphore()
    with pytest.raises(RuntimeError): obj.__enter__()

# Generated at 2022-06-24 08:50:23.212814
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    # Lock 1
    # No setUp and tearDown needed
    raise NotImplementedError()


# Generated at 2022-06-24 08:50:27.202175
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    event = Event()
    assert event.is_set() == False
    assert event.__repr__() == "<Event clear>"

    event.set()
    assert event.is_set() == True
    assert event.__repr__() == "<Event set>"



# Generated at 2022-06-24 08:50:28.495562
# Unit test for constructor of class Semaphore
def test_Semaphore():
    s = Semaphore(2)


# Generated at 2022-06-24 08:50:30.205848
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"

# Generated at 2022-06-24 08:50:32.747794
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    condition._waiters.append(Future())
    assert repr(condition) == '<Condition waiters[1]>'



# Generated at 2022-06-24 08:50:34.422467
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    a = _TimeoutGarbageCollector()
    # TODO: assert a.__init__()



# Generated at 2022-06-24 08:50:43.481023
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    s = Semaphore()
    # __aexit__ does not return anything, but must be
    # annotated as returning None for mypy to be happy
    return_of_aexit = s.__aexit__(None, None, None)
    assert return_of_aexit is None
    # Functions from __aexit__ must be annotated
    # as such to be compatible with all Python versions
    assert isinstance(Semaphore.__aenter__, CheckedCoroutineFunction)
    assert isinstance(Semaphore.__aexit__, CheckedCoroutineFunction)



# Generated at 2022-06-24 08:50:48.502026
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    # Constructor
    obj = object()
    m = _ReleasingContextManager(obj)
    assert m is not None

    # enter
    with m:
        pass

    # exit
    class DummyException(Exception):
        pass
    try:
        m.__exit__(None, None, None)
    except DummyException:
        pass



# Generated at 2022-06-24 08:50:50.211862
# Unit test for constructor of class Semaphore
def test_Semaphore():
    s = Semaphore()
    assert(s._value == 1)



# Generated at 2022-06-24 08:50:52.282344
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(5)
    print('Semaphore value: ', sem._value)


# Generated at 2022-06-24 08:50:52.941053
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    return

# Generated at 2022-06-24 08:50:56.751400
# Unit test for method is_set of class Event
def test_Event_is_set():
        e = Event()
        assert(e.is_set() == False)
        e.set()
        assert(e.is_set() == True)
        e.clear()
        assert(e.is_set() == False)

# Generated at 2022-06-24 08:50:58.475471
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    _TimeoutGarbageCollector()



# Generated at 2022-06-24 08:51:02.442422
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    '''Unit test for method __enter__ of class Semaphore'''
    sem = Semaphore()
    try:
        with sem:
            pass
    except RuntimeError:
        pass
    else:
        raise AssertionError('Semaphore.__enter__ raised no exception')

# Generated at 2022-06-24 08:51:08.265815
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore()
    # the counter is 1 by default
    f = sem.acquire()
    assert f.done() == False
    sem.release()
    assert f.done() == True
    # the counter is 0 after release
    f = sem.acquire()
    assert f.done() == False
    sem.release()
    assert f.done() == True
    # the counter is -1 after release again
    f = sem.acquire()
    assert f.done() == False
    sem.release()
    assert f.done() == True
    # the counter is -2 after release again
    f = sem.acquire()
    assert f.done() == False
    sem.release()
    assert f.done() == True
    # the counter is -3 after release again
    f = sem.acquire()

# Generated at 2022-06-24 08:51:10.572017
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    print(repr(lock))
    return lock


# Generated at 2022-06-24 08:51:15.481787
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    from tornado.locks import Lock
    import time
    # Create a Lock
    Lock_instance0 = Lock()
    # Stringify
    repr(Lock_instance0)
    # Delete the Lock
    del Lock_instance0
    # Verify that Lock has been deleted
    try:
        Lock
    except NameError:
        assert True
    else:
        assert False

# Generated at 2022-06-24 08:51:16.839222
# Unit test for method set of class Event
def test_Event_set():
    __tracebackhide__ = True
    x= Event()
    x.set()

# Generated at 2022-06-24 08:51:18.370860
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    cm = _ReleasingContextManager(5)
    assert cm._obj == 5

# Generated at 2022-06-24 08:51:21.421159
# Unit test for method is_set of class Event
def test_Event_is_set():
    e=Event()
    print(e.is_set())
    e.set()
    print(e.is_set())
    e.clear()
    print(e.is_set())


# Generated at 2022-06-24 08:51:29.165885
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from collections import deque
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from tornado.locks import Semaphore

    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-24 08:51:30.700069
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    obj = Lock()
    assert repr(obj) == '<Lock _block=<BoundedSemaphore _value=1,_initial_value=1>>'



# Generated at 2022-06-24 08:51:33.458172
# Unit test for constructor of class Semaphore
def test_Semaphore():
    try:
        Semaphore(100)
        Semaphore(-100)
    except ValueError:
        return True
    return False


# Generated at 2022-06-24 08:51:35.884944
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    s = BoundedSemaphore(1)
    s.release()
    s.release()

# Generated at 2022-06-24 08:51:38.210181
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    # test constructor
    if not isinstance(lock, Lock):
        raise RuntimeError("constructor returns wrong type")
    return


# Generated at 2022-06-24 08:51:41.072951
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    with _ReleasingContextManager(1) as a:
        try:
            a.__exit__(None, None, None)
        except Exception as e:
            print(e)


# Generated at 2022-06-24 08:51:45.969371
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    try:
        raise ValueError
    except ValueError as e:
        _ReleasingContextManager(()).__exit__(
            type(e), e, None
        )
        _ReleasingContextManager(()).__exit__(
            type(e), e, None
        )



# Generated at 2022-06-24 08:51:48.093465
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    waiter = Event()
    waiter.set()
    with _ReleasingContextManager(waiter):
        pass
    assert waiter.is_set()



# Generated at 2022-06-24 08:51:57.290776
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from asyncio import Future
    from tornado import gen, locks
    lock = locks.Lock()
    future = Future()
    def do_release():
        future.set_result(None)

    lock._block._value = -1
    lock._block._waiters.append(future)

    async def test():
        await lock.__aexit__(None, None, None)
        assert lock._block._value == 0
        assert len(lock._block._waiters) == 0

    gen.run_sync(test)
    assert future.done()

# Generated at 2022-06-24 08:51:58.949113
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    lock = Lock()
    try:
        lock.__enter__()
    except RuntimeError as err:
        assert err == "Use `async with` instead of `with` for Lock"


# Generated at 2022-06-24 08:52:00.752490
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    from tornado import locks
    from tornado import gen
    l = locks.Lock()
    l.acquire()



# Generated at 2022-06-24 08:52:03.059204
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bs = BoundedSemaphore(2)
    bs.release()
    return bs.release()

test_run(test_BoundedSemaphore_release)


# Generated at 2022-06-24 08:52:06.740251
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    class Test(object):

        def __init__(self) -> None:
            self.released = False

        def release(self) -> None:
            self.released = True

    obj = Test()
    cm = _ReleasingContextManager(obj)
    cm.__exit__(None, None, None)
    assert obj.released



# Generated at 2022-06-24 08:52:08.429743
# Unit test for constructor of class Event
def test_Event():
    assert not Event().is_set()



# Generated at 2022-06-24 08:52:10.765307
# Unit test for constructor of class Semaphore
def test_Semaphore():
    s = Semaphore(3)
    assert s._value == 3


# Generated at 2022-06-24 08:52:13.713180
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    loop = ioloop.IOLoop.current()
    @gen.coroutine
    def waiter():
        yield condition.wait()
        print("I'm done waiting")
    @gen.coroutine
    def notifier():
        yield gen.sleep(1)
        print("About to notify")
        condition.notify()
        condition.notify_all()
        print("Done notifying")
    @gen.coroutine
    def runner():
        yield gen.multi([waiter(), notifier()])
    loop.run_sync(runner)


# Generated at 2022-06-24 08:52:19.072004
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # c1 = Condition()
    # c2 = Condition()
    # c2_repr = repr(c2)  # NOQA
    # c2._waiters.append(object())
    # c2_with_waiter = repr(c2)  # NOQA
    # return c1, c2, c2_repr, c2_with_waiter
    pass


_NO_RESULT = object()



# Generated at 2022-06-24 08:52:26.429765
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    from typing import Deque
    a = _TimeoutGarbageCollector()
    assert isinstance(a._waiters, Deque)
    assert a._timeouts == 0

    a._garbage_collect()
    assert a._timeouts == 1

    a._garbage_collect()
    assert a._timeouts == 2

    a._garbage_collect()
    assert a._timeouts == 3

    a._garbage_collect()
    assert a._timeouts == 4

test__TimeoutGarbageCollector()



# Generated at 2022-06-24 08:52:33.715279
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    gc = _TimeoutGarbageCollector()
    for i in range(1000):
        f = Future()
        if i >= 2:
            f.set_result(i)
        gc._waiters.append(f)
    gc._garbage_collect()
    print(gc._waiters)
test__TimeoutGarbageCollector()

ConditionResult = Union[bool, datetime.timedelta]


# Generated at 2022-06-24 08:52:39.942769
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    class Test_Semaphore(Semaphore):
        pass
    t1 = Test_Semaphore(1)
    r1 = repr(t1)
    r2 = t1.__repr__()
    assert r1 == r2
# Code from Tornado, Copyright 2009 Facebook
# Copyright 2010-present Twitter. All rights reserved.
# Licensed under the Apache License, Version 2.0
# http://www.apache.org/licenses/LICENSE-2.0


# Generated at 2022-06-24 08:52:41.255201
# Unit test for constructor of class Event
def test_Event():
    a = Event()
    print(type(a))


# Generated at 2022-06-24 08:52:44.713398
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    assert event._value == False
    assert isinstance(event._waiters, set)
# Testing end



# Generated at 2022-06-24 08:52:46.219558
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    import pytest
    from tornado import locks
    with pytest.raises(RuntimeError):
        with locks.Lock():
            pass



# Generated at 2022-06-24 08:52:53.595180
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    """ Method release of class BoundedSemaphore.

    Args:
        None

    Returns:
        None

    Raises:
        None
    """
    # Object of class BoundedSemaphore
    sem = BoundedSemaphore(value=2)

    # Release semaphore 3 times
    sem.release()
    sem.release()
    try :
        sem.release()
    except ValueError:
        pass



# Generated at 2022-06-24 08:52:57.796791
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    from tornado import locks
    lock = locks.Lock()
    assert isinstance(lock._block, locks.BoundedSemaphore)
    assert lock.__repr__() == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"

# Generated at 2022-06-24 08:53:02.316185
# Unit test for method is_set of class Event
def test_Event_is_set():
    e = Event()
    e.clear()
    assert not e.is_set(), 'is_set function failed'
    e.set()
    assert e.is_set(), 'is_set function failed'

test_Event_is_set()


# Generated at 2022-06-24 08:53:05.760507
# Unit test for constructor of class Semaphore
def test_Semaphore():
    with pytest.raises(ValueError) as exc_info:
        s = Semaphore(-1)
    assert 'semaphore initial value must be >= 0' in str(exc_info.value)


# Generated at 2022-06-24 08:53:08.156232
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    print("test_BoundedSemaphore_release")
    sem = BoundedSemaphore(value=1)
    sem.release()
    assert sem._value == 1



# Generated at 2022-06-24 08:53:12.029407
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())


# Generated at 2022-06-24 08:53:16.287343
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    e = Event()
    r = e.__repr__()
    assert r == "<Event clear>"
    e.set()
    r = e.__repr__()
    assert r == "<Event set>"



# Generated at 2022-06-24 08:53:17.898735
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    pass  # TODO: implement your test here



# Generated at 2022-06-24 08:53:19.002638
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    e = Event()
    print(e)
    e.set()
    print(e)


# Generated at 2022-06-24 08:53:24.170118
# Unit test for method release of class Lock
def test_Lock_release():
    # Setup
    lock = Lock()
    lock_acquire = lock.acquire()
    lock._block._value = 0
    lock._block._waiters.append(lock_acquire)

    # Test
    lock.release()

    # Assert
    assert lock_acquire.done()

# Generated at 2022-06-24 08:53:26.416094
# Unit test for method wait of class Event
def test_Event_wait():
    e = Event()
    try:
        # 'e' is not set.
        assert e.is_set() == False
        e.wait(timeout=0.5)
        pass
    except TimeoutError:
        # 'e' is set.
        e.set()
        assert e.is_set() == True
