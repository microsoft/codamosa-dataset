

# Generated at 2022-06-24 08:43:28.921849
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    sem = Semaphore(5)
    def test():
        sem.__enter__()
    try:
        test()
        assert False
    except RuntimeError:
        pass
    assert True


# Generated at 2022-06-24 08:43:33.267016
# Unit test for method is_set of class Event
def test_Event_is_set():
    e = Event()
    # by default, the flag is False
    assert not e.is_set()
    e.set()
    assert e.is_set()
    e.clear()
    assert not e.is_set()

# Generated at 2022-06-24 08:43:34.145363
# Unit test for constructor of class Event
def test_Event():
    global event
    event = Event()


# Generated at 2022-06-24 08:43:35.387697
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    obj = _TimeoutGarbageCollector()
    obj.__init__()



# Generated at 2022-06-24 08:43:39.978024
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    lock = Lock()
    try:
        lock.__enter__()
    except RuntimeError as e:
        assert str(e) == 'Use `async with` instead of `with` for Lock'
test_Lock___enter__()


# Generated at 2022-06-24 08:43:41.239245
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    print(lock)

# Generated at 2022-06-24 08:43:43.557420
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True

# Generated at 2022-06-24 08:43:45.946401
# Unit test for method clear of class Event
def test_Event_clear():
    e = Event()
    if e == 0:
        pass
    else:
        print("e != 0")
        print("e = " + str(e))


# Generated at 2022-06-24 08:43:48.570384
# Unit test for constructor of class Lock
def test_Lock():
    """Unit test for constructor of class Lock"""
    lock = Lock()
    assert lock._block is not None
    assert len(lock._block._waiters) == 0
    assert lock._block._value == 1



# Generated at 2022-06-24 08:43:57.415334
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado.locks import Condition

    condition = Condition()

    async def async_writer():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def async_reader():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([async_reader(), async_writer()])

    ioloop.IOLoop.current().run_sync(runner)



# Generated at 2022-06-24 08:43:59.950576
# Unit test for constructor of class Event
def test_Event():

    # t.Tuple[None, None]
    value = Event().wait()
    assert isinstance(value, Awaitable)
    #assert value == (None, None)



# Generated at 2022-06-24 08:44:05.294842
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())
    print(event.wait())


if __name__ == "__main__":
    test_Event_wait()

# Generated at 2022-06-24 08:44:06.823545
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    lock = Lock()

    with (yield lock.acquire()):
        pass



# Generated at 2022-06-24 08:44:10.618641
# Unit test for method wait of class Event
def test_Event_wait():
    print("Testing method wait of Event class")
    event = Event()
    event.set()
    assert event.wait()
    assert event.wait(timeout=datetime.timedelta(seconds=1))
    print("Passed")

test_Event_wait()


# Generated at 2022-06-24 08:44:18.418748
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    n = 200
    waiters = []
    def test_waiters():
        for x in range(n):
            waiters.append(condition.wait())

    io_loop = ioloop.IOLoop.current()
    io_loop.run_sync(test_waiters)

    condition.notify_all()

    for x in range(n):
        assert waiters[x].done() == True


# Generated at 2022-06-24 08:44:24.508716
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert event.is_set() == False

    event.set()
    assert event.is_set() == True

    event.clear()
    assert event.is_set() == False


# Generated at 2022-06-24 08:44:33.621556
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    obj = Semaphore(1)
    try:
        with (obj):
            pass
    except Exception as e:
        if not isinstance(e, RuntimeError):
            raise Exception(
                "Unexpected exception raised: " + repr(e)
            )
        else:
            if str(e) != "'Use 'async with' instead of 'with' for Semaphore'":
                raise Exception(
                    "Unexpected exception raised: " + str(e)
                )
            else:
                pass
    else:
        raise Exception(
            "RuntimeError not raised"
        )


# Generated at 2022-06-24 08:44:38.578386
# Unit test for method wait of class Condition
def test_Condition_wait():
    cond = Condition()

    async def wait_for_it():
        await cond.wait()
        print('hello')

    async def wake_waiters():
        await gen.sleep(0.1)
        cond.notify()

    IOLoop.current().run_sync(lambda: gen.multi([wait_for_it(), wake_waiters()]))



# Generated at 2022-06-24 08:44:50.629175
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    ''' method Lock.acquire(timeout)
    '''
    lock = Lock()
    async def f():
        async with lock:
            while True:
                print("Hi!")
                await gen.sleep(0.5)
    
    async def g():
        await gen.sleep(1)
        async with lock:
            print("Bye!")
    
    # what it does:
    # await lock.acquire()
    # with (_ReleasingContextManager(lock)) as t:
    asyncio.run([f(), g()])
    print('Done!')

# test_Lock_acquire()

# Generated at 2022-06-24 08:44:53.115259
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    async def __aexit__(self, typ, value, tb):
        self.release()
    __aexit__(self, typ, value, tb)



# Generated at 2022-06-24 08:45:00.222722
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition=Condition()

    #Test 1
    print("Test 1")
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]

    ioloop.IOLoop.current().run_sync(runner)

    #Test 2
    print("Test 2")
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")


# Generated at 2022-06-24 08:45:05.694920
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    class TestObject(object):
        def __init__(self):
            # type: () -> None
            self.called = False

        def release(self):
            # type: () -> None
            self.called = True

    testobj = TestObject()
    with _ReleasingContextManager(testobj):
        pass
    assert testobj.called



# Generated at 2022-06-24 08:45:06.793133
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    return


# Generated at 2022-06-24 08:45:16.566400
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()

    @gen.coroutine
    def f1():
        yield cond.wait()
        print("f1 done")

    @gen.coroutine
    def f2():
        yield cond.wait()
        print("f2 done")

    @gen.coroutine
    def f3():
        yield cond.wait()
        print("f3 done")

    @gen.coroutine
    def f4():
        yield cond.wait()
        print("f4 done")

    @gen.coroutine
    def f0():
        yield gen.multi([f1(), f2(), f3(), f4()])
        print("f0 done")

    ioloop.IOLoop.current().run_sync(f0)
    cond.notify_all()



# Generated at 2022-06-24 08:45:18.880813
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()

    condition = Condition(ioloop.IOLoop.current())


# Generated at 2022-06-24 08:45:25.543392
# Unit test for method release of class Lock
def test_Lock_release():

    lock = Lock()
    with pytest.raises(RuntimeError):
        lock.release()
    lock.block = BoundedSemaphore(value = 1)
    # The first coroutine in line waiting for `acquire` gets the lock.
    lock._block.value = 0
    with pytest.raises(ValueError):
        lock.release()
    # else
    lock.release()

# Generated at 2022-06-24 08:45:34.257512
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    """Test for method __aexit__ of class Lock."""
    from tornado.ioloop import IOLoop, PeriodicCallback
    from tornado.locks import Lock, Event
    import time

    lock = Lock()
    result_event = Event()

    async def wait_for_lock():
        async with lock:
            # Simulate some wait time.
            await gen.sleep(2)
            result_event.set('released')

    async def acquire_lock():
        await gen.sleep(1)
        await lock.acquire()
        result_event.set('acquired')

    async def runner():
        """Test aenter/aexit using async with."""
        await wait_for_lock()
        await acquire_lock()
        result = await result_event.wait()
        assert result == 'released'

    IOLoop.current

# Generated at 2022-06-24 08:45:37.273385
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore()
    async with sem:
        assert sem._value == 0


# Generated at 2022-06-24 08:45:39.632156
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    sem = BoundedSemaphore(1)
    assert isinstance(sem, Semaphore)
    assert sem._initial_value == 1
    assert sem._value == 1

    sem.acquire()
    assert sem._value == 0
    sem.release()
    assert sem._value == 1
    try:
        sem.release()
        assert False
    except ValueError:
        pass

# Generated at 2022-06-24 08:45:43.956078
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():        
    class_ = Condition()
    num_waiters = 3
    waiters = [description for description in range(num_waiters)]
    class_._waiters = collections.deque(waiters)

    class_.notify_all()

    assert len(class_._waiters) == 0


# Generated at 2022-06-24 08:45:57.080529
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    def make_args(self: Semaphore, typ: "Optional[Type[BaseException]]", value: Optional[BaseException], traceback: Optional[types.TracebackType]):
        return self, typ, value, traceback
    self: Semaphore = Semaphore()
    value_arg = None
    args = make_args(self, None, value_arg, None)
    self.acquire = lambda: Future()
    self.__exit__(*args)
    for _ in range(10):
        self.acquire = lambda: Future()
        self.__exit__(*args)
        self.acquire = lambda: Future()
        self.__exit__(*args)
        self.acquire = lambda: Future()
        self.__exit__(*args)

# Generated at 2022-06-24 08:46:04.307497
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    _value = 1
    while _waiters:
        waiter = _waiters.popleft()
        if not waiter.done():
            _value -= 1

            # If the waiter is a coroutine paused at
            #
            #     with (yield semaphore.acquire()):
            #
            # then the context manager's __exit__ calls release() at the end
            # of the "with" block.
            waiter.set_result(_ReleasingContextManager(self))
            break

# Generated at 2022-06-24 08:46:10.065620
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    class TestReleasingContextManager(_ReleasingContextManager):
        pass
    obj = object()
    ctx = TestReleasingContextManager(obj)
    assert ctx._obj is obj
    assert ctx.__enter__() is None
    assert ctx.__exit__(None, None, None) is None


# Generated at 2022-06-24 08:46:13.586980
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    try:
        sem = BoundedSemaphore(10) # try to create bouded semaphore
        assert(sem is not None) # if creation succeeded, that means the constructor works
    except:
        assert(1 == 0) # else, that means the constructor doesn't work

# Generated at 2022-06-24 08:46:14.381301
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()



# Generated at 2022-06-24 08:46:15.481700
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    assert isinstance(condition, Condition)


# Generated at 2022-06-24 08:46:17.766945
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()
    n = c.notify(2)
    print(n)
    c.notify(1)
    c.notify(1)

test_Condition_notify()


# Generated at 2022-06-24 08:46:20.226231
# Unit test for method release of class Lock
def test_Lock_release():
    from tornado.locks import Lock

    lock = Lock()
    lock.release()

# Generated at 2022-06-24 08:46:25.907136
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    # Lock.__exit__() -> None
    # Raises RuntimeError when used with the "with" semantinc
    lock = Lock()
    try:
        with lock:
            pass
    except RuntimeError:
        pass
    else:  # pragma: no cover
        assert False, "failed to raise RuntimeError"



# Generated at 2022-06-24 08:46:30.236923
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    @gen.coroutine
    def f():
        lock = Lock()
        with (yield lock.acquire()):
            print('Acquire')
            yield gen.sleep(20)

    ioloop = IOLoop.current()
    ioloop.run_sync(f)


# Generated at 2022-06-24 08:46:33.575506
# Unit test for method is_set of class Event
def test_Event_is_set():
    e = Event()
    assert not e.is_set()  # test if its not set
    e.set()                # set the event
    assert e.is_set()      # test that it is now set

# Generated at 2022-06-24 08:46:36.405157
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    a = _TimeoutGarbageCollector()
    assert a._waiters == collections.deque()
    assert a._timeouts == 0


# Generated at 2022-06-24 08:46:37.800590
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(10)
    sem.release()

# Generated at 2022-06-24 08:46:45.375263
# Unit test for method wait of class Event
def test_Event_wait():
    from tornado.ioloop import IOLoop
    event = Event()
    def waiter():
        print("Waiting for event")
        event.wait()
        print("Not waiting this time")
        event.wait()
        print("Done")

    def setter():
        print("About to set the event")
        event.set()

    def runner():
        waiter()
        setter()

    runner()
    IOLoop.current().start()


# test_Event_wait()



# Generated at 2022-06-24 08:46:46.840290
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    assert isinstance(_ReleasingContextManager(object()), _ReleasingContextManager)



# Generated at 2022-06-24 08:46:48.203307
# Unit test for constructor of class Lock
def test_Lock():
    l = Lock()


# Generated at 2022-06-24 08:46:53.489846
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    import inspect
    from tornado import locks

    # type: Lock
    lock = locks.Lock()

    # __exit__ is a method of Lock
    assert hasattr(lock, "__exit__")
    assert inspect.isfunction(lock.__exit__)

    # __exit__ has 4 positional arguments
    assert lock.__exit__.__code__.co_argcount == 4



# Generated at 2022-06-24 08:46:55.196898
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    """Test method __enter__ of class Lock"""
    return None


# Generated at 2022-06-24 08:46:59.635705
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    import asyncio
    from datetime import timedelta
    # Setup
    s = Semaphore()
    # Exercise
    with (yield s.acquire()):
        pass
    async def worker():
        async with s:
            pass
    IOLoop.current().run_sync(worker)
    s._value = 0
    with (yield s.acquire(timeout=0.5)):
        pass
    s.__aexit__(None, None, None)
    # Verify
    assert True
    pass



# Generated at 2022-06-24 08:47:07.317518
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)

    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi(worker(i) for i in range(3))

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-24 08:47:14.326387
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # This test is taken from the unit test of a different version of Semaphore
    sem = BoundedSemaphore(5)
    for _ in range(2):
        sem.release()
        assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5
    with pytest.raises(ValueError):
        sem.release()
    with pytest.raises(ValueError):
        sem.release(block=False)



# Generated at 2022-06-24 08:47:19.494210
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-24 08:47:21.650246
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    # First, try clearing the Event.
    event.clear()
    # Event has a .is_set() method that should return True if the Event
    # has been set and False if not.
    assert event.is_set() is False



# Generated at 2022-06-24 08:47:24.001553
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    """Test for method __repr__ of class Lock"""
    lock = Lock()
    assert type(lock.__repr__()) == str



# Generated at 2022-06-24 08:47:30.234519
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)



# Generated at 2022-06-24 08:47:33.120364
# Unit test for method clear of class Event
def test_Event_clear():
    e = Event()
    e.clear()
    assert not e._value
    assert not e._waiters


# Generated at 2022-06-24 08:47:42.433489
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Arrange
    sem = Semaphore(5)
    # Act
    assert sem.acquire() == True
    assert sem.acquire() == True
    assert sem.acquire() == True
    assert sem.acquire() == True
    assert sem.acquire() == True
    assert sem.acquire() == False
    # Assert condition after Acquire
    assert(sem._value == 0) # value should be zero since all 5 have been acquired

if __name__ == "__main__":
    test_Semaphore_acquire()

# Generated at 2022-06-24 08:47:45.716080
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    from tornado import locks
    lock = locks.Lock()

    # noinspection PyUnusedLocal
    def f(typ, value, tb):
        return "Lock"

    lock.__exit__(RuntimeError, None, None)

# Generated at 2022-06-24 08:47:49.386762
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # The following line will raise ValueError exception due to the release()
    # method of class BoundedSemaphore.
    print("\nThe following exception is expected and it is not a bug:\n")
    val = 1
    sem = BoundedSemaphore(val)
    sem.release()

# Generated at 2022-06-24 08:47:51.183661
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    # Lock.__enter__() -> None
    ...



# Generated at 2022-06-24 08:47:54.435837
# Unit test for method set of class Event
def test_Event_set():
    print("Test method set of class Event")
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-24 08:47:55.657804
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()



# Generated at 2022-06-24 08:47:57.425703
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    with Lock() as lock:
        pass

# Generated at 2022-06-24 08:48:00.309338
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    obj: Lock = Lock()
    def __aexit__(self, typ, value, tb):
        pass



# Generated at 2022-06-24 08:48:03.145876
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    """Test if Condition.__repr__ works as expected"""
    condition = Condition()
    assert '<Condition' in condition.__repr__()


# Generated at 2022-06-24 08:48:04.662817
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    print (event.is_set())


# Generated at 2022-06-24 08:48:15.662742
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    """
    async def test_Lock___exit__(self):
        from tornado.ioloop import IOLoop
        from tornado.locks import Lock

        lock = Lock()

        async def child():
            async with lock:
                pass

        def raise_error():
            raise Exception()
            # shouldn't get here
            return False

        async def parent():
            async with lock:
                # With a real exception, the lock should be released,
                # but with something like AssertionError (which is
                # swallowed by main_async), it stays held.
                IOLoop.current().add_callback(raise_error)

        with self.assertRaises(Exception):
            IOLoop.current().run_sync(parent)
        self.assertTrue(IOLoop.current().run_sync(lock.acquire))

    """


# Generated at 2022-06-24 08:48:17.597717
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    event.set()
    event.clear()
    event.wait()

# Generated at 2022-06-24 08:48:26.208834
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():  # type: () -> None


    def __init__(self) -> None:
        super().__init__()
        self.io_loop = ioloop.IOLoop.current()
        self._waiters = collections.deque()  # type: Deque[Future]
        self._timeouts = 0

    def __repr__(self) -> str:
        result = "<%s" % (self.__class__.__name__,)
        if self._waiters:
            result += " waiters[%s]" % len(self._waiters)
        return result + ">"


# Generated at 2022-06-24 08:48:30.811730
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    import unittest

    class LockTestCase(unittest.TestCase):
        def runTest(self):
            lock = Lock()
            with self.assertRaises(RuntimeError):
                with lock:
                    pass

    unittest.main()


# Generated at 2022-06-24 08:48:33.106245
# Unit test for method is_set of class Event
def test_Event_is_set():
    e = Event()
    assert not e.is_set()
    e.set()
    assert e.is_set()



# Generated at 2022-06-24 08:48:39.503305
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    from unittest import TestCase
    from tornado.locks import Semaphore

    class TestSemaphore(TestCase):
        def test_Semaphore___enter__(self):
            # type: () -> None
            sem = Semaphore()
            with self.assertRaises(RuntimeError):
                with sem:
                    pass

    test_Semaphore = TestSemaphore()
    test_Semaphore.test_Semaphore___enter__()


# Generated at 2022-06-24 08:48:52.571100
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    import collections, sys

    print(sys.version_info)
    assert sys.version_info < (3, 7)

    class test_iter:
        def __init__(self, x):
            self.x = x
            self.count = 0

        def __aiter__(self):
            return self

        async def __anext__(self):
            if self.count < len(self.x):
                self.count += 1
                return self.x[self.count - 1]
            else:
                raise StopAsyncIteration

    assert sys.version_info < (3, 7)
    assert len(collections.deque()) == 0
    assert len(collections.deque((1, 2, 3))) == 3
    assert len(collections.deque((1, 2, 3, 4))) == 4
   

# Generated at 2022-06-24 08:48:55.571607
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    b = BoundedSemaphore(value=10)
    assert b._value == 10
    b.release()
    assert b._value == 10

test_BoundedSemaphore()

# Generated at 2022-06-24 08:49:02.382300
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    import unittest

    class TestCase(unittest.TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_test(self):
            with self.assertRaises(RuntimeError):
                s = Semaphore()
                with s:
                    pass
    unittest.main(verbosity=2)


# Generated at 2022-06-24 08:49:06.213301
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    class Test(object):
        def release(self) -> None:
            self.released = True
    obj = Test()
    with _ReleasingContextManager(obj):
        pass
    assert obj.released
# Test does not work in mypy
# test__ReleasingContextManager___exit__()

# Generated at 2022-06-24 08:49:09.166372
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    obj = _ReleasingContextManager(1)
    obj.__enter__()
    obj.__exit__(None, None, None)



# Generated at 2022-06-24 08:49:11.315999
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    lock = Lock()
    with pytest.raises(RuntimeError):
        lock.__enter__()


# Generated at 2022-06-24 08:49:16.809291
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    # Skip test if condition is not met
    if not isinstance(1, int):
        return
    from tornado.testing import gen_test
    from tornado import gen

    e = _ReleasingContextManager(1)
    f = gen.Future() # type: gen.Future[None]
    def callback(_):
        f.set_result(None)
    gen.coroutine(e.__enter__)(callback)
    yield f



# Generated at 2022-06-24 08:49:21.310123
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    # Semaphore.__enter__()  ->  NotImplemented
    # (This function is a coroutine)
    #
    #  raise RuntimeError("Use 'async with' instead of 'with' for Semaphore")
    # 
    pass




# Generated at 2022-06-24 08:49:22.840596
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    # Event.__repr__() -> str
    ...

# Generated at 2022-06-24 08:49:26.167014
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(value=0)
    assert sem._value == 0
    assert type(sem.release) == types.MethodType
    assert type(sem.acquire) == types.MethodType
    assert type(sem._waiters) == collections.deque


# Generated at 2022-06-24 08:49:29.314439
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    '''
    Test Semaphore.__repr__
    '''
    c = Semaphore(1)
    assert repr(c) == "<Semaphore [locked]>"
    c.release()
    assert repr(c) == "<Semaphore [unlocked,value:1]>"




# Generated at 2022-06-24 08:49:37.691680
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    bs = BoundedSemaphore(10)
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    try:
        bs.release()
        bs.release()
        bs.release()
        bs.release()
        bs.release()
        bs.release()
    except ValueError as e:
        print(e)

# Generated at 2022-06-24 08:49:39.668099
# Unit test for constructor of class Semaphore
def test_Semaphore():
  with pytest.raises(ValueError):
    s = Semaphore(-1)



# Generated at 2022-06-24 08:49:49.542774
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    lock = Lock()
    lock._block = BoundedSemaphore(value=1)
    
    import tornado.locks as locks

    assert lock._block._initial_value == 1

    assert lock.__exit__(TypeError, None, None) is None
    assert lock.__exit__(TypeError, None, None) is None
    assert lock.__exit__(TypeError, None, None) is None
    assert lock.__exit__(TypeError, None, None) is None
    assert lock.__exit__(TypeError, None, None) is None
    assert lock.__exit__(TypeError, None, None) is None
    assert lock.__exit__(TypeError, None, None) is None
    assert lock.__exit__(TypeError, None, None) is None

# Generated at 2022-06-24 08:49:51.143554
# Unit test for method is_set of class Event
def test_Event_is_set():
    ev = Event()
    assert ev.is_set() == False

# Generated at 2022-06-24 08:49:51.725727
# Unit test for method wait of class Condition
def test_Condition_wait():
    pass


# Generated at 2022-06-24 08:49:59.281248
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import types
    import random
    import string
    import uuid
    import time
    import sys

    import concurrent.futures as mp
    import tornado.gen as gen
    import tornado.ioloop as ioloop
    import tornado.locks as locks
    import tornado.testing as testing
    import tornado.platform.asyncio as asyncio
    import asyncio
    from tornado.platform.asyncio import to_asyncio_future
    from tornado.platform.asyncio import to_tornado_future
    from tornado.platform.asyncio import AnyThreadEventLoopPolicy
    from concurrent.futures import ThreadPoolExecutor, ProcessPoolExecutor
    import asyncio
    import tornado.platform.asyncio
    from tornado.platform.asyncio import to_asyncio_future

# Generated at 2022-06-24 08:50:10.414976
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
  condition1 = Condition()
  condition1.notify_all()
  # Initialization of variable that stores details of the test performed
  test_details = dict()
  test_details['test_id'] = 'Test_9'
  test_details['test_case_id'] = 'TC_9.1'
  test_details['test_name'] = 'Notify All'
  test_details['prerequisite'] = ''
  test_details['expected_outcome'] = 'No Exception should be thrown'
  test_details['actual_result'] = 'No Exception is thrown'
  test_details['test_passed'] = True

  # Populate test_details with the test performed
  test_details['measurement_name'] = 'Run Time'
  test_details['measurement_value'] = ''


# Generated at 2022-06-24 08:50:12.720320
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    instance = Semaphore()
    try:
        instance.__enter__()
    except RuntimeError as e:
        pass
    else:
        raise Exception("RuntimeError was expected")

# Generated at 2022-06-24 08:50:15.613753
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert event.is_set() == False
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-24 08:50:16.878277
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    print(event.is_set()) # False


# Generated at 2022-06-24 08:50:21.211002
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    future = Future()
    condition._waiters.append(future)
    assert repr(condition) == '<Condition waiters[1]>'


# Generated at 2022-06-24 08:50:26.258972
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore()
    assert sem.acquire(2) == _ReleasingContextManager(sem)
    assert sem.acquire(1) == _ReleasingContextManager(sem)
    assert sem.acquire(3) == _ReleasingContextManager(sem)
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-24 08:50:26.965805
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    pass

# Generated at 2022-06-24 08:50:30.453713
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    assert repr(lock) == '<Lock _block=<BoundedSemaphore _waiters:0, unblocked:1, value:1>>'


# Generated at 2022-06-24 08:50:38.763092
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    list1 = []
    async def waiter():
        await condition.wait()
        list1.append(1)
        print("I'm done waiting")
    condition = Condition()
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await condition.wait()
        await gen.multi([waiter(), waiter(), waiter()])

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    ioloop = IOLoop.current()
    ioloop.run_sync(runner)
#     def test_Condition_notify_all():
#         list1 = []
#         async def waiter():
#             await condition.wait()
#             list1.append(1)
#             print("I'm done waiting")
#         condition = Condition()

# Generated at 2022-06-24 08:50:43.853548
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    value = 10
    import random
    for i in range(value):
        bs = BoundedSemaphore(value)
        bs.release()
    return "test_BoundedSemaphore_release passed!"
print(test_BoundedSemaphore_release())


# Generated at 2022-06-24 08:50:46.164203
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock_obj = Lock()
    assert lock_obj._block._value == 1
    assert lock_obj.__aexit__(None, None, None) is None
    

# Generated at 2022-06-24 08:50:57.328615
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from tornado import testing
    import unittest
    import threading
    import time

    class LockTest(testing.AsyncTestCase):

        def test_context_manager(self):
            lock = threading.Lock()
            with lock:
                with self.assertRaises(RuntimeError):
                    with lock:
                        self.fail("didn't raise")
            self.assertFalse(lock.locked())
            with lock:
                pass
            self.assertFalse(lock.locked())

        def test_context_manager_from_coroutine(self):
            lock = threading.Lock()
            self.assertFalse(lock.locked())
            @gen.coroutine
            def f():
                with lock:
                    yield gen.sleep(0.1)
                self.assertFalse(lock.locked())

            lock.acquire()
            start

# Generated at 2022-06-24 08:51:01.217318
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    s = BoundedSemaphore()

    def test():
        try:
            s.release()
            raise "Should throw error"
        except ValueError:
            pass

    test()
    try:
        s.release()
        s.acquire()
        test()
    finally:
        s.release()

# Generated at 2022-06-24 08:51:03.318798
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    '''
    It should return None
    '''
    A = Lock()
    assert A.__aenter__() is None

# Generated at 2022-06-24 08:51:04.103158
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()


# Generated at 2022-06-24 08:51:06.774354
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    a = _TimeoutGarbageCollector()
    assert a._garbage_collect() == None

Condition = ioloop.IOLoop.instance().run_sync(
    lambda: Condition(), timeout=30
)


# Generated at 2022-06-24 08:51:10.627126
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    tgc = _TimeoutGarbageCollector()
    assert tgc._waiters == collections.deque()
    assert tgc._timeouts == 0

# Generated at 2022-06-24 08:51:13.585815
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    sem = Semaphore()
    try:
        with sem:
            pass
    except RuntimeError:
        pass
    else:
        Exception('method __enter__ of class Semaphore has no exception')


# Generated at 2022-06-24 08:51:14.605394
# Unit test for method clear of class Event
def test_Event_clear():
    Event.clear()



# Generated at 2022-06-24 08:51:16.467243
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    result = event.clear()
    assert result == None


# Generated at 2022-06-24 08:51:22.382041
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    '''Unit test for method __exit__ of class Lock

    Ensure that exceptions in the block are handled correctly.
    '''
    #from tornado.locks import Lock
    #from tornado import gen
    import pytest

    #failing = True

    #lock = Lock()

    #@gen.coroutine
    #def f():
    #    nonlocal failing
    #    with (yield lock):
    #        if failing:
    #            failing = False
    #            raise ZeroDivisionError()

    #    yield gen.sleep(0)

    #IOLoop.current().run_sync(f)

    #with pytest.raises(ZeroDivisionError, match=r'division'):
    #    IOLoop.current().run_sync(f)

    #class CustomError(Exception):
    #    pass

   

# Generated at 2022-06-24 08:51:23.046926
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    return True



# Generated at 2022-06-24 08:51:24.420706
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    print(Semaphore(2).release())

# Generated at 2022-06-24 08:51:33.952069
# Unit test for method notify of class Condition
def test_Condition_notify():
    '''
    Condition.notify()
    '''
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-24 08:51:37.967301
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    print(repr(Semaphore()))
    print(repr(Semaphore(5)))
    with futures.ThreadPoolExecutor(max_workers=5) as executor:
        semaphore = Semaphore()
        futures_q = deque([executor.submit(semaphore.acquire()) for _ in range(3)])
        print(repr(semaphore))


# Generated at 2022-06-24 08:51:47.126072
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from tornado import gen
    from tornado.locks import Semaphore, Condition
    from tornado.ioloop import IOLoop

    semaphore = Semaphore(1)
    condition = Condition()

    async def waiter():
        print("Waiting for semaphore")
        await semaphore.acquire()
        print("Done waiting")

    async def setter():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), setter()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-24 08:51:48.094678
# Unit test for method is_set of class Event
def test_Event_is_set():
    print(Event().is_set())


# Generated at 2022-06-24 08:51:49.766825
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    with lock:
        pass
    lock.release()

# Generated at 2022-06-24 08:51:53.733006
# Unit test for constructor of class Event
def test_Event():
    a = Event()
    assert a.is_set() == False
    a.set()
    assert a.is_set() == True
    a.clear()
    assert a.is_set() == False



# Generated at 2022-06-24 08:51:58.188901
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    cond = Condition()
    cond.notify_all()
    cond.wait()
    cond.notify()
    if cond.wait(timeout = 1):
        print('condition was notified')
    else:
        print('condition timeout')


# Generated at 2022-06-24 08:52:00.810518
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"
    c.wait()
    assert repr(c) == "<Condition waiters[1]>"


# Generated at 2022-06-24 08:52:01.415713
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    pass

# Generated at 2022-06-24 08:52:03.616085
# Unit test for method clear of class Event
def test_Event_clear():
    obj = Event()
    obj.clear()
    obj = Event()
    obj.clear()
    obj = Event()
    obj.clear()


# Generated at 2022-06-24 08:52:04.666122
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    print(type(lock))


# Generated at 2022-06-24 08:52:08.056148
# Unit test for method is_set of class Event
def test_Event_is_set():
    e = Event()
    assert not e.is_set()
    e.set()
    assert e.is_set()
    e.clear()
    assert not e.is_set()


# Generated at 2022-06-24 08:52:10.281062
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    obj = Event()
    print(obj)


# Generated at 2022-06-24 08:52:12.650328
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    assert event._value is False
    assert isinstance(event._waiters, set)


# Generated at 2022-06-24 08:52:18.263128
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    async def test_acquire():
        sem = Semaphore(2)
        with (await sem.acquire()):
            assert sem.acquire().done()
            assert sem.acquire().done()
            await sem.acquire()
        sem.release()
        assert len(sem._waiters) == 0
        assert sem._value == 2

    ioloop.IOLoop.current().run_sync(test_acquire)



# Generated at 2022-06-24 08:52:22.108842
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    instance = Semaphore()
    assert repr(instance) == "<Semaphore [unlocked,value:1]>"
    instance.acquire(timeout = None)
    assert repr(instance) == "<Semaphore [unlocked,value:0,waiters:1]>"
    instance.release()
    assert repr(instance) == "<Semaphore [unlocked,value:1]>"

# Generated at 2022-06-24 08:52:22.815335
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    pass

# Generated at 2022-06-24 08:52:26.867422
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    print(condition)
    print(type(condition))
    print(Condition.__bases__)
    print((lambda _: type(condition)))
if __name__ == "__main__":
    test_Condition___repr__()



# Generated at 2022-06-24 08:52:38.388668
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    #
    # Test the __exit__ method of the Semaphore class
    #
    s = Semaphore()

    # Test a normal case where the Semaphore is locked and released
    with s:
        pass

    # Test exception cases where the Semaphore is locked but the release is
    # never called
    def check_exception():
        with s:
            raise Exception("Hello")

    try:
        check_exception()
    except Exception as e:
        assert str(e) == "Hello"

    assert not s.is_released()

    try:
        check_exception()
    except Exception as e:
        assert str(e) == "Hello"

    assert not s.is_released()



# Generated at 2022-06-24 08:52:40.815264
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    obj = _ReleasingContextManager("")
    obj.__enter__()


# Generated at 2022-06-24 08:52:41.431458
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    pass

# Generated at 2022-06-24 08:52:42.905041
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    b = BoundedSemaphore(1)
    b.release()
    b.release()



# Generated at 2022-06-24 08:52:47.841241
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(3)
    print(sem._value)
    print(sem._initial_value)
    try:
        sem.release()
        sem.release()
        sem.release()
        sem.release()
    except ValueError:
        print("Semaphore released too many times")


# Generated at 2022-06-24 08:52:51.459514
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    semaphore = Semaphore(1)
    thread_id = semaphore._value
    assert(thread_id == 1)
    
    
    
    
    


# Generated at 2022-06-24 08:53:02.781775
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import time
    import threading
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()
    num_waiters = 0


    def waiter(i):
        print("I'll wait right here")
        global num_waiters
        num_waiters = num_waiters + 1
        condition.wait()
        print("I'm done waiting")


    def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")
        print("num_waiters = " + str(num_waiters))


    def runner():
        # Wait for waiter() and notifier() in parallel
        global num_waiters
        for i in range(num_waiters):
            waiter(i)
        notifier()

# Generated at 2022-06-24 08:53:04.287026
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.locks import _ReleasingContextManager

    for _ in range(1000):
        obj = _ReleasingContextManager(None)
        with obj:
            pass
test__ReleasingContextManager___enter__()



# Generated at 2022-06-24 08:53:06.187313
# Unit test for method is_set of class Event
def test_Event_is_set():
    # Create an event object
    test_event = Event()
    test_event.is_set()


# Generated at 2022-06-24 08:53:08.184961
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()

# Generated at 2022-06-24 08:53:09.614227
# Unit test for constructor of class Condition
def test_Condition():
    pass


# Generated at 2022-06-24 08:53:22.797406
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    sem = BoundedSemaphore(0)
    io_loop = IOLoop.current()

    def wait_sem():
        print('waiting sem')
        sem.acquire()
        io_loop.call_soon(sem.release)
        io_loop.stop()

    def release_sem():
        print('release sem')
        sem.release()

    def release_sem_twice():
        print('release sem twice')
        sem.release()
        sem.release()

    print('test1: release sem when sem is free. should print twice')
    wait_sem()
    release_sem()
    io_loop.start()

    print('test2: release twice when sem is free. should raise ValueError')
    wait_sem

# Generated at 2022-06-24 08:53:24.726706
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    print(condition)
