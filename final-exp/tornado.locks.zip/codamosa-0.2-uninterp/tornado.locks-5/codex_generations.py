

# Generated at 2022-06-18 10:13:00.694650
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))



# Generated at 2022-06-18 10:13:02.469175
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:13:06.280402
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False


# Generated at 2022-06-18 10:13:08.432453
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:13:15.101881
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:20.645836
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:29.266274
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    assert sem._value == 2
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5
    sem.release()
    assert sem._value == 6
    sem.release()
    assert sem._value == 7
    sem.release()
    assert sem._value == 8
    sem.release()
    assert sem._value == 9
    sem.release()
    assert sem._value == 10
    sem.release()
    assert sem._value == 11
    sem.release()
    assert sem._value == 12
    sem.release()
    assert sem._value == 13
    sem.release()
    assert sem._value == 14
    sem.release()
    assert sem._value == 15

# Generated at 2022-06-18 10:13:31.540823
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:13:36.399669
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        waiter()
        notifier()

    runner()


# Generated at 2022-06-18 10:13:44.448892
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:06.970208
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:14.496987
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:22.805748
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:33.812691
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release()
    lock.acquire()
    lock.release

# Generated at 2022-06-18 10:14:41.598194
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:43.518291
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:14:48.580640
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert lock.__aenter__() == None


# Generated at 2022-06-18 10:14:58.205697
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)
    condition.notify(21)

# Generated at 2022-06-18 10:15:05.316364
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.release())
    print(sem)
    print(sem.release())
    print(sem)
    print(sem.release())
    print(sem)


# Generated at 2022-06-18 10:15:13.160886
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:29.078421
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:36.527956
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)

# Generated at 2022-06-18 10:15:38.358188
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    assert sem.__aenter__() is None


# Generated at 2022-06-18 10:15:41.446626
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test for method __repr__ (of class Condition)
    # See if repr works
    c = Condition()
    assert repr(c) == "<Condition>"



# Generated at 2022-06-18 10:15:44.783524
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:15:56.952993
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
   

# Generated at 2022-06-18 10:16:08.929114
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__

# Generated at 2022-06-18 10:16:10.531636
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:16:13.428849
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:16:18.061140
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        print("ValueError")
    else:
        print("No ValueError")

# Generated at 2022-06-18 10:16:33.267921
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    assert sem.__aenter__() == None


# Generated at 2022-06-18 10:16:43.220435
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    assert sem.is_set() == True
    sem.release()
    assert sem.is_set() == True
    sem.release()
    assert sem.is_set() == True
    sem.release()
    assert sem.is_set() == True
    sem.acquire()
    assert sem.is_set() == False
    sem.acquire()
    assert sem.is_set() == False
    sem.acquire()
    assert sem.is_set() == False
    sem.release()
    assert sem.is_set() == False
    sem.release()
    assert sem.is_set() == False
    sem.release()
    assert sem.is_set() == True
    sem.acquire()
    assert sem.is_set() == False
    sem.ac

# Generated at 2022-06-18 10:16:44.977586
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore()
    async with sem:
        pass
    assert sem._value == 0


# Generated at 2022-06-18 10:16:46.421175
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem.acquire() == sem.__aenter__()


# Generated at 2022-06-18 10:16:50.254102
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:16:52.031732
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:16:54.625934
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    assert lock._block._value == 0


# Generated at 2022-06-18 10:17:03.818182
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:09.161044
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release()
    lock.__aenter__()
    lock.release

# Generated at 2022-06-18 10:17:12.963240
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:17:32.662766
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        print("Worker %d is done" % worker_id)
    async def runner():
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:35.126650
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:17:40.085420
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:45.355139
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:48.960822
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())
    event.wait()
    print(event.is_set())
#test_Event_wait()



# Generated at 2022-06-18 10:17:57.622387
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:59.090620
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:18:01.406803
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:18:11.037682
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))
    event.wait(timeout=datetime.timedelta(microseconds=1))
    event.wait(timeout=datetime.timedelta(milliseconds=1))
    event.wait(timeout=datetime.timedelta(minutes=1))
    event.wait(timeout=datetime.timedelta(hours=1))
    event.wait(timeout=datetime.timedelta(days=1))
    event.wait(timeout=datetime.timedelta(weeks=1))


# Generated at 2022-06-18 10:18:12.942605
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:18:26.706200
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:18:30.266759
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False


# Generated at 2022-06-18 10:18:32.067018
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    sem.__aenter__()
    assert sem._value == 1


# Generated at 2022-06-18 10:18:33.835787
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    sem.__aenter__()


# Generated at 2022-06-18 10:18:40.251982
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    io_loop = ioloop.IOLoop.current()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    io_loop.run_sync(runner)


# Generated at 2022-06-18 10:18:43.432392
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.__aexit__(None, None, None)

# Generated at 2022-06-18 10:18:49.840192
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:52.042716
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:18:53.760499
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.__aexit__()


# Generated at 2022-06-18 10:18:55.400257
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set()


# Generated at 2022-06-18 10:19:13.314164
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:20.280628
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    # Test the case when the counter is zero
    sem._value = 0
    waiter = Future()
    sem._waiters.append(waiter)
    assert sem.acquire() == waiter
    assert sem._value == 0
    assert sem._waiters == [waiter]
    # Test the case when the counter is positive
    sem._value = 1
    waiter = Future()
    sem._waiters.append(waiter)
    assert sem.acquire() == waiter
    assert sem._value == 0
    assert sem._waiters == []


# Generated at 2022-06-18 10:19:22.916612
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True

# Generated at 2022-06-18 10:19:24.245380
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:19:35.041787
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()

# Generated at 2022-06-18 10:19:36.835828
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:19:48.821245
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__

# Generated at 2022-06-18 10:19:56.570831
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import asyncio
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        print("Worker %d is done" % worker_id)
    async def runner():
        await asyncio.gather(*[worker(i) for i in range(3)])
    asyncio.run(runner())

# Generated at 2022-06-18 10:20:05.142247
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:14.306559
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
   

# Generated at 2022-06-18 10:20:29.376700
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:20:34.963297
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:37.594643
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:20:45.426186
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:49.128427
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert condition._waiters == collections.deque()
    assert condition._timeouts == 0
    assert condition.io_loop == ioloop.IOLoop.current()


# Generated at 2022-06-18 10:20:50.978604
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:20:58.536390
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:00.177233
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem.__aenter__() is None


# Generated at 2022-06-18 10:21:06.799196
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:09.707756
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:34.487241
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Test for method acquire(...) of class Semaphore
    sem = Semaphore(2)
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.ac

# Generated at 2022-06-18 10:21:39.137610
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert len(condition._waiters) == 0
    waiter = Future()
    condition._waiters.append(waiter)
    condition.notify_all()
    assert len(condition._waiters) == 0
    assert waiter.done()
    assert waiter.result() == True


# Generated at 2022-06-18 10:21:41.162062
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    assert sem.__aenter__() == None


# Generated at 2022-06-18 10:21:44.316378
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # Test that Semaphore.__aenter__() is a coroutine
    from tornado.locks import Semaphore
    sem = Semaphore()
    assert iscoroutinefunction(sem.__aenter__)
    assert iscoroutine(sem.__aenter__())


# Generated at 2022-06-18 10:21:46.136259
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:21:48.159050
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:21:50.223316
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:21:53.940821
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert condition._waiters == collections.deque()
    assert condition._timeouts == 0
    assert condition.io_loop == ioloop.IOLoop.current()
    assert repr(condition) == "<Condition>"



# Generated at 2022-06-18 10:21:55.818915
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:22:03.033296
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:22:21.228299
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    pass


# Generated at 2022-06-18 10:22:23.688927
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    async def f():
        async with lock:
            pass
    IOLoop.current().run_sync(f)


# Generated at 2022-06-18 10:22:26.207295
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"
    c.wait()
    assert repr(c) == "<Condition waiters[1]>"

# Generated at 2022-06-18 10:22:29.399200
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()
