

# Generated at 2022-06-18 10:13:19.726153
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__

# Generated at 2022-06-18 10:13:28.218415
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)

# Generated at 2022-06-18 10:13:34.541525
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:44.665847
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    sem.acquire()
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"

# Generated at 2022-06-18 10:13:56.188796
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_

# Generated at 2022-06-18 10:14:03.521782
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:11.817420
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:15.629775
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert condition._waiters == collections.deque()
    assert condition._timeouts == 0
    assert condition.io_loop == ioloop.IOLoop.current()
    assert condition.__repr__() == "<Condition waiters[0]>"


# Generated at 2022-06-18 10:14:17.181128
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()



# Generated at 2022-06-18 10:14:18.622855
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:14:40.320984
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:42.936879
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:14:44.737550
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:14:49.676601
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:57.302683
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:58.787836
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:15:07.097452
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:13.609966
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:15.246536
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    assert lock._block._value == 0


# Generated at 2022-06-18 10:15:24.235123
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:38.301970
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:15:39.563780
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:15:43.957106
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:46.120279
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:15:58.215984
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)
    condition.notify(21)

# Generated at 2022-06-18 10:15:59.406417
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    waiter = condition.wait()
    condition.notify_all()
    assert waiter.result() == True


# Generated at 2022-06-18 10:16:04.415712
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:09.324158
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))


# Generated at 2022-06-18 10:16:12.298608
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:16:21.509047
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Test case 1
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:49.079192
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert lock.__aenter__() == None


# Generated at 2022-06-18 10:17:00.857617
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem._value == 2
    assert sem._waiters == []
    sem.__aenter__()
    assert sem._value == 1
    assert sem._waiters == []
    sem.__aenter__()
    assert sem._value == 0
    assert sem._waiters == []
    sem.__aenter__()
    assert sem._value == 0
    assert len(sem._waiters) == 1
    assert sem._waiters[0].done() == False
    sem.release()
    assert sem._value == 1
    assert sem._waiters == []
    sem.release()
    assert sem._value == 2
    assert sem._waiters == []
    sem.release()
    assert sem._value == 3
    assert sem._waiters == []
    sem.__aenter__()

# Generated at 2022-06-18 10:17:03.725249
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:17:06.770235
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import asyncio
    from tornado.locks import Semaphore
    sem = Semaphore(1)
    async def test():
        async with sem:
            print('test')
    asyncio.run(test())

# Generated at 2022-06-18 10:17:15.186975
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)

# Generated at 2022-06-18 10:17:17.284725
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()


# Generated at 2022-06-18 10:17:19.070693
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:17:22.621890
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado.locks import Lock
    lock = Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()


# Generated at 2022-06-18 10:17:23.862719
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:17:28.462082
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        pass
    else:
        raise AssertionError("BoundedSemaphore.release() failed")


# Generated at 2022-06-18 10:18:03.233141
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:11.618649
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:16.793072
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:18.357722
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:18:20.618529
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    assert lock._block._value == 1


# Generated at 2022-06-18 10:18:21.958896
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:18:29.636823
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:34.796485
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:38.440777
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.acquire()
    lock.release()
    lock.__aenter__()
    lock.__aexit__(None, None, None)
    lock.__enter__()
    lock.__exit__(None, None, None)


# Generated at 2022-06-18 10:18:41.033768
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:19:09.830433
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:19:14.481073
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    def runner():
        waiter()
        notifier()
    runner()


# Generated at 2022-06-18 10:19:19.766735
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:22.259939
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    sem.__aenter__()


# Generated at 2022-06-18 10:19:24.335089
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()
    return


# Generated at 2022-06-18 10:19:33.003423
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:37.375638
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bs = BoundedSemaphore(value=1)
    bs.release()
    try:
        bs.release()
    except ValueError:
        print("test_BoundedSemaphore_release passed")
    else:
        print("test_BoundedSemaphore_release failed")


# Generated at 2022-06-18 10:19:38.719531
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert lock.__aenter__() is None


# Generated at 2022-06-18 10:19:42.552129
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"

# Generated at 2022-06-18 10:19:49.757012
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:17.641308
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert condition._waiters == collections.deque()
    assert condition._timeouts == 0
    assert condition.io_loop == ioloop.IOLoop.current()


# Generated at 2022-06-18 10:20:21.221120
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    assert sem._value == 2
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5


# Generated at 2022-06-18 10:20:23.031867
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:20:30.221056
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:31.982532
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.release()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:20:39.610703
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:47.413296
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:49.439294
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:20:51.316325
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()


# Generated at 2022-06-18 10:20:55.232603
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    assert sem._value == 2
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5


# Generated at 2022-06-18 10:21:25.700283
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    import asyncio
    from tornado.locks import Semaphore
    sem = Semaphore()
    async def test():
        async with sem:
            print('hello')
    asyncio.run(test())
    print('test_Semaphore___aexit__ passed')


# Generated at 2022-06-18 10:21:33.583736
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:36.821129
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.acquire()
    lock.release()
    lock.__aenter__()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:21:38.278165
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"

# Generated at 2022-06-18 10:21:41.001812
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"

# Generated at 2022-06-18 10:21:43.283696
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:21:46.719695
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        waiter()
        notifier()

    runner()


# Generated at 2022-06-18 10:21:50.225994
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    from tornado.locks import Semaphore
    sem = Semaphore()
    async def test():
        async with sem:
            pass
    ioloop.IOLoop.current().run_sync(test)
    assert sem._value == 1


# Generated at 2022-06-18 10:21:52.406676
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:21:59.563865
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)
