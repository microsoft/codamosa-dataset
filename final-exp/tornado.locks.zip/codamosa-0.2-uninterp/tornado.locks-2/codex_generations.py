

# Generated at 2022-06-18 10:13:06.551222
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado.locks import Lock
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock

# Generated at 2022-06-18 10:13:15.140561
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())


# Generated at 2022-06-18 10:13:20.771703
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:26.709877
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:29.012648
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"
    c.wait()
    assert repr(c) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:13:30.917932
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    print(sem)
    print(sem.acquire())
    print(sem)

# Generated at 2022-06-18 10:13:38.255274
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:44.057490
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")
    def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")
    def runner():
        # Wait for waiter() and notifier() in parallel
        gen.multi([waiter(), notifier()])
    runner()


# Generated at 2022-06-18 10:13:46.747909
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:13:50.108864
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:14:05.237119
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:14:08.274795
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem._value == 2
    sem.__aenter__()
    assert sem._value == 1


# Generated at 2022-06-18 10:14:11.396929
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(1)
    async def test():
        async with sem:
            pass
    ioloop.IOLoop.current().run_sync(test)
    assert sem._value == 1



# Generated at 2022-06-18 10:14:14.418214
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    # Wait for waiter() and notifier() in parallel
    # await gen.multi([waiter(), notifier()])
    # waiter()
    # notifier()
    condition.notify()


# Generated at 2022-06-18 10:14:15.554346
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()



# Generated at 2022-06-18 10:14:18.203633
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    sem.__aenter__()
    assert sem._value == 1


# Generated at 2022-06-18 10:14:20.535838
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem.__aenter__() == None


# Generated at 2022-06-18 10:14:22.294374
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)



# Generated at 2022-06-18 10:14:31.071447
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=None)
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))
    event.wait(timeout=datetime.timedelta(microseconds=1))
    event.wait(timeout=datetime.timedelta(days=1))
    event.wait(timeout=datetime.timedelta(days=1, seconds=1))
    event.wait(timeout=datetime.timedelta(days=1, seconds=1, microseconds=1))



# Generated at 2022-06-18 10:14:33.253942
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:14:52.031137
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import asyncio
    import tornado.locks
    import tornado.testing
    import tornado.platform.asyncio
    import unittest
    import unittest.mock

    class TestSemaphore(unittest.TestCase):
        def setUp(self):
            self.loop = asyncio.new_event_loop()
            asyncio.set_event_loop(None)
            tornado.platform.asyncio.AsyncIOMainLoop().install()
            self.addCleanup(self.loop.close)

        def test_Semaphore___aenter__(self):
            # __aenter__() is a coroutine function
            self.assertTrue(
                asyncio.iscoroutinefunction(tornado.locks.Semaphore.__aenter__)
            )

            # Make sure that __aenter__() is non

# Generated at 2022-06-18 10:15:00.349586
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__

# Generated at 2022-06-18 10:15:07.403924
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)
    # Unit test for method __aexit__ of class Semaphore

# Generated at 2022-06-18 10:15:09.316246
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    with pytest.raises(RuntimeError):
        lock.__aenter__()

# Generated at 2022-06-18 10:15:12.178679
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:21.774910
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:29.812937
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:38.720449
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    import asyncio
    import time
    import random
    import threading
    import concurrent.futures
    import tornado.locks
    import tornado.ioloop
    import tornado.platform.asyncio
    tornado.platform.asyncio.AsyncIOMainLoop().install()
    loop = asyncio.get_event_loop()
    sem = tornado.locks.Semaphore(2)
    def worker(worker_id):
        loop.run_until_complete(sem.acquire())
        try:
            print("Worker %d is working" % worker_id)
            time.sleep(random.randint(1, 3))
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

# Generated at 2022-06-18 10:15:47.301517
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:49.233929
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert len(condition._waiters) == 0


# Generated at 2022-06-18 10:16:08.166795
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None

# Generated at 2022-06-18 10:16:10.162567
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    assert lock.__aenter__() == None


# Generated at 2022-06-18 10:16:12.600221
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:16:15.643349
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:16:19.203982
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:16:28.298840
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
   

# Generated at 2022-06-18 10:16:32.427871
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"

# Generated at 2022-06-18 10:16:40.255676
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:44.634812
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    # Wait for waiter() and notifier() in parallel
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    async def runner():
        await gen.multi([waiter(), notifier()])
    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:45.822270
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:17:00.769353
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:17:04.001165
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None


# Generated at 2022-06-18 10:17:09.438009
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:18.721969
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock

# Generated at 2022-06-18 10:17:20.513024
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:17:22.868335
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:17:30.793967
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:32.169758
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:17:33.923465
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:17:37.318084
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters = [1, 2, 3]
    assert repr(condition) == "<Condition waiters[3]>"


# Generated at 2022-06-18 10:17:52.720717
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert len(sem._waiters) == 0


# Generated at 2022-06-18 10:17:55.487664
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:17:58.032271
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()
    condition.wait()


# Generated at 2022-06-18 10:18:00.635787
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert condition._waiters == collections.deque()
    assert condition._timeouts == 0


# Generated at 2022-06-18 10:18:09.328627
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:11.371126
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()

# Generated at 2022-06-18 10:18:20.835394
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)
    condition.notify(21)

# Generated at 2022-06-18 10:18:22.884527
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:18:30.515637
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:38.698393
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    condition.notify(3)
    condition.notify()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_

# Generated at 2022-06-18 10:18:53.898547
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:18:55.176736
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()

# Generated at 2022-06-18 10:19:05.675760
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
   

# Generated at 2022-06-18 10:19:08.466806
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        pass
    else:
        raise Exception("BoundedSemaphore.release() should raise ValueError")

test_BoundedSemaphore_release()



# Generated at 2022-06-18 10:19:18.443117
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.release()
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.release()
   

# Generated at 2022-06-18 10:19:20.020444
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()


# Generated at 2022-06-18 10:19:23.307060
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:19:31.475075
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)
    # Join all workers.
    async def runner():
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:33.689055
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.acquire()
    lock.release()
    lock.__aenter__()


# Generated at 2022-06-18 10:19:35.668825
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:19:51.231263
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:20:01.230282
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore

    sem = Semaphore(2)

    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:10.690785
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:11.965190
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:20:16.326792
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)



# Generated at 2022-06-18 10:20:26.834446
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    print(sem)
    print(sem._value)
    print(sem._waiters)
    print(sem.acquire())
    print(sem._value)
    print(sem._waiters)
    print(sem.acquire())
    print(sem._value)
    print(sem._waiters)
    print(sem.acquire())
    print(sem._value)
    print(sem._waiters)
    print(sem.acquire())
    print(sem._value)
    print(sem._waiters)
    print(sem.acquire())
    print(sem._value)
    print(sem._waiters)
    print(sem.acquire())
    print(sem._value)
    print(sem._waiters)
    print(sem.acquire())
   

# Generated at 2022-06-18 10:20:29.237567
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore()
    async def test():
        async with sem:
            pass
    ioloop.IOLoop.current().run_sync(test)
    assert sem._value == 1


# Generated at 2022-06-18 10:20:39.465363
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
   

# Generated at 2022-06-18 10:20:42.277204
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:20:50.088297
# Unit test for method wait of class Condition
def test_Condition_wait():
    import asyncio
    from tornado.locks import Condition
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await asyncio.gather(waiter(), notifier())
    asyncio.run(runner())


# Generated at 2022-06-18 10:21:12.311528
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:17.102585
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:27.710036
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    print(sem)
    print(sem._value)
    print(sem._waiters)
    sem.release()
    print(sem)
    print(sem._value)
    print(sem._waiters)
    sem.acquire()
    print(sem)
    print(sem._value)
    print(sem._waiters)
    sem.acquire()
    print(sem)
    print(sem._value)
    print(sem._waiters)
    sem.acquire()
    print(sem)
    print(sem._value)
    print(sem._waiters)
    sem.release()
    print(sem)
    print(sem._value)
    print(sem._waiters)
    sem.release()
    print(sem)

# Generated at 2022-06-18 10:21:31.375823
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))


# Generated at 2022-06-18 10:21:34.439366
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:21:35.928348
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:21:39.591457
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    print(condition)
    print(condition._waiters)
    print(condition._timeouts)
    condition.notify_all()
    print(condition)
    print(condition._waiters)
    print(condition._timeouts)


# Generated at 2022-06-18 10:21:44.046654
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:46.132416
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    with pytest.raises(RuntimeError):
        sem.__aenter__()

# Generated at 2022-06-18 10:21:55.415628
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_

# Generated at 2022-06-18 10:22:19.685362
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:22:21.982377
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:22:28.900484
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)
