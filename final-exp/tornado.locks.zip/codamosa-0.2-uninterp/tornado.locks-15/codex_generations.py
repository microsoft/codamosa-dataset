

# Generated at 2022-06-18 10:12:55.052936
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    assert lock._block._value == 0


# Generated at 2022-06-18 10:13:03.485122
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()

# Generated at 2022-06-18 10:13:06.440665
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    assert condition.notify() == None
    assert condition.notify(1) == None
    assert condition.notify_all() == None


# Generated at 2022-06-18 10:13:07.914559
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()

# Generated at 2022-06-18 10:13:13.703785
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:15.214743
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:13:22.891251
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:28.750235
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:31.296545
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:13:37.972865
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:54.902991
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()

# Generated at 2022-06-18 10:14:01.819947
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        print("Worker %d is done" % worker_id)
    async def runner():
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:09.472058
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:10.983360
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:14:16.656743
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:20.273330
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert len(condition._waiters) == 0
    assert condition._timeouts == 0
    assert condition.io_loop == ioloop.IOLoop.current()


# Generated at 2022-06-18 10:14:21.681040
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()

# Generated at 2022-06-18 10:14:23.964743
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:14:27.685291
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:14:29.469777
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()


# Generated at 2022-06-18 10:14:44.622671
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:14:46.469635
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:14:47.911115
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:14:49.267725
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:14:58.766854
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bs = BoundedSemaphore(value=1)
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    bs.release()
    b

# Generated at 2022-06-18 10:15:01.941711
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:15:04.597418
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:15:07.602999
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    sem.release()
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:15:16.145725
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_

# Generated at 2022-06-18 10:15:27.112592
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)

# Generated at 2022-06-18 10:16:06.224899
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None
    assert lock.__aexit__(None, None, None) is None

# Generated at 2022-06-18 10:16:07.901446
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:16:20.708745
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:16:23.452595
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:16:24.811680
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:16:26.871457
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:16:30.051314
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:16:32.810722
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:16:42.836402
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore(2)
    print(sem)
    print(repr(sem))
    print(str(sem))
    print(sem.__repr__())
    print(sem.__str__())
    print(sem.__format__(''))
    print(sem.__format__('s'))
    print(sem.__format__('r'))
    print(sem.__format__('a'))
    print(sem.__format__('b'))
    print(sem.__format__('c'))
    print(sem.__format__('d'))
    print(sem.__format__('e'))
    print(sem.__format__('f'))
    print(sem.__format__('g'))
    print(sem.__format__('h'))

# Generated at 2022-06-18 10:16:44.210457
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(n=1)


# Generated at 2022-06-18 10:17:13.366385
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    assert condition.notify_all() == None


# Generated at 2022-06-18 10:17:16.918224
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        pass
    else:
        assert False, "Should raise ValueError"


# Generated at 2022-06-18 10:17:23.121139
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import asyncio
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        print("Worker %d is done" % worker_id)
    async def runner():
        await asyncio.gather(*[worker(i) for i in range(3)])
    asyncio.run(runner())

# Generated at 2022-06-18 10:17:24.856351
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:17:32.963354
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:39.371555
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:45.087222
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:46.637376
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set()


# Generated at 2022-06-18 10:17:53.152309
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:04.760440
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()

# Generated at 2022-06-18 10:18:33.822709
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:18:40.334190
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:44.493592
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert condition._waiters == collections.deque()
    assert condition._timeouts == 0
    assert condition.io_loop == ioloop.IOLoop.current()



# Generated at 2022-06-18 10:18:46.958347
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:18:54.564348
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:02.689762
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:07.720705
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:10.428237
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    sem.__aenter__()
    assert sem._value == 1


# Generated at 2022-06-18 10:19:12.837588
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:19:15.394755
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:19:45.192615
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:19:51.464684
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()
    sem.release()
    assert sem._value == 4
    assert sem._waiters == deque()
    sem.release()
    assert sem._value == 5
    assert sem._waiters == deque()
    sem.release()
    assert sem._value == 6
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:19:56.871864
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert len(condition._waiters) == 0
    waiter = Future()
    condition._waiters.append(waiter)
    condition.notify_all()
    assert len(condition._waiters) == 0
    assert waiter.done()
    assert waiter.result() == True


# Generated at 2022-06-18 10:20:06.618307
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:17.052862
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem._value == 2
    assert sem._waiters == []
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set

# Generated at 2022-06-18 10:20:19.695516
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    sem.__aenter__()
    assert sem._value == 1


# Generated at 2022-06-18 10:20:27.790140
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:30.179314
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:20:35.479162
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore(2)
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"


# Generated at 2022-06-18 10:20:39.430460
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError")


# Generated at 2022-06-18 10:21:09.842370
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    sem.__aenter__()


# Generated at 2022-06-18 10:21:12.255970
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"
    c.wait()
    assert repr(c) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:21:18.544387
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()
    condition.notify_all()

# Generated at 2022-06-18 10:21:20.293807
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:21:23.437639
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(1)
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:21:35.198464
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    import asyncio
    import time
    import random
    import threading
    import concurrent.futures
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado.platform.asyncio import AsyncIOMainLoop
    AsyncIOMainLoop().install()
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_

# Generated at 2022-06-18 10:21:39.722765
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    def waiter():
        print("Waiting for event")
        event.wait()
        print("Not waiting this time")
        event.wait()
        print("Done")
    def setter():
        print("About to set the event")
        event.set()
    waiter()
    setter()


# Generated at 2022-06-18 10:21:45.699220
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:49.559259
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.wait()
    assert event.is_set() == True


# Generated at 2022-06-18 10:21:51.477888
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(n=1)
    condition.notify_all()


# Generated at 2022-06-18 10:22:23.985518
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:22:25.949704
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:22:34.023080
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem._value == 2
    assert sem._waiters == deque()
    assert sem.acquire() == None
    assert sem._value == 1
    assert sem._waiters == deque()
    assert sem.acquire() == None
    assert sem._value == 0
    assert sem._waiters == deque()
    assert sem.acquire() == None
    assert sem._value == -1
    assert sem._waiters == deque()
    assert sem.acquire() == None
    assert sem._value == -2
    assert sem._waiters == deque()
    assert sem.acquire() == None
    assert sem._value == -3
    assert sem._waiters == deque()
    assert sem.acquire() == None
    assert sem._value == -4
    assert sem