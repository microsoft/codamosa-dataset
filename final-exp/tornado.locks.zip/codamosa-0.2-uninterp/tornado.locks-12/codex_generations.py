

# Generated at 2022-06-18 10:12:55.671950
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    assert lock._block._value == 0


# Generated at 2022-06-18 10:13:04.178548
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
   

# Generated at 2022-06-18 10:13:07.208712
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore()
    async def test():
        async with sem:
            pass
    ioloop.IOLoop.current().run_sync(test)

# Generated at 2022-06-18 10:13:09.331561
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:13:10.840220
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:13:13.045642
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:13:16.068508
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    # Test the method __repr__ of class Semaphore
    # Create an instance of Semaphore
    sem = Semaphore()
    # Test the method __repr__ of class Semaphore
    assert repr(sem) == "<Semaphore unlocked,value:1>"

# Generated at 2022-06-18 10:13:19.611285
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    assert sem._value == 2
    sem.__aenter__()
    assert sem._value == 1
    sem.__aenter__()
    assert sem._value == 0
    sem.__aenter__()
    assert sem._value == 0


# Generated at 2022-06-18 10:13:22.175008
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:13:24.180966
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(1)
    assert sem.__aenter__() is None
    assert sem.__aenter__() is None


# Generated at 2022-06-18 10:13:40.837593
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:42.460412
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:13:44.492870
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:13:53.366591
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:04.632548
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem._value == 2
    assert sem._waiters == deque()
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False
    assert sem.is_set() == False

# Generated at 2022-06-18 10:14:08.009728
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:14:14.034246
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:16.661863
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:14:19.216996
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:14:28.147362
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:39.781288
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()
    condition.wait()


# Generated at 2022-06-18 10:14:45.034319
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)
    # Join all workers.
    asyncio.run(gen.multi([worker(i) for i in range(3)]))


# Generated at 2022-06-18 10:14:49.908055
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:14:53.112861
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:15:04.158700
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
   

# Generated at 2022-06-18 10:15:11.036155
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:15.066184
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    print(c)
    c.wait()
    print(c)
    c.notify()
    print(c)


# Generated at 2022-06-18 10:15:18.009964
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem.__aenter__() == None


# Generated at 2022-06-18 10:15:20.894613
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == '<Condition>'
    c.wait()
    assert repr(c) == '<Condition waiters[1]>'


# Generated at 2022-06-18 10:15:24.485424
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:40.042332
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:42.246853
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado.locks import Lock
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:15:49.923998
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore(2)
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"


# Generated at 2022-06-18 10:16:02.480177
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
   

# Generated at 2022-06-18 10:16:05.281497
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    assert sem.__aenter__() is None


# Generated at 2022-06-18 10:16:17.956232
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [unlocked,value:0]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [unlocked,value:0]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"


# Generated at 2022-06-18 10:16:27.897888
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)
    assert sem.acquire() == True
    assert sem.acquire() == False
    sem.release()
    assert sem.acquire() == True
    assert sem.acquire() == False
    sem.release()
    assert sem.acquire() == True
    assert sem.acquire() == False
    sem.release()
    assert sem.acquire() == True
    assert sem.acquire() == False
    sem.release()
    assert sem.acquire() == True
    assert sem.acquire() == False
    sem.release()
    assert sem.acquire() == True
    assert sem.acquire() == False
    sem.release()
    assert sem.acquire() == True
    assert sem.acquire() == False
    sem.release()
    assert sem.acquire()

# Generated at 2022-06-18 10:16:37.225913
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:39.255842
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()
    condition.wait()


# Generated at 2022-06-18 10:16:40.653438
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:16:52.212892
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()

# Generated at 2022-06-18 10:16:55.711096
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:17:06.446747
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
   

# Generated at 2022-06-18 10:17:14.627197
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:20.833941
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:22.827220
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:17:25.745090
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:17:27.923729
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:17:35.032817
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")
    def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")
    def runner():
        # Wait for waiter() and notifier() in parallel
        gen.multi([waiter(), notifier()])
    runner()


# Generated at 2022-06-18 10:17:36.853680
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set()


# Generated at 2022-06-18 10:17:48.501844
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:17:51.547363
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:17:58.860046
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    # Wait for waiter() and notifier() in parallel
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")
    async def runner():
        await gen.multi([waiter(), notifier()])
    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:00.680052
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert len(condition._waiters) == 0


# Generated at 2022-06-18 10:18:07.302252
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        gen.multi([waiter(), notifier()])

    runner()


# Generated at 2022-06-18 10:18:12.332994
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test for method __repr__ of class Condition
    # Returns:
    #   string representation of the object
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition.wait()
    assert repr(condition) == "<Condition waiters[1]>"
    condition.notify()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:18:19.235002
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore(2)
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"


# Generated at 2022-06-18 10:18:25.716945
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:27.233589
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    event.wait()


# Generated at 2022-06-18 10:18:33.950693
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:52.034749
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:02.961689
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)
    # Unit test for method __aenter__ of class Semaphore
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)
    # Unit test for method __aenter__ of class Semaphore

# Generated at 2022-06-18 10:19:05.712322
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:19:06.685826
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:19:07.891931
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)



# Generated at 2022-06-18 10:19:09.834371
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()


# Generated at 2022-06-18 10:19:19.073314
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None

# Generated at 2022-06-18 10:19:30.011503
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.is_set()
    assert event.wait() is None
    event.clear()
    assert not event.is_set()
    assert event.wait() is None
    event.clear()
    assert not event.is_set()
    assert event.wait(timeout=datetime.timedelta(seconds=1)) is None
    event.clear()
    assert not event.is_set()
    assert event.wait(timeout=datetime.timedelta(seconds=1)) is None
    event.clear()
    assert not event.is_set()
    assert event.wait(timeout=datetime.timedelta(seconds=1)) is None
    event.clear()
    assert not event.is_set()

# Generated at 2022-06-18 10:19:40.182994
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:19:51.617292
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)
    condition.notify(21)

# Generated at 2022-06-18 10:20:21.363988
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None

# Generated at 2022-06-18 10:20:29.459313
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:34.445998
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)
    return worker

# Generated at 2022-06-18 10:20:45.350603
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem._value == 2
    assert sem._waiters == deque()
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True
    assert sem.is_set() == True

# Generated at 2022-06-18 10:20:47.370329
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:20:55.107042
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:56.722526
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    assert lock._block._value == 0


# Generated at 2022-06-18 10:21:06.252939
# Unit test for method wait of class Condition
def test_Condition_wait():
    import asyncio
    import time
    from tornado.locks import Condition

    async def waiter(condition: Condition, timeout: Optional[Union[float, datetime.timedelta]] = None) -> None:
        print("I'll wait right here")
        await condition.wait(timeout)
        print("I'm done waiting")

    async def notifier(condition: Condition) -> None:
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner() -> None:
        # Wait for waiter() and notifier() in parallel
        condition = Condition()
        await asyncio.gather(waiter(condition), notifier(condition))

    asyncio.run(runner())
    time.sleep(1)


# Generated at 2022-06-18 10:21:08.680763
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    assert repr(c) == "<Condition>"
    c.wait()
    assert repr(c) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:21:10.800596
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() == None


# Generated at 2022-06-18 10:21:38.135184
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:44.132816
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:46.263094
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    sem.__aenter__()
    assert sem._value == 1


# Generated at 2022-06-18 10:21:48.998147
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    sem.__aexit__(None, None, None)
    assert sem._value == 3


# Generated at 2022-06-18 10:21:51.658277
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:21:58.864163
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:22:00.979436
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:22:09.666821
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_

# Generated at 2022-06-18 10:22:11.030611
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem.__aenter__() == None


# Generated at 2022-06-18 10:22:13.266595
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()
