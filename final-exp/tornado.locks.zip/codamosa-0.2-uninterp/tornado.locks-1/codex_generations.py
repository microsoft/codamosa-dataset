

# Generated at 2022-06-18 10:13:12.810194
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:13:20.332879
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()

# Generated at 2022-06-18 10:13:26.836210
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    from tornado.testing import AsyncTestCase, gen_test

    class TestSemaphore(AsyncTestCase):
        @gen_test
        async def test_acquire(self):
            sem = Semaphore(value=1)
            await sem.acquire()
            self.assertEqual(sem._value, 0)
            sem.release()
            self.assertEqual(sem._value, 1)

    IOLoop.current().run_sync(TestSemaphore().test_acquire)


# Generated at 2022-06-18 10:13:32.851441
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:35.371928
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:13:41.680985
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:43.922841
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:13:46.611954
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:13:48.658985
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:14:00.542930
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:14:17.180888
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert len(condition._waiters) == 0


# Generated at 2022-06-18 10:14:28.506809
# Unit test for method release of class BoundedSemaphore

# Generated at 2022-06-18 10:14:31.748389
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=None)
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))



# Generated at 2022-06-18 10:14:35.659673
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    # test if the semaphore is locked
    assert sem.acquire() == False
    # test if the semaphore is unlocked
    assert sem.acquire() == True


# Generated at 2022-06-18 10:14:38.662155
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()

# Generated at 2022-06-18 10:14:41.341558
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:14:47.223119
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:49.471981
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:14:51.209145
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:14:54.052897
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))


# Generated at 2022-06-18 10:15:09.848766
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))


# Generated at 2022-06-18 10:15:21.463528
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:15:24.861123
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:15:30.908125
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:33.256456
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))



# Generated at 2022-06-18 10:15:34.994905
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:15:36.572120
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert len(condition._waiters) == 0



# Generated at 2022-06-18 10:15:39.678294
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()


# Generated at 2022-06-18 10:15:47.783034
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.gen import coroutine
    import unittest
    import asyncio
    import time
    import threading

    class TestSemaphore(AsyncTestCase):
        def setUp(self):
            super().setUp()
            self.sem = Semaphore(1)

        @gen_test
        async def test_Semaphore___aexit__(self):
            async with self.sem:
                pass

    unittest.main()


# Generated at 2022-06-18 10:15:56.899519
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:13.235362
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:16:15.441082
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:16:26.606040
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)
    condition.notify(21)

# Generated at 2022-06-18 10:16:37.987666
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)

# Generated at 2022-06-18 10:16:40.434837
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))



# Generated at 2022-06-18 10:16:42.268388
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()


# Generated at 2022-06-18 10:16:47.543817
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:51.013872
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()

# Generated at 2022-06-18 10:16:52.725144
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:17:04.977166
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
    lock.release()
   

# Generated at 2022-06-18 10:17:21.773423
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:17:23.427497
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:17:29.249069
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)



# Generated at 2022-06-18 10:17:39.829659
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem.acquire() == _ReleasingContextManager(sem)

# Generated at 2022-06-18 10:17:41.417227
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()


# Generated at 2022-06-18 10:17:47.848978
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:58.724589
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None

# Generated at 2022-06-18 10:18:02.689823
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        pass
    else:
        raise AssertionError("Expected ValueError")


# Generated at 2022-06-18 10:18:05.278375
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:18:07.623037
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Lock.__aenter__() -> None
    # Acquire the lock.
    pass


# Generated at 2022-06-18 10:18:30.636824
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:32.473146
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")
    waiter()
    condition.notify_all()


# Generated at 2022-06-18 10:18:35.530113
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        print("ValueError")
    else:
        print("No ValueError")


# Generated at 2022-06-18 10:18:39.449227
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    assert sem._value == 2
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5
    sem.release()
    assert sem._value == 6


# Generated at 2022-06-18 10:18:50.168593
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)

# Generated at 2022-06-18 10:18:58.481710
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:01.343304
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    sem.__aexit__(None, None, None)
    assert sem._value == 3



# Generated at 2022-06-18 10:19:03.586924
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:19:05.092137
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()


# Generated at 2022-06-18 10:19:07.918422
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    print("notify_all")


# Generated at 2022-06-18 10:19:38.335372
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:19:40.046909
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:19:42.445183
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:19:44.942973
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:19:47.211844
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    assert condition.notify_all() is None


# Generated at 2022-06-18 10:19:50.669429
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    assert sem._value == 2
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5


# Generated at 2022-06-18 10:19:56.785517
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    def waiter():
        print("Waiting for event")
        event.wait()
        print("Not waiting this time")
        event.wait()
        print("Done")

    def setter():
        print("About to set the event")
        event.set()

    waiter()
    setter()


# Generated at 2022-06-18 10:20:05.875011
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore(2)
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"


# Generated at 2022-06-18 10:20:13.163757
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:15.672613
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:21:23.568695
# Unit test for method __aenter__ of class Semaphore

# Generated at 2022-06-18 10:21:33.583476
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.acquire()
    lock.release()
    assert lock._block._value == 0
    lock.release()
    assert lock._block._value == 1
    lock.acquire()
    lock.acquire()
    lock.acquire()
    lock.release()
    assert lock._block._value == 0
    lock.release()
    assert lock._block._value == 0
    lock.release()
    assert lock._block._value == 1


# Generated at 2022-06-18 10:21:37.555785
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore

    sem = Semaphore(2)

    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:38.746886
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:21:40.417308
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() is None


# Generated at 2022-06-18 10:21:46.152808
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:50.327864
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    assert condition._waiters == collections.deque()
    waiter = Future()
    condition._waiters.append(waiter)
    condition.notify_all()
    assert waiter.done()
    assert waiter.result() == True
    assert condition._waiters == collections.deque()


# Generated at 2022-06-18 10:21:59.799778
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:22:03.034419
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False


# Generated at 2022-06-18 10:22:06.017501
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)

