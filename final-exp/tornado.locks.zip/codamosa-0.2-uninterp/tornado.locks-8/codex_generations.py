

# Generated at 2022-06-18 10:12:43.878400
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)
    assert sem.acquire() == _ReleasingContextManager(sem)


# Generated at 2022-06-18 10:12:45.830579
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()


# Generated at 2022-06-18 10:12:47.274593
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem.__aenter__() == None


# Generated at 2022-06-18 10:12:49.080278
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    assert lock._block._value == 0


# Generated at 2022-06-18 10:12:50.770475
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:12:56.977984
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:00.473955
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    # Test the method __aexit__ of class Semaphore
    # Create an instance of class Semaphore
    sem = Semaphore()
    # Test the method __aexit__ of class Semaphore
    # Assert the result
    assert sem.__aexit__() == None

# Generated at 2022-06-18 10:13:02.544795
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:13:09.180788
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:14.639797
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:24.053190
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        async with lock:
            # Do something holding the lock.
            pass
        # Now the lock is released.
    f()

# Generated at 2022-06-18 10:13:32.731530
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)
    print(sem.acquire())
    print(sem)

# Generated at 2022-06-18 10:13:34.582110
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:13:37.360356
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:13:41.024220
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5


# Generated at 2022-06-18 10:13:42.634833
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:13:45.702607
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.locks import Condition
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(1)
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:13:53.185654
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:56.478273
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:14:04.978587
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:18.668856
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:26.644704
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:28.928610
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    with pytest.raises(RuntimeError):
        sem.__aenter__()


# Generated at 2022-06-18 10:14:32.180439
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # Test case data
    semaphore = Semaphore()
    # Perform the test
    semaphore.release()
    # Verify the result
    assert True # TODO: implement your test here



# Generated at 2022-06-18 10:14:35.303929
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert condition._waiters == collections.deque()
    assert condition._timeouts == 0


# Generated at 2022-06-18 10:14:42.476701
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:49.156589
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    def runner():
        # Wait for waiter() and notifier() in parallel
        waiter()
        notifier()
    runner()


# Generated at 2022-06-18 10:14:54.565499
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait(timeout=datetime.timedelta(seconds=1)) == None
    event.clear()
    assert event.wait(timeout=datetime.timedelta(seconds=1)) == None


# Generated at 2022-06-18 10:14:56.123366
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()


# Generated at 2022-06-18 10:15:04.889225
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore(2)
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.acquire()
    assert repr(sem) == "<Semaphore [locked]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:1]>"
    sem.release()
    assert repr(sem) == "<Semaphore [unlocked,value:2]>"


# Generated at 2022-06-18 10:15:12.964951
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:15:16.067742
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:15:18.009876
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()


# Generated at 2022-06-18 10:15:20.561323
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None


# Generated at 2022-06-18 10:15:25.102774
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.wait()
    assert event.is_set() == True


# Generated at 2022-06-18 10:15:34.783442
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()
    assert event.wait() == None
    event.clear()
    assert event.wait() == None
    event.set()

# Generated at 2022-06-18 10:15:37.712159
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.locks import Condition
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(1)
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:15:39.563207
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition.wait()
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:15:40.747464
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:15:43.303876
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:16:00.085702
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:01.819977
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    lock = locks.Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:16:04.690302
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:16:14.632437
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:18.166370
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    import asyncio
    from tornado.locks import Semaphore
    sem = Semaphore(1)
    async def f():
        async with sem:
            pass
    asyncio.run(f())


# Generated at 2022-06-18 10:16:21.332811
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))


# Generated at 2022-06-18 10:16:23.727222
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set()


# Generated at 2022-06-18 10:16:33.041496
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:16:38.322360
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False



# Generated at 2022-06-18 10:16:42.615011
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    value = 1
    sem = BoundedSemaphore(value)
    sem.release()
    assert sem._value == 1
    sem.release()
    assert sem._value == 2
    try:
        sem.release()
    except ValueError:
        assert sem._value == 2
    else:
        assert False



# Generated at 2022-06-18 10:16:58.994483
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:17:01.040143
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:17:02.172843
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:17:04.628467
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:17:07.225975
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    assert condition.notify(1) == None
    assert condition.notify_all() == None


# Generated at 2022-06-18 10:17:09.320153
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.release()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:17:11.446703
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado.locks import Lock
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:17:17.486792
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:19.759485
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:17:24.569707
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:39.511999
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:17:45.180938
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:46.728367
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:17:57.416090
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    print(sem)
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())
    print(sem.acquire())

# Generated at 2022-06-18 10:18:00.142446
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:18:02.830866
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:18:07.456285
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem._value == 2
    sem.__aenter__()
    assert sem._value == 1
    sem.__aenter__()
    assert sem._value == 0
    sem.__aenter__()
    assert sem._value == 0


# Generated at 2022-06-18 10:18:10.436676
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))



# Generated at 2022-06-18 10:18:15.725020
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    waiters = []
    for i in range(10):
        waiter = Future()
        waiters.append(waiter)
        condition._waiters.append(waiter)
    condition.notify(5)
    for i in range(5):
        assert waiters[i].done()
        assert waiters[i].result() == True
    for i in range(5, 10):
        assert not waiters[i].done()


# Generated at 2022-06-18 10:18:19.769319
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:36.965412
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        pass
    else:
        raise AssertionError("Semaphore released too many times")



# Generated at 2022-06-18 10:18:39.322887
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    sem.release()
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:18:49.970970
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)
    condition.notify(21)

# Generated at 2022-06-18 10:19:01.074991
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()
    event.clear()
    event.wait()
   

# Generated at 2022-06-18 10:19:03.050218
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:19:06.484954
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:19:09.123324
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:19:14.991140
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:20.538171
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:23.883619
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:19:39.049722
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()


# Generated at 2022-06-18 10:19:40.747787
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:19:44.223455
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:19:50.519062
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        waiter()
        notifier()

    runner()

test_Condition_notify()


# Generated at 2022-06-18 10:19:55.180532
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"

# Generated at 2022-06-18 10:20:04.108227
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:13.774900
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:20:19.322452
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    def runner():
        # Wait for waiter() and notifier() in parallel
        waiter()
        notifier()

    runner()


# Generated at 2022-06-18 10:20:26.694578
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:34.814235
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    assert sem._value == 2
    assert sem._waiters == deque()
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem._value == 1
    assert sem._waiters == deque()
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem._value == 0
    assert sem._waiters == deque()
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem._value == -1
    assert sem._waiters == deque()
    assert sem.acquire() == _ReleasingContextManager(sem)
    assert sem._value == -2
    assert sem._waiters == deque()
    assert sem.acquire() == _ReleasingContextManager(sem)

# Generated at 2022-06-18 10:20:50.885222
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(n=2)
    condition.notify_all()


# Generated at 2022-06-18 10:20:52.688498
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() is None


# Generated at 2022-06-18 10:21:02.414227
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado.gen import coroutine
    from tornado.testing import AsyncTestCase, gen_test
    import unittest

    @coroutine
    def coroutine_test():
        sem = Semaphore(1)
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.acquire()
        await sem.ac

# Generated at 2022-06-18 10:21:05.186116
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:21:11.715759
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:16.788415
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:27.250416
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5
    sem.release()
    assert sem._value == 6
    sem.release()
    assert sem._value == 7
    sem.release()
    assert sem._value == 8
    sem.release()
    assert sem._value == 9
    sem.release()
    assert sem._value == 10
    sem.release()
    assert sem._value == 11
    sem.release()
    assert sem._value == 12
    sem.release()
    assert sem._value == 13
    sem.release()
    assert sem._value == 14
    sem.release()
    assert sem._value == 15
    sem.release()
   

# Generated at 2022-06-18 10:21:29.119194
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3


# Generated at 2022-06-18 10:21:32.037479
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)


# Generated at 2022-06-18 10:21:35.101959
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:21:55.493144
# Unit test for method wait of class Condition
def test_Condition_wait():
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    condition = Condition()
    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:21:57.939356
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:21:59.721271
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:22:02.871037
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert len(condition._waiters) == 0
    assert condition._timeouts == 0
    assert condition.io_loop == ioloop.IOLoop.current()


# Generated at 2022-06-18 10:22:08.709449
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:22:12.953183
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:22:14.812510
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    assert sem.__aenter__() is None


# Generated at 2022-06-18 10:22:22.381859
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:22:24.360507
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()
    return


# Generated at 2022-06-18 10:22:26.745661
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert len(sem._waiters) == 0
