

# Generated at 2022-06-18 10:13:06.735583
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.locks import Condition
    condition = Condition()
    assert repr(condition) == "<Condition>"

# Generated at 2022-06-18 10:13:15.288642
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:13:17.565603
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))



# Generated at 2022-06-18 10:13:24.013143
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:29.632502
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:30.875633
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:13:32.062691
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    assert condition.notify_all() == None


# Generated at 2022-06-18 10:13:39.754445
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:13:41.115045
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-18 10:13:43.878509
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(value=1)
    assert sem._value == 1
    sem.__aenter__()
    assert sem._value == 0


# Generated at 2022-06-18 10:14:05.373581
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:08.788989
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:14:14.847767
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:23.023607
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore(2)
    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:25.886233
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    assert condition.notify(n=1) == None
    assert condition.notify_all() == None


# Generated at 2022-06-18 10:14:33.918844
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:36.528775
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.acquire()
    lock.release()
    lock.__aenter__()


# Generated at 2022-06-18 10:14:38.794010
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(1)
    condition.notify_all()


# Generated at 2022-06-18 10:14:45.356759
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:14:50.299695
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test with no waiters
    condition = Condition()
    assert repr(condition) == "<Condition>"

    # Test with waiters
    condition.wait()
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:15:05.453584
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem.__aenter__() is None


# Generated at 2022-06-18 10:15:15.059918
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import tornado.ioloop
    import tornado.locks
    import tornado.testing
    import tornado.test.util
    import tornado.web
    import tornado.websocket
    import tornado.gen
    import tornado.platform.asyncio
    import asyncio
    import concurrent.futures
    import functools
    import logging
    import os
    import sys
    import unittest
    import uuid
    import warnings
    import zmq
    import zmq.asyncio
    import zmq.eventloop.ioloop
    import zmq.eventloop.zmqstream
    import zmq.utils.strtypes
    import zmq.utils.jsonapi
    import zmq.utils.strtypes
    import zmq.utils.jsonapi
    import zmq.utils.strtypes

# Generated at 2022-06-18 10:15:26.537710
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()
    assert event.wait() is None
    event.clear()
    assert event.wait() is None
    event.set()

# Generated at 2022-06-18 10:15:29.161958
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:15:35.599955
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:15:36.585532
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:15:43.038160
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None
    assert sem.acquire() == None

# Generated at 2022-06-18 10:15:46.024766
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))



# Generated at 2022-06-18 10:15:58.126867
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)
    condition.notify(11)
    condition.notify(12)
    condition.notify(13)
    condition.notify(14)
    condition.notify(15)
    condition.notify(16)
    condition.notify(17)
    condition.notify(18)
    condition.notify(19)
    condition.notify(20)
    condition.notify(21)

# Generated at 2022-06-18 10:16:02.086368
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()
    assert condition._waiters == collections.deque()
    assert condition._timeouts == 0
    assert condition.io_loop == ioloop.IOLoop.current()


# Generated at 2022-06-18 10:16:26.842496
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5
    sem.release()
    assert sem._value == 6
    sem.release()
    assert sem._value == 7
    sem.release()
    assert sem._value == 8
    sem.release()
    assert sem._value == 9
    sem.release()
    assert sem._value == 10
    sem.release()
    assert sem._value == 11
    sem.release()
    assert sem._value == 12
    sem.release()
    assert sem._value == 13
    sem.release()
    assert sem._value == 14
    sem.release()
    assert sem._value == 15
    sem.release()
   

# Generated at 2022-06-18 10:16:36.044769
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:37.764958
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sem = Semaphore(2)
    assert sem.__aenter__() == None


# Generated at 2022-06-18 10:16:39.078506
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:16:40.433685
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:16:46.546564
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:54.209006
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:16:56.593817
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    lock.release()

# Generated at 2022-06-18 10:17:07.085933
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)

# Generated at 2022-06-18 10:17:12.992296
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:17:46.868093
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
    event.wait(timeout=1)
    event.wait(timeout=datetime.timedelta(seconds=1))
    event.wait(timeout=datetime.timedelta(seconds=1.0))
    event.wait(timeout=datetime.timedelta(seconds=1.0))
    event.wait(timeout=datetime.timedelta(seconds=1.0))
    event.wait(timeout=datetime.timedelta(seconds=1.0))
    event.wait(timeout=datetime.timedelta(seconds=1.0))
    event.wait(timeout=datetime.timedelta(seconds=1.0))
    event.wait(timeout=datetime.timedelta(seconds=1.0))

# Generated at 2022-06-18 10:17:52.012016
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify(1)
    condition.notify(2)
    condition.notify(3)
    condition.notify(4)
    condition.notify(5)
    condition.notify(6)
    condition.notify(7)
    condition.notify(8)
    condition.notify(9)
    condition.notify(10)


# Generated at 2022-06-18 10:18:00.680128
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:09.371172
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:11.697149
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:18:13.984269
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.set()
    event.wait()
    event.clear()
    event.wait()
    event.set()
    event.wait()



# Generated at 2022-06-18 10:18:15.841336
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:18:20.764109
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:18:23.627142
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque()


# Generated at 2022-06-18 10:18:33.107968
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.release()
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__(None, None, None)
    lock.__aexit__

# Generated at 2022-06-18 10:19:28.704605
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert sem._waiters == deque([])


# Generated at 2022-06-18 10:19:30.426491
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        pass
    else:
        raise AssertionError("Semaphore released too many times")


# Generated at 2022-06-18 10:19:40.614169
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()
    sem.release()

# Generated at 2022-06-18 10:19:50.287884
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:19:59.356296
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:20:02.090393
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:20:06.570214
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:20:07.383708
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"


# Generated at 2022-06-18 10:20:11.011536
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value=1)
    sem.release()
    try:
        sem.release()
    except ValueError:
        pass
    else:
        raise AssertionError("BoundedSemaphore.release() did not raise ValueError")


# Generated at 2022-06-18 10:20:13.983635
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-18 10:22:06.492582
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-18 10:22:13.577839
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado.gen import coroutine
    import time
    import random
    import asyncio
    import threading
    import logging
    import sys
    import os
    import datetime
    import functools
    import concurrent.futures
    import traceback
    import unittest
    import typing
    import inspect
    import collections
    import contextlib
    import queue
    import multiprocessing
    import subprocess
    import signal
    import socket
    import json
    import re
    import base64
    import shutil
    import tempfile
    import urllib
    import urllib.parse
    import urllib.request
    import http.client
    import email.parser
    import email.policy
    import email.message

# Generated at 2022-06-18 10:22:16.090371
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    condition.notify()
    condition.notify(2)
    condition.notify_all()


# Generated at 2022-06-18 10:22:23.858491
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-18 10:22:32.898425
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    # event.wait()
    # event.wait(timeout=None)
    # event.wait(timeout=1)
    # event.wait(timeout=datetime.timedelta(seconds=1))
    # event.wait(timeout=datetime.timedelta(seconds=1.0))
    # event.wait(timeout=datetime.timedelta(seconds=1.0))
    # event.wait(timeout=datetime.timedelta(seconds=1.0))
    # event.wait(timeout=datetime.timedelta(seconds=1.0))
    # event.wait(timeout=datetime.timedelta(seconds=1.0))
    # event.wait(timeout=datetime.timedelta(seconds=1.0))
    # event.wait(timeout=datetime.tim