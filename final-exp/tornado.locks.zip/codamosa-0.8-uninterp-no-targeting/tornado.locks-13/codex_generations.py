

# Generated at 2022-06-22 03:53:37.669850
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    print(repr(Event()))



# Generated at 2022-06-22 03:53:38.832921
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    __aexit__(self, typ, value, tb)

# Generated at 2022-06-22 03:53:41.020750
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    event = Event()
    assert event.__repr__() == "<Event clear>"
    event.set()
    assert event.__repr__() == "<Event set>"


# Generated at 2022-06-22 03:53:53.736371
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    """
    This test checks that the first 'wait' coroutine (waiter) is waken up before
    the second 'wait' coroutine (waiter2) is waken up;
    Then it checks that waiter is waken up before notifier is executed and that notifier is executed
    before waiter2 is executed
    """
    @gen.coroutine
    def waiter():
        print("waiter: I'll wait right here")
        yield condition.wait()
        print("waiter: I'm done waiting")

    @gen.coroutine
    def waiter2():
        print("waiter2: I'll wait right here")
        yield condition.wait()
        print("waiter2: I'm done waiting")

    @gen.coroutine
    def notifier():
        print("notifier: About to notify")
        condition.notify_all()

# Generated at 2022-06-22 03:53:57.133295
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    assert Semaphore().__str__ == "Semaphore(locked)"
    assert str(Semaphore()) == "Semaphore(locked)"



# Generated at 2022-06-22 03:53:58.629350
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    # call function __exit__ of class Lock
    obj = Lock()



# Generated at 2022-06-22 03:54:01.446585
# Unit test for method release of class Lock
def test_Lock_release():
    lock = Lock()

    try:
        lock.release()
        assert("False")
    except RuntimeError:
        assert("True")




# Generated at 2022-06-22 03:54:04.427987
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.locks import Condition
    condition = Condition()
    assert repr(condition) == '<Condition>'
    return None

# Generated at 2022-06-22 03:54:10.607196
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    # Check whether the acquire method returns a future object.
    from tornado import locks
    lock = locks.Lock()
    lock.acquire()
    try:
        assert isinstance(lock.acquire(), Future)
    except:
        raise Exception("The acquire method does not return a Future object.")
    else:
        print("My test passed!")

# Generated at 2022-06-22 03:54:19.490682
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    import tornado.testing
    import tornado.ioloop
    import concurrent.futures as futures
    import tornado.concurrent
    from tornado.locks import Lock
    from tornado.gen import coroutine
    from tornado.gen import Return
    from tornado.ioloop import IOLoop
    import time
    import tornado.ioloop, tornado.iostream, tornado.gen
    import threading
    from tornado.locks import Event
    from tornado.gen import Future
    from tornado.locks import Condition
    from collections import deque
    from tornado.test.util import unittest

    tornado.testing.gen_test(lambda: None)
    #TODO: fix!
    #Lock.acquire()
    #Lock.__init__()
    #Lock.__aenter__()
    #Lock.__aexit__()
    #Lock.

# Generated at 2022-06-22 03:54:40.783338
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    with pytest.raises(AttributeError):
        c.__repr__()
    c._waiters = [1, 2, 3]
    assert c.__repr__() == "<Condition waiters[3]>"


# Generated at 2022-06-22 03:54:45.655039
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    # mode: full
    # full: True
    # tag: __repr__
    # flag: FUN_MEMBER_DEFAULT_ARGUMENT
    # priority: 3
    event_obj = locks.Event()
    assert repr(event_obj) == "<Event clear>"
    event_obj.set()
    assert repr(event_obj) == "<Event set>"



# Generated at 2022-06-22 03:54:49.801921
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    assert lock
    return lock

async def test_read_Lock(lock: Lock) -> None:
    assert lock

async def test_write_Lock(lock: Lock) -> None:
    assert lock



# Generated at 2022-06-22 03:54:52.925556
# Unit test for method wait of class Event
def test_Event_wait():
    Event.wait.__annotations__ = {
        "timeout": Optional[Union[float, datetime.timedelta]],
        "return": Awaitable[None],
    }

# Generated at 2022-06-22 03:54:56.665897
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    """ aenter does not block. """
    sem= Semaphore()
    resp = sem.__aenter__()
    assert resp is None

# Generated at 2022-06-22 03:55:03.484290
# Unit test for method clear of class Event
def test_Event_clear():
    e = Event()
    def f1():
        e.set()
        
    def f2():
        e.wait()
    t1 = Thread(target = f1)
    t2 = Thread(target = f2)
    t1.start()
    t2.start()
    t1.join()
    t2.join()
    e.clear()
    t3 = Thread(target = f2)
    t3.start()



# Generated at 2022-06-22 03:55:15.887363
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    class testRunner(gen.Coroutine):
        def run(self):
            await gen.multi([waiter0(), waiter1()])

    class waiter0(gen.Coroutine):
        def run(self):
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")

    class waiter1(gen.Coroutine):
        def run(self):
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")

    class notifier(gen.Coroutine):
        def run(self):
            print("About to notify")
            condition.notify_all()
            print("Done notifying")

    ioloop.IOLoop.current().run_sync(lambda: gen.multi([testRunner(), notifier()]))

# Generated at 2022-06-22 03:55:25.067225
# Unit test for constructor of class Condition
def test_Condition():
    import time

    async def f():
        c = Condition()
        print('c:'+str(c))
        return True
    async def f2():
        c = Condition()
        while True:
            print('c:'+str(c))
            await c.wait(short_timeout=1)


    # test init and await wait
    gen.coroutine(f)()
    # test init and wait
    f2()
    time.sleep(3)
    # test timeout, assert False
    assert Condition().wait(2) == False



# Generated at 2022-06-22 03:55:36.742215
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    print("testing __exit__")
    from tornado.locks import Lock
    lock = Lock()
    r = lock.__exit__()
    assert r == None


# Generated at 2022-06-22 03:55:48.461576
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    with BoundedSemaphore(2) as bs:

        test_value = bs.acquire()
        if test_value == True:
            print("The test_value is:",test_value)
        else:
            raise Exception("The value is false")
        test_value = bs.acquire()
        if test_value == True:
            print("The test_value is:",test_value)
        else:
            raise Exception("The value is false")
        test_value = bs.acquire()
        if test_value == False:
            print("The test_value is:",test_value)
        else:
            raise Exception("The value is true")

        test_value = bs.release()
        test_value = bs.release()
        test_value = bs.release()



# Generated at 2022-06-22 03:56:12.084284
# Unit test for method wait of class Event
def test_Event_wait():
    import time
    import asyncio
    from tornado.ioloop import IOLoop
    from tornado.locks import Event
    
    loop = asyncio.get_event_loop()
    event = Event()

    async def waiter():
        await event.wait()
        print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        print("Not waiting this time")
        await event.wait()
        print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        print("Done")

    async def setter():
        print(datetime.now().strftime('%Y-%m-%d %H:%M:%S'))
        print("About to set the event")
        event.set()


# Generated at 2022-06-22 03:56:13.609233
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    tgc = _TimeoutGarbageCollector()
    pass



# Generated at 2022-06-22 03:56:17.520021
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    a = BoundedSemaphore(value = 2)
    a.release()
    a.release()
    try:
        a.release()
    except ValueError:
        print("Release too many times")

test_BoundedSemaphore_release()



# Generated at 2022-06-22 03:56:21.147680
# Unit test for method notify of class Condition
def test_Condition_notify():
    cond = Condition()
    cond.notify(10)
    cond.notify_all()
    cond.wait(timeout=None)


# Generated at 2022-06-22 03:56:32.305792
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    gc = _TimeoutGarbageCollector()
    futures = [Future() for _ in range(20)]
    for i in range(0, 20, 2):
        futures[i].set_result(None)

    gc._waiters = collections.deque(futures)
    gc._garbage_collect()
    futures = [Future() for _ in range(20)]
    for i in range(0, 20, 2):
        futures[i].set_result(None)

    gc._waiters = collections.deque(futures)
    gc._garbage_collect()
    futures = [Future() for _ in range(20)]
    for i in range(0, 20, 2):
        futures[i].set_result(None)


# Generated at 2022-06-22 03:56:35.050820
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    obj = Lock()
    a = _ReleasingContextManager(obj)
    obj.acquire()
    assert obj._counter == 0
    exc_type, exc_val, exc_tb = None, None, None
    a.__exit__(exc_type, exc_val, exc_tb)
    assert obj._counter == 1



# Generated at 2022-06-22 03:56:43.358843
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    async def main():
        sem = Semaphore(value=2)
        print("Semaphore initial value is 2")
        
        # Acquire semaphore, then decrement its value
        async with sem:
            print("Semaphore decremented to 1")
            
        # Acquire semaphore, then decrement its value again
        async with sem:
            print("Semaphore decremented to 0")
            print("Semaphore is locked")
            
        def test():
            async def worker():
                await sem.acquire()
                print("Semaphore decremented to -1")
            
            print("Worker is waiting for Semaphore to be unlocked")
            worker()
            
        # Test worker
        test()
        
        # Unlock semaphore
        sem.release()

# Generated at 2022-06-22 03:56:44.945903
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
  condition = Condition()
  print("ok")
  return condition


# Generated at 2022-06-22 03:56:46.604963
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado.testing import AsyncTestCase, gen_test

    class Test(AsyncTestCase):
        async def test_lock(self):
            lock = Lock()
            await lock.acquire()
            await lock.release()

    test = Test()
    test.test_lock()

# Generated at 2022-06-22 03:56:47.705629
# Unit test for constructor of class Event
def test_Event():
    ev = Event()
    assert ev.is_set() is False  # type: ignore


# Generated at 2022-06-22 03:57:06.579751
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 03:57:13.844932
# Unit test for method wait of class Event
def test_Event_wait():
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    event = Event()
    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 03:57:15.633932
# Unit test for constructor of class Semaphore
def test_Semaphore():
    s = Semaphore(5)
    assert s._value == 5, "Semaphore's constructor does not work."



# Generated at 2022-06-22 03:57:24.874235
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    for i in range(0,20):
        print(i)
        sem = Semaphore(10)
        print(sem)
        i = 0
        while i < 20:
            i += 1 
            if sem._value == 0:
                print("Acquire:", i, "-", sem._value, "do")
                try:
                    waiter = Future()
                    if sem._value > 0:
                        sem._value -= 1
                        waiter.set_result(ContextManager(sem))
                    else:
                        sem._waiters.append(waiter)
                        sem.on_timeout()
                except gen.TimeoutError:
                    sem._garbage_collect()
                print("Acquire:", i, "-", sem._value, "done")


# Generated at 2022-06-22 03:57:26.724502
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    condition.notify_all()


# Generated at 2022-06-22 03:57:30.102306
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    from tornado import locks
    lock = locks.Lock()
    assert repr(lock) == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"


# Generated at 2022-06-22 03:57:43.066554
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import random
    import concurrent.futures
    import asyncio
    def do_random_stuff():
        # choose a random number between 1 and 10
        random_value = random.randint(1, 10)
        # sleep for the random number of seconds
        time.sleep(random_value)
        return random_value
    async def async_random_stuff():
        # choose a random number between 1 and 10
        random_value = random.randint(1, 10)
        # sleep for the random number of seconds
        await asyncio.sleep(random_value)
        return random_value
    # set the max number of workers to 4
    pool = concurrent.futures.ThreadPoolExecutor(max_workers=4)
    # create a Semaphore with a value of 4
    semaphore = Semaphore(4)


# Generated at 2022-06-22 03:57:48.915567
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    gc = _TimeoutGarbageCollector()
    loop = ioloop.IOLoop()
    f1 = loop.create_future()
    f2 = loop.create_future()
    gc._waiters.append(f1)
    gc._waiters.append(f2)
    gc._garbage_collect()
    assert len(gc._waiters) == 2
    f1.set_result('foo')
    gc._garbage_collect()
    assert len(gc._waiters) == 1


# Generated at 2022-06-22 03:57:51.550437
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    def __enter__(self):
        raise RuntimeError("Use `async with` instead of `with` for Lock")

# Generated at 2022-06-22 03:57:55.677096
# Unit test for method set of class Event
def test_Event_set():
  #event = Event()
  test_conditon = (not isinstance(event, Event))
  assert test_conditon == False, "Event not initialized"
  event.set()


# Generated at 2022-06-22 03:58:27.703727
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    print("Unit test for method acquire of class Semaphore")
    
    lock = Semaphore(1)
    
    async def acquire_then_release():
        print("About to acquire")
        async with lock:
            print("Acquired")
            await gen.sleep(0)
            print("Done")
    
    async def runner():
        print("About to wait")
        await gen.multi([acquire_then_release(), acquire_then_release()])
    
    ioloop.IOLoop.current().run_sync(runner)
   
    print("Done unit test for method acquire of class Semaphore")
    return



# Generated at 2022-06-22 03:58:32.677593
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    c = Lock()
    r = c.__repr__()
    assert r == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"


# Generated at 2022-06-22 03:58:35.640515
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    assert repr(Event()) == "<Event clear>"
    event = Event()
    event._value = True
    assert repr(event) == "<Event set>"


# Generated at 2022-06-22 03:58:37.356988
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    assert isinstance(condition, Condition) == True

# Generated at 2022-06-22 03:58:42.782217
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    import tornado.locks as locks
    lock = locks.Lock()
    loop = ioloop.IOLoop.current()
    async def main():
        async with lock:
            print('locked')
        print('unlocked')
    loop.run_sync(main)

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-22 03:58:50.126921
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    event = Event()
    # event.is_set() is False
    event.set()
    # event.is_set() is True
    print(event)
    # assert event == "<Event set>"
    event.clear()
    print(event)
    # assert event == "<Event clear>"


# Generated at 2022-06-22 03:58:52.273893
# Unit test for constructor of class Condition
def test_Condition():
    c = Condition()
    assert isinstance(c, _TimeoutGarbageCollector)
    assert isinstance(c, Condition)


# Generated at 2022-06-22 03:58:54.622340
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    # Wait for event
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True


# Generated at 2022-06-22 03:58:55.609240
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    pass


# Generated at 2022-06-22 03:58:58.243748
# Unit test for constructor of class Lock
def test_Lock():
    from tornado import locks
    lock = locks.Lock()
    for i in range(10):
        if i < 3:
            lock.acquire()
        else:
            lock.release()
test_Lock()



# Generated at 2022-06-22 03:59:25.408716
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    lock = Lock()
    sem = BoundedSemaphore(value=1)
    @coroutine
    def f():
        h= yield lock.acquire()
        try:
            print("Lock acquired")
            g= yield sem.acquire()
            print("Semaphore acquired")
        except gen.TimeoutError:
            print("Lock acquisition timed out")
    @coroutine
    def g():
        try:
            lock.release()
            print("Lock released")
        except RuntimeError:
            print("Lock released")

# Generated at 2022-06-22 03:59:27.712530
# Unit test for constructor of class Condition
def test_Condition():
    #self = Condition()
    #self.__init__()
    pass


# Generated at 2022-06-22 03:59:31.806458
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    s = Semaphore(value=1)
    with pytest.raises(RuntimeError, match="Use 'async with' instead of 'with' for Semaphore"):
        s.__exit__(RuntimeError, 1, None)




# Generated at 2022-06-22 03:59:33.904336
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # __aenter__(self: tornado.locks.Lock) -> None
    pass

# Generated at 2022-06-22 03:59:44.603450
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)
    # assert sem.value == 2
    # assert sem.waiters == []
    # assert sem.acquire() == 1
    # assert sem.value == 1
    # assert sem.waiters == []
    # assert sem.acquire() == 1
    # assert sem.value == 0
    # assert sem.waiters == []
    # assert sem.acquire() == 0
    # assert sem.value == 0
    # assert sem.waiters == []
    # assert len(sem.waiters) == 0
    # assert sem.acquire() == 0
    # assert len(sem.waiters) == 1



# Generated at 2022-06-22 03:59:47.969187
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    smp = Semaphore(0)
    with smp:
        pass
    assert smp
SEMAPHORE = Semaphore(0)

# Generated at 2022-06-22 03:59:49.325245
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()


# Generated at 2022-06-22 03:59:53.709675
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    import asyncio
    sem = Semaphore(5)
    async def worker():
        await sem.acquire()
        print('got one')
        await sem.acquire()
        print('got two')
        await sem.acquire()
        print('got three')
    asyncio.get_event_loop().run_until_complete(worker())

if __name__ == "__main__":
    test_Semaphore_acquire()

# Generated at 2022-06-22 04:00:01.154475
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(4)

    waiter = Future()
    if sem._value > 0:
        sem._value -= 1
        waiter.set_result(_ReleasingContextManager(sem))
    else:
        sem._waiters.append(waiter)

    sem.release()

    assert sem._value == 4
    assert not sem._waiters



# Generated at 2022-06-22 04:00:02.098758
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    obj = Event()
    result = obj.__repr__()
    assert result is not None


# Generated at 2022-06-22 04:00:42.123483
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    with pytest.raises(RuntimeError):
        # This call to method __enter__ of class Lock should raise an exception
        Lock().__enter__()
    return



# Generated at 2022-06-22 04:00:55.213916
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    test_cases = (
        # test_case is an instance of namedtuple
        # ('test', 'expect_output', 'exception')
        #   test is a string for testing.
        #   expect_output is what we expect from the test.
        #   exception is True if exception is expected, otherwise is False.
        TestCase('__exit__(None, None, None)', None, False),
    )
    for i, test_case in enumerate(test_cases):
        print('Running test case #%d: %s' % (i + 1, test_case.test))
        manager = _ReleasingContextManager(mock.MagicMock())
        assert not hasattr(manager, 'a')

# Generated at 2022-06-22 04:00:58.101380
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    garbage = _TimeoutGarbageCollector()
    assert garbage._waiters == collections.deque()
    assert garbage._timeouts == 0
    garbage._garbage_collect()
    assert garbage._timeouts == 0


# Generated at 2022-06-22 04:00:59.394773
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(2)
    assert sem._value == 2
    assert sem._waiters == deque()


# Generated at 2022-06-22 04:01:00.776348
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    collector = _TimeoutGarbageCollector()
    assert not collector._waiters
    assert collector._timeouts == 0

test__TimeoutGarbageCollector()


# Generated at 2022-06-22 04:01:02.396738
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()

# Generated at 2022-06-22 04:01:06.349873
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False



# Generated at 2022-06-22 04:01:09.063731
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    """
    This is a unit test for method __enter__ of class _ReleasingContextManager.
    It will do nothing.
    """
    pass



# Generated at 2022-06-22 04:01:17.632614
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
  sem = Semaphore(1)

  # Test normal exit
  waiter = WaitIterator()
  waiter.add_future(sem.__aenter__())
  waiter.add_future(sem.__aexit__(None, None, None))
  waiter.next()
  waiter.next()
  assert sem._value == 1

  # Test exception raised
  waiter = WaitIterator()
  waiter.add_future(sem.__aenter__())
  waiter.add_future(sem.__aexit__(TypeError, ValueError, None))
  waiter.next()
  waiter.next()
  assert sem._value == 1

# Generated at 2022-06-22 04:01:19.442804
# Unit test for constructor of class Condition
def test_Condition():
    result = "<Condition>"
    condition = Condition()
    assert str(condition) == result

