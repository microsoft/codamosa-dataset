

# Generated at 2022-06-22 03:53:37.482751
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    return condition





# Generated at 2022-06-22 03:53:42.799668
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Lock

    lock = Lock()

    @gen.coroutine
    def func():
        try:
            async with lock:
                pass
        except:
            print('caught')

    IOLoop.current().run_sync(func)

# Generated at 2022-06-22 03:53:46.856838
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
  lock = Lock()
  assert lock.__repr__() == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"


# Generated at 2022-06-22 03:53:48.501347
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(10)
    assert sem._value == 10


# Generated at 2022-06-22 03:53:50.819244
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    assert not lock._block._value

# Generated at 2022-06-22 03:54:02.511355
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()

    # Unit test for method acquire of class Lock
    async def method_acquire(lock):
        print("1: acquire")
        await lock.acquire()
        print("2: acquire")
        await lock.acquire()
        print("3: acquire")
        await lock.acquire()
        print("4: acquire")
        await lock.acquire()
        print("5: acquire")

    async def test_method_acquire():
        await gen.multi([ method_acquire(lock), method_acquire(lock) ])

    try:
        ioloop.IOLoop.current().run_sync(test_method_acquire)
    except:
        print("exception")

    # Unit test for method release of class Lock
    async def test_method_release():
        lock.release()
       

# Generated at 2022-06-22 03:54:03.998027
# Unit test for constructor of class Event
def test_Event():
    test = Event()
    assert test.is_set() == False



# Generated at 2022-06-22 03:54:14.147447
# Unit test for method notify of class Condition
def test_Condition_notify():
    class MyCondition(Condition):
        pass
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)

# Generated at 2022-06-22 03:54:16.446047
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    from tornado.locks import Lock
    lock = Lock()
    with lock:
        pass


# Generated at 2022-06-22 03:54:22.932771
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    # Implicitly tested by above doctests:
    #
    #     def test_Lock(self, value):
    #         self.assertEqual(
    #             repr(Lock(value)),
    #             "<Lock _block={!r}>".format(BoundedSemaphore(value=value)))
    #
    pass



# Generated at 2022-06-22 03:54:34.734281
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    s = Semaphore(1)
    print("Acquiring semaphore")
    with (yield s.acquire()):
        print("Acquired")
    print("Released semaphore")


# Generated at 2022-06-22 03:54:39.679869
# Unit test for method set of class Event
def test_Event_set():
    from tornado.ioloop import IOLoop
    from tornado import gen
    event = Event()

    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 03:54:41.446735
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    from tornado.locks import Semaphore
    sem = Semaphore()
    try:
        with (sem):
            ...
        raise AssertionError
    except RuntimeError:
        pass


# Generated at 2022-06-22 03:54:45.568480
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    tgc = _TimeoutGarbageCollector()
    assert(isinstance(tgc._waiters, collections.deque))
    assert(isinstance(tgc._timeouts, int))
    assert(tgc._waiters.__sizeof__() == 56)
    assert(tgc._timeouts == 0)


# Generated at 2022-06-22 03:54:50.171512
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    obj = gen.coroutine(lambda: None)
    ReleasingContextManager = _ReleasingContextManager(obj)

    if ReleasingContextManager.__enter__() == None:
        assert True

    print(ReleasingContextManager.__exit__())
test__ReleasingContextManager()



# Generated at 2022-06-22 03:54:52.354367
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    # Check method acquire of class Lock
    lock = Lock()
    lock.acquire()
    lock.release()


# Generated at 2022-06-22 03:54:54.681822
# Unit test for constructor of class Condition
def test_Condition():
    c = Condition()
    print(c)


# Generated at 2022-06-22 03:55:03.197566
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
	from tornado import gen
	from tornado.ioloop import IOLoop
	from tornado.locks import Condition
	c = Condition()
	async def wa():
		await c.wait()
		print('done')
	async def na():
		await gen.sleep(0.5)
		c.notify_all()
	async def runner():
		# Wait for waiter() and notifier() in parallel
		await gen.multi([wa(), na()])
		
	IOLoop.current().run_sync(runner)

# Generated at 2022-06-22 03:55:09.745390
# Unit test for method clear of class Event
def test_Event_clear():
    '''
    Test if we can clear an event
    '''
    initial_value = False
    e1 = Event()
    assert e1.is_set() == initial_value
    e1.set()
    assert e1.is_set() == True
    e1.clear()
    assert e1.is_set() == initial_value



# Generated at 2022-06-22 03:55:21.370276
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    from tornado.locks import Lock
    from tornado.log import gen_log

    lock = Lock()

    try:
        with lock:
            pass
    except:
        # Error message shown by Lock.__enter__
        pass

    # log_function of the default IOLoop is gen.log.gen_log
    # If a log_function is set, the log_function is called
    # and a error message is shown
    # In this case, gen.log.gen_log is called.
    gen_log.error("Error message in function gen.log.gen_log")

    try:
        lock = Lock()
        try:
            with lock:
                pass
        except:
            # Error message shown by Lock.__enter__
            pass
    except:
        pass


# Generated at 2022-06-22 03:55:48.592135
# Unit test for method clear of class Event
def test_Event_clear():
    """Test case for Event.clear

    This class will test the function clear of class Event
    """
    import tornado
    import tornado.ioloop
    import time

    # testing for Event
    print("Testing class Event")

    print("\tTesting method clear of class Event")
    # open a ioloop
    ioloop = tornado.ioloop.IOLoop.current()

    # wait the Event
    def wait_event(event):
        yield event.wait()

        # set a timer after 50ms
        ioloop.call_later(0.05, ioloop.stop)

    # set the Event after 100ms
    def set_event(event):
        event.set()

    event = tornado.locks.Event()

    # start the test
    ioloop.add_callback(wait_event, event)
   

# Generated at 2022-06-22 03:55:53.390542
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    '''
    _ReleasingContextManager class test
    '''
    # initialize variable for test
    obj = None
    # Perform the test
    test_obj = _ReleasingContextManager(obj)
    # assert the result
    assert test_obj is not None, "A new '_ReleasingContextManager' object is not created"



# Generated at 2022-06-22 03:55:55.409599
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    from tornado import locks
    lock = locks.Lock()
    print(lock.__repr__())

# Generated at 2022-06-22 03:55:59.758428
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(4)
    for i in range(4):
        sem.release()
    try:
        sem.release()
    except ValueError as e:
        print(e)

test_BoundedSemaphore_release()


# Generated at 2022-06-22 03:56:05.276715
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Create a semaphore.
    semaphore = Semaphore()

    try:
        # Wait here forever to be waken up by the semaphore.
        with (yield semaphore.acquire()):
            print("I've got the semaphore!")
    except Exception as e:
        print(e)
        print("Timeout error")


# Generated at 2022-06-22 03:56:08.097619
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    semaphore = Semaphore(1)
    with (yield semaphore.acquire()):
        pass
    # Now semaphore.release() has been called.



# Generated at 2022-06-22 03:56:12.395232
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(value = 1)
    try:
        sem.release()
        sem.release()
    except ValueError:
        pass
    else:
        raise AssertionError("Should be an exception")

# Generated at 2022-06-22 03:56:15.364155
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    # Check the number of released.
    semaphore = Semaphore(10)
    with (yield semaphore.acquire()):
        assert len(semaphore._releasers) == 1



# Generated at 2022-06-22 03:56:21.506499
# Unit test for method wait of class Event
def test_Event_wait():
    async def main():
        a = Event()
        print("Before wait " + str(a.is_set()))
        await a.wait()
        print("After wait " + str(a.is_set()))
    loop = ioloop.IOLoop.current()
    loop.run_sync(main)

# Generated at 2022-06-22 03:56:27.254798
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    # type: () -> None
    """test_Lock___enter__"""

    # __enter__ of Lock
    def _f():
        # type: () -> None

        def _f():
            # type: () -> None
            raise RuntimeError("Use `async with` instead of `with` for Lock")
        return _f

    with pytest.raises(RuntimeError):
        _f()()



# Generated at 2022-06-22 03:56:59.553105
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    lock = Lock()
    with lock:
        pass
    # Now lock.release() has been called.
    assert lock.locked()



# Generated at 2022-06-22 03:57:05.577417
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # Check the __aenter__ of Semaphore.
    from tornado import gen

    from tornado.locks import Semaphore


    sem = Semaphore(1)


    async def test():
        await sem.__aenter__()
        assert sem._value == 0
        sem.release()
        assert sem._value == 1
    gen.run_test(test)

# Generated at 2022-06-22 03:57:08.683619
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True



# Generated at 2022-06-22 03:57:11.423847
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(0)
    try:
        assert sem._value == 0
    except:
        print('Error: test_Semaphore failed')

# Generated at 2022-06-22 03:57:13.126105
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(0)
    assert sem.release() == None


# Generated at 2022-06-22 03:57:16.875736
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    with pytest.raises(TypeError):
        assert Condition().__repr__()


# Generated at 2022-06-22 03:57:18.944489
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    assert not event.is_set()
    assert event is not None


# Generated at 2022-06-22 03:57:26.065529
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()

    @gen.coroutine
    def waiter():
       print('waiting for event')
       yield event.wait()
       print('not waiting this time')
       yield event.wait()
       print('done')

    @gen.coroutine
    def setter():
        print('about to set the event')
        event.set()

    @gen.coroutine
    def runner():
        yield [waiter(), setter()]

    ioloop.IOLoop.current().run_sync(runner)

# Generated at 2022-06-22 03:57:28.293250
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    gc = _TimeoutGarbageCollector()
    assert len(gc._waiters)==0



# Generated at 2022-06-22 03:57:40.853349
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    # Create an instance of Semaphore
    # and set the value of its instance variable _value as 1
    # such that the acquire method returns immediately
    sem = Semaphore(1)
    # Reset the value of sem._value to an arbitrary value: 0 
    sem._value = 0
    # Create a Future whose result is set as _ReleasingContextManager(self)
    waiter = Future()
    # Append waiter to sem._waiters
    sem._waiters.append(waiter)
    # Invoke acquire(-1)
    res = sem.acquire(-1)
    # Check that acquire(-1) returns the same Future object as waiter
    assert(res == waiter)
    # Check that the result of waiter is a _ReleasingContextManager instance
    assert(isinstance(res.result(), _ReleasingContextManager))
    # Check that

# Generated at 2022-06-22 03:58:43.712568
# Unit test for constructor of class Condition
def test_Condition():
	condition = Condition()


# Generated at 2022-06-22 03:58:48.473443
# Unit test for constructor of class Condition
def test_Condition():
    a = Condition()
    print(a)
    a.notify()
    print(a)
    a.notify_all()
    print(a)


# Generated at 2022-06-22 03:58:57.928944
# Unit test for method wait of class Event
def test_Event_wait():
    import pytest
    from test.util import unittest
    from tornado.locks import Event
    from tornado.testing import gen_test

    ev = Event()

    @gen_test
    def test_wait():
        def callback(arg):
            assert arg == 'result'
        # 考虑到wait是一个Future对象，所以才会在test_wait中的result()中得到"result"的字符串
        # 实际上Event对象的wait方法封装了一个Future对象，这个方法会阻塞当前线程

# Generated at 2022-06-22 03:58:58.827527
# Unit test for constructor of class Condition
def test_Condition():
    c = Condition()


# Generated at 2022-06-22 03:59:03.038634
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import gen

    lock = Lock()
    async def func():
        async with lock:
            pass
    IOLoop.current().run_sync(func)

# Generated at 2022-06-22 03:59:12.521927
# Unit test for method notify of class Condition
def test_Condition_notify():
    def test_waiter(waiter, condition):
        print("I'll wait right here")
        async with ioloop.IOLoop().run_sync(condition.wait()):
            print("I'm done waiting")

    async def test_notifier(condition):
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def test_runner():
        # Wait for waiter() and notifier() in parallel
        waiter = []
        condition = Condition()
        waiter = threading.Thread(
            target=test_waiter, args=(waiter, condition)
        )
        waiter.start()
        await test_notifier(condition)

    ioloop.IOLoop.current().run_sync(test_runner)


# Generated at 2022-06-22 03:59:19.415377
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    r = Semaphore(1)
    # print("r_repr=",r.__repr__())
    print("r._value=",r._value)
    r.release()
    print("r._value=",r._value)
    # print("r_repr=",r.__repr__())


# Generated at 2022-06-22 03:59:30.913856
# Unit test for constructor of class Lock
def test_Lock():
    # type: () -> None
    '''
    >>> from tornado import locks
    >>> lock = locks.Lock()
    >>>
    >>> async def f():
    ...    async with lock:
    ...        # Do something holding the lock.
    ...        pass
    ...
    ...    # Now the lock is released.

    For compatibility with older versions of Python, the `.acquire`
    method asynchronously returns a regular context manager:

    >>> async def f2():
    ...    with (yield lock.acquire()):
    ...        # Do something holding the lock.
    ...        pass
    ...
    ...    # Now the lock is released.

    .. versionchanged:: 4.3
       Added ``async with`` support in Python 3.5.

    '''
    pass


# Generated at 2022-06-22 03:59:43.437666
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    '''
    Please run the following to make sure no error is thrown:

    from tornado.locks import Semaphore

    sem = Semaphore(2)

    async def worker(worker_id):
        async with sem:
            print("Worker %d is working" % worker_id)
            await use_some_resource()

        # Now the semaphore has been released.
        print("Worker %d is done" % worker_id)

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)

    '''
    from tornado.ioloop import IOLoop
    from tornado import gen
    from tornado.locks import Semaphore

    sem = Semaphore(2)


# Generated at 2022-06-22 03:59:44.101589
# Unit test for method set of class Event
def test_Event_set():
    pass

# Generated at 2022-06-22 04:02:06.675016
# Unit test for method wait of class Condition
def test_Condition_wait():
    import tornado.gen
    import tornado.ioloop
    import tornado.locks
    import threading
    import asyncio
    def main_async(wait_callback:tornado.locks.Condition):
        print('BEGIN MAIN_ASYNC')
        future = tornado.gen.multi([wait_callback().wait(),wait_callback().wait(),wait_callback().wait()])
        #print(future)
        #print(await future)
        tornado.ioloop.IOLoop.current().run_sync(future)

    def main_notify(wait_callback:tornado.locks.Condition):
        print('BEGIN MAIN_NOTIFY')
        tornado.ioloop.IOLoop.current().call_later(0.05,wait_callback().notify_all())



# Generated at 2022-06-22 04:02:08.701744
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    ac_func = lambda: None
    ac_func.acquire = Lock().acquire
    assert isawaitable(ac_func.acquire())



# Generated at 2022-06-22 04:02:15.510815
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    # _waiters �?�个元素的时候，会有 waiters[1]
    f = Future()
    condition._waiters = collections.deque([f])
    assert repr(condition) == "<Condition waiters[1]>"



# Generated at 2022-06-22 04:02:18.154875
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()
    
    
    
    
    

# Generated at 2022-06-22 04:02:18.732353
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    pass

# Generated at 2022-06-22 04:02:27.031066
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)
# Unit test of method wait of class Condition

# Generated at 2022-06-22 04:02:34.779972
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 04:02:46.968899
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    # Tested function
    #from tornado.locks import Lock

    def __init__(self):
        self._block = BoundedSemaphore(value=1)

    def __repr__(self):
        return "<%s _block=%s>" % (self.__class__.__name__, self._block)

    def acquire(self, timeout=None):
        return self._block.acquire(timeout)

    def release(self):
        return self._block.release()

    def __enter__(self):
        raise RuntimeError("Use `async with` instead of `with` for Lock")

    # Tested function
    def __exit__(self, typ, value, tb):
        self.__enter__()

    # Test data
    self = Lock()

    # Perform the test

# Generated at 2022-06-22 04:02:53.521583
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 04:02:59.490864
# Unit test for method clear of class Event
def test_Event_clear():
    from . import locks
    event = locks.Event()
    event.set()
    event.clear()
    assert event.is_set() == False, 'Event.clear() should transform the attribute is_set of a Event object'
    assert all(
        isinstance(event, type(None)) for event in event._waiters
    ), 'Event.clear() should transform the attribute _waiters of a Event object'
    print('All tests passed!')
