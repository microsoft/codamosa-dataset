

# Generated at 2022-06-22 03:53:50.489503
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    repr_returned = repr(locks.Lock())
    assert repr_returned == '<Lock _block=<BoundedSemaphore [unlocked,value:1]>,waiters:0>'

# Generated at 2022-06-22 03:53:52.957899
# Unit test for constructor of class Event
def test_Event():
    e = Event()
    assert e.is_set() == False
    e.set()
    assert e.is_set() == True
    e.clear()
    assert e.is_set() == False

test_Event()



# Generated at 2022-06-22 03:54:05.512287
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()

    import threading
    import time

    def condition_notify_all(condition1):
        print("thread %s is running" % threading.current_thread().name)
        time.sleep(2)
        print("thread %s is running" % threading.current_thread().name)
        condition1.notify_all()

    def condition_wait(condition1):
        print("thread %s is running" % threading.current_thread().name)
        time.sleep(2)
        print("thread %s is running" % threading.current_thread().name)
        condition1.wait()

    test_threads = []

    test_threads.append(threading.Thread(target=condition_notify_all,args=(condition,)))

# Generated at 2022-06-22 03:54:16.899793
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    init(devices.cuda)
    lock1 = Lock()              # instance of Lock class
    # lock1.acquire()    # cannot do that because it is an awaitable

    @gen.coroutine
    def set_lock():
        print("Setting lock")
        yield lock1.acquire()  # wait until lock1 is not locked, then lock it
        print("Lock acquired")

    @gen.coroutine
    def wait_lock():
        print("Waiting for lock")
        yield lock1.acquire()
        print("Lock acquired")

    @gen.coroutine
    def runner():
        yield [set_lock(), wait_lock()]

    ioloop.IOLoop.current().run_sync(runner)
    """
    Setting lock
    Lock acquired
    Waiting for lock
    Lock acquired
    """


# Generated at 2022-06-22 03:54:21.216793
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify_all()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]

    loop = ioloop.IOLoop.current()
    loop.run_sync(runner)

# Generated at 2022-06-22 03:54:25.004522
# Unit test for constructor of class Semaphore
def test_Semaphore():

    class TestSemaphore(asynctest.TestCase):

        async def test_Semaphore_init(self):
            sem = Semaphore()

    asynctest.run_test_case(TestSemaphore())


# Generated at 2022-06-22 03:54:29.809113
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    """Test __aenter__ method of Semaphore"""
    async def async_test():
        sem = Semaphore(2)
        await sem.acquire()
        return sem
    sem = sync_test(async_test())
    sem.release()


# Generated at 2022-06-22 03:54:32.666853
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    test_obj = Semaphore()
    test_obj.release()
    return

# Generated at 2022-06-22 03:54:44.099993
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import _ReleasingContextManager

    from _ReleasingContextManager_test import _ReleasingContextManager_test
    from Box import Box

    mybox = Box()

    async def waiter():
        print("Waiting for event")
        await mybox.condition.wait()
        print("Not waiting this time")
        await mybox.condition.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        mybox.condition.notify()

    async def runner():
        await gen.multi([waiter(), setter()])

    mybox.condition = Condition()
    runner = Box()
    runner.v = runner()
    IOLoop.current().run_sync(runner.v)
    test_

# Generated at 2022-06-22 03:54:56.656696
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    from random import randint
    from unittest import TestCase

    class TestBoundedSemaphore_release(TestCase):
        def test_1(self):
            #raise ValueError
            sem=BoundedSemaphore(value=1)
            sem.release()
            with self.assertRaises(ValueError):
                sem.release()

        def test_2(self):
            #raise ValueError
            sem=BoundedSemaphore(value=3)
            sem.release()
            sem.release()
            sem.release()
            with self.assertRaises(ValueError):
                sem.release()

        def test_3(self):
            #raise ValueError
            n=randint(1,10)
            sem=BoundedSemaphore(value=n)

# Generated at 2022-06-22 03:55:09.554587
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    sm = Semaphore()
    sm.acquire()
    sm.acquire()
    assert sm._value == -2
    sm.acquire()
    assert sm._value == -3


# Generated at 2022-06-22 03:55:11.017534
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    def __exit__(
        self,
        exc_type: "Optional[Type[BaseException]]",
        exc_val: Optional[BaseException],
        exc_tb: Optional[types.TracebackType],
    ) -> None:
        self._obj.release()



# Generated at 2022-06-22 03:55:14.364249
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    obj = Semaphore()
    assert obj.__repr__() == "<tornado.locks.Semaphore [unlocked,value:1]>"

# Generated at 2022-06-22 03:55:16.229732
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    semaphore = BoundedSemaphore(10)
    semaphore.release()
    assert True



# Generated at 2022-06-22 03:55:26.977684
# Unit test for method release of class Lock
def test_Lock_release():
    from tornado import locks
    from tornado.testing import AsyncTestCase, gen_test, bind_unused_port

    async def coro(lock):
        async with lock:
            lock.release()
        # check that the lock was released
        async with lock:
            lock.release()

    class MethodRelease(AsyncTestCase):
        @gen_test
        def test_lock_release(self):
            lock = locks.Lock()
            server = bind_unused_port()[0]
            await coro(lock)
            # code coverage doesn't distinguish between different exceptions
            self.assertRaises(Exception, lock.release)
            server.close()


# Generated at 2022-06-22 03:55:32.211031
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from .locks import Semaphore
    sem = Semaphore()
    assert sem._value == 1
    sem.release()
    assert sem._value == 2
    sem.release()
    assert sem._value == 3
    sem.release()
    assert sem._value == 4


# Generated at 2022-06-22 03:55:35.549114
# Unit test for method clear of class Event
def test_Event_clear():
    # |GIVEN|
    event = Event()
    result = False
    # |WHEN|
    event.clear()
    # |THEN|
    assert event._value == False


# Generated at 2022-06-22 03:55:41.048356
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    waiters = []
    n = 1
    while n and condition._waiters:
        waiter = condition._waiters.popleft()
        if not waiter.done():  # Might have timed out.
            n -= 1
            waiters.append(waiter)
    return waiters


# Generated at 2022-06-22 03:55:41.718541
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    assert lock._block._initial_value == 1



# Generated at 2022-06-22 03:55:43.762215
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    collector = _TimeoutGarbageCollector()
    assert isinstance(collector._waiters, collections.deque)
    assert isinstance(collector._timeouts, int)



# Generated at 2022-06-22 03:56:02.842387
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)
    
    null = Future() # type: Future[None]
    null.set_result(None)
    null_set_result_unless_cancelled(null, None)

    waiter = Future() # type: Future[_ReleasingContextManager]
    
    waiter.add_done_callback(lambda _: io_loop.remove_timeout(timeout_handle))

# Generated at 2022-06-22 03:56:07.248377
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    # Test for specific exception
    bounded_semaphore = BoundedSemaphore(1)
    bounded_semaphore.release()
    try:
        bounded_semaphore.release()
    except ValueError:
        assert True
    except:
        assert False



# Generated at 2022-06-22 03:56:11.805761
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    s = Semaphore(value=1)
    try:
        with (s):
            pass
        assert False
    except RuntimeError as e:
        assert str(e) == "Use 'async with' instead of 'with' for Semaphore"


# Generated at 2022-06-22 03:56:21.658329
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(2)

    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
            await use_some_resource()
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])




    IOLoop.current().run_sync(runner)

if __name__ == '__main__':
    test_Semaphore_acquire()
    pass

# Generated at 2022-06-22 03:56:26.220843
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sema = BoundedSemaphore(2)
    sema.release()
    sema.release()
    try:
        sema.release()
    except ValueError as valerr:
        print(valerr)
    else:
        print('hmmm, unexpected ...')

# Generated at 2022-06-22 03:56:27.254070
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()



# Generated at 2022-06-22 03:56:37.203410
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)

test_Condition_wait()


# Generated at 2022-06-22 03:56:39.408776
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    print(c.__repr__())
    assert (c.__repr__()=="<Condition>")

# Generated at 2022-06-22 03:56:43.220617
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())


# Generated at 2022-06-22 03:56:49.265656
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    _block = BoundedSemaphore(value=1)
    lock1 = Lock()
    lock1._block = _block
    assert repr(lock1) == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"
    lock1._block = None
    assert repr(lock1) == "<Lock _block=None>"


# Generated at 2022-06-22 03:57:21.194467
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    collector = _TimeoutGarbageCollector()
    assert type(collector) == _TimeoutGarbageCollector, \
        "__init__ should set collector to an instance of type _TimeoutGarbageCollector"
    assert type(collector._waiters) == collections.deque
    assert type(collector._timeouts) == int
    assert collector._timeouts == 0, 'constructor should set _timeouts to 0'


# Generated at 2022-06-22 03:57:22.483659
# Unit test for constructor of class Condition
def test_Condition():
    _TimeoutGarbageCollector()
    Condition()


# Generated at 2022-06-22 03:57:24.336881
# Unit test for method __repr__ of class Event
def test_Event___repr__():
        f = Event()
        result = f.__repr__()
        assert result == '<Event clear>'

# Generated at 2022-06-22 03:57:27.334954
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    io_loop = IOLoop.current()
    io_loop.run_sync(lambda:  Semaphore().__exit__(None, None, None))


# Generated at 2022-06-22 03:57:29.636553
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    pass


# Generated at 2022-06-22 03:57:34.746167
# Unit test for method release of class Lock
def test_Lock_release():
    # create object Lock
    obj = Lock()
    assert isinstance(obj, Lock)
    # set value for _block
    obj._block = 1
    # try to raise exception:
    try:
        obj.release()
    except RuntimeError as e:
        assert str(e) == 'release unlocked lock'
    except Exception as e:
        raise ('Not the expected type of exception')

# Generated at 2022-06-22 03:57:38.021843
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
        import asyncio
        import typing
        with Lock() as lock:
                print('Not reached')
                lock.__aexit__(None, None, None)
        lock.__aexit__(None, None, None)

# Generated at 2022-06-22 03:57:41.979306
# Unit test for method set of class Event
def test_Event_set(): 
    import inspect 
    lines = inspect.getsource(Event.set) 
    assert "fut.set_result(None)" in lines

# Generated at 2022-06-22 03:57:43.059154
# Unit test for constructor of class Condition
def test_Condition():
    c = Condition()


# Generated at 2022-06-22 03:57:45.767921
# Unit test for constructor of class Lock
def test_Lock():
    # 1) test the constructor, check if __init__ is implemented
    lock = Lock()
    print(type(lock))
    assert type(lock) is Lock
    assert isinstance(lock._block, BoundedSemaphore)


# Generated at 2022-06-22 03:58:39.908005
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(2)
    sem.release()
    assert sem._value == 3
    assert len(sem._waiters) == 0


# Generated at 2022-06-22 03:58:41.778116
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    from tornado.locks import Lock
    lock = Lock()
    lock.__enter__()
    return None


# Generated at 2022-06-22 03:58:54.705033
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    """Test case for Lock.acquire(), basic case"""
    from tornado import locks
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    lock = locks.Lock()
    @gen.coroutine
    def tester():
        # This routine will be waiting on lock in the future
        t_future = Future()
        def tester_executor():
            with (yield lock.acquire()):
                t_future.set_result(None)
                # Close the lock, so that other threads could acquire the lock
                lock.release()
        IOLoop.current().add_callback(tester_executor)
        # Acquire the lock
        with (yield lock.acquire()):
            # Do something holding the lock
            pass
        yield t_future
    IOL

# Generated at 2022-06-22 03:58:56.525479
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    assert repr(Semaphore(2)) == "<Semaphore [unlocked,value:2]>"


# Generated at 2022-06-22 03:59:09.176962
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    pass
    # value = 1
    # self._value = value
    # if self._value >= self._initial_value:
    #     raise ValueError("Semaphore released too many times")
    # self._value += 1
    # while self._waiters:
    #     waiter = self._waiters.popleft()
    #     if not waiter.done():
    #         self._value -= 1
    #
    #         # If the waiter is a coroutine paused at
    #         #
    #         #     with (yield semaphore.acquire()):
    #         #
    #         # then the context manager's __exit__ calls release() at the end
    #         # of the "with" block.
    #         waiter.set_result(_ReleasingContextManager(self))
    #         break

# Generated at 2022-06-22 03:59:12.248119
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()
    assert lock._block._value == 0


# Generated at 2022-06-22 03:59:13.748069
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    print(lock)


# Generated at 2022-06-22 03:59:16.668273
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    print(lock)
    

# Generated at 2022-06-22 03:59:20.902061
# Unit test for constructor of class Event
def test_Event():
    # try to create a Event object
    event = Event()
    # try to call set
    event.set()
    event.wait(timeout=datetime.timedelta(seconds=1))
    event.clear()


# Generated at 2022-06-22 03:59:27.300937
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    from tornado.locks import Lock
    lock = Lock()
    try:
        lock.__exit__(None, None, None)
        assert False, "expected exception"
    except RuntimeError as e:
        assert str(e) == "Use `async with` instead of `with` for Lock"
    else:
        assert False, "expected exception"


# Generated at 2022-06-22 04:00:24.767460
# Unit test for method wait of class Condition
def test_Condition_wait():
    @gen.coroutine
    def condition_obj():
        while True:
            yield condition.wait(short_timeout)
            print('looping....')

    async def condition_obj():
        while True:
            await condition.wait(short_timeout)
            print('looping....')

    assert isinstance(condition_obj(), Future)
    assert isinstance(condition_obj(), Awaitable)



# Generated at 2022-06-22 04:00:29.112023
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    a = event.set()
    assert a is None
    assert event._value == True
    # assert that the waiters list is empty
    assert len(event._waiters) == 0


# Generated at 2022-06-22 04:00:30.633363
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    _lock = Lock()
    with _lock:
        pass


# Generated at 2022-06-22 04:00:34.345351
# Unit test for constructor of class Semaphore
def test_Semaphore():
    s = Semaphore(3)
    print('A semaphore with initial value 3: %s'%s)

if __name__ == '__main__':
    test_Semaphore()

# Generated at 2022-06-22 04:00:39.706146
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    async def func():
        print("Waiting for event")
        await event.wait()
        print("Done")
    def setter():
        print("About to set the event")
        event.set()
    loop = ioloop.IOLoop.current()
    loop.add_callback(setter)
    loop.run_sync(func)


# Generated at 2022-06-22 04:00:42.205512
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    with pytest.raises(Exception):
        s = BoundedSemaphore(value=1)
        s.release()
        s.release()

# Generated at 2022-06-22 04:00:46.264479
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    assert event.is_set() == False
    event.clear()
    assert event.is_set() == False


# Generated at 2022-06-22 04:00:49.134793
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    ctx = _ReleasingContextManager(None)
    ctx.__exit__(None, None, None)

test__ReleasingContextManager___exit__()



# Generated at 2022-06-22 04:00:57.254074
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    assert lock.__repr__() == "<tornado.locks.Lock _block=<tornado.locks.BoundedSemaphore [unlocked,value:1]>>"
    lock.release()
    assert lock.__repr__() == "<tornado.locks.Lock _block=<tornado.locks.BoundedSemaphore [unlocked,value:1]>>"
    lock.acquire()
    assert lock.__repr__() == "<tornado.locks.Lock _block=<tornado.locks.BoundedSemaphore [locked]>>"



# Generated at 2022-06-22 04:01:00.086136
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from tornado.locks import Semaphore
    with Semaphore(10) as sema:
        pass



# Generated at 2022-06-22 04:02:51.132510
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()


# Generated at 2022-06-22 04:02:53.603745
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    obj = _ReleasingContextManager("asdf")
    obj.__enter__()



# Generated at 2022-06-22 04:03:03.863585
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    from typing import cast
    from tornado.locks import Semaphore
    import sys
    import unittest

    # Create the class for testing.
    class Test__ReleasingContextManager(unittest.TestCase):

        # Test the constructor.
        def test_init(self):
            from typing import cast
            obj = Semaphore(1)
            result = _ReleasingContextManager(obj=obj)
            assert cast(Semaphore, result._obj) is obj

        # Test __enter__().
        def test___enter__(self):
            result = _ReleasingContextManager(Semaphore(1))
            assert result.__enter__() is None

        # Test __exit__().
        def test___exit__(self):
            obj = Semaphore(1)
            result = _ReleasingContextManager(obj=obj)

# Generated at 2022-06-22 04:03:04.982298
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert event.is_set() == False

# Generated at 2022-06-22 04:03:05.609463
# Unit test for method clear of class Event
def test_Event_clear():
    pass

# Generated at 2022-06-22 04:03:15.478779
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Event
    event = Event()
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    IOLoop.current().run_sync(runner)
    assert repr(event) == "<Event set>"
    