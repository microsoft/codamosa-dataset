

# Generated at 2022-06-22 03:53:50.581061
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    async def test_wait(condition):
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")

    async def test_notifier(condition):
            print("About to notify")
            condition.notify_all()
            print("Done notifying")


    async def test_runner():
            # Wait for waiter() and notifier() in parallel
            await gen.multi([test_wait(c), test_notifier(c)])

    ioloop.IOLoop.current().run_sync(test_runner)


# Generated at 2022-06-22 03:53:52.745717
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    l = _TimeoutGarbageCollector()
    assert l._timeouts == 0
    assert len(l._waiters) == 0

# Timer for the garbage collection of class _TimeoutGarbageCollector

# Generated at 2022-06-22 03:53:56.282301
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    class TestClass(object):
        def release(self):
            pass
    TestClass().__exit__(None, None, None)

# Generated at 2022-06-22 03:54:03.507886
# Unit test for method release of class Lock
def test_Lock_release():
    async def f():
        lock = Lock()
        assert lock._block._value == 1
        await lock.acquire()
        assert lock._block._value == 0
        lock.release()
        assert lock._block._value == 1
        lock.release()
        try:
            lock.release()
        except RuntimeError:
            assert True
        finally:
            assert lock._block._value == 1

    ioloop.IOLoop.current().run_sync(f)

# Generated at 2022-06-22 03:54:07.179947
# Unit test for method is_set of class Event
def test_Event_is_set():
    e = Event()

    assert not e.is_set()
    e.set()
    assert e.is_set()
    e.clear()
    assert not e.is_set()


# Generated at 2022-06-22 03:54:12.002994
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    value = 10
    sem = Semaphore(value)
    assert sem._value == value, "Test Semaphore init value failed"
    sem.release()
    assert sem._value == value + 1, "Test Semaphore release failed"



# Generated at 2022-06-22 03:54:13.159919
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()  # type: Condition
    c.notify_all()


# Generated at 2022-06-22 03:54:14.939635
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    pass



# Generated at 2022-06-22 03:54:27.621538
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    # Count number of times the garbage collector is called
    def garbage_collect(self):
        self.garbage_collect_count += 1

    # Create instance and replace the garbage collector method by count version
    a = _TimeoutGarbageCollector()
    a.garbage_collect_count = 0
    a._garbage_collect = garbage_collect.__get__(a, _TimeoutGarbageCollector)
    # Set _timeouts to a value that triggers garbage collection
    a._timeouts = 101

    # Set waiters and call garbage collector, check the counter
    a._waiters = [1, 2, 3]
    a._garbage_collect()
    assert a.garbage_collect_count == 1 and a._timeouts == 1 and a._waiters == []



# Generated at 2022-06-22 03:54:29.756088
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    obj = _ReleasingContextManager(None)
    assert(None == obj.__enter__())

# Generated at 2022-06-22 03:54:46.160697
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    print("==========Start testing BoundedSemaphore_release==========")
    bs = BoundedSemaphore(value=0)
    try:
        bs.release()
    except ValueError as e:
        pass
    except Exception as e:
        raise e
    print("==========Finish testing BoundedSemaphore_release==========")


# Generated at 2022-06-22 03:54:57.020712
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    from tornado.locks import Condition
    import sys
    import time
    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)
    print('---------')
    runner()
    print('count time')
    # time.sleep(2)


# Generated at 2022-06-22 03:55:01.913664
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
  with pytest.raises(RuntimeError) as the_exception:
    sem = Semaphore()
    with sem:
      pass
  assert the_exception.type == RuntimeError
  assert the_exception.value.args == ("Use 'async with' instead of 'with' for Semaphore",)

# Generated at 2022-06-22 03:55:10.710915
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    import pytest
    from tornado.locks import Event
    from tornado.testing import AsyncTestCase, gen_test

    class TestEvent(AsyncTestCase):
        # Unit test for method __repr__ of class Event
        @gen_test
        def test___repr__(self):
            event = Event()
            assert repr(event) == "<Event clear>"
            event.set()
            assert repr(event) == "<Event set>"
            event.clear()

    test_event = TestEvent()
    test_event.run()

# Generated at 2022-06-22 03:55:15.241993
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    # Create a dummy instance of class Event
    event = Event()
    # Create an instance of builtin type repr
    repr_value = repr(event)
    assert repr_value.startswith('<Event ')
    assert repr_value.endswith('>')

# Generated at 2022-06-22 03:55:17.020457
# Unit test for method __exit__ of class Lock

# Generated at 2022-06-22 03:55:22.335509
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    """
    Test case for method acquire of class Lock
    """
    lock = Lock()
    async def inner():
        async with lock:
            pass

    t = gen.Task(inner)
    t.result() # runs test and returns result



# Generated at 2022-06-22 03:55:24.927741
# Unit test for method clear of class Event
def test_Event_clear():
    e = Event()
    e.set()
    e.clear()
    return



# Generated at 2022-06-22 03:55:25.855177
# Unit test for constructor of class Event
def test_Event():
    e = Event()
    print(e.is_set())
test_Event()


# Generated at 2022-06-22 03:55:28.385028
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    import tornado.locks
    lock = tornado.locks.Lock()
    lock.acquire(None)

# Generated at 2022-06-22 03:55:40.786789
# Unit test for constructor of class Semaphore
def test_Semaphore():
    pass


# Generated at 2022-06-22 03:55:45.621826
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 03:55:50.024885
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    # TESTED:
    # import tornado.locks
    # s = tornado.locks.Semaphore(4)
    # waiter = Future()
    # waiter.set_result(None)
    # s._value = 1
    # s._waiters.append(waiter)
    # s.release()
    pass



# Generated at 2022-06-22 03:55:58.907275
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    """
    Test for the __enter__ method of class Lock
    """
    async def async_test_Lock___enter__():
        lock_ins = Lock()
        try:
            await lock_ins.acquire()
        except:
            assert False
        else:
            assert True
        finally:
            lock_ins.release()
    # The following two lines execute the async_test_Lock___enter__ coroutine
    # and makes sure that it raises no exception.
    loop = asyncio.get_event_loop()
    loop.run_until_complete(async_test_Lock___enter__())


# Generated at 2022-06-22 03:56:00.665433
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    """
    >>> from tornado.locks import _ReleasingContextManager
    """
    pass



# Generated at 2022-06-22 03:56:04.060420
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    # Construction of the instance
    obj=Lock()
    # Testing the method
    assert repr(obj) == '<Lock _block=<Semaphore [unlocked,value:1]>>'

# Generated at 2022-06-22 03:56:14.134351
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(1)
    print(sem)  # <Semaphore [unlocked,value:1]>

    sem = Semaphore(0)
    print(sem)  # <Semaphore [locked]>

async def test_Semaphore_acquire():
    sem = Semaphore(1)
    await sem.acquire()
    print(sem)  # <Semaphore [locked]>

    sem = Semaphore(1)
    async with sem:
        print(sem)  # <Semaphore [locked]>
    
    print(sem)  # <Semaphore [unlocked,value:1]>



# Generated at 2022-06-22 03:56:16.393996
# Unit test for constructor of class Condition
def test_Condition():
    # test basic condition
    c = Condition()
    assert(repr(c) == "<Condition>")

    # test notify
    c.notify()
    c.notify(n=3)

    # test notify_all
    c.notify_all()

test_Condition()



# Generated at 2022-06-22 03:56:17.745608
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert event.is_set() == False


# Generated at 2022-06-22 03:56:21.766702
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    a = BoundedSemaphore(value=10)
    b = BoundedSemaphore(value=100)
    assert a._value == 10


# Generated at 2022-06-22 03:56:43.144630
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    from tornado.concurrent import TracebackFuture
    from tornado.locks import Semaphore
    from tornado.testing import AsyncTestCase, gen_test

    class MyTest(AsyncTestCase):
        def test_Semaphore___enter__(self):
            sem = Semaphore()
            fut = TracebackFuture()
            try:
                with sem:
                    pass
            except RuntimeError as e:
                fut.set_exc_info(sys.exc_info())
            fut.add_done_callback(self.stop)
            self.wait()

# Generated at 2022-06-22 03:56:46.774731
# Unit test for method wait of class Event
def test_Event_wait():
    event1=Event()
    event1.wait()
    event1.set()
    event1.wait()
    event1.clear()
    event1.wait()


# Generated at 2022-06-22 03:56:48.166628
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    gc = _TimeoutGarbageCollector()
    assert gc


# Generated at 2022-06-22 03:56:51.881083
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    assert isinstance(lock, Lock)
    assert repr(lock) == "<Lock _block=<Semaphore unlocked,value:1>>"



# Generated at 2022-06-22 03:56:53.801504
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem=Semaphore()
    print(sem.__repr__())

# Generated at 2022-06-22 03:56:58.193444
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    sem.__class__ = Semaphore
    try:
        with (yield sem.acquire()) as obj:
            pass
    except Exception as e:
        print(e)


# Generated at 2022-06-22 03:57:00.547639
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    E = Event() # type: Event
    E.is_set() # type: bool
    E.set()

    E.clear()
    E.wait() # type: Awaitable[None]


# Generated at 2022-06-22 03:57:11.376820
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()
    condition.wait()

    flag = False

    with IOLoop.current().start():
        condition.notify()

    with IOLoop.current().start():
        async def waiter():
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")
            nonlocal flag
            flag = True

        async def runner():
            # Wait for waiter() and notifier() in parallel
            await gen.multi([waiter()])

        runner()

    with IOLoop.current().start():
        condition.notify()

    assert flag


# Generated at 2022-06-22 03:57:13.760284
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    assert repr(lock) == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"


# Generated at 2022-06-22 03:57:18.280293
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    print(event.is_set())
    print(event._waiters)
    event.set()
    print(event.is_set())
    print(event._waiters)



# Generated at 2022-06-22 03:57:33.272533
# Unit test for method release of class Lock
def test_Lock_release():
    # define input parameters and expected output
    lock = locks.Lock()
    try:
        lock.release()
    except RuntimeError:
        return True
    else:
        return False

# Generated at 2022-06-22 03:57:36.905286
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    c = Condition()
    futures = [c.wait() for i in range(3)]
    c.notify_all()
    for fut in futures:
        if not fut.done():
            raise RuntimeError("notify_all did not notify")



# Generated at 2022-06-22 03:57:41.280302
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert not event.is_set()
    event.set()
    assert event.is_set()
    event.clear()
    assert not event.is_set()


# Generated at 2022-06-22 03:57:42.478695
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    lock = Lock()
    lock.__enter__()

# Generated at 2022-06-22 03:57:50.408929
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    from tornado import gen
    from tornado.ioloop import IOLoop
    from time import time
    from time import sleep

    # Test for blocked wait()
    async def waiter_1():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter_1():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter_1(), setter_1()])

    IOLoop.current().run_sync(runner)


    # Test for non-blocked wait()
    async def waiter_2():
        print("Waiting for event")
        event.set()
        await event.wait()

# Generated at 2022-06-22 03:57:57.726654
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    if(not event.is_set()):
        print('test_Event_is_set: OK')
    else:
        print('test_Event_is_set: Failed')
    event.set()
    if(event.is_set()):
        print('test_Event_is_set: OK')
    else:
        print('test_Event_is_set: Failed')

# Generated at 2022-06-22 03:57:58.830657
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    assert True



# Generated at 2022-06-22 03:58:01.200723
# Unit test for constructor of class Lock
def test_Lock():
    try:
        lock = Lock()
    except Exception as err:
        print(err)


if __name__ == "__main__":
    test_Lock()

# Generated at 2022-06-22 03:58:09.918715
# Unit test for method wait of class Event
def test_Event_wait():
    from tornado.testing import AsyncTestCase, gen_test
    import unittest
    class TestEvent(AsyncTestCase):
        @gen_test
        def test_Event_wait(self):
            e = Event()
            result = yield e.wait()
            self.assertIs(result, None)
            # now check that on timeout it returns True
            result = yield gen.with_timeout(
            timeout=3, future=e.wait())
            self.assertIs(result, None)
    unittest.main()



# Generated at 2022-06-22 03:58:16.524411
# Unit test for method wait of class Condition
def test_Condition_wait():
    import asyncio
    async def test_wait1():
        condition = Condition()
        async def waiter():
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")

        async def notifier():
            print("About to notify")
            condition.notify()
            print("Done notifying")

        async def runner():
            # Wait for waiter() and notifier() in parallel
            await gen.multi([waiter(), notifier()])

        loop = asyncio.get_event_loop()
        loop.run_until_complete(runner())

    async def test_wait2():
        condition = Condition()
        async def waiter():
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")


# Generated at 2022-06-22 03:58:32.719630
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    class A(_TimeoutGarbageCollector):
        pass
    a = A()
    assert isinstance(a._waiters, collections.deque)
    assert a._timeouts == 0


# Generated at 2022-06-22 03:58:42.031606
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    __tracebackhide__ = True
    f = Lock()
    while True:
        # STATE: f.__aenter__ -> <Return(h)>
        try:
            # STATE: h -> <Future>
            h = f.__aenter__()
            if isinstance(h, Future):
                break
        except BaseException as e:
            # STATE: <Exception>(AsyncExitStack, ProcessPoolExecutor, TimeoutError, RuntimeError)
            return e
    # STATE: <Future>.set_result -> None
    h.set_result(None)
    # STATE: <Future>.result -> None
    return h.result()

# Generated at 2022-06-22 03:58:46.053944
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    # __init__ of class _ReleasingContextManager
    obj = None
    _ReleasingContextManager(obj)



# Generated at 2022-06-22 03:58:48.610727
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    obj = _ReleasingContextManager(0)
    assert(isinstance(obj, object))


# Generated at 2022-06-22 03:58:55.322311
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    from tornado import gen
    @gen.coroutine
    def test():
        sem = Semaphore(1)
        release = False
        assert sem._value == 1
        if not release:
            yield sem.acquire()
        sem.release()
        assert sem._value == 1
        release = True
        print("correct")
    IOLoop.current().run_sync(test)


# Generated at 2022-06-22 03:59:07.894397
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    import time
    import sys
    import asyncio
    from tornado.locks import Semaphore
    sem = Semaphore()
    async def worker(id):
        sem.acquire()
        print("Worker %d is working" % id)
        await asyncio.sleep(1)
        print("Worker %d is finished working" % id)
        sem.release()

    async def runner():
        workers = [asyncio.ensure_future(worker(i)) for i in range(3)]
        await asyncio.wait(workers)

    loop = asyncio.get_event_loop()
    loop.run_until_complete(runner())
    loop.close()

if __name__ == "__main__":
    test_Semaphore_acquire()

# Generated at 2022-06-22 03:59:10.342285
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    m = _ReleasingContextManager(None)
    m.__enter__()
    m.__exit__(None, None, None)



# Generated at 2022-06-22 03:59:13.224837
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    obj = _ReleasingContextManager(object())
    exit_ret = obj.__exit__()
    assert exit_ret == None



# Generated at 2022-06-22 03:59:27.145273
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import random
    import time
    import threading
    import multiprocessing
    with Semaphore():
        pass

    def run_tasks(tasks):
        def worker():
            for task in tasks:
                task()
        thread = threading.Thread(target=worker)
        thread.start()
        return thread

    # Ensure deterministic behavior in tests by initializing RNGs.
    random.seed(0xdead)

    # unit test for correct behavior on release
    semaphore = Semaphore(1)
    results = []

    def acquire():
        results.append(semaphore.acquire())

    def release():
        # may not actually call release() since the semaphore is already locked
        if results[-1]._result is not None:
            results[-1].result().release()
       

# Generated at 2022-06-22 03:59:29.303139
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())


# Generated at 2022-06-22 04:00:03.535366
# Unit test for method notify of class Condition
def test_Condition_notify():

    condition = Condition()

    @gen.coroutine
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    loop = ioloop.IOLoop.current()
    loop.run_sync(runner)
# test_Condition_notify() 



# Generated at 2022-06-22 04:00:05.973760
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    with pytest.raises(RuntimeError):

        # __enter__ of class Semaphore with *args, **kwargs:
        Semaphore().__enter__()


# Generated at 2022-06-22 04:00:16.835302
# Unit test for constructor of class Condition
def test_Condition():
    import libs.tormysql.utils
    import libs.tormysql.utils.ioloop
    from libs.tormysql.utils import Condition
    from libs.tormysql.utils.ioloop import IOLoop
    from libs.tormysql.utils.ioloop import PeriodicCallback
    from libs.tormysql.utils.locks import Event
    import random
    import time

    # Create a random number generator with a fixed seed, so this test
    # is reproducable.
    randint = random.Random(42).randint

    def check_condition(condition):
        assert condition._timeouts == 0
        assert len(condition._waiters) == 0

    condition1 = Condition()
    assert isinstance(condition1._waiters, collections.deque)

# Generated at 2022-06-22 04:00:18.991214
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    pass
    # a = Condition()
    # a.wait()
    # a.notify_all()



# Generated at 2022-06-22 04:00:25.991129
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    import tornado.ioloop
    import tornado.locks
    import tornado.testing
    import types

    class TestCase(tornado.testing.AsyncTestCase):
        def test___aenter__(self):
            # self.assertEqual(expected, TestCase.test___aenter__(self))
            raise NotImplementedError
    # Unit test for method __aenter__ of class Semaphore

# Generated at 2022-06-22 04:00:29.976401
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    from tornado import gen

    lock = Lock()

    @gen.coroutine
    def f():
        async with lock:
            pass

    gen.convert_yielded()(f())



# Generated at 2022-06-22 04:00:31.353582
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    t = Semaphore()
    assert t.__aenter__()



# Generated at 2022-06-22 04:00:42.341711
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(1)
    assert sem.__repr__() == "<Semaphore [unlocked,value:1]>"
    assert sem.release() == None
    assert sem.__repr__() == "<Semaphore [unlocked,value:2]>"
    sem.release()
    assert sem.acquire() == None
    assert sem.__repr__() == "<Semaphore [unlocked,value:1]>"
    assert sem.__aenter__() == None
    assert sem.__aexit__() == None
    assert sem.__repr__() == "<Semaphore [unlocked,value:2]>"
    assert sem.__exit__() == None
    assert sem.__repr__() == "<Semaphore [locked]>"
    assert sem.__enter__() == None
    assert sem

# Generated at 2022-06-22 04:00:46.936654
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    lock = Lock()
    assert lock.__repr__() == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"


# Generated at 2022-06-22 04:00:50.901769
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    def __exit__(self, exc_type, exc_val, exc_tb):
        if '__exit__':
            return None
        else:
            return '__exit__'

# Generated at 2022-06-22 04:01:44.794808
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    # __exit__()

    # raises RuntimeError if lock not locked
    lock = Lock()
    with pytest.raises(RuntimeError) as e:
        lock.__exit__(None, None, None)
    # __exit__()

# Generated at 2022-06-22 04:01:47.386071
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    res = super().__repr__()
    extra = ('locked' if self._value == 0 else 'unlocked,value:%s' % self._value)
    if self._waiters:
        extra = '%s,waiters:%s' % (extra, len(self._waiters))
    return '<%s [%s]>' % (res[1:-1], extra)



# Generated at 2022-06-22 04:01:52.702843
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    import asyncio
    async def test_Semaphore_acquire_1(value=1, timeout=None):
        s = Semaphore(value=value)
        try:
            print("Start acquire")
            aenter = await s.__aenter__()
            print("End acquire")
            if aenter is None:
                print("aenter is None")
            return aenter
        except Exception as e:
            print("Error: %s" % str(e))
            return None
    asyncio.run(test_Semaphore_acquire_1())
    asyncio.run(test_Semaphore_acquire_1(value=None))



# Generated at 2022-06-22 04:01:59.710207
# Unit test for method set of class Event
def test_Event_set():
    from tornado.ioloop import IOLoop
    from tornado.locks import Event
    event = Event()
    print("Waiting for event")
    io_loop = IOLoop.current()
    io_loop.add_timeout(io_loop.time() + 1, event.set)
    assert io_loop.run_sync(event.wait)



# Generated at 2022-06-22 04:02:01.927902
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    f = Lock()
    f.__aexit__(exc_type=None, exc_value=None, exc_tb=None)

# Generated at 2022-06-22 04:02:03.327185
# Unit test for method wait of class Event
def test_Event_wait():
    Event.wait()



# Generated at 2022-06-22 04:02:05.237812
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
	s = Semaphore(100)
	print(s)


# Generated at 2022-06-22 04:02:08.259094
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    _waiters = set()
    _value = 1
    obj1 = Semaphore(_value)
    obj1._waiters = _waiters
    res = obj1.__repr__()

    assert res == "<Semaphore [unlocked,value:1]>"



# Generated at 2022-06-22 04:02:13.582116
# Unit test for constructor of class Semaphore
def test_Semaphore():
    try:
        Semaphore(1)
        Semaphore(0)
        print("Semaphore initial value accepted")
    except Exception as e:
        print(e)

    try:
        Semaphore(-1)
        print("Semaphore initial value accepted")
    except Exception as e:
        print(e)


# Generated at 2022-06-22 04:02:15.960300
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    # test Lock.acquire()
    pass