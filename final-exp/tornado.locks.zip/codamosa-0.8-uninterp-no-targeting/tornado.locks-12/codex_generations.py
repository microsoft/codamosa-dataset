

# Generated at 2022-06-22 03:53:46.856372
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    """Test for method __enter__ of class Lock."""
    lock = Lock()
    with raises(RuntimeError):
        lock.__enter__()


# Generated at 2022-06-22 03:53:56.457781
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore

    sem = Semaphore(2)
    
    
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 03:53:58.271940
# Unit test for constructor of class Condition
def test_Condition():
    cond = Condition()


# Generated at 2022-06-22 03:53:59.672601
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    self = Event()
    assert repr(self) == "<Event clear>"


# Generated at 2022-06-22 03:54:03.643941
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem=Semaphore()
    assert not sem._value
    sem.__aexit__(None,None,None)
    assert sem._value
test_Semaphore___aexit__()


# Generated at 2022-06-22 03:54:05.467916
# Unit test for constructor of class Condition
def test_Condition():
    ioloop.IOLoop.current().run_sync(lambda: Condition())

# Generated at 2022-06-22 03:54:12.555112
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    obj = Semaphore()
    # No exception to raise
    typ = None # type: Optional[Type[BaseException]]
    value = None # type: Optional[BaseException]
    tb = None # type: Optional[types.TracebackType]
    # Call the __aexit__ method
    obj.__aexit__(typ, value, tb)

# Generated at 2022-06-22 03:54:23.417895
# Unit test for constructor of class Condition
def test_Condition():
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()
    # io_loop = IOLoop.current()

    async def waiter():
        # print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        # print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)

# Generated at 2022-06-22 03:54:25.368656
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    print(event)
    event.set()
    print(event)


# Generated at 2022-06-22 03:54:35.496787
# Unit test for method clear of class Event
def test_Event_clear():
    #type: () -> None
    """Unit test for method clear of class Event"""
    class Mock(object):
        pass
    event = Event()
    event._value = True
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event._waiters = set()
    mock = Mock()
    mock2 = Mock()
    event._waiters.add(mock)
    event._waiters.add(mock2)
    event.clear()
    assert event.is_set() == False
    assert event._waiters == set([])
    

# Generated at 2022-06-22 03:54:49.372891
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    from tornado.locks import Semaphore
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    count = 0
    sem = Semaphore()
    async def worker():
        async with sem:
            nonlocal count
            count += 1
            assert count == 1
            await Future()
            count -= 1
    async def runner():
        await worker()
        assert count == 0
        await worker()
        assert count == 0
    IOLoop.current().run_sync(runner)



# Generated at 2022-06-22 03:54:54.682358
# Unit test for method set of class Event
def test_Event_set():
    e = Event()
    e.set()
    assert(e.is_set())
    #assert(e.is_clear()) # This method is not implemented by author
    e.clear()
    assert(not e.is_set())
    #assert(e.is_clear())


# Generated at 2022-06-22 03:54:57.125927
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    g.lock = Lock()
    with (await g.lock):
        pass

# Generated at 2022-06-22 03:54:57.883381
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    pass

# Generated at 2022-06-22 03:55:07.973935
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]

    condition = Condition()

    ioloop = IOLoop.current()
    ioloop.run_sync(runner)


# Generated at 2022-06-22 03:55:11.413432
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    from tornado.locks import Event

    obj = Event()
    f = getattr(obj, '__repr__')
    assert f() == "<Event clear>"



# Generated at 2022-06-22 03:55:14.010378
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    # Test the method arguments
    Semaphore().__exit__(None, None, None)

# Generated at 2022-06-22 03:55:16.650160
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    print("Testing __exit__ of class Lock")

    foo = Lock()
    assert foo.__exit__(0, 0, 0) == None
    

# Generated at 2022-06-22 03:55:29.585206
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import tornado.ioloop
    from tornado.locks import Condition
    from tornado.gen import Future, TimeoutError
    import time
    import logging
    logging.basicConfig(level=logging.DEBUG)
    condition = Condition()
    waiter = Future()
    def waiter_coroutine():
        logging.info("waiter_coroutine start")
        time.sleep(2)
        try:
            a = yield gen.with_timeout(datetime.timedelta(seconds=1), condition.wait())
            logging.info("get condition.wait() result: a={}".format(a))
        except TimeoutError:
            logging.info("waiter time out")
        logging.info("waiter_coroutine end")
    io_loop = tornado.ioloop.IOLoop.current()

# Generated at 2022-06-22 03:55:31.291827
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    # test arguments
    # returned value
    # assertions
    pass

# Generated at 2022-06-22 03:55:43.935893
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(0)
    assert (str(sem) == '<Semaphore [locked,waiters:0]>')
    sem.release()
    assert (str(sem) == '<Semaphore [unlocked,value:1]>')
    sem.acquire()
    assert (str(sem) == '<Semaphore [unlocked,value:0,waiters:0]>')



# Generated at 2022-06-22 03:55:46.929093
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Example of a coroutine function
    async def coro(lock):
        await lock.acquire()

    # Example of a regular function
    def func(lock):
        return lock.acquire()

# Generated at 2022-06-22 03:55:47.565631
# Unit test for method release of class Lock
def test_Lock_release():
    pass

# Generated at 2022-06-22 03:55:53.470404
# Unit test for method wait of class Event
def test_Event_wait():
  """Test the method Event.wait()."""
  event = Event()
  assert event.is_set() == False
  event.wait(timeout = 0.1)
  assert event.is_set() == True 
  
  event.clear()
  assert event.is_set() == False
  event.wait(timeout = 0.1)
  assert event.is_set() == True 
  event.wait() 
  


# Generated at 2022-06-22 03:55:54.500432
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    tgc = _TimeoutGarbageCollector();



# Generated at 2022-06-22 03:55:57.371946
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    print(cond)
    cond._waiters.append(None)
    cond._waiters.append(None)
    print(cond)


# Generated at 2022-06-22 03:56:00.431638
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    lock = Lock()
    lock.acquire()
    lock.acquire()
    lock.release()
    lock.release()
    lock.release()


# Generated at 2022-06-22 03:56:09.926532
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    obj = _TimeoutGarbageCollector()
    assert isinstance(obj._waiters, collections.deque)
    assert isinstance(obj._timeouts, int)
    assert obj._timeouts == 0
    obj._waiters.append(Future())
    assert obj._waiters[0].done() == False
    obj._timeouts = 10
    obj._waiters[0].set_result(10)
    assert obj._waiters[0].done() == True
    obj._garbage_collect()
    assert len(obj._waiters) == 0
    assert obj._timeouts == 0

test__TimeoutGarbageCollector()



_NOT_SET = object()



# Generated at 2022-06-22 03:56:13.817177
# Unit test for constructor of class Condition
def test_Condition():
    pass
    # cond = Condition()
    # time = time.time()
    # cond.wait()
    # assert cond._waiters == collections.deque()
    # assert cond._timeouts == 0



# Generated at 2022-06-22 03:56:25.791153
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    from tornado.locks import Lock
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from tornado import gen
    import logging

    l = Lock()

    async def print_num(x):
        print("\nStarting print_num with x={}".format(x))
        await l.acquire()
        try:
            print("print_num with x={} has acquired the lock".format(x))
        finally:
            l.release()
        print("Finished print_num with x={}".format(x))

    # yield values
    async def run():
        print("in run, before lock.acquire")
        await l.acquire()
        try:
            print("in run, after lock.acquire")
        finally:
            l.release()

# Generated at 2022-06-22 03:56:41.433639
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    print("test_")
    """Async iterator method."""
    semaphore = Semaphore()
    with pytest.raises(RuntimeError):
        assert semaphore.__aenter__()
    print("Done")


# Generated at 2022-06-22 03:56:43.065587
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    assert type(_TimeoutGarbageCollector) == types.FunctionType



# Generated at 2022-06-22 03:56:47.138450
# Unit test for method release of class Lock
def test_Lock_release():
    from tornado.locks import Lock
    lock = Lock()
    lock.release()
    print("test_Lock_release")
    print(Lock.__name__)

test_Lock_release()


# Generated at 2022-06-22 03:56:59.376170
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(1)
    print(sem)

# Async with Semaphore()
async def worker(worker_id, sema):
    async with sema:
        print("Worker %d is working" % worker_id)
        #await use_some_resource()

    # Now the semaphore has been released.
    print("Worker %d is done" % worker_id)

async def runner():
    # Join all workers.
    sema = Semaphore(2)
    await gen.multi([worker(i, sema) for i in range(3)])

if __name__ == "__main__":
    print("Started from Semaphore")

# Generated at 2022-06-22 03:57:05.438606
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado.locks import Lock
    from tornado.testing import gen_test, AsyncTestCase

    class LockTest(AsyncTestCase):
        async def test_lock(self):
            lock = Lock()
            async with lock:
                result = await gen.sleep(0.001)
                assert result is None

    with LockTest() as t:
        t.run()


# Generated at 2022-06-22 03:57:08.589961
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # test_semaphore = Semaphore()
    # coro = test_semaphore.__aenter__()
    pass

# Generated at 2022-06-22 03:57:09.198571
# Unit test for constructor of class Condition
def test_Condition():
    Condition()



# Generated at 2022-06-22 03:57:12.293812
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    from tornado.locks import Semaphore
    sem = Semaphore()
    assert sem.__exit__() is None
## Unit test for method release of class Semaphore

# Generated at 2022-06-22 03:57:16.433520
# Unit test for method release of class Lock
def test_Lock_release():
    from collections import deque

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))

    def use_some_resource():
        return futures_q.popleft()


    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Lock

    lock = Lock()

   

# Generated at 2022-06-22 03:57:18.374162
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    event.set()
    assert event.is_set() == True

# Generated at 2022-06-22 03:57:42.623007
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
	with pytest.raises(RuntimeError):
		s = Semaphore()
		with s:
			pass

# Generated at 2022-06-22 03:57:54.779722
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    from concurrent.futures import ThreadPoolExecutor
    from tornado.locks import Lock

    def unit_test_async(a):
        async def async_method():
            await a.acquire()

        return async_method

    lock = Lock()

    with ThreadPoolExecutor(1) as executor:
        m = unit_test_async(lock)
        futures = [executor.submit(lambda: lock.acquire()), m()]
        futures[1].result()
        futures[0].result()

    lock = Lock()

    with ThreadPoolExecutor(1) as executor:
        m = unit_test_async(lock)
        futures = [executor.submit(m()), executor.submit(lambda: lock.acquire())]
        futures[1].result()
        futures[0].result()

# Generated at 2022-06-22 03:58:02.160522
# Unit test for constructor of class Event
def test_Event():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    event = Event()

    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 03:58:08.301020
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    try:
        bs = BoundedSemaphore(0)
        bs.release()
        bs.release()
        bs.release()
        print(bs._value > bs._initial_value)
    except ValueError as e:
        print(e)
    #Output: Semaphore released too many times
test_BoundedSemaphore()


# Generated at 2022-06-22 03:58:15.628104
# Unit test for method notify of class Condition
def test_Condition_notify():
    #Tornado test case
    from tornado.testing import gen_test
    from tornado.locks import Condition
    from tornado.web import RequestHandler, Application
    from tornado import httpserver
    from tornado import ioloop

    c = Condition()
    async def waiter():
        print("I'll wait right here")
        await c.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        c.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        try:
            await gen.multi([waiter(), notifier()])
        except Exception as ex:
            print(ex)
        finally:
            print("All Done")

    # Run the code using a io_loop
    runner()
    iol

# Generated at 2022-06-22 03:58:20.239696
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    # Tests method __exit__ of class _ReleasingContextManager

        semaphore = Semaphore(value=2)

        with (yield semaphore.acquire()):
            pass

        assert semaphore._counter == 2


# Generated at 2022-06-22 03:58:24.710132
# Unit test for method is_set of class Event
def test_Event_is_set():
    print("Executing unit test test_Event_is_set")
    from tornado.ioloop import IOLoop
    from tornado.locks import Event
    event = Event()
    event.set()
    assert event.is_set() == True
    print("Test test_Event_is_set passed!")

# Generated at 2022-06-22 03:58:26.502276
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    """Method __repr__ of class Event"""
    pass

# Generated at 2022-06-22 03:58:28.121552
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(1, 2, 3)


# Generated at 2022-06-22 03:58:31.051489
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    event.wait()
# Line: 101


# Generated at 2022-06-22 03:59:16.291903
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    cond = Condition()
    cond.notify()
    assert repr(cond) == "<Condition waiters[1]>"



# Generated at 2022-06-22 03:59:18.860599
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    event = Event()
    assert event.__repr__() == "<Event clear>"



# Generated at 2022-06-22 03:59:30.415762
# Unit test for method release of class Lock
def test_Lock_release():
    from collections import deque
    from tornado.locks import Lock
    from tornado.ioloop import IOLoop
    from tornado import gen
    from tornado.concurrent import Future
    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(4)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))

    def use_some_resource():
        return futures_q.popleft()

    lock = Lock()


# Generated at 2022-06-22 03:59:33.814593
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    lock = Lock()
    try:
        with lock:
            pass
    except RuntimeError as e:
        assert str(e) == "Use `async with` instead of `with` for Lock"


# Generated at 2022-06-22 03:59:36.845810
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    assert isinstance(condition, Condition)

# Unit tests for method of class Condition

# Generated at 2022-06-22 03:59:37.904878
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    obj = _TimeoutGarbageCollector()


# Generated at 2022-06-22 03:59:47.605946
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()
    condition.notify_all()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print('About to notify')
        condition.notify()
        print('Done notifying')

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-22 03:59:50.332766
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    print(condition)
    print(condition._waiters)
    print(condition._timeouts)
    print(condition.io_loop)



# Generated at 2022-06-22 03:59:53.014165
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    async def __aenter__(self): pass
    assert Semaphore.__aenter__ == __aenter__


# Generated at 2022-06-22 04:00:06.061208
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    import random
    import time
    import threading
    import concurrent.futures

    sem = Semaphore(0)
    num = 15
    num_threads = 5
    num_iterations = 10

    def worker(name):
        for i in range(num_iterations):
            time.sleep(random.random() / 10.0)
            sem.acquire()
            time.sleep(random.random() / 10.0)
            print("worker {} has acquired".format(name))
            time.sleep(random.random() / 10.0)
            print("worker {} is releasing".format(name))
            sem.release()

    # Create threads
    threads = []
    for i in range(num_threads):
        t = threading.Thread(target=worker, args=(i,))
        threads.append

# Generated at 2022-06-22 04:01:38.734941
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bs=BoundedSemaphore(value=2)
    bs.release()
    bs.release()
    try:
        bs.release()
    except ValueError as e:
        print(e)
        print("receive except")
    print("end")


# Generated at 2022-06-22 04:01:45.408235
# Unit test for method clear of class Event
def test_Event_clear():
    from tornado.ioloop import IOLoop
    from tornado.locks import Event

    evt = Event()
    evt.set()
    assert evt.is_set()

    IOLoop.current().run_sync(lambda: evt.wait())
    evt.clear()

    assert not evt.is_set()

    IOLoop.current().run_sync(lambda: evt.wait())



# Generated at 2022-06-22 04:01:49.656352
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    class _Obj:
        def __init__(self) -> None:
            self.release_called = False
        def release(self) -> None:
            self.release_called = True
    obj = _Obj()
    mgr = _ReleasingContextManager(obj)
    mgr.__exit__(None,None,None)
    assert obj.release_called



# Generated at 2022-06-22 04:01:50.989740
# Unit test for constructor of class Semaphore
def test_Semaphore():
    # Arrange
    sem = Semaphore(3)
    # Act
    # Assert


# Generated at 2022-06-22 04:01:58.007534
# Unit test for method is_set of class Event
def test_Event_is_set():
    import pytest
    # Test case data
    event_test_data = [
        (True, True),
        (False, False),
    ]
    @pytest.mark.parametrize("input, expected", event_test_data)
    # Unit test
    def test_Event_is_set(input, expected):
        # Input
        event = Event()
        event._value = input
        # Expected result
        assert event.is_set() == expected



# Generated at 2022-06-22 04:02:08.953079
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    #@Author: John Gooch
    #@Created: 20180308
    #@Updated: 
    #@Version: 1.0
    #@Name: test_Semaphore_release
    #@Description: Unit test for method release of class Semaphore
    import unittest
    import sys
    import os
    import logging
    import threading
    logging.basicConfig( level=logging.DEBUG )
    sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__),"../../")))
    from lib.file_system import FileSystem
    from lib.system import System
    from pprint import pprint
    import time
    import asyncio
    

# Generated at 2022-06-22 04:02:16.152779
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    gen.multi([waiter(), notifier()])
    print("notify test finished")
#Unit test for method wait of class Condition

# Generated at 2022-06-22 04:02:18.324807
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    lock = Lock()
    fut = lock.acquire()
    assert fut._result is None


# Generated at 2022-06-22 04:02:22.083440
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    assert(not event.is_set())
    assert(type(event) == Event)
    event.set()
    assert(event.is_set())
    event.clear()
    assert(not event.is_set())



# Generated at 2022-06-22 04:02:33.440266
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    import asyncio
    from tornado import concurrent
    from tornado import gen
    from tornado import locks
    from tornado import ioloop
    import tornado.testing
    from concurrent.futures import Executor
    from concurrent.futures import Future
    from types import TracebackType
    from typing import Awaitable
    from typing import Callable
    from typing import Iterable
    from typing import Optional
    from typing import Type
    from typing import TypeVar
    from typing import Union
    _T = TypeVar('_T')
    def stop_loop(loop: 'tornado.ioloop.IOLoop') -> None:
        loop.stop()
    def loop_running(loop: 'tornado.ioloop.IOLoop') -> bool:
        return (loop.asyncio_loop.is_running())