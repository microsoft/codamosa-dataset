

# Generated at 2022-06-22 03:53:45.311635
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    pass



# Generated at 2022-06-22 03:53:55.326660
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from locks import _ReleasingContextManager, Lock, Semaphore
    from concurrent.futures._base import _AcquireFailed

    lock = Lock()
    with lock as l:
        assert l == lock
    with lock:
        pass
    with lock:
        pass
    assert not lock.locked()

    sem = Semaphore(1)
    with (yield sem.acquire()) as s:
        assert s == sem
    with (yield sem.acquire()):
        pass
    with (yield sem.acquire()):
        pass
    assert not sem.locked()

    try:
        with (yield fut.failed(LockAcquireFailed())):
            pass
    except LockAcquireFailed:
        assert not lock.locked()
    else:
        assert False



# Generated at 2022-06-22 03:54:07.994622
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    from collections import deque
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future


    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])
    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)
    IOLoop.current().add_callback(simulator, list(futures_q))
    def use_some_resource():
        return futures_q.popleft()
    sem = Semaphore(2)

# Generated at 2022-06-22 03:54:18.355851
# Unit test for method wait of class Event
def test_Event_wait():
    import typing
    from typing import Optional
    from typing import Union
    from tornado.concurrent import Future
    import inspect
    
    
    
    
    
    
    def test_Event_wait_invocation_1() -> None:
        import tornado.gen
        import tornado.ioloop
        from tornado.locks import Event
        from tornado.ioloop import IOLoop
        from tornado.locks import Event
        event = Event()
        async def waiter():
            print("Waiting for event")
            await event.wait()
            print("Not waiting this time")
            await event.wait()
            print("Done")
        async def setter():
            print("About to set the event")
            event.set()
        async def runner():
            await tornado.gen.multi([waiter(), setter()])
        IOLoop.current

# Generated at 2022-06-22 03:54:22.769112
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    x = Semaphore.__repr__(1)
    expected = '<tornado.platform.asyncio.locks.Semaphore object at 0x7f0d8ddb5cf8>'
    assert x == expected


# Generated at 2022-06-22 03:54:23.822079
# Unit test for method clear of class Event
def test_Event_clear():
    e = Event()
    e.set()
    assert e.is_set() == True
    e.clear()
    assert e.is_set() == False


# Generated at 2022-06-22 03:54:26.315591
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    if Semaphore(2).acquire(timeout=None):
        return True
    else:
        return False



# Generated at 2022-06-22 03:54:39.706840
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    # Lock___aenter__() -> (Future[None], Future[None])
    lock = Lock()
    lock_fut = lock.acquire()
    with (yield lock_fut):
        pass
    # Now the lock is released.

    # Lock___aenter__() -> Future[None]
    async with lock:
        pass
    # Now the lock is released.


async def test_method___aenter__Lock(loop: ioloop.IOLoop) -> None:
    lock = Lock()
    lock_fut = lock.acquire()
    with (await lock_fut):
        pass
    # Now the lock is released.

    # Lock___aenter__() -> Future[None]
    async with lock:
        pass
    # Now the lock is released.



# Generated at 2022-06-22 03:54:50.607792
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    """test method of Semaphore: __enter__"""
    # expected causes
    expected_causes = [RuntimeError]

    # expected values
    expected_values = []

    # expected traceback
    expected_traceback = [
        ('<fragment at 0xb7a60a8c>', 'line 4, in test_Semaphore___enter__'),
        ('Semaphore', '__enter__')
    ]

    # test
    exception = None
    try:
        sem = Semaphore(1)
        with sem:
            pass
    except Exception as e:
        exception = e

    assert type(exception) in expected_causes
    assert (exception.args) == tuple(expected_values)

# Generated at 2022-06-22 03:54:52.819501
# Unit test for method set of class Event
def test_Event_set():
    event = Event()
    print(event.is_set())
    event.set()
    print(event.is_set())

# Generated at 2022-06-22 03:55:05.594244
# Unit test for method set of class Event
def test_Event_set():
  e = Event()
  e.set()
  assert (e.is_set())
  e.clear()


# Generated at 2022-06-22 03:55:06.694918
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    return condition


# Generated at 2022-06-22 03:55:09.589004
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    fred = Semaphore(1)
    fred.__aexit__(1,1,1)



# Generated at 2022-06-22 03:55:21.647308
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    from . import gen
    from . import ioloop

    class Future(object):
        def set_result(self, value): pass

        def set_exception(self, value): pass

    class Semaphore(object):

        def __init__(self):
            self._value = 1
            self._waiters = []

        def __repr__(self):
            res = super().__repr__()
            extra = 'locked' if self._value == 0 else 'unlocked,value:%s' % (
                self._value,)
            if self._waiters:
                extra = '%s,waiters:%s' % (extra, len(self._waiters))
            return '<%s [%s]>' % (res[1:-1], extra)


# Generated at 2022-06-22 03:55:25.533388
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()
    # 1st wait
    waiter = c.wait()
    c.notify()
    assert waiter._result == True, "Condition.notify method Failed"

    # 2nd wait
    waiter = c.wait()
    c.notify(2)
    assert waiter._result == True, "Condition.notify method Failed"

    # 3rd wait
    waiter = c.wait(timeout=datetime.datetime.now() + datetime.timedelta(seconds=5))
    c.notify() #notify after 5 sec
    assert waiter._result == False, "Condition.notify method Failed"
    print("Condition.notify method passed")


# Generated at 2022-06-22 03:55:30.254938
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    import functools
    def f(arg):
      print(arg)
    testSemaphore = Semaphore()
    testSemaphore.__exit__ = functools.partial(f, '''__exit__''')
    testSemaphore.__exit__()

# Generated at 2022-06-22 03:55:34.680604
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # This method tests the __repr__ method of the Condition class
    # Condition is a _TimeoutGarbageCollector
    """
    Test for __repr__ method in Condition
    """
    new_Condition = Condition()
    assert new_Condition.__repr__() == "<Condition>"



# Generated at 2022-06-22 03:55:42.180075
# Unit test for method release of class Lock
def test_Lock_release():
    import time
    import tornado.ioloop
    import tornado.concurrent

    lock = Lock()

    async def func():
        await lock.acquire()
        print("Lock acquired")
        time.sleep(1)

    async def runner():
        print("About to acquire")
        await func()
        print("About to release")
        lock.release()

    tornado.ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 03:55:52.526369
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    import tornado.locks
    import tornado.concurrent
    import tornado.ioloop
    import tornado.testing
    import types
    import datetime
    import collections.abc
    import typing
    import weakref
    import abc
    import collections
    import unittest
    import contextlib
    import gc
    class Counter(dict):
        def __missing__(self, key):
            return 0
    class _TimeoutGarbageCollector(object):
        def __init__(self):
            self._waiters = collections.deque()  # type: typing.Deque[Future[Any]]
            self._cleanup_handle = None  # type: typing.Optional[IOLoop.Handle]
            self._refcount = 0  # type: int
        def __del__(self):
            self.stop()

# Generated at 2022-06-22 03:55:54.780457
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    try:
        pass
    finally:
        lock.release()


# Generated at 2022-06-22 03:56:16.543061
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    asyncio.set_event_loop(None)
    import asyncio
    from tornado.locks import Semaphore
    from tornado.platform.asyncio import to_asyncio_future
    import inspect
    from unittest.mock import create_autospec
    from typing import Optional, Type

    result = object()
    future = asyncio.Future()  # type: asyncio.Future
    future.set_result(result)

    def acquire() -> Awaitable[None]:
        return to_asyncio_future(future)

    sem = Semaphore()
    sem.acquire = acquire
    sem.acquire = acquire
    with create_autospec(Semaphore.release, spec_set=True) as mock_release:
        mock_release.return_value = None
        sem.release = mock_

# Generated at 2022-06-22 03:56:19.444346
# Unit test for method clear of class Event
def test_Event_clear():
    import pytest
    import time
    event=Event()
    event.set()
    starttime=time.time()
    gen.with_timeout(0.01,event.wait(),timeout_value=None)
    elapsedtime=time.time()-starttime
    assert elapsedtime<0.01
    event.clear()
    starttime=time.time()
    gen.with_timeout(0.01,event.wait(),timeout_value=None)
    elapsedtime=time.time()-starttime
    assert elapsedtime>=0.01


# Generated at 2022-06-22 03:56:21.870477
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    __tracebackhide__ = True  # for #15214
    with pytest.raises(RuntimeError):
        with Lock():
            pass


# Generated at 2022-06-22 03:56:24.766306
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    print('-'*10)
    print('Event().__repr__()')
    print('-'*10)
    print(Event().__repr__())

# Generated at 2022-06-22 03:56:27.397141
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    instance = Lock()
    expected = "<%s _block=%s>" % (instance.__class__.__name__, instance._block)
    assert instance.__repr__() == expected

# Generated at 2022-06-22 03:56:38.614212
# Unit test for method wait of class Condition
def test_Condition_wait():
    import time
    import numpy as np
    print("in test_Condition_wait")
    condition = Condition()
    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]

    ioloop.IOLoop.current().run_sync(runner)

########################################################################################################################



# Generated at 2022-06-22 03:56:39.951973
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert not event.is_set()

# Generated at 2022-06-22 03:56:41.975436
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    with pytest.raises(NotImplementedError):
        Semaphore().acquire()



# Generated at 2022-06-22 03:56:43.142807
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    import asyncio
    condition = Condition()
    condition.notify_all()
    return True



# Generated at 2022-06-22 03:56:53.474036
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    import unittest
    import _io
    import io
    # Method __exit__ of class Lock
    class Test__exit__(unittest.TestCase):

        # No error messages
        def test(self):
            err = _io.StringIO()
            with contextlib.redirect_stderr(err):
                with (yield lock.acquire()):
                    # Do something holding the lock.
                    pass
            self.assertEqual(err.getvalue(), '')
    # __main__
    if __name__ == '__main__':
        unittest.main()



# Generated at 2022-06-22 03:57:16.564380
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert not event.is_set()

# Generated at 2022-06-22 03:57:22.293622
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    import tornado.locks

    # Test with default args
    lock = tornado.locks.Lock()
    assert repr(lock) == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"

    # Test with non-default args
    lock = tornado.locks.Lock()
    assert repr(lock) == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"



# Generated at 2022-06-22 03:57:24.214839
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    print('\n# Unit test for method __repr__ of class Semaphore')
    value = Semaphore()
    print(value)

# Generated at 2022-06-22 03:57:30.153113
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    class A(object):
        def __init__(self):
            self.value = False
        def release(self):
            self.value = True
    a = _ReleasingContextManager(A())
    assert a.__exit__() == None
    assert a._obj.value == True



# Generated at 2022-06-22 03:57:32.237765
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    flag = event.wait()
    assert flag is False

# Generated at 2022-06-22 03:57:34.914989
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    event.set()
    print(event.is_set())
    event.clear()
    print(event.is_set())

# Generated at 2022-06-22 03:57:45.633128
# Unit test for method clear of class Event
def test_Event_clear():
    # test_set
    e = Event()
    e.set()
    assert e.is_set()

    # test_clear
    e.clear()
    assert not e.is_set()

    # test_wait_immediate
    e.set()
    assert e.wait() is None

    # test_wait_timeout_immediate
    assert e.wait(datetime.timedelta(seconds=0.1)) is None

    # test_wait_timeout_clear
    e.clear()
    IOLoop.current().run_sync(
        lambda: e.wait(datetime.timedelta(seconds=0.1))
    )



# Generated at 2022-06-22 03:57:49.839800
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition()
    print("condition=", condition)
    condition.notify_all()
    print("condition=", condition)
    condition.wait()
    print("condition=", condition)
    condition.wait()
    print("condition=", condition)
    condition.notify(100)
    print("condition=", condition)
    condition.notify_all()
    print("condition=", condition)


# Generated at 2022-06-22 03:57:51.943397
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    garbageCollector = _TimeoutGarbageCollector()
    return garbageCollector


# Generated at 2022-06-22 03:57:53.259306
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    pass


# Generated at 2022-06-22 03:58:35.958247
# Unit test for method is_set of class Event
def test_Event_is_set():
	event = Event()
	assert event.is_set() == False
	event.set()
	assert event.is_set() == True


# Generated at 2022-06-22 03:58:40.730620
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    value = None
    obj = Semaphore(value)
    try:
        obj.__exit__(None, None, None)
        return obj
    except RuntimeError:
        return obj

# Testing...
print(test_Semaphore___exit__())


# Generated at 2022-06-22 03:58:43.956567
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False



# Generated at 2022-06-22 03:58:50.350481
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    value = 0
    waiters = []# type: List[Future]
    _value = 1
    waiter = Future()
    waiters.insert(0,waiter)
    waiters[0].set_result(_ReleasingContextManager(self))


# Generated at 2022-06-22 03:58:55.567600
# Unit test for method wait of class Event
def test_Event_wait():
    import tornado.testing

    class TestEvent(tornado.testing.AsyncTestCase):
        @tornado.testing.gen_test
        async def test_event_wait(self):
            event = Event()
            task = [event.wait() for _ in range(10)]
            event.set()
            await gen.multi(task)
            self.assertEqual(len(task), 0)

    tornado.testing.main()

# Generated at 2022-06-22 03:59:01.602014
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    from tornado.locks import Semaphore
    from tornado.testing import AsyncTestCase, gen_test
    # This code will be executed in a thread
    import time
    import threading

    # Define a function for the thread
    def print_time( threadName, delay):
       count = 0
       while count < 5:
          time.sleep(delay)
          count += 1
          print ("%s: %s" % ( threadName, time.ctime(time.time()) ))
    
    
    
    
    # Create two threads as follows
    try:
       _thread.start_new_thread( print_time, ("Thread-1", 2, ) )
       _thread.start_new_thread( print_time, ("Thread-2", 4, ) )
    except:
       print ("Error: unable to start thread")

# Generated at 2022-06-22 03:59:06.572349
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()

    # ensure that lock is the instance of Lock class
    assert isinstance(lock, Lock)

    # ensure that lock has no any attributes
    assert len(lock.__dict__) == 0

    return lock


# Generated at 2022-06-22 03:59:09.258695
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    assert lock.__repr__() == "<Lock _block=<BoundedSemaphore [unlocked,value:1]>>"

test_Lock()



# Generated at 2022-06-22 03:59:14.918071
# Unit test for constructor of class Event
def test_Event():
    e = Event()
    assert not e.is_set()
    e.set()
    assert e.is_set()
    e.clear()
    assert not e.is_set()
    assert type(e.wait(0)) == Future


# Generated at 2022-06-22 03:59:18.651000
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    

    condition = Condition()
    condition.notify()
    assert repr(condition) == '<Condition waiters[1]>'


# Generated at 2022-06-22 04:00:47.041289
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    obj = _ReleasingContextManager(None)
    assert obj


# Generated at 2022-06-22 04:00:50.624471
# Unit test for method notify of class Condition
def test_Condition_notify():
    c = Condition()
    assert c._waiters == collections.deque()
    c.notify()
    assert c._waiters == collections.deque()


# Generated at 2022-06-22 04:00:56.064005
# Unit test for method notify of class Condition
def test_Condition_notify():
    condition = Condition()
    aFuture = Future()
    condition._waiters.append(aFuture)
    aWaiter = Future()
    condition._waiters.append(aWaiter)
    waiter = Future()
    condition._waiters.append(waiter)
    condition.notify(2)
    assert not aFuture.done()
    assert aWaiter.done()
    assert waiter.done()

# Generated at 2022-06-22 04:01:01.387329
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    '''
    Unit test for method __enter__() of class Semaphore
    '''
    _tc_verify_exception(
        Semaphore(),
        RuntimeError,
        RuntimeError("Use 'async with' instead of 'with' for Semaphore"),
    )

# Generated at 2022-06-22 04:01:13.628870
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    import tornado.ioloop
    import tornado.locks
    import tornado.testing
    
    
    
    class TestSemaphore(tornado.testing.AsyncTestCase):
        
        def test_Semaphore___exit__(self):
            # type: () -> None
            import tornado.concurrent
            import typing
            
            class _ReleasingContextManager(object):
    
                def __init__(self, obj):
                    # type: (typing.Any) -> None
                    self._obj = obj
    
                def __enter__(self):
                    # type: () -> None
                    pass
    

# Generated at 2022-06-22 04:01:17.664526
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    class Test(BoundedSemaphore):
        def __init__(self, value: int = 2) -> None:
            super().__init__(value=value)
            self._initial_value = value
            
    obj = Test()
    obj.release()
    obj.release()
    # the next line will fail if the release is called more than once
    assert obj._value == obj._initial_value


# Generated at 2022-06-22 04:01:26.946972
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    c = 0
    l = Lock()
    async def f1():
        nonlocal c
        await l.acquire()
        c += 1
        await gen.sleep(0.1)
        c += 1
        l.release()

    async def f2():
        nonlocal c
        await l.acquire()
        c += 1
        await gen.sleep(0.1)
        c += 1
        l.release()

    async def test():
        await gen.multi([f1(), f2()])

    IOLoop.current().run_sync(test)
    assert c == 6, c


# Generated at 2022-06-22 04:01:30.499270
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    assert (event.is_set() == False)
    event.set()
    assert (event.is_set() == True)
    event.clear()
    assert (event.is_set() == False)



# Generated at 2022-06-22 04:01:32.873512
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    lock = locks.Lock()
    async def f():
        lock.acquire()
    f()



# Generated at 2022-06-22 04:01:36.195711
# Unit test for method __repr__ of class Event
def test_Event___repr__():
    import time
    import tornado.ioloop
    e = Event()
    time.sleep(1)
    e.is_set()
    e.set()
    e.clear()

