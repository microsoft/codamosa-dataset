

# Generated at 2022-06-22 03:53:51.871948
# Unit test for constructor of class Event
def test_Event(): 
    event = Event()
    assert event._value == False # Test if the value of the internal flag is false
    assert len(event._waiters) == 0 # Test if the waiters list is empty


# Generated at 2022-06-22 03:53:52.920853
# Unit test for constructor of class Condition
def test_Condition():
    c = Condition()
    assert c is not None


# Generated at 2022-06-22 03:53:59.762164
# Unit test for method clear of class Event
def test_Event_clear():
    # create the event object
    e = Event()
    if e.is_set():
        raise Exception("Should be false")
    # set the event
    e.set()
    if not e.is_set():
        raise Exception("Should be true")
    # clear the event
    e.clear()
    if e.is_set():
        raise Exception("Should be false")


# Generated at 2022-06-22 03:54:03.786660
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem =  Semaphore(1)
    sem.acquire()
    print("Semaphore value is: "+str(sem._value))
    print("Test case passed")


# Generated at 2022-06-22 03:54:04.529302
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    BoundedSemaphore(value=1)

# Generated at 2022-06-22 03:54:10.259962
# Unit test for constructor of class Condition
def test_Condition():
    # type: () -> None
    condition = Condition()
    assert isinstance(condition, Condition)
    assert isinstance(condition._waiters, collections.deque)
    assert isinstance(condition._timeouts, int)
    assert isinstance(condition.io_loop, ioloop.IOLoop)


# Generated at 2022-06-22 03:54:12.660813
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    from tornado import locks
    lock = locks.Lock()
    lock.__enter__()



# Generated at 2022-06-22 03:54:15.697026
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    # Create the object
    lock = Lock()
    # Call the method
    try:
        lock.__enter__()
    except RuntimeError:
        pass
    else:
        assert False, "Did not raise RuntimeError."


# Generated at 2022-06-22 03:54:21.184896
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    with pytest.raises(ValueError):
        sem = Semaphore(value=-1)
    sem = Semaphore(value=3)
    sem.release()
    assert sem._value == 4
    sem.release()
    assert sem._value == 5

# Generated at 2022-06-22 03:54:24.528218
# Unit test for method release of class Lock
def test_Lock_release():
    # lock = Lock() must be called to create lock object
    # lock.release() must be called to release lock
    # lock.release() must not be called when lock is locked
    pass


# Generated at 2022-06-22 03:54:41.675366
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True
    event.clear()
    assert event.is_set() == False
    return
    
    

# Generated at 2022-06-22 03:54:52.447799
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    from tornado.testing import AsyncTestCase, gen_test, bind_unused_port, main
    import socket
    class _TimeoutGarbageCollector_Test(AsyncTestCase):
        def _check(self, c):
            c._timeouts = 5
            c._waiters[0].set_result(1)
            self.assertEqual(len(c._waiters), 1)
            c._garbage_collect()
            self.assertEqual(len(c._waiters), 0)
            c._timeouts = 5
            c._waiters.append(self.make_future())
            self.assertEqual(len(c._waiters), 1)
            c._garbage_collect()
            self.assertEqual(len(c._waiters), 1)


# Generated at 2022-06-22 03:55:04.827725
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    from tornado import gen
    from tornado import locks
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    def use_some_resource():
        return Future()

    lock = locks.Lock()
    
    
    
    
    
    
    
    
    
    
    futures = []
    async def worker(worker_id):
        with (await lock.acquire()):
            print("Worker %d is working" % worker_id)
            futures.append(use_some_resource())
        print("Worker %d is done" % worker_id)
    
    
    
    
    
    
    
    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])
    
    
    
    


# Generated at 2022-06-22 03:55:09.685529
# Unit test for constructor of class Event
def test_Event():
    '''
    Test the constructor of class Event
    '''
    a = Event()


if typing.TYPE_CHECKING:
    SemaphoreType = typing.TypeVar("SemaphoreType", bound="Semaphore")



# Generated at 2022-06-22 03:55:22.033271
# Unit test for method release of class Lock
def test_Lock_release():
    import time
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Lock
    import sys

    fut = Future()

    @gen.coroutine
    def run_release():
        lock = Lock()
        # lock._block.release()
        try:
            lock.release()
        except RuntimeError:
            fut.set_result(1)
        else:
            fut.set_result(0)
        raise gen.Return(lock)

    @gen.coroutine
    def test_release():
        yield run_release()


    res = IOLoop.current().run_sync(test_release)

    assert res == 1
    print('Method release of class Lock is ok!')

    # Unit test for method acquire of class Lock
    fut = Future()


# Generated at 2022-06-22 03:55:25.748507
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    print(event)
    print(event._value)
    print(event._waiters)
    event.set()
    event.clear()
    event.is_set()

# Generated at 2022-06-22 03:55:37.413137
# Unit test for constructor of class Event
def test_Event():
    import tornado.ioloop
    import tornado.locks
    import tornado.testing
    import unittest

    class TestEvent(tornado.testing.AsyncTestCase):
        def setUp(self):
            super(TestEvent, self).setUp()
            self.event = tornado.locks.Event()

        def test_is_set(self):
            self.assertFalse(self.event.is_set())

        def test_set(self):
            self.event.set()
            self.assertTrue(self.event.is_set())

        def test_clear(self):
            self.event.set()
            self.event.clear()
            self.assertFalse(self.event.is_set())

        def test_wait(self):
            self.event.set()

# Generated at 2022-06-22 03:55:40.491170
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    assert isinstance(condition, Condition)
    assert isinstance(condition, _TimeoutGarbageCollector)


# Generated at 2022-06-22 03:55:44.083846
# Unit test for method is_set of class Event
def test_Event_is_set():
    e = Event()
    assert not e.is_set()
    e.set()
    assert e.is_set()
    e.clear()
    assert not e.is_set()

# Generated at 2022-06-22 03:55:47.173024
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert (event.is_set()==False)
    event.set()
    assert (event.is_set()==True)
test_Event_is_set()

# Generated at 2022-06-22 03:56:23.772633
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    l = Lock()
    assert l._block._value == 1
    l.release()
    assert l._block._value == 1
    l.release()
    assert l._block._value == 2
    l.release()
    assert l._block._value == 3
    l.release()
    assert l._block._value == 4
    l.release()
    assert l._block._value == 5
    l.release()
    assert l._block._value == 5
    l.release()
    assert l._block._value == 5
    assert l._block._waiters == [], "The semaphore _waiters array should be empty"
    l.release()
    assert l._block._value == 5
    assert l._block._waiters == [], "The semaphore _waiters array should be empty"
    l.release()

# Generated at 2022-06-22 03:56:29.826646
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    async def test_Semaphore_acquire():
        from tornado import gen
        from tornado.ioloop import IOLoop
        from tornado.locks import Semaphore
        sem = Semaphore(1)
        async with sem:
            await gen.sleep(0)

    IOLoop.current().run_sync(test_Semaphore_acquire)

# Generated at 2022-06-22 03:56:35.230908
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    # release() is called which is supposed to make the counter value to zero and make all the waiters satisfied
    sem = Semaphore()
    # Test for semaphore initial value
    assert sem._value == 1
    # Test for wake up all waiters
    assert not sem._waiters
    # Test for decrement counter value
    # Test for return the semaphore itself as context manager
    assert await sem.acquire() == _ReleasingContextManager(sem)
    # Test for semaphore initial value
    assert sem._value == 0
    # Test for semaphore waiters length
    assert len(sem._waiters) == 0



# Generated at 2022-06-22 03:56:38.469956
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    assert not event.is_set()
    event.set()
    assert event.is_set()
    event.clear()
    assert not event.is_set()


# Generated at 2022-06-22 03:56:39.452992
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore()

# Generated at 2022-06-22 03:56:50.862977
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    s = Semaphore(value=0)
    try:
        assert s._value == 0
        assert not s._waiters
        s.__exit__(None, None, None)
        raise AssertionError('Semaphore released when there are no ressources')
    except RuntimeError:
        assert s._value == 0
        assert not s._waiters
    s = Semaphore(value=1)
    try:
        assert s._value == 1
        assert not s._waiters
        s.__exit__(None, None, None)
        assert s._value == 0
        assert not s._waiters
    except RuntimeError:
        assert False



# Generated at 2022-06-22 03:57:02.712763
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    bounded_sem = BoundedSemaphore(2)
    assert bounded_sem._value == 2
    assert bounded_sem._initial_value == 2
    assert bounded_sem.acquire()
    assert bounded_sem._value == 1
    assert bounded_sem._initial_value == 2
    assert bounded_sem.acquire()
    assert bounded_sem._value == 0
    assert bounded_sem._initial_value == 2
    assert bounded_sem.acquire()
    assert bounded_sem._value == -1
    assert bounded_sem._initial_value == 2
    bounded_sem.release()
    assert bounded_sem._value == 0
    assert bounded_sem._initial_value == 2
    bounded_sem.release()
    assert bounded_sem._value == 1
    assert bounded_sem._initial_value == 2
    bounded_sem.release

# Generated at 2022-06-22 03:57:14.225420
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    def acquire_mock():
        semaphore.acquire.return_value=Future()
        semaphore.acquire.return_value.done.return_value=False
        semaphore.acquire.return_value.result=None
        semaphore.acquire.return_value.exception=None
        semaphore.acquire.return_value.set_result=MagicMock()
        semaphore.acquire.return_value.set_exception=MagicMock()
        semaphore.acquire.return_value.add_done_callback=MagicMock()
        return semaphore.acquire.return_value

    semaphore= Semaphore()
    semaphore.acquire= MagicMock()
    semaphore.release= MagicMock()
    semaphore.timeout= MagicM

# Generated at 2022-06-22 03:57:21.765804
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    print("# Unit test for method release of class Semaphore")
    s = Semaphore()
    assert s.is_set() is False
    s.release()
    assert s.is_set() is True
    s.release()
    assert s.is_set() is True
    s.clear()
    assert s.is_set() is False
    s.release()
    assert s.is_set() is True
    s.release()
    assert s.is_set() is True
    s.release()
    assert s.is_set() is True
    print("# test_Semaphore_release() passed !")


# Generated at 2022-06-22 03:57:32.569340
# Unit test for method release of class Lock
def test_Lock_release():
    from tornado import locks
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    lock = locks.Lock()

    async def f():
        await lock.acquire()
        print("f acquired the lock")
        f = Future()
        IOLoop.current().add_callback(lambda : f.set_result("f"))
        return await f

    async def g():
        print("g is waiting for the lock")
        await lock.acquire()
        print("g acquired the lock")
        g = Future()
        IOLoop.current().add_callback(lambda : g.set_result("g"))
        return await g

    tasks = [f(), g()]
    result = IOLoop.current().run_sync(lambda : gen.multi(tasks))

# Generated at 2022-06-22 03:59:06.614216
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    obj = _ReleasingContextManager(1)
    obj.__enter__()

# Generated at 2022-06-22 03:59:08.629031
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sema = Semaphore(10)
    assert sema._value == 10
    assert sema._waiters == []

# Generated at 2022-06-22 03:59:10.470666
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    lock = Lock()
    with lock:
        pass


# Generated at 2022-06-22 03:59:18.004635
# Unit test for constructor of class Semaphore
def test_Semaphore():
   def try_Semaphore(value: int = 1):
      try:
         Semaphore(value)
      except ValueError:
         return False
      return True

   assert(try_Semaphore(1) == True)
   assert(try_Semaphore(0) == True)
   assert(try_Semaphore(-1) == False)


# Generated at 2022-06-22 03:59:21.326211
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    sem = Semaphore()
    assert repr(sem) == "<Semaphore unlocked,value:1>"
    async def main():
        sem.acquire()
        assert repr(sem) == "<Semaphore locked>"
        sem.release()
        assert repr(sem) == "<Semaphore unlocked,value:1>"
    asyncio.get_event_loop().run_until_complete(main())


# Generated at 2022-06-22 03:59:24.194572
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    semaphore1 = Semaphore(2)
    async def async_test():
        await semaphore1.__aenter__()
    IOLoop.current().run_sync(async_test)

# Generated at 2022-06-22 03:59:32.616217
# Unit test for method wait of class Condition
def test_Condition_wait():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)



# Generated at 2022-06-22 03:59:36.846985
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    # Create an instance of Condition
    condition = Condition()
    print("Wake all waiters")
    condition.notify_all()
    print("Done")

test_Condition_notify_all()


# Generated at 2022-06-22 03:59:48.523939
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    from collections import deque

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future

    # Ensure reliable doctest output: resolve Futures one at a time.
    futures_q = deque([Future() for _ in range(3)])

    async def simulator(futures):
        for f in futures:
            # simulate the asynchronous passage of time
            await gen.sleep(0)
            await gen.sleep(0)
            f.set_result(None)

    IOLoop.current().add_callback(simulator, list(futures_q))

    def use_some_resource():
        return futures_q.popleft()

    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Lock

    lock = Lock()


# Generated at 2022-06-22 03:59:52.564594
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    class R():
        def __init__(self) -> None:
            self.x = False
        def release(self) -> None:
            self.x = True
    r = R()
    with _ReleasingContextManager(r) as _:
        pass
    assert r.x



# Generated at 2022-06-22 04:00:56.269054
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    def __init__(self) -> None:
        super().__init__()
        self.io_loop = ioloop.IOLoop.current()
    class Condition(_TimeoutGarbageCollector):
        def __init__(self) -> None:
            super().__init__()
            self.io_loop = ioloop.IOLoop.current()
    def wait(self, timeout: Optional[Union[float, datetime.timedelta]] = None) -> Awaitable[bool]:
        """Wait for `.notify`.
        Returns a `.Future` that resolves ``True`` if the condition is notified,
        or ``False`` after a timeout.
        """        
        waiter = Future()  # type: Future[bool]
        self._waiters.append(waiter)

# Generated at 2022-06-22 04:00:57.253587
# Unit test for constructor of class Event
def test_Event():
    Event()
    return True


# Generated at 2022-06-22 04:00:59.733679
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    obj = Lock()
    assert isinstance(obj.__repr__(), str)

# Generated at 2022-06-22 04:01:02.025451
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    sem = Semaphore()
    with pytest.raises(RuntimeError):
        sem.__enter__()


# Generated at 2022-06-22 04:01:10.871543
# Unit test for method wait of class Condition
def test_Condition_wait():
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        return await gen.multi([waiter(), notifier()])

    ioloop.IOLoop.current().run_sync(runner)

    assert True


# Generated at 2022-06-22 04:01:12.198762
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    sem = Semaphore()
    async with sem:
        pass

# Generated at 2022-06-22 04:01:22.349885
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    from tornado.ioloop import IOLoop
    from tornado.concurrent import Future
    from tornado.locks import Lock
    lock = Lock()
    # Lock is unlocked
    assert lock._block._value == 1
    fut = lock.acquire()
    # Lock is locked
    assert lock._block._value == 0
    try:
        assert len(lock._block._waiters) == 0
    except Exception as e:
        raise e
    lock.release()
    # Lock is unlocked
    assert lock._block._value == 1
    try:
        assert len(lock._block._waiters) == 0
    except Exception as e:
        raise e

# Generated at 2022-06-22 04:01:27.671751
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    from tornado import locks
    lock = locks.Lock()

    def f():
        async with lock:
            # Do something holding the lock.
            return True

    def f2():
        with (yield lock.acquire()):
            # Do something holding the lock.
            return True

    assert ioloop.IOLoop.current().run_sync(f) is True
    assert ioloop.IOLoop.current().run_sync(f2) is True



# Generated at 2022-06-22 04:01:29.182615
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    pass  # no-op



# Generated at 2022-06-22 04:01:38.438230
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    """
    This test tests if the method __aenter__ of class Lock works as expected
    """
    # Expected result for locking
    expected_result=True
    # Expected result for the release
    expected_result_release=True
    # Creation of a lock object
    lock=Lock()
    # Locking the lock
    actual_result=lock.acquire()
    # If the lock is locked, then it is released and the program return a True value
    if actual_result:
        lock.release()
    return actual_result==expected_result and actual_result_release==expected_result_release


# Generated at 2022-06-22 04:02:39.379287
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    result = Semaphore._TimeoutGarbageCollector.release(Semaphore())
    assert result is None


# Generated at 2022-06-22 04:02:50.521957
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    from unittest.mock import patch, MagicMock
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    import inspect
    import types

    # Create a mock Future object and replace the yield point with a future
    # object
    future_mock = MagicMock()
    future_mock.__await__.return_value.__iter__.return_value = iter([future_mock])
    future_mock.done.return_value = False
    future_mock.__await__.return_value.__next__.return_value = '_ReleasingContextManager'
    future_mock.add_done_callback.return_value = None
    future_mock.set_result.return_value = None

# Generated at 2022-06-22 04:02:55.148589
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    n = 2

    value = BoundedSemaphore(n=2)
    if value._initial_value != 2 or value._value != 2:
        raise ValueError('BoundedSemaphore.__init__ failed')

if __name__ == '__main__':
    test_BoundedSemaphore()

# Generated at 2022-06-22 04:02:57.850719
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    class LockMock(object):
        def __init__(self):
            pass
    locks.Lock.__enter__(LockMock())

# Generated at 2022-06-22 04:03:04.682058
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(value = 1)
    print(repr(sem))
    #print(sem.__enter__())
    sem.release()
    print(repr(sem))
    sem.release()
    print(repr(sem))
    sem.acquire(timeout = None)
    print(repr(sem))
    #print(sem.__exit__(None, None, None))
    print(repr(sem))

#if __name__ == '__main__':
#    test_Semaphore()


# Generated at 2022-06-22 04:03:10.538921
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert repr(condition) == "<Condition>"
    waiter = Future()  # type: Future[bool]
    condition._waiters.append(waiter)
    assert repr(condition) == "<Condition waiters[1]>"
    assert repr(condition) == "<Condition waiters[1]>"


# Generated at 2022-06-22 04:03:14.703481
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    assert isinstance(condition, Condition)
    assert isinstance(condition._waiters, collections.deque)
    assert isinstance(condition._timeouts, int)



# Generated at 2022-06-22 04:03:16.112589
# Unit test for method set of class Event
def test_Event_set():
    Event.set(Event)
    assert Event.is_set(Event)
