

# Generated at 2022-06-22 03:53:41.668286
# Unit test for constructor of class Semaphore
def test_Semaphore():
    sem = Semaphore(0)
    assert(sem._value == 0)
    assert(sem._waiters == [])
    sem = Semaphore(1)
    assert(sem._value == 1)
    assert(sem._waiters == [])
    sem = Semaphore(2)
    assert(sem._value == 2)
    assert(sem._waiters == [])
    with pytest.raises(ValueError):
        Semaphore(-1)


# Generated at 2022-06-22 03:53:52.431082
# Unit test for method __repr__ of class Semaphore
def test_Semaphore___repr__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Semaphore
    sem = Semaphore(2)
    print(repr(sem))
    async def worker(worker_id):
        await sem.acquire()
        try:
            print("Worker %d is working" % worker_id)
        finally:
            print("Worker %d is done" % worker_id)
            sem.release()

    async def runner():
        # Join all workers.
        await gen.multi([worker(i) for i in range(3)])

    IOLoop.current().run_sync(runner)

# Generated at 2022-06-22 03:53:56.676054
# Unit test for constructor of class _TimeoutGarbageCollector
def test__TimeoutGarbageCollector():
    # type: () -> None
    tgc = _TimeoutGarbageCollector()

    assert(tgc._waiters == collections.deque())
    assert(tgc._timeouts == 0)



# Generated at 2022-06-22 03:54:00.832883
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    bs = BoundedSemaphore(value=0)
    bs.release()
    #print("bs._value = {}".format(bs._value))
    try:
        bs.release()
    except ValueError as ve:
        print(ve)
    #print("bs._value = {}".format(bs._value))

# Generated at 2022-06-22 03:54:06.923418
# Unit test for method notify of class Condition
def test_Condition_notify():
    """Test method notify of class Condition"""
    io_loop = ioloop.IOLoop.current()
    condition = Condition()
    f = io_loop.run_sync(lambda: condition.notify())
    
    assert f == None
    print("Test method notify of class Condition done!")
test_Condition_notify()



# Generated at 2022-06-22 03:54:09.695463
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from . import Lock
    lock = Lock()
    with lock:
        pass
    lock



# Generated at 2022-06-22 03:54:18.987067
# Unit test for method wait of class Condition
def test_Condition_wait():
    import random

    async def cond_test(cond):
        print('cond_test start')
        started = ioloop.IOLoop.current().time()

        await gen.sleep(0.1)  # yield

        await cond.wait()

        ended = ioloop.IOLoop.current().time()
        print('cond_test end. It took', ended - started)

    async def cond_test_timeout(cond):
        print('cond_test_timeout start')
        started = ioloop.IOLoop.current().time()

        await gen.sleep(0.1)  # yield

        await cond.wait(timeout=0.1)

        ended = ioloop.IOLoop.current().time()
        print('cond_test_timeout end. It took', ended - started)


# Generated at 2022-06-22 03:54:20.800101
# Unit test for constructor of class Condition
def test_Condition():
    cond = Condition()
    return cond

# Generated at 2022-06-22 03:54:32.059088
# Unit test for method wait of class Condition
def test_Condition_wait():
    done = []

    def f():
        print('hello')
        done.append(True)

    async def runner():
        async def waiter():
            print("I'll wait right here")
            await condition.wait()
            print("I'm done waiting")

        async def notifier():
            print("About to notify")
            condition.notify()
            print("Done notifying")

        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    condition = Condition()
    IOLoop.current().add_callback(f)
    IOLoop.current().run_sync(runner)
    print(done)

test_Condition_wait()


# Generated at 2022-06-22 03:54:35.452583
# Unit test for constructor of class Condition
def test_Condition():
    condition = Condition()
    assert condition.io_loop.__class__ == ioloop.IOLoop
    assert condition._timeouts == 0
    assert condition._waiters.__class__ == collections.deque


# Generated at 2022-06-22 03:54:52.690720
# Unit test for method release of class Lock
def test_Lock_release():
   x = Lock()
   x._block = BoundedSemaphore()
   x._block._initial_value = 1
   x._block._value = 0
   x._block._waiters = []
   x._block.release = MagicMock(side_effect = RuntimeError('release unlocked lock'))
   assertRaises(RuntimeError, x.release)
   assert x._block.release.called



# Generated at 2022-06-22 03:55:05.016334
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    from tornado.ioloop import IOLoop
    from tornado.gen import coroutine
    from tornado.locks import Condition
    import orm_stubs

    class StubIOLoop(orm_stubs.StubIOLoop):
        def time(self) -> int:
            return 0

        def add_timeout(self, callback: orm_stubs.stubify(types.FunctionType), deadline: int, io_loop: orm_stubs.stubify(IOLoop)) -> None:
            return

    @coroutine
    def main() -> None:
        StubIOLoop.reset()
        condition = Condition()
        await condition.wait()
        condition.notify_all()

    condition = Condition()
    assert repr(condition) == "<Condition>"
    condition._waiters.append(Future())
    condition._wait

# Generated at 2022-06-22 03:55:08.074401
# Unit test for method set of class Event
def test_Event_set():
    event = Event();
    print(event.is_set());
    event.set();
    print(event.is_set());
#test_Event_set();



# Generated at 2022-06-22 03:55:08.827043
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()
    assert event.is_set() == False

# Generated at 2022-06-22 03:55:14.262750
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    condition = Condition()
    assert str(condition) == '<Condition>'
    assert repr(condition) == '<Condition>'
    condition._waiters.append(Future())
    assert str(condition) == '<Condition waiters[1]>'
    assert repr(condition) == '<Condition waiters[1]>'



# Generated at 2022-06-22 03:55:22.335909
# Unit test for method wait of class Event
def test_Event_wait():
    #test call signature
    event = Event()
    global timeout
    def on_timeout() -> None:
        global timeout
        timeout=1
    global timeout
    timeout = 0
    timeout_handle = event.io_loop.add_timeout(event._time_out, on_timeout)
    #event.wait()
    event.io_loop.add_future(event.wait(),lambda fut: event.io_loop.remove_timeout(timeout_handle))
    return True
assert test_Event_wait()



# Generated at 2022-06-22 03:55:32.997676
# Unit test for method notify of class Condition
def test_Condition_notify():
    # Create a new object of class Condition
    condition = Condition()
    print(condition)

    # Define a coroutine
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")

    # Define a coroutine
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    # Define a coroutine
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    # Run the coroutine
    ioloop.IOLoop.current().run_sync(runner)


# Generated at 2022-06-22 03:55:33.841582
# Unit test for constructor of class Lock
def test_Lock():
    lock = Lock()
    lock.release()


# Generated at 2022-06-22 03:55:35.460260
# Unit test for method __repr__ of class Lock
def test_Lock___repr__():
    # Initialization
    Lock_obj = Lock()



# Generated at 2022-06-22 03:55:38.009975
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    sem = BoundedSemaphore(1)
    sem.release()
    sem.release()



# Generated at 2022-06-22 03:56:00.753868
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()
    result = None

    @gen.coroutine
    def waiter():
        print("I'll wait right here")
        result = yield condition.wait()
        print("I'm done waiting")
        return result

    @gen.coroutine
    def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
        return

    @gen.coroutine
    def runner():
        # Wait for waiter() and notifier() in parallel
        yield gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)
    print(result)
    return



# Generated at 2022-06-22 03:56:12.667443
# Unit test for method wait of class Condition
def test_Condition_wait():
    from multiprocessing import Process
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()
    running = False

    @gen.coroutine
    def waiter():
        nonlocal running
        running = True
        print("I'll wait right here")
        yield condition.wait()
        print("I'm done waiting")

    @gen.coroutine
    def notifier():
        nonlocal running
        print("About to notify")
        condition.notify()
        print("Done notifying")

    @gen.coroutine
    def runner():
        nonlocal running
        # Wait for waiter() and notifier() in parallel
        yield [waiter(), notifier()]
        print("Both are done")
        running = False
        IOLoop.current().stop()


# Generated at 2022-06-22 03:56:15.323602
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    lock.__aexit__(TypeError, Exception, "traceback")
    lock.__aexit__(TypeError, None, None)



# Generated at 2022-06-22 03:56:17.657334
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    print(Condition.__repr__.__doc__)

    condition = Condition()
    print(condition)


# Generated at 2022-06-22 03:56:22.589559
# Unit test for method set of class Event
def test_Event_set():
    #初始化
    ev = Event()
    #赋值
    ev.set()
    #验证结果
    assert ev.is_set() == True


# Generated at 2022-06-22 03:56:24.167010
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    _ReleasingContextManager(obj=None).__enter__()


# Generated at 2022-06-22 03:56:25.652250
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    c = Condition()
    print(c)


# Generated at 2022-06-22 03:56:33.346691
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    from utils.testutils import random_string
    from .locks import _ReleasingContextManager
    from .locks import Lock
    from .locks import _assert_locked
    from .locks import _assert_unlocked
    
    obj = Lock()
    obj.acquire().add_done_callback(lambda future: future.result())
    _assert_locked(obj)
    context_manager = _ReleasingContextManager(obj)
    context_manager.__enter__()
    _assert_locked(obj)


# Generated at 2022-06-22 03:56:37.408627
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    lock = Lock()
    try:
        with (yield lock.acquire()):
            pass
    except Exception as e:
        lock.release()


# Generated at 2022-06-22 03:56:41.296551
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    test_Semaphore = Semaphore(value = 1)
    test_typ = BaseException
    test_value = BaseException()
    test_tb = types.TracebackType()
    test_Semaphore.__aexit__(test_typ, test_value, test_tb)
    return test_Semaphore



# Generated at 2022-06-22 03:56:55.625756
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    obj = object()
    ctx = _ReleasingContextManager(obj)
    assert ctx.__enter__() is None
    assert ctx._obj is obj

# Generated at 2022-06-22 03:56:57.777515
# Unit test for method __aenter__ of class Semaphore
def test_Semaphore___aenter__():
    s = Semaphore()
    assert not s.is_set()
    s.set()
    assert s.is_set()

    # Semaphore() call is simultaneous with set() call
    s = Semaphore()
    s.set()
    assert s._value == 1
    assert s.is_set()

# Generated at 2022-06-22 03:56:59.507083
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    from .locks import Lock
    mylock = Lock()
    with (mylock.acquire()):
        pass


# Generated at 2022-06-22 03:57:02.141274
# Unit test for constructor of class Semaphore
def test_Semaphore():
    from tornado.locks import Semaphore
    sem = Semaphore(value=1)
    assert isinstance(sem, Semaphore)



# Generated at 2022-06-22 03:57:06.443817
# Unit test for constructor of class Semaphore
def test_Semaphore():
    s = Semaphore(2)
    assert s._value == 2

    try:
        s = Semaphore(-2)
    except ValueError as e:
        print(e)
    else:
        assert False, "ValueError not raised"



# Generated at 2022-06-22 03:57:09.146483
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    __enter__ = _ReleasingContextManager.__enter__
    assert __enter__(object()) == None

# Generated at 2022-06-22 03:57:11.472178
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
        a = _ReleasingContextManager(None)
        assert a.__enter__() is None

# Generated at 2022-06-22 03:57:23.471054
# Unit test for method clear of class Event
def test_Event_clear():
    event = Event()
    assert not event.is_set()
    event.set()
    assert event.is_set()
    event.clear()
    assert not event.is_set()
    event.set()

    # Wait blocks until event is set.
    gen.sleep(0.1)
    async def waiter():
        print("Waiting for event")
        await event.wait()
        print("Not waiting this time")
        await event.wait()
        print("Done")

    async def setter():
        print("About to set the event")
        event.set()

    async def runner():
        await gen.multi([waiter(), setter()])

    ioloop.IOLoop.current().run_sync(runner)
#Unit test for method set of class Event

# Generated at 2022-06-22 03:57:28.062414
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    semaphore = Semaphore()
    with pytest.raises(RuntimeError) as e:
        semaphore.__enter__()
    assert e.value.args[0] == ("Use 'async with' instead of 'with' for Semaphore")

# Generated at 2022-06-22 03:57:34.870347
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    semaphore=Semaphore(2)
    print("Test Case 1: semaphore.__exit__(None,None,None)")
    semaphore.__exit__(None,None,None)
    print("Test Case 2: semaphore.__exit__(RuntimeError,'dummy',None)")
    semaphore.__exit__(RuntimeError,'dummy',None)


# Generated at 2022-06-22 03:57:50.246213
# Unit test for method is_set of class Event
def test_Event_is_set():
    success = 1
    event = Event()
    result = event.is_set()
    if result:
        success = 0
    if success != 0:
        raise RuntimeError("test failed")


# Generated at 2022-06-22 03:57:54.637402
# Unit test for method __aexit__ of class Semaphore
def test_Semaphore___aexit__():
    async def async_wrapper(coroutine):
        await coroutine

    async def test_method():
        lock = Semaphore(2)
        async with lock:
            pass

    async_wrapper(test_method())

# Generated at 2022-06-22 03:58:00.196965
# Unit test for method release of class Lock
def test_Lock_release():
    #Release a non-locked lock.
    #Release a locked lock.
    #Test the release method of the Lock class
    print('\n')
    print('Test the release method of the Lock class')
    lock = Lock()
    lock.release()
    lock.acquire()
    lock.release()
    #Unit test end
test_Lock_release()


# Generated at 2022-06-22 03:58:03.331426
# Unit test for method __enter__ of class Lock
def test_Lock___enter__():
    # Instance to test method __enter__ of class Lock
    Lock_instance = Lock()
    # Test method __enter__ of class Lock
    assert_raises(
        TypeError,
        Lock_instance.__enter__
    )

# Generated at 2022-06-22 03:58:04.664367
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    pass


# Generated at 2022-06-22 03:58:12.232574
# Unit test for method acquire of class Lock
def test_Lock_acquire():
    '''
    Asynchronous function for unit testing method acquire of class Lock
    Return:
        A boolean value: True for pass, False for fail
    '''

    async def _test_Lock_acquire():
        # Test Lock acquire
        lock = Lock()
        # lock is not locked, acquire it
        _result = await lock.acquire()
        # lock is locked, acquire it should timeout
        await lock.acquire()

    # Run the asynchronous function
    IOLoop.current().run_sync(_test_Lock_acquire)
    return True

# Generated at 2022-06-22 03:58:17.617130
# Unit test for method is_set of class Event
def test_Event_is_set():
    event = Event()

    assert event.is_set() == False

    event.set()

    assert event.is_set() == True

    event.clear()

    assert event.is_set() == False


# Generated at 2022-06-22 03:58:20.999894
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    a = _ReleasingContextManager(1)
    a.__enter__()
    a.__exit__(None, None, None)



# Generated at 2022-06-22 03:58:22.810362
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    m = _ReleasingContextManager(Lock())
    m.__exit__(None, None, None)


# Generated at 2022-06-22 03:58:29.882361
# Unit test for constructor of class _ReleasingContextManager
def test__ReleasingContextManager():
    # type: () -> None
    from pytest import raises
    from tornado.concurrent import Future
    from tornado.ioloop import IOLoop

    future = Future()  # type: Future[None]
    future.set_result(None)

    a = _ReleasingContextManager(future)
    a.__enter__()

    def func():
        # type: () -> None
        a.__exit__(0, 0, 0)

    IOLoop.current().add_callback(func)
    IOLoop.current().start()

    assert future.done()



# Generated at 2022-06-22 03:58:48.975257
# Unit test for method release of class BoundedSemaphore
def test_BoundedSemaphore_release():
    value = 1
    semaphore = BoundedSemaphore(value=value)
    if semaphore._value >= semaphore._initial_value:
        raise ValueError("Semaphore released too many times")
    else:
        print("Semaphore released right number of times")


# Generated at 2022-06-22 03:58:51.805486
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    arg1 = _ReleasingContextManager(None)
    res1 = arg1.__enter__()
    assert (res1 is None)


# Generated at 2022-06-22 03:58:53.466840
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    obj = _ReleasingContextManager(object())
    obj.__enter__()

# Generated at 2022-06-22 03:58:56.055240
# Unit test for method __repr__ of class Condition
def test_Condition___repr__():
    # Test the method __repr__ of class Condition
    cond = Condition()
    r = cond.__repr__()  # type: str
    assert isinstance(r, str)


# Generated at 2022-06-22 03:59:01.411474
# Unit test for constructor of class Lock
def test_Lock():
    import asyncio
    async def coro():
        lock = Lock()
        print('try to acquire the lock')
        async with lock:
            print('acquired the lock')
        print('released the lock')
    loop = asyncio.get_event_loop()
    loop.run_until_complete(coro())

test_Lock()

# Generated at 2022-06-22 03:59:03.571174
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    # __exit__(self, typ, value, tb)
    return True


# Generated at 2022-06-22 03:59:09.136926
# Unit test for constructor of class Condition
def test_Condition():
    c1 = Condition()
    c2 = Condition()
    assert c1 is not c2

    assert not isinstance(c1, Condition)

    assert isinstance(c1, _TimeoutGarbageCollector)
    assert not isinstance(c1, types.GeneratorType)


# Generated at 2022-06-22 03:59:15.314326
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    bs = BoundedSemaphore(10)
    # release too many times
    for i in range(10):
        bs.release()
    try:
        bs.release()
    except ValueError:
        pass

BoundedSemaphore.test = test_BoundedSemaphore



# Generated at 2022-06-22 03:59:19.322808
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    lock = locks.Lock()
    print(lock)
    lock.acquire()
    print(lock)
    lock.release()
    print(lock)
    

# Generated at 2022-06-22 03:59:25.834558
# Unit test for method wait of class Event
def test_Event_wait():
    event = Event()
    def waiter():
        print("Waiting for event")
        fut = gen.Future()
        event.wait(fut)
        print("Not waiting this time")
        event.wait()
        print("Done")
    def setter():
        print("About to set the event")
        event.set()
    def runner():
        ioloop.IOLoop.current().run_sync(setter)
    runner()


# Generated at 2022-06-22 03:59:55.333026
# Unit test for method acquire of class Semaphore
def test_Semaphore_acquire():
    sem = Semaphore(value = 1)
    assert sem._value == 1
    waiter = Future()
    if sem._value > 0:
        sem._value -= 1
        waiter.set_result(_ReleasingContextManager(sem))
    else:
        sem._waiters.append(waiter)
        if timeout:
            def on_timeout() -> None:
                if not waiter.done():
                    waiter.set_exception(gen.TimeoutError())
                sem._garbage_collect()
            io_loop = IOLoop.current()
            timeout_handle = io_loop.add_timeout(timeout, on_timeout)
            waiter.add_done_callback(lambda _: io_loop.remove_timeout(timeout_handle))
    
    waiter.set_result(_ReleasingContextManager(sem))

# Generated at 2022-06-22 04:00:05.359514
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition

    condition = Condition()

    async def waiter():
        print("I'll wait right here")
        async with condition.wait():
            print("I'm done waiting")

    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")

    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])

    IOLoop.current().run_sync(runner)
    


# Generated at 2022-06-22 04:00:16.334206
# Unit test for method __enter__ of class _ReleasingContextManager
def test__ReleasingContextManager___enter__():
    from _pytest.warning_types import _PytestWarning
    import pytest
    import warnings
    # _ReleasingContextManager.__enter__
    # 

    # Assume
    x = _ReleasingContextManager(obj=1)

    # Action
    _ = x.__enter__()

    # Assert that no exceptions escape __enter__()
    # _ReleasingContextManager.__exit__
    # 

    # Assume
    x = _ReleasingContextManager(obj=1)

    # Action
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=DeprecationWarning)
        _ = x.__exit__(exc_type=None, exc_val=None, exc_tb=None)

    # Assert that no exceptions escape __enter__()
    # _ReleasingContext

# Generated at 2022-06-22 04:00:19.223190
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    sem = Semaphore(1)
    res = sem.release()
    assert res is None, f'Expected None, but got {res}'

# Generated at 2022-06-22 04:00:20.489094
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    a = _NotifyAllTest()
    a.notify_all()


# Generated at 2022-06-22 04:00:33.797112
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():
    """
    AsyncioTestCase
    ---------------
    """
    from tornado.testing import AsyncTestCase, gen_test
    from tornado.locks import Semaphore

    class TestMethod__enter__(AsyncTestCase):
        @gen_test
        async def test_it(self):
            semaphore = Semaphore()
            exception_raised = False

            try:
                semaphore.__enter__()
            except RuntimeError as e:
                exception_raised = True
                self.assertEqual(
                    "Use 'async with' instead of 'with' for Semaphore", str(e)
                )

            self.assertTrue(exception_raised)

    test_method___enter__ = TestMethod__enter__()
    test_method___enter__.test_it()


# Generated at 2022-06-22 04:00:37.517894
# Unit test for constructor of class BoundedSemaphore
def test_BoundedSemaphore():
    sem = BoundedSemaphore(2)
    sem.acquire()
    sem.acquire()

    try:
        sem.acquire()
        assert False, "BoundedSemaphore doesn't raise ValueError"
    except ValueError as err:
        str(err)

# Generated at 2022-06-22 04:00:40.179177
# Unit test for method notify_all of class Condition
def test_Condition_notify_all():
    condition = Condition();
    condition.notify_all()
    assert(condition.__repr__() == "<Condition waiters[0]>")



# Generated at 2022-06-22 04:00:52.877348
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    import tornado
    import unittest.mock
    import concurrent.futures
    
    with unittest.mock.patch(
        'tornado.locks.Lock.release',
        new=unittest.mock.MagicMock(),
    ) as mocked_release:
        async def async_magic_mock_aexit__(self, typ, value, tb):
            mocked_release.assert_called_once_with()
    
    with unittest.mock.patch(
        'tornado.locks.Lock.__aexit__',
        new=async_magic_mock_aexit__,
    ):
        lock = tornado.locks.Lock()

# Generated at 2022-06-22 04:00:55.810671
# Unit test for method set of class Event
def test_Event_set():
    # 
    event = Event()
    assert event.is_set() == False
    event.set()
    assert event.is_set() == True



# Generated at 2022-06-22 04:01:49.074759
# Unit test for method __exit__ of class Semaphore
def test_Semaphore___exit__():
    inst = Semaphore()
    inst.release()
    inst.acquire()
    inst.__exit__(None, None, None)
    assert inst._value == 0
    assert inst._waiters == deque()

# Generated at 2022-06-22 04:01:56.538932
# Unit test for method notify of class Condition
def test_Condition_notify():
    from tornado import gen
    from tornado.ioloop import IOLoop
    from tornado.locks import Condition
    condition = Condition()
    async def waiter():
        print("I'll wait right here")
        await condition.wait()
        print("I'm done waiting")
    async def notifier():
        print("About to notify")
        condition.notify()
        print("Done notifying")
    async def runner():
        # Wait for waiter() and notifier() in parallel
        await gen.multi([waiter(), notifier()])
    IOLoop.current().run_sync(runner)



# Generated at 2022-06-22 04:02:00.738800
# Unit test for constructor of class Event
def test_Event():
    event = Event()
    print(event.is_set()) # should be false
    event.set()
    print(event.is_set()) # should be True



# Generated at 2022-06-22 04:02:09.759239
# Unit test for method __aexit__ of class Lock
def test_Lock___aexit__():
    """Test if __aexit__ works correctly"""
    
    # Test with value given
    
    
    
    # Test with value given and with exception
    
    
    
    # Test without value given
    
    
    
    # Test without value given and with exception
    
    
    
    # Test with value given
    
    lock = Lock()
    await lock.acquire()
    await lock.__aexit__(None, None, None)
    assert lock._block._value == 1
    
    # Test with value given and with exception
    lock = Lock()
    await lock.acquire()
    await lock.__aexit__(RuntimeError, RuntimeError("test"), None)
    assert lock._block._value == 1
    
    # Test without value given
    lock = Lock()
    await lock.acquire()

# Generated at 2022-06-22 04:02:13.197702
# Unit test for method __exit__ of class _ReleasingContextManager
def test__ReleasingContextManager___exit__():
    from tornado import gen
    from tornado.locks import Semaphore

    semaphore = Semaphore(1)
    with (yield semaphore.acquire()):
        pass

# Generated at 2022-06-22 04:02:23.484631
# Unit test for method __exit__ of class Lock
def test_Lock___exit__():
    __dict__ = {}  # type: Dict[str, object]
    __args__ = [None, None, None]
    test_Lock___exit__.__dict__ = __dict__
    test_Lock___exit__.__args__ = __args__
    if __args__[0] is None:
        raise TypeError("__exit__() takes exactly 3 arguments (1 given)")
    if __args__[1] is None:
        raise TypeError("__exit__() takes exactly 3 arguments (2 given)")
    if __args__[2] is None:
        raise TypeError("__exit__() takes exactly 3 arguments (3 given)")
    try:
        self.__enter__()
    except:
        pass
    return



# Generated at 2022-06-22 04:02:25.611704
# Unit test for method __aenter__ of class Lock
def test_Lock___aenter__():
    lock = Lock()
    lock.__aenter__()



# Generated at 2022-06-22 04:02:30.418774
# Unit test for method release of class Semaphore
def test_Semaphore_release():
    a = Semaphore(1)
    test_future = Future()
    test_future.set_result(_ReleasingContextManager(a))
    a._value = a._value + 1
    a._waiters.append(test_future)
    a.release()
    return a

# Generated at 2022-06-22 04:02:41.785038
# Unit test for method acquire of class Lock
def test_Lock_acquire():
   import datetime
   from tornado.locks import Lock
   a = Lock()
   with pytest.raises(RuntimeError):
      a.__enter__()
   a.__exit__(None, None, None)
   with pytest.raises(RuntimeError):
      a.acquire(datetime.timedelta(0))
   a.acquire().__exit__(None, None, None)
   with pytest.raises(RuntimeError):
      a.acquire().__aexit__(None, None, None)
   a.acquire().__aexit__(None, None, None)
   with pytest.raises(RuntimeError):
      a.acquire().__aexit__(None, None, None)
   a.acquire().__aexit__(None, None, None)

# Generated at 2022-06-22 04:02:47.549308
# Unit test for method __enter__ of class Semaphore
def test_Semaphore___enter__():

    # Init Semaphore object with default value
    sem = Semaphore()

    try:
        # Enter the context defined by this object.
        with sem:
            # Extract the underlying Semaphore value.
            print(sem._value)
    except Exception as err:
        # Print error to console
        print(err)