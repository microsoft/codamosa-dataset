

# Generated at 2022-06-22 14:22:28.646857
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u"foo", u"bar"]) == u"foobar"
    assert ansible_native_concat([u"foo", u"bar", u"baz"]) == u"foobarbaz"
    assert ansible_native_concat([u"foo", u"bar", u"baz", u"qux"]) == u"foobarbazqux"
    assert ansible_native_concat([u"foo", u"bar", u"baz", u"qux", u"quux"]) == u"foobarbazquxquux"
    assert ansible_native_concat([u"foo", u"bar", u"baz", u"qux", u"quux", u"quuz"]) == u"foobarbazquxquuxquuz"

# Generated at 2022-06-22 14:22:32.693077
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    tests = (
        (['one string', 'two string'], 'onetwostring'),
        (['one string', 'two string'], 'onetwostring'),
        (['one string', 'two string'], 'onetwostring'),
        (['one string', 'two string'], 'onetwostring'),
        (['one string', 'two string'], 'onetwostring'),
    )
    for args, expected in tests:
        assert expected == ansible_native_concat(args)

# Generated at 2022-06-22 14:22:45.111560
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Undefined:
        def __str__(self):
            raise StrictUndefined()

    string1 = 'foo'
    string2 = 'bar'
    undef = Undefined()

    assert ansible_native_concat([string1]) == 'foo'
    assert ansible_native_concat([string1, string2]) == 'foobar'
    assert ansible_native_concat([string1, string2, undef]) == 'foobar'

    # literal_eval tries to return the correct type in its output
    assert isinstance(ansible_native_concat([container_to_text(1)]), int)
    assert isinstance(ansible_native_concat([container_to_text(1.0)]), float)

# Generated at 2022-06-22 14:22:57.653625
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test when nodes is empty
    assert ansible_native_concat(nodes=[]) is None

    # Test when nodes has only one element
    # Test when the one element is a string
    assert ansible_native_concat(nodes=['abc']) == 'abc'
    assert ansible_native_concat(nodes=['123']) == '123'  # integer
    assert ansible_native_concat(nodes=['1.2']) == '1.2'  # float

    # Test when the one element is not a string
    assert ansible_native_concat(nodes=[1]) == 1  # integer
    assert ansible_native_concat(nodes=[1.2]) == 1.2  # float
    assert ansible_native_concat(nodes=[None]) is None  #

# Generated at 2022-06-22 14:23:10.261239
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import string
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    c = AnsibleConstructor(yaml_impl=AnsibleConstructor.yaml_base)

    def _eval(value):
        return c.construct_yaml_str(string(value))

    nodes = [u'1', _eval(1), u'2']

    assert ansible_native_concat(nodes) == 12
    assert type(ansible_native_concat(nodes)) == int

    nodes = [u'1', _eval(1), _eval([u'2'])]

    assert ansible_native_concat(nodes) == [u'21']

# Generated at 2022-06-22 14:23:23.192643
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleBaseYAMLObject
    from ansible.parsing.yaml.loader import AnsibleLoader
    # noinspection PyProtectedMember
    from ansible.template.safe_eval import _fail_on_undefined, _is_safe_eval_type

    # We cannot use pytest directly as the pytest handler automatically
    # triggers the undefined exception. We need to manually iterate the
    # items to fail on the Undefined exception.

    # We do this because the original function tests each item
    # in the data structure and if one of the items fails the
    # exception will be thrown.
    # This is done in order to support unwrapped variables in Jinja2


# Generated at 2022-06-22 14:23:32.800343
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test no nodes
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat(iter([1])) is 1
    assert ansible_native_concat(iter([{'a': 1}])) is {'a': 1}

    # test that literal_eval is called
    assert ansible_native_concat(iter(['1'])) is 1
    assert ansible_native_concat(iter(['1'])) is not '1'
    assert ansible_native_concat(iter(['{a:1}'])) == {'a': 1}

    # test that literal_eval is not called
    assert ansible_native_concat(iter(['1', '2'])) == '12'

# Generated at 2022-06-22 14:23:40.202595
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native, to_text

    def assert_type_and_value(str_or_native, value):
        """Helper function that asserts that given str_or_native value is
        converted to native value and has the same value.
        """
        assert value == to_text(value)
        assert value == to_native(value)
        assert to_native(str_or_native) == to_native(value)

    assert ansible_native_concat([]) is None
    assert ansible_native_concat((1,)) == 1
    assert ansible_native_concat((True,)) == True
    assert ansible_native_concat(('42',)) == 42

# Generated at 2022-06-22 14:23:44.623700
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # single values
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == u'a'

    # multiple values
    assert ansible_native_concat(['a', 'b', 'c']) == u'abc'
    assert ansible_native_concat([1, 2, 3]) == 6

    # dicts
    assert ansible_native_concat([{'a': 1, 'b': 2}]) == {'a': 1, 'b': 2}
    assert ansible_native_concat([{'a': 'b'}, {'c': 'd'}]) == u'{c: d}'
    assert ansible_native_concat([{'a': 1, 'b': 2}, {'c': 'd'}]) == u

# Generated at 2022-06-22 14:23:56.323324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert container_to_text(ansible_native_concat([text_type(123)])) == '123'
    assert container_to_text(ansible_native_concat([text_type('a'), text_type('b')])) == 'ab'
    assert container_to_text(ansible_native_concat([text_type('[1,2,3]')])) == '[1,2,3]'
    assert container_to_text(ansible_native_concat([text_type('[a,b]')])) == '[a,b]'
    assert container_to_text(ansible_native_concat([])) == ''
    assert container_to_text(ansible_native_concat([text_type('[')])) == '['

# Generated at 2022-06-22 14:24:05.478633
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 123]) == 'abc123'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat(['abc', '']) == 'abc'
    assert ansible_native_concat(['', 'def']) == 'def'
    assert ansible_native_concat(['', '', 'ghi']) == 'ghi'
    assert ansible_native_concat(['abc', 1]) == 'abc1'
    assert ansible_native_concat(['abc', True]) == 'abcTrue'

# Generated at 2022-06-22 14:24:16.810047
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    nodes = ['foo', 'bar', ['baz'], 'baz']
    assert ansible_native_concat(nodes) == 'foobar[\'baz\']baz'

    nodes = ['foo', 'bar', ['baz'], 'baz']
    assert ansible_native_concat(nodes) == 'foobar[\'baz\']baz'

    nodes = ['foo', 'bar', ['baz'], 'baz']
    assert ansible_native_concat(nodes) == 'foobar[\'baz\']baz'


# Generated at 2022-06-22 14:24:28.687624
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['\n']) == ''
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['"a"']) == 'a'

# Generated at 2022-06-22 14:24:35.739476
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Template
    from ansible.module_utils.jinja2 import AnsibleJ2
    from ansible.module_utils.basic import _json_decode

    for jinja_tmpl in ('{{ a }}', '{{ a|string }}', '{{ b }}', '{{ b|string }}', '{{ c }}', '{{ d }}', '{{ d|string }}', '{{ e }}', '{{ f }}', '{{ f|string }}', '{{ g }}', '{{ h }}', '{{ i }}', '{{ j }}'):
        tmpl = Template(jinja_tmpl, autoescape=False)
        compiled_tmpl = tmpl.compile()
        compiled_ansible_tmpl = AnsibleJ2(tmpl).compile()

# Generated at 2022-06-22 14:24:46.024627
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat function"""

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([None]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([-1]) == -1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([0.0]) == 0.0
    assert ansible_native_concat([-1.0]) == -1.0


# Generated at 2022-06-22 14:24:58.018601
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:25:09.017411
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.template.filters.core import to_json
    from jinja2 import Markup
    from ansible.module_utils.common.text.converters import container_to_text

    assert ansible_native_concat([]) is None

    # test that we convert to text and not bytes
    assert isinstance(ansible_native_concat([u'foo']), text_type)

    # test that we parse the result according to literal_eval
    assert ansible_native_concat([u'nested']) == [u'nested']
    assert ansible_native_concat([u'1']) == 1

    # test that we join the nodes

# Generated at 2022-06-22 14:25:19.097201
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: Need test for AnsibleVaultEncryptedUnicode input
    assert ansible_native_concat([False]) is False

    assert ansible_native_concat([True]) is True

    # TODO: NativeJinjaText is not supported in Python 3
    # assert ansible_native_concat([NativeJinjaText("1")]) == "1"

    assert ansible_native_concat([123]) == 123

    assert ansible_native_concat([1.23]) == 1.23

    assert ansible_native_concat(['Hello']) == 'Hello'

    assert ansible_native_concat(['Hello', 'World']) == 'HelloWorld'


# Generated at 2022-06-22 14:25:29.500525
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=unused-argument
    result = ansible_native_concat([container_to_text(1), container_to_text(2), container_to_text("3")])
    assert result == "123", result

    result = ansible_native_concat([container_to_text("1"), container_to_text("2"), container_to_text("3")])
    assert result == 123, result

    result = ansible_native_concat([container_to_text("1"), container_to_text("2"), container_to_text("a")])
    assert result == "123a", result
    # pylint: enable=unused-argument

# Generated at 2022-06-22 14:25:39.981344
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([[1, 2]]) == [1, 2]
    assert ansible_native_concat(
        [1, 2, 3],
    ) == u'123'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', None, u'b', u'c']) == u'aNonebcaNonebc'
    assert ansible_native_concat([u'a', None, None, u'b', u'c']) == u'aNoneNonebcaNoneNonebc'

# Generated at 2022-06-22 14:25:53.602000
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([NativeJinjaText(u'foo'), 1]) == 'foo1'
    assert ansible_native_concat([1, NativeJinjaText('2')]) == '12'
    assert ansible_native_concat([NativeJinjaText(u'foo'), NativeJinjaText('1')]) == 'foo1'
    assert ansible_native_concat([None, u'2']) == '2'

# Generated at 2022-06-22 14:25:59.862044
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([None, 1]) == 'None1'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['True', 'True']) == True
    assert ansible_native_concat(['[1, 2]', '1']) == [1, 2, 1]

# Generated at 2022-06-22 14:26:10.094580
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # string
    assert ansible_native_concat(u'abc') == u'abc'
    # int
    assert ansible_native_concat(123) == 123
    # bool
    assert ansible_native_concat(True) is True
    # null
    assert ansible_native_concat(None) is None
    # dict
    assert isinstance(
        ansible_native_concat({u'foo': u'bar'}), dict
    )
    # list
    assert isinstance(
        ansible_native_concat([u'foo', u'bar']), list
    )
    # tuple
    assert isinstance(
        ansible_native_concat((u'foo', u'bar')), tuple
    )
    # set

# Generated at 2022-06-22 14:26:19.545855
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, u'b']) == u'1b'
    assert ansible_native_concat([u'a', 2]) == u'a2'
    assert ansible_native_concat([u'a', u'b']) == u'ab'

# Generated at 2022-06-22 14:26:31.620019
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

# Generated at 2022-06-22 14:26:44.193718
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test that we can concat literals of different types
    assert ansible_native_concat([1, 'foo', 2, 'bar']) == '1foo2bar'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat([True, 'foo', False, 'bar']) == 'TruefooFalsebar'
    assert ansible_native_concat([True, 'foo', False, 'bar']) == 'TruefooFalsebar'
    assert ansible_native_concat(['foo', '\n', 'bar', '\n']) == 'foo\nbar\n'
    assert ansible_native_concat(['foo', '\n', 'bar', '\n']) == 'foo\nbar\n'

    # test conc

# Generated at 2022-06-22 14:26:55.260724
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Create a test context (environment)
    env = jinja2.Environment(undefined=Undefined,
                             keep_trailing_newline=True,
                             finalize=ansible_native_concat)
    # Register the jinja2.nodes.Call
    env.globals['test_nodelist'] = test_nodelist
    # Test template

# Generated at 2022-06-22 14:27:04.109140
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(('foo', 'bar')) == 'foobar'
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat(['foo', 42]) == 'foo42'
    assert ansible_native_concat(['foo', '42']) == 42
    assert ansible_native_concat(['foo', ansible_native_concat(['1', '2'])]) == 'foo12'
    assert ansible_native_concat(['foo', ansible_native_concat([1, '2'])]) == 'foo12'



# Generated at 2022-06-22 14:27:16.532324
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader

    # condition_expr = '"foo"'
    # condition_expr_vault = AnsibleVaultEncryptedUnicode('"foo"', b'')

    # set_expr = 'bar'
    # set_expr_vault = AnsibleVaultEncryptedUnicode('bar', b'')

    # single_quoted_string = "test"
    # double_quoted_string = 'test'
    # statements_string = 'foo: bar'
    # simple_dict = "{'foo': 'bar'}"
    # simple_list = "['foo', 'bar']"
    # multi_line_string = """
    #     foo: bar
    # """
    # result = ansible_native_concat([
    #     single_qu

# Generated at 2022-06-22 14:27:23.956964
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText(u'http://'), NativeJinjaText(u'example.com')]) == u'http://example.com'
    assert ansible_native_concat([u'http://', u'example.com']) == u'http://example.com'
    assert ansible_native_concat([u'http://', u'example.com', u'/foo', u'/bar']) == u'http://example.com/foo/bar'
    assert ansible_native_concat([u'http://', u'example.com/foo', u'/bar']) == u'http://example.com/foo/bar'
    assert ansible_native_concat([True, u'example.com']) == True

# Generated at 2022-06-22 14:27:34.983112
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    value = ansible_native_concat(['A', 'B'])
    assert value == u'AB'

    value = ansible_native_concat([u'A', u'B'])
    assert value == u'AB'

    value = ansible_native_concat(u'AB')
    assert value == u'AB'

    value = ansible_native_concat(u'A'*1000)
    assert value == u'A'*1000

    value = ansible_native_concat(['"A"', '"B"'])
    assert value == u'AB'

    value = ansible_native_concat(['A', 'B', AnsibleVaultEncryptedUnicode('some_password')])
    assert value == u'Ab'


# Generated at 2022-06-22 14:27:43.378379
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nativetypes import NativeString, to_string
    from jinja2.nodes import Name

    assert ansible_native_concat([Name(u'foo', 'load')]) == u'foo'

    assert ansible_native_concat([NativeString(u'a'), NativeString(u'b')]) == u'ab'

    assert ansible_native_concat([to_string(42), to_string(u'foo')]) == u'42foo'

# Generated at 2022-06-22 14:27:56.052541
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.template import AnsibleJ2

    template = AnsibleJ2()

    literal_eval = ['true', 'null', 'false', '{}', '[]',
                    '42', '3.14', '1.0e42', '1.0e42j',
                    u'\x00', u'\x00\x00\xfe\xff', u'\u0000', u'\u0000\u0000\ufffe\xffff',
                    u'\U00000000',
                    '"foo"',
                    "'bar'",
                    '"a string with an escaped \\"\\"',
                    "'a string with an escaped \\\\'",
                    "'a string with a newline \n\\'"]

    for value in literal_eval:
        nodes = template.parse('{{ %s }}' % value)
        result

# Generated at 2022-06-22 14:28:07.445165
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['2', '2']) == 22
    assert ansible_native_concat(['["foo", "bar", "baz"]']) == ['foo', 'bar', 'baz']
    assert ansible_native_concat([u'\u263a']) == u'\u263a'
    assert ansible_native_concat(['1', '2', '3', '4', '5']) == 12345

# Generated at 2022-06-22 14:28:20.945528
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [u'foo', u'bar', u'baz']
    result = ansible_native_concat(nodes)
    assert result == 'foobarbaz'
    result = ansible_native_concat(iter(nodes))
    assert result == 'foobarbaz'
    nodes = [u'1', u'2', u'3']
    result = ansible_native_concat(nodes)
    assert result == 123
    result = ansible_native_concat(iter(nodes))
    assert result == 123
    nodes = [u'1', u'2', u'3', u'x']
    result = ansible_native_concat(nodes)
    assert result == '123x'
    result = ansible_native_concat(iter(nodes))

# Generated at 2022-06-22 14:28:33.660049
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestUndefined(StrictUndefined):
        def __str__(self):
            pass

    class TestText(NativeJinjaText):
        def __str__(self):
            pass

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([0]) == 0
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([TestUndefined()]) is None
    assert ansible_native_con

# Generated at 2022-06-22 14:28:46.757863
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([42, 42]) == u'4242'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([u'4242']) == u'4242'
    assert ansible_native_concat([b'4242']) == b'4242'
    assert ansible_native_concat([{'a': 'A'}]) == {'a': 'A'}

    assert ansible_native_concat([u'{', u'}']) == '{}'
    assert ansible_native_concat([u'str', [u'list']]) == 'str[list]'
    assert ansible_native_concat([u'a', u'b', u'c']) == 'abc'
    assert ansible_native_

# Generated at 2022-06-22 14:28:50.330709
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert(ansible_native_concat(['foo', 'bar']) == 'foobar')
    assert(ansible_native_concat(['foo', '\tbar']) == 'foo\tbar')



# Generated at 2022-06-22 14:28:56.519229
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Python 3.4+ only - we want to use the ast.parse mode='eval'
    # argument and this was not added until 3.4
    import sys
    if sys.version_info >= (3, 4):
        def _test():
            # Convert the function ansible_native_concat to a string
            import inspect
            ansible_native_concat_str = inspect.getsource(ansible_native_concat)

            from jinja2 import Environment
            fn = Environment().from_string(ansible_native_concat_str).module.ansible_native_concat

            assert fn([]) is None

            assert fn(['foo']) == 'foo'
            assert fn(['foo', 'bar']) == 'foobar'

# Generated at 2022-06-22 14:29:06.040656
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import DictLoader, Environment
    from jinja2.utils import concat as default_concat
    env = Environment(loader=DictLoader({'test': '{{ a }}|{{ b }}'}), extensions=['jinja2_ansible.AnsibleExtension'])
    env.globals['a'] = [1]
    env.globals['b'] = [2, 3]
    template = env.get_template('test')
    assert template.module.ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert template.module.ansible_native_concat([1, [2], 3]) == [1, 2, 3]

# Generated at 2022-06-22 14:29:16.879387
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test concat
    a = 'hello'
    b = u'world'
    assert container_to_text(ansible_native_concat([a, b])) == 'helloworld'

    # Test concat of unicode and non-unicode
    assert container_to_text(ansible_native_concat([a, u'world'])) == 'helloworld'
    assert container_to_text(ansible_native_concat([u'hello', b])) == 'helloworld'

    # Test concat of int and non-int
    a = 1
    assert container_to_text(ansible_native_concat([a, b])) == '1world'
    assert container_to_text(ansible_native_concat([a, u'world'])) == '1world'
    assert container

# Generated at 2022-06-22 14:29:28.702737
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert 'a' == ansible_native_concat(['a'])
    assert b'a' == ansible_native_concat([b'a'])
    assert u'a' == ansible_native_concat([u'a'])
    assert 1 == ansible_native_concat([1])
    assert 1.2 == ansible_native_concat([1.2])
    assert [1] == ansible_native_concat([[1]])
    assert [1] == ansible_native_concat([(1)])
    # TODO(aemerson): Improve when https://github.com/ansible/ansible/issues/69960 is fixed
    assert u'a' == ansible_native_concat(NativeJinjaText('a'))

    assert 'a' == ansible_native_

# Generated at 2022-06-22 14:29:39.658348
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # To properly test ansible_native_concat we need to pass it a stream of
    # compiled nodes. We can't just pass it a stream of values since
    # StrictUndefined doesn't actually raise the undefined exception until
    # the value is accessed.
    # See:
    # https://github.com/ansible/ansible/issues/52158
    # and StrictUndefined implementation in upstream Jinja2.
    # A workaround is to access the StrictUndefined object in some way
    # before passing it to ansible_native_concat. As long as we don't look
    # at the value of the object, we can do this. We use container_to_text
    # for this which returns an empty string for StrictUndefined objects.

    # test 1: empty values
    values = []

# Generated at 2022-06-22 14:29:51.415616
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test(nodes, expected):
        assert ansible_native_concat(nodes) == expected

    test([], None)
    test([1], 1)
    test([1, 2], u'12')
    test([1, 2, 3], u'123')
    test([1, 2, 3], u'123')
    test([[1, 2], [3, 4]], [[1, 2], [3, 4]])
    test([container_to_text([1, 2]), 3], [[1, 2], 3])
    test([container_to_text(['a', 'b']), 'c'], ['a', 'b', 'c'])
    test(['a', 'b', 'c'], u'abc')
    test([1, 'b', 'c'], u'1bc')
    test

# Generated at 2022-06-22 14:29:56.552364
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["hello ", "world"]) == "hello world"
    assert ansible_native_concat(["hello ", "world", None]) == "hello world"
    assert ansible_native_concat(["hello ", "world", False]) == "hello world"
    assert ansible_native_concat(["hello ", "world", True]) == "hello world"
    assert ansible_native_concat(["hello ", "world", {}]) == "hello world"
    assert ansible_native_concat(["hello ", "world", []]) == "hello world"
    assert ansible_native_concat(["hello ", "world", "", "!"]) == "hello world!"
    assert ansible_native_concat(["hello ", "world", "", "!"]) == "hello world!"
   

# Generated at 2022-06-22 14:30:08.855219
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:30:20.076346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_value(values, expected_value):
        assert ansible_native_concat(values()) == expected_value

    def test_fails(values, expected_error):
        try:
            ansible_native_concat(values())
        except expected_error:
            pass
        else:
            raise AssertionError('Expected exception not raised')

    def gen_values(*args):
        for value in args:
            yield value

    def literal_eval(value):
        try:
            return ast.literal_eval(value)
        except (ValueError, SyntaxError, MemoryError):
            return None

    def test_string(value):
        test_value(lambda: gen_values(value), literal_eval(value))


# Generated at 2022-06-22 14:30:31.612252
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # single node
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['True']) == 'True'
    assert ansible_native_concat(['1.0']) == '1.0'

    # single node that is a string but can be parsed as other type
    assert ansible_native_concat(['True']) == True
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0

    # single node that can't be parsed
    assert ansible_native_concat([u'1']) == u'1'

    assert ansible_

# Generated at 2022-06-22 14:30:35.630813
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 3, 4]) == 'ab34'

    assert ansible_native_concat(['a', 'b', 3, 4]) == 'ab34'

    assert ansible_native_concat(['a', 2]) == 'a2'
    assert ansible_native_concat([2, 'a']) == '2a'

    assert ansible_native_concat([text_type('a'), 2]) == 'a2'
    assert ansible_native_concat([2, text_type('a')]) == '2a'



# Generated at 2022-06-22 14:30:46.490478
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    ARGS_DATA = {
        'vars': {
            'one': 1,
            'list': [1, 2, 3],
            'mystr': 'test',
            'dict': {'a': 1, 'b': 2},
            'mystr2': "test's",
            'mystr3': '"test"',
            'mystr4': '"test',
            'mystr5': 'test"',
            'mystr6': "test's",
            'null': None,
            'other_dict': dict(a='b', b='{c}', c='{d}', d='e'),
            'obj': object(),
        },
        'method': 'ansible_native_concat',
    }

# Generated at 2022-06-22 14:31:01.272526
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Ensure that ansible_native_concat returns expected results"""

    import jinja2

    # simple concatenation of two strings
    ret = ansible_native_concat([jinja2.Markup("foo"), jinja2.Markup("bar")])
    assert ret == 'foobar'

    # simple concatenation of two strings
    ret = ansible_native_concat(["foo", "bar"])
    assert ret == 'foobar'

    # simple concatenation of two strings
    ret = ansible_native_concat([u"foo", u"bar"])
    assert ret == u'foobar'

    # simple concatenation of three strings
    ret = ansible_native_concat([u"foo", "bar", "baz"])
    assert ret == u'foobarbaz'

# Generated at 2022-06-22 14:31:11.733448
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['# Comment', 'a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(('b', 'c')) == 'bc'
    assert ansible_native_concat(['b', '', 'c']) == 'bc'
    assert ansible_native_concat([' b ', ' c ']) == ' b  c '
    assert ansible_native_concat(['True', 'False', 'None']) == 'TrueFalseNone'
    assert ansible_native_concat(['True', 'False', 'None']) == 'TrueFalseNone'

# Generated at 2022-06-22 14:31:23.289392
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText("foo")]) == "foo"
    assert ansible_native_concat([NativeJinjaText("foo"), "bar"]) == "foo bar"
    assert ansible_native_concat([NativeJinjaText("foo"), "bar", "baz"]) == "foo bar baz"
    assert ansible_native_concat([NativeJinjaText("foo"), "bar", "baz", "qux"]) == "foo bar baz qux"
    assert ansible_native_concat([NativeJinjaText("foo"), "bar", NativeJinjaText("baz"), "qux"]) == "foo bar baz qux"

# Generated at 2022-06-22 14:31:30.428460
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(iter([1, 2, 3])) == 123
    assert ansible_native_concat([1, 2, 3, 4]) == 1234
    assert ansible_native_concat([1, 2, [3, 4]]) == 12
    assert ansible_native_concat([1, 2, [3, 4], 5]) == 12
    assert ansible_native_concat([1, 2, [3, 4], 5, 6]) == 12

# Generated at 2022-06-22 14:31:40.979588
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:31:51.302808
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.collections import is_sequence


# Generated at 2022-06-22 14:32:02.493586
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment()
    env.filters['string'] = container_to_text
    env.globals['foobar'] = 'foobar'
    env.globals['foo'] = 'foo'
    env.globals['bar'] = 'bar'
    env.globals['number'] = 23

    env.filters['native_concat'] = ansible_native_concat

    def test_concat_template(template_expression, expected_result):
        """Test a given template expression against the expected result."""
        template = env.from_string(template_expression)
        actual_result = template.render()
        assert actual_result == expected_result, \
            "Template expression `%s` failed. Expected `%s`, got `%s`"

# Generated at 2022-06-22 14:32:09.145376
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = [None, False, True, 0, 1, 2, -1, -2, -3, '', 'foo', '"', "'", u'', u'foo', u'"', u"'", [], [[]], [1, 2], [[1, 2]], {}, {1:2}, '   ']
    from jinja2.nativetypes import NativeUndefined
    from jinja2.runtime import Undefined
    StrictUndefined = type(Undefined())
    for d in data:
        if isinstance(d, StrictUndefined):
            d = type(NativeUndefined)('value')

        out = ansible_native_concat([d])
        assert d == out, '%s != %s !' % (d, out)

# Generated at 2022-06-22 14:32:18.611938
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', ' ', 'bar']) == 'foo bar'
    assert ansible_native_concat(['foo', '\n', 'bar']) == 'foo\nbar'
    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', '\n', '', 'bar']) == 'foo\nbar'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([['foo', 'bar']]) == ['foo', 'bar']
    assert ansible_native_