

# Generated at 2022-06-22 14:22:31.384479
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import textwrap


# Generated at 2022-06-22 14:22:44.026073
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    #
    # test if a single variable is returned
    #
    single_var = ansible_native_concat(['foo'])
    assert single_var == 'foo'

    #
    # test if a string is returned with values being concatenated
    #
    str1 = ansible_native_concat(['foo', 'bar'])
    assert str1 == 'foobar', 'foobar != {}'.format(str1)

    #
    # test if boolean is returned
    #
    bool1 = ansible_native_concat(['true'])
    assert bool1 == True

    #
    # test if an empty list is returned
    #
    empty_list = ansible_native_concat([])
    assert empty_list == None

    #
    # test if a list of items is returned
    #

# Generated at 2022-06-22 14:22:49.943619
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from collections import OrderedDict

    from jinja2.nodes import String

    values = [
        String('foo'),
        String('bar'),
        String('1'),
        String('2'),
        String('"quoted"'),
        String('(1, 2)'),
        String('{1: 2, "foo": "bar"}'),
        String('[1, 2]'),
        String('True'),
        String('False'),
        String('None'),
    ]

    # Test multiple values
    result = ansible_native_concat(values)
    assert isinstance(result, text_type)
    assert result == u''.join([v.value for v in values])

    # Test a single value
    result = ansible_native_concat([values[0]])

# Generated at 2022-06-22 14:23:02.528574
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test the function ansible_native_concat.
    """
    # Test that integers are properly handled
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, u'3']) == "123"
    assert ansible_native_concat(["1", 2, u'3']) == "123"

    # Test that floats are properly handled
    assert ansible_native_concat([1.2]) == 1.2
    assert ansible_native_concat([1.0, 2.0, 3.0]) == 123.0
    assert ansible_native_concat([1.0, 2.0, u'3']) == "1.02.03"
    assert ans

# Generated at 2022-06-22 14:23:08.098554
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleMapping, AnsibleSequence

    out = '{{ [1, 2, 3] + [4, 5, 6] }}'
    res1 = ansible_native_concat(out)

    assert isinstance(res1, list)
    assert res1 == [1, 2, 3, 4, 5, 6]

    out = '{{ "hello " + "world" + "!" }}'
    res2 = ansible_native_concat(out)
    assert isinstance(res2, text_type)
    assert res2 == u"hello world!"

    out = '{{ [1, 2, 3] + " " + "world" + "!" }}'
    res3 = ansible_native_concat(out)

# Generated at 2022-06-22 14:23:20.815575
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # basic concatenation of string types
    concat_string = ansible_native_concat(['foo', 'bar'])
    assert concat_string == 'foobar'

    # concatenation of strings and bytes, should return string
    concat_bytes = ansible_native_concat(['foo', b'bar'])
    assert concat_bytes == 'foobar'

    # concatenation of strings and ints, should return string
    concat_int = ansible_native_concat(['foo', 0])
    assert concat_int == 'foo0'

    # concatenation of strings and floats, should return string
    concat_float = ansible_native_concat(['foo', 0.1])
    assert concat_float == 'foo0.1'

    # concatenation of ints,

# Generated at 2022-06-22 14:23:31.294068
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    actual = ansible_native_concat(['123', '4', '56'])
    assert actual == '123456'

    actual = ansible_native_concat(['123', 4, '56'])
    assert actual == '123456'

    actual = ansible_native_concat(['123', '-', 4, 5, 6])
    assert actual == '123-456'

    actual = ansible_native_concat([123, '-', 456])
    assert actual == '123-456'

    actual = ansible_native_concat([123, '-', 456, '-'])
    assert actual == '123-456-'

    actual = ansible_native_concat([123, '-', 456, '-', 789])
    assert actual == '123-456-789'


# Generated at 2022-06-22 14:23:39.104200
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([True, 2]) is True
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([1, 'b']) == '1b'
    assert ansible_native_concat([1.1, 'b']) == '1.1b'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == 'abcd'
   

# Generated at 2022-06-22 14:23:49.894851
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3

    n = ansible_native_concat
    assert n([]) is None
    assert n([1]) == 1
    assert n([1, 2]) == 12
    assert n(['1']) == 1
    assert n(['1', '2']) == 12
    assert n(['1', '2', '3']) == 123
    assert n(['1', True, '3']) == 1 is True and 3
    assert n(['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']) == 12345678910
    assert n(['x', '2', 3]) == 'x2' + to_text(3)

# Generated at 2022-06-22 14:23:58.116724
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.json_utils import from_json
    from ansible.module_utils.common.text.converters import to_json
    from ansible.module_utils.common.text.converters import to_unicode

    # `ansible_native_concat` is expected to be used with a single compiled
    # node or a chain of two.
    nodes = chain(['foo'], chain(['bar'], ['baz']))
    # The above chain is expected to be equivalent to this.
    assert 'foo' + 'bar' + 'baz' == ansible_native_concat(nodes)

    assert None == ansible_native_concat(iter([]))
    assert None == ansible_native_concat(iter([None]))
    assert None == ansible_native_

# Generated at 2022-06-22 14:24:11.810052
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_arguments(arguments, expected, encoding='utf-8'):
        result = ansible_native_concat(ansible_native_concat_gen(arguments, encoding))
        assert result == expected, "'%s' != expected '%s'" % (result, expected)

    def ansible_native_concat_gen(arguments, encoding):
        for a in arguments:
            yield a if isinstance(a, text_type) else a.decode(encoding)

    yield test_arguments, [], None
    yield test_arguments, [u'1'], 1
    yield test_arguments, [u'1', u'2'], u'12'
    yield test_arguments, [u'1', u'2', u'3'], u'123'
    yield test_arguments,

# Generated at 2022-06-22 14:24:19.811096
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["a", "b"]) == "ab"
    assert ansible_native_concat(["a", 1]) == "a1"
    assert ansible_native_concat([1, "a"]) == "1a"
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat(["a", None]) == "aNone"
    assert ansible_native_concat(["a", False]) == "aFalse"
    assert ansible_native_concat(["a", 1, 1.0]) == "a11.0"
    assert ansible_native_concat(["1", "1"]) == "11"
    assert ans

# Generated at 2022-06-22 14:24:30.922970
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test if the function can evaluate literal
    assert ansible_native_concat([1]) == 1

    # Test if the function can evaluate strings
    assert ansible_native_concat([u'1']) == u'1'

    # Test if the function can evaluate unicode strings
    assert ansible_native_concat([u'\xc3\xa5']) == u'\xc3\xa5'

    # Test if the function can evaluate container to text conversions
    assert ansible_native_concat([container_to_text([1])]) == '[1]'

    # Test if the function can evaluate a jinja2.runtime.StrictUndefined object
    assert ansible_native_concat([StrictUndefined(jinja_env=None)]) is StrictUndefined

    # Test if the function can evaluate a jinja

# Generated at 2022-06-22 14:24:43.914624
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from jinja2.loaders import DictLoader

    loader = DictLoader({
        'test_ansible_native_concat': """
---
{{ ansible_native_concat([1, 2, 3]) }}
---
{{ ansible_native_concat(ansible_native_concat([1, 2, 3])) }}
---
{{ ansible_native_concat([
    ansible_native_concat([1, 2, 3]) | string,
    ansible_native_concat([4, 5, 6]) | string,
]) | to_json }}
"""
    })

    env = jinja2.Environment(loader=loader)
    template = env.get_template('test_ansible_native_concat')
    rendered = template.render()

    ansible_

# Generated at 2022-06-22 14:24:57.056255
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import yaml
    yaml_doc = text_type(u"---\n"
                         u"- 'a'\n"
                         u"- 'b'\n"
                         u"- 'c'\n"
                         u"- 'd'\n"
                         u"- 'e'\n"
                         u"- 'f'\n"
                         u"- 'g'\n"
                         u"- 'h'\n"
                         u"...\n")
    yaml_doc_parsed = yaml.safe_load(yaml_doc)
    assert yaml_doc_parsed == ansible_native_concat(yaml_doc_parsed)
    assert u'abcdefgh' == ansible_native_concat(u'abcdefgh')
    assert u'abcdefgh' == ansible_native_

# Generated at 2022-06-22 14:25:06.412931
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import datetime

    class my_time(datetime.time):
        def __str__(self):
            return self.isoformat()

    class my_date(datetime.date):
        def __str__(self):
            return self.isoformat()

    class my_datetime(datetime.datetime):
        def __str__(self):
            return self.isoformat()

    # Test empty list
    assert ansible_native_concat([]) is None

    # Test non-string values
    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat([3.14]) == 3.14
    assert ansible_native_concat(['3']) == '3'

# Generated at 2022-06-22 14:25:15.721594
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    class UwU(object):
        string = 'uwu'
        def __str__(self):
            return self.string
    UwUwUwU = UwU()
    UwUwUwU.string = 'uwuwuuwu'

    class StrictUndefined(object):
        def __repr__(self):
            raise TypeError

    class AnsibleVaultEncryptedUnicode(object):
        def __init__(self):
            self.data = 'uwu'


# Generated at 2022-06-22 14:25:27.424608
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['foo']) == 'foo'

    assert isinstance(ansible_native_concat([u'foo']), text_type)
    assert ansible_native_concat([u'foo']) == u'foo'

    assert ansible_native_concat([1, 2, 3, 4]) == 1234
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 12345
    assert ansible_native_concat([1, 2, None, 3, 4, 5]) == 12305
    assert ansible_

# Generated at 2022-06-22 14:25:38.884934
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    # testing native concatenation
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(map(text_type, [1, 2])) == '12'
    assert ansible_native_concat(map(pow, range(10), range(10, 20))) == '00101112131415161718'

    # testing literal evaluation
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['0xa']) == 10
    assert ansible_native_concat(['0o12']) == 10
    assert ansible_native_concat(['0b1010']) == 10

# Generated at 2022-06-22 14:25:50.743414
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([['foo'], ['bar']]) == 'foobar'
    assert ansible_native_concat([['foo'], ['bar']]) == 'foobar'
    assert ansible_native_concat([['foo'], 1, ['bar'], 2, 'baz']) == 'foobarbaz'
    assert ansible_native_concat([1, 2, 3]) == 6
    assert ansible_native_concat([1, [2, 3]]) == '12, 3'

# Generated at 2022-06-22 14:25:59.217286
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.display import Display
    from ansible.utils.native_jinja import NativeJinjaText
    import ast
    import sys

    d = global_display = Display()
    d.cowsay = False

    # Handle the case where ast returns a Unicode string, as in Python 2.7
    # execution.
    if sys.version_info[0] == 2:
        def literal_eval(node):
            return ast.literal_eval(node)
    else:
        def literal_eval(node):
            return ast.literal_eval(node).decode('unicode-escape')

    def test(nodes, expected):
        if not isinstance(expected, type):
            expected = literal_eval

# Generated at 2022-06-22 14:26:09.616534
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert None == ansible_native_concat([])
    assert None == ansible_native_concat(())
    assert None == ansible_native_concat({})
    assert 'foo' == ansible_native_concat('foo')
    assert 'foo' == ansible_native_concat('foo')
    assert 'foo' == ansible_native_concat(['foo'])
    assert 'foo' == ansible_native_concat(('foo'))
    assert 'foobar' == ansible_native_concat(['foo', 'bar'])
    assert 'foobar' == ansible_native_concat(('foo', 'bar'))
    assert ['foo', 'bar'] == ansible_native_concat(['[', '"foo"', ',', '"bar"', ']'])

# Generated at 2022-06-22 14:26:19.172601
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) is 'foo'
    assert ansible_native_concat(['foo', 'bar']) is 'foobar'
    assert ansible_native_concat([1, 2, 3]) is 123
    assert ansible_native_concat([['foo', 'bar'], 'baz']) == ["foo", "bar", "baz"]
    assert ansible_native_concat(['foo', ['bar']]) == ["foo", ["bar"]]
    assert ansible_native_concat(['foo', ['bar', ['baz']]]) == ["foo", ["bar", ["baz"]]]

# Generated at 2022-06-22 14:26:31.199148
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([['foo']]) == ['foo']
    assert ansible_native_concat([[0], ['foo', 1]]) == [0, 'foo', 1]
    assert ansible_native_concat(['foo', 1]) == 'foo1'
    assert ansible_native_concat(['foo', ['bar']]) == 'foo[\'bar\']'
    assert ansible_native_concat([False, [0]]) == 'False[0]'
    assert ansible_native_concat(['1', '2']) == 3

# Generated at 2022-06-22 14:26:43.678608
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', '\\', '\\', 'b']) == 'a\\b'
    assert ansible_native_concat(['a', ' ', 'b']) == 'a b'
    assert ansible_native_concat(['a', ' ', 'b']).__class__.__name__ == 'str'
    assert isinstance(ansible_native_concat(['a', ' ', 'b']), text_type)
    assert ansible_native_concat(['a', ' ', 'b']) == u'a b'
    assert ansible_native_concat(['a', ' ', 'b']) == 'a b'

# Generated at 2022-06-22 14:26:51.172660
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment, StrictUndefined
    env = Environment(undefined=StrictUndefined)
    env.filters['to_text'] = to_text

    fail_on_undefined = env.tests['undefined']

    def test_ansible_native_concat_impl(result, *args):
        import ast as old_ast
        import types

        nodes = [object() for _ in args]
        for i, arg in enumerate(args):
            if isinstance(arg, string_types) and not isinstance(arg, text_type):
                arg = arg.decode('utf-8')
            if arg is None:
                arg = None
            elif isinstance(arg, types.GeneratorType):
                arg = [v for v in arg]
            nodes[i] = arg


# Generated at 2022-06-22 14:27:01.994991
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    import ansible.parsing.yaml.loader
    # Loader must accept a block mapping
    loader = ansible.parsing.yaml.loader.SafeLoader


# Generated at 2022-06-22 14:27:07.629696
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 43]) == '4243'
    assert ansible_native_concat(['42', 43]) == '4243'
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat([[1, 2], [3, 4]]) == '[1, 2][3, 4]'
    assert ansible_native_concat(['42', '43']) == '4243'
    assert ansible_native_concat([42, 43, 44]) == '424344'



# Generated at 2022-06-22 14:27:18.996676
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test 1: concat arguments
    assert ansible_native_concat([1, 2, 3, 4]) == 1234
    assert ansible_native_concat([['a', 'b', 'c', 'd']]) == 'abcd'
    assert ansible_native_concat([[1, 'a', 2], [3, 'b', 4]]) == '1a2 3b4'
    assert ansible_native_concat([[1, 'a', 2], [3, 'b', 4, 5]]) == '1a2 3b45'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == ['a', 'b', 'c', 'd']

# Generated at 2022-06-22 14:27:30.318141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([42, 'bar']) == '42bar'

    assert ansible_native_concat(['42', 'bar']) == '42bar'
    assert ansible_native_concat(['foo', 42]) == 'foo42'

    assert ansible_native_concat(['foo', '42', 'bar']) == 'foo42bar'
    assert ansible_native_concat(['foo', '42', 42]) == 'foo4242'

    assert ansible_native_concat(['4', '2', 'bar']) == 42
    assert ansible_native_concat(['foo', '4', '2', 'bar']) == 'foo42bar'
    assert ansible_

# Generated at 2022-06-22 14:27:45.652878
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.nodes import CallBlock, List, Name
    from jinja2.nodes import Node as _Node
    from jinja2.nodes import Output
    from jinja2.parser import Parser
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.text.converters import to_str
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.six import string_types

    # Given a template string make a CallBlock node that uses the concatenation
    # function.
    def make_call_block(template):
        tokens = Parser(template).parse()
        node = _Node(tokens)
        assert isinstance(node, Output)

# Generated at 2022-06-22 14:27:56.616936
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:28:08.010475
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) == None

    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1]) == 1

    assert ansible_native_concat(['1','2']) == '12'
    assert ansible_native_concat(['1',2]) == '12'

    assert ansible_native_concat(['1',2,'3']) == '123'
    assert ansible_native_concat(['1',2,3]) == '123'

    assert ansible_native_concat(['1.0',2,'3.0']) == '1.02.0'
    assert ansible_native_concat(['1.0',2,3.0]) == '1.02.0'

    assert ans

# Generated at 2022-06-22 14:28:21.027284
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import collections
    import jinja2

    env = jinja2.Environment(
        undefined=jinja2.StrictUndefined,
        finalize=ansible_native_concat
    )

    def _assert_final(v):
        assert isinstance(v, jinja2.runtime.Undefined)
        data = v._undefined_obj()
        assert data == v
        assert isinstance(data, StrictUndefined)
        assert isinstance(data.msg, string_types)
        assert isinstance(data.obj, jinja2.runtime.Node)

    def _assert_final_eval(v, expected):
        assert isinstance(v, jinja2.runtime.Undefined)
        data = v._undefined_obj()
        assert data == v

# Generated at 2022-06-22 14:28:26.140409
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Since this is a Jinja2 extension, the test isn't at the usual
    # place, in test/units/utils/ instead it's in test/units/jinja2/helpers.py

    # TODO: Write unit test for ansible_native_concat
    pass



# Generated at 2022-06-22 14:28:38.179246
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(['foo']) == u'foo'
    assert ansible_native_concat(['1', 2]) == u'12'
    assert ansible_native_concat([2, '1']) == u'21'
    # Test with native Jinja types, currently only NativeJinjaText
    assert isinstance(ansible_native_concat([NativeJinjaText('foo')]), text_type)

# Generated at 2022-06-22 14:28:50.993621
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1]) == 1
    assert container_to_text(ansible_native_concat([b'foo', b'bar'])) == 'foobar'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([b'foo', u'bar']) == 'foobar'
    assert ansible_native_concat([u'foo', b'bar']) == 'foobar'

    assert ansible_native_concat(['foo', True, 1, b'bar']) == 'foobar'
    assert ans

# Generated at 2022-06-22 14:29:03.183030
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2 as j2
    # implicitly calls ansible_native_concat when the final output is rendered
    env = j2.Environment(keep_trailing_newline=True)
    env.filters['to_json'] = container_to_text
    assert env.from_string('{{ [1,2,3] }}').render() == '[1, 2, 3]'
    assert env.from_string('{{ [1,2,3] | to_json }}').render() == '[1, 2, 3]'
    assert isinstance(env.from_string('{{ [1,2,3] }}').render(), list)
    assert isinstance(env.from_string('{{ [1,2,3] | to_json }}').render(), text_type)


# Generated at 2022-06-22 14:29:13.030006
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 2, u'bar', True, None]) == u'foo2barTrueNone'
    assert ansible_native_concat([u'foo', True, 2.5, None, u'bar']) == u'fooTrue2.5Nonebar'

    false_values = [u'False', u'false', u'f', u'F']

# Generated at 2022-06-22 14:29:24.877455
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(()) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([12, 34]) == 1234
    assert ansible_native_concat(['12', 34]) == '1234'
    assert ansible_native_concat(['12', '34', 56]) == '123456'
    assert ansible_native_concat([u'12', u'34']) == u'1234'
    assert ansible_native_concat(['12', [34]]) == '12[34]'
    assert ansible_native_concat(['12', {34: 56}]) == "12{34: 56}"

# Generated at 2022-06-22 14:29:39.577762
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([u'a', 'b', 'c']) == u'abc'
    assert ansible_native_concat([u'a', b'b', 'c']) == u'abc'
    assert ansible_native_concat([b'a', b'b', 'c']) == 'abc'

    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([True]) is True
    assert ans

# Generated at 2022-06-22 14:29:51.415572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', text_type('bar')]) == 'foobar'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'

    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, 2]) == '12'

# Generated at 2022-06-22 14:30:02.821062
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, None]) == '1None'
    assert ansible_native_concat([None, None]) == 'NoneNone'


# Generated at 2022-06-22 14:30:14.483853
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test single element
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([['a', 'b'], 'c']) == ['a', 'b', 'c']
    assert ansible_native_concat([{'a': 'b'}, 'c']) == [{'a': 'b'}, 'c']
    assert ansible_native_concat(['a', {'b': 'c'}]) == ['a', {'b': 'c'}]

    # test multiple elements
    assert ansible_native_con

# Generated at 2022-06-22 14:30:25.910103
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:30:35.283220
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    native_concat = lambda s, l=None: ansible_native_concat(s, list(l) if l else None)

    assert native_concat("") == ''
    assert native_concat("ab") == 'ab'
    assert native_concat("{{ a }}", [5]) == 5
    assert native_concat("{{ a }}", [5.3]) == 5.3
    assert native_concat("{{ a }}", ["{{ b }}"]) == "{{ b }}"
    assert native_concat("{{ a }}", ["{{ b }}", "{{ c }}"]) == "{{ b }}{{ c }}"
    assert native_concat("{{ 'a' }}", ["{{ 'b' }}", "{{ 'c' }}"]) == "abc"

# Generated at 2022-06-22 14:30:46.327876
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 1, 2, 3]) == u'foo123'
    assert ansible_native_concat([u'foo', u'1', u'2']) == u'foo12'
    assert ansible_native_concat([u'foo', u'1', None, u'2']) == u'foo12'
    assert ansible_native_concat([u'foo', u'1', u'2', None]) == u'foo12'
    assert ansible_native_concat([u'foo', u'1', None, u'2', None]) == u'foo12'

# Generated at 2022-06-22 14:30:58.549738
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test empty list
    assert ansible_native_concat([]) == None

    # test one element in list
    assert ansible_native_concat(["hello"]) == "hello"

    # test two elements in list
    assert ansible_native_concat(["hello", "world"]) == "helloworld"

    # test multiple elements in list
    assert ansible_native_concat(["hello", " ", "world"]) == "hello world"

    # test list of integers
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    # test list of strings and characters
    assert ansible_native_concat([1, 2, "hello"]) == "12hello"

    # test nested lists

# Generated at 2022-06-22 14:31:11.400534
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    env = jinja2.Environment()
    env.policies['ansible.native_concat'] = 'ansible.module_utils.common.text.native_concat'
    env.filters['to_text'] = to_text
    env.filters['to_json'] = container_to_text
    assert env.from_string('{{ [1, 2, 3] | to_json }}').render(env) == u'[1, 2, 3]'
    assert env.from_string('{{ 0x5A | to_json }}').render(env) == u'0x5A'
    assert env.from_string('{{ "0x5A" }}').render(env) == u'0x5A'

# Generated at 2022-06-22 14:31:23.128346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=protected-access,import-error
    from ansible.module_utils.common.collections import _AnsibleUnsafe
    from ansible.module_utils.common.text.converters import text_to_native


# Generated at 2022-06-22 14:31:38.728141
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert None is ansible_native_concat([])

    assert 'foo' is ansible_native_concat(['foo'])

    assert 'foo' is ansible_native_concat(['foo', 'bar'])

    assert (5, 3.5, 'foo', 'bar', ['a', ['b']], {'c': 'd'}) == ansible_native_concat(
        [5, '3.5', 'foo', 'bar', ['a', ['b']], '{c: d}'])

    assert 'foo bar' is ansible_native_concat(['foo', '', ' ', '', 'bar'])

    assert 5 is ansible_native_concat(['5'])

    assert (5, 6) is ansible_native_concat(['5', '', '6'])

   

# Generated at 2022-06-22 14:31:48.767172
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([container_to_text(x) for x in [1, '1']]) == '11'
    assert ansible_native_concat([container_to_text(x) for x in [1, '1', 'a']]) == '11a'
    assert ansible_native_concat([container_to_text(x) for x in ['1', 1, 'a']]) == '11a'
    assert ansible_native_concat([container_to_text(x) for x in ['1', 1]]) == '11'
    assert ansible_native_concat([container_to_text(x) for x in ['1']]) == '1'

# Generated at 2022-06-22 14:31:54.270589
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([True, True]) == "TrueTrue"
    assert ansible_native_concat(["a", 1, "b"]) == "a1b"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat([True, "a", 2, "b"]) == "Truea2b"
    assert ansible_native_concat(["a", 2, 3]) == "a23"
    assert ansible_native_concat([True, "a", 2, 3]) == "Truea23"
    assert ansible_native_concat([1, 2, "b"]) == "12b"
    assert ansible_native_concat([1, "a", "b"]) == "1ab"
    assert ansible_

# Generated at 2022-06-22 14:32:05.192521
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:32:16.639303
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    '''
    Some test cases to test the function
    '''

    def check_old_results(expected, actual):
        '''
        This functions is used to check old result and new result.

        If the new result is different from old result, it will be failed.
        '''
        expected_result = repr(expected)
        actual_result = repr(actual)
        error_str = 'Expected result is %s, but got %s ' % (expected_result, actual_result)
        assert expected == actual, error_str

    # test literal_eval and concatenation
    check_old_results(1 + 3, ansible_native_concat([1, '+', 3]))
    check_old_results('1 + 3', ansible_native_concat(['1', '+', '3']))
    check