

# Generated at 2022-06-22 14:22:21.392335
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import native_string
    from ansible.module_utils.common.text.converters import to_native

    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat(['1', 2, 3, '1', 2, 3]) == '123123'
    assert ansible_native_concat(['1', 2, 3, 4]) == '1234'
    assert ansible_native_concat(['1', 2, '1', 2, 3, 4]) == '121234'

# Generated at 2022-06-22 14:22:34.301402
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from collections import OrderedDict
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat((x for x in 'abcdef')) == 'abcdef'
    assert ansible_native_concat([42, 'a']) == '42a'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42.42]) == 42.42
    assert ansible_native_concat(['42.42']) == 42.42
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['4.2'])

# Generated at 2022-06-22 14:22:41.658823
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:22:54.113291
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestClass(object):
        def __init__(self, value):
            self.value = value

        def __repr__(self):
            return self.value

        def __str__(self):
            return self.value

    # Test string
    test_string = 'My test string'
    expected_return = 'My test string'
    assert ansible_native_concat([test_string]) == expected_return

    # Test list
    test_list = ['my', 'test', 'list']
    expected_return = ['my', 'test', 'list']
    assert ansible_native_concat([test_list]) == expected_return

    # Test integer
    test_int = 42
    expected_return = 42
    assert ansible_native_concat([test_int]) == expected_return

    # Test boolean

# Generated at 2022-06-22 14:23:07.326332
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    py_dict = str({"a": "b"})
    py_dict_bytes = b'{\'a\': \'b\'}'
    py_scalar = str(42)
    py_scalar_bytes = b'42'
    jinja_dict = container_to_text({"a": "b"})
    jinja_dict_bytes = container_to_text(b'{\'a\': \'b\'}')
    jinja_scalar = container_to_text(42)
    jinja_scalar_bytes = container_to_text(b'42')
    assert ansible_native_concat(()) is None
    assert ansible_native_concat((py_scalar,)) == py_scalar

# Generated at 2022-06-22 14:23:19.942202
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment(undefined=StrictUndefined, extensions=['ansible.utils.native_jinja.NativeJinjaExtension'])
    # python 3 requires a unicode string literal
    literal = isinstance(env.native_concat([1]), text_type)

    assert literal == True
    assert env.native_concat([]) == None
    assert env.native_concat([1]) == 1
    assert env.native_concat([1, 2, 3]) == '123'
    assert env.native_concat(['a', 'b', 'c']) == 'abc'
    assert env.native_concat(['a', 1, 'b', 2, 'c', 3]) == 'a1b2c3'

# Generated at 2022-06-22 14:23:30.647413
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['my', 'string']) == 'mystring'
    assert ansible_native_concat(['my', 'string', True]) == 'mystringTrue'
    assert ansible_native_concat(['my', 'string', True, 'hello', False]) == 'mystringTruehelloFalse'

    assert ansible_native_concat(['12', '34']) == 1234
    assert ansible_native_concat(['12', '34', False]) == '1234False'
    assert ansible_native_concat(['12', '34', False, 'hello', False]) == '1234FalsehelloFalse'

    assert ansible_native_concat(['[', '1,', '2]']) == [1, 2]

# Generated at 2022-06-22 14:23:43.106372
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    # Reuse the test cases from jinja2/nativetypes.

# Generated at 2022-06-22 14:23:54.749562
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from jinja2 import Environment, meta
    from jinja2.nodes import Node
    from ansible.module_utils.common.text.converters import to_text
    import ast

    def _literal_eval(value):
        if not isinstance(value, string_types):
            return value
        try:
            return ast.literal_eval(value)
        except (ValueError, SyntaxError):
            return value


# Generated at 2022-06-22 14:24:06.814286
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test case 1
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    # Test case 2
    assert ansible_native_concat([1]) == 1

    # Test case 3
    assert ansible_native_concat([1, 2.5]) == '1 2.5'

    # Test case 4
    assert ansible_native_concat([1, 2, 3]) is [1, 2, 3]

    # Test case 5
    assert ansible_native_concat([1, 'abc', 3]) == 1
    assert ansible_native_concat([1, 'abc', 3]) == 1

    # Test case 6
    assert ansible_native_concat(['abc', 'def', 'ghi']) == u'abcdefghi'
    assert ansible

# Generated at 2022-06-22 14:24:18.132059
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def assert_native_concat(e, *nodes):
        assert ansible_native_concat(nodes) == e

    assert_native_concat(1, 1)
    assert_native_concat(u'a:b:c', u'a', u':', u'b', u':', u'c')
    assert_native_concat(1, ast.literal_eval, u'1')
    assert_native_concat([1, 2], [1, 2])
    assert_native_concat({'a': 1}, {'a': 1})

# Generated at 2022-06-22 14:24:29.755274
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(None) is None

    # should concat
    assert ansible_native_concat(['1', '2']) == '12'

    # should not concat
    assert ansible_native_concat(['1']) == '1'

    # should force to string
    assert isinstance(ansible_native_concat(['1', 2]), text_type)

    # should raise exception for undefined
    class Undef(StrictUndefined):
        pass

    try:
        ansible_native_concat([Undef(None, None, None)])
        raise AssertionError('Should have raise exception here')
    except StrictUndefined:
        pass

    # should be able to evaluate as number

# Generated at 2022-06-22 14:24:36.819146
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['', '']) is None
    assert ansible_native_concat('abc') == 'abc'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 5]) == 'a5'
    assert ansible_native_concat(['a', True]) == 'aTrue'
    assert ansible_native_concat([['a'], ['b'], ['c']]) == ['a', 'b', 'c']
    assert ansible_native_concat([['a'], 'b', ['c']]) == ['a', 'b', 'c']

# Generated at 2022-06-22 14:24:46.767108
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for ansible_native_concat"""
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['x']) == 'x'
    assert ansible_native_concat(['x', 'y']) == 'xy'
    assert ansible_native_concat(['x', ['y', 'z']]) == 'xyz'
    assert ansible_native_concat(['x', {'y': 'z'}]) == 'xz'

    assert ansible_native_concat(['10']) == 10
    assert ansible_native_concat(['10', '20']) == '1020'
    assert ansible_native_concat([10, ['20', '30']]) == '102030'
    assert ansible_native_con

# Generated at 2022-06-22 14:24:55.946569
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, "2"]) == '12'
    assert ansible_native_concat(["1", 2]) == '12'
    assert ansible_native_concat([[1], 2]) == '12'
    assert ansible_native_concat(['\n  12']) == '12'  # string containing a leading new line



# Generated at 2022-06-22 14:25:05.539228
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', 2]) == '122'
    assert ansible_native_concat([True, False]) == 'TrueFalse'
    assert ansible_native_concat([1, 2, 3]) == 123

# Generated at 2022-06-22 14:25:15.948280
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1]) == '1'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 'a', False]) == '1aFalse'
    assert ansible_native_concat(['a', '{{ b }}']) == 'a{{ b }}'
    assert ansible_native_concat(['a', '{{ b }}', 'c']) == 'abc'
    assert ansible_native_concat(['a', '{{ b }}', 1]) == 'a{{ b }}1'
    assert ans

# Generated at 2022-06-22 14:25:27.579327
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Check concatenation of an integer and string
    assert ansible_native_concat([2, 'string']) == '2string'

    # Check concatenation of two integers
    assert ansible_native_concat([2, 3]) == 23

    # Check joining two lists of same length
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]

    # Check joining two lists of unequal length
    assert ansible_native_concat([[1, 2], [3, 4, 5]]) == '1234'

    # Check joining list and string
    assert ansible_native_concat([[1, 2], 'string']) == '1string'

    # Check joining list and an integer

# Generated at 2022-06-22 14:25:39.008778
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, 2, 3]
    assert ansible_native_concat(nodes) == 1

    nodes = [1, 2, 3, 4]
    assert ansible_native_concat(nodes) == '1234'

    nodes = [1, 2, 3, 4]
    assert ansible_native_concat(nodes, literal_eval=False) == '1234'

    nodes = ['[', 1, ',', 2, ']']
    assert ansible_native_concat(nodes) == [1, 2]

    nodes = ['{', 1, ':', 2, '}']
    assert ansible_native_concat(nodes) == {1: 2}

    nodes = ['[', 1, ',', '2', ']']

# Generated at 2022-06-22 14:25:51.690442
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    import ast

    # Test basic evaluation
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['2', 3]) == [2, 3]
    assert ansible_native_concat([ast.literal_eval('"foo"')]) == 'foo'

    # Test multi-value concatenation
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    # Test literal_eval behavior
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]

    # Test strings that cannot be parsed using literal_eval

# Generated at 2022-06-22 14:26:05.725622
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native, to_text

    # A
    assert ansible_native_concat([None, 'a']) == 'a'
    assert ansible_native_concat([None, 'a', 'b']) == 'ab'

    assert ansible_native_concat([None, 1]) == 1
    assert ansible_native_concat([None, 1, 2]) == '12'

    assert ansible_native_concat([None, True]) == True
    assert ansible_native_concat([None, True, False]) == 'TrueFalse'

    assert ansible_native_concat([None, [1]]) == [1]
    assert ansible_native_concat([None, [1], [2]]) == ['12']

    assert ans

# Generated at 2022-06-22 14:26:16.883847
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_list

    # String concatenation, can be parsed with ast.literal_eval
    assert ansible_native_concat(to_list('foo')) == 'foo'
    assert ansible_native_concat(to_list('"foo"')) == '"foo"'
    assert ansible_native_concat(to_list('"foo" "bar"')) == 'foobar'
    assert ansible_native_concat(to_list('"foo" "bar" "baz"')) == 'foobarbaz'

    # Single value, can be parsed with ast.literal_eval
    assert ansible_native_concat(to_list('foo')) == 'foo'

# Generated at 2022-06-22 14:26:29.960219
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, '1', '1.0']) == 101.0
    assert ansible_native_concat(['1', 2, 3.0]) == '123.0'
    assert ansible_native_concat(['1', '2', '3.0']) == '123.0'
    assert ansible_native_concat(['1', '2', '3.0', 5]) == '123.05'
    assert ansible_native_concat(['1', '2', '3.0', 5, ansible_native_concat(['test'])]) == '123.05test'
    assert ansible_native_concat([1, 2, 3.0]) == container_to_text(u'1 2 3.0', 'utf-8')
    assert ansible_

# Generated at 2022-06-22 14:26:42.116025
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [1, u'a', u'b', u'c', 2, u'foo']
    assert ansible_native_concat(nodes) == u'abc2foo'

    nodes = [u'a', u'b', u'\n']
    assert ansible_native_concat(nodes) == u'a\nb\n'

    nodes = [1, '+', True, u'foo']
    assert ansible_native_concat(nodes) == 2

    nodes = [1, '+', True, u'foo', u'bar']
    assert ansible_native_concat(nodes) == u'2foobar'

    nodes = [1, u'2']
    assert ansible_native_concat(nodes) == 12


# Generated at 2022-06-22 14:26:50.377108
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.compat import to_native
    from ansible.module_utils.common.text.converters import to_native_tuple, to_native_list

    # Test basic concatenation
    assert ansible_native_concat([u'f', u'o', u'o']) == u'foo'
    assert ansible_native_concat([u'f', u'o', u'o', 123]) == u'foo123'
    assert ansible_native_concat([u'', u'f', u'o', u'o', u'']) == u'foo'

    # Test handling of native Python types
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat([123, 456]) == u'123456'
   

# Generated at 2022-06-22 14:27:01.384007
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes
    assert ansible_native_concat([1, 'b', u'3', u'4']) == '1234'
    assert ansible_native_concat([1.0, 'b', u'3', u'4']) == '1.0b34'
    assert ansible_native_concat([1, 'b', u'false', u'4']) == '1bfalse4'
    assert ansible_native_concat([1, 'b', u'false', u'4']) == '1bfalse4'
    assert ansible_native_concat([to_bytes(u'1'), u'b', u'false', u'4']) == '1bfalse4'

# Generated at 2022-06-22 14:27:07.844278
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '12']) == '112'
    assert ansible_native_concat(['1.2', '12']) == '1.212'
    assert ansible_native_concat(['1.2', '12']) == '1.212'
    assert ansible_native_concat(['1.2', '12']) == '1.212'

# Generated at 2022-06-22 14:27:19.075766
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:27:27.636722
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['string']) == 'string'
    assert ansible_native_concat(['string', 'another string']) == 'stringanother string'
    assert ansible_native_concat(['string', 123]) == 'string123'
    assert ansible_native_concat(['string', 123, 'abc']) == 'string123abc'
    assert ansible_native_concat(['string', {'a': 'b'}]) == 'string{a: b}'


# Generated at 2022-06-22 14:27:36.435432
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This is required in order to test 'literal_eval' when it occurs inside
    # a list. 'ast.literal_eval' for integers works in Python 3 but not in
    # Python 2.
    if not hasattr(ast, 'Constant'):
        ast.Constant = object

    # These are the tests we run. Each is [expression, expected result]

# Generated at 2022-06-22 14:27:55.346736
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(('a',)) == 'a'
    assert ansible_native_concat(('a', 'b')) == 'ab'
    assert ansible_native_concat(('a', '1', 'b', 2)) == 'a1b2'
    assert ansible_native_concat(('a', 'b', 1, 2.0)) == 'ab12.0'
    assert ansible_native_concat(('a', 'b', 1, 2.0)) == 'ab12.0'
    assert ansible_native_concat(('a', 'b', 'c', None, None)) == 'abcNoneNone'
    # Return as strings should work with strings of all types

# Generated at 2022-06-22 14:28:06.979921
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:28:20.127569
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([['foo', 'bar'], 'baz']) == ['foobar', 'baz']
    assert ansible_native_concat([['foo', 'bar'], 'baz']) == ['foobar', 'baz']
    assert ansible_native_concat([['foo', 'bar'], 'baz']) == ['foobar', 'baz']
    assert ansible_native_concat([['foo', 'bar'], 'baz']) == ['foobar', 'baz']
    # short-circuit literal_eval for anything other than strings
    assert ansible_native_concat([123]) == 123

# Generated at 2022-06-22 14:28:32.781947
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Markup, Undefined
    from jinja2.runtime import UndefinedError
    class TestUndefined (Undefined, object):
        def __str__(self):
            raise UndefinedError('test')

    v = TestUndefined()

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(('a', 'b')) == 'ab'
    # this would be an error with the upstream-Jinja2 NativeConcat
    assert ansible_native_concat((None, 1)) is None
    assert ansible_native_concat([v]) == 'test'

    # This is the fix for https://github.com/ansible/ansible/issues/52158
    assert ansible_native_concat((v, v)) == 'test'



# Generated at 2022-06-22 14:28:38.632320
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # This test is completely equivalent to the original nativetypes.py
    # test_concat
    assert ansible_native_concat(['foo', 'bar']) == u'foobar'
    assert ansible_native_concat(iter(['foo', 'bar'])) == u'foobar'
    assert ansible_native_concat(['foo', 42]) == u'foo42'
    assert ansible_native_concat([42, 'foo']) == u'42foo'
    assert ansible_native_concat([42, 24]) == 66
    assert ansible_native_concat(['\n', 'foo']) == u'\nfoo'
    assert ansible_native_concat([u'\xff', 'foo']) == u'\xfffoo'

# Generated at 2022-06-22 14:28:51.361678
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

    # strip leading whitespace
    assert ansible_native_concat(u'\nfoo\nbar\n') == u'\nfoo\nbar\n'

    # literal eval
    assert ansible_native_concat([u'[', u'1,', u' 2,', u' 3]', u' ']) == [1, 2, 3]

    # mark as string
    assert isinstance(ansible_native_concat(NativeJinjaText(u'foo')), NativeJinjaText)

    # mark as string
    assert isinstance(ansible_native_concat(AnsibleVaultEncryptedUnicode(u'foo')), AnsibleVaultEncryptedUnicode)

    #

# Generated at 2022-06-22 14:29:03.375818
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Test empty input
    assert ansible_native_concat('') is None

    # Test a single item
    assert ansible_native_concat('a') == 'a'

    # Test a list and a dict
    assert ansible_native_concat(['a', {'b': 'c'}]) == 'a{b: c}'

    # Test numbers
    assert ansible_native_concat(1) == 1
    assert ansible_native_concat(1.1) == 1.1
    assert ansible_native_concat(1j) == 1j

    # Test True/False/None
    assert ansible_native_concat(True)
    assert not ansible_native_concat(False)
    assert ansible_native_concat(None) is None

    # Test concatenation

# Generated at 2022-06-22 14:29:13.145465
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.utils import contextfunction
    from jinja2 import Template

    @contextfunction
    def func(context):
        res = []
        for x in context.call(ansible_native_concat, context['vars']['nodes']):
            res.append(x)
        return res


# Generated at 2022-06-22 14:29:25.074885
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test merging of multiple nodes
    out = ansible_native_concat([1, 2, 3])
    assert out == 123

    # Test merging of multiple nodes which are not all of the same type
    out = ansible_native_concat([1, 2, u'3'])
    assert isinstance(out, text_type)
    assert out == "123"

    # Test merging of multiple nodes of type list
    out = ansible_native_concat([[1], [2, 3]])
    assert isinstance(out, list)
    assert out == [1, 2, 3]

    # Test merging of multiple nodes of type tuple
    out = ansible_native_concat(((1,), (2, 3)))
    assert isinstance(out, tuple)
    assert out == (1, 2, 3)

    #

# Generated at 2022-06-22 14:29:36.444717
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([None, u'bar']) is None
    assert ansible_native_concat([u'foo', None]) == u'foo'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'
   

# Generated at 2022-06-22 14:30:02.977572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Undefined(StrictUndefined):
        def __unicode__(self):
            return u'undefined'

        def __repr__(self):
            return "Undefined()"

        __str__ = __unicode__

    # in AnsibleVaultEncryptedUnicode and StrictUndefined support unicode
    # representation, in Python 2.7 strings are also returned
    undefined = Undefined()
    assert ansible_native_concat([undefined, u'b']) == u'undefinedb'
    assert ansible_native_concat([undefined, u'b']) == u'undefinedb'

    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', True]) == u'aTrue'



# Generated at 2022-06-22 14:30:14.584367
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert (ansible_native_concat(['a'])) == 'a'
    assert (ansible_native_concat(['a', 'b'])) == 'ab'
    assert (ansible_native_concat(['a', 'b', 'c'])) == 'abc'
    assert (ansible_native_concat('a')) == 'a'
    assert (ansible_native_concat('a', 'b')) == 'ab'
    assert (ansible_native_concat('a', 'b', 'c')) == 'abc'

    assert (ansible_native_concat(['a', 1])) == 'a1'
    assert (ansible_native_concat(['a', 1, 2.0])) == 'a12.0'


# Generated at 2022-06-22 14:30:26.049349
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test ansible_native_concat with no arguments.
    node = ansible_native_concat(())
    assert node is None

    # Test ansible_native_concat with a string
    node = ansible_native_concat(('abc',))
    assert node == 'abc'

    # Test ansible_native_concat with a list of strings
    node = ansible_native_concat((x for x in ['abc', 'def', 'ghi']))
    assert node == 'abcdefghi'

    # Test ansible_native_concat with a parseable string
    node = ansible_native_concat(('[1, 2, 3, "abc", "def", "ghi"]',))
    assert node == [1, 2, 3, "abc", "def", "ghi"]

    # Test

# Generated at 2022-06-22 14:30:35.329530
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.template.template import _get_template_data_loader_class

    data_loader_class = _get_template_data_loader_class()
    assert data_loader_class is AnsibleLoader

    def assert_equal(result, expected):
        assert_string = 'Expected:\n{0}\ninstead of:\n{1}\n'.format(container_to_text(expected), container_to_text(result))
        assert result == expected, assert_string

    jinja2 = J2Filters()
    assert_equal(jinja2._concat('one', 'two'), 'onetwo')
    assert_equal(jinja2._concat(['one', 'two']), 'onetwo')

# Generated at 2022-06-22 14:30:46.352066
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert [] == ansible_native_concat(())
    assert [] == ansible_native_concat([])

    assert None is ansible_native_concat(iter([]))
    assert None is ansible_native_concat(iter(()))
    assert None is ansible_native_concat(iter(()))

    assert 'x' == ansible_native_concat(['x'])
    assert 'x' == ansible_native_concat([u'x'])

    assert 1234 == ansible_native_concat([1234])

# Generated at 2022-06-22 14:30:52.227832
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3,]) == 123
    assert ansible_native_concat([u'a', 'b', 'c',]) == u'abc'
    assert ansible_native_concat([container_to_text({'key': 'value'}),]) == u'{\n    "key": "value"\n}'

# Generated at 2022-06-22 14:31:01.430764
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    class TestNative(object):
        def __str__(self):
            return 'foo'

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([TestNative()]) == 'foo'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', 2, 3]) == '123'
    assert ansible_native_concat([{'foo': 2, 'bar': [1, 2, 3]}]) == "{'bar': [1, 2, 3], 'foo': 2}"

# Generated at 2022-06-22 14:31:11.761773
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([{'a': 1}, {'b': 2}, {'c': 3}]) == {'a': 1, 'b': 2, 'c': 3}
    assert ansible_native_concat([['a'], ['b'], ['c']]) == ['a', 'b', 'c']
    assert ansible_native_concat(['foo', 1, 2, 3]) == 'foo123'
    assert ansible_native_concat(['foo', ['a'], ['b'], ['c']]) == 'fooabc'
    assert ansible_native_concat

# Generated at 2022-06-22 14:31:23.289756
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['{', '"foo":', '1', '}']) == {'foo': 1}
    assert ansible_native_concat(['"bar"']) == 'bar'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['[', '1,', '2', ']']) == [1, 2]
    assert ansible_native_concat(['[', '1,', '"' '2', '"' ']']) == [1, '2']
    assert ansible_native_concat(['[', '"a",', '"b"', ']']) == ['a', 'b']

# Generated at 2022-06-22 14:31:32.440119
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # ansible_native_concat is tested via test_template.py

    # pylint: disable=unused-variable

    # test literal_eval
    test_string = 'str(10)'
    assert ansible_native_concat(test_string) == '10'

    # test literal_eval
    test_list = "['a', 'b']"
    assert ansible_native_concat(test_list) == ['a', 'b']

    # test literal_eval
    test_list = "['a', str(10), 'b']"
    assert ansible_native_concat(test_list) == ['a', '10', 'b']

    # test literal_eval
    test_number = '10'
    assert ansible_native_concat(test_number) == 10

    # test literal_

# Generated at 2022-06-22 14:32:08.959720
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test no arguments
    assert ansible_native_concat([]) is None

    # test single argument
    argument = [42]
    assert ansible_native_concat(argument) == 42

    # test multiple arguments
    argument_1 = 'foobar'
    argument_2 = 1
    assert ansible_native_concat([argument_1, argument_2]) == 'foobar1'

    # test single argument from Tailor
    argument = NativeJinjaText('foobar', lineno=2)
    assert ansible_native_concat(argument) == 'foobar'

    # test join of generator
    def generate_strings():
        yield 'foo'
        yield 'bar'
    assert ansible_native_concat(generate_strings()) == 'foobar'

    # test single AnsibleVaultEncryptedUn