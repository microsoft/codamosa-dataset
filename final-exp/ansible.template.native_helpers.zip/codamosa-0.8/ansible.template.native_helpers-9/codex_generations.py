

# Generated at 2022-06-22 14:22:26.368906
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert (ansible_native_concat(["test", "me", "now"]) == "testmenow")
    assert (ansible_native_concat(["test", "me", "now"]) == "testmenow")
    assert (ansible_native_concat(str(None)) == None)
    assert (ansible_native_concat(str(1)) == 1)
    assert (ansible_native_concat(str(0.1)) == 0.1)
    assert (ansible_native_concat({'v': 'test'}) == '{\'v\': \'test\'}')


# Generated at 2022-06-22 14:22:39.018959
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.environment import Environment

    #
    # test without native_types enabled
    #

    env = Environment()

    # test with one argument and with argument as empty list or string
    assert ansible_native_concat(env.compile_expression('\'a\'')) == 'a'
    assert ansible_native_concat(env.compile_expression('[]')) == []
    assert ansible_native_concat(env.compile_expression('\'\'')) == ''

    # test with two arguments and compiling as an expression
    assert ansible_native_concat(env.compile_expression('[\'a\', \'b\']')) == ['a', 'b']

    # test with two arguments and compiling as a statement

# Generated at 2022-06-22 14:22:51.230852
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True

    assert ansible_native_concat([u'127.0.0.1']) == u'127.0.0.1'
    assert ansible_native_concat([1, u'127.0.0.1', 2]) == u'127.0.0.12'

    assert ansible_native_concat([u'[1,2,3]']) == [1, 2, 3]
    assert ansible_native_concat([u'[1,2,3]', u'[4,5,6]']) == [1, 2, 3]

# Generated at 2022-06-22 14:23:04.096253
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter(['foo', 'bar'])) == 'foobar'
    assert ansible_native_concat(iter(['foobar'])) == 'foobar'
    assert ansible_native_concat(iter(['foo', u'bar'])) == u'foobar'
    assert ansible_native_concat(iter([42])) == 42
    assert ansible_native_concat(iter([42, 'foo'])) == '42foo'
    assert ansible_native_concat(iter([42, u'foo'])) == u'42foo'
    assert ansible_native_concat(iter([42, 'foo', u'bar'])) == u'42foobar'

# Generated at 2022-06-22 14:23:16.993505
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ast
    import math
    from ansible.module_utils.common.text.converters import to_text, to_native
    import jinja2

    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    env = jinja2.Environment(undefined=StrictUndefined)
    env.tests['is_str'] = lambda x: isinstance(x, string_types)
    env.filters['to_str'] = lambda x: x if is_str(x) else to_text(x)
    env.tests['is_native_str'] = lambda x: isinstance(x, NativeJinjaText)

# Generated at 2022-06-22 14:23:28.844406
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:23:41.789847
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['1', '2', '3']) == [1, 2, 3]
    assert ansible_native_concat(['1', 'True', '3']) == ['1', True, 3]
    assert ansible_native_concat(['1', 'False', '3']) == ['1', False, 3]
    assert ansible_native_concat(['1', 'None', '3']) == ['1', None, 3]
    assert ansible_native_concat(['1.1', '2.2', '3.3']) == [1.1, 2.2, 3.3]

# Generated at 2022-06-22 14:23:54.020356
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # We are doing this trick here to import a module in a different manner than jinja2
    # does. The module has to be loaded from a different path, since the fact that we
    # are running in a test changes the path for the jinja module
    import sys
    import os
    import imp
    import jinja2.testsuite
    new_path = list(filter(lambda x: x.endswith('jinja2'), sys.path))
    if len(new_path) != 1:
        raise Exception("New jinja2 path missing from sys.path")
    new_path = os.path.join(new_path[0], 'testsuite')

# Generated at 2022-06-22 14:24:05.711387
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([5]) == 5
    assert ansible_native_concat([5, 6]) == '56'
    assert ansible_native_concat([5, 6, 7]) == '567'
    assert ansible_native_concat([5, 'b']) == '5b'

    # Mark text as "safe" explicitly so that literal_eval is not called.
   

# Generated at 2022-06-22 14:24:17.000840
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import convert_to_native_type, boolean
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.common.text.formatters import to_nice_yaml
    from ansible.parsing.vault import VaultLib
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([boolean(True)])
    assert ansible_native_concat([boolean(True), None])

    assert ansible_native_concat([to_text('abc')]) == 'abc'

# Generated at 2022-06-22 14:24:31.186843
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.ansible.community.plugins.filter.native import AnsibleNativeJinjaBridge

    nodes = [('literal', u'foo'),
             ('literal', u'bar'),
             ('literal', u'baz')]

    output = ansible_native_concat(iter(nodes))
    assert output == u'foobarbaz'

    output = ansible_native_concat(iter(nodes[0:1]))
    assert output == u'foo'

    output = ansible_native_concat(iter(nodes[1:2]))
    assert output == u'bar'

    output = ansible_native_concat(iter([('literal', u'[1,2,3]')]))
    assert output == [1,2,3]

    bridge = Ans

# Generated at 2022-06-22 14:24:44.213865
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2, 3]) == '23'
    assert ansible_native_concat([4, 5, 6]) == '456'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-22 14:24:57.222898
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """
    >>> test_ansible_native_concat()
    """
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.text.converters import to_bytes

    # Test concatenation
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'
    assert ansible_native_concat([u'foo', u'', u'bar', u'baz']) == u'foobarbaz'
    assert ansible_native_concat([u'foo', u'  ', u'bar', u'baz']) == u'foo  barbaz'

# Generated at 2022-06-22 14:25:06.505544
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-22 14:25:16.113628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.sandbox import SandboxedEnvironment

    env = SandboxedEnvironment()
    env.undefined = StrictUndefined
    env.filters['ansible_native_concat'] = ansible_native_concat

    def test(template, expected_response):
        t = env.from_string('{{%s}}' % template)
        assert t.render() == container_to_text(expected_response)

    # Testing string concatenation
    test('"" | ansible_native_concat', '')
    test(r'[] | ansible_native_concat', '')
    test(r'[1] | ansible_native_concat', '1')
    test(r'[1, 2] | ansible_native_concat', '12')

# Generated at 2022-06-22 14:25:28.093785
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # checking concatenation of strings
    assert (ansible_native_concat(['foo', 'bar']) == 'foobar')
    assert (ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz')

    # checking concatenation of numbers
    assert (ansible_native_concat([1, 2]) == 3)
    assert (ansible_native_concat([1, 2, 3]) == 6)
    assert (ansible_native_concat([1, 2, 3, 4, 5]) == 15)

    # checking concatenation of list
    assert (ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4])

# Generated at 2022-06-22 14:25:37.716462
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert isinstance(ansible_native_concat([1]), int)
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1, u'2']) == u'12'
    assert ansible_native_concat([1, u'2']) == 12
    assert isinstance(ansible_native_concat([u'1', u'2']), text_type)
    assert ansible_native_concat([u'1', u'2']) == u'12'



# Generated at 2022-06-22 14:25:43.268248
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Undefined

    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['abc', ' def', 123]) == 'abc def123'
    assert ansible_native_concat([1, '2', 3]) == '123'

    assert ansible_native_concat([Undefined()]) == Undefined()
    assert ansible_native_concat([Undefined(), 1]) == Undefined()
    assert ansible_native_concat

# Generated at 2022-06-22 14:25:54.421286
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data_str = '{"foo": "bar"}'
    data_dict = dict(foo='bar')

    assert ansible_native_concat([data_str]) == data_str
    assert ansible_native_concat(data_dict) == data_dict
    assert ansible_native_concat(data_dict.values()) == container_to_text(data_dict.values())
    assert ansible_native_concat((x for x in data_dict.values())) == container_to_text(data_dict.values())
    assert ansible_native_concat([data_str, data_str]) == '{0}{0}'.format(data_str)
    assert ansible_native_concat([data_str, data_str]) == '{0}{0}'.format(data_str)

# Generated at 2022-06-22 14:26:05.649436
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, "StrictUndefined", 3]) is Undefined
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', 'StrictUndefined', 'c']) == 'abc'
    assert ansible_native_concat(["'", "'", "'"]) == "'''"
    assert ansible_native_concat(["'", "'", "StrictUndefined", "'"]) == "'''"
    assert ansible_native_concat(['"', '"', '"']) == '"""'

# Generated at 2022-06-22 14:26:19.678289
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode

    class TestObj:
        def __str__(self):
            return '<str>'

        def __unicode__(self):
            return '<unicode>'

    class TestNativeJinjaText(NativeJinjaText):
        pass

    # tests
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([[], [], []]) == '[]'
    assert ansible_native_concat(['1', '2']) == '12'

# Generated at 2022-06-22 14:26:31.661739
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Note: We don't assert map() call.  It's not part of the logic.
    # See https://github.com/ansible/ansible/issues/52013

    # Ensure return is None on zero elements
    assert ansible_native_concat(map(ansible_native_concat, [])) is None
    assert ansible_native_concat(map(ansible_native_concat, [[]])) is None

    # Ensure return is single value on single element
    assert ansible_native_concat(map(ansible_native_concat, [1])) is 1
    assert ansible_native_concat(map(ansible_native_concat, [True])) is True
    assert ansible_native_concat(map(ansible_native_concat, [None])) is None
    assert ansible

# Generated at 2022-06-22 14:26:44.296932
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat(xrange(1, 4)) == u'123'
    assert ansible_native_concat([[1], 2, [3]]) == u'[1]23'
    assert ansible_native_concat([{1: 'a', 2: 'b'}, [3]]) == u"{1: 'a', 2: 'b'}[3]"

    assert ansible_native_concat(['a']) == 'a'

# Generated at 2022-06-22 14:26:51.441179
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test with data in various formats to determine if we are properly
    serializing values to native python types.
    """

    # Test that ansible_native_concat respects the configurable behavior
    # of jinja2.meta.find_undeclared_variables


# Generated at 2022-06-22 14:27:02.193177
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:27:08.242032
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # Testing tuple
    input_tuple = tuple([875])
    output_tuple = ansible_native_concat(input_tuple)
    assert output_tuple == 875

    # Testing list
    input_list = list([875])
    output_list = ansible_native_concat(input_list)
    assert output_list == 875

    # Testing set
    input_set = set([875])
    output_set = ansible_native_concat(input_set)
    assert output_set == 875

    # Testing frozenset
    input_frozenset = frozenset([875])
    output_frozenset = ansible_native_concat(input_frozenset)
    assert output_frozenset == 875

    # Testing string

# Generated at 2022-06-22 14:27:14.903914
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    ast_literal_eval_test_values = [
        (u"test_string", u"test_string"),
        (u"123", 123),
        (u"123.456", 123.456)
    ]
    for (value_before, value_after) in ast_literal_eval_test_values:
        assert ansible_native_concat([value_before]) == value_after



# Generated at 2022-06-22 14:27:23.143568
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3

    # A standard concatenation of two strings
    expr = '[{{ "foo" }}, {{ "bar" }}]'
    result = ansible_native_concat(expr)
    assert result == 'foobar'

    # A standard concatenation of string with a number
    expr = '[{{ "foo" }}, {{ 42 }}]'
    result = ansible_native_concat(expr)
    assert result == 'foo42'

    # A standard concatenation of string with a number
    expr = '[{{ 42 }}, {{ "foo" }}]'
    result = ansible_native_concat(expr)
    assert result == '42foo'

    # A standard concatenation of string with a number and a float

# Generated at 2022-06-22 14:27:33.700309
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1,2,3]) == '123'
    assert ansible_native_concat([1,2,3,4]) == '1234'
    assert ansible_native_concat([1,2,3,4]) == '1234'
    assert ansible_native_concat([1,2,3,4,5,6]) == '123456'
    assert ansible_native_concat([1,2,3,4,5,6,7,8]) == '12345678'
    assert ansible_native_concat([1,2,3,4,5,6,7,8,9,10]) == '12345678910'

# Generated at 2022-06-22 14:27:45.652505
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test concatenation of native types."""
    # Test empty nodes
    nodes = []
    assert ansible_native_concat(nodes) is None

    # Test single node
    nodes = [True]
    assert ansible_native_concat(nodes)

    nodes = ['string']
    assert ansible_native_concat(nodes) == 'string'

    nodes = [{'key': 'value'}]
    assert ansible_native_concat(nodes) == {'key': 'value'}

    # Test multiple nodes
    nodes = [True, 'string', {'key': 'value'}]
    assert ansible_native_concat(nodes) == 'True string {key: value}'

    nodes = ['string', {'key': 'value'}]
    assert ansible_native

# Generated at 2022-06-22 14:27:58.245042
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([[]]) is None
    assert ansible_native_concat([2]) == 2
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat([2, "foo", "bar", 4]) == 2
    assert ansible_native_concat(["2", "foo", "bar", "4"]) == "24"
    assert ansible_native_concat(["[[[", "foo", "bar", "]]]"]) == "[[[foobar]]]"

# Generated at 2022-06-22 14:28:09.108722
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["a"]) == u"a"
    assert ansible_native_concat([1, "a"]) == u"1a"
    assert ansible_native_concat([1, "a",
                                  {"b": 1, "c": ["d"], "e": (2, 3)},
                                  "f"]) == u"1a{'b': 1, 'c': ['d'], 'e': (2, 3)}f"

# Generated at 2022-06-22 14:28:21.397465
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo"]) == "foo"
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["foo", 123]) == "foo123"
    assert ansible_native_concat(["foo", "bar", 123]) == "foobar123"

    foo_bar_num_list = ["foo", "bar", 123]
    assert ansible_native_concat(foo_bar_num_list) == "foobar123"

    assert ansible_native_concat(["one two"]) == "one two"
    assert ansible_native_concat(["one", "two"]) == "onetwo"

# Generated at 2022-06-22 14:28:31.946482
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from jinja2.environment import Environment

    env = Environment(
        loader=jinja2.DictLoader({
            'good': "{{ [1, 2, 3] | map('int') | list }}",
            'bad': "{{ (1, 2, 3) | tuple }}",
            'very_bad': "{{ bad | ansible_native_concat }}",
        }),
    )
    assert env.get_template('good').render() == "True"
    assert env.get_template('bad').render() == "[1, 2, 3]"
    assert env.get_template('very_bad').render() == "[1, 2, 3]"

# Generated at 2022-06-22 14:28:45.180232
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.formatters import (
        to_yaml, to_json, to_nice_yaml, to_nice_json
    )

    def format_args(args, text_format):
        return [text_format(arg) for arg in args]

    # Note: Undefined values are not allowed in the tests.
    # Covered by tests in test_utils_native_jinja.py

    # Note: AnsibleVaultEncryptedUnicode data is replaced by its data attribute
    # Covered by tests in test_utils_native_jinja.py

    def assert_result_in(args, expected_results, text_format=None):
        if text_format is None:
            text_format = to_text

        args = format_args(args, text_format)

        result

# Generated at 2022-06-22 14:28:57.845910
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'bar']) == '1bar'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['foo', 2]) == 'foo2'
    assert ansible_native_concat([1, 'x', 2, 'y', 3, 'z']) == '1x2y3z'
    assert ansible_native_concat([1, 'x', 2, 'y', 3, 'z']) == '1x2y3z'

# Generated at 2022-06-22 14:29:07.504064
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.loader import AnsibleLoader

    data = dict(
        list_of_strings=[1, 2, 3],
        list_of_lists=[[4, 5], [6, 7]],
        list_of_strings_and_lists=[[8, 9], 10],
    )
    data_str = container_to_text(data)

    # Test list with only strings
    loader = AnsibleLoader(data_str, None, list_errors=True)
    result = list(ansible_native_concat(loader.get_single_data()['list_of_strings']))
    assert result == [1, 2, 3]

    # Test list with strings and lists
    loader = AnsibleLoader(data_str, None, list_errors=True)

# Generated at 2022-06-22 14:29:15.666616
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([u'ab', u'cd']) == u'abcd'
    assert ansible_native_concat([u'ab', u'cd', u'ef']) == u'abcdef'

    assert ansible_native_concat([u'a', u'2']) == u'a2'
    assert ansible_native_concat([u'1', u'2']) == 12

    assert ansible_native_concat([u'0b10']) == 2
    assert ansible_native_concat([u'0o10']) == 8
    assert ansible_native_concat([u'0x10']) == 16

    assert ansible_native_concat([u'"a"']) == u'a'

# Generated at 2022-06-22 14:29:28.005373
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.utils.unsafe_proxy
    import jinja2

    # String is returned
    assert ansible_native_concat(['foo']) == 'foo'

    # String concatenation
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    # List is returned
    assert ansible_native_concat([['foo']]) == ['foo']

    # List concatenation
    assert ansible_native_concat([['foo'], ['bar']]) == ['foo', 'bar']

    # Can be parsed from literal_eval
    assert ansible_native_concat([0]) == 0

    # literal_eval does not throw error
    assert ansible_native_concat(['10e500']) == u'10e500'
    assert ansible_native

# Generated at 2022-06-22 14:29:38.851310
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=missing-docstring
    # pylint: disable=too-many-locals
    import types
    from jinja2.runtime import Undefined

    n = ansible_native_concat
    # pylint: disable=protected-access
    # we're not calling _fail_on_undefined directly here
    uu = StrictUndefined('failed')

    assert n([]) == None
    assert n([42]) == 42
    assert n([42, 24]) == '4224'
    assert n(['foo']) == 'foo'
    assert n(['foo', 'bar']) == 'foobar'
    assert n(types.GeneratorType(lambda: iter(['foo', 'bar']), (), {})) == 'foobar'

# Generated at 2022-06-22 14:29:53.529072
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['3.14']) == 3.14

    assert ansible_native_concat(['true', 'false', 'true']) is True
    assert ansible_native_concat(['false']) is False

    assert ansible_native_concat(['[1, 2, 3]', '[4, 5, 6]']) == [1, 2, 3, 4, 5, 6]
    assert ansible_native_concat(['{"a": 1}', '{"b": 2}']) == {u'a': 1, u'b': 2}



# Generated at 2022-06-22 14:30:05.200841
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert isinstance(ansible_native_concat(['1']), int)
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'

    assert isinstance(ansible_native_concat(['1.']), float)
    assert ansible_native_concat(['1.', '2']) == '1.2'
    assert ansible_native_

# Generated at 2022-06-22 14:30:17.205847
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    d = {'k': [1, 2]}
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([d, 2]) == [d, 2]
    assert ansible_native_concat(["1", "2"]) == "12"
    assert ansible_native_concat(['1', 2]) == "12"
    assert ansible_native_concat(['ab', u'\u2603']) == u"ab☃"
    assert ansible_native_concat(['ab', u'\u2603'.encode('utf-8'), 'c']) == u"ab☃c"
    assert ansible_native_concat(["1", 2.0]) == "12.0"
    assert ansible_native_concat

# Generated at 2022-06-22 14:30:30.155572
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.environment import Environment
    from jinja2.lexer import Token, Lexer
    from jinja2.parser import Parser

    env = Environment(extensions=['jinja2.ext.do'])
    env.globals['concat'] = ansible_native_concat

    # Test a table of expressions and the expected results when used in
    # a jinja2 template. Each expression is compiled into multiple nodes by
    # the jinja2 parser and then the concatenation function is used to
    # convert them into a single value.

# Generated at 2022-06-22 14:30:43.043438
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:30:57.080111
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = [u'0', u'1']
    assert ansible_native_concat(nodes) == [u'0', u'1']

    nodes = [u'abc', u'123']
    assert ansible_native_concat(nodes) == u'abc123'

    nodes = [u'10']
    assert ansible_native_concat(nodes) == 10

    nodes = [u'true']
    assert ansible_native_concat(nodes) == True

    nodes = [u'false']
    assert ansible_native_concat(nodes) == False

    nodes = [u'null']
    assert ansible_native_concat(nodes) == None

    nodes = [u'abc']
    assert ansible_native_concat(nodes) == u'abc'

   

# Generated at 2022-06-22 14:31:09.959133
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 123]) == 'a123'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['0', 'b']) == '0b'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', ' b']) == 'a b'
    assert ansible_native_concat(['a ', 'b']) == 'a b'
    assert ansible_native_concat(['a', ' b'])

# Generated at 2022-06-22 14:31:22.469750
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2.runtime import Undefined
    from ansible.module_utils.common.text.converters import to_unicode
    from ansible.module_utils.common.collections import Mapping
    from ansible.module_utils.six import PY2


# Generated at 2022-06-22 14:31:29.930770
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1

    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat(iter([1, 2, 3])) == u'123'

    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat(iter([u'foo'])) == u'foo'

    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ans

# Generated at 2022-06-22 14:31:40.759859
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    env = jinja2.Environment(
        undefined=jinja2.StrictUndefined,
        variable_start_string='{',
        variable_end_string='}',
        trim_blocks=True,
        lstrip_blocks=True,
        extensions=[
            'jinja2.ext.do',
            'jinja2.ext.loopcontrols',
            'jinja2.ext.with_',
            'jinja2.ext.autoescape',
            'jinja2.ext.i18n',
            'jinja2.ext.import_helpers',
        ],
        autoescape=True,
        loader=jinja2.DictLoader({}),
    )

    env.filters['native_concat'] = ansible_native_concat

# Generated at 2022-06-22 14:31:51.427822
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['test', 'ing']) == 'testing'
    assert ansible_native_concat(['test', 1]) == 'test1'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['{"foo":', '"bar"}']) == {"foo": "bar"}
    assert ansible_native_concat([[1, 2], 3]) == [1, 2, 3]



# Generated at 2022-06-22 14:32:02.924797
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test for literal_eval
    nodes = ['"a"', '"b"']
    out = ansible_native_concat(nodes)
    assert out == 'ab'

    nodes = ['2', '2']
    out = ansible_native_concat(nodes)
    assert out == 4

    # Test for literal_eval with single node
    nodes = ['2']
    out = ansible_native_concat(nodes)
    assert out == 2

    nodes = ['"2"']
    out = ansible_native_concat(nodes)
    assert out == '2'

    # Test for literal_eval with special chars
    nodes = ['', '"$"', '"{"', '"a"', '":1"', '"}"']

# Generated at 2022-06-22 14:32:09.284101
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text import native_json

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['FALSE']) is False
    assert ansible_native_concat(['null']) is None
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['[42]']) == [42]
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

# Generated at 2022-06-22 14:32:18.634983
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Check single value
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat(["1"]) == "1"
    assert ansible_native_concat([u"1"]) == u"1"
    assert ansible_native_concat([""]) == ""
    assert ansible_native_concat([None]) is None

    # Check multi value
    assert ansible_native_concat([True, True]) == "TrueTrue"
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1.0, 2.0]) == "1.02.0"
   