

# Generated at 2022-06-22 14:22:21.936009
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.common._collections_compat import Mapping, Sequence
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    # Non-strings
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1, 2, 3]) == 1

    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([True, False]) == True
    assert ansible_native_concat([True, False, True]) == True
    assert ans

# Generated at 2022-06-22 14:22:34.720955
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test bool
    assert True == ansible_native_concat([True])
    # test int
    assert 42 == ansible_native_concat([42])
    # test string
    assert 'test' == ansible_native_concat(['test'])
    # test list
    assert ['test', '1', '2'] == ansible_native_concat([['test', '1', '2']])
    # test dict
    assert {'test': '1', '2': '3'} == ansible_native_concat([{'test': '1', '2': '3'}])
    # test None
    assert None == ansible_native_concat([None])

    # test concatenation of multiple variables of different types

# Generated at 2022-06-22 14:22:41.708804
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # unicode strings
    assert ansible_native_concat([u'hello']) == 'hello'
    assert ansible_native_concat([u"hello", u'world']) == 'helloworld'
    assert ansible_native_concat([u'1']) == 1
    assert ansible_native_concat([u'5.5']) == 5.5
    assert ansible_native_concat([u'[1, 2]']) == [1, 2]
    assert ansible_native_concat([u'{"key": "value"}']) == {"key": "value"}
    assert ansible_native_concat([u'True']) is True
    assert ansible_native_concat([u'None']) is None
    # Convert non-unicode strings to unicode
    assert ansible_native

# Generated at 2022-06-22 14:22:48.825112
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _check(nodes, result):
        assert ansible_native_concat(nodes) == result

    _check([], None)
    _check([1], 1)
    _check([1.0], 1.0)
    _check([1j], 1j)
    _check(['a'], 'a')
    _check([[1, 2]], [1, 2])
    _check([{'a': 1}], {'a': 1})

    _check([1, 'a'], '1a')
    _check([1, 'a', 2], '1a2')
    _check([1, 'a', 2j], '1a2j')
    _check([1j, 'a', 2], '1j*2a')


# Generated at 2022-06-22 14:23:01.968939
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Function ansible_native_concat returns a native Python type
    """
    native_concat = ansible_native_concat

    assert native_concat([]) == None
    assert native_concat([u' ']) == u' '
    assert native_concat([u' ']) == u' '
    assert native_concat([u' ']) == u' '

    assert native_concat([u'foo']) == u'foo'
    assert native_concat([u'foo']) == u'foo'
    assert native_concat([u'foo']) == u'foo'

    assert native_concat([u'foo', u'bar']) == u'foobar'
    assert native_concat([u'foo', u'bar']) == u'foobar'

# Generated at 2022-06-22 14:23:13.989508
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['abc']) == 'abc'

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'

    assert ansible_native_concat([1, 2.3]) == u'12.3'
    assert ansible_native_concat(['1', '2.3']) == u'12.3'

    assert ansible_native_concat(['1', 2.3]) == u'12.3'
    assert ansible_native_concat([1, '2.3']) == u'12.3'

    assert ansible_native_concat([1, 2.3, u'4']) == u'12.34'


# Generated at 2022-06-22 14:23:27.289200
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import doctest
    import jinja2
    import sys

    env = jinja2.Environment(
        undefined=jinja2.StrictUndefined,
        finalize=ansible_native_concat
    )

    class FakeCompiler(object):
        def __init__(self, nodes):
            self.nodes = nodes

    class FakeCodeGenerator(object):
        def __init__(self, code):
            self.code = code

    class FakeVisitor(object):
        def __init__(self):
            self.frame = None

        def visit_List(self, node):
            # visit nested Constant nodes to ensure proper finalization
            node.items = [self.visit(item) for item in node.items]

            return node


# Generated at 2022-06-22 14:23:36.105039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.jinjautils import ansible_native_concat
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText, AnsibleUnsafeBytes

    assert ansible_native_concat(list()) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42, 43]) == '4243'

    assert ansible_native_concat([AnsibleUnsafeBytes(b'\xe2\x82\xac')]) == '\xe2\x82\xac'
    assert ansible_native_concat([AnsibleUnsafeText('\xe2\x82\xac')]) == '\xe2\x82\xac'


# Generated at 2022-06-22 14:23:47.784607
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import json_loads
    natives = (True, False, None, 100, 0.0, 'test', u"test_unicode",
               frozenset(['test']), (1, 2, 3))
    for native in natives:
        assert native == ansible_native_concat([native])

    for native in natives:
        assert native == ansible_native_concat([native, native])

    strings = [u'{0}'.format(native) for native in natives]
    assert u''.join(strings) == ansible_native_concat(strings)

    # Sequence of native types on the right side of a concat operation
    # will be converted to strings.
    assert ''.join(strings) == ansible_native_concat([strings])

    # Jin

# Generated at 2022-06-22 14:23:57.059477
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None, None]) is None
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', [], 3, None]) == 'foo3None'
    assert ansible_native_concat(['1', '2', '3']) == [1, 2, 3]
    assert ansible_native_concat([['foo', 'bar'], ['1', '2']]) == [['foo', 'bar'], ['1', '2']]



# Generated at 2022-06-22 14:24:10.543464
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class TestUndefined(StrictUndefined):
        def __str__(self):
            raise self.undefined_exception(self)

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1
    assert isinstance(ansible_native_concat([NativeJinjaText('a')]), NativeJinjaText)
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 1, u'baz']) == u'foo1baz'

# Generated at 2022-06-22 14:24:19.304815
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u"foobar"
    assert ansible_native_concat([u'Foo ', u'', u' bar']) == u"Foo   bar"
    assert ansible_native_concat([u'True']) == True
    assert ansible_native_concat([u'False']) == False
    assert ansible_native_concat([u'1', u'3']) == 13
    assert ansible_native_concat([u'0o11', u'3']) == 83
    assert ansible_native_concat([u'0x11', u'3']) == 273
    assert ansible_native_concat([u'1.2', u'3']) == 1.23
    assert ansible_native_concat

# Generated at 2022-06-22 14:24:30.098043
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['123', 'foo']) == '123foo'
    assert ansible_native_concat([['123']]) == ['123']
    assert ansible_native_concat(['', 123]) == 123
    assert ansible_native_concat(['', [123]]) == [123]
    assert ansible_native_concat([None]) is None

# TODO: implement and test filter_concat
# https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py



# Generated at 2022-06-22 14:24:36.491032
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat([u'foo', u'bar', u'baz']) == u'foobarbaz'

# Generated at 2022-06-22 14:24:46.593229
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, [], 3]) == '13'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat([1, '2', [3]]) == '123'
    assert ansible_native_concat([1, {'foo': 'bar'}, 3]) == '1{0}{2}'.format(container_to_text({'foo': 'bar'}), text_type(None), '3')
    assert ansible_native_

# Generated at 2022-06-22 14:24:58.220954
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = ['1', '2', '3']
    assert ansible_native_concat(nodes) == 123
    nodes = ['1', '2', '3', 3]
    assert ansible_native_concat(nodes) == 123
    nodes = ['1', '2', 'true']
    assert ansible_native_concat(nodes) == '123true'
    nodes = ['1', '2', 'true', True]
    assert ansible_native_concat(nodes) == '123trueTrue'
    # https://github.com/pallets/jinja/issues/1200
    nodes = ['1', '2', '"true"']
    assert ansible_native_concat(nodes) == '123"true"'


# Generated at 2022-06-22 14:25:09.263828
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:25:19.246342
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml import objects

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(iter([])) == None

    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', u'b', 'c']) == 'abc'
    # same as previous test, but iterable
    assert ansible_native_concat(['a', u'b', 'c']) == 'abc'
    assert ansible_native_concat([None, None, None]) == None
    assert ansible_native_concat(['a', 'b', None]) == 'ab'
    # same as previous test,

# Generated at 2022-06-22 14:25:31.425736
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.dataloader import DataLoader
    import jinja2
    import sys
    import unittest

    class TestAnsibleNativeConcat(unittest.TestCase):
        def setUp(self):
            self.loader = DataLoader()

            # in Python 2.6 and 2.7, dicts are not ordered
            if sys.version_info[:2] in ((2, 6), (2, 7)):
                self.skipTest("No dict order in Python 2.6 or Python 2.7")

            # compile the test template using the native extension
            self.env = jinja2.Environment(extensions=["ansible.module_utils.jinja2.nativetypes"])
            self.env.filters["thing"] = lambda x: x
            self.test_template = self

# Generated at 2022-06-22 14:25:41.228201
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert "test" == ansible_native_concat(["test"])
    assert 1 == ansible_native_concat(["1"])
    assert 1 == ansible_native_concat(["1.0"])
    assert 1 == ansible_native_concat(["1.000000000000000"])
    assert 1.0 == ansible_native_concat(["1.0"])
    assert 1.000000000000000 == ansible_native_concat(["1.000000000000000"])
    assert [1] == ansible_native_concat(["[1]"])
    assert {"k": "v"} == ansible_native_concat(["{'k': 'v'}"])

# Generated at 2022-06-22 14:25:54.458446
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat("xyz") == "xyz"
    assert ansible_native_concat("x{{ z }}y") == "x{{ z }}y"
    assert ansible_native_concat("x{{ \"y\" }}z") == "xyz"
    assert ansible_native_concat("x{{ 1 }}y") == "x1y"
    assert ansible_native_concat("{{ 1 }}{{ 2 }}") == "12"
    assert ansible_native_concat("x{{ True }}y") is True
    assert ansible_native_concat("{{ True }}{{ False }}") is False
    assert ansible_native_concat("{{ True }}{{ True }}") is True
    assert ansible_native_

# Generated at 2022-06-22 14:26:05.647541
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class _TestUndefined(object):
        def __init__(self, name):
            self.name = name

        def __str__(self):
            raise UndefinedError('Find undefined %s' % self.name)

    undefined = _TestUndefined('value')

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', ' b']) == 'a b'
    assert ansible_native_concat(['a', ' b', ' c']) == 'a b c'
    assert ansible_native_concat([123]) == 123
    assert ansible_native_concat(['123'])

# Generated at 2022-06-22 14:26:16.886447
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert not ansible_native_concat([])
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 2]) == u'foo2'
    assert ansible_native_concat([[u'foo'], u'bar']) == [u'foo', u'bar']
    assert ansible_native_concat([[u'foo'], [u'bar']]) == [u'foo', u'bar']
    assert ansible_native_concat([u'foo', [u'bar']]) == u'foobar'
    assert ansible_native_

# Generated at 2022-06-22 14:26:23.622363
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class FakeNode:
        # These are defined in the upstream implementation
        # See: https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py#L52
        #      https://github.com/pallets/jinja/blob/master/src/jinja2/visitor.py
        def set_ctx(self, ctx):
            self.ctx = ctx
            return self

        def iter_fields(self):
            yield 'value', self.value

        # Our version of the test doesn't require value (as it is used in upstream)
        # We just need a to_string function that returns a string
        def __str__(self):
            return self.value

    def assert_concat_equal(nodes, expected):
        assert expected == ansible_native_con

# Generated at 2022-06-22 14:26:34.531134
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['abc']) == 'abc'

    # test ast.literal_eval
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['123']) == 123
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['{"key": "value", "key2": "value2"}']) == {"key": "value", "key2": "value2"}
    assert ansible_native_concat(['(1, 2, 3)']) == (1, 2, 3)

# Generated at 2022-06-22 14:26:45.889914
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.dataloader import DataLoader
    from ansible.template.safe_eval import ast_eval, AnsibleUndefined

    def _check(value, expected):
        out = ansible_native_concat(value)
        assert out == expected, "expected {0}, got {1} (type {2})".format(
            container_to_text(expected, quote=True),
            container_to_text(out, quote=True),
            out.__class__,
        )

    loader = DataLoader()

    # test literal_eval
    _check([u'sub(r"\\n", " ", "test\\ntest")'], u'sub(r"\n", " ", "test\ntest")')

# Generated at 2022-06-22 14:26:57.936594
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Node:
        def __init__(self, value):
            self.value = value
        def __str__(self):
            return str(self.value)
        def __unicode__(self):
            return text_type(self.value)

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([Node(1)]) == 1
    assert ansible_native_concat([Node(1), Node(2)]) == [1, 2]
    assert ansible_native_concat([Node('1'), Node('2')]) == '12'
    assert ansible_native_concat([Node('1 2')]) == [1, 2]
    assert ansible_native_concat([Node('1 2'), Node('3 4')]) == '1 2 3 4'
    assert ans

# Generated at 2022-06-22 14:27:06.008341
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    test_cases = [
        # test prefix/suffix handling
        (['foo', 'bar'], 'foobar'),
        # test single node handling
        (['foobar'], 'foobar'),
        # test empty list
        ([], None),
        # test literal eval
        (['[1, 2, 3]'], [1, 2, 3]),
        # test literal eval failure
        (['1 + 2 + "foo"'], '1 + 2 + "foo"'),
        # test literal eval failure
        (['"a" + "b" "c"'], '"a" + "b" "c"'),
        # test literal eval failure
        (['-1'], '-1'),
    ]
    for nodes, result in test_cases:
        assert ansible_native_concat(nodes) == result

# Generated at 2022-06-22 14:27:18.346779
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat([c for c in 'abc']) == 'abc'
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert ansible_native_concat([1, 2, 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_concat([1, '2', 3, 4]) == [1, 2, 3, 4]
    assert ansible_native_

# Generated at 2022-06-22 14:27:30.113320
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'

    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    assert ansible_native_concat(['foo', '', 'bar']) == 'foobar'

    assert ansible_native_concat(['foo', True, 'bar']) == 'fooTruebar'

    assert ansible_native_concat(['foo', ['bar', 'baz'], 'bar']) == 'foo["bar", "baz"]bar'


# Generated at 2022-06-22 14:27:45.654862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat([u'a', "b", 'c'])
    assert result == 'abc'

    result = ansible_native_concat([u'a', "b", 'c', 1])
    assert result == 'abc1'

    result = ansible_native_concat([u'a', "b", 'c', u'1'])
    assert result == 'abc1'

    result = ansible_native_concat([u'a', "b", 'c', True])
    assert result == 'abcTrue'

    result = ansible_native_concat([u'a', "b", 'c', {'a': 'b'}])
    assert result == "{'a': 'b'}"


# Generated at 2022-06-22 14:27:56.537303
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:28:07.933759
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=import-error
    import jinja2
    env = jinja2.Environment(trim_blocks=True, lstrip_blocks=True)
    env.filters['to_text'] = to_text
    env.filters['container_to_text'] = container_to_text
    env.filters['quote'] = container_to_text
    env.tests['quoted_string'] = lambda v: isinstance(v, string_types)
    env.tests['sequence'] = is_sequence
    env.tests['vaulted_string'] = lambda v: isinstance(v, AnsibleVaultEncryptedUnicode)
    env.finalize = ansible_native_concat
    env.filters['to_json'] = container_to_text


# Generated at 2022-06-22 14:28:20.984782
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["abc", 123]) == "abc123"
    assert ansible_native_concat(["abc"]) == "abc"
    assert ansible_native_concat(["abc", "123"]) == "abc123"
    assert ansible_native_concat(["abc", "123"]) == "abc123"
    assert ansible_native_concat(["${1 + 1}", "123"]) == "2123"
    assert ansible_native_concat(["abc", "${1 + 1}", "123"]) == "abc2123"
    assert ansible_native_concat(["abc123", "def456"]) == "abc123def456"
    assert ansible_native_concat(["123", 123]) == "123123"
    assert ansible_native_

# Generated at 2022-06-22 14:28:33.662419
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def assert_concat(values, expected):
        values = [to_text(v) for v in values]
        expected = to_text(expected)
        result = ansible_native_concat(values)

        if isinstance(result, string_types):
            assert result == expected
            return

        if isinstance(result, Mapping):
            assert isinstance(expected, dict)
            assert dict(result) == expected

        if is_sequence(result):
            assert is_sequence(expected)
            assert list(result) == expected


# Generated at 2022-06-22 14:28:45.130278
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'{{ foo.bar }}']) == u'{{ foo.bar }}'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([NativeJinjaText(u'{{ foo.bar }}')]) == NativeJinjaText(u'{{ foo.bar }}')
    assert ansible_native_concat([NativeJinjaText(u'a'), NativeJinjaText(u'b'), NativeJinjaText(u'c')]) == u'abc'
    assert ansible_native_concat([StrictUndefined()]) == StrictUndefined()



# Generated at 2022-06-22 14:28:57.844958
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(iter([1, 2])) == 12
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(iter([1, 2, 3])) == 123
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(iter(['a', 'b', 'c'])) == 'abc'
    assert ansible_

# Generated at 2022-06-22 14:29:06.856710
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == ''
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1,2']) == '1,2'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, '2', '3']) == 123
    assert ansible_native_concat(['1,2', '3']) == '1,23'
    assert ansible_native_concat(['1', '2', '3']) == '123'

# Generated at 2022-06-22 14:29:15.234234
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat."""
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([42j]) == 42j
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat([{'a': 'b'}]) == {'a': 'b'}
    assert ansible_native_concat([['a']]) == ['a']
    assert ansible_native_concat([['a', 'b']]) == ['a', 'b']
    # `ansible_native_concat()` concatenates nodes as strings. Passing
    # multiple nodes to `ast.literal_eval

# Generated at 2022-06-22 14:29:27.515457
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test the native types of concat."""
    # The following tests are based on the following tests:
    # https://github.com/pallets/jinja/blob/master/src/jinja2/tests/test_nativetypes.py
    # TODO remove when we no longer need to backport our version of
    # native_concat.

    from jinja2 import Environment

    env = Environment(extensions=['jinja2.ext.do'], undefined=StrictUndefined)

    def test_scenario(scenario):
        """Run a single scenario."""
        tmpl = env.from_string(u"""{{ ({{ in }} | do('ansible.module_utils.common.text.converters.container_to_text') | list) | join(',') }}""")
        result = tmpl

# Generated at 2022-06-22 14:29:43.232169
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test Ansible native concatenation function.
    """
    # for this test, we can't stub out the jinja2.nativetypes.StrictUndefined
    # so we'll remove it from the globals for the duration of this test
    global StrictUndefined
    StrictUndefined = None

    from ansible.module_utils.native_jinja import ansible_native_concat

    class Foo(object):
        def __str__(self):
            return 'Foo'

    class AttrFoo(object):
        def __init__(self):
            self.attr = 'Attr'

    assert ansible_native_concat([]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.5]) == 1.5
    assert ansible

# Generated at 2022-06-22 14:29:54.456120
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Ensure ansible_native_concat returns the proper Python type."""
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat([None]) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'

    assert ansible_native_concat(['a']) == u'a'
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == u'abc'

    assert ansible_native_concat([u'a']) == u'a'
   

# Generated at 2022-06-22 14:30:06.466870
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.dumper import AnsibleDumper
    import sys

    # On Python 2, str and int are the same type
    if sys.version_info.major == 2:
        str_type = types.NoneType
    else:
        str_type = str

    concat = ansible_native_concat

    # Testing the concatenation of a list of string literals
    nodes = (u"Ansible", u" is", u" awesome")
    result = u"Ansible is awesome"
    assert result == concat(nodes)
    assert isinstance(concat(nodes), text_type)

    # Testing the concatenation of a single string literal
    nodes = (u"Ansible is awesome", )
    result = u"Ansible is awesome"
    assert result

# Generated at 2022-06-22 14:30:18.378560
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test_ansible_native_concat: no args
    assert ansible_native_concat([]) is None

    # test_ansible_native_concat: int literal
    assert ansible_native_concat([5]) == 5

    # test_ansible_native_concat: string literal
    assert ansible_native_concat(['string']) == 'string'

    # test_ansible_native_concat: list literal
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]

    # test_ansible_native_concat: dict literal
    assert ansible_native_concat([{'a': 1, 'b': 2, 'c': 3}]) == {'a': 1, 'b': 2, 'c': 3}

    # test_

# Generated at 2022-06-22 14:30:30.976064
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['1,2', '3']) == ['1,2', '3']
    assert ansible_native_concat(['[1, 2]', 1]) == [1, 2, 1]
    assert ansible_native_concat(['[1, 2]', '3']) == [1, 2, 3]
    assert ansible_native_concat(['{', '"foo": 1,', '"bar": 2', '}', '{"bar": 3}']) == {'foo': 1, 'bar': 3}

# Generated at 2022-06-22 14:30:43.787711
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function ansible_native_concat"""
    data = ansible_native_concat([42, u'foo', u'bar', u'', u'ansible'])
    assert data == '42foobaransible'

    data = ansible_native_concat([42, u'foo', u'bar', u'', u'ansible', u''])
    assert data == '42foobaransible'

    data = ansible_native_concat([u'42', u'foo', u'bar', u'', u'ansible', u''])
    assert data == 42

    data = ansible_native_concat([u'42', u'foo', u'bar', u'', u'ansible', u'', u'', u'foo'])
    assert data == '42foobaransible'

    data

# Generated at 2022-06-22 14:30:50.130184
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 'bar']) == 1
    assert ansible_native_concat([True, 1, 'bar']) is True
    assert ansible_native_concat(['foo']) == 'foo'

    # TODO test encrypted values

# Generated at 2022-06-22 14:31:00.578457
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat("foo".split()) == 'foo'
    assert ansible_native_concat("foo".split() + "bar".split()) == 'foobar'
    assert ansible_native_concat("foo".split() + "bar".split() + "baz".split()) == 'foobarbaz'
    assert ansible_native_concat(" foo  ".split()) == ' foo  '
    assert ansible_native_concat("1 + 1".split()) == 2
    assert ansible_native_concat("2 + 2".split()) == 4
    assert ansible

# Generated at 2022-06-22 14:31:11.700735
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text


# Generated at 2022-06-22 14:31:23.248628
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == u'123'

    # Verify that literal_eval works as expected
    assert ansible_native_concat([123]) == 123

    # Verify that literal_eval is called for each sub expression
    assert ansible_native_concat([[1, 2, 3], [4, 5, 6]]) == u'[1, 2, 3][4, 5, 6]'

    # Verify that literal_eval is not called for values that don't
    # need evaluation.
    assert ansible_native_concat([1, 2, [[3]]]) == u'123[[3]]'

    # Verify that literal_eval is not called for native strings
    assert ansible_native_concat(['1', '2', '3']) == u'123'

    # Verify that literal_

# Generated at 2022-06-22 14:31:38.009028
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None

    # If a single node cannot be parsed with ast.literal_eval
    # the string representation is returned.
    assert ansible_native_concat([u"unicode-string"]) == u"unicode-string"
    assert ansible_native_concat([b"byte-string"]) == b"byte-string"

    # Multiple nodes or a single node that cannot be parsed with
    # ast.literal_eval are joined as strings, then parsed with
    # ast.literal_eval. If parsing fails, the joined string is returned.

# Generated at 2022-06-22 14:31:45.927863
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    foo = 'foo'
    assert ansible_native_concat([foo]) is foo
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([[1, 2], [3, 4]]) == [1, 2, 3, 4]
    assert ansible_native_concat([(1, 2), (3, 4)]) == (1, 2, 3, 4)

# Generated at 2022-06-22 14:31:52.598979
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    loaded = {'a': 1, 'b': ['a', 'b', {'c': 'd'}], 'c': 'string', 'd': [{'a': 1}, 3]}
    failed = {'a': 1, 'b': ['a', 'b', {'c': 'd'}], 'c': 'string', 'd': [{'a': 1}, 3], 'e': StrictUndefined()}
    assert ansible_native_concat(loaded.values()) == [1, ['a', 'b', {'c': 'd'}], 'string', [{'a': 1}, 3]]
    try:
        ansible_native_concat(failed.values())
    except:
        assert True
    else:
        assert False

container_to_text_with_native_concat = container_to_

# Generated at 2022-06-22 14:32:03.930922
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([[1, 2]]) == [1, 2]
    assert ansible_native_concat(['1']) == '1'
    out_data = {'test': 'data'}
    assert ansible_native_concat([out_data]) == out_data
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, [2]]) == '1[2]'
    assert ansible_native_concat([1, 2, [3]]) == '12[3]'
    assert ansible_native_concat(['a', [2, 3]]) == 'a[2, 3]'


# Generated at 2022-06-22 14:32:15.964283
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.collections import is_sequence, Mapping

    node = {
        'one_node': ['one'],
        'two_nodes': ['one', 'two'],
        'three_nodes': ['one', 'two', 'three'],
        'nested_list': ['one', ['two']],
        'nested_dict': ['one', {'two': 'two'}],
        'list_nodes': [
            ['one'],
            ['one', 'two'],
        ],
        'dict_nodes': [
            {'one': 'one'},
            {'one': 'one', 'two': 'two'},
        ],
    }
