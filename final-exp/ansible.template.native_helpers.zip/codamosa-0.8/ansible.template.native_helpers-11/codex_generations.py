

# Generated at 2022-06-22 14:22:27.404748
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test for empty node list
    assert ansible_native_concat([]) is None

    # Test for single node
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat(['abc', 1, 'def']) == 'abc1def'
    assert ansible_native_concat([b'abc', 1, b'def']) == b'abc1def'

    # Test for two or more nodes
    assert ansible_native_concat([1, 2, 3, 4]) == 1234
    assert ansible_native_concat([1, 'abc', 'def']) == '1abcdef'

# Generated at 2022-06-22 14:22:33.941478
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # No nodes
    assert ansible_native_concat(()) is None

    # Two nodes
    assert ansible_native_concat((1, 2)) == 3

    # More than two nodes
    assert ansible_native_concat((1, 2, 3, 4)) == '1234'

    # One node that is a generator
    assert ''.join(ansible_native_concat((x for x in 'abcd'))) == 'abcd'

    # Two nodes that are generators
    assert ''.join(ansible_native_concat((x for x in 'abcd'), (x for x in 'efgh'))) == 'abcdefgh'

    # Generator of undefined values
    assert ansible_native_concat((StrictUndefined() for x in 'abcd')) is StrictUndefined

    # Stringified generator of

# Generated at 2022-06-22 14:22:46.485226
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2

    here = os.path.dirname(os.path.abspath(__file__))
    native_concat = jinja2.Environment(autoescape=True, extensions=['jinja2.ext.loopcontrols']).from_string('{{ [1,2,3,4] | native_concat }}').root_render_func(globals())
    assert native_concat == [1, 2, 3, 4]

    native_concat = jinja2.Environment(autoescape=True, extensions=['jinja2.ext.loopcontrols']).from_string('{{ "{{ ansible_managed }}" | native_concat }}').root_render_func(globals())
    assert native_concat == "{{ ansible_managed }}"

    native_concat = j

# Generated at 2022-06-22 14:22:59.217765
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([u'']) == u''

    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'', u'c']) == u'abc'

# Generated at 2022-06-22 14:23:11.558192
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["a", "bc"]) == 'abc'
    assert ansible_native_concat(["a", "bc", "def"]) == 'abcdef'
    assert ansible_native_concat([1, 2, 3, 4]) == 10
    assert ansible_native_concat([[], ",", [1, "2"]]) == '1,2'
    assert ansible_native_concat([["", " ", "", ""]]) == " "
    assert ansible_native_concat([True, ["", "False"]]) is False

    assert ansible_native_concat(['"\\"', '"\\"']) == '""'
    assert ansible_native_concat([r'"\"', r'"foo"', r'"\""']) == r'"foo"'

# Generated at 2022-06-22 14:23:24.673937
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest

    @pytest.mark.parametrize(
        'nodes,result',
        [
            # single node
            ([1], 1),
            (['1'], '1'),
            (['1 ', '2'], '1 2'),
            ([[1]], [1]),
            (['[1]'], [1]),
            (['(1, 2)'], (1, 2)),
            (['[1, 2]'], [1, 2]),
            (['{1: 2}'], {1: 2}),
            (['{1, 2}'], {1, 2}),
        ]
    )
    def test_simple(nodes, result):
        assert ansible_native_concat(nodes) == result


# Generated at 2022-06-22 14:23:37.358680
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bool, to_text, to_bytes
    from ansible.module_utils.common.text.converters import to_native, to_nice_yaml, to_json
    from ansible.module_utils.common.text.converters import to_naive_datetime, to_nice_date
    from ansible.module_utils.common.text.formatters import human_to_bytes
    import jinja2
    import os
    import sys

    # check the environment and skip if not running on python3.7+
    # since it would fail anyway.
    major, minor, micro, releaselevel, serial = sys.version_info
    if (major, minor) < (3, 7):
        return


# Generated at 2022-06-22 14:23:48.705081
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(u'foo') == u'foo'
    assert ansible_native_concat(u'foo,bar') == u'foo,bar'
    assert ansible_native_concat(u'foo', u'bar') == u'foobar'
    assert ansible_native_concat(u'foo\n', u'bar') == u'foo\nbar'
    assert ansible_native_concat(u'foo\n', u'bar') == u'foo\nbar'
    assert ansible_native_concat([u'foo\n', u'bar']) == u'foo\nbar'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'

# Generated at 2022-06-22 14:23:57.501417
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import ansible.module_utils.common.text.converters as conv
    import ansible.module_utils.native_jinja as nj
    import itertools
    import json
    import yaml

    if conv.opt_value('N') is None:
        conv.opt_value('N', True)

    def native(s):
        """
        Return a native Python type given a string with a type literal.
        :param s: A string with an expression representing a type literal.
        """
        return nj.ansible_native_concat(
            [nj.NativeJinjaText(t.strip()) for t in s.split(',')]
        )


# Generated at 2022-06-22 14:24:09.028025
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a', '', 'b']) == 'ab'
    assert ansible_native_concat(['a', None, 'b']) == 'ab'
    assert ansible_native_concat(['a', False, 'b']) == 'ab'
    assert ansible_native_concat(['a', 0, 'b']) == 'ab'
    assert ansible_native_concat(['a', 1, 'b']) == 'ab'

    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_

# Generated at 2022-06-22 14:24:19.444168
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) is 1
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat(['a', 2, 'c', 4]) == 'a2c4'

    assert ansible_native_concat([to_text('é')]) == u'é'
    assert ansible_native_concat([to_text('é'), '2']) == u'é2'

# Generated at 2022-06-22 14:24:30.601363
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # empty
    assert ansible_native_concat([]) is None

    # single node
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['42']) == '42'
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['{"x": "y"}']) == {"x": "y"}
    assert ansible_native_concat(['(1, 2)']) == (1, 2)
    assert ansible_native_concat(['b"abc"']) == b"abc"
    assert ansible_native_concat(['u"abc"']) == u"abc"

    # multiple nodes

# Generated at 2022-06-22 14:24:43.789425
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1, "ab", 3]) == "1ab3"
    assert ansible_native_concat([1, "[2, 3]", 4]) == [2, 3]
    assert ansible_native_concat([1, '3 + 4', 5]) == 7
    assert ansible_native_concat([1, '[2, 3]', 4]) == [2, 3]
    assert ansible_native_concat(['{2: 3, 4}', 5]) == {2: 3, 4: 5}

# Generated at 2022-06-22 14:24:56.971072
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Make sure that the function is callable.
    assert ansible_native_concat([]) is None

    assert ansible_native_concat(['foo']) == 'foo'

    # str, str -> str
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    # str, int -> str
    assert ansible_native_concat(['foo', 123]) == 'foo123'

    # int, str -> str
    assert ansible_native_concat([123, 'foo']) == '123foo'

    # int, int -> int
    assert ansible_native_concat([123, 456]) == 579

    # str, int, str, int -> str

# Generated at 2022-06-22 14:25:05.537758
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 42, 'bar']) == 'foo42bar'
    assert ansible_native_concat(['foo', container_to_text({'key': 'value'}), 'bar']) == 'foo{u\'key\': u\'value\'}bar'
    assert ansible_native_concat(['foo', container_to_text([1, 2, 3]), 'bar']) == 'foo[1, 2, 3]bar'

# Generated at 2022-06-22 14:25:15.948012
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([[1]]) == [1]
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat(['a', ['b']]) == u'a[b]'
    assert ansible_native_concat(['a', [u'b', u'c']]) == u'a[b, c]'
    assert ansible_native_concat([{'a': 'b'}]) == {'a': 'b'}
    # dict

# Generated at 2022-06-22 14:25:23.629290
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:25:31.985528
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.module_utils.common.text.converters import to_text
    from ansible.template import generate_ansible_native_vars_for_test
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    # these use native types
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([b'1']) == 1

# Generated at 2022-06-22 14:25:41.555581
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert u'foobar' == ansible_native_concat([u'foo', u'bar'])
    assert u'foo bar' == ansible_native_concat([u'foo ', u'bar'])
    assert [u'foo', u'bar'] == ansible_native_concat([[u'foo', u'bar']])
    assert [u'foo', u'bar'] == ansible_native_concat([[u'foo', u'bar']])
    assert {u'foo': u'bar'} == ansible_native_concat([{u'foo': u'bar'}])
    assert b'foobar' == ansible_native_concat([b'foo', b'bar'])

# Generated at 2022-06-22 14:25:53.472945
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Any Python type that is not a string should be returned unchanged
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([1234]) == 1234
    assert ansible_native_concat([56.789]) == 56.789
    assert ansible_native_concat([{'a': 1}]) == {'a': 1}
    assert ansible_native_concat([['b', 2]]) == ['b', 2]

    # Concatenation of multiple values should be handled properly
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([u'xyz', u'pqr']) == 'xyzpqr'
    assert ansible_native_concat([[1, 2], [3, 4]])

# Generated at 2022-06-22 14:26:08.161211
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text import native_concat

    data = {
        "a": [1, 2],
        "b": {
            "c": True
        }
    }

    assert ansible_native_concat(data["a"]) == native_concat(data["a"])
    assert ansible_native_concat(data["b"]) == native_concat(data["b"])
    assert ansible_native_concat(data) == native_concat(data)


# Generated at 2022-06-22 14:26:18.104673
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    variables = {
        'foo': AnsibleVaultEncryptedUnicode('bar'),
        'bar': b'',
        'baz': [1,2]
    }

    data = {
        'a': (
            "{{ foo }}",
            variables['foo'].data,
            variables['foo'],
            "{{ '{{ foo }}' }}",
            "{% for i in baz %} {{ i }}{% endfor %}",
            [1, 2],
            "[1,2]",
        ),
        'b': (' ', '{'),
        'c': ('{{ bar | string }}', variables['bar']),
    }

    from ansible.plugins.loader import shared_plugin_loader
    from ansible.plugins.lookup.template import LookupModule

# Generated at 2022-06-22 14:26:30.674023
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    from ansible.module_utils.common.collections import is_sequence

    assert ansible_native_concat(u'foobar') == 'foobar'
    assert ansible_native_concat(123) == 123
    assert ansible_native_concat(3.14) == 3.14
    assert ansible_native_concat(True) is True
    assert ansible_native_concat(False) is False
    assert ansible_native_concat(None) is None

    assert isinstance(ansible_native_concat([u'foo', u'bar']), text_type)
    assert isinstance(ansible_native_concat([3, 14]), text_type)
    assert isinstance(ansible_native_concat([True, False]), text_type)


# Generated at 2022-06-22 14:26:42.999400
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Something(object):
        def __str__(self):
            return 'something'

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['']) == ''
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1.1]) == 1.1
    assert ansible_native_concat([{'hi': 'ho'}]) == {'hi': 'ho'}
    assert ansible_native_concat([{'hi': 'ho'}, 'foo']) == 'foo'
    assert ansible_native_concat([{'hi': {'hello': 'world'}}]) == {'hi': {'hello': 'world'}}

# Generated at 2022-06-22 14:26:50.841721
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert (ansible_native_concat(['a', 'b']) ==
            ansible_native_concat(['a', ' ', 'b'])) == 'ab'
    assert (ansible_native_concat([1, 2]) ==
            ansible_native_concat([1, ' ', 2])) == '12'
    assert ansible_native_concat([1, 2]) == 12
    assert (ansible_native_concat(['1', '2']) ==
            ansible_native_concat(['1', ' ', '2'])) == '1 2'
    assert ansible_native_concat(['1', '2']) == '1 2'

# Generated at 2022-06-22 14:27:01.714713
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(iter([])) is None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1

    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat(iter([1, 2])) == u'12'

    assert ansible_native_concat([1, '2']) == u'12'
    assert ansible_native_concat(iter([1, '2'])) == u'12'

    assert ansible_native_concat(['1', '2']) == u'12'

# Generated at 2022-06-22 14:27:13.284952
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # avoid deprecation warning, use ast.literal_eval where possible
    try:
        from ast import literal_eval
    except ImportError:
        pass
    else:
        assert literal_eval(container_to_text(b'a')) == ansible_native_concat(container_to_text(b'a'))
        assert literal_eval(container_to_text(u'b')) == ansible_native_concat(container_to_text(u'b'))
        assert literal_eval(container_to_text(b'"a"')) == ansible_native_concat(container_to_text(b'"a"'))
        assert literal_eval(container_to_text(u'"b"')) == ansible_native_concat(container_to_text(u'"b"'))

    # simple examples

# Generated at 2022-06-22 14:27:18.117344
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['{', '}']) == '{}'
    assert ansible_native_concat(['[', ']']) == '[]'
    assert ansible_native_concat(['(', ')']) == '()'
    assert ansible_native_concat(['"', '"']) == '""'
    assert ansible_native_concat(['a', 'bc', 'd']) == 'abcd'

    assert ansible_native_concat(['"', '"', '']) == ''
    assert ansible_native_concat(['"', '"', ' ']) == ''
    assert ansible_native_concat(['"', '"', 'abc']) == 'abc'
    assert ansible_native_concat(['"', '']) == ''
   

# Generated at 2022-06-22 14:27:27.013255
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, '2', 3]) == 123
    assert ansible_native_concat([1, '2', [3]]) == 123
    assert ansible_native_concat([1, '2', {'3': 1}]) == [1, '2', {'3': 1}]
    assert ansible_native_concat([1, '2', {'3': 1}]) == [1, '2', {'3': 1}]



# Generated at 2022-06-22 14:27:36.083976
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) is 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3', '4']) == '1234'
    assert ansible_native_concat([1, '2']) == '12'
    assert ansible_native_concat

# Generated at 2022-06-22 14:27:53.352585
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

# This is a filtered-out version of the original native_concat filter which does not attempt
# to use literal_eval. Instead, it remains an identity function for sequences and recursive
# traversal for mappings (note: this is a strict subset of behaviours of the original
# native_concat filter implemented in ansible.module_utils.common.text.converters).

# Generated at 2022-06-22 14:28:00.363830
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import (
        force_bytes,
        to_bytes,
        to_text,
    )
    from ansible.module_utils.common.text.formatters import (
        human_to_bytes,
    )
    from ansible.module_utils.common.text.misc import (
        missing_bytes_hint,
    )
    from ansible.module_utils.common.text.templating import (
        get_all_template_paths,
        template,
    )

    assert ansible_native_concat((1, 2, 3)) == [1, 2, 3]
    assert ansible_native_concat((1, 2, 3,)) == [1, 2, 3]

# Generated at 2022-06-22 14:28:09.547224
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from jinja2.nativetypes import NativeEnvironment

    e = NativeEnvironment()
    t = e.from_string(
        """\
{%- set code = 'a' %}
{%- set code = code|string %}
{% set yaml = [{code}] %}
{%- set yaml2 = [code] %}
{{ yaml }}
{{ yaml2 }}
"""
    )
    result = t.render()
    assert result == "['a']\n[u'a']\n"

    t = e.from_string(
        """\
{%- set code = '0o10' %}
{%- set code = code|string %}
{%- set code = code|int %}
{{ code }}
"""
    )
    result = t.render()


# Generated at 2022-06-22 14:28:21.629172
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Basic tests for ansible_native_concat function."""
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['hello']) == 'hello'
    assert ansible_native_concat(['hello', 'world']) == 'helloworld'
    assert ansible_native_concat(['True'])
    assert not ansible_native_concat(['False'])
    assert ansible_native_concat(['{}']) == {}
    assert ansible_native_concat(['[]']) == []
    assert ansible_native_concat(['{"a": "b"}']) == {'a': 'b'}
    assert ansible_native_concat(['["a", "b"]']) == ['a', 'b']
    assert ansible

# Generated at 2022-06-22 14:28:34.358090
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:28:47.509452
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat with various input types."""
    # Concatenation with string literals
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', u'bar']) == 'foobar'
    assert ansible_native_concat([u'foo', 'bar']) == 'foobar'
    assert ansible_native_concat([u'f', 'o', 'o']) == 'foo'
    assert ansible_native_concat(['f', u'o', 'o']) == 'foo'
    assert ansible_native_concat(['f', u'o', 'o']) == 'foo'
    assert ansible_native

# Generated at 2022-06-22 14:29:00.030090
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(nodes=[1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(nodes=['1', u'2']) == '12'
    assert ansible_native_concat(nodes=['1', '2']) == '12'
    assert ansible_native_concat(nodes=[text_type('1'), '2']) == '12'
    assert ansible_native_concat(nodes=[None, None]) is None
    assert ansible_native_concat(nodes=[1]) == 1
    assert ansible_native_concat(nodes=['1']) == '1'
    assert ansible_native_concat(nodes=['1', '2']) == '12'
    assert ansible_native_

# Generated at 2022-06-22 14:29:08.332762
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # pylint: disable=too-many-branches,too-many-locals

    nodes = [1, 2, 3]
    result = ansible_native_concat(nodes)
    assert result is '123'

    # test strings
    nodes = ['ansible', '-', 'easy']
    result = ansible_native_concat(nodes)
    assert result is 'ansible-easy'

    # test unicode strings
    nodes = [u'ansible', u'-', u'easy']
    result = ansible_native_concat(nodes)
    assert result is 'ansible-easy'

    # test encoded strings
    nodes = [b'ansible', b'-', b'easy']
    result = ansible_native_concat(nodes)
    assert result is 'ansible-easy'

# Generated at 2022-06-22 14:29:13.587553
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test a single node
    node = text_type('foo')
    assert ansible_native_concat([node]) == node
    # Test multiple nodes
    nodes = [node, None]
    assert ansible_native_concat(nodes) == container_to_text(nodes)

    # Test a generator
    def generator():
        yield 'bar'
        yield None

    assert ansible_native_concat(generator()) == container_to_text(generator())

# Generated at 2022-06-22 14:29:25.535883
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat([ast.Str('a')]) == 'a'
    assert ansible_native_concat([ast.Str('a'), ast.Str('b')]) == 'ab'
    assert ansible_native_concat([ast.Str('a'), ast.Str('b'), ast.Str('c')]) == 'abc'

    assert ansible_native_concat([ast.Num(1)]) == 1
    assert ansible_native_concat([ast.Num(1), ast.Str('b')]) == '1b'
    assert ansible_native_concat([ast.Num(1), ast.Str('b'), ast.Num(2)]) == '1b2'

# Generated at 2022-06-22 14:29:44.075764
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit tests for ansible_native_concat.
    """
    # pylint: disable=unused-argument
    from ansible.module_utils.six import PY3, PY2
    from datetime import date, datetime, timedelta
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as E

    if PY3:
        unicode_ = str
    else:
        unicode_ = unicode

    if PY3 and not PY2:
        # how to detect if pytz is installed?
        def to_datetime(x):
            return datetime.utcfromtimestamp(x)
    else:
        from pytz import utc
        def to_datetime(x):
            return datetime.fromtimestamp(x, utc)



# Generated at 2022-06-22 14:29:55.383990
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.vars import combine_vars

    # Should handle literals
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['foo']) == 'foo'
    # Should handle variables
    assert ansible_native_concat([combine_vars(42)]) == 42
    assert ansible_native_concat([combine_vars('foo')]) == 'foo'
    # Should handle lists
    assert ansible_native_concat([[1, 2, 3]]) == [1, 2, 3]
    # Should handle dictionaries
    assert ansible_native_concat([{'foo': 'bar'}]) == {'foo': 'bar'}

    # Should concatenate string literals

# Generated at 2022-06-22 14:30:07.631283
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    print("Running tests for function ansible_native_concat")
    assert ansible_native_concat(['a', u'b']) == u'ab'
    assert ansible_native_concat(['a', 'b']) == u'ab'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([1, '2']) == u'12'
    assert ansible_native_concat(["1", 2]) == u'12'
    assert ansible_native_concat([None, 1]) == 1
    assert ansible_native_concat(['1', u'2', u'3']) == u'123'
    assert ansible_native_concat([1, '2', u'3']) == u'123'
    assert ansible_

# Generated at 2022-06-22 14:30:19.268314
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([None, None]) is None

    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([u'\u03b1', u'\u03b2', u'\u03b3']) == u'\u03b1\u03b2\u03b3'
    assert ansible_native_concat([u'\u03b1', 'b', u'\u03b3']) == u'\u03b1b\u03b3'


# Generated at 2022-06-22 14:30:31.260720
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test ansible_native_concat"""

    from ansible.module_utils.parsing.convert_bool import BOOLEANS_TRUE

    def iter_values(fn, values=None):
        if values is None:
            values = BOOLEANS_TRUE

        for value in values:
            yield fn(value)

    def jinja_str(value):
        return NativeJinjaText(value)

    def text(value):
        return text_type(value)

    def bytes(value):
        return to_text(value).encode('ascii')

    # pylint: disable=too-many-locals,too-many-branches,too-many-statements
    def make_test(items, expected):
        def test_fn():
            result = ansible_native_

# Generated at 2022-06-22 14:30:44.085454
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Define a unit test function to test the ansible_native_concat
    # using the ast.literal_eval on the result. This is because
    # ansible_native_concat tries its best to return a python native
    # representation, and ast.literal_eval is the best way to compare
    # that type for equality.
    # (e.g. the string 'foo' == the string 'foo').

    def check_val(expected_val, exprs, context=None):
        if context is None:
            context = {}
        node = ast.Expression(ast.List(exprs, ast.Load()))
        code_obj = compile(node, filename='<inline>', mode='eval')
        result = ansible_native_concat(code_obj.co_consts)
        assert ast.literal_

# Generated at 2022-06-22 14:30:57.222129
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['foo']) == 'foo'

    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 1, 'bar']) == 'foo1bar'

    # result is a non-string
    assert ansible_native_concat(['foo', 1]) is 1

    # result is a string, not a valid expression
    result = ansible_native_concat(['foo', ''])
    assert isinstance(result, text_type)
    assert result == 'foo'

    # result is a string, can be parsed with literal_eval
    assert ansible_native_concat(['foo', '1']) == 1
    assert ansible_native

# Generated at 2022-06-22 14:31:10.118471
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.errors import AnsibleUndefinedVariable

    # Test list values
    nodes = []
    assert ansible_native_concat(nodes) is None

    nodes = [1]
    assert ansible_native_concat(nodes) == 1

    nodes = [1, 2, 3]
    assert ansible_native_concat(nodes) == '123'

    nodes = [1, 2, ['3', 4]]
    assert ansible_native_concat(nodes) == '1234'

    nodes = ['40', ['3', '4']]
    assert ansible_native_concat(nodes) == '4034'

    nodes = ['4', '0', '3', '4']
    assert ansible_native_concat(nodes) == '4034'

    # Test generator expression


# Generated at 2022-06-22 14:31:22.676724
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert isinstance(ansible_native_concat(['']), string_types)
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == '1.0'
    assert ansible_native_concat(['1.0', '2.0']) == '1.02.0'
    assert ansible_native_concat([1, '2.0']) == '12.0'
    assert ansible_native_concat([1, AnsibleUnicode('2.0')]) == '12.0'
    assert ansible_

# Generated at 2022-06-22 14:31:29.530670
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["abc", "123"]) == "abc123"
    assert ansible_native_concat([["abc"], ["123"]]) == ["abc", "123"]
    assert ansible_native_concat([["abc"], "123"]) == ["abc", "123"]
    assert ansible_native_concat([["abc", "123"]]) == ["abc", "123"]
    assert ansible_native_concat([]) is None
    # See https://github.com/ansible/ansible/pull/51492 for more tests.
    # This test is not strictly needed for Python 2, but it never harms.
    assert ansible_native_concat(["abc", "123", None]) == "abc123None"



# Generated at 2022-06-22 14:31:44.750435
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from jinja2.runtime import StrictUndefined
    import jinja2
    from ansible.module_utils.common.text.converters import container_to_text
    from ansible.module_utils._text import to_text
    import ast

    j_env = jinja2.Environment(undefined=StrictUndefined)
    j_unsafe_template = j_env.from_string('{{ str(3) }}')
    try:
        j_unsafe_template.render()
    except Exception as e:
        assert type(e) is UndefinedError


# Generated at 2022-06-22 14:31:52.218395
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test case 1
    # this is the normal case of 'join' jinja filter
    # the native jinja concat function returns a string
    val1 = ansible_native_concat([1,2])
    assert(val1 == '12')
    val2 = ansible_native_concat([3,4])
    assert(val2 == '34')

    # test case 2
    # literal jinja concat function returns a list
    # which is not the same as the native jinja concat
    val3 = ansible_native_concat([val1,val2])
    assert(val3 == '1234')

    # test case 3
    # literal jinja concat function returns a list
    # which is not the same as the native jinja concat
    # even when literal jinja conc

# Generated at 2022-06-22 14:32:03.651769
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat('') is None
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat('foo') == 'foo'
    assert ansible_native_concat('foo ') == 'foo '
    assert ansible_native_concat('1') == 1
    assert ansible_native_concat(' False ') is False
    assert ansible_native_concat('False ') is False
    assert ansible_native_concat('False\n') is False
    assert ansible_native_concat('\tFalse\n') is False
    assert ansible_native_concat('\tTrue\n') is True
    assert ansible_native_concat('\tTrue\n') is True

# Generated at 2022-06-22 14:32:15.969169
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import wrap_var
    from jinja2 import Markup, nodes
    from jinja2.utils import StrAndUnicode, PythonData, internalcode

    class FakeTemplate(StrAndUnicode):
        def render(self, *args, **kwargs):
            return self

    class FakeEnvironment(object):
        def __init__(self, autoescape=None):
            self.autoescape = autoescape

        def from_string(self, source):
            source = source.replace('{{', '{%').replace('}}', '%}')
            return FakeTemplate(source)

        def is_safe_attribute(self, cls, attr, value):
            return getattr(cls, attr, None) is value
