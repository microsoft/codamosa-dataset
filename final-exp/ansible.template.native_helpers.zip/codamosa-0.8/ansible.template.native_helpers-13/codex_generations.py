

# Generated at 2022-06-22 14:22:29.638317
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    class testUndefined(StrictUndefined):
        pass

    assert ansible_native_concat([testUndefined()]) == None
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['ab']) == 'ab'
    assert ansible_native_concat(['a', [1]]) == 'a[1]'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, None]) == '1None'
    assert ansible_native_concat(['a', True]) == 'aTrue'
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native

# Generated at 2022-06-22 14:22:42.433686
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['{', '}']) == '{}'
    assert ansible_native_concat(['foo', 'bar', '{', '}']) == 'foobar{}'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['{', 'foo', '}']) == '{foo}'

# Generated at 2022-06-22 14:22:54.877119
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText

    if False:
        from jinja2.runtime import StrictUndefined
        from ansible.module_utils.six import PY3

    class DummyStrictUndefined(StrictUndefined):
        """A dummy class to substitute for jinja2.undefined.StrictUndefined
        by the unit tests.
        """

    class DummyAnsibleVaultEncryptedUnicode(AnsibleVaultEncryptedUnicode):
        """A dummy class to substitute for AnsibleVaultEncryptedUnicode
        by the unit tests.
        """


# Generated at 2022-06-22 14:23:07.887342
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class Foo(object):
        def __str__(self):
            return '<Foo>'


# Generated at 2022-06-22 14:23:20.608197
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.dumper import AnsibleDumper

    yaml_dumper = AnsibleDumper(width=float('inf'))


# Generated at 2022-06-22 14:23:31.106821
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    func_globals = dict()
    func_globals['ansible_native_concat'] = ansible_native_concat
    func_globals['container_to_text'] = container_to_text

# Generated at 2022-06-22 14:23:38.944921
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Literal types
    assert ansible_native_concat(['1', '1']) == 2
    assert ansible_native_concat(['1', '1']) == 2
    assert ansible_native_concat(['0', '0']) == 0
    assert ansible_native_concat(['1.1', '1.1']) == 2.2
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.1']) == 1.1
    assert ansible_native_concat(['0']) == 0
    assert ansible_native_concat(['"1"']) == '1'
    assert ansible_native_concat(['True']) is True

# Generated at 2022-06-22 14:23:49.459327
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1', 2]) == '1 2'
    assert ansible_native_concat([1, 2]) == '1 2'
    assert ansible_native_concat(['1', 2, 'a']) == '1 2 a'
    assert ansible_native_concat(['1', '2']) == 1
    assert ansible_native_concat(['1', 'b']) == '1 b'
    assert ansible_native_concat(['1', 'b', 'c']) == '1 b c'



# Generated at 2022-06-22 14:23:57.831340
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def _assert(nodes, expected):
        assert ansible_native_concat(nodes) == expected

    _assert([
        NativeJinjaText('a'),
        NativeJinjaText('b'),
        NativeJinjaText('c'),
    ],
        u'abc'
    )

    _assert([
        NativeJinjaText('a'),
        NativeJinjaText(u'\U0001f602'),
        NativeJinjaText('c'),
    ],
        u'a\U0001f602c'
    )

    # When a single node is provided, return that node instead of
    # concatenating it with an empty string.
    _assert([NativeJinjaText('a')], u'a')

    # Return the input for an empty list.
    _assert([], None)

    #

# Generated at 2022-06-22 14:24:09.072949
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    with StrictUndefined():
        # The second item in the sequence is used as the function's
        # return value. The rest of the sequence should be present
        # in the concatenation output.
        assert ansible_native_concat([1, 2, 3]) == 2
        assert ansible_native_concat(iter([1, 2, 3])) == 2

        # Strings can be parsed by ast.literal_eval and their parsed
        # value should be returned.
        assert isinstance(ansible_native_concat(['None', 'None']), type(None))
        assert isinstance(ansible_native_concat(['False', 'False']), bool)
        assert isinstance(ansible_native_concat(['0', '0']), int)

# Generated at 2022-06-22 14:24:19.596960
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['string', '1']) == 'string1'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat(['1', '2.0']) == 3.0
    assert ansible_native_concat(['1', u'\u00dc']) == u'1\u00dc'
    assert ansible_native_concat(map(str, range(10))) == '0123456789'
    test_dict = ansible_native_concat([{'key1': 'val1'}, {'key2': 'val2'}])
    assert is_sequence(test_dict)
    assert isinstance(test_dict[0], dict)

# Generated at 2022-06-22 14:24:30.725030
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['True']) is True

    # list type
    assert ansible_native_concat(['[1]']) == [1]
    assert ansible_native_concat([u'[1]']) == [1]

    # unicode string
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'1', u'2']) == 12
    assert ansible_native_concat([u'True']) is True

    # text_type string

# Generated at 2022-06-22 14:24:40.801382
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'a']) == u'a'
    assert ansible_native_concat([2]) == 2
    assert ansible_native_concat([1.2]) == 1.2
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', 1, u'c']) == u'a1c'



# Generated at 2022-06-22 14:24:48.863564
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test single
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([{'foo': 'bar'}]) == {'foo': 'bar'}
    assert ansible_native_concat([['foo', 'bar']]) == ['foo', 'bar']
    assert isinstance(ansible_native_concat(['1']), int)
    assert isinstance(ansible_native_concat(['1.0']), float)
    assert isinstance(ansible_native_concat(['True']), bool)

# Generated at 2022-06-22 14:24:59.281493
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    d = {'hello': 'world'}
    e = {'hello': 'everybody'}
    f = {'hello': 'everybody'}
    g = {'hello': 'everybody'}
    b = 'hello'
    c = ['hello']
    h = 'hello'
    i = [1, 2, 3]
    j = u'hello'
    k = 123
    l = 1.2
    m = {'hello', 'world'}
    n = 1j
    o = '1j'
    p = 'hello world'
    q = 'hello world'

    # builtin test
    assert ansible_native_concat([]).__class__ is type(None)
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_con

# Generated at 2022-06-22 14:25:07.201032
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # pylint: disable=no-member
    # "ast.parse" (in the try block) does not exist in python 2.6

    # concat single value
    data = 'foo'
    out = ansible_native_concat([data])
    assert out == data
    assert isinstance(out, string_types)

    # concat strings elements
    data = ['foo', 'bar']
    out = ansible_native_concat(data)
    assert out == 'foobar'
    assert isinstance(out, string_types)

    # concat string and number
    data = ['foo', 1]
    out = ansible_native_concat(data)
    assert out == 'foo1'
    assert isinstance(out, string_types)

    # concat numbers
    data = [1, 2]


# Generated at 2022-06-22 14:25:17.894092
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.constructor import AnsibleConstructor

    # Call the test from this directory
    from . import test_template_filter_native

    # Disable the TAG loader because it will not work for this test.
    # We just want to test that the native concat function does not
    # call the loader.
    oldloader = AnsibleConstructor.yaml_constructors["!native"]
    del AnsibleConstructor.yaml_constructors["!native"]

    # Ensure that our jinja filter functions are registered.
    test_template_filter_native.register_filter()

    # Test the ansible_native_concat function
    argv = [123, '456']
    assert ansible_native_concat(argv) == '123456'
    argv = ['foo', 'bar']
   

# Generated at 2022-06-22 14:25:30.198901
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(None) is None
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(["1"]) == "1"
    assert ansible_native_concat(("1", "2")) == "12"
    assert ansible_native_concat(("1", "2", 5)) == "125"
    assert ansible_native_concat(("1", "2", "5")) == "125"
    assert ansible_native_concat(("1", "2", "5", "2", "5", "2", "5")) == "1252525"

# Generated at 2022-06-22 14:25:40.354351
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Python 2
    assert ansible_native_concat(['{{', ' 1', '+', '\n', '2', '}}']) == 1 + 2
    assert ansible_native_concat([u'{{ " 3-2"', '-', u'1 }}']) == u' 3-2-1 '
    assert ansible_native_concat([u'{{ True', 'and', u'true }}']) == u'{{ True and true }}'
    assert ansible_native_concat([u'{{ "4"', u'*', u'true }}']) == u'{{ "4" * true }}'

    # Python 3
    assert ansible_native_concat([u'true', 'and', 'true']) is True

# Generated at 2022-06-22 14:25:48.841274
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1]) == 1

    # Ensure that we correctly handle leading spaces/tabs
    assert ansible_native_concat(['   a  ', ' b  ']) == '\ta\t b  '



# Generated at 2022-06-22 14:26:07.462353
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Check basic usage
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat([1, '1']) == '11'
    # Check literal_eval usage
    assert ansible_native_concat(['1']) == '1'
    assert ansible_native_concat(['1', '1']) == '11'
    assert ansible_native_concat(['2.0']) == 2.0
    assert ansible_native_concat(['2', '.', '0']) == '2.0'
    assert ansible_native_concat(['True']) is True
    assert ansible_native_concat(['False']) is False
    assert ansible_native_

# Generated at 2022-06-22 14:26:17.580881
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([text_type(123), text_type(456)]) == 123456
    # TODO: Fix this
    assert ansible_native_concat([text_type(123), text_type(456)]) == u'123456'
    assert ansible_native_concat([text_type('123'), text_type('456')]) == 123456
    assert ansible_native_concat([text_type('123'), text_type('456')]) == u'123456'
    assert ansible_native_concat([text_type('ab'), text_type('cd')]) == u'abcd'
    assert ansible_native_concat([text_type('{'), text_type('}')]) == u'{}'

# Generated at 2022-06-22 14:26:30.161068
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_cases():
        yield True, ['foo', 'bar'], 'foobar'
        yield True, ['foo', ' bar'], 'foo bar'
        yield True, ['foo', u' bar'], 'foo bar'
        yield True, ['foo', '\n  bar'], 'foo\n  bar'
        yield True, [['foo', 'bar'], ['baz']], ['foo', 'bar', 'baz']
        yield True, ['foo', ['bar', 'baz']], ['foo', 'bar', 'baz']
        yield True, [1, 2, 3], [1, 2, 3]
        yield True, [1, 2, '3'], [1, 2, '3']
        yield True, ['foo', '"bar"'], 'foo"bar"'

# Generated at 2022-06-22 14:26:42.220772
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible_collections.ansible.community.tests.unit.compat import unittest

    class TestAnsibleNativeConcat(unittest.TestCase):
        def test_list_concat(self):
            self.assertEqual(ansible_native_concat([2, 3, 4]), [2, 3, 4])
            self.assertEqual(ansible_native_concat([2, 'a', 4]), [2, 'a', 4])
            self.assertEqual(ansible_native_concat([2, '3', 4]), [2, '3', 4])
            self.assertEqual(ansible_native_concat([2, 'a']), [2, 'a'])
            self.assertEqual(ansible_native_concat([1]), 1)

        # In addition to

# Generated at 2022-06-22 14:26:50.433528
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six import PY3

    assert ansible_native_concat([]) is None

    # int
    assert ansible_native_concat(['1']) == 1

    # float
    assert ansible_native_concat(['1.0']) == 1.0

    # bool
    assert ansible_native_concat(['true']) is True
    assert ansible_native_concat(['false']) is False

    # str
    assert ansible_native_concat(['"foo"']) == "foo"
    assert ansible_native_concat(['foo']) == "foo"

    # list
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]

    # dict
    assert ansible_native_

# Generated at 2022-06-22 14:27:01.426725
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class DummyNode(object):
        def __init__(self, value):
            self.value = value

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([DummyNode(None)]) is None
    assert ansible_native_concat([DummyNode(None), DummyNode(None)]) == ''
    assert ansible_native_concat([DummyNode(23)]) == 23
    assert ansible_native_concat([DummyNode(23), DummyNode(42)]) == '2342'
    assert ansible_native_concat([DummyNode('23'), DummyNode(' + '), DummyNode(42)]) == '23 + 42'

# Generated at 2022-06-22 14:27:09.435237
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat(['2']) == 2
    assert ansible_native_concat(['"foo"']) == 'foo'
    assert ansible_native_concat(['"foo', 'b"', 'ar']) == 'foobar'
    assert ansible_native_concat([u'\u1234']) == u'\u1234'



# Generated at 2022-06-22 14:27:13.031873
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    map_ = {'foo': [1, 2, 3], 'bar': range(10)}
    assert ansible_native_concat(map_.items()) == ansible_native_concat(map_)

    assert ansib

# Generated at 2022-06-22 14:27:22.288345
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Create custom class to ensure that ansible_native_concat
    # does not cause false positives when native type is returned
    class _Custom(object):
        def __init__(self, val):
            self.val = val
        def __str__(self):
            return str(self.val)
        def __repr__(self):
            return str(self.val)
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1.2, 3.4, 5.6]) == '1.23.45.6'
    assert ansible_native_concat([_Custom(1)]) == 1
    assert ansible_

# Generated at 2022-06-22 14:27:33.319427
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u"foo", u"bar"]) == u'foobar'
    assert ansible_native_concat([u"foo", 1]) == u'foo1'
    assert ansible_native_concat([u"foo", 1, 2]) == u'foo12'
    assert ansible_native_concat(["foo", 3]) == 'foo3'
    assert ansible_native_concat([1, u"foo"]) == u'1foo'
    assert ansible_native_concat([1, 2, u"foo"]) == u'12foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["foo", "bar"]) == "foobar"

# Generated at 2022-06-22 14:27:49.607630
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.module_utils.six import PY3

    # we can't use native types if Python isn't 3
    if not PY3:
        return

    data = {
        'foo': 'bar',
        'list': [1, 2, 3],
        'dict': {1: 'one', 2: 'two'},
        'bool': True,
        'none': None,
    }
    expected = {
        'foo': 'bar',
        'list': [1, 2, 3],
        'dict': {1: 'one', 2: 'two'},
        'bool': True,
        'none': None,
    }

# Generated at 2022-06-22 14:27:58.527521
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    x = ansible_native_concat([1])
    assert x == 1
    x = ansible_native_concat([1, 2])
    assert x == u"12"
    x = ansible_native_concat(['a', 4])
    assert x == u"a4"
    x = ansible_native_concat(['a', 'b'])
    assert x == u"ab"
    x = ansible_native_concat(['a', 'b', 3])
    assert x == u"ab3"
    x = ansible_native_concat(['a', 'b', 'c'])
    assert x == u"abc"
    x = ansible_native_concat(['a'])
    assert x == u"a"

# Generated at 2022-06-22 14:28:09.110533
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:28:21.398200
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([NativeJinjaText('a')]) == 'a'
    assert ansible_native_concat([NativeJinjaText('a'), NativeJinjaText('b')]) == 'a'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([['a']]) == ['a']
    assert ansible_native_concat([['a'], 'b', ['c']]) == ['a', 'b', 'c']
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]

# Generated at 2022-06-22 14:28:34.116659
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """We test the function with some of the cases
    where is was causing problems
    See: https://github.com/ansible/ansible/issues/70831
    """
    import pytest
    from ansible.module_utils.common.text.converters import to_bytes

    def _test_concat(expected, nodes):
        """Return the result of concatenating the nodes
        and compare with the expected result"""
        got = ansible_native_concat(nodes)
        if not isinstance(expected, string_types):
            # Ensure that got is not a NativeJinjaText
            # See: https://github.com/pallets/jinja/issues/1200
            assert not isinstance(got, NativeJinjaText)

# Generated at 2022-06-22 14:28:47.224764
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(None) == None

    assert ansible_native_concat([]) == None

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([{}]) == {}
    assert ansible_native_concat(['test']) == 'test'
    assert ansible_native_concat([u'test']) == u'test'
    assert ansible_native_concat([u'test']) == u'test'

    assert ansible_native_concat(['test', 'test']) == 'testtest'
    assert ansible_native_concat([False, 'test']) == 'False'
    assert ansible

# Generated at 2022-06-22 14:28:59.755190
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:29:10.458501
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['string']) == 'string'
    assert ansible_native_concat(['string', 'another']) == 'stringanother'
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['{', '}']) == '{}'
    assert ansible_native_concat(['{', 'key', ':', 'value', '}']) == {'key': 'value'}
    assert ansible_native_concat(['[', '1', ',', '2', ']']) == [1, 2]

# Generated at 2022-06-22 14:29:17.310693
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(["hello"]) == "hello"
    assert ansible_native_concat(["hello", "world"]) == "helloworld"
    assert ansible_native_concat(["hello", "", "world"]) == "helloworld"
    assert ansible_native_concat(["hello", " ", "world"]) == "hello world"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat(["hello", 1, 2, 3]) == "hello123"
    assert ansible_native_concat(["hello", ["world", "foo"], "world"]) == "helloworldworld"

# Generated at 2022-06-22 14:29:29.190039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1, 2, '3']) == [1, 2, '3']
    assert ansible_native_concat([1, 2, '3', AnsibleVaultEncryptedUnicode(b'secret'), 4]) == [1, 2, '3', AnsibleVaultEncryptedUnicode(b'secret'), 4]
    assert ansible_native_concat(['1', 2, '3']) == '123'
    assert ansible_native_concat(['1', 2, '3', AnsibleVaultEncryptedUnicode(b'secret'), 4, '5']) == AnsibleVaultEncryptedUnicode(b'secret')
    assert ansible_

# Generated at 2022-06-22 14:29:57.529993
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test for :func:`ansible_native_concat`."""
    undefined = StrictUndefined()

    assert ansible_native_concat([]) is None
    assert ansible_native_concat([undefined]) is undefined
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['ab', 'cd']) == 'abcd'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat([1.0]) == 1.0
    assert ansible_native_concat([1.0, 2.0]) == 12.0
    assert ans

# Generated at 2022-06-22 14:30:10.081685
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat([None, '2', '']) == ''
    assert ansible_native_concat([None, '2', '3']) == '23'
    assert ansible_native_concat([None, '2', 'a']) == '2a'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1', '2', '3.5']) == '123.5'
    assert ansible_native_concat(['[', '1', ',', '2', ']']) == '[1,2]'

# Generated at 2022-06-22 14:30:20.700525
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['ok', 'ok']) == 'okok'
    assert ansible_native_concat(['ok'] * 2) == 'okok'

    assert ansible_native_concat(['ok', 'ok']) == 'okok'
    assert ansible_native_concat(('ok',) * 2) == 'okok'

    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat(('1', '2')) == '12'

    assert ansible_native_concat(['1', 2]) == '12'
    assert ansible_native_concat(('1', 2)) == '12'

    assert ansible_native_concat([1, '2']) == '12'
    assert ans

# Generated at 2022-06-22 14:30:32.058374
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(["a", "b"])
    assert result == u'ab'

    result = ansible_native_concat([True, "b"])
    assert result == u'Trueb'

    result = ansible_native_concat([True, False])
    assert result is True

    result = ansible_native_concat([])
    assert result is None

    result = ansible_native_concat([{'foo': 'bar'}, {'baz': 'bat'}])
    assert result == {'foo': 'bar', 'baz': 'bat'}

    result = ansible_native_concat(['foo', {'baz': 'bat'}])
    assert result == 'foo{u\'baz\': u\'bat\'}'

    result = ansible_native

# Generated at 2022-06-22 14:30:44.328621
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Unit test for function ansible_native_concat"""
    # pylint: disable=missing-docstring
    from ansible.module_utils.common.text.converters import to_bytes

    def test(inp, out):
        assert container_to_text(ansible_native_concat(inp)) == to_text(out)

    test([False], False)
    test([True], True)
    test([42], 42)
    test(['abc'], 'abc')
    test([to_bytes('abc')], 'abc')
    test([None], None)
    test([{'key': 'value'}], "{'key': 'value'}")
    test([[1, 2, 3]], [1, 2, 3])

# Generated at 2022-06-22 14:30:57.344415
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u'foo']) == 'foo'
    assert ansible_native_concat([1, 2]) == 3
    assert ansible_native_concat([u'a', u'b']) == 'ab'
    assert ansible_native_concat([u'a\n', u'b']) == u'a\nb'
    assert ansible_native_concat([u'a\nb']) == u'a\nb'
    assert ansible_native_concat([u'str', True]) == u'strTrue'
    assert ansible_native_concat([1, u'b']) == u'1b'

# Generated at 2022-06-22 14:31:10.236307
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ('foo' == ansible_native_concat(['foo']))
    assert ('foobar' == ansible_native_concat(['foo', 'bar']))
    assert (['foo', 'bar'] == ansible_native_concat(['[foo,bar]']))
    assert (['foo', 'bar'] == ansible_native_concat(['[f', 'oo', ',b', 'ar]']))

    # https://github.com/pallets/jinja/blob/master/src/jinja2/nativetypes.py#L49-L51
    assert ({1, 2} == ansible_native_concat(['{1,2}']))
    assert ({1, 2} == ansible_native_concat(['{', '1', ',', '2', '}']))

    # https

# Generated at 2022-06-22 14:31:22.796941
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == "12"
    assert ansible_native_concat([1, ['a', 'b']]) == "[1, ['a', 'b']]"
    assert ansible_native_concat(['1', '2']) == "12"
    assert ansible_native_concat(['1', '2', '3']) == "123"
    assert ansible_native_concat([1, 2, 3]) == "123"
    assert ansible_native_concat(['1', ['a', 'b'], 3]) == "[1, ['a', 'b'], 3]"
    assert ansible_native_concat(['1', '2', {'x': 1}]) == "['1', '2', {'x': 1}]"
    assert ansible

# Generated at 2022-06-22 14:31:28.890320
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, '2', 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat(['None']) is None



# Generated at 2022-06-22 14:31:39.773237
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(['a', 2, 'b']) == 'a2b'
    assert ansible_native_concat(['a', 2, 'b']) == 'a2b'
    assert ansible_native_concat(['a', 2, 'b']) == 'a2b'
    assert ansible_native_concat([1, 2, NativeJinjaText('b')]) == '1b2'
    assert ansible_native_concat([NativeJinjaText('a'), 2, 'b']) == 'a2b'
    assert ansible_native_concat([NativeJinjaText('a'), NativeJinjaText('b'), 'c']) == 'a b c'
    assert ansible

# Generated at 2022-06-22 14:32:05.803371
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleMapping
    from ansible.module_utils.common.text.converters import to_str

    class TestException(Exception):
        pass

    class TestObj(object):
        def __init__(self, arg, arg2, arg3):
            self.arg = arg
            self.arg2 = arg2
            self.arg3 = arg3

        def __repr__(self):
            return "{0}('{1}', '{2}','{3}')".format(self.__class__.__name__,
                                                    self.arg, self.arg2, self.arg3)


# Generated at 2022-06-22 14:32:16.739775
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import Environment, DictLoader
