

# Generated at 2022-06-22 14:22:24.613493
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:22:32.585486
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(iter([1])) == 1
    assert ansible_native_concat(iter([1, 2])) == '1 2'
    assert ansible_native_concat([1, 2]) == '1 2'
    assert ansible_native_concat(iter([1, 2, 3])) == '1 2 3'
    assert ansible_native_concat([1, 2, 3]) == '1 2 3'
    assert ansible_native_concat([True, False, None]) == 'True False None'
    assert ansible_native_concat([1, True, 'false', False]) == '1 True false False'

# Generated at 2022-06-22 14:22:45.015614
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(["1", "2"]) == '12'
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat([1, 2, u'34']) == '1234'
    assert ansible_native_concat([1, 2, u'34']) == '1234'
    assert ansible_native_concat([1, 2, u'34', 5]) == '12345'
    assert ansible_native_concat([1, 2, u'34', 5]) == '12345'
    assert ansible_native_concat([1, 2, u'34', 5, 6]) == '123456'
    assert ansible_native_concat([1, 2, u'34', 5, 6]) == '123456'


# Generated at 2022-06-22 14:22:57.576434
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=redefined-outer-name
    # pylint: disable=too-many-branches
    # pylint: disable=too-many-nested-blocks
    # pylint: disable=too-many-return-statements

    # Failures
    try:
        ansible_native_concat([]), "empty generator"
    except Exception:
        pass

    try:
        ansible_native_concat([StrictUndefined()]), "undefined in generator"
    except Exception:
        pass

    # Single node
    assert ansible_native_concat([u"ansible"]) == u"ansible"
    assert ansible_native_concat([u"ansible"]) == to_text(b"ansible", encoding='utf-8')
    assert ansible_native_

# Generated at 2022-06-22 14:23:10.213268
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:23:23.139117
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test_ansible_native_concat01
    assert ansible_native_concat((u'foo', u'bar')) == u'foobar'
    assert ansible_native_concat((u'foo', u'\n', u'bar')) == u'foo\nbar'
    assert ansible_native_concat((u'foo', u'\n', u'bar', u'\n')) == u'foo\nbar\n'
    assert ansible_native_concat((u'', u'bar')) == u'bar'
    assert ansible_native_concat((u'foo', u'')) == u'foo'
    assert ansible_native_concat((u'', u'')) == u''

    # test_ansible_native_concat02
    assert ansible_native_

# Generated at 2022-06-22 14:23:32.763061
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class DummyNode:
        def __init__(self, value):
            self._value = value

        def __repr__(self):
            return '<DummyNode({})>'.format(self._value)

        def __str__(self):
            return container_to_text(self._value)

    def _nodes(values):
        for value in values:
            yield DummyNode(value)

    # Literal evaluation
    assert ansible_native_concat(_nodes([1, 2, 3])) == 1
    assert ansible_native_concat(_nodes(['1', '2', '3'])) == '1'
    assert ansible_native_concat(_nodes(['0'])) is False
    assert ansible_native_concat(_nodes(['1']))
    assert ansible

# Generated at 2022-06-22 14:23:44.797740
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: test for Vaulted text
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([2, 3, 5]) == u'235'
    assert ansible_native_concat([u'2', 3, 5]) == u'235'
    assert ansible_native_concat([u'23', u'4']) == u'234'
    assert ansible_native_concat((2, 3, 5)) == u'235'
    assert ansible_native_concat([u'2', 3, 5]) == u'235'
    assert ansible_native_concat([u'"2"']) == u'"2"'
    assert ansible_native_concat([u'"2"', u'3'])

# Generated at 2022-06-22 14:23:56.510902
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    assert isinstance(ansible_native_concat([1]), int)
    assert ansible_native_concat([1]) == 1

    assert isinstance(ansible_native_concat([1, 2]), int)
    assert ansible_native_concat([1, 2]) == 12

    assert isinstance(ansible_native_concat([1, 2, 3]), int)
    assert ansible_native_concat([1, 2, 3]) == 123

    assert isinstance(ansible_native_concat(('1', '2', '3')), text_type)
    assert ansible_native_concat(('1', '2', '3')) == '123'


# Generated at 2022-06-22 14:24:08.760778
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleSequence, AnsibleMapping
    from ansible.module_utils.common.text.converters import to_bytes
    from ansible.module_utils.common.text.converters import to_text
    from ansible.module_utils.common.text.converters import to_native
    from ansible.module_utils.parsing.convert_bool import boolean

    # Test concat of an empty list
    assert ansible_native_concat(AnsibleSequence([])) == []

    # Test concat of a single node
    assert ansible_native_concat(['abc']) == 'abc'

    # Test concat of two nodes
    assert ansible_native_concat(['abc', 'def']) == 'abcdef'



# Generated at 2022-06-22 14:24:19.446161
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.jinja import AnsibleUndefined
    from ansible.module_utils.common.text.converters import to_bytes

    def _test_settings(data):
        lhs = container_to_text(data, format='json', pretty=False)
        assert isinstance(lhs, text_type)
        rhs = container_to_text(ansible_native_concat([data]), format='json', pretty=False)
        assert isinstance(rhs, text_type)
        return lhs == rhs

    # primitive types
    assert _test_settings(None)
    assert _test_settings(True)
    assert _test_settings(False)
    assert _test_settings(1)
    assert _test_settings(3.14)

# Generated at 2022-06-22 14:24:30.601039
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleUnicode

    assert ansible_native_concat([]) == None
    assert ansible_native_concat([10]) == 10
    assert ansible_native_concat([AnsibleUnicode("10")]) == "10"
    assert ansible_native_concat([AnsibleUnicode("10"), 20]) == "10 20"
    assert ansible_native_concat([AnsibleUnicode("10"), AnsibleUnicode("20")]) == "10 20"
    assert ansible_native_concat([AnsibleUnicode("10 2"), AnsibleUnicode("0")]) == "10 20"

# Add ansible_native_concat as a filter to jinja2 environment
# This is used in ansible.plugins

# Generated at 2022-06-22 14:24:43.783401
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat([False]) == False
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat(range(10)) == u'0123456789'
    assert ansible_native_concat(['a', 'b', 'c', 'd']) == u'abcd'
    assert ansible_native_concat(['12']) == 12
    assert ansible_native_concat(['[1,2]']) == [1,2]
    assert ansible_native_concat(['{"a":1}']) == {"a":1}


# Generated at 2022-06-22 14:24:56.925654
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # TODO: add comments why the test case
    #       TODO: add assert
    #       TODO: add test cases for other functions

    nodes_list = [
        "ansible",
        "for",
        "humans",
    ]
    ansible_native_concat(nodes_list)

    nodes_list = [
        "\tansible",
        "for",
        "\thumans",
    ]
    ansible_native_concat(nodes_list)

    nodes_list = [
        "",
        "ansible",
        "for",
        "humans",
        "",
        "",
    ]
    ansible_native_concat(nodes_list)


# Generated at 2022-06-22 14:25:06.411906
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    int_value = 123
    list_value = [1, 2, 3]
    str_value = 'hello'
    base_value = ansible_native_concat([int_value])
    assert base_value == 123
    assert isinstance(base_value, int)
    base_value = ansible_native_concat([list_value])
    assert base_value == list_value
    assert isinstance(base_value, list)
    base_value = ansible_native_concat([str_value])
    assert base_value == str_value
    assert isinstance(base_value, str)

    base_value = ansible_native_concat(['123', list_value, str_value])

# Generated at 2022-06-22 14:25:15.785308
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """ Test of ansible_native_concat function
    """
    import jinja2
    from ansible.module_utils.common.text.converters import (
        to_native,
        container_to_text,
    )

    def eq(result, expected):
        expected_text = container_to_text(expected)
        result_text = container_to_text(result)
        if result_text != expected_text:
            raise AssertionError(
                '{} != {}'.format(expected_text, result_text)
            )

    env = jinja2.Environment(undefined=StrictUndefined)
    env.tests['func'] = ansible_native_concat

    assert env.from_string('{{ [1, 2, 3] | func }}').render() == '123'
   

# Generated at 2022-06-22 14:25:27.475252
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([1, 'a', {'a': 'b'}, '[1, 2, 3]']) == [1, 'a', {'a': 'b'}, [1, 2, 3]]
    assert ansible_native_concat(['-', 'a', 'b']) == '-ab'
    assert ansible_native_concat(['-', 'a', 'b', '[', '1', '2']) == '-ab[12'
    assert ansible_native_concat(['a', 'b', '-', '1', '2']) == 'ab-12'


# Generated at 2022-06-22 14:25:38.927559
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text, to_bytes
    from ansible.module_utils.common.collections import is_sequence

    for num, entry in enumerate(test_ansible_native_concat.cases):
        expected = entry['expected']
        result = ansible_native_concat(entry['iterable'])
        assert result == expected, 'test #%s failed: %s != %s' % (num + 1, container_to_text(result), container_to_text(expected))

        # Ensure that we return native Python types when we can.
        assert isinstance(result, type(expected))
        if isinstance(result, string_types):
            assert isinstance(result, text_type)

# Generated at 2022-06-22 14:25:48.792296
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat([' "1"']) == ' "1"'
    assert ansible_native_concat(['"1"']) == '1'
    assert ansible_native_concat([b'1']) == b'1'
    assert ansible_native_concat(['1', '2', '3']) == '123'



# Generated at 2022-06-22 14:25:56.961862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat([u'a', u'b']) == u'ab'
    assert ansible_native_concat([u'foo', 4, u'bar']) == u'foo4bar'
    assert ansible_native_concat([[1, 2], 3]) == [1, 2]
    assert ansible_native_concat([{'a': 1, 'b': 2}, {'c': 3}]) == {'a': 1, 'b': 2, 'c': 3}
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c']) != 'abc'
   

# Generated at 2022-06-22 14:26:09.426662
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'1 2'
    assert ansible_native_concat([1, 2, 3]) == u'1 2 3'
    assert ansible_native_concat(x for x in [1, 2, 3]) == u'1 2 3'
    assert ansible_native_concat([1, 2, 3, 4]) == u'1 2 3 4'
    assert ansible_native_concat(x for x in [1, 2, 3, 4]) == u'1 2 3 4'
    assert ansible_native_concat([True, False]) == u'True False'
    assert ansible_native_concat([True, False, True])

# Generated at 2022-06-22 14:26:19.056110
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a', 'b', 'c']) == u'abc'
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1.0, 2.0, 3.0]) == 6.0
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([b'a', b'b', b'c']) == b'abc'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

    class MyStr(text_type):
        pass


# Generated at 2022-06-22 14:26:31.113098
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:26:43.523417
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # If a single data is passed, return it directly
    assert ansible_native_concat([1]) == 1

    # If list of data is passed along with `NativeJinjaText`, concatenate data
    # and wrap it with `NativeJinjaText`.
    assert ansible_native_concat([1, 2, 3, 4]) == '1234'
    assert isinstance(ansible_native_concat([1, 2, 3, NativeJinjaText(4)]), NativeJinjaText)

    # If list of data is passed, concatenate data as string.
    # If the result can be parsed with `ast.literal_eval`, return parsed value.
    # If the result cannot be parsed with `ast.literal_eval`, return string.

# Generated at 2022-06-22 14:26:51.099747
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:26:54.964576
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    nodes = (
        'foo',
        # this node should not be evaluated
        StrictUndefined(),
        'bar',
    )
    assert ansible_native_concat(nodes) == u'foobar'



# Generated at 2022-06-22 14:27:04.483777
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # variables used for tests
    undefined = StrictUndefined()
    text = NativeJinjaText('bar1')
    vaulted = AnsibleVaultEncryptedUnicode('foo1')
    result = ansible_native_concat([text, 'bar', vaulted])
    assert result == 'bar1barfoo1'
    result = ansible_native_concat([text, 'bar', vaulted, undefined])
    assert isinstance(result, StrictUndefined)
    result = ansible_native_concat(text)
    assert result == 'bar1'
    result = ansible_native_concat('bar')
    assert result == 'bar'
    result = ansible_native_concat([text])
    assert result == 'bar1'
    result = ansible_native_concat([text, undefined])
   

# Generated at 2022-06-22 14:27:16.764394
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=import-outside-toplevel,protected-access
    from ansible.parsing.yaml.constructor import AnsibleConstructor
    from ansible.parsing.yaml.dumper import AnsibleDumper
    from ansible.parsing.yaml.loader import AnsibleLoader

    yaml_anchor = '&test_anchor'
    yaml_alias = '*test_anchor'
    yaml_binary_string = '|\n  hi'
    yaml_complex_dict = (
        '{foo: {bar: baz}, hello: world, integers: [1, 2, 3]}'
    )
    yaml_complex_str = "This has 'quotes' and \"quotes\""
    yaml_float = '1.2'
    yaml

# Generated at 2022-06-22 14:27:27.112457
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['"a"']) == 'a'
    assert ansible_native_concat(['a', '"b"']) == 'ab'
    assert ansible_native_concat(['"a', 'b"']) == 'ab'
    assert ansible_native_concat(['"a"', 'b']) == 'ab'
    assert ansible_native_concat(['"a', '"b"']) == 'ab'
    assert ansible_native_concat(['"a"', '"b"']) == 'ab'
    assert ansible

# Generated at 2022-06-22 14:27:36.145279
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # call the function with simple single item list
    ret = ansible_native_concat([True])
    assert ret is True

    # Call the function with single item list of strings
    ret = ansible_native_concat([u"test"])
    assert ret == u"test"

    # Call the function with single item list of strings (bytes)
    ret = ansible_native_concat([b"test"])
    assert ret == u"test"

    # Call the function with single item list of strings (int)
    ret = ansible_native_concat([42])
    assert ret == 42

    # Call the function with invalid floats
    ret = ansible_native_concat([u"<42,23.2>", u"[4.2,3.1]"])

# Generated at 2022-06-22 14:27:42.985902
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Use a generator of strings to make sure we use the concatenation
    # function ansible_native_concat and not some other logic in
    # ansible_native_concat that only works for lists or tuples.
    input = (
        '{{ 1 }}',
        '{{ 1 }}',
        '{{ 2 }}',
        '{{ "foo" }}',
        '{{ "bar" }}',
        '{{ True }}',
        '{{ [1, 2, 3] }}',
        '{{ {a: 1} }}',
        '{{ template }}',
    )
    expected = (1, 1, 2, "foo", "bar", True, [1, 2, 3], {'a': 1}, 'template')

    assert tuple(ansible_native_concat(input)) == expected

# Generated at 2022-06-22 14:27:55.640729
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([u'foo', 42]) == u'foo42'
    assert ansible_native_concat([u'foo', None]) == u'foo'
    assert ansible_native_concat([42, u'foo']) == u'42foo'
    assert ansible_native_concat([u'foo', u"bar", u"baz"]) == u'foobarbaz'

    value = ansible_native_concat([u"foo", u"bar"])
    assert isinstance(value, text_type)

    value = ansible_native_concat([u"foo", u"42"])
    assert isinstance(value, text_type)

    value = ansible

# Generated at 2022-06-22 14:28:07.146662
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # string
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3, '']) == u'123'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([1, u'b', u'c']) == u'1bc'
    assert ansible_native_concat([None, u'b', u'c']) == u'bc'

# Generated at 2022-06-22 14:28:20.296887
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import sys
    import unittest

    if sys.version_info < (3, 0):
        # Earlier Python versions are not used by Ansible and therefore not
        # supported by this test.
        raise unittest.SkipTest('Test is not suitable for Python 2.x')

    # We need to use NativeJinjaText here because otherwise we would use the
    # jinja.tests.utils.env which is not present in Python 3.
    def concat(a, b, c):
        return NativeJinjaText(ansible_native_concat((a, b, c)))

    class TestAnsibleNativeConcat(unittest.TestCase):

        def test_empty(self):
            self.assertIsNone(ansible_native_concat([]))

        # TODO we should actually be able to compare with an

# Generated at 2022-06-22 14:28:33.049776
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat(["None"]) == "None"
    assert ansible_native_concat([NativeJinjaText("string")]) == "string"
    assert ansible_native_concat([u"string"]) == u"string"
    assert ansible_native_concat([1234]) == 1234
    assert ansible_native_concat(["1234"]) == 1234
    assert ansible_native_concat(["1234", "5678"]) == "12345678"
    assert ansible_native_concat([1234, 5678]) == 12345678
    assert ansible_native_concat(["123.45"]) == 123.45

# Generated at 2022-06-22 14:28:45.998828
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    text_undef = StrictUndefined('text_undef')
    int_undef = StrictUndefined('int_undef')
    string_undef = StrictUndefined('string_undef')
    list_undef = StrictUndefined('list_undef')
    dict_undef = StrictUndefined('dict_undef')
    bool_undef = StrictUndefined('bool_undef')
    float_undef = StrictUndefined('float_undef')


# Generated at 2022-06-22 14:28:58.747125
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.six.moves import builtins
    import ast

    literal_eval = builtins.__dict__['literal_eval']
    parse = ast.__dict__['parse']

    # ast.literal_eval just returns `x` when x is not a string
    # 'Foo' is our proxy for the most common non-string input
    assert ansible_native_concat(['Foo']) == 'Foo'

    # ansible_native_concat is a wrapper function that calls ast.literal_eval
    # ast.literal_eval just returns `x` when x is not a string
    ast.literal_eval = lambda x: x
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['Foo']) == 'Foo'

# Generated at 2022-06-22 14:29:07.503184
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class DummyNode(object):
        def __init__(self, val):
            self.value = val

        def __unicode__(self):
            return to_text(self.value)

    dummy_node = DummyNode
    assert ansible_native_concat([dummy_node(1)]) == 1
    assert ansible_native_concat([dummy_node('foo'), dummy_node(1)]) == 'foo1'
    assert ansible_native_concat([dummy_node(1), dummy_node('foo')]) == '1foo'
    assert ansible_native_concat([dummy_node('foo'), dummy_node('bar')]) == 'foobar'

# Generated at 2022-06-22 14:29:15.667796
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:29:28.005728
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', 'bar', 'baz']) == 'foobarbaz'
    assert ansible_native_concat(['foo', 'bar', 'baz'],) == 'foobarbaz'
    assert ansible_native_concat(['', 'foobar']) == 'foobar'
    assert ansible_native_concat(['foobar', '']) == 'foobar'
    assert ansible_native_concat(['foobar']) == 'foobar'
    assert ansible_native_concat([{'key': 'value'}]) == {'key': 'value'}

# Generated at 2022-06-22 14:29:43.418308
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # The function ansible_native_concat is a recommended way to concatenate
    # a dynamic number of Ansible variables according to
    # https://github.com/pallets/jinja/pull/1199
    # So let's make sure it works as expected with a variety of data types
    # (int, dict, list, string, AnsibleVaultEncryptedUnicode, None)
    # as well as with a single argument and with multiple arguments
    assert ansible_native_concat([]) is None

    assert type(ansible_native_concat([42])) is int
    assert ansible_native_concat([42]) == 42

    assert type(ansible_native_concat(['42'])) is int
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat

# Generated at 2022-06-22 14:29:54.633672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # pylint: disable=no-self-use
    testcases = (
        # https://github.com/ansible/ansible/issues/70831#issuecomment-664190894
        {
            'args': (1,),
            'expect': 1,
        },
        {
            'args': ('string',),
            'expect': 'string',
        },
        {
            'args': ('a', 'r', 'r', 'a', 'y'),
            'expect': ['a', 'r', 'r', 'a', 'y'],
        },
        {
            'args': ('a', ' ', 'r', 'a', 'y'),
            'expect': 'a r a y',
        },
    )

# Generated at 2022-06-22 14:29:59.971422
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Tests the ansible_native_concat function
    """
    # Test evaluation of generator expressions
    gen_expr = (i for i in (1, 2, 3))
    assert ansible_native_concat(gen_expr) == 1

    # Test string concatenation
    gen_expr = (i for i in ('hello ', 'world'))
    assert ansible_native_concat(gen_expr) == 'hello world'

    # Test literal evaluation
    gen_expr = (i for i in (1, 2, 3))
    assert ansible_native_concat(gen_expr) == 1

    # Test unsupported types
    gen_expr = (i for i in ({'a': 'b'}, ))
    assert ansible_native_concat(gen_expr) == {'a': 'b'}

    #

# Generated at 2022-06-22 14:30:11.851116
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    class MyCollection(Mapping):
        def __init__(self):
            self._mapping = dict(a='b', c='d')

        def __iter__(self):
            return iter(self._mapping)

        def __len__(self):
            return len(self._mapping)

        def __getitem__(self, key):
            return self._mapping[key]

    assert ansible_native_concat([1, 2]) == 1
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['1', '2', 'a']) == '1 2 a'
    assert ansible_native_concat([['1', '2'], 3]) == '1 2 3'

# Generated at 2022-06-22 14:30:22.225880
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['x']) == 'x'
    assert ansible_native_concat(['1']) == 1
    assert ansible_native_concat(['1.0']) == 1.0
    assert ansible_native_concat(['False']) == False
    assert ansible_native_concat(['[]']) == []
    assert ansible_native_concat(['{}']) == {}
    assert ansible_native_concat(['[1]']) == [1]
    assert ansible_native_concat(['{1: 1}']) == {1: 1}
    assert ansible_native_concat(['True']) == True

# Generated at 2022-06-22 14:30:32.742076
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    try:
        import __builtin__ as builtins
    except ImportError:
        import builtins
    from jinja2 import Environment
    import operator
    import sys

    env = Environment()
    env.globals['concat'] = ansible_native_concat
    env.globals.update(vars(operator))

    c = env.compiler
    c.init_state()

    c.visit(c.parse('"foo" ~ "bar"', 'test'))
    assert c.state.stack[-1][1] == 'foobar'
    c.visit(c.parse('"foo" + "bar"', 'test'))
    assert c.state.stack[-1][1] == 'foobar'

# Generated at 2022-06-22 14:30:44.717651
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import types
    import json
    import yaml

    # type name: (py obj, js obj)
    # js obj is the string representation of the py obj

# Generated at 2022-06-22 14:30:57.430320
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Verify that the function returns the correct native type

    # Test that ansible_native_concat returns None if the list
    # of compiled nodes is empty
    assert ansible_native_concat([]) is None

    # Test that ansible_native_concat returns a string when
    # the list of compiled nodes contains more than one element
    assert isinstance(ansible_native_concat([1, 2]), string_types)

    # Test that ansible_native_concat returns the value of a single node
    assert ansible_native_concat([1]) == 1

    # Test that ansible_native_concat returns the variable if the node
    # is a NativeJinjaText variable
    node = NativeJinjaText(u"{{ variable }}")
    assert ansible_native_concat([node]) == node

    # Test

# Generated at 2022-06-22 14:31:09.349779
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    data = "abcd"
    assert ansible_native_concat(data) == data

    data = ('a', 'b', 'c', 'd')
    assert ansible_native_concat(data) == 'abcd'

    data = ['a', 'b', 'c', 'd']
    assert ansible_native_concat(data) == 'abcd'

    data = ['a', 'b', 'c', 'd']
    assert ansible_native_concat(iter(data)) == 'abcd'

    data = ['a', 'b', 'c', 'd']
    assert ansible_native_concat(chain.from_iterable(data)) == 'abcd'

# Generated at 2022-06-22 14:31:21.687079
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def c(val):
        if isinstance(val, u''):
            return NativeJinjaText(val)
        return val

    assert ansible_native_concat([c(u'1'), c(u'2')]) == u'12'
    assert ansible_native_concat([c(u'foo'), c(u'bar')]) == u'foobar'
    assert ansible_native_concat([c(u'foo'), c(u'bar'), c(u'baz')]) == u'foobarbaz'
    assert ansible_native_concat([c(1), c(2), c(3)]) == 123
    assert ansible_native_concat([c('1'), c('2'), c('3')]) == 123

# Generated at 2022-06-22 14:31:30.611294
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', ['bar']]) == 'foo[\'bar\']'
    assert ansible_native_concat(['foo', '\n', ['bar']]) == 'foo\n[\'bar\']'
    assert ansible_native_concat(['foo', '\n', ['bar']], literal_eval=False) == 'foo\n[\'bar\']'
    assert ansible_native_concat(['foo', 'bar'], literal_eval=False) == 'foobar'
    assert ansible_native_concat([['foo', ['bar']]]) == "['foo', ['bar']]"

# Generated at 2022-06-22 14:31:41.013969
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:31:51.302789
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 'string']) == 1
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([12.3]) == 12.3
    assert ansible_native_concat([12.3, 'foo']) == 12.3
    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat(['a', 2, 'c']) == 'a2c'
    assert ansible_native_concat([1, 2, 3]) == '123'

# Generated at 2022-06-22 14:32:02.494507
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    """Test function ansible_native_concat and its return values
    """
    assert ansible_native_concat(["a"]) == "a"
    assert type(ansible_native_concat(["a"])) == str
    assert ansible_native_concat([1]) == 1
    assert type(ansible_native_concat([1])) == int
    assert ansible_native_concat([1, 2, 3, 4, 5]) == 15
    assert type(ansible_native_concat([1, 2, 3, 4, 5])) == int
    assert ansible_native_concat(["a", "b", "c", "d", "e"]) == "abcde"
    assert type(ansible_native_concat(["a", "b", "c", "d", "e"]))

# Generated at 2022-06-22 14:32:07.318297
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    from ansible.module_utils.common.text.converters import container_to_text

    # The following line is commented until we decide what to do with
    # the undefined object.
    # env = jinja2.Environment(undefined=jinja2.StrictUndefined)
    env = jinja2.Environment()
    env.filters['native_concat'] = ansible_native_concat

    env.filters['to_text'] = container_to_text

    template = '{{ [1, 2] | native_concat }}'
    assert env.from_string(template).render() == [1, 2]

    template = '{{ [1, "2"] | native_concat }}'
    assert env.from_string(template).render() == [1, "2"]

# Generated at 2022-06-22 14:32:17.581620
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1234]) == 1234
    assert ansible_native_concat([NativeJinjaText(1234)]) == 1234
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([NativeJinjaText('abc')]) == 'abc'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat([NativeJinjaText('a'), NativeJinjaText('b'), NativeJinjaText('c')]) == 'abc'
    assert ansible_native_concat(['a', NativeJinjaText('b'), 'c']) == 'abc'
    assert ansible_native