

# Generated at 2022-06-22 14:22:20.939990
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:22:33.840378
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text
    from ansible.vars.unsafe_proxy import UnsafeProxy
    from ansible.utils.unsafe_proxy import wrap_var
    from ansible.vars.unsafe_proxy import AnsibleUnsafeText
    wrapped_list = wrap_var([u'hello', u' ', u'world'])
    wrapped_list_ansible_unsafe_text = wrap_var([u'hello', u' ', u'world'],
                                                AnsibleUnsafeText)
    wrapped_list_2 = wrap_var([u'hello', u' ', u'world'])
    wrapped_list_3 = wrap_var([u'hello', u' ', u'world'])

# Generated at 2022-06-22 14:22:46.392862
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'

    assert ansible_native_concat(['foo', 'c', 'bar']) == 'foocbar'
    assert ansible_native_concat(['foo', '   ', 'bar']) == 'foo   bar'
    assert ansible_native_concat(['foo', '\t', 'bar']) == 'foo\tbar'

    assert ansible_native_concat([1, 2]) == 12
    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', '2', '3']) == '123'
    assert ansible_native_concat(['1', '2', '3', '4']) == '1234'

# Generated at 2022-06-22 14:22:59.121972
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(iter([])) is None
    assert ansible_native_concat(iter(['foo'])) == 'foo'
    assert ansible_native_concat(iter(['foo', 'bar'])) == 'foobar'
    assert ansible_native_concat(iter(['foo', 'bar', 'baz'])) == 'foobarbaz'
    assert ansible_native_concat(iter([u'foo', u'bar'])) == 'foobar'
    assert ansible_native_concat(iter([u'foo', u'\u2028'])) == 'foo\u2028'
    assert ansible_native_concat(iter([u'\u2028', u'foo'])) == '\u2028foo'

# Generated at 2022-06-22 14:23:11.507730
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # unit test for function ansible_native_concat
    from ansible.parsing import yaml
    from ansible.template import Templar
    from ansible.vars.manager import VariableManager

    tmplar = Templar(VariableManager(), {})


# Generated at 2022-06-22 14:23:24.619826
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([5, 10]) == 15
    assert ansible_native_concat([12, 'string']) == "12string"
    assert ansible_native_concat([12, 3, 4]) == 1234
    assert ansible_native_concat(['string', ' ', 'value']) == "string value"
    assert ansible_native_concat([u'S\xf8ren', u' Erik', u' Larsen']) == u'S\xf8ren Erik Larsen'
    assert ansible_native_concat([u'S\xf8ren', u' Erik', u' Larsen']) == u'S\xf8ren Erik Larsen'
    assert ansible_native_concat(['12', True]) == '12True'

# Generated at 2022-06-22 14:23:33.587124
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    env = jinja2.Environment(extensions=(NativeJinjaText,))
    env.globals['foo'] = 'bar'

    assert ansible_native_concat(env._parse('{{ foo }}').body[0].values) == 'bar'
    assert ansible_native_concat(env._parse('{{ 1 + 1 }}').body[0].values) == 2
    assert ansible_native_concat(env._parse('{{ "foo" }}').body[0].values) == 'foo'
    assert ansible_native_concat(env._parse('{{ "foo" }}').body[0].values) == 'foo'
    assert ansible_native_concat(env._parse('{{ "foo"|string }}').body[0].values) == 'foo'
    assert ansible

# Generated at 2022-06-22 14:23:45.544749
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Python v2.7 literal_eval crashes on None; should return None
    assert ansible_native_concat([None]) is None

    # Python v2.7 literal_eval crashes on long; should return long
    assert ansible_native_concat([1000000000000000]) == 1000000000000000

    # should return int
    assert ansible_native_concat([1]) == 1

    # should return string
    assert ansible_native_concat(['foo']) == 'foo'

    # should return dict
    assert ansible_native_concat([{'foo': 'bar'}]) == {'foo': 'bar'}

    # should return combined string
    assert ansible_native_concat([1, 'foo']) == '1foo'

    # should return combined dict

# Generated at 2022-06-22 14:23:54.585406
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat(['a']) == 'a'
    assert ansible_native_concat([1.0, 2.0]) == '1.02.0'
    assert ansible_native_concat([1.0, 2.0]) == '1.02.0'
    assert ansible_native_concat([2.0]) == 2.0
    assert ansible_native_concat(['1', 2.0]) == '1'
    assert ansible_native_concat(['1', 2.0]) == '1'



# Generated at 2022-06-22 14:24:06.814491
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat([1, 2, 3], [4, 5, 6]) == u"1 2 3 4 5 6"
    assert ansible_native_concat(["1", 2, 3]) == u"1 2 3"
    assert ansible_native_concat([1, 2, 3]) == 1
    assert ansible_native_concat(["1", "2", 3]) == 1
    assert ansible_native_concat(["1", "2", 3], [4, "5", 6]) == [1, 2, 3, 4, 5, 6]
    assert ansible_native_concat("1", "2", "3") == 1
    assert ansible_native_concat("1", "2", 3) == u

# Generated at 2022-06-22 14:24:18.064887
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([4, 2]) == '42'
    assert ansible_native_concat([4, 'foo', 2]) == '4foo2'
    assert ansible_native_concat([4, 'foo', 2, 3, 'bar', 4]) == '4foo234bar4'
    assert ansible_native_concat([4, 'foo', 2, 'bar', 4]) == '4foo2bar4'
    assert ansible_native_concat([{'a': 42}, 4]) == '{a: 42}4'

# Generated at 2022-06-22 14:24:29.757672
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from jinja2 import DictLoader
    from jinja2 import Environment

    E = None
    env = Environment(loader=DictLoader({}))

    # Pass value without change
    E = env.from_string("{{ ansible_native_concat(['a', 'b', 'c']) }}")
    assert E.render() == 'abc'

    # Concatenate and parse string
    E = env.from_string("{{ ansible_native_concat(['True', 'True']) }}")
    assert E.render() == 'TrueTrue'
    E = env.from_string("{{ ansible_native_concat(['False', 'False']) }}")
    assert E.render() == 'FalseFalse'

# Generated at 2022-06-22 14:24:42.257181
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:24:49.343078
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2]) == '12'
    assert ansible_native_concat(['1', '2']) == '12'
    assert ansible_native_concat([1.0, 2.0]) == '1.02.0'
    assert ansible_native_concat([1.0, '2']) == '1.02'
    assert ansible_native_concat([1, 2.0]) == '12.0'
    assert ansible_native_concat(['1', 2.0]) == '12.0'

    text = '1,2.0'
    assert ansible_native_concat([text]) == text
    assert ansible

# Generated at 2022-06-22 14:24:59.456398
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode as AnsibleVaultEncryptedUnicode
    from ansible.utils.native_jinja import NativeJinjaText as AnsibleNativeJinjaText


# Generated at 2022-06-22 14:25:07.301089
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == ['foo', 'bar']
    assert ansible_native_concat([1, 2]) == [1, 2]
    assert ansible_native_concat([1, [2, 3]]) == [1, [2, 3]]
    assert ansible_native_concat([1, [2, 3]]) == [1, [2, 3]]
    assert ansible_native_concat([1, {'a': 2, 'b': 3}]) == [1, {'a': 2, 'b': 3}]
    assert ansible_native_concat([1, {'a': 2, 'b': 3}]) == [1, {'a': 2, 'b': 3}]

# Generated at 2022-06-22 14:25:18.086932
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # call a function to initialise the ansible-native-concat function
    ansible_native_concat([])

    # create the containers to hold the data for the function
    nodes = []

    assert ansible_native_concat(nodes) == None

    # test with string, numbers and booleans
    nodes = [u'10', u'20', u'1.1']
    assert ansible_native_concat(nodes) == u'10201.1'
    nodes = [u'10', u'20', u'1.1', u'true']
    assert ansible_native_concat(nodes) == u'10201.1true'
    # Test with a single item
    nodes = [u'10']
    assert ansible_native_concat(nodes) == u'10'

   

# Generated at 2022-06-22 14:25:30.443369
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_bytes

    assert ansible_native_concat(['Hello', ',', ' World!']) == 'Hello, World!'
    assert ansible_native_concat(['Hello', ' World!']) == 'Hello World!'
    assert ansible_native_concat([]) is None
    # Test ast.literal_eval return values
    assert ansible_native_concat(['42']) == 42
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat(['{"a": "b"}']) == {"a": "b"}
    assert ansible_native_concat(['"Hello, World!"']) == 'Hello, World!'
    assert ansible_native

# Generated at 2022-06-22 14:25:37.346265
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    module = types.ModuleType('__main__')
    module.__builtins__ = {'object': object}
    module.__name__ = __name__

    _exec = getattr(types.ModuleType(module.__name__), '__dict__').__setitem__
    _exec('ansible_native_concat', ansible_native_concat)
    _exec('StrictUndefined', StrictUndefined)
    _exec('str', text_type)
    _exec('Mapping', Mapping)
    _exec('is_sequence', is_sequence)
    _exec('string_types', string_types)
    _exec('container_to_text', container_to_text)
    _exec('AnsibleVaultEncryptedUnicode', AnsibleVaultEncryptedUnicode)

# Generated at 2022-06-22 14:25:43.035990
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test if the result of the expression can be parsed using literal_eval
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['[1, 2, 3]']) == [1, 2, 3]
    assert ansible_native_concat([['1', '2', '3']]) == ['1', '2', '3']
    # Test if the value is returned as integer when the expression is a integer
    assert ansible_native_concat(['1']) == 1
    # Test if the value is returned as dictionary when the expression is a
    # dictionary
    assert ansible_native_concat(['{"foo": "bar"}']) == {'foo': 'bar'}
    # Test if the value is returned as string when the expression is a string

# Generated at 2022-06-22 14:25:55.021460
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # given
    class A:
        def __init__(self, val):
            self.val = val

        def __str__(self):
            return str(self.val)


# Generated at 2022-06-22 14:26:06.076728
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([None]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([u"a ", u"bc", u":1"]) == u"a bc:1"
    assert ansible_native_concat([u"a ", u"bc", u":1"]) == u"a bc:1"
    assert ansible_native_concat([u"1"]) == 1
    assert ansible_native_concat([u"1", u"2"]) == u"12"
    assert ansible_native_concat([u"1 ", u"2"]) == u"1 2"
    assert ansible_native_concat([u"1", u" 2"]) == u"1 2"

# Generated at 2022-06-22 14:26:16.926052
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_text

    # test the sequence of a string "str", unicode "u", 3, and a list [1, 2, 3]
    seq = ("str", u"u", 3, [1, 2, 3])
    out = ansible_native_concat(seq)
    assert type(out) == list
    assert out == [u"stru", 3, [1, 2, 3]]
    assert type(out[0]) == text_type
    assert type(out[1]) == int
    assert type(out[2]) == list
    assert type(out[2][0]) == int

    out = ansible_native_concat(map(to_text, seq))
    assert out == [u"stru", 3, [1, 2, 3]]



# Generated at 2022-06-22 14:26:23.661357
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat((None,)) is None
    assert isinstance(ansible_native_concat((1, 2, 3)), int)
    assert isinstance(ansible_native_concat((1, '2', 3)), text_type)
    assert isinstance(ansible_native_concat(('a', {'b': 'c'}, 'd')), text_type)

    assert isinstance(ansible_native_concat(['a', {'b': 'c'}, 'd']), text_type)

    assert ansible_native_concat(['a', {'b': 'c'}, 'd']) == u"a{'b': 'c'}d"

    assert isinstance(ansible_native_concat(('1', '2', '3')), int)

    assert ansible

# Generated at 2022-06-22 14:26:34.558374
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.utils.unsafe_proxy import AnsibleUnsafeText
    from jinja2.runtime import Undefined

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(["a"]) == "a"
    assert ansible_native_concat(["a", "b", "c"]) == "abc"
    assert ansible_native_concat(["1", "2", "3"]) == "123"
    assert ansible_native_concat(["1", "2", "3.0", "4.5"]) == "123.04.5"
    assert ansible_native_concat(["1", "2", "3.0", "4.5", "false", "true"]) == "123.04.5falsetrue"
    assert ansible

# Generated at 2022-06-22 14:26:45.887201
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert isinstance(ansible_native_concat([u'foo']), text_type)
    assert isinstance(ansible_native_concat([b'foo']), text_type)
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([u'foo', True]) == u'fooTrue'
    assert ansible_native_concat([u'foo\nbar', True]) == u'foo\nbarTrue'
    assert ansible_native_concat([u'foo', [1, 2]]) == u'foo[1, 2]'


# Generated at 2022-06-22 14:26:58.116482
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(
        [NativeJinjaText('[1, 2, 3]')]
    ) == [1, 2, 3]

    assert ansible_native_concat(
        [NativeJinjaText('[1, 2, 3]'), NativeJinjaText('[4, 5, 6]')]
    ) == [1, 2, 3, 4, 5, 6]

    assert ansible_native_concat(
        [NativeJinjaText('[1, 2, 3]'), NativeJinjaText('[4, 5, 6]')],
    ) == [1, 2, 3, 4, 5, 6]


# Generated at 2022-06-22 14:27:06.060529
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def eq(a, b):
        return a == b

    def test(data, expected):
        res = ansible_native_concat(data)
        assert expected == res, '%r != %r: %r %r' % (expected, res, type(expected), type(res))

    test([], None)
    test(['foo'], 'foo')
    test(['foo', 'bar'], 'foobar')
    test(['foo', 123], 'foo123')
    test(['foo', u'bar'], 'foobar')
    test([u'foo', u'bar'], 'foobar')
    test(['foo', u'ж'], 'fooж')
    test([u'foo', u'ж'], 'fooж')

# Generated at 2022-06-22 14:27:18.388305
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    env = jinja2.Environment(extensions=['jinja2.ext.do'])
    env.globals['ansible_native_concat'] = ansible_native_concat
    env.globals['to_text'] = to_text
    env.globals['type'] = type
    env.globals['repr'] = repr

    def case(name, *expectations):
        for expression, expectation in expectations:
            # This can be used to debug a single test case.
            # if name == 'to_text() | int(base=10)':
            #     print(repr(expression), repr(expectation))
            template = '{{ (expr | ansible_native_concat) | type }} == ' + repr(type(expectation))
           

# Generated at 2022-06-22 14:27:30.113565
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat([1, 2, '3']) == 123
    assert ansible_native_concat([1, [2, 3]]) == '[2, 3]'
    assert ansible_native_concat([1, [2, '3']]) == '[2, 3]'
    assert ansible_native_concat([1, {'x': 2, 'y': '3'}]) == "{'x': 2, 'y': 3}"
    assert ansible_native_concat([1, [[1]], 0]) == '[1]'

# Generated at 2022-06-22 14:27:42.554036
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([None]) is None
    assert ansible_native_concat([1, 2]) == u'1, 2'
    assert ansible_native_concat([1, 2, 3, 4]) == u'1, 2, 3, 4'
    assert ansible_native_concat([u'1', u'2']) == u'1, 2'
    assert ansible_native_concat([1, u'2', 3, u'4']) == u'1, 2, 3, 4'
    assert ansible_native_concat([1, u'2', 3, u'4']) == u'1, 2, 3, 4'

# Generated at 2022-06-22 14:27:55.124812
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == '123'
    assert ansible_native_concat(['1', '2', '3']) == 123
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'
    assert ansible_native_concat(['a', ['b'], 'c']) == 'abc'
    assert ansible_native_concat([['a', 'b'], 'c']) == 'abc'
    assert ansible_native_concat(['a', 'b', ['c']]) == 'abc'
    assert ansible_native_concat([['a', 'b'], ['c']]) == 'abc'

# Generated at 2022-06-22 14:28:06.790377
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import pytest
    from ansible.playbook.play_context import PlayContext
    from ansible.template import Templar
    from ansible.parsing.yaml.loader import AnsibleLoader
    from ansible.parsing.yaml.objects import AnsibleVaultEncryptedUnicode
    from ansible.utils.vault import VaultLib

    loader = AnsibleLoader(None, None)

    vault_secret = 'mysecreteveryverysecret'

    def t(value, variable_manager=None, loader=loader):
        variable_manager = variable_manager or ansible.vars.manager.VariableManager()
        templar = Templar(loader=loader, variables=variable_manager, fail_on_undefined=True)
        return templar.template(value, disable_lookups=True)


# Generated at 2022-06-22 14:28:19.985366
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['a']) == 'a'

    assert ansible_native_concat(['a', 'b']) == 'ab'
    assert ansible_native_concat(['a', 'b', 'c']) == 'abc'

    assert ansible_native_concat(['"a"', '"b"']) == 'ab'
    assert ansible_native_concat(['"a"', '"b"', '"c"']) == 'abc'

    assert ansible_native_concat(['1', '2']) == 12
    assert ansible_native_concat(['1', '2', '3']) == 123

    assert ansible_native_concat(['["a"]', '["b"]'])

# Generated at 2022-06-22 14:28:32.714464
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat(['abc']) == 'abc'
    assert ansible_native_concat([u"abc"]) == u"abc"
    # concatenate strings
    assert ansible_native_concat(['abc', 'def']) == u'abcdef'
    # concatenate a string and an int
    assert ansible_native_concat(['abc', 1]) == u'abc1'
    # concatenate a string and a dict
    assert ansible_native_concat(['abc', {'def': 'ghi'}]) == u'abcdef'
    # concatenate an int and a string, evaluate with ast.literal_eval
    assert ansible_native_concat([1, "abc"]) == 1
   

# Generated at 2022-06-22 14:28:45.622963
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([2, 3]) == u'2 3'
    assert ansible_native_concat([1, 2, 3]) == u'1 2 3'
    assert ansible_native_concat([1, 2, 3]) == u'1 2 3'
    assert ansible_native_concat(text_type(1)) == u'1'
    assert ansible_native_concat(text_type(1) + text_type(2)) == u'12'
    assert ansible_native_concat(text_type(1) + text_type(2) + text_type(3)) == u'123'

# Generated at 2022-06-22 14:28:58.201825
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    from ansible.module_utils.common.text.converters import to_native
    import unittest

    class TestNativeConcat(unittest.TestCase):
        def test_empty(self):
            self.assertEqual(None, to_native(ansible_native_concat([])))

        def test_one_string(self):
            self.assertEqual(to_native('test'), to_native(ansible_native_concat(['test'])))

        def test_two_strings(self):
            self.assertEqual(to_native('test \n'), to_native(ansible_native_concat(['test ', '\n'])))


# Generated at 2022-06-22 14:29:02.070222
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    # AnsibleVaultEncryptedUnicode is not decrypted because isinstance(data, AnsibleVaultEncryptedUnicode)
    # fallback on string concatenation

    res = ansible_native_concat(['foo', 'bar'])
    assert res == 'foobar'

    res = ansible_native_concat(['foo', 'bar', '42'])
    assert res == 'foobar42'

    res = ansible_native_conca

# Generated at 2022-06-22 14:29:12.561178
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:29:23.890177
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    def test_type(data):
        assert type(data) == type(ansible_native_concat(data))

    test_type([])
    test_type(['x'])
    test_type(['x' + ' ' + 'y'])
    test_type(['x', ' '])
    test_type([1, 2])
    test_type([1, '2'])
    test_type(['1', '2'])
    test_type(['foo', ' ', 'bar'])

    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([1, ' ']) == '1 '
    assert ansible_native_concat(['1', '2']) == 3
    assert ansible_native_concat(['foo', ' ', 'bar'])

# Generated at 2022-06-22 14:29:37.161638
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    def assert_function_generator(fn):
        """Create a function which can be used in tests to check
        that the given function applied to the arguments returns
        the expected result.

        Return the created function.
        """
        def assert_function(args, expected):
            """Return ``expected`` if ``fn(args)`` returns ``expected``.
            Otherwise, raise an AssertionError.
            """
            result = fn(list(args))
            assert result == expected, "Expected {} from ({}), got {}" \
                .format(expected, list(args), result)
            return result

        return assert_function

    assert_concat = assert_function_generator(ansible_native_concat)

    # Test for single node
    assert_concat([1], 1)

# Generated at 2022-06-22 14:29:45.727346
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) == None
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'
    assert ansible_native_concat(['1+1']) == 2

    assert ansible_native_concat([['a+b', 'b+c'], 'c+d']) == 'abc+db+cc+d'

    assert ansible_native_concat([None, 'foo', None]) == 'foo'
    assert ansible_native_concat([None, [None, 'foo', None], None]) == 'foo'

    assert ansible_native_concat(['foo', ' bar', AnsibleVaultEncryptedUnicode('baz')]) == 'foobarbaz'
    assert ans

# Generated at 2022-06-22 14:29:57.250573
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # 'foo' + 'bar'
    def ast_list(value):
        return [ast.Str(n) for n in value]

    ast_foo = ast_list('foo')
    ast_bar = ast_list('bar')

    # single string
    assert ansible_native_concat(ast_foo) == 'foo'

    # concatenated strings
    assert ansible_native_concat(ast_foo + ast_bar) == 'foobar'

    # concatenated strings, including spaces before and after
    assert ansible_native_concat([' '] + ast_foo + ast_bar + [' ']) == ' foo  bar '

    # concatenated with literal_eval
    assert ansible_native_concat(ast_list('1') + ast_list('+') + ast_list('2'))

# Generated at 2022-06-22 14:30:09.486832
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # copy/paste of upstream jinja2.nativetypes.NativeConcat
    def _test(input, expected):
        # The core of the function has been copied from upstream jinja2
        # unit test, with some minimal adjustments to work with the
        # latest upstream jinja2.
        nodes = [
            ast.NameConstant(v) for v in [None, True, False]
        ]
        nodes.extend([
            ast.Num(v) for v in [1, 1.0, 10 ** 25, -10 ** 25, 3.14]
        ])
        nodes.extend([
            ast.Str(v) for v in ['a', u'\u263a', '\U0001f3c3' * 1024]
        ])

# Generated at 2022-06-22 14:30:13.522935
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == [1, 2, 3]
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat(["foo", "bar"]) == "foobar"
    assert ansible_native_concat(["{{", "foo", "}}"]) == "{{foo}}"
    assert ansible_native_concat(["", ""]) == ""
    assert ansible_native_concat([]) is None



# Generated at 2022-06-22 14:30:23.251224
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None

    # single literals
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([42]) == 42
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([3.14]) == 3.14

    # single variables
    # TODO ansible_native_concat is_safe=True
    assert ansible_native_concat([NativeJinjaText('foo')]) == 'foo'
    assert ansible_native_concat([NativeJinjaText(42)]) == 42
    assert ansible_native_concat([NativeJinjaText(True)]) is True
    assert ansible_native_concat([NativeJinjaText(3.14)])

# Generated at 2022-06-22 14:30:34.065349
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    result = ansible_native_concat(['foo', 'bar'])
    assert result == 'foobar'

    result = ansible_native_concat(['foo', 'bar', 'baz'])
    assert result == 'foobarbaz'

    result = ansible_native_concat(['foo', '', 'bar'])
    assert result == 'foobar'

    result = ansible_native_concat(['foo', 'bar', None])
    assert result == 'foobar'

    result = ansible_native_concat([None, 'bar'])
    assert result == 'bar'

    result = ansible_native_concat(['foo', StrictUndefined()])
    assert result == 'foo'

    result = ansible_native_concat(['foo', u'bar'])
    assert result

# Generated at 2022-06-22 14:30:45.738203
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([1, 2, 3]) == 123
    assert ansible_native_concat([1, 2, u'3']) == 123
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'
    assert ansible_native_concat([1, u'b', u'c']) == u'1bc'
    assert container_to_text(ansible_native_concat([u'a', u'b', u'c'])) == u'abc'
    assert ansible_native_concat([u'{{ no_var }}', u'b', u'c']) == u'b{{ no_var }}c'

# Generated at 2022-06-22 14:30:58.088601
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # test that ansible_native_concat returns the value of a single node
    assert ansible_native_concat([u'foo']) == u'foo'
    assert ansible_native_concat([1]) == 1
    assert ansible_native_concat([True]) is True
    assert ansible_native_concat([False]) is False
    # test that ansible_native_concat returns the string concatenation of two
    # or more nodes
    assert ansible_native_concat([1, 2]) == u'12'
    assert ansible_native_concat([u'foo', u'bar']) == u'foobar'
    assert ansible_native_concat([1, u'foo']) == u'1foo'

# Generated at 2022-06-22 14:31:11.045668
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat([42, 'foo']) == '42foo'
    assert ansible_native_concat([None, 'foo']) == None
    assert ansible_native_concat(['foo']) == 'foo'
    assert ansible_native_concat([]) == None

    assert ansible_native_concat(['foo', ['bar', 'baz']]) == 'foo[\'bar\', \'baz\']'
    assert ansible_native_concat(['foo', ['bar', 'baz']]) == 'foo[\'bar\', \'baz\']'

# Generated at 2022-06-22 14:31:23.803436
# Unit test for function ansible_native_concat

# Generated at 2022-06-22 14:31:33.473985
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    # Test basic functionality
    assert ansible_native_concat(['foo', 'bar']) == 'foobar'
    assert ansible_native_concat(['foo', ' bar']) == 'foo bar'
    assert ansible_native_concat(['foo ', 'bar']) == 'foo bar'

    # Test list
    assert ansible_native_concat([[1, 2, 3], [4, 5, 6]]) == [1, 2, 3, 4, 5, 6]

    # Test dict
    assert ansible_native_concat([{'foo': 'bar'}, {'baz': 'blah'}]) == {'foo': 'bar', 'baz': 'blah'}

    # Test raw str
    assert ansible_native_concat(['1']) == 1
    assert ansible

# Generated at 2022-06-22 14:31:42.716126
# Unit test for function ansible_native_concat
def test_ansible_native_concat():

    assert ansible_native_concat([]) == None
    assert ansible_native_concat(['str']) == 'str'

    # Python 3 requires a u prefix, or it will not be considered a text string
    assert ansible_native_concat([u'this', u' ', u'is', u' ', u'string']) == 'this is string'
    assert ansible_native_concat([6, ' ', u'is', u' ', u'integer', u' ', 6]) == '6 is integer 6'

    assert ansible_native_concat([3]) == 3
    assert ansible_native_concat([3.0]) == 3.0
    assert ansible_native_concat([True]) == True
    assert ansible_native_concat(['true']) == 'true'

    native_jin

# Generated at 2022-06-22 14:31:52.460951
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    assert ansible_native_concat([]) is None
    assert ansible_native_concat([1, 2, 3]) == u'123'
    assert ansible_native_concat([1, 2, 3, 'a', 'b']) == u'123ab'
    assert ansible_native_concat([1, 2, 3, 'a', ' ', 'b']) == u'123a b'
    assert ansible_native_concat(u'abc') == u'abc'
    assert ansible_native_concat(u'a', u'b', u'c') == u'abc'
    assert ansible_native_concat([u'a', u'b', u'c']) == u'abc'

# Generated at 2022-06-22 14:32:03.515035
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    values = [
        None,
        True,
        '''
        foo:
          bar: baz
        '''
    ]

    for t in values:
        assert t == ansible_native_concat(t)

    data = [
        'foo',
        'bar'
    ]

    assert 'foo' == ansible_native_concat(data[:1])
    assert 'foobar' == ansible_native_concat(data)

    for t in values:
        assert t == ansible_native_concat(iter(t))

    assert 'foobar' == ansible_native_concat(iter(data))

    assert 'foobar' == ansible_native_concat(iter(chain(data[:1], data)))



# Generated at 2022-06-22 14:32:15.925078
# Unit test for function ansible_native_concat
def test_ansible_native_concat():
    import jinja2
    env = jinja2.Environment(keep_trailing_newline=True)

    # Non-string values do not pass thru literal_eval
    assert ansible_native_concat(env.compile_expression('123')) == 123
    assert ansible_native_concat(env.compile_expression('[1, 2, 3]')) == [1, 2, 3]

    # Concatenation of non-string values does not pass thru literal_eval
    # Note: when using ansible_native_concat, the result is always a string
    assert isinstance(ansible_native_concat(env.compile_expression('[1, 2, 3] + [4, 5, 6]')), text_type)

    # Strings do pass thru literal_eval
    assert ansible_native_